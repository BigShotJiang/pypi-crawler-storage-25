"""Executor factory: returns the appropriate executor for a given config."""

import logging

from ..config.settings import AgentConfig
from .base import BaseExecutor

logger = logging.getLogger(__name__)


class ConfigError(Exception):
    """Raised when adapter configuration is invalid."""


def get_executor(config: AgentConfig) -> BaseExecutor:
    """
    Reads adapter type from AgentConfig and returns the appropriate executor.
    Raises ConfigError if the adapter type is not supported.
    """
    adapter_type = config.adapter_type.lower()
    kwargs = config.adapter_kwargs or {}

    match adapter_type:
        case "duckdb":
            from .duckdb_exec import DuckDBExecutor

            database = kwargs.get("path") or kwargs.get("database") or ":memory:"
            return DuckDBExecutor(database=database)

        case "postgres" | "postgresql" | "redshift":
            from .postgres_exec import PostgresExecutor

            return PostgresExecutor(
                host=kwargs.get("host", "localhost"),
                port=int(kwargs.get("port", 5432)),
                database=kwargs.get("dbname") or kwargs.get("database", "postgres"),
                user=kwargs.get("user", "postgres"),
                password=kwargs.get("password", ""),
                schema=kwargs.get("schema", "public"),
            )

        case "bigquery":
            from .bigquery_exec import BigQueryExecutor

            return BigQueryExecutor(
                project=kwargs.get("project", ""),
                dataset=kwargs.get("dataset", ""),
                keyfile=kwargs.get("keyfile") or kwargs.get("keyfile_json"),
            )

        case "snowflake":
            from .snowflake_exec import SnowflakeExecutor

            return SnowflakeExecutor(
                account=kwargs.get("account", ""),
                user=kwargs.get("user", ""),
                password=kwargs.get("password", ""),
                warehouse=kwargs.get("warehouse", ""),
                database=kwargs.get("database", ""),
                schema=kwargs.get("schema", "public"),
                role=kwargs.get("role"),
            )

        case _:
            supported = ["duckdb", "postgres", "bigquery", "snowflake"]
            raise ConfigError(
                f"Unsupported adapter type '{adapter_type}'. "
                f"Supported adapters: {', '.join(supported)}"
            )
