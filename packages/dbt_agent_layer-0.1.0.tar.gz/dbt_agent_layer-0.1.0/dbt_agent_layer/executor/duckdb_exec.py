"""DuckDB executor adapter."""

import logging
from typing import Any

from .base import BaseExecutor

logger = logging.getLogger(__name__)


class DuckDBExecutor(BaseExecutor):
    """Execute SQL against a DuckDB database (file or in-memory)."""

    def __init__(self, database: str = ":memory:", **kwargs: Any) -> None:
        self._database = database
        self._conn: Any = None

    def _get_conn(self) -> Any:
        """Lazy-init DuckDB connection."""
        if self._conn is None:
            try:
                import duckdb
            except ImportError:
                raise ImportError(
                    "duckdb is not installed. Run: pip install 'dbt-agent-layer[duckdb]'"
                )
            self._conn = duckdb.connect(self._database)
        return self._conn

    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL and return list of row dicts."""
        conn = self._get_conn()
        logger.debug("DuckDB executing: %s", sql[:200])
        try:
            rel = conn.execute(sql)
            columns = [desc[0] for desc in rel.description]
            rows = rel.fetchall()
            return [dict(zip(columns, row)) for row in rows]
        except Exception as e:
            logger.error("DuckDB execution error: %s", e)
            raise

    async def test_connection(self) -> bool:
        """Test DuckDB connectivity."""
        try:
            conn = self._get_conn()
            conn.execute("SELECT 1")
            return True
        except Exception as e:
            logger.error("DuckDB connection test failed: %s", e)
            return False

    def get_adapter_type(self) -> str:
        return "duckdb"

    def close(self) -> None:
        """Close the connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
