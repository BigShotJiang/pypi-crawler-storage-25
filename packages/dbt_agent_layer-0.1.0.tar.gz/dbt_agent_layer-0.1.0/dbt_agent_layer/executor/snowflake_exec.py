"""Snowflake executor adapter."""

import asyncio
import logging
from typing import Any

from .base import BaseExecutor

logger = logging.getLogger(__name__)


class SnowflakeExecutor(BaseExecutor):
    """Execute SQL against Snowflake (async via run_in_executor)."""

    def __init__(
        self,
        account: str = "",
        user: str = "",
        password: str = "",
        warehouse: str = "",
        database: str = "",
        schema: str = "public",
        role: str | None = None,
        private_key_path: str | None = None,
        **kwargs: Any,
    ) -> None:
        self._account = account
        self._user = user
        self._password = password
        self._warehouse = warehouse
        self._database = database
        self._schema = schema
        self._role = role
        self._private_key_path = private_key_path
        self._conn: Any = None

    def _get_conn(self) -> Any:
        """Lazy-init Snowflake connection."""
        if self._conn is None:
            try:
                import snowflake.connector
            except ImportError:
                raise ImportError(
                    "snowflake-connector-python is not installed. "
                    "Run: pip install 'dbt-agent-layer[snowflake]'"
                )
            connect_kwargs: dict[str, Any] = {
                "account": self._account,
                "user": self._user,
                "warehouse": self._warehouse,
                "database": self._database,
                "schema": self._schema,
            }
            if self._role:
                connect_kwargs["role"] = self._role
            if self._password:
                connect_kwargs["password"] = self._password
            self._conn = snowflake.connector.connect(**connect_kwargs)
        return self._conn

    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL and return list of row dicts."""
        logger.debug("Snowflake executing: %s", sql[:200])
        conn = self._get_conn()

        def _run() -> list[dict]:
            cursor = conn.cursor(snowflake.connector.DictCursor)
            cursor.execute(sql)
            return cursor.fetchall()

        return await asyncio.get_event_loop().run_in_executor(None, _run)

    async def test_connection(self) -> bool:
        """Test Snowflake connectivity."""
        try:
            await self.execute("SELECT 1")
            return True
        except Exception as e:
            logger.error("Snowflake connection test failed: %s", e)
            return False

    def get_adapter_type(self) -> str:
        return "snowflake"
