"""PostgreSQL executor adapter using asyncpg."""

import logging
from typing import Any

from .base import BaseExecutor

logger = logging.getLogger(__name__)


class PostgresExecutor(BaseExecutor):
    """Execute SQL against PostgreSQL using asyncpg."""

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "postgres",
        user: str = "postgres",
        password: str = "",
        schema: str = "public",
        **kwargs: Any,
    ) -> None:
        self._host = host
        self._port = port
        self._database = database
        self._user = user
        self._password = password
        self._schema = schema
        self._pool: Any = None

    async def _get_pool(self) -> Any:
        """Lazy-init asyncpg connection pool."""
        if self._pool is None:
            try:
                import asyncpg
            except ImportError:
                raise ImportError(
                    "asyncpg is not installed. Run: pip install 'dbt-agent-layer[postgres]'"
                )
            self._pool = await asyncpg.create_pool(
                host=self._host,
                port=self._port,
                database=self._database,
                user=self._user,
                password=self._password,
            )
        return self._pool

    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL and return list of row dicts."""
        pool = await self._get_pool()
        logger.debug("Postgres executing: %s", sql[:200])
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql)
            return [dict(row) for row in rows]

    async def test_connection(self) -> bool:
        """Test PostgreSQL connectivity."""
        try:
            pool = await self._get_pool()
            async with pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            return True
        except Exception as e:
            logger.error("Postgres connection test failed: %s", e)
            return False

    def get_adapter_type(self) -> str:
        return "postgres"
