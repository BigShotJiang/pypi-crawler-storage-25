"""Parse schema.yml files across a dbt project for metric definitions."""

import logging
from pathlib import Path

import yaml

from .models import DbtMetric

logger = logging.getLogger(__name__)


def parse_schema_files(project_dir: str) -> list[DbtMetric]:
    """
    Walk project_dir, find all .yml files, extract metrics: and semantic_models: blocks.
    Returns merged list of DbtMetric objects.

    This is a fallback / supplemental parser for when manifest.json is not available.
    Prefer manifest.py when manifest.json exists.
    """
    project_path = Path(project_dir).expanduser().resolve()
    metrics: list[DbtMetric] = []

    yml_files = list(project_path.rglob("*.yml")) + list(project_path.rglob("*.yaml"))

    for yml_path in yml_files:
        # Skip dbt_project.yml, profiles.yml, dbt-agent.yml
        if yml_path.name in ("dbt_project.yml", "profiles.yml", "dbt-agent.yml"):
            continue
        try:
            with open(yml_path) as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            logger.debug("Skipping %s: YAML parse error: %s", yml_path, e)
            continue

        if not isinstance(data, dict):
            continue

        # Legacy metrics block
        for m in data.get("metrics", []):
            if not isinstance(m, dict) or not m.get("name"):
                continue
            metrics.append(_parse_legacy_metric(m))

        # Semantic models block (dbt >= 1.6)
        semantic_models = data.get("semantic_models", [])
        # Collect measure-to-model mappings for dimension resolution
        measure_model_map: dict[str, dict] = {}
        for sm in semantic_models:
            if not isinstance(sm, dict):
                continue
            model_name = sm.get("model", "").replace("ref('", "").rstrip("')")
            for measure in sm.get("measures", []):
                if isinstance(measure, dict):
                    measure_model_map[measure.get("name", "")] = {
                        "model": model_name,
                        "dimensions": sm.get("dimensions", []),
                    }

        for m in data.get("metrics", []):
            # Already handled in legacy block above if no type_params
            type_params = m.get("type_params", {})
            if not type_params:
                continue
            metrics.append(_parse_semantic_metric(m, measure_model_map))

    # Deduplicate by name, preferring later entries
    seen: dict[str, DbtMetric] = {}
    for metric in metrics:
        seen[metric.name] = metric
    return list(seen.values())


def _parse_legacy_metric(m: dict) -> DbtMetric:
    """Parse a single legacy metrics: entry from schema.yml."""
    raw_dims = m.get("dimensions", [])
    dimensions = [d if isinstance(d, str) else d.get("name", "") for d in raw_dims]

    model_ref = m.get("model", "")
    if isinstance(model_ref, str):
        model_ref = model_ref.replace("ref('", "").rstrip("')")

    timestamp_col = m.get("timestamp")
    if isinstance(timestamp_col, list):
        timestamp_col = timestamp_col[0] if timestamp_col else None

    return DbtMetric(
        name=m.get("name", ""),
        label=m.get("label") or m.get("name", ""),
        description=m.get("description"),
        type=m.get("calculation_method") or m.get("type", "simple"),
        sql=m.get("sql") or m.get("expression"),
        measure=None,
        model=model_ref or None,
        dimensions=dimensions,
        timestamp_column=timestamp_col,
        filters=m.get("filters", []),
        meta=m.get("meta", {}),
        format=m.get("meta", {}).get("format") if isinstance(m.get("meta"), dict) else None,
        currency=m.get("meta", {}).get("currency") if isinstance(m.get("meta"), dict) else None,
    )


def _parse_semantic_metric(m: dict, measure_model_map: dict[str, dict]) -> DbtMetric:
    """Parse a semantic layer metric entry."""
    type_params = m.get("type_params", {})
    measure_name = type_params.get("measure")
    if isinstance(measure_name, dict):
        measure_name = measure_name.get("name")

    sm_info = measure_model_map.get(measure_name or "", {})
    raw_dims = sm_info.get("dimensions", [])

    dimensions = []
    timestamp_col = None
    for d in raw_dims:
        if isinstance(d, dict):
            if d.get("type") == "time":
                timestamp_col = d.get("name")
            else:
                dimensions.append(d.get("name", ""))
        else:
            dimensions.append(str(d))

    return DbtMetric(
        name=m.get("name", ""),
        label=m.get("label") or m.get("name", ""),
        description=m.get("description"),
        type=m.get("type", "simple"),
        sql=None,
        measure=measure_name,
        model=sm_info.get("model"),
        dimensions=dimensions,
        timestamp_column=timestamp_col,
        filters=[],
        meta=m.get("meta", {}),
        format=m.get("meta", {}).get("format") if isinstance(m.get("meta"), dict) else None,
        currency=m.get("meta", {}).get("currency") if isinstance(m.get("meta"), dict) else None,
    )
