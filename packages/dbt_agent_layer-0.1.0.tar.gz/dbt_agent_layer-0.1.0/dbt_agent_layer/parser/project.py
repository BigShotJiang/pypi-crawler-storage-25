"""Read and resolve dbt_project.yml metadata."""

import logging
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


class DbtProject:
    """Reads dbt_project.yml and resolves key settings."""

    def __init__(self, project_dir: str) -> None:
        self.project_dir = Path(project_dir).expanduser().resolve()
        yml_path = self.project_dir / "dbt_project.yml"
        if not yml_path.exists():
            raise FileNotFoundError(f"dbt_project.yml not found in {project_dir}")
        with open(yml_path) as f:
            self._data = yaml.safe_load(f) or {}

    @property
    def name(self) -> str:
        return self._data.get("name", "unknown")

    @property
    def version(self) -> str:
        return str(self._data.get("version", "0"))

    @property
    def profile(self) -> str:
        return self._data.get("profile", self.name)

    @property
    def target_path(self) -> Path:
        return self.project_dir / self._data.get("target-path", "target")

    @property
    def manifest_path(self) -> Path:
        return self.target_path / "manifest.json"

    @property
    def model_paths(self) -> list[Path]:
        paths = self._data.get("model-paths") or self._data.get("source-paths", ["models"])
        return [self.project_dir / p for p in paths]

    def find_manifest(self) -> Path:
        """Return path to manifest.json, raising if not found."""
        if not self.manifest_path.exists():
            raise FileNotFoundError(
                f"manifest.json not found at {self.manifest_path}. "
                "Run `dbt compile` or `dbt run` first."
            )
        return self.manifest_path
