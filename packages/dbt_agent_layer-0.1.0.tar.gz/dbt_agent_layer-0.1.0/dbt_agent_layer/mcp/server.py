"""FastMCP server: registers all metric tools and built-in tools."""

import logging
from datetime import datetime

from mcp.server.fastmcp import FastMCP

from ..config.settings import AgentConfig
from ..executor.base import BaseExecutor
from ..generator.tool_builder import build_tool_function
from ..parser.models import DbtMetric
from .schema import MetricDetail, MetricResult, MetricSummary

logger = logging.getLogger(__name__)

# Module-level FastMCP instance
mcp = FastMCP("dbt-agent-layer")

# Registry populated by register_all_tools()
_metric_registry: dict[str, DbtMetric] = {}
_executor_ref: BaseExecutor | None = None
_config_ref: AgentConfig | None = None


def create_server(
    metrics: list[DbtMetric],
    executor: BaseExecutor,
    config: AgentConfig,
) -> FastMCP:
    """
    Configure the FastMCP server with all metric tools and built-ins.
    Returns the configured mcp instance.
    """
    register_all_tools(metrics, executor, config)
    return mcp


def register_all_tools(
    metrics: list[DbtMetric],
    executor: BaseExecutor,
    config: AgentConfig,
) -> None:
    """
    Iterate over parsed metrics, generate tool functions, and register them.
    Also registers built-in tools: list_metrics, describe_metric, query_metric.
    """
    global _metric_registry, _executor_ref, _config_ref
    _executor_ref = executor
    _config_ref = config

    # Apply include/exclude filters
    filtered = _filter_metrics(metrics, config)

    for metric in filtered:
        _metric_registry[metric.name] = metric
        tool_fn = build_tool_function(metric, executor, config)
        mcp.tool()(tool_fn)
        logger.debug("Registered tool: get_%s", metric.name)

    logger.info(
        "Registered %d metric tools from %d total metrics.", len(filtered), len(metrics)
    )


def _filter_metrics(metrics: list[DbtMetric], config: AgentConfig) -> list[DbtMetric]:
    """Apply include/exclude filters from config."""
    if config.include_metrics:
        metrics = [m for m in metrics if m.name in config.include_metrics]
    if config.exclude_metrics:
        metrics = [m for m in metrics if m.name not in config.exclude_metrics]
    return metrics


# ---------------------------------------------------------------------------
# Built-in tools (always registered)
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_metrics() -> list[MetricSummary]:
    """
    List all available metrics in this dbt project.

    Returns name, label, description, and available dimensions for each metric.
    Call this first if you're unsure what metrics exist.
    """
    return [
        MetricSummary(
            name=m.name,
            label=m.label,
            description=m.description,
            dimensions=m.dimensions,
            example_query=f"get_{m.name}(period='current_month')",
        )
        for m in _metric_registry.values()
    ]


@mcp.tool()
async def describe_metric(metric_name: str) -> MetricDetail | dict:
    """
    Return full metadata for a metric: definition, SQL logic,
    available dimensions, example query, and timestamp column.
    """
    m = _metric_registry.get(metric_name)
    if m is None:
        available = list(_metric_registry.keys())
        return {
            "error": "METRIC_NOT_FOUND",
            "message": f"Metric '{metric_name}' not found.",
            "available_metrics": available,
        }
    return MetricDetail(
        name=m.name,
        label=m.label,
        description=m.description,
        dimensions=m.dimensions,
        example_query=f"get_{m.name}(period='current_month')",
        type=m.type,
        sql_definition=m.sql,
        model=m.model,
        timestamp_column=m.timestamp_column,
        filters=m.filters,
    )


@mcp.tool()
async def query_metric(
    metric_name: str,
    period: str = "current_month",
    compare_to: str = "prior_period",
    breakdown_by: str | None = None,
    filters: dict | None = None,
) -> MetricResult | dict:
    """
    Generic metric query tool. Use this when a specific named metric tool
    is not available or when metric_name is dynamic.

    Args:
        metric_name: Name of the metric to query (use list_metrics to discover).
        period: Time period (e.g. current_month, prior_month, 2024-03, last_30_days).
        compare_to: prior_period or prior_year.
        breakdown_by: Optional dimension to group by.
        filters: Optional dict of column → value filters.
    """
    from ..mcp.schema import ErrorResult

    m = _metric_registry.get(metric_name)
    if m is None:
        available = list(_metric_registry.keys())
        return {
            "error": "METRIC_NOT_FOUND",
            "message": (
                f"Metric '{metric_name}' not found. "
                f"Available metrics: {', '.join(available)}."
            ),
            "suggestions": available,
        }

    if _executor_ref is None or _config_ref is None:
        return {
            "error": "SERVER_NOT_INITIALIZED",
            "message": "Server not fully initialized. Try again shortly.",
        }

    tool_fn = build_tool_function(m, _executor_ref, _config_ref)
    return await tool_fn(
        period=period,
        compare_to=compare_to,
        breakdown_by=breakdown_by,
        filters=filters,
    )
