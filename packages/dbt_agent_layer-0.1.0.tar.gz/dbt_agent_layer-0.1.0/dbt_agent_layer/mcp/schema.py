"""Pydantic models for all MCP tool return types."""

from datetime import date, datetime

from pydantic import BaseModel

from ..generator.delta import DeltaResult
from ..generator.anomaly import AnomalyFlag


class ErrorResult(BaseModel):
    """Structured error returned when a tool call fails."""

    code: str  # e.g. "METRIC_NOT_FOUND"
    message: str
    suggestions: list[str] | None = None


class BreakdownRow(BaseModel):
    """A single row in a dimension breakdown."""

    dimension_value: str
    value: float
    formatted_value: str
    share_of_total: float  # 0.0 to 1.0


class MetricResult(BaseModel):
    """Full result returned by any metric tool."""

    # Core
    metric_name: str
    metric_label: str
    value: float
    formatted_value: str  # "$142,500" or "8.3%" or "1,204"
    unit: str | None  # "USD" | "%" | "users" | None

    # Period
    period_label: str  # "March 2024"
    period_start: date
    period_end: date

    # Delta
    delta: DeltaResult | None

    # Context
    narrative: str  # "MRR is $142,500 in March 2024, down 8.3%..."
    anomaly: AnomalyFlag | None

    # Breakdown (if breakdown_by was requested)
    breakdown: list[BreakdownRow] | None

    # Provenance
    sql_executed: str  # the actual SQL that ran (for debugging)
    executed_at: datetime
    data_freshness: str | None = None  # "as of 2024-03-31 06:00 UTC" if known

    # Error (set when tool call fails gracefully)
    error: ErrorResult | None = None

    model_config = {"arbitrary_types_allowed": True}


class MetricSummary(BaseModel):
    """Brief summary of a metric for list_metrics tool."""

    name: str
    label: str
    description: str | None
    dimensions: list[str]
    example_query: str  # "get_mrr(period='current_month')"


class MetricDetail(MetricSummary):
    """Full metadata for a metric (describe_metric tool)."""

    type: str
    sql_definition: str | None
    model: str | None
    timestamp_column: str | None
    filters: list[dict]
