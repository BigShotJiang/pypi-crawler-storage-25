"""MCP server module."""

from .server import create_server

__all__ = ["create_server"]
