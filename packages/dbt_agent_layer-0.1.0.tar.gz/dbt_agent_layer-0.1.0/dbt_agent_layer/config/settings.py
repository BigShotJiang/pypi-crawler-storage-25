"""Configuration loading and management for dbt-agent-layer."""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


@dataclass
class AgentConfig:
    """Full configuration for dbt-agent-layer."""

    # dbt project
    project_dir: str = "."
    profiles_dir: str = "~/.dbt"
    target: str = "dev"

    # adapter
    adapter_type: str = "duckdb"
    adapter_kwargs: dict = field(default_factory=dict)

    # server
    host: str = "0.0.0.0"
    port: int = 8000
    transport: str = "stdio"

    # metric behaviour
    default_period: str = "current_month"
    compare_to: str = "prior_period"
    include_metrics: list[str] = field(default_factory=list)
    exclude_metrics: list[str] = field(default_factory=list)

    # narrative
    narratives_enabled: bool = True
    narrative_style: str = "concise"


def _read_yaml(path: Path) -> dict:
    """Read a YAML file, returning empty dict on failure."""
    try:
        with open(path) as f:
            return yaml.safe_load(f) or {}
    except FileNotFoundError:
        return {}
    except yaml.YAMLError as e:
        logger.warning("Failed to parse YAML at %s: %s", path, e)
        return {}


def _detect_adapter_from_profiles(profiles_path: Path, target: str) -> tuple[str, dict]:
    """
    Read profiles.yml and extract adapter type + connection kwargs for a given target.
    Returns ("duckdb", {}) as fallback.
    """
    profiles = _read_yaml(profiles_path)
    for profile_name, profile in profiles.items():
        if not isinstance(profile, dict):
            continue
        outputs = profile.get("outputs", {})
        if target in outputs:
            cfg = outputs[target]
            adapter = cfg.get("type", "duckdb")
            return adapter, cfg
        # also check any output if target not found
        for output_name, cfg in outputs.items():
            if isinstance(cfg, dict):
                adapter = cfg.get("type", "duckdb")
                return adapter, cfg
    return "duckdb", {}


def load_config(project_dir: str = ".") -> AgentConfig:
    """
    Load configuration with priority (highest to lowest):
    1. Environment variables (DBT_AGENT_*)
    2. dbt-agent.yml in project_dir
    3. Auto-detection from dbt_project.yml + profiles.yml
    4. Defaults

    Environment variables:
      DBT_AGENT_ADAPTER_TYPE
      DBT_AGENT_PORT
      DBT_AGENT_TRANSPORT
      DBT_AGENT_TARGET
      DBT_AGENT_PROFILES_DIR
    """
    project_path = Path(project_dir).expanduser().resolve()
    config = AgentConfig(project_dir=str(project_path))

    # --- Step 3: auto-detect from dbt_project.yml ---
    dbt_project = _read_yaml(project_path / "dbt_project.yml")
    if dbt_project:
        config.target = dbt_project.get("target", config.target)

    # --- Step 2: dbt-agent.yml ---
    agent_yml = _read_yaml(project_path / "dbt-agent.yml")
    if agent_yml:
        proj = agent_yml.get("project", {})
        config.project_dir = str(
            (project_path / proj.get("dir", ".")).resolve()
        )
        config.profiles_dir = proj.get("profiles_dir", config.profiles_dir)
        config.target = proj.get("target", config.target)

        adapter = agent_yml.get("adapter", {})
        if "type" in adapter:
            config.adapter_type = adapter["type"]

        server = agent_yml.get("server", {})
        config.host = server.get("host", config.host)
        config.port = int(server.get("port", config.port))
        config.transport = server.get("transport", config.transport)

        metrics = agent_yml.get("metrics", {})
        config.include_metrics = metrics.get("include", config.include_metrics) or []
        config.exclude_metrics = metrics.get("exclude", config.exclude_metrics) or []
        config.default_period = metrics.get("default_period", config.default_period)
        config.compare_to = metrics.get("compare_to", config.compare_to)

        narratives = agent_yml.get("narratives", {})
        config.narratives_enabled = narratives.get("enabled", config.narratives_enabled)
        config.narrative_style = narratives.get("style", config.narrative_style)

    # --- Auto-detect adapter from profiles.yml ---
    profiles_dir = Path(config.profiles_dir).expanduser()
    profiles_path = profiles_dir / "profiles.yml"
    if profiles_path.exists():
        detected_type, detected_kwargs = _detect_adapter_from_profiles(
            profiles_path, config.target
        )
        if not agent_yml.get("adapter", {}).get("type"):
            config.adapter_type = detected_type
        config.adapter_kwargs = detected_kwargs

    # --- Step 1: environment variables ---
    if v := os.environ.get("DBT_AGENT_ADAPTER_TYPE"):
        config.adapter_type = v
    if v := os.environ.get("DBT_AGENT_PORT"):
        config.port = int(v)
    if v := os.environ.get("DBT_AGENT_TRANSPORT"):
        config.transport = v
    if v := os.environ.get("DBT_AGENT_TARGET"):
        config.target = v
    if v := os.environ.get("DBT_AGENT_PROFILES_DIR"):
        config.profiles_dir = v

    return config


def write_default_config(project_dir: str, adapter_type: str = "duckdb") -> Path:
    """Write a default dbt-agent.yml to project_dir."""
    config_path = Path(project_dir) / "dbt-agent.yml"
    content = f"""version: 1

project:
  dir: "."                      # path to dbt project
  profiles_dir: "~/.dbt"        # path to profiles.yml
  target: "dev"                 # dbt target to use

adapter:
  type: {adapter_type}           # postgres | bigquery | snowflake | duckdb

server:
  host: "0.0.0.0"
  port: 8000
  transport: "stdio"            # stdio | http (stdio for Claude Desktop)

metrics:
  include: []                   # empty = all metrics
  exclude: []
  default_period: "current_month"
  compare_to: "prior_period"    # prior_period | prior_year | both

narratives:
  enabled: true
  style: "concise"              # concise | detailed
"""
    config_path.write_text(content)
    return config_path
