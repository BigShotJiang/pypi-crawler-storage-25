"""dbt-agent build command."""

import json
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command()
@click.option(
    "--project-dir",
    default=".",
    show_default=True,
    help="Path to dbt project directory.",
    type=click.Path(file_okay=False),
)
@click.option(
    "--skip-compile",
    is_flag=True,
    default=False,
    help="Use existing manifest.json; skip dbt compile.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Print what would be generated; write nothing.",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Print each metric as it is parsed.",
)
def build_cmd(
    project_dir: str,
    skip_compile: bool,
    dry_run: bool,
    verbose: bool,
) -> None:
    """Parse the dbt project and generate MCP tool metadata."""
    from ..config.settings import load_config
    from ..parser.project import DbtProject
    from ..parser.manifest import DbtManifest

    project_path = Path(project_dir).expanduser().resolve()
    config = load_config(str(project_path))

    # 1. Compile dbt if needed
    if not skip_compile:
        with console.status("[bold blue]Running dbt compile...[/bold blue]"):
            result = subprocess.run(
                ["dbt", "compile", "--project-dir", str(project_path)],
                capture_output=True,
                text=True,
            )
        if result.returncode != 0:
            console.print("[yellow]dbt compile failed — trying existing manifest.json[/yellow]")
            console.print(f"[dim]{result.stderr[:500]}[/dim]")

    # 2. Find manifest
    try:
        dbt_project = DbtProject(str(project_path))
        manifest_path = dbt_project.find_manifest()
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    # 3. Parse metrics
    with console.status("[bold blue]Parsing metrics...[/bold blue]"):
        manifest = DbtManifest(str(manifest_path))
        metrics = manifest.get_metrics()

    # Apply include/exclude
    if config.include_metrics:
        metrics = [m for m in metrics if m.name in config.include_metrics]
    if config.exclude_metrics:
        metrics = [m for m in metrics if m.name not in config.exclude_metrics]

    if verbose:
        for m in metrics:
            console.print(
                f"  [green]✓[/green] [bold]{m.name}[/bold] "
                f"({m.type}) — {m.description or m.label}"
            )

    # 4. Write manifest cache
    output_dir = project_path / "dbt_agent_tools"
    if not dry_run:
        output_dir.mkdir(exist_ok=True)
        cache = {
            "generated_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            "manifest_format": manifest.metric_format,
            "metrics": [
                {
                    "name": m.name,
                    "label": m.label,
                    "description": m.description,
                    "type": m.type,
                    "sql": m.sql,
                    "measure": m.measure,
                    "model": m.model,
                    "dimensions": m.dimensions,
                    "timestamp_column": m.timestamp_column,
                    "filters": m.filters,
                    "meta": m.meta,
                    "warehouse_table": m.warehouse_table,
                    "format": m.format,
                    "currency": m.currency,
                }
                for m in metrics
            ],
        }
        cache_path = output_dir / "manifest_cache.json"
        cache_path.write_text(json.dumps(cache, indent=2))

    # 5. Summary table
    table = Table(title="Metrics discovered", show_lines=True)
    table.add_column("Name", style="cyan")
    table.add_column("Label")
    table.add_column("Type", style="dim")
    table.add_column("Dimensions", style="dim")

    for m in metrics:
        table.add_row(m.name, m.label, m.type, ", ".join(m.dimensions) or "—")

    console.print(table)

    action = "Would generate" if dry_run else "Generated"
    console.print(
        f"\n[bold green]{action}[/bold green] [bold]{len(metrics)}[/bold] metric tools"
        + (f" → [cyan]{output_dir}[/cyan]" if not dry_run else "")
    )
