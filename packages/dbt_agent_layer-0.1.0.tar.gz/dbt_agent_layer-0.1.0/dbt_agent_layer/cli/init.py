"""dbt-agent init command."""

from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

console = Console()


@click.command()
@click.option(
    "--project-dir",
    default=".",
    show_default=True,
    help="Path to dbt project directory.",
    type=click.Path(exists=True, file_okay=False),
)
@click.option(
    "--adapter",
    default=None,
    help="Warehouse adapter (postgres|bigquery|snowflake|duckdb). Auto-detected if not set.",
    type=click.Choice(["postgres", "bigquery", "snowflake", "duckdb"], case_sensitive=False),
)
def init_cmd(project_dir: str, adapter: str | None) -> None:
    """Initialise dbt-agent-layer in a dbt project."""
    import yaml

    from ..config.settings import write_default_config, _detect_adapter_from_profiles

    project_path = Path(project_dir).expanduser().resolve()

    # Detect dbt project
    dbt_project_yml = project_path / "dbt_project.yml"
    if not dbt_project_yml.exists():
        console.print(
            f"[red]Error:[/red] dbt_project.yml not found in {project_path}. "
            "Are you inside a dbt project directory?"
        )
        raise SystemExit(1)

    with open(dbt_project_yml) as f:
        dbt_cfg = yaml.safe_load(f) or {}
    project_name = dbt_cfg.get("name", "unknown")

    # Auto-detect adapter from profiles.yml
    detected_adapter = adapter
    if not detected_adapter:
        target = dbt_cfg.get("target", "dev")
        for profiles_dir in [project_path, Path.home() / ".dbt"]:
            profiles_path = profiles_dir / "profiles.yml"
            if profiles_path.exists():
                detected_adapter, _ = _detect_adapter_from_profiles(profiles_path, target)
                break
        detected_adapter = detected_adapter or "duckdb"

    # Write config
    config_path = write_default_config(str(project_path), adapter_type=detected_adapter)

    console.print(
        Panel(
            f"[bold green]dbt-agent-layer initialised[/bold green]\n\n"
            f"  dbt project : [cyan]{project_name}[/cyan]\n"
            f"  adapter     : [cyan]{detected_adapter}[/cyan]\n"
            f"  config      : [cyan]{config_path}[/cyan]\n\n"
            "[bold]Next steps:[/bold]\n"
            "  1. Edit [cyan]dbt-agent.yml[/cyan] if needed\n"
            "  2. Run [bold]dbt-agent build[/bold] to generate tools\n"
            "  3. Run [bold]dbt-agent serve[/bold] to start the MCP server",
            title="dbt-agent init",
            border_style="green",
        )
    )
