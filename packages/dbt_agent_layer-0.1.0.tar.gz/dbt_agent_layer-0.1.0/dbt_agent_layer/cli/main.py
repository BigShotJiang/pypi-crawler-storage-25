"""Main CLI entrypoint — groups all dbt-agent commands."""

import click

from .init import init_cmd
from .build import build_cmd
from .serve import serve_cmd


@click.group()
@click.version_option(package_name="dbt-agent-layer")
def cli() -> None:
    """dbt-agent-layer: Make your dbt metrics queryable by AI agents via MCP."""


cli.add_command(init_cmd, name="init")
cli.add_command(build_cmd, name="build")
cli.add_command(serve_cmd, name="serve")
