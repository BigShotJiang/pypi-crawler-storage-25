"""dbt-agent-layer: Make your dbt metrics queryable by AI agents via MCP."""

__version__ = "0.1.0"
