"""Simple statistical anomaly detection for metrics."""

import logging
import math
from dataclasses import dataclass
from datetime import date

from ..executor.base import BaseExecutor
from ..parser.models import DbtMetric

logger = logging.getLogger(__name__)


@dataclass
class AnomalyFlag:
    """Result of anomaly detection for a metric value."""

    is_anomaly: bool
    severity: str | None  # "low" | "medium" | "high"
    description: str | None  # "Value is 2.3 std devs below 90-day mean"
    baseline_mean: float | None
    baseline_std: float | None


async def detect_anomaly(
    metric: DbtMetric,
    current_value: float,
    current_period: tuple[date, date],
    executor: BaseExecutor,
    lookback_periods: int = 12,
) -> AnomalyFlag:
    """
    Detect if a metric value is anomalous vs historical baseline.

    Method: compute mean and std of last N monthly periods.
    Flag if current value is > 2 std deviations from mean.

    Returns AnomalyFlag(is_anomaly=False) gracefully if not enough history.
    Never raises — anomaly detection is best-effort.
    """
    try:
        return await _run_detection(
            metric, current_value, current_period, executor, lookback_periods
        )
    except Exception as e:
        logger.debug("Anomaly detection failed for %s (non-fatal): %s", metric.name, e)
        return AnomalyFlag(
            is_anomaly=False,
            severity=None,
            description=None,
            baseline_mean=None,
            baseline_std=None,
        )


async def _run_detection(
    metric: DbtMetric,
    current_value: float,
    current_period: tuple[date, date],
    executor: BaseExecutor,
    lookback_periods: int,
) -> AnomalyFlag:
    """Internal: run the actual anomaly detection query."""
    from dateutil.relativedelta import relativedelta

    from .tool_builder import build_metric_sql

    current_start, current_end = current_period

    # Collect historical values for the past N monthly periods
    historical: list[float] = []
    for i in range(1, lookback_periods + 1):
        period_start = (current_start - relativedelta(months=i)).replace(day=1)
        import calendar
        last_day = calendar.monthrange(period_start.year, period_start.month)[1]
        period_end = period_start.replace(day=last_day)

        try:
            sql = build_metric_sql(
                metric=metric,
                start_date=period_start,
                end_date=period_end,
                adapter_type=executor.get_adapter_type(),
            )
            rows = await executor.execute(sql)
            if rows:
                val = rows[0].get("value")
                if val is not None:
                    historical.append(float(val))
        except Exception:
            continue

    if len(historical) < 3:
        return AnomalyFlag(
            is_anomaly=False,
            severity=None,
            description=None,
            baseline_mean=None,
            baseline_std=None,
        )

    mean = sum(historical) / len(historical)
    variance = sum((x - mean) ** 2 for x in historical) / len(historical)
    std = math.sqrt(variance)

    if std == 0:
        return AnomalyFlag(
            is_anomaly=False,
            severity=None,
            description=f"Value is {current_value:.2f} (baseline mean: {mean:.2f}, std: 0).",
            baseline_mean=mean,
            baseline_std=std,
        )

    z_score = abs(current_value - mean) / std

    if z_score < 2.0:
        return AnomalyFlag(
            is_anomaly=False,
            severity=None,
            description=None,
            baseline_mean=mean,
            baseline_std=std,
        )

    direction = "above" if current_value > mean else "below"
    description = (
        f"Value is {z_score:.1f} std devs {direction} the "
        f"{len(historical)}-period mean ({mean:.2f})."
    )

    if z_score >= 3.0:
        severity = "high"
    elif z_score >= 2.5:
        severity = "medium"
    else:
        severity = "low"

    return AnomalyFlag(
        is_anomaly=True,
        severity=severity,
        description=description,
        baseline_mean=mean,
        baseline_std=std,
    )
