"""
Core generator: converts DbtMetric definitions into async tool functions.
"""

import logging
from collections.abc import Callable
from datetime import date, datetime

from ..executor.base import BaseExecutor
from ..parser.models import DbtMetric

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Period resolution
# ---------------------------------------------------------------------------

def resolve_period(period: str) -> tuple[date, date]:
    """
    Resolve a period string to a (start_date, end_date) tuple.

    Accepts:
    - "current_month"     → first/last day of current month
    - "prior_month"       → first/last day of last month
    - "current_quarter"   → current quarter bounds
    - "prior_quarter"
    - "current_year"
    - "prior_year"
    - "2024-03"           → March 2024
    - "2024-Q1"           → Q1 2024
    - "last_7_days"
    - "last_30_days"
    - "last_90_days"
    - ISO date range "2024-01-01:2024-03-31"
    """
    import calendar
    from dateutil.relativedelta import relativedelta

    today = date.today()

    def _month_range(d: date) -> tuple[date, date]:
        last = calendar.monthrange(d.year, d.month)[1]
        return d.replace(day=1), d.replace(day=last)

    def _quarter_range(d: date) -> tuple[date, date]:
        q_start_month = ((d.month - 1) // 3) * 3 + 1
        q_start = d.replace(month=q_start_month, day=1)
        q_end_month = q_start_month + 2
        q_end_day = calendar.monthrange(d.year, q_end_month)[1]
        q_end = d.replace(month=q_end_month, day=q_end_day)
        return q_start, q_end

    match period:
        case "current_month":
            return _month_range(today)
        case "prior_month":
            prior = today - relativedelta(months=1)
            return _month_range(prior)
        case "current_quarter":
            return _quarter_range(today)
        case "prior_quarter":
            prior = today - relativedelta(months=3)
            return _quarter_range(prior)
        case "current_year":
            return date(today.year, 1, 1), date(today.year, 12, 31)
        case "prior_year":
            y = today.year - 1
            return date(y, 1, 1), date(y, 12, 31)
        case "last_7_days":
            return today - relativedelta(days=6), today
        case "last_30_days":
            return today - relativedelta(days=29), today
        case "last_90_days":
            return today - relativedelta(days=89), today

    # ISO year-month: "2024-03"
    if len(period) == 7 and period[4] == "-":
        try:
            d = datetime.strptime(period, "%Y-%m").date()
            return _month_range(d)
        except ValueError:
            pass

    # Quarter string: "2024-Q1"
    if len(period) == 7 and "Q" in period:
        try:
            year_str, q_str = period.split("-Q")
            year = int(year_str)
            quarter = int(q_str)
            q_start_month = (quarter - 1) * 3 + 1
            import calendar as cal
            q_end_month = q_start_month + 2
            q_start = date(year, q_start_month, 1)
            q_end = date(year, q_end_month, cal.monthrange(year, q_end_month)[1])
            return q_start, q_end
        except (ValueError, IndexError):
            pass

    # ISO range: "2024-01-01:2024-03-31"
    if ":" in period:
        parts = period.split(":", 1)
        try:
            start = date.fromisoformat(parts[0])
            end = date.fromisoformat(parts[1])
            return start, end
        except ValueError:
            pass

    raise ValueError(
        f"Cannot parse period '{period}'. "
        "Use: current_month, prior_month, current_quarter, prior_quarter, "
        "current_year, last_7_days, last_30_days, last_90_days, "
        "2024-03, 2024-Q1, or 2024-01-01:2024-03-31"
    )


# ---------------------------------------------------------------------------
# SQL builder
# ---------------------------------------------------------------------------

_DATE_TRUNC: dict[str, str] = {
    "postgres": "DATE_TRUNC('{grain}', {col})",
    "postgresql": "DATE_TRUNC('{grain}', {col})",
    "redshift": "DATE_TRUNC('{grain}', {col})",
    "bigquery": "DATE_TRUNC({col}, {GRAIN})",
    "snowflake": "DATE_TRUNC('{grain}', {col})",
    "duckdb": "DATE_TRUNC('{grain}', {col})",
}


def _date_literal(d: date, adapter: str) -> str:
    """Format a date literal for the given adapter."""
    if adapter == "bigquery":
        return f"DATE '{d.isoformat()}'"
    return f"'{d.isoformat()}'"


def _safe_identifier(name: str) -> str:
    """Strip any characters that could cause SQL injection in identifiers."""
    import re
    return re.sub(r"[^\w]", "_", name)


def build_metric_sql(
    metric: DbtMetric,
    start_date: date,
    end_date: date,
    breakdown_by: str | None = None,
    filters: dict | None = None,
    adapter_type: str = "postgres",
) -> str:
    """
    Build parameterized SQL for a metric query.

    Handles:
    - Date range filtering on timestamp_column
    - Optional GROUP BY for breakdown_by dimension
    - Additional filters dict
    - Adapter-specific date functions

    Returns executable SQL string (values interpolated safely — no user-supplied
    identifiers are injected without sanitisation).
    """
    adapter = adapter_type.lower()

    # Determine the table reference
    table = metric.warehouse_table or metric.model or metric.name
    if not table:
        raise ValueError(f"Metric '{metric.name}' has no resolvable table reference.")

    # Determine the aggregation expression
    if metric.sql:
        agg_expr = metric.sql
    elif metric.measure:
        # For semantic layer, use measure name as column by convention
        agg_expr = f"SUM({_safe_identifier(metric.measure)})"
    else:
        agg_expr = "COUNT(*)"

    # Build SELECT
    select_parts = [f"{agg_expr} AS value"]

    # Breakdown column
    breakdown_col = None
    if breakdown_by:
        # Only allow dimensions declared on the metric
        allowed = [d.lower() for d in metric.dimensions]
        if breakdown_by.lower() not in allowed and breakdown_by not in metric.dimensions:
            raise ValueError(
                f"Dimension '{breakdown_by}' not available for metric '{metric.name}'. "
                f"Available: {metric.dimensions}"
            )
        breakdown_col = _safe_identifier(breakdown_by)
        select_parts.insert(0, breakdown_col)

    sql_select = ", ".join(select_parts)

    # Build WHERE
    where_parts: list[str] = []

    # Date filter
    if metric.timestamp_column:
        ts_col = _safe_identifier(metric.timestamp_column)
        start_lit = _date_literal(start_date, adapter)
        end_lit = _date_literal(end_date, adapter)
        if adapter == "bigquery":
            where_parts.append(f"{ts_col} BETWEEN {start_lit} AND {end_lit}")
        else:
            where_parts.append(
                f"{ts_col} >= {start_lit} AND {ts_col} <= {end_lit}"
            )

    # Static metric filters
    for f in metric.filters or []:
        if isinstance(f, dict):
            field_name = _safe_identifier(f.get("field", ""))
            operator = f.get("operator", "=")
            value = f.get("value", "")
            # Only allow safe operators
            if operator not in ("=", "!=", "<", ">", "<=", ">=", "IN", "NOT IN", "LIKE"):
                operator = "="
            if isinstance(value, str):
                value = f"'{value}'"
            elif isinstance(value, (list, tuple)):
                value = "(" + ", ".join(f"'{v}'" if isinstance(v, str) else str(v) for v in value) + ")"
            else:
                value = str(value)
            if field_name:
                where_parts.append(f"{field_name} {operator} {value}")
        elif isinstance(f, str):
            # Raw SQL filter (trust the dbt metric definition)
            where_parts.append(f)

    # Additional runtime filters (dict of col → value)
    if filters:
        for col, val in filters.items():
            safe_col = _safe_identifier(col)
            if isinstance(val, str):
                where_parts.append(f"{safe_col} = '{val}'")
            elif isinstance(val, (int, float)):
                where_parts.append(f"{safe_col} = {val}")

    where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

    # GROUP BY
    group_clause = f"GROUP BY {breakdown_col}" if breakdown_col else ""

    sql = f"SELECT {sql_select} FROM {table} {where_clause} {group_clause}".strip()
    # Collapse extra spaces
    import re
    sql = re.sub(r"\s+", " ", sql)
    return sql


# ---------------------------------------------------------------------------
# Tool function builder
# ---------------------------------------------------------------------------

def build_tool_function(
    metric: DbtMetric,
    executor: BaseExecutor,
    config: "AgentConfig | None" = None,  # noqa: F821
) -> Callable:
    """
    Dynamically generate an async tool function for a given metric.

    Generated function signature (example for MRR metric):

        async def get_mrr(
            period: str = "current_month",
            compare_to: str = "prior_period",
            breakdown_by: str | None = None,
            filters: dict | None = None,
        ) -> MetricResult: ...

    The function name is: f"get_{metric.name}"
    The docstring is: metric.description or metric.label
    """
    from ..mcp.schema import MetricResult, ErrorResult, BreakdownRow
    from .delta import compute_delta
    from .narrative import generate_narrative, _format_value
    from .anomaly import detect_anomaly

    default_period = config.default_period if config else "current_month"
    default_compare_to = config.compare_to if config else "prior_period"
    narratives_enabled = config.narratives_enabled if config else True
    narrative_style = config.narrative_style if config else "concise"

    async def tool_fn(
        period: str = default_period,
        compare_to: str = default_compare_to,
        breakdown_by: str | None = None,
        filters: dict | None = None,
    ) -> MetricResult:
        executed_at = datetime.now(__import__("datetime").timezone.utc)

        # 1. Resolve period
        try:
            start_date, end_date = resolve_period(period)
        except ValueError as e:
            return MetricResult(
                metric_name=metric.name,
                metric_label=metric.label,
                value=0,
                formatted_value="",
                unit=None,
                period_label=period,
                period_start=date.today(),
                period_end=date.today(),
                delta=None,
                narrative="",
                anomaly=None,
                breakdown=None,
                sql_executed="",
                executed_at=executed_at,
                error=ErrorResult(
                    code="PERIOD_PARSE_ERROR",
                    message=str(e),
                    suggestions=[
                        "current_month", "prior_month", "2024-03",
                        "last_30_days", "2024-01-01:2024-03-31",
                    ],
                ),
            )

        # 2. Build and execute SQL
        try:
            sql = build_metric_sql(
                metric=metric,
                start_date=start_date,
                end_date=end_date,
                breakdown_by=breakdown_by,
                filters=filters,
                adapter_type=executor.get_adapter_type(),
            )
        except ValueError as e:
            return MetricResult(
                metric_name=metric.name,
                metric_label=metric.label,
                value=0,
                formatted_value="",
                unit=None,
                period_label=period,
                period_start=start_date,
                period_end=end_date,
                delta=None,
                narrative="",
                anomaly=None,
                breakdown=None,
                sql_executed="",
                executed_at=executed_at,
                error=ErrorResult(
                    code="DIMENSION_NOT_AVAILABLE",
                    message=str(e),
                    suggestions=metric.dimensions,
                ),
            )

        try:
            rows = await executor.execute(sql)
        except Exception as e:
            logger.error("SQL execution failed for %s: %s", metric.name, e)
            return MetricResult(
                metric_name=metric.name,
                metric_label=metric.label,
                value=0,
                formatted_value="",
                unit=None,
                period_label=_period_label_from_dates(start_date, end_date),
                period_start=start_date,
                period_end=end_date,
                delta=None,
                narrative="",
                anomaly=None,
                breakdown=None,
                sql_executed=sql,
                executed_at=executed_at,
                error=ErrorResult(
                    code="SQL_EXECUTION_ERROR",
                    message=f"Query failed: {str(e)[:200]}",
                    suggestions=None,
                ),
            )

        # 3. Extract value
        if not rows:
            value = 0.0
            breakdown_result = None
        elif breakdown_by:
            # Multiple rows — build breakdown
            total = sum(float(r.get("value", 0)) for r in rows)
            breakdown_result = [
                BreakdownRow(
                    dimension_value=str(r.get(breakdown_by, "")),
                    value=float(r.get("value", 0)),
                    formatted_value=_format_value(
                        float(r.get("value", 0)), metric.format, metric.currency
                    ),
                    share_of_total=float(r.get("value", 0)) / total if total else 0.0,
                )
                for r in rows
            ]
            value = total
        else:
            value = float(rows[0].get("value", 0))
            breakdown_result = None

        formatted_value = _format_value(value, metric.format, metric.currency)
        period_label = _period_label_from_dates(start_date, end_date)

        # 4. Delta
        delta = await compute_delta(
            metric=metric,
            current_period=(start_date, end_date),
            compare_to=compare_to,
            executor=executor,
            filters=filters,
        )

        # 5. Narrative
        narrative = ""
        if narratives_enabled:
            narrative = generate_narrative(
                metric_name=metric.name,
                metric_label=metric.label,
                value=value,
                period_label=period_label,
                metric_format=metric.format,
                currency=metric.currency,
                delta=delta,
                style=narrative_style,
            )

        # 6. Anomaly (best-effort, only for non-breakdown queries)
        anomaly = None
        if not breakdown_by:
            anomaly = await detect_anomaly(
                metric=metric,
                current_value=value,
                current_period=(start_date, end_date),
                executor=executor,
            )

        return MetricResult(
            metric_name=metric.name,
            metric_label=metric.label,
            value=value,
            formatted_value=formatted_value,
            unit=metric.currency or (
                "%" if metric.format == "percentage" else None
            ),
            period_label=period_label,
            period_start=start_date,
            period_end=end_date,
            delta=delta,
            narrative=narrative,
            anomaly=anomaly,
            breakdown=breakdown_result,
            sql_executed=sql,
            executed_at=executed_at,
            error=None,
        )

    # Set function name and docstring for MCP tool registration
    fn_name = f"get_{metric.name}"
    tool_fn.__name__ = fn_name
    tool_fn.__qualname__ = fn_name
    tool_fn.__doc__ = metric.description or metric.label or metric.name

    return tool_fn


def _period_label_from_dates(start: date, end: date) -> str:
    """Produce a human-readable label for a date range."""
    import calendar
    last_day = calendar.monthrange(end.year, end.month)[1]
    if start.day == 1 and end.day == last_day and start.year == end.year and start.month == end.month:
        return start.strftime("%B %Y")
    return f"{start.isoformat()} to {end.isoformat()}"
