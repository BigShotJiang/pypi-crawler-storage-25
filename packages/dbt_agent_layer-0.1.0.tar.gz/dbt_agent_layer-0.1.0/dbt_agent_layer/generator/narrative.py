"""Generate natural-language narrative descriptions for metric results."""

import logging

logger = logging.getLogger(__name__)


def _format_value(value: float, metric_format: str | None, currency: str | None) -> str:
    """Format a numeric value based on metric format metadata."""
    if metric_format == "percentage" or (metric_format is None and abs(value) < 1 and value != 0):
        return f"{value * 100:.1f}%"
    if metric_format == "currency" or currency:
        symbol = "$" if (currency or "USD") == "USD" else currency or ""
        if abs(value) >= 1_000_000:
            return f"{symbol}{value / 1_000_000:.2f}M"
        if abs(value) >= 1_000:
            return f"{symbol}{value:,.0f}"
        return f"{symbol}{value:.2f}"
    if abs(value) >= 1_000:
        return f"{value:,.0f}"
    if value == int(value):
        return str(int(value))
    return f"{value:.2f}"


def generate_narrative(
    metric_name: str,
    metric_label: str,
    value: float,
    period_label: str,
    metric_format: str | None = None,
    currency: str | None = None,
    delta: "DeltaResult | None" = None,  # noqa: F821
    style: str = "concise",
) -> str:
    """
    Generate a factual narrative for a metric result.

    Examples:
      concise:
        "MRR is $142,500 in March 2024, down 8.3% vs February 2024 ($155,400)."

      detailed:
        "Monthly Recurring Revenue (MRR) stands at $142,500 for March 2024,
         representing an 8.3% decline ($12,900 decrease) compared to
         February 2024's $155,400."

    Rules:
    - Always include: metric name, current value, period, delta, comparison period
    - Format currency with $ and commas
    - Format percentages with 1 decimal place
    - Do NOT add interpretation or cause — that's the agent's job
    - Numbers must be factually accurate
    """
    formatted = _format_value(value, metric_format, currency)

    if delta is None:
        if style == "detailed":
            return (
                f"{metric_label} stands at {formatted} for {period_label}."
            )
        return f"{metric_label} is {formatted} in {period_label}."

    pct = abs(delta.percentage_change) * 100
    direction_word = {"up": "up", "down": "down", "flat": "flat"}.get(delta.direction, "changed")
    prior_formatted = _format_value(delta.prior_value, metric_format, currency)
    abs_change_formatted = _format_value(abs(delta.absolute_change), metric_format, currency)

    if style == "detailed":
        name_part = f"{metric_label} ({metric_name.upper()})" if metric_label != metric_name else metric_label
        if delta.direction == "flat":
            return (
                f"{name_part} stands at {formatted} for {period_label}, "
                f"essentially unchanged compared to {delta.prior_period_label}'s "
                f"{prior_formatted}."
            )
        return (
            f"{name_part} stands at {formatted} for {period_label}, "
            f"representing a {pct:.1f}% {direction_word} "
            f"({abs_change_formatted} {'increase' if delta.direction == 'up' else 'decrease'}) "
            f"compared to {delta.prior_period_label}'s {prior_formatted}."
        )

    # concise
    if delta.direction == "flat":
        return (
            f"{metric_label} is {formatted} in {period_label}, "
            f"flat vs {delta.prior_period_label} ({prior_formatted})."
        )
    return (
        f"{metric_label} is {formatted} in {period_label}, "
        f"{direction_word} {pct:.1f}% vs {delta.prior_period_label} ({prior_formatted})."
    )
