"""Generator module: builds tool functions and enriches metric results."""

from .tool_builder import build_tool_function, build_metric_sql, resolve_period
from .delta import compute_delta, DeltaResult
from .narrative import generate_narrative
from .anomaly import detect_anomaly, AnomalyFlag

__all__ = [
    "build_tool_function",
    "build_metric_sql",
    "resolve_period",
    "compute_delta",
    "DeltaResult",
    "generate_narrative",
    "detect_anomaly",
    "AnomalyFlag",
]
