"""Period-over-period delta computation."""

import logging
from dataclasses import dataclass
from datetime import date

from ..executor.base import BaseExecutor
from ..parser.models import DbtMetric

logger = logging.getLogger(__name__)


@dataclass
class DeltaResult:
    """Result of a period-over-period comparison."""

    current_value: float
    prior_value: float
    absolute_change: float
    percentage_change: float  # as decimal, e.g. 0.083 = 8.3%
    direction: str  # "up" | "down" | "flat"
    is_significant: bool  # abs(pct_change) > 0.05
    prior_period_label: str


def _is_full_calendar_month(start: date, end: date) -> bool:
    """Return True if start/end span exactly one full calendar month."""
    import calendar
    return (
        start.day == 1
        and end.day == calendar.monthrange(end.year, end.month)[1]
        and start.year == end.year
        and start.month == end.month
    )


def _prior_period_dates(
    current_start: date,
    current_end: date,
    compare_to: str,
) -> tuple[date, date]:
    """Compute the prior period date range."""
    import calendar
    from dateutil.relativedelta import relativedelta

    if compare_to == "prior_year":
        return (
            current_start - relativedelta(years=1),
            current_end - relativedelta(years=1),
        )

    # For "prior_period": if it's a full calendar month, use the prior calendar month.
    # Otherwise fall back to a fixed-length shift.
    if _is_full_calendar_month(current_start, current_end):
        prior_start = current_start - relativedelta(months=1)
        prior_end = prior_start.replace(
            day=calendar.monthrange(prior_start.year, prior_start.month)[1]
        )
        return prior_start, prior_end

    # Generic: shift by the period length
    period_len = (current_end - current_start).days + 1
    prior_end = current_start - relativedelta(days=1)
    prior_start = prior_end - relativedelta(days=period_len - 1)
    return prior_start, prior_end


def _period_label(start: date, end: date) -> str:
    """Human-readable label for a date range."""
    if start.day == 1 and (
        end.day == (date(end.year, end.month % 12 + 1, 1) - __import__("datetime").timedelta(days=1)).day
        if end.month < 12
        else end.day == 31
    ):
        import calendar
        last_day = calendar.monthrange(end.year, end.month)[1]
        if end.day == last_day:
            return start.strftime("%B %Y")
    return f"{start.isoformat()} to {end.isoformat()}"


async def compute_delta(
    metric: DbtMetric,
    current_period: tuple[date, date],
    compare_to: str,  # "prior_period" | "prior_year"
    executor: BaseExecutor,
    filters: dict | None = None,
) -> DeltaResult | None:
    """
    Compute period-over-period delta for a metric.
    Returns None gracefully if prior period query fails.
    """
    from .tool_builder import build_metric_sql

    current_start, current_end = current_period
    prior_start, prior_end = _prior_period_dates(current_start, current_end, compare_to)

    try:
        # Query current period
        current_sql = build_metric_sql(
            metric=metric,
            start_date=current_start,
            end_date=current_end,
            adapter_type=executor.get_adapter_type(),
            filters=filters,
        )
        current_rows = await executor.execute(current_sql)
        current_value = float(current_rows[0].get("value", 0)) if current_rows else 0.0

        # Query prior period
        prior_sql = build_metric_sql(
            metric=metric,
            start_date=prior_start,
            end_date=prior_end,
            adapter_type=executor.get_adapter_type(),
            filters=filters,
        )
        prior_rows = await executor.execute(prior_sql)
        prior_value = float(prior_rows[0].get("value", 0)) if prior_rows else 0.0

    except Exception as e:
        logger.warning("Delta computation failed for %s: %s", metric.name, e)
        return None

    absolute_change = current_value - prior_value
    if prior_value != 0:
        percentage_change = absolute_change / abs(prior_value)
    else:
        percentage_change = 0.0

    if abs(percentage_change) < 0.001:
        direction = "flat"
    elif absolute_change > 0:
        direction = "up"
    else:
        direction = "down"

    return DeltaResult(
        current_value=current_value,
        prior_value=prior_value,
        absolute_change=absolute_change,
        percentage_change=percentage_change,
        direction=direction,
        is_significant=abs(percentage_change) > 0.05,
        prior_period_label=_period_label(prior_start, prior_end),
    )
