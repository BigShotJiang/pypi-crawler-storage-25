# Project Specification: `dbt-agent-layer`

> **For:** AI coding agents (Claude Code, Cursor, GPT-4o in agentic mode)  
> **Purpose:** Build the `dbt-agent-layer` Python package from scratch  
> **Version target:** 0.1.0 (MVP / public beta)  
> **Estimated complexity:** Medium-Large (~2,500–4,000 lines of code)

---

## 1. What You Are Building

`dbt-agent-layer` is an open-source Python CLI and library that reads an existing dbt project and automatically generates an **MCP (Model Context Protocol) server** exposing all dbt metrics as callable agent tools.

### One-sentence pitch
> "dbt makes your data warehouse queryable by humans. dbt-agent-layer makes it queryable by agents."

### The problem it solves
Teams using AI agents for data analysis hit a wall: agents either hallucinate metrics (they invent numbers) or require hand-written SQL tool wrappers per KPI (which is unmaintainable). Neither works at scale.

dbt projects already contain the source of truth — metric definitions, SQL models, semantic layer configs — but they have no agent-facing interface. This package generates that interface automatically.

### What success looks like (demo target)
```bash
pip install dbt-agent-layer
cd my_dbt_project
dbt-agent serve

# → MCP server running at http://localhost:8000
# → User connects Claude Desktop or any MCP client
# → User asks: "What's our MRR trend and why did it drop in March?"
# → Agent calls get_mrr(period="2024-03"), receives value + delta + narrative + drivers
# → Agent answers accurately with no hallucination
```

---

## 2. Target Audience (Critical Context for Agent)

### Primary user: Analytics Engineer
- Writes and maintains the company's dbt project
- Fluent in SQL, Jinja, YAML
- Uses dbt Cloud or dbt Core (open-source)
- Currently frustrated: their agents give wrong numbers or need manual SQL wrappers
- Will find this via dbt Slack, GitHub, or a blog post
- Evaluates in < 10 minutes: if the demo doesn't work fast, they move on
- **Cares about:** correctness, not touching their existing dbt project, easy install

### Secondary user: Head of Data / VP Analytics
- Manages the analytics engineer
- Budget owner for tooling
- Will upgrade to a paid cloud version if OSS proves value
- **Cares about:** security, team collaboration, audit logs

### Anti-target (do NOT design for):
- Non-technical users
- Companies not using dbt
- Pure ML/AI teams without a data warehouse

---

## 3. Technical Architecture

### 3.1 High-level component map

```
dbt-agent-layer/
├── cli/                    # Click CLI entrypoints
│   ├── init.py             # dbt-agent init
│   ├── build.py            # dbt-agent build
│   └── serve.py            # dbt-agent serve
├── parser/                 # dbt project reader
│   ├── project.py          # reads dbt_project.yml
│   ├── manifest.py         # reads manifest.json (compiled dbt artifact)
│   ├── semantic_layer.py   # reads metrics: blocks in schema.yml / metrics.yml
│   └── models.py           # reads mart/model metadata
├── generator/              # tool + narrative generator
│   ├── tool_builder.py     # converts metric def → Python tool function
│   ├── delta.py            # period-over-period computation
│   ├── narrative.py        # generates natural language descriptions
│   └── anomaly.py          # simple anomaly flagging
├── executor/               # SQL execution layer
│   ├── base.py             # abstract executor interface
│   ├── duckdb_exec.py      # DuckDB adapter
│   ├── postgres_exec.py    # PostgreSQL adapter
│   ├── bigquery_exec.py    # BigQuery adapter
│   └── snowflake_exec.py   # Snowflake adapter
├── mcp/                    # MCP server
│   ├── server.py           # FastMCP server, tool registration
│   ├── tools.py            # auto-registered tool functions
│   └── schema.py           # MetricResult and other Pydantic models
├── config/                 # Configuration management
│   └── settings.py         # dbt-agent.yml reader, env var handling
└── tests/
    ├── fixtures/            # sample dbt project for testing
    └── ...
```

### 3.2 Data flow

```
dbt project on disk
       ↓
[Parser] reads manifest.json + schema.yml + metrics.yml
       ↓
[Generator] produces Python tool functions per metric
       ↓
[MCP Server] registers tools, starts HTTP server
       ↓
MCP client (Claude Desktop, any agent) calls tool
       ↓
[Executor] runs SQL against DWH adapter
       ↓
[Delta + Narrative] enriches raw number with context
       ↓
MetricResult returned to agent
```

---

## 4. Detailed Component Specifications

### 4.1 CLI

Built with **Click**. Three commands:

#### `dbt-agent init`
```
Usage: dbt-agent init [--project-dir PATH] [--adapter ADAPTER]

What it does:
- Detects dbt project in current dir or --project-dir
- Reads profiles.yml to detect DWH adapter (postgres/bigquery/snowflake/duckdb)
- Creates dbt-agent.yml config file in project root
- Prints next steps

Output file: dbt-agent.yml
```

**dbt-agent.yml structure:**
```yaml
version: 1

project:
  dir: "."                      # path to dbt project
  profiles_dir: "~/.dbt"        # path to profiles.yml
  target: "dev"                 # dbt target to use

adapter:
  type: postgres                # postgres | bigquery | snowflake | duckdb
  # connection details pulled from profiles.yml automatically
  # can be overridden here

server:
  host: "0.0.0.0"
  port: 8000
  transport: "stdio"            # stdio | http (stdio for Claude Desktop)

metrics:
  include: []                   # empty = all metrics
  exclude: []
  default_period: "current_month"
  compare_to: "prior_period"    # prior_period | prior_year | both

narratives:
  enabled: true
  style: "concise"              # concise | detailed
```

---

#### `dbt-agent build`
```
Usage: dbt-agent build [--project-dir PATH]

What it does:
- Runs dbt compile (or reads existing manifest.json if --skip-compile)
- Parses manifest.json for metric and model metadata
- Generates ./dbt_agent_tools/ directory with:
  - tools.py        (auto-generated tool functions)
  - schema.py       (Pydantic models)
  - manifest_cache.json (parsed metric registry)
- Prints summary: N metrics found, N tools generated

Flags:
  --skip-compile    use existing manifest.json, skip dbt compile
  --dry-run         print what would be generated, write nothing
  --verbose         print each metric as it's parsed
```

---

#### `dbt-agent serve`
```
Usage: dbt-agent serve [--project-dir PATH] [--port INT] [--transport stdio|http]

What it does:
- Runs dbt-agent build (unless --skip-build)
- Starts FastMCP server with all generated tools registered
- Default transport: stdio (for Claude Desktop)
- HTTP transport: for web-based MCP clients

Flags:
  --skip-build      use existing ./dbt_agent_tools/, skip build step
  --port INT        override port from dbt-agent.yml (default: 8000)
  --transport       stdio or http (default: stdio)
  --reload          hot-reload on dbt project changes (dev mode)
```

---

### 4.2 Parser

#### `parser/manifest.py`

dbt compiles a `manifest.json` artifact containing all models, metrics, and metadata. This is the primary input.

```python
class DbtManifest:
    """
    Reads and parses dbt's manifest.json.
    
    Key fields to extract:
    - manifest["metrics"]      → dict of metric definitions
    - manifest["nodes"]        → dict of model/source nodes  
    - manifest["sources"]      → dict of source definitions
    - manifest["semantic_models"] → new-style semantic layer (dbt >= 1.6)
    """
    
    def __init__(self, manifest_path: str): ...
    
    def get_metrics(self) -> list[DbtMetric]: ...
    def get_models(self) -> list[DbtModel]: ...
    def get_semantic_models(self) -> list[DbtSemanticModel]: ...
    def get_metric_by_name(self, name: str) -> DbtMetric: ...
```

**DbtMetric dataclass (must handle both old and new dbt metric formats):**
```python
@dataclass
class DbtMetric:
    name: str
    label: str                    # human-readable name
    description: str | None
    type: str                     # "simple" | "ratio" | "cumulative" | "derived"
    sql: str | None               # raw SQL expression (old format)
    measure: str | None           # measure name (new semantic layer format)
    model: str | None             # ref model name
    dimensions: list[str]         # available filter dimensions
    timestamp_column: str | None  # time dimension column
    filters: list[dict]           # default filters
    meta: dict                    # arbitrary metadata from schema.yml
    
    # derived by parser
    warehouse_table: str | None   # resolved fully-qualified table name
```

**Important:** dbt has two metric formats. Handle both:
- **Old format** (dbt < 1.6): `metrics:` block in schema.yml with `calculation_method`, `sql`, `model`
- **New semantic layer format** (dbt >= 1.6): `semantic_models:` + `metrics:` blocks with `measure` references

---

#### `parser/semantic_layer.py`

Parse `schema.yml` files across the dbt project for metric definitions. Walk the project directory tree, find all `*.yml` files, extract `metrics:` and `semantic_models:` blocks.

```python
def parse_schema_files(project_dir: str) -> list[DbtMetric]:
    """
    Walk project_dir, find all .yml files,
    extract metrics: and semantic_models: blocks.
    Returns merged list of DbtMetric objects.
    """
```

---

### 4.3 Generator

#### `generator/tool_builder.py`

This is the core of the package. Takes a `DbtMetric` and generates a Python function that:
1. Accepts natural parameters (period, dimensions, filters)
2. Builds the correct SQL query
3. Runs it via the executor
4. Returns a `MetricResult`

```python
def build_tool_function(metric: DbtMetric, executor: BaseExecutor) -> Callable:
    """
    Dynamically generates a tool function for a given metric.
    
    Generated function signature (example for MRR metric):
    
    async def get_mrr(
        period: str = "current_month",
        compare_to: str = "prior_period", 
        breakdown_by: str | None = None,
        filters: dict | None = None
    ) -> MetricResult:
        ...
    
    The function name is: f"get_{metric.name}"
    The docstring is: metric.description or metric.label
    """
```

**Period resolution logic** (implement carefully, this is user-facing):
```python
def resolve_period(period: str) -> tuple[date, date]:
    """
    Accepts natural language or ISO periods:
    - "current_month"     → first/last day of current month
    - "prior_month"       → first/last day of last month  
    - "current_quarter"   → current quarter bounds
    - "prior_quarter"
    - "current_year"
    - "2024-03"           → March 2024
    - "2024-Q1"           → Q1 2024
    - "last_7_days"
    - "last_30_days"
    - "last_90_days"
    - ISO date range "2024-01-01:2024-03-31"
    """
```

**SQL builder:**
```python
def build_metric_sql(
    metric: DbtMetric,
    start_date: date,
    end_date: date,
    breakdown_by: str | None = None,
    filters: dict | None = None,
    adapter_type: str = "postgres"
) -> str:
    """
    Builds parameterized SQL for a metric query.
    Handles:
    - Date range filtering on timestamp_column
    - Optional GROUP BY for breakdown_by dimension
    - Additional filters dict
    - Adapter-specific date functions (DATE_TRUNC varies by warehouse)
    
    Returns executable SQL string (no placeholders — values interpolated safely).
    """
```

---

#### `generator/delta.py`

Compute period-over-period comparisons.

```python
@dataclass  
class DeltaResult:
    current_value: float
    prior_value: float
    absolute_change: float
    percentage_change: float          # as decimal, e.g. 0.083 = 8.3%
    direction: str                    # "up" | "down" | "flat"
    is_significant: bool              # abs(pct_change) > 0.05

async def compute_delta(
    metric: DbtMetric,
    current_period: tuple[date, date],
    compare_to: str,                  # "prior_period" | "prior_year"
    executor: BaseExecutor,
    filters: dict | None = None
) -> DeltaResult: ...
```

---

#### `generator/narrative.py`

Converts a MetricResult into a human-readable sentence. This is used by the agent as context — it should be factual and concise, not fluffy.

```python
def generate_narrative(
    metric: DbtMetric,
    result: "MetricResult",
    style: str = "concise"    # "concise" | "detailed"
) -> str:
    """
    Examples of generated narratives:
    
    concise:
    "MRR is $142,500 in March 2024, down 8.3% vs February 2024 ($155,400)."
    
    detailed:
    "Monthly Recurring Revenue (MRR) stands at $142,500 for March 2024, 
     representing an 8.3% decline ($12,900 decrease) compared to February 2024's 
     $155,400. This is the second consecutive month of decline."
    
    Rules:
    - Always include: metric name, current value, period, delta, comparison period
    - Format currency with $ and commas
    - Format percentages with 1 decimal place
    - Do NOT add interpretation or cause — that's the agent's job
    - Numbers must be factually accurate (no rounding narratives)
    """
```

---

#### `generator/anomaly.py`

Simple statistical anomaly detection. No ML required for v0.1.

```python
@dataclass
class AnomalyFlag:
    is_anomaly: bool
    severity: str | None          # "low" | "medium" | "high"
    description: str | None       # "Value is 2.3 std devs below 90-day mean"
    baseline_mean: float | None
    baseline_std: float | None

async def detect_anomaly(
    metric: DbtMetric,
    current_value: float,
    current_period: tuple[date, date],
    executor: BaseExecutor,
    lookback_periods: int = 12    # months of history for baseline
) -> AnomalyFlag:
    """
    Method: compute mean and std of last N periods, flag if current value
    is > 2 std deviations from mean.
    
    Returns AnomalyFlag(is_anomaly=False) gracefully if not enough history.
    Never raise — anomaly detection is best-effort.
    """
```

---

### 4.4 Executor

Abstract interface + 4 adapters.

```python
# executor/base.py
from abc import ABC, abstractmethod

class BaseExecutor(ABC):
    
    @abstractmethod
    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL, return list of row dicts."""
    
    @abstractmethod
    async def test_connection(self) -> bool:
        """Ping the warehouse. Used on startup."""
    
    @abstractmethod
    def get_adapter_type(self) -> str:
        """Returns 'postgres' | 'bigquery' | 'snowflake' | 'duckdb'"""
```

**Adapter implementations:**

```python
# executor/postgres_exec.py
# Uses: asyncpg
# Connection: from dbt profiles.yml (host, port, dbname, user, password, schema)

# executor/bigquery_exec.py  
# Uses: google-cloud-bigquery (async via run_in_executor)
# Connection: project, dataset, credentials (ADC or service account JSON)

# executor/snowflake_exec.py
# Uses: snowflake-connector-python (async via run_in_executor)
# Connection: account, warehouse, database, schema, user, password/private_key

# executor/duckdb_exec.py
# Uses: duckdb
# Connection: database path or :memory:
# Primary use: local development with DuckDB-backed dbt projects
```

**Executor factory:**
```python
# executor/factory.py
def get_executor(config: AgentConfig) -> BaseExecutor:
    """
    Reads adapter type from dbt-agent.yml or auto-detects from profiles.yml.
    Returns appropriate executor instance.
    Raises ConfigError if adapter not supported.
    """
```

---

### 4.5 MCP Server

Built with **FastMCP** (the Python MCP SDK).

```python
# mcp/server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("dbt-agent-layer")

def register_all_tools(
    metrics: list[DbtMetric], 
    executor: BaseExecutor,
    config: AgentConfig
) -> None:
    """
    Iterates over parsed metrics.
    For each metric, calls build_tool_function() to generate a callable.
    Registers it with mcp.tool() decorator dynamically.
    
    Also registers these built-in tools (always present):
    - list_metrics()     → returns all available metric names + descriptions
    - describe_metric()  → returns full metadata for a named metric
    - get_dimensions()   → returns available dimensions for a metric
    """
```

**Built-in tools (always registered, regardless of dbt project):**

```python
@mcp.tool()
async def list_metrics() -> list[MetricSummary]:
    """
    List all available metrics in this dbt project.
    Returns name, label, description, available dimensions for each.
    Agent should call this first if unsure what metrics exist.
    """

@mcp.tool()
async def describe_metric(metric_name: str) -> MetricDetail:
    """
    Returns full metadata for a metric: definition, SQL logic,
    available dimensions, example query, typical value range.
    """

@mcp.tool()  
async def query_metric(
    metric_name: str,
    period: str = "current_month",
    compare_to: str = "prior_period",
    breakdown_by: str | None = None,
    filters: dict | None = None
) -> MetricResult:
    """
    Generic metric query tool. Use this when a specific metric tool
    is not available or when metric_name is dynamic.
    """
```

---

### 4.6 Pydantic Models

All tool return types. These must be clean because the agent reads them directly.

```python
# mcp/schema.py
from pydantic import BaseModel
from datetime import date

class MetricResult(BaseModel):
    # Core
    metric_name: str
    metric_label: str
    value: float
    formatted_value: str              # "$142,500" or "8.3%" or "1,204"
    unit: str | None                  # "USD" | "%" | "users" | None
    
    # Period
    period_label: str                 # "March 2024"
    period_start: date
    period_end: date
    
    # Delta
    delta: DeltaResult | None
    
    # Context
    narrative: str                    # "MRR is $142,500 in March 2024, down 8.3%..."
    anomaly: AnomalyFlag | None
    
    # Breakdown (if breakdown_by was requested)
    breakdown: list[BreakdownRow] | None
    
    # Provenance
    sql_executed: str                 # the actual SQL that ran (for debugging)
    executed_at: datetime
    data_freshness: str | None        # "as of 2024-03-31 06:00 UTC" if known

class BreakdownRow(BaseModel):
    dimension_value: str
    value: float
    formatted_value: str
    share_of_total: float             # 0.0 to 1.0

class MetricSummary(BaseModel):
    name: str
    label: str
    description: str | None
    dimensions: list[str]
    example_query: str                # "get_mrr(period='current_month')"

class MetricDetail(MetricSummary):
    type: str
    sql_definition: str | None
    model: str | None
    timestamp_column: str | None
    filters: list[dict]
```

---

## 5. Configuration & Settings

```python
# config/settings.py

@dataclass
class AgentConfig:
    # dbt project
    project_dir: str
    profiles_dir: str
    target: str
    
    # adapter
    adapter_type: str             # auto-detected from profiles.yml
    adapter_kwargs: dict          # connection params
    
    # server
    host: str
    port: int
    transport: str                # "stdio" | "http"
    
    # metric behavior  
    default_period: str
    compare_to: str
    include_metrics: list[str]    # empty = all
    exclude_metrics: list[str]
    
    # narrative
    narratives_enabled: bool
    narrative_style: str

def load_config(project_dir: str) -> AgentConfig:
    """
    Load priority (highest to lowest):
    1. Environment variables (DBT_AGENT_*)
    2. dbt-agent.yml in project_dir
    3. Auto-detection from dbt_project.yml + profiles.yml
    4. Defaults
    
    Environment variables:
    DBT_AGENT_ADAPTER_TYPE
    DBT_AGENT_PORT
    DBT_AGENT_TRANSPORT
    DBT_AGENT_TARGET
    DBT_AGENT_PROFILES_DIR
    """
```

---

## 6. Package Structure & Setup

### `pyproject.toml`
```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "dbt-agent-layer"
version = "0.1.0"
description = "Make your dbt metrics queryable by AI agents via MCP"
readme = "README.md"
requires-python = ">=3.10"
license = {text = "Apache-2.0"}

keywords = ["dbt", "mcp", "llm", "agents", "analytics", "metrics"]

classifiers = [
  "Development Status :: 3 - Alpha",
  "Intended Audience :: Developers",
  "Topic :: Software Development :: Libraries",
  "License :: OSI Approved :: Apache Software License",
]

dependencies = [
  "click>=8.1",
  "pydantic>=2.0",
  "mcp[cli]>=1.0",          # FastMCP
  "pyyaml>=6.0",
  "rich>=13.0",             # pretty CLI output
  "httpx>=0.27",
  "python-dateutil>=2.9",
]

[project.optional-dependencies]
postgres   = ["asyncpg>=0.29"]
bigquery   = ["google-cloud-bigquery>=3.0"]
snowflake  = ["snowflake-connector-python>=3.0"]
duckdb     = ["duckdb>=0.10"]
all        = [
  "asyncpg>=0.29",
  "google-cloud-bigquery>=3.0",
  "snowflake-connector-python>=3.0",
  "duckdb>=0.10",
]
dev        = [
  "pytest>=8.0",
  "pytest-asyncio>=0.23",
  "pytest-mock>=3.0",
  "ruff>=0.4",
  "mypy>=1.10",
]

[project.scripts]
dbt-agent = "dbt_agent_layer.cli:cli"

[project.urls]
Homepage = "https://github.com/[org]/dbt-agent-layer"
Documentation = "https://dbt-agent-layer.dev/docs"
Repository = "https://github.com/[org]/dbt-agent-layer"
```

---

## 7. Error Handling Requirements

All errors must be **agent-friendly**: the agent calling a tool should receive a structured error it can reason about, not a raw Python traceback.

```python
# Never do this in tool functions:
raise ValueError("metric not found")

# Always do this:
return MetricResult(
    error=ErrorResult(
        code="METRIC_NOT_FOUND",
        message="Metric 'revenue' not found. Available metrics: mrr, arr, churn_rate.",
        suggestions=["get_mrr", "get_arr"]
    )
)
```

**Error codes to handle:**
- `METRIC_NOT_FOUND` — metric name doesn't exist in registry
- `DIMENSION_NOT_AVAILABLE` — breakdown_by dim not in metric.dimensions
- `PERIOD_PARSE_ERROR` — period string not parseable
- `SQL_EXECUTION_ERROR` — DWH query failed (include sanitized error)
- `CONNECTION_ERROR` — can't reach DWH
- `INSUFFICIENT_DATA` — not enough history for delta/anomaly (return partial result)
- `PERMISSION_ERROR` — DWH access denied

Add `error: ErrorResult | None` field to `MetricResult`. When error is set, other fields may be None.

---

## 8. Testing Requirements

### Test fixtures
Create a minimal fake dbt project under `tests/fixtures/sample_dbt_project/`:
```
tests/fixtures/sample_dbt_project/
├── dbt_project.yml
├── profiles.yml           # points to DuckDB :memory:
├── models/
│   ├── marts/
│   │   ├── fct_revenue.sql
│   │   └── fct_users.sql
│   └── schema.yml         # includes 3-5 metrics definitions
└── target/
    └── manifest.json      # pre-compiled, for parser tests
```

### Required test coverage
```
tests/
├── test_parser.py          # manifest parsing, metric extraction
├── test_tool_builder.py    # SQL generation, period resolution
├── test_delta.py           # delta computation correctness
├── test_narrative.py       # narrative generation format
├── test_executor_duckdb.py # DuckDB adapter (no external deps needed)
├── test_mcp_server.py      # tool registration, response schema
└── test_cli.py             # init, build, serve commands
```

Minimum: parser + DuckDB executor + tool builder tests must pass. Other adapters can be marked `@pytest.mark.integration` and skipped in CI.

---

## 9. README Requirements

The README is a GTM asset, not just documentation. It must:

1. **Hero section**: one-liner + 3-step install + gif/screenshot (placeholder ok)
2. **Quick start**: working example in < 10 lines
3. **Supported sources**: table of DWH adapters + dbt version compatibility
4. **How it works**: simple diagram (ASCII ok) of the flow
5. **Configuration reference**: full dbt-agent.yml annotated
6. **Claude Desktop setup**: exact JSON snippet for claude_desktop_config.json
7. **Contributing**: how to add a new adapter
8. **License**: Apache 2.0

**Claude Desktop config snippet to include (critical for adoption):**
```json
{
  "mcpServers": {
    "dbt-metrics": {
      "command": "dbt-agent",
      "args": ["serve", "--project-dir", "/path/to/your/dbt/project"],
      "env": {}
    }
  }
}
```

---

## 10. dbt Version Compatibility

Must handle gracefully:

| dbt version | Metric format | Notes |
|---|---|---|
| < 1.0 | No metrics block | Skip gracefully, warn user |
| 1.0 – 1.5 | Old `metrics:` block in schema.yml | `calculation_method`, `sql`, `model` fields |
| 1.6+ | New semantic layer: `semantic_models:` + `metrics:` | `measure` references, `MetricFlow` |
| dbt Cloud | manifest.json via artifact API | Out of scope for v0.1, document as roadmap |

Detection logic:
```python
def detect_dbt_metric_format(manifest: dict) -> str:
    """Returns 'legacy' | 'semantic_layer' | 'none'"""
    if "semantic_models" in manifest and manifest["semantic_models"]:
        return "semantic_layer"
    if "metrics" in manifest and manifest["metrics"]:
        return "legacy"
    return "none"
```

---

## 11. What NOT to Build in v0.1

Explicitly out of scope. Do not implement:

- Authentication / API keys on the MCP server
- Multi-project support
- Caching of query results
- Web UI / dashboard
- dbt Cloud API integration
- Reverse ETL / writing back to sources
- Custom metric definitions (outside dbt project)
- Streaming / real-time metrics
- Team collaboration features
- Any paid/cloud features

These are v0.2+ or cloud-tier features.

---

## 12. Implementation Order (Recommended)

Follow this sequence to have a working demo as fast as possible:

```
Step 1: Package scaffold + CLI skeleton (click, pyproject.toml)
Step 2: Parser — read manifest.json, extract metrics (legacy format first)
Step 3: DuckDB executor (no external credentials needed for testing)
Step 4: Tool builder — generate one working tool function for one metric
Step 5: MCP server — register that one tool, start server, connect Claude Desktop
Step 6: Delta + narrative on top of working tool
Step 7: list_metrics + describe_metric built-ins
Step 8: Remaining adapters (postgres, bigquery, snowflake)
Step 9: Semantic layer format (dbt >= 1.6)
Step 10: Anomaly detection
Step 11: Tests + README
```

**Stop at step 5 and validate the demo works before continuing.**

---

## 13. Key Dependencies Summary

| Package | Version | Purpose |
|---|---|---|
| `click` | >= 8.1 | CLI framework |
| `pydantic` | >= 2.0 | Schema / validation |
| `mcp[cli]` | >= 1.0 | FastMCP server (official Anthropic MCP SDK) |
| `pyyaml` | >= 6.0 | YAML parsing |
| `rich` | >= 13.0 | Pretty terminal output |
| `python-dateutil` | >= 2.9 | Period/date parsing |
| `asyncpg` | >= 0.29 | Postgres async driver (optional) |
| `duckdb` | >= 0.10 | DuckDB driver (optional, default for dev) |
| `google-cloud-bigquery` | >= 3.0 | BigQuery (optional) |
| `snowflake-connector-python` | >= 3.0 | Snowflake (optional) |

Install MCP SDK:
```bash
pip install "mcp[cli]"
# official SDK: https://github.com/modelcontextprotocol/python-sdk
```

---

## 14. Coding Standards

- Python 3.10+ only (use match/case, `X | Y` union types, `str | None`)
- All public functions must have docstrings
- All tool return types must be Pydantic models (never raw dicts)
- Async-first: all executor methods and tool functions must be `async def`
- No print() in library code — use `logging` module
- CLI output uses `rich` (tables, panels, spinners)
- Type hints required on all function signatures
- Ruff for linting (included in dev deps)
- No secrets in code — all credentials via profiles.yml or env vars

---

*Spec version: 1.0 | Last updated: April 2026*
*Build target: dbt-agent-layer v0.1.0 (public beta)*
