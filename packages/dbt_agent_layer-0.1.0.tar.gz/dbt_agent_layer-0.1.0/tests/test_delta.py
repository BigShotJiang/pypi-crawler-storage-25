"""Tests for delta computation."""

from datetime import date

import pytest

from dbt_agent_layer.generator.delta import DeltaResult, _prior_period_dates, _period_label


class TestPriorPeriodDates:
    def test_prior_period(self) -> None:
        start = date(2024, 3, 1)
        end = date(2024, 3, 31)
        prior_start, prior_end = _prior_period_dates(start, end, "prior_period")
        assert prior_end == date(2024, 2, 29)
        assert prior_start == date(2024, 2, 1)

    def test_prior_year(self) -> None:
        start = date(2024, 3, 1)
        end = date(2024, 3, 31)
        prior_start, prior_end = _prior_period_dates(start, end, "prior_year")
        assert prior_start == date(2023, 3, 1)
        assert prior_end == date(2023, 3, 31)


class TestDeltaResult:
    def test_direction_up(self) -> None:
        d = DeltaResult(
            current_value=110,
            prior_value=100,
            absolute_change=10,
            percentage_change=0.10,
            direction="up",
            is_significant=True,
            prior_period_label="February 2024",
        )
        assert d.direction == "up"
        assert d.is_significant

    def test_direction_flat(self) -> None:
        d = DeltaResult(
            current_value=100,
            prior_value=100,
            absolute_change=0,
            percentage_change=0.0,
            direction="flat",
            is_significant=False,
            prior_period_label="February 2024",
        )
        assert not d.is_significant


class TestPeriodLabel:
    def test_full_month(self) -> None:
        label = _period_label(date(2024, 3, 1), date(2024, 3, 31))
        assert label == "March 2024"

    def test_partial_range(self) -> None:
        label = _period_label(date(2024, 3, 5), date(2024, 3, 20))
        assert "2024-03-05" in label
        assert "2024-03-20" in label
