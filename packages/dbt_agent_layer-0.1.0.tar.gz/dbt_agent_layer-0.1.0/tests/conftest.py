"""Shared pytest fixtures."""

import json
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "sample_dbt_project"
MANIFEST_PATH = FIXTURES_DIR / "target" / "manifest.json"


@pytest.fixture
def manifest_path() -> str:
    return str(MANIFEST_PATH)


@pytest.fixture
def manifest_data() -> dict:
    with open(MANIFEST_PATH) as f:
        return json.load(f)


@pytest.fixture
def sample_project_dir() -> str:
    return str(FIXTURES_DIR)
