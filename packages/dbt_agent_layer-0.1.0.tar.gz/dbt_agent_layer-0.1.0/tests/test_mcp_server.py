"""Tests for MCP server tool registration and response schema."""

import pytest
from datetime import date

from dbt_agent_layer.executor.duckdb_exec import DuckDBExecutor
from dbt_agent_layer.parser.models import DbtMetric
from dbt_agent_layer.config.settings import AgentConfig
from dbt_agent_layer.generator.tool_builder import build_tool_function
from dbt_agent_layer.mcp.schema import MetricResult, MetricSummary


@pytest.fixture
def simple_metric() -> DbtMetric:
    return DbtMetric(
        name="test_metric",
        label="Test Metric",
        description="A test metric",
        type="sum",
        sql="SUM(amount)",
        measure=None,
        model="fct_test",
        dimensions=["region"],
        timestamp_column="event_date",
        filters=[],
        meta={},
        warehouse_table=None,
        format="currency",
        currency="USD",
    )


@pytest.fixture
def duckdb_executor() -> DuckDBExecutor:
    executor = DuckDBExecutor(":memory:")
    return executor


@pytest.fixture
def config() -> AgentConfig:
    return AgentConfig(
        project_dir=".",
        narratives_enabled=True,
        narrative_style="concise",
        default_period="current_month",
        compare_to="prior_period",
    )


class TestToolFunction:
    @pytest.mark.asyncio
    async def test_tool_name(self, simple_metric, duckdb_executor, config) -> None:
        fn = build_tool_function(simple_metric, duckdb_executor, config)
        assert fn.__name__ == "get_test_metric"

    @pytest.mark.asyncio
    async def test_tool_docstring(self, simple_metric, duckdb_executor, config) -> None:
        fn = build_tool_function(simple_metric, duckdb_executor, config)
        assert fn.__doc__ == "A test metric"

    @pytest.mark.asyncio
    async def test_returns_metric_result_on_error(
        self, simple_metric, duckdb_executor, config
    ) -> None:
        """When the table doesn't exist, should return MetricResult with error."""
        # Metric references a non-existent table
        simple_metric.warehouse_table = "nonexistent.schema.table"
        fn = build_tool_function(simple_metric, duckdb_executor, config)
        result = await fn(period="2024-03")
        assert isinstance(result, MetricResult)
        assert result.error is not None
        assert result.error.code == "SQL_EXECUTION_ERROR"

    @pytest.mark.asyncio
    async def test_period_parse_error(
        self, simple_metric, duckdb_executor, config
    ) -> None:
        fn = build_tool_function(simple_metric, duckdb_executor, config)
        result = await fn(period="not-a-valid-period")
        assert isinstance(result, MetricResult)
        assert result.error is not None
        assert result.error.code == "PERIOD_PARSE_ERROR"

    @pytest.mark.asyncio
    async def test_successful_query(
        self, simple_metric, duckdb_executor, config
    ) -> None:
        """Set up real DuckDB table and query it."""
        await duckdb_executor.execute(
            """
            CREATE TABLE fct_test AS
            SELECT
                '2024-03-10'::DATE AS event_date,
                500.0 AS amount,
                'us-east' AS region
            UNION ALL
            SELECT '2024-03-20'::DATE, 300.0, 'us-west'
            """
        )
        simple_metric.warehouse_table = "fct_test"
        fn = build_tool_function(simple_metric, duckdb_executor, config)
        result = await fn(period="2024-03")
        assert isinstance(result, MetricResult)
        assert result.error is None
        assert result.value == 800.0
        assert result.metric_name == "test_metric"
        assert result.period_label == "March 2024"
        assert result.sql_executed != ""
        assert result.narrative != ""


class TestSchemaModels:
    def test_metric_summary(self) -> None:
        s = MetricSummary(
            name="mrr",
            label="MRR",
            description="Monthly Recurring Revenue",
            dimensions=["plan"],
            example_query="get_mrr(period='current_month')",
        )
        assert s.name == "mrr"
