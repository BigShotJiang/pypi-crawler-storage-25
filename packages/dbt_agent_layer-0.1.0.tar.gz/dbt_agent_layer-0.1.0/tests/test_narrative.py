"""Tests for narrative generation."""

import pytest

from dbt_agent_layer.generator.delta import DeltaResult
from dbt_agent_layer.generator.narrative import generate_narrative, _format_value


class TestFormatValue:
    def test_currency(self) -> None:
        assert _format_value(142500, "currency", "USD") == "$142,500"

    def test_small_currency(self) -> None:
        assert _format_value(99.5, "currency", "USD") == "$99.50"

    def test_millions(self) -> None:
        result = _format_value(1_500_000, "currency", "USD")
        assert "1.50M" in result or "M" in result

    def test_percentage(self) -> None:
        result = _format_value(0.083, "percentage", None)
        assert "8.3%" in result

    def test_plain_number(self) -> None:
        assert _format_value(1204, None, None) == "1,204"

    def test_integer(self) -> None:
        assert _format_value(100.0, None, None) == "100"


class TestGenerateNarrative:
    def test_concise_no_delta(self) -> None:
        narrative = generate_narrative(
            metric_name="monthly_revenue",
            metric_label="Monthly Revenue",
            value=142500,
            period_label="March 2024",
            metric_format="currency",
            currency="USD",
            delta=None,
            style="concise",
        )
        assert "Monthly Revenue" in narrative
        assert "$142,500" in narrative
        assert "March 2024" in narrative

    def test_concise_with_delta_down(self) -> None:
        delta = DeltaResult(
            current_value=142500,
            prior_value=155400,
            absolute_change=-12900,
            percentage_change=-0.083,
            direction="down",
            is_significant=True,
            prior_period_label="February 2024",
        )
        narrative = generate_narrative(
            metric_name="monthly_revenue",
            metric_label="Monthly Revenue",
            value=142500,
            period_label="March 2024",
            metric_format="currency",
            currency="USD",
            delta=delta,
            style="concise",
        )
        assert "down" in narrative
        assert "8.3%" in narrative
        assert "February 2024" in narrative

    def test_detailed_style(self) -> None:
        delta = DeltaResult(
            current_value=142500,
            prior_value=155400,
            absolute_change=-12900,
            percentage_change=-0.083,
            direction="down",
            is_significant=True,
            prior_period_label="February 2024",
        )
        narrative = generate_narrative(
            metric_name="monthly_revenue",
            metric_label="Monthly Revenue",
            value=142500,
            period_label="March 2024",
            metric_format="currency",
            currency="USD",
            delta=delta,
            style="detailed",
        )
        assert "decline" in narrative or "decrease" in narrative
        assert "8.3%" in narrative

    def test_flat_direction(self) -> None:
        delta = DeltaResult(
            current_value=100,
            prior_value=100,
            absolute_change=0,
            percentage_change=0.0,
            direction="flat",
            is_significant=False,
            prior_period_label="February 2024",
        )
        narrative = generate_narrative(
            metric_name="new_users",
            metric_label="New Users",
            value=100,
            period_label="March 2024",
            delta=delta,
            style="concise",
        )
        assert "flat" in narrative
