"""Tests for CLI commands."""

from pathlib import Path

import pytest
from click.testing import CliRunner

from dbt_agent_layer.cli.main import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def sample_project(tmp_path: Path) -> Path:
    """Create a minimal dbt project for CLI tests."""
    # dbt_project.yml
    (tmp_path / "dbt_project.yml").write_text(
        "name: test_project\nversion: '1.0.0'\nprofile: test_project\n"
        "model-paths: ['models']\ntarget-path: 'target'\n"
    )
    # profiles.yml in project dir
    (tmp_path / "profiles.yml").write_text(
        "test_project:\n  target: dev\n  outputs:\n    dev:\n"
        "      type: duckdb\n      path: ':memory:'\n"
    )
    # target/manifest.json (minimal)
    target_dir = tmp_path / "target"
    target_dir.mkdir()
    import json
    manifest = {
        "metadata": {},
        "nodes": {},
        "sources": {},
        "semantic_models": {},
        "metrics": {
            "metric.test.count": {
                "name": "count",
                "label": "Count",
                "description": "Row count",
                "calculation_method": "count",
                "sql": "COUNT(*)",
                "model": "ref('fct_test')",
                "timestamp": "created_at",
                "dimensions": [],
                "filters": [],
                "meta": {},
            }
        },
    }
    (target_dir / "manifest.json").write_text(json.dumps(manifest))
    return tmp_path


class TestInitCommand:
    def test_init_creates_config(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(cli, ["init", "--project-dir", str(sample_project)])
        assert result.exit_code == 0, result.output
        config_file = sample_project / "dbt-agent.yml"
        assert config_file.exists()

    def test_init_with_adapter(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(
            cli, ["init", "--project-dir", str(sample_project), "--adapter", "duckdb"]
        )
        assert result.exit_code == 0
        config = (sample_project / "dbt-agent.yml").read_text()
        assert "duckdb" in config

    def test_init_not_a_dbt_project(self, runner: CliRunner, tmp_path: Path) -> None:
        result = runner.invoke(cli, ["init", "--project-dir", str(tmp_path)])
        assert result.exit_code != 0


class TestBuildCommand:
    def test_build_dry_run(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(
            cli,
            [
                "build",
                "--project-dir",
                str(sample_project),
                "--skip-compile",
                "--dry-run",
            ],
        )
        assert result.exit_code == 0, result.output
        # No output dir created in dry-run
        assert not (sample_project / "dbt_agent_tools").exists()

    def test_build_creates_cache(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(
            cli,
            ["build", "--project-dir", str(sample_project), "--skip-compile"],
        )
        assert result.exit_code == 0, result.output
        cache = sample_project / "dbt_agent_tools" / "manifest_cache.json"
        assert cache.exists()

    def test_build_verbose(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(
            cli,
            ["build", "--project-dir", str(sample_project), "--skip-compile", "--verbose"],
        )
        assert result.exit_code == 0
        assert "count" in result.output
