"""Tests for manifest parsing and metric extraction."""

import pytest

from dbt_agent_layer.parser.manifest import DbtManifest, detect_dbt_metric_format
from dbt_agent_layer.parser.models import DbtMetric
from dbt_agent_layer.parser.semantic_layer import parse_schema_files


class TestDetectFormat:
    def test_legacy_format(self, manifest_data: dict) -> None:
        assert detect_dbt_metric_format(manifest_data) == "legacy"

    def test_semantic_layer_format(self) -> None:
        manifest = {"semantic_models": {"sm.foo": {}}, "metrics": {"m.foo": {}}}
        assert detect_dbt_metric_format(manifest) == "semantic_layer"

    def test_none_format(self) -> None:
        assert detect_dbt_metric_format({}) == "none"
        assert detect_dbt_metric_format({"metrics": {}}) == "none"


class TestDbtManifest:
    def test_load(self, manifest_path: str) -> None:
        m = DbtManifest(manifest_path)
        assert m.metric_format == "legacy"

    def test_get_metrics_count(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        metrics = manifest.get_metrics()
        assert len(metrics) == 4

    def test_metric_names(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        names = {m.name for m in manifest.get_metrics()}
        assert "monthly_revenue" in names
        assert "new_users" in names
        assert "revenue_per_user" in names
        assert "churn_rate" in names

    def test_metric_fields(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        metric = manifest.get_metric_by_name("monthly_revenue")
        assert metric is not None
        assert metric.label == "Monthly Revenue"
        assert metric.description == "Total revenue for the period"
        assert "channel" in metric.dimensions
        assert metric.timestamp_column == "order_month"
        assert metric.format == "currency"
        assert metric.currency == "USD"

    def test_get_metric_by_name_missing(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        assert manifest.get_metric_by_name("nonexistent") is None

    def test_get_models(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        models = manifest.get_models()
        assert len(models) == 2
        names = {m.name for m in models}
        assert "fct_revenue" in names
        assert "fct_users" in names

    def test_warehouse_table_resolved(self, manifest_path: str) -> None:
        manifest = DbtManifest(manifest_path)
        metric = manifest.get_metric_by_name("monthly_revenue")
        assert metric is not None
        # Should resolve to main.main.fct_revenue
        assert metric.warehouse_table is not None
        assert "fct_revenue" in metric.warehouse_table

    def test_manifest_not_found(self, tmp_path) -> None:
        with pytest.raises(FileNotFoundError):
            DbtManifest(str(tmp_path / "nonexistent.json"))


class TestSchemaFileParser:
    def test_parse_schema_files(self, sample_project_dir: str) -> None:
        metrics = parse_schema_files(sample_project_dir)
        names = {m.name for m in metrics}
        assert "monthly_revenue" in names
        assert "new_users" in names

    def test_metric_dimensions(self, sample_project_dir: str) -> None:
        metrics = parse_schema_files(sample_project_dir)
        rev = next((m for m in metrics if m.name == "monthly_revenue"), None)
        assert rev is not None
        assert "channel" in rev.dimensions
