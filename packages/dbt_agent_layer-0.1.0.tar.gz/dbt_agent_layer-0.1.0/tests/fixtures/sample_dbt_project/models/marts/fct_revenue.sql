SELECT
    date_trunc('month', order_date) AS order_month,
    SUM(amount) AS revenue,
    COUNT(DISTINCT customer_id) AS customer_count,
    channel
FROM {{ ref('stg_orders') }}
WHERE status = 'completed'
GROUP BY 1, 4
