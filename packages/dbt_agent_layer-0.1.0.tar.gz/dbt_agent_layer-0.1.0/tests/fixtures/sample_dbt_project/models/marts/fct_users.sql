SELECT
    date_trunc('month', created_at) AS signup_month,
    COUNT(*) AS new_users,
    plan_type
FROM {{ ref('stg_users') }}
GROUP BY 1, 3
