"""Tests for DuckDB executor."""

import pytest

from dbt_agent_layer.executor.duckdb_exec import DuckDBExecutor


@pytest.fixture
def executor() -> DuckDBExecutor:
    return DuckDBExecutor(database=":memory:")


class TestDuckDBExecutor:
    @pytest.mark.asyncio
    async def test_execute_simple(self, executor: DuckDBExecutor) -> None:
        rows = await executor.execute("SELECT 42 AS value")
        assert len(rows) == 1
        assert rows[0]["value"] == 42

    @pytest.mark.asyncio
    async def test_execute_multiple_rows(self, executor: DuckDBExecutor) -> None:
        rows = await executor.execute(
            "SELECT * FROM (VALUES (1, 'a'), (2, 'b')) t(id, name)"
        )
        assert len(rows) == 2
        assert rows[0]["id"] == 1
        assert rows[1]["name"] == "b"

    @pytest.mark.asyncio
    async def test_test_connection(self, executor: DuckDBExecutor) -> None:
        assert await executor.test_connection() is True

    def test_adapter_type(self, executor: DuckDBExecutor) -> None:
        assert executor.get_adapter_type() == "duckdb"

    @pytest.mark.asyncio
    async def test_execute_with_date_filter(self, executor: DuckDBExecutor) -> None:
        # Create a test table and query it
        await executor.execute(
            """
            CREATE TABLE IF NOT EXISTS test_revenue AS
            SELECT
                '2024-03-15'::DATE AS order_month,
                1000.0 AS revenue,
                'web' AS channel
            UNION ALL
            SELECT '2024-02-15'::DATE, 800.0, 'app'
            """
        )
        rows = await executor.execute(
            "SELECT SUM(revenue) AS value FROM test_revenue "
            "WHERE order_month >= '2024-03-01' AND order_month <= '2024-03-31'"
        )
        assert rows[0]["value"] == 1000.0

    @pytest.mark.asyncio
    async def test_execute_error(self, executor: DuckDBExecutor) -> None:
        with pytest.raises(Exception):
            await executor.execute("SELECT * FROM nonexistent_table_xyz")
