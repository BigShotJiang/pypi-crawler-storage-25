"""
### Tribulnation Latoken
> An SDK to connect Latoken with the Tribulnation ecosystem.

- Details
"""