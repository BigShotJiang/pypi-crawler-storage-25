from __future__ import annotations

from enum import Enum
from typing import Literal, NotRequired, TypedDict

from ..sensor import SensorType

PythonVersion = Literal["3.11", "3.12"]
"""Python interpreter major.minor version a Python plugin requires. The host
ensures a matching interpreter exists in its venv pool before launching the
plugin; Node and Go plugins ignore this field."""


class PluginRole(str, Enum):
    """Role a plugin plays in the system. The role decides which lifecycle
    hooks the host invokes and which contract validations apply."""

    Hub = "hub"
    """Cloud-service integration that manages its own cameras end-to-end via
    a vendor account (e.g. a vendor SDK / cloud API). The hub owns camera
    creation, streaming and sensors; it cannot expose sensors for cameras
    owned by other plugins."""

    SensorProvider = "sensorProvider"
    """Adds sensors to existing cameras without owning the camera itself.
    Typical use: a detection plugin that consumes another plugin's video
    frames and emits motion / object / face detections back into the
    system."""

    CameraController = "cameraController"
    """Manages cameras and their media streams (ONVIF, RTSP, generic IP, ...).
    The plugin is responsible for stream URLs, PTZ, snapshots, and the
    lifecycle hooks in BasePlugin. It does not produce sensors for foreign
    cameras."""

    CameraAndSensorProvider = "cameraAndSensorProvider"
    """Combined role: plugin both manages cameras and exposes sensors (its
    own cameras and, when ``consumes`` is set, also foreign cameras). Used
    by integrations that ship a complete camera + detection stack."""


class PluginInterface(str, Enum):
    """Capability flags a plugin advertises in its contract.

    The host uses these to decide which RPC handlers to wire up and which
    UI affordances to show.
    """

    MotionDetection = "MotionDetection"
    """Implements MotionDetectionInterface (video-based motion detection)."""

    ObjectDetection = "ObjectDetection"
    """Implements ObjectDetectionInterface (e.g. person, vehicle, animal)."""

    AudioDetection = "AudioDetection"
    """Implements AudioDetectionInterface (event/keyword audio detection)."""

    FaceDetection = "FaceDetection"
    """Implements FaceDetectionInterface (face localisation + embeddings).
    The NVR owns matching against enrolled faces; the plugin only emits
    detections + embeddings."""

    LicensePlateDetection = "LicensePlateDetection"
    """Implements LicensePlateDetectionInterface (plate localisation + OCR)."""

    ClassifierDetection = "ClassifierDetection"
    """Implements ClassifierDetectionInterface (generic image classification
    emitting attribute/label pairs)."""

    DiscoveryProvider = "DiscoveryProvider"
    """Implements DiscoveryProvider — plugin can scan the network for new
    cameras and adopt them. Only valid for camera-controlling roles."""

    NVR = "NVR"
    """Implements NVRInterface — persists events and recordings, and serves
    them back to the UI / mobile clients. Exactly one plugin per host fills
    this role at runtime."""

    Notifier = "Notifier"
    """Implements NotifierInterface (get_devices, send_notification, ...).
    Lets the central NotificationManager dispatch notifications to this
    plugin regardless of role — see camera_ui_sdk/plugin/notifier.py."""


class PluginContract(TypedDict):
    """Manifest contract a plugin declares so the host knows what it does
    and what it needs at load time. Validated by ``helper.py`` before the
    plugin is started."""

    name: str
    """Stable, unique identifier for the plugin instance — used as the
    registry key, log prefix and the storage namespace."""

    role: PluginRole
    """Role of the plugin (see :class:`PluginRole`)."""

    provides: list[SensorType]
    """Sensor types the plugin produces. Empty for hubs and pure
    camera-controllers; required for sensor providers."""

    consumes: list[SensorType]
    """Sensor types the plugin reads from other plugins (e.g. a face plugin
    consumes camera video frames)."""

    interfaces: list[PluginInterface]
    """Capability flags the plugin implements (see :class:`PluginInterface`)."""

    pythonVersion: NotRequired[PythonVersion]
    """Required Python interpreter version for Python plugins. Ignored by
    Node / Go plugins."""

    dependencies: NotRequired[list[str]]
    """Extra package dependencies installed into the plugin's runtime (PyPI
    for Python plugins, npm for Node plugins)."""


class PluginInfo(TypedDict):
    """Lightweight handle identifying an installed plugin — used in RPC
    payloads and managers to refer to the plugin without shipping its full
    state."""

    id: str
    """Unique runtime ID assigned by the host (stable across restarts)."""

    name: str
    """Plugin package name (matches PluginContract.name)."""

    contract: PluginContract
    """Full contract the plugin was loaded with."""
