from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Literal,
    NotRequired,
    Protocol,
    TypedDict,
    runtime_checkable,
)

from typing_extensions import TypeVar as ExtTypeVar

from ..camera import DetectionEvent, EventTriggerType
from ..sensor import ClassifierDetection, Detection, FaceDetection, LicensePlateDetection
from ..sensor.audio import BaseAudioLabel
from ..sensor.clip import ClipEmbedding
from ..sensor.motion import DetectionAttribute, DetectionLabel, VideoFrameData
from .api import PluginAPI

if TYPE_CHECKING:
    from ..camera import CameraConfig, CameraDevice
    from ..manager import DiscoveredCamera
    from ..storage import DeviceStorage, JsonSchemaWithoutCallbacks
    from ..types import LoggerService

from ..storage import JsonSchema

# Special filter value matching classifier-produced types not in the standard set.
EVENT_TYPE_OTHER: Literal["__other__"] = "__other__"

# TypeVar for generic storage typing in BasePlugin
# Using Mapping as bound since TypedDict is compatible with Mapping but not dict
StorageT = ExtTypeVar("StorageT", bound=Mapping[str, Any], default=dict[str, Any])
"""TypeVar for plugin storage values type. Defaults to dict[str, Any]."""


class ImageMetadata(TypedDict):
    """Image metadata for detection test requests."""

    width: int
    height: int


class AudioMetadata(TypedDict):
    """Audio metadata for detection test requests."""

    mimeType: Literal["audio/mpeg", "audio/wav", "audio/ogg"]


class MotionDetectionPluginResponse(TypedDict):
    """Response from a motion detection test."""

    detected: bool
    detections: list[Detection]
    videoData: NotRequired[bytes]


class ObjectDetectionPluginResponse(TypedDict):
    """Response from an object detection test."""

    detected: bool
    detections: list[Detection]


class AudioDetectionPluginResponse(TypedDict):
    """Response from an audio detection test."""

    detected: bool
    detections: list[Detection]
    decibels: NotRequired[float]


class FaceDetectionPluginResponse(TypedDict):
    """Response from a face detection test."""

    detected: bool
    detections: list[FaceDetection]
    embeddingModel: NotRequired[str]


class LicensePlateDetectionPluginResponse(TypedDict):
    """Response from a license plate detection test."""

    detected: bool
    detections: list[LicensePlateDetection]


class ClassifierDetectionPluginResponse(TypedDict):
    """Response from a classifier detection test."""

    detected: bool
    detections: list[ClassifierDetection]


class ClipDetectionPluginResponse(TypedDict):
    """Response from a CLIP embedding test."""

    embeddings: list[ClipEmbedding]
    embeddingModel: str


class ClipTextEmbeddingResult(TypedDict):
    """Result of text-to-embedding conversion."""

    embedding: list[float]
    embeddingModel: str


class BasePlugin(ABC, Generic[StorageT]):
    """Base class every plugin extends.

    It wires up the three dependencies the host injects (logger, PluginAPI,
    DeviceStorage) and declares the lifecycle methods the host calls on the
    plugin.

    Lifecycle order: the host calls :meth:`configureCameras` once at startup
    with every camera already assigned to this plugin, then calls
    :meth:`onCameraAdded` / :meth:`onCameraReleased` as the user adds or
    removes cameras at runtime.

    The generic type parameter ``StorageT`` types ``storage.values`` so plugin
    code gets autocompletion for its own settings shape.

    Example:
        ```python
        class MyStorageValues(TypedDict):
            model_path: str
            threshold: float


        class MyPlugin(BasePlugin[MyStorageValues]):
            async def configureCameras(self, cameras: list[CameraDevice]) -> None:
                # storage.values is typed as MyStorageValues
                model_path = self.storage.values.get("model_path")  # str
                for camera in cameras:
                    await self.onCameraAdded(camera)

            async def onCameraAdded(self, camera: CameraDevice) -> None:
                # Initialize camera controller
                pass

            async def onCameraReleased(self, camera_id: str) -> None:
                # Cleanup camera controller
                pass
        ```
    """

    def __init__(self, logger: LoggerService, api: PluginAPI, storage: DeviceStorage[StorageT]) -> None:
        self.logger = logger
        self.api = api
        self.storage: DeviceStorage[StorageT] = storage

    @property
    def storage_schema(self) -> list[JsonSchema]:
        """Override to register a JSON schema for the plugin-level settings
        form rendered in the UI. Default: no schema."""
        return []

    @abstractmethod
    async def configureCameras(self, cameraDevices: list[CameraDevice]) -> None:
        """Called once on startup with every camera already assigned to this
        plugin. The plugin should attach handlers, open vendor sessions, and
        warm up models. Raising aborts plugin startup.

        Args:
            cameraDevices: Cameras already assigned to this plugin.
        """
        ...

    @abstractmethod
    async def onCameraAdded(self, camera: CameraDevice) -> None:
        """Called whenever a camera is assigned to this plugin at runtime —
        after a discovery adoption (:meth:`DiscoveryProvider.onAdoptCamera`)
        or after the user re-assigns an existing camera in the UI. The
        plugin should set up the same per-camera state as in
        :meth:`configureCameras`.

        Args:
            camera: The camera device that was added.
        """
        ...

    @abstractmethod
    async def onCameraReleased(self, cameraId: str) -> None:
        """Called when a camera is unassigned from this plugin or deleted
        from the system. The plugin must release per-camera resources
        (sessions, timers, decoders) before returning.

        Args:
            cameraId: ID of the camera that was released.
        """
        ...


@runtime_checkable
class DiscoveryProvider(Protocol):
    """Implemented by plugins that can scan the network for new cameras and
    adopt them. Only plugins with a camera-controlling role
    (CameraController or CameraAndSensorProvider) are queried for discovery."""

    async def onDiscoverCameras(self) -> list[DiscoveredCamera]:
        """Scan the network and return the cameras the plugin can offer for
        adoption. Called by the host on demand (UI rescan button) or on a
        polling schedule.

        Returns:
            Cameras currently discoverable by this plugin.
        """
        ...

    async def onGetCameraSettings(self, camera: DiscoveredCamera) -> list[JsonSchemaWithoutCallbacks]:
        """Return a JSON schema describing the form fields (credentials,
        transport options, ...) the user must fill in to adopt this specific
        discovered camera.

        Args:
            camera: The discovered camera the user is about to adopt.

        Returns:
            Schema for the adoption form.
        """
        ...

    async def onAdoptCamera(
        self, camera: DiscoveredCamera, cameraSettings: dict[str, object]
    ) -> CameraConfig:
        """Probe the device with the user-provided settings and return the
        camera configuration the host should persist. The host then creates
        the camera and invokes :meth:`BasePlugin.onCameraAdded` on the
        plugin.

        Args:
            camera: The discovered camera being adopted.
            cameraSettings: Values entered into the adoption form.

        Returns:
            Final camera configuration for the host to persist.
        """
        ...


@runtime_checkable
class MotionDetectionInterface(Protocol):
    """Interface implemented by plugins that perform video-based motion
    detection. The host invokes :meth:`testMotionDetection` from the UI test
    panel and :meth:`detectMotion` from automation / benchmark pipelines."""

    async def testMotionDetection(
        self, video_data: bytes, config: dict[str, Any]
    ) -> MotionDetectionPluginResponse | None:
        """Run detection on a raw video buffer captured by the UI test panel
        and return the result for preview rendering."""
        ...

    async def detectMotion(
        self, frames: list[VideoFrameData], config: dict[str, Any] | None = None
    ) -> MotionDetectionPluginResponse | None:
        """Run detection on already-decoded :class:`VideoFrameData`. Called
        from automation / benchmark pipelines that supply pre-decoded frames
        directly to avoid re-encoding."""
        ...

    async def motionDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema used to render the motion-detection
        settings form in the UI. Return None for no schema."""
        ...


@runtime_checkable
class ObjectDetectionInterface(Protocol):
    """Interface implemented by plugins that perform object detection
    (person, vehicle, animal, ...)."""

    async def testObjectDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> ObjectDetectionPluginResponse | None:
        """Run detection on a single image captured by the UI test panel;
        ``metadata`` carries the image dimensions."""
        ...

    async def detectObjects(
        self, frame: VideoFrameData, config: dict[str, Any] | None = None
    ) -> ObjectDetectionPluginResponse | None:
        """Run detection on a pre-decoded video frame. Called from
        automation / benchmark pipelines."""
        ...

    async def objectDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema used to render the object-detection
        settings form in the UI. Return None for no schema."""
        ...


@runtime_checkable
class AudioDetectionInterface(Protocol):
    """Interface implemented by plugins that perform audio event or keyword
    detection."""

    async def testAudioDetection(
        self, audio_data: bytes, metadata: AudioMetadata, config: dict[str, Any]
    ) -> AudioDetectionPluginResponse | None:
        """Run detection on an audio buffer captured by the UI test panel;
        ``metadata`` carries the input MIME type (mpeg/wav/ogg)."""
        ...

    async def audioDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema used to render the audio-detection
        settings form in the UI. Return None for no schema."""
        ...


@runtime_checkable
class FaceDetectionInterface(Protocol):
    """Interface implemented by plugins that locate faces and emit per-face
    embeddings. The NVR owns matching against enrolled faces; the plugin
    only emits raw detections + embeddings."""

    async def testFaceDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> FaceDetectionPluginResponse | None:
        """Run face detection on a single image captured by the UI test
        panel and return the result for preview rendering."""
        ...

    async def detectFaces(
        self, frame: VideoFrameData, config: dict[str, Any] | None = None
    ) -> FaceDetectionPluginResponse | None:
        """Run face detection on a pre-decoded video frame."""
        ...

    async def faceDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema for the face-detection settings form in
        the UI. Return None for no schema."""
        ...


@runtime_checkable
class LicensePlateDetectionInterface(Protocol):
    """Interface implemented by plugins that locate license plates and run
    OCR on them."""

    async def testLicensePlateDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> LicensePlateDetectionPluginResponse | None:
        """Run detection on a single image captured by the UI test panel and
        return the result for preview rendering."""
        ...

    async def detectLicensePlates(
        self, frame: VideoFrameData, config: dict[str, Any] | None = None
    ) -> LicensePlateDetectionPluginResponse | None:
        """Run detection on a pre-decoded video frame."""
        ...

    async def licensePlateDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema for the license-plate-detection settings
        form in the UI. Return None for no schema."""
        ...


@runtime_checkable
class ClassifierDetectionInterface(Protocol):
    """Interface implemented by plugins that run a generic image classifier
    and emit attribute/label pairs (e.g. weather, scene, activity)."""

    async def testClassifierDetection(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> ClassifierDetectionPluginResponse | None:
        """Run classification on a single image captured by the UI test
        panel and return the result for preview rendering."""
        ...

    async def detectClassifications(
        self, frame: VideoFrameData, config: dict[str, Any] | None = None
    ) -> ClassifierDetectionPluginResponse | None:
        """Run classification on a pre-decoded video frame."""
        ...

    async def classifierDetectionSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema for the classifier-detection settings
        form in the UI. Return None for no schema."""
        ...


@runtime_checkable
class ClipDetectionInterface(Protocol):
    """Interface implemented by plugins that generate CLIP image and text
    embeddings used for semantic search over recorded events."""

    async def testClipEmbedding(
        self, image_data: bytes, metadata: ImageMetadata, config: dict[str, Any]
    ) -> ClipDetectionPluginResponse | None:
        """Run the CLIP image branch on a single image captured by the UI
        test panel."""
        ...

    async def detectClipEmbedding(
        self, frame: VideoFrameData, config: dict[str, Any] | None = None
    ) -> ClipDetectionPluginResponse | None:
        """Run the CLIP image branch on a pre-decoded video frame."""
        ...

    async def getTextEmbedding(self, text: str) -> ClipTextEmbeddingResult:
        """Run the CLIP text branch and return a single embedding vector
        usable for semantic-search queries against previously stored image
        embeddings."""
        ...

    async def clipSettings(self) -> list[JsonSchema] | None:
        """Return the JSON schema for the CLIP settings form in the UI.
        Return None for no schema."""
        ...


class CameraStorageStats(TypedDict):
    """Storage usage for a single camera."""

    usedBytes: int
    segmentCount: int
    oldestDay: str
    newestDay: str
    daysCount: int
    bandwidthMBh: float
    recordingMode: str
    isRecording: bool


class StorageStats(TypedDict):
    """Overall storage and per-camera usage statistics."""

    diskTotalGB: float
    diskUsedGB: float
    diskFreeGB: float
    diskFreePercent: float
    nvrUsedGB: float
    nvrQuotaGB: float
    retentionDays: int
    cameras: dict[str, CameraStorageStats]


class RecordingSegment(TypedDict):
    """A continuous recording time range."""

    startTime: int  # Unix ms
    endTime: int  # Unix ms


class RecordingState(TypedDict):
    """Current recording status of a camera."""

    cameraId: str
    state: Literal["recording", "stopped"]
    timestamp: int  # Unix ms


class GetEventsOptions(TypedDict, total=False):
    """Server-side filter options for getEvents()."""

    types: list[DetectionLabel | DetectionAttribute | EventTriggerType | Literal["__other__"] | str]
    """Filter events by detection type. Use "__other__" to match classifier-produced types outside the standard set."""

    triggers: list[EventTriggerType | str]
    """Filter events that have at least one trigger with matching type (e.g. ["motion", "contact"])."""

    triggerLabels: list[BaseAudioLabel | str]
    """Filter events that have at least one trigger with matching label (e.g. ["doorbell", "glass_break"])."""

    attributes: list[DetectionAttribute | str]
    """Filter events that have at least one segment attribute with matching type (e.g. ["face", "license_plate"])."""

    filterLogicTriggers: Literal["and", "or"]
    """How to combine triggers/triggerLabels with types. Default: 'or'."""

    filterLogicAttributes: Literal["and", "or"]
    """How to combine types with attributes. Default: 'or'."""

    state: Literal["active", "ended"]
    """Filter by event lifecycle state."""

    search: str
    """Case-insensitive substring match across all detection labels."""

    hasDetections: bool
    """Only return events with detection types beyond just motion/audio."""

    minConfidence: float
    """Only return events where the best detection score >= this value (0–1)."""

    startMs: int
    """Only return events with startTime >= startMs."""

    endMs: int
    """Only return events with startTime <= endMs."""

    limit: int
    """Maximum number of events to return. Events are sorted newest first."""

    before: int
    """Pagination cursor: only return events with startTime < before (Unix ms)."""


class GetEventsResult(TypedDict):
    """Paginated result from get_events / get_camera_events."""

    events: list[DetectionEvent]
    """Events matching the query, sorted newest first."""

    hasMore: bool
    """True if more events exist beyond this page."""


class EventThumbnails(TypedDict, total=False):
    """All thumbnails for a single event, grouped by category."""

    event: bytes
    """Event-level full-frame downscaled JPEG captured at event start. Always available
    (even for events without object detection); UI uses it as the fallback when no
    scene/detection/attribute thumbnail exists yet."""

    scenes: dict[str, bytes]
    """Scene thumbnails per segment index. Key: segment index as string ("0", "1", ...)."""

    detections: dict[str, bytes]
    """Detection thumbnails per segment+label. Key: "{segIdx}:{label}"."""

    attributes: dict[str, bytes]
    """Attribute thumbnails keyed by "{type}:{label}" (e.g. "face:John", "license_plate:ABC123")."""


class NvrExportOptions(TypedDict, total=False):
    """Options for NVR export (trim/timelapse)."""

    timelapseIntervalSec: int
    """Timelapse interval in seconds. 0 or omitted means no timelapse."""

    format: Literal["mp4"]
    """Output format (currently only mp4)."""


class HeatmapPoint(TypedDict):
    """A single detection center point for heatmap rendering. Coordinates are normalized 0-1."""

    x: float
    """Center X (0-1)."""

    y: float
    """Center Y (0-1)."""


class DetectionHeatmapResult(TypedDict):
    """Aggregated detection center points for heatmap rendering."""

    points: list[HeatmapPoint]
    """Detection center points (normalized 0-1)."""

    count: int
    """Total number of events scanned."""


class NvrExportResult(TypedDict):
    """Result of an NVR export operation."""

    url: str
    """Download URL for the exported file."""

    filename: str
    """Filename of the exported file."""

    size: int
    """File size in bytes."""

    durationMs: int
    """Duration of the exported clip in milliseconds."""


class NvrScrubFrame(TypedDict):
    """A single encoded frame within a fine-scrub response."""

    frame: bytes
    ts: int
    keyframe: bool


class NvrScrubResult(TypedDict):
    """Result of a scrub request — a single keyframe at a timestamp."""

    frame: NotRequired[bytes]
    """AVCC keyframe data (length-prefixed NALUs)."""
    description: NotRequired[bytes]
    """avcC/hvcC decoder configuration record."""
    ts: int
    """Actual keyframe timestamp (μs)."""
    videoCodec: str
    """Video codec name (e.g. 'H264', 'H265')."""
    noData: NotRequired[bool]
    """No recording at this timestamp."""
    codecString: NotRequired[str]
    """WebCodecs codec string (e.g. 'avc1.4d401e', 'hvc1.1.6.L120')."""
    frames: NotRequired[list[NvrScrubFrame]]
    """Fine scrub: keyframe + delta frames up to target timestamp."""


class NvrPreviewResult(TypedDict):
    """Result of a preview frames request — sampled keyframes for hover preview."""

    frames: list[NvrScrubFrame]
    videoCodec: str
    codecString: NotRequired[str]
    width: NotRequired[int]
    height: NotRequired[int]
    noData: NotRequired[bool]


class NvrPlaybackReady(TypedDict):
    """Emitted once per pull-callback session before the first onVideo."""

    sessionId: str
    videoCodec: str
    codecString: str
    width: int
    height: int
    audioCodec: NotRequired[str]
    audioCodecString: NotRequired[str]
    audioSampleRate: NotRequired[int]
    audioChannels: NotRequired[int]
    audioDescription: NotRequired[bytes]


class NvrPlaybackVideo(TypedDict):
    """One video frame (Annex-B) per invocation."""

    frame: bytes
    ts: int
    keyframe: NotRequired[bool]


class NvrPlaybackAudio(TypedDict):
    """One encoded audio frame per invocation."""

    frame: bytes
    ts: int


class NvrPlaybackNoData(TypedDict):
    """Gap signal: no recording at ts. Iterator finishes with `done` right after."""

    ts: int


@runtime_checkable
class NvrPlaybackCallbacks(Protocol):
    """Callback surface passed to nvrPlayback via rpcCallbacks.
    All methods are oneway; the RPC layer serializes dispatch per session."""

    def onReady(self, payload: NvrPlaybackReady) -> None: ...
    def onVideo(self, payload: NvrPlaybackVideo) -> None: ...
    def onAudio(self, payload: NvrPlaybackAudio) -> None: ...
    def onNoData(self, payload: NvrPlaybackNoData) -> None: ...


NvrPlaybackCommandType = Literal["pause", "resume", "speed"]
"""Playback control command. Seek is not a server command — the client
cancels the pull iterator and issues a fresh playback call instead."""


class NvrPlaybackCommand(TypedDict):
    """Command to control an active playback session."""

    cmd: NvrPlaybackCommandType
    speed: NotRequired[float]


@runtime_checkable
class NVRInterface(Protocol):
    """Interface implemented by the NVR plugin — the singleton that persists
    detection events and recordings and serves them back to the UI / mobile
    clients. Exactly one plugin per host fills this role at runtime."""

    async def getEvents(
        self, opts: GetEventsOptions | None = None
    ) -> GetEventsResult:
        """Query events across every managed camera, sorted newest first.
        The returned events have no thumbnails or embeddings inlined — call
        :meth:`getEventThumbnails` for lazy thumbnail loading."""
        ...

    async def getCameraEvents(
        self, cameraIDs: list[str], opts: GetEventsOptions | None = None
    ) -> GetEventsResult:
        """Query events for the given cameras, sorted newest first. The
        returned events have no thumbnails or embeddings inlined — call
        :meth:`getEventThumbnails` for lazy thumbnail loading."""
        ...

    async def getEventThumbnails(self, cameraID: str, startMs: int, eventID: str) -> EventThumbnails:
        """Return every thumbnail stored for one event, grouped by category
        (event-level fallback, scene per segment, detection per segment+label,
        attribute per type+label).

        Args:
            cameraID: Camera ID the event belongs to.
            startMs: The event's startTime in milliseconds (used to locate
                the underlying day-DB).
            eventID: The event's UUID (DetectionEvent.id).
        """
        ...

    async def getRecordingSegments(
        self, cameraID: str, startMs: int, endMs: int
    ) -> list[RecordingSegment]:
        """Return continuous recording time ranges for a camera within
        ``[startMs, endMs]``. Used to render the timeline scrubber."""
        ...

    async def getRecordingDays(self, cameraID: str, year: int, month: int) -> list[str]:
        """Return the days (``YYYY-MM-DD``) within the given year/month
        (1-indexed) that contain recordings for the camera."""
        ...

    def onRecordingState(self, cameraID: str, callback: Any) -> Any:
        """Subscribe to real-time recording-state changes for a camera.
        Returns an unsubscribe handle."""
        ...

    async def getManagedCameraIds(self) -> list[str]:
        """Return the IDs of every camera currently being recorded by this
        NVR plugin."""
        ...

    async def getStorageStats(self) -> StorageStats:
        """Return overall and per-camera storage usage statistics for the
        NVR plugin."""
        ...

    async def nvrPreviewFrames(
        self, cameraID: str, startUs: int, endUs: int, count: int = 12
    ) -> NvrPreviewResult:
        """Return ``count`` sampled keyframes within ``[startUs, endUs]``
        (microseconds) for the timeline hover-preview animation."""
        ...

    async def nvrExport(
        self, cameraID: str, startUs: int, endUs: int, options: NvrExportOptions | None = None
    ) -> NvrExportResult:
        """Export the recording slice ``[startUs, endUs]`` (microseconds)
        for the camera — optionally as a timelapse — and return a download
        URL plus file metadata."""
        ...

    async def getDetectionHeatmap(self, cameraID: str, startMs: int, endMs: int) -> DetectionHeatmapResult:
        """Return aggregated detection bounding-box centre points within
        ``[startMs, endMs]`` for heatmap rendering. Coordinates are
        normalised 0–1 relative to the video frame."""
        ...

    # Face recognition
    async def matchFaces(
        self, embeddings: list[list[float]], embeddingModel: str
    ) -> list[FaceMatchResult | None]:
        """Match a batch of face embeddings against the enrolled face
        gallery. Returns one entry per input embedding (None for no match).
        ``embeddingModel`` must equal the model used to produce the
        embeddings — the NVR refuses to mix models."""
        ...

    async def enrollFace(self, name: str, imageData: bytes, facePluginName: str) -> None:
        """Enrol a new known face from a raw image. The NVR routes the
        image to the named face plugin to produce the embedding."""
        ...

    async def enrollFromEvent(self, name: str, unknownFaceId: str) -> None:
        """Promote a previously-recorded unknown face to the known-face
        gallery under ``name``."""
        ...

    async def listKnownFaces(self) -> list[FaceProfile]:
        """Return every enrolled face profile (name, image count,
        timestamps, optional thumbnail)."""
        ...

    async def deleteFace(self, name: str) -> None:
        """Delete the known-face profile and all of its embeddings."""
        ...

    async def getFaceImages(self, name: str) -> list[FaceImageData]:
        """Return every JPEG image associated with the known face
        ``name``."""
        ...

    async def removeFaceImage(self, name: str, index: int) -> None:
        """Remove a single image from the known-face profile by 0-based
        index."""
        ...

    async def getUnknownFaces(self, limit: int = 50) -> list[UnknownFace]:
        """Return up to ``limit`` recent unknown-face detections that have
        not yet been enrolled or dismissed."""
        ...

    async def deleteUnknownFace(self, unknownFaceId: str) -> None:
        """Permanently delete one unknown-face record."""
        ...

    async def deleteAllUnknownFaces(self) -> None:
        """Permanently delete every unknown-face record."""
        ...

    async def deleteUnknownFacesByCluster(self, clusterId: str) -> None:
        """Permanently delete every unknown-face record assigned to the
        given cluster."""
        ...

    async def deleteUngroupedUnknownFaces(self) -> None:
        """Permanently delete every unknown-face record that has no cluster
        assignment."""
        ...

    async def removeFromCluster(self, unknownFaceId: str) -> None:
        """Detach an unknown-face record from its cluster without deleting
        the record itself."""
        ...

    async def enrollCluster(self, name: str, faceIds: list[str]) -> None:
        """Enrol every unknown face in the list as a single new known
        identity under ``name``."""
        ...

    async def rescanFaces(self) -> int:
        """Re-cluster the unknown-face pool (e.g. after enrolment changes)
        and return the resulting cluster count."""
        ...

    # CLIP semantic search
    async def searchEventsByText(
        self, text: str, limit: int = 50, threshold: float = 0.2
    ) -> list[ClipSearchResult]:
        """Run a CLIP semantic-search query: convert ``text`` to an
        embedding via the active CLIP plugin and return matching events
        whose stored image embedding is at most ``threshold`` away (cosine
        distance), capped at ``limit`` hits."""
        ...


class ClipSearchResult(TypedDict):
    """Single CLIP-based semantic-search hit returned by
    :meth:`NVRInterface.searchEventsByText`."""

    eventId: str
    cameraId: str
    score: float
    timestamp: int
    label: str


class FaceMatchResult(TypedDict):
    """Single face-recognition match returned by
    :meth:`NVRInterface.matchFaces`."""

    identity: str
    score: float


class FaceImageData(TypedDict):
    """Single JPEG image associated with a known-face profile, optionally
    with the detection confidence at enrolment time."""

    jpeg: bytes
    confidence: NotRequired[float]


class FaceProfile(TypedDict):
    """Known/enrolled face identity returned by
    :meth:`NVRInterface.listKnownFaces`."""

    name: str
    imageCount: int
    createdAt: int
    updatedAt: int
    thumbnail: NotRequired[bytes]


class UnknownFace(TypedDict):
    """Un-enrolled face encountered during detection. Persisted by the NVR
    until the user enrols, dismisses or auto-prunes it."""

    id: str
    cameraId: str
    timestamp: int
    embeddingModel: str
    confidence: NotRequired[float]
    clusterId: NotRequired[str]
    embedding: NotRequired[list[float]]
    thumbnail: NotRequired[bytes]


# Union of all optional plugin interfaces.
PluginInterfaces = (
    MotionDetectionInterface
    | ObjectDetectionInterface
    | AudioDetectionInterface
    | FaceDetectionInterface
    | LicensePlateDetectionInterface
    | ClassifierDetectionInterface
    | ClipDetectionInterface
    | DiscoveryProvider
    | NVRInterface
)
