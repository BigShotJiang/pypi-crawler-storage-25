from __future__ import annotations

from typing import Any, cast

from ..sensor import (
    SensorType,
)
from .contract import PluginContract, PluginInterface, PluginRole


def get_contract_validation_errors(contract: object) -> list[str]:
    """Check the structural validity of an unknown contract object —
    required fields present, enum values inside the accepted sets — and
    return one human-readable error per problem found. Returns an empty list
    when the contract is valid. Mirrors the Node and Go implementations in
    this module.

    Args:
        contract: Untrusted candidate contract (e.g. parsed manifest JSON).

    Returns:
        Error messages, empty if the contract is valid.

    Example:
        ```python
        errors = get_contract_validation_errors(my_contract)
        if errors:
            print(f"Invalid contract: {errors}")
        ```
    """
    errors: list[str] = []

    if not contract or not isinstance(contract, dict):
        errors.append(
            f"Contract must be an object. Got: {'null' if contract is None else type(contract).__name__}"
        )
        return errors

    c = cast(Any, contract)
    valid_roles = [r.value for r in PluginRole]
    valid_sensor_types = [s.value for s in SensorType]

    # Check role
    if "role" not in c:
        errors.append('Missing required field: "role"')
    elif not isinstance(c.get("role"), str):
        role_value = c.get("role")
        errors.append(f'Field "role" must be a string. Got: {type(role_value).__name__}')
    elif c["role"] not in valid_roles:
        errors.append(f'Invalid role "{c["role"]}". Valid roles: {", ".join(valid_roles)}')

    # Check name
    if "name" not in c:
        errors.append('Missing required field: "name"')
    elif not isinstance(c["name"], str):
        errors.append(f'Field "name" must be a string. Got: {type(c["name"]).__name__}')
    elif len(c["name"]) == 0:
        errors.append('Field "name" cannot be empty')

    # Check provides
    if "provides" not in c:
        errors.append('Missing required field: "provides"')
    elif not isinstance(c["provides"], list):
        errors.append(f'Field "provides" must be an array. Got: {type(c["provides"]).__name__}')
    else:
        for sensor_type in c["provides"]:
            if sensor_type not in valid_sensor_types:
                errors.append(
                    f'Invalid sensor type in "provides": "{sensor_type}". Valid types: {", ".join(valid_sensor_types)}'
                )

    # Check consumes
    if "consumes" not in c:
        errors.append('Missing required field: "consumes"')
    elif not isinstance(c["consumes"], list):
        errors.append(f'Field "consumes" must be an array. Got: {type(c["consumes"]).__name__}')
    else:
        for sensor_type in c["consumes"]:
            if sensor_type not in valid_sensor_types:
                errors.append(
                    f'Invalid sensor type in "consumes": "{sensor_type}". Valid types: {", ".join(valid_sensor_types)}'
                )

    # Check interfaces
    valid_interfaces = [i.value for i in PluginInterface]
    if "interfaces" not in c:
        errors.append('Missing required field: "interfaces"')
    elif not isinstance(c["interfaces"], list):
        errors.append(f'Field "interfaces" must be an array. Got: {type(c["interfaces"]).__name__}')
    else:
        for iface in c["interfaces"]:
            if iface not in valid_interfaces:
                errors.append(
                    f'Invalid interface in "interfaces": "{iface}". Valid interfaces: {", ".join(valid_interfaces)}'
                )

    # Check optional pythonVersion
    if "pythonVersion" in c and c["pythonVersion"] not in ["3.11", "3.12"]:
        errors.append(f'Invalid pythonVersion "{c["pythonVersion"]}". Valid versions: 3.11, 3.12')

    # Check optional dependencies
    if "dependencies" in c and not isinstance(c["dependencies"], list):
        errors.append(f'Field "dependencies" must be an array. Got: {type(c["dependencies"]).__name__}')

    return errors


def validate_contract(contract: object) -> bool:
    """Boolean wrapper around :func:`get_contract_validation_errors`:
    returns True exactly when the contract is structurally valid.

    Args:
        contract: Untrusted candidate contract.

    Returns:
        True if structurally valid.
    """
    return len(get_contract_validation_errors(contract)) == 0


def is_provider(contract: PluginContract) -> bool:
    """Report whether the plugin produces at least one sensor type.

    Args:
        contract: Plugin contract.

    Returns:
        True if the plugin produces at least one sensor type.
    """
    return len(contract["provides"]) > 0


def is_consumer(contract: PluginContract) -> bool:
    """Report whether the plugin reads at least one sensor type from other
    plugins.

    Args:
        contract: Plugin contract.

    Returns:
        True if the plugin consumes at least one sensor type.
    """
    return len(contract["consumes"]) > 0


def provides_sensor(contract: PluginContract, sensor_type: SensorType) -> bool:
    """Report whether the plugin produces the given sensor type.

    Args:
        contract: Plugin contract.
        sensor_type: Sensor type to test.

    Returns:
        True if the plugin produces ``sensor_type``.
    """
    return sensor_type in contract["provides"]


def consumes_sensor(contract: PluginContract, sensor_type: SensorType) -> bool:
    """Report whether the plugin reads the given sensor type from other
    plugins.

    Args:
        contract: Plugin contract.
        sensor_type: Sensor type to test.

    Returns:
        True if the plugin consumes ``sensor_type``.
    """
    return sensor_type in contract["consumes"]


def is_camera_controller(contract: PluginContract) -> bool:
    """Report whether the plugin owns cameras (role is CameraController or
    CameraAndSensorProvider). Used to gate camera-creating operations such
    as DiscoveryProvider adoption.

    Args:
        contract: Plugin contract.

    Returns:
        True if the plugin can create / manage cameras.
    """
    return contract["role"] in (PluginRole.CameraController, PluginRole.CameraAndSensorProvider)


def is_qualified_contract(contract: PluginContract) -> bool:
    """Report whether the contract's role is one of the known
    :class:`PluginRole` values. Cheaper than full validation when only the
    role needs checking.

    Args:
        contract: Plugin contract.

    Returns:
        True if the role is a recognised :class:`PluginRole`.
    """
    return contract["role"] in PluginRole
