"""Generic notification types — domain-agnostic.

Mirrors sdk/go/notifier.go and sdk/node/src/plugin/notifier.ts. All three
SDKs MUST stay in sync on field names; the NotificationManager and notifier
plugins talk over RPC and JSON-encode these types directly.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, NotRequired, Protocol, TypedDict, runtime_checkable


class Severity(str, Enum):
    """Classifies how urgent a Notification is.

    Notifiers map this to platform-specific delivery characteristics — e.g.
    Mobile maps ``Critical`` to APNs Critical Alerts (DND-bypass) and Android
    Importance-MAX channels.
    """

    Info = "info"
    """Standard notification — default delivery (sound + banner)."""

    Warn = "warn"
    """Heightened attention; notifiers may use a different sound/colour."""

    Error = "error"
    """Failure or action-required notification."""

    Critical = "critical"
    """DND/Silent-bypass on supporting notifiers (iOS Critical Alerts, etc.)."""


class NotifierDevice(TypedDict):
    """A push-target managed by a notifier plugin (one phone, one chat, ...).

    Devices are owned by the plugin that registered them; the manager queries
    plugins for their device list rather than maintaining a shared registry.
    """

    id: str
    ownerUserId: str
    # Plugin-defined string used as a UI hint and grouping key.
    # Conventional values: 'mobile' | 'telegram' | 'email' — but plugins are
    # free to coin their own.
    type: str
    name: str
    active: bool
    metadata: NotRequired[dict[str, Any]]


class NotificationTypeInfo(TypedDict):
    """Optional UI metadata exposed by a notifier so the settings UI can
    render human-readable labels for the `type` strings it understands."""

    type: str
    label: str
    description: NotRequired[str]


class Notification(TypedDict):
    """Generic, domain-agnostic notification routed through the
    NotificationManager. Sources populate it; notifiers translate it to
    platform-specific shapes.

    `type` is intentionally a free-form string — there is no enum — so plugins
    can introduce new categories without an SDK release. Convention: dotted
    namespaces, e.g. 'detection', 'system.disk_full', 'plugin.<name>.<event>'.
    """

    id: str
    type: str
    title: str
    body: NotRequired[str]
    severity: NotRequired[Severity]
    # Collapse-key for dedup and rate-limiting at both manager and notifier
    # level (e.g. 'motion:cam-1' — multiple events with the same tag inside
    # the throttle window collapse into one notification).
    tag: NotRequired[str]
    # Raw image bytes. Notifiers that don't support images ignore this field.
    thumbnail: NotRequired[bytes]
    # Router-relative path consumed by mobile / web tap-handlers.
    # Convention: path + query string, no host (e.g. '/cameras/cam-1?startTs=...').
    deepLink: NotRequired[str]
    # Domain-specific context (cameraId, eventId, plugin-defined keys).
    # Routing rules can match against these. String values keep the wire
    # format predictable across mobile / FCM / APNs / SMTP / etc.
    data: NotRequired[dict[str, str]]
    createdAt: datetime


@runtime_checkable
class NotifierInterface(Protocol):
    """Implemented by plugins that deliver notifications.

    The NotificationManager invokes these methods over RPC. Plugins own their
    device storage — the manager never persists devices itself.
    """

    async def get_devices(self, owner_user_id: str) -> list[NotifierDevice]:
        """Return every device this notifier currently knows about for the
        given user. May return [] when the notifier is unavailable (e.g.
        license invalid). Called frequently — keep cheap."""
        ...

    async def get_device(self, device_id: str) -> NotifierDevice | None:
        """Return a single device by id, or None if not found."""
        ...

    async def send_notification(self, device_id: str, n: Notification) -> None:
        """Deliver a notification to a specific device. Errors are logged;
        the manager dispatches in parallel and never aborts a fan-out
        because one notifier failed."""
        ...

    async def register_device(self, owner_user_id: str, input: dict[str, Any]) -> NotifierDevice:
        """Create a new device on this notifier. ``input`` is plugin-specific
        JSON (NVR expects fcmToken/platform/deviceName; Telegram expects
        chatId/label) — the NotificationManager just forwards it."""
        ...

    async def revoke_device(self, device_id: str) -> None:
        """Permanently remove a device. Called on mobile logout, or when the
        user removes a chat in a plugin's config UI."""
        ...

    async def update_device(self, device_id: str, patch: dict[str, Any]) -> NotifierDevice | None:
        """Mutate a subset of fields on an existing device. ``patch`` is
        plugin-agnostic (``name``, ``active``); plugins ignore unknown keys.
        Returns the updated device, or None if the id isn't ours so the
        manager can probe the next plugin."""
        ...

    def get_supported_types(self) -> list[NotificationTypeInfo]:
        """Optional UI metadata. Returning [] just means the settings UI
        falls back to raw type strings."""
        ...
