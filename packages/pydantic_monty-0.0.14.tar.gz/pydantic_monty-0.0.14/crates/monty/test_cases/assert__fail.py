assert False
# Raise=AssertionError()
