"""Yoghurt test suite."""
