"""Rule detectors."""

