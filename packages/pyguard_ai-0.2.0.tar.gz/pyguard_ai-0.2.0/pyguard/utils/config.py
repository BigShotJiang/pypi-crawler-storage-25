from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class ScanConfig:
    target: str
    source_root: Path
    enable_ai: bool = False
    enable_sandbox: bool = False
    sandbox_network: str = "none"   # "none" | "bridge"
    transitive: bool = False         # scan transitive dependencies
    rules_path: Path | None = None  # path to custom rules YAML

