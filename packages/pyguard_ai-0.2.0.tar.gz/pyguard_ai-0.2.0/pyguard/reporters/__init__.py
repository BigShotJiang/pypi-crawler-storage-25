"""Reporter registry and factory.

Design patterns:
  - Factory Method : ReporterFactory.create(name) instantiates the right reporter.
  - Composite      : CompositeReporter fans out to multiple reporters in one call.
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from pyguard.models import ScanResult


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BaseReporter(ABC):
    """All reporters implement this interface."""

    @abstractmethod
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        """Render results and return the report string.
        If *output* is given, also write to that file.
        """


# ---------------------------------------------------------------------------
# Composite pattern — CompositeReporter
# ---------------------------------------------------------------------------

class CompositeReporter(BaseReporter):
    """Fans out to multiple reporters (Composite pattern).

    Usage::

        reporter = CompositeReporter([TerminalReporter(), SarifReporter()])
        reporter.report(results)
    """

    def __init__(self, reporters: list[BaseReporter]) -> None:
        self._reporters = reporters

    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        outputs: list[str] = []
        for r in self._reporters:
            outputs.append(r.report(results, output))
        return "\n".join(outputs)


# ---------------------------------------------------------------------------
# Concrete reporters (thin wrappers delegating to existing render functions)
# ---------------------------------------------------------------------------

class TerminalReporter(BaseReporter):
    def __init__(self, no_color: bool = False) -> None:
        self._no_color = no_color

    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from rich.console import Console  # noqa: PLC0415
        from pyguard.reporters.terminal import render_terminal  # noqa: PLC0415

        con = Console(no_color=self._no_color)
        for result in results:
            render_terminal(result, con)
        return ""  # terminal reporter writes directly to console


class JSONReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.json_reporter import render_json  # noqa: PLC0415

        text = json.dumps([render_json(r) for r in results], indent=2)
        if output:
            output.write_text(text, encoding="utf-8")
        return text


class SarifReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.sarif_reporter import render_sarif  # noqa: PLC0415

        text = json.dumps(render_sarif(results), indent=2)
        if output:
            output.write_text(text, encoding="utf-8")
        return text


class HtmlReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.html_reporter import render_html  # noqa: PLC0415

        html = render_html(results)
        if output:
            output.write_text(html, encoding="utf-8")
        return html


class GitHubActionsReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.github_actions import render_github_actions  # noqa: PLC0415

        text = render_github_actions(results)
        if output:
            output.write_text(text, encoding="utf-8")
        return text


class PipAuditReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.pip_audit_reporter import render_pip_audit  # noqa: PLC0415

        text = json.dumps(render_pip_audit(results), indent=2)
        if output:
            output.write_text(text, encoding="utf-8")
        return text


class SbomReporter(BaseReporter):
    def report(self, results: list[ScanResult], output: Path | None = None) -> str:
        from pyguard.reporters.sbom_reporter import render_sbom  # noqa: PLC0415

        text = json.dumps(render_sbom(results), indent=2)
        if output:
            output.write_text(text, encoding="utf-8")
        return text


# ---------------------------------------------------------------------------
# Factory Method — ReporterFactory
# ---------------------------------------------------------------------------

class ReporterFactory:
    """Creates reporter instances by name (Factory Method pattern).

    Reporters register themselves via ``register()``.  The factory is a class
    (not an instance) so it acts as a global registry without needing a
    Singleton — the class dict *is* the shared state.
    """

    _registry: dict[str, type[BaseReporter]] = {}

    @classmethod
    def register(cls, name: str, reporter_cls: type[BaseReporter]) -> None:
        cls._registry[name.lower()] = reporter_cls

    @classmethod
    def create(cls, name: str, **kwargs: Any) -> BaseReporter:
        key = name.lower()
        if key not in cls._registry:
            raise ValueError(
                f"Unknown reporter '{name}'. Available: {', '.join(cls._registry)}"
            )
        return cls._registry[key](**kwargs)

    @classmethod
    def create_composite(cls, names: list[str], **kwargs: Any) -> BaseReporter:
        """Create a CompositeReporter from a list of reporter names."""
        reporters = [cls.create(n, **kwargs) for n in names]
        if len(reporters) == 1:
            return reporters[0]
        return CompositeReporter(reporters)


# Register built-in reporters
ReporterFactory.register("terminal", TerminalReporter)
ReporterFactory.register("json", JSONReporter)
ReporterFactory.register("sarif", SarifReporter)
ReporterFactory.register("html", HtmlReporter)
ReporterFactory.register("github", GitHubActionsReporter)
ReporterFactory.register("github-actions", GitHubActionsReporter)
ReporterFactory.register("pip-audit", PipAuditReporter)
ReporterFactory.register("sbom", SbomReporter)
