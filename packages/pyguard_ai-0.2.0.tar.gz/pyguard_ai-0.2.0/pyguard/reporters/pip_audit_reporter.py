"""pip-audit compatible JSON reporter.

Outputs the same JSON schema as ``pip-audit --format json`` so pyguard can
act as a drop-in source of vulnerability data for tooling that already
consumes pip-audit output.

pip-audit schema reference:
  https://github.com/pypa/pip-audit#json-output-format
"""
from __future__ import annotations

from typing import Any

from pyguard.models import ScanResult, Severity

_SEVERITY_ALIASES: dict[Severity, str] = {
    Severity.CRITICAL: "CRITICAL",
    Severity.HIGH: "HIGH",
    Severity.MEDIUM: "MODERATE",
    Severity.LOW: "LOW",
    Severity.INFO: "UNKNOWN",
}


def render_pip_audit(results: list[ScanResult]) -> list[dict[str, Any]]:
    """Return a list of pip-audit compatible package vulnerability entries."""
    entries: list[dict[str, Any]] = []
    for result in results:
        vulns: list[dict[str, Any]] = []
        for finding in result.findings:
            if finding.severity == Severity.INFO:
                continue
            vuln: dict[str, Any] = {
                "id": finding.cve_id or f"PYGUARD-{finding.category.upper()}-{abs(hash(finding.title)) % 100000:05d}",
                "fix_versions": [],
                "aliases": [],
                "description": finding.description,
                "published": None,
                "withdrawn": None,
                "affected_versions": [result.package.version],
                "details": {
                    "severity": _SEVERITY_ALIASES[finding.severity],
                    "layer": finding.layer,
                    "confidence": finding.confidence,
                    "title": finding.title,
                    "file": finding.file,
                    "line": finding.line,
                    "category": finding.category,
                },
            }
            if finding.cve_id:
                vuln["aliases"].append(finding.cve_id)
            vulns.append(vuln)

        entries.append(
            {
                "name": result.package.name,
                "version": result.package.version,
                "vulns": vulns,
                "skip_reason": None,
            }
        )
    return entries
