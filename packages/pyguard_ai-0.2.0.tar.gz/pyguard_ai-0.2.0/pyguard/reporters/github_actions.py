"""GitHub Actions workflow command reporter.

Outputs ``::error`` / ``::warning`` / ``::notice`` annotations consumed by
the GitHub Actions runner to surface findings inline on pull requests.

Reference: https://docs.github.com/en/actions/using-workflows/workflow-commands-for-github-actions
"""
from __future__ import annotations

from pyguard.models import ScanResult, Severity

_LEVEL_MAP: dict[Severity, str] = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "notice",
    Severity.INFO: "notice",
}


def render_github_actions(results: list[ScanResult]) -> str:
    """Return a string of GitHub Actions workflow commands, one per finding."""
    lines: list[str] = []
    for result in results:
        for finding in result.findings:
            level = _LEVEL_MAP[finding.severity]
            file_part = f"file={finding.file}," if finding.file else ""
            line_part = f"line={finding.line}," if finding.line else ""
            title_part = f"title=pyguard: {finding.title}"
            message = finding.description.replace("\n", " ").replace("%", "%25")
            lines.append(
                f"::{level} {file_part}{line_part}{title_part}::{message}"
            )
    return "\n".join(lines)
