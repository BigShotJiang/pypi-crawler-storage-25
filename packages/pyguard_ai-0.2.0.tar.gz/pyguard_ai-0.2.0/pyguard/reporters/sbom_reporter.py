"""CycloneDX 1.4 SBOM reporter.

Produces a CycloneDX JSON Software Bill of Materials that embeds pyguard
findings as vulnerabilities, suitable for ingestion by SBOM tooling.

CycloneDX spec: https://cyclonedx.org/specification/overview/
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pyguard.models import ScanResult, Severity

_SEVERITY_RATING: dict[Severity, str] = {
    Severity.CRITICAL: "critical",
    Severity.HIGH: "high",
    Severity.MEDIUM: "medium",
    Severity.LOW: "low",
    Severity.INFO: "info",
}


def render_sbom(results: list[ScanResult]) -> dict[str, Any]:
    """Return a CycloneDX 1.4 BOM dict."""
    components: list[dict[str, Any]] = []
    vulnerabilities: list[dict[str, Any]] = []

    for result in results:
        pkg = result.package
        bom_ref = f"pkg:{pkg.name}@{pkg.version}"

        components.append(
            {
                "type": "library",
                "bom-ref": bom_ref,
                "name": pkg.name,
                "version": pkg.version,
                "purl": f"pkg:pypi/{pkg.name}@{pkg.version}",
                "properties": [
                    {"name": "pyguard:risk_score", "value": str(result.risk_score)},
                    {"name": "pyguard:risk_label", "value": result.risk_label.value},
                ],
            }
        )

        for finding in result.findings:
            if finding.severity == Severity.INFO:
                continue
            vuln_id = finding.cve_id or f"PYGUARD-{abs(hash(finding.title)) % 100000:05d}"
            vulnerabilities.append(
                {
                    "bom-ref": str(uuid.uuid4()),
                    "id": vuln_id,
                    "source": {"name": "pyguard", "url": "https://github.com/rajveer43/PyGaurd"},
                    "ratings": [
                        {
                            "source": {"name": "pyguard"},
                            "severity": _SEVERITY_RATING[finding.severity],
                            "score": _severity_to_score(finding.severity),
                        }
                    ],
                    "description": finding.description,
                    "detail": finding.title,
                    "affects": [
                        {
                            "ref": bom_ref,
                            "versions": [{"version": pkg.version, "status": "affected"}],
                        }
                    ],
                    "properties": [
                        {"name": "pyguard:layer", "value": finding.layer},
                        {"name": "pyguard:category", "value": finding.category},
                        {"name": "pyguard:confidence", "value": str(finding.confidence)},
                    ],
                }
            )

    return {
        "bomFormat": "CycloneDX",
        "specVersion": "1.4",
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tools": [{"name": "pyguard", "version": "0.2.0"}],
        },
        "components": components,
        "vulnerabilities": vulnerabilities,
    }


def _severity_to_score(severity: Severity) -> float:
    return {
        Severity.CRITICAL: 9.5,
        Severity.HIGH: 7.5,
        Severity.MEDIUM: 5.0,
        Severity.LOW: 2.5,
        Severity.INFO: 0.0,
    }[severity]
