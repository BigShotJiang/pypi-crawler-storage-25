from __future__ import annotations

from dataclasses import asdict

from pyguard.models import ScanResult


def render_json(result: ScanResult) -> dict[str, object]:
    return {
        "package": {
            "name": result.package.name,
            "version": result.package.version,
        },
        "risk_score": result.risk_score,
        "risk_label": result.risk_label.value,
        "layers_run": result.layers_run,
        "scan_duration_ms": result.scan_duration_ms,
        "findings": [asdict(finding) for finding in result.findings],
    }

