from __future__ import annotations

from abc import ABC, abstractmethod

from pyguard.models import Finding, PackageInfo


class BaseLayer(ABC):
    name: str

    @abstractmethod
    async def analyze(self, package: PackageInfo) -> list[Finding]:
        raise NotImplementedError

