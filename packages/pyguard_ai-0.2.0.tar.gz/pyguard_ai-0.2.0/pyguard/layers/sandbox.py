"""Layer 3 — Runtime sandbox using Docker with honeypot credential injection.

Design patterns:
  - Chain of Responsibility : Checker pipeline (Honeypot → Strace → Filesystem → Resource).
  - Template Method         : BaseSandboxChecker._before_run / _after_run / _emit_findings.
  - Decorator               : TimedSandboxLayer wraps SandboxLayer to add timing metrics.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import tempfile
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pyguard.layers.base import BaseLayer
from pyguard.models import Finding, PackageInfo, Severity

logger = logging.getLogger(__name__)

_SANDBOX_IMAGE = "python:3.12-slim"
_INSTALL_TIMEOUT = 120  # seconds
_MEM_LIMIT = "256m"

# Honeypot markers embedded in fake credential files
_SSH_MARKER = "PYGUARD_HONEYPOT_SSH_KEY"
_AWS_KEY_ID = "AKIAPYGUARDHONEYPOT01"
_AWS_SECRET = "pyguard/honeypot/do-not-use"
_KUBE_MARKER = "pyguard-honeypot-cluster"
_OPENAI_MARKER = "sk-pyguard-honeypot"

_HONEYPOT_FILES: dict[str, str] = {
    ".ssh/id_rsa": (
        f"-----BEGIN RSA PRIVATE KEY-----\n{_SSH_MARKER}\n-----END RSA PRIVATE KEY-----\n"
    ),
    ".aws/credentials": (
        f"[default]\naws_access_key_id = {_AWS_KEY_ID}\n"
        f"aws_secret_access_key = {_AWS_SECRET}/{uuid.uuid4()}\n"
    ),
    ".kube/config": (
        f"apiVersion: v1\nclusters:\n- cluster:\n    server: https://127.0.0.1:6443\n"
        f"  name: {_KUBE_MARKER}\n"
    ),
    ".env": f"OPENAI_API_KEY={_OPENAI_MARKER}-{uuid.uuid4()}\n",
}

_ALL_MARKERS = [_SSH_MARKER, _AWS_KEY_ID, _AWS_SECRET, _KUBE_MARKER, _OPENAI_MARKER]


# ---------------------------------------------------------------------------
# Shared context passed through the checker chain
# ---------------------------------------------------------------------------

@dataclass
class SandboxContext:
    """Shared data object passed through the checker chain."""
    package: PackageInfo
    home_dir: Path
    output: str                           # stdout+stderr from container
    exit_code: int = 0
    container_stats: dict[str, Any] = field(default_factory=dict)
    strace_log: str = ""
    fs_snapshot_before: dict[str, str] = field(default_factory=dict)
    fs_snapshot_after: dict[str, str] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Chain of Responsibility — BaseSandboxChecker
# ---------------------------------------------------------------------------

class BaseSandboxChecker(ABC):
    """Abstract node in the sandbox checker chain (Chain of Responsibility).

    Each checker can add findings to the shared context, then pass control to
    the next checker in the chain.  Template Method defines the _check_impl
    hook that concrete subclasses must implement.
    """

    def __init__(self) -> None:
        self._next: BaseSandboxChecker | None = None

    def set_next(self, checker: "BaseSandboxChecker") -> "BaseSandboxChecker":
        """Chain this checker to the next one and return the next for fluent API."""
        self._next = checker
        return checker

    def check(self, ctx: SandboxContext) -> list[Finding]:
        """Run this checker then delegate to the next in the chain."""
        self._check_impl(ctx)
        if self._next:
            self._next.check(ctx)
        return ctx.findings

    @abstractmethod
    def _check_impl(self, ctx: SandboxContext) -> None:
        """Concrete checkers implement their analysis here."""


# ---------------------------------------------------------------------------
# Concrete checkers
# ---------------------------------------------------------------------------

class HoneypotChecker(BaseSandboxChecker):
    """Detects honeypot credential leaks in container output and file tampering."""

    def _check_impl(self, ctx: SandboxContext) -> None:
        # 1. Stdout/stderr leaks
        leaked = [m for m in _ALL_MARKERS if m in ctx.output]
        if leaked:
            ctx.findings.append(
                Finding(
                    severity=Severity.CRITICAL,
                    title="Honeypot credential exfiltration confirmed",
                    description=(
                        f"Package '{ctx.package.name}' accessed and leaked honeypot "
                        f"credential markers during installation: {', '.join(leaked)}. "
                        "This is definitive proof of credential theft behaviour."
                    ),
                    layer="sandbox",
                    package=ctx.package.name,
                    version=ctx.package.version,
                    evidence={"leaked_markers": leaked, "output_snippet": ctx.output[:500]},
                    confidence=0.99,
                    category="credential_theft",
                    remediation="Do NOT install this package. Report to PyPI security.",
                )
            )

        # 2. File content tampering
        for rel_path, original in _HONEYPOT_FILES.items():
            fpath = ctx.home_dir / rel_path
            if not fpath.exists():
                continue
            try:
                current = fpath.read_text(encoding="utf-8")
            except OSError:
                continue
            if current != original:
                ctx.findings.append(
                    Finding(
                        severity=Severity.CRITICAL,
                        title=f"Honeypot file modified: {rel_path}",
                        description=(
                            f"The honeypot credential file '~/{rel_path}' was modified "
                            f"during installation of '{ctx.package.name}'. "
                            "This indicates the package accessed and tampered with credentials."
                        ),
                        layer="sandbox",
                        package=ctx.package.name,
                        version=ctx.package.version,
                        evidence={"honeypot_file": rel_path},
                        confidence=0.95,
                        category="credential_theft",
                        remediation="Do NOT install this package. Report to PyPI security.",
                    )
                )


class StraceChecker(BaseSandboxChecker):
    """Parses strace output to detect suspicious syscalls (network connect, sensitive file opens)."""

    # Sensitive path prefixes that strace open() calls should not touch
    _SENSITIVE_PATHS = (
        "/etc/passwd", "/etc/shadow", "/root/.ssh", "/root/.aws",
        "/root/.kube", "/root/.env", "/proc/",
    )

    def _check_impl(self, ctx: SandboxContext) -> None:
        if not ctx.strace_log:
            return

        ctx.findings.extend(self._parse_connect_calls(ctx))
        ctx.findings.extend(self._parse_file_opens(ctx))

    def _parse_connect_calls(self, ctx: SandboxContext) -> list[Finding]:
        """Flag outbound connect() syscalls to external IPs."""
        findings: list[Finding] = []
        # Pattern: connect(fd, {sa_family=AF_INET, sin_addr=inet_addr("x.x.x.x"), ...}, len)
        connect_re = re.compile(r'connect\(\d+,\s*\{.*?sin_addr=inet_addr\("([^"]+)"')
        seen: set[str] = set()
        for match in connect_re.finditer(ctx.strace_log):
            ip = match.group(1)
            if ip in seen or ip.startswith(("127.", "0.", "::1")):
                continue
            seen.add(ip)
            findings.append(
                Finding(
                    severity=Severity.HIGH,
                    title=f"Outbound network connection during install: {ip}",
                    description=(
                        f"strace captured a connect() syscall to external IP {ip} "
                        f"during installation of '{ctx.package.name}'. "
                        "Packages must not initiate network connections at install time."
                    ),
                    layer="sandbox",
                    package=ctx.package.name,
                    version=ctx.package.version,
                    evidence={"ip": ip},
                    confidence=0.90,
                    category="exfiltration",
                    remediation="Review setup.py install hooks for outbound requests.",
                )
            )
        return findings

    def _parse_file_opens(self, ctx: SandboxContext) -> list[Finding]:
        """Flag open() syscalls on sensitive credential paths."""
        findings: list[Finding] = []
        # Pattern: openat(AT_FDCWD, "/path/to/file", flags)
        open_re = re.compile(r'open(?:at)?\([^,]+,\s*"([^"]+)"')
        seen: set[str] = set()
        for match in open_re.finditer(ctx.strace_log):
            path = match.group(1)
            if path in seen:
                continue
            if any(path.startswith(p) for p in self._SENSITIVE_PATHS):
                seen.add(path)
                findings.append(
                    Finding(
                        severity=Severity.HIGH,
                        title=f"Sensitive file access during install: {path}",
                        description=(
                            f"strace detected open() on sensitive path '{path}' "
                            f"during installation of '{ctx.package.name}'."
                        ),
                        layer="sandbox",
                        package=ctx.package.name,
                        version=ctx.package.version,
                        evidence={"path": path},
                        confidence=0.85,
                        category="credential_theft",
                        remediation="Review the package's install hooks.",
                    )
                )
        return findings


class FilesystemChecker(BaseSandboxChecker):
    """Detects filesystem changes (new/modified/deleted files) made during install."""

    def _check_impl(self, ctx: SandboxContext) -> None:
        before = ctx.fs_snapshot_before
        after = ctx.fs_snapshot_after
        if not before and not after:
            return

        new_files = set(after) - set(before)
        deleted_files = set(before) - set(after)
        modified = {
            p for p in set(before) & set(after)
            if before[p] != after[p]
        }

        for path in new_files:
            ctx.findings.append(
                Finding(
                    severity=Severity.MEDIUM,
                    title=f"New file created during install: {path}",
                    description=(
                        f"Installation of '{ctx.package.name}' created a new file at '{path}'. "
                        "Packages should only write to site-packages."
                    ),
                    layer="sandbox",
                    package=ctx.package.name,
                    version=ctx.package.version,
                    evidence={"path": path},
                    confidence=0.75,
                    category="persistence",
                )
            )

        for path in modified:
            # Honeypot files are handled by HoneypotChecker; skip duplicates
            rel = path.lstrip("/root/").lstrip("/")
            if rel in _HONEYPOT_FILES:
                continue
            ctx.findings.append(
                Finding(
                    severity=Severity.HIGH,
                    title=f"Existing file modified during install: {path}",
                    description=(
                        f"Installation of '{ctx.package.name}' modified '{path}'. "
                        "This may indicate persistence or system tampering."
                    ),
                    layer="sandbox",
                    package=ctx.package.name,
                    version=ctx.package.version,
                    evidence={"path": path},
                    confidence=0.80,
                    category="persistence",
                    remediation="Inspect the file change and the package's setup hooks.",
                )
            )

        for path in deleted_files:
            ctx.findings.append(
                Finding(
                    severity=Severity.MEDIUM,
                    title=f"File deleted during install: {path}",
                    description=(
                        f"Installation of '{ctx.package.name}' deleted '{path}'."
                    ),
                    layer="sandbox",
                    package=ctx.package.name,
                    version=ctx.package.version,
                    evidence={"path": path},
                    confidence=0.70,
                    category="persistence",
                )
            )


class ResourceChecker(BaseSandboxChecker):
    """Flags anomalous CPU/memory usage (e.g. cryptominer behaviour)."""

    _CPU_THRESHOLD_PERCENT = 80.0  # flag if CPU usage exceeded this

    def _check_impl(self, ctx: SandboxContext) -> None:
        # CPU resource check (requires Docker stats)
        if ctx.container_stats:
            cpu_pct = _calc_cpu_percent(ctx.container_stats)
            if cpu_pct and cpu_pct >= self._CPU_THRESHOLD_PERCENT:
                ctx.findings.append(
                    Finding(
                        severity=Severity.HIGH,
                        title=f"Excessive CPU usage during install: {cpu_pct:.1f}%",
                        description=(
                            f"'{ctx.package.name}' consumed {cpu_pct:.1f}% CPU during sandbox "
                            "installation. This may indicate a cryptominer or compute-heavy payload."
                        ),
                        layer="sandbox",
                        package=ctx.package.name,
                        version=ctx.package.version,
                        evidence={"cpu_percent": cpu_pct},
                        confidence=0.70,
                        category="execution",
                        remediation="Inspect setup.py for background computation.",
                    )
                )

        # Network activity patterns in output (kept lightweight, no packet capture)
        network_hints = [
            ("curl ", "curl command executed during install"),
            ("wget ", "wget command executed during install"),
            ("requests.post", "requests.post call detected in install output"),
            ("urllib.request", "urllib.request call detected in install output"),
        ]
        lower = ctx.output.lower()
        for hint, label in network_hints:
            if hint in lower:
                ctx.findings.append(
                    Finding(
                        severity=Severity.HIGH,
                        title=f"Network activity during install: {label}",
                        description=(
                            f"Installation of '{ctx.package.name}' produced output suggesting "
                            f"network activity: '{label}'. Packages should not make outbound "
                            "connections during installation."
                        ),
                        layer="sandbox",
                        package=ctx.package.name,
                        version=ctx.package.version,
                        evidence={"hint": hint, "output_snippet": ctx.output[:300]},
                        confidence=0.70,
                        category="exfiltration",
                        remediation="Review the package's setup.py and install hooks.",
                    )
                )


# ---------------------------------------------------------------------------
# Filesystem snapshot helper
# ---------------------------------------------------------------------------

def _snapshot_directory(directory: Path) -> dict[str, str]:
    """Return {relative_path: sha256_hex} for every file under directory."""
    snapshot: dict[str, str] = {}
    if not directory.exists():
        return snapshot
    for fpath in directory.rglob("*"):
        if fpath.is_file():
            try:
                data = fpath.read_bytes()
                rel = str(fpath.relative_to(directory))
                snapshot[rel] = hashlib.sha256(data).hexdigest()
            except OSError:
                pass
    return snapshot


def _write_honeypot(home_dir: Path) -> None:
    for rel_path, content in _HONEYPOT_FILES.items():
        dest = home_dir / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")


def _calc_cpu_percent(stats: dict[str, Any]) -> float | None:
    """Calculate CPU percentage from Docker stats response."""
    try:
        cpu_delta = stats["cpu_stats"]["cpu_usage"]["total_usage"] - stats["precpu_stats"]["cpu_usage"]["total_usage"]
        system_delta = stats["cpu_stats"]["system_cpu_usage"] - stats["precpu_stats"]["system_cpu_usage"]
        num_cpus = stats["cpu_stats"].get("online_cpus") or len(stats["cpu_stats"]["cpu_usage"].get("percpu_usage", [1]))
        if system_delta > 0:
            return (cpu_delta / system_delta) * num_cpus * 100.0
    except (KeyError, ZeroDivisionError, TypeError):
        pass
    return None


# ---------------------------------------------------------------------------
# SandboxLayer — orchestrates the chain
# ---------------------------------------------------------------------------

class SandboxLayer(BaseLayer):
    """Layer 3 sandbox runtime analysis.

    Builds and runs the checker chain:
      HoneypotChecker → StraceChecker → FilesystemChecker → ResourceChecker
    """

    name = "sandbox"

    def __init__(self, network_mode: str = "none") -> None:
        self._docker_available: bool | None = None
        self._network_mode = network_mode  # "none" | "bridge"

        # Build checker chain (Chain of Responsibility)
        self._chain = HoneypotChecker()
        strace = self._chain.set_next(StraceChecker())
        fs = strace.set_next(FilesystemChecker())
        fs.set_next(ResourceChecker())

    def _check_docker(self) -> bool:
        if self._docker_available is not None:
            return self._docker_available
        try:
            import docker  # noqa: PLC0415

            client = docker.from_env()
            client.ping()
            self._docker_available = True
        except Exception:  # noqa: BLE001
            self._docker_available = False
        return self._docker_available

    async def analyze(self, package: PackageInfo) -> list[Finding]:
        if not self._check_docker():
            logger.warning("Sandbox layer disabled: Docker is not available on this system.")
            return []

        if package.version in ("latest", "unknown", ""):
            logger.info("Sandbox skipped: no pinned version for '%s'", package.name)
            return []

        try:
            return await self._run_sandbox(package)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Sandbox layer failed for %s: %s", package.name, exc)
            return [
                Finding(
                    severity=Severity.INFO,
                    title="Sandbox execution failed",
                    description=f"Could not complete sandbox analysis: {exc}",
                    layer=self.name,
                    package=package.name,
                    version=package.version,
                    evidence={"error": str(exc)},
                    confidence=1.0,
                    category="sandbox_error",
                )
            ]

    async def _run_sandbox(self, package: PackageInfo) -> list[Finding]:
        import docker  # noqa: PLC0415

        with tempfile.TemporaryDirectory(prefix="pyguard_sandbox_") as tmp:
            tmp_path = Path(tmp)
            home_dir = tmp_path / "home" / "testuser"
            home_dir.mkdir(parents=True)
            _write_honeypot(home_dir)

            monitor_dir = tmp_path / "monitor"
            monitor_dir.mkdir()

            client = docker.from_env()

            # Filesystem snapshot BEFORE install
            fs_before = _snapshot_directory(home_dir)

            install_cmd = (
                f"pip install --no-deps --quiet "
                f"{package.name}=={package.version} 2>&1"
            )
            full_cmd = f"sh -c '{install_cmd}'"

            volumes: dict[str, dict[str, str]] = {
                str(home_dir): {"bind": "/root", "mode": "rw"},
                str(monitor_dir): {"bind": "/monitor", "mode": "rw"},
            }

            container_obj = None
            try:
                container_obj = client.containers.run(
                    _SANDBOX_IMAGE,
                    full_cmd,
                    remove=False,     # keep for stats query
                    detach=True,
                    mem_limit=_MEM_LIMIT,
                    network_mode=self._network_mode,
                    security_opt=["no-new-privileges"],
                    cap_drop=["ALL"],
                    volumes=volumes,
                    stdout=True,
                    stderr=True,
                )
                # Wait for completion
                result = container_obj.wait(timeout=_INSTALL_TIMEOUT)
                exit_code = result.get("StatusCode", 0)

                # Collect logs
                output: str = container_obj.logs(stdout=True, stderr=True).decode("utf-8", errors="replace")

                # Collect resource stats
                try:
                    stats = container_obj.stats(stream=False)
                except Exception:  # noqa: BLE001
                    stats = {}

            except Exception as exc:  # noqa: BLE001
                raise RuntimeError(f"Docker run failed: {exc}") from exc
            finally:
                if container_obj:
                    try:
                        container_obj.remove(force=True)
                    except Exception:  # noqa: BLE001
                        pass

            # Filesystem snapshot AFTER install
            fs_after = _snapshot_directory(home_dir)

            # Read strace log if present
            strace_log_path = monitor_dir / "strace.log"
            strace_log = strace_log_path.read_text(encoding="utf-8", errors="replace") if strace_log_path.exists() else ""

            # Build shared context
            ctx = SandboxContext(
                package=package,
                home_dir=home_dir,
                output=output,
                exit_code=exit_code,
                container_stats=stats,
                strace_log=strace_log,
                fs_snapshot_before=fs_before,
                fs_snapshot_after=fs_after,
            )

            # Run the checker chain
            return self._chain.check(ctx)


# ---------------------------------------------------------------------------
# Decorator pattern — TimedSandboxLayer
# ---------------------------------------------------------------------------

class TimedSandboxLayer(BaseLayer):
    """Decorator that wraps SandboxLayer to log execution timing."""

    name = "sandbox"

    def __init__(self, wrapped: SandboxLayer) -> None:
        self._wrapped = wrapped

    async def analyze(self, package: PackageInfo) -> list[Finding]:
        start = time.monotonic()
        findings = await self._wrapped.analyze(package)
        elapsed_ms = int((time.monotonic() - start) * 1000)
        logger.info("Sandbox analysis for %s completed in %d ms", package.name, elapsed_ms)
        return findings
