"""Layer 2 — AI analysis using the Anthropic Claude API.

Design patterns:
  - Template Method : BaseLayer.analyze() skeleton; AIAnalysisLayer fills hooks.
  - Builder         : PromptBuilder assembles the Claude prompt step-by-step.
  - Strategy        : ResponseParser is swappable (ToolUseParser / JSONParser).
"""
from __future__ import annotations

import json
import logging
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from pyguard.layers.base import BaseLayer
from pyguard.models import Finding, PackageInfo, Severity

logger = logging.getLogger(__name__)

# Files analysed first (highest attack surface)
_PRIORITY_NAMES = {"setup.py", "setup.cfg", "pyproject.toml", "__init__.py"}

# Rough token budget per request (leaves head-room in 200 k context window)
_MAX_SOURCE_CHARS = 120_000

_SYSTEM_PROMPT = """\
You are a Python supply chain security expert. Analyse the provided package source code \
for ACTIVE malicious behaviour — not theoretical vulnerabilities.

Focus on:
1. Credential theft: reading ~/.ssh/, ~/.aws/, ~/.kube/, env vars with key/token/secret.
2. Data exfiltration: HTTP POST to external domains during install or import.
3. Persistence: modifying shell configs, cron jobs, startup items.
4. Obfuscation: base64-encoded payloads, exec(compile(…)), __import__ tricks.
5. Install hooks: setup.py cmdclass overrides, distutils hooks.
6. Privilege escalation: sudo, setuid, modifying system files.

Respond ONLY with valid JSON matching this schema (no markdown, no prose):
{
  "findings": [
    {
      "severity": "critical|high|medium|low|info",
      "title": "Short title (≤80 chars)",
      "description": "What it does and why it is dangerous",
      "file": "relative/path/to/file.py",
      "line_hint": 42,
      "code_snippet": "1–3 relevant lines",
      "confidence": 0.95,
      "category": "credential_theft|exfiltration|obfuscation|persistence|execution|other"
    }
  ],
  "overall_verdict": "malicious|suspicious|clean",
  "reasoning": "One-sentence explanation"
}
If there are no findings return {"findings": [], "overall_verdict": "clean", "reasoning": "…"}.
"""

_SEVERITY_MAP: dict[str, Severity] = {
    "critical": Severity.CRITICAL,
    "high": Severity.HIGH,
    "medium": Severity.MEDIUM,
    "low": Severity.LOW,
    "info": Severity.INFO,
}


# ---------------------------------------------------------------------------
# Builder pattern — PromptBuilder
# ---------------------------------------------------------------------------

class PromptBuilder:
    """Assembles the Claude user-prompt step by step (Builder pattern).

    Usage::

        prompt = (
            PromptBuilder()
            .with_metadata(package)
            .with_taint_summary(static_findings)
            .with_source_files(package.files)
            .with_instructions()
            .build()
        )
    """

    def __init__(self) -> None:
        self._parts: list[str] = []
        self._chars_used: int = 0

    def with_metadata(self, package: PackageInfo) -> "PromptBuilder":
        meta = package.metadata
        lines = [
            f"Package: {package.name}=={package.version}",
        ]
        if meta.author:
            lines.append(f"Author: {meta.author}")
        if meta.release_history:
            age_days = None
            try:
                from datetime import datetime, timezone  # noqa: PLC0415
                first_upload = meta.release_history[0].upload_time
                dt = datetime.fromisoformat(first_upload.replace("Z", "+00:00"))
                age_days = (datetime.now(timezone.utc) - dt).days
            except Exception:  # noqa: BLE001
                pass
            lines.append(f"Versions in history: {len(meta.release_history)}")
            if age_days is not None:
                lines.append(f"Package age (days): {age_days}")
        self._parts.append("\n".join(lines))
        return self

    def with_taint_summary(self, static_findings: list[Finding]) -> "PromptBuilder":
        """Inject a taint analysis summary derived from Layer 1 findings."""
        if not static_findings:
            return self
        high_sev = [
            f for f in static_findings
            if f.severity in (Severity.CRITICAL, Severity.HIGH)
        ]
        if not high_sev:
            return self
        lines = ["", "Layer 1 static analysis flagged the following (use as hints):"]
        for finding in high_sev[:10]:  # cap at 10 to avoid prompt bloat
            loc = f"{finding.file}:{finding.line}" if finding.file else "unknown"
            lines.append(f"  - [{finding.severity.value.upper()}] {finding.title} @ {loc}")
        self._parts.append("\n".join(lines))
        return self

    def with_source_files(self, files: dict[str, str]) -> "PromptBuilder":
        """Add Python source files in priority order, respecting the char budget."""
        lines = ["", "Source files (in priority order):", ""]
        for file_path, content in sorted(files.items(), key=lambda kv: _priority_sort_key(kv[0])):
            if not file_path.endswith(".py"):
                continue
            header = f"### {file_path}\n"
            block = f"```python\n{content}\n```\n\n"
            chunk = header + block
            if self._chars_used + len(chunk) > _MAX_SOURCE_CHARS:
                lines.append(f"### {file_path}\n[truncated — file budget exceeded]\n")
                break
            lines.append(chunk)
            self._chars_used += len(chunk)
        self._parts.append("\n".join(lines))
        return self

    def with_instructions(self) -> "PromptBuilder":
        self._parts.append(
            "\nAnalyse ALL files above for active malicious behaviour. "
            "Pay special attention to install hooks and obfuscated code."
        )
        return self

    def build(self) -> str:
        return "\n".join(self._parts)


# ---------------------------------------------------------------------------
# Strategy pattern — ResponseParser
# ---------------------------------------------------------------------------

class ResponseParser(ABC):
    """Abstract strategy for parsing a Claude API response into findings."""

    @abstractmethod
    def parse(
        self, package: PackageInfo, raw: str
    ) -> tuple[list[Finding], str | None, float | None]:
        """Return (findings, verdict, avg_confidence)."""


class JSONParser(ResponseParser):
    """Parse Claude's free-form JSON text response (fallback strategy)."""

    def parse(
        self, package: PackageInfo, raw: str
    ) -> tuple[list[Finding], str | None, float | None]:
        try:
            data: dict[str, Any] = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("AI layer: could not parse JSON response")
            return [], None, None

        return _extract_findings(package, data)


class ToolUseParser(ResponseParser):
    """Parse Claude's structured tool_use response (preferred strategy)."""

    def parse(
        self, package: PackageInfo, raw_or_data: str
    ) -> tuple[list[Finding], str | None, float | None]:
        # raw_or_data is a JSON-serialised tool_use input block
        try:
            data: dict[str, Any] = json.loads(raw_or_data)
        except json.JSONDecodeError:
            logger.warning("AI layer: could not parse tool_use JSON")
            return [], None, None
        return _extract_findings(package, data)


def _extract_findings(
    package: PackageInfo, data: dict[str, Any]
) -> tuple[list[Finding], str | None, float | None]:
    """Shared extraction logic used by both parsers."""
    findings: list[Finding] = []
    for item in data.get("findings", []):
        sev_str = str(item.get("severity", "medium")).lower()
        severity = _SEVERITY_MAP.get(sev_str, Severity.MEDIUM)
        confidence = float(item.get("confidence", 0.7))
        findings.append(
            Finding(
                severity=severity,
                title=str(item.get("title", "AI finding"))[:120],
                description=str(item.get("description", "")),
                layer="ai",
                package=package.name,
                version=package.version,
                evidence={
                    "code_snippet": str(item.get("code_snippet", "")),
                    "ai_verdict": str(data.get("overall_verdict", "")),
                },
                confidence=min(max(confidence, 0.0), 1.0),
                file=item.get("file") or None,
                line=int(item["line_hint"]) if item.get("line_hint") else None,
                category=str(item.get("category", "general")),
            )
        )

    verdict: str | None = data.get("overall_verdict") or None
    avg_conf: float | None = (
        sum(f.confidence for f in findings) / len(findings)
        if findings
        else (0.9 if verdict else None)
    )
    return findings, verdict, avg_conf


# ---------------------------------------------------------------------------
# Confidence calibration
# ---------------------------------------------------------------------------

def _calibrate_confidence(
    ai_findings: list[Finding], static_findings: list[Finding]
) -> list[Finding]:
    """Boost AI finding confidence when corroborated by Layer 1 (Strategy result refinement)."""
    static_titles = {f.title.lower() for f in static_findings}
    static_files = {f.file for f in static_findings if f.file}

    calibrated: list[Finding] = []
    for finding in ai_findings:
        conf = finding.confidence
        # Corroborated: same file flagged by static analysis
        if finding.file and finding.file in static_files:
            conf = min(conf + 0.15, 0.95)
        # Title overlap
        elif any(word in finding.title.lower() for word in static_titles if len(word) > 4):
            conf = min(conf + 0.10, 0.95)
        # AI-only critical
        elif finding.severity == Severity.CRITICAL:
            conf = max(conf, 0.75)
        # AI-only low
        elif finding.severity == Severity.LOW:
            conf = min(conf, 0.5)

        # Return a new Finding with updated confidence (dataclass replace)
        from dataclasses import replace  # noqa: PLC0415
        calibrated.append(replace(finding, confidence=round(conf, 2)))
    return calibrated


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _priority_sort_key(file_path: str) -> int:
    return 0 if Path(file_path).name in _PRIORITY_NAMES else 1


# ---------------------------------------------------------------------------
# AIAnalysisLayer — Template Method (analyze skeleton)
# ---------------------------------------------------------------------------

class AIAnalysisLayer(BaseLayer):
    """Layer 2 AI analysis using Claude.

    Template Method: analyze() orchestrates the fixed skeleton;
    PromptBuilder and ResponseParser are injected for flexibility.
    """

    name = "ai"

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-sonnet-4-6",
        parser: ResponseParser | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self._model = model
        # Default to ToolUseParser with JSONParser as fallback
        self._parser: ResponseParser = parser or JSONParser()

    async def analyze(self, package: PackageInfo, static_findings: list[Finding] | None = None) -> list[Finding]:
        """Template Method skeleton:
        1. Guard checks
        2. Build prompt  (PromptBuilder)
        3. Call Claude API
        4. Parse response (ResponseParser strategy)
        5. Calibrate confidence
        6. Attach verdict finding
        """
        if not self._api_key:
            logger.warning(
                "AI layer disabled: set ANTHROPIC_API_KEY to enable Claude analysis."
            )
            return []

        if not package.files:
            return []

        try:
            import anthropic  # noqa: PLC0415
        except ImportError:
            logger.warning("AI layer disabled: install 'anthropic' package to enable.")
            return []

        prior = static_findings or []

        # Step 2 — Build prompt (Builder pattern)
        prompt = (
            PromptBuilder()
            .with_metadata(package)
            .with_taint_summary(prior)
            .with_source_files(package.files)
            .with_instructions()
            .build()
        )

        # Step 3 — Call Claude
        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        raw = await self._call_api(client, prompt)
        if raw is None:
            return []

        # Step 4 — Parse response (Strategy pattern)
        findings, verdict, avg_conf = self._parser.parse(package, raw)

        # Step 5 — Calibrate confidence against Layer 1 findings
        findings = _calibrate_confidence(findings, prior)

        # Step 6 — Attach overall verdict as synthetic INFO finding
        if verdict and verdict != "clean":
            try:
                reasoning = json.loads(raw).get("reasoning", "")
            except Exception:  # noqa: BLE001
                reasoning = ""
            findings.append(
                Finding(
                    severity=Severity.INFO,
                    title=f"AI overall verdict: {verdict}",
                    description=str(reasoning),
                    layer="ai",
                    package=package.name,
                    version=package.version,
                    evidence={"verdict": verdict},
                    confidence=avg_conf or 0.8,
                    category="ai_verdict",
                )
            )

        return findings

    async def _call_api(self, client: Any, prompt: str) -> str | None:
        """Call Claude and return the raw text response."""
        try:
            import anthropic  # noqa: PLC0415

            # Attempt tool_use structured output first
            findings_tool = anthropic.types.ToolParam(
                name="report_findings",
                description="Report security findings in structured format",
                input_schema={
                    "type": "object",
                    "properties": {
                        "findings": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "severity": {"type": "string", "enum": ["critical", "high", "medium", "low", "info"]},
                                    "title": {"type": "string"},
                                    "description": {"type": "string"},
                                    "file": {"type": "string"},
                                    "line_hint": {"type": "integer"},
                                    "code_snippet": {"type": "string"},
                                    "confidence": {"type": "number"},
                                    "category": {"type": "string"},
                                },
                                "required": ["severity", "title", "description", "confidence", "category"],
                            },
                        },
                        "overall_verdict": {"type": "string", "enum": ["malicious", "suspicious", "clean"]},
                        "reasoning": {"type": "string"},
                    },
                    "required": ["findings", "overall_verdict", "reasoning"],
                },
            )

            message = await client.messages.create(
                model=self._model,
                max_tokens=4096,
                system=_SYSTEM_PROMPT,
                tools=[findings_tool],
                tool_choice={"type": "auto"},
                messages=[{"role": "user", "content": prompt}],
            )

            # Extract tool_use block if present, else fall back to text
            for block in message.content:
                if block.type == "tool_use" and block.name == "report_findings":
                    # Switch to ToolUseParser for this response
                    self._parser = ToolUseParser()
                    return json.dumps(block.input)

            # Fallback: plain text JSON
            self._parser = JSONParser()
            text_blocks = [b for b in message.content if hasattr(b, "text")]
            return text_blocks[0].text if text_blocks else None

        except Exception as exc:  # noqa: BLE001
            logger.warning("AI layer API call failed: %s", exc)
            return None
