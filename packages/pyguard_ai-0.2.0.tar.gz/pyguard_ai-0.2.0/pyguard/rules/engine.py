"""Custom rules engine.

Design patterns:
  - Singleton : RuleRegistry holds all loaded rules; one instance per process.
  - Visitor   : RuleVisitor walks the AST and applies rules without modifying
                the detector or AST code.  New rules = new visit logic, no
                changes to core detectors.
"""
from __future__ import annotations

import ast
import logging
import re
from pathlib import Path
from typing import Any

from pyguard.models import Finding, Severity
from pyguard.rules.schema import Rule

logger = logging.getLogger(__name__)

_SEVERITY_MAP: dict[str, Severity] = {
    "critical": Severity.CRITICAL,
    "high": Severity.HIGH,
    "medium": Severity.MEDIUM,
    "low": Severity.LOW,
    "info": Severity.INFO,
}


# ---------------------------------------------------------------------------
# Singleton — RuleRegistry
# ---------------------------------------------------------------------------

class RuleRegistry:
    """Global singleton that holds all active detection rules.

    Load rules once at startup; all detectors share the same instance.

    Usage::

        registry = RuleRegistry.instance()
        registry.load_yaml(Path("rules.yaml"))
        rules = registry.rules
    """

    _instance: "RuleRegistry | None" = None

    def __new__(cls) -> "RuleRegistry":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._rules: list[Rule] = []
        return cls._instance

    @classmethod
    def instance(cls) -> "RuleRegistry":
        return cls()

    @classmethod
    def reset(cls) -> None:
        """Clear the singleton (useful in tests)."""
        cls._instance = None

    def load_yaml(self, path: Path) -> None:
        """Load rules from a YAML file and add them to the registry."""
        try:
            import yaml  # type: ignore[import]
        except ImportError:
            logger.warning("PyYAML not installed; cannot load custom rules from %s", path)
            return

        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse rules file %s: %s", path, exc)
            return

        raw_rules: list[Any] = data.get("rules", []) if isinstance(data, dict) else []
        loaded = 0
        for item in raw_rules:
            try:
                rule = Rule(**item)
                if rule.enabled:
                    self._rules.append(rule)
                    loaded += 1
            except Exception as exc:  # noqa: BLE001
                logger.warning("Skipping invalid rule %s: %s", item.get("id", "?"), exc)
        logger.info("Loaded %d custom rules from %s", loaded, path)

    def load_default_rules(self) -> None:
        """Load the built-in default_rules.yaml shipped with pyguard."""
        default = Path(__file__).parent / "default_rules.yaml"
        if default.exists():
            self.load_yaml(default)

    @property
    def rules(self) -> list[Rule]:
        return list(self._rules)

    def clear(self) -> None:
        self._rules.clear()


# ---------------------------------------------------------------------------
# Visitor pattern — RuleVisitor
# ---------------------------------------------------------------------------

class RuleVisitor(ast.NodeVisitor):
    """Applies custom rules to an AST (Visitor pattern).

    This visitor iterates over AST nodes without modifying any detector or AST
    infrastructure.  Adding a new rule type only requires extending
    ``_apply_ast_call_rule`` / ``_apply_import_rule``.
    """

    def __init__(self, rules: list[Rule], file_path: str, source: str) -> None:
        self._rules = rules
        self._file_path = file_path
        self._source_lines = source.splitlines()
        self.findings: list[Finding] = []

    # --- AST call visitor ---------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:
        qualified = _qualified_name(node.func)
        if qualified:
            for rule in self._rules:
                if rule.pattern_type == "ast_call" and re.search(rule.pattern, qualified):
                    self._emit(rule, node.lineno)
        self.generic_visit(node)

    # --- Import visitors ----------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self._check_import(alias.name, node.lineno)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        self._check_import(module, node.lineno)
        self.generic_visit(node)

    def _check_import(self, module: str, lineno: int) -> None:
        for rule in self._rules:
            if rule.pattern_type == "import" and re.search(rule.pattern, module):
                self._emit(rule, lineno)

    # --- Emission -----------------------------------------------------------

    def _emit(self, rule: Rule, lineno: int | None) -> None:
        snippet = ""
        if lineno and 1 <= lineno <= len(self._source_lines):
            snippet = self._source_lines[lineno - 1].strip()
        self.findings.append(
            Finding(
                severity=_SEVERITY_MAP.get(rule.severity, Severity.MEDIUM),
                title=rule.name,
                description=rule.description,
                layer="static",
                package="",       # filled in by caller
                version="",       # filled in by caller
                evidence={"rule_id": rule.id, "code_snippet": snippet},
                confidence=0.80,
                file=self._file_path,
                line=lineno,
                category=rule.category,
                remediation=rule.remediation,
            )
        )


def apply_regex_rules(
    rules: list[Rule], file_path: str, source: str
) -> list[Finding]:
    """Apply regex-type rules against raw source lines."""
    findings: list[Finding] = []
    lines = source.splitlines()
    regex_rules = [r for r in rules if r.pattern_type == "regex"]
    for rule in regex_rules:
        try:
            compiled = re.compile(rule.pattern)
        except re.error as exc:
            logger.warning("Invalid regex in rule %s: %s", rule.id, exc)
            continue
        for lineno, line in enumerate(lines, start=1):
            if compiled.search(line):
                findings.append(
                    Finding(
                        severity=_SEVERITY_MAP.get(rule.severity, Severity.MEDIUM),
                        title=rule.name,
                        description=rule.description,
                        layer="static",
                        package="",
                        version="",
                        evidence={"rule_id": rule.id, "code_snippet": line.strip()},
                        confidence=0.80,
                        file=file_path,
                        line=lineno,
                        category=rule.category,
                        remediation=rule.remediation,
                    )
                )
    return findings


def run_rules(
    rules: list[Rule],
    file_path: str,
    source: str,
    package_name: str,
    package_version: str,
) -> list[Finding]:
    """Run all custom rules against a source file and return findings.

    Fills in package/version on every finding returned.
    """
    findings: list[Finding] = []

    # Regex rules (no AST needed)
    findings.extend(apply_regex_rules(rules, file_path, source))

    # AST-based rules (ast_call + import)
    ast_rules = [r for r in rules if r.pattern_type in ("ast_call", "import")]
    if ast_rules:
        try:
            tree = ast.parse(source, filename=file_path)
            visitor = RuleVisitor(ast_rules, file_path, source)
            visitor.visit(tree)
            findings.extend(visitor.findings)
        except SyntaxError:
            pass  # non-parseable file; skip AST rules

    # Stamp package info
    from dataclasses import replace  # noqa: PLC0415
    return [replace(f, package=package_name, version=package_version) for f in findings]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _qualified_name(node: ast.expr) -> str | None:
    """Return dotted name for attribute/name access (e.g. 'os.system')."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _qualified_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    return None
