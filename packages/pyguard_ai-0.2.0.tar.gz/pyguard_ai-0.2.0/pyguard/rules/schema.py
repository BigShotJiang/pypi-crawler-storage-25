"""Pydantic model for a custom detection rule."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Rule(BaseModel):
    """A single detection rule loaded from YAML."""

    id: str = Field(..., description="Unique rule identifier, e.g. PG-CUSTOM-001")
    name: str = Field(..., description="Human-readable rule name")
    severity: Literal["critical", "high", "medium", "low", "info"] = "medium"
    pattern_type: Literal["regex", "ast_call", "import"] = Field(
        ...,
        description=(
            "regex  — match against raw source lines\n"
            "ast_call — match a function call by qualified name (e.g. os.system)\n"
            "import   — flag when a module is imported (e.g. ctypes)"
        ),
    )
    pattern: str = Field(..., description="The pattern string to match")
    description: str = Field(..., description="What the rule detects and why it matters")
    category: str = "general"
    remediation: str | None = None
    enabled: bool = True
