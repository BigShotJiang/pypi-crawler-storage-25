"""Custom rules engine for pyguard."""
