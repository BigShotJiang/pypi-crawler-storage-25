# Architecture

`pyguard` uses an orchestrator that runs one or more analysis layers and aggregates findings into a unified report.

