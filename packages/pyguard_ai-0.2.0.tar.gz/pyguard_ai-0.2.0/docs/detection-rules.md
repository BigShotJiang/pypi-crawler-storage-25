# Detection Rules

Current rules cover typosquatting and AST-detected suspicious behaviors such as credential-path access, subprocess execution, and outbound HTTP usage.

