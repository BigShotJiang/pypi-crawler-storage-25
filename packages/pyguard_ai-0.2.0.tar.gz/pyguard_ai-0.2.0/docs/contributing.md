# Contributing

1. Create a branch.
2. Install development dependencies with `make install`.
3. Run `make lint test typecheck` before opening a pull request.

