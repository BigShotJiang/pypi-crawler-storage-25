# pyguard

`pyguard` is a PyPI supply chain scanner focused on malicious-package detection, not just known CVEs.

## Current scope

This repository now includes:

- A working `pyguard scan` CLI
- Core data models and scan orchestration
- Layer 1 static analysis baseline
- JSON and terminal reporting
- Project tooling, CI, and test scaffolding

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pyguard scan requests==2.31.0
pytest
```

## Roadmap

The implementation follows the multi-phase plan for:

- Layer 1 static analysis
- Layer 2 AI-assisted analysis
- Layer 3 sandbox runtime analysis
- CI/CD integrations and reporting outputs

