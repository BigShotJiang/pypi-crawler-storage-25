"""Unit tests for the requirements resolver."""
from __future__ import annotations

from pathlib import Path

from pyguard.resolver import parse_requirements_txt


def test_pinned_version_extracted(tmp_path: Path):
    req_file = tmp_path / "requirements.txt"
    req_file.write_text("requests==2.31.0\nnumpy==1.26.0\n")
    result = parse_requirements_txt(req_file)
    assert ("requests", "2.31.0") in result
    assert ("numpy", "1.26.0") in result


def test_unpinned_version_becomes_latest(tmp_path: Path):
    req_file = tmp_path / "requirements.txt"
    req_file.write_text("flask\n")
    result = parse_requirements_txt(req_file)
    assert ("flask", "latest") in result


def test_comments_and_blank_lines_ignored(tmp_path: Path):
    req_file = tmp_path / "requirements.txt"
    req_file.write_text("# comment\n\nrequests==2.31.0\n")
    result = parse_requirements_txt(req_file)
    assert len(result) == 1
    assert result[0] == ("requests", "2.31.0")


def test_dash_r_directive_ignored(tmp_path: Path):
    req_file = tmp_path / "requirements.txt"
    req_file.write_text("-r base.txt\nrequests==2.31.0\n")
    result = parse_requirements_txt(req_file)
    assert len(result) == 1


def test_inline_comment_stripped(tmp_path: Path):
    req_file = tmp_path / "requirements.txt"
    req_file.write_text("requests==2.31.0  # via pip-tools\n")
    result = parse_requirements_txt(req_file)
    assert ("requests", "2.31.0") in result
