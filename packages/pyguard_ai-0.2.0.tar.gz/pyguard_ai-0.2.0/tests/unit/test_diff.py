"""Unit tests for the version diff analyzer."""
from __future__ import annotations

from pyguard.detectors.diff import analyze_diff
from pyguard.models import Severity


def test_new_binary_file_flagged():
    old: dict[str, str] = {"pyguard/__init__.py": "# old"}
    new: dict[str, str] = {**old, "pyguard/_ext.so": ""}
    findings = analyze_diff("pkg", "2.0.0", old, new)
    assert any("binary" in f.title.lower() for f in findings)
    assert any(f.severity == Severity.HIGH for f in findings)


def test_new_requests_import_flagged():
    old: dict[str, str] = {"pkg.py": "print('hello')"}
    new: dict[str, str] = {"pkg.py": "import requests\nprint('hello')"}
    findings = analyze_diff("pkg", "2.0.0", old, new)
    assert any("import" in f.title.lower() for f in findings)


def test_credential_path_in_diff_flagged():
    old: dict[str, str] = {"pkg.py": "x = 1"}
    new: dict[str, str] = {"pkg.py": "x = open('~/.ssh/id_rsa').read()"}
    findings = analyze_diff("pkg", "2.0.0", old, new)
    assert any("credential" in f.title.lower() for f in findings)


def test_setup_py_change_flagged():
    old: dict[str, str] = {"setup.py": "from setuptools import setup\nsetup(name='x')"}
    new: dict[str, str] = {"setup.py": "from setuptools import setup\nsetup(name='x', version='2')"}
    findings = analyze_diff("pkg", "2.0.0", old, new)
    assert any("build" in f.title.lower() or "install" in f.title.lower() for f in findings)


def test_identical_versions_no_findings():
    files: dict[str, str] = {"pkg.py": "print('hello')"}
    findings = analyze_diff("pkg", "1.0.0", files, files)
    assert findings == []
