from pathlib import Path

import pytest

from pyguard.scanner import Scanner
from pyguard.utils.config import ScanConfig


@pytest.mark.asyncio
async def test_scanner_runs_static_layer_on_local_path(tmp_path: Path) -> None:
    package_file = tmp_path / "setup.py"
    package_file.write_text(
        "import os\nprint(os.environ['SECRET'])\n",
        encoding="utf-8",
    )
    config = ScanConfig(target=str(tmp_path), source_root=tmp_path)
    result = await Scanner(config).scan()
    assert result.layers_run == ["static"]
    assert result.findings


@pytest.mark.asyncio
async def test_scanner_skips_virtualenv_contents(tmp_path: Path) -> None:
    venv_file = tmp_path / ".venv" / "lib" / "python3.14" / "site-packages" / "bad.py"
    venv_file.parent.mkdir(parents=True)
    venv_file.write_text("import subprocess\nsubprocess.run(['whoami'])\n", encoding="utf-8")

    package_file = tmp_path / "pkg.py"
    package_file.write_text("print('clean')\n", encoding="utf-8")

    config = ScanConfig(target=str(tmp_path), source_root=tmp_path)
    result = await Scanner(config).scan()

    assert all(
        finding.file != ".venv/lib/python3.14/site-packages/bad.py"
        for finding in result.findings
    )
