"""Unit tests for the custom rules engine (Visitor + Singleton patterns)."""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from pyguard.rules.engine import RuleRegistry, RuleVisitor, apply_regex_rules, run_rules
from pyguard.rules.schema import Rule
from pyguard.models import Severity


# Always reset the singleton between tests to avoid state bleed
@pytest.fixture(autouse=True)
def reset_registry():
    RuleRegistry.reset()
    yield
    RuleRegistry.reset()


# ---------------------------------------------------------------------------
# RuleRegistry (Singleton)
# ---------------------------------------------------------------------------

class TestRuleRegistry:
    def test_singleton_returns_same_instance(self) -> None:
        a = RuleRegistry.instance()
        b = RuleRegistry.instance()
        assert a is b

    def test_load_yaml_adds_rules(self, tmp_path: Path) -> None:
        yaml_content = """\
rules:
  - id: TEST-001
    name: Test exec rule
    severity: critical
    pattern_type: regex
    pattern: "exec\\\\("
    description: Detects exec calls
    category: execution
"""
        rules_file = tmp_path / "rules.yaml"
        rules_file.write_text(yaml_content, encoding="utf-8")

        registry = RuleRegistry.instance()
        registry.load_yaml(rules_file)
        assert len(registry.rules) == 1
        assert registry.rules[0].id == "TEST-001"

    def test_load_yaml_skips_disabled_rules(self, tmp_path: Path) -> None:
        yaml_content = """\
rules:
  - id: DISABLED-001
    name: Disabled rule
    severity: low
    pattern_type: regex
    pattern: "foo"
    description: Should be skipped
    category: general
    enabled: false
"""
        rules_file = tmp_path / "rules.yaml"
        rules_file.write_text(yaml_content, encoding="utf-8")
        registry = RuleRegistry.instance()
        registry.load_yaml(rules_file)
        assert registry.rules == []

    def test_clear_removes_all_rules(self, tmp_path: Path) -> None:
        registry = RuleRegistry.instance()
        registry._rules.append(
            Rule(id="X", name="x", pattern_type="regex", pattern="x", description="x")
        )
        registry.clear()
        assert registry.rules == []

    def test_load_default_rules(self) -> None:
        registry = RuleRegistry.instance()
        registry.load_default_rules()
        # default_rules.yaml has at least 10 rules
        assert len(registry.rules) >= 10


# ---------------------------------------------------------------------------
# apply_regex_rules
# ---------------------------------------------------------------------------

class TestApplyRegexRules:
    def _regex_rule(self, pattern: str, severity: str = "high") -> Rule:
        return Rule(
            id="R-001",
            name="Test regex",
            severity=severity,
            pattern_type="regex",
            pattern=pattern,
            description="Test",
            category="test",
        )

    def test_matches_pattern_in_source(self) -> None:
        rules = [self._regex_rule(r"exec\(")]
        findings = apply_regex_rules(rules, "evil.py", "exec('rm -rf /')")
        assert len(findings) == 1
        assert findings[0].line == 1

    def test_no_match_returns_empty(self) -> None:
        rules = [self._regex_rule(r"marshal\.loads")]
        findings = apply_regex_rules(rules, "clean.py", "print('hello')")
        assert findings == []

    def test_severity_mapped_correctly(self) -> None:
        rules = [self._regex_rule(r"eval\(", severity="critical")]
        findings = apply_regex_rules(rules, "f.py", "eval(x)")
        assert findings[0].severity == Severity.CRITICAL

    def test_invalid_regex_skipped_gracefully(self) -> None:
        rules = [self._regex_rule(r"[invalid")]  # bad regex
        findings = apply_regex_rules(rules, "f.py", "hello")
        assert findings == []


# ---------------------------------------------------------------------------
# RuleVisitor (Visitor pattern) — AST-based rules
# ---------------------------------------------------------------------------

class TestRuleVisitor:
    def _ast_call_rule(self, pattern: str) -> Rule:
        return Rule(
            id="AST-001",
            name="Dangerous call",
            severity="high",
            pattern_type="ast_call",
            pattern=pattern,
            description="Detects dangerous call",
            category="execution",
        )

    def _import_rule(self, pattern: str) -> Rule:
        return Rule(
            id="IMP-001",
            name="Dangerous import",
            severity="medium",
            pattern_type="import",
            pattern=pattern,
            description="Detects dangerous import",
            category="execution",
        )

    def test_ast_call_detects_os_system(self) -> None:
        source = "import os\nos.system('rm -rf /')"
        import ast
        tree = ast.parse(source)
        rule = self._ast_call_rule(r"^os\.system$")
        visitor = RuleVisitor([rule], "evil.py", source)
        visitor.visit(tree)
        assert len(visitor.findings) == 1
        assert visitor.findings[0].line == 2

    def test_import_rule_detects_ctypes(self) -> None:
        source = "import ctypes"
        import ast
        tree = ast.parse(source)
        rule = self._import_rule(r"^ctypes$")
        visitor = RuleVisitor([rule], "evil.py", source)
        visitor.visit(tree)
        assert len(visitor.findings) == 1

    def test_no_findings_on_clean_code(self) -> None:
        source = "def add(a, b):\n    return a + b\n"
        import ast
        tree = ast.parse(source)
        rules = [self._ast_call_rule(r"^os\.system$"), self._import_rule(r"^ctypes$")]
        visitor = RuleVisitor(rules, "clean.py", source)
        visitor.visit(tree)
        assert visitor.findings == []

    def test_includes_code_snippet_in_evidence(self) -> None:
        source = "import ctypes\n"
        import ast
        tree = ast.parse(source)
        rule = self._import_rule(r"^ctypes$")
        visitor = RuleVisitor([rule], "evil.py", source)
        visitor.visit(tree)
        assert "ctypes" in visitor.findings[0].evidence.get("code_snippet", "")


# ---------------------------------------------------------------------------
# run_rules — end-to-end
# ---------------------------------------------------------------------------

class TestRunRules:
    def test_stamps_package_info(self) -> None:
        rule = Rule(
            id="E2E-001",
            name="exec call",
            severity="critical",
            pattern_type="regex",
            pattern=r"exec\(",
            description="exec found",
            category="obfuscation",
        )
        findings = run_rules([rule], "setup.py", "exec(base64.b64decode(x))", "mypkg", "2.0.0")
        assert findings[0].package == "mypkg"
        assert findings[0].version == "2.0.0"

    def test_handles_syntax_error_gracefully(self) -> None:
        rule = Rule(
            id="SYN-001",
            name="ast rule",
            severity="high",
            pattern_type="ast_call",
            pattern=r"os\.system",
            description="test",
            category="test",
        )
        # Source with syntax error — AST rules should be skipped, no crash
        findings = run_rules([rule], "bad.py", "def (broken(:", "pkg", "1.0")
        assert isinstance(findings, list)
