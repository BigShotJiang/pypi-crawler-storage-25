"""Unit tests for Layer 4 — ReporterFactory, CompositeReporter, and new reporters."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from pyguard.models import Finding, PackageInfo, PackageMetadata, ScanResult, Severity
from pyguard.reporters import (
    CompositeReporter,
    GitHubActionsReporter,
    JSONReporter,
    PipAuditReporter,
    ReporterFactory,
    SarifReporter,
    SbomReporter,
)


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _make_result(severity: Severity = Severity.HIGH, layer: str = "static") -> ScanResult:
    pkg = PackageInfo(
        name="evil-pkg",
        version="1.2.3",
        source_path=Path("/tmp"),
        metadata=PackageMetadata(),
    )
    finding = Finding(
        severity=severity,
        title="Test finding",
        description="Something bad was detected.",
        layer=layer,
        package="evil-pkg",
        version="1.2.3",
        evidence={"snippet": "exec(base64...)"},
        confidence=0.92,
        file="setup.py",
        line=10,
        category="obfuscation",
    )
    return ScanResult(
        package=pkg,
        findings=[finding],
        risk_score=8.0,
        risk_label=severity,
        layers_run=[layer],
        scan_duration_ms=42,
    )


# ---------------------------------------------------------------------------
# ReporterFactory
# ---------------------------------------------------------------------------

class TestReporterFactory:
    def test_create_json_reporter(self) -> None:
        reporter = ReporterFactory.create("json")
        assert isinstance(reporter, JSONReporter)

    def test_create_sarif_reporter(self) -> None:
        reporter = ReporterFactory.create("sarif")
        assert isinstance(reporter, SarifReporter)

    def test_create_github_reporter(self) -> None:
        reporter = ReporterFactory.create("github")
        assert isinstance(reporter, GitHubActionsReporter)

    def test_create_pip_audit_reporter(self) -> None:
        reporter = ReporterFactory.create("pip-audit")
        assert isinstance(reporter, PipAuditReporter)

    def test_create_sbom_reporter(self) -> None:
        reporter = ReporterFactory.create("sbom")
        assert isinstance(reporter, SbomReporter)

    def test_unknown_reporter_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown reporter"):
            ReporterFactory.create("nonexistent-format")

    def test_create_composite_single(self) -> None:
        reporter = ReporterFactory.create_composite(["json"])
        assert isinstance(reporter, JSONReporter)

    def test_create_composite_multi(self) -> None:
        reporter = ReporterFactory.create_composite(["json", "sarif"])
        assert isinstance(reporter, CompositeReporter)


# ---------------------------------------------------------------------------
# CompositeReporter
# ---------------------------------------------------------------------------

class TestCompositeReporter:
    def test_fans_out_to_all_reporters(self) -> None:
        called: list[str] = []

        class FakeA(JSONReporter):
            def report(self, results, output=None):
                called.append("A")
                return "A"

        class FakeB(SarifReporter):
            def report(self, results, output=None):
                called.append("B")
                return "B"

        comp = CompositeReporter([FakeA(), FakeB()])
        comp.report([_make_result()])
        assert called == ["A", "B"]


# ---------------------------------------------------------------------------
# JSONReporter
# ---------------------------------------------------------------------------

class TestJSONReporter:
    def test_produces_valid_json(self) -> None:
        result = _make_result()
        reporter = JSONReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert isinstance(data, list)
        assert data[0]["package"]["name"] == "evil-pkg"
        assert len(data[0]["findings"]) == 1

    def test_writes_to_file(self, tmp_path: Path) -> None:
        result = _make_result()
        out = tmp_path / "report.json"
        reporter = JSONReporter()
        reporter.report([result], output=out)
        assert out.exists()
        data = json.loads(out.read_text())
        assert data[0]["package"]["version"] == "1.2.3"


# ---------------------------------------------------------------------------
# GitHubActionsReporter
# ---------------------------------------------------------------------------

class TestGitHubActionsReporter:
    def test_produces_error_annotation_for_critical(self) -> None:
        result = _make_result(Severity.CRITICAL)
        reporter = GitHubActionsReporter()
        text = reporter.report([result])
        assert "::error" in text
        assert "setup.py" in text
        assert "Test finding" in text

    def test_produces_warning_for_medium(self) -> None:
        result = _make_result(Severity.MEDIUM)
        reporter = GitHubActionsReporter()
        text = reporter.report([result])
        assert "::warning" in text

    def test_produces_notice_for_low(self) -> None:
        result = _make_result(Severity.LOW)
        reporter = GitHubActionsReporter()
        text = reporter.report([result])
        assert "::notice" in text

    def test_no_output_for_empty_results(self) -> None:
        pkg = PackageInfo(name="clean", version="1.0.0", source_path=Path("/tmp"), metadata=PackageMetadata())
        empty_result = ScanResult(
            package=pkg, findings=[], risk_score=0.0, risk_label=Severity.INFO,
            layers_run=["static"], scan_duration_ms=5
        )
        reporter = GitHubActionsReporter()
        text = reporter.report([empty_result])
        assert text.strip() == ""


# ---------------------------------------------------------------------------
# PipAuditReporter
# ---------------------------------------------------------------------------

class TestPipAuditReporter:
    def test_produces_pip_audit_schema(self) -> None:
        result = _make_result()
        reporter = PipAuditReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert isinstance(data, list)
        entry = data[0]
        assert entry["name"] == "evil-pkg"
        assert entry["version"] == "1.2.3"
        assert "vulns" in entry
        assert len(entry["vulns"]) == 1

    def test_skips_info_severity(self) -> None:
        result = _make_result(Severity.INFO)
        reporter = PipAuditReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert data[0]["vulns"] == []

    def test_vuln_has_id_and_description(self) -> None:
        result = _make_result(Severity.CRITICAL)
        reporter = PipAuditReporter()
        text = reporter.report([result])
        data = json.loads(text)
        vuln = data[0]["vulns"][0]
        assert "id" in vuln
        assert "description" in vuln


# ---------------------------------------------------------------------------
# SbomReporter
# ---------------------------------------------------------------------------

class TestSbomReporter:
    def test_produces_cyclonedx_structure(self) -> None:
        result = _make_result()
        reporter = SbomReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert data["bomFormat"] == "CycloneDX"
        assert data["specVersion"] == "1.4"
        assert len(data["components"]) == 1
        assert data["components"][0]["name"] == "evil-pkg"

    def test_has_purl(self) -> None:
        result = _make_result()
        reporter = SbomReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert "pkg:pypi/evil-pkg@1.2.3" in data["components"][0]["purl"]

    def test_vulnerability_embedded(self) -> None:
        result = _make_result(Severity.HIGH)
        reporter = SbomReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert len(data["vulnerabilities"]) == 1
        vuln = data["vulnerabilities"][0]
        assert vuln["ratings"][0]["severity"] == "high"

    def test_info_findings_excluded(self) -> None:
        result = _make_result(Severity.INFO)
        reporter = SbomReporter()
        text = reporter.report([result])
        data = json.loads(text)
        assert data["vulnerabilities"] == []
