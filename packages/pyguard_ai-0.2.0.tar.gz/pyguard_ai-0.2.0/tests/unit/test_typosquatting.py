from pyguard.detectors.typosquatting import find_typosquat_candidates, levenshtein_distance


def test_levenshtein_distance_detects_simple_edit() -> None:
    assert levenshtein_distance("requets", "requests") == 1


def test_find_typosquat_candidates_matches_popular_package() -> None:
    matches = find_typosquat_candidates("requets", {"requests", "numpy"})
    assert len(matches) == 1
    assert matches[0].target == "requests"

