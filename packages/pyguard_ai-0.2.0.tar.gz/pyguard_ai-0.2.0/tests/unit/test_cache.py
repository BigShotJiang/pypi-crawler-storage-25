"""Unit tests for the file cache."""
from __future__ import annotations

import time
from pathlib import Path

from pyguard.utils.cache import FileCache


def test_set_and_get(tmp_path: Path):
    cache = FileCache(tmp_path)
    cache.set("key1", {"data": 42})
    result = cache.get("key1")
    assert result == {"data": 42}


def test_expired_entry_returns_none(tmp_path: Path):
    cache = FileCache(tmp_path)
    cache.set("key_exp", "value", ttl_seconds=0)
    time.sleep(0.05)
    assert cache.get("key_exp") is None


def test_missing_key_returns_none(tmp_path: Path):
    cache = FileCache(tmp_path)
    assert cache.get("nonexistent") is None


def test_delete_removes_entry(tmp_path: Path):
    cache = FileCache(tmp_path)
    cache.set("delkey", "value")
    cache.delete("delkey")
    assert cache.get("delkey") is None


def test_clear_removes_all(tmp_path: Path):
    cache = FileCache(tmp_path)
    cache.set("a", 1)
    cache.set("b", 2)
    cache.clear()
    assert cache.get("a") is None
    assert cache.get("b") is None
