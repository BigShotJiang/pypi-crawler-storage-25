"""Fixture: obfuscated payload pattern (for testing only — never run this)."""
import base64

# Base64-encoded exec — classic obfuscation
exec(base64.b64decode("cHJpbnQoJ2hlbGxvJyk=").decode())

# Dynamic import
__import__("subprocess").run(["id"])
