"""Fixture: clean utility module — should produce zero findings."""


def add(a: int, b: int) -> int:
    return a + b


def greet(name: str) -> str:
    return f"Hello, {name}!"
