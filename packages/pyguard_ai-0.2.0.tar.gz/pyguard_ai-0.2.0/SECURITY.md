# Security Policy

## Reporting

Please report suspected vulnerabilities in `pyguard` privately to the maintainers before public disclosure.

Include:

- A clear description of the issue
- Reproduction steps or proof of concept
- Impact assessment
- Suggested remediation if available

## Scope

This project handles untrusted package metadata and source archives. Reports involving parser safety, sandbox isolation, credential leakage, and report integrity are high priority.

