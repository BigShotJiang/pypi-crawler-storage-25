FROM python:3.12-slim

# Install security analysis tools
RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        strace \
        tcpdump \
        iproute2 \
    && rm -rf /var/lib/apt/lists/*

# Create non-root sandbox user
RUN useradd -m -s /bin/sh -u 10000 pyguard

# Writable runtime directories (tmpfs-mounted at runtime)
RUN mkdir -p /tmp /monitor /home/pyguard && \
    chown pyguard:pyguard /monitor /home/pyguard

# Drop to non-root by default — override at container runtime when needed
USER pyguard

WORKDIR /home/pyguard

# Read-only root filesystem is enforced via --read-only docker flag;
# /tmp and /monitor must be mounted as tmpfs for writes.
# Example run command:
#   docker run --rm --read-only \
#     --tmpfs /tmp:rw,noexec,nosuid,size=64m \
#     --tmpfs /monitor:rw,noexec,nosuid,size=32m \
#     --security-opt no-new-privileges \
#     --cap-drop ALL \
#     --memory 256m \
#     --network none \
#     pyguard-sandbox \
#     sh -c "pip install --no-deps --quiet <package>==<version>"

LABEL org.opencontainers.image.title="pyguard-sandbox" \
      org.opencontainers.image.description="Isolated sandbox for PyPI package runtime analysis" \
      org.opencontainers.image.source="https://github.com/rajveer43/PyGaurd"
