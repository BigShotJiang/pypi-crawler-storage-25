import json
import os
import sys
import tempfile
from unittest.mock import patch, MagicMock

import pytest

from rlm_tools_bsl.server import (
    _rlm_start,
    _rlm_execute,
    _rlm_end,
    _format_helper_summary,
    _rlm_projects,
    _rlm_index,
    _resolve_path_map,
    rlm_index,
)
from rlm_tools_bsl.sandbox import HelperCall


# ---------------------------------------------------------------------------
# _format_helper_summary tests
# ---------------------------------------------------------------------------


def test_format_helper_summary_mixed():
    """Mixed case: one helper once, another 5 times, third below threshold."""
    calls = [
        HelperCall("find_module", 0.3),
        HelperCall("code_metrics", 0.1),
        HelperCall("code_metrics", 0.2),
        HelperCall("code_metrics", 0.15),
        HelperCall("code_metrics", 0.12),
        HelperCall("code_metrics", 0.13),
        HelperCall("glob_files", 0.02),  # below 0.1 threshold
    ]
    parts, count = _format_helper_summary(calls, threshold=0.1)
    assert count == 2  # find_module + code_metrics (glob_files excluded)
    assert "find_module(0.3s)" in parts
    assert "code_metrics(5\u00d7, total=0.7s)" in parts
    assert "glob_files" not in parts


def test_format_helper_summary_single_call():
    """Single call above threshold."""
    calls = [HelperCall("find_roles", 0.5)]
    parts, count = _format_helper_summary(calls, threshold=0.1)
    assert count == 1
    assert parts == "find_roles(0.5s)"


def test_format_helper_summary_all_below_threshold():
    """All calls below threshold — empty result."""
    calls = [HelperCall("glob_files", 0.01), HelperCall("help", 0.0)]
    parts, count = _format_helper_summary(calls, threshold=0.1)
    assert count == 0
    assert parts == ""


def test_format_helper_summary_threshold_zero():
    """With threshold=0.0 (log_all mode), all calls are included."""
    calls = [
        HelperCall("find_module", 0.3),
        HelperCall("glob_files", 0.0),
        HelperCall("glob_files", 0.0),
    ]
    parts, count = _format_helper_summary(calls, threshold=0.0)
    assert count == 2
    assert "find_module(0.3s)" in parts
    assert "glob_files(2\u00d7" in parts


# ---------------------------------------------------------------------------
# RLM flow tests
# ---------------------------------------------------------------------------


def test_full_rlm_flow():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "example.py"), "w") as f:
            f.write("def hello():\n    return 'world'\n\ndef foo():\n    return 'bar'\n")

        start_result = _rlm_start(path=tmpdir, query="find all functions")
        result_data = json.loads(start_result)
        session_id = result_data["session_id"]
        assert session_id is not None
        assert "metadata" in result_data

        exec_result = _rlm_execute(
            session_id=session_id, code="files = glob_files('**/*.py')\nprint(f'Found {len(files)} Python files')"
        )
        exec_data = json.loads(exec_result)
        assert "Found 1 Python files" in exec_data["stdout"]

        exec_result2 = _rlm_execute(session_id=session_id, code="print(files)")
        exec_data2 = json.loads(exec_result2)
        assert "example.py" in exec_data2["stdout"]

        end_result = _rlm_end(session_id=session_id)
        end_data = json.loads(end_result)
        assert end_data["success"] is True


def test_invalid_session():
    result = _rlm_execute(session_id="nonexistent", code="print('hi')")
    data = json.loads(result)
    assert "error" in data


def test_invalid_directory():
    result = _rlm_start(path="/nonexistent/path", query="test")
    data = json.loads(result)
    assert "error" in data


def test_resolve_mapped_drive_returns_unc():
    from rlm_tools_bsl.server import _resolve_mapped_drive

    if sys.platform != "win32":
        assert _resolve_mapped_drive("U:\\some\\path") is None
        return

    import winreg

    fake_sids = ["S-1-5-21-fake"]

    def fake_enum_key(hkey, index):
        if index < len(fake_sids):
            return fake_sids[index]
        raise OSError

    fake_key = MagicMock()

    def fake_open_key(hkey, sub_key):
        if sub_key == "S-1-5-21-fake\\Network\\U":
            cm = MagicMock()
            cm.__enter__ = MagicMock(return_value=fake_key)
            cm.__exit__ = MagicMock(return_value=False)
            return cm
        raise OSError

    def fake_query(key, name):
        if key is fake_key and name == "RemotePath":
            return ("\\\\server\\share", winreg.REG_SZ)
        raise OSError

    with (
        patch.object(winreg, "EnumKey", side_effect=fake_enum_key),
        patch.object(winreg, "OpenKey", side_effect=fake_open_key),
        patch.object(winreg, "QueryValueEx", side_effect=fake_query),
    ):
        result = _resolve_mapped_drive("U:\\ERP\\mainconf")
        assert result == "\\\\server\\share\\ERP\\mainconf"


def test_resolve_mapped_drive_no_mapping():
    from rlm_tools_bsl.server import _resolve_mapped_drive

    if sys.platform != "win32":
        return

    import winreg

    def fake_enum_key(hkey, index):
        raise OSError  # no SIDs

    with patch.object(winreg, "EnumKey", side_effect=fake_enum_key):
        result = _resolve_mapped_drive("Z:\\nonexistent")
        assert result is None


def test_resolve_mapped_drive_not_windows():
    from rlm_tools_bsl.server import _resolve_mapped_drive

    with patch("rlm_tools_bsl.server.os.name", "posix"):
        assert _resolve_mapped_drive("U:\\some\\path") is None


def test_invalid_directory_hint_inaccessible_drive():
    """Error should include UNC hint when drive root is inaccessible."""
    result = _rlm_start(path="Z:\\nonexistent\\path", query="test")
    data = json.loads(result)
    assert "error" in data
    if sys.platform == "win32" and not os.path.isdir("Z:\\"):
        assert "UNC" in data["error"] or "drive Z:" in data["error"]


def test_metadata_includes_file_types():
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()
        open(os.path.join(tmpdir, "b.py"), "w").close()
        open(os.path.join(tmpdir, "c.txt"), "w").close()

        result = _rlm_start(path=tmpdir, query="test", include_metadata=True)
        data = json.loads(result)
        assert data["metadata"]["total_files"] == 3
        assert ".py" in data["metadata"]["file_types"]

        _rlm_end(data["session_id"])


def test_read_file_in_sandbox():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "data.txt"), "w") as f:
            f.write("important data")

        result = _rlm_start(path=tmpdir, query="read file")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(session_id=session_id, code="content = read_file('data.txt')\nprint(content)")
        exec_data = json.loads(exec_result)
        assert "important data" in exec_data["stdout"]
        assert exec_data["error"] is None

        _rlm_end(session_id)


def test_grep_in_sandbox():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "code.py"), "w") as f:
            f.write("class MyController:\n    def handle_error(self):\n        pass\n")

        result = _rlm_start(path=tmpdir, query="find controllers")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(
            session_id=session_id, code="results = grep('class.*Controller')\nprint(len(results))"
        )
        exec_data = json.loads(exec_result)
        assert "1" in exec_data["stdout"]

        _rlm_end(session_id)


def test_skip_metadata_scan():
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()

        result = _rlm_start(path=tmpdir, query="test", include_metadata=False)
        data = json.loads(result)
        assert data["metadata"] == {}
        assert "session_id" in data

        _rlm_end(data["session_id"])


def test_new_helpers_in_sandbox():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "a.txt"), "w") as f:
            f.write("hello from a")
        with open(os.path.join(tmpdir, "b.txt"), "w") as f:
            f.write("hello from b")

        result = _rlm_start(path=tmpdir, query="test helpers")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(
            session_id=session_id,
            code="result = read_files(['a.txt', 'b.txt'])\nfor k, v in sorted(result.items()):\n    print(f'{k}: {v}')",
        )
        exec_data = json.loads(exec_result)
        assert "a.txt: 1 | hello from a" in exec_data["stdout"]
        assert "b.txt: 1 | hello from b" in exec_data["stdout"]

        exec_result2 = _rlm_execute(session_id=session_id, code="print(grep_summary('hello'))")
        exec_data2 = json.loads(exec_result2)
        assert "2 matches" in exec_data2["stdout"]

        exec_result3 = _rlm_execute(session_id=session_id, code="result = grep_read('hello')\nprint(result['summary'])")
        exec_data3 = json.loads(exec_result3)
        assert "2 matches" in exec_data3["stdout"]

        _rlm_end(session_id)


def test_new_defaults():
    """Default effort=medium -> 25 execute calls, 15 llm calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()

        result = _rlm_start(path=tmpdir, query="test defaults")
        data = json.loads(result)
        assert data["limits"]["max_execute_calls"] == 25  # medium effort
        assert data["limits"]["max_llm_calls"] == 15  # medium effort
        assert data["limits"]["execution_timeout_seconds"] == 45

        _rlm_end(data["session_id"])


def test_full_detail_excludes_helper_functions_from_variables():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "a.txt"), "w") as f:
            f.write("hello")

        start = json.loads(_rlm_start(path=tmpdir, query="detail vars"))
        session_id = start["session_id"]

        result = json.loads(
            _rlm_execute(
                session_id=session_id,
                code="x = 123",
                detail_level="full",
            )
        )

        assert "x" in result["variables"]
        assert "read_files" not in result["variables"]
        assert "grep_summary" not in result["variables"]
        assert "grep_read" not in result["variables"]
        assert "find_module" not in result["variables"]
        assert "find_by_type" not in result["variables"]
        assert "extract_procedures" not in result["variables"]
        assert "safe_grep" not in result["variables"]
        assert "find_files" not in result["variables"]

        _rlm_end(session_id)


def test_extension_context_main_with_nearby_extension():
    """rlm_start returns extension_context with nearby extensions for main config."""
    import textwrap

    with tempfile.TemporaryDirectory() as parent:
        main_dir = os.path.join(parent, "main")
        ext_dir = os.path.join(parent, "ext")
        os.makedirs(main_dir)
        os.makedirs(ext_dir)

        # Main config
        with open(os.path.join(main_dir, "Configuration.xml"), "w", encoding="utf-8") as f:
            f.write(
                textwrap.dedent("""\
                <?xml version="1.0" encoding="UTF-8"?>
                <MetaDataObject xmlns="http://v8.1c.ru/8.3/MDClasses">
                    <Configuration uuid="00000000-0000-0000-0000-000000000001">
                        <Properties>
                            <Name>Основная</Name>
                            <NamePrefix/>
                        </Properties>
                    </Configuration>
                </MetaDataObject>
            """)
            )

        # Extension
        with open(os.path.join(ext_dir, "Configuration.xml"), "w", encoding="utf-8") as f:
            f.write(
                textwrap.dedent("""\
                <?xml version="1.0" encoding="UTF-8"?>
                <MetaDataObject xmlns="http://v8.1c.ru/8.3/MDClasses">
                    <Configuration uuid="00000000-0000-0000-0000-000000000002">
                        <Properties>
                            <ObjectBelonging>Adopted</ObjectBelonging>
                            <Name>ТестРасш</Name>
                            <ConfigurationExtensionPurpose>AddOn</ConfigurationExtensionPurpose>
                            <NamePrefix>мр_</NamePrefix>
                        </Properties>
                    </Configuration>
                </MetaDataObject>
            """)
            )

        result = _rlm_start(path=main_dir, query="test ext context")
        data = json.loads(result)

        assert "extension_context" in data
        ec = data["extension_context"]
        assert ec["is_extension"] is False
        assert ec["config_role"] == "main"
        assert len(ec["nearby_extensions"]) == 1
        assert ec["nearby_extensions"][0]["name"] == "ТестРасш"
        assert ec["nearby_extensions"][0]["purpose"] == "AddOn"
        # warnings are at top level, not inside extension_context
        assert len(data["warnings"]) > 0

        _rlm_end(data["session_id"])


def test_extension_context_for_extension():
    """rlm_start for extension shows is_extension=True."""
    import textwrap

    with tempfile.TemporaryDirectory() as parent:
        ext_dir = os.path.join(parent, "myext")
        os.makedirs(ext_dir)

        with open(os.path.join(ext_dir, "Configuration.xml"), "w", encoding="utf-8") as f:
            f.write(
                textwrap.dedent("""\
                <?xml version="1.0" encoding="UTF-8"?>
                <MetaDataObject xmlns="http://v8.1c.ru/8.3/MDClasses">
                    <Configuration uuid="00000000-0000-0000-0000-000000000003">
                        <Properties>
                            <ObjectBelonging>Adopted</ObjectBelonging>
                            <Name>Расширение1</Name>
                            <ConfigurationExtensionPurpose>Customization</ConfigurationExtensionPurpose>
                            <NamePrefix>р1_</NamePrefix>
                        </Properties>
                    </Configuration>
                </MetaDataObject>
            """)
            )

        result = _rlm_start(path=ext_dir, query="test ext")
        data = json.loads(result)

        ec = data["extension_context"]
        assert ec["is_extension"] is True
        assert ec["config_role"] == "extension"
        assert ec["current_name"] == "Расширение1"
        assert ec["current_purpose"] == "Customization"
        assert ec["current_prefix"] == "р1_"

        _rlm_end(data["session_id"])


def test_config_format_returned():
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "script.bsl"), "w").close()

        result = _rlm_start(path=tmpdir, query="test format")
        data = json.loads(result)
        assert "config_format" in data
        assert data["config_format"] in ("cf", "edt", "unknown")

        _rlm_end(data["session_id"])


def test_strategy_always_returned():
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.bsl"), "w").close()

        result = _rlm_start(path=tmpdir, query="test strategy")
        data = json.loads(result)
        assert "strategy" in data
        assert "find_module" in data["strategy"]
        assert "CRITICAL" in data["strategy"]

        _rlm_end(data["session_id"])


def test_effort_levels():
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()

        for effort, expected_exec in [("low", 10), ("medium", 25), ("high", 50), ("max", 100)]:
            result = _rlm_start(path=tmpdir, query="test effort", effort=effort)
            data = json.loads(result)
            assert data["limits"]["max_execute_calls"] == expected_exec, f"effort={effort}"
            _rlm_end(data["session_id"])


def test_bsl_helpers_in_sandbox():
    """BSL helpers should be available in sandbox when format_info is provided."""
    with tempfile.TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, "CommonModules", "TestModule", "Ext"))
        with open(os.path.join(tmpdir, "CommonModules", "TestModule", "Ext", "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Тест() Экспорт\nКонецПроцедуры\n")
        with open(os.path.join(tmpdir, "Configuration.xml"), "w") as f:
            f.write("<Configuration/>")

        start = json.loads(_rlm_start(path=tmpdir, query="test bsl helpers"))
        session_id = start["session_id"]
        assert start["config_format"] == "cf"

        # Test find_module
        result = json.loads(
            _rlm_execute(session_id=session_id, code="modules = find_module('TestModule')\nprint(len(modules))")
        )
        assert "1" in result["stdout"]
        assert result["error"] is None

        # Test extract_procedures
        result2 = json.loads(
            _rlm_execute(
                session_id=session_id, code="procs = extract_procedures(modules[0]['path'])\nprint(procs[0]['name'])"
            )
        )
        assert "Тест" in result2["stdout"]

        _rlm_end(session_id)


def test_override_effort_limits():
    """Manual max_llm_calls and max_execute_calls override effort defaults."""
    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()

        result = _rlm_start(
            path=tmpdir,
            query="test override",
            effort="low",
            max_execute_calls=99,
            max_llm_calls=77,
        )
        data = json.loads(result)
        assert data["limits"]["max_execute_calls"] == 99
        assert data["limits"]["max_llm_calls"] == 77

        _rlm_end(data["session_id"])


# ---------------------------------------------------------------------------
# Transport / main() tests
# ---------------------------------------------------------------------------


def test_main_default_stdio():
    """main() without args calls mcp.run(transport='stdio')."""
    from rlm_tools_bsl import server

    with patch.object(server.mcp, "run") as mock_run, patch.object(sys, "argv", ["rlm-tools-bsl"]):
        server.main()
        mock_run.assert_called_once_with(transport="stdio")


def test_main_streamable_http_arg():
    """--transport streamable-http sets transport and updates settings."""
    from rlm_tools_bsl import server

    original_host = server.mcp.settings.host
    original_port = server.mcp.settings.port
    try:
        with (
            patch.object(server.mcp, "run") as mock_run,
            patch.object(sys, "argv", ["rlm-tools-bsl", "--transport", "streamable-http"]),
        ):
            server.main()
            mock_run.assert_called_once_with(transport="streamable-http")
            assert server.mcp.settings.host == "127.0.0.1"
            assert server.mcp.settings.port == 9000
    finally:
        server.mcp.settings.host = original_host
        server.mcp.settings.port = original_port


def test_main_custom_port():
    """--port overrides default port in mcp.settings."""
    from rlm_tools_bsl import server

    original_port = server.mcp.settings.port
    try:
        with (
            patch.object(server.mcp, "run") as mock_run,
            patch.object(sys, "argv", ["rlm-tools-bsl", "--transport", "streamable-http", "--port", "3000"]),
        ):
            server.main()
            mock_run.assert_called_once_with(transport="streamable-http")
            assert server.mcp.settings.port == 3000
    finally:
        server.mcp.settings.port = original_port


def test_main_env_transport():
    """RLM_TRANSPORT env var is used as fallback when no CLI arg given."""
    from rlm_tools_bsl import server

    original_host = server.mcp.settings.host
    original_port = server.mcp.settings.port
    try:
        with (
            patch.object(server.mcp, "run") as mock_run,
            patch.object(sys, "argv", ["rlm-tools-bsl"]),
            patch.dict(os.environ, {"RLM_TRANSPORT": "streamable-http"}),
        ):
            server.main()
            mock_run.assert_called_once_with(transport="streamable-http")
    finally:
        server.mcp.settings.host = original_host
        server.mcp.settings.port = original_port


def test_main_stdio_does_not_change_settings():
    """When transport is stdio, mcp.settings.host/port are NOT modified."""
    from rlm_tools_bsl import server

    original_host = server.mcp.settings.host
    original_port = server.mcp.settings.port
    try:
        with patch.object(server.mcp, "run") as mock_run, patch.object(sys, "argv", ["rlm-tools-bsl"]):
            server.main()
            mock_run.assert_called_once_with(transport="stdio")
            assert server.mcp.settings.host == original_host
            assert server.mcp.settings.port == original_port
    finally:
        server.mcp.settings.host = original_host
        server.mcp.settings.port = original_port


def test_sandboxes_concurrent_access():
    """Concurrent create/end must not crash with _sandboxes_lock."""
    import threading

    with tempfile.TemporaryDirectory() as tmpdir:
        open(os.path.join(tmpdir, "a.py"), "w").close()

        errors = []

        def create_and_end():
            try:
                result = _rlm_start(path=tmpdir, query="concurrent test")
                data = json.loads(result)
                sid = data["session_id"]
                _rlm_execute(session_id=sid, code="print(1+1)")
                _rlm_end(session_id=sid)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=create_and_end) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        assert not errors, f"Concurrent access errors: {errors}"


# ---------------------------------------------------------------------------
# Project registry integration tests
# ---------------------------------------------------------------------------


def test_rlm_projects_list_empty():
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            result = json.loads(_rlm_projects(action="list"))
            assert result["projects"] == []


def test_rlm_projects_add_remove_rename_update():
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            # add
            r = json.loads(_rlm_projects(action="add", name="Test", path=src, description="Desc"))
            assert "added" in r
            assert r["added"]["name"] == "Test"
            # list
            r = json.loads(_rlm_projects(action="list"))
            assert len(r["projects"]) == 1
            # rename
            r = json.loads(_rlm_projects(action="rename", name="Test", new_name="Test2"))
            assert r["renamed"]["name"] == "Test2"
            # update
            r = json.loads(_rlm_projects(action="update", name="Test2", description="Updated"))
            assert r["updated"]["description"] == "Updated"
            # remove
            r = json.loads(_rlm_projects(action="remove", name="Test2"))
            assert r["removed"]["name"] == "Test2"
            r = json.loads(_rlm_projects(action="list"))
            assert r["projects"] == []


def test_rlm_projects_validation_errors():
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            # add without name
            r = json.loads(_rlm_projects(action="add", path="/tmp"))
            assert "error" in r
            # add without path
            r = json.loads(_rlm_projects(action="add", name="X"))
            assert "error" in r
            # remove nonexistent
            r = json.loads(_rlm_projects(action="remove", name="Ghost"))
            assert "error" in r


def test_rlm_start_with_project():
    """rlm_start resolves project name from the registry."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        open(os.path.join(src, "a.py"), "w").close()
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="MyProject", path=src)
            result = json.loads(_rlm_start(path=None, query="test", project="MyProject"))
            assert "session_id" in result
            assert "error" not in result
            _rlm_end(result["session_id"])


def test_rlm_start_project_not_found():
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            result = json.loads(_rlm_start(path=None, query="test", project="NoSuch"))
            assert "error" in result
            assert "not found" in result["error"].lower()
            assert "available_projects" in result


def test_rlm_start_project_ambiguous():
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        s1 = os.path.join(tmpdir, "s1")
        s2 = os.path.join(tmpdir, "s2")
        os.makedirs(s1)
        os.makedirs(s2)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="Config Alpha", path=s1)
            _rlm_projects(action="add", name="Config Beta", path=s2)
            result = json.loads(_rlm_start(path=None, query="test", project="Config"))
            assert "error" in result
            assert "ambiguous" in result["error"].lower()
            assert "matches" in result


def test_rlm_start_project_fuzzy():
    """Fuzzy match returns 'Did you mean?' error, not a session."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="Main Config", path=src)
            result = json.loads(_rlm_start(path=None, query="test", project="Main Confgi"))
            assert "error" in result
            assert "did you mean" in result["error"].lower()


def test_rlm_start_project_corrupted_registry():
    """rlm_start with project= and corrupted registry returns clear error."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        # Write invalid JSON to projects.json
        proj_file = os.path.join(tmpdir, "projects.json")
        with open(proj_file, "w", encoding="utf-8") as f:
            f.write("{bad json")
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            result = json.loads(_rlm_start(path=None, query="test", project="Any"))
            assert "error" in result
            assert "corrupted" in result["error"].lower()


def test_rlm_start_project_invalid_structure():
    """rlm_start with project= and structurally invalid registry."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        proj_file = os.path.join(tmpdir, "projects.json")
        with open(proj_file, "w", encoding="utf-8") as f:
            f.write("[]")
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            result = json.loads(_rlm_start(path=None, query="test", project="Any"))
            assert "error" in result
            assert "corrupted" in result["error"].lower()


def test_rlm_start_neither_path_nor_project():
    result = json.loads(_rlm_start(path=None, query="test", project=None))
    assert "error" in result
    assert "either" in result["error"].lower()


def test_rlm_start_path_project_hint():
    """Unregistered path returns project_hint in the response."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        open(os.path.join(tmpdir, "a.py"), "w").close()
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            result = json.loads(_rlm_start(path=tmpdir, query="test"))
            assert "session_id" in result
            assert "project_hint" in result
            _rlm_end(result["session_id"])


def test_sandbox_read_file_numbered():
    """read_file in MCP sandbox returns numbered lines."""
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "test.txt"), "w") as f:
            f.write("alpha\nbeta\ngamma")

        result = _rlm_start(path=tmpdir, query="test numbered")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(session_id=session_id, code="print(read_file('test.txt'))")
        exec_data = json.loads(exec_result)
        assert "1 | alpha" in exec_data["stdout"]
        assert "2 | beta" in exec_data["stdout"]
        assert "3 | gamma" in exec_data["stdout"]

        _rlm_end(session_id)


def test_sandbox_read_files_numbered():
    """read_files in MCP sandbox returns numbered lines."""
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "x.txt"), "w") as f:
            f.write("line1\nline2")

        result = _rlm_start(path=tmpdir, query="test numbered files")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(
            session_id=session_id,
            code="r = read_files(['x.txt'])\nprint(r['x.txt'])",
        )
        exec_data = json.loads(exec_result)
        assert "1 | line1" in exec_data["stdout"]
        assert "2 | line2" in exec_data["stdout"]

        _rlm_end(session_id)


def test_sandbox_grep_read_numbered():
    """grep_read with context_lines=0 returns numbered file contents."""
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "code.txt"), "w") as f:
            f.write("function test()\n  return true\nend")

        result = _rlm_start(path=tmpdir, query="test grep numbered")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(
            session_id=session_id,
            code="r = grep_read('test', 'code.txt')\nprint(r['files']['code.txt'])",
        )
        exec_data = json.loads(exec_result)
        assert "1 | " in exec_data["stdout"]
        assert "2 | " in exec_data["stdout"]

        _rlm_end(session_id)


def test_sandbox_grep_read_context_unchanged():
    """grep_read with context_lines>0 keeps L42: format (not numbered)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "code.txt"), "w") as f:
            f.write("line1\nline2\ntarget\nline4\nline5")

        result = _rlm_start(path=tmpdir, query="test grep context")
        data = json.loads(result)
        session_id = data["session_id"]

        exec_result = _rlm_execute(
            session_id=session_id,
            code="r = grep_read('target', 'code.txt', context_lines=1)\nprint(r['files']['code.txt'])",
        )
        exec_data = json.loads(exec_result)
        # context_lines>0 should use L-prefix format, not pipe format
        assert "L2:" in exec_data["stdout"] or "L3:" in exec_data["stdout"]
        assert " | " not in exec_data["stdout"]

        _rlm_end(session_id)


def test_read_procedure_numbered_param():
    """read_procedure with numbered=True returns numbered lines, default returns raw."""
    from rlm_tools_bsl.bsl_helpers import make_bsl_helpers

    with tempfile.TemporaryDirectory() as tmpdir:
        bsl_path = os.path.join(tmpdir, "Module.bsl")
        with open(bsl_path, "w", encoding="utf-8") as f:
            f.write("// header\nПроцедура Тест()\n  Возврат;\nКонецПроцедуры\n")

        def _read(p):
            with open(os.path.join(tmpdir, p), encoding="utf-8-sig", errors="replace") as fh:
                return fh.read()

        helpers = make_bsl_helpers(
            base_path=tmpdir,
            resolve_safe=lambda p: os.path.join(tmpdir, p),
            read_file_fn=_read,
            grep_fn=lambda *a, **kw: [],
            glob_files_fn=lambda *a, **kw: [],
            format_info=None,
        )
        rp = helpers["read_procedure"]

        raw = rp("Module.bsl", "Тест")
        assert raw is not None
        assert " | " not in raw
        assert raw.startswith("Процедура Тест()")

        numbered = rp("Module.bsl", "Тест", numbered=True)
        assert numbered is not None
        assert "2 | Процедура Тест()" in numbered
        assert "3 |   Возврат;" in numbered


def test_read_procedure_numbered_absolute():
    """read_procedure numbered=True starts numbering at the actual line in file."""
    from rlm_tools_bsl.bsl_helpers import make_bsl_helpers

    with tempfile.TemporaryDirectory() as tmpdir:
        bsl_path = os.path.join(tmpdir, "Module.bsl")
        # Procedure starts at line 5
        lines = [
            "// line 1",
            "// line 2",
            "// line 3",
            "// line 4",
            "Процедура Пятая()",
            "  Возврат;",
            "КонецПроцедуры",
        ]
        with open(bsl_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

        def _read(p):
            with open(os.path.join(tmpdir, p), encoding="utf-8-sig", errors="replace") as fh:
                return fh.read()

        helpers = make_bsl_helpers(
            base_path=tmpdir,
            resolve_safe=lambda p: os.path.join(tmpdir, p),
            read_file_fn=_read,
            grep_fn=lambda *a, **kw: [],
            glob_files_fn=lambda *a, **kw: [],
            format_info=None,
        )
        rp = helpers["read_procedure"]

        numbered = rp("Module.bsl", "Пятая", numbered=True)
        assert numbered is not None
        assert "5 | Процедура Пятая()" in numbered
        assert "6 |   Возврат;" in numbered
        assert "7 | КонецПроцедуры" in numbered


def test_streamable_http_server_starts():
    """Integration: streamable-http server starts and responds to MCP initialize."""
    import socket
    import subprocess
    import time

    # Find a free port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    proc = subprocess.Popen(
        [sys.executable, "-m", "rlm_tools_bsl", "--transport", "streamable-http", "--port", str(port)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    try:
        # Wait for server to start
        import httpx

        client = httpx.Client()
        mcp_url = f"http://127.0.0.1:{port}/mcp"
        initialize_request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-03-26",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "0.1.0"},
            },
            "id": 1,
        }

        # Retry a few times while server starts up
        response = None
        for _ in range(20):
            try:
                response = client.post(
                    mcp_url,
                    json=initialize_request,
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "application/json, text/event-stream",
                    },
                    timeout=2,
                )
                break
            except httpx.ConnectError:
                time.sleep(0.5)

        assert response is not None, "Server did not start in time"
        assert response.status_code == 200
        assert len(response.content) > 0
    finally:
        proc.terminate()
        proc.wait(timeout=5)


# ---------------------------------------------------------------------------
# rlm_index integration tests
# ---------------------------------------------------------------------------


def test_rlm_index_requires_path_or_project():
    r = json.loads(_rlm_index(action="build"))
    assert "error" in r
    assert "path" in r["error"].lower() or "project" in r["error"].lower()


def test_rlm_index_path_not_found():
    r = json.loads(_rlm_index(action="build", path="/nonexistent/path/xyz"))
    assert "error" in r


def test_rlm_index_build_and_info_and_drop():
    """Full lifecycle: build → info → drop."""
    with tempfile.TemporaryDirectory() as tmpdir:
        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Тест()\nКонецПроцедуры\n")

        with patch.dict(os.environ, {"RLM_INDEX_DIR": idx_dir}):
            # build
            r = json.loads(_rlm_index(action="build", path=src))
            assert r["action"] == "build"
            assert "db_path" in r
            assert r["elapsed_seconds"] >= 0

            # info
            r = json.loads(_rlm_index(action="info", path=src))
            assert r["action"] == "info"
            assert "modules" in r
            assert "methods" in r

            # drop
            r = json.loads(_rlm_index(action="drop", path=src))
            assert r["action"] == "drop"
            assert "dropped" in r

            # info after drop → error
            r = json.loads(_rlm_index(action="info", path=src))
            assert "error" in r
            assert "not found" in r["error"].lower()


def test_rlm_index_drop_nonexistent():
    with tempfile.TemporaryDirectory() as tmpdir:
        r = json.loads(_rlm_index(action="drop", path=tmpdir))
        assert "error" in r
        assert "not found" in r["error"].lower()


def test_rlm_index_update_no_index():
    """Update without prior build → FileNotFoundError."""
    with tempfile.TemporaryDirectory() as tmpdir:
        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with patch.dict(os.environ, {"RLM_INDEX_DIR": idx_dir}):
            r = json.loads(_rlm_index(action="update", path=src))
            assert "error" in r


def test_rlm_index_build_and_update():
    """Build then update → returns delta counts."""
    with tempfile.TemporaryDirectory() as tmpdir:
        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Один()\nКонецПроцедуры\n")

        with patch.dict(os.environ, {"RLM_INDEX_DIR": idx_dir}):
            _rlm_index(action="build", path=src)

            # update with no changes
            r = json.loads(_rlm_index(action="update", path=src))
            assert r["action"] == "update"
            assert r["added"] == 0
            assert r["changed"] == 0
            assert r["removed"] == 0

            # cleanup
            _rlm_index(action="drop", path=src)


def test_rlm_index_with_project():
    """rlm_index resolves project name from the registry."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Два()\nКонецПроцедуры\n")

        _reset_registry()
        with patch.dict(
            os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json"), "RLM_INDEX_DIR": idx_dir}
        ):
            _reset_registry()
            _rlm_projects(action="add", name="IdxTest", path=src)

            # build by project name
            r = json.loads(_rlm_index(action="build", project="IdxTest"))
            assert r["action"] == "build"
            assert r["project"] == "IdxTest"

            # info by project name
            r = json.loads(_rlm_index(action="info", project="IdxTest"))
            assert r["action"] == "info"
            assert r["project"] == "IdxTest"

            # drop by project name
            r = json.loads(_rlm_index(action="drop", project="IdxTest"))
            assert r["action"] == "drop"
            assert r["project"] == "IdxTest"


def test_rlm_index_unknown_action():
    with tempfile.TemporaryDirectory() as tmpdir:
        r = json.loads(_rlm_index(action="unknown", path=tmpdir))
        assert "error" in r


def test_rlm_index_build_options():
    """Build with all skip flags."""
    with tempfile.TemporaryDirectory() as tmpdir:
        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Три()\nКонецПроцедуры\n")

        with patch.dict(os.environ, {"RLM_INDEX_DIR": idx_dir}):
            r = json.loads(
                _rlm_index(
                    action="build",
                    path=src,
                    no_calls=True,
                    no_metadata=True,
                    no_fts=True,
                    no_synonyms=True,
                )
            )
            assert r["action"] == "build"
            assert "db_path" in r
            assert r["db_path"].startswith(idx_dir)

            # cleanup
            _rlm_index(action="drop", path=src)


# ---------------------------------------------------------------------------
# rlm_index confirm flow tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_rlm_index_build_requires_project_not_path():
    """build with path (no project) → error."""
    result = json.loads(await rlm_index(action="build", path="/some/path"))
    assert "error" in result
    assert "requires a registered project" in result["error"]


@pytest.mark.asyncio
async def test_rlm_index_build_path_and_project_rejected():
    """build with path + project → error (path is forbidden for admin actions)."""
    result = json.loads(await rlm_index(action="build", path="/some/path", project="Test"))
    assert "error" in result
    assert "requires a registered project" in result["error"]


@pytest.mark.asyncio
async def test_rlm_index_build_no_password_configured():
    """Project without password → error with instruction to set password."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="NoPwd", path=src)
            result = json.loads(await rlm_index(action="build", project="NoPwd"))
            assert "error" in result
            assert "no password configured" in result["error"]


@pytest.mark.asyncio
async def test_rlm_index_build_no_confirm():
    """Project with password, no confirm → approval_required."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="WithPwd", path=src, password="secret")
            result = json.loads(await rlm_index(action="build", project="WithPwd"))
            assert result["approval_required"] is True
            assert result["action"] == "build"
            assert result["project"] == "WithPwd"
            assert "message" in result


@pytest.mark.asyncio
async def test_rlm_index_build_wrong_confirm():
    """Project with password, wrong confirm → approval_required (same form)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="WithPwd", path=src, password="secret")
            result = json.loads(await rlm_index(action="build", project="WithPwd", confirm="wrong"))
            assert result["approval_required"] is True


@pytest.mark.asyncio
async def test_rlm_index_build_correct_confirm():
    """Project with password, correct confirm → build executes."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Тест()\nКонецПроцедуры\n")

        _reset_registry()
        with patch.dict(
            os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json"), "RLM_INDEX_DIR": idx_dir}
        ):
            _reset_registry()
            _rlm_projects(action="add", name="WithPwd", path=src, password="secret")
            r = json.loads(await rlm_index(action="build", project="WithPwd", confirm="secret"))
            assert r["action"] == "build"
            assert "db_path" in r
            # cleanup
            _rlm_index(action="drop", path=src)


@pytest.mark.asyncio
async def test_rlm_index_drop_correct_confirm():
    """drop with correct password → executes."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Тест()\nКонецПроцедуры\n")

        _reset_registry()
        with patch.dict(
            os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json"), "RLM_INDEX_DIR": idx_dir}
        ):
            _reset_registry()
            _rlm_projects(action="add", name="WithPwd", path=src, password="secret")
            # Build first
            await rlm_index(action="build", project="WithPwd", confirm="secret")
            # Drop
            r = json.loads(await rlm_index(action="drop", project="WithPwd", confirm="secret"))
            assert r["action"] == "drop"


@pytest.mark.asyncio
async def test_rlm_index_update_correct_confirm():
    """update with correct password → executes."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        idx_dir = os.path.join(tmpdir, "indexes")
        os.makedirs(src)
        with open(os.path.join(src, "Module.bsl"), "w", encoding="utf-8") as f:
            f.write("Процедура Тест()\nКонецПроцедуры\n")

        _reset_registry()
        with patch.dict(
            os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json"), "RLM_INDEX_DIR": idx_dir}
        ):
            _reset_registry()
            _rlm_projects(action="add", name="WithPwd", path=src, password="secret")
            # Build first
            await rlm_index(action="build", project="WithPwd", confirm="secret")
            # Update
            r = json.loads(await rlm_index(action="update", project="WithPwd", confirm="secret"))
            assert r["action"] == "update"
            # cleanup
            _rlm_index(action="drop", path=src)


@pytest.mark.asyncio
async def test_rlm_index_info_works_with_path():
    """info via path without password → works as before."""
    with tempfile.TemporaryDirectory() as tmpdir:
        r = json.loads(await rlm_index(action="info", path=tmpdir))
        assert "approval_required" not in r


@pytest.mark.asyncio
async def test_rlm_index_info_works_with_project():
    """info via project without password → works as before."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="InfoTest", path=src)
            r = json.loads(await rlm_index(action="info", project="InfoTest"))
            assert "approval_required" not in r


# --- _rlm_projects password tests (sync) ---


def test_rlm_projects_add_with_password():
    """add with password → response has no password_hash/password_salt."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            r = json.loads(_rlm_projects(action="add", name="PwdTest", path=src, password="secret"))
            assert "added" in r
            assert "password_hash" not in r["added"]
            assert "password_salt" not in r["added"]


def test_rlm_projects_list_no_password_fields():
    """list never returns password fields."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="PwdTest", path=src, password="secret")
            r = json.loads(_rlm_projects(action="list"))
            for p in r["projects"]:
                assert "password_hash" not in p
                assert "password_salt" not in p


def test_rlm_projects_update_password():
    """update with password → response has no password_hash."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="PwdTest", path=src)
            r = json.loads(_rlm_projects(action="update", name="PwdTest", password="newpass"))
            assert "updated" in r
            assert "password_hash" not in r["updated"]


def test_rlm_projects_update_clear_password():
    """update with clear_password → password removed."""
    with tempfile.TemporaryDirectory() as tmpdir:
        from rlm_tools_bsl.projects import _reset_registry, get_registry

        src = os.path.join(tmpdir, "src")
        os.makedirs(src)
        _reset_registry()
        with patch.dict(os.environ, {"RLM_CONFIG_FILE": os.path.join(tmpdir, "service.json")}):
            _reset_registry()
            _rlm_projects(action="add", name="PwdTest", path=src, password="secret")
            reg = get_registry()
            assert reg.has_password("PwdTest") is True
            _rlm_projects(action="update", name="PwdTest", clear_password=True)
            _reset_registry()
            reg = get_registry()
            assert reg.has_password("PwdTest") is False


# ---------------------------------------------------------------------------
# _resolve_path_map tests
# ---------------------------------------------------------------------------


def test_resolve_path_map_no_env():
    """Without RLM_PATH_MAP, path is returned unchanged."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("RLM_PATH_MAP", None)
        assert _resolve_path_map("D:/Repos/erp/src") == "D:/Repos/erp/src"


def test_resolve_path_map_windows_prefix():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Repos:/repos"}):
        assert _resolve_path_map("D:/Repos/erp/src/cf") == "/repos/erp/src/cf"


def test_resolve_path_map_backslashes():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Repos:/repos"}):
        assert _resolve_path_map("D:\\Repos\\erp\\src\\cf") == "/repos/erp/src/cf"


def test_resolve_path_map_case_insensitive():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Repos:/repos"}):
        assert _resolve_path_map("d:/repos/erp/src") == "/repos/erp/src"


def test_resolve_path_map_no_match():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Repos:/repos"}):
        assert _resolve_path_map("/home/user/data") == "/home/user/data"


def test_resolve_path_map_linux():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "/home/user/repos:/repos"}):
        assert _resolve_path_map("/home/user/repos/erp/src") == "/repos/erp/src"


def test_resolve_path_map_trailing_slash():
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Repos/:/repos/"}):
        assert _resolve_path_map("D:/Repos/erp/src") == "/repos/erp/src"


def test_resolve_path_map_partial_prefix_no_match():
    """D:/Rep must NOT match D:/Repos — boundary check."""
    with patch.dict(os.environ, {"RLM_PATH_MAP": "D:/Rep:/repos"}):
        assert _resolve_path_map("D:/Repos/erp") == "D:/Repos/erp"
