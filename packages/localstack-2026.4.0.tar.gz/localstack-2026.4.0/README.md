# LocalStack CLI

The command-line interface for [LocalStack](https://localstack.cloud), a cloud service emulator that runs on your laptop or in your CI environment.

## Installation

```bash
pip install localstack-cli-standalone
```

Requires Docker to be installed and running.

## Usage

Start LocalStack:

```bash
localstack start
```

Check service status:

```bash
localstack status services
```

Stop LocalStack:

```bash
localstack stop
```

## Documentation

For full documentation, visit [docs.localstack.cloud](https://docs.localstack.cloud).

## License

Apache License 2.0
