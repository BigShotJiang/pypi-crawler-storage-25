import unittest

from dc_algorithms import (
    RaymondMutex,
    evaluate_ricart_request,
    is_safe_state,
    run_bully_election,
    run_distributed_global_average,
    synchronize_times,
)


class TestAlgorithms(unittest.TestCase):
    def test_bankers_safe(self) -> None:
        safe, seq = is_safe_state(
            allocation=[[0, 1], [1, 0]],
            max_demand=[[1, 1], [1, 1]],
            available=[1, 0],
        )
        self.assertTrue(safe)
        self.assertEqual(len(seq), 2)

    def test_berkely(self) -> None:
        result = synchronize_times((10, 0, 0), [(10, 0, 10), (9, 59, 50)])
        self.assertIn("master", result)
        self.assertEqual(len(result["nodes"]), 2)

    def test_berkely_java_rounding_parity(self) -> None:
        # avg offset = (-1) / 2 = -0.5, Java Math.round(-0.5) == 0
        result = synchronize_times((0, 0, 1), [(0, 0, 0)])
        self.assertEqual(result["master"], "00:00:01")

    def test_bully(self) -> None:
        result = run_bully_election(5, crashed_process=2, initiator=1)
        self.assertEqual(result.coordinator, 4)

    def test_distributed_global_average(self) -> None:
        history = run_distributed_global_average([3.0, 6.0, 9.0], rounds=2)
        self.assertEqual(len(history), 2)
        self.assertEqual(len(history[0]), 3)

    def test_raymond(self) -> None:
        rm = RaymondMutex.default_demo_state()
        events = rm.request_cs(3)
        self.assertTrue(any("Token transferred" in e for e in events))

    def test_ricart(self) -> None:
        result = evaluate_ricart_request([5, 10, 11], requester=0)
        self.assertTrue(result.can_enter_cs)


if __name__ == "__main__":
    unittest.main()
