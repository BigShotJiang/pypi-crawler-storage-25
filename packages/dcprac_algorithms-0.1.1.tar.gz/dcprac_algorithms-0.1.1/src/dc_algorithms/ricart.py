"""Ricart-Agrawala mutual exclusion request simulation."""

# Original Java source (ricart.java):
# import java.util.*;
#
# class Ricart {
#
#     public static void main(String[] args) {
#
#         Scanner sc = new Scanner(System.in);
#
#         System.out.print("Enter number of processes: ");
#         int n = sc.nextInt();
#
#         int[] ts = new int[n];
#
#         System.out.println("Enter timestamps:");
#         for (int i = 0; i < n; i++) {
#             ts[i] = sc.nextInt();
#         }
#
#         System.out.print("Enter requesting process (0 to " + (n - 1) + "): ");
#         int p = sc.nextInt();
#
#         int replies = 0;
#
#         System.out.println("\nP" + p + " requests CS");
#
#         for (int i = 0; i < n; i++) {
#             if (i == p)
#                 continue;
#
#             System.out.println("P" + p + " -> REQUEST -> P" + i);
#
#             if (ts[p] < ts[i] || (ts[p] == ts[i] && p < i)) {
#                 System.out.println("P" + i + " -> OK -> P" + p);
#                 replies++;
#             } else {
#                 System.out.println("P" + i + " defers reply");
#             }
#         }
#
#         if (replies == n - 1)
#             System.out.println("\nP" + p + " enters CS");
#         else
#             System.out.println("\nP" + p + " waits for replies");
#
#         sc.close();
#     }
# }

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence


@dataclass(frozen=True)
class RicartResult:
    requester: int
    replies: int
    deferred_from: List[int]
    can_enter_cs: bool
    events: List[str]


def evaluate_ricart_request(timestamps: Sequence[int], requester: int) -> RicartResult:
    """Evaluate one requesting process using Java-equivalent tie-breaking."""
    n = len(timestamps)
    if n == 0:
        raise ValueError("timestamps must not be empty")
    if not (0 <= requester < n):
        raise ValueError("requester out of range")

    replies = 0
    deferred: List[int] = []
    events: List[str] = [f"P{requester} requests CS"]

    for i in range(n):
        if i == requester:
            continue

        events.append(f"P{requester} -> REQUEST -> P{i}")
        if timestamps[requester] < timestamps[i] or (
            timestamps[requester] == timestamps[i] and requester < i
        ):
            replies += 1
            events.append(f"P{i} -> OK -> P{requester}")
        else:
            deferred.append(i)
            events.append(f"P{i} defers reply")

    can_enter = replies == n - 1
    if can_enter:
        events.append(f"P{requester} enters CS")
    else:
        events.append(f"P{requester} waits for replies")

    return RicartResult(
        requester=requester,
        replies=replies,
        deferred_from=deferred,
        can_enter_cs=can_enter,
        events=events,
    )
