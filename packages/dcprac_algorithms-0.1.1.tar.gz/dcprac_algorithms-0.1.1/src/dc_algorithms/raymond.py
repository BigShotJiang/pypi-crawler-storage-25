"""Raymond tree-based mutual exclusion simulation."""

# Original Java source (raymond.java):
# class Raymond {
#
#     static int holder[] = { 1, 1, 2, 2 };
#     static boolean hasToken[] = { true, false, false, false };
#
#     static void requestCS(int p) {
#
#         int original = p;
#         System.out.println("Process " + p + " requests Critical Section");
#
#         // Walk up the tree to find the token holder
#         while (!hasToken[p - 1]) {
#             int parent = holder[p - 1];
#             System.out.println("Request sent from P" + p + " to P" + parent);
#             p = parent;
#         }
#
#         // p now holds the token; transfer it to original
#         hasToken[p - 1] = false;
#         hasToken[original - 1] = true;
#
#         // Update holder pointers: the old token holder now points toward original
#         if (p != original) {
#             holder[p - 1] = original;
#         }
#
#         System.out.println("Token transferred to Process " + original);
#         System.out.println("Process " + original + " enters Critical Section\n");
#     }
#
#     public static void main(String[] args) {
#
#         System.out.println("Initial Token Holder: Process 1\n");
#
#         requestCS(3);
#         requestCS(4);
#     }
# }
#
# /*
#  * import java.util.*;
#  *
#  * class Raymond {
#  *
#  * static int holder[];
#  * static boolean hasToken[];
#  *
#  * static void requestCS(int p) {
#  *
#  * int original = p;
#  * System.out.println("\nProcess " + p + " requests Critical Section");
#  *
#  * // move up tree to find token
#  * while (!hasToken[p - 1]) {
#  * int parent = holder[p - 1];
#  * System.out.println("Request sent from P" + p + " to P" + parent);
#  * p = parent;
#  * }
#  *
#  * // transfer token
#  * hasToken[p - 1] = false;
#  * hasToken[original - 1] = true;
#  *
#  * if (p != original)
#  * holder[p - 1] = original;
#  *
#  * System.out.println("Token transferred to Process " + original);
#  * System.out.println("Process " + original + " enters Critical Section");
#  * }
#  *
#  * public static void main(String[] args) {
#  *
#  * Scanner sc = new Scanner(System.in);
#  *
#  * System.out.print("Enter number of processes: ");
#  * int n = sc.nextInt();
#  *
#  * holder = new int[n];
#  * hasToken = new boolean[n];
#  *
#  * System.out.println("Enter holder (parent) of each process:");
#  * for (int i = 0; i < n; i++)
#  * holder[i] = sc.nextInt();
#  *
#  * System.out.print("Enter initial token holder: ");
#  * int t = sc.nextInt();
#  * hasToken[t - 1] = true;
#  *
#  * System.out.print("Enter number of requests: ");
#  * int r = sc.nextInt();
#  *
#  * for (int i = 0; i < r; i++) {
#  * System.out.print("Enter process requesting CS: ");
#  * int p = sc.nextInt();
#  * requestCS(p);
#  * }
#  *
#  * sc.close();
#  * }
#  * }
#  */

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence


@dataclass
class RaymondMutex:
    """Simplified Raymond algorithm state.

    holder uses 1-based process ids, matching the Java sample.
    """

    holder: List[int]
    has_token: List[bool]

    @classmethod
    def default_demo_state(cls) -> "RaymondMutex":
        return cls(holder=[1, 1, 2, 2], has_token=[True, False, False, False])

    def request_cs(self, process_id: int) -> List[str]:
        """Process requests CS and token is transferred if necessary."""
        if not (1 <= process_id <= len(self.holder)):
            raise ValueError("process_id out of range")

        events = [f"Process {process_id} requests Critical Section"]
        original = process_id
        p = process_id

        while not self.has_token[p - 1]:
            parent = self.holder[p - 1]
            events.append(f"Request sent from P{p} to P{parent}")
            p = parent

        self.has_token[p - 1] = False
        self.has_token[original - 1] = True

        if p != original:
            self.holder[p - 1] = original

        events.append(f"Token transferred to Process {original}")
        events.append(f"Process {original} enters Critical Section")
        return events
