"""Berkeley clock synchronization implementation."""

# Original Java source (berkely.java):
# import java.util.*;
#
# class Berkeley {
#     public static void main(String[] args) {
#
#         Scanner sc = new Scanner(System.in);
#
#         System.out.println("Enter Master time (h m s):");
#         int mh = sc.nextInt(), mm = sc.nextInt(), ms = sc.nextInt();
#
#         System.out.println("Enter number of nodes:");
#         int n = sc.nextInt();
#
#         int h[] = new int[n], m[] = new int[n], s[] = new int[n];
#         double diff[] = new double[n];
#
#         // Convert master time to seconds
#         int masterTime = mh * 3600 + mm * 60 + ms;
#
#         double sum = 0;
#
#         System.out.println("Enter node times:");
#         for (int i = 0; i < n; i++) {
#             h[i] = sc.nextInt();
#             m[i] = sc.nextInt();
#             s[i] = sc.nextInt();
#
#             int nodeTime = h[i] * 3600 + m[i] * 60 + s[i];
#
#             diff[i] = nodeTime - masterTime; // difference
#             sum += diff[i];
#         }
#
#         // Include master (diff = 0)
#         double avg = sum / (n + 1);
#
#         // Adjust master
#         int newMaster = masterTime + (int) Math.round(avg);
#
#         System.out.println("\nSynchronized Times:");
#         System.out.println("Master: " + format(newMaster));
#
#         // Adjust nodes
#         for (int i = 0; i < n; i++) {
#             int nodeTime = h[i] * 3600 + m[i] * 60 + s[i];
#
#             int newTime = nodeTime - (int) Math.round(diff[i] - avg);
#
#             System.out.println("Node " + (i + 1) + ": " + format(newTime));
#         }
#
#         sc.close();
#     }
#
#     // Convert seconds -> HH:MM:SS
#     static String format(int t) {
#         t = (t + 86400) % 86400;
#         int h = t / 3600;
#         int m = (t % 3600) / 60;
#         int s = t % 60;
#         return String.format("%02d:%02d:%02d", h, m, s);
#     }
# }

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

TimeTuple = Tuple[int, int, int]


def _to_seconds(t: TimeTuple) -> int:
    h, m, s = t
    return h * 3600 + m * 60 + s


def _format_seconds(total_seconds: int) -> str:
    t = (total_seconds + 86400) % 86400
    h = t // 3600
    m = (t % 3600) // 60
    s = t % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def _java_round(value: float) -> int:
    # Java Math.round(double) is equivalent to floor(x + 0.5).
    return int(math.floor(value + 0.5))


def synchronize_times(master_time: TimeTuple, node_times: Sequence[TimeTuple]) -> Dict[str, object]:
    """Synchronize node clocks based on Berkeley algorithm math from the Java version."""
    master_seconds = _to_seconds(master_time)

    diffs: List[int] = []
    for node in node_times:
        node_seconds = _to_seconds(node)
        diffs.append(node_seconds - master_seconds)

    avg = sum(diffs) / (len(node_times) + 1)
    new_master = master_seconds + _java_round(avg)

    adjusted_nodes: List[str] = []
    adjusted_nodes_seconds: List[int] = []
    for diff, node in zip(diffs, node_times):
        node_seconds = _to_seconds(node)
        new_time = node_seconds - _java_round(diff - avg)
        adjusted_nodes_seconds.append(new_time)
        adjusted_nodes.append(_format_seconds(new_time))

    return {
        "master": _format_seconds(new_master),
        "nodes": adjusted_nodes,
        "master_seconds": new_master,
        "nodes_seconds": adjusted_nodes_seconds,
        "average_offset": avg,
    }
