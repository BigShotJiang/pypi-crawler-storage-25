"""Bully election algorithm simulation."""

# Original Java source (bully.java):
# import java.util.Scanner;
#
# public class bully {
#
#     public static void main(String[] args) {
#
#         Scanner sc = new Scanner(System.in);
#
#         // Input number of processes
#         System.out.print("Enter number of processes: ");
#         int n = sc.nextInt();
#
#         int[] process = new int[n];
#
#         // Initialize all processes as active
#         for (int i = 0; i < n; i++) {
#             process[i] = 1;
#         }
#
#         // Take crashed process input
#         System.out.print("Enter process ID that crashed: ");
#         int crashed = sc.nextInt();
#         process[crashed] = 0;
#
#         System.out.println("Process " + crashed + " has crashed");
#
#         // Take initiator input
#         System.out.print("Enter process ID that starts election: ");
#         int initiator = sc.nextInt();
#
#         System.out.println("\nElection started by process " + initiator);
#
#         int coordinator = initiator;
#
#         // Election process
#         for (int i = initiator + 1; i < n; i++) {
#             if (process[i] == 1) {
#                 System.out.println("Election message sent from " + initiator + " to " + i);
#                 System.out.println("OK message from " + i);
#
#                 System.out.println("New election started by process " + i);
#                 coordinator = i;
#             }
#         }
#
#         // Final coordinator
#         System.out.println("\nFinal Coordinator is Process " + coordinator);
#
#         // Coordinator informs all
#         for (int i = 0; i < n; i++) {
#             if (process[i] == 1 && i != coordinator) {
#                 System.out.println("Message to " + i + ": Coordinator is " + coordinator);
#             }
#         }
#
#         sc.close();
#     }
# }

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class BullyElectionResult:
    coordinator: int
    active_processes: List[int]
    events: List[str]


def run_bully_election(process_count: int, crashed_process: int, initiator: int) -> BullyElectionResult:
    """Run the same bully-election flow as the Java sample."""
    if process_count <= 0:
        raise ValueError("process_count must be > 0")
    if not (0 <= crashed_process < process_count):
        raise ValueError("crashed_process out of range")
    if not (0 <= initiator < process_count):
        raise ValueError("initiator out of range")

    process = [1] * process_count
    process[crashed_process] = 0

    events: List[str] = [f"Process {crashed_process} has crashed", f"Election started by process {initiator}"]
    coordinator = initiator

    for i in range(initiator + 1, process_count):
        if process[i] == 1:
            events.append(f"Election message sent from {initiator} to {i}")
            events.append(f"OK message from {i}")
            events.append(f"New election started by process {i}")
            coordinator = i

    events.append(f"Final Coordinator is Process {coordinator}")
    for i in range(process_count):
        if process[i] == 1 and i != coordinator:
            events.append(f"Message to {i}: Coordinator is {coordinator}")

    active = [i for i, status in enumerate(process) if status == 1]
    return BullyElectionResult(coordinator=coordinator, active_processes=active, events=events)
