"""Distributed global average (ring-neighbor averaging) simulation."""

# Original Java source (distributedglobalaverage.java):
# import java.util.*;
#
# public class distributedglobalaverage {
#
#     public static void main(String[] args) {
#
#         Scanner sc = new Scanner(System.in);
#
#         System.out.print("Enter number of nodes: ");
#         int n = sc.nextInt();
#
#         double[] values = new double[n];
#
#         System.out.println("Enter values:");
#         for (int i = 0; i < n; i++) {
#             values[i] = sc.nextDouble();
#         }
#
#         System.out.print("Enter number of rounds: ");
#         int rounds = sc.nextInt();
#
#         for (int round = 1; round <= rounds; round++) {
#
#             double[] newValues = new double[n];
#
#             for (int i = 0; i < n; i++) {
#                 double left = values[(i - 1 + n) % n];
#                 double right = values[(i + 1) % n];
#
#                 newValues[i] = (values[i] + left + right) / 3;
#             }
#
#             values = newValues;
#
#             System.out.print("Round " + round + ": ");
#             for (double v : values) {
#                 System.out.printf("%.2f ", v);
#             }
#             System.out.println();
#         }
#
#         sc.close();
#     }
# }

from __future__ import annotations

from typing import Iterable, List, Sequence


def run_distributed_global_average(values: Sequence[float], rounds: int) -> List[List[float]]:
    """Run neighbor-averaging rounds and return values for each round."""
    if not values:
        raise ValueError("values must not be empty")
    if rounds < 0:
        raise ValueError("rounds must be >= 0")

    current = [float(v) for v in values]
    n = len(current)
    history: List[List[float]] = []

    for _ in range(rounds):
        new_values = [0.0] * n
        for i in range(n):
            left = current[(i - 1 + n) % n]
            right = current[(i + 1) % n]
            new_values[i] = (current[i] + left + right) / 3.0
        current = new_values
        history.append(current.copy())

    return history
