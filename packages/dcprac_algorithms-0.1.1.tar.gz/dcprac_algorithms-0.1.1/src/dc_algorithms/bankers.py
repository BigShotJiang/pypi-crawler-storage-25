"""Banker's algorithm implementation."""

# Original Java source (bankers.java):
# import java.util.*;
#
# class Bankers {
#     public static void main(String[] args) {
#
#         Scanner sc = new Scanner(System.in);
#
#         System.out.print("Processes: ");
#         int p = sc.nextInt();
#
#         System.out.print("Resources: ");
#         int r = sc.nextInt();
#
#         int allocation[][] = new int[p][r];
#         int max[][] = new int[p][r];
#         int available[] = new int[r];
#         int need[][] = new int[p][r];
#
#         System.out.println("Enter Allocation:");
#         for (int i = 0; i < p; i++)
#             for (int j = 0; j < r; j++)
#                 allocation[i][j] = sc.nextInt();
#
#         System.out.println("Enter Max:");
#         for (int i = 0; i < p; i++)
#             for (int j = 0; j < r; j++)
#                 max[i][j] = sc.nextInt();
#
#         System.out.println("Enter Available:");
#         for (int i = 0; i < r; i++)
#             available[i] = sc.nextInt();
#
#         // Need = Max - Allocation
#         for (int i = 0; i < p; i++)
#             for (int j = 0; j < r; j++)
#                 need[i][j] = max[i][j] - allocation[i][j];
#
#         boolean finished[] = new boolean[p];
#         int safeSeq[] = new int[p];
#         int work[] = available.clone();
#
#         int count = 0;
#
#         while (count < p) {
#             boolean found = false;
#
#             for (int i = 0; i < p; i++) {
#                 if (!finished[i]) {
#
#                     int j;
#                     for (j = 0; j < r; j++)
#                         if (need[i][j] > work[j])
#                             break;
#
#                     if (j == r) {
#                         for (int k = 0; k < r; k++)
#                             work[k] += allocation[i][k];
#
#                         safeSeq[count++] = i;
#                         finished[i] = true;
#                         found = true;
#                     }
#                 }
#             }
#
#             if (!found) {
#                 System.out.println("Not Safe");
#                 return;
#             }
#         }
#
#         System.out.print("Safe Sequence: ");
#         for (int i = 0; i < p; i++)
#             System.out.print("P" + safeSeq[i] + " ");
#     }
# }

from __future__ import annotations

from typing import List, Sequence, Tuple


def _validate_matrix(matrix: Sequence[Sequence[int]], rows: int, cols: int, name: str) -> None:
    if len(matrix) != rows:
        raise ValueError(f"{name} must have {rows} rows")
    for row in matrix:
        if len(row) != cols:
            raise ValueError(f"all rows in {name} must have {cols} columns")


def is_safe_state(
    allocation: Sequence[Sequence[int]],
    max_demand: Sequence[Sequence[int]],
    available: Sequence[int],
) -> Tuple[bool, List[int]]:
    """Return whether state is safe and the corresponding safe sequence.

    This follows the same logic as the Java sample and returns an empty
    sequence when the state is not safe.
    """
    p = len(allocation)
    if p == 0:
        return True, []

    r = len(available)
    if r == 0:
        raise ValueError("available must not be empty")

    _validate_matrix(allocation, p, r, "allocation")
    _validate_matrix(max_demand, p, r, "max_demand")

    need = [[max_demand[i][j] - allocation[i][j] for j in range(r)] for i in range(p)]

    finished = [False] * p
    safe_seq: List[int] = []
    work = list(available)

    while len(safe_seq) < p:
        found = False

        for i in range(p):
            if finished[i]:
                continue

            if all(need[i][j] <= work[j] for j in range(r)):
                for k in range(r):
                    work[k] += allocation[i][k]

                safe_seq.append(i)
                finished[i] = True
                found = True

        if not found:
            return False, []

    return True, safe_seq
