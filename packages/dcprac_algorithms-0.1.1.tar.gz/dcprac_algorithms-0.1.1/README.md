# dcprac-algorithms

Python package version of your Java implementations for:

- Banker's Algorithm
- Berkeley Time Synchronization (kept as `berkely` for compatibility with your naming)
- Bully Election Algorithm
- Distributed Global Average (ring neighbors)
- Raymond Mutual Exclusion (simplified simulation)
- Ricart-Agrawala Mutual Exclusion

## Install locally

```bash
pip install -e .
```

## Quick usage

```python
from dc_algorithms import (
    is_safe_state,
    synchronize_times,
    run_bully_election,
    run_distributed_global_average,
    RaymondMutex,
    evaluate_ricart_request,
)

safe, seq = is_safe_state(
    allocation=[[0, 1], [1, 0]],
    max_demand=[[1, 1], [1, 1]],
    available=[1, 0],
)
print(safe, seq)
```

## Build package

```bash
python -m pip install --upgrade build twine
python -m build
```

This creates artifacts in `dist/`.

## Publish to PyPI

```bash
python -m twine upload dist/*
```

Before publishing, update at least:

- `version` in `pyproject.toml`
- `project.urls` in `pyproject.toml`
- author metadata if needed
