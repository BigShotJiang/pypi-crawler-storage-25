# AGENTS.md - dts-dance 项目指南

此文件为 AI 编程助手提供 dts-dance 项目的背景信息、架构说明和开发指南。

## 项目概述

**dts-dance** 是一个 Python 客户端库，为 ByteDTS（字节跳动数据同步服务）提供各种内部 API 服务的封装。主要功能包括：

- 多服务 API 客户端实现（DFlow、飞书、SpaceX、指标服务等）
- 自动认证令牌管理和续期
- 线程安全的令牌刷新机制
- 完整的类型提示支持
- 内置错误处理和日志记录

## 技术栈

- **语言**: Python 3.12+
- **包管理**: [uv](https://docs.astral.sh/uv/)（推荐）或 pip
- **构建系统**: Hatchling (配置在 pyproject.toml)
- **主要依赖**:
  - `requests` - HTTP 请求
  - `loguru` - 日志记录
  - `boto3` - AWS/S3 兼容存储
  - `pyyaml` - YAML 解析
  - `requests_toolbelt` - 多部分表单编码

## 项目结构

```
dts-dance/
├── dtsdance/              # 主包目录
│   ├── __init__.py        # 包初始化
│   ├── bytecloud.py       # ByteCloud JWT 认证客户端
│   ├── bytedts_dflow.py   # DFlow 任务管理客户端
│   ├── bytedts_dsyncer.py # DSyncer 客户端
│   ├── bytedts_spacex.py  # ByteDTS SpaceX 运维平台客户端
│   ├── ddutil.py          # 通用 HTTP 请求工具
│   ├── feishu_base.py     # 飞书 API 基础客户端
│   ├── feishu_table.py    # 飞书多维表格操作
│   ├── metrics_fe.py      # 指标服务前端客户端
│   ├── s3.py              # S3 存储操作
│   ├── spacex.py          # SpaceX 工单服务客户端
│   ├── tcc_inner.py       # TCC 内部 API 客户端
│   ├── tcc_open.py        # TCC OpenAPI 客户端
│   └── tce.py             # TCE 相关功能
├── tests/                 # 测试目录
│   ├── config.py          # 测试配置加载器
│   ├── test_dflow.py      # DFlow 测试
│   ├── test_spacex.py     # SpaceX 测试
│   ├── test_bytedts_spacex.py
│   └── test_tcc.py        # TCC 测试
├── config.yaml            # 站点配置（多环境端点）
├── pyproject.toml         # 项目配置和依赖
├── uv.lock               # uv 锁定文件
└── README.md             # 项目说明
```

## 核心模块说明

### 1. 认证与基础客户端

#### `bytecloud.py` - ByteCloudClient
- **用途**: ByteCloud JWT 令牌管理
- **关键特性**:
  - 支持多环境配置（boe, cn, i18n, us-ttp, eu-ttp 等）
  - 可选的 JWT 令牌缓存（`enable_jwt_cache=True`）
  - 后台线程自动刷新（每 2 小时）
  - 线程安全的令牌访问（使用 `threading.Lock`）
- **依赖关系**: 被 DFlowClient、SpaceXClient、TCCInnerClient 等依赖

#### `feishu_base.py` - FeishuBase
- **用途**: 飞书（Lark）OpenAPI 认证和通用请求
- **关键特性**:
  - 自动 `tenant_access_token` 获取和续期
  - 提前 5 分钟刷新令牌
  - 支持消息发送（文本、图片、卡片）
  - 图片上传功能
  - 批量用户 ID 查询

### 2. 业务客户端

| 模块 | 类名 | 依赖 | 用途 |
|------|------|------|------|
| `feishu_table.py` | FeishuTable | FeishuBase | 飞书多维表格操作 |
| `bytedts_dflow.py` | DFlowClient | ByteCloudClient | DFlow 任务/进程管理 |
| `spacex.py` | SpaceXClient | ByteCloudClient | SpaceX 工单创建 |
| `bytedts_spacex.py` | BytedtsSpaceXClient | ByteCloudClient | SpaceX 运维平台 API |
| `tcc_open.py` | TCCClient | - | TCC OpenAPI（配置管理）|
| `tcc_inner.py` | TCCInnerClient | ByteCloudClient | TCC 内部 API |
| `s3.py` | S3Client | boto3 | S3 兼容存储操作 |

### 3. 工具模块

- **`ddutil.py`**: HTTP 请求通用封装，包含 `make_request()` 和 `output_curl()`

## 开发环境设置

### 使用 uv（推荐）

```bash
# 同步依赖并创建虚拟环境
uv sync

# 激活虚拟环境
source .venv/bin/activate

# 安装包（可编辑模式）
uv pip install -e .

# 运行 Python 脚本
uv run python xxx.py
```

### 使用 pyenv + pip

```bash
pyenv shell 3.12.10
python -m venv .venv
source .venv/bin/activate
pip install .
```

## 构建和发布

```bash
# 构建包
uv build

# 发布到 PyPI
export UV_PUBLISH_TOKEN=pypi-xxx
uv publish
```

构建产物位于 `dist/` 目录，包含 wheel 和 sdist 格式。

## 测试

使用 pytest 运行测试：

```bash
# 运行所有测试
pytest tests/

# 运行特定测试
pytest tests/test_dflow.py::test_get_task_info -s

# 运行并输出打印信息
pytest tests/test_tcc.py::test_list_all_configs -s
```

### 测试配置

测试使用 `tests/config.py` 中的 `ConfigLoader` 从 `config.yaml` 加载站点配置：

```python
from tests.config import ConfigLoader

loader = ConfigLoader.get_instance()
loader.load_from_file(["boe", "cn"])  # 加载指定环境
site_configs = loader.get_site_configs()
```

可通过环境变量指定配置文件路径：
```bash
export CONFIG_PATH=/path/to/config.yaml
```

## 代码规范

### 格式化和风格

- **行长度**: 150 字符（`pyproject.toml` 中 Black 配置）
- **格式化工具**: Black（目标 Python 3.12）
- **类型提示**: 强制使用，风格：`dict[str, Any]`, `str | None`

### 编码约定

1. **日志记录**: 统一使用 `loguru.logger`，不使用 `print`（遗留代码除外）
   ```python
   from loguru import logger
   logger.info("信息日志")
   logger.warning("警告日志")
   logger.debug("调试日志")
   ```

2. **错误处理**: 记录警告/错误后抛出异常
   ```python
   try:
       # 操作
   except Exception as e:
       logger.warning(f"操作失败: {e}")
       raise
   ```

3. **类型提示**: 所有函数参数和返回值必须添加类型提示
   ```python
   def get_task_info(self, site: str, task_id: str, vregion: str | None = None) -> dict[str, Any]:
   ```

4. **线程安全**: Token 管理使用 `threading.Lock`
   ```python
   self._token_lock = threading.Lock()
   with self._token_lock:
       # 访问共享资源
   ```

## 配置说明

### config.yaml

定义多环境端点和服务账户信息：

```yaml
sites:
  boe:
    endpoint: https://cloud-boe.bytedance.net
    endpoint_bytedts_spacex: https://bytedts-spacex-boe.bytedance.net
    svc_account: bytedts
    svc_secret: xxx
  cn:
    endpoint: https://cloud.bytedance.net
    endpoint_bytedts_spacex: https://bytedts-spacex-cn.bytedance.net
    endpoint_spacex: https://spacex-api.bytedance.net
    svc_account: bytedts
    svc_secret: xxx
  # ... 其他环境
```

支持的环境：boe, boe-i18n, cn, i18n-bd, i18n-tt, us-ttp, eu-ttp

## 使用示例

### 使用 DFlowClient

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient

# 初始化
sites = {
    "cn": SiteConfig("cn", "https://cloud.bytedance.net", "account", "secret")
}
bytecloud = ByteCloudClient(sites)
dflow = DFlowClient(bytecloud)

# 获取任务信息
info = dflow.get_task_info("cn", "12345")
```

### 使用飞书客户端

```python
from dtsdance.feishu_base import FeishuBase
from dtsdance.feishu_table import FeishuTable

# 初始化认证
feishu = FeishuBase(app_id="xxx", app_secret="xxx")

# 发送消息
feishu.send_text_message(receive_id="chat_xxx", text="Hello", receive_id_type="chat_id")

# 操作多维表格
table = FeishuTable(feishu, app_token="xxx", table_id="xxx")
records = table.fetch_all(view_id="xxx", field_names=["字段1", "字段2"])
```

## 注意事项

1. **JWT 环境变量**: 可通过 `JWT_TOKEN` 环境变量覆盖 JWT 获取
2. **线程安全**: ByteCloudClient 的 `enable_jwt_cache=True` 会启动后台线程定期刷新令牌
3. **异常处理**: 客户端方法在失败时抛出异常，调用方需处理
4. **vregion 参数**: 部分 API 需要指定 vregion（虚拟区域）来路由请求
