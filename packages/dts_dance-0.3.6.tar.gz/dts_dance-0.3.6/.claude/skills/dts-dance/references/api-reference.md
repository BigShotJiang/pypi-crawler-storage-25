# API 参考

## ByteCloudClient

### 类定义

```python
class ByteCloudClient:
    def __init__(
        self,
        sites: dict[str, SiteConfig],
        enable_jwt_cache: bool = False
    ) -> None
```

### 方法

#### get_jwt_token

```python
def get_jwt_token(self, site: str) -> str
```

获取指定站点的 JWT 令牌。

**参数：**
- `site`: 站点名称（如 "cn", "boe"）

**返回：** JWT 令牌字符串

**异常：**
- `KeyError`: 站点不存在
- `Exception`: 获取令牌失败

---

## DFlowClient

### 类定义

```python
class DFlowClient:
    def __init__(self, bytecloud: ByteCloudClient) -> None
```

### 方法

#### get_task_info

```python
def get_task_info(
    self,
    site: str,
    task_id: str,
    vregion: str | None = None
) -> dict[str, Any]
```

获取任务详细信息。

**参数：**
- `site`: 站点名称
- `task_id`: 任务 ID
- `vregion`: 虚拟区域（可选）

#### get_process_info

```python
def get_process_info(
    self,
    site: str,
    process_id: str,
    vregion: str | None = None
) -> dict[str, Any]
```

获取进程详细信息。

#### retry_task

```python
def retry_task(
    self,
    site: str,
    task_id: str,
    vregion: str | None = None
) -> dict[str, Any]
```

重试失败的任务。

---

## FeishuBase

### 类定义

```python
class FeishuBase:
    def __init__(
        self,
        app_id: str,
        app_secret: str
    ) -> None
```

### 方法

#### send_text_message

```python
def send_text_message(
    self,
    receive_id: str,
    text: str,
    receive_id_type: str = "chat_id"
) -> dict[str, Any]
```

发送文本消息。

**参数：**
- `receive_id`: 接收者 ID
- `text`: 消息内容
- `receive_id_type`: ID 类型（"chat_id", "open_id", "user_id", "email"）

#### send_image_message

```python
def send_image_message(
    self,
    receive_id: str,
    image_key: str,
    receive_id_type: str = "chat_id"
) -> dict[str, Any]
```

发送图片消息。

#### send_card_message

```python
def send_card_message(
    self,
    receive_id: str,
    card_data: dict[str, Any],
    receive_id_type: str = "chat_id"
) -> dict[str, Any]
```

发送卡片消息。

#### upload_image

```python
def upload_image(
    self,
    image_path: str,
    image_type: str = "message"
) -> str
```

上传图片，返回 image_key。

#### get_users_by_emails

```python
def get_users_by_emails(
    self,
    emails: list[str]
) -> dict[str, str]
```

根据邮箱批量查询用户 ID。

---

## FeishuTable

### 类定义

```python
class FeishuTable:
    def __init__(
        self,
        feishu: FeishuBase,
        app_token: str,
        table_id: str
    ) -> None
```

### 方法

#### fetch_all

```python
def fetch_all(
    self,
    view_id: str | None = None,
    field_names: list[str] | None = None
) -> list[dict[str, Any]]
```

获取表格所有记录。

**参数：**
- `view_id`: 视图 ID（可选）
- `field_names`: 指定字段列表（可选）

**返回：** 记录列表

#### filter_records

```python
def filter_records(
    self,
    filter_conditions: list[dict[str, Any]] | None = None
) -> list[dict[str, Any]]
```

根据条件筛选记录。

---

## SpaceXClient

### 类定义

```python
class SpaceXClient:
    def __init__(self, bytecloud: ByteCloudClient) -> None
```

### 方法

#### create_ticket

```python
def create_ticket(
    self,
    site: str,
    title: str,
    content: str,
    owner: str,
    priority: str = "P2",
    **kwargs
) -> dict[str, Any]
```

创建工单。

**参数：**
- `site`: 站点名称
- `title`: 工单标题
- `content`: 工单内容
- `owner`: 负责人用户 ID
- `priority`: 优先级（P0/P1/P2/P3）

---

## TCCClient (OpenAPI)

### 类定义

```python
class TCCClient:
    def __init__(self, endpoint: str) -> None
```

### 方法

#### list_configs

```python
def list_configs(
    self,
    app_name: str,
    environment: str = "prod"
) -> list[dict[str, Any]]
```

列出应用的所有配置。

#### get_config

```python
def get_config(
    self,
    app_name: str,
    key: str,
    environment: str = "prod"
) -> Any
```

获取指定配置项的值。

---

## TCCInnerClient (内部 API)

### 类定义

```python
class TCCInnerClient:
    def __init__(self, bytecloud: ByteCloudClient) -> None
```

### 方法

与 `TCCClient` 类似，但使用内部 API 端点，需要 ByteCloud 认证。

---

## S3Client

### 类定义

```python
class S3Client:
    def __init__(
        self,
        endpoint: str,
        access_key: str,
        secret_key: str,
        region: str = "cn-beijing"
    ) -> None
```

### 方法

#### upload_file

```python
def upload_file(
    self,
    bucket: str,
    key: str,
    local_path: str
) -> None
```

上传本地文件到 S3。

#### download_file

```python
def download_file(
    self,
    bucket: str,
    key: str,
    local_path: str
) -> None
```

从 S3 下载文件到本地。

#### list_objects

```python
def list_objects(
    self,
    bucket: str,
    prefix: str = ""
) -> list[dict[str, Any]]
```

列出存储桶中的对象。
