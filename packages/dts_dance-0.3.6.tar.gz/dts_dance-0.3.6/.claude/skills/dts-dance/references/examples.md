# 使用示例

## 完整工作流示例

### 示例 1: DFlow 任务监控并发送飞书通知

```python
import os
import time
from datetime import datetime
from loguru import logger

from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient
from dtsdance.feishu_base import FeishuBase

# 初始化配置
sites = {
    "cn": SiteConfig(
        name="cn",
        endpoint="https://cloud.bytedance.net",
        svc_account=os.environ["DTS_ACCOUNT"],
        svc_secret=os.environ["DTS_SECRET"]
    )
}

# 初始化客户端
bytecloud = ByteCloudClient(sites, enable_jwt_cache=True)
dflow = DFlowClient(bytecloud)
feishu = FeishuBase(
    app_id=os.environ["FEISHU_APP_ID"],
    app_secret=os.environ["FEISHU_APP_SECRET"]
)

# 监控任务列表
TASKS_TO_MONITOR = ["task-001", "task-002", "task-003"]
ALERT_CHAT_ID = "chat_xxx"

def check_task_status():
    """检查任务状态并发送告警"""
    for task_id in TASKS_TO_MONITOR:
        try:
            info = dflow.get_task_info("cn", task_id)
            status = info.get("status", "UNKNOWN")
            
            if status in ["FAILED", "TIMEOUT"]:
                # 发送告警
                message = f"【任务告警】\n任务 ID: {task_id}\n状态: {status}\n时间: {datetime.now()}"
                feishu.send_text_message(
                    receive_id=ALERT_CHAT_ID,
                    text=message,
                    receive_id_type="chat_id"
                )
                logger.warning(f"任务 {task_id} 异常，已发送告警")
                
        except Exception as e:
            logger.error(f"检查任务 {task_id} 失败: {e}")

# 定时执行
while True:
    check_task_status()
    time.sleep(300)  # 每 5 分钟检查一次
```

### 示例 2: 从飞书表格读取数据并创建 DFlow 任务

```python
from dtsdance.feishu_base import FeishuBase
from dtsdance.feishu_table import FeishuTable
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient

# 初始化飞书
feishu = FeishuBase(app_id="cli_xxx", app_secret="xxx")
table = FeishuTable(
    feishu=feishu,
    app_token="app_xxx",
    table_id="tbl_xxx"
)

# 从表格读取待处理的任务配置
records = table.fetch_all(field_names=["任务名称", "数据源", "目标库", "配置JSON"])

# 初始化 DFlow
sites = {"cn": SiteConfig(...)}
dflow = DFlowClient(ByteCloudClient(sites))

# 批量创建任务
for record in records:
    fields = record.get("fields", {})
    task_name = fields.get("任务名称", "")
    config = fields.get("配置JSON", "{}")
    
    try:
        # 这里根据实际 API 调用创建任务
        logger.info(f"创建任务: {task_name}")
        # result = dflow.create_task("cn", config)
    except Exception as e:
        logger.error(f"创建任务 {task_name} 失败: {e}")
```

### 示例 3: 工单自动创建和更新

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.spacex import SpaceXClient
from dtsdance.feishu_base import FeishuBase

# 初始化
sites = {"cn": SiteConfig(...)}
bytecloud = ByteCloudClient(sites)
spacex = SpaceXClient(bytecloud)
feishu = FeishuBase(app_id="cli_xxx", app_secret="xxx")

def create_alert_ticket(
    alert_title: str,
    alert_content: str,
    owner_email: str,
    priority: str = "P1"
):
    """根据告警创建工单"""
    
    # 查询用户 ID
    users = feishu.get_users_by_emails([owner_email])
    owner_id = users.get(owner_email)
    
    if not owner_id:
        raise ValueError(f"找不到用户: {owner_email}")
    
    # 创建工单
    ticket = spacex.create_ticket(
        site="cn",
        title=alert_title,
        content=alert_content,
        owner=owner_id,
        priority=priority
    )
    
    return ticket

# 使用示例
try:
    ticket = create_alert_ticket(
        alert_title="【P1】数据同步延迟告警",
        alert_content="任务 task-xxx 延迟超过 1 小时",
        owner_email="ops@bytedance.com",
        priority="P1"
    )
    print(f"工单创建成功: {ticket.get('ticket_id')}")
except Exception as e:
    print(f"工单创建失败: {e}")
```

### 示例 4: 多环境配置管理

```python
import os
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient

# 定义多环境配置
ENV_CONFIGS = {
    "boe": {
        "endpoint": "https://cloud-boe.bytedance.net",
        "account": os.environ["BOE_ACCOUNT"],
        "secret": os.environ["BOE_SECRET"]
    },
    "cn": {
        "endpoint": "https://cloud.bytedance.net",
        "account": os.environ["CN_ACCOUNT"],
        "secret": os.environ["CN_SECRET"]
    },
    "i18n": {
        "endpoint": "https://cloud-i18n.bytedance.net",
        "account": os.environ["I18N_ACCOUNT"],
        "secret": os.environ["I18N_SECRET"]
    }
}

def get_dflow_client(environment: str) -> DFlowClient:
    """获取指定环境的 DFlow 客户端"""
    if environment not in ENV_CONFIGS:
        raise ValueError(f"未知环境: {environment}")
    
    cfg = ENV_CONFIGS[environment]
    sites = {
        environment: SiteConfig(
            name=environment,
            endpoint=cfg["endpoint"],
            svc_account=cfg["account"],
            svc_secret=cfg["secret"]
        )
    }
    
    bytecloud = ByteCloudClient(sites, enable_jwt_cache=True)
    return DFlowClient(bytecloud)

# 跨环境操作
def get_task_info_cross_env(task_id: str, env: str):
    """从指定环境获取任务信息"""
    client = get_dflow_client(env)
    return client.get_task_info(env, task_id)

# 使用示例
for env in ["boe", "cn"]:
    try:
        info = get_task_info_cross_env("task-123", env)
        print(f"[{env}] 任务状态: {info.get('status')}")
    except Exception as e:
        print(f"[{env}] 获取失败: {e}")
```

### 示例 5: S3 数据同步

```python
import json
from dtsdance.s3 import S3Client
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient

# 初始化 S3
s3 = S3Client(
    endpoint="https://tos-s3-cn-beijing.volces.com",
    access_key=os.environ["S3_ACCESS_KEY"],
    secret_key=os.environ["S3_SECRET_KEY"],
    region="cn-beijing"
)

# 下载配置文件
s3.download_file(
    bucket="dts-configs",
    key="prod/tasks/task-001.json",
    local_path="/tmp/task-001.json"
)

# 读取配置
with open("/tmp/task-001.json") as f:
    task_config = json.load(f)

# 使用配置创建 DFlow 任务
sites = {"cn": SiteConfig(...)}
dflow = DFlowClient(ByteCloudClient(sites))
# ... 创建任务逻辑

# 上传执行结果
with open("/tmp/result.json", "w") as f:
    json.dump({"status": "success", "task_id": "xxx"}, f)

s3.upload_file(
    bucket="dts-results",
    key="prod/results/task-001-result.json",
    local_path="/tmp/result.json"
)
```
