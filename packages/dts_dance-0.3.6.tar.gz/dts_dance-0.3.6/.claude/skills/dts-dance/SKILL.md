---
name: dts-dance
description: Guide for using the dts-dance Python library (ByteDTS client SDK). Use when the user needs help with importing, initializing, configuring, or using any of the dts-dance clients including DFlow, Feishu/Lark, SpaceX, TCC, S3, metrics services, or ByteCloud authentication.
---

# dts-dance 使用指南

**dts-dance** 是 ByteDTS（字节跳动数据同步服务）的 Python 客户端库，提供多种内部 API 的封装。

## 快速开始

### 安装

```bash
pip install dts-dance
```

或使用 uv：

```bash
uv add dts-dance
```

### 基础导入

```python
# 认证基类
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.feishu_base import FeishuBase

# 业务客户端
from dtsdance.bytedts_dflow import DFlowClient
from dtsdance.bytedts_spacex import BytedtsSpaceXClient
from dtsdance.spacex import SpaceXClient
from dtsdance.feishu_table import FeishuTable
from dtsdance.tcc_open import TCCClient
from dtsdance.tcc_inner import TCCInnerClient
from dtsdance.s3 import S3Client
```

## 客户端使用模式

### 1. ByteCloud 认证客户端

ByteCloudClient 是多个服务的基础认证层，管理 JWT 令牌的获取和自动刷新。

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig

# 配置站点
sites = {
    "cn": SiteConfig(
        name="cn",
        endpoint="https://cloud.bytedance.net",
        svc_account="your-account",
        svc_secret="your-secret"
    ),
    "boe": SiteConfig(
        name="boe",
        endpoint="https://cloud-boe.bytedance.net",
        svc_account="your-account",
        svc_secret="your-secret"
    )
}

# 初始化（启用缓存会自动后台刷新令牌）
bytecloud = ByteCloudClient(sites, enable_jwt_cache=True)

# 获取 JWT 令牌
token = bytecloud.get_jwt_token("cn")
```

### 2. DFlow 任务管理

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.bytedts_dflow import DFlowClient

# 初始化
sites = {"cn": SiteConfig(...)}
bytecloud = ByteCloudClient(sites)
dflow = DFlowClient(bytecloud)

# 获取任务信息
info = dflow.get_task_info("cn", "task-id-123")

# 获取进程信息
process_info = dflow.get_process_info("cn", "process-id-456")

# 重试任务
result = dflow.retry_task("cn", "task-id-123")
```

### 3. 飞书客户端

#### 基础认证和消息发送

```python
from dtsdance.feishu_base import FeishuBase

# 初始化
feishu = FeishuBase(app_id="cli_xxx", app_secret="xxx")

# 发送文本消息
feishu.send_text_message(
    receive_id="chat_xxx",
    text="Hello from dts-dance!",
    receive_id_type="chat_id"  # 或 "open_id", "user_id"
)

# 发送图片消息
feishu.send_image_message(
    receive_id="chat_xxx",
    image_key="img_xxx",
    receive_id_type="chat_id"
)

# 发送卡片消息
feishu.send_card_message(
    receive_id="chat_xxx",
    card_data={"config": {...}, "header": {...}, "elements": [...]},
    receive_id_type="chat_id"
)
```

#### 飞书多维表格操作

```python
from dtsdance.feishu_base import FeishuBase
from dtsdance.feishu_table import FeishuTable

# 初始化
feishu = FeishuBase(app_id="cli_xxx", app_secret="xxx")
table = FeishuTable(
    feishu=feishu,
    app_token="app_xxx",
    table_id="tbl_xxx"
)

# 获取所有记录
records = table.fetch_all(
    view_id="vew_xxx",           # 可选：指定视图
    field_names=["字段1", "字段2"]  # 可选：指定字段
)

# 查询记录
records = table.filter_records(
    filter_conditions=[
        {"field_name": "状态", "operator": "is", "value": "进行中"}
    ]
)
```

### 4. SpaceX 工单服务

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.spacex import SpaceXClient

# 初始化
sites = {"cn": SiteConfig(...)}
bytecloud = ByteCloudClient(sites)
spacex = SpaceXClient(bytecloud)

# 创建工单
ticket = spacex.create_ticket(
    site="cn",
    title="问题标题",
    content="问题描述",
    owner="user_id",
    priority="P1"  # P0/P1/P2/P3
)
```

### 5. TCC 配置管理

#### OpenAPI（无需 ByteCloud 认证）

```python
from dtsdance.tcc_open import TCCClient

# 初始化
tcc = TCCClient(endpoint="https://tcc.bytedance.net")

# 列出配置
configs = tcc.list_configs(
    app_name="my-app",
    environment="prod"
)

# 获取配置值
value = tcc.get_config(
    app_name="my-app",
    key="config-key",
    environment="prod"
)
```

#### 内部 API（需要 ByteCloud 认证）

```python
from dtsdance.bytecloud import ByteCloudClient, SiteConfig
from dtsdance.tcc_inner import TCCInnerClient

# 初始化
sites = {"cn": SiteConfig(...)}
bytecloud = ByteCloudClient(sites)
tcc = TCCInnerClient(bytecloud)

# 操作与 TCCClient 类似，但使用内部 API 端点
```

### 6. S3 存储操作

```python
from dtsdance.s3 import S3Client

# 初始化
s3 = S3Client(
    endpoint="https://s3.bytedance.net",
    access_key="xxx",
    secret_key="xxx",
    region="cn-beijing"
)

# 上传文件
s3.upload_file(
    bucket="my-bucket",
    key="path/to/file.txt",
    local_path="/local/path/file.txt"
)

# 下载文件
s3.download_file(
    bucket="my-bucket",
    key="path/to/file.txt",
    local_path="/local/path/file.txt"
)

# 列出对象
objects = s3.list_objects(
    bucket="my-bucket",
    prefix="path/to/"
)
```

## 配置管理

### 使用 config.yaml

创建 `config.yaml` 文件管理多环境配置：

```yaml
sites:
  boe:
    endpoint: https://cloud-boe.bytedance.net
    svc_account: bytedts
    svc_secret: ${BOE_SECRET}  # 使用环境变量
  cn:
    endpoint: https://cloud.bytedance.net
    svc_account: bytedts
    svc_secret: ${CN_SECRET}
  i18n:
    endpoint: https://cloud-i18n.bytedance.net
    svc_account: bytedts
    svc_secret: ${I18N_SECRET}
```

加载配置：

```python
import yaml
import os

# 加载配置
with open("config.yaml") as f:
    config = yaml.safe_load(f)

# 从环境变量替换 secret
for site, cfg in config["sites"].items():
    if cfg["svc_secret"].startswith("${") and cfg["svc_secret"].endswith("}"):
        env_var = cfg["svc_secret"][2:-1]
        cfg["svc_secret"] = os.environ.get(env_var, "")

# 创建 SiteConfig
from dtsdance.bytecloud import SiteConfig

sites = {
    name: SiteConfig(name=name, **cfg)
    for name, cfg in config["sites"].items()
}
```

## 环境变量

| 变量名 | 说明 |
|--------|------|
| `JWT_TOKEN` | 覆盖自动获取的 JWT 令牌 |
| `CONFIG_PATH` | 指定配置文件路径 |

## 日志记录

所有客户端使用 `loguru` 进行日志记录：

```python
from loguru import logger

# 配置日志级别
import sys
logger.remove()
logger.add(sys.stderr, level="DEBUG")

# 客户端会自动输出调试信息
```

## 错误处理

客户端方法在失败时会抛出异常，调用方需要处理：

```python
from dtsdance.bytedts_dflow import DFlowClient

try:
    info = dflow.get_task_info("cn", "invalid-id")
except Exception as e:
    logger.error(f"获取任务信息失败: {e}")
    # 处理错误
```

## 线程安全

- `ByteCloudClient` 的令牌管理是线程安全的（使用 `threading.Lock`）
- `FeishuBase` 的 token 续期也是线程安全的
- 可以安全地在多线程环境中共享客户端实例

## 参考文档

- **详细 API 参考**: 参见 [references/api-reference.md](references/api-reference.md)
- **配置示例**: 参见 [references/examples.md](references/examples.md)
- **故障排查**: 参见 [references/troubleshooting.md](references/troubleshooting.md)
