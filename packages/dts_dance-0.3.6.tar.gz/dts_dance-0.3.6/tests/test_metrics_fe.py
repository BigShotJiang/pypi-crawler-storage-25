import json
from config import ConfigLoader
from dtsdance.metrics_fe import MetricTypeEnum, MetricsClient, MetricEnvInfo

loader = ConfigLoader.get_instance()
loader.load_from_file()

metrics_fe_configs: dict[str, MetricEnvInfo] = {
    env.name: MetricEnvInfo(name=env.name, ak=env.ak, sk=env.sk, endpoint=env.endpoint) for env in loader.get_metrics_fe_configs()
}
metrics_client = MetricsClient(metrics_fe_configs)


# pytest tests/test_metrics_fe.py::test_get_dflow_task_metrics -s
def test_get_dflow_task_metrics():
    result = metrics_client.get_dflow_task_metrics(
        "China-North", "110853187302914", MetricTypeEnum.DFLOW_CONSUME_DELAY, "2026-04-03 19:40:00", "2026-04-03 20:40:00", downsample="1m-max"
    )
    print(json.dumps(result, indent=2))
