from dtsdance.bytecloud import ByteCloudClient
from config import ConfigLoader

loader = ConfigLoader.get_instance()
loader.load_from_file(["boe", "cn", "i18n-tt", "i18n-bd", "us-ttp"])
site_configs = loader.get_site_configs()
bytecloud_client = ByteCloudClient(site_configs)


# pytest tests/test_bytecloud.py::test_get_jwt_token -s
def test_get_jwt_token():
    jwt_token = bytecloud_client.get_jwt_token("i18n-tt")
    print(f"JWT Token: {jwt_token}")
