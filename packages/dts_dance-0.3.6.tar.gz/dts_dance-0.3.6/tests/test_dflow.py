import json
from dtsdance.bytedts_dflow import OPERATE_TYPE, DFlowClient
from dtsdance.bytecloud import ByteCloudClient
from config import ConfigLoader

loader = ConfigLoader.get_instance()
loader.load_from_file(["boe", "cn", "i18n-tt", "i18n-bd", "us-ttp"])
site_configs = loader.get_site_configs()
bytecloud_client = ByteCloudClient(site_configs)
dflow_client = DFlowClient(bytecloud_client)


# pytest tests/test_dflow.py::test_get_task_info -s
def test_get_task_info():
    # info = dflow_client.get_task_info("cn", "106037095986690")
    info = dflow_client.get_task_info("cn", "10457709471247")
    print(f"DFlow Info: {info}")


# pytest tests/test_dflow.py::test_count_dflow_list -s
def test_count_dflow_list():
    count = dflow_client.count_dflow_list("cn", "100816481778434", "cn_north_abase_sub6")
    print(f"DFlow Count: {count}")


# pytest tests/test_dflow.py::test_list_resources -s
def test_list_resources():
    resources = dflow_client.list_resources("cn", "China-East", "cn_east")
    print(f"list_resources: {json.dumps(resources, indent=2)}")


# pytest tests/test_dflow.py::test_get_all_ctrl_envs -s
def test_get_all_ctrl_envs():
    # ctrl_envs = dflow_client.get_all_ctrl_envs("boe")
    ctrl_envs = dflow_client.get_all_ctrl_envs("cn")
    # ctrl_envs = dflow_client.get_all_ctrl_envs("i18n-tt")
    # ctrl_envs = dflow_client.get_all_ctrl_envs("i18n-bd")
    # ctrl_envs = dflow_client.get_all_ctrl_envs("us-ttp")
    print(f"get_all_ctrl_envs: {json.dumps(ctrl_envs, indent=2)}")


# pytest tests/test_dflow.py::test_modify_task -s
def test_modify_task():
    result = dflow_client.modify_task("cn", 108139860865282, {"admin_list": ["bytedts", "dp_dorado_dts", "panailin.alin"]})
    print(f"result: {result}")


# pytest tests/test_dflow.py::test_operate_dflow -s
def test_operate_dflow():
    result = dflow_client.operate_dflow("cn", "12202291235599", "cn_east_volcommon", OPERATE_TYPE.RESTART, "China-East")
    print(f"result: {result}")
