import os
from typing import Optional
import boto3
from loguru import logger


class S3Client:
    """
    S3 兼容的对象存储客户端，支持文件上传功能
    """

    def __init__(self, access_key: str, secret_key: str, endpoint: str, region: str, bucket: str, base_url: str):
        self.bucket = bucket
        self.base_url = base_url
        self.s3_client = boto3.client(
            "s3",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            endpoint_url=endpoint,
            region_name=region,
        )

    def upload_file(self, local_file_path, s3_file_name=None, ExtraArgs=None) -> Optional[str]:
        if not self.s3_client:
            logger.error("S3 客户端未初始化")
            raise ValueError("S3 客户端未初始化")

        if s3_file_name is None:
            s3_file_name = os.path.basename(local_file_path)
        try:
            self.s3_client.upload_file(
                local_file_path,
                self.bucket,
                s3_file_name,
                ExtraArgs=ExtraArgs,
            )
            file_url = f"{self.base_url}/{s3_file_name}"
            logger.info(f"文件已成功上传到 S3: {file_url}")
            return file_url
        except Exception as e:
            logger.error(f"上传文件到 S3 时出错: {e}")
            return None

    def list_objects(self, prefix: str = "", max_keys: int = 1000) -> Optional[list]:
        """
        列出 bucket 中的对象

        Args:
            prefix: 对象前缀过滤
            max_keys: 最大返回数量

        Returns:
            对象键列表，失败返回 None
        """
        if not self.s3_client:
            logger.error("S3 客户端未初始化")
            raise ValueError("S3 客户端未初始化")

        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket,
                Prefix=prefix,
                MaxKeys=max_keys,
            )
            contents = response.get("Contents", [])
            keys = [obj["Key"] for obj in contents]
            logger.info(f"列出对象成功，数量: {len(keys)}")
            return keys
        except Exception as e:
            logger.error(f"列出 S3 对象时出错: {e}")
            return None

    def download_file(self, s3_file_name: str, local_file_path: str) -> bool:
        """
        从 S3 下载文件

        Args:
            s3_file_name: S3 中的对象键
            local_file_path: 本地保存路径

        Returns:
            是否下载成功
        """
        if not self.s3_client:
            logger.error("S3 客户端未初始化")
            raise ValueError("S3 客户端未初始化")

        try:
            self.s3_client.download_file(self.bucket, s3_file_name, local_file_path)
            logger.info(f"文件已成功下载到: {local_file_path}")
            return True
        except Exception as e:
            logger.error(f"从 S3 下载文件时出错: {e}")
            return False
