"""
Following Module

Provides access to follow group management functionality.
"""

from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from reportify_sdk.client import Reportify


FollowType = Literal["company", "channel"]


class FollowingModule:
    """
    Following module for managing follow groups

    Access through the main client:
        >>> client = Reportify(api_key="xxx")
        >>> groups = client.following.get_follow_groups()
    """

    def __init__(self, client: "Reportify"):
        self._client = client

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._get(path, params=params)

    def _post(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._post(path, json=json)

    def _put(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._put(path, json=json)

    def _delete(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._delete(path, params=params)

    def create_follow_group(
        self,
        name: str,
        follow_values: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        """
        Create a new follow group

        Args:
            name: Group name
            follow_values: List of follow values (each with 'follow_type' and 'follow_value')
                          follow_type: "company", "channel"

        Returns:
            Created group information including group_id, name, and count

        Example:
            >>> result = client.following.create_follow_group(
            ...     name="My Stocks",
            ...     follow_values=[
            ...         {"follow_type": "company", "follow_value": "US:AAPL"},
            ...         {"follow_type": "company", "follow_value": "HK:00700"}
            ...     ]
            ... )
            >>> print(f"Created group: {result['group_id']}")
        """
        json_data = {"name": name}
        if follow_values is not None:
            json_data["follow_values"] = follow_values
        return self._post("/v1/following/groups", json=json_data)

    def get_follow_groups(self) -> list[dict[str, Any]]:
        """
        Get all follow groups for the authenticated user

        Returns:
            List of follow groups with group_id, name, and count

        Example:
            >>> groups = client.following.get_follow_groups()
            >>> for group in groups:
            ...     print(f"{group['name']}: {group['count']} items")
        """
        response = self._get("/v1/following/groups")
        return response.get("groups", [])

    def get_follow_group(self, group_id: str) -> dict[str, Any]:
        """
        Get a follow group by ID

        Args:
            group_id: Group ID

        Returns:
            Group information including group_id, name, count, and follow_values

        Example:
            >>> group = client.following.get_follow_group("group_123")
            >>> print(f"{group['name']}: {group['count']} items")
            >>> for fv in group['follow_values']:
            ...     print(f"  - {fv['follow_type']}: {fv['follow_value']}")
        """
        return self._get(f"/v1/following/groups/{group_id}")

    def update_follow_group(
        self, group_id: str, name: str | None = None
    ) -> dict[str, Any]:
        """
        Update a follow group

        Args:
            group_id: Group ID
            name: New group name

        Returns:
            Updated group information

        Example:
            >>> result = client.following.update_follow_group("group_123", name="New Name")
            >>> print(f"Updated: {result['name']}")
        """
        json_data = {}
        if name is not None:
            json_data["name"] = name
        return self._post(f"/v1/following/groups/{group_id}", json=json_data)

    def delete_follow_group(self, group_id: str) -> dict[str, Any]:
        """
        Delete a follow group

        Args:
            group_id: Group ID

        Returns:
            Status message

        Example:
            >>> result = client.following.delete_follow_group("group_123")
            >>> print(result.get('message', 'Deleted'))
        """
        return self._delete(f"/v1/following/groups/{group_id}")

    def add_follows_to_group(
        self, group_id: str, follow_values: list[dict[str, str]]
    ) -> dict[str, Any]:
        """
        Add follows to a group

        Args:
            group_id: Group ID
            follow_values: List of follow values (each with 'follow_type' and 'follow_value')
                          follow_type: "company", "channel"

        Returns:
            Status message

        Example:
            >>> result = client.following.add_follows_to_group(
            ...     "group_123",
            ...     follow_values=[{"follow_type": "company", "follow_value": "US:TSLA"}]
            ... )
            >>> print(result.get('message', 'Added'))
        """
        return self._post(
            f"/v1/following/groups/{group_id}/follows",
            json={"follow_values": follow_values}
        )

    def remove_follows_from_group(
        self, group_id: str, follow_values: list[str]
    ) -> dict[str, Any]:
        """
        Remove follows from a group

        Args:
            group_id: Group ID
            follow_values: List of follow values to remove (e.g., stock symbols, channel IDs)

        Returns:
            Status message

        Example:
            >>> result = client.following.remove_follows_from_group("group_123", ["AAPL", "MSFT"])
            >>> print(result.get('message', 'Removed'))
        """
        return self._delete(
            f"/v1/following/groups/{group_id}/follows",
            params={"follow_values": follow_values}
        )

    def set_group_follows(
        self, group_id: str, follow_values: list[dict[str, str]]
    ) -> dict[str, Any]:
        """
        Set follows for a group (replace all existing follows)

        Args:
            group_id: Group ID
            follow_values: List of follow values (each with 'follow_type' and 'follow_value')
                          follow_type: "company", "channel"

        Returns:
            Status message

        Example:
            >>> result = client.following.set_group_follows(
            ...     "group_123",
            ...     follow_values=[
            ...         {"follow_type": "company", "follow_value": "US:AAPL"},
            ...         {"follow_type": "company", "follow_value": "HK:00700"}
            ...     ]
            ... )
            >>> print(result.get('message', 'Set'))
        """
        return self._put(
            f"/v1/following/groups/{group_id}/follows",
            json={"follow_values": follow_values}
        )

    def get_follow_group_docs(
        self, group_id: str, page_num: int = 1, page_size: int = 10
    ) -> dict[str, Any]:
        """
        Get docs for a follow group

        Args:
            group_id: Group ID
            page_num: Page number (default: 1)
            page_size: Page size (default: 10)

        Returns:
            Dictionary with items, total_count, page_num, and page_size

        Example:
            >>> result = client.following.get_follow_group_docs("group_123", page_num=1, page_size=20)
            >>> print(f"Total reports: {result['total_count']}")
        """
        params: dict[str, Any] = {"page_num": page_num, "page_size": page_size}
        return self._get(f"/v1/following/groups/{group_id}/docs", params=params)
