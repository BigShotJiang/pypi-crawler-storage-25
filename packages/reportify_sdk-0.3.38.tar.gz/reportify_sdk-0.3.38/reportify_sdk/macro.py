"""
Macro Module

Provides access to macroeconomic data including commodity prices.
Time series data is returned as pandas DataFrame.
"""

from typing import TYPE_CHECKING, Any, Literal

import pandas as pd

if TYPE_CHECKING:
    from reportify_sdk.client import Reportify


class MacroModule:
    """
    Macro data module for macroeconomic and commodity data

    Access through the main client:
        >>> client = Reportify(api_key="xxx")
        >>> oil = client.macro.commodities("oil", start_date="2026-02-01", end_date="2026-02-09")
    """

    def __init__(self, client: "Reportify"):
        self._client = client

    def _post(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._post(path, json=json)

    # -------------------------------------------------------------------------
    # Commodities
    # -------------------------------------------------------------------------

    def commodities(
        self,
        type: Literal["oil", "gold", "gas", "silver", "platinum"],
        *,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """
        Get commodity price data

        Args:
            type: Commodity type
                - "oil": WTI and Brent crude oil spot prices (USD/barrel)
                - "gold": Shanghai gold (CNY) and London gold LBMA (USD/oz)
                - "gas": Henry Hub natural gas spot price (USD/MMBtu)
                - "silver": London silver price (USD/oz)
                - "platinum": London platinum price (USD/oz)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
                The interval between start and end must not exceed 10 years.

        Returns:
            DataFrame with commodity price data, indexed by date.
            Columns vary by type:
            - oil: wti_co_sp, brent_co_sp
            - gold: lbma_pm_usd, sge_pm_cny
            - gas: hh_ng_sp
            - silver: si_eur
            - platinum: pl_usd

        Example:
            >>> oil = client.macro.commodities("oil", start_date="2026-02-01", end_date="2026-02-09")
            >>> print(oil[["wti_co_sp", "brent_co_sp"]].head())

            >>> gold = client.macro.commodities("gold", start_date="2026-02-01", end_date="2026-02-09")
            >>> print(gold[["lbma_pm_usd", "sge_pm_cny"]].head())
        """
        data: dict[str, Any] = {
            "type": type,
            "start_date": start_date,
            "end_date": end_date,
        }

        response = self._post("/v1/stock/macro-commodities", json=data)
        return self._to_dataframe(response)

    # -------------------------------------------------------------------------
    # Helper Methods
    # -------------------------------------------------------------------------

    def _to_dataframe(self, data: Any) -> pd.DataFrame:
        """Convert API response to DataFrame"""
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, dict):
            if "data" in data:
                inner_data = data["data"]
                if isinstance(inner_data, dict) and "items" in inner_data:
                    df = pd.DataFrame(inner_data["items"])
                elif isinstance(inner_data, list):
                    df = pd.DataFrame(inner_data)
                elif isinstance(inner_data, dict):
                    df = pd.DataFrame([inner_data])
                else:
                    df = pd.DataFrame([data])
            elif "items" in data:
                df = pd.DataFrame(data["items"])
            else:
                df = pd.DataFrame([data])
        else:
            df = pd.DataFrame()

        # Set date column as index if present
        if "date" in df.columns:
            try:
                df["date"] = pd.to_datetime(df["date"])
                df = df.set_index("date")
            except (ValueError, TypeError):
                pass

        return df
