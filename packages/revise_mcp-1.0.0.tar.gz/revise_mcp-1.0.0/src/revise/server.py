"""MCP server setup and tool registration."""

from mcp.server.fastmcp import FastMCP

# Create FastMCP server instance
mcp = FastMCP(
    name='revise',
    instructions='Tools to revise/refactor code'
)

# Import tools to register them via decorators
# (These imports will execute the @mcp.tool() decorators)
import revise.tools.rename_symbol  # noqa: E402, F401
import revise.tools.move_string_in_file  # noqa: E402, F401
import revise.tools.indent_dedent  # noqa: E402, F401
import revise.tools.outline_file  # noqa: E402, F401
