"""Shared indentation utilities."""


def detect_indent(content: str) -> int | str | None:
    """
    Auto-detect the indentation style of a file's content.

    Returns:
        int: Number of spaces per indent level (e.g., 2, 4, 6, 8).
        str: '\\t' for tab indentation.
        None: If auto-detection is inconclusive.
    """
    # Candidate indent styles, ordered from largest to smallest.
    # Ties are broken in favor of larger sizes (checked first).
    candidates = ['\t', 8, 6, 4, 2]
    tallies = {c: 0 for c in candidates}

    for line in content.split('\n'):
        if not line or line.isspace():
            continue
        leading = len(line) - len(line.lstrip())
        if leading == 0:
            continue

        # Check tab indentation
        if line[0] == '\t':
            tallies['\t'] += 1
            continue

        # Check space-based candidates
        for size in [8, 6, 4, 2]:
            if leading % size == 0:
                tallies[size] += 1

    # Find the winner
    best = None
    best_count = 0
    for candidate in candidates:
        count = tallies[candidate]
        if count > best_count:
            best_count = count
            best = candidate

    if best_count == 0:
        return None

    return best


def resolve_indent_unit(indent_size: int | str) -> str:
    """
    Convert an indent size to the concrete string to prepend/remove.

    Examples:
        resolve_indent_unit(4) -> '    '
        resolve_indent_unit('\\t') -> '\\t'
    """
    if isinstance(indent_size, str) and indent_size == '\t':
        return '\t'
    return ' ' * indent_size
