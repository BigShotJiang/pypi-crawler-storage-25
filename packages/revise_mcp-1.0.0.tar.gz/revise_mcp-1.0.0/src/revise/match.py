"""Shared utilities for ⬥-based substring matching and context expansion."""

import json

MARKER = '⬥'

# Minimum number of non-whitespace characters to include in expanded context.
# Tunable; chosen to balance uniqueness vs. brevity.
MIN_NONWHITESPACE_CONTEXT = 20


def parse_context_around_marker(input: str) -> tuple[str, str] | None:
    """
    Splits an input string at the ⬥ marker.

    Returns (before_context, after_context), or None if the input
    does not contain exactly one ⬥.
    """
    parts = input.split(MARKER)
    if len(parts) != 2:
        return None
    return (parts[0], parts[1])


def find_marker_positions(content: str, before_context: str, after_context: str) -> list[int]:
    """
    Searches content for all occurrences of before_context + after_context
    and returns a list of character offsets corresponding to the ⬥ position
    (i.e., match_start + len(before_context)).

    If no exact match is found, retries with trailing whitespace (spaces and
    tabs) stripped from both the content and the search string, mapping any
    match positions back to original file offsets.
    """
    search_string = before_context + after_context
    if not search_string:
        return []
    positions = []
    start = 0
    while True:
        idx = content.find(search_string, start)
        if idx == -1:
            break
        positions.append(idx + len(before_context))
        start = idx + 1

    if positions:
        return positions

    # Fallback: try normalized matching (trailing whitespace ignored)
    return _find_marker_positions_normalized(content, before_context, after_context)


def _find_marker_positions_normalized(
    content: str, before_context: str, after_context: str
) -> list[int]:
    """
    Like find_marker_positions but strips trailing spaces/tabs from each line
    in both content and search string before matching.  Positions are mapped
    back to original content offsets.
    """
    norm_content, offset_map = _build_normalized_mapping(content)
    norm_before = _strip_trailing_whitespace(before_context)
    norm_after = _strip_trailing_whitespace(after_context)
    norm_search = norm_before + norm_after

    if not norm_search:
        return []

    positions = []
    start = 0
    while True:
        idx = norm_content.find(norm_search, start)
        if idx == -1:
            break
        norm_marker_pos = idx + len(norm_before)
        positions.append(offset_map[norm_marker_pos])
        start = idx + 1
    return positions


def _build_normalized_mapping(content: str) -> tuple[str, list[int]]:
    """
    Build a normalized version of content with trailing spaces and tabs
    removed from each line, plus a mapping from normalized offsets to
    original offsets.

    Returns (normalized_content, offset_map) where offset_map[i] gives
    the original offset corresponding to normalized offset i.
    offset_map has length len(normalized_content) + 1.
    """
    normalized_chars: list[str] = []
    offset_map: list[int] = []
    i = 0
    while i < len(content):
        newline_pos = content.find('\n', i)
        if newline_pos == -1:
            # Last line with no trailing newline
            line = content[i:]
            stripped = line.rstrip(' \t')
            for j in range(len(stripped)):
                normalized_chars.append(content[i + j])
                offset_map.append(i + j)
            break
        else:
            line = content[i:newline_pos]
            stripped = line.rstrip(' \t')
            for j in range(len(stripped)):
                normalized_chars.append(content[i + j])
                offset_map.append(i + j)
            normalized_chars.append('\n')
            offset_map.append(newline_pos)
            i = newline_pos + 1
    # End-of-content sentinel
    offset_map.append(len(content))
    return (''.join(normalized_chars), offset_map)


def _strip_trailing_whitespace(s: str) -> str:
    """Strip trailing spaces and tabs from each line in s."""
    lines = s.split('\n')
    return '\n'.join(line.rstrip(' \t') for line in lines)


def offset_to_line_col(content: str, offset: int) -> tuple[int, int]:
    """
    Converts a 0-based character offset to a (line, column) pair,
    both 1-indexed.
    """
    line = content[:offset].count('\n') + 1
    last_newline = content.rfind('\n', 0, offset)
    if last_newline == -1:
        col = offset + 1
    else:
        col = offset - last_newline
    return (line, col)


def expand_context(
    content: str,
    offset: int,
    min_nonwhitespace: int = MIN_NONWHITESPACE_CONTEXT,
) -> str:
    """
    Expands outward from offset in both directions, consuming full lines,
    until at least min_nonwhitespace non-whitespace characters are accumulated.
    Returns the expanded context string with a ⬥ inserted at offset.
    """
    # Find the line boundaries containing the offset
    line_start = content.rfind('\n', 0, offset)
    # line_start is the index of the \n before this line, or -1 if first line
    # We want to include from that \n (or from 0)
    if line_start == -1:
        expand_start = 0
    else:
        expand_start = line_start  # include the \n

    line_end = content.find('\n', offset)
    if line_end == -1:
        expand_end = len(content)
    else:
        expand_end = line_end + 1  # include the \n

    while True:
        region = content[expand_start:expand_end]
        nonws = sum(1 for c in region if not c.isspace())
        if nonws >= min_nonwhitespace:
            break

        expanded = False
        # Expand backward one line
        if expand_start > 0:
            prev_newline = content.rfind('\n', 0, expand_start)
            if prev_newline == -1:
                expand_start = 0
            else:
                expand_start = prev_newline
            expanded = True

        # Expand forward one line
        if expand_end < len(content):
            next_newline = content.find('\n', expand_end)
            if next_newline == -1:
                expand_end = len(content)
            else:
                expand_end = next_newline + 1
            expanded = True

        if not expanded:
            break

    # Insert ⬥ at the offset position within the region
    marker_pos = offset - expand_start
    region = content[expand_start:expand_end]
    return region[:marker_pos] + MARKER + region[marker_pos:]


def extract_sub_contexts(before_context: str, after_context: str) -> list[str]:
    """
    Extracts simplified sub-contexts for fallback searching when
    the full context doesn't match.

    Returns a list of up to two sub-context strings to try in order:
    1. Following-line: the first (possibly partial) line of after_context,
       including the trailing newline.
    2. Preceding-line: the last (possibly partial) line of before_context,
       including the leading newline.

    Each sub-context is only included if it differs from the full input
    and is not entirely whitespace. The returned strings include the ⬥
    marker at the appropriate position.
    """
    full_input = before_context + MARKER + after_context
    results = []

    # 1. Following-line sub-context
    if after_context:
        newline_idx = after_context.find('\n')
        if newline_idx != -1:
            following = after_context[:newline_idx + 1]
        else:
            following = after_context
        sub = MARKER + following
        if sub != full_input and not following.isspace() and following:
            results.append(sub)

    # 2. Preceding-line sub-context
    if before_context:
        # Strip trailing newlines to find the last content line
        stripped = before_context.rstrip('\n')
        if stripped:
            newline_idx = stripped.rfind('\n')
            if newline_idx != -1:
                line_text = stripped[newline_idx + 1:]
            else:
                line_text = stripped
            # Build sub-context with line bounded by \n
            sub = '\n' + line_text + '\n' + MARKER
            if sub != full_input and line_text.strip():
                results.append(sub)

    return results


def offset_to_line_bounds(content: str, offset: int) -> tuple[int, int]:
    """
    Returns (line_start, line_end) character offsets for the line containing `offset`.

    line_start: offset of the first character on the line (after the preceding \\n, or 0).
    line_end: offset of the \\n terminating the line (or len(content) if last line has no \\n).
    """
    last_newline = content.rfind('\n', 0, offset)
    if last_newline == -1:
        line_start = 0
    else:
        line_start = last_newline + 1

    next_newline = content.find('\n', offset)
    if next_newline == -1:
        line_end = len(content)
    else:
        line_end = next_newline

    return (line_start, line_end)


def snap_to_line_start(content: str, offset: int) -> int:
    """Snap an offset to the start of its containing line."""
    newline_pos = content.rfind('\n', 0, offset)
    return newline_pos + 1 if newline_pos != -1 else 0


def is_line_boundary(content: str, offset: int) -> bool:
    """Check whether an offset falls on a line boundary."""
    if offset == 0 or offset == len(content):
        return True
    return content[offset - 1] == '\n'


def count_blank_lines_before(content: str, offset: int) -> int:
    """Count consecutive blank lines immediately before the given offset.

    The offset should be at a line boundary (start of a line or end of file).
    A blank line is a line containing only whitespace.
    """
    count = 0
    pos = offset
    while pos > 0 and content[pos - 1] == '\n':
        newline_before = content.rfind('\n', 0, pos - 1)
        line_start = newline_before + 1
        line_content = content[line_start:pos - 1]
        if line_content.strip() == '':
            count += 1
            pos = line_start
        else:
            break
    return count


def count_blank_lines_after(content: str, offset: int) -> int:
    """Count consecutive blank lines immediately after the given offset.

    The offset should be at a line boundary (start of a line or end of file).
    A blank line is a line containing only whitespace.
    """
    count = 0
    pos = offset
    while pos < len(content):
        newline_pos = content.find('\n', pos)
        if newline_pos == -1:
            line_content = content[pos:]
            if line_content.strip() == '':
                count += 1
            break
        else:
            line_content = content[pos:newline_pos]
            if line_content.strip() == '':
                count += 1
                pos = newline_pos + 1
            else:
                break
    return count


def error_response(message: str) -> str:
    """Create a JSON error response with just a message."""
    return json.dumps({'success': False, 'message': message}, indent=2)


def check_unique_match(
    positions: list[int],
    param_name: str,
    content: str,
    before_context: str,
    after_context: str,
) -> str | None:
    """
    Validate that exactly one match was found for a ⬥-based boundary.
    Returns an error JSON string if validation fails, or None if OK.
    """
    if len(positions) == 1:
        return None

    if len(positions) > 1:
        # Ambiguous match
        matching_lines = {}
        for pos in positions:
            line, _ = offset_to_line_col(content, pos)
            matching_lines[str(line)] = expand_context(content, pos)
        return json.dumps({
            'success': False,
            'message': (
                f'Provided `{param_name}` was found in multiple locations. '
                f'Try again with additional context to disambiguate.'
            ),
            'matchingLines': matching_lines,
        }, indent=2)

    # No match — try sub-context fallback
    sub_contexts = extract_sub_contexts(before_context, after_context)

    sub_results = []
    for sub in sub_contexts:
        sub_parsed = parse_context_around_marker(sub)
        if sub_parsed is None:
            continue
        sub_before, sub_after = sub_parsed
        sub_positions = find_marker_positions(content, sub_before, sub_after)
        if sub_positions:
            # Sub-context matched — report its locations
            sub_matching_lines = {}
            for pos in sub_positions:
                line, _ = offset_to_line_col(content, pos)
                sub_matching_lines[str(line)] = expand_context(content, pos)
            return json.dumps({
                'success': False,
                'message': (
                    f'Provided `{param_name}` was not found. '
                    f'However the sub-context {repr(sub)} was found in the following locations. '
                    f'Try again with different context.'
                ),
                'subContextMatchingLines': sub_matching_lines,
            }, indent=2)
        else:
            sub_results.append(sub)

    # No sub-context matched either
    if sub_results:
        if len(sub_results) == 1:
            return error_response(
                f'Provided `{param_name}` was not found. '
                f'The sub-context {repr(sub_results[0])} was also not found. '
                f'Try again with different context.'
            )
        else:
            quoted = ' and '.join(repr(s) for s in sub_results)
            return error_response(
                f'Provided `{param_name}` was not found. '
                f'The sub-contexts {quoted} were also not found. '
                f'Try again with different context.'
            )

    return error_response(
        f'Provided `{param_name}` was not found. '
        f'Try again with different context.'
    )
