"""Entry point for the Revise MCP server."""


def main() -> None:
    """Run the MCP server using stdio transport (default)."""
    # Supports optional --transport flag for development/testing.
    # Examples:
    #   python -m revise                           # stdio (default)
    #   python -m revise --transport streamable-http  # HTTP on port 8000
    #   python -m revise --transport sse           # SSE transport
    
    # FastMCP's run() supports transport selection via command-line args
    from revise.server import mcp
    mcp.run()


if __name__ == '__main__':
    main()
