"""
The outline_file tool: show a file's high-level structure (like VS Code's folded view).
"""

import re
import sys
from pathlib import Path
from typing import Annotated


# === CLI Entrypoint ===

def _main() -> None:
    if len(sys.argv) != 2:
        print('Usage: python -m revise.tools.outline_file <file>', file=sys.stderr)
        sys.exit(1)

    path = Path(sys.argv[1])
    try:
        content = path.read_text()
    except FileNotFoundError:
        print(f'Error: File not found: {path}', file=sys.stderr)
        sys.exit(1)

    print(_compute_outline(content), end='')


# === Tool Definition ===

# Don't import revise.server when running as CLI to avoid starting the MCP server
if __name__ != '__main__':
    from revise.match import error_response
    from revise.server import mcp

    @mcp.tool()
    async def outline_file(
        filePath: Annotated[
            str,
            'Absolute path to the file to outline.'
        ],
    ) -> str:
        """\
        Returns a high-level outline of a file, similar to VS Code's folded view.

        Shows only structurally significant lines:
        - class and def definitions (at any indentation level)
        - Section separator comments (# === ... or # --- ... prefix, at any indentation)
        - Section name comments that immediately follow a pure separator line

        Output format: "LINE_NUMBER:LINE_CONTENT" (1-indexed), one per line.
        Useful for understanding the structure of a large file before reading it in full.
        """
        try:
            content = Path(filePath).read_text()
        except FileNotFoundError:
            return error_response(f'File not found: {filePath}')

        return _compute_outline(content)


# === Outline Logic ===

# Matches structurally significant lines: class/def definitions and section
# separator comments (# --- or # === as a prefix, at any indentation level).
_OUTLINE_RE = re.compile(r'^[ \t]*(async\s+def\s|def\s|class\s|# ===|# ---|if\s+__name__\s*[!=]=)')
# Separator lines are a subset of outline lines (triggers section-name peek)
_SEPARATOR_RE = re.compile(r'^[ \t]*(# ===|# ---)')


def _compute_outline(content: str) -> str:
    """
    Compute the outline of a file's content.

    Returns lines of the form "LINE_NUMBER:LINE_CONTENT" (1-indexed), joined by newlines.
    Includes class/def definitions and section separator comments (# --- / # ===).
    When a separator comment is found, also includes the immediately following line
    if it looks like a section name (a non-separator comment starting with "# ").
    """
    lines = content.splitlines()
    output: list[str] = []

    i = 0
    while i < len(lines):
        line = lines[i]
        lineno = i + 1

        if _OUTLINE_RE.match(line):
            output.append(f'{lineno}:{line}')

            # For separator lines, peek at the next line for a section name
            if _SEPARATOR_RE.match(line) and i + 1 < len(lines):
                next_line = lines[i + 1]
                # Include if it's a comment with content but not itself a separator
                if next_line.startswith('# ') and not _SEPARATOR_RE.match(next_line):
                    i += 1
                    output.append(f'{i + 1}:{lines[i]}')

        i += 1

    return '\n'.join(output) + '\n' if output else ''


# === CLI Entrypoint ===

if __name__ == '__main__':
    _main()
