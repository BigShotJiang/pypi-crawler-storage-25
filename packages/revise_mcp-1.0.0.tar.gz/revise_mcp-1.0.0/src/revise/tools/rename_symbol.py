"""
The rename_symbol tool: AI-agent-friendly symbol renaming.
"""

from pathlib import Path
from typing import Annotated, Any
import re
import json

from revise.server import mcp
from revise.vscode_client import call_vscode_tool


# === Tool Definition ===

@mcp.tool()
def rename_symbol(
    filePath: Annotated[
        str,
        'Absolute path to the file containing the symbol to rename'
    ],
    oldString: Annotated[
        str,
        "Line fragment containing the original symbol name. Must be unique within the file (or within the specified line). Example: 'def mocked_show_modal('"
    ],
    newString: Annotated[
        str,
        "Line fragment with all occurrences of the symbol renamed. Example: 'def mocked_show_modal_renamed('"
    ],
    line: Annotated[
        int | None,
        'Optional 1-indexed line number to limit search for oldString. Use when oldString appears on multiple lines.'
    ] = None
) -> str:
    """\
    Renames a symbol (function, variable, class, etc.) and all its references across the workspace.

    Uses text-based matching to locate the symbol—no coordinate counting required.

    Example:
        filePath: "/path/to/file.py"
        oldString: "def helper_function("
        newString: "def _helper_function("

        This will rename helper_function to _helper_function everywhere it's referenced.
    """
    file_path = filePath
    old_string = oldString
    new_string = newString
    target_line = line  # 1-indexed, optional

    # Step 1: Read the file
    try:
        content = Path(file_path).read_text()
    except FileNotFoundError:
        return _error_json({'success': False, 'message': f'File not found: {file_path}'})
    except Exception as e:
        return _error_json({'success': False, 'message': f'Error reading file: {e}'})
    lines = content.splitlines()

    # Step 2: Find matching lines
    matching = []  # List of (line_number_1indexed, line_content)
    for i, line_content in enumerate(lines, start=1):
        if old_string in line_content:
            if target_line is None or target_line == i:
                matching.append((i, line_content))
    if not matching:
        return _error_json({
            'success': False,
            'message': 'Provided `oldString` was not found in the file.',
            'matchingLines': {}
        })

    # Step 3: Handle multiple matches
    if len(matching) > 1:
        # TODO: Check if all matches reference the same symbol using find_references
        # For now, require disambiguation
        matching_lines = {str(ln): content for ln, content in matching}
        return _error_json({
            'success': False,
            'message': (
                'Provided `oldString` was found in multiple locations. '
                'Try again with additional context in `oldString` to disambiguate. '
                'Or try again with `line` limited to one of the following matching lines:'
            ),
            'matchingLines': matching_lines
        })
    # Single match found
    line_num, line_content = matching[0]

    # Step 4: Extract symbol name by diffing old and new strings
    result = _extract_symbol_rename(old_string, new_string)
    if result is None:
        return _error_json({
            'success': False,
            'message': (
                'Ambiguous rename detected. Problems:\n'
                ' \u2022 Not all symbol occurrences in `oldString` were renamed in `newString`, OR\n'
                ' \u2022 Some renamed occurrences refer to different symbols, OR\n'
                ' \u2022 Multiple distinct symbols are being renamed\n'
                'Tip: Ensure exactly one symbol is renamed across all its occurrences.'
            ),
            'matchingLines': {str(line_num): line_content}
        })
    old_name, new_name = result

    # Step 5: Find character position of symbol in line
    char_pos = line_content.find(old_name)
    if char_pos == -1:
        # Shouldn't happen if extract worked, but be defensive
        char_pos = line_content.find(old_string)
        if char_pos == -1:
            char_pos = 0

    # Step 6: Call VSCode rename_symbol
    try:
        vscode_result = call_vscode_tool('rename_symbol', {
            'uri': file_path,
            'line': line_num - 1,  # Convert to 0-indexed
            'character': char_pos,
            'newName': new_name
        })
    except Exception as e:
        error_msg = str(e)
        if 'connection' in error_msg.lower() or 'refused' in error_msg.lower():
            return _error_json({
                'success': False,
                'message': (
                    'Cannot connect to VSCode MCP server at http://localhost:4000/mcp. '
                    'Ensure the "VSC as MCP" extension is installed and VS Code is running.'
                )
            })
        return _error_json({'success': False, 'message': f'VSCode rename failed: {error_msg}'})

    # Step 7: Transform response
    return _transform_response(vscode_result)


# === Utility ===

def _extract_symbol_rename(old_string: str, new_string: str) -> tuple[str, str] | None:
    """
    Extract the (old_name, new_name) from oldString/newString pair.

    Returns None if the rename is ambiguous or invalid.
    """
    # Find all identifier-like tokens in both strings
    identifier_pattern = r'\b([a-zA-Z_][a-zA-Z0-9_]*)\b'
    old_tokens = re.findall(identifier_pattern, old_string)
    new_tokens = re.findall(identifier_pattern, new_string)

    if len(old_tokens) != len(new_tokens):
        return None

    # Find which token(s) changed
    changes = []
    for old_tok, new_tok in zip(old_tokens, new_tokens):
        if old_tok != new_tok:
            changes.append((old_tok, new_tok))

    if len(changes) == 0:
        return None  # Nothing changed

    # All changes must be for the same symbol
    old_names = set(c[0] for c in changes)
    new_names = set(c[1] for c in changes)

    if len(old_names) != 1 or len(new_names) != 1:
        return None  # Multiple different symbols changed

    return (changes[0][0], changes[0][1])


def _transform_response(vscode_result: dict[str, Any]) -> str:
    """Transform VSCode's response to our concise format."""
    # The VSC as MCP extension returns tool results as content blocks
    # Parse the content to extract change information
    content = vscode_result.get('content', [])

    # Extract text content from the response
    text_parts = []
    for item in content:
        if isinstance(item, dict) and item.get('type') == 'text':
            text_parts.append(item.get('text', ''))
    if not text_parts:
        # If no content blocks, try treating vscode_result itself as the data
        if vscode_result.get('isError', False):
            error_text = ''
            for item in content:
                if isinstance(item, dict):
                    error_text += item.get('text', '')
            return _error_json({
                'success': False,
                'message': f'Rename operation failed: {error_text or "Unknown error"}'
            })
        return _transform_success_from_raw(vscode_result)

    # Try to parse the text content
    full_text = '\n'.join(text_parts)
    if vscode_result.get('isError', False):
        # Response indicates an error
        return _error_json({
            'success': False,
            'message': f'Rename operation failed: {full_text}'
        })
    try:
        # Try to parse as JSON first
        parsed = json.loads(full_text)
        return _transform_success_from_raw(parsed)
    except (json.JSONDecodeError, ValueError):
        # The response is likely a text description of changes
        # Return success with the raw text as the message
        return json.dumps({
            'success': True,
            'message': full_text
        }, indent=2)


def _transform_success_from_raw(vscode_result: dict[str, Any]) -> str:
    """Transform a parsed VSCode result into our concise format."""
    changes_raw = vscode_result.get('changes', [])

    if not changes_raw and not vscode_result.get('documentChanges', []):
        # No structured changes available; return what we have
        return json.dumps({
            'success': True,
            'message': 'Rename completed (no detailed change info available)'
        }, indent=2)

    # Handle documentChanges format (used by some LSP implementations)
    if not changes_raw:
        changes_raw = vscode_result.get('documentChanges', [])

    # Collect all file paths and their changes
    file_changes: dict[str, dict] = {}
    for change in changes_raw:
        uri = change.get('uri', change.get('textDocument', {}).get('uri', ''))
        # Convert file:// URI to path
        if uri.startswith('file://'):
            path = uri[7:]  # Remove 'file://'
        else:
            path = uri

        edits = change.get('edits', [])
        lines = set()
        for edit in edits:
            rng = edit.get('range', {})
            # Handle both nested format (start.line) and flat format (startLine)
            if 'start' in rng:
                line = rng['start'].get('line', 0) + 1
            else:
                line = rng.get('startLine', 0) + 1
            lines.add(line)

        file_changes[path] = {
            'lines': sorted(lines),
            'count': len(edits)
        }

    # Extract common path prefix
    if file_changes:
        paths = list(file_changes.keys())
        start_directory = _common_path_prefix(paths)

        # Shorten paths relative to start_directory
        if start_directory:
            shortened = {}
            for path, data in file_changes.items():
                short_path = path[len(start_directory):]
                if short_path.startswith('/'):
                    short_path = short_path[1:]
                shortened[short_path] = data
            file_changes = shortened
    else:
        start_directory = None

    # Calculate totals
    total_files = len(file_changes)
    total_changes = sum(c['count'] for c in file_changes.values())

    message = f'Successfully renamed symbol in {total_files} file(s) with {total_changes} change(s)'

    # Build compact JSON with each file change on one line.
    # This improves readability/scannability when many files are changed,
    # allowing all files to be visible at once without scrolling.
    changes_lines = []
    for filename, data in file_changes.items():
        # Compact format: {"lines": [...], "count": N}
        compact = json.dumps(data, separators=(', ', ': '))
        changes_lines.append(f'    {json.dumps(filename)}: {compact}')
    changes_str = ',\n'.join(changes_lines)

    # Manually construct the result JSON with custom formatting
    result_str = '{\n'
    result_str += '  "success": true,\n'
    result_str += f'  "startDirectory": {json.dumps(start_directory)},\n'
    result_str += '  "changes": {\n'
    result_str += changes_str + '\n'
    result_str += '  },\n'
    result_str += f'  "message": {json.dumps(message)}\n'
    result_str += '}'

    return result_str


def _common_path_prefix(paths: list[str]) -> str | None:
    """Find the longest common directory prefix of the given paths."""
    if not paths:
        return None

    # Get the directory portion of each path (exclude filename)
    dir_paths = [str(Path(p).parent) for p in paths]

    # Split each directory path into components
    split_paths = [Path(d).parts for d in dir_paths]

    # Find common prefix
    common = []
    for parts in zip(*split_paths):
        if len(set(parts)) == 1:
            common.append(parts[0])
        else:
            break
    if not common:
        return None

    result = str(Path(*common))
    # Ensure trailing slash for directories
    if not result.endswith('/'):
        result += '/'
    return result


def _error_json(result: dict[str, Any]) -> str:
    """Create an error response as JSON string."""
    return json.dumps(result, indent=2)
