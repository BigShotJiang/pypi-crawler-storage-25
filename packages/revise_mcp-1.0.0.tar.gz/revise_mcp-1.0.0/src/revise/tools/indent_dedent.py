"""
The indent_dedent tool: AI-agent-friendly line indentation and unindentation.
"""

from pathlib import Path
from typing import Annotated
import json

from revise.server import mcp
from revise.match import (
    MARKER,
    parse_context_around_marker,
    find_marker_positions,
    check_unique_match,
    offset_to_line_col,
    offset_to_line_bounds,
    expand_context,
    error_response,
)
from revise.indent import detect_indent, resolve_indent_unit


# === Tool Definition ===

@mcp.tool()
async def indent_dedent(
    filePath: Annotated[
        str,
        'Absolute path to the file to edit.'
    ],
    indentStartAt: Annotated[
        str,
        'Substring fragment identifying the first line to indent/unindent. '
        'The ⬥ character marks a position on the target line. '
        'The entire line containing the ⬥ position is the first line of the range. '
        "Example: '# Create home URL\\n⬥' — the line after '# Create home URL' is "
        'the first indented line. '
        'No ⬥ is needed if the context is within a single line only (no \\n).'
    ],
    indentEndAt: Annotated[
        str,
        'Substring fragment identifying the last line to indent/unindent. '
        'The ⬥ character marks a position on the target line. '
        'The entire line containing the ⬥ position is the last line of the range. '
        "Example: '(home_ti,) = root_ti.Children⬥\\n'. "
        'No ⬥ is needed if the context is within a single line only (no \\n).'
    ],
    indentDelta: Annotated[
        int,
        'Number of indent levels to add (positive) or remove (negative). '
        'Example: 1 to indent one level, -1 to unindent one level.'
    ],
    indentSize: Annotated[
        int | str | None,
        'Optional. Number of spaces per indent level (e.g., 4), or "\\t" for tab '
        'indentation. If omitted, auto-detected from the most common indent pattern '
        'across the entire file.'
    ] = None,
) -> str:
    # NOTE: Can't use an f-string to use "{MARKER}" rather than "⬥" because
    #       only regular strings work as docstrings
    """\
    Indents or unindents a range of lines in a file.

    Specify the range using substring matching with a ⬥ marker.
    The ⬥ identifies which line is the boundary — the full line containing
    the ⬥ is included in the range.

    Common pattern — indent a block, then wrap it:
        1. indent_dedent(indentStartAt="# Create home URL\\n⬥", ..., indentDelta=1)
        2. replace_string_in_file to insert "if True:" before the indented block

    ⬥ in boundaries anywhere on a line marks the line to indent when the context contains multiple lines.
    No ⬥ is needed if the context is within a single line only.

    Whitespace at the end of lines is ignored when matching substrings.

    Empty lines within the range are left unchanged (no whitespace added).
    Non-empty lines (including whitespace-only lines) are indented/unindented.
    """
    # Step 1: Validate markers
    start_parsed = _parse_indent_boundary(indentStartAt)
    if start_parsed is None:
        return error_response(
            f'Provided `indentStartAt` must contain exactly one {MARKER} marker, '
            f'or be a single-line fragment (no \\n) with no {MARKER}.'
        )

    end_parsed = _parse_indent_boundary(indentEndAt)
    if end_parsed is None:
        return error_response(
            f'Provided `indentEndAt` must contain exactly one {MARKER} marker, '
            f'or be a single-line fragment (no \\n) with no {MARKER}.'
        )

    # Step 2: Validate indentDelta
    if indentDelta == 0:
        return error_response(
            'Provided `indentDelta` must be a non-zero integer.'
        )

    # Step 3: Read the file
    try:
        content = Path(filePath).read_text()
    except FileNotFoundError:
        return error_response(f'File not found: {filePath}')

    # Step 4-5: Find indentStartAt position
    start_before, start_after = start_parsed
    start_positions = find_marker_positions(content, start_before, start_after)
    err = check_unique_match(
        start_positions, 'indentStartAt', content, start_before, start_after
    )
    if err is not None:
        return err

    # Step 6: Find indentEndAt position
    end_before, end_after = end_parsed
    end_positions = find_marker_positions(content, end_before, end_after)
    err = check_unique_match(
        end_positions, 'indentEndAt', content, end_before, end_after
    )
    if err is not None:
        return err

    start_offset = start_positions[0]
    end_offset = end_positions[0]

    # Step 7: Determine line ranges
    start_line_start, start_line_end = offset_to_line_bounds(content, start_offset)
    end_line_start, end_line_end = offset_to_line_bounds(content, end_offset)

    # Step 8: Validate boundaries are not reversed
    if start_line_start > end_line_start:
        start_line, _ = offset_to_line_col(content, start_offset)
        end_line, _ = offset_to_line_col(content, end_offset)
        return error_response(
            f'Provided `indentStartAt` (on line {start_line}) '
            f'was found after `indentEndAt` (on line {end_line}).'
        )
    if start_line_start == end_line_start and start_offset > end_offset:
        start_line, start_col = offset_to_line_col(content, start_offset)
        end_line, end_col = offset_to_line_col(content, end_offset)
        return error_response(
            f'Provided `indentStartAt` (on line {start_line}, column {start_col}) '
            f'was found after `indentEndAt` (on line {end_line}, column {end_col}).'
        )

    # Step 9: Resolve indentSize
    if indentSize is None:
        detected = detect_indent(content)
        if detected is None:
            return error_response(
                'Unable to determine `indentSize` automatically. '
                'Try again with an explicit `indentSize`.'
            )
        indentSize = detected

    # Step 10: Resolve indent unit
    indent_unit = resolve_indent_unit(indentSize)

    # The range of content to modify: from start_line_start to end_line_end
    region = content[start_line_start:end_line_end]
    lines = region.split('\n')

    # Step 11: If unindenting, validate all non-empty lines have enough whitespace
    if indentDelta < 0:
        required_prefix = indent_unit * abs(indentDelta)
        unindentable = {}
        for i, line in enumerate(lines):
            # Empty lines are skipped
            if line == '':
                continue
            if not line.startswith(required_prefix):
                line_num = offset_to_line_col(content, start_line_start)[0] + i
                unindentable[str(line_num)] = line
        if unindentable:
            indent_desc = _indent_size_description(indentSize)
            return json.dumps({
                'success': False,
                'message': (
                    f'Cannot unindent by {abs(indentDelta)} level ({indent_desc}). '
                    f'The following lines have insufficient indentation:'
                ),
                'unindentableLines': unindentable,
            }, indent=2)

    # Step 12: Apply indentation changes
    new_lines = []
    for line in lines:
        if line == '':
            # Empty line: leave unchanged
            new_lines.append(line)
        elif indentDelta > 0:
            # Indent: prepend
            new_lines.append(indent_unit * indentDelta + line)
        else:
            # Unindent: remove prefix
            prefix_len = len(indent_unit) * abs(indentDelta)
            new_lines.append(line[prefix_len:])

    new_region = '\n'.join(new_lines)
    new_content = content[:start_line_start] + new_region + content[end_line_end:]

    # Step 13: Write the modified file
    Path(filePath).write_text(new_content)

    # Step 14: Build success response
    # Calculate line numbers (1-indexed)
    first_line_num = offset_to_line_col(content, start_line_start)[0]
    last_line_num = offset_to_line_col(content, end_line_start)[0]
    line_count = last_line_num - first_line_num + 1

    indent_desc = _indent_size_description(indentSize)
    if indentDelta > 0:
        action = 'Indented'
    else:
        action = 'Unindented'
    summary = (
        f'{action} {line_count} lines (lines {first_line_num}-{last_line_num}) '
        f'by {abs(indentDelta)} level ({indent_desc})'
    )

    # Context for the first indented line (⬥ at start of line)
    # In new_content, the first line starts at start_line_start
    new_start_context = expand_context(new_content, start_line_start)

    # Context for the last indented line (⬥ at end of line, before trailing \n)
    # In new_content, find the end of the last line
    new_end_line_start, new_end_line_end = offset_to_line_bounds(
        new_content, start_line_start + len(new_region) - 1
    )
    # Place ⬥ at end of line content (before \n)
    new_end_context = expand_context(new_content, new_end_line_end)

    return json.dumps({
        'success': True,
        'summary': summary,
        'newStartAtContext': new_start_context,
        'newEndAtContext': new_end_context,
    }, indent=2)


# === Helpers ===

def _parse_indent_boundary(value: str) -> tuple[str, str] | None:
    """
    Parse an indent boundary parameter (indentStartAt or indentEndAt).

    If the value contains a ⬥ marker, parse normally via parse_context_around_marker.
    If the value has no ⬥ and no \\n (single-line fragment), treat the entire
    string as after_context with an implicit marker at the start: ('', value).
    Otherwise return None (invalid).
    """
    parsed = parse_context_around_marker(value)
    if parsed is not None:
        return parsed
    if MARKER not in value and '\n' not in value and value:
        return ('', value)
    return None


def _indent_size_description(indent_size: int | str) -> str:
    """Human-readable description of an indent size."""
    if indent_size == '\t':
        return 'tab'
    return f'{indent_size} spaces'
