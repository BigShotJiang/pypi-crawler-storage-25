"""
The move_string_in_file tool: AI-agent-friendly cut-and-paste of code blocks.
"""

from pathlib import Path
from typing import Annotated
import json

from revise.server import mcp
from revise.match import (
    MARKER,
    parse_context_around_marker,
    find_marker_positions,
    snap_to_line_start,
    is_line_boundary,
    count_blank_lines_before,
    count_blank_lines_after,
    offset_to_line_col,
    expand_context,
    check_unique_match,
    error_response,
)


# === Tool Definition ===

@mcp.tool()
async def move_string_in_file(
    cutFilePath: Annotated[
        str,
        'Absolute path to the file containing the text to move.'
    ],
    cutStartAt: Annotated[
        str,
        'Substring fragment identifying the line where the cut begins. '
        f'The {MARKER} can appear anywhere on the target line. '
        f'The cut begins at the start of that line. '
        f"Example: '\\n{MARKER}class _OutputBuffer:' - cut starts at the line containing 'class _OutputBuffer:'."
    ],
    cutEndAt: Annotated[
        str,
        'Substring fragment identifying the line following where the cut ends. '
        f'The {MARKER} can appear anywhere on the target line. '
        f'The cut ends BEFORE the target line, at the end of the preceding line.'
        f'The identified line is NOT included in the cut. '
        f"Example: '\\n{MARKER}class _DeferredWriter:' - cut ends before 'class _DeferredWriter:'."
    ],
    pasteAt: Annotated[
        str,
        'Substring fragment marking where to insert the cut lines, adjacent to a \\n or start/end of file. '
        f'The {MARKER} character marks the precise insertion point. '
        'Matched against the pre-cut file state. Must be outside the cut region. '
        f"Example: '\\n{MARKER}def _main_loop_has_exited() -> bool:' - insert cut lines before the start of the def line"
    ],
    pasteFilePath: Annotated[
        str | None,
        'Optional. Absolute path to the paste destination file. '
        'Defaults to cutFilePath (same-file move).'
    ] = None,
) -> str:
    # NOTE: Can't use an f-string to use "{MARKER}" rather than "⬥" because
    #       only regular strings work as docstrings
    """\
    Moves a continuous range of lines from one location to another within a file (or between files).
    
    Specify cut boundaries and paste location using substring matching with an optional ⬥ marker.
    
    Example 1: Move a definition before another definition:
        cutStartAt: "class MyClass:" (start at this line)
        cutEndAt:   "class NextClass:" (end BEFORE this line)
        pasteAt:    "\\n⬥def target_function():" (paste adjacent to the \\n)
    
    Example 2: Move a paragraph after another paragraph:
        cutStartAt: "# Close the database" (start at this line)
        cutEndAt:   "db.close()\\n⬥" (end after the final paragraph line)
        pasteAt:    "db.open()\\n⬥" (paste after a different paragraph's last line)
    
    ⬥ in cut boundaries anywhere in a line marks the line to cut when the cut context contains multiple lines.
    No ⬥ is needed if cut context is within a single line only.
    
    ⬥ in a paste boundary must be adjacent to a \\n or the start/end of the file.
    All lines will be pasted before/after the nearby \\n or file boundary.
    
    Whitespace at the end of lines is ignored when matching substrings.
    
    After editing reports on blank lines around the cut and paste boundaries,
    simplifying clean up of nearby line spacing with small subsequent edits.
    
    Does not alter indentation.
    Use indent_dedent to adjust indentation after moving if needed.
    """
    cut_file_path = cutFilePath
    paste_file_path = pasteFilePath or cut_file_path
    same_file = (Path(cut_file_path).resolve() == Path(paste_file_path).resolve())

    # Step 1: Validate markers
    cut_start_parsed = _parse_cut_boundary(cutStartAt)
    if cut_start_parsed is None:
        return error_response(f'Provided `cutStartAt` must contain exactly one {MARKER} marker, or be a single-line fragment (no \\n) with no {MARKER}.')

    cut_end_parsed = _parse_cut_boundary(cutEndAt)
    if cut_end_parsed is None:
        return error_response(f'Provided `cutEndAt` must contain exactly one {MARKER} marker, or be a single-line fragment (no \\n) with no {MARKER}.')

    paste_parsed = parse_context_around_marker(pasteAt)
    if paste_parsed is None:
        return error_response(f'Provided `pasteAt` must contain exactly one {MARKER} marker.')

    # Step 2: Read files
    try:
        cut_content = Path(cut_file_path).read_text()
    except FileNotFoundError:
        return error_response(f'File not found: {cut_file_path}')

    if same_file:
        paste_content = cut_content
    else:
        try:
            paste_content = Path(paste_file_path).read_text()
        except FileNotFoundError:
            return error_response(f'File not found: {paste_file_path}')

    # Step 3-5: Find all three boundary positions
    if True:
        cut_start_before, cut_start_after = cut_start_parsed
        cut_start_positions = find_marker_positions(cut_content, cut_start_before, cut_start_after)
        err = check_unique_match(cut_start_positions, 'cutStartAt', cut_content, cut_start_before, cut_start_after)
        if err is not None:
            return err

        cut_end_before, cut_end_after = cut_end_parsed
        cut_end_positions = find_marker_positions(cut_content, cut_end_before, cut_end_after)
        err = check_unique_match(cut_end_positions, 'cutEndAt', cut_content, cut_end_before, cut_end_after)
        if err is not None:
            return err

        paste_before, paste_after = paste_parsed
        paste_positions = find_marker_positions(paste_content, paste_before, paste_after)
        err = check_unique_match(paste_positions, 'pasteAt', paste_content, paste_before, paste_after)
        if err is not None:
            return err

        cut_start = snap_to_line_start(cut_content, cut_start_positions[0])
        cut_end = snap_to_line_start(cut_content, cut_end_positions[0])
        paste_pos = paste_positions[0]

    # Step 5b: Snap pasteAt to a line boundary.
    # The marker may be right before a \n (end of line); snap forward past
    # the \n so pasted lines start on their own line.
    if not is_line_boundary(paste_content, paste_pos):
        if paste_pos < len(paste_content) and paste_content[paste_pos] == '\n':
            paste_pos += 1
        else:
            line, col = offset_to_line_col(paste_content, paste_pos)
            return error_response(
                f'Provided `pasteAt` resolved to line {line}, column {col}, '
                f'which is not a line boundary. The paste location must be '
                f'adjacent to a \\n or file boundary. '
                f'Try again with \u2b25 positioned at the start or end of a target line.'
            )

    # Step 6: Validate cut region
    if True:
        if cut_start == cut_end:
            line, col = offset_to_line_col(cut_content, cut_start)
            return json.dumps({
                'success': False,
                'message': 'Provided `cutStartAt` and `cutEndAt` form an empty selection.',
                'matchingLines': {
                    str(line): expand_context(cut_content, cut_start)
                },
            }, indent=2)

        if cut_start > cut_end:
            start_line, start_col = offset_to_line_col(cut_content, cut_start)
            end_line, end_col = offset_to_line_col(cut_content, cut_end)
            if start_line == end_line:
                msg = (
                    f'Provided `cutStartAt` (on line {start_line}, column {start_col}) '
                    f'was found after `cutEndAt` (on line {end_line}, column {end_col}).'
                )
            else:
                msg = (
                    f'Provided `cutStartAt` (on line {start_line}) '
                    f'was found after `cutEndAt` (on line {end_line}).'
                )
            return error_response(msg)

    # Step 7: Validate paste is outside cut region
    if same_file and cut_start <= paste_pos < cut_end:
        paste_line, _ = offset_to_line_col(paste_content, paste_pos)
        cut_start_line, _ = offset_to_line_col(cut_content, cut_start)
        cut_end_line, _ = offset_to_line_col(cut_content, cut_end - 1)
        return error_response(
            f'Provided `pasteAt` (on line {paste_line}) falls inside the cut region '
            f'(lines {cut_start_line}-{cut_end_line}). '
            f'The paste location must be outside the cut region.'
        )

    # Step 8: Extract the cut text
    cut_text = cut_content[cut_start:cut_end]

    # Step 9-12: Perform the move
    if same_file:
        # Same-file move
        if paste_pos < cut_start:
            # Paste is before cut: insert first, then remove (offsets shift)
            new_content = (
                paste_content[:paste_pos]
                + cut_text
                + paste_content[paste_pos:cut_start]
                + paste_content[cut_end:]
            )
            # New layout: [before_paste][cut_text][between_paste_and_cut][after_cut]
            new_cut_point = paste_pos + len(cut_text) + (cut_start - paste_pos)
            new_paste_start = paste_pos
        else:
            # Paste is after cut: remove first, then insert (offsets shift)
            adjusted_paste = paste_pos - len(cut_text)
            new_content = (
                cut_content[:cut_start]
                + cut_content[cut_end:paste_pos]
                + cut_text
                + cut_content[paste_pos:]
            )
            new_cut_point = cut_start
            new_paste_start = adjusted_paste
    else:
        # Cross-file move
        new_cut_content = cut_content[:cut_start] + cut_content[cut_end:]
        new_paste_content = paste_content[:paste_pos] + cut_text + paste_content[paste_pos:]
        new_cut_point = cut_start
        new_paste_start = paste_pos

    # Step 13: Write files
    if same_file:
        Path(cut_file_path).write_text(new_content)
        final_paste_content = new_content
        final_cut_content = new_content
    else:
        Path(cut_file_path).write_text(new_cut_content)
        Path(paste_file_path).write_text(new_paste_content)
        final_paste_content = new_paste_content
        final_cut_content = new_cut_content

    # Step 14: Build success response
    if True:
        new_paste_end = new_paste_start + len(cut_text)

        # Line count of moved text
        moved_line_count = cut_text.count('\n')
        if not cut_text.endswith('\n'):
            moved_line_count += 1

        # Destination line range (1-indexed)
        dest_start_line, _ = offset_to_line_col(final_paste_content, new_paste_start)
        dest_end_offset = new_paste_end - 1 if new_paste_end > new_paste_start else new_paste_start
        dest_end_line, _ = offset_to_line_col(final_paste_content, dest_end_offset)

        # Build summary
        cut_filename = Path(cut_file_path).name
        paste_filename = Path(paste_file_path).name
        if same_file:
            summary = (
                f'Moved {moved_line_count} line selection '
                f'to lines {dest_start_line}-{dest_end_line} of {paste_filename}'
            )
        else:
            summary = (
                f'Moved {moved_line_count} line selection '
                f'from {cut_filename} '
                f'to lines {dest_start_line}-{dest_end_line} of {paste_filename}'
            )

        # Context outputs
        new_cut_context = expand_context(final_cut_content, new_cut_point)
        new_paste_context_before = expand_context(final_paste_content, new_paste_start)
        new_paste_context_after = expand_context(final_paste_content, new_paste_end)

        # Blank line counts at key boundaries
        new_blank_lines_around = {
            'cutLocation': (
                count_blank_lines_before(final_cut_content, new_cut_point)
                + count_blank_lines_after(final_cut_content, new_cut_point)
            ),
            'pasteBeforeLocation': (
                count_blank_lines_before(final_paste_content, new_paste_start)
                + count_blank_lines_after(final_paste_content, new_paste_start)
            ),
            'pasteAfterLocation': (
                count_blank_lines_before(final_paste_content, new_paste_end)
                + count_blank_lines_after(final_paste_content, new_paste_end)
            ),
        }

        return json.dumps({
            'success': True,
            'summary': summary,
            'newCutContext': new_cut_context,
            'newPasteContextBefore': new_paste_context_before,
            'newPasteContextAfter': new_paste_context_after,
            'newBlankLinesAround': new_blank_lines_around,
            'suggestion': 'Review new cut/paste context to repair blank line spacing or other boundary issues',
        }, indent=2)


# === Helpers ===

def _parse_cut_boundary(value: str) -> tuple[str, str] | None:
    """
    Parse a cut boundary parameter (cutStartAt or cutEndAt).

    If the value contains a ⬥ marker, parse normally via parse_context_around_marker.
    If the value has no ⬥ and no \\n (single-line fragment), treat the entire
    string as after_context with an implicit marker at the start: ('', value).
    Otherwise return None (invalid).
    """
    parsed = parse_context_around_marker(value)
    if parsed is not None:
        return parsed
    if MARKER not in value and '\n' not in value and value:
        return ('', value)
    return None
