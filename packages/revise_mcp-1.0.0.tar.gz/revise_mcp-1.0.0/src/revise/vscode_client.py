"""Client for communicating with the VSC as MCP extension."""

import json
import urllib.request
from typing import Any

VSCODE_MCP_URL = 'http://localhost:4000/mcp'

def call_vscode_tool(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """
    Call a tool on the VSC as MCP server.

    Arguments:
    * tool_name -- Name of the tool to call (e.g., 'rename_symbol')
    * arguments -- Tool arguments as a dictionary

    Returns the tool result as a dictionary.

    Raises:
    * urllib.error.URLError -- If the HTTP request fails
    * ValueError -- If the response is not valid JSON or contains a JSON-RPC error
    """
    payload = json.dumps({
        'jsonrpc': '2.0',
        'method': 'tools/call',
        'params': {
            'name': tool_name,
            'arguments': arguments
        },
        'id': 1
    }).encode()

    req = urllib.request.Request(
        VSCODE_MCP_URL,
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    with urllib.request.urlopen(req, timeout=30.0) as response:
        result = json.loads(response.read())

    if 'error' in result:
        raise ValueError(f'VSCode MCP error: {result["error"]}')

    return result.get('result', {})
