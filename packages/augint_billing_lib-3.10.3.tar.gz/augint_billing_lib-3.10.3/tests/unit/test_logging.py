"""Unit tests for logging utilities."""

import json
import logging

import pytest

from augint_billing_lib.logging import log_event, log_metric


@pytest.mark.unit
class TestLogEvent:
    """Test log_event function."""

    def test_log_event_basic(self, caplog):
        """Test basic event logging."""
        with caplog.at_level(logging.INFO):
            log_event("info", "test_event", key1="value1", key2="value2")

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["msg"] == "test_event"
        assert log_data["key1"] == "value1"
        assert log_data["key2"] == "value2"

    def test_log_event_with_nested_data(self, caplog):
        """Test logging with nested data structures."""
        with caplog.at_level(logging.WARNING):
            log_event(
                "warning", "complex_event", data={"nested": {"key": "value"}}, list_data=[1, 2, 3]
            )

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["msg"] == "complex_event"
        assert log_data["data"] == {"nested": {"key": "value"}}
        assert log_data["list_data"] == [1, 2, 3]

    def test_log_event_with_none_values(self, caplog):
        """Test logging with None values."""
        with caplog.at_level(logging.ERROR):
            log_event("error", "error_event", error=None, details=None)

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["msg"] == "error_event"
        assert log_data["error"] is None
        assert log_data["details"] is None


@pytest.mark.unit
class TestLogMetric:
    """Test log_metric function."""

    def test_log_metric_without_dimensions(self, caplog):
        """Test metric logging without dimensions."""
        with caplog.at_level(logging.INFO):
            log_metric("TestMetric", 100)

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["TestMetric"] == 100
        assert "_aws" in log_data
        assert log_data["_aws"]["CloudWatchMetrics"][0]["Namespace"] == "AugInt/Billing"
        assert log_data["_aws"]["CloudWatchMetrics"][0]["Metrics"][0]["Name"] == "TestMetric"

    def test_log_metric_with_dimensions(self, caplog):
        """Test metric logging with dimensions."""
        with caplog.at_level(logging.INFO):
            log_metric("UsageReports", 5, dims={"Environment": "prod", "Region": "us-east-1"})

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["UsageReports"] == 5
        assert log_data["Environment"] == "prod"
        assert log_data["Region"] == "us-east-1"
        assert "_aws" in log_data

    def test_log_metric_with_unit(self, caplog):
        """Test metric logging with custom unit - unit is always Count in current implementation."""
        with caplog.at_level(logging.INFO):
            # Current implementation doesn't support custom units, always uses "Count"
            log_metric("ResponseTime", 250)

        assert len(caplog.records) == 1
        log_data = json.loads(caplog.records[0].message)

        assert log_data["ResponseTime"] == 250
        assert log_data["_aws"]["CloudWatchMetrics"][0]["Metrics"][0]["Unit"] == "Count"
