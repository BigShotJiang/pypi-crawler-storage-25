"""Test package initialization."""

import pytest

import augint_billing_lib


@pytest.mark.unit
def test_package_import():
    """Test that package can be imported."""
    assert augint_billing_lib is not None
    assert hasattr(augint_billing_lib, "__version__")
