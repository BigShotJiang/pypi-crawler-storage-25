"""Unit tests for validators."""

import pytest

from augint_billing_lib.validators import require_keys


@pytest.mark.unit
class TestRequireKeys:
    """Test require_keys validator."""

    def test_require_keys_all_present(self):
        """Test with all required keys present."""
        data = {"key1": "value1", "key2": "value2", "key3": "value3"}

        result = require_keys(data, ["key1", "key2"])
        assert result == data  # Returns the dict, not True

    def test_require_keys_missing_one(self):
        """Test with one required key missing."""
        data = {"key1": "value1", "key3": "value3"}

        with pytest.raises(ValueError, match="Missing required keys: \\['key2'\\]"):
            require_keys(data, ["key1", "key2"])

    def test_require_keys_missing_multiple(self):
        """Test with multiple required keys missing."""
        data = {"key3": "value3"}

        with pytest.raises(ValueError, match="Missing required keys: \\['key1', 'key2'\\]"):
            require_keys(data, ["key1", "key2"])

    def test_require_keys_empty_requirements(self):
        """Test with no required keys."""
        data = {"any": "data"}

        result = require_keys(data, [])
        assert result == data

    def test_require_keys_empty_data(self):
        """Test with empty data dict."""
        data = {}

        with pytest.raises(ValueError, match="Missing required keys: \\['key1'\\]"):
            require_keys(data, ["key1"])

    def test_require_keys_none_values(self):
        """Test that None values are considered missing (based on implementation)."""
        data = {"key1": None, "key2": "value2"}

        # None is considered missing in the implementation
        with pytest.raises(ValueError, match="Missing required keys: \\['key1'\\]"):
            require_keys(data, ["key1", "key2"])

    def test_require_keys_empty_string_values(self):
        """Test that empty strings are considered missing."""
        data = {"key1": "", "key2": "value2"}

        with pytest.raises(ValueError, match="Missing required keys: \\['key1'\\]"):
            require_keys(data, ["key1", "key2"])

    def test_require_keys_nested_not_checked(self):
        """Test that nested keys are not checked."""
        data = {"key1": {"nested": "value"}}

        # Should pass for key1
        result = require_keys(data, ["key1"])
        assert result == data

        # Should fail for nested key
        with pytest.raises(ValueError, match="Missing required keys: \\['nested'\\]"):
            require_keys(data, ["nested"])
