"""Basic unit tests for adapter modules."""

from unittest.mock import Mock, patch

import pytest

from augint_billing_lib.adapters.apigw_admin import ApiGwAdmin
from augint_billing_lib.adapters.apigw_usage import ApiGwUsage
from augint_billing_lib.adapters.ddb_repo import DdbRepo
from augint_billing_lib.adapters.stripe import StripeAdapter


@pytest.mark.unit
class TestAdapterInitialization:
    """Test adapter initialization."""

    @patch("augint_billing_lib.adapters.stripe.stripe")
    def test_stripe_adapter_init(self, mock_stripe):
        """Test StripeAdapter initialization."""
        adapter = StripeAdapter("sk_test_123", "price_metered")
        assert adapter.price_id == "price_metered"
        mock_stripe.api_key = "sk_test_123"

    def test_ddb_repo_init(self):
        """Test DdbRepo initialization."""
        mock_table = Mock()
        repo = DdbRepo(mock_table)
        assert repo.table == mock_table

    def test_apigw_usage_init(self):
        """Test ApiGwUsage initialization."""
        mock_client = Mock()
        usage = ApiGwUsage(mock_client)
        assert usage.apigw == mock_client

    def test_apigw_admin_init(self):
        """Test ApiGwAdmin initialization."""
        mock_client = Mock()
        admin = ApiGwAdmin(mock_client, "FREE_10K", "METERED")
        assert admin.apigw == mock_client
        assert admin.free_plan_id == "FREE_10K"
        assert admin.metered_plan_id == "METERED"
