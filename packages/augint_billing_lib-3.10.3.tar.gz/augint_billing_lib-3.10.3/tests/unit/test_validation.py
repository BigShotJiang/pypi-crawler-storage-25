import pytest

from augint_billing_lib.validators import require_keys


@pytest.mark.unit
def test_require_keys_ok():
    require_keys({"a": 1, "b": 2}, ["a", "b"])


@pytest.mark.unit
def test_require_keys_missing():
    with pytest.raises(ValueError, match="Missing required keys"):
        require_keys({"a": 1}, ["a", "b"])
