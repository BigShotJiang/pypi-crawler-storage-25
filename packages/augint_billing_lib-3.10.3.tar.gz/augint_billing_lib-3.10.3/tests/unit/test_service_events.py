import pytest

from augint_billing_lib.service import BillingService


@pytest.mark.unit
def test_promote_on_setup_intent(fakes):
    repo, stripe, usage = fakes
    svc = BillingService(repo=repo, stripe=stripe, usage=usage)
    evt = {"type": "setup_intent.succeeded", "data": {"object": {"customer": "cus_1"}}}
    out = svc.handle_stripe_event(evt)
    assert out["target_plan"] == "metered"
    assert out["subscription_item_id"] == "si_test999"


@pytest.mark.unit
def test_usage_reporting_counts(fakes):
    import datetime

    repo, stripe, usage = fakes
    svc = BillingService(repo=repo, stripe=stripe, usage=usage)
    now = datetime.datetime(2024, 1, 1, 12, 0, 0, tzinfo=datetime.UTC)
    reports = svc.reconcile_usage_window(now, now)
    assert reports
    assert reports[0]["units"] == 42
