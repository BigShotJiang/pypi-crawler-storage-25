"""Unit tests for port interfaces."""

import pytest

from augint_billing_lib.ports import CustomerRepoPort, PlanAdminPort, StripePort, UsageSourcePort


@pytest.mark.unit
class TestPorts:
    """Test port interfaces."""

    def test_stripe_port_interface(self):
        """Test StripePort interface."""
        # Port is an abstract interface, verify methods exist
        assert hasattr(StripePort, "has_default_payment_method")
        assert hasattr(StripePort, "ensure_metered_subscription")
        assert hasattr(StripePort, "cancel_subscription_if_any")
        assert hasattr(StripePort, "report_usage")

    def test_customer_repo_port_interface(self):
        """Test CustomerRepoPort interface."""
        assert hasattr(CustomerRepoPort, "get_by_api_key")
        assert hasattr(CustomerRepoPort, "get_by_customer")
        assert hasattr(CustomerRepoPort, "save")
        assert hasattr(CustomerRepoPort, "scan_metered")

    def test_usage_source_port_interface(self):
        """Test UsageSourcePort interface."""
        assert hasattr(UsageSourcePort, "get_usage")

    def test_plan_admin_port_interface(self):
        """Test PlanAdminPort interface."""
        assert hasattr(PlanAdminPort, "move_key_to_plan")
