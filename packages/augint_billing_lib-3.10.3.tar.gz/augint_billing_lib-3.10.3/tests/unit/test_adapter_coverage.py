"""Minimal adapter coverage tests."""

from unittest.mock import Mock

import pytest

from augint_billing_lib.adapters.apigw_admin import ApiGwAdmin
from augint_billing_lib.adapters.apigw_usage import ApiGwUsage
from augint_billing_lib.adapters.ddb_repo import DdbRepo
from augint_billing_lib.adapters.stripe import StripeAdapter


@pytest.mark.unit
def test_stripe_adapter_methods_exist():
    """Test StripeAdapter has required methods."""
    adapter = StripeAdapter("sk_test", "price_123")
    assert hasattr(adapter, "has_default_payment_method")
    assert hasattr(adapter, "ensure_metered_subscription")
    assert hasattr(adapter, "cancel_subscription_if_any")
    assert hasattr(adapter, "report_usage")
    assert hasattr(adapter, "discover_metered_price_id")


@pytest.mark.unit
def test_ddb_repo_methods_exist():
    """Test DdbRepo has required methods."""
    mock_table = Mock()
    repo = DdbRepo(mock_table)
    assert hasattr(repo, "save")
    assert hasattr(repo, "get_by_api_key")
    assert hasattr(repo, "get_by_customer")
    assert hasattr(repo, "scan_metered")
    assert repo.table == mock_table


@pytest.mark.unit
def test_apigw_usage_methods_exist():
    """Test ApiGwUsage has required methods."""
    mock_client = Mock()
    usage = ApiGwUsage(mock_client)
    assert hasattr(usage, "get_usage")
    assert usage.apigw == mock_client


@pytest.mark.unit
def test_apigw_admin_methods_exist():
    """Test ApiGwAdmin has required methods."""
    mock_client = Mock()
    admin = ApiGwAdmin(mock_client, "FREE", "METERED")
    assert hasattr(admin, "move_key_to_plan")
    assert admin.apigw == mock_client
    assert admin.free_plan_id == "FREE"
    assert admin.metered_plan_id == "METERED"
