"""Stripe API response fixtures for testing."""


def customer_with_pm():
    """Customer with default payment method."""
    return {"id": "cus_test456", "invoice_settings": {"default_payment_method": "pm_test123"}}


def customer_without_pm():
    """Customer without default payment method."""
    return {"id": "cus_test456", "invoice_settings": {"default_payment_method": None}}


def active_metered_subscription():
    """Active metered subscription."""
    return {
        "id": "sub_test789",
        "customer": "cus_test456",
        "status": "active",
        "items": {
            "data": [
                {
                    "id": "si_test999",
                    "price": {"id": "price_metered123", "recurring": {"usage_type": "metered"}},
                }
            ]
        },
    }


def usage_report_response():
    """Successful usage report response."""
    return {
        "id": "mbur_test123",
        "object": "usage_record",
        "livemode": False,
        "quantity": 100,
        "subscription_item": "si_test999",
        "timestamp": 1640995200,
    }
