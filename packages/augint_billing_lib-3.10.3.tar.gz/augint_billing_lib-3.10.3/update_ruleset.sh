#!/bin/bash

# Update the ruleset with the correct integration test check name
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  /repos/svange/augint-billing-lib/rulesets/7305464 \
  --input - << 'RULESET'
{
  "name": "Publishing Branches",
  "target": "branch",
  "enforcement": "active",
  "conditions": {
    "ref_name": {
      "exclude": [],
      "include": ["~DEFAULT_BRANCH"]
    }
  },
  "rules": [
    {
      "type": "deletion"
    },
    {
      "type": "non_fast_forward"
    },
    {
      "type": "pull_request",
      "parameters": {
        "required_approving_review_count": 0,
        "dismiss_stale_reviews_on_push": false,
        "require_code_owner_review": false,
        "require_last_push_approval": false,
        "required_review_thread_resolution": false,
        "automatic_copilot_code_review_enabled": false,
        "allowed_merge_methods": ["merge", "squash", "rebase"]
      }
    },
    {
      "type": "required_status_checks",
      "parameters": {
        "strict_required_status_checks_policy": false,
        "do_not_enforce_on_create": false,
        "required_status_checks": [
          {
            "context": "Enforce commit standards",
            "integration_id": 15368
          },
          {
            "context": "Generate compliance reports",
            "integration_id": 15368
          },
          {
            "context": "Security scanning",
            "integration_id": 15368
          },
          {
            "context": "Run unit tests",
            "integration_id": 15368
          },
          {
            "context": "Run integration tests (3.12, ubuntu-latest)",
            "integration_id": 15368
          }
        ]
      }
    }
  ],
  "bypass_actors": [
    {
      "actor_id": 5,
      "actor_type": "RepositoryRole",
      "bypass_mode": "always"
    }
  ]
}
RULESET
