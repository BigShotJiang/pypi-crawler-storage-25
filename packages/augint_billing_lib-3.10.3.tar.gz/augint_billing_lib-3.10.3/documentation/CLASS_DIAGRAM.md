```mermaid
classDiagram
  class BillingService {
    +handle_stripe_event(evt: dict) -> dict
    +reconcile_usage_window(since: datetime, until: datetime) -> list~Report~
    +promote(api_key_id: str) -> dict
    +demote(api_key_id: str) -> dict
  }

  class StripePort {
    <<interface>>
    +ensure_metered_subscription(customer_id: str) -> str  # returns subscription_item_id
    +cancel_subscription_if_any(customer_id: str) -> None
    +has_default_payment_method(customer_id: str) -> bool
    +report_usage(subscription_item_id: str, units: int, timestamp: int, idempotency_key: str) -> None
  }

  class UsageSourcePort {
    <<interface>>
    +get_usage(usage_plan_id: str, api_key_id: str, since: datetime, until: datetime) -> int
  }

  class CustomerRepoPort {
    <<interface>>
    +get_by_api_key(api_key_id: str) -> Link
    +get_by_customer(customer_id: str) -> list~Link~
    +save(link: Link) -> None
    +scan_metered() -> list~Link~
  }

  class Link {
    +api_key_id: str
    +stripe_customer_id: str
    +cognito_user_id: Optional[str]
    +plan: str
    +usage_plan_id: str
    +metered_subscription_item_id: Optional[str]
    +last_reported_usage_ts: Optional[datetime]
    +current_month_reported_units: int
  }
```
