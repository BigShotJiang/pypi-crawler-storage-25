"""Pre-push-check command: verify CHANGELOG.md has an entry for the current version."""

import fnmatch
import os
import re
import subprocess
import sys

from ..targets import TARGETS
from ..workspace import find_workspace_root, load_workspace


def _detect_version(dir_path="."):
    """Detect version using registry adapters.

    Returns (version_string, registry_name) or (None, None) if undetectable.
    """
    for name in ("go", "npm", "pypi"):
        reg = TARGETS[name]
        if reg.check_project_exists(dir_path):
            return reg.read_version(dir_path), name
    return None, None


def _check_changelog(dir_path, version):
    """Check that CHANGELOG.md in dir_path has a ## <version> heading.

    Returns None on success, or an error message string on failure.
    """
    changelog_path = os.path.join(dir_path, "CHANGELOG.md")
    if not os.path.exists(changelog_path):
        return None  # no changelog -- skip

    with open(changelog_path, "r", encoding="utf-8") as f:
        content = f.read()

    pattern = re.compile(r"^## " + re.escape(version) + r"\s*$", re.MULTILINE)
    if pattern.search(content):
        return None

    return f"CHANGELOG.md has no entry for version {version}"


def _parse_stdin_refs():
    """Parse pre-push hook stdin to extract (local_sha, remote_sha) pairs.

    Each line is: <local ref> <local sha> <remote ref> <remote sha>
    Returns a list of (local_sha, remote_sha) tuples, or None if stdin
    is not readable or empty.
    """
    try:
        if sys.stdin.isatty():
            return None
    except (AttributeError, OSError):
        return None

    lines = sys.stdin.read().strip()
    if not lines:
        return None

    refs = []
    for line in lines.splitlines():
        parts = line.split()
        if len(parts) >= 4:
            local_sha = parts[1]
            remote_sha = parts[3]
            refs.append((local_sha, remote_sha))
    return refs if refs else None


def _get_changed_files(refs):
    """Get the list of files changed across all pushed refs.

    Returns a set of file paths relative to the repo root.
    """
    zero_sha = "0" * 40
    changed = set()

    for local_sha, remote_sha in refs:
        if local_sha == zero_sha:
            # Branch being deleted -- nothing to check
            continue

        try:
            if remote_sha == zero_sha:
                # New branch: get files in commits not yet on any remote
                result = subprocess.run(
                    ["git", "log", "--name-only", "--pretty=format:", local_sha,
                     "--not", "--remotes"],
                    capture_output=True, text=True, timeout=30,
                )
            else:
                result = subprocess.run(
                    ["git", "diff", "--name-only", f"{remote_sha}..{local_sha}"],
                    capture_output=True, text=True, timeout=30,
                )
            if result.returncode == 0:
                for f in result.stdout.strip().splitlines():
                    f = f.strip()
                    if f:
                        changed.add(f)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            # If git fails, fall back to single-project behavior
            return None

    return changed


def _file_matches_project(filepath, project):
    """Check whether a file path belongs to a project.

    A file belongs to a project if:
    - It starts with the project's path prefix, OR
    - It matches any of the project's watch globs
    """
    proj_path = project["path"]
    # Normalize: ensure prefix ends with /
    prefix = proj_path.rstrip("/") + "/"
    if filepath == proj_path or filepath.startswith(prefix):
        return True

    for glob_pattern in project.get("watch", []):
        if fnmatch.fnmatch(filepath, glob_pattern):
            return True

    return False


def _affected_projects(changed_files, projects):
    """Determine which projects are affected by the changed files.

    Returns a list of project dicts that have at least one changed file.
    """
    affected = []
    for proj in projects:
        for f in changed_files:
            if _file_matches_project(f, proj):
                affected.append(proj)
                break
    return affected


def _run_monorepo_check(workspace_root, projects, changed_files):
    """Check changelogs for all affected monorepo projects.

    Returns exit code 0 on success, 1 if any project fails.
    """
    affected = _affected_projects(changed_files, projects)
    if not affected:
        sys.exit(0)

    failures = []
    for proj in affected:
        proj_dir = os.path.join(workspace_root, proj["path"])
        version, _ = _detect_version(proj_dir)
        if not version:
            continue  # cannot detect version -- skip

        error = _check_changelog(proj_dir, version)
        if error:
            failures.append((proj["name"], version, error))

    if not failures:
        sys.exit(0)

    for name, version, error in failures:
        print(f"Error: {name}: {error}.", file=sys.stderr)
        print(f"Add a '## {version}' section to {name}'s CHANGELOG.md before pushing.",
              file=sys.stderr)
    sys.exit(1)


def run_cmd(registry, args, flags):
    """Check that CHANGELOG.md has an entry for the current project version.

    In monorepo mode (when a workspace root is detected), parses the pushed
    ref range from stdin to determine which projects are affected, then checks
    each affected project's changelog independently.

    In single-project mode, checks the current directory's changelog.

    Exits 1 if any changelog entry is missing; exits 0 silently on success.
    """
    # Detect monorepo context
    workspace_root = find_workspace_root(".")
    if workspace_root:
        refs = _parse_stdin_refs()
        if refs is not None:
            changed_files = _get_changed_files(refs)
            if changed_files is not None:
                projects = load_workspace(workspace_root)
                _run_monorepo_check(workspace_root, projects, changed_files)
                # _run_monorepo_check always calls sys.exit, so this is unreachable

    # Single-project fallback
    version, _project_type = _detect_version()
    if not version:
        sys.exit(0)

    error = _check_changelog(".", version)
    if error is None:
        sys.exit(0)

    print(f"Error: {error}.", file=sys.stderr)
    print(f"Add a '## {version}' section before pushing.", file=sys.stderr)
    sys.exit(1)
