"""Lint configuration loading from .rlsbl/lint/ TOML files."""

import os
import sys
import tomllib
from dataclasses import dataclass, field


# Per-language default forbidden imports
_DEFAULT_FORBIDDEN = {
    "python": [
        "argparse", "click", "typer",
        "flask", "fastapi", "django",
        "uvicorn", "granian", "starlette",
        "tornado", "bottle",
    ],
    "go": [
        "net/http",
        "github.com/spf13/cobra",
        "github.com/urfave/cli",
    ],
    "npm": [
        "express", "koa", "hono",
        "commander", "yargs",
    ],
}

# Old-format ignore entries that map to stdout_ignore
_STDOUT_IGNORE_ENTRIES = frozenset({"print", "sys", "logging"})


@dataclass
class LanguageLintConfig:
    forbidden_imports: list[str] = field(default_factory=list)
    stdout_enabled: bool = True
    stdout_ignore: list[str] = field(default_factory=list)
    entry_point_enabled: bool = True
    entry_point_ignore: list[str] = field(default_factory=list)
    exclude_patterns: list[str] = field(default_factory=list)


def load_language_config(project_path: str, language: str) -> LanguageLintConfig:
    """Read .rlsbl/lint/<language>.toml, falling back to defaults if missing."""
    config_path = os.path.join(project_path, ".rlsbl", "lint", f"{language}.toml")
    defaults = _DEFAULT_FORBIDDEN.get(language, [])

    if not os.path.isfile(config_path):
        return LanguageLintConfig(forbidden_imports=list(defaults))

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return LanguageLintConfig(forbidden_imports=list(defaults))

    fi_section = data.get("forbidden-imports", {})
    forbidden = fi_section.get("modules", list(defaults))

    stdout_section = data.get("stdout", {})
    stdout_enabled = stdout_section.get("enabled", True)
    stdout_ignore = stdout_section.get("ignore", [])

    ep_section = data.get("entry-point", {})
    ep_enabled = ep_section.get("enabled", True)
    ep_ignore = ep_section.get("ignore", [])

    files_section = data.get("files", {})
    exclude = files_section.get("exclude", [])

    return LanguageLintConfig(
        forbidden_imports=forbidden,
        stdout_enabled=stdout_enabled,
        stdout_ignore=stdout_ignore,
        entry_point_enabled=ep_enabled,
        entry_point_ignore=ep_ignore,
        exclude_patterns=exclude,
    )


def load_parser_setting(project_path: str) -> str:
    """Read parser type from .rlsbl/lint.toml, defaulting to 'ast'."""
    lint_toml = os.path.join(project_path, ".rlsbl", "lint.toml")
    if not os.path.isfile(lint_toml):
        return "ast"
    try:
        with open(lint_toml, "rb") as f:
            data = tomllib.load(f)
        parser = data.get("parser", "ast")
        if parser not in ("ast", "regex"):
            return "ast"
        return parser
    except Exception:
        return "ast"


def _load_old_lint_toml(project_path: str) -> list[str] | None:
    """Read old-format .rlsbl/lint.toml and return the ignore list, or None.

    The old format had a flat ``ignore`` key:
        ignore = ["argparse", "print", "logging"]

    Returns the list if the key is present, None otherwise.
    """
    lint_toml = os.path.join(project_path, ".rlsbl", "lint.toml")
    if not os.path.isfile(lint_toml):
        return None
    try:
        with open(lint_toml, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return None
    ignore = data.get("ignore")
    if ignore is None:
        return None
    if not isinstance(ignore, list):
        return None
    return ignore


def apply_old_ignore_shim(config: "LanguageLintConfig", ignore_entries: list[str]) -> None:
    """Apply backward-compatible shim from old lint.toml ignore list.

    Mutates *config* in place:
    - Module names found in forbidden_imports are removed from that list.
    - "print", "sys", "logging" entries are added to stdout_ignore.
    - Anything else is added to entry_point_ignore.
    """
    forbidden_set = set(config.forbidden_imports)
    for entry in ignore_entries:
        if entry in _STDOUT_IGNORE_ENTRIES:
            if entry not in config.stdout_ignore:
                config.stdout_ignore.append(entry)
        elif entry in forbidden_set:
            config.forbidden_imports.remove(entry)
        else:
            # Assume it is an entry point name
            if entry not in config.entry_point_ignore:
                config.entry_point_ignore.append(entry)
