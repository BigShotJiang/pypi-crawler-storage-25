# قارئ القرآن الكريم - Quran Reader

نظام لبناء قاعدة بيانات JSON من مجلدات القرآن الكريم والاستعلام عنها بسهولة.

---

## 📁 هيكل المجلدات المطلوب

```
quran_db/
├── 001/              # سورة الفاتحة
│   ├── 001.txt       # الآية الأولى
│   ├── 002.txt       # الآية الثانية
│   └── ...
├── 002/              # سورة البقرة
│   ├── 001.txt
│   ├── 002.txt
│   └── ...
└── ...
```

**أو:**

```
quran_db/
├── 001_الفاتحة/
│   ├── 001.txt
│   ├── 002.txt
│   └── ...
├── 002_البقرة/
│   ├── 001.txt
│   ├── 002.txt
│   └── ...
└── ...
```

---

## 🚀 الاستخدام

### 1. بناء قاعدة البيانات

```bash
python build_quran_db.py
```

هذا الأمر سيقوم بـ:
- قراءة كل المجلدات في `quran_db/`
- استخراج رقم السورة من اسم المجلد
- قراءة كل الملفات النصية (الآيات)
- بناء ملف `quran.json` بالهيكل التالي:

```json
{
  "1": {
    "1": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
    "2": "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    ...
  },
  "2": {
    "1": "الم",
    "2": "ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِلْمُتَّقِينَ",
    ...
  }
}
```

---

### 2. قراءة البيانات

```python
from quran_reader import QuranReader

# تحميل قاعدة البيانات
reader = QuranReader("quran.json")
```

#### أ) قراءة آية كاملة

```python
ayah = reader.get_ayah(surah_number=1, ayah_number=1)
print(ayah)
# بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
```

#### ب) قراءة كلمة محددة

```python
# الكلمة الأولى (index 0)
word = reader.get_word_at_index(surah_number=1, ayah_number=1, word_index=0)
print(word)
# بِسْمِ

# الكلمة الثانية (index 1)
word = reader.get_word_at_index(surah_number=1, ayah_number=1, word_index=1)
print(word)
# اللَّهِ
```

#### ج) معلومات عن سورة

```python
info = reader.get_surah_info(surah_number=1)
print(info)
# {'surah_number': 1, 'ayat_count': 7, 'ayat_numbers': [1, 2, 3, 4, 5, 6, 7]}
```

#### د) طباعة آية مع أرقام الكلمات

```python
reader.print_ayah(surah_number=1, ayah_number=1, show_word_indices=True)

# النتيجة:
# ============================================================
# السورة 1 - الآية 1
# ============================================================
# 
# [0] بِسْمِ
# [1] اللَّهِ
# [2] الرَّحْمَٰنِ
# [3] الرَّحِيمِ
# 
# عدد الكلمات: 4
# ============================================================
```

#### هـ) قراءة كل آيات سورة

```python
ayat = reader.get_all_ayat_in_surah(surah_number=1)
for ayah_num, ayah_text in ayat.items():
    print(f"{ayah_num}. {ayah_text}")
```

#### و) البحث في آية

```python
found = reader.search_in_ayah(
    surah_number=1, 
    ayah_number=1, 
    search_text="الرَّحْمَٰنِ"
)
print(found)  # True
```

#### ز) عدد الكلمات في آية

```python
count = reader.get_word_count(surah_number=1, ayah_number=1)
print(count)  # 4
```

---

## 📝 الدوال المتاحة

| الدالة | الوصف |
|--------|-------|
| `get_ayah(surah, ayah)` | الحصول على آية كاملة |
| `get_word_at_index(surah, ayah, index)` | الحصول على كلمة محددة |
| `get_surah_info(surah)` | معلومات عن السورة |
| `get_all_ayat_in_surah(surah)` | كل آيات السورة |
| `search_in_ayah(surah, ayah, text)` | البحث في آية |
| `get_word_count(surah, ayah)` | عدد كلمات الآية |
| `print_ayah(surah, ayah, show_indices)` | طباعة منسقة |

---

## 🎯 أمثلة عملية

### مثال 1: تحليل تجويدي لآية

```python
from quran_reader import QuranReader
from tajweed_engine import TajweedEngine

reader = QuranReader("quran.json")
tajweed = TajweedEngine()

# قراءة الآية
ayah = reader.get_ayah(2, 249)

# تحليل تجويدي
results = tajweed.analyze(ayah)
tajweed.print_analysis(results)
```

### مثال 2: استعراض سورة كاملة مع التحليل

```python
reader = QuranReader("quran.json")
tajweed = TajweedEngine()

# قراءة كل آيات الفاتحة
ayat = reader.get_all_ayat_in_surah(1)

for ayah_num, ayah_text in ayat.items():
    print(f"\n{'='*60}")
    print(f"الآية {ayah_num}: {ayah_text}")
    print('='*60)
    
    results = tajweed.analyze(ayah_text)
    tajweed.print_analysis(results, show_words_without_rules=False)
```

---

## ⚙️ متطلبات التشغيل

- Python 3.6+
- لا توجد مكتبات خارجية مطلوبة (استخدام المكتبات القياسية فقط)

---

## 📦 الملفات

- `build_quran_db.py` - بناء قاعدة البيانات
- `quran_reader.py` - قراءة والاستعلام عن البيانات
- `example_usage.py` - أمثلة الاستخدام
- `quran.json` - قاعدة البيانات (يتم إنشاؤها)

---

## 🔧 التخصيص

### تغيير مسار المجلد

```python
builder = QuranDatabaseBuilder(
    quran_db_path="path/to/your/quran_db",
    output_file="my_quran.json"
)
```

### تغيير ملف JSON المستخدم

```python
reader = QuranReader("my_quran.json")
```

---

## 💡 ملاحظات

- أرقام الآيات والكلمات تبدأ من 1 (ليس من 0)
- لكن الـ `word_index` يبدأ من 0 (لأنه index في Python)
- يتم تنظيف المسافات الزائدة تلقائياً
- يدعم Unicode كامل للنصوص العربية

---

## ✅ اختبار التثبيت

```bash
# بناء قاعدة البيانات
python build_quran_db.py

# تشغيل الأمثلة
python example_usage.py
```