"""Smoke test against production API to verify SDK works end-to-end."""

import os
import pytest
from zerolatency import Memory


@pytest.mark.skipif(
    not os.environ.get("ZEROLATENCY_API_KEY"),
    reason="ZEROLATENCY_API_KEY not set"
)
def test_memory_round_trip():
    """Test that we can write and recall a memory from production."""
    api_key = os.environ["ZEROLATENCY_API_KEY"]
    
    # Create client
    memory = Memory(api_key=api_key)
    
    # Test 1: Add a memory
    test_content = "User prefers dark mode theme in all applications"
    test_agent_id = "sdk-smoke-test-agent"
    
    add_response = memory.add(
        content=test_content,
        agent_id=test_agent_id,
        metadata={"test": True, "source": "smoke_test"}
    )
    
    print(f"Add response: {add_response}")
    assert add_response is not None
    
    # Test 2: Recall the memory
    recall_response = memory.recall(
        query="What theme does the user prefer?",
        agent_id=test_agent_id,
        limit=5
    )
    
    print(f"Recall response: {recall_response}")
    assert recall_response is not None
    
    # Test 3: Extract from conversation
    conversation = [
        {"role": "user", "content": "I love working late at night"},
        {"role": "assistant", "content": "That's interesting! Night owl productivity."}
    ]
    
    extract_response = memory.extract(
        conversation=conversation,
        agent_id=test_agent_id
    )
    
    print(f"Extract response: {extract_response}")
    assert extract_response is not None
    assert "job_id" in extract_response or "status" in extract_response
    
    print("✓ All smoke tests passed against production")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
