from __future__ import annotations

from typing import Any

from test_support.fixtures import fixtures_dir, make_handler_fixture_test
from timeback.server.handlers.identity_only.handler import create_identity_only_handlers
from timeback.server.types import IdentityOnlySsoConfig

FIXTURES_DIR = fixtures_dir("sdk", "handlers/identity-only/signout")


def _on_callback_success(ctx: Any) -> Any:
    return ctx.redirect("/")


def _setup(_fixture: dict[str, Any]) -> dict[str, Any]:
    identity = IdentityOnlySsoConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        on_callback_success=_on_callback_success,
    )
    handlers = create_identity_only_handlers(env="staging", identity=identity)

    async def _handler(_request: Any) -> Any:
        return handlers.sign_out()

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_only_signout_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity-only > signout",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
