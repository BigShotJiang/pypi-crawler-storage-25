"""Identity-only callback handler tests."""

from __future__ import annotations

from contextlib import ExitStack
from typing import Any
from unittest.mock import AsyncMock, patch

from starlette.responses import JSONResponse, Response

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.identity_only.handler import create_identity_only_handlers
from timeback.server.test_utils.handler_helpers import handler_fixtures_dir
from timeback.server.types import IdentityOnlySsoConfig


def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
    stubs = fixture.get("stubs", {})
    context = fixture.get("context", {})
    callback_stub = stubs.get("handleCallback", {})

    def _on_callback_success(_ctx: Any) -> Response:
        body = callback_stub.get("body", {})
        status = int(callback_stub.get("status", 200))
        return JSONResponse(body, status_code=status)

    def _on_callback_error(_ctx: Any) -> Response:
        body = callback_stub.get("body", {"error": "callback failed"})
        status = int(callback_stub.get("status", 400))
        return JSONResponse(body, status_code=status)

    identity = IdentityOnlySsoConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        on_callback_success=_on_callback_success,
        on_callback_error=_on_callback_error,
    )
    handlers = create_identity_only_handlers(
        env=context.get("env", "staging"),
        identity=identity,
    )

    email = context.get("email", "student@example.com")

    async def _handler(request: Any) -> Response:
        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.get_authorization_url",
                    new=AsyncMock(return_value="https://idp.example.com/authorize"),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.exchange_code",
                    new=AsyncMock(
                        return_value={"access_token": "fixture-token", "token_type": "Bearer"}
                    ),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.get_user_info",
                    new=AsyncMock(return_value={"sub": "fixture-sub", "email": email}),
                )
            )
            return await handlers.callback(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_only_callback_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity-only > callback",
    fixtures_dir=handler_fixtures_dir("identity-only", "callback"),
    setup=_setup,
)
