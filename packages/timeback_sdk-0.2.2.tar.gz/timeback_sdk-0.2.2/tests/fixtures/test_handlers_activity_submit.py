"""Activity submit handler tests."""

from unittest.mock import patch

from test_support.fixtures import RecordedClientCall, make_handler_fixture_test
from timeback.server.handlers.activity.submit_handler import create_submit_handler
from timeback.server.test_utils.handler_helpers import (
    fixture_context,
    handler_fixtures_dir,
)
from timeback.server.timeback import AppConfig
from timeback.server.types import (
    ActivityBeforeSendData,
    ApiCredentials,
    CompletionResult,
    CustomIdentityConfig,
)


def _make_identity(context):
    identity_ctx = context.get("identity")
    if isinstance(identity_ctx, dict):
        auth_as = identity_ctx.get("authenticatedAs")
        if auth_as is None:

            async def _get_email(_request):
                return None

            return CustomIdentityConfig(get_email=_get_email)
        if isinstance(auth_as, dict):
            email = auth_as.get("email", "student@example.com")

            async def _get_email(_request):
                return email

            return CustomIdentityConfig(get_email=_get_email)

    async def _get_email(_request):
        return "student@example.com"

    return CustomIdentityConfig(get_email=_get_email)


def _setup(fixture):
    ctx = fixture_context(fixture)
    stubs = fixture.get("stubs", {})
    calls = []

    completion_stub = stubs.get("recordCompletion")

    async def _record_completion(*_args, **_kwargs):
        calls.append(
            RecordedClientCall(client="activity", method="record_completion", args=(), kwargs={})
        )
        if isinstance(completion_stub, dict):
            if "__throw" in completion_stub:
                if completion_stub["__throw"] == "TimebackUserResolutionError":
                    from timeback.server.lib.resolve import TimebackUserResolutionError

                    raise TimebackUserResolutionError(
                        "Unable to resolve Timeback identity", "timeback_user_ambiguous"
                    )
                raise RuntimeError(completion_stub.get("__message", "Fixture stub error"))
            if "__error" in completion_stub:
                raise RuntimeError(completion_stub["__error"])
        return CompletionResult(
            success=True,
            preview=False,
            data=ActivityBeforeSendData(
                sensor="",
                actor={},
                object=None,
                event=None,
                payload={},
                course={},
                app_name="",
                api_env="staging",
                email="",
                timeback_id="",
            ),
        )

    identity = _make_identity(ctx)
    handler = create_submit_handler(
        env=ctx.get("env", "staging"),
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
        identity=identity,
        app_config=AppConfig(
            name="Fixture App",
            sensor="https://sensor.example.com",
            courses=[
                {
                    "subject": "Math",
                    "grade": 3,
                    "course_code": "MATH-3",
                    "ids": {"staging": "course-1"},
                    "sensor": "https://sensor.example.com",
                },
                {
                    "subject": "Reading",
                    "grade": 3,
                    "course_code": "READ-3",
                    "ids": {"staging": "course-2"},
                    "sensor": "https://sensor.example.com",
                },
            ],
        ),
        get_client=lambda: None,
        hooks=None,
    )

    async def _handler(request):
        with patch(
            "timeback.server.handlers.activity.submit_handler.record_completion",
            new=_record_completion,
        ):
            return await handler(request)

    return {"handler": _handler, "calls": calls}


test_sdk_handlers_activity_submit_fixtures = make_handler_fixture_test(
    name="sdk > handlers > activity > submit",
    fixtures_dir=handler_fixtures_dir("activity", "submit"),
    setup=_setup,
)
