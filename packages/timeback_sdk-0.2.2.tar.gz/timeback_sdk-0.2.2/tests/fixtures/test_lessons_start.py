"""Fixture tests for lessons.start namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_lessons_setup

FIXTURES_DIR = fixtures_dir("sdk", "lessons/start")


test_sdk_lessons_start_fixtures = make_namespace_fixture_test(
    name="sdk > lessons > start",
    fixtures_dir=FIXTURES_DIR,
    setup=create_lessons_setup("start", include_courses=False),
)
