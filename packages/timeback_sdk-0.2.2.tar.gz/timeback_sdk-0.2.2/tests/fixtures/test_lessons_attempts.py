"""Fixture tests for lessons.attempts namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_lessons_setup

FIXTURES_DIR = fixtures_dir("sdk", "lessons/attempts")


test_sdk_lessons_attempts_fixtures = make_namespace_fixture_test(
    name="sdk > lessons > attempts",
    fixtures_dir=FIXTURES_DIR,
    setup=create_lessons_setup("attempts", include_courses=True, course_ids_env="dev"),
)
