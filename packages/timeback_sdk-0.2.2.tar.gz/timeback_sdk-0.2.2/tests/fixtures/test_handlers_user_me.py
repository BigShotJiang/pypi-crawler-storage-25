"""User me handler tests."""

from contextlib import ExitStack
from unittest.mock import AsyncMock, patch

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.user.handler import create_user_handler
from timeback.server.test_utils.handler_helpers import (
    fixture_context,
    handler_fixtures_dir,
)
from timeback.server.types import ApiCredentials, CustomIdentityConfig
from timeback.shared.types import TimebackIdentity


def _make_custom_identity(ctx):
    authenticated = ctx.get("authenticated", True)
    email = ctx.get("email", "student@example.com")

    async def _get_email(_request):
        return email if authenticated else None

    return CustomIdentityConfig(get_email=_get_email)


mock_resolve = AsyncMock()
mock_profile = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    stubs = fixture.get("stubs", {})
    email = ctx.get("email", "student@example.com")

    resolve_stub = stubs.get("resolve")
    profile_stub = stubs.get("profile")

    mock_resolve.reset_mock()
    mock_resolve.side_effect = None
    if isinstance(resolve_stub, dict) and "__error" in resolve_stub:
        raw = resolve_stub["__error"]
        if isinstance(raw, dict):
            code = raw.get("code", "timeback_user_lookup_failed")
            message = raw.get("message", "Resolution failed")
            from timeback.server.lib.resolve import TimebackUserResolutionError

            mock_resolve.side_effect = TimebackUserResolutionError(message, code)
        elif isinstance(raw, str):
            mock_resolve.side_effect = RuntimeError(raw)
    else:
        value = resolve_stub or {}
        user_id = (
            value.get("id", "timeback-user-1") if isinstance(value, dict) else "timeback-user-1"
        )
        user_email = value.get("email", email) if isinstance(value, dict) else email
        mock_resolve.return_value = TimebackIdentity(id=user_id, email=user_email)

    mock_profile.reset_mock()
    mock_profile.side_effect = None
    if isinstance(profile_stub, dict) and "__error" in profile_stub:
        mock_profile.side_effect = RuntimeError(profile_stub["__error"])
    else:
        mock_profile.return_value = profile_stub

    def _profile_to_dict(profile):
        if isinstance(profile, dict):
            return profile
        if hasattr(profile, "model_dump"):
            return profile.model_dump(by_alias=True)
        return {"value": profile}

    identity = _make_custom_identity(ctx)
    handler = create_user_handler(
        env=ctx.get("env", "staging"),
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
        identity=identity,
        app_config={
            "name": "Fixture App",
            "courses": [
                {
                    "subject": "Math",
                    "grade": 3,
                    "course_code": "MATH-3",
                    "ids": {"staging": "course-1"},
                    "sensor": "https://sensor.example.com",
                }
            ],
        },
        get_client=lambda: None,
    )

    async def _handler(request):
        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.user.handler.resolve_timeback_user_by_email",
                    new=mock_resolve,
                )
            )
            stack.enter_context(
                patch("timeback.server.handlers.user.handler.build_user_profile", new=mock_profile)
            )
            stack.enter_context(
                patch("timeback.server.handlers.user.handler.profile_to_dict", new=_profile_to_dict)
            )
            return await handler(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_user_me_fixtures = make_handler_fixture_test(
    name="sdk > handlers > user > me",
    fixtures_dir=handler_fixtures_dir("user", "me"),
    setup=_setup,
)
