"""Identity-only sign-in handler tests."""

from __future__ import annotations

from contextlib import ExitStack
from typing import Any
from unittest.mock import AsyncMock, patch

from starlette.responses import Response

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.identity_only.handler import create_identity_only_handlers
from timeback.server.test_utils.handler_helpers import handler_fixtures_dir
from timeback.server.types import IdentityOnlySsoConfig


def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
    stubs = fixture.get("stubs", {})
    context = fixture.get("context", {})
    sign_in_stub = stubs.get("handleSignIn", {})

    identity = IdentityOnlySsoConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        on_callback_success=lambda _ctx: Response(),
    )
    handlers = create_identity_only_handlers(
        env=context.get("env", "staging"),
        identity=identity,
    )

    async def _handler(request: Any) -> Response:
        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.get_authorization_url",
                    new=AsyncMock(
                        return_value=sign_in_stub.get(
                            "location", "https://idp.example.com/authorize"
                        )
                    ),
                )
            )
            return await handlers.sign_in(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_only_signin_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity-only > signin",
    fixtures_dir=handler_fixtures_dir("identity-only", "signin"),
    setup=_setup,
)
