from __future__ import annotations

from typing import Any

from test_support.fixtures import fixtures_dir, make_handler_fixture_test
from timeback.server.handlers.identity.handler import create_identity_handlers
from timeback.server.types import ApiCredentials, SsoIdentityConfig

FIXTURES_DIR = fixtures_dir("sdk", "handlers/identity/signout")


async def _get_user(_request: Any) -> Any:
    return type("Identity", (), {"id": "timeback-user-1", "email": "student@example.com"})()


def _on_callback_success(ctx: Any) -> Any:
    return ctx.redirect("/")


def _setup(_fixture: dict[str, Any]) -> dict[str, Any]:
    identity = SsoIdentityConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        get_user=_get_user,
        on_callback_success=_on_callback_success,
    )
    handlers = create_identity_handlers(
        env="staging",
        identity=identity,
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
    )

    async def _handler(_request: Any) -> Any:
        return handlers.sign_out()

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_signout_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity > signout",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
