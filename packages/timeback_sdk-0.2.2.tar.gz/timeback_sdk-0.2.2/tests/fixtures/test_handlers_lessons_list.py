"""Lessons list handler tests."""

from unittest.mock import AsyncMock

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.lessons.list_handler import create_lesson_list_handler
from timeback.server.test_utils.handler_helpers import (
    configure_mock,
    fixture_context,
    handler_fixtures_dir,
    make_handler_config,
    patched_handler,
)

mock_list = AsyncMock()
mock_has_user = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    mock_has_user.reset_mock()
    mock_has_user.return_value = ctx.get("authenticated", True)
    configure_mock(mock_list, fixture.get("stubs", {}).get("lessons.list"))

    namespace = type("NS", (), {"list": mock_list})()

    return patched_handler(
        create_lesson_list_handler,
        make_handler_config(fixture),
        patches={
            "timeback.server.handlers.lessons.list_handler.create_lessons_namespace": namespace,
            "timeback.server.handlers.lessons.auth.has_lesson_user": mock_has_user,
        },
    )


test_sdk_handlers_lessons_list_fixtures = make_handler_fixture_test(
    name="sdk > handlers > lessons > list",
    fixtures_dir=handler_fixtures_dir("lessons", "list"),
    setup=_setup,
)
