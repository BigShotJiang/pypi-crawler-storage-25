"""Fixture tests for user.verify namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_user_verify_setup
from timeback.server.test_utils.namespace_stub_shapes import normalize_namespace_stubs

FIXTURES_DIR = fixtures_dir("sdk", "user/verify")

test_sdk_user_verify_fixtures = make_namespace_fixture_test(
    name="sdk > user > verify",
    fixtures_dir=FIXTURES_DIR,
    setup=create_user_verify_setup(
        stub_normalizer=lambda stubs: normalize_namespace_stubs(stubs, oneroster_users=True)
    ),
)
