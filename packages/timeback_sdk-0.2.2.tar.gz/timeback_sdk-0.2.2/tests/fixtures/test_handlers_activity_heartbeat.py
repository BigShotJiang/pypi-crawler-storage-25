"""Activity heartbeat handler tests."""

from unittest.mock import AsyncMock, patch

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.activity.heartbeat_handler import create_heartbeat_handler
from timeback.server.test_utils.handler_helpers import (
    default_app_config,
    fixture_context,
    handler_fixtures_dir,
)
from timeback.server.types import ApiCredentials, CustomIdentityConfig

mock_lookup = AsyncMock(return_value="timeback-user-1")
mock_caliper_send = AsyncMock()


def _make_identity(context):
    identity_ctx = context.get("identity")
    if isinstance(identity_ctx, dict):
        auth_as = identity_ctx.get("authenticatedAs")
        if auth_as is None:

            async def _get_email_none(_request):
                return None

            return CustomIdentityConfig(get_email=_get_email_none)
        if isinstance(auth_as, dict):
            email = auth_as.get("email", "student@example.com")

            async def _get_email_auth(_request):
                return email

            return CustomIdentityConfig(get_email=_get_email_auth)

    async def _get_email_default(_request):
        return "student@example.com"

    return CustomIdentityConfig(get_email=_get_email_default)


def _stub_get_client():
    return type(
        "Client",
        (),
        {
            "caliper": type(
                "Caliper", (), {"events": type("Events", (), {"send": mock_caliper_send})()}
            )()
        },
    )()


def _setup(fixture):
    ctx = fixture_context(fixture)
    stubs = fixture.get("stubs", {})
    lookup_stub = stubs.get("lookupTimebackId")

    mock_lookup.reset_mock()
    mock_lookup.side_effect = None
    mock_caliper_send.reset_mock()

    if isinstance(lookup_stub, dict) and ("__error" in lookup_stub or "__throw" in lookup_stub):
        from timeback.server.lib.resolve import TimebackUserResolutionError

        if "__throw" in lookup_stub and lookup_stub["__throw"] == "TimebackUserResolutionError":
            mock_lookup.side_effect = TimebackUserResolutionError(
                "Unable to resolve Timeback identity", "timeback_user_ambiguous"
            )
        elif "__error" in lookup_stub:
            raw = lookup_stub["__error"]
            if isinstance(raw, dict):
                mock_lookup.side_effect = TimebackUserResolutionError(
                    raw.get("message", "Failed"), raw.get("code", "timeback_user_lookup_failed")
                )
            elif isinstance(raw, str):
                mock_lookup.side_effect = RuntimeError(raw)
    elif isinstance(lookup_stub, str):
        mock_lookup.return_value = lookup_stub
    else:
        mock_lookup.return_value = "timeback-user-1"

    identity = _make_identity(ctx)
    handler = create_heartbeat_handler(
        env=ctx.get("env", "staging"),
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
        identity=identity,
        app_config=default_app_config(),
        get_client=_stub_get_client,
        hooks=None,
    )

    async def _handler(request):
        from timeback.server.handlers.activity import heartbeat_handler as hb_mod

        hb_mod._dedupe_cache.clear()
        with patch(
            "timeback.server.handlers.activity.heartbeat_handler.lookup_timeback_id_by_email",
            new=mock_lookup,
        ):
            return await handler(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_activity_heartbeat_fixtures = make_handler_fixture_test(
    name="sdk > handlers > activity > heartbeat",
    fixtures_dir=handler_fixtures_dir("activity", "heartbeat"),
    setup=_setup,
)
