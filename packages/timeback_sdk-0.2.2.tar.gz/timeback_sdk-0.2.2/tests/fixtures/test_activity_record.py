"""Fixture tests for activity.record namespace."""

from __future__ import annotations

from typing import Any

from test_support.fixtures import RecordedClientCall, fixtures_dir, make_namespace_fixture_test
from timeback.server.namespaces.activity import create_activity_record
from timeback.server.test_utils.recording_client import create_sdk_recording_client

FIXTURES_DIR = fixtures_dir("sdk", "activity/record")


def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
    calls: list[RecordedClientCall] = []
    recording = create_sdk_recording_client(fixture.get("stubs"))

    async def _record_wrapper(*args: Any, **kwargs: Any) -> None:
        calls.append(
            RecordedClientCall(
                client="activity", method="record_completion", args=args, kwargs=kwargs
            )
        )

    async def _time_spent_wrapper(*args: Any, **kwargs: Any) -> None:
        calls.append(
            RecordedClientCall(
                client="activity", method="send_time_spent", args=args, kwargs=kwargs
            )
        )

    record = create_activity_record(
        env="staging",
        api={"client_id": "test", "client_secret": "test"},
        app_config=type(
            "AppConfig",
            (),
            {
                "name": "Test App",
                "courses": [
                    {
                        "subject": "Math",
                        "grade": 3,
                        "sensor": "test-sensor",
                        "ids": {"staging": "course-1"},
                    },
                ],
                "sensor": "test-sensor",
            },
        )(),
        get_client=lambda: recording,
        deps={
            "record_completion": _record_wrapper,
            "send_time_spent": _time_spent_wrapper,
        },
    )

    return {"invoke": record, "calls": calls}


test_sdk_activity_record_fixtures = make_namespace_fixture_test(
    name="sdk > activity > record",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
