"""Tests for namespace fixture test utility boundaries."""

from __future__ import annotations

import pytest

from timeback.server.test_utils.namespace_helpers import (
    create_lessons_setup,
    create_user_verify_setup,
)
from timeback.server.test_utils.namespace_stub_shapes import normalize_namespace_stubs


def test_create_lessons_setup_returns_standard_shape() -> None:
    setup = create_lessons_setup("start", include_courses=False)

    result = setup({"stubs": {}})

    assert callable(result["invoke"])
    assert result["calls"] == []


@pytest.mark.asyncio
async def test_create_user_verify_setup_can_use_family_normalizer() -> None:
    setup = create_user_verify_setup(
        stub_normalizer=lambda stubs: normalize_namespace_stubs(stubs, oneroster_users=True)
    )

    result = setup(
        {
            "stubs": {
                "oneroster.users.list": {
                    "data": [{"sourcedId": "user-1", "email": "student@example.com"}]
                }
            }
        }
    )

    response = await result["invoke"]("student@example.com")

    assert response.verified is True
    assert response.timeback_id == "user-1"
    assert len(result["calls"]) == 1
    call = result["calls"][0]
    assert call.client == "oneroster"
    assert call.method == "users.list"
    assert call.kwargs["where"] == {"email": "student@example.com"}
    assert call.kwargs["limit"] == 2


def test_normalize_namespace_stubs_adds_defaults_without_mutating_input() -> None:
    source = {
        "oneroster.users.list": {"data": [{"sourcedId": "user-1"}]},
        "powerpath.assessments.getNextQuestion": {"question": {"id": "q1"}},
        "edubridge.enrollments.list": [{"metadata": {"goals": {"dailyXp": 10}}}],
    }

    normalized = normalize_namespace_stubs(
        source,
        oneroster_users=True,
        powerpath_question=True,
        edubridge_goals=True,
    )

    assert source["oneroster.users.list"]["data"][0] == {"sourcedId": "user-1"}
    assert normalized["oneroster.users.list"]["data"][0]["primaryOrg"] is None
    assert normalized["powerpath.assessments.getNextQuestion"]["question"]["difficulty"] == "medium"
    assert (
        normalized["edubridge.enrollments.list"][0]["metadata"]["goals"]["dailyActiveMinutes"]
        is None
    )
