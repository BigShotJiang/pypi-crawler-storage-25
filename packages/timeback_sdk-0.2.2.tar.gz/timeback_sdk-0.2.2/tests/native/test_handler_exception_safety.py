"""Regression tests for handler exception safety (GitHub issue #7).

Every HTTP handler must return a well-formed JSON error response for any failure.
No raw Starlette/ASGI tracebacks should ever reach the client.

Tests cover:
- Malformed JSON in request body → 400
- User callbacks (get_email/get_user) throwing → 502/500
- SSO build_state callback throwing → 500
- SSO on_callback_error/on_callback_success throwing → 500
- OIDC decode_state with malformed state → graceful handling
- Identity sign-in OIDC failures → 500
"""

from __future__ import annotations

import json
from contextlib import ExitStack
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from timeback.server.handlers.activity.heartbeat_handler import create_heartbeat_handler
from timeback.server.handlers.activity.submit_handler import create_submit_handler
from timeback.server.handlers.identity.handler import create_identity_handlers
from timeback.server.handlers.identity_only.handler import create_identity_only_handlers
from timeback.server.handlers.user.verify import create_user_verify_handler
from timeback.server.types import (
    ApiCredentials,
    CustomIdentityConfig,
    SsoIdentityConfig,
)
from timeback.shared.types import TimebackIdentity

# ─────────────────────────────────────────────────────────────────────────────
# Shared Helpers
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class MockAppConfig:
    name: str = "Test App"
    sensor: str | None = "https://sensor.example.com"
    courses: list[dict[str, Any]] = field(
        default_factory=lambda: [
            {
                "subject": "Math",
                "grade": 3,
                "course_code": "MATH-3",
                "ids": {"staging": "course-1"},
                "sensor": "https://sensor.example.com",
            }
        ]
    )


def _mock_request_with_malformed_json() -> AsyncMock:
    """Request whose .json() raises (simulating malformed body)."""
    request = AsyncMock()
    request.json = AsyncMock(side_effect=ValueError("Expecting value: line 1"))
    return request


def _mock_request_with_body(body: dict[str, Any]) -> AsyncMock:
    request = AsyncMock()
    request.json = AsyncMock(return_value=body)
    return request


def _throwing_get_email(_request: Any) -> str:
    raise RuntimeError("get_email callback exploded")


async def _async_throwing_get_email(_request: Any) -> str:
    raise RuntimeError("async get_email callback exploded")


def _throwing_get_user(_request: Any) -> TimebackIdentity:
    raise RuntimeError("get_user callback exploded")


def _parse_json_body(response: Any) -> dict[str, Any]:
    return json.loads(response.body.decode())


# ─────────────────────────────────────────────────────────────────────────────
# Heartbeat Handler
# ─────────────────────────────────────────────────────────────────────────────


class TestHeartbeatExceptionSafety:
    """heartbeat_handler must never leak raw tracebacks."""

    def _make_handler(self, *, identity: CustomIdentityConfig | None = None):
        if identity is None:

            async def _get_email(_req: Any) -> str:
                return "test@example.com"

            identity = CustomIdentityConfig(get_email=_get_email)

        return create_heartbeat_handler(
            env="staging",
            api=ApiCredentials(client_id="test", client_secret="test"),
            identity=identity,
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
        )

    @pytest.mark.asyncio
    async def test_malformed_json_returns_400(self) -> None:
        handler = self._make_handler()
        request = _mock_request_with_malformed_json()

        response = await handler(request)

        assert response.status_code == 400
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INVALID_PAYLOAD"

    @pytest.mark.asyncio
    async def test_get_email_callback_throwing_returns_error(self) -> None:
        identity = CustomIdentityConfig(get_email=_throwing_get_email)
        handler = self._make_handler(identity=identity)
        request = _mock_request_with_body({})

        response = await handler(request)

        assert response.status_code == 502
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INTERNAL_ERROR"

    @pytest.mark.asyncio
    async def test_async_get_email_callback_throwing_returns_error(self) -> None:
        identity = CustomIdentityConfig(get_email=_async_throwing_get_email)
        handler = self._make_handler(identity=identity)
        request = _mock_request_with_body({})

        response = await handler(request)

        assert response.status_code == 502
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INTERNAL_ERROR"


# ─────────────────────────────────────────────────────────────────────────────
# Submit Handler
# ─────────────────────────────────────────────────────────────────────────────


class TestSubmitExceptionSafety:
    """submit_handler must never leak raw tracebacks."""

    def _make_handler(self, *, identity: CustomIdentityConfig | None = None):
        if identity is None:

            async def _get_email(_req: Any) -> str:
                return "test@example.com"

            identity = CustomIdentityConfig(get_email=_get_email)

        return create_submit_handler(
            env="staging",
            api=ApiCredentials(client_id="test", client_secret="test"),
            identity=identity,
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
        )

    @pytest.mark.asyncio
    async def test_malformed_json_returns_400(self) -> None:
        handler = self._make_handler()
        request = _mock_request_with_malformed_json()

        response = await handler(request)

        assert response.status_code == 400
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INVALID_PAYLOAD"

    @pytest.mark.asyncio
    async def test_get_email_callback_throwing_returns_error(self) -> None:
        identity = CustomIdentityConfig(get_email=_throwing_get_email)
        handler = self._make_handler(identity=identity)
        request = _mock_request_with_body({})

        response = await handler(request)

        assert response.status_code == 502
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INTERNAL_ERROR"


# ─────────────────────────────────────────────────────────────────────────────
# Identity Handler (SSO sign-in)
# ─────────────────────────────────────────────────────────────────────────────


class TestIdentitySigninExceptionSafety:
    """sso_signin must never leak raw tracebacks."""

    def _make_handlers(self, *, build_state=None):
        async def _get_user(_req: Any) -> TimebackIdentity:
            return TimebackIdentity(id="u1", email="test@example.com")

        identity = SsoIdentityConfig(
            client_id="test",
            client_secret="test",
            get_user=_get_user,
            on_callback_success=lambda _ctx: MagicMock(),
            build_state=build_state,
        )
        return create_identity_handlers(
            env="staging",
            identity=identity,
            api=ApiCredentials(client_id="test", client_secret="test"),
        )

    @pytest.mark.asyncio
    async def test_build_state_throwing_returns_500(self) -> None:
        def _throwing_build_state(_ctx: Any) -> dict:
            raise RuntimeError("build_state exploded")

        handlers = self._make_handlers(build_state=_throwing_build_state)
        request = AsyncMock()
        request.base_url = "https://example.com/"
        request.url = MagicMock()
        request.url.path = "/api/timeback/identity/signin"

        response = await handlers.sign_in(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_oidc_discovery_failure_returns_500(self) -> None:
        handlers = self._make_handlers()
        request = AsyncMock()
        request.base_url = "https://example.com/"
        request.url = MagicMock()
        request.url.path = "/api/timeback/identity/signin"

        with patch(
            "timeback.server.handlers.identity.handler.OIDCClient.get_authorization_url",
            new=AsyncMock(side_effect=Exception("OIDC discovery failed")),
        ):
            response = await handlers.sign_in(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body


# ─────────────────────────────────────────────────────────────────────────────
# Identity Handler (SSO callback)
# ─────────────────────────────────────────────────────────────────────────────


class TestIdentityCallbackExceptionSafety:
    """sso_callback must never leak raw tracebacks."""

    def _make_handlers(
        self,
        *,
        on_callback_error=None,
        on_callback_success=None,
    ):
        async def _get_user(_req: Any) -> TimebackIdentity:
            return TimebackIdentity(id="u1", email="test@example.com")

        identity = SsoIdentityConfig(
            client_id="test",
            client_secret="test",
            get_user=_get_user,
            on_callback_success=on_callback_success,
            on_callback_error=on_callback_error,
        )
        return create_identity_handlers(
            env="staging",
            identity=identity,
            api=ApiCredentials(client_id="test", client_secret="test"),
        )

    def _make_callback_request(self, *, code: str | None = "auth-code", error: str | None = None):
        request = AsyncMock()
        request.base_url = "https://example.com/"
        request.url = MagicMock()
        request.url.path = "/api/timeback/identity/callback"
        params: dict[str, str] = {}
        if code:
            params["code"] = code
        if error:
            params["error"] = error
            params["error_description"] = "IdP error details"
        request.query_params = params
        return request

    @pytest.mark.asyncio
    async def test_on_callback_error_throwing_returns_json(self) -> None:
        """If on_callback_error itself throws, we still return JSON."""

        def _throwing_on_error(_ctx: Any) -> None:
            raise RuntimeError("on_callback_error exploded")

        handlers = self._make_handlers(on_callback_error=_throwing_on_error)
        request = self._make_callback_request(code=None, error="access_denied")

        response = await handlers.callback(request)

        assert response.status_code == 400
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_on_callback_success_throwing_returns_500(self) -> None:
        """If on_callback_success throws, we return 500 JSON."""

        def _throwing_on_success(_ctx: Any) -> None:
            raise RuntimeError("on_callback_success exploded")

        handlers = self._make_handlers(on_callback_success=_throwing_on_success)
        request = self._make_callback_request(code="auth-code")

        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.exchange_code",
                    new=AsyncMock(return_value={"access_token": "tok", "token_type": "Bearer"}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.get_user_info",
                    new=AsyncMock(return_value={"sub": "s1", "email": "test@example.com"}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.resolve_timeback_user_by_email",
                    new=AsyncMock(return_value=TimebackIdentity(id="u1", email="test@example.com")),
                )
            )
            response = await handlers.callback(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_malformed_state_param_handled_gracefully(self) -> None:
        """Malformed state param should not crash the callback."""

        def _on_success(_ctx: Any):
            from starlette.responses import JSONResponse

            return JSONResponse({"ok": True})

        handlers = self._make_handlers(on_callback_success=_on_success)
        request = self._make_callback_request(code="auth-code")
        request.query_params = {"code": "auth-code", "state": "not-valid-base64!!!"}

        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.exchange_code",
                    new=AsyncMock(return_value={"access_token": "tok", "token_type": "Bearer"}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.get_user_info",
                    new=AsyncMock(return_value={"sub": "s1", "email": "test@example.com"}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.resolve_timeback_user_by_email",
                    new=AsyncMock(return_value=TimebackIdentity(id="u1", email="test@example.com")),
                )
            )
            response = await handlers.callback(request)

        assert response.status_code in (200, 302, 500)


# ─────────────────────────────────────────────────────────────────────────────
# Identity-Only Handler
# ─────────────────────────────────────────────────────────────────────────────


class TestIdentityOnlyExceptionSafety:
    """identity_only handlers must never leak raw tracebacks."""

    def _make_handlers(self, *, build_state=None, on_callback_error=None, on_callback_success=None):
        from timeback.server.types import IdentityOnlySsoConfig

        identity = IdentityOnlySsoConfig(
            client_id="test",
            client_secret="test",
            build_state=build_state,
            on_callback_error=on_callback_error,
            on_callback_success=on_callback_success,
        )
        return create_identity_only_handlers(env="staging", identity=identity)

    def _make_signin_request(self):
        request = AsyncMock()
        request.base_url = "https://example.com/"
        request.url = MagicMock()
        request.url.path = "/api/timeback/identity/signin"
        return request

    def _make_callback_request(self, *, code: str | None = "auth-code", error: str | None = None):
        request = AsyncMock()
        request.base_url = "https://example.com/"
        request.url = MagicMock()
        request.url.path = "/api/timeback/identity/callback"
        params: dict[str, str] = {}
        if code:
            params["code"] = code
        if error:
            params["error"] = error
            params["error_description"] = "IdP error details"
        request.query_params = params
        return request

    @pytest.mark.asyncio
    async def test_build_state_throwing_returns_500(self) -> None:
        def _throwing_build_state(_ctx: Any) -> dict:
            raise RuntimeError("build_state exploded")

        handlers = self._make_handlers(build_state=_throwing_build_state)
        request = self._make_signin_request()

        with patch(
            "timeback.server.handlers.identity_only.handler.OIDCClient.get_authorization_url",
            new=AsyncMock(return_value="https://idp.example.com/authorize"),
        ):
            response = await handlers.sign_in(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_oidc_failure_in_signin_returns_500(self) -> None:
        handlers = self._make_handlers()
        request = self._make_signin_request()

        with patch(
            "timeback.server.handlers.identity_only.handler.OIDCClient.get_authorization_url",
            new=AsyncMock(side_effect=Exception("OIDC discovery failed")),
        ):
            response = await handlers.sign_in(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_on_callback_error_throwing_returns_json(self) -> None:
        def _throwing_on_error(_ctx: Any) -> None:
            raise RuntimeError("on_callback_error exploded")

        handlers = self._make_handlers(on_callback_error=_throwing_on_error)
        request = self._make_callback_request(code=None, error="access_denied")

        response = await handlers.callback(request)

        assert response.status_code == 400
        body = _parse_json_body(response)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_on_callback_success_throwing_returns_500(self) -> None:
        def _throwing_on_success(_ctx: Any) -> None:
            raise RuntimeError("on_callback_success exploded")

        handlers = self._make_handlers(on_callback_success=_throwing_on_success)
        request = self._make_callback_request(code="auth-code")

        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.exchange_code",
                    new=AsyncMock(return_value={"access_token": "tok", "token_type": "Bearer"}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity_only.handler.OIDCClient.get_user_info",
                    new=AsyncMock(return_value={"sub": "s1", "email": "test@example.com"}),
                )
            )
            response = await handlers.callback(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert "error" in body


# ─────────────────────────────────────────────────────────────────────────────
# User Verify Handler
# ─────────────────────────────────────────────────────────────────────────────


class TestUserVerifyExceptionSafety:
    """user/verify handler must never leak raw tracebacks."""

    def _make_handler(self, *, identity: CustomIdentityConfig | None = None):
        if identity is None:

            async def _get_email(_req: Any) -> str:
                return "test@example.com"

            identity = CustomIdentityConfig(get_email=_get_email)

        return create_user_verify_handler(
            env="staging",
            api=ApiCredentials(client_id="test", client_secret="test"),
            identity=identity,
            get_client=lambda: MagicMock(),
        )

    @pytest.mark.asyncio
    async def test_get_email_callback_throwing_returns_500(self) -> None:
        identity = CustomIdentityConfig(get_email=_throwing_get_email)
        handler = self._make_handler(identity=identity)
        request = AsyncMock()

        response = await handler(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INTERNAL_ERROR"

    @pytest.mark.asyncio
    async def test_get_user_callback_throwing_returns_500(self) -> None:
        identity = SsoIdentityConfig(
            client_id="test",
            client_secret="test",
            get_user=_throwing_get_user,
            on_callback_success=lambda _ctx: MagicMock(),
        )
        handler = create_user_verify_handler(
            env="staging",
            api=ApiCredentials(client_id="test", client_secret="test"),
            identity=identity,
            get_client=lambda: MagicMock(),
        )
        request = AsyncMock()

        response = await handler(request)

        assert response.status_code == 500
        body = _parse_json_body(response)
        assert body["error"]["code"] == "INTERNAL_ERROR"
