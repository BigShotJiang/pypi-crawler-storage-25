"""Unit tests for activity handler schema validation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from timeback.server.handlers.activity.schema import (
    validate_heartbeat_request,
    validate_submit_request,
)


@dataclass
class MockAppConfig:
    """Minimal app config shape used by activity schema validation."""

    sensor: str | None = "https://default-sensor.example.com"
    courses: list[dict[str, Any]] = field(
        default_factory=lambda: [
            {
                "subject": "Math",
                "grade": 3,
                "course_code": "MATH-3",
                "ids": {"staging": "staging-math-3"},
                "sensor": "https://math-sensor.example.com",
            },
            {
                "subject": "Reading",
                "grade": 3,
                "course_code": "READ-3",
                "ids": {"staging": "staging-read-3"},
            },
        ]
    )


def _error_body(response: Any) -> dict[str, Any]:
    """Decode JSONResponse payload into a dict."""
    return json.loads(response.body.decode("utf-8"))


def _valid_heartbeat_payload() -> dict[str, Any]:
    return {
        "id": "activity-123",
        "name": "Lesson 1",
        "course": {"subject": "Math", "grade": 3},
        "runId": "550e8400-e29b-41d4-a716-446655440000",
        "startedAt": "2024-03-15T10:00:00Z",
        "endedAt": "2024-03-15T10:05:00Z",
        "elapsedMs": 300000,
        "pausedMs": 0,
    }


def _valid_submit_payload() -> dict[str, Any]:
    return {
        "id": "activity-123",
        "name": "Lesson 1",
        "course": {"subject": "Math", "grade": 3},
        "runId": "550e8400-e29b-41d4-a716-446655440000",
        "endedAt": "2024-03-15T10:30:00Z",
        "metrics": {
            "totalQuestions": 10,
            "correctQuestions": 8,
            "xpEarned": 100,
        },
    }


class TestValidateHeartbeatRequest:
    """Tests for validate_heartbeat_request."""

    def test_returns_ok_with_payload_course_and_sensor(self) -> None:
        result = validate_heartbeat_request(_valid_heartbeat_payload(), MockAppConfig())

        assert result.ok is True
        assert result.payload.run_id == "550e8400-e29b-41d4-a716-446655440000"
        assert result.course["course_code"] == "MATH-3"
        assert result.sensor == "https://math-sensor.example.com"

    def test_returns_400_for_invalid_payload(self) -> None:
        result = validate_heartbeat_request({}, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"]["code"] == "INVALID_PAYLOAD"
        assert body["error"]["message"] == "Invalid payload"

    def test_returns_400_for_unknown_course(self) -> None:
        payload = _valid_heartbeat_payload()
        payload["course"] = {"subject": "Writing", "grade": 1}
        result = validate_heartbeat_request(payload, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "UNKNOWN_COURSE",
            "message": "Unknown course: Writing grade 1",
        }

    def test_returns_500_for_ambiguous_course_selector(self) -> None:
        config = MockAppConfig(
            courses=[
                {"subject": "Math", "grade": 3, "course_code": "MATH-3A"},
                {"subject": "Math", "grade": 3, "course_code": "MATH-3B"},
            ]
        )
        result = validate_heartbeat_request(_valid_heartbeat_payload(), config)

        assert result.ok is False
        assert result.response.status_code == 500
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "AMBIGUOUS_COURSE_SELECTOR",
            "message": "Ambiguous course selector in timeback.config.json",
        }

    def test_returns_500_for_missing_sensor(self) -> None:
        config = MockAppConfig(
            sensor=None,
            courses=[
                {"subject": "Math", "grade": 3, "course_code": "MATH-3"},
            ],
        )
        result = validate_heartbeat_request(_valid_heartbeat_payload(), config)

        assert result.ok is False
        assert result.response.status_code == 500
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "MISSING_SENSOR",
            "message": 'Course "Math grade 3" has no sensor configured.',
        }

    def test_trims_non_empty_strings_before_building_payload(self) -> None:
        payload = _valid_heartbeat_payload()
        payload["id"] = "  activity-123  "
        payload["name"] = "  Lesson 1  "
        payload["course"] = {"code": "  MATH-3  "}

        result = validate_heartbeat_request(payload, MockAppConfig())

        assert result.ok is True
        assert result.payload.id == "activity-123"
        assert result.payload.name == "Lesson 1"
        assert result.payload.course.code == "MATH-3"

    def test_rejects_whitespace_only_code_based_course_selector(self) -> None:
        payload = _valid_heartbeat_payload()
        payload["course"] = {"code": "   "}

        result = validate_heartbeat_request(payload, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"]["details"] == {
            "field": "course.code",
            "message": "Expected non-empty string",
        }


class TestValidateSubmitRequest:
    """Tests for validate_submit_request."""

    def test_returns_ok_with_payload_course_and_sensor(self) -> None:
        result = validate_submit_request(_valid_submit_payload(), MockAppConfig())

        assert result.ok is True
        assert result.payload.run_id == "550e8400-e29b-41d4-a716-446655440000"
        assert result.course["course_code"] == "MATH-3"
        assert result.sensor == "https://math-sensor.example.com"

    def test_returns_400_for_invalid_payload(self) -> None:
        result = validate_submit_request({}, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"]["code"] == "INVALID_PAYLOAD"
        assert body["error"]["message"] == "Invalid payload"

    def test_returns_400_for_unknown_course(self) -> None:
        payload = _valid_submit_payload()
        payload["course"] = {"subject": "Writing", "grade": 1}
        result = validate_submit_request(payload, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "UNKNOWN_COURSE",
            "message": "Unknown course: Writing grade 1",
        }

    def test_returns_500_for_ambiguous_course_selector(self) -> None:
        config = MockAppConfig(
            courses=[
                {"subject": "Math", "grade": 3, "course_code": "MATH-3A"},
                {"subject": "Math", "grade": 3, "course_code": "MATH-3B"},
            ]
        )
        result = validate_submit_request(_valid_submit_payload(), config)

        assert result.ok is False
        assert result.response.status_code == 500
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "AMBIGUOUS_COURSE_SELECTOR",
            "message": "Ambiguous course selector in timeback.config.json",
        }

    def test_returns_500_for_missing_sensor(self) -> None:
        config = MockAppConfig(
            sensor=None,
            courses=[
                {"subject": "Math", "grade": 3, "course_code": "MATH-3"},
            ],
        )
        result = validate_submit_request(_valid_submit_payload(), config)

        assert result.ok is False
        assert result.response.status_code == 500
        body = _error_body(result.response)
        assert body["error"] == {
            "code": "MISSING_SENSOR",
            "message": 'Course "Math grade 3" has no sensor configured.',
        }

    def test_rejects_whitespace_only_required_string_fields(self) -> None:
        payload = _valid_submit_payload()
        payload["id"] = "   "

        result = validate_submit_request(payload, MockAppConfig())

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"]["details"] == {"field": "id", "message": "Required"}
