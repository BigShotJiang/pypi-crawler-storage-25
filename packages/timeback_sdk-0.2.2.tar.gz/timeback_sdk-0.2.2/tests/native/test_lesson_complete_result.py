"""Regression test: to_lesson_complete_result must always populate lesson_type and attempt.

When final_result is None (powerpath-100 lessons, already-finalized quizzes),
the function must fall back to progress for lessonType and attempt instead of
omitting them.
"""

from __future__ import annotations

from timeback.server.namespaces.lessons.helpers import to_lesson_complete_result


class TestLessonCompleteResultFallback:
    """Ensure lesson_type and attempt are populated from progress when final_result is absent."""

    def test_no_final_result_falls_back_to_progress(self) -> None:
        """When final_result is None, lesson_type and attempt come from progress."""
        progress = {
            "lessonType": "powerpath-100",
            "attempt": 3,
            "score": 95,
            "totalQuestions": 10,
            "correctQuestions": 9,
            "accuracy": 0.9,
        }

        result = to_lesson_complete_result(progress, final_result=None)

        assert result["lesson_type"] == "powerpath-100"
        assert result["attempt"] == 3

    def test_final_result_takes_precedence(self) -> None:
        """When final_result provides lessonType/attempt, those win over progress."""
        progress = {
            "lessonType": "quiz",
            "attempt": 1,
            "score": 80,
            "totalQuestions": 5,
            "correctQuestions": 4,
            "accuracy": 0.8,
            "finalized": True,
        }
        final_result = {"lessonType": "quiz", "attempt": 2}

        result = to_lesson_complete_result(progress, final_result=final_result)

        assert result["lesson_type"] == "quiz"
        assert result["attempt"] == 2

    def test_final_result_missing_fields_falls_back(self) -> None:
        """When final_result exists but lacks lessonType/attempt, progress is used."""
        progress = {
            "lessonType": "quiz",
            "attempt": 1,
            "score": 70,
            "totalQuestions": 10,
            "correctQuestions": 7,
            "accuracy": 0.7,
            "finalized": True,
        }
        final_result = {"someOtherField": True}

        result = to_lesson_complete_result(progress, final_result=final_result)

        assert result["lesson_type"] == "quiz"
        assert result["attempt"] == 1

    def test_neither_source_has_attempt(self) -> None:
        """When neither progress nor final_result has attempt, key is absent."""
        progress = {
            "lessonType": "quiz",
            "score": 50,
            "totalQuestions": 4,
            "correctQuestions": 2,
            "accuracy": 0.5,
            "finalized": True,
        }

        result = to_lesson_complete_result(progress, final_result=None)

        assert result["lesson_type"] == "quiz"
        assert "attempt" not in result

    def test_progress_fields_always_populated(self) -> None:
        """Score, total_questions, accuracy etc. always come from progress."""
        progress = {
            "lessonType": "powerpath-100",
            "attempt": 2,
            "score": 100,
            "totalQuestions": 15,
            "correctQuestions": 12,
            "accuracy": 0.8,
        }

        result = to_lesson_complete_result(progress, final_result=None)

        assert result["score"] == 100
        assert result["total_questions"] == 15
        assert result["correct_questions"] == 12
        assert result["accuracy"] == 0.8
        assert result["finalized"] is True
