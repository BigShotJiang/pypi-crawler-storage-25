"""Regression test: lessons.list() must accept raw dict course references.

The programmatic namespace (timeback.lessons.list) receives course refs as
plain dicts from LessonListInput, but resolve_activity_course uses isinstance
checks against SubjectGradeCourseRef / CourseCodeRef dataclasses. Without
normalisation, a dict never matches and raises TypeError.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from timeback.server.namespaces.lessons.list import create_list
from timeback.shared.types import CourseCodeRef, SubjectGradeCourseRef


def _make_config(courses: list[dict[str, Any]]) -> dict[str, Any]:
    """Build a minimal LessonsNamespaceConfig stub."""
    app_config = MagicMock()
    app_config.courses = courses

    client = MagicMock()
    oneroster = MagicMock()
    course_scope = MagicMock()
    course_scope.components = AsyncMock(return_value=[])
    oneroster.courses = MagicMock(return_value=course_scope)
    client.oneroster = oneroster

    return {
        "env": "staging",
        "app_config": app_config,
        "get_client": lambda: client,
    }


COURSES: list[dict[str, Any]] = [
    {
        "subject": "Math",
        "grade": 3,
        "course_code": "MATH-3",
        "ids": {"staging": "staging-math-3"},
    },
    {
        "subject": "Other",
        "course_code": "CS-101",
        "ids": {"staging": "staging-cs-101"},
    },
]


class TestLessonsListCourseRefNormalization:
    """Ensure list_lessons normalises dict course refs to dataclasses."""

    @pytest.mark.asyncio
    async def test_subject_grade_dict_does_not_raise(self) -> None:
        """A subject+grade dict must be accepted, not raise TypeError."""
        config = _make_config(COURSES)
        list_fn = create_list(config)

        result = await list_fn({"course": {"subject": "Math", "grade": 3}})

        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_code_dict_does_not_raise(self) -> None:
        """A code dict must be accepted, not raise TypeError."""
        config = _make_config(COURSES)
        list_fn = create_list(config)

        result = await list_fn({"course": {"code": "CS-101"}})

        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_subject_grade_dataclass_still_works(self) -> None:
        """Passing the dataclass directly (HTTP handler path) must still work."""
        config = _make_config(COURSES)
        list_fn = create_list(config)

        result = await list_fn({"course": SubjectGradeCourseRef(subject="Math", grade=3)})

        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_code_dataclass_still_works(self) -> None:
        """Passing a CourseCodeRef directly must still work."""
        config = _make_config(COURSES)
        list_fn = create_list(config)

        result = await list_fn({"course": CourseCodeRef(code="CS-101")})

        assert isinstance(result, list)
