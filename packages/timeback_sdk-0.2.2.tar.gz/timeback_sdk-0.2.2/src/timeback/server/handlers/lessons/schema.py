"""Lessons handler request schema validation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field, field_validator

from timeback_common import NonEmptyString  # noqa: TC001

from ...lib.utils import error_response

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response


@dataclass
class ParseResult:
    """Result of parsing a request payload."""

    ok: bool
    payload: Any = None
    response: Any = None


def _ok(payload: Any) -> ParseResult:
    return ParseResult(ok=True, payload=payload)


def _fail(response: Response) -> ParseResult:
    return ParseResult(ok=False, response=response)


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic request schemas
# ─────────────────────────────────────────────────────────────────────────────


class ListPayload(BaseModel):
    """Schema for list request payload."""

    course: Any | None = None

    @field_validator("course", mode="before")
    @classmethod
    def validate_course_ref(cls, v: Any) -> Any:
        if v is None:
            return None
        if not isinstance(v, dict):
            msg = "course must be an object"
            raise ValueError(msg)
        if "code" in v:
            code = v.get("code")
            if not isinstance(code, str) or code.strip() == "":
                msg = "course.code must be a non-empty string"
                raise ValueError(msg)
            from ....shared.types import CourseCodeRef

            return CourseCodeRef(code=code.strip())
        if "subject" in v and "grade" in v:
            from typing import get_args

            from ....shared.types import SubjectGradeCourseRef, TimebackGrade, TimebackSubject

            subject = v["subject"]
            grade = v["grade"]
            valid_subjects = get_args(TimebackSubject)
            valid_grades = get_args(TimebackGrade)
            if subject not in valid_subjects:
                msg = f"course.subject must be one of {list(valid_subjects)}"
                raise ValueError(msg)
            if grade not in valid_grades:
                msg = f"course.grade must be one of {list(valid_grades)}"
                raise ValueError(msg)
            return SubjectGradeCourseRef(subject=subject, grade=grade)
        msg = "course must have either {subject, grade} or {code}"
        raise ValueError(msg)

    model_config = {"arbitrary_types_allowed": True}


class StartPayload(BaseModel):
    """Schema for lesson start request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")
    force_new: bool | None = Field(default=None, alias="forceNew")

    model_config = {"populate_by_name": True}


class NextPayload(BaseModel):
    """Schema for lesson next request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")
    lesson_type: NonEmptyString | None = Field(default=None, alias="lessonType")

    model_config = {"populate_by_name": True}


class SubmitPayload(BaseModel):
    """Schema for lesson submit request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")
    question_id: NonEmptyString = Field(alias="questionId")
    response: NonEmptyString

    model_config = {"populate_by_name": True}


class CompletePayload(BaseModel):
    """Schema for lesson complete request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")

    model_config = {"populate_by_name": True}


class AttemptsPayload(BaseModel):
    """Schema for lesson attempts request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")

    model_config = {"populate_by_name": True}


class AttemptDetailsPayload(BaseModel):
    """Schema for lesson attempt details request payload."""

    lesson_id: NonEmptyString = Field(alias="lessonId")
    attempt: int = Field(gt=0)

    model_config = {"populate_by_name": True}

    @field_validator("attempt", mode="before")
    @classmethod
    def validate_attempt_is_int(cls, v: Any) -> int:
        if isinstance(v, bool) or not isinstance(v, int):
            msg = "attempt must be an integer"
            raise ValueError(msg)
        return v


# ─────────────────────────────────────────────────────────────────────────────
# Parse helpers
# ─────────────────────────────────────────────────────────────────────────────


async def _parse_body(request: Request) -> dict[str, Any] | None:
    """Parse the request body as JSON."""
    try:
        body = await request.json()
        if not isinstance(body, dict):
            return None
        return body
    except Exception:
        return None


async def _parse_with_schema(request: Request, schema: type[BaseModel]) -> ParseResult:
    """Parse and validate request body with a Pydantic schema."""
    body = await _parse_body(request)
    if body is None:
        return _fail(error_response("INVALID_PAYLOAD", "Invalid JSON body", 400))
    try:
        parsed = schema.model_validate(body)
        return _ok(parsed)
    except Exception as exc:
        return _fail(
            error_response(
                "INVALID_PAYLOAD",
                "Invalid payload",
                400,
                details=str(exc),
            )
        )


# ─────────────────────────────────────────────────────────────────────────────
# Public parse functions
# ─────────────────────────────────────────────────────────────────────────────


async def parse_list_payload(request: Request) -> ParseResult:
    """Parse list request payload."""
    body = await _parse_body(request)
    if body is None:
        return _fail(error_response("INVALID_PAYLOAD", "Invalid JSON body", 400))
    try:
        return _ok(ListPayload.model_validate(body))
    except Exception as exc:
        return _fail(error_response("INVALID_PAYLOAD", "Invalid payload", 400, details=str(exc)))


async def parse_start_payload(request: Request) -> ParseResult:
    """Parse start request payload."""
    return await _parse_with_schema(request, StartPayload)


async def parse_next_payload(request: Request) -> ParseResult:
    """Parse next request payload."""
    return await _parse_with_schema(request, NextPayload)


async def parse_submit_payload(request: Request) -> ParseResult:
    """Parse submit request payload."""
    return await _parse_with_schema(request, SubmitPayload)


async def parse_complete_payload(request: Request) -> ParseResult:
    """Parse complete request payload."""
    return await _parse_with_schema(request, CompletePayload)


async def parse_attempts_payload(request: Request) -> ParseResult:
    """Parse attempts request payload."""
    return await _parse_with_schema(request, AttemptsPayload)


async def parse_attempt_details_payload(request: Request) -> ParseResult:
    """Parse attempt details request payload."""
    return await _parse_with_schema(request, AttemptDetailsPayload)
