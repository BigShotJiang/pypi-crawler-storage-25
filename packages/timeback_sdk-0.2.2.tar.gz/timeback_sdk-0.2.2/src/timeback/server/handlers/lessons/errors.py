"""Lessons handler error helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...lib.logger import create_scoped_logger
from ...lib.resolve import TimebackUserResolutionError, resolve_status_for_user_resolution_error
from ...lib.utils import error_response
from ...namespaces.lessons.next import LessonTypeMismatchError

if TYPE_CHECKING:
    from starlette.responses import Response

log = create_scoped_logger("handlers.lessons")


def to_lesson_error_response(error: BaseException, message: str) -> Response:
    """Convert an exception into an API error response.

    Args:
        error: Thrown error
        message: Context message for logs

    Returns:
        Error response
    """
    if isinstance(error, TimebackUserResolutionError):
        return error_response(
            "USER_RESOLUTION_FAILED",
            "Unable to resolve Timeback identity",
            resolve_status_for_user_resolution_error(error),
        )

    if isinstance(error, LessonTypeMismatchError):
        return error_response("LESSON_TYPE_MISMATCH", str(error), 400)

    detail = str(error) if isinstance(error, Exception) else "Unknown error"
    log.error("%s: %s", message, detail)
    return error_response("INTERNAL_ERROR", detail, 500)
