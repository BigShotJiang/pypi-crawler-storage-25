"""Lessons handler authentication helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...lib.resolve import lookup_timeback_id_by_email
from ..activity.submit_handler import get_activity_user_info

if TYPE_CHECKING:
    from starlette.requests import Request

    from .types import LessonsHandlerConfig


async def resolve_lesson_student_id(
    config: LessonsHandlerConfig,
    request: Request,
) -> str | None:
    """Resolve the authenticated student's sourcedId for lesson operations.

    Args:
        config: Lessons handler config
        request: Incoming HTTP request

    Returns:
        Student sourcedId or None when unauthorized
    """
    user_info = await get_activity_user_info(config["identity"], request)
    if not user_info:
        return None
    if user_info.timeback_id:
        return user_info.timeback_id
    return await lookup_timeback_id_by_email(email=user_info.email, client=config["get_client"]())


async def has_lesson_user(
    config: LessonsHandlerConfig,
    request: Request,
) -> bool:
    """Check if the request has an authenticated user context.

    Args:
        config: Lessons handler config
        request: Incoming HTTP request

    Returns:
        True when user context exists
    """
    user_info = await get_activity_user_info(config["identity"], request)
    return user_info is not None
