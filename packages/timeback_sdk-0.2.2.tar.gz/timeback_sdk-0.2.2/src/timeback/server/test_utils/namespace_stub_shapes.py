"""Package-local stub shape normalizers for namespace fixture tests.

This module is intentionally narrow:
- only family-level shape completion for shared fixture stubs
- no branching by fixture file
- no unbounded accumulation of dot-path-specific behavior

If this grows beyond a few conceptual families, split it by family rather than
turning it into a long central registry.
"""

from __future__ import annotations

import copy
from typing import Any


def normalize_namespace_stubs(
    stubs: dict[str, Any] | None,
    *,
    oneroster_users: bool = False,
    powerpath_question: bool = False,
    powerpath_assessment_progress: bool = False,
    edubridge_goals: bool = False,
) -> dict[str, Any]:
    normalized = copy.deepcopy(stubs or {})
    if oneroster_users:
        _apply_oneroster_user_defaults(normalized.get("oneroster.users.list"))
    if powerpath_question:
        _apply_powerpath_question_defaults(normalized.get("powerpath.assessments.getNextQuestion"))
    if powerpath_assessment_progress:
        _apply_powerpath_assessment_progress_defaults(
            normalized.get("powerpath.assessments.getAssessmentProgress")
        )
    if edubridge_goals:
        _apply_edubridge_goal_defaults(normalized.get("edubridge.enrollments.list"))
    return normalized


def _apply_oneroster_user_defaults(stub: Any) -> None:
    if not isinstance(stub, dict):
        return
    users = stub.get("data")
    if not isinstance(users, list):
        return
    for user in users:
        if not isinstance(user, dict):
            continue
        user.setdefault("primaryOrg", None)
        user.setdefault("orgs", None)
        user.setdefault("grades", None)
        user.setdefault("givenName", None)
        user.setdefault("familyName", None)
        user.setdefault("roles", None)


def _apply_powerpath_question_defaults(stub: Any) -> None:
    if not isinstance(stub, dict):
        return
    question = stub.get("question")
    if not isinstance(question, dict):
        return
    question.setdefault("difficulty", "medium")
    question.setdefault("humanApproved", False)
    question.setdefault("response", None)
    question.setdefault("responses", None)
    question.setdefault("correct", None)
    question.setdefault("result", None)
    question.setdefault("resultId", None)
    question.setdefault("learningObjectives", None)


def _apply_powerpath_assessment_progress_defaults(stub: Any) -> None:
    if not isinstance(stub, dict):
        return
    stub.setdefault("questions", [])
    stub.setdefault("attempt", 0)
    stub.setdefault("accuracy", 0)
    stub.setdefault("correctQuestions", 0)
    stub.setdefault("totalQuestions", 0)

    questions = stub.get("questions")
    if not isinstance(questions, list):
        return
    for question in questions:
        if not isinstance(question, dict):
            continue
        question.setdefault("difficulty", "medium")


def _apply_edubridge_goal_defaults(stub: Any) -> None:
    if not isinstance(stub, list):
        return
    for enrollment in stub:
        if not isinstance(enrollment, dict):
            continue
        metadata = enrollment.get("metadata")
        if not isinstance(metadata, dict):
            continue
        goals = metadata.get("goals")
        if not isinstance(goals, dict):
            continue
        goals.setdefault("dailyActiveMinutes", None)
        goals.setdefault("dailyAccuracy", None)
        goals.setdefault("dailyMasteredUnits", None)
