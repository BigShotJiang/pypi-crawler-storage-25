"""Shared handler fixture helpers (mirrors TS handler-helpers.ts).

Generic utilities for handler fixture tests. No domain-specific logic —
just the mechanical boilerplate that every handler test needs.
"""

from __future__ import annotations

from contextlib import ExitStack
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, patch

from starlette.responses import Response

from test_support.fixtures import fixtures_dir

from ..timeback import AppConfig

if TYPE_CHECKING:
    from collections.abc import Callable


def handler_fixtures_dir(*segments: str) -> Any:
    """Resolve a handler fixtures directory under the SDK fixtures root."""
    return fixtures_dir("sdk", f"handlers/{'/'.join(segments)}")


def fixture_context(fixture: dict[str, Any]) -> dict[str, Any]:
    """Read ``fixture.context`` as a typed record."""
    return fixture.get("context") or {}


def make_handler_config(fixture: dict[str, Any]) -> dict[str, Any]:
    """Build the standard handler config from fixture context."""
    ctx = fixture_context(fixture)
    authenticated = ctx.get("authenticated", True)
    email = ctx.get("email", "student@example.com")
    timeback_id = ctx.get("timebackId", "student-1")

    async def _get_user(_request: Any) -> Any:
        if not authenticated:
            return None
        from ...shared.types import TimebackIdentity

        return TimebackIdentity(id=timeback_id, email=email)

    from ..types import SsoIdentityConfig

    identity = SsoIdentityConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        get_user=_get_user,
        on_callback_success=lambda _ctx: Response(),
    )

    return {
        "env": ctx.get("env", "staging"),
        "identity": identity,
        "app_config": {
            "name": "Fixture App",
            "courses": [
                {
                    "subject": "Math",
                    "grade": 3,
                    "course_code": "MATH-3",
                    "ids": {"staging": "course-1", "production": "course-1-prod"},
                    "sensor": "https://sensor.example.com",
                },
            ],
        },
        "get_client": lambda: None,
    }


def configure_mock(mock: AsyncMock, stub: Any) -> None:
    """Configure an AsyncMock from a fixture stub value."""
    mock.reset_mock()
    if stub is None:
        return
    if isinstance(stub, dict) and "__error" in stub:
        mock.side_effect = RuntimeError(stub["__error"])
    else:
        mock.side_effect = None
        mock.return_value = stub


def patched_handler(
    factory: Callable[..., Any],
    config: dict[str, Any],
    *,
    patches: dict[str, Any],
) -> dict[str, Any]:
    """Create a handler wrapped in patches. Absorbs ``unittest.mock.patch`` verbosity.

    Each key in *patches* is a dotted import path; values are either:
    - a mock/object to use as ``new`` (for callables)
    - any value to use as ``return_value`` (for factories)
    """

    async def _handler(request: Any) -> Response:
        with ExitStack() as stack:
            for target, value in patches.items():
                if callable(value):
                    stack.enter_context(patch(target, new=value))
                else:
                    stack.enter_context(patch(target, return_value=value))
            h = factory(config)
            return await h(request)

    return {"handler": _handler, "calls": []}


# ─────────────────────────────────────────────────────────────────────────────
# Fake client stubs for activity handlers
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class _FakeOneRosterTransportPaths:
    rostering: str = "/ims/oneroster/rostering/v1p2"


@dataclass
class _FakeOneRosterTransport:
    base_url: str = "https://api.timeback.test"
    paths: _FakeOneRosterTransportPaths = field(default_factory=_FakeOneRosterTransportPaths)


class _FakeOneRosterClient:
    def get_transport(self) -> _FakeOneRosterTransport:
        return _FakeOneRosterTransport()


class _FakeCaliperEvents:
    async def send(self, _sensor: str, _events: list[Any]) -> None:
        return None


@dataclass
class _FakeCaliperClient:
    events: _FakeCaliperEvents = field(default_factory=_FakeCaliperEvents)


@dataclass
class _FakeActivityClient:
    oneroster: _FakeOneRosterClient = field(default_factory=_FakeOneRosterClient)
    caliper: _FakeCaliperClient = field(default_factory=_FakeCaliperClient)


def stub_get_client() -> Any:
    """Return a fake client with oneroster/caliper stubs for activity handlers."""
    return _FakeActivityClient()


def default_app_config() -> AppConfig:
    """Standard 2-course app config used by activity and lessons handler fixtures."""
    return AppConfig(
        name="Fixture App",
        sensor="https://sensor.example.com",
        courses=[
            {
                "subject": "Math",
                "grade": 3,
                "course_code": "MATH-3",
                "ids": {"staging": "course-1", "production": "course-1-prod"},
                "sensor": "https://sensor.example.com",
            },
            {
                "subject": "Reading",
                "grade": 3,
                "course_code": "READ-3",
                "ids": {"staging": "course-2", "production": "course-2-prod"},
                "sensor": "https://sensor.example.com",
            },
        ],
    )
