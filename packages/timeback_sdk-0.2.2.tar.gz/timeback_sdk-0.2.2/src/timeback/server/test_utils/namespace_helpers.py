"""Shared setup builders for SDK namespace fixture tests.

This module is intentionally narrow:
- shared setup wiring only
- branching by namespace family is acceptable
- branching by fixture name or stub path is not

If a helper needs case-by-case behavior for one fixture file, keep that logic
local to the test instead of growing this module into a general-purpose
dispatcher.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, cast

from timeback.server.namespaces.lessons import create_lessons_namespace
from timeback.server.namespaces.user import create_user_get_profile, create_user_verify
from timeback.server.test_utils.recording_client import create_sdk_recording_client
from timeback.server.timeback import AppConfig
from timeback.server.types import ApiCredentials

if TYPE_CHECKING:
    from timeback.server.namespaces.lessons.types import LessonsNamespaceConfig
    from timeback.server.timeback import CourseConfig

StubNormalizer = Callable[[dict[str, Any] | None], dict[str, Any]]


def create_lessons_setup(
    method_name: str,
    *,
    include_courses: bool,
    course_ids_env: str = "staging",
    stub_normalizer: StubNormalizer | None = None,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
        recording = _create_recording_client(fixture, stub_normalizer)
        config = cast(
            "LessonsNamespaceConfig",
            {
                "env": "staging",
                "app_config": _build_lessons_app_config(
                    include_courses=include_courses, course_ids_env=course_ids_env
                ),
                "get_client": lambda: recording,
            },
        )
        namespace = create_lessons_namespace(config)
        return {"invoke": getattr(namespace, method_name), "calls": recording.calls}

    return _setup


def create_user_verify_setup(
    *, stub_normalizer: StubNormalizer | None = None
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
        recording = _create_recording_client(fixture, stub_normalizer)
        verify = create_user_verify(get_client=lambda: recording)
        return {"invoke": verify, "calls": recording.calls}

    return _setup


def create_user_get_profile_setup(
    *, stub_normalizer: StubNormalizer | None = None
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
        recording = _create_recording_client(fixture, stub_normalizer)
        get_profile = create_user_get_profile(
            env="staging",
            api=ApiCredentials(client_id="test", client_secret="test"),
            app_config=AppConfig(
                name="Test App",
                sensor="test-sensor",
                courses=[
                    {
                        "subject": "Math",
                        "grade": 3,
                        "course_code": "MATH-1",
                        "sensor": "test-sensor",
                        "ids": {"staging": "course-1"},
                    },
                ],
            ),
            get_client=lambda: recording,
        )
        return {"invoke": get_profile, "calls": recording.calls}

    return _setup


def _create_recording_client(
    fixture: dict[str, Any], stub_normalizer: StubNormalizer | None
) -> Any:
    stubs = fixture.get("stubs")
    if stub_normalizer is not None:
        stubs = stub_normalizer(stubs)
    return create_sdk_recording_client(stubs)


def _build_lessons_app_config(*, include_courses: bool, course_ids_env: str) -> Any:
    courses = (
        [
            {
                "subject": "Math",
                "grade": 3,
                "sensor": "test-sensor",
                "ids": {course_ids_env: "course-1"},
            },
        ]
        if include_courses
        else []
    )
    return AppConfig(
        name="Test App",
        courses=cast("list[CourseConfig]", courses),
        sensor="test-sensor",
    )
