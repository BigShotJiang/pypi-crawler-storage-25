"""Lessons list operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from ....shared.types import CourseCodeRef, SubjectGradeCourseRef
from ...handlers.activity.resolve import resolve_activity_course
from ...lib.utils import map_env_for_api
from .helpers import resolve_course_ids, to_question_count
from .types import Lesson

if TYPE_CHECKING:
    from ....shared.types import ActivityCourseRef
    from .types import LessonListInput, LessonsNamespaceConfig


def _to_course_ref(value: Any) -> ActivityCourseRef:
    """Convert a raw dict or dataclass to a typed course reference."""
    if isinstance(value, (SubjectGradeCourseRef, CourseCodeRef)):
        return value
    if isinstance(value, dict):
        if "code" in value:
            return CourseCodeRef(code=value["code"])
        if "subject" in value and "grade" in value:
            return SubjectGradeCourseRef(subject=value["subject"], grade=value["grade"])
    msg = f"Invalid course reference: expected {{subject, grade}} or {{code}}, got {value!r}"
    raise ValueError(msg)


def _get_field(obj: Any, snake_name: str, camel_name: str | None = None) -> Any:
    """Extract a field from a model object or raw dict."""
    if isinstance(obj, dict):
        if camel_name and camel_name in obj:
            return obj[camel_name]
        return obj.get(snake_name)
    return getattr(obj, snake_name, None)


def create_list(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons list operation."""

    async def list_lessons(input_data: LessonListInput | None = None) -> list[Lesson]:
        api = config["get_client"]()
        api_env = map_env_for_api(config["env"])
        course_ids: list[str]

        courses = cast("list[dict[str, Any]]", config["app_config"].courses)

        if input_data and input_data.get("course"):
            course_ref = _to_course_ref(input_data.get("course"))
            course = resolve_activity_course(courses, course_ref)
            course_id = (course.get("ids") or {}).get(api_env)
            course_ids = [course_id] if course_id else []
        else:
            course_ids = resolve_course_ids(courses, api_env)

        lessons: list[Lesson] = []

        for course_id in course_ids:
            components = await api.oneroster.courses(course_id).components(
                where={"status": "active"},
            )

            for component in components:
                component_id = _get_field(component, "sourced_id", "sourcedId") or ""
                if not component_id:
                    continue

                resources = await api.oneroster.courses.component_resources(
                    where={
                        "courseComponent.sourcedId": component_id,
                        "status": "active",
                    }
                )

                for resource in resources:
                    sourced_id = _get_field(resource, "sourced_id", "sourcedId") or ""
                    if not sourced_id:
                        continue

                    title = _get_field(resource, "title") or ""
                    raw_metadata = _get_field(resource, "metadata")
                    metadata: dict[str, Any] = (
                        raw_metadata
                        if isinstance(raw_metadata, dict)
                        else (
                            raw_metadata.model_dump(by_alias=True)
                            if raw_metadata and hasattr(raw_metadata, "model_dump")
                            else {}
                        )
                    )

                    question_count = to_question_count({"metadata": metadata})
                    lesson_type = metadata.get("lessonType", "quiz")

                    lessons.append(
                        Lesson(
                            id=sourced_id,
                            name=title or sourced_id,
                            type=lesson_type,
                            course_id=course_id,
                            question_count=question_count,
                            metadata=metadata,
                        )
                    )

        return lessons

    return list_lessons
