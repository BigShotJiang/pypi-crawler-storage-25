"""Lessons namespace helpers."""

from __future__ import annotations

from typing import Any

from .types import (
    LessonCompleteResult,
    LessonQuestion,
    LessonQuestionBatch,
    LessonStartResult,
    LessonSubmitResult,
)


def to_question_count(resource: dict[str, Any]) -> int | None:
    """Extract optional numeric question count from resource metadata."""
    metadata = resource.get("metadata") or {}
    count = metadata.get("questionCount")
    return count if isinstance(count, int) else None


def to_lesson_question(question: Any) -> LessonQuestion:
    """Convert a PowerPath question to the SDK lesson question shape."""
    content = None
    if hasattr(question, "content") and question.content:
        content = {"rawXml": question.content.raw_xml}

    return LessonQuestion(
        id=question.id,
        title=question.title,
        difficulty=question.difficulty,
        content=content,
        index=question.index,
        url=question.url,
        human_approved=question.human_approved,
        response=question.response,
        responses=question.responses,
        correct=question.correct,
        result=question.result.model_dump(by_alias=True) if question.result else None,
        result_id=question.result_id,
        learning_objectives=question.learning_objectives,
    )


def map_progress_to_start(
    lesson_id: str,
    progress: dict[str, Any] | None,
) -> LessonStartResult:
    """Map assessment progress response to lesson start result."""
    if not progress:
        return LessonStartResult(
            lesson_id=lesson_id,
            lesson_type="quiz",
            score=0,
            seen_questions=0,
            finalized=False,
        )

    lesson_type = progress.get("lessonType", "quiz")
    is_pp100 = lesson_type == "powerpath-100"

    result = LessonStartResult(
        lesson_id=lesson_id,
        lesson_type=lesson_type,
        score=progress.get("score", 0) or 0,
        seen_questions=len(progress.get("seenQuestions", [])) if is_pp100 else 0,
        finalized=False if is_pp100 else progress.get("finalized", False),
    )

    attempt = progress.get("attempt")
    if attempt is not None:
        result["attempt"] = attempt

    total_questions = progress.get("totalQuestions")
    if total_questions is not None:
        result["question_count"] = total_questions

    return result


def parse_linear_batch(progress: dict[str, Any]) -> LessonQuestionBatch:
    """Parse linear quiz progress into a question batch result.

    Only applicable to quiz-like (non-adaptive) lesson types.
    """
    from timeback_powerpath.types.responses import StandardProgressResponse

    parsed = StandardProgressResponse.model_validate(progress)
    all_questions = parsed.questions

    answered_ids = [q.id for q in all_questions if q.response is not None]

    return LessonQuestionBatch(
        questions=[to_lesson_question(q) for q in all_questions],
        answered_ids=answered_ids,
        score=parsed.score or 0,
        finalized=parsed.finalized,
        complete=parsed.finalized,
    )


def to_lesson_submit_result(payload: dict[str, Any]) -> LessonSubmitResult:
    """Convert a PowerPath submit response into an SDK submit result."""
    lesson_type = payload.get("lessonType", "")
    is_pp100 = lesson_type == "powerpath-100"

    if is_pp100:
        response_result = payload.get("responseResult", {})
        correct = response_result.get("isCorrect", False)
        score = payload.get("powerpathScore", 0)
    else:
        correct = False
        score = 0

    return LessonSubmitResult(
        correct=correct,
        score=score,
        complete=is_pp100 and score >= 100,
        question_result=payload.get("questionResult"),
    )


def to_lesson_complete_result(
    progress: dict[str, Any],
    final_result: dict[str, Any] | None = None,
) -> LessonCompleteResult:
    """Build a lesson complete result from progress.

    Uses finalResult for lessonType/attempt when available, falling back
    to progress so callers always receive these fields regardless of
    whether finalization occurred.
    """
    lesson_type = progress.get("lessonType", "")
    is_pp100 = lesson_type == "powerpath-100"
    finalized = True if is_pp100 else progress.get("finalized", False) is True

    result = LessonCompleteResult(
        score=progress.get("score", 0) or 0,
        total_questions=progress.get("totalQuestions", 0),
        correct_questions=progress.get("correctQuestions", 0),
        accuracy=progress.get("accuracy", 0),
        finalized=finalized,
    )
    lt = (final_result or {}).get("lessonType") or progress.get("lessonType")
    if lt is not None:
        result["lesson_type"] = lt
    attempt = (final_result or {}).get("attempt") or progress.get("attempt")
    if attempt is not None:
        result["attempt"] = attempt
    if final_result and final_result.get("finalizedByApi"):
        result["finalized_by_api"] = True
    return result


def resolve_course_ids(
    courses: list[dict[str, Any]],
    env: str,
) -> list[str]:
    """Resolve configured course IDs for the given environment."""
    seen: set[str] = set()
    result: list[str] = []
    for course in courses:
        ids = course.get("ids") or {}
        course_id = ids.get(env)
        if course_id and course_id not in seen:
            seen.add(course_id)
            result.append(course_id)
    return result
