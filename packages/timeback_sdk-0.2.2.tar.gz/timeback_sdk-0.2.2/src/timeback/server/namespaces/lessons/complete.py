"""Lessons complete operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...lib.logger import create_scoped_logger
from .helpers import to_lesson_complete_result

if TYPE_CHECKING:
    from .types import LessonCompleteInput, LessonCompleteResult, LessonsNamespaceConfig

log = create_scoped_logger("lessons.complete")


def create_complete(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons complete operation."""

    async def complete(input_data: LessonCompleteInput) -> LessonCompleteResult:
        assessments = config["get_client"]().powerpath.assessments
        student_id = input_data["student"]
        lesson_id = input_data["lesson"]

        raw_progress = await assessments.get_assessment_progress(
            {"student": student_id, "lesson": lesson_id}
        )
        progress = raw_progress.model_dump(by_alias=True)

        final_result: dict[str, Any] | None = None
        if progress.get("lessonType") != "powerpath-100" and progress.get("finalized") is not True:
            try:
                result = await assessments.final_student_assessment_response(
                    {"student": student_id, "lesson": lesson_id}
                )
                final_result = result.model_dump(by_alias=True)
            except Exception:
                log.debug("Finalize suppressed (may already be finalized)")

            raw_progress = await assessments.get_assessment_progress(
                {"student": student_id, "lesson": lesson_id}
            )
            progress = raw_progress.model_dump(by_alias=True)

        return to_lesson_complete_result(progress, final_result)

    return complete
