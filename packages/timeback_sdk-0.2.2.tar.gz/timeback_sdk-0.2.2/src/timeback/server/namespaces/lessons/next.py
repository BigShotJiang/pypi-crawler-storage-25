"""Lessons next operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .helpers import parse_linear_batch, to_lesson_question

if TYPE_CHECKING:
    from .types import LessonNextInput, LessonQuestion, LessonQuestionBatch, LessonsNamespaceConfig


class LessonTypeMismatchError(Exception):
    """Thrown when the client-provided lessonType conflicts with the actual
    lesson type reported by PowerPath. This is a client-correctable error.
    """


def create_next(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons next operation."""

    async def next_question(
        input_data: LessonNextInput,
    ) -> LessonQuestion | LessonQuestionBatch:
        assessments = config["get_client"]().powerpath.assessments

        if input_data.get("lesson_type") == "powerpath-100":
            response = await assessments.get_next_question(
                {"student": input_data["student"], "lesson": input_data["lesson"]}
            )
            return to_lesson_question(response.question)

        raw_progress = await assessments.get_assessment_progress(
            {"student": input_data["student"], "lesson": input_data["lesson"]}
        )
        progress = raw_progress.model_dump(by_alias=True)

        if progress.get("lessonType") == "powerpath-100":
            if input_data.get("lesson_type") is not None:
                raise LessonTypeMismatchError(
                    f"Expected quiz progress but got powerpath-100 for lesson {input_data['lesson']}"
                )
            # Client omitted lesson_type — auto-route to adaptive path
            response = await assessments.get_next_question(
                {"student": input_data["student"], "lesson": input_data["lesson"]}
            )
            return to_lesson_question(response.question)

        return parse_linear_batch(progress)

    return next_question
