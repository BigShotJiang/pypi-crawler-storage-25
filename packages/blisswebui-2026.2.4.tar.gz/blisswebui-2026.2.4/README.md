# blisswebui

![blisswebui](images/blisswebui.png 'blisswebui')

Bliss Web UI provides a simple web user interface to consume the bliss [REST API](https://bliss.gitlab-pages.esrf.fr/bliss/master/blissapi.html).

# Development

## Use with bliss demo session

In developement mode, the application can
be tested together with the bliss demo session
like that:

```
VITE_API_URL=http://localhost:5000/api pnpm dev
```

## Use with daiquiri-ui dev version

There is no integrated way to do that.

But the following is patching the `package.json` and the lock files.

```
pnpm add ../daiquiri-ui.git/lib/
```

Obviously, such changes must not be committed.
