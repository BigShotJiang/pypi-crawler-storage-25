"""Allow running via ``python -m codedd_cli``."""

import os
import sys


def _ensure_utf8_io() -> None:
    """
    Reconfigure stdout/stderr to use UTF-8 on Windows.

    PowerShell and cmd.exe default to the system code page (e.g. cp1252),
    which causes ``UnicodeEncodeError: 'charmap' codec can't encode …``
    whenever Rich prints Unicode symbols.  Setting the streams to UTF-8
    early — before any import triggers output — eliminates the need for
    callers to set ``PYTHONIOENCODING=utf-8`` externally.
    """
    if sys.platform != "win32":
        return

    # Env-var approach: respected by any subprocess we may spawn as well
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

    # Reconfigure the existing streams in-place (Python 3.7+)
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass  # non-standard stream (e.g. piped / pytest capture)

    # Enable UTF-8 mode for the Windows console (Python 3.15+ flag;
    # also ensures ctypes-level console code page is set).
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
    except Exception:
        pass


# Apply before importing anything that may write to the console
_ensure_utf8_io()

from codedd_cli.api.exceptions import CodeDDConnectionError  # noqa: E402
from codedd_cli.cli import app  # noqa: E402
from codedd_cli.utils.display import print_error  # noqa: E402


def main() -> None:
    try:
        app()
    except CodeDDConnectionError as e:
        print_error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
