"""
``codedd ai-docs`` command: Comprehensive AI-agent documentation.

This command prints structured documentation designed for AI agents to understand
and use the CodeDD-CLI tool effectively. It covers authentication, audit workflows,
and the remediation process with all available options and parameters.
"""

import textwrap

import typer
from rich.console import Console
from rich.syntax import Syntax

# Use force_terminal to ensure proper encoding on Windows
console = Console(force_terminal=True, legacy_windows=True)

ai_docs_app = typer.Typer(no_args_is_help=False)


def _section(title: str, content: str) -> None:
    """Print a formatted section header with content."""
    console.print(f"\n[bold cyan]{'=' * 80}[/bold cyan]")
    console.print(f"[bold cyan]{title}[/bold cyan]")
    console.print(f"[bold cyan]{'=' * 80}[/bold cyan]")
    console.print(content)


def _subsection(title: str, content: str = "") -> None:
    """Print a formatted subsection header."""
    console.print(f"\n[bold yellow]> {title}[/bold yellow]")
    if content:
        console.print(content)


def _code_block(title: str, code: str) -> None:
    """Print a code block with syntax highlighting."""
    console.print(f"\n[dim]{title}[/dim]")
    syntax = Syntax(code, "bash", theme="monokai", line_numbers=False, word_wrap=True)
    console.print(syntax)


def _table_item(label: str, description: str, indent: int = 2) -> None:
    """Print a labeled item in a structured way."""
    prefix = " " * indent
    console.print(f"{prefix}[bold]{label}[/bold]")
    console.print(f"{prefix}  {description}")


@ai_docs_app.callback(invoke_without_command=True)
def show_ai_docs(ctx: typer.Context = None) -> None:
    """
    Print comprehensive CodeDD-CLI documentation for AI agents.

    This document explains the tool's capabilities, authentication, audit workflows,
    and the remediation (fix) process with all parameters and options.
    """
    # Skip execution if a subcommand was invoked
    if ctx and ctx.invoked_subcommand is not None:
        return

    # =========================================================================
    # INTRODUCTION
    # =========================================================================
    _section(
        "CODEDD-CLI: COMPREHENSIVE DOCUMENTATION FOR AI AGENTS",
        textwrap.dedent("""
        CodeDD-CLI is a command-line interface for performing comprehensive code
        audits and managing security/quality issue remediation on software projects.

        The tool is designed to:
        1. Authenticate with the CodeDD platform
        2. Define and scope audit targets (repositories, directories)
        3. Execute audits that identify security flags and vulnerabilities
        4. Guide developers through structured remediation workflows

        This document provides complete command specifications for AI agents
        integrating with CodeDD-CLI.
        """).strip(),
    )

    # =========================================================================
    # PART 1: AUTHENTICATION
    # =========================================================================
    _section(
        "PART 1: AUTHENTICATION",
        textwrap.dedent("""
        All commands (except --help and --version) require authentication.
        Use the auth system to obtain and manage CLI tokens.
        """).strip(),
    )

    _subsection("Login Command", "Authenticate with a CLI token.")
    _code_block(
        "Interactive prompt (recommended for AI agents to skip):",
        "codedd auth login",
    )
    _code_block(
        "Non-interactive with token (preferred for AI agents):",
        "codedd auth login --token YOUR_CLI_TOKEN",
    )
    console.print(
        textwrap.dedent("""
        Parameters:
          --token TEXT          The CLI token string (can be obtained from CodeDD platform)
          --show / --no-show    Write request to file for review before sending

        Response: Stores authentication token in local config file.
        Status: Use 'codedd auth status' to verify authentication.
        """).strip()
    )

    _subsection("Status Command", "Check current authentication and account status.")
    _code_block("Get auth status:", "codedd auth status")
    console.print(
        "Response: Displays authenticated user email, account status, and token validity."
    )

    _subsection("Logout Command", "Clear stored authentication token.")
    _code_block("Logout:", "codedd auth logout")

    # =========================================================================
    # PART 2: AUDIT MANAGEMENT
    # =========================================================================
    _section(
        "PART 2: AUDIT MANAGEMENT",
        textwrap.dedent("""
        Audits represent code analyses performed on repositories or directories.
        The audit system manages:
        - Listing available audits
        - Selecting an active audit
        - Starting new audits
        - Viewing audit results

        Key Concept: An "active audit" is the target audit for fix operations.
        Set it with: codedd audits select
        """).strip(),
    )

    _subsection("List Audits", "Display all audits available to authenticated user.")
    _code_block("List audits:", "codedd audits list")
    console.print(
        textwrap.dedent("""
        Response Format: Table showing:
          - Audit UUID
          - Audit Name
          - Repository Name
          - Created Date
          - Status (completed, in-progress, etc.)
          - Audit Type (single or group)
        """).strip()
    )

    _subsection(
        "Select Active Audit",
        "Set which audit subsequent commands will operate on.",
    )
    _code_block("Select interactively:", "codedd audits select")
    console.print(
        textwrap.dedent("""
        Interactive Prompt:
          - Displays list of available audits numbered 1, 2, 3, ...
          - Prompts for numeric selection
          - Stores selected audit UUID in config

        Subsequent Commands:
          All fix commands (fetch, comment, resolve) use the active audit.
          Verify active audit with: codedd config show  (or: codedd config view)
        """).strip()
    )

    _subsection("Check Active Audit", "Display currently selected audit.")
    _code_block("View config:", "codedd config show")
    console.print(
        textwrap.dedent("""
        Look for 'active_audit_uuid' and 'active_audit_name' in output.

        Alias: 'codedd config view' works identically.
        """).strip()
    )

    # =========================================================================
    # PART 3: SCOPE MANAGEMENT
    # =========================================================================
    _section(
        "PART 3: SCOPE MANAGEMENT",
        textwrap.dedent("""
        Scopes define the local directories to be audited. The scope system
        allows you to register and confirm which parts of your codebase
        are included in an audit.
        """).strip(),
    )

    _subsection("Confirm Scope", "Register local directories for the active audit.")
    _code_block("Start scope confirmation:", "codedd scope confirm")
    console.print(
        textwrap.dedent("""
        Workflow:
          1. Lists available repositories for the active audit
          2. For each repository, prompts for local directory path
          3. Validates directory exists and is readable
          4. Confirms with user
          5. Sends scope registration to CodeDD platform

        Response: Lists confirmed scopes with UUID and validation status.
        """).strip()
    )

    # =========================================================================
    # PART 4: FIX WORKFLOW - THE CORE REMEDIATION SYSTEM
    # =========================================================================
    _section(
        "PART 4: FIX WORKFLOW - THE CORE REMEDIATION SYSTEM",
        textwrap.dedent("""
        The Fix workflow is the primary remediation system in CodeDD-CLI.
        It guides developers through structured remediation of:
        1. Security Flags (from AI analysis and SonarQube)
        2. Third-party Package Vulnerabilities (from dependency scanning)

        Requirements:
        - Must be authenticated (codedd auth login)
        - Must have active audit selected (codedd audits select)

        Workflow Pattern:
        1. Fetch overview (codedd fix fetch {flags|vulns})
        2. Get next issue (codedd fix {flags|vulns} next [OPTIONS])
        3. Record progress (codedd fix comment \"...\")
        4. Mark resolved (codedd fix resolve)
        5. Iterate or check status (codedd fix status)
        """).strip(),
    )

    # =========================================================================
    # FETCH OVERVIEW
    # =========================================================================
    _subsection(
        "Step 1: Fetch Fix Overview",
        "Load and display summary of issues ready for remediation.",
    )

    _code_block("Fetch flags overview:", "codedd fix fetch flags")
    _code_block("Fetch vulnerabilities overview:", "codedd fix fetch vulns")

    _code_block(
        "Non-interactive for group audits (by UUID):",
        'codedd fix fetch flags --sub-audit-uuid "abc123def456"',
    )
    _code_block(
        "Non-interactive for group audits (by index, 0 = auto):",
        "codedd fix fetch flags --sub-audit-index 2",
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix fetch {issue_type} [OPTIONS]")
    console.print("\n[bold]Arguments:[/bold]")
    _table_item(
        "issue_type",
        "Required string: 'flags' (security/quality flags) or 'vulns' (package vulnerabilities)",
    )

    console.print("\n[bold]Options (non-interactive sub-audit selection):[/bold]")
    _table_item(
        "--sub-audit-uuid TEXT",
        "Directly select a sub-audit by UUID.  Skips the interactive prompt.  Use for AI-agent workflows.",
        2,
    )
    _table_item(
        "--sub-audit-index INT",
        "Select a sub-audit by 1-based index (as shown in the interactive table).  "
        "Use 0 for auto-priority mode.  Skips the interactive prompt.",
        2,
    )

    console.print("\n[bold]Response (for flags):[/bold]")
    console.print(
        textwrap.dedent("""
        - Displays issue count (total, resolved, pending)
        - Shows severity breakdown for vulnerabilities
        - If audit is a GROUP (has sub-audits):
            * Displays table of sub-audits (repositories)
            * Prompts for numeric selection (1, 2, 3...)
            * Option 0 = Auto-priority mode (critical/red first)
        - If audit is SINGLE:
            * Proceeds directly to auto-priority or list next issue
        - Shows currently loaded issue (if any)
        """).strip()
    )

    console.print("\n[bold]Response (for vulns):[/bold]")
    console.print(
        textwrap.dedent("""
        - Displays total vulnerabilities count
        - Shows severity breakdown:
            * critical=N, high=N, medium=N, low=N
        - If GROUP audit: Prompts for sub-audit selection
        - Shows current issue if one is loaded
        """).strip()
    )

    # =========================================================================
    # NEXT FLAG ISSUE
    # =========================================================================
    _subsection(
        "Step 2A: Get Next Flag Issue",
        "Retrieve the next unresolved security/quality flag.",
    )

    _code_block("Get next flag issue:", "codedd fix flags next")
    _code_block(
        "Get with auto-priority (red first):", "codedd fix flags next --auto"
    )
    _code_block(
        "Get scoped to sub-audit UUID:",
        'codedd fix flags next --sub-audit-uuid "abc123def456"',
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix flags next [OPTIONS]")

    console.print("\n[bold]Options:[/bold]")
    _table_item(
        "--auto",
        "Boolean flag. Use auto-priority selection (Red flags first). Overrides manual scanning.",
        2,
    )
    _table_item(
        "--sub-audit-uuid TEXT",
        "Explicitly scope to one sub-audit UUID. Only returns issues from that repository.",
        2,
    )

    console.print("\n[bold]Response:[/bold]")
    console.print(
        textwrap.dedent("""
        Issue Block Displays:
          Issue UUID        - Unique identifier for this flag
          File              - File path and repository name
          Flag              - Human-readable reason/description
          Next              - Recommended action
          Agent Prompt      - Context for LLM-based fixing
          Resolved          - Current status (yes/no)

        Progress Display:
          resolved M/N      - M issues fixed out of N total
          pending P         - P issues remaining
          queue position Q  - Position in remediation queue
        """).strip()
    )

    # =========================================================================
    # NEXT VULN ISSUE
    # =========================================================================
    _subsection(
        "Step 2B: Get Next Vulnerability Issue",
        "Retrieve the next unresolved package vulnerability.",
    )

    _code_block(
        "Get next vulnerability (auto-priority, severity-ordered):",
        "codedd fix vulns next --auto",
    )
    _code_block(
        "Get only critical severities:",
        "codedd fix vulns next --auto --severity critical",
    )
    _code_block(
        "Get only packages in use (with file-level imports):",
        "codedd fix vulns next --auto --used-only",
    )
    _code_block(
        "Get from specific sub-audit:",
        'codedd fix vulns next --auto --sub-audit-uuid "xyz789abc"',
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix vulns next [OPTIONS]")

    console.print("\n[bold]Options:[/bold]")
    _table_item(
        "--auto",
        "Boolean flag. Auto-priority ordering: critical > high > medium > low, with used-count first within each tier.",
        2,
    )
    _table_item(
        "--severity {critical|high|medium|low}",
        "Filter to specific severity tier. Shorthand: -s critical",
        2,
    )
    _table_item(
        "--used-only",
        "Boolean flag. Only include packages with direct file-level usage (times_used > 0). Shorthand: -u",
        2,
    )
    _table_item(
        "--sub-audit-uuid TEXT",
        "Scope to one sub-audit UUID. Only returns issues from that repository.",
        2,
    )

    console.print("\n[bold]Response:[/bold]")
    console.print(
        textwrap.dedent("""
        Package Information:
          Package Name      - Name of vulnerable dependency (e.g., lodash)
          Severity          - Critical (red), High (orange), Medium (yellow), Low (cyan)
          Vulns Count       - total=T (critical=C, high=H, medium=M, low=L)
          CVSS Score        - Maximum CVSS score across vulnerabilities
          Used in N file(s) - Count of files directly importing package
          repo: NAME        - Repository where vulnerability exists

        Version Information:
          Latest version    - Current stable version available
          Patched versions  - Versions where vulnerability is fixed

        CVE Information:
          CVEs              - List of CVE identifiers (e.g., CVE-2021-12345)
          Summary           - Description of vulnerability

        Repository Breakdown:
          For each repository in audit:
            - name: declared version (e.g., lodash: 4.17.19)

        Additional Fields:
          Agent Prompt      - Context for LLM-based fixing
          Developer Comment - Any notes added by team

        Progress Display:
          Same as flags (resolved M/N, pending P, queue position Q)
        """).strip()
    )

    # =========================================================================
    # AFFECTED FILES
    # =========================================================================
    _subsection(
        "Step 2C: List Files Using a Vulnerable Package",
        "Show which files directly import a vulnerable package.",
    )

    _code_block(
        "List files using lodash:",
        "codedd fix vulns affected-files lodash",
    )
    _code_block(
        "List files using a scoped package:",
        "codedd fix vulns affected-files @babel/core",
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix vulns affected-files PACKAGE_NAME")

    console.print("\n[bold]Arguments:[/bold]")
    _table_item(
        "PACKAGE_NAME",
        "Required. Package name to look up (exact match). Examples: lodash, requests, @babel/core",
        2,
    )

    console.print("\n[bold]Response:[/bold]")
    console.print(
        textwrap.dedent("""
        Table Format:
          #   File Path
          1   src/utils/helpers.js
          2   src/services/api.js
          ...

        Displays:
          - Count of total files
          - Full file paths (sanitized relative to repo root)
          - Numbered list for reference in other workflows
        """).strip()
    )

    # =========================================================================
    # INVALIDATE FLAG
    # =========================================================================
    _subsection(
        "Step 2D: Mark Flag as Invalid (Skip)",
        "Dismiss a flag that upon review is not valid/actionable.",
    )

    _code_block(
        "Mark current flag as not valid and skip to next:",
        "codedd fix flags invalidate",
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix flags invalidate")

    console.print("\n[bold]Function:[/bold]")
    console.print(
        textwrap.dedent("""
        - Sets user_marked_valid=false on current flag issue
        - Moves session to next unresolved flag
        - Does NOT increment resolved counter
        - Useful for: false positives, out-of-scope issues, non-issues
        """).strip()
    )

    console.print("\n[bold]Response:[/bold]")
    console.print(
        textwrap.dedent("""
        - Confirmation of invalidated issue UUID
        - Next issue details (same format as 'fix flags next')
        - Progress update
        """).strip()
    )

    # =========================================================================
    # ADD COMMENT
    # =========================================================================
    _subsection(
        "Step 3: Record Progress (Add Comment)",
        "Document work progress on the current issue.",
    )

    _code_block(
        "Add comment (auto-detects flags/vulns session):",
        'codedd fix comment "bumped lodash to 4.17.21"',
    )
    _code_block(
        "Explicitly for flags:",
        'codedd fix comment "Fixed by removing unused import" --issue-type flags',
    )
    _code_block(
        "Explicitly for vulns:",
        'codedd fix comment "Updated to 4.18.0, tested imports" --issue-type vulns',
    )

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix comment TEXT [OPTIONS]")

    console.print("\n[bold]Arguments:[/bold]")
    _table_item(
        "TEXT",
        (
            "Comment string (can include spaces, quotes, special chars). "
            "Examples: 'Fixed boundary check', 'Bump to v2.1.0'"
        ),
        2,
    )

    console.print("\n[bold]Options:[/bold]")
    _table_item(
        "--issue-type {flags|vulns}",
        "Explicitly specify session type (auto-detected if omitted). Shorthand: -t flags",
        2,
    )

    console.print("\n[bold]Behavior:[/bold]")
    console.print(
        textwrap.dedent("""
        - Stores comment on current_issue in server
        - Does NOT resolve or advance issue
        - Multiple comments can be added to one issue
        - If no session active: creates one and stores comment
        - Auto-detection: Checks which session (flags/vulns) has active issue
        """).strip()
    )

    # =========================================================================
    # RESOLVE ISSUE
    # =========================================================================
    _subsection(
        "Step 4: Mark Issue Resolved",
        "Complete remediation and advance to next issue.",
    )

    _code_block(
        "Mark current issue resolved (auto-detect type):",
        "codedd fix resolve",
    )
    _code_block("Resolve with explicit type:", "codedd fix resolve --issue-type vulns")

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix resolve [OPTIONS]")

    console.print("\n[bold]Options:[/bold]")
    _table_item(
        "--issue-type {flags|vulns}",
        "Explicitly specify session type (auto-detected if omitted). Shorthand: -t flags",
        2,
    )

    console.print("\n[bold]Behavior:[/bold]")
    console.print(
        textwrap.dedent("""
        - Sets is_resolved=true on current_issue
        - Increments resolved_issues counter
        - Automatically fetches next unresolved issue
        - Advances queue_position in workflow
        - Returns next issue details (if available)

        Response includes:
        - Confirmation of resolved issue UUID
        - Next issue block (same rendering as 'fix {flags|vulns} next')
        - Updated progress (resolved M/total, pending P)
        - Message if no unresolved issues remain
        """).strip()
    )

    # =========================================================================
    # FIX STATUS
    # =========================================================================
    _subsection(
        "Step 5: View Unified Fix Dashboard",
        "Display progress across all fix domains (flags and vulnerabilities).",
    )

    _code_block("View fix status:", "codedd fix status")

    console.print("[bold]Command Format:[/bold]")
    console.print("  codedd fix status")

    console.print("\n[bold]Response:[/bold]")
    console.print(
        textwrap.dedent("""
        Progress Table:
        +----------+-----+----------+---------+----------+-----------------+
        | Domain   |Total|Resolved  | Pending |Queue Pos | Current Issue   |
        +----------+-----+----------+---------+----------+-----------------+
        | Flags    |  42 |   15     |   27    |    16    | uuid...  (Red)  |
        | Vulns    |  8  |   3      |   5     |    4     | lodash  (crit)  |
        +----------+-----+----------+---------+----------+-----------------+

        For each domain with active issue:
        - Full issue details block (same as 'fix {flags|vulns} next')
        - Shows current work-in-progress

        Usage: Run before/after remediation sessions to track overall progress
        """).strip()
    )

    # =========================================================================
    # FIX OVERVIEW
    # =========================================================================
    _subsection(
        "Fetch Detailed Issue Breakdown",
        "Get comprehensive overview of all issues without loading one.",
    )

    _code_block("Fetch detailed overview:", "codedd fix fetch flags")

    console.print("[bold]Includes:[/bold]")
    console.print(
        textwrap.dedent("""
        - Total count by severity (for vulns) or status
        - List of available sub-audits (if GROUP audit)
        - Summary statistics
        - Current session issue (if active)
        """).strip()
    )

    # =========================================================================
    # PART 5: COMMON AI WORKFLOWS
    # =========================================================================
    _section(
        "PART 5: COMMON AI AGENT WORKFLOWS",
        "Patterns for AI agents to interact with CodeDD-CLI effectively.",
    )

    _subsection(
        "Workflow 1: Initialize and Authenticate",
        "One-time setup for new session.",
    )
    console.print(
        textwrap.dedent("""
        codedd auth login --token YOUR_CLI_TOKEN
        codedd audits list
        codedd audits select  # Choose by numeric index
        codedd config show    # Verify active audit is set  (alias: codedd config view)
        """).strip()
    )

    _subsection(
        "Workflow 2: Remediate Security Flags (Interactive)",
        "Step through flags one by one with manual priority.",
    )
    console.print(
        textwrap.dedent("""
        codedd fix fetch flags
        codedd fix flags next                    # Load first flag
        # ... developer reviews and makes fix ...
        codedd fix comment "Fixed null check in line 42"
        codedd fix resolve                       # Mark resolved, load next
        codedd fix comment "Refactored error handling"
        codedd fix resolve                       # Continue...
        """).strip()
    )

    _subsection(
        "Workflow 3: Auto-Priority Vulnerability Remediation",
        "Process vulnerabilities by severity (critical first).",
    )
    console.print(
        textwrap.dedent("""
        codedd fix fetch vulns
        codedd fix vulns next --auto             # Critical first
        codedd fix vulns affected-files lodash   # See which files import it
        # ... developer updates package version ...
        codedd fix comment "Updated lodash to 4.17.21"
        codedd fix resolve                         # Move to next critical
        """).strip()
    )

    _subsection(
        "Workflow 4: Severity-Filtered Remediation",
        "Process only 'critical' and 'high' vulnerabilities.",
    )
    console.print(
        textwrap.dedent("""
        codedd fix fetch vulns
        codedd fix vulns next --auto --severity critical   # All critical
        # ... remediate all critical ...
        codedd fix vulns next --auto --severity high       # Then high
        # ... remediate all high ...
        """).strip()
    )

    _subsection(
        "Workflow 5: Group Audit with Sub-Audit Targeting",
        "Work on one repository within a multi-repo audit.",
    )
    console.print(
        textwrap.dedent("""
        # Interactive (original):
        codedd fix fetch flags
        # Prompt shows: 0=auto, 1=frontend-app, 2=backend-api, 3=shared-libs
        # Choose: 2

        # Non-interactive — by index (preferred for AI agents):
        codedd fix fetch flags --sub-audit-index 2

        # Non-interactive — by UUID:
        codedd fix fetch flags --sub-audit-uuid "uuid-of-backend-api"

        # Non-interactive — auto-priority across all repos:
        codedd fix fetch flags --sub-audit-index 0

        codedd fix flags next --auto             # Only from selected scope
        codedd fix flags next --auto             # Continues within same scope
        """).strip()
    )

    _subsection(
        "Workflow 6: Check Status Without Modifying",
        "View dashboard without advancing workflow.",
    )
    console.print(
        textwrap.dedent("""
        codedd fix status
        # Shows progress across flags and vulns
        # No issues advanced
        # Safe to call repeatedly for monitoring
        """).strip()
    )

    _subsection(
        "Workflow 7: Skip Invalid Flags",
        "Dismiss false positives without resolution.",
    )
    console.print(
        textwrap.dedent("""
        codedd fix fetch flags
        codedd fix flags next --auto
        # Review flag, determine it's a false positive
        codedd fix flags invalidate               # Mark invalid, load next
        codedd fix flags invalidate               # Skip another invalid flag
        codedd fix flags next                     # Load next valid one
        """).strip()
    )

    # =========================================================================
    # PART 6: DATA STRUCTURES AND RESPONSE FORMATS
    # =========================================================================
    _section(
        "PART 6: DATA STRUCTURES AND RESPONSE FORMATS",
        "JSON structures returned by API endpoints used by fix commands.",
    )

    _subsection("Flag Issue Object", "Structure of a security/quality flag issue.")
    console.print(
        textwrap.dedent("""
        {
          "issue_uuid": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
          "issue_type": "flags",
          "file_path": "src/utils/helpers.ts",
          "repo_name": "backend-api",
          "flag_color": "Red",              # Red, Yellow, Orange, etc.
          "flag_source": "ai",              # 'ai' or 'sonarqube'
          "reason": "Missing null check on user input",
          "recommended_action": "Add validation before use",
          "agent_prompt": "Context for LLM fixing...",
          "is_resolved": false,
          "user_marked_valid": null         # null, true, false
        }
        """).strip()
    )

    _subsection("Vulnerability Issue Object", "Structure of a package vulnerability issue.")
    console.print(
        textwrap.dedent("""
        {
          "issue_uuid": "v847ac10b-58cc-4372-a567-0e02b2c3d479",
          "issue_type": "vulns",
          "package_name": "lodash",
          "severity": "critical",           # critical, high, medium, low
          "total_vulnerabilities": 3,
          "critical_count": 1,
          "high_count": 1,
          "medium_count": 1,
          "low_count": 0,
          "vulnerability_max_cvss_score": 9.8,
          "times_used": 7,                  # Files importing this package
          "vulnerability_ids": "CVE-2021-23337, CVE-2021-23337",
          "vulnerability_summary": "Prototype pollution vulnerability...",
          "latest_version": "4.17.21",
          "vulnerability_first_patched_versions": "4.17.21",
          "repository_breakdown": [
            {
              "repository_name": "backend-api",
              "declared_version": "4.17.19"
            },
            {
              "repository_name": "frontend-app",
              "declared_version": "4.16.0"
            }
          ],
          "agent_prompt": "Context for LLM fixing...",
          "developer_comment": null,
          "is_resolved": false,
          "repo_name": "backend-api"        # Current repository focus
        }
        """).strip()
    )

    _subsection("Progress Object", "Remediation progress tracking.")
    console.print(
        textwrap.dedent("""
        {
          "total_issues": 42,
          "resolved_issues": 15,
          "pending_issues": 27,
          "queue_position": 16
        }
        """).strip()
    )

    # =========================================================================
    # PART 7: ERROR HANDLING AND COMMON ISSUES
    # =========================================================================
    _section(
        "PART 7: ERROR HANDLING AND COMMON ISSUES",
        "How to handle errors and common edge cases.",
    )

    _subsection("No Active Audit Selected", "Error and recovery.")
    console.print(
        textwrap.dedent("""
        Error Message:
          "No active audit selected. Run 'codedd audits select' first."

        Recovery:
          1. Run: codedd audits list
          2. Run: codedd audits select
          3. Choose the audit by numeric index
          4. Retry fix command
        """).strip()
    )

    _subsection("Authentication Expired", "Token invalid or lost.")
    console.print(
        textwrap.dedent("""
        Error Message:
          "Authentication failed" or 4xx HTTP response

        Recovery:
          1. Run: codedd auth logout
          2. Run: codedd auth login --token NEW_TOKEN
          3. Verify: codedd auth status
          4. Retry command
        """).strip()
    )

    _subsection("No Issues Available", "Audit is fully remediated or error state.")
    console.print(
        textwrap.dedent("""
        Message:
          "No unresolved issues left for this scope."

        Check Status:
          codedd fix status

        All issues resolved successfully!
        """).strip()
    )

    _subsection("Sub-Audit UUID Not Found", "Invalid UUID specified.")
    console.print(
        textwrap.dedent("""
        Error:
          "Sub-audit UUID not found"

        Recovery:
          1. Run: codedd fix fetch {flags|vulns}
          2. If GROUP audit, select from interactive table
          3. Or verify UUID is correct from: codedd audits list
        """).strip()
    )

    # =========================================================================
    # PART 8: QUICK REFERENCE COMMAND MAP
    # =========================================================================
    _section(
        "PART 8: QUICK REFERENCE - COMMAND MAP",
        "Organized list of all commands for quick lookup.",
    )

    console.print("[bold]Authentication[/bold]")
    console.print("  codedd auth login --token TOKEN")
    console.print("  codedd auth status")
    console.print("  codedd auth logout")

    console.print("\n[bold]Audit Management[/bold]")
    console.print("  codedd audits list")
    console.print("  codedd audits select")
    console.print("  codedd audit start")
    console.print("  codedd scope confirm")

    console.print("\n[bold]Fix Workflow - Initialization[/bold]")
    console.print("  codedd fix fetch flags [--sub-audit-uuid UUID | --sub-audit-index INT]")
    console.print("  codedd fix fetch vulns [--sub-audit-uuid UUID | --sub-audit-index INT]")

    console.print("\n[bold]Fix Workflow - Progress (Flags)[/bold]")
    console.print("  codedd fix flags next [--auto] [--sub-audit-uuid UUID]")
    console.print("  codedd fix flags invalidate")

    console.print("\n[bold]Fix Workflow - Progress (Vulnerabilities)[/bold]")
    console.print(
        "  codedd fix vulns next [--auto] [--severity SEVERITY] [--used-only] [--sub-audit-uuid UUID]"
    )
    console.print("  codedd fix vulns affected-files PACKAGE_NAME")

    console.print("\n[bold]Fix Workflow - Common Operations[/bold]")
    console.print('  codedd fix comment "COMMENT_TEXT" [--issue-type {flags|vulns}]')
    console.print("  codedd fix resolve [--issue-type {flags|vulns}]")
    console.print("  codedd fix status")

    console.print("\n[bold]Configuration[/bold]")
    console.print("  codedd config show                    (alias: codedd config view)")

    # =========================================================================
    # CLOSING
    # =========================================================================
    _section(
        "AI INTEGRATION GUIDELINES",
        textwrap.dedent("""
        For AI agents integrating with CodeDD-CLI:

        1. AUTHENTICATION
           - Use non-interactive flag: --token TOKEN
           - Store token securely; rotate regularly
           - Check auth status before automation

        2. AUDIT SELECTION
           - Use 'audits list' to get UUID
           - Set active audit once per session
           - Confirm with 'config show' (or 'config view') before operations

        3. REMEDIATION LOOPS
           - Always call 'fetch' before 'next' to initialize
           - Use --auto for priority-based workflows
           - Check response status field == "success"
           - Handle "no issues left" gracefully

        4. ERROR RECOVERY
           - Wrap operations in try-catch
           - Check HTTP status codes (200=success)
           - Log error messages from 'message' field
           - Retry with exponential backoff on transient failures

        5. MONITORING
           - Call 'fix status' to check progress without advancing
           - Store issue UUIDs for tracking
           - Log comments during automation for audit trail

        6. GROUP AUDITS
           - Fetch overview first to check sub-audit requirements
           - Use --sub-audit-uuid to scope to repositories
           - Process one repository at a time for clarity

        Complete documentation available at:
        https://codedd.com/docs/cli
        """).strip(),
    )

    console.print(
        "\n[dim italic]Generated for CodeDD-CLI AI Agent Integration[/dim italic]\n"
    )
