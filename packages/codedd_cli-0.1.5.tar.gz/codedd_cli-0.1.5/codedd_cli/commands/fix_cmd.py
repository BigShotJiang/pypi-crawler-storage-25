"""
``codedd fix`` sub-commands: fetch/status/comment/resolve, ``flags next``,
and ``vulns next / affected-files``.
"""

from enum import Enum

import typer
from rich.console import Console
from rich.prompt import IntPrompt
from rich.table import Table

from codedd_cli.api.client import CodeDDClient
from codedd_cli.api.endpoints import Endpoints
from codedd_cli.auth.session import require_auth
from codedd_cli.config.fix_session import FixSessionTracker
from codedd_cli.config.settings import ConfigManager
from codedd_cli.utils.display import print_error, print_info, print_success, print_warning

console = Console()

fix_app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode="rich",
    help=(
        "Fetch and guide issue remediation workflows.\n\n"
        "[bold]Quick start (group / portfolio audits):[/bold]\n"
        "  1. [bold cyan]codedd fix status[/bold cyan]               — see all repos ranked by severity\n"
        "  2. [bold cyan]codedd fix repo my-service[/bold cyan]      — scope to one repository by name\n"
        "  3. [bold cyan]codedd fix flags next --auto[/bold cyan]    — get the first unresolved issue\n\n"
        "[bold]Quick start (single-repo audits):[/bold]\n"
        "  1. [bold cyan]codedd fix fetch flags[/bold cyan]          — load overview (interactive sub-audit pick)\n"
        "  2. [bold cyan]codedd fix flags next --auto[/bold cyan]    — get the first unresolved issue\n\n"
        "Use [bold cyan]codedd fix repo --help[/bold cyan] for non-interactive / AI-agent workflows."
    ),
)

flags_app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode="rich",
    help=(
        "Fix security/quality flags (AI and SonarQube issues).\n\n"
        "[bold]Workflow:[/bold]\n"
        "  1. codedd fix repo my-service     \u2014 scope to one repository (group audits)\n"
        "     codedd fix fetch flags         \u2014 or pick interactively / use auto mode\n"
        "  2. codedd fix flags next --auto   \u2014 get the next unresolved flag\n"
        "  3. codedd fix comment \"...\"       \u2014 record progress\n"
        "  4. codedd fix resolve             \u2014 mark fixed & advance\n"
        "  5. codedd fix flags invalidate    \u2014 mark as not valid & advance\n\n"
        "[bold]Flags next options:[/bold]\n"
        "  --auto              auto-priority (Red first)\n"
        "  --sub-audit-uuid    scope to one sub-audit"
    ),
)

vulns_app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode="rich",
    help=(
        "Fix third-party package security vulnerabilities.\n\n"
        "[bold]Workflow:[/bold]\n"
        "  1. codedd fix fetch vulns                        \u2014 load overview\n"
        "  2. codedd fix vulns next --auto                  \u2014 auto-priority (critical first)\n"
        "  3. codedd fix vulns affected-files <PACKAGE>     \u2014 list importing files\n"
        "  4. codedd fix comment \"...\"                      \u2014 record progress\n"
        "  5. codedd fix resolve                            \u2014 mark fixed & advance\n\n"
        "[bold]Vulns next options:[/bold]\n"
        "  --auto                          auto-priority across all severities\n"
        "  --severity critical|high|medium|low  filter to one severity\n"
        "  --used-only                     only packages with file-level usage\n"
        "  --sub-audit-uuid                scope to one sub-audit"
    ),
)


class Severity(str, Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _require_active_audit(cfg: ConfigManager) -> None:
    """Abort if no audit has been selected."""
    if not cfg.active_audit_uuid:
        print_error("No active audit selected. Run [bold cyan]codedd audits select[/bold cyan] first.")
        raise typer.Exit(code=1)


def _render_issue(issue: dict) -> None:
    """Render a compact flag-issue block for terminal workflows."""
    if not issue:
        return
    color = issue.get("flag_color", "Unknown")
    source = issue.get("flag_source", "ai")
    issue_uuid = issue.get("issue_uuid", "")
    file_path = issue.get("file_path", "")
    repo_name = issue.get("repo_name", "")
    reason = issue.get("reason", "")
    recommendation = issue.get("recommended_action", "")
    resolved = bool(issue.get("is_resolved", False))

    console.print()
    console.print(f"[bold]Issue:[/bold] {issue_uuid}  [dim]({color} / {source})[/dim]")
    console.print(f"[bold]File:[/bold]  {file_path}  [dim]repo: {repo_name}[/dim]")
    if reason:
        console.print(f"[bold]Flag:[/bold]  {reason}")
    if recommendation:
        console.print(f"[bold]Next:[/bold]  {recommendation}")
    agent_prompt = issue.get("agent_prompt", "")
    if agent_prompt:
        console.print("[bold]Agent Prompt:[/bold]")
        console.print(agent_prompt)
    console.print(f"[bold]Resolved:[/bold] {'yes' if resolved else 'no'}")


def _render_vuln_issue(issue: dict) -> None:
    """Render a compact vulnerability-issue block for terminal workflows."""
    if not issue:
        return
    pkg = issue.get("package_name", "")
    severity = issue.get("severity", "unknown")
    crit = issue.get("critical_count", 0)
    high = issue.get("high_count", 0)
    med = issue.get("medium_count", 0)
    low = issue.get("low_count", 0)
    total = issue.get("total_vulnerabilities", 0)
    times_used = issue.get("times_used", 0)
    latest_version = issue.get("latest_version", "")
    patched = issue.get("vulnerability_first_patched_versions", "")
    vuln_ids = issue.get("vulnerability_ids", "")
    cvss = issue.get("vulnerability_max_cvss_score", 0.0)
    vuln_summary = issue.get("vulnerability_summary", "")
    repo_name = issue.get("repo_name", "")
    resolved = bool(issue.get("is_resolved", False))
    comment = issue.get("developer_comment", "")

    sev_color = {"critical": "red", "high": "dark_orange", "medium": "yellow", "low": "cyan"}.get(severity, "white")

    console.print()
    console.print(f"[bold]Package:[/bold] {pkg}  [{sev_color}]{severity.upper()}[/{sev_color}]")
    console.print(
        f"[bold]Vulns:[/bold]  total={total}  "
        f"(critical={crit}, high={high}, medium={med}, low={low})  "
        f"CVSS={cvss}"
    )
    console.print(f"[bold]Used in:[/bold] {times_used} file(s)  [dim]repo: {repo_name}[/dim]")
    if latest_version:
        console.print(f"[bold]Latest version:[/bold] {latest_version}")
    if patched:
        console.print(f"[bold]Patched versions:[/bold] {patched}")
    if vuln_ids:
        console.print(f"[bold]CVEs:[/bold] {vuln_ids}")
    if vuln_summary:
        console.print(f"[bold]Summary:[/bold] {vuln_summary}")

    breakdown = issue.get("repository_breakdown", [])
    if breakdown:
        console.print("[bold]Repository breakdown:[/bold]")
        for rb in breakdown:
            rn = rb.get("repository_name", "")
            dv = rb.get("declared_version", "?")
            console.print(f"  - {rn}: declared {dv}")

    agent_prompt = issue.get("agent_prompt", "")
    if agent_prompt:
        console.print("[bold]Agent Prompt:[/bold]")
        console.print(agent_prompt)

    if comment:
        console.print(f"[bold]Comment:[/bold] {comment}")
    console.print(f"[bold]Resolved:[/bold] {'yes' if resolved else 'no'}")


def _render_progress(progress: dict) -> None:
    if not progress:
        return
    total = int(progress.get("total_issues", 0))
    resolved = int(progress.get("resolved_issues", 0))
    pending = int(progress.get("pending_issues", 0))
    position = int(progress.get("queue_position", 0))
    console.print(
        f"[bold]Progress:[/bold] resolved {resolved}/{total}  |  pending {pending}  |  queue position {position}"
    )


def _handle_error_response(resp, default_message: str) -> None:
    msg = default_message
    try:
        data = resp.json()
        msg = data.get("message", msg)
    except Exception:
        pass
    print_error(msg)


def _render_any_issue(issue: dict) -> None:
    """Dispatch to the correct renderer based on issue_type."""
    if not issue:
        return
    if issue.get("issue_type") == "vulns":
        _render_vuln_issue(issue)
    else:
        _render_issue(issue)


def _warn_if_stale(issue: dict, tracker: FixSessionTracker) -> None:
    """
    Emit a prominent warning if the incoming issue targets a file that
    already had flags resolved earlier in this session.  Earlier fixes
    may have altered the code in a way that makes the new flag obsolete.
    """
    if not issue:
        return
    file_path = issue.get("file_path", "")
    if not file_path:
        return
    count = tracker.prior_fix_count(file_path)
    if count == 0:
        return
    plural = "fix" if count == 1 else "fixes"
    console.print()
    console.print(
        f"[bold yellow]Stale-flag warning:[/bold yellow] "
        f"[bold]{file_path}[/bold] already had [bold]{count}[/bold] {plural} "
        f"applied in this session.  This flag may reference outdated code."
    )
    console.print(
        "[dim]  If the earlier fix already addressed this, consider running "
        "[bold cyan]codedd fix flags invalidate[/bold cyan] to skip it.[/dim]"
    )


def _render_status_flag_issue(issue: dict) -> None:
    """Render compact flag details for `codedd fix status`."""
    if not issue:
        return
    console.print(f"[bold]Issue:[/bold] {issue.get('issue_uuid', '')}")
    console.print(f"[bold]File:[/bold] {issue.get('file_path', '')}")
    console.print(f"[bold]Flag reason:[/bold] {issue.get('reason', '')}")
    console.print(f"[bold]Resolved:[/bold] {'yes' if issue.get('is_resolved', False) else 'no'}")


def _render_status_vuln_issue(issue: dict) -> None:
    """Render compact vulnerability details for `codedd fix status`."""
    if not issue:
        return
    summary = (
        f"total={issue.get('total_vulnerabilities', 0)} "
        f"(critical={issue.get('critical_count', 0)}, "
        f"high={issue.get('high_count', 0)}, "
        f"medium={issue.get('medium_count', 0)}, "
        f"low={issue.get('low_count', 0)})"
    )
    console.print(f"[bold]Package:[/bold] {issue.get('package_name', '')}")
    console.print(f"[bold]severity:[/bold] {issue.get('severity', 'unknown')}")
    console.print(f"[bold]vuln counts summary:[/bold] {summary}")
    console.print(f"[bold]used count:[/bold] {issue.get('times_used', 0)}")
    console.print(f"[bold]Resolved:[/bold] {'yes' if issue.get('is_resolved', False) else 'no'}")


def _render_status_any_issue(issue: dict) -> None:
    """Dispatch compact status renderer based on issue_type."""
    if not issue:
        return
    if issue.get("issue_type") == "vulns":
        _render_status_vuln_issue(issue)
    else:
        _render_status_flag_issue(issue)


def _detect_active_issue_type(cfg: ConfigManager) -> str:
    """
    Try to detect whether the user has an active vulns or flags session by
    probing the status endpoint for both types.  Return whichever has a
    current_issue, preferring vulns if both exist (most recent workflow).
    """
    for it in ("vulns", "flags"):
        try:
            with CodeDDClient(config=cfg) as client:
                resp = client.get(
                    Endpoints.FIX_STATUS,
                    params={"audit_uuid": cfg.active_audit_uuid, "issue_type": it},
                )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "success" and data.get("current_issue"):
                    return it
        except Exception:
            continue
    return "flags"


def _fetch_domain_status(cfg: ConfigManager, issue_type: str) -> dict | None:
    """Fetch fix status for a single domain (flags or vulns)."""
    try:
        with CodeDDClient(config=cfg) as client:
            resp = client.get(
                Endpoints.FIX_STATUS,
                params={"audit_uuid": cfg.active_audit_uuid, "issue_type": issue_type},
            )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "success":
                return data
    except Exception:
        pass
    return None


def _fetch_domain_overview(cfg: ConfigManager, issue_type: str) -> dict | None:
    """
    Fetch overview summary in auto mode for a domain.

    This gives accurate aggregate counts even when no active fix session exists.
    """
    try:
        with CodeDDClient(config=cfg) as client:
            resp = client.get(
                Endpoints.FIX_OVERVIEW,
                params={
                    "audit_uuid": cfg.active_audit_uuid,
                    "issue_type": issue_type,
                    "selection_mode": "auto",
                },
            )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "success":
                return data
    except Exception:
        pass
    return None


_SUB_AUDIT_PAGE_SIZE = 10


def _extract_color_counts(sub_audit: dict) -> tuple[int, int]:
    """Return (red_count, orange_count) from a sub-audit dict, tolerating multiple field-name conventions."""
    nested_issue = sub_audit.get("issue_counts") or sub_audit.get("color_counts") or {}
    nested_flag = sub_audit.get("flag_counts") or {}
    red = int(
        sub_audit.get("red_count")
        or sub_audit.get("flags_red")
        or sub_audit.get("flag_red_count")
        or nested_issue.get("red")
        or nested_issue.get("Red")
        or nested_flag.get("red")
        or nested_flag.get("Red")
        or 0
    )
    orange = int(
        sub_audit.get("orange_count")
        or sub_audit.get("flags_orange")
        or sub_audit.get("flag_orange_count")
        or nested_issue.get("orange")
        or nested_issue.get("Orange")
        or nested_flag.get("orange")
        or nested_flag.get("Orange")
        or 0
    )
    return red, orange


def _render_sub_audit_ranking(sub_audits: list[dict]) -> None:
    """Render a paginated table of sub-audits ranked by red issues, then orange issues."""
    if not sub_audits:
        return

    sorted_subs = sorted(
        sub_audits,
        key=lambda sa: (-_extract_color_counts(sa)[0], -_extract_color_counts(sa)[1]),
    )
    total = len(sorted_subs)
    page = 0

    console.print()
    console.rule("[bold]Repositories — Ranked by Issues[/bold]")

    while True:
        start = page * _SUB_AUDIT_PAGE_SIZE
        end = min(start + _SUB_AUDIT_PAGE_SIZE, total)
        chunk = sorted_subs[start:end]

        table = Table(
            title=f"[dim]Repositories {start + 1}–{end} of {total}[/dim]",
            show_header=True,
            padding=(0, 1),
        )
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("Repository", min_width=22)
        table.add_column("Status", min_width=10)
        table.add_column("[red]Red[/red]", justify="right", width=5)
        table.add_column("[orange1]Orange[/orange1]", justify="right", width=7)
        table.add_column("Total", justify="right", width=6)

        for idx, sub in enumerate(chunk, start=start + 1):
            red, orange = _extract_color_counts(sub)
            total_issues = int(
                sub.get("total_issues")
                or sub.get("total_flags")
                or sub.get("issue_count")
                or 0
            )
            status = sub.get("status", "—")
            repo_name = sub.get("repo_name") or sub.get("audit_uuid", "—")
            red_str = f"[red]{red}[/red]" if red > 0 else "[dim]0[/dim]"
            orange_str = f"[orange1]{orange}[/orange1]" if orange > 0 else "[dim]0[/dim]"
            total_str = str(total_issues) if total_issues else "—"
            table.add_row(str(idx), repo_name, status, red_str, orange_str, total_str)

        console.print(table)

        if end >= total:
            break
        if not typer.confirm(f"Show more ({end}/{total} shown)?", default=True):
            break
        page += 1


# ---------------------------------------------------------------------------
# codedd fix fetch <issue_type>
# ---------------------------------------------------------------------------


@fix_app.command("fetch")
@require_auth
def fetch_overview(
    issue_type: str = typer.Argument(
        ...,
        help="Issue outlook to fetch: flags | vulns",
    ),
    sub_audit_uuid: str | None = typer.Option(
        None,
        "--sub-audit-uuid",
        help=(
            "Directly select a sub-audit by UUID (non-interactive).  "
            "Skips the interactive sub-audit prompt for group audits."
        ),
    ),
    sub_audit_index: int | None = typer.Option(
        None,
        "--sub-audit-index",
        help=(
            "Select a sub-audit by its 1-based index in the sub-audit "
            "list (non-interactive).  Use 0 for auto-priority mode."
        ),
    ),
) -> None:
    """
    Fetch fix outlook for an audit (flags or vulns).

    For group audits, [bold cyan]codedd fix repo <name>[/bold cyan] is usually
    simpler — it resolves the repository by name and scopes the session in one step.
    Use this command for interactive sub-audit selection or when you need the
    full overview payload.

    [bold]Non-interactive options (useful for AI agents):[/bold]

        --sub-audit-uuid <UUID>    select directly by sub-audit UUID
        --sub-audit-index N        select by row number (0 = auto-priority)
    """
    issue_type = issue_type.strip().lower()
    if issue_type not in ("flags", "vulns"):
        print_error("Supported types: flags, vulns. Use: [bold cyan]codedd fix fetch flags[/bold cyan]")
        raise typer.Exit(code=1)

    if sub_audit_uuid is not None and sub_audit_index is not None:
        print_error("Specify only one of --sub-audit-uuid or --sub-audit-index, not both.")
        raise typer.Exit(code=1)

    cfg = ConfigManager()
    _require_active_audit(cfg)

    params = {
        "audit_uuid": cfg.active_audit_uuid,
        "issue_type": issue_type,
    }

    with CodeDDClient(config=cfg) as client:
        overview_resp = client.get(Endpoints.FIX_OVERVIEW, params=params)
    if overview_resp.status_code != 200:
        _handle_error_response(overview_resp, "Failed to fetch fix overview.")
        raise typer.Exit(code=1)

    overview = overview_resp.json()
    if overview.get("status") != "success":
        print_error(overview.get("message", "Failed to fetch fix overview."))
        raise typer.Exit(code=1)

    selected_sub_audit_uuid = ""
    selection_mode = "specific"

    if cfg.active_audit_type == "group" and overview.get("requires_sub_audit_selection"):
        sub_audits = overview.get("available_sub_audits", [])
        if not sub_audits:
            print_warning("No sub-audits found. Falling back to auto-priority mode.")
            selection_mode = "auto"
        elif sub_audit_uuid is not None:
            # Non-interactive: direct UUID selection
            sub_audit_uuid = sub_audit_uuid.strip()
            known_uuids = {s.get("audit_uuid", "") for s in sub_audits}
            if sub_audit_uuid not in known_uuids:
                print_error(
                    f"Sub-audit UUID [bold]{sub_audit_uuid}[/bold] not found in this audit.  "
                    "Available sub-audit UUIDs:"
                )
                for sub in sub_audits:
                    console.print(f"  {sub.get('audit_uuid', '')}  ({sub.get('repo_name', '')})")
                raise typer.Exit(code=1)
            selected_sub_audit_uuid = sub_audit_uuid
        elif sub_audit_index is not None:
            # Non-interactive: index-based selection (0 = auto, 1..N = sub-audit)
            if sub_audit_index == 0:
                selection_mode = "auto"
            elif 1 <= sub_audit_index <= len(sub_audits):
                selected_sub_audit_uuid = sub_audits[sub_audit_index - 1].get("audit_uuid", "")
            else:
                print_error(
                    f"Sub-audit index {sub_audit_index} out of range.  "
                    f"Valid range: 0 (auto) or 1–{len(sub_audits)}."
                )
                raise typer.Exit(code=1)
        else:
            # Interactive prompt (original behavior)
            auto_label = (
                "Auto-priority (critical first)" if issue_type == "vulns" else "Auto-priority (any Red first)"
            )
            table = Table(title="Select sub-audit for fix flow", show_header=True, padding=(0, 1))
            table.add_column("#", style="dim", width=4, justify="right")
            table.add_column("Audit Name")
            table.add_column("Status")
            table.add_row("0", auto_label, "auto")
            for idx, sub in enumerate(sub_audits, start=1):
                table.add_row(str(idx), sub.get("repo_name", ""), sub.get("status", ""))
            console.print(table)
            choice = IntPrompt.ask(
                "Pick sub-audit",
                default=0,
                choices=[str(i) for i in range(0, len(sub_audits) + 1)],
            )
            if choice == 0:
                selection_mode = "auto"
            else:
                selected_sub_audit_uuid = sub_audits[choice - 1].get("audit_uuid", "")

    params = {
        "audit_uuid": cfg.active_audit_uuid,
        "issue_type": issue_type,
        "selection_mode": selection_mode,
    }
    if selected_sub_audit_uuid:
        params["sub_audit_uuid"] = selected_sub_audit_uuid

    with CodeDDClient(config=cfg) as client:
        final_resp = client.get(Endpoints.FIX_OVERVIEW, params=params)
    if final_resp.status_code != 200:
        _handle_error_response(final_resp, "Failed to fetch scoped fix overview.")
        raise typer.Exit(code=1)

    data = final_resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to fetch scoped fix overview."))
        raise typer.Exit(code=1)

    # Persist sub-audit selection so fix repo / fix status can show it
    if selected_sub_audit_uuid and selection_mode == "specific":
        sub_audit_list = overview.get("available_sub_audits", []) if cfg.active_audit_type == "group" else []
        matched = next((s for s in sub_audit_list if s.get("audit_uuid") == selected_sub_audit_uuid), None)
        cfg.active_sub_audit_uuid = selected_sub_audit_uuid
        cfg.active_sub_audit_name = matched.get("repo_name", "") if matched else ""
        cfg.save()
    elif selection_mode == "auto":
        cfg.active_sub_audit_uuid = ""
        cfg.active_sub_audit_name = ""
        cfg.save()

    summary = data.get("summary", {})
    print_success(f"Fix overview loaded for [bold]{cfg.active_audit_name}[/bold].")
    console.print(f"[bold]Issue Type:[/bold] {issue_type}")
    if data.get("selected_sub_audit_uuid"):
        sub_name = cfg.active_sub_audit_name
        label = (
            f"{sub_name}  [dim]({data['selected_sub_audit_uuid']})[/dim]"
            if sub_name
            else data["selected_sub_audit_uuid"]
        )
        console.print(f"[bold]Repository:[/bold] {label}")
    console.print(f"[bold]Selection mode:[/bold] {data.get('selection_mode', 'auto')}")

    if issue_type == "vulns":
        by_sev = summary.get("by_severity", {})
        if by_sev:
            console.print(
                f"[bold]By severity:[/bold]  critical={by_sev.get('critical', 0)}  "
                f"high={by_sev.get('high', 0)}  medium={by_sev.get('medium', 0)}  "
                f"low={by_sev.get('low', 0)}"
            )

    _render_progress(
        {
            "total_issues": summary.get("total_issues", 0),
            "resolved_issues": summary.get("resolved_issues", 0),
            "pending_issues": summary.get("pending_issues", 0),
            "queue_position": 0,
        }
    )
    current = data.get("current_issue")
    if current:
        print_info("Current issue from active session:")
        _render_status_any_issue(current)
    else:
        next_cmd = "codedd fix vulns next" if issue_type == "vulns" else "codedd fix flags next"
        print_info(f"No active issue selected yet. Run [bold cyan]{next_cmd}[/bold cyan].")


# ---------------------------------------------------------------------------
# codedd fix flags next
# ---------------------------------------------------------------------------


@flags_app.command("next")
@require_auth
def next_flag_issue(
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Use auto-priority selection mode across scoped audits.",
    ),
    sub_audit_uuid: str | None = typer.Option(
        None,
        "--sub-audit-uuid",
        help="Explicitly scope to one sub-audit UUID.",
    ),
) -> None:
    """
    Get the next logical unresolved flag issue.
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    payload = {"audit_uuid": cfg.active_audit_uuid, "issue_type": "flags"}
    if auto:
        payload["selection_mode"] = "auto"
    if sub_audit_uuid:
        payload["sub_audit_uuid"] = sub_audit_uuid.strip()
        payload["selection_mode"] = "specific"

    with CodeDDClient(config=cfg) as client:
        resp = client.post(Endpoints.FIX_FLAGS_NEXT, json=payload)
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to fetch next issue.")
        raise typer.Exit(code=1)

    data = resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to fetch next issue."))
        raise typer.Exit(code=1)

    current = data.get("current_issue")
    if not current:
        print_info(data.get("message", "No unresolved issues left for this scope."))
        _render_progress(data.get("progress", {}))
        return

    print_success("Loaded next issue.")
    _render_issue(current)
    _warn_if_stale(current, FixSessionTracker(cfg.active_audit_uuid))
    _render_progress(data.get("progress", {}))


# ---------------------------------------------------------------------------
# codedd fix flags invalidate
# ---------------------------------------------------------------------------


@flags_app.command("invalidate")
@require_auth
def invalidate_flag() -> None:
    """
    Mark the current flag as **not valid** and advance to the next issue.

    Sets user_marked_valid=false on the current flag, signaling that after
    review the issue does not warrant a fix.  The session automatically
    advances to the next unresolved flag — no separate ``resolve`` call
    is needed.
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    invalidated_uuid = ""
    payload = {"audit_uuid": cfg.active_audit_uuid, "issue_type": "flags"}
    with CodeDDClient(config=cfg) as client:
        resp = client.post(Endpoints.FIX_INVALIDATE, json=payload)
        if resp.status_code != 200:
            _handle_error_response(resp, "Failed to invalidate current issue.")
            raise typer.Exit(code=1)

        data = resp.json()
        if data.get("status") != "success":
            print_error(data.get("message", "Failed to invalidate current issue."))
            raise typer.Exit(code=1)

        invalidated_uuid = data.get("invalidated_issue_uuid", "")
        invalidated_file = data.get("file_path", "")
        print_success(f"Issue [bold]{invalidated_uuid}[/bold] marked as not valid.")

        if invalidated_file and invalidated_uuid:
            FixSessionTracker(cfg.active_audit_uuid).record_invalidated(
                invalidated_file, invalidated_uuid,
            )

        # Explicitly advance the queue by requesting the next issue.
        # The invalidate response's ``next_issue`` can stale-return the
        # just-invalidated issue; a dedicated next-call guarantees a true
        # advance so the caller never has to follow up with ``resolve``.
        next_payload: dict = {
            "audit_uuid": cfg.active_audit_uuid,
            "issue_type": "flags",
            "selection_mode": "auto",
        }
        next_resp = client.post(Endpoints.FIX_FLAGS_NEXT, json=next_payload)

    tracker = FixSessionTracker(cfg.active_audit_uuid)
    if next_resp.status_code == 200:
        next_data = next_resp.json()
        if next_data.get("status") == "success":
            next_issue = next_data.get("current_issue")
            if next_issue:
                # Guard against the server returning the same issue we just invalidated
                if next_issue.get("issue_uuid") == invalidated_uuid:
                    print_warning(
                        "Server returned the invalidated issue again. "
                        "Try [bold cyan]codedd fix flags next --auto[/bold cyan] to advance manually."
                    )
                else:
                    print_info("Next issue:")
                    _render_issue(next_issue)
                    _warn_if_stale(next_issue, tracker)
            else:
                print_info(next_data.get("message", "No unresolved issues left."))
            _render_progress(next_data.get("progress", {}))
            return

    # Fallback: show whatever the original invalidate response contained
    next_issue = data.get("next_issue")
    if next_issue and next_issue.get("issue_uuid") != invalidated_uuid:
        print_info("Next issue:")
        _render_issue(next_issue)
    else:
        print_info("No unresolved issues left.")
    _render_progress(data.get("progress", {}))


# ---------------------------------------------------------------------------
# codedd fix vulns next
# ---------------------------------------------------------------------------


@vulns_app.command("next")
@require_auth
def next_vuln_issue(
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Auto-priority: critical -> high -> medium -> low; used-count first within each tier.",
    ),
    severity: Severity | None = typer.Option(
        None,
        "--severity",
        "-s",
        help="Filter to a specific severity: critical, high, medium, low.",
    ),
    used_only: bool = typer.Option(
        False,
        "--used-only",
        "-u",
        help="Only show vulnerabilities in packages with file-level usage.",
    ),
    sub_audit_uuid: str | None = typer.Option(
        None,
        "--sub-audit-uuid",
        help="Explicitly scope to one sub-audit UUID.",
    ),
) -> None:
    """
    Get the next unresolved vulnerable package to remediate.
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    payload: dict = {
        "audit_uuid": cfg.active_audit_uuid,
        "issue_type": "vulns",
    }
    if auto:
        payload["selection_mode"] = "auto"
    if severity:
        payload["severity"] = severity.value
    if used_only:
        payload["used_only"] = True
    if sub_audit_uuid:
        payload["sub_audit_uuid"] = sub_audit_uuid.strip()
        payload["selection_mode"] = "specific"

    with CodeDDClient(config=cfg) as client:
        resp = client.post(Endpoints.FIX_VULNS_NEXT, json=payload)
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to fetch next vulnerability.")
        raise typer.Exit(code=1)

    data = resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to fetch next vulnerability."))
        raise typer.Exit(code=1)

    current = data.get("current_issue")
    if not current:
        print_info(data.get("message", "No unresolved vulnerability issues left for this scope."))
        _render_progress(data.get("progress", {}))
        return

    print_success("Loaded next vulnerability issue.")
    _render_vuln_issue(current)
    _render_progress(data.get("progress", {}))


# ---------------------------------------------------------------------------
# codedd fix vulns affected-files <package_name>
# ---------------------------------------------------------------------------


@vulns_app.command("affected-files")
@require_auth
def vuln_affected_files(
    package_name: str = typer.Argument(
        None,
        help="Package name to look up (e.g. lodash, requests).",
        show_default=False,
    ),
) -> None:
    """
    List files that directly depend on a vulnerable package (sanitized paths).

    Example:  codedd fix vulns affected-files lodash
    """
    if not package_name:
        print_error(
            "Package name is required.\n\n"
            "  Usage: [bold cyan]codedd fix vulns affected-files <PACKAGE_NAME>[/bold cyan]\n"
            "  Example: [dim]codedd fix vulns affected-files lodash[/dim]"
        )
        raise typer.Exit(code=1)
    cfg = ConfigManager()
    _require_active_audit(cfg)

    params = {
        "audit_uuid": cfg.active_audit_uuid,
        "package_name": package_name.strip(),
    }

    with CodeDDClient(config=cfg) as client:
        resp = client.get(Endpoints.FIX_VULNS_AFFECTED_FILES, params=params)
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to fetch affected files.")
        raise typer.Exit(code=1)

    data = resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to fetch affected files."))
        raise typer.Exit(code=1)

    files = data.get("files", [])
    total = data.get("total_files", len(files))

    if not files:
        print_info(f"No files found importing [bold]{package_name}[/bold] in this audit scope.")
        return

    table = Table(
        title=f"Files depending on [bold]{package_name}[/bold] ({total} total)",
        show_header=True,
        padding=(0, 1),
    )
    table.add_column("#", style="dim", width=5, justify="right")
    table.add_column("File Path")
    for idx, fp in enumerate(files, start=1):
        table.add_row(str(idx), fp)
    console.print(table)


# ---------------------------------------------------------------------------
# codedd fix repo <name>  — scope fix workflow to a named repository
# ---------------------------------------------------------------------------


def _resolve_sub_audit(query: str, sub_audits: list[dict]) -> "dict | list[dict] | None":
    """
    Match *query* (name or UUID) against *sub_audits*.

    Returns:
        dict       — exactly one match
        list[dict] — multiple candidates (caller must disambiguate)
        None       — no match
    """
    # Exact UUID
    for sub in sub_audits:
        if sub.get("audit_uuid", "") == query:
            return sub

    # Exact repo name (case-insensitive)
    exact = [s for s in sub_audits if s.get("repo_name", "").lower() == query.lower()]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        return exact

    # Partial repo name (case-insensitive substring)
    partial = [s for s in sub_audits if query.lower() in s.get("repo_name", "").lower()]
    if len(partial) == 1:
        return partial[0]
    if len(partial) > 1:
        return partial

    return None


def _interactive_repo_select(
    cfg: ConfigManager, sub_audits: list[dict]
) -> tuple[str, str] | tuple[None, None]:
    """
    Show the current sub-audit selection, a ranked repo table, and prompt for a choice.

    Returns:
        (uuid, name)   — a specific repo was chosen
        (None, None)   — auto-priority mode was chosen (choice 0)
    """
    current_name = cfg.active_sub_audit_name

    console.print()
    if current_name:
        console.print(
            f"  Currently scoped to: [bold green]{current_name}[/bold green]  "
            f"[dim](audit: {cfg.active_audit_name})[/dim]"
        )
    else:
        console.print(
            f"  Currently scoped to: [dim]none — auto-priority mode[/dim]  "
            f"[dim](audit: {cfg.active_audit_name})[/dim]"
        )

    sorted_subs = sorted(
        sub_audits,
        key=lambda sa: (-_extract_color_counts(sa)[0], -_extract_color_counts(sa)[1]),
    )

    table = Table(
        title=f"Repositories in {cfg.active_audit_name or 'this audit'} — ranked by severity",
        show_header=True,
        padding=(0, 1),
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Repository", min_width=22)
    table.add_column("Status", min_width=10)
    table.add_column("[red]Red[/red]", justify="right", width=5)
    table.add_column("[orange1]Orange[/orange1]", justify="right", width=7)
    table.add_column("Total", justify="right", width=6)

    table.add_row("0", "[dim]Auto-priority — highest severity across all repos[/dim]", "", "", "", "")

    for idx, sub in enumerate(sorted_subs, start=1):
        red, orange = _extract_color_counts(sub)
        total = int(sub.get("total_issues") or sub.get("issue_count") or 0)
        name = sub.get("repo_name") or sub.get("audit_uuid", "—")
        is_current = name == current_name
        name_cell = f"[bold green]{name} ✓[/bold green]" if is_current else name
        red_str = f"[red]{red}[/red]" if red > 0 else "[dim]0[/dim]"
        orange_str = f"[orange1]{orange}[/orange1]" if orange > 0 else "[dim]0[/dim]"
        total_str = str(total) if total else "—"
        table.add_row(str(idx), name_cell, sub.get("status", "—"), red_str, orange_str, total_str)

    console.print()
    console.print(table)

    choice = IntPrompt.ask(
        "\nSelect repository",
        default=0,
        choices=[str(i) for i in range(0, len(sorted_subs) + 1)],
    )

    if choice == 0:
        return None, None
    selected = sorted_subs[choice - 1]
    return selected.get("audit_uuid", ""), selected.get("repo_name") or selected.get("audit_uuid", "")


@fix_app.command("repo")
@require_auth
def fix_repo(
    repo: str | None = typer.Argument(
        None,
        help=(
            "Repository name (exact or partial, case-insensitive) or sub-audit UUID. "
            "Omit to see the full list and select interactively."
        ),
    ),
    issue_type: str = typer.Option(
        "flags",
        "--type",
        "-t",
        help="Issue type to fix: flags | vulns  (default: flags)",
    ),
) -> None:
    """
    Select a repository and scope the fix workflow to it.

    Called without arguments, shows the current selection and a ranked list
    of all repositories, then prompts you to pick one — similar to
    [bold cyan]codedd audits select[/bold cyan].

    Called with a name or UUID, resolves it and scopes immediately:

        codedd fix repo frontend-service
        codedd fix repo frontend-service --type vulns
        codedd fix repo <sub-audit-uuid>

    After selecting, run:

        codedd fix flags next --auto   — get the first unresolved issue

    Equivalent to (but more readable than):

        codedd fix fetch flags --sub-audit-uuid <uuid>
    """
    issue_type = issue_type.strip().lower()
    if issue_type not in ("flags", "vulns"):
        print_error("--type must be [bold]flags[/bold] or [bold]vulns[/bold].")
        raise typer.Exit(code=1)

    cfg = ConfigManager()
    _require_active_audit(cfg)

    if cfg.active_audit_type != "group":
        print_warning(
            "The active audit is not a group audit — no sub-audit selection needed.\n"
            "Run [bold cyan]codedd fix fetch flags[/bold cyan] to load the overview directly."
        )
        raise typer.Exit(code=1)

    # Fetch sub-audit catalogue
    with CodeDDClient(config=cfg) as client:
        resp = client.get(
            Endpoints.FIX_OVERVIEW,
            params={"audit_uuid": cfg.active_audit_uuid, "issue_type": issue_type},
        )
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to fetch repository list.")
        raise typer.Exit(code=1)
    overview = resp.json()
    if overview.get("status") != "success":
        print_error(overview.get("message", "Failed to fetch repository list."))
        raise typer.Exit(code=1)

    sub_audits = overview.get("available_sub_audits", [])
    if not sub_audits:
        print_warning("No repositories found for this group audit.")
        raise typer.Exit(code=1)

    # ---- Resolve sub-audit UUID + name ----
    if repo is None:
        # Interactive selection view
        sub_audit_uuid, repo_name = _interactive_repo_select(cfg, sub_audits)
        if sub_audit_uuid is None:
            # User chose auto-priority mode
            with CodeDDClient(config=cfg) as client:
                auto_resp = client.get(
                    Endpoints.FIX_OVERVIEW,
                    params={
                        "audit_uuid": cfg.active_audit_uuid,
                        "issue_type": issue_type,
                        "selection_mode": "auto",
                    },
                )
            if auto_resp.status_code == 200 and auto_resp.json().get("status") == "success":
                cfg.active_sub_audit_uuid = ""
                cfg.active_sub_audit_name = ""
                cfg.save()
                summary = auto_resp.json().get("summary", {})
                print_success("Fix session set to [bold]auto-priority[/bold] mode.")
                _render_progress(
                    {
                        "total_issues": summary.get("total_issues", 0),
                        "resolved_issues": summary.get("resolved_issues", 0),
                        "pending_issues": summary.get("pending_issues", 0),
                        "queue_position": 0,
                    }
                )
            else:
                print_success("Fix session set to auto-priority mode.")
            next_cmd = "codedd fix vulns next --auto" if issue_type == "vulns" else "codedd fix flags next --auto"
            print_info(f"Run [bold cyan]{next_cmd}[/bold cyan] to get your first issue.")
            return
    else:
        match = _resolve_sub_audit(repo.strip(), sub_audits)
        if match is None:
            print_error(f"No repository matching [bold]{repo}[/bold] found.")
            _print_sub_audit_list(sub_audits)
            raise typer.Exit(code=1)
        if isinstance(match, list):
            print_warning(f"Multiple repositories match [bold]{repo}[/bold] — please pick one:")
            _print_sub_audit_list(match, start_index=1)
            choice = IntPrompt.ask(
                "Select repository",
                choices=[str(i) for i in range(1, len(match) + 1)],
            )
            match = match[choice - 1]
        sub_audit_uuid = match.get("audit_uuid", "")
        repo_name = match.get("repo_name") or sub_audit_uuid

    # ---- Scope the session to the resolved sub-audit ----
    with CodeDDClient(config=cfg) as client:
        scoped_resp = client.get(
            Endpoints.FIX_OVERVIEW,
            params={
                "audit_uuid": cfg.active_audit_uuid,
                "issue_type": issue_type,
                "selection_mode": "specific",
                "sub_audit_uuid": sub_audit_uuid,
            },
        )
    if scoped_resp.status_code != 200:
        _handle_error_response(scoped_resp, "Failed to scope fix session to repository.")
        raise typer.Exit(code=1)
    scoped = scoped_resp.json()
    if scoped.get("status") != "success":
        print_error(scoped.get("message", "Failed to scope fix session to repository."))
        raise typer.Exit(code=1)

    # Persist selection so other commands (and fix repo with no args) know what's active
    cfg.active_sub_audit_uuid = sub_audit_uuid
    cfg.active_sub_audit_name = repo_name
    cfg.save()

    summary = scoped.get("summary", {})
    print_success(
        f"Fix session scoped to [bold]{repo_name}[/bold]  "
        f"[dim](audit: {cfg.active_audit_name})[/dim]"
    )
    _render_progress(
        {
            "total_issues": summary.get("total_issues", 0),
            "resolved_issues": summary.get("resolved_issues", 0),
            "pending_issues": summary.get("pending_issues", 0),
            "queue_position": 0,
        }
    )

    next_cmd = (
        "codedd fix vulns next --auto" if issue_type == "vulns" else "codedd fix flags next --auto"
    )
    print_info(f"Run [bold cyan]{next_cmd}[/bold cyan] to get your first issue.")


def _print_sub_audit_list(sub_audits: list[dict], start_index: int = 1) -> None:
    """Print a compact table of sub-audits (used in error/disambiguation paths)."""
    table = Table(title="Available repositories", show_header=True, padding=(0, 1))
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Repository", min_width=20)
    table.add_column("Status", min_width=10)
    table.add_column("Sub-audit UUID", style="dim")
    for idx, sub in enumerate(sub_audits, start=start_index):
        table.add_row(
            str(idx),
            sub.get("repo_name", "—"),
            sub.get("status", "—"),
            sub.get("audit_uuid", "—"),
        )
    console.print(table)


# ---------------------------------------------------------------------------
# codedd fix status  (auto-detects flags or vulns session)
# ---------------------------------------------------------------------------


@fix_app.command("status")
@require_auth
def fix_status() -> None:
    """
    Show a unified fix dashboard across all domains (flags + vulnerabilities).

    Displays the current issue being worked on and progress for each domain.
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    flags_data = _fetch_domain_status(cfg, "flags")
    vulns_data = _fetch_domain_status(cfg, "vulns")
    flags_has_session = bool(flags_data and isinstance(flags_data.get("progress"), dict))
    vulns_has_session = bool(vulns_data and isinstance(vulns_data.get("progress"), dict))

    if not flags_has_session and not vulns_has_session:
        flags_overview = _fetch_domain_overview(cfg, "flags")
        vulns_overview = _fetch_domain_overview(cfg, "vulns")
    else:
        flags_overview = None
        vulns_overview = None

    # For group audits, always need the flags overview to render per-repo ranking
    is_group = cfg.active_audit_type == "group"
    if is_group and flags_overview is None:
        flags_overview = _fetch_domain_overview(cfg, "flags")

    if not flags_has_session and not vulns_has_session and not flags_overview and not vulns_overview:
        print_info(
            "No active fix sessions found. Start with:\n"
            "  [bold cyan]codedd fix fetch flags[/bold cyan]  or  "
            "[bold cyan]codedd fix fetch vulns[/bold cyan]"
        )
        return

    # -- Progress overview table --
    progress_table = Table(
        title=f"Fix Progress \u2014 {cfg.active_audit_name or 'Audit'}",
        show_header=True,
        padding=(0, 1),
    )
    progress_table.add_column("Domain", style="bold", min_width=8)
    progress_table.add_column("Total", justify="right")
    progress_table.add_column("Resolved", justify="right", style="green")
    progress_table.add_column("Pending", justify="right", style="yellow")
    progress_table.add_column("Queue Pos", justify="right", style="dim")
    progress_table.add_column("Current Issue", min_width=30)

    for label, data, has_session, overview in [
        ("Flags", flags_data, flags_has_session, flags_overview),
        ("Vulns", vulns_data, vulns_has_session, vulns_overview),
    ]:
        if not has_session:
            if overview and isinstance(overview.get("summary"), dict):
                summary = overview.get("summary", {})
                total = str(summary.get("total_issues", 0))
                resolved = str(summary.get("resolved_issues", 0))
                pending = str(summary.get("pending_issues", 0))
                progress_table.add_row(
                    label,
                    total,
                    resolved,
                    pending,
                    "-",
                    "[dim]no active session[/dim]",
                )
            else:
                progress_table.add_row(label, "-", "-", "-", "-", "[dim]no session[/dim]")
            continue

        if not data:
            progress_table.add_row(label, "-", "-", "-", "-", "[dim]no session[/dim]")
            continue
        prog = data.get("progress", {})
        current = data.get("current_issue")
        total = str(prog.get("total_issues", 0))
        resolved = str(prog.get("resolved_issues", 0))
        pending = str(prog.get("pending_issues", 0))
        position = str(prog.get("queue_position", 0))
        if current:
            if label == "Flags":
                issue_label = (
                    f"{current.get('issue_uuid', '')[:12]}.. "
                    f"[dim]({current.get('flag_color', '')})[/dim]"
                )
            else:
                issue_label = (
                    f"{current.get('package_name', '')} "
                    f"[dim]({current.get('severity', '')})[/dim]"
                )
        else:
            issue_label = "[dim]none[/dim]"
        progress_table.add_row(label, total, resolved, pending, position, issue_label)

    console.print()
    console.print(progress_table)

    # -- Detail blocks for each domain with an active issue --
    for label, data, has_session in [
        ("Flags", flags_data, flags_has_session),
        ("Vulns", vulns_data, vulns_has_session),
    ]:
        if not has_session or not data:
            continue
        current = data.get("current_issue")
        if not current:
            continue
        console.print()
        console.rule(f"[bold]{label} \u2014 Current Issue[/bold]")
        _render_status_any_issue(current)

    # -- Per-repository ranking + next-action hint for group audits --
    if is_group and flags_overview:
        sub_audits = flags_overview.get("available_sub_audits", [])
        _render_sub_audit_ranking(sub_audits)

        console.print()
        console.rule("[dim]Next Action[/dim]")

        # Show currently selected repository (stored in config by fix repo / fetch)
        selected_name = cfg.active_sub_audit_name
        if selected_name:
            console.print(
                f"  Selected repository: [bold green]{selected_name}[/bold green]  "
                f"[dim](change with codedd fix repo)[/dim]"
            )
        else:
            console.print("  Selected repository: [dim]none — auto-priority mode[/dim]")

        flags_summary = flags_overview.get("summary", {})
        pending = int(flags_summary.get("pending_issues", 0))

        if sub_audits:
            top = max(sub_audits, key=lambda sa: _extract_color_counts(sa))
            top_name = top.get("repo_name") or top.get("audit_uuid", "")
            red, orange = _extract_color_counts(top)

            if pending == 0:
                console.print(
                    "  [green]All flag issues are resolved across all repositories.[/green]"
                )
            else:
                parts = []
                if red:
                    parts.append(f"[red]{red} red[/red]")
                if orange:
                    parts.append(f"[orange1]{orange} orange[/orange1]")
                severity_str = "  ·  ".join(parts) if parts else f"{pending} pending"
                console.print(
                    f"  Top priority: [bold]{top_name}[/bold]  ({severity_str})"
                )
                console.print(
                    f'  [dim]Start fixing:[/dim]  [bold cyan]codedd fix repo "{top_name}"[/bold cyan]'
                )

        console.print(
            "  [dim]See all repositories:[/dim]  [bold cyan]codedd fix repo[/bold cyan]"
        )


# ---------------------------------------------------------------------------
# codedd fix comment "<text>"  (auto-detects flags or vulns session)
# ---------------------------------------------------------------------------


@fix_app.command("comment")
@require_auth
def fix_comment(
    comment: str = typer.Argument(..., help='Comment text, e.g. "bumped lodash to 4.17.21".'),
    issue_type: str | None = typer.Option(
        None,
        "--issue-type",
        "-t",
        help="Session type: flags | vulns.  Auto-detected from the active session if omitted.",
    ),
) -> None:
    """
    Add a comment to the current issue (flags or vulns, auto-detected).
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    it = issue_type.strip().lower() if issue_type else _detect_active_issue_type(cfg)

    payload = {
        "audit_uuid": cfg.active_audit_uuid,
        "issue_type": it,
        "comment": comment,
    }
    with CodeDDClient(config=cfg) as client:
        resp = client.post(Endpoints.FIX_COMMENT, json=payload)
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to store comment.")
        raise typer.Exit(code=1)

    data = resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to store comment."))
        raise typer.Exit(code=1)

    print_success("Comment stored on current issue.")


# ---------------------------------------------------------------------------
# codedd fix resolve  (auto-detects flags or vulns session)
# ---------------------------------------------------------------------------


@fix_app.command("resolve")
@require_auth
def fix_resolve(
    issue_type: str | None = typer.Option(
        None,
        "--issue-type",
        "-t",
        help="Session type: flags | vulns.  Auto-detected from the active session if omitted.",
    ),
) -> None:
    """
    Mark the current issue as resolved and advance to the next one (auto-detects flags/vulns).
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    it = issue_type.strip().lower() if issue_type else _detect_active_issue_type(cfg)

    payload = {"audit_uuid": cfg.active_audit_uuid, "issue_type": it}
    with CodeDDClient(config=cfg) as client:
        resp = client.post(Endpoints.FIX_RESOLVE, json=payload)
    if resp.status_code != 200:
        _handle_error_response(resp, "Failed to resolve current issue.")
        raise typer.Exit(code=1)

    data = resp.json()
    if data.get("status") != "success":
        print_error(data.get("message", "Failed to resolve current issue."))
        raise typer.Exit(code=1)

    print_success("Current issue resolved.")

    # Track the resolved file so later flags on the same file trigger a stale warning
    tracker = FixSessionTracker(cfg.active_audit_uuid)
    resolved_file = data.get("resolved_file_path", "") or data.get("file_path", "")
    resolved_uuid = data.get("resolved_issue_uuid", "")
    if resolved_file and resolved_uuid:
        tracker.record_resolved(resolved_file, resolved_uuid)

    next_issue = data.get("next_issue")
    if next_issue:
        print_info("Next issue:")
        _render_any_issue(next_issue)
        _warn_if_stale(next_issue, tracker)
    else:
        print_info("No unresolved issues left.")
    _render_progress(data.get("progress", {}))


# ---------------------------------------------------------------------------
# Remediation Module Access sub-app
# ---------------------------------------------------------------------------

access_app = typer.Typer(
    no_args_is_help=True,
    rich_markup_mode="rich",
    help=(
        "Manage Remediation Module access for the active audit's organization.\n\n"
        "[bold]Commands:[/bold]\n"
        "  codedd fix access status      — show access status\n"
        "  codedd fix access enable       — release remediation data (initiator)\n"
        "  codedd fix access disable      — revoke remediation access (initiator)\n"
        "  codedd fix access activate     — activate the module for the org\n"
        "  codedd fix access deactivate   — deactivate the module (initiator)"
    ),
)


@access_app.command("status")
@require_auth
def access_status() -> None:
    """Show remediation access status for the active audit's organization."""
    cfg = ConfigManager()
    _require_active_audit(cfg)
    account_uuid = _require_account_uuid(cfg)
    client = CodeDDClient()

    response = client.get(
        Endpoints.FIX_ACCESS_STATUS,
        params={
            "audit_uuid": cfg.active_audit_uuid,
            "account_uuid": account_uuid,
        },
    )
    data = response.json()

    if data.get("status") != "success":
        print_error(data.get("message", "Failed to fetch remediation access status."))
        raise typer.Exit(code=1)

    t = Table(title="Remediation Module Access", show_lines=True)
    t.add_column("Property", style="bold")
    t.add_column("Value")
    t.add_row("Organization UUID", data.get("organization_uuid", "—"))
    t.add_row("Your Role", data.get("user_role", "—"))

    enabled = data.get("remediation_enabled", False)
    active = data.get("module_active", False)
    t.add_row(
        "Remediation Released",
        "[green]Yes[/green]" if enabled else "[red]No[/red]",
    )
    t.add_row(
        "Module Active",
        "[green]Yes[/green]" if active else "[yellow]No[/yellow]",
    )
    console.print(t)


def _toggle_access(action: str) -> None:
    """Shared helper for enable/disable/activate/deactivate."""
    cfg = ConfigManager()
    _require_active_audit(cfg)
    account_uuid = _require_account_uuid(cfg)
    client = CodeDDClient()

    response = client.post(
        Endpoints.FIX_ACCESS_TOGGLE,
        json={
            "audit_uuid": cfg.active_audit_uuid,
            "account_uuid": account_uuid,
            "action": action,
        },
    )
    data = response.json()

    if data.get("status") != "success":
        print_error(data.get("message", f"Failed to {action} remediation."))
        raise typer.Exit(code=1)

    print_success(data.get("message", f"Remediation {action}d successfully."))


def _require_account_uuid(cfg: ConfigManager) -> str:
    """Ensure current session has account UUID persisted from login."""
    if not cfg.account_uuid:
        print_error("Missing account context. Run [bold]codedd auth login[/bold] and try again.")
        raise typer.Exit(code=1)
    return cfg.account_uuid


@access_app.command("enable")
@require_auth
def access_enable() -> None:
    """Release remediation data for the organization (initiator only)."""
    _toggle_access("enable")


@access_app.command("disable")
@require_auth
def access_disable() -> None:
    """Revoke remediation access and deactivate the module (initiator only)."""
    _toggle_access("disable")


@access_app.command("activate")
@require_auth
def access_activate() -> None:
    """Activate the Remediation Module for the organization."""
    _toggle_access("activate")


@access_app.command("deactivate")
@require_auth
def access_deactivate() -> None:
    """Deactivate the Remediation Module (initiator only)."""
    _toggle_access("deactivate")


# ---------------------------------------------------------------------------
# Register sub-apps
# ---------------------------------------------------------------------------

fix_app.add_typer(flags_app, name="flags", help="Fix security/quality flags (AI + SonarQube).")
fix_app.add_typer(vulns_app, name="vulns", help="Fix third-party package vulnerabilities.")
fix_app.add_typer(access_app, name="access", help="Manage Remediation Module access.")
