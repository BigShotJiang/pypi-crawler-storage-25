"""
``codedd audit`` sub-commands: start.

Manages the audit lifecycle — pre-flight checks, payment, local file
auditing via LLM, and result submission to CodeDD.

Workflow:
    1. ``codedd scope confirm``        – register scope with CodeDD
    2. ``codedd audit start``          – auto-sync, pre-flight, pay/budget,
                                         fetch plan, audit locally, submit results
"""

import logging
import os
import sys
import threading
import time
import urllib.parse
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
)
from rich.prompt import Confirm
from rich.table import Table

from codedd_cli.api.client import CodeDDClient
from codedd_cli.api.endpoints import Endpoints
from codedd_cli.auditor.audit_checkpoint import AuditCheckpoint
from codedd_cli.auditor.complexity_analyzer import (
    FileComplexityResult,
)
from codedd_cli.auditor.dependency_scanner import (
    ImportResult,
    ManifestResult,
)
from codedd_cli.auditor.file_auditor import AuditFileResult
from codedd_cli.auditor.sub_audit_runner import (
    SubAuditRunnerContext,
    SubmissionRetryPolicy,
    run_sub_audit,
)
from codedd_cli.auth.session import require_auth
from codedd_cli.config.constants import (
    FILE_AUDIT_SECONDS_MAX,
    FILE_AUDIT_SECONDS_MIN,
    FILE_COUNT_CONCURRENCY_WARN,
    MIN_RECOMMENDED_CONCURRENCY,
    SERVER_FILE_AUDIT_SOFT_TIMEOUT_H,
)
from codedd_cli.config.settings import ConfigManager
from codedd_cli.llm.key_manager import PROVIDER_MODELS, LLMKeyManager
from codedd_cli.models.audit import Audit, GroupAudit
from codedd_cli.utils.display import (
    SYMBOL_OK,
    SYMBOL_WARN,
    MultiRepoProgress,
    print_error,
    print_info,
    print_success,
    print_warning,
)
from codedd_cli.utils.payload_inspector import (
    open_file,
    review_payload,
    review_request,
    write_payload_file,
)

logger = logging.getLogger(__name__)

REPO_PIPELINE_TIMEOUT_SECONDS = 1800

console = Console()
audit_app = typer.Typer(no_args_is_help=True)


_TRUSTED_CHECKOUT_DOMAINS = frozenset(
    {
        "codedd.ai",
        "www.codedd.ai",
        "checkout.stripe.com",
        "billing.stripe.com",
    }
)


def _is_safe_checkout_url(url: str) -> bool:
    """Return True only when *url* uses HTTPS and points to a trusted domain."""
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return False
    if parsed.scheme != "https":
        return False
    host = parsed.netloc.lower().split(":")[0]  # strip optional port
    return host in _TRUSTED_CHECKOUT_DOMAINS


def _as_bool(value: object) -> bool:
    """Best-effort bool coercion for API payload values."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y"}
    return False


def _extract_account_uuid(value: object) -> str:
    """Extract an account UUID from mixed response shapes."""
    if isinstance(value, str):
        return value.strip().lower()
    if isinstance(value, dict):
        for key in ("account_uuid", "uuid", "id"):
            raw = value.get(key)
            if isinstance(raw, str) and raw.strip():
                return raw.strip().lower()
    return ""


def _is_current_user_auditor(preflight: dict, account_uuid: str) -> bool:
    """
    Determine whether the current CLI user is the auditor/scope accepter.

    The backend shape may evolve, so this checks multiple compatible fields.
    """
    for key in (
        "current_user_is_auditor",
        "user_is_auditor",
        "is_auditor",
        "is_scope_acceptor",
        "scope_accepted_by_current_user",
        "scope_confirmed_by_current_user",
    ):
        if _as_bool(preflight.get(key)):
            return True

    for key in ("current_user_role", "user_role", "role_in_audit", "audit_role", "role"):
        role = str(preflight.get(key, "")).strip().lower()
        if role in {"auditor", "owner", "creator", "scope_owner"}:
            return True

    current = account_uuid.strip().lower()
    if not current:
        current = _extract_account_uuid(
            preflight.get("current_account_uuid")
            or preflight.get("current_user")
            or preflight.get("current_account")
        )
    if not current:
        return False

    for key in (
        "auditor_account_uuid",
        "scope_acceptor_account_uuid",
        "scope_accepted_by_account_uuid",
        "scope_confirmed_by_account_uuid",
        "confirmed_by_account_uuid",
        "accepted_by_account_uuid",
        "scope_actor",
        "scope_acceptor",
        "scope_confirmer",
        "auditor",
    ):
        if _extract_account_uuid(preflight.get(key)) == current:
            return True

    return False


def _is_readiness_only_block(preflight: dict) -> bool:
    """Return True when pre-flight block is about readiness/auditor approval."""
    for key in (
        "blocked_by_ready_status",
        "blocked_by_auditor_readiness",
        "requires_auditor_ready",
        "awaiting_auditor_acceptance",
    ):
        if _as_bool(preflight.get(key)):
            return True

    text = f"{preflight.get('reason', '')} {preflight.get('message', '')}".strip().lower()
    if not text:
        return False
    return "ready" in text and ("auditor" in text or "accept" in text)


def _require_active_audit(cfg: ConfigManager) -> None:
    """Abort if no audit has been selected."""
    if not cfg.active_audit_uuid:
        print_error("No active audit.  Run [bold cyan]codedd audits select[/bold cyan] first.")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# codedd audit start
# ---------------------------------------------------------------------------


@audit_app.command("start")
@require_auth
def start_audit(
    skip_sync: bool = typer.Option(
        False,
        "--skip-sync",
        help="Skip the automatic scope sync before starting.",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Auto-confirm prompts (non-interactive mode).",
    ),
    show: bool = typer.Option(
        False,
        "--show",
        "-s",
        help=(
            "Safe transparency mode: writes a single execution summary file, opens it, and asks for one confirmation."
        ),
    ),
    show_interactive: bool = typer.Option(
        False,
        "--show-interactive",
        help=(
            "Interactive transparency mode: review and confirm every outgoing "
            "request/payload (for debugging; can be very slow on large audits)."
        ),
    ),
    show_force_interactive: bool = typer.Option(
        False,
        "--show-force-interactive",
        help=("Force per-request interactive --show mode even when many confirmations are expected."),
    ),
    debug_llm: bool = typer.Option(
        False,
        "--debug-llm",
        help="Print full LLM prompt, raw response, and parsed result to the CLI (for debugging).",
    ),
    debug_llm_full_prompt: bool = typer.Option(
        False,
        "--debug-llm-full-prompt",
        help="Include full proprietary system prompt in --debug-llm output (sensitive).",
    ),
) -> None:
    """
    Start the active audit on the CodeDD platform.

    This command:
      1. Auto-syncs local scope with CodeDD (detects file changes).
      2. Runs pre-flight checks (status, payment, LoC budget).
      3. Handles payment scenarios (budget deduction or Stripe checkout).
      4. Enqueues the audit for processing.
    """
    cfg = ConfigManager()
    _require_active_audit(cfg)

    audit_uuid = cfg.active_audit_uuid
    audit_name = cfg.active_audit_name
    audit_type = cfg.active_audit_type

    console.print(f"\n[bold]Starting audit:[/bold]  {audit_name}  [dim]({audit_type})[/dim]\n")

    # Transparency mode selection:
    # - --show            => summary mode (single confirmation)
    # - --show-interactive => per-request confirmations (legacy behavior)
    # If both are provided, interactive mode takes precedence.
    interactive_show = show_interactive
    summary_show = show and not show_interactive

    if summary_show:
        summary_payload = {
            "command": "codedd audit start",
            "audit_uuid": audit_uuid,
            "audit_name": audit_name,
            "audit_type": audit_type,
            "transparency_mode": "summary",
            "notes": [
                "This mode does not pause on every API call.",
                "It is designed for production-size audits.",
                "Use --show-interactive for per-request review.",
            ],
            "high_level_steps": [
                "Scope sync (unless --skip-sync)",
                "Pre-flight check",
                "Payment / budget handling if required",
                "Fetch audit plan",
                "Local execution (LLM audit, complexity, dependencies, git, architecture)",
                "Batch submissions and completion trigger",
            ],
        }
        if not _review_summary_once(
            summary_payload,
            command_label="Audit Start --show Summary",
            context_note=(
                "This file is a high-level run summary. Individual requests are "
                "not reviewed one-by-one in summary mode."
            ),
            confirm_prompt="Proceed with this audit run?",
        ):
            print_info("Cancelled.")
            raise typer.Exit(code=0)

    # -----------------------------------------------------------------------
    # Phase 1 — Auto-sync (unless skipped)
    # -----------------------------------------------------------------------
    if not skip_sync:
        sync_ok = _auto_sync(cfg, auto_confirm=yes, show=interactive_show)
        if not sync_ok:
            print_error("Scope sync failed or was cancelled.  Audit not started.")
            raise typer.Exit(code=1)
        console.print()

    # -----------------------------------------------------------------------
    # Phase 1b — Verify LLM API key availability
    # -----------------------------------------------------------------------
    llm_ok = _check_llm_keys(cfg)
    if not llm_ok:
        raise typer.Exit(code=1)
    console.print()

    # -----------------------------------------------------------------------
    # Phase 1c — Guard against re-starting a running / completed audit
    # -----------------------------------------------------------------------
    if not _check_audit_state_before_start(cfg, audit_uuid):
        print_info("Audit start cancelled.")
        raise typer.Exit(code=0)

    # -----------------------------------------------------------------------
    # Phase 2 — Pre-flight check
    # -----------------------------------------------------------------------
    console.print("[dim]Pre-flight checks…[/dim]\n")

    if interactive_show:
        confirmed = review_request(
            "GET",
            Endpoints.AUDIT_CAN_START,
            params={"audit_uuid": audit_uuid},
            command_label="Audit Start — Pre-flight",
            context_note=(
                "This request checks whether the audit can be started "
                "(payment, scope, etc.). Only the audit UUID is sent."
            ),
            confirm_prompt="Proceed with this request to CodeDD?",
        )
        if not confirmed:
            print_info("Cancelled.")
            raise typer.Exit(code=0)

    with CodeDDClient(config=cfg) as client:
        preflight = _fetch_preflight(client, audit_uuid)

    if preflight is None:
        raise typer.Exit(code=1)

    # -----------------------------------------------------------------------
    # Fast-path resume: pre-flight blocked because audit is already "started".
    # The server returns an error when a group audit is in "Group audit started"
    # state (local file auditing was running and the terminal was closed).
    # Payment and AUDIT_START registration were already completed in the
    # previous run — skip phases 3-4 and resume local execution directly.
    # -----------------------------------------------------------------------
    _pf_msg = (
        preflight.get("message") or preflight.get("reason") or ""
    ).lower()
    _pf_is_started_block = (
        not preflight.get("can_start", False)
        and "group audit started" in _pf_msg
    )
    if _pf_is_started_block:
        print_info(
            "Audit is already in [bold]'started'[/bold] state — the previous local "
            "run was interrupted.\n"
            "  Payment and registration are already done.  "
            "Resuming local audit directly."
        )
        console.print()
        _run_local_audit(
            cfg,
            audit_uuid,
            show=interactive_show,
            show_force_interactive=show_force_interactive,
            debug_llm=debug_llm,
            debug_llm_full_prompt=debug_llm_full_prompt,
            scope_loc=preflight.get("total_lines_of_code", 0),
            yes=yes,
        )
        return

    # Server returned an error (e.g. 500 with status/message)
    if preflight.get("status") == "error":
        print_error(preflight.get("message", "Pre-flight check failed."))
        raise typer.Exit(code=1)

    # Legacy or alternate error shape
    if "error" in preflight:
        print_error(preflight["error"])
        raise typer.Exit(code=1)

    # Malformed or unexpected response
    if "can_start" not in preflight:
        print_error(preflight.get("message", "Invalid pre-flight response from server."))
        raise typer.Exit(code=1)

    _render_preflight(preflight)
    console.print()

    # -----------------------------------------------------------------------
    # Phase 3 — Decision tree
    # -----------------------------------------------------------------------
    # Use .get() so we don't KeyError when backend returns a minimal response
    # (e.g. can_start=False, reason="Not all repositories have been scoped").
    can_start = preflight.get("can_start", False)
    is_paid = preflight.get("is_paid", False)
    payment_required = preflight.get("payment_required", False)
    skip_budget_deduction = preflight.get("skip_budget_deduction", False)
    loc_delta = preflight.get("loc_delta", 0)
    loc_budget = preflight.get("loc_budget", 0)
    scope_loc = preflight.get("total_lines_of_code", 0)
    is_current_user_auditor = _is_current_user_auditor(preflight, cfg.account_uuid)
    readiness_only_block = (not can_start) and _is_readiness_only_block(preflight)

    # If the same CLI user is the auditor/scope accepter, run direct payment/budget
    # handling instead of the invitee-only "auditor handled checkout" path.
    effective_skip_budget_deduction = bool(skip_budget_deduction) and not is_current_user_auditor
    effective_can_start = bool(can_start) or (is_current_user_auditor and readiness_only_block)

    use_budget = False

    # -----------------------------------------------------------------------
    # Special case: pre-flight blocked because the audit is ALREADY in
    # "started" state.  This means the local file audit was previously
    # registered + paid for, but the terminal was closed mid-run.
    # Payment and AUDIT_START are already done — skip phases 3-4 and jump
    # straight to resuming the local execution (checkpoint will handle skips).
    # -----------------------------------------------------------------------
    if not effective_can_start:
        block_msg = (preflight.get("reason") or preflight.get("message") or "").lower()
        is_already_started = "group audit started" in block_msg or (
            "audit started" in block_msg and "cannot" in block_msg
        )
        if is_already_started:
            print_info(
                "Audit is already in 'started' state — the previous local run was "
                "interrupted.\n  Skipping payment/registration and resuming local "
                "execution directly."
            )
            console.print()
            _run_local_audit(
                cfg,
                audit_uuid,
                show=interactive_show,
                show_force_interactive=show_force_interactive,
                debug_llm=debug_llm,
                debug_llm_full_prompt=debug_llm_full_prompt,
                scope_loc=scope_loc,
                yes=yes,
            )
            return

    if is_current_user_auditor and (not can_start) and readiness_only_block:
        print_info("Auditor role detected for current CLI user. Proceeding without readiness gate.")

    if effective_can_start and effective_skip_budget_deduction:
        # Invitee/member CLI flow: auditor already handled checkout/readiness.
        print_success("Audit is ready. Checkout was handled by the auditor.")
        if not yes and not Confirm.ask("Start audit now?", default=True):
            print_info("Audit start cancelled.")
            raise typer.Exit()

    elif effective_can_start and is_paid and loc_delta == 0:
        # Fully paid, no changes — good to go
        print_success("Audit is fully paid. Ready to start.")
        if not yes and not Confirm.ask("Start audit now?", default=True):
            print_info("Audit start cancelled.")
            raise typer.Exit()

    elif effective_can_start and is_paid and loc_delta > 0:
        # Paid but scope grew, budget covers the delta
        print_warning(
            f"Scope increased by [bold]+{loc_delta:,}[/bold] LoC since payment.\n"
            f"  Your budget ([bold]{loc_budget:,}[/bold] LoC) can cover the difference."
        )
        if not yes and not Confirm.ask("Deduct from budget and start?", default=True):
            print_info("Audit start cancelled.")
            raise typer.Exit()
        use_budget = True

    elif effective_can_start and not is_paid:
        # Not paid, budget covers the full audit
        print_info(f"Using LoC budget: [bold]{scope_loc:,}[/bold] LoC (budget: {loc_budget:,} LoC).")
        if not yes and not Confirm.ask("Deduct from budget and start?", default=True):
            print_info("Audit start cancelled.")
            raise typer.Exit()
        use_budget = True

    elif payment_required and is_paid and loc_delta > 0:
        # Paid but scope grew beyond budget — need additional payment
        shortfall = loc_delta - loc_budget
        print_warning(
            f"Scope increased by [bold]+{loc_delta:,}[/bold] LoC since payment.\n"
            f"  Budget: {loc_budget:,} LoC | Shortfall: [bold red]{shortfall:,}[/bold red] LoC\n"
            f"  Additional payment is needed for the LoC difference."
        )
        if not Confirm.ask("Open payment page in your browser?", default=True):
            print_info("Audit start cancelled. You can pay at [bold cyan]codedd.ai[/bold cyan].")
            raise typer.Exit()

        paid_ok = _handle_checkout(cfg, audit_uuid, loc_delta, show=interactive_show)
        if not paid_ok:
            raise typer.Exit(code=1)

    elif payment_required and not is_paid:
        # Not paid, budget insufficient — full payment needed
        print_warning(
            f"LoC budget insufficient: [bold]{loc_budget:,}[/bold] available, "
            f"[bold]{scope_loc:,}[/bold] needed.\n"
            f"  Payment required for this audit."
        )
        if not Confirm.ask("Open payment page in your browser?", default=True):
            print_info("Audit start cancelled. You can pay at [bold cyan]codedd.ai[/bold cyan].")
            raise typer.Exit()

        paid_ok = _handle_checkout(cfg, audit_uuid, scope_loc, show=interactive_show)
        if not paid_ok:
            raise typer.Exit(code=1)

    else:
        # Fallback — preflight said cannot start
        print_error(preflight.get("reason", "Audit cannot be started."))
        raise typer.Exit(code=1)

    # -----------------------------------------------------------------------
    # Phase 4 — Register audit start on CodeDD (and optionally deduct budget)
    # -----------------------------------------------------------------------
    start_payload = {
        "audit_uuid": audit_uuid,
        "use_budget": bool(use_budget),
        "local_execution": True,  # CLI drives the audit locally
    }
    if interactive_show:
        if use_budget:
            command_label = "Audit Start — Budget Deduction"
            context_note = (
                "This payload tells CodeDD to deduct LoC from your budget and "
                "mark the audit as started. No server-side audit is triggered."
            )
            confirm_prompt = "Proceed with budget deduction on CodeDD?"
        else:
            command_label = "Audit Start — Mark Started"
            context_note = (
                "This payload marks the group audit as started for local CLI execution. "
                "No LoC budget will be deducted."
            )
            confirm_prompt = "Proceed with audit start registration on CodeDD?"

        confirmed = review_payload(
            start_payload,
            command_label=command_label,
            context_note=context_note,
            confirm_prompt=confirm_prompt,
        )
        if not confirmed:
            print_info("Cancelled.")
            raise typer.Exit(code=0)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Registering audit start…", total=None)
        with CodeDDClient(config=cfg) as client:
            resp = client.post(Endpoints.AUDIT_START, json=start_payload)

    if resp.status_code != 200:
        msg = "Failed to register audit start"
        try:
            msg = resp.json().get("message", msg)
        except Exception:
            pass
        print_error(msg)
        raise typer.Exit(code=1)

    body = resp.json()
    if body.get("status") != "success":
        print_error(body.get("message", "Unknown error while registering audit start"))
        raise typer.Exit(code=1)

    loc_deducted = body.get("loc_deducted", 0)
    if loc_deducted:
        print_info(f"  {loc_deducted:,} LoC deducted from budget")

    # -----------------------------------------------------------------------
    # Phase 4b — Record LLM model(s) on CodeDD
    # -----------------------------------------------------------------------
    # The model is determined by the configured provider preference and stored
    # keys — we know it upfront before any file is audited.
    llm_model_str = _resolve_llm_model_string(cfg)
    if llm_model_str:
        _submit_llm_model_used(cfg, audit_uuid, llm_model_str)

    # -----------------------------------------------------------------------
    # Phase 5 — Local file audit
    # -----------------------------------------------------------------------
    _run_local_audit(
        cfg,
        audit_uuid,
        show=interactive_show,
        show_force_interactive=show_force_interactive,
        debug_llm=debug_llm,
        debug_llm_full_prompt=debug_llm_full_prompt,
        scope_loc=scope_loc,
        yes=yes,
    )


# ---------------------------------------------------------------------------
# audit status
# ---------------------------------------------------------------------------

# Server-side pipeline steps in processing order.
# Each entry: (display_label, list_of_status_strings_that_mark_this_step_done)
_AUDIT_PIPELINE: list[tuple[str, list[str]]] = [
    ("File auditing",     ["file auditing completed", "scores calculated",
                           "architecture completed", "contextualization completed",
                           "consolidation completed", "recommendations completed",
                           "audit completed"]),
    ("Scoring",           ["scores calculated", "architecture completed",
                           "contextualization completed", "consolidation completed",
                           "recommendations completed", "audit completed"]),
    ("Architecture",      ["architecture completed", "contextualization completed",
                           "consolidation completed", "recommendations completed",
                           "audit completed"]),
    ("Contextualization", ["contextualization completed", "consolidation completed",
                           "recommendations completed", "audit completed"]),
    ("Consolidation",     ["consolidation completed", "recommendations completed",
                           "audit completed"]),
    ("Recommendations",   ["recommendations completed", "audit completed"]),
    ("Complete",          ["audit completed"]),
]

_IN_PROGRESS_MARKERS = {"audit started", "processing files"}

# Platform-appropriate step symbols
if sys.platform == "win32":
    _SYM_DONE = "[+]"
    _SYM_ACTIVE = "[>]"
    _SYM_PENDING = "[ ]"
else:
    _SYM_DONE = "[green]✓[/green]"
    _SYM_ACTIVE = "[yellow]●[/yellow]"
    _SYM_PENDING = "[dim]○[/dim]"


def _elapsed_str(iso_str: str | None) -> str:
    """Human-readable elapsed time since an ISO timestamp."""
    if not iso_str:
        return "—"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        total = int(delta.total_seconds())
        if total < 60:
            return f"{total}s ago"
        if total < 3600:
            return f"{total // 60}m ago"
        h, m = divmod(total // 60, 60)
        return f"{h}h {m}m ago"
    except Exception:
        return iso_str[:16] if len(iso_str) >= 16 else iso_str


def _fetch_audit_by_uuid(
    cfg: ConfigManager,
    audit_uuid: str,
) -> Audit | GroupAudit | None:
    """Scan LIST_AUDITS pages until the audit with matching UUID is found."""
    with CodeDDClient(config=cfg) as client:
        for offset in range(0, 500, 50):
            try:
                resp = client.get(
                    Endpoints.LIST_AUDITS,
                    params={"offset": offset, "limit": 50},
                )
            except Exception:
                return None
            if resp.status_code != 200:
                return None
            data = resp.json()
            if data.get("status") != "success":
                return None

            for a in data.get("audits_data", []):
                if a.get("audit_uuid") == audit_uuid:
                    return Audit(
                        audit_uuid=a["audit_uuid"],
                        audit_name=a.get("audit_name", ""),
                        audit_status=a.get("audit_status", ""),
                        audit_type=a.get("audit_type", "single"),
                        ai_synthesis=a.get("ai_synthesis"),
                        repo_url=a.get("repo_url", ""),
                        number_files=a.get("number_files", 0),
                        lines_of_code=a.get("lines_of_code", 0),
                    )

            for g in data.get("group_audits_data", []):
                if g.get("audit_uuid") == audit_uuid:
                    return GroupAudit(
                        audit_uuid=g["audit_uuid"],
                        audit_name=g.get("audit_name", ""),
                        audit_status=g.get("audit_status", ""),
                        audit_type=g.get("audit_type", "group"),
                        ai_synthesis=g.get("ai_synthesis"),
                        number_of_sub_audits=g.get("number_of_sub_audits", 0),
                        number_files=g.get("number_files", 0),
                        lines_of_code=g.get("lines_of_code", 0),
                    )

            # Stop if this was the last page
            total = data.get("total_audits", 0)
            if offset + 50 >= total:
                break

    return None


def _render_status_panel(
    audit: Audit | GroupAudit | None,
    audit_uuid: str,
    audit_name: str,
    audit_type: str,
    checkpoint: "AuditCheckpoint",
) -> None:
    """Render a comprehensive audit status panel to the console."""
    server_status = (audit.audit_status if audit else "").strip()
    lower_status = server_status.lower()

    # ---- Server status line -------------------------------------------------
    if "completed" in lower_status and "file" not in lower_status:
        status_markup = f"[bold green]{server_status}[/bold green]"
    elif lower_status in _IN_PROGRESS_MARKERS or "processing" in lower_status:
        status_markup = f"[bold yellow]{server_status or 'Running (local)'}[/bold yellow]"
    elif "error" in lower_status or "failed" in lower_status:
        status_markup = f"[bold red]{server_status}[/bold red]"
    elif "cancelled" in lower_status or "expired" in lower_status:
        status_markup = f"[dim]{server_status}[/dim]"
    elif server_status:
        status_markup = f"[yellow]{server_status}[/yellow]"
    else:
        status_markup = "[dim]Unknown[/dim]"

    # ---- Pipeline visualization ---------------------------------------------
    pipeline_lines: list[str] = []
    terminal_done = "audit completed" in lower_status
    is_failed = "failed" in lower_status or "error" in lower_status or "cancelled" in lower_status

    if not is_failed:
        for label, done_statuses in _AUDIT_PIPELINE:
            is_done = any(s in lower_status for s in done_statuses)
            # "In progress" = current status string contains this step's keyword
            step_key = label.lower().replace(" ", "")
            is_current = (
                not is_done
                and not terminal_done
                and any(step_key in lower_status for step_key in [label.lower(), step_key])
            ) or (
                label == "File auditing"
                and lower_status in _IN_PROGRESS_MARKERS
            )

            if is_done:
                pipeline_lines.append(f"  {_SYM_DONE}  {label}")
            elif is_current:
                pipeline_lines.append(f"  {_SYM_ACTIVE}  [bold]{label}[/bold]  ← in progress")
            else:
                pipeline_lines.append(f"  {_SYM_PENDING}  [dim]{label}[/dim]")

    # ---- Checkpoint (local) section -----------------------------------------
    checkpoint_lines: list[str] = []
    if checkpoint.has_progress():
        n_submitted = checkpoint.total_submitted_files()
        created = checkpoint.created_at() or ""
        data = checkpoint._data
        updated = data.get("updated_at", "")

        checkpoint_lines.append("")
        checkpoint_lines.append("[bold]Local checkpoint[/bold] (audit was interrupted):")
        checkpoint_lines.append(f"  Files submitted : [bold]{n_submitted}[/bold]")
        if created:
            checkpoint_lines.append(f"  Started         : {created[:19].replace('T', ' ')}  ({_elapsed_str(created)})")
        if updated and updated != created:
            checkpoint_lines.append(f"  Last update     : {updated[:19].replace('T', ' ')}  ({_elapsed_str(updated)})")

        # Per-sub-audit breakdown
        sub_audits = data.get("sub_audits", {})
        if len(sub_audits) > 1:
            for sub_uuid, sub_data in sub_audits.items():
                n = len(sub_data.get("submitted_file_paths", []))
                short_uuid = sub_uuid[:8]
                checkpoint_lines.append(f"    [{short_uuid}…] {n} files")

        checkpoint_lines.append("")
        checkpoint_lines.append("  Run [bold cyan]codedd audit start[/bold cyan] to resume.")

    # ---- Assemble panel content ---------------------------------------------
    type_label = "Group Audit" if audit_type == "group" else "Single Audit"
    lines = [
        f"[bold]Audit[/bold]  : {audit_name or audit_uuid}",
        f"[bold]Type[/bold]   : {type_label}",
        f"[bold]UUID[/bold]   : {audit_uuid}",
        f"[bold]Status[/bold] : {status_markup}",
    ]

    if audit:
        # Prefer the plan file count (stored in checkpoint) over the total-scoped
        # count from LIST_AUDITS — they differ because the server only selects
        # LLM-auditable files for the audit plan.
        plan_count = checkpoint.get_plan_file_count()
        scoped_count = audit.number_files or 0
        if plan_count:
            lines.append(f"[bold]Files in plan[/bold] : {plan_count:,}")
            if scoped_count and scoped_count != plan_count:
                lines.append(f"[bold]Scoped total[/bold]  : {scoped_count:,}")
        elif scoped_count:
            lines.append(f"[bold]Scoped files[/bold]  : {scoped_count:,}")
        if audit.lines_of_code:
            lines.append(f"[bold]LoC[/bold]           : {audit.lines_of_code:,}")
        # Only show a completion timestamp when the audit has actually completed.
        is_terminal = "audit completed" in lower_status
        if audit.ai_synthesis and is_terminal:
            lines.append(f"[bold]Completed[/bold]     : {audit.ai_synthesis[:16].replace('T', ' ')}")

    if pipeline_lines:
        lines.append("")
        lines.append("[bold]Pipeline[/bold]:")
        lines.extend(pipeline_lines)

    lines.extend(checkpoint_lines)

    console.print(Panel("\n".join(lines), title="Audit Status", expand=False))


@audit_app.command("status")
@require_auth
def status_audit(
    audit_uuid_arg: str | None = typer.Argument(
        None,
        metavar="AUDIT_UUID",
        help="UUID of the audit to check. Defaults to the active audit.",
    ),
    watch: bool = typer.Option(
        False,
        "--watch",
        "-w",
        help="Poll the server every N seconds until the audit completes.",
    ),
    interval: int = typer.Option(
        20,
        "--interval",
        "-i",
        help="Polling interval in seconds (used with --watch).",
    ),
) -> None:
    """
    Show the current status of an audit.

    Displays the server-side processing stage, local checkpoint progress
    (if the previous run was interrupted), and the full pipeline overview.

    Examples:

        codedd audit status                  # active audit\n
        codedd audit status <uuid>           # specific audit\n
        codedd audit status --watch          # live-refresh every 20s\n
        codedd audit status --watch -i 10   # refresh every 10s
    """
    cfg = ConfigManager()

    audit_uuid = audit_uuid_arg or cfg.active_audit_uuid
    if not audit_uuid:
        print_error("No active audit.  Run [bold cyan]codedd audits select[/bold cyan] first.")
        raise typer.Exit(code=1)

    audit_name = cfg.active_audit_name if not audit_uuid_arg else ""
    audit_type = cfg.active_audit_type if not audit_uuid_arg else "single"

    config_dir = Path.home() / ".codedd"
    checkpoint = AuditCheckpoint(audit_uuid=audit_uuid, config_dir=config_dir)

    terminal_statuses = {"audit completed", "audit failed", "cancelled", "expired", "deleted"}

    def _refresh() -> bool:
        """Fetch and render status. Returns True if a terminal state was reached."""
        audit = _fetch_audit_by_uuid(cfg, audit_uuid)

        # Fill name/type from server response if available
        resolved_name = (audit.audit_name if audit else None) or audit_name or audit_uuid
        resolved_type = (audit.audit_type if audit else None) or audit_type or "single"

        _render_status_panel(audit, audit_uuid, resolved_name, resolved_type, checkpoint)

        if audit and audit.audit_status.lower() in terminal_statuses:
            return True
        return False

    if not watch:
        _refresh()
        return

    # --watch mode: live-refresh until terminal state
    console.print(f"[dim]Watching audit status (every {interval}s) — press Ctrl+C to stop[/dim]\n")
    try:
        while True:
            done = _refresh()
            if done:
                print_success("Audit has reached a terminal state.")
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped watching.[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _review_summary_once(
    payload: dict,
    *,
    command_label: str,
    context_note: str,
    confirm_prompt: str,
) -> bool:
    """
    Write/open a single summary file and ask for one confirmation.

    Used by production-safe ``--show`` mode to avoid per-request prompts.
    """
    filepath = write_payload_file(
        payload,
        command_label=command_label,
        context_note=context_note,
    )
    console.print(f"\n[bold]Summary written to:[/bold] {filepath}\n")
    console.print(f"[dim]Review the file above.  {context_note}[/dim]")
    open_file(filepath)
    console.print()
    return Confirm.ask(confirm_prompt, default=True)


def _resolve_active_providers(cfg: ConfigManager) -> list[str]:
    """
    Return the ordered list of providers that will be used for this audit,
    applying the same preference + fallback logic as ``_check_llm_keys``.

    The first entry is the primary provider; the second (if present) is the
    automatic fallback.  Returns an empty list when no keys are configured.
    """
    preference = cfg.llm_provider
    configured = LLMKeyManager.get_configured_providers()
    if not configured:
        return []
    if preference == "both":
        return configured
    if preference in configured:
        # preferred provider first, others as fallback
        return [preference] + [p for p in configured if p != preference]
    # Preference key not stored — fall back to whatever is available
    return configured


def _resolve_llm_model_string(cfg: ConfigManager) -> str:
    """
    Build the ``llm_model_used`` string from currently configured providers.

    Returns the primary model name, with the fallback appended when a second
    provider is available (comma-separated, primary first).  Examples::

        "claude-sonnet-4-6"
        "claude-sonnet-4-6, gpt-5.2"
    """
    active = _resolve_active_providers(cfg)
    if not active:
        return ""
    return ", ".join(PROVIDER_MODELS.get(p, p) for p in active)


def _check_llm_keys(cfg: ConfigManager) -> bool:
    """
    Verify that at least one LLM API key is configured and matches the
    provider preference.

    Displays which provider(s) will be used.  Returns ``False`` if no
    usable key is found.
    """
    preference = cfg.llm_provider
    configured = LLMKeyManager.get_configured_providers()

    if not configured:
        print_error(
            "No LLM API keys configured.\n"
            "  CodeDD uses LLMs (Anthropic, OpenAI, Gemini, or Grok) to run the source code audit.\n"
            "  Add an API key with [bold cyan]codedd config set-key[/bold cyan]."
        )
        return False

    # Determine which providers will actually be used
    if preference == "both":
        active = configured  # use whatever is available
    elif preference in configured:
        active = [preference]
    else:
        # Preference set to a provider without a key — fall back to what's available
        active = configured
        console.print(
            f"  [yellow]{SYMBOL_WARN}[/yellow] Preferred provider "
            f"[bold]{preference}[/bold] has no key stored.  "
            f"Falling back to: {', '.join(active)}"
        )

    # Display summary
    primary = active[0]
    fallback = active[1] if len(active) > 1 else None
    model_primary = PROVIDER_MODELS.get(primary, "")
    info_parts = [f"[bold]{primary}[/bold] [dim]({model_primary})[/dim]"]
    if fallback:
        model_fallback = PROVIDER_MODELS.get(fallback, "")
        info_parts.append(f"fallback: [bold]{fallback}[/bold] [dim]({model_fallback})[/dim]")

    console.print(f"  [green]{SYMBOL_OK}[/green] LLM provider(s): {' | '.join(info_parts)}")
    return True


def _auto_sync(cfg: ConfigManager, auto_confirm: bool = False, show: bool = False) -> bool:
    """
    Run an automatic scope sync.  If changes are detected, prompt to
    re-confirm.

    Returns True if sync is OK (no changes or changes were re-confirmed).
    """
    # Import sync internals from scope_cmd
    from codedd_cli.commands.scope_cmd import (
        _compute_diff,
        _run_reconfirm,
    )
    from codedd_cli.scanner.file_walker import scan_repository

    dirs = cfg.scope_directories
    if not dirs:
        print_warning("No directories in scope. Run [bold cyan]codedd scope add[/bold cyan] first.")
        return False

    audit_uuid = cfg.active_audit_uuid

    console.print("[dim]Phase 1 — Syncing scope with CodeDD…[/dim]\n")

    if show:
        confirmed = review_request(
            "GET",
            Endpoints.SCOPE_FILES,
            params={"audit_uuid": audit_uuid},
            command_label="Audit Start — Sync Scope",
            context_note=(
                "This request fetches the registered scope from CodeDD to detect "
                "local changes. Only the audit UUID is sent."
            ),
            confirm_prompt="Proceed with this request to CodeDD?",
        )
        if not confirmed:
            print_info("Cancelled.")
            return False

    # Fetch remote state
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Fetching remote scope…", total=None)
        with CodeDDClient(config=cfg) as client:
            resp = client.get(Endpoints.SCOPE_FILES, params={"audit_uuid": audit_uuid})

    if resp.status_code != 200:
        print_warning("Could not fetch remote scope. Skipping sync.")
        return True  # Non-fatal — let pre-flight catch issues

    body = resp.json()
    if body.get("status") != "success":
        print_warning("Remote scope fetch returned non-success. Skipping sync.")
        return True

    remote_sub_audits = body.get("sub_audits", [])
    remote_by_name: dict[str, list[dict]] = {}
    for sa in remote_sub_audits:
        remote_by_name[sa.get("repo_name", "")] = sa.get("files", [])

    # Warn if server has repos the local config doesn't know about.
    # These repos will appear in AUDIT_PLAN but have no local path → their
    # files silently fail during auditing.
    local_repo_names = {e.get("repo_name", Path(e["path"]).name) for e in dirs}
    server_only_repos = {name for name in remote_by_name if name and name not in local_repo_names}
    if server_only_repos:
        console.print()
        for name in sorted(server_only_repos):
            n = len(remote_by_name[name])
            console.print(
                f"  [bold yellow]{SYMBOL_WARN}[/bold yellow] [bold]{name}[/bold]  "
                f"registered on server ({n} files) but not in local scope config"
            )
        print_info(
            "  Run [bold cyan]codedd scope add <path>[/bold cyan] for each missing "
            "repo, then re-confirm scope before starting the audit."
        )
        console.print()

    # Scan local and compute diffs
    has_changes = False
    for entry in dirs:
        repo_path = entry["path"]
        repo_name = entry.get("repo_name", Path(repo_path).name)

        result = scan_repository(repo_path)

        local_files = {
            f.relative_path: {
                "lines_of_code": f.lines_of_code,
                "lines_of_doc": f.lines_of_doc,
            }
            for f in result.files
        }

        remote_files = {}
        for rf in remote_by_name.get(repo_name, []):
            remote_files[rf["relative_path"]] = {
                "lines_of_code": rf.get("lines_of_code", 0),
                "lines_of_doc": rf.get("lines_of_doc", 0),
            }

        diff = _compute_diff(local_files, remote_files)
        if diff["added"] or diff["removed"] or diff["changed"]:
            has_changes = True
            total_changes = len(diff["added"]) + len(diff["removed"]) + len(diff["changed"])
            console.print(
                f"  [bold yellow]{SYMBOL_WARN}[/bold yellow] [bold]{repo_name}[/bold]  "
                f"{total_changes} change(s) detected"
            )
        else:
            console.print(f"  [bold green]{SYMBOL_OK}[/bold green] [bold]{repo_name}[/bold]  in sync")

    if has_changes:
        console.print()
        print_warning("Local files have changed since last registration.")
        if auto_confirm or Confirm.ask("Re-confirm scope now?", default=True):
            reconfirm_ok = _run_reconfirm(cfg, show=show)
            if not reconfirm_ok:
                print_error("Scope re-registration failed.  Cannot start audit.")
                return False
            return True
        else:
            return False

    return True


# Status strings that mean the server is running post-processing steps
# (scoring, architecture, etc.) — re-starting local file audit here is wrong.
_POST_PROCESSING_KEYWORDS: tuple[str, ...] = (
    "file auditing completed",
    "scores calculated",
    "architecture completed",
    "contextualization completed",
    "consolidation completed",
    "recommendations completed",
)


def _check_audit_state_before_start(cfg: ConfigManager, audit_uuid: str) -> bool:
    """
    Fetch the current server-side audit status and warn if re-starting the
    local file audit would be harmful (audit already completed or server is
    in post-processing).

    Returns False if the user chose to abort, True to proceed.
    """
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as _prog:
        _prog.add_task("Checking audit state…", total=None)
        audit = _fetch_audit_by_uuid(cfg, audit_uuid)

    if audit is None:
        # Can't determine state — let the pre-flight endpoint handle it.
        return True

    status = audit.audit_status.strip()
    lower = status.lower()

    # ---- Server is in post-processing (after AUDIT_COMPLETE was called) -----
    if any(kw in lower for kw in _POST_PROCESSING_KEYWORDS):
        console.print(
            Panel(
                f"[bold]Current status[/bold]: [bold yellow]{status}[/bold yellow]\n\n"
                "The server is currently running post-processing steps (scoring,\n"
                "architecture, recommendations, etc.).\n\n"
                "Restarting the local file audit at this point is not needed and\n"
                "may cause duplicate result submissions.\n\n"
                "  • To watch progress: [bold cyan]codedd audit status --watch[/bold cyan]\n"
                "  • Results appear at [bold cyan]codedd.ai[/bold cyan] when complete.",
                title="[bold yellow]Audit is already in post-processing[/bold yellow]",
                expand=False,
            )
        )
        return Confirm.ask("Restart local file audit anyway?", default=False, console=console)

    # ---- Audit fully completed -----------------------------------------------
    if "audit completed" in lower:
        console.print(
            Panel(
                f"[bold]Current status[/bold]: [bold green]{status}[/bold green]\n\n"
                "This audit is already complete.\n"
                "Restarting would create duplicate results and waste LLM credits.\n\n"
                "  • View results at [bold cyan]codedd.ai[/bold cyan]\n"
                "  • To start a new audit, run [bold cyan]codedd audits select[/bold cyan].",
                title="[bold yellow]Audit already completed[/bold yellow]",
                expand=False,
            )
        )
        return Confirm.ask("Restart this audit anyway?", default=False, console=console)

    # ---- Terminal failure --------------------------------------------------------
    if any(kw in lower for kw in ("failed", "error", "cancelled", "expired", "deleted")):
        print_warning(f"Previous audit ended with status: [bold]{status}[/bold]  — proceeding with restart.")
        return True

    # ---- "Group audit started" / "Audit started" / empty -----------------------
    # This is the normal resume case: local file auditing was interrupted.
    # Checkpoint detection later in _run_local_audit will handle the resume prompt.
    return True


def _fetch_preflight(client: CodeDDClient, audit_uuid: str) -> dict | None:
    """
    Call the pre-flight endpoint and return the parsed response dict.
    Returns None on network/auth failure (error is already printed).
    """
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Running pre-flight checks…", total=None)
        resp = client.get(
            Endpoints.AUDIT_CAN_START,
            params={"audit_uuid": audit_uuid},
        )

    if resp.status_code == 401:
        print_error("Authentication failed.  Run [bold cyan]codedd auth login[/bold cyan].")
        return None

    try:
        return resp.json()
    except Exception:
        print_error("Invalid response from server.")
        return None


def _render_preflight(preflight: dict) -> None:
    """Display a summary table from the pre-flight check.

    Handles partial responses when the backend blocks early (e.g. not all
    repos scoped) and omits total_lines_of_code, is_paid, loc_budget, etc.
    """
    table = Table(title="Pre-flight Summary", show_header=True, padding=(0, 1))
    table.add_column("Item", style="bold")
    table.add_column("Value", justify="right")

    total_loc = preflight.get("total_lines_of_code")
    if total_loc is not None:
        table.add_row("Scope LoC", f"{total_loc:,}")
    table.add_row("Repositories", str(len(preflight.get("sub_audits", []))))

    is_paid = preflight.get("is_paid")
    if is_paid is not None:
        table.add_row(
            "Payment",
            "[green]Paid[/green]" if is_paid else "[yellow]Unpaid[/yellow]",
        )
        if is_paid and preflight.get("lines_purchased", 0) > 0:
            table.add_row("Lines purchased", f"{preflight['lines_purchased']:,}")

    loc_delta = preflight.get("loc_delta", 0)
    if loc_delta is not None and loc_delta > 0:
        table.add_row("Scope delta", f"[yellow]+{loc_delta:,}[/yellow]")

    loc_budget = preflight.get("loc_budget")
    if loc_budget is not None:
        table.add_row("LoC budget", f"{loc_budget:,}")

    table.add_row(
        "Status",
        "[green]Ready[/green]" if preflight.get("can_start") else "[red]Blocked[/red]",
    )

    console.print(table)


def _handle_checkout(
    cfg: ConfigManager,
    audit_uuid: str,
    lines_of_code: int,
    show: bool = False,
) -> bool:
    """
    Create a Stripe checkout session, open in the browser, and poll
    until payment is confirmed.

    Returns True if payment was confirmed, False otherwise.
    """
    console.print()

    checkout_payload = {"audit_uuid": audit_uuid, "lines_of_code": lines_of_code}
    if show:
        confirmed = review_payload(
            checkout_payload,
            command_label="Audit Checkout",
            context_note="This payload requests a payment checkout session for the given audit and line count.",
            confirm_prompt="Proceed with creating the payment session on CodeDD?",
        )
        if not confirmed:
            print_info("Cancelled.")
            return False

    # Create checkout session
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Creating payment session…", total=None)
        with CodeDDClient(config=cfg) as client:
            resp = client.post(
                Endpoints.AUDIT_CHECKOUT,
                json=checkout_payload,
            )

    if resp.status_code != 200:
        msg = "Failed to create checkout session"
        try:
            msg = resp.json().get("message", msg)
        except Exception:
            pass
        print_error(msg)
        return False

    body = resp.json()
    checkout_url = body.get("checkout_url", "")
    if not checkout_url:
        print_error("No checkout URL received from server.")
        return False

    # Open browser
    print_info(f"Opening payment page…\n  [link={checkout_url}]{checkout_url}[/link]\n")
    if not _is_safe_checkout_url(checkout_url):
        print_error(
            "Checkout URL rejected: expected an HTTPS URL on a trusted domain "
            "(codedd.ai or stripe.com).  Aborting for security."
        )
        return False
    try:
        webbrowser.open(checkout_url)
    except Exception:
        print_warning("Could not open browser automatically. Please visit the URL above.")

    # Poll for payment confirmation
    console.print("[dim]Waiting for payment confirmation…  (Ctrl+C to cancel)[/dim]\n")

    poll_interval = max(1, int(cfg.get("audit", "payment_poll_interval_seconds", 5)))
    max_wait = max(
        poll_interval,
        int(cfg.get("audit", "payment_poll_max_wait_seconds", 600)),
    )
    elapsed = 0

    try:
        with CodeDDClient(config=cfg) as poll_client, Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Waiting for payment…", total=None)

            while elapsed < max_wait:
                time.sleep(poll_interval)
                elapsed += poll_interval

                poll_resp = poll_client.get(
                    Endpoints.AUDIT_PAYMENT_STATUS,
                    params={"audit_uuid": audit_uuid},
                )

                if poll_resp.status_code == 200:
                    poll_body = poll_resp.json()
                    if poll_body.get("is_paid"):
                        print_success("Payment confirmed!")
                        return True

                progress.update(task, description=f"Waiting for payment… ({elapsed}s)")

    except KeyboardInterrupt:
        console.print()
        print_warning("Payment polling cancelled.")
        print_info("You can complete payment at [bold cyan]codedd.ai[/bold cyan] and retry.")
        return False

    print_warning(
        "Payment was not confirmed within the timeout.\n"
        "  Complete payment at [bold cyan]codedd.ai[/bold cyan] and run this command again."
    )
    return False


# ---------------------------------------------------------------------------
# LLM model tracking
# ---------------------------------------------------------------------------


def _submit_llm_model_used(
    cfg: ConfigManager,
    audit_uuid: str,
    llm_model_used: str,
) -> None:
    """
    POST the resolved LLM model string to CodeDD so it can be stored on
    the ``group_audit`` entity for reporting and analytics.

    Failures are non-fatal — a warning is logged and the audit flow
    continues normally.
    """
    try:
        with CodeDDClient(config=cfg) as client:
            resp = client.post(
                Endpoints.AUDIT_LLM_MODEL,
                json={"audit_uuid": audit_uuid, "llm_model_used": llm_model_used},
            )
        if resp.status_code != 200:
            logger.warning(
                "Failed to record LLM model used (HTTP %s): %s",
                resp.status_code,
                resp.text[:200],
            )
        else:
            logger.debug("LLM model recorded: %s", llm_model_used)
    except Exception as exc:
        logger.warning("Could not submit LLM model info: %s", exc)


# ---------------------------------------------------------------------------
# Concurrency pre-flight warning
# ---------------------------------------------------------------------------


def _check_concurrency_warning(total_files: int, max_concurrent: int) -> bool:
    """
    Warn the user when audit time estimates are risky given current concurrency.

    Returns False if the user chooses to abort, True to proceed.
    """
    if total_files == 0:
        return True

    est_min_h = total_files * FILE_AUDIT_SECONDS_MIN / max_concurrent / 3600
    est_max_h = total_files * FILE_AUDIT_SECONDS_MAX / max_concurrent / 3600

    needs_warn = total_files > FILE_COUNT_CONCURRENCY_WARN and max_concurrent < MIN_RECOMMENDED_CONCURRENCY
    will_timeout = est_max_h > SERVER_FILE_AUDIT_SOFT_TIMEOUT_H

    if not needs_warn and not will_timeout:
        return True

    if will_timeout:
        severity_label = "[bold red]CRITICAL[/bold red]"
        severity_note = (
            f"Estimated maximum time ([bold]{est_max_h:.1f}h[/bold]) "
            f"exceeds the server's {SERVER_FILE_AUDIT_SOFT_TIMEOUT_H:.0f}h limit — "
            "the audit job [bold red]may be killed before it completes[/bold red]."
        )
    else:
        severity_label = "[bold yellow]WARNING[/bold yellow]"
        severity_note = (
            f"Estimated time: [bold]{est_min_h:.1f}h – {est_max_h:.1f}h[/bold]. "
            "Consider increasing concurrency to finish faster."
        )

    # Calculate the concurrency needed to finish within ~75% of the server soft limit
    target_h = SERVER_FILE_AUDIT_SOFT_TIMEOUT_H * 0.75
    needed_c = int(total_files * FILE_AUDIT_SECONDS_MAX / (target_h * 3600)) + 1
    needed_c = max(needed_c, MIN_RECOMMENDED_CONCURRENCY)

    lines = [
        f"{severity_label}  Audit time estimate",
        "",
        f"  Files to audit  : [bold]{total_files:,}[/bold]",
        f"  Concurrency     : [bold]{max_concurrent}[/bold] parallel LLM workers",
        f"  Estimated time  : [bold]{est_min_h:.1f}h – {est_max_h:.1f}h[/bold]  "
        f"(@ {FILE_AUDIT_SECONDS_MIN}–{FILE_AUDIT_SECONDS_MAX}s per file)",
        f"  Server limit    : {SERVER_FILE_AUDIT_SOFT_TIMEOUT_H:.0f}h (soft)",
        "",
        severity_note,
        "",
        f"  To increase concurrency: [bold]codedd config set-concurrency {needed_c}[/bold]",
    ]
    console.print(Panel("\n".join(lines), expand=False))

    default_yes = not will_timeout
    return Confirm.ask(
        "Continue with current concurrency?",
        default=default_yes,
        console=console,
    )


# ---------------------------------------------------------------------------
# Local audit execution
# ---------------------------------------------------------------------------


def _run_local_audit(
    cfg: ConfigManager,
    audit_uuid: str,
    show: bool = False,
    show_force_interactive: bool = False,
    debug_llm: bool = False,
    debug_llm_full_prompt: bool = False,
    scope_loc: int = 0,
    yes: bool = False,
) -> None:
    """
    Execute the full local audit flow:
        1. Fetch the audit plan from CodeDD (file list + system prompt).
        2. Audit each file locally via LLM (with concurrency + progress bar).
        3. Submit results in batches to CodeDD.
        4. Signal completion (triggers post-processing Steps 7-9).
    """
    console.print()

    # ---- Step 1: Fetch audit plan ----------------------------------------
    console.print("[bold]Fetching audit plan from CodeDD…[/bold]\n")

    if show:
        confirmed = review_request(
            "GET",
            Endpoints.AUDIT_PLAN,
            params={"audit_uuid": audit_uuid},
            command_label="Audit Plan",
            context_note=(
                "This request fetches the audit execution plan (file list, "
                "system prompt, config) from CodeDD.  Only the audit UUID is sent."
            ),
            confirm_prompt="Proceed with fetching the audit plan?",
        )
        if not confirmed:
            print_info("Cancelled.")
            raise typer.Exit(code=0)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Downloading plan…", total=None)
        with CodeDDClient(config=cfg) as client:
            resp = client.get(
                Endpoints.AUDIT_PLAN,
                params={"audit_uuid": audit_uuid},
            )

    if resp.status_code != 200:
        msg = "Failed to fetch audit plan"
        try:
            msg = resp.json().get("message", msg)
        except Exception:
            pass
        print_error(msg)
        raise typer.Exit(code=1)

    plan = resp.json()
    if plan.get("status") != "success":
        print_error(plan.get("message", "Unexpected response from server"))
        raise typer.Exit(code=1)

    system_prompt = plan.get("prompts", {}).get("file_audit", "")
    vulnerability_validation_prompt = plan.get("prompts", {}).get("vulnerability_validation", "")
    if not system_prompt:
        print_error("Server returned an empty system prompt.  Cannot audit.")
        raise typer.Exit(code=1)

    sub_audits = plan.get("sub_audits", [])
    plan_config = plan.get("config", {})
    architecture_config = plan_config.get("architecture", {}) if isinstance(plan_config, dict) else {}
    if not isinstance(architecture_config, dict):
        architecture_config = {}
    batch_size = plan_config.get("batch_size", 10)
    server_max = plan_config.get("max_concurrent", 8)
    max_concurrent = min(cfg.llm_concurrency, server_max)
    del plan

    # Build scope_dirs + repo_files_by_sub directly from sub_audits,
    # avoiding a redundant flat `all_files` list.
    scope_dirs: dict[str, str] = {}
    repo_files_by_sub: dict[str, list[dict]] = {}
    total_loc = 0
    total_file_count = 0

    local_dirs = cfg.scope_directories
    dir_by_name = {e.get("repo_name", ""): e.get("path", "") for e in local_dirs}

    for sa in sub_audits:
        repo_name = sa.get("repo_name", "")
        local_path = dir_by_name.get(repo_name, "")
        scope_dirs[repo_name] = local_path
        sub_uuid = sa["audit_uuid"]
        sub_files: list[dict] = []

        for f in sa.get("files", []):
            f["repo_name"] = repo_name
            f["sub_audit_uuid"] = sub_uuid
            sub_files.append(f)
            total_loc += f.get("lines_of_code", 0)

        repo_files_by_sub[sub_uuid] = sub_files
        total_file_count += len(sub_files)

    if not total_file_count:
        print_warning("No files to audit.  Check your scope selection.")
        raise typer.Exit(code=0)

    # ---- Plan validation: repos with no local path -------------------------
    # Files from repos with an empty local path will fail during auditing
    # (Path("").read_text() throws).  Catch this before any LLM calls happen.
    no_path_repos: list[tuple[str, int]] = []
    for sa in sub_audits:
        rname = sa.get("repo_name", "")
        suuid = sa.get("audit_uuid", "")
        n = len(repo_files_by_sub.get(suuid, []))
        if n > 0 and not scope_dirs.get(rname, ""):
            no_path_repos.append((rname, n))

    if no_path_repos:
        skipped = sum(n for _, n in no_path_repos)
        auditable = total_file_count - skipped
        lines = [
            "The server audit plan references repositories that have no local path\n"
            "in your CLI scope configuration.\n",
            "Files from these repositories [bold]cannot be read or audited[/bold]:\n",
        ]
        for rname, n in no_path_repos:
            lines.append(f"  [bold]{rname}[/bold]  ({n:,} files)")
        lines.append(
            "\n[bold]Fix:[/bold] run [bold cyan]codedd scope add <path>[/bold cyan] for each "
            "missing repository,\nthen re-run [bold cyan]codedd scope confirm[/bold cyan] "
            "and retry [bold cyan]codedd audit start[/bold cyan]."
        )
        console.print(
            Panel(
                "\n".join(lines),
                title="[bold red]Repositories missing local paths[/bold red]",
                expand=False,
            )
        )
        if auditable == 0:
            print_error(
                "No files can be audited — every repository in the plan is missing a "
                "local path.  Add the repo paths and re-confirm scope before retrying."
            )
            raise typer.Exit(code=1)

        if not yes and not Confirm.ask(
            f"Continue with only [bold]{auditable:,}[/bold] of {total_file_count:,} "
            f"auditable files (skipping {skipped:,})?",
            default=False,
            console=console,
        ):
            raise typer.Exit(code=0)

    # ---- Concurrency pre-flight warning ------------------------------------
    if not _check_concurrency_warning(total_file_count, max_concurrent):
        print_info("Audit cancelled. Adjust concurrency and retry.")
        raise typer.Exit(code=0)

    # ---- Checkpoint: resume interrupted audit session ----------------------
    config_dir = Path.home() / ".codedd"
    checkpoint = AuditCheckpoint(audit_uuid=audit_uuid, config_dir=config_dir)
    # Persist plan file count immediately so `codedd audit status` can show it.
    checkpoint.set_plan_file_count(total_file_count)
    if checkpoint.has_progress():
        n_done = checkpoint.total_submitted_files()
        since = checkpoint.created_at() or "unknown time"
        console.print(
            Panel(
                f"Incomplete audit found\n\n"
                f"  Files already submitted : [bold]{n_done}[/bold]\n"
                f"  Session started         : {since}\n\n"
                "  Resuming will skip already-submitted files and continue from where the\n"
                "  audit was interrupted.",
                title="[bold yellow]Resume checkpoint detected[/bold yellow]",
                expand=False,
            )
        )
        if not Confirm.ask("Resume from checkpoint?", default=True, console=console):
            checkpoint.clear()
            checkpoint = AuditCheckpoint(audit_uuid=audit_uuid, config_dir=config_dir)

    # Guardrail: interactive transparency can explode on large audits due to
    # per-batch confirmations. Downgrade to summary-style behavior unless forced.
    if show:
        prompt_threshold = 20
        estimated_prompts = 2  # "Audit Plan" + "Audit Complete"
        for sa in sub_audits:
            file_count = len(sa.get("files", []))
            batches = (file_count + batch_size - 1) // batch_size if file_count else 0
            # Results batch + complexity batch prompts
            estimated_prompts += batches * 2
        # Dependency submission prompt is once per sub-audit payload.
        estimated_prompts += len(sub_audits)

        if estimated_prompts > prompt_threshold and not show_force_interactive:
            print_warning(
                f"Interactive transparency would require about "
                f"[bold]{estimated_prompts}[/bold] confirmations.\n"
                "  Downgrading to safe summary mode for this run."
            )
            summary_payload = {
                "command": "codedd audit start",
                "audit_uuid": audit_uuid,
                "transparency_mode": "auto-downgraded-to-summary",
                "reason": {
                    "estimated_confirmations": estimated_prompts,
                    "threshold": prompt_threshold,
                },
                "audit_plan": {
                    "sub_audits": len(sub_audits),
                    "files": total_file_count,
                    "batch_size": batch_size,
                },
            }
            if not _review_summary_once(
                summary_payload,
                command_label="Audit Start --show Downgrade",
                context_note=(
                    "Interactive per-request review was downgraded to protect runtime performance on a large audit."
                ),
                confirm_prompt="Proceed with summary mode for this run?",
            ):
                print_info("Cancelled.")
                raise typer.Exit(code=0)
            show = False

    # Retrieve LLM API keys now (keyring can be slow on Windows; do it before "Auditing files…")
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task("Retrieving API keys…", total=None)
        anthropic_key = LLMKeyManager.retrieve_key("anthropic")
        openai_key = LLMKeyManager.retrieve_key("openai")
        gemini_key = LLMKeyManager.retrieve_key("gemini")
        grok_key = LLMKeyManager.retrieve_key("grok")

    # Display summary with per-repo breakdown
    console.print(f"  Repositories  : [bold]{len(sub_audits)}[/bold]")
    for sa in sub_audits:
        rname = sa.get("repo_name", "?")
        suuid = sa.get("audit_uuid", "")
        n = len(repo_files_by_sub.get(suuid, []))
        local_ok = bool(scope_dirs.get(rname, ""))
        status_tag = "" if local_ok else "  [bold red]⚠ no local path[/bold red]"
        console.print(f"    {rname}: [bold]{n:,}[/bold] files{status_tag}")
    console.print(f"  Files to audit: [bold]{total_file_count:,}[/bold]")
    scope_label = f" (of {scope_loc:,} scoped)" if scope_loc and scope_loc != total_loc else ""
    console.print(f"  Auditable LoC : [bold]{total_loc:,}[/bold]{scope_label}")
    console.print(f"  Concurrency   : [bold]{max_concurrent}[/bold] parallel LLM calls\n")

    # ---- Step 2: Repo-level local execution with repo concurrency ---------
    from codedd_cli.auditor.architecture_analyzer import run_architecture_analysis
    from codedd_cli.auditor.git_stats_collector import collect_git_statistics

    preference = cfg.llm_provider
    start_time = time.monotonic()

    repo_server_max = int(
        plan_config.get("repo_max_concurrent")
        or plan_config.get("max_repo_concurrent")
        or plan_config.get("sub_audit_concurrency")
        or 1
    )
    repo_concurrency = max(1, min(repo_server_max, len(sub_audits)))
    if show and repo_concurrency > 1:
        print_warning(
            "Interactive review mode is incompatible with parallel repo workers. "
            "Using single-repo execution for this run."
        )
        repo_concurrency = 1
    llm_workers_per_repo = max(1, max_concurrent // repo_concurrency)

    console.print(
        f"  Repo concurrency: [bold]{repo_concurrency}[/bold] | "
    )

    # Fetch dependency config once and reuse in each repo worker
    dep_config: dict = {}
    try:
        with CodeDDClient(config=cfg) as client:
            dep_cfg_resp = client.get(Endpoints.AUDIT_DEPENDENCY_CONFIG)
        if dep_cfg_resp.status_code == 200:
            dep_cfg_body = dep_cfg_resp.json()
            if dep_cfg_body.get("status") == "success":
                dep_config = dep_cfg_body.get("config", {})
        elif dep_cfg_resp.status_code == 404:
            pass
    except Exception:
        pass

    provider_stats: dict[str, int] = {}
    successful_results: list[AuditFileResult] = []
    failed_files: list[AuditFileResult] = []
    cx_ok: list[FileComplexityResult] = []
    manifest_ok: list[ManifestResult] = []
    import_results: list[ImportResult] = []
    total_dep_pkgs = 0
    total_import_pkgs = 0
    vuln_found = 0
    arch_submitted = 0
    arch_components_total = 0
    arch_relationships_total = 0

    def _collect_all_repo_files(local_dir: str, sub_uuid: str, repo_name: str) -> list[str]:
        paths: list[str] = []
        skip_dirs = {
            "node_modules", ".git", "__pycache__", ".venv", "venv", "env",
            ".env", "vendor", "bower_components", "dist", "build", "target",
            ".next", ".nuxt", ".svelte-kit", ".angular", "coverage",
            ".pytest_cache", ".tox", ".gradle", ".idea", ".vscode", ".vs",
        }
        for root, dirs, files in os.walk(local_dir):
            dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".")]
            for fname in files:
                full_path = os.path.join(root, fname)
                rel = os.path.relpath(full_path, local_dir).replace("\\", "/")
                paths.append(f"cli://{sub_uuid}/{repo_name}/{rel}")
        return paths

    retry_policy = SubmissionRetryPolicy(
        attempts=max(1, int(cfg.get("audit", "submission_retry_attempts", 3))),
        base_delay_seconds=max(
            0.1,
            float(cfg.get("audit", "submission_retry_base_delay_seconds", 1.0)),
        ),
        max_delay_seconds=max(
            0.1,
            float(cfg.get("audit", "submission_retry_max_delay_seconds", 8.0)),
        ),
    )

    runner_context = SubAuditRunnerContext(
        cfg=cfg,
        scope_dirs=scope_dirs,
        repo_files_by_sub=repo_files_by_sub,
        batch_size=batch_size,
        llm_workers_per_repo=llm_workers_per_repo,
        system_prompt=system_prompt,
        preference=preference,
        anthropic_key=anthropic_key,
        openai_key=openai_key,
        gemini_key=gemini_key,
        grok_key=grok_key,
        vulnerability_validation_prompt=vulnerability_validation_prompt,
        architecture_config=architecture_config,
        dep_config=dep_config,
        submission_retry_policy=retry_policy,
        collect_all_repo_files=_collect_all_repo_files,
        run_architecture_analysis=run_architecture_analysis,
        collect_git_statistics=collect_git_statistics,
        checkpoint=checkpoint,
    )

    # -- Executor block: launch repo workers with live progress display ----

    console.print("[bold]Running repo pipelines…[/bold]\n")
    repo_progress = MultiRepoProgress(sub_audits)
    merge_lock = threading.Lock()

    with Live(repo_progress, console=console, refresh_per_second=4):
        with ThreadPoolExecutor(max_workers=repo_concurrency) as pool:
            futures = {
                pool.submit(
                    run_sub_audit,
                    sa=sa,
                    progress=repo_progress,
                    context=runner_context,
                ): sa
                for sa in sub_audits
            }
            for future in as_completed(futures):
                sa = futures[future]
                sa_name = sa.get("repo_name", "")
                sa_uuid = sa.get("audit_uuid", "")
                try:
                    repo_out = future.result(timeout=REPO_PIPELINE_TIMEOUT_SECONDS)
                except TimeoutError:
                    repo_progress.mark_error(sa_uuid, "Pipeline timed out")
                    logger.error("%s: repo pipeline timed out", sa_name)
                    continue
                except Exception as exc:
                    repo_progress.mark_error(sa_uuid, str(exc))
                    logger.error("%s: repo pipeline failed: %s", sa_name, exc)
                    continue

                with merge_lock:
                    successful_results.extend(repo_out["success_results"])
                    failed_files.extend(repo_out["failed_results"])
                    cx_ok.extend(repo_out["cx_ok"])
                    manifest_ok.extend(repo_out["manifest_ok"])
                    import_results.extend(repo_out["import_results"])
                    total_dep_pkgs += int(repo_out["dep_pkg_count"])
                    total_import_pkgs += int(repo_out["dep_import_count"])
                    vuln_found += int(repo_out["vuln_found"])
                    arch_submitted += int(repo_out["arch_submitted"])
                    arch_components_total += int(repo_out["arch_components"])
                    arch_relationships_total += int(repo_out["arch_relationships"])
                    for p, c in repo_out["provider_stats"].items():
                        provider_stats[p] = provider_stats.get(p, 0) + c

    elapsed = time.monotonic() - start_time
    console.print()
    if failed_files:
        print_warning(f"{len(failed_files)} file(s) could not be audited.")
    if not successful_results:
        print_error("No files were successfully audited. Nothing to submit.")
        raise typer.Exit(code=1)

    # ---- Step 4: Signal completion ---------------------------------------
    console.print("[bold]Triggering post-processing on CodeDD…[/bold]\n")

    complete_payload = {
        "audit_uuid": audit_uuid,
        "trigger_next_steps": True,
        # Final summary so server has definitive counts even if any batch
        # progress updates were missed (e.g. transient network errors).
        "files_submitted": len(successful_results),
        "files_failed": len(failed_files),
        "total_plan_files": total_file_count,
    }
    if show:
        confirmed = review_payload(
            complete_payload,
            command_label="Audit Complete",
            context_note=(
                "This tells CodeDD that file-level auditing is done and to "
                "trigger consolidation / recommendations (Steps 7-9)."
            ),
            confirm_prompt="Proceed with audit completion?",
        )
        if not confirmed:
            print_info("Cancelled.")
            raise typer.Exit(code=0)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as prog:
        prog.add_task("Finalising…", total=None)
        with CodeDDClient(config=cfg) as client:
            resp = client.post(Endpoints.AUDIT_COMPLETE, json=complete_payload)

    if resp.status_code != 200:
        msg = "Failed to signal audit completion"
        try:
            msg = resp.json().get("message", msg)
        except Exception:
            pass
        print_error(msg)
        raise typer.Exit(code=1)

    complete_body = resp.json()
    if complete_body.get("status") != "success":
        print_error(complete_body.get("message", "Unknown error during completion"))
        raise typer.Exit(code=1)

    # Audit completed successfully — remove the checkpoint so a fresh run starts clean.
    checkpoint.clear()

    # ---- Final summary ---------------------------------------------------
    console.print()
    minutes, seconds = divmod(int(elapsed), 60)
    time_str = f"{minutes}m {seconds}s" if minutes else f"{seconds}s"

    print_success("[bold]Audit complete![/bold]")
    console.print(f"    Files audited: [bold]{len(successful_results)}[/bold]")
    if cx_ok:
        console.print(f"    Complexity analysed: [bold]{len(cx_ok)}[/bold] files")
    if arch_submitted:
        console.print(
            f"    Architecture: [bold]{arch_components_total}[/bold] components, "
            f"[bold]{arch_relationships_total}[/bold] relationships"
        )
    if manifest_ok or import_results:
        console.print(
            f"    Dependencies: [bold]{total_dep_pkgs}[/bold] packages, [bold]{total_import_pkgs}[/bold] imports"
        )
        if vuln_found:
            console.print(f"    Vulnerabilities: [bold yellow]{vuln_found}[/bold yellow] packages affected")
    console.print(f"    Time: [bold]{time_str}[/bold]")

    if provider_stats:
        provider_parts = []
        for p, count in sorted(provider_stats.items()):
            model_name = PROVIDER_MODELS.get(p, p)
            provider_parts.append(f"{p.capitalize()} / {model_name} ({count} files)")
        console.print(f"    Model(s) used: {' | '.join(provider_parts)}")

    if complete_body.get("post_processing_triggered"):
        console.print(
            "    [dim]Post-processing (dependency enrichment, consolidation "
            "& recommendations) is running on CodeDD.[/dim]"
        )

    console.print()
    print_info("Track results at [bold cyan]codedd.ai[/bold cyan] or run [bold cyan]codedd audits list[/bold cyan].")
