"""
Per-audit session tracker for the fix workflow.

Persists a lightweight JSON file at ``~/.codedd/fix_session.json`` that
records which files have already been resolved or invalidated during the
current remediation session.  This lets the CLI detect when a newly-queued
flag targets code that was already modified by an earlier fix in the same
session — a strong indicator that the flag is stale.

The tracker is **audit-scoped**: data for audit A is independent of
audit B, so switching audits does not produce false warnings.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _session_path() -> Path:
    """Return ``~/.codedd/fix_session.json``."""
    return Path.home() / ".codedd" / "fix_session.json"


class FixSessionTracker:
    """Track files that have been resolved/invalidated in the current session."""

    def __init__(self, audit_uuid: str) -> None:
        self._audit_uuid = audit_uuid
        self._path = _session_path()
        self._data: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(self._data, indent=2), encoding="utf-8")

    def _audit_data(self) -> dict[str, Any]:
        return self._data.setdefault(self._audit_uuid, {"resolved_files": {}})

    def record_resolved(self, file_path: str, issue_uuid: str) -> None:
        """Record that a flag on *file_path* was resolved."""
        audit = self._audit_data()
        resolved: dict[str, list[dict[str, str]]] = audit.setdefault("resolved_files", {})
        resolved.setdefault(file_path, []).append({
            "issue_uuid": issue_uuid,
            "action": "resolved",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        self._save()

    def record_invalidated(self, file_path: str, issue_uuid: str) -> None:
        """Record that a flag on *file_path* was invalidated."""
        audit = self._audit_data()
        resolved: dict[str, list[dict[str, str]]] = audit.setdefault("resolved_files", {})
        resolved.setdefault(file_path, []).append({
            "issue_uuid": issue_uuid,
            "action": "invalidated",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        self._save()

    def get_prior_actions(self, file_path: str) -> list[dict[str, str]]:
        """Return list of prior resolve/invalidate actions for *file_path* in this audit."""
        audit = self._audit_data()
        return audit.get("resolved_files", {}).get(file_path, [])

    def has_prior_fixes(self, file_path: str) -> bool:
        """Return ``True`` if any flag on *file_path* was already resolved in this session."""
        return any(
            a["action"] == "resolved"
            for a in self.get_prior_actions(file_path)
        )

    def prior_fix_count(self, file_path: str) -> int:
        """Return how many flags on *file_path* have been resolved this session."""
        return sum(
            1 for a in self.get_prior_actions(file_path)
            if a["action"] == "resolved"
        )

    def clear_audit(self) -> None:
        """Remove all tracked data for the current audit (e.g. on session reset)."""
        self._data.pop(self._audit_uuid, None)
        self._save()
