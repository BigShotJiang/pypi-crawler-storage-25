"""
Application-wide constants for the CodeDD CLI.
"""

# Application identity
APP_NAME = "codedd-cli"
CONFIG_DIR_NAME = ".codedd"

# Default API endpoint (production)
DEFAULT_API_URL = "https://api.codedd.ai/django_codedd"

# Keyring service name used to store the CLI token in the OS credential store
KEYRING_SERVICE = "codedd-cli"
KEYRING_TOKEN_KEY = "cli_token"

# CLI token prefix expected by the server
CLI_TOKEN_PREFIX = "codedd_cli_"

# HTTP client settings
REQUEST_TIMEOUT_SECONDS = 60
MAX_RETRIES = 3
USER_AGENT_PREFIX = "codedd-cli"

# Auth: how long (seconds) a successful server-side token verification is
# considered fresh before the next command triggers a re-check.
TOKEN_VERIFY_CACHE_TTL_SECONDS = 300  # 5 minutes

# Audit checkpoint / fail-safe batching
AUDIT_CHECKPOINT_BATCH_SIZE = 25  # submit every N files or vuln validations

# Concurrency warning thresholds (for audit start pre-flight)
FILE_COUNT_CONCURRENCY_WARN = 500      # warn when file count exceeds this
MIN_RECOMMENDED_CONCURRENCY = 8        # minimum recommended concurrent LLM workers
FILE_AUDIT_SECONDS_MIN = 20            # optimistic seconds per file (1 LLM call)
FILE_AUDIT_SECONDS_MAX = 30            # pessimistic seconds per file
SERVER_FILE_AUDIT_SOFT_TIMEOUT_H = 33.0  # server Celery soft limit for file audit step
SERVER_FILE_AUDIT_HARD_TIMEOUT_H = 35.0  # server Celery hard limit for file audit step
