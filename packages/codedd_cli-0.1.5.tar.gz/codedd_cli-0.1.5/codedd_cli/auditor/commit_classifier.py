"""
Commit classifier for Innovation Rate KPI — CLI-local port.

Classifies git commits into categories:
  - new_feature: New functionality being added
  - bug_fix:     Fixing defects
  - refactoring: Code improvement without changing behaviour
  - maintenance: Updates, dependencies, config changes
  - unplanned:   Hotfixes, emergency fixes

Uses keyword-based classification for performance (O(n) per commit).
Supports conventional-commits format and fallback patterns.

Ported from the server-side module so the CLI can classify locally without
requiring the Django codebase on ``sys.path``.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

logger = logging.getLogger(__name__)


class CommitClassifier:
    """
    Classify commits using keyword matching and file-change patterns.

    Strategy:
      1. Primary  — commit-message keywords (fast, accurate for well-formatted commits)
      2. Secondary — file-change patterns (config, test, doc files)
      3. Tertiary  — addition / deletion ratio heuristics
    """

    NEW_FEATURE_KEYWORDS = [
        r"\bfeat\b", r"\bfeature\b", r"\badd\b", r"\badding\b", r"\badded\b",
        r"\bimplement\b", r"\bnew\b", r"\bcreate\b", r"\bintroduce\b",
        r"\benhance\b", r"\bextend\b", r"\binitial\b", r"\bsupport\b",
        r"\benable\b", r"\ballow\b", r"\blabel\b",
    ]

    BUG_FIX_KEYWORDS = [
        r"\bfix\b", r"\bfixing\b", r"\bfixed\b", r"\bbug\b", r"\bissue\b",
        r"\berror\b", r"\bbugfix\b", r"\bresolve\b", r"\bcorrect\b",
        r"\bpatch\b", r"\brepair\b", r"\bworkaround\b",
        r"\bfixes\s*#", r"\bresolves\s*#", r"\bcloses\s*#", r"\bproperly\b",
    ]

    REFACTORING_KEYWORDS = [
        r"\brefactor\b", r"\brefactoring\b", r"\bcleanup\b", r"\bimprove\b",
        r"\boptimize\b", r"\brestructure\b", r"\breorganize\b", r"\bsimplify\b",
        r"\bpolish\b", r"\bmodernize\b", r"\brevise\b", r"\brename\b",
        r"\brenaming\b", r"\bmove\b", r"\bmoving\b",
        r"\bremove\s+duplicat", r"\bdeduplicat",
    ]

    MAINTENANCE_KEYWORDS = [
        r"\bupdate\b", r"\bupgrade\b", r"\bbump\b", r"\bdeps\b",
        r"\bdependencies\b", r"\bconfig\b", r"\bchore\b", r"\bmaintenance\b",
        r"\bdoc\b", r"\bdocs\b", r"\bdocumentation\b", r"\bci\b", r"\bcd\b",
        r"\bworkflow\b", r"\bformat\b", r"\blint\b", r"\bstyle\b",
        r"\brelease\b", r"\bversion\b", r"\brevert\b", r"\bmerge\b",
    ]

    UNPLANNED_KEYWORDS = [
        r"\bhotfix\b", r"\bemergency\b", r"\burgent\b", r"\bcritical\b",
        r"\bquick\s*fix\b", r"\bemergency\s*fix\b", r"\bhot\s*fix\b",
    ]

    CONFIG_FILE_PATTERNS = [
        r"package\.json$", r"requirements\.txt$", r"yarn\.lock$",
        r"package-lock\.json$", r"pom\.xml$", r"build\.gradle$",
        r"\.gitignore$", r"\.env", r"dockerfile", r"docker-compose",
        r"\.yml$", r"\.yaml$", r"Makefile", r"\.config\.",
        r"tsconfig\.json$", r"webpack\.config\.", r"\.eslintrc",
        r"\.prettierrc",
    ]

    TEST_FILE_PATTERNS = [
        r"\.test\.", r"\.spec\.", r"__test__", r"__tests__", r"/test/",
        r"/tests/", r"\.test\.js$", r"\.test\.ts$", r"\.spec\.js$",
        r"\.spec\.ts$",
    ]

    DOC_FILE_PATTERNS = [
        r"\.md$", r"\.rst$", r"\.txt$", r"README", r"CHANGELOG",
        r"LICENSE", r"\.adoc$", r"/docs/", r"/documentation/",
    ]

    # Pre-compiled at class level so all instances share the same objects
    # and no recompilation occurs per classify_commit_history() call.
    _new_feature_rx = [re.compile(p, re.IGNORECASE) for p in NEW_FEATURE_KEYWORDS]
    _bug_fix_rx = [re.compile(p, re.IGNORECASE) for p in BUG_FIX_KEYWORDS]
    _refactoring_rx = [re.compile(p, re.IGNORECASE) for p in REFACTORING_KEYWORDS]
    _maintenance_rx = [re.compile(p, re.IGNORECASE) for p in MAINTENANCE_KEYWORDS]
    _unplanned_rx = [re.compile(p, re.IGNORECASE) for p in UNPLANNED_KEYWORDS]
    _config_file_rx = [re.compile(p, re.IGNORECASE) for p in CONFIG_FILE_PATTERNS]
    _test_file_rx = [re.compile(p, re.IGNORECASE) for p in TEST_FILE_PATTERNS]
    _doc_file_rx = [re.compile(p, re.IGNORECASE) for p in DOC_FILE_PATTERNS]

    # ------------------------------------------------------------------
    # Single-commit classification
    # ------------------------------------------------------------------

    def classify_commit(self, commit: dict[str, Any]) -> dict[str, Any]:
        """Return ``{type, confidence, method, keywords_matched}`` for *commit*."""
        message = commit.get("message", "") or ""
        file_changes = commit.get("file_changes", []) or []
        is_merge = commit.get("is_merge", False)

        message_lower = message.lower()

        total_added = sum(f.get("added", 0) or 0 for f in file_changes)
        total_deleted = sum(f.get("deleted", 0) or 0 for f in file_changes)
        total_changes = total_added + total_deleted

        matched_keywords: list[str] = []

        # --- Revert detection (highest priority) ---
        if message_lower.startswith("revert ") or message_lower.startswith('revert"'):
            return {"type": "maintenance", "confidence": 0.95,
                    "method": "revert_detection", "keywords_matched": ["revert"]}

        # --- Extract PR title from merge commits ---
        if is_merge or message_lower.startswith("merge "):
            pr_match = re.search(r"\(#\d+\)", message)
            if pr_match:
                pr_title = message[:pr_match.start()].strip()
                if pr_title:
                    message_lower = pr_title.lower()
            elif "\n\n" in message:
                lines = message.split("\n\n")
                if len(lines) > 1:
                    potential_title = lines[1].strip()
                    if potential_title and len(potential_title) < 200:
                        message_lower = potential_title.lower()

        # --- Unplanned (high priority) ---
        for rx in self._unplanned_rx:
            if rx.search(message_lower):
                matched_keywords.append(rx.pattern)
                return {"type": "unplanned", "confidence": 0.9,
                        "method": "message_keywords", "keywords_matched": matched_keywords}

        # --- Conventional commits (feat:, fix:, refactor:, chore:, …) ---
        cc_match = re.match(r"^(\w+)(\(.+\))?:\s*(.+)$", message_lower)
        if cc_match:
            prefix = cc_match.group(1)
            if prefix in ("feat", "feature"):
                return {"type": "new_feature", "confidence": 0.95,
                        "method": "conventional_commits", "keywords_matched": [prefix]}
            if prefix in ("fix", "bugfix"):
                return {"type": "bug_fix", "confidence": 0.95,
                        "method": "conventional_commits", "keywords_matched": [prefix]}
            if prefix in ("refactor", "refactoring"):
                return {"type": "refactoring", "confidence": 0.95,
                        "method": "conventional_commits", "keywords_matched": [prefix]}
            if prefix in ("chore", "maintenance", "docs", "ci", "cd"):
                return {"type": "maintenance", "confidence": 0.9,
                        "method": "conventional_commits", "keywords_matched": [prefix]}

        # --- Bug-fix keywords ---
        for rx in self._bug_fix_rx:
            if rx.search(message_lower):
                matched_keywords.append(rx.pattern)
                confidence = 0.9 if any(p in (r"\bfixing\b", r"\bworkaround\b") for p in matched_keywords) else 0.85
                return {"type": "bug_fix", "confidence": confidence,
                        "method": "message_keywords", "keywords_matched": matched_keywords}

        # --- Refactoring keywords ---
        for rx in self._refactoring_rx:
            if rx.search(message_lower):
                matched_keywords.append(rx.pattern)
                return {"type": "refactoring", "confidence": 0.8,
                        "method": "message_keywords", "keywords_matched": matched_keywords}

        # --- New-feature keywords (but not workarounds) ---
        is_workaround = "workaround" in message_lower
        for rx in self._new_feature_rx:
            if rx.search(message_lower):
                if is_workaround:
                    return {"type": "bug_fix", "confidence": 0.85,
                            "method": "message_keywords", "keywords_matched": ["workaround"]}
                matched_keywords.append(rx.pattern)
                return {"type": "new_feature", "confidence": 0.8,
                        "method": "message_keywords", "keywords_matched": matched_keywords}

        # --- Release / version patterns ---
        release_patterns = [
            r"\brelease\s+", r"\brelease\s+notes", r"\brelease\s+chart",
            r"\brelease\s+carvel", r"\brelease\s+candidate",
            r"\bversion\s+\d+", r"\bv\d+\.\d+", r"\brc\d+",
        ]
        if any(re.search(p, message_lower) for p in release_patterns):
            return {"type": "maintenance", "confidence": 0.9,
                    "method": "message_keywords", "keywords_matched": ["release/version"]}

        # --- Maintenance keywords ---
        for rx in self._maintenance_rx:
            if rx.search(message_lower):
                matched_keywords.append(rx.pattern)
                return {"type": "maintenance", "confidence": 0.75,
                        "method": "message_keywords", "keywords_matched": matched_keywords}

        # === Secondary: file-change patterns ===
        if file_changes:
            config_files = test_files = doc_files = new_files = 0
            for fc in file_changes:
                fname = fc.get("filename", "") or ""
                added = fc.get("added", 0) or 0
                deleted = fc.get("deleted", 0) or 0
                if any(rx.search(fname) for rx in self._config_file_rx):
                    config_files += 1
                if any(rx.search(fname) for rx in self._test_file_rx):
                    test_files += 1
                if any(rx.search(fname) for rx in self._doc_file_rx):
                    doc_files += 1
                if added > 0 and deleted == 0:
                    new_files += 1

            n = len(file_changes)
            if config_files and config_files >= n * 0.5:
                return {"type": "maintenance", "confidence": 0.7,
                        "method": "file_patterns", "keywords_matched": []}
            if test_files and test_files >= n * 0.5:
                tp = "bug_fix" if any(rx.search(message_lower) for rx in self._bug_fix_rx) else "new_feature"
                return {"type": tp, "confidence": 0.65,
                        "method": "file_patterns", "keywords_matched": []}
            if doc_files and doc_files >= n * 0.5:
                return {"type": "maintenance", "confidence": 0.7,
                        "method": "file_patterns", "keywords_matched": []}
            if new_files and new_files >= n * 0.4:
                return {"type": "new_feature", "confidence": 0.6,
                        "method": "file_patterns", "keywords_matched": []}
            if config_files:
                feature_indicators = ("add", "adding", "allow", "label", "enable", "support", "new")
                if any(ind in message_lower for ind in feature_indicators):
                    return {"type": "new_feature", "confidence": 0.7,
                            "method": "file_patterns", "keywords_matched": []}

        # === Tertiary: change-ratio heuristics ===
        if total_added > 0:
            if total_deleted / total_added > 0.7:
                return {"type": "refactoring", "confidence": 0.6,
                        "method": "change_ratio", "keywords_matched": []}
            if total_changes < 50:
                return {"type": "bug_fix", "confidence": 0.5,
                        "method": "change_ratio", "keywords_matched": []}

        # === Default fallback ===
        if is_merge or message_lower.startswith("merge "):
            return {"type": "maintenance", "confidence": 0.7,
                    "method": "merge_commit_fallback", "keywords_matched": []}

        return {"type": "maintenance", "confidence": 0.4,
                "method": "default", "keywords_matched": []}

    # ------------------------------------------------------------------
    # Batch classification
    # ------------------------------------------------------------------

    def classify_commits(self, commits: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Classify a list of commit dicts, adding a ``classification`` key to each."""
        for commit in commits:
            try:
                commit["classification"] = self.classify_commit(commit)
            except Exception as exc:
                logger.warning("Error classifying commit %s: %s",
                               commit.get("hash", "unknown"), exc)
                commit["classification"] = {
                    "type": "maintenance", "confidence": 0.0,
                    "method": "error_fallback", "keywords_matched": [],
                }
        return commits


# ----------------------------------------------------------------------
# Public entry-point (mirrors server's classify_commit_history)
# ----------------------------------------------------------------------

def classify_commit_history(
    commit_history: dict[str, Any],
    time_window_years: int = 2,
) -> dict[str, Any]:
    """
    Classify all commits in *commit_history* and add a
    ``classification_summary`` section.

    Only commits within the last *time_window_years* are classified; older
    commits are kept but receive no ``classification`` key.
    """
    if not commit_history or not isinstance(commit_history, dict):
        return commit_history

    commits = commit_history.get("commits", [])
    if not commits:
        return commit_history

    cutoff = datetime.now(timezone.utc) - timedelta(days=time_window_years * 365)

    recent: list[dict[str, Any]] = []
    for commit in commits:
        raw_date = commit.get("date")
        if not raw_date:
            recent.append(commit)
            continue
        try:
            dt = datetime.fromisoformat(str(raw_date).replace("Z", "+00:00"))
            if dt >= cutoff:
                recent.append(commit)
        except Exception:
            recent.append(commit)

    if not recent:
        return commit_history

    classifier = CommitClassifier()
    classifier.classify_commits(recent)

    hash_to_cls = {c.get("hash"): c.get("classification") for c in recent if c.get("hash")}
    for commit in commits:
        h = commit.get("hash")
        if h and h in hash_to_cls:
            commit["classification"] = hash_to_cls[h]

    counts: dict[str, int] = {
        "new_feature": 0, "bug_fix": 0, "refactoring": 0,
        "maintenance": 0, "unplanned": 0,
    }
    for c in recent:
        ctype = c.get("classification", {}).get("type", "maintenance")
        if ctype in counts:
            counts[ctype] += 1

    total = sum(counts.values())

    commit_history["commits"] = commits
    commit_history["classification_summary"] = {
        "total_classified": total,
        "time_window_years": time_window_years,
        "by_type": counts,
        "percentages": {
            k: round((v / total * 100) if total > 0 else 0, 1)
            for k, v in counts.items()
        },
    }
    return commit_history
