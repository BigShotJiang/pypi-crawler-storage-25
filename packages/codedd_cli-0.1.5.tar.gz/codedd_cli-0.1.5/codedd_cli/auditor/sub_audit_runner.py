"""
Sub-audit execution helpers for local audit pipelines.

This module keeps repo worker logic out of ``audit_cmd`` and centralises
submission reliability/validation concerns.
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from codedd_cli.api.client import CodeDDClient
from codedd_cli.api.endpoints import Endpoints
from codedd_cli.auditor.audit_checkpoint import AuditCheckpoint
from codedd_cli.auditor.complexity_analyzer import (
    LocalComplexityAnalyzer,
    aggregate_complexity_results,
)
from codedd_cli.auditor.dependency_scanner import (
    LocalDependencyScanner,
)
from codedd_cli.auditor.file_auditor import AuditFileResult, LocalFileAuditor
from codedd_cli.auditor.vulnerability_validator import (
    LocalVulnerabilityValidator,
    ValidationCandidate,
    ValidationOutcome,
)
from codedd_cli.config.constants import AUDIT_CHECKPOINT_BATCH_SIZE
from codedd_cli.config.settings import ConfigManager
from codedd_cli.utils.display import RepoStage

if TYPE_CHECKING:
    from codedd_cli.utils.display import MultiRepoProgress


logger = logging.getLogger(__name__)


class SubmissionError(RuntimeError):
    """Raised when a submission stage cannot be completed reliably."""


@dataclass(frozen=True)
class SubmissionRetryPolicy:
    """Retry policy for transient submission failures."""

    attempts: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 8.0


@dataclass(frozen=True)
class SubAuditRunnerContext:
    """Immutable context for a single repo worker execution."""

    cfg: ConfigManager
    scope_dirs: dict[str, str]
    repo_files_by_sub: dict[str, list[dict]]
    batch_size: int
    llm_workers_per_repo: int
    system_prompt: str
    preference: str
    anthropic_key: str | None = field(repr=False)
    openai_key: str | None = field(repr=False)
    gemini_key: str | None = field(repr=False)
    grok_key: str | None = field(repr=False)
    vulnerability_validation_prompt: str | None
    architecture_config: dict[str, Any]
    dep_config: dict
    submission_retry_policy: SubmissionRetryPolicy
    collect_all_repo_files: Callable[[str, str, str], list[str]]
    run_architecture_analysis: Callable[..., tuple[dict, dict]]
    collect_git_statistics: Callable[..., dict]
    checkpoint: AuditCheckpoint | None = None


def _extract_response_message(response: Any, fallback: str) -> str:
    try:
        body = response.json()
    except Exception:
        return fallback
    if isinstance(body, dict):
        for key in ("message", "error", "detail"):
            value = body.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return fallback


def _is_transient_status(status_code: int) -> bool:
    return status_code in {408, 425, 429} or 500 <= status_code <= 599


def _post_with_retry(
    *,
    client: CodeDDClient,
    endpoint: str,
    payload: dict,
    stage_name: str,
    timeout: int | None,
    retry_policy: SubmissionRetryPolicy,
    require_success_status: bool = False,
) -> dict:
    """POST with retries and response validation."""
    attempts = max(1, int(retry_policy.attempts))
    base_delay = max(0.1, float(retry_policy.base_delay_seconds))
    max_delay = max(base_delay, float(retry_policy.max_delay_seconds))
    last_error: str = f"{stage_name}: unknown failure"

    for attempt in range(1, attempts + 1):
        try:
            kwargs: dict[str, Any] = {"json": payload}
            if timeout is not None:
                kwargs["timeout"] = timeout
            resp = client.post(endpoint, **kwargs)
        except Exception as exc:
            last_error = f"{stage_name}: {exc}"
            if attempt < attempts:
                delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
                time.sleep(delay)
                continue
            raise SubmissionError(last_error) from exc

        if resp.status_code != 200:
            last_error = _extract_response_message(
                resp,
                f"{stage_name}: HTTP {resp.status_code}",
            )
            if _is_transient_status(resp.status_code) and attempt < attempts:
                delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
                time.sleep(delay)
                continue
            raise SubmissionError(last_error)

        try:
            body = resp.json()
        except Exception as exc:
            raise SubmissionError(f"{stage_name}: invalid JSON response") from exc

        if not isinstance(body, dict):
            raise SubmissionError(f"{stage_name}: unexpected response payload")

        status = str(body.get("status", "")).strip().lower()
        if require_success_status and status != "success":
            message = str(body.get("message") or body.get("error") or "").strip()
            if not message:
                message = f"{stage_name}: server reported status={status or 'missing'}"
            raise SubmissionError(message)

        return body

    raise SubmissionError(last_error)


def _outcome_to_dict(outcome: ValidationOutcome) -> dict:
    return {
        "file_path": outcome.file_path,
        "conclusion": outcome.conclusion,
        "impact": outcome.impact,
        "confidence": outcome.confidence,
        "recommended_action": outcome.recommended_action,
        "revised_time_to_fix_hours": outcome.revised_time_to_fix_hours,
    }


def submit_vulnerability_validation(
    *,
    sub_uuid: str,
    repo_files: list[dict],
    success_results: list[AuditFileResult],
    local_repo_dir: str,
    anthropic_key: str | None,
    openai_key: str | None,
    gemini_key: str | None,
    grok_key: str | None,
    preference: str,
    vulnerability_validation_prompt: str | None,
    llm_workers_per_repo: int,
    client: CodeDDClient,
    retry_policy: SubmissionRetryPolicy,
    checkpoint: AuditCheckpoint | None = None,
    errors_out: list[str] | None = None,
) -> int:
    """Run local vulnerability validation and submit outcomes in batches of 25."""
    file_to_local_path: dict[str, str] = {}
    if local_repo_dir:
        resolved_repo_dir = Path(local_repo_dir).resolve()
        for file_meta in repo_files:
            rel = file_meta.get("relative_path", "")
            file_path = file_meta.get("file_path", "")
            if not (rel and file_path):
                continue
            candidate_path = (resolved_repo_dir / rel.replace("/", os.sep).replace("\\", os.sep)).resolve()
            # Reject paths that escape the repo directory (e.g. via ../../)
            if resolved_repo_dir not in candidate_path.parents and candidate_path != resolved_repo_dir:
                continue
            file_to_local_path[file_path] = str(candidate_path)

    validation_candidates: list[ValidationCandidate] = []
    for result in success_results:
        audit_data = result.audit_data or {}
        flag_color = str(audit_data.get("flag_color", "")).strip().lower()
        reasons = str(audit_data.get("reasons_of_flag", "")).strip()
        if flag_color not in {"red", "orange"}:
            continue
        if not reasons or reasons.upper() in {"N/A", "NONE"}:
            continue
        local_path = file_to_local_path.get(result.file_path, "")
        if not local_path:
            continue
        revised_time = audit_data.get("time_to_fix_flag")
        try:
            revised_time = float(revised_time) if revised_time is not None else None
        except (TypeError, ValueError):
            revised_time = None
        validation_candidates.append(
            ValidationCandidate(
                file_path=result.file_path,
                local_path=local_path,
                hypothesis=reasons,
                flag_color=flag_color,
                stored_time_to_fix_hours=revised_time,
            )
        )

    # Merge persisted candidates from previous runs with candidates from this run.
    # This ensures red/orange files submitted in an earlier interrupted session
    # are still validated even when the current run's success_results doesn't
    # include them (because they were already file-submitted and skipped).
    if checkpoint:
        persisted_raw = checkpoint.get_vuln_candidates(sub_uuid)
        if persisted_raw:
            current_fps = {c.file_path for c in validation_candidates}
            for raw in persisted_raw:
                fp = raw.get("file_path", "")
                if not fp or fp in current_fps:
                    continue
                local_path = file_to_local_path.get(fp, "")
                if not local_path:
                    continue
                validation_candidates.append(
                    ValidationCandidate(
                        file_path=fp,
                        local_path=local_path,
                        hypothesis=raw.get("hypothesis", ""),
                        flag_color=raw.get("flag_color", ""),
                        stored_time_to_fix_hours=raw.get("stored_time_to_fix_hours"),
                    )
                )

    if not validation_candidates:
        return 0

    # Sort deterministically so resume skip is stable across sessions.
    validation_candidates.sort(key=lambda c: (c.file_path, c.hypothesis[:80]))

    # Persist candidates so they survive an interrupted run and can be merged
    # into a future resume.
    if checkpoint:
        checkpoint.set_vuln_candidates(
            sub_uuid,
            [
                {
                    "file_path": c.file_path,
                    "hypothesis": c.hypothesis,
                    "flag_color": c.flag_color,
                    "stored_time_to_fix_hours": c.stored_time_to_fix_hours,
                }
                for c in validation_candidates
            ],
        )

    # Skip candidates already validated in a previous session (path-based).
    already_validated_paths = checkpoint.get_vuln_validated_paths(sub_uuid) if checkpoint else set()
    if already_validated_paths:
        remaining = [c for c in validation_candidates if c.file_path not in already_validated_paths]
        if not remaining:
            return len(already_validated_paths)
        validation_candidates = remaining

    # Capture total BEFORE trimming — needed for server-side progress display.
    total_validations = len(validation_candidates) + len(already_validated_paths)

    submitted_count = len(already_validated_paths)
    successfully_submitted_paths: set[str] = set()

    def _on_vuln_batch(batch: list[ValidationOutcome]) -> None:
        nonlocal submitted_count
        batch_count = len(batch)
        payload = {
            "audit_uuid": sub_uuid,
            "validations": [_outcome_to_dict(o) for o in batch],
            # Progress context: lets the server track validation completeness.
            "validations_submitted_so_far": submitted_count + batch_count,
            "total_validations": total_validations,
        }
        try:
            _post_with_retry(
                client=client,
                endpoint=Endpoints.AUDIT_VULNERABILITY_VALIDATION,
                payload=payload,
                stage_name="Vulnerability validation submit",
                timeout=120,
                retry_policy=retry_policy,
                require_success_status=True,
            )
            submitted_count += batch_count
            batch_fps = [o.file_path for o in batch]
            successfully_submitted_paths.update(batch_fps)
            if checkpoint:
                checkpoint.mark_vuln_paths_submitted(sub_uuid, batch_fps)
        except Exception as exc:
            msg = f"Vulnerability validation batch submit: {exc}"
            logger.warning(msg)
            if errors_out is not None:
                errors_out.append(msg)

    with LocalVulnerabilityValidator(
        anthropic_key=anthropic_key,
        openai_key=openai_key,
        gemini_key=gemini_key,
        grok_key=grok_key,
        provider_preference=preference,
        system_prompt=vulnerability_validation_prompt or None,
        on_debug=None,
        max_workers=llm_workers_per_repo,
    ) as validator:
        all_outcomes = validator.validate(
            validation_candidates,
            on_batch=_on_vuln_batch,
            batch_size=AUDIT_CHECKPOINT_BATCH_SIZE,
        )

    # Re-submit any outcomes that were computed but whose batch POST failed.
    dropped = [o for o in all_outcomes if o.file_path not in successfully_submitted_paths]
    for i in range(0, len(dropped), AUDIT_CHECKPOINT_BATCH_SIZE):
        chunk = dropped[i : i + AUDIT_CHECKPOINT_BATCH_SIZE]
        batch_count = len(chunk)
        payload = {
            "audit_uuid": sub_uuid,
            "validations": [_outcome_to_dict(o) for o in chunk],
            "validations_submitted_so_far": submitted_count + batch_count,
            "total_validations": total_validations,
        }
        try:
            _post_with_retry(
                client=client,
                endpoint=Endpoints.AUDIT_VULNERABILITY_VALIDATION,
                payload=payload,
                stage_name="Vulnerability validation submit (retry)",
                timeout=120,
                retry_policy=retry_policy,
                require_success_status=True,
            )
            submitted_count += batch_count
            batch_fps = [o.file_path for o in chunk]
            if checkpoint:
                checkpoint.mark_vuln_paths_submitted(sub_uuid, batch_fps)
        except Exception as exc:
            msg = f"Vulnerability validation retry submit: {exc}"
            logger.warning(msg)
            if errors_out is not None:
                errors_out.append(msg)

    return submitted_count


def run_sub_audit(
    *,
    sa: dict,
    progress: MultiRepoProgress,
    context: SubAuditRunnerContext,
) -> dict:
    """Execute local analysis + submissions for one sub-audit repo."""
    sub_uuid = sa.get("audit_uuid", "")
    repo_name = sa.get("repo_name", "")
    repo_files = context.repo_files_by_sub.get(sub_uuid, [])
    local_repo_dir = context.scope_dirs.get(repo_name, "")
    scope_single = {repo_name: local_repo_dir} if repo_name else {}

    out: dict[str, Any] = {
        "repo_name": repo_name,
        "sub_uuid": sub_uuid,
        "success_results": [],
        "failed_results": [],
        "provider_stats": {},
        "cx_ok": [],
        "manifest_ok": [],
        "import_results": [],
        "vuln_found": 0,
        "dep_pkg_count": 0,
        "dep_import_count": 0,
        "arch_components": 0,
        "arch_relationships": 0,
        "arch_submitted": 0,
        "errors": [],
    }

    if not repo_files:
        progress.mark_done(sub_uuid)
        return out

    checkpoint = context.checkpoint

    # Resume: skip files whose results were already submitted in a previous session.
    already_submitted: set[str] = checkpoint.get_submitted_files(sub_uuid) if checkpoint else set()
    is_resuming = bool(already_submitted)
    files_to_audit = [f for f in repo_files if f["file_path"] not in already_submitted]
    if is_resuming:
        progress.log(
            f"{repo_name}: resuming — skipping {len(already_submitted)} already-submitted files"
        )

    progress.set_stage(sub_uuid, RepoStage.AUDITING)

    def _on_file_done(result: AuditFileResult) -> None:
        short = result.relative_path.rsplit("/", 1)[-1] if result.relative_path else ""
        progress.advance_file(sub_uuid, detail=short)

    # Total files in the plan for this sub-audit (used in progress payloads so
    # the server can show "N/M files submitted" without guessing the total).
    total_plan_files = len(repo_files)

    # Open client before auditing so _on_file_batch can submit every 25 results live.
    with CodeDDClient(config=context.cfg) as client:
        submitted_file_count = len(already_submitted)

        def _on_file_batch(batch: list[AuditFileResult]) -> None:
            nonlocal submitted_file_count
            success_batch = [r for r in batch if r.success]
            if not success_batch:
                return
            batch_count = len(success_batch)
            payload = {
                "audit_uuid": sub_uuid,
                "results": [
                    {"file_path": r.file_path, "audit_data": r.audit_data}
                    for r in success_batch
                ],
                # Progress context: lets the server update "N/M files" status display.
                "files_submitted_so_far": submitted_file_count + batch_count,
                "total_plan_files": total_plan_files,
            }
            try:
                _post_with_retry(
                    client=client,
                    endpoint=Endpoints.AUDIT_RESULTS,
                    payload=payload,
                    stage_name="File results submit",
                    timeout=120,
                    retry_policy=context.submission_retry_policy,
                )
                submitted_file_count += batch_count
                progress.set_detail(sub_uuid, f"submitted {submitted_file_count}/{total_plan_files}")
                if checkpoint:
                    checkpoint.mark_files_submitted(
                        sub_uuid, [r.file_path for r in success_batch]
                    )
            except Exception as exc:
                msg = f"File results batch submit: {exc}"
                out["errors"].append(msg)
                progress.add_stage_error(sub_uuid, msg)
                progress.log(f"[!] {repo_name}: {msg}")
                logger.warning("%s: %s", repo_name, msg)

        with LocalFileAuditor(
            anthropic_key=context.anthropic_key,
            openai_key=context.openai_key,
            gemini_key=context.gemini_key,
            grok_key=context.grok_key,
            system_prompt=context.system_prompt,
            provider_preference=context.preference,
            max_concurrent=context.llm_workers_per_repo,
            on_dump_llm=None,
        ) as auditor:
            file_results = auditor.audit_batch(
                files=files_to_audit,
                scope_dirs=context.scope_dirs,
                on_progress=_on_file_done,
                on_batch=_on_file_batch,
                batch_size=AUDIT_CHECKPOINT_BATCH_SIZE,
            )

        success_results = [result for result in file_results if result.success]
        failed_results = [result for result in file_results if not result.success]
        out["success_results"] = success_results
        out["failed_results"] = failed_results
        for result in success_results:
            provider = result.provider_used or "unknown"
            out["provider_stats"][provider] = out["provider_stats"].get(provider, 0) + 1

        progress.log(
            f"{repo_name}: {len(success_results)} files audited"
            + (f", {len(failed_results)} failed" if failed_results else "")
        )

        progress.set_stage(sub_uuid, RepoStage.COMPLEXITY)
        progress.set_detail(sub_uuid, "analyzing...")
        cx_analyzer = LocalComplexityAnalyzer(
            max_workers=min(context.llm_workers_per_repo, os.cpu_count() or 4, 8),
        )
        cx_results = cx_analyzer.analyze_batch(files=repo_files, scope_dirs=context.scope_dirs)
        cx_ok_local = [result for result in cx_results if result.success]
        out["cx_ok"] = cx_ok_local
        progress.log(f"{repo_name}: complexity done ({len(cx_ok_local)} files)")

        progress.set_stage(sub_uuid, RepoStage.DEPENDENCIES)
        progress.set_detail(sub_uuid, "scanning...")
        dep_scanner = LocalDependencyScanner(
            config=context.dep_config,
            on_debug=None,
            max_workers=context.llm_workers_per_repo,
        )
        manifest_local = dep_scanner.scan_manifests(scope_single)
        progress.set_detail(sub_uuid, "imports...")
        import_local = dep_scanner.scan_source_imports(repo_files, context.scope_dirs)
        # Vulnerability scanning is server-side for CLI audits.
        # CLI only extracts source-derived dependency signals (manifests/imports).
        vuln_local: dict[str, dict] = {}
        manifest_ok_local = [manifest for manifest in manifest_local if not manifest.error]
        out["manifest_ok"] = manifest_ok_local
        out["import_results"] = import_local
        out["dep_pkg_count"] = sum(len(manifest.packages) for manifest in manifest_ok_local)
        out["dep_import_count"] = sum(len(result.packages) for result in import_local)
        n_vuln = 0
        out["vuln_found"] = n_vuln
        progress.log(
            f"{repo_name}: {out['dep_pkg_count']} packages, "
            f"{out['dep_import_count']} imports"
            + (f", {n_vuln} vulnerabilities" if n_vuln else "")
        )

        progress.set_stage(sub_uuid, RepoStage.SUBMITTING)

        # File results were submitted incrementally via _on_file_batch during auditing.
        if success_results:
            try:
                progress.set_detail(sub_uuid, "vuln validation...")
                submit_vulnerability_validation(
                    sub_uuid=sub_uuid,
                    repo_files=repo_files,
                    success_results=success_results,
                    local_repo_dir=local_repo_dir,
                    anthropic_key=context.anthropic_key,
                    openai_key=context.openai_key,
                    gemini_key=context.gemini_key,
                    grok_key=context.grok_key,
                    preference=context.preference,
                    vulnerability_validation_prompt=context.vulnerability_validation_prompt,
                    llm_workers_per_repo=context.llm_workers_per_repo,
                    client=client,
                    retry_policy=context.submission_retry_policy,
                    checkpoint=checkpoint,
                    errors_out=out["errors"],
                )
            except Exception as exc:
                msg = f"Vulnerability validation: {exc}"
                out["errors"].append(msg)
                progress.add_stage_error(sub_uuid, msg)
                progress.log(f"[!] {repo_name}: {msg}")
                logger.warning("%s: %s", repo_name, msg)

        if cx_ok_local:
            try:
                progress.set_detail(sub_uuid, "complexity...")
                cx_payload_items = [
                    {"file_path": result.file_path, "metrics": result.metrics}
                    for result in cx_ok_local
                ]
                agg_input = {item["file_path"]: item["metrics"] for item in cx_payload_items}
                summary = aggregate_complexity_results(agg_input)
                for i in range(0, len(cx_payload_items), context.batch_size):
                    chunk = cx_payload_items[i : i + context.batch_size]
                    cx_payload: dict = {"audit_uuid": sub_uuid, "results": chunk}
                    if i + context.batch_size >= len(cx_payload_items):
                        cx_payload["summary"] = summary
                    _post_with_retry(
                        client=client,
                        endpoint=Endpoints.AUDIT_COMPLEXITY,
                        payload=cx_payload,
                        stage_name="Complexity submit",
                        timeout=120,
                        retry_policy=context.submission_retry_policy,
                    )
            except Exception as exc:
                msg = f"Complexity submit: {exc}"
                out["errors"].append(msg)
                progress.add_stage_error(sub_uuid, msg)
                progress.log(f"[!] {repo_name}: {msg}")
                logger.warning("%s: %s", repo_name, msg)

        if manifest_ok_local or import_local:
            try:
                progress.set_detail(sub_uuid, "dependencies...")
                manifest_payload = [
                    {
                        "manifest_path": f"cli://{sub_uuid}/{repo_name}/{manifest.manifest_path}",
                        "registry": manifest.registry,
                        "packages": manifest.packages,
                    }
                    for manifest in manifest_ok_local
                ]
                imports_payload = [
                    {
                        "file_path": result.file_path,
                        "registry_prefix": result.registry_prefix,
                        "packages": result.packages,
                    }
                    for result in import_local
                ]
                dep_payload = {
                    "audit_uuid": sub_uuid,
                    "manifest_packages": manifest_payload,
                    "import_packages": imports_payload,
                    "vulnerabilities": vuln_local,
                }
                _post_with_retry(
                    client=client,
                    endpoint=Endpoints.AUDIT_DEPENDENCIES,
                    payload=dep_payload,
                    stage_name="Dependencies submit",
                    timeout=180,
                    retry_policy=context.submission_retry_policy,
                )
            except Exception as exc:
                msg = f"Dependencies submit: {exc}"
                out["errors"].append(msg)
                progress.add_stage_error(sub_uuid, msg)
                progress.log(f"[!] {repo_name}: {msg}")
                logger.warning("%s: %s", repo_name, msg)

    progress.log(f"{repo_name}: results submitted")

    progress.set_stage(sub_uuid, RepoStage.GIT_STATS)
    if local_repo_dir and os.path.isdir(local_repo_dir):
        try:
            progress.set_detail(sub_uuid, "collecting...")
            stats = context.collect_git_statistics(
                local_repo_dir,
                repository_name=repo_name or None,
                repository_url=None,
                include_derived_stats=False,
                include_classification=False,
            )
            if stats:
                commit_history = stats.get("commit_history", {}) or {}
                commits = commit_history.get("commits", []) if isinstance(commit_history, dict) else []
                n_commits = len(commits)
                progress.set_detail(sub_uuid, f"submitting ({n_commits} commits)...")
                git_payload = {
                    "audit_uuid": sub_uuid,
                    "repository_name": stats.get("repository_name"),
                    "repository_url": stats.get("repository_url"),
                    "commit_history": commit_history,
                    "author_stats": stats.get("author_stats", {}),
                    "merge_stats": stats.get("merge_stats", {}),
                    "branch_stats": stats.get("branch_stats", {}),
                    "meta_info": stats.get("meta_info", {}),
                    # Keep CLI payload lightweight; server derives these from commit_history.
                    "time_based_stats": {},
                    "release_stats": stats.get("release_stats", {}),
                    "code_churn_stats": {},
                    "collaboration_stats": {},
                }
                with CodeDDClient(config=context.cfg) as client:
                    _post_with_retry(
                        client=client,
                        endpoint=Endpoints.AUDIT_GIT_STATISTICS,
                        payload=git_payload,
                        stage_name="Git statistics submit",
                        timeout=300,
                        retry_policy=context.submission_retry_policy,
                        require_success_status=True,
                    )
                    # Best-effort trigger for cloud-side git development analysis.
                    # Older servers may not expose this endpoint yet, so failures
                    # here should not block the rest of the pipeline.
                    try:
                        _post_with_retry(
                            client=client,
                            endpoint=Endpoints.AUDIT_GIT_DEVELOPMENT_ANALYSIS,
                            payload={"audit_uuid": sub_uuid},
                            stage_name="Git development analysis trigger",
                            timeout=120,
                            retry_policy=context.submission_retry_policy,
                            require_success_status=True,
                        )
                    except SubmissionError as analysis_exc:
                        logger.warning(
                            "%s: cloud git development analysis trigger skipped: %s",
                            repo_name,
                            analysis_exc,
                        )
                progress.log(f"{repo_name}: git stats submitted ({n_commits} commits)")
        except Exception as exc:
            msg = f"Git statistics: {exc}"
            out["errors"].append(msg)
            progress.add_stage_error(sub_uuid, msg)
            progress.log(f"[!] {repo_name}: {msg}")
            logger.warning("%s: %s", repo_name, msg)

    progress.set_stage(sub_uuid, RepoStage.ARCHITECTURE)
    try:
        progress.set_detail(sub_uuid, "scanning files...")
        if local_repo_dir and os.path.isdir(local_repo_dir):
            arch_file_paths = context.collect_all_repo_files(local_repo_dir, sub_uuid, repo_name)
        else:
            arch_file_paths = [file_meta["file_path"] for file_meta in repo_files]
        if arch_file_paths:
            progress.set_detail(sub_uuid, "phase 1...")

            def _arch_progress(msg: str) -> None:
                short = msg[:60].rstrip(".")
                progress.set_detail(sub_uuid, short)
                progress.log(f"{repo_name}: {msg}")

            phase1, phase2 = context.run_architecture_analysis(
                sub_uuid,
                repo_name or "repo",
                arch_file_paths,
                scope_dirs=context.scope_dirs,
                detector_config=context.architecture_config,
                on_progress=_arch_progress,
                max_workers=context.llm_workers_per_repo,
            )
            n_comp = len(phase2.get("architectural_components") or {})
            n_rel = len(phase2.get("component_relationships") or [])
            progress.set_detail(sub_uuid, "submitting...")
            arch_payload = {
                "audit_uuid": sub_uuid,
                "phase1_results": phase1,
                "phase2_results": phase2,
            }
            with CodeDDClient(config=context.cfg) as client:
                _post_with_retry(
                    client=client,
                    endpoint=Endpoints.AUDIT_ARCHITECTURE,
                    payload=arch_payload,
                    stage_name="Architecture submit",
                    timeout=180,
                    retry_policy=context.submission_retry_policy,
                )
            out["arch_submitted"] = 1
            out["arch_components"] = n_comp
            out["arch_relationships"] = n_rel

            classification = phase2.get("archetype_classification")
            if classification:
                tier = classification.get("primary_tier", 0)
                tier_name = classification.get("primary_archetype_name", "")
                confidence = classification.get("confidence", 0)
                out["arch_tier"] = tier
                out["arch_tier_name"] = tier_name
                out["arch_confidence"] = confidence
                progress.log(
                    f"{repo_name}: architecture {n_comp} components, {n_rel} relationships "
                    f"→ Tier {tier} ({tier_name}, {confidence:.0f}%)"
                )
            else:
                progress.log(f"{repo_name}: architecture {n_comp} components, {n_rel} relationships")
    except Exception as exc:
        msg = f"Architecture analysis: {exc}"
        out["errors"].append(msg)
        progress.add_stage_error(sub_uuid, msg)
        progress.log(f"[!] {repo_name}: {msg}")
        logger.warning("%s: %s", repo_name, msg)

    progress.mark_done(sub_uuid)
    return out
