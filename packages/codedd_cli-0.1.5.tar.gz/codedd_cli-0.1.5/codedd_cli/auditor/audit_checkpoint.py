"""
Persistent checkpoint for resumable local audit sessions.

State is written to ``~/.codedd/audit_progress_{audit_uuid}.json`` after
every batch submission so an interrupted audit can resume where it left off.
Writes are atomic (write-then-rename) so a crash mid-save never corrupts the
file.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_FORMAT_VERSION = 1
_FILENAME_PREFIX = "audit_progress_"


class AuditCheckpoint:
    """Tracks per-sub-audit submission progress across CLI sessions."""

    def __init__(self, audit_uuid: str, config_dir: Path) -> None:
        self._audit_uuid = audit_uuid
        self._path = config_dir / f"{_FILENAME_PREFIX}{audit_uuid}.json"
        self._data: dict = self._load()

    # ---- Internal persistence -----------------------------------------------

    def _empty(self) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        return {
            "version": _FORMAT_VERSION,
            "audit_uuid": self._audit_uuid,
            "created_at": now,
            "updated_at": now,
            "sub_audits": {},
        }

    def _load(self) -> dict:
        if not self._path.exists():
            return self._empty()
        try:
            with open(self._path, encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or data.get("audit_uuid") != self._audit_uuid:
                logger.warning("Checkpoint mismatch or corrupt — starting fresh.")
                return self._empty()
            return data
        except Exception as exc:
            logger.warning("Cannot read checkpoint (%s) — starting fresh.", exc)
            return self._empty()

    def _save(self) -> None:
        self._data["updated_at"] = datetime.now(timezone.utc).isoformat()
        tmp = self._path.with_suffix(".json.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2)
            os.replace(tmp, self._path)
        except Exception as exc:
            logger.warning("Checkpoint save failed: %s", exc)
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass

    def _sub(self, sub_uuid: str) -> dict:
        subs = self._data.setdefault("sub_audits", {})
        if sub_uuid not in subs:
            subs[sub_uuid] = {"submitted_file_paths": [], "vuln_submitted_count": 0}
        return subs[sub_uuid]

    # ---- File audit phase ---------------------------------------------------

    def get_submitted_files(self, sub_uuid: str) -> set[str]:
        """Return the set of file_path strings already submitted for this sub-audit."""
        return set(self._sub(sub_uuid).get("submitted_file_paths", []))

    def mark_files_submitted(self, sub_uuid: str, file_paths: list[str]) -> None:
        """Append newly submitted file paths and persist immediately."""
        sub = self._sub(sub_uuid)
        existing: set[str] = set(sub.get("submitted_file_paths", []))
        added = False
        for fp in file_paths:
            if fp not in existing:
                sub.setdefault("submitted_file_paths", []).append(fp)
                existing.add(fp)
                added = True
        if added:
            self._save()

    # ---- Vulnerability validation phase ------------------------------------

    def get_vuln_submitted_count(self, sub_uuid: str) -> int:
        """Number of vuln-validation outcomes already submitted for this sub-audit."""
        # Path-based tracking is preferred; fall back to legacy count field.
        paths = self._sub(sub_uuid).get("vuln_validated_paths")
        if paths is not None:
            return len(paths)
        return int(self._sub(sub_uuid).get("vuln_submitted_count", 0))

    def mark_vulns_submitted(self, sub_uuid: str, total_count: int) -> None:
        """Update the total count of submitted vuln validations and persist."""
        self._sub(sub_uuid)["vuln_submitted_count"] = total_count
        self._save()

    def get_vuln_validated_paths(self, sub_uuid: str) -> set[str]:
        """Return file_paths whose validation outcomes were already submitted."""
        return set(self._sub(sub_uuid).get("vuln_validated_paths", []))

    def mark_vuln_paths_submitted(self, sub_uuid: str, file_paths: list[str]) -> None:
        """Append newly submitted vuln file_paths and persist immediately."""
        sub = self._sub(sub_uuid)
        existing: list[str] = sub.setdefault("vuln_validated_paths", [])
        existing_set = set(existing)
        added = False
        for fp in file_paths:
            if fp not in existing_set:
                existing.append(fp)
                existing_set.add(fp)
                added = True
        if added:
            self._save()

    def set_vuln_candidates(self, sub_uuid: str, candidates: list[dict]) -> None:
        """Persist serialised validation candidates for recovery on resume."""
        self._sub(sub_uuid)["vuln_candidates"] = candidates
        self._save()

    def get_vuln_candidates(self, sub_uuid: str) -> list[dict]:
        """Return previously persisted validation candidates (empty if none)."""
        return list(self._sub(sub_uuid).get("vuln_candidates", []))

    # ---- Audit plan metadata ------------------------------------------------

    def set_plan_file_count(self, count: int) -> None:
        """Persist the total number of files in the audit plan."""
        if count > 0:
            self._data["plan_file_count"] = count
            self._save()

    def get_plan_file_count(self) -> int:
        """Return the stored audit plan file count (0 if not yet set)."""
        return int(self._data.get("plan_file_count", 0))

    # ---- Introspection ------------------------------------------------------

    def has_progress(self) -> bool:
        """True if the checkpoint file exists and has at least one submitted file."""
        if not self._path.exists():
            return False
        return self.total_submitted_files() > 0

    def total_submitted_files(self) -> int:
        return sum(
            len(sub.get("submitted_file_paths", []))
            for sub in self._data.get("sub_audits", {}).values()
        )

    def created_at(self) -> str | None:
        return self._data.get("created_at")

    @property
    def path(self) -> Path:
        return self._path

    # ---- Lifecycle ----------------------------------------------------------

    def clear(self) -> None:
        """Delete checkpoint file after a successful, complete audit."""
        try:
            self._path.unlink(missing_ok=True)
        except Exception as exc:
            logger.warning("Could not delete checkpoint file: %s", exc)
