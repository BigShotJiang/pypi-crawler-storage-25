"""
Tier Definitions — Single Source of Truth

All tier-related constants, thresholds, centroids, prerequisite gates,
penalty caps, and evidence-strength rules live here.  Every module that
needs tier metadata (archetype_classifier, multi_repo_analyzer,
scalability_kpi_complete_fix, and the frontend API) MUST import from
this file rather than maintaining its own copy.
"""

from typing import Any

# ---------------------------------------------------------------------------
# 1. Tier Profiles  (T1–T5)
# ---------------------------------------------------------------------------

ARCHETYPE_TIERS: dict[int, dict[str, Any]] = {
    1: {
        'name': 'Low-Scale Monolith',
        'description': (
            'Simple monolithic application with a single deployable unit, '
            'single relational database, synchronous request handling, and '
            'minimal infrastructure automation.'
        ),
        'example_platforms': [
            'Internal admin/ops portals',
            'Handbook/policy systems',
        ],
        'characteristics': [
            'Simple',
            'Low concurrency',
            'Minimal scaling needs',
        ],
        'example_architecture': [
            'Monolith',
            'Layered architecture',
            'MVC',
            'Synchronous requests',
        ],
    },
    2: {
        'name': 'Moderate-Scale Modular Monolith',
        'description': (
            'Modularized but single-deployable application with bounded contexts, '
            'read replicas, caching layers, and containerized deployment. '
            'Optimized for read-heavy workloads.'
        ),
        'example_platforms': [
            'Document management',
            'Workflow/case management',
            'Content/catalog systems',
        ],
        'characteristics': [
            'Modularized but single deployable',
            'Optimized for read-heavy loads',
        ],
        'example_architecture': [
            'Modular monolith',
            'Bounded contexts',
            'Background job workers',
            'Caching layers',
        ],
    },
    3: {
        'name': 'Mid-Scale Service-Oriented (SOA)',
        'description': (
            'A few coarse-grained domain services communicating via API gateway '
            'and asynchronous messaging. Moderate throughput with team autonomy '
            'over individual services. Kubernetes or managed container orchestration.'
        ),
        'example_platforms': [
            'ERP-like subsystems',
            'CFO platforms (AP/AR/expenses)',
            'Integration hubs',
        ],
        'characteristics': [
            'A few domain services',
            'Moderate throughput',
            'Team autonomy',
        ],
        'example_architecture': [
            'SOA / "macro services"',
            'API gateway',
            'Asynchronous messaging',
            'Domain services',
        ],
    },
    4: {
        'name': 'High-Scale Microservices',
        'description': (
            'Many independently deployed services with high throughput and '
            'event-driven communication. Polyglot persistence with per-service '
            'databases, CQRS, distributed tracing, and Kubernetes autoscaling.'
        ),
        'example_platforms': [
            'High-volume order processing',
            'Marketplace backends',
            'Large multi-tenant SaaS',
        ],
        'characteristics': [
            'Many independently deployed services',
            'High throughput',
            'Event-driven',
        ],
        'example_architecture': [
            'Microservices',
            'Event-driven architecture',
            'CQRS',
            'Distributed tracing',
        ],
    },
    5: {
        'name': 'Real-Time Ultra-Scale Distributed System',
        'description': (
            'Extreme TPS with real-time processing, multi-region resilience, '
            'stream processing pipelines, event sourcing, sharding/partitioning, '
            'and geo-replicated distributed databases.'
        ),
        'example_platforms': [
            'Transaction monitoring',
            'Fraud detection',
            'Real-time bidding/adtech',
            'IoT telemetry/alerting',
        ],
        'characteristics': [
            'Real-time processing',
            'Extreme TPS',
            'Multi-region resilience',
        ],
        'example_architecture': [
            'Stream processing pipelines',
            'Event sourcing',
            'Sharding/partitioning',
            'Geo-replication',
        ],
    },
}

# ---------------------------------------------------------------------------
# 2. Dimension Labels & Descriptions
# ---------------------------------------------------------------------------

DIMENSION_LABELS: dict[str, str] = {
    'deployment_model': 'Deployment Model',
    'data_architecture': 'Data Architecture',
    'communication_style': 'Communication Style',
    'infrastructure_maturity': 'Infrastructure Maturity',
    'scaling_mechanisms': 'Scaling Mechanisms',
    'operational_maturity': 'Operational Maturity',
}

DIMENSION_DESCRIPTIONS: dict[str, str] = {
    'deployment_model': (
        'How the system is packaged and deployed — from manual uploads '
        'to orchestrated containers.'
    ),
    'data_architecture': (
        'Database topology, caching layers, and data distribution strategy.'
    ),
    'communication_style': (
        'Inter-service and client-server communication patterns and protocols.'
    ),
    'infrastructure_maturity': (
        'Monitoring, IaC, CI/CD, and operational tooling readiness.'
    ),
    'scaling_mechanisms': (
        'Horizontal/vertical scaling capabilities and auto-scaling infrastructure.'
    ),
    'operational_maturity': (
        'Observability, incident response, feature management, and release practices.'
    ),
}

DIMENSION_KEYS: list[str] = list(DIMENSION_LABELS.keys())

# ---------------------------------------------------------------------------
# 3. Dimension Weights
#
# Architecture and data carry more weight because they are the hardest
# (most expensive) to change post-deployment.
# ---------------------------------------------------------------------------

DIMENSION_WEIGHTS: dict[str, float] = {
    'deployment_model': 0.22,
    'data_architecture': 0.20,
    'communication_style': 0.15,
    'infrastructure_maturity': 0.17,
    'scaling_mechanisms': 0.13,
    'operational_maturity': 0.13,
}

# ---------------------------------------------------------------------------
# 4. Tier Centroids
#
# The "ideal" score for each dimension at each tier.  Used as reference
# points for distance calculations and for the frontend leveling-system
# display (centroid labels on the progress bar).
# ---------------------------------------------------------------------------

TIER_CENTROIDS: dict[int, dict[str, int]] = {
    1: {
        'deployment_model': 12,
        'data_architecture': 15,
        'communication_style': 10,
        'infrastructure_maturity': 15,
        'scaling_mechanisms': 8,
        'operational_maturity': 15,
    },
    2: {
        'deployment_model': 35,
        'data_architecture': 38,
        'communication_style': 30,
        'infrastructure_maturity': 40,
        'scaling_mechanisms': 30,
        'operational_maturity': 40,
    },
    3: {
        'deployment_model': 58,
        'data_architecture': 55,
        'communication_style': 55,
        'infrastructure_maturity': 60,
        'scaling_mechanisms': 50,
        'operational_maturity': 58,
    },
    4: {
        'deployment_model': 80,
        'data_architecture': 78,
        'communication_style': 80,
        'infrastructure_maturity': 82,
        'scaling_mechanisms': 75,
        'operational_maturity': 80,
    },
    5: {
        'deployment_model': 92,
        'data_architecture': 90,
        'communication_style': 92,
        'infrastructure_maturity': 93,
        'scaling_mechanisms': 90,
        'operational_maturity': 92,
    },
}

# Inject centroids into ARCHETYPE_TIERS for backward compatibility.
for _tier, _profile in ARCHETYPE_TIERS.items():
    _profile['dimension_centroids'] = TIER_CENTROIDS[_tier]

# ---------------------------------------------------------------------------
# 5. Tier Band Thresholds  (replaces nearest-centroid matching)
#
# A dimension score falls into exactly one tier band.  Bands are defined
# as [lower, upper) intervals.  The upper bound of tier N equals the lower
# bound of tier N+1 (midpoint between consecutive centroids, rounded).
# ---------------------------------------------------------------------------

TIER_BAND_THRESHOLDS: dict[str, dict[int, dict[str, int]]] = {
    'deployment_model': {
        1: {'lower': 0, 'upper': 24},
        2: {'lower': 24, 'upper': 47},
        3: {'lower': 47, 'upper': 69},
        4: {'lower': 69, 'upper': 86},
        5: {'lower': 86, 'upper': 101},
    },
    'data_architecture': {
        1: {'lower': 0, 'upper': 27},
        2: {'lower': 27, 'upper': 47},
        3: {'lower': 47, 'upper': 67},
        4: {'lower': 67, 'upper': 84},
        5: {'lower': 84, 'upper': 101},
    },
    'communication_style': {
        1: {'lower': 0, 'upper': 20},
        2: {'lower': 20, 'upper': 43},
        3: {'lower': 43, 'upper': 68},
        4: {'lower': 68, 'upper': 86},
        5: {'lower': 86, 'upper': 101},
    },
    'infrastructure_maturity': {
        1: {'lower': 0, 'upper': 28},
        2: {'lower': 28, 'upper': 50},
        3: {'lower': 50, 'upper': 71},
        4: {'lower': 71, 'upper': 88},
        5: {'lower': 88, 'upper': 101},
    },
    'scaling_mechanisms': {
        1: {'lower': 0, 'upper': 19},
        2: {'lower': 19, 'upper': 40},
        3: {'lower': 40, 'upper': 63},
        4: {'lower': 63, 'upper': 83},
        5: {'lower': 83, 'upper': 101},
    },
    'operational_maturity': {
        1: {'lower': 0, 'upper': 28},
        2: {'lower': 28, 'upper': 49},
        3: {'lower': 49, 'upper': 69},
        4: {'lower': 69, 'upper': 86},
        5: {'lower': 86, 'upper': 101},
    },
}


def tier_for_dimension_score(dim_key: str, score: float) -> int:
    """Return the tier a single dimension score falls into using band thresholds."""
    bands = TIER_BAND_THRESHOLDS.get(dim_key, {})
    for tier in (5, 4, 3, 2, 1):
        band = bands.get(tier, {})
        if score >= band.get('lower', 0):
            return tier
    return 1

# ---------------------------------------------------------------------------
# 6. Tier Prerequisite Gates
#
# Hard minimum dimension scores required to qualify for each tier.
# If ANY prerequisite is not met the classifier caps the tier at the
# highest tier whose prerequisites ARE fully satisfied.
#
# Only dimensions that are structurally decisive for a tier are listed;
# dimensions not listed have no gate for that tier.
# ---------------------------------------------------------------------------

TIER_PREREQUISITE_GATES: dict[int, dict[str, float]] = {
    2: {
        'deployment_model': 18,
        'infrastructure_maturity': 18,
    },
    3: {
        'deployment_model': 33,
        'communication_style': 22,
        'infrastructure_maturity': 33,
    },
    4: {
        'deployment_model': 52,
        'data_architecture': 42,
        'communication_style': 48,
        'infrastructure_maturity': 52,
    },
    5: {
        'deployment_model': 72,
        'data_architecture': 68,
        'communication_style': 68,
        'infrastructure_maturity': 72,
        'scaling_mechanisms': 62,
    },
}


def max_qualifying_tier(dimension_scores: dict[str, float]) -> int:
    """Return the highest tier whose prerequisite gates are fully satisfied."""
    max_tier = 1
    for tier in (2, 3, 4, 5):
        gates = TIER_PREREQUISITE_GATES.get(tier, {})
        if all(
            dimension_scores.get(dim, 0) >= threshold
            for dim, threshold in gates.items()
        ):
            max_tier = tier
        else:
            break
    return max_tier

# ---------------------------------------------------------------------------
# 7. Dimension Penalty Caps
#
# Negative architectural signals that impose a hard ceiling on specific
# dimension scores regardless of how many positive signals are detected.
#
# Each entry is: (signal_key, affected_dimension, cap_value, description)
# The DimensionScorer checks for these signals and applies the cap AFTER
# the additive scoring pass.
# ---------------------------------------------------------------------------

PENALTY_CAPS: list[dict[str, Any]] = [
    {
        'signal': 'monolith_detected',
        'dimension': 'deployment_model',
        'cap': 35,
        'description': 'Monolithic architecture detected — caps deployment model.',
    },
    {
        'signal': 'no_async_messaging',
        'dimension': 'communication_style',
        'cap': 25,
        'description': 'No asynchronous messaging detected — caps communication style.',
    },
    {
        'signal': 'single_database_only',
        'dimension': 'data_architecture',
        'cap': 30,
        'description': 'Single database technology — caps data architecture.',
    },
    {
        'signal': 'no_containerization',
        'dimension': 'infrastructure_maturity',
        'cap': 30,
        'description': 'No containerization detected — caps infrastructure maturity.',
    },
    {
        'signal': 'no_autoscaling',
        'dimension': 'scaling_mechanisms',
        'cap': 35,
        'description': 'No auto-scaling mechanisms detected — caps scaling mechanisms.',
    },
    {
        'signal': 'no_monitoring',
        'dimension': 'operational_maturity',
        'cap': 30,
        'description': 'No monitoring/observability detected — caps operational maturity.',
    },
]

# ---------------------------------------------------------------------------
# 8. Evidence Strength Levels
#
# Evidence items are tagged with a strength level that determines their
# weight contribution to the dimension score.
# ---------------------------------------------------------------------------

EVIDENCE_STRENGTH: dict[str, float] = {
    'strong': 1.0,    # Direct file/config evidence (Dockerfile, K8s manifest)
    'medium': 0.75,   # Dependency-based detection (package.json, requirements.txt)
    'weak': 0.50,     # Inferred from naming or LLM pattern analysis
}

# ---------------------------------------------------------------------------
# 9. Cross-Dimension Attenuation
#
# Technologies that contribute to multiple dimensions get attenuated on
# the second and subsequent dimensions to avoid double-counting.
#
# Format: technology_keyword -> list of dimensions it naturally contributes to
# The FIRST dimension in the list gets full credit; subsequent ones get
# ATTENUATION_FACTOR of the original contribution.
# ---------------------------------------------------------------------------

ATTENUATION_FACTOR: float = 0.5

MULTI_DIMENSION_TECHNOLOGIES: dict[str, list[str]] = {
    'kafka': ['communication_style', 'scaling_mechanisms', 'data_architecture'],
    'redis': ['data_architecture', 'scaling_mechanisms'],
    'kubernetes': ['infrastructure_maturity', 'deployment_model', 'scaling_mechanisms'],
    'docker': ['infrastructure_maturity', 'deployment_model'],
    'elasticsearch': ['data_architecture', 'scaling_mechanisms'],
    'rabbitmq': ['communication_style', 'scaling_mechanisms'],
    'prometheus': ['operational_maturity', 'infrastructure_maturity'],
    'grafana': ['operational_maturity', 'infrastructure_maturity'],
}

# ---------------------------------------------------------------------------
# 10. Growth Factor Ceiling per Tier
# ---------------------------------------------------------------------------

TIER_GROWTH_CEILING: dict[int, float] = {
    1: 1.5,
    2: 3.0,
    3: 5.0,
    4: 10.0,
    5: 20.0,
}

# ---------------------------------------------------------------------------
# 11. Gap Recommendations per (dimension, current_tier)
# ---------------------------------------------------------------------------

GAP_RECOMMENDATIONS: dict[str, dict[int, str]] = {
    'deployment_model': {
        1: 'Introduce bounded contexts and modular packaging within the monolith.',
        2: 'Extract domain services behind well-defined API contracts.',
        3: 'Decompose macro services into independently deployable microservices.',
        4: 'Ensure every service can be deployed, scaled, and rolled back independently across regions.',
    },
    'data_architecture': {
        1: 'Add a caching layer (Redis) and consider read replicas for heavy-read paths.',
        2: 'Introduce polyglot persistence: use the best data store per service domain.',
        3: 'Implement per-service databases with clear data ownership boundaries.',
        4: 'Adopt distributed databases (Cassandra/Spanner) with sharding and geo-replication.',
    },
    'communication_style': {
        1: 'Add background job processing (Celery/Bull) for non-critical work.',
        2: 'Introduce an event bus (RabbitMQ/SNS+SQS) for inter-service events.',
        3: 'Adopt a streaming platform (Kafka) for high-throughput event pipelines.',
        4: 'Implement event sourcing and stream processing (Flink/KStreams) for real-time analytics.',
    },
    'infrastructure_maturity': {
        1: 'Containerize the application with Docker and introduce a CI/CD pipeline.',
        2: 'Adopt Kubernetes for orchestration and Infrastructure as Code (Terraform).',
        3: 'Implement autoscaling policies (HPA/KEDA) and multi-environment promotion.',
        4: 'Deploy multi-region Kubernetes clusters with global load balancing.',
    },
    'scaling_mechanisms': {
        1: 'Add application-level caching and a CDN for static assets.',
        2: 'Introduce CQRS to separate read/write paths; add database read replicas.',
        3: 'Adopt data sharding/partitioning and streaming pipelines for hot paths.',
        4: 'Implement geo-replicated data stores and stream processing at scale.',
    },
    'operational_maturity': {
        1: 'Add centralized logging (ELK/Loki) and basic monitoring (Prometheus+Grafana).',
        2: 'Introduce distributed tracing (OpenTelemetry) and structured alerting.',
        3: 'Adopt GitOps, feature flags, and SLO-based alerting.',
        4: 'Add chaos engineering practices and multi-region observability.',
    },
}

# ---------------------------------------------------------------------------
# 12. Helper: build frontend tier_reference payload
# ---------------------------------------------------------------------------

def build_tier_reference() -> dict[str, dict[str, Any]]:
    """Build the tier_reference dict consumed by the frontend leveling UI."""
    ref: dict[str, dict[str, Any]] = {}
    for tier_num, profile in ARCHETYPE_TIERS.items():
        ref[str(tier_num)] = {
            'name': profile['name'],
            'description': profile['description'],
            'example_platforms': profile['example_platforms'],
            'characteristics': profile.get('characteristics', []),
            'example_architecture': profile.get('example_architecture', []),
            'dimension_centroids': TIER_CENTROIDS[tier_num],
            'dimension_bands': {
                dim: TIER_BAND_THRESHOLDS[dim][tier_num]
                for dim in DIMENSION_KEYS
            },
            'prerequisite_gates': TIER_PREREQUISITE_GATES.get(tier_num, {}),
            'growth_ceiling': TIER_GROWTH_CEILING.get(tier_num),
        }
    return ref
