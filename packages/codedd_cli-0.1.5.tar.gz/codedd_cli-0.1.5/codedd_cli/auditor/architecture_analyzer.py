"""
Local architecture analysis for CLI-driven audits.

Runs Phase 1 (file discovery and categorization), Phase 2 (per-file LLM
analysis over local file contents), and Phase 2.5 (synthesis of
architectural_components, component_relationships and architectural_insights
from per-file analyses — also LLM-driven, using the user's API keys).

Phase 3 (graph construction and TypeDB storage) runs on the server after
the CLI POSTs the fully populated phase1_results and phase2_results.

All LLM calls use the user's own API keys; no source code leaves the machine.
"""

import json
import logging
import os
import re
import threading
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from codedd_cli.auditor.archetype_classifier import classify_local
from codedd_cli.auditor.architecture_prompts import CATEGORY_PROMPTS, CATEGORY_SCHEMAS
from codedd_cli.auditor.enhanced_architecture_detectors import (
    LocalEnhancedRelationshipDetector,
    LocalEnhancedTechnologyDetector,
)

logger = logging.getLogger(__name__)

# Max file size for architecture analysis (1MB) and content truncation (30k chars)
_MAX_FILE_BYTES = 1024 * 1024
_MAX_CONTENT_CHARS = 30000

# ---------------------------------------------------------------------------
# Phase 1 constants — comprehensive file identification (ported from server)
# ---------------------------------------------------------------------------

# All 12 architecture analysis categories (4 more than the original 8)
ARCHITECTURE_CATEGORIES = [
    "dependency_files",
    "frontend_files",
    "backend_files",
    "database_files",
    "infrastructure_files",
    "ci_cd_files",
    "testing_files",
    "config_files",
    "api_schema_files",
    "monitoring_files",
    "message_queue_files",
    "security_auth_files",
]

# Exact dependency file names per ecosystem — matched first, highest priority
_DEPENDENCY_FILE_NAMES: dict[str, list[str]] = {
    "python": [
        "requirements.txt", "requirements-dev.txt", "requirements-test.txt",
        "requirements-prod.txt", "Pipfile", "setup.py", "setup.cfg",
        "pyproject.toml", "poetry.lock", "environment.yml", "environment.yaml",
        "tox.ini", "uv.lock", "pdm.lock",
    ],
    "node": [
        "package.json", "yarn.lock", "pnpm-lock.yaml", "lerna.json",
        "nx.json", "rush.json", ".nvmrc", ".node-version",
        "deno.json", "deno.jsonc",
    ],
    "java": [
        "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle",
        "gradle.properties", "build.xml", "ivy.xml", "gradle-wrapper.properties",
    ],
    "ruby": [
        "Gemfile", "gems.rb", ".ruby-version", ".ruby-gemset",
        "Rakefile", "config.ru", "Appraisals",
    ],
    "go": [
        "go.mod", "go.work", "Gopkg.toml", "Gopkg.lock", "glide.yaml",
    ],
    "rust": [
        "Cargo.toml", "rust-toolchain", "rust-toolchain.toml",
    ],
    "php": [
        "composer.json", "phpunit.xml", "phpunit.xml.dist", "psalm.xml", "phpstan.neon",
    ],
    "csharp": [
        "packages.config", "global.json", "nuget.config",
        "Directory.Build.props", "Directory.Packages.props",
    ],
    "cpp": [
        "CMakeLists.txt", "conanfile.txt", "conanfile.py", "vcpkg.json",
        "meson.build", "configure.ac",
    ],
    "swift": [
        "Package.swift", "Package.resolved", "Podfile", "Cartfile",
    ],
    "dart": [
        "pubspec.yaml", "analysis_options.yaml",
    ],
    "elixir": [
        "mix.exs", "mix.lock",
    ],
    "haskell": [
        "stack.yaml", "cabal.project",
    ],
    "perl": [
        "cpanfile", "Makefile.PL", "Build.PL", "META.json", "META.yml",
        "dist.ini", "minil.toml",
    ],
    "r": [
        "DESCRIPTION", "renv.lock",
    ],
    "zig": [
        "build.zig", "build.zig.zon",
    ],
}
_ALL_DEPENDENCY_FILE_NAMES: set[str] = {
    name for names in _DEPENDENCY_FILE_NAMES.values() for name in names
}

# Exact architecture-relevant file names per category (second priority after dep files)
_ARCHITECTURE_FILE_NAMES: dict[str, list[str]] = {
    "frontend_files": [
        "index.html", "main.html", "app.html", "index.htm",
        "App.js", "App.jsx", "App.tsx", "App.vue", "app.component.ts",
        "main.ts", "main.js", "index.ts", "index.jsx", "index.tsx",
        "webpack.config.js", "vite.config.js", "vite.config.ts", "rollup.config.js",
        "angular.json", "vue.config.js", "next.config.js", "next.config.mjs",
        "nuxt.config.js", "nuxt.config.ts", "svelte.config.js", "remix.config.js",
        "astro.config.mjs", "solid.config.js",
        "tailwind.config.js", "tailwind.config.ts", "postcss.config.js",
        "tsconfig.json", "tsconfig.app.json", "tsconfig.node.json",
        ".babelrc", ".babelrc.js", "babel.config.js", "babel.config.json",
        ".eslintrc", ".eslintrc.js", ".eslintrc.json", "eslint.config.js", "eslint.config.mjs",
        ".prettierrc", ".prettierrc.js", ".prettierrc.json", "prettier.config.js",
    ],
    "backend_files": [
        "manage.py", "settings.py", "wsgi.py", "asgi.py", "urls.py",
        "app.py", "main.py", "run.py", "start.py",
        "gunicorn.conf.py", "gunicorn_config.py", "uvicorn_config.py",
        "celery.py", "celery_config.py", "worker.py",
        "server.js", "app.js", "index.js", "server.ts", "app.ts",
        "Application.java", "Main.java", "App.java", "Server.java",
        "application.properties", "application.yml", "application.yaml",
        "config.ru", "application.rb",
        "Program.cs", "Startup.cs", "appsettings.json", "appsettings.Development.json",
        "app.pl", "app.psgi", "server.pl", "application.pl",
        "middleware.py", "middleware.js", "middleware.ts",
        "routes.py", "routes.js", "routes.ts", "router.js", "router.ts",
        "main.go", "main.rs", "main.rb", "artisan", "index.php", "server.php",
    ],
    "database_files": [
        "models.py", "model.py", "schema.py", "entities.py", "entity.py",
        "schema.sql", "init.sql", "seed.sql", "data.sql", "setup.sql",
        "schema.prisma", "schema.graphql", "typeDefs.js", "typeDefs.ts",
        "database.js", "database.ts", "db.js", "db.ts", "connection.js", "datasource.js",
        "alembic.ini", "flyway.conf", "liquibase.properties",
        "knexfile.js", "ormconfig.json", "typeorm.config.js", "sequelize.config.js",
        "schema.tql", "define_schema.tql",
    ],
    "infrastructure_files": [
        "Dockerfile", "Dockerfile.dev", "Dockerfile.prod", "Dockerfile.test",
        "docker-compose.yml", "docker-compose.yaml",
        "docker-compose.dev.yml", "docker-compose.prod.yml", "docker-compose.test.yml",
        ".dockerignore",
        "Procfile", "Procfile.dev", "app.yaml", "app.yml",
        "serverless.yml", "serverless.yaml", "sam-template.yaml", "sam-template.yml",
        "cloudformation.yml", "cloudformation.yaml", "template.yml", "template.yaml",
        "terraform.tf", "main.tf", "variables.tf", "outputs.tf", "provider.tf",
        "Pulumi.yaml", "Pulumi.dev.yaml", "Pulumi.prod.yaml",
        "Vagrantfile", "ansible.cfg", "playbook.yml",
        "skaffold.yaml", "kustomization.yaml", "Chart.yaml",
        "deployment.yaml", "service.yaml", "ingress.yaml", "configmap.yaml",
        "secret.yaml", "statefulset.yaml", "daemonset.yaml", "job.yaml", "cronjob.yaml",
        "nginx.conf", "nginx.dev.conf", "nginx.prod.conf",
        "kong.yml", "kong.yaml", "traefik.yml", "traefik.yaml",
        "envoy.yaml", "istio.yaml", "nomad.hcl",
    ],
    "ci_cd_files": [
        "Jenkinsfile", "jenkins.yml", "jenkins.yaml",
        ".gitlab-ci.yml", ".travis.yml", "circle.yml",
        "azure-pipelines.yml", "bitbucket-pipelines.yml",
        "buildspec.yml", "cloudbuild.yaml", "drone.yml", "appveyor.yml",
        "workflow.yml", "workflow.yaml", "ci.yml", "cd.yml", "deploy.yml",
    ],
    "testing_files": [
        "pytest.ini", "conftest.py",
        "jest.config.js", "jest.config.ts", "jest.setup.js", "jest.setup.ts",
        "karma.conf.js", "protractor.conf.js",
        "vitest.config.js", "vitest.config.ts",
        "cypress.json", "cypress.config.js", "cypress.config.ts",
        "playwright.config.js", "playwright.config.ts",
        "wdio.conf.js", "wdio.conf.ts",
        "phpunit.xml", "testng.xml", ".rspec",
    ],
    "api_schema_files": [
        "openapi.yaml", "openapi.yml", "openapi.json",
        "swagger.yaml", "swagger.yml", "swagger.json",
        "api.yaml", "api.yml", "api.json",
        "schema.graphql", "schema.gql", "typeDefs.graphql",
        "service.proto", "api.proto", "service.wsdl",
    ],
    "monitoring_files": [
        "prometheus.yml", "prometheus.yaml", "prometheus.config.yml",
        "alerting.yml", "alerts.yml",
        "grafana.ini", "datasources.yml", "dashboard.json",
        "otel-collector-config.yaml", "opentelemetry.yaml",
        "jaeger.yml", "jaeger-config.yml",
        "datadog.yaml", "datadog.yml",
        "newrelic.yml", "newrelic.js",
        "fluentd.conf", "fluent-bit.conf", "logstash.conf",
    ],
    "message_queue_files": [
        "rabbitmq.conf", "rabbitmq.config",
        "server.properties", "producer.properties", "consumer.properties",
        "redis.conf", "redis.yaml",
        "celeryconfig.py",
    ],
    "security_auth_files": [
        "auth.config.js", "auth.config.ts", "auth.js", "auth.ts",
        "keycloak.json", "keycloak.config.js",
        "security.txt", "security.yaml",
        "cors.config.js", "helmet.config.js",
        ".env.example", ".env.template", ".env.sample",
    ],
}
# Flat lookup: filename → category (for O(1) exact-name dispatch)
_FILE_NAME_TO_CATEGORY: dict[str, str] = {
    name: cat
    for cat, names in _ARCHITECTURE_FILE_NAMES.items()
    for name in names
}

# Folder-name patterns — files inside these folder names get categorised accordingly
_FOLDER_PATTERNS: dict[str, list[str]] = {
    "frontend_files": [
        "frontend", "client", "ui", "web", "www", "public", "static", "assets",
        "components", "views", "pages", "layouts", "templates", "partials",
        "hooks", "contexts", "providers", "store", "stores", "state",
    ],
    "backend_files": [
        "backend", "server", "api", "app", "src", "lib", "services",
        "controllers", "routes", "handlers", "middleware", "middlewares",
        "models", "utils", "helpers", "core", "domain",
        "business", "logic", "repository", "workers", "tasks", "jobs",
    ],
    "database_files": [
        "migrations", "db", "sql", "database", "schema", "schemas", "seeds",
        "fixtures", "alembic", "flyway", "liquibase", "prisma", "typeorm",
    ],
    "infrastructure_files": [
        "infra", "infrastructure", "deploy", "deployment", "ops", "devops",
        "k8s", "kubernetes", "helm", "charts", "kustomize",
        "terraform", "tf", "cloudformation", "ansible",
        "docker", "containers", "compose", "pulumi", "nomad", "manifests",
    ],
    "testing_files": [
        "tests", "test", "__tests__", "spec", "specs",
        "e2e", "integration", "unit", "functional",
        "cypress", "selenium", "playwright", "puppeteer",
    ],
    "api_schema_files": [
        "api", "apis", "graphql", "grpc", "rest", "rpc",
        "proto", "protobuf", "schemas",
    ],
    "monitoring_files": [
        "monitoring", "observability", "metrics", "logs", "logging",
        "alerts", "alerting", "prometheus", "grafana",
    ],
    "security_auth_files": [
        "auth", "authentication", "authorization", "security", "iam", "oauth", "jwt",
    ],
}

# Regex patterns for files/directories to exclude from architecture analysis
_EXCLUDE_PATTERNS: list[str] = [
    # Version control
    r"\.git/", r"\.svn/", r"\.hg/", r"\.gitkeep$", r"\.gitattributes$",
    # Package manager caches / vendor
    r"node_modules/", r"bower_components/", r"vendor/", r"jspm_packages/",
    r"\.yarn/", r"\.npm/", r"\.pnpm-store/",
    # Python environment / cache
    r"__pycache__/", r"__init__\.py$", r"\.pyc$", r"\.pyo$", r"\.pyd$",
    r"\.egg-info/", r"\.eggs/", r"venv/", r"env/", r"\.venv/", r"virtualenv/",
    r"conda-meta/", r"\.conda/",
    # Perl build cache
    r"blib/", r"_build/", r"\.build/", r"cover_db/", r"\.carton/", r"local/",
    # Build output
    r"build/", r"dist/", r"target/", r"out/", r"obj/", r"release/", r"debug/",
    r"cmake-build-.*/", r"\.output/", r"\.vercel/", r"\.netlify/",
    # Generated code
    r"generated/", r"gen/", r"__generated__/", r"codegen/",
    # IDE / editor
    r"\.idea/", r"\.vscode/", r"\.vs/", r"\.eclipse/", r"\.settings/",
    r"\.swp$", r"\.swo$", r"~$",
    # OS generated
    r"\.DS_Store", r"Thumbs\.db", r"desktop\.ini",
    # Build tool caches / framework output
    r"\.gradle/", r"\.mvn/", r"\.parcel-cache/", r"\.turbo/", r"\.cache/",
    r"\.sass-cache/", r"\.next/", r"\.nuxt/", r"\.svelte-kit/",
    r"\.angular/", r"_site/", r"\.gatsby-cache/",
    # Test / coverage output
    r"coverage/", r"\.coverage$", r"\.nyc_output/", r"htmlcov/",
    r"\.pytest_cache/", r"test-results/", r"\.tox/",
    # Minified / bundled assets
    r"\.min\.js$", r"\.bundle\.js$", r"\.chunk\.js$", r"\.min\.css$", r"\.map$",
    # Media — images
    r"\.jpg$", r"\.jpeg$", r"\.png$", r"\.gif$", r"\.bmp$", r"\.ico$",
    r"\.svg$", r"\.webp$", r"\.tiff$", r"\.psd$", r"\.sketch$", r"\.fig$",
    # Media — video / audio
    r"\.mp4$", r"\.avi$", r"\.mov$", r"\.webm$", r"\.mkv$",
    r"\.mp3$", r"\.wav$", r"\.flac$", r"\.aac$", r"\.ogg$",
    # Documents
    r"\.pdf$", r"\.doc$", r"\.docx$", r"\.xls$", r"\.xlsx$",
    # Fonts
    r"\.woff$", r"\.woff2$", r"\.ttf$", r"\.otf$", r"\.eot$",
    # Documentation source
    r"\.md$", r"README", r"CHANGELOG", r"CONTRIBUTING", r"CODE_OF_CONDUCT",
    r"\.rst$", r"\.adoc$",
    # License / legal
    r"^LICENSE", r"^COPYING", r"^NOTICE", r"^PATENTS",
    # Binary / compiled
    r"\.exe$", r"\.dll$", r"\.so$", r"\.dylib$", r"\.a$", r"\.o$",
    r"\.class$", r"\.jar$", r"\.war$", r"\.ear$",
    # Certificates / keys
    r"\.pem$", r"\.key$", r"\.crt$", r"\.cer$", r"\.p12$", r"\.pfx$", r"\.jks$",
    # Database binary files
    r"\.db$", r"\.sqlite$", r"\.sqlite3$",
    # Archives
    r"\.zip$", r"\.tar\.gz$", r"\.tgz$", r"\.tar$", r"\.rar$", r"\.7z$", r"\.gz$",
    # Lock files (dependency manifests kept; lock files excluded)
    r"package-lock\.json$", r"yarn\.lock$", r"pnpm-lock\.yaml$",
    r"poetry\.lock$", r"Pipfile\.lock$", r"Gemfile\.lock$", r"composer\.lock$",
    r"go\.sum$", r"Cargo\.lock$",
    # Logs / temp
    r"logs/", r"log/", r"\.log$", r"\.tmp$", r"tmp/", r"temp/",
    # Cloud / IaC state / artifacts
    r"\.serverless/", r"\.terraform/", r"terraform\.tfstate",
    r"cdk\.out/", r"\.aws-sam/", r"\.pulumi/",
    # Misc tooling caches
    r"\.eslintcache$", r"\.stylelintcache$", r"\.prettiercache$",
    r"npm-debug\.log", r"yarn-error\.log",
]
_COMPILED_EXCLUDE: list[re.Pattern] = [re.compile(p) for p in _EXCLUDE_PATTERNS]

# File selection limits (matching server FileIdentifier constants)
_MAX_RELEVANT_FILES = 50
_MIN_FILES_PER_CATEGORY = 5
_FILE_SELECTION_PRIORITY: list[str] = [
    "dependency_files",
    "infrastructure_files",
    "api_schema_files",
    "database_files",
    "ci_cd_files",
    "backend_files",
    "frontend_files",
    "monitoring_files",
    "message_queue_files",
    "security_auth_files",
    "config_files",
    "testing_files",
]


# ---------------------------------------------------------------------------
# Phase 1 helper functions (ported from server FileIdentifier)
# ---------------------------------------------------------------------------

def _get_relative_path(file_path: str) -> str:
    """Extract the relative path from a CLI-style path (cli://uuid/repo/rel/path)."""
    m = re.match(r"cli://[^/]+/[^/]+/(.+)", file_path)
    if m:
        return m.group(1)
    # Keep non-CLI paths as relative-style paths so folder-pattern matching
    # still works in unit tests and local helper usage.
    return file_path.replace("\\", "/").lstrip("./")


def _should_exclude(file_path: str) -> bool:
    """Return True if this file should be excluded from architecture analysis."""
    rel = _get_relative_path(file_path)
    return any(pat.search(rel) for pat in _COMPILED_EXCLUDE)


def _matches_folder(rel_path: str, folder_names: list[str]) -> bool:
    """Return True if rel_path sits inside one of the given folder names."""
    path_lower = rel_path.lower().replace("\\", "/")
    for folder in folder_names:
        f = folder.lower()
        if f"/{f}/" in path_lower or path_lower.startswith(f"{f}/"):
            return True
    return False


def _is_important_frontend_file(file_name: str) -> bool:
    """Return True for architecturally significant files found inside frontend folders."""
    name_lower = file_name.lower()
    entry_stems = {"index", "main", "app", "root"}
    fe_extensions = {".tsx", ".jsx", ".vue", ".svelte", ".js", ".ts", ".html"}
    specific_names = {
        "app.js", "app.jsx", "app.ts", "app.tsx", "app.vue", "app.svelte",
        "index.html", "angular.json", "vue.config.js", "next.config.js",
        "nuxt.config.js", "svelte.config.js", "webpack.config.js",
        "vite.config.js", "rollup.config.js", "tailwind.config.js", "postcss.config.js",
    }
    stem, ext = os.path.splitext(name_lower)
    return (
        (stem in entry_stems and ext in fe_extensions)
        or name_lower in specific_names
        or "config" in name_lower
    )


def _is_important_backend_file(file_name: str) -> bool:
    """Return True for architecturally significant files found inside backend folders."""
    name_lower = file_name.lower()
    generic_stems = {
        "main", "app", "server", "application", "run", "index", "startup", "program", "service",
    }
    lang_specific = {
        "wsgi.py", "asgi.py", "manage.py", "settings.py", "config.py", "urls.py",
        "main.go", "main.rs", "main.rb", "artisan", "index.php", "server.php",
        "program.cs", "startup.cs", "appsettings.json",
        "config.ru", "app.rb", "app.pl", "app.psgi", "server.pl",
    }
    backend_extensions = {
        ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".kt", ".go", ".cs", ".rb", ".rs",
        ".php", ".pl", ".pm", ".psgi", ".cgi",
    }
    stem, ext = os.path.splitext(name_lower)
    return (
        (stem in generic_stems and ext in backend_extensions)
        or name_lower in lang_specific
        or ext in backend_extensions
        or "config" in name_lower
        or "settings" in name_lower
    )


def _is_config_file_phase1(file_name: str) -> bool:
    """Return True for generic configuration files (catch-all at end of categorisation)."""
    config_exts = {".yml", ".yaml", ".json", ".ini", ".conf", ".cfg", ".toml"}
    config_keywords = {"config", "settings", "env", "properties"}
    name_lower = file_name.lower()
    return (
        any(name_lower.endswith(ext) for ext in config_exts)
        and any(kw in name_lower for kw in config_keywords)
    )


def _categorize_file(file_path: str) -> str | None:
    """
    Comprehensive file categorisation matching the server FileIdentifier logic.

    Priority order:
      1. Dependency file (exact filename match) → ``dependency_files``
      2. Architecture-specific exact filename → specific category
      3. Folder-pattern match → category (with importance filter for frontend/backend)
      4. Generic config file → ``config_files``
    """
    file_name = os.path.basename(file_path.replace("\\", "/"))
    rel_path = _get_relative_path(file_path)

    # 1. Dependency files — highest priority
    if file_name in _ALL_DEPENDENCY_FILE_NAMES:
        return "dependency_files"

    # 2. Preserve legacy behavior for CI YAML naming.
    # Historically, generic *.yml/*.yaml infrastructure handling took precedence
    # over CI/CD exact-name mapping (e.g. .gitlab-ci.yml).
    if file_name in _ARCHITECTURE_FILE_NAMES.get("ci_cd_files", []) and file_name.lower().endswith(
        (".yml", ".yaml")
    ):
        return "infrastructure_files"

    # 3. Architecture-specific exact filenames
    if file_name in _FILE_NAME_TO_CATEGORY:
        return _FILE_NAME_TO_CATEGORY[file_name]

    # 4. Folder-pattern categorisation
    for cat, folders in _FOLDER_PATTERNS.items():
        if _matches_folder(rel_path, folders):
            if cat == "frontend_files" and not _is_important_frontend_file(file_name):
                continue
            if cat == "backend_files" and not _is_important_backend_file(file_name):
                continue
            return cat

    # 5. Generic config catch-all
    if _is_config_file_phase1(file_name):
        return "config_files"

    return None


def _select_relevant_files(file_categories: dict[str, list[str]]) -> list[str]:
    """
    Priority-based file selection with MIN/MAX limits, matching the server
    ``FileIdentifier._select_relevant_files`` logic.
    """
    final: list[str] = []
    seen: set[str] = set()
    allocated: dict[str, int] = {}

    # Phase 1: fill to MAX_RELEVANT_FILES in priority order
    for cat in _FILE_SELECTION_PRIORITY:
        cat_files = file_categories.get(cat, [])
        if not cat_files:
            allocated[cat] = 0
            continue
        added = 0
        for fp in cat_files:
            if fp not in seen and len(final) < _MAX_RELEVANT_FILES:
                seen.add(fp)
                final.append(fp)
                added += 1
        allocated[cat] = added
        if len(final) >= _MAX_RELEVANT_FILES:
            break

    # Phase 2: ensure minimum representation per category
    for cat in _FILE_SELECTION_PRIORITY:
        current = allocated.get(cat, 0)
        if current >= _MIN_FILES_PER_CATEGORY:
            continue
        cat_files = file_categories.get(cat, [])
        needed = _MIN_FILES_PER_CATEGORY - current
        extra = 0
        for fp in cat_files:
            if fp not in seen and extra < needed:
                seen.add(fp)
                final.append(fp)
                extra += 1
        allocated[cat] = current + extra

    return final


def _identify_technologies(
    dep_file_paths: list[str],
    local_base: str,
    prefix: str,
) -> dict[str, Any]:
    """Parse dependency files to extract technology / framework information."""
    technologies: dict[str, Any] = {}
    for dep_path in dep_file_paths:
        rel = (
            dep_path[len(prefix):].lstrip("/")
            if prefix and dep_path.startswith(prefix)
            else _get_relative_path(dep_path)
        )
        local_path = os.path.normpath(os.path.join(local_base, rel))
        if not os.path.isfile(local_path):
            continue
        file_name = os.path.basename(local_path)
        try:
            if file_name == "package.json":
                info = _parse_package_json(local_path)
            elif file_name in ("requirements.txt", "Pipfile"):
                info = _parse_python_deps(local_path)
            elif file_name in ("pom.xml", "build.gradle", "build.gradle.kts"):
                info = _parse_java_deps(local_path, file_name)
            elif file_name == "Gemfile":
                info = _parse_ruby_deps(local_path)
            elif file_name == "go.mod":
                info = _parse_go_deps(local_path)
            else:
                info = {"language": "unknown", "package_manager": file_name, "total_dependencies": 0}
            if info:
                technologies[dep_path] = info
        except Exception as exc:
            logger.debug("Failed to parse dependency file %s: %s", dep_path, exc)
    return technologies


def _parse_package_json(path: str) -> dict[str, Any]:
    """Parse Node.js package.json for technology information."""
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        deps: dict[str, str] = {}
        deps.update(data.get("dependencies", {}))
        deps.update(data.get("devDependencies", {}))
        fw_kw = ("react", "vue", "angular", "svelte", "next", "express", "nest", "fastify", "nuxt")
        frameworks = [d for d in deps if any(kw in d.lower() for kw in fw_kw)]
        return {
            "language": "javascript/nodejs",
            "package_manager": "npm/yarn",
            "total_dependencies": len(deps),
            "frameworks": frameworks[:10],
            "project_name": data.get("name", "unknown"),
            "scripts": list(data.get("scripts", {}).keys())[:10],
        }
    except Exception:
        return {}


def _parse_python_deps(path: str) -> dict[str, Any]:
    """Parse requirements.txt or Pipfile for technology information."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        deps: list[str] = []
        for line in content.splitlines():
            line = line.strip()
            if line and not line.startswith("#") and not line.startswith("-r"):
                dep = re.split(r"[>=<!;\s]", line)[0].strip()
                if dep:
                    deps.append(dep)
        fw_kw = ("django", "flask", "fastapi", "tornado", "starlette", "aiohttp")
        frameworks = [d for d in deps if any(kw in d.lower() for kw in fw_kw)]
        return {
            "language": "python",
            "package_manager": "pip" if "requirements" in os.path.basename(path) else "pipenv",
            "total_dependencies": len(deps),
            "frameworks": frameworks,
            "dependencies": deps[:20],
        }
    except Exception:
        return {}


def _parse_java_deps(path: str, file_name: str) -> dict[str, Any]:
    """Parse pom.xml or build.gradle for technology information."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        frameworks = []
        content_lower = content.lower()
        if "spring-boot" in content_lower or "springframework" in content_lower:
            frameworks.append("Spring Boot")
        if "quarkus" in content_lower:
            frameworks.append("Quarkus")
        if "micronaut" in content_lower:
            frameworks.append("Micronaut")
        dep_count = content_lower.count("<dependency>") or content.count("implementation(")
        return {
            "language": "java",
            "package_manager": "maven" if "pom.xml" in file_name else "gradle",
            "total_dependencies": dep_count,
            "frameworks": frameworks,
        }
    except Exception:
        return {}


def _parse_ruby_deps(path: str) -> dict[str, Any]:
    """Parse Gemfile for technology information."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        gems = re.findall(r"gem\s+['\"]([^'\"]+)['\"]", content)
        return {
            "language": "ruby",
            "package_manager": "bundler",
            "total_dependencies": len(gems),
            "frameworks": ["Rails"] if "rails" in [g.lower() for g in gems] else [],
            "dependencies": gems[:10],
        }
    except Exception:
        return {}


def _parse_go_deps(path: str) -> dict[str, Any]:
    """Parse go.mod for technology information."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        deps = re.findall(r"^\s+([^\s]+)\s+v", content, re.MULTILINE)
        return {
            "language": "go",
            "package_manager": "go_modules",
            "total_dependencies": len(deps),
            "frameworks": [],
            "dependencies": deps[:10],
        }
    except Exception:
        return {}


def _analyze_folder_structure(filtered_files: list[str]) -> dict[str, Any]:
    """Analyse folder structure to identify high-level architectural patterns."""
    folders: set[str] = set()
    root_items: set[str] = set()
    for fp in filtered_files:
        rel = _get_relative_path(fp).replace("\\", "/")
        parts = rel.split("/")
        if len(parts) > 1:
            root_items.add(parts[0])
        for i in range(1, len(parts)):
            folders.add("/".join(parts[:i]))
    patterns: list[str] = []
    if any(f in root_items for f in ("apps", "packages", "services", "projects")):
        patterns.append("monorepo")
    if len([i for i in root_items if "service" in i.lower()]) > 1:
        patterns.append("microservices")
    if any(f in root_items for f in ("frontend", "backend", "database", "api")):
        patterns.append("layered")
    if any(f in folders for f in ("controllers", "models", "views")):
        patterns.append("mvc")
    return {
        "total_folders": len(folders),
        "root_level_items": sorted(root_items),
        "architectural_patterns": patterns,
        "max_depth": max((len(f.split("/")) for f in folders), default=0),
    }


def build_phase1_results(
    file_paths: list[str],
    repository_path: str,
    local_base: str | None = None,
    sub_audit_uuid: str = "",
    repo_name: str = "",
) -> dict[str, Any]:
    """
    Build Phase 1 (file identification) results from a list of file paths.

    Ports the server ``FileIdentifier`` logic for CLI use:
    - Filters excluded files (node_modules, __pycache__, media, binaries, etc.)
    - Categorises files using exact-name + folder-pattern matching across 12 categories
    - Selects architecturally relevant files with priority ordering and MIN/MAX limits
    - Identifies technologies by parsing dependency file content when local_base is provided
    - Analyses folder structure for high-level architectural patterns

    file_paths:      list of paths in TypeDB form (e.g. cli://uuid/repo/rel/path).
    repository_path: display path (e.g. cli://uuid/repo or repo name).
    local_base:      optional local directory root for technology detection.
    sub_audit_uuid:  used to build the path prefix for local file resolution.
    repo_name:       used to build the path prefix for local file resolution.
    """
    # 1. Filter excluded files
    filtered = [fp for fp in file_paths if not _should_exclude(fp)]

    # 2. Categorise files across all 12 categories
    file_categories: dict[str, list[str]] = {cat: [] for cat in ARCHITECTURE_CATEGORIES}
    seen_categorised: set[str] = set()
    for fp in filtered:
        cat = _categorize_file(fp)
        if cat and cat in file_categories and fp not in seen_categorised:
            file_categories[cat].append(fp)
            seen_categorised.add(fp)

    # 3. Priority-based file selection with MIN/MAX limits
    relevant_files = _select_relevant_files(file_categories)

    # 4. Technology identification from dependency file content (requires local access)
    identified_technologies: dict[str, Any] = {}
    if local_base and os.path.isdir(local_base):
        prefix = f"cli://{sub_audit_uuid}/{repo_name}/" if sub_audit_uuid and repo_name else ""
        identified_technologies = _identify_technologies(
            file_categories.get("dependency_files", []),
            local_base,
            prefix,
        )

    # 5. Folder structure analysis
    folder_structure = _analyze_folder_structure(filtered)

    return {
        "repository_path": repository_path,
        "total_files_scanned": len(file_paths),
        "filtered_files_count": len(filtered),
        "relevant_files": relevant_files,
        "file_categories": file_categories,
        "identified_technologies": identified_technologies,
        "folder_structure": folder_structure,
        "analysis_metadata": {
            "phase": "file_identification",
            "status": "completed",
            "data_source": "cli",
            "max_files_limit": _MAX_RELEVANT_FILES,
        },
    }


def build_phase2_results_empty(reason: str = "CLI stub") -> dict[str, Any]:
    """Build minimal Phase 2 results so the server can run Phase 3 and store."""
    return _build_phase2_skeleton(
        category_analyses={},
        total_files_analyzed=0,
        categories_analyzed=[],
        executive_summary=f"Architecture analysis (CLI): {reason}.",
    )


def _build_phase2_skeleton(
    category_analyses: dict[str, list],
    total_files_analyzed: int,
    categories_analyzed: list[str],
    executive_summary: str = "Architecture analysis completed on CLI.",
) -> dict[str, Any]:
    """Build Phase 2 payload with category_analyses; components/relationships/insights left for server synthesis."""
    return {
        "analysis_metadata": {
            "phase": "enhanced_llm_analysis",
            "status": "completed",
            "timestamp": time.time(),
            "total_files_analyzed": total_files_analyzed,
            "categories_analyzed": categories_analyzed,
            "enhanced_technologies_detected": 0,
            "enhanced_relationships_detected": 0,
        },
        "category_analyses": category_analyses,
        "enhanced_technology_detection": {
            "detected_technologies": {},
            "relationship_map": {},
            "technology_count": 0,
            "relationship_count": 0,
        },
        "enhanced_relationship_analysis": {
            "relationships": {},
            "component_graph": {},
            "architectural_patterns": [],
            "coupling_analysis": {},
            "communication_patterns": {},
            "critical_dependencies": [],
            "relationship_count": 0,
            "component_count": 0,
        },
        "architectural_components": {},
        "component_relationships": [],
        "architectural_insights": {
            "technology_stack": [],
            "architectural_patterns": [],
            "service_architecture": "unknown",
            "data_architecture": "unknown",
            "deployment_approach": "unknown",
            "development_practices": [],
            "coupling_analysis": {},
            "communication_patterns": {},
            "critical_dependencies": [],
            "executive_summary": executive_summary,
        },
    }


def _read_file_safely_local(local_path: str, max_chars: int = _MAX_CONTENT_CHARS) -> str | None:
    """Read file content with size limit; truncate by character count. Returns None on error."""
    try:
        if not os.path.isfile(local_path):
            return None
        size = os.path.getsize(local_path)
        if size > _MAX_FILE_BYTES:
            return None
        with open(local_path, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        if len(content) > max_chars:
            content = content[:max_chars] + "\n... (truncated)"
        return content
    except OSError:
        return None


def _build_analysis_prompt(file_path: str, file_content: str, category: str) -> str:
    """Build category-specific analysis prompt (server-compatible format)."""
    base_prompt = CATEGORY_PROMPTS.get(category, CATEGORY_PROMPTS["config_files"])
    expected_schema = CATEGORY_SCHEMAS.get(category, CATEGORY_SCHEMAS["config_files"])
    return f"""
{base_prompt}

File: {os.path.basename(file_path)}
Category: {category}

Expected Output Format (JSON):
{json.dumps(expected_schema, indent=2)}

File Content:
```
{file_content}
```

**CRITICAL**: Respond with ONLY valid JSON. No markdown, no explanations. Start with {{ and end with }}.
"""


def _clean_json_content(raw: str) -> str:
    """Try to fix common LLM JSON issues (trailing commas, markdown wrapper)."""
    text = raw.strip()
    # Extract from markdown code block
    m = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if m:
        text = m.group(1)
    # Fix trailing commas before ] or }
    text = re.sub(r",(\s*[}\]])", r"\1", text)
    return text


def _parse_llm_response(response_text: str, file_path: str, category: str) -> dict[str, Any] | None:
    """Extract and validate JSON from LLM response; add file_path and analysis_timestamp."""
    logger = logging.getLogger(__name__)
    try:
        start = response_text.find("{")
        end = response_text.rfind("}") + 1
        if start == -1 or end <= start:
            return None
        cleaned = _clean_json_content(response_text[start:end])
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    schema = CATEGORY_SCHEMAS.get(category, CATEGORY_SCHEMAS["config_files"])
    for key in schema:
        if key not in data:
            data[key] = schema[key] if isinstance(schema[key], (list, dict)) else ""
        else:
            expected_type = type(schema[key])
            if not isinstance(data[key], expected_type):
                logger.warning(
                    "Schema drift detected for category=%r key=%r: expected %s, got %s (file=%s)",
                    category, key, expected_type.__name__, type(data[key]).__name__, file_path,
                )
    data["file_path"] = file_path
    data["analysis_category"] = category
    data["analysis_timestamp"] = time.time()
    return data


def _call_llm_for_architecture(
    prompt: str,
    anthropic_client: Any,
    openai_client: Any,
    gemini_client: Any,
    grok_client: Any,
    on_debug: Callable[[str], None] | None,
    *,
    system_override: str | None = None,
    max_tokens: int = 4000,
) -> str | None:
    """Call configured providers in order and return first successful text response."""
    import httpx

    from codedd_cli.llm.key_manager import PROVIDER_MODELS

    system = system_override or (
        "You are a code analysis assistant that ONLY outputs valid JSON. "
        "No markdown, no explanations. Response must start with { and end with }."
    )
    timeout = 180.0

    def dbg(msg: str) -> None:
        if on_debug:
            on_debug(msg)
        logger.debug(msg)

    if anthropic_client:
        try:
            payload = {
                "model": PROVIDER_MODELS.get("anthropic", "claude-sonnet-4-6"),
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": "user", "content": prompt}],
            }
            resp = anthropic_client.post("/v1/messages", json=payload, timeout=timeout)
            if resp.status_code == 200:
                body = resp.json()
                blocks = body.get("content", [])
                parts = [b["text"] for b in blocks if b.get("type") == "text"]
                out = "\n".join(parts) if parts else None
                if out:
                    dbg("Anthropic: OK")
                    return out
            else:
                dbg(f"Anthropic: HTTP {resp.status_code}")
        except httpx.TimeoutException:
            dbg("Anthropic: timeout")
        except Exception as e:
            dbg(f"Anthropic: {e}")

    if openai_client:
        try:
            payload = {
                "model": PROVIDER_MODELS.get("openai", "gpt-5.2"),
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": max_tokens,
            }
            resp = openai_client.post("/v1/chat/completions", json=payload, timeout=timeout)
            if resp.status_code == 200:
                body = resp.json()
                choices = body.get("choices", [])
                if choices:
                    out = choices[0].get("message", {}).get("content")
                    if out:
                        dbg("OpenAI: OK")
                        return out
            else:
                dbg(f"OpenAI: HTTP {resp.status_code}")
        except httpx.TimeoutException:
            dbg("OpenAI: timeout")
        except Exception as e:
            dbg(f"OpenAI: {e}")

    if gemini_client:
        try:
            model = PROVIDER_MODELS.get("gemini", "gemini-3-flash-preview")
            payload = {"contents": [{"parts": [{"text": f"{system}\n\n{prompt}"}]}]}
            resp = gemini_client.post(f"/v1beta/models/{model}:generateContent", json=payload, timeout=timeout)
            if resp.status_code == 200:
                body = resp.json()
                candidates = body.get("candidates", [])
                parts = (((candidates or [{}])[0].get("content") or {}).get("parts") or [])
                out = "\n".join(
                    p.get("text", "")
                    for p in parts
                    if isinstance(p, dict) and p.get("text")
                ).strip()
                if out:
                    dbg("Gemini: OK")
                    return out
            else:
                dbg(f"Gemini: HTTP {resp.status_code}")
        except httpx.TimeoutException:
            dbg("Gemini: timeout")
        except Exception as e:
            dbg(f"Gemini: {e}")

    if grok_client:
        try:
            payload = {
                "model": PROVIDER_MODELS.get("grok", "grok-4.20-0309-reasoning"),
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": max_tokens,
            }
            resp = grok_client.post("/v1/chat/completions", json=payload, timeout=timeout)
            if resp.status_code == 200:
                body = resp.json()
                choices = body.get("choices", [])
                if choices:
                    out = choices[0].get("message", {}).get("content")
                    if out:
                        dbg("Grok: OK")
                        return out
            else:
                dbg(f"Grok: HTTP {resp.status_code}")
        except httpx.TimeoutException:
            dbg("Grok: timeout")
        except Exception as e:
            dbg(f"Grok: {e}")

    return None


# ---------------------------------------------------------------------------
#  Synthesis helpers — ported from server LLMAnalyzer
#  Build components, relationships, and insights from per-file analyses.
# ---------------------------------------------------------------------------

# Category-specific synthesis instructions.  Each value is a tuple of
# (title, focus_points, component_types, extra_schema_fields).
_SYNTHESIS_CATEGORY_META: dict[str, dict[str, Any]] = {
    "dependency_files": {
        "title": "DEPENDENCY COMPONENT SYNTHESIS",
        "focus": (
            "- Main programming language ecosystems\n"
            "- Core frameworks (web, data, testing)\n"
            "- Infrastructure dependencies\n"
            "- Development tools"
        ),
        "types": "framework|runtime|database|infrastructure|development_tool",
        "category_label": "dependency",
        "extra_fields": '"category_role": "backend_framework|frontend_framework|database|cache|testing",\n'
        '"key_dependencies": ["dep1", "dep2"],\n'
        '"architectural_role": "description of role in architecture"',
    },
    "infrastructure_files": {
        "title": "INFRASTRUCTURE COMPONENT SYNTHESIS",
        "focus": (
            "- Container services and their roles\n"
            "- Network configuration and service communication\n"
            "- Storage and persistence layers\n"
            "- Deployment orchestration"
        ),
        "types": "container_service|network_component|storage_component|orchestration",
        "category_label": "infrastructure",
        "extra_fields": '"services_managed": ["service1", "service2"],\n'
        '"deployment_pattern": "containerized|kubernetes|serverless",\n'
        '"communication_ports": ["8000", "5432"],\n'
        '"architectural_role": "description of deployment role"',
    },
    "backend_files": {
        "title": "BACKEND COMPONENT SYNTHESIS",
        "focus": (
            "- API services and endpoints\n"
            "- Business logic and data processing\n"
            "- External service integrations\n"
            "- Data access patterns"
        ),
        "types": "api_service|business_logic|data_access|integration_service",
        "category_label": "backend",
        "extra_fields": '"api_endpoints": ["/api/endpoint1", "/api/endpoint2"],\n'
        '"business_capabilities": ["capability1", "capability2"],\n'
        '"data_models": ["Model1", "Model2"],\n'
        '"architectural_role": "description of backend role"',
    },
    "frontend_files": {
        "title": "FRONTEND COMPONENT SYNTHESIS",
        "focus": (
            "- UI frameworks and component libraries\n"
            "- Routing and navigation systems\n"
            "- State management patterns\n"
            "- Build and bundling tools"
        ),
        "types": "ui_framework|component_library|routing_system|build_tool|state_management",
        "category_label": "frontend",
        "extra_fields": '"ui_components": ["Component1", "Component2"],\n'
        '"routing_patterns": ["/route1", "/route2"],\n'
        '"state_management": "redux|context|local",\n'
        '"architectural_role": "description of frontend role"',
    },
    "database_files": {
        "title": "DATABASE COMPONENT SYNTHESIS",
        "focus": (
            "- Database schemas and table structures\n"
            "- Data relationships and constraints\n"
            "- Data access patterns and ORM usage\n"
            "- Migration and versioning strategies"
        ),
        "types": "database_schema|data_model|migration_system|data_access",
        "category_label": "database",
        "extra_fields": '"data_entities": ["Entity1", "Entity2"],\n'
        '"relationships": ["entity1_to_entity2"],\n'
        '"access_patterns": ["orm", "raw_sql"],\n'
        '"architectural_role": "description of data role"',
    },
    "ci_cd_files": {
        "title": "CI/CD COMPONENT SYNTHESIS",
        "focus": (
            "- Build processes and automation\n"
            "- Deployment strategies and targets\n"
            "- Quality gates and testing integration\n"
            "- Artifact management and versioning"
        ),
        "types": "build_pipeline|deployment_pipeline|quality_gate|artifact_management",
        "category_label": "cicd",
        "extra_fields": '"pipeline_stages": ["build", "test", "deploy"],\n'
        '"deployment_targets": ["staging", "production"],\n'
        '"quality_gates": ["gate1", "gate2"],\n'
        '"architectural_role": "description of CI/CD role"',
    },
    "testing_files": {
        "title": "TESTING COMPONENT SYNTHESIS",
        "focus": (
            "- Testing frameworks and tools\n"
            "- Test coverage and scope\n"
            "- Quality gates and metrics\n"
            "- Test data management"
        ),
        "types": "test_framework|quality_gate|test_data_management|coverage_analysis",
        "category_label": "testing",
        "extra_fields": '"test_types": ["unit", "integration", "e2e"],\n'
        '"coverage_areas": ["area1", "area2"],\n'
        '"quality_metrics": ["coverage", "pass_rate"],\n'
        '"architectural_role": "description of testing role"',
    },
    "config_files": {
        "title": "CONFIGURATION COMPONENT SYNTHESIS",
        "focus": (
            "- Application settings and parameters\n"
            "- Environment-specific configurations\n"
            "- External service integrations\n"
            "- Security and credential management"
        ),
        "types": "app_configuration|environment_config|security_config|integration_config",
        "category_label": "config",
        "extra_fields": '"config_scope": ["application", "environment", "security"],\n'
        '"external_services": ["service1", "service2"],\n'
        '"security_features": ["feature1", "feature2"],\n'
        '"architectural_role": "description of configuration role"',
    },
    "api_schema_files": {
        "title": "API SCHEMA COMPONENT SYNTHESIS",
        "focus": (
            "- API endpoints and resource definitions\n"
            "- Authentication and authorization schemes\n"
            "- Request/response data models\n"
            "- API versioning and integration contracts"
        ),
        "types": "rest_api|graphql_api|grpc_service|websocket_api|api_gateway",
        "category_label": "api_schema",
        "extra_fields": '"endpoints": ["/api/v1/resource"],\n'
        '"auth_schemes": ["jwt", "oauth2"],\n'
        '"api_version": "v1",\n'
        '"architectural_role": "description of API contract role"',
    },
    "monitoring_files": {
        "title": "MONITORING COMPONENT SYNTHESIS",
        "focus": (
            "- Metrics collection and dashboards\n"
            "- Alerting rules and notification channels\n"
            "- Log aggregation and tracing pipelines\n"
            "- Observability infrastructure"
        ),
        "types": "metrics_collector|alerting_system|log_aggregator|tracing_system|dashboard",
        "category_label": "monitoring",
        "extra_fields": '"metrics_collected": ["cpu", "memory", "latency"],\n'
        '"alert_channels": ["email", "slack"],\n'
        '"dashboards": ["service_health"],\n'
        '"architectural_role": "description of observability role"',
    },
    "message_queue_files": {
        "title": "MESSAGE QUEUE COMPONENT SYNTHESIS",
        "focus": (
            "- Message brokers and queuing systems\n"
            "- Topics, exchanges, and routing patterns\n"
            "- Producer and consumer configurations\n"
            "- Async processing and event-driven patterns"
        ),
        "types": "message_broker|event_bus|task_queue|pub_sub_system",
        "category_label": "messaging",
        "extra_fields": '"broker_type": "rabbitmq|kafka|redis|celery",\n'
        '"topics_exchanges": ["topic1", "exchange1"],\n'
        '"processing_patterns": ["async", "pub_sub"],\n'
        '"architectural_role": "description of messaging role"',
    },
    "security_auth_files": {
        "title": "SECURITY & AUTH COMPONENT SYNTHESIS",
        "focus": (
            "- Authentication mechanisms and identity providers\n"
            "- Authorization and access control policies\n"
            "- Token management and session handling\n"
            "- Security controls and compliance settings"
        ),
        "types": "auth_provider|access_control|security_policy|token_service",
        "category_label": "security",
        "extra_fields": '"auth_mechanisms": ["jwt", "oauth2", "session"],\n'
        '"security_features": ["cors", "csrf", "rate_limiting"],\n'
        '"identity_providers": ["keycloak", "auth0"],\n'
        '"architectural_role": "description of security role"',
    },
}

_JSON_CRITICAL_RULES = (
    "**CRITICAL JSON FORMATTING REQUIREMENTS:**\n"
    "1. Return ONLY valid JSON inside ```json code blocks\n"
    "2. Do NOT include actual newlines in string values - use spaces instead\n"
    "3. Keep all descriptions on single lines (no multi-line strings)\n"
    "4. Ensure all strings are properly quoted with double quotes\n"
    "5. Remove any trailing commas before closing braces or brackets\n"
    "6. Validate your JSON structure before responding"
)


def _safe_join(items: list, max_items: int = 5) -> str:
    """Format a list of strings or dicts into a comma-separated preview."""
    if not items:
        return "None identified"
    parts: list[str] = []
    for item in items[:max_items]:
        if isinstance(item, dict):
            name = (
                item.get("name")
                or item.get("path")
                or item.get("endpoint")
                or item.get("service")
                or item.get("component")
                or item.get("route")
                or item.get("table")
                or item.get("stage")
                or item.get("target")
                or item.get("type")
                or item.get("setting")
                or item.get("variable")
                or item.get("technology")
                or item.get("framework")
                or item.get("migration")
                or item.get("test")
                or str(item)
            )
            parts.append(str(name))
        else:
            parts.append(str(item))
    return ", ".join(parts) if parts else "None identified"


def _format_analyses_for_prompt(category_analyses: list[dict[str, Any]]) -> str:
    """Format per-file analyses for inclusion in category synthesis prompts."""
    formatted: list[str] = []
    for i, analysis in enumerate(category_analyses[:10]):
        if not isinstance(analysis, dict):
            continue
        file_path = analysis.get("file_path", "unknown")
        file_name = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
        ft = analysis.get("file_type", "")

        if ft == "infrastructure_config" or "docker-compose" in file_name.lower():
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Services Defined: {_safe_join(analysis.get('services_defined', []), 8)}\n"
                f"- Ports Exposed: {_safe_join(analysis.get('ports_exposed', []))}\n"
                f"- Service Dependencies: {len(analysis.get('dependencies_between_services', []))} dependencies\n"
                f"- Deployment Pattern: {analysis.get('deployment_pattern', 'unknown')}"
            )
        elif ft == "backend_code":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- API Endpoints: {_safe_join(analysis.get('api_endpoints', []))}\n"
                f"- Data Models: {_safe_join(analysis.get('data_models', []), 3)}\n"
                f"- Business Logic: {_safe_join(analysis.get('business_logic', []), 3)}\n"
                f"- External Integrations: {_safe_join(analysis.get('external_integrations', []), 3)}"
            )
        elif ft == "frontend_code":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- UI Components: {_safe_join(analysis.get('ui_components', []))}\n"
                f"- Routing Config: {_safe_join(analysis.get('routing_config', []), 3)}\n"
                f"- State Management: {_safe_join(analysis.get('state_management', []), 3)}\n"
                f"- API Interactions: {_safe_join(analysis.get('api_interactions', []), 3)}\n"
                f"- Styling Approach: {analysis.get('styling_approach', 'unknown')}"
            )
        elif ft in ("database_schema", "migration"):
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Tables/Schemas: {_safe_join(analysis.get('tables_schemas', []))}\n"
                f"- Relationships: {_safe_join(analysis.get('relationships', []), 3)}\n"
                f"- Indexes: {_safe_join(analysis.get('indexes', []), 3)}\n"
                f"- Migrations: {_safe_join(analysis.get('migrations', []), 3)}\n"
                f"- Database Type: {analysis.get('database_type', 'unknown')}"
            )
        elif ft == "ci_cd_pipeline":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Pipeline Stages: {_safe_join(analysis.get('pipeline_stages', []))}\n"
                f"- Deployment Targets: {_safe_join(analysis.get('deployment_targets', []), 3)}\n"
                f"- Testing Automation: {_safe_join(analysis.get('testing_automation', []), 3)}\n"
                f"- Build Processes: {_safe_join(analysis.get('build_processes', []), 3)}\n"
                f"- Pipeline Platform: {analysis.get('pipeline_platform', 'unknown')}"
            )
        elif ft in ("test_config", "test_suite"):
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Test Types: {_safe_join(analysis.get('test_types', []))}\n"
                f"- Coverage Areas: {_safe_join(analysis.get('test_coverage_areas', []), 3)}\n"
                f"- Testing Environments: {_safe_join(analysis.get('testing_environments', []), 3)}\n"
                f"- Automation Config: {_safe_join(analysis.get('automation_config', []), 3)}\n"
                f"- Testing Framework: {analysis.get('testing_framework', 'unknown')}"
            )
        elif ft in ("application_config", "environment_config"):
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Application Settings: {_safe_join(analysis.get('application_settings', []))}\n"
                f"- Environment Variables: {_safe_join(analysis.get('environment_variables', []), 3)}\n"
                f"- External Service Config: {_safe_join(analysis.get('external_service_config', []), 3)}\n"
                f"- Security Settings: {_safe_join(analysis.get('security_settings', []), 3)}\n"
                f"- Config Purpose: {analysis.get('config_purpose', 'unknown')}"
            )
        elif ft == "api_schema":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- API Spec Type: {analysis.get('api_spec_type', 'unknown')}\n"
                f"- Endpoints: {_safe_join(analysis.get('endpoints', []))}\n"
                f"- Auth Schemes: {_safe_join(analysis.get('authentication_schemes', []), 3)}\n"
                f"- Data Models: {_safe_join(analysis.get('data_models', []), 3)}\n"
                f"- API Version: {analysis.get('api_version', 'unknown')}"
            )
        elif ft == "monitoring_config":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Monitoring Type: {analysis.get('monitoring_type', 'unknown')}\n"
                f"- Metrics Collected: {_safe_join(analysis.get('metrics_collected', []))}\n"
                f"- Alerts Defined: {_safe_join(analysis.get('alerts_defined', []), 3)}\n"
                f"- Data Sources: {_safe_join(analysis.get('data_sources', []), 3)}\n"
                f"- Notification Channels: {_safe_join(analysis.get('notification_channels', []), 3)}"
            )
        elif ft == "message_queue_config":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Broker Type: {analysis.get('broker_type', 'unknown')}\n"
                f"- Queues/Topics: {_safe_join(analysis.get('queues_topics', []))}\n"
                f"- Consumers: {_safe_join(analysis.get('consumers', []), 3)}\n"
                f"- Producers: {_safe_join(analysis.get('producers', []), 3)}\n"
                f"- Processing Patterns: {_safe_join(analysis.get('processing_patterns', []), 3)}"
            )
        elif ft == "auth_security_config":
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Auth Type: {analysis.get('auth_type', 'unknown')}\n"
                f"- Identity Providers: {_safe_join(analysis.get('identity_providers', []))}\n"
                f"- Security Mechanisms: {_safe_join(analysis.get('security_mechanisms', []), 3)}\n"
                f"- Token Configuration: {_safe_join(analysis.get('token_configuration', []), 3)}\n"
                f"- CORS/Rate Limiting: "
                f"{_safe_join(analysis.get('cors_settings', []) + analysis.get('rate_limiting', []), 3)}"
            )
        else:
            text = (
                f"**File {i + 1}: {file_name}**\n"
                f"- Technologies: {_safe_join(analysis.get('tech_stack', []))}\n"
                f"- Frameworks: {_safe_join(analysis.get('frameworks', []), 3)}\n"
                f"- Key Functions: {_safe_join(analysis.get('key_functions', []), 3)}"
            )
        formatted.append(text)

    if len(category_analyses) > 10:
        formatted.append(f"\n... and {len(category_analyses) - 10} more files")
    return "\n\n".join(formatted)


def _build_category_synthesis_prompt(
    category: str,
    category_analyses: list[dict[str, Any]],
) -> str:
    """Build the LLM prompt that synthesises components for one category."""
    meta = _SYNTHESIS_CATEGORY_META.get(category)
    formatted_analyses = _format_analyses_for_prompt(category_analyses)

    if not meta:
        return (
            f"# GENERIC COMPONENT SYNTHESIS\n\n"
            f"Analyze these {len(category_analyses)} {category} files:\n\n"
            f"## DETAILED FILE ANALYSES:\n{formatted_analyses}\n\n"
            f"Create relevant architectural components based on the analysis.\n\n"
            f"{_JSON_CRITICAL_RULES}"
        )

    return (
        f"# {meta['title']}\n\n"
        f"Analyze these {len(category_analyses)} {category.replace('_', ' ')} files to create "
        f"architectural components:\n\n"
        f"## DETAILED FILE ANALYSES:\n{formatted_analyses}\n\n"
        f"**Create components that represent the architecture. Focus on:**\n"
        f"{meta['focus']}\n\n"
        f"**Output Format:**\n"
        f"```json\n"
        f"{{\n"
        f'  "component_name": {{\n'
        f'    "name": "component_name",\n'
        f'    "type": "{meta["types"]}",\n'
        f'    "category": "{meta["category_label"]}",\n'
        f'    "description": "Detailed description of the component",\n'
        f'    "technologies": ["tech1", "tech2"],\n'
        f'    "responsibilities": ["responsibility1", "responsibility2"],\n'
        f'    "key_files": ["file1.ext", "file2.ext"],\n'
        f'    "confidence": 85,\n'
        f'    "evidence_sources": ["{category.replace("_files", "")}_analysis"],\n'
        f"    {meta['extra_fields']}\n"
        f"  }}\n"
        f"}}\n"
        f"```\n\n"
        f"{_JSON_CRITICAL_RULES}"
    )


def _parse_category_synthesis_response(llm_response: str) -> dict[str, Any]:
    """Extract component dict from LLM synthesis response JSON."""
    try:
        m = re.search(r"```json\s*(\{.*?\})\s*```", llm_response, re.DOTALL)
        if m:
            json_str = m.group(1)
        else:
            m2 = re.search(r"(\{.*\})", llm_response, re.DOTALL)
            if m2:
                json_str = m2.group(1)
            else:
                return {}
        # Fix trailing commas
        json_str = re.sub(r",(\s*[}\]])", r"\1", json_str)
        components = json.loads(json_str)
        return components if isinstance(components, dict) else {}
    except json.JSONDecodeError:
        raise  # let caller retry
    except Exception:
        return {}


def _build_relationship_prompt(
    architectural_components: dict[str, Any],
    category_analyses: dict[str, list[dict[str, Any]]],
) -> str:
    """Build the LLM prompt for extracting relationships between components."""
    cap = 10
    api_calls: list[Any] = []
    database_interactions: list[Any] = []
    service_dependencies: list[Any] = []
    for analyses in category_analyses.values():
        for analysis in analyses:
            if len(api_calls) < cap:
                if "api_interactions" in analysis:
                    api_calls.extend(analysis["api_interactions"][: cap - len(api_calls)])
                elif "api_endpoints" in analysis:
                    api_calls.extend(
                        [{"endpoint": ep.get("path", "")} for ep in analysis["api_endpoints"]][
                            : cap - len(api_calls)
                        ]
                    )
            if len(database_interactions) < cap and "database_interactions" in analysis:
                database_interactions.extend(
                    analysis["database_interactions"][: cap - len(database_interactions)]
                )
            if len(service_dependencies) < cap:
                if "dependencies_between_services" in analysis:
                    service_dependencies.extend(
                        analysis["dependencies_between_services"][: cap - len(service_dependencies)]
                    )
                elif "external_integrations" in analysis:
                    service_dependencies.extend(
                        analysis["external_integrations"][: cap - len(service_dependencies)]
                    )

    return (
        "Based on the identified architectural components and file analysis data, "
        "determine how these components interact with each other.\n\n"
        f"## ARCHITECTURAL COMPONENTS:\n{json.dumps(architectural_components, indent=2)}\n\n"
        f"## INTERACTION DATA:\n"
        f"API Calls/Endpoints: {json.dumps(api_calls, indent=2)}\n"
        f"Database Interactions: {json.dumps(database_interactions, indent=2)}\n"
        f"Service Dependencies: {json.dumps(service_dependencies, indent=2)}\n\n"
        "Identify relationships between components focusing on:\n"
        "1. **Data Flow** - How data moves between components\n"
        "2. **API Dependencies** - Which components call which APIs\n"
        "3. **Database Access** - Which components access which databases\n"
        "4. **Service Communications** - How services communicate\n"
        "5. **Deployment Dependencies** - Which components depend on others\n\n"
        "IMPORTANT: Respond with ONLY a JSON object in this EXACT format "
        "(no markdown, no explanations):\n\n"
        "{\n"
        '  "relationships": [\n'
        "    {\n"
        '      "source": "source_component_name",\n'
        '      "target": "target_component_name",\n'
        '      "type": "api_call|data_access|dependency|communication|deployment_dependency|message_passing",\n'
        '      "description": "Clear description of how source interacts with target (max 100 characters)",\n'
        '      "strength": "high|medium|low"\n'
        "    }\n"
        "  ]\n"
        "}\n\n"
        "Generate 3-15 meaningful relationships based on the component data above. "
        "Use exact component names from the ARCHITECTURAL COMPONENTS list.\n\n"
        f"{_JSON_CRITICAL_RULES}"
    )


def _parse_relationship_response(llm_response: str) -> list[dict[str, Any]]:
    """Parse component relationships from LLM response."""
    try:
        start = llm_response.find("{")
        end = llm_response.rfind("}") + 1
        if start == -1 or end <= start:
            return []
        raw = llm_response[start:end]
        raw = re.sub(r",(\s*[}\]])", r"\1", raw)
        parsed = json.loads(raw)
        rels: list[dict[str, Any]] = []
        for rel in parsed.get("relationships", []):
            src = rel.get("source", "")
            tgt = rel.get("target", "")
            if src and tgt:
                rels.append(
                    {
                        "source": src,
                        "target": tgt,
                        "type": rel.get("type", "unknown"),
                        "description": rel.get("description", "")[:200],
                        "strength": rel.get("strength", "medium"),
                    }
                )
        return rels
    except (json.JSONDecodeError, Exception):
        return []


def _create_fallback_relationships(
    architectural_components: dict[str, Any],
) -> list[dict[str, Any]]:
    """Basic fallback relationships when LLM extraction fails."""
    rels: list[dict[str, Any]] = []
    keys = list(architectural_components.keys())
    if len(keys) < 2:
        return rels
    if "core_application" in keys and "configuration_management" in keys:
        rels.append(
            {
                "source": "core_application",
                "target": "configuration_management",
                "type": "uses",
                "description": "Core application uses configuration management for settings",
                "strength": "high",
            }
        )
    if "testing_framework" in keys and "core_application" in keys:
        rels.append(
            {
                "source": "testing_framework",
                "target": "core_application",
                "type": "tests",
                "description": "Testing framework validates core application functionality",
                "strength": "medium",
            }
        )
    return rels


def _extract_architectural_insights(
    architectural_components: dict[str, Any],
    component_relationships: list[dict[str, Any]],
) -> dict[str, Any]:
    """Derive insights deterministically from components and relationships."""
    insights: dict[str, Any] = {
        "technology_stack": [],
        "architectural_patterns": [],
        "service_architecture": "",
        "data_architecture": "unknown",
        "deployment_approach": "",
        "development_practices": [],
        "coupling_analysis": {},
        "communication_patterns": {},
        "critical_dependencies": [],
    }
    all_tech: set[str] = set()
    for comp in architectural_components.values():
        all_tech.update(comp.get("technologies", []))
    insights["technology_stack"] = sorted(all_tech)

    patterns: set[str] = set()
    backend_services = [c for c in architectural_components.values() if c.get("category") == "backend"]
    if len(backend_services) > 1:
        insights["service_architecture"] = "microservices"
        patterns.add("Microservices Architecture")
    else:
        insights["service_architecture"] = "monolithic"
        patterns.add("Monolithic Architecture")

    if "Docker" in all_tech or "Kubernetes" in all_tech:
        patterns.add("Containerized Deployment")
    if "Redis" in all_tech or "RabbitMQ" in all_tech:
        patterns.add("Message Queue Pattern")
    if any("REST" in t for t in all_tech):
        patterns.add("RESTful API Design")
    insights["architectural_patterns"] = sorted(patterns)

    infra = [c for c in architectural_components.values() if c.get("category") == "infrastructure"]
    if any("kubernetes" in c.get("name", "").lower() for c in infra):
        insights["deployment_approach"] = "kubernetes"
    elif any("docker" in c.get("name", "").lower() for c in infra):
        insights["deployment_approach"] = "containerized"
    else:
        insights["deployment_approach"] = "traditional"

    return insights


def _build_executive_summary_prompt(
    architectural_components: dict[str, Any],
    component_relationships: list[dict[str, Any]],
    insights: dict[str, Any],
) -> str:
    """Build prompt for executive summary generation."""
    security_highlights: list[str] = []
    cicd_present = any(c.get("category") == "cicd" for c in architectural_components.values())
    testing_present = any(c.get("category") == "testing" for c in architectural_components.values())
    for comp in architectural_components.values():
        for tech in comp.get("technologies", []):
            name = str(tech).lower()
            if any(kw in name for kw in ("jwt", "oauth", "saml", "csrf", "security", "auth")):
                security_highlights.append(tech)
    security_highlights = list(set(security_highlights))[:10]

    return (
        "Create a concise executive summary of this software architecture based on "
        "the following analysis:\n\n"
        f"ARCHITECTURAL COMPONENTS ({len(architectural_components)}):\n"
        f"{json.dumps(architectural_components, indent=2)}\n\n"
        f"COMPONENT RELATIONSHIPS ({len(component_relationships)}):\n"
        f"{json.dumps(component_relationships, indent=2)}\n\n"
        f"IDENTIFIED PATTERNS:\n"
        f"- Service Architecture: {insights.get('service_architecture', 'unknown')}\n"
        f"- Deployment Approach: {insights.get('deployment_approach', 'unknown')}\n"
        f"- Technology Stack: {', '.join(insights.get('technology_stack', [])[:8])}\n"
        f"- Architectural Patterns: {', '.join(insights.get('architectural_patterns', []))}\n\n"
        f"SECURITY HIGHLIGHTS:\n"
        f"{', '.join(security_highlights) if security_highlights else 'None detected'}\n\n"
        f"CI/CD PIPELINE PRESENT: {cicd_present}\n"
        f"AUTOMATED TESTING PRESENT: {testing_present}\n\n"
        "**CRITICAL INSTRUCTIONS - MARKDOWN FORMAT REQUIRED:**\n\n"
        "Provide an executive summary in **pure Markdown format**.\n"
        "- DO NOT wrap the response in JSON\n"
        "- Start directly with Markdown headings and content\n"
        "- Use Markdown syntax: # for headings, - for bullets, ** for bold\n"
        "- Maximum length: 500 words\n\n"
        "Cover at least:\n"
        "1. Overall architecture style and approach\n"
        "2. Key technologies and frameworks used\n"
        "3. Main architectural strengths or notable patterns\n"
        "4. Deployment and scalability approach\n"
        "5. Security posture and critical dependencies\n"
        "6. CI/CD & testing maturity (if data available)\n\n"
        "Return ONLY the Markdown content, nothing else."
    )


def _extract_markdown_from_response(response: str) -> str:
    """Clean up LLM response to extract pure Markdown content."""
    text = response.strip()
    if text.startswith("{") and text.endswith("}"):
        try:
            parsed = json.loads(text)
            for key in ("executive_summary", "summary", "markdown", "content", "text", "description"):
                if key in parsed and isinstance(parsed[key], str):
                    return parsed[key].strip()
        except json.JSONDecodeError:
            pass
    if "```" in text:
        m = re.search(r"```(?:markdown|md)?\s*(.*?)\s*```", text, re.DOTALL)
        if m:
            return m.group(1).strip()
    return text


def _are_components_similar(name1: str, data1: dict, name2: str, data2: dict) -> bool:
    """Check if two components should be merged (name overlap or tech overlap)."""
    words1 = set(name1.lower().split("_"))
    words2 = set(name2.lower().split("_"))
    if len(words1 & words2) >= 2:
        return True
    tech1 = set(data1.get("technologies", []))
    tech2 = set(data2.get("technologies", []))
    if len(tech1 & tech2) >= 2:
        return True
    t1, t2 = data1.get("type", ""), data2.get("type", "")
    if t1 == t2 and t1:
        return True
    return False


def _merge_and_deduplicate_components(all_components: dict[str, Any]) -> dict[str, Any]:
    """Merge similar components and remove duplicates."""
    processed: set[str] = set()
    groups: dict[str, list[str]] = {}
    for name, data in all_components.items():
        if name in processed:
            continue
        group = [name]
        for other, odata in all_components.items():
            if other != name and other not in processed:
                if _are_components_similar(name, data, other, odata):
                    group.append(other)
        best = max(group, key=lambda n: all_components[n].get("confidence", 0))
        groups[best] = group
        processed.update(group)

    final: dict[str, Any] = {}
    for rep, members in groups.items():
        merged = all_components[rep].copy()
        all_tech: set[str] = set(merged.get("technologies", []))
        all_evidence: set[str] = set(merged.get("evidence_sources", []))
        max_conf = merged.get("confidence", 0)
        for m in members[1:] if members[0] == rep else members:
            if m == rep:
                continue
            md = all_components[m]
            all_tech.update(md.get("technologies", []))
            all_evidence.update(md.get("evidence_sources", []))
            mc = md.get("confidence", 0)
            if mc > max_conf:
                max_conf = mc
        merged["technologies"] = sorted(all_tech)
        merged["evidence_sources"] = sorted(all_evidence)
        merged["confidence"] = max_conf
        if len(members) > 1:
            merged["merged_from"] = [m for m in members if m != rep]
        final[rep] = merged
    return final


def synthesize_components_locally(
    category_analyses: dict[str, list[dict[str, Any]]],
    anthropic_client: Any = None,
    openai_client: Any = None,
    on_progress: Callable[[str], None] | None = None,
    on_debug: Callable[[str], None] | None = None,
    *,
    anthropic_key: str | None = None,
    openai_key: str | None = None,
    gemini_key: str | None = None,
    grok_key: str | None = None,
    max_workers: int = 4,
) -> dict[str, Any]:
    """
    Run the full synthesis pipeline locally: category synthesis (parallelised),
    relationship extraction, insights and executive summary.

    Accepts either pre-built ``anthropic_client``/``openai_client`` (legacy) or
    raw ``anthropic_key``/``openai_key`` strings.  When keys are supplied each
    parallel worker creates its own httpx.Client instance, which is required for
    thread safety.

    Returns a dict with keys ``architectural_components``,
    ``component_relationships`` and ``architectural_insights``.
    """

    def prog(msg: str) -> None:
        if on_progress:
            on_progress(msg)

    # --- Step 1: Synthesise components per category (parallel) ---
    all_components: dict[str, Any] = {}
    categories_processed: list[str] = []

    active_categories = [cat for cat in ARCHITECTURE_CATEGORIES if category_analyses.get(cat)]
    prog(f"Synthesising {len(active_categories)} categories...")

    components_lock = threading.Lock()

    def _synthesise_category(category: str) -> tuple[str, dict[str, Any]]:
        analyses = category_analyses[category]
        prog(f"  {category} ({len(analyses)} files)...")
        prompt = _build_category_synthesis_prompt(category, analyses)

        # Each worker needs its own clients when running in a thread.
        if anthropic_key or openai_key or gemini_key or grok_key:
            a_client, o_client, g_client, x_client = _make_llm_clients(
                anthropic_key,
                openai_key,
                gemini_key,
                grok_key,
            )
        else:
            # Legacy: use the pre-built clients (single-threaded path)
            a_client, o_client, g_client, x_client = anthropic_client, openai_client, None, None

        try:
            for attempt in range(3):
                raw = _call_llm_for_architecture(prompt, a_client, o_client, g_client, x_client, on_debug)
                if not raw:
                    time.sleep(2)
                    continue
                try:
                    result = _parse_category_synthesis_response(raw)
                except json.JSONDecodeError:
                    time.sleep(2)
                    continue
                if result:
                    return category, result
                time.sleep(2)
            return category, {}
        finally:
            if (anthropic_key or openai_key or gemini_key or grok_key):
                if a_client:
                    a_client.close()
                if o_client:
                    o_client.close()
                if g_client:
                    g_client.close()
                if x_client:
                    x_client.close()

    cat_workers = max(1, min(max_workers, len(active_categories)))
    with ThreadPoolExecutor(max_workers=cat_workers) as executor:
        cat_futures = {
            executor.submit(_synthesise_category, cat): cat
            for cat in active_categories
        }
        for future in as_completed(cat_futures):
            try:
                category, components = future.result()
                if components:
                    with components_lock:
                        all_components.update(components)
                        categories_processed.append(category)
                    prog(f"  {category}: {len(components)} components")
            except Exception as exc:
                logger.warning("Category synthesis worker failed: %s", exc)

    if all_components:
        all_components = _merge_and_deduplicate_components(all_components)
    prog(f"Components: {len(all_components)} (from {len(categories_processed)} categories)")

    # Steps 2 and 4 are sequential (each depends on prior output).
    # Create one shared client pair for these calls.
    seq_a, seq_o, seq_g, seq_x = (
        _make_llm_clients(anthropic_key, openai_key, gemini_key, grok_key)
        if (anthropic_key or openai_key or gemini_key or grok_key)
        else (anthropic_client, openai_client, None, None)
    )

    try:
        # --- Step 2: Extract relationships between components ---
        component_relationships: list[dict[str, Any]] = []
        if all_components:
            prog("Extracting component relationships...")
            rel_prompt = _build_relationship_prompt(all_components, category_analyses)
            raw = _call_llm_for_architecture(rel_prompt, seq_a, seq_o, seq_g, seq_x, on_debug)
            if raw:
                component_relationships = _parse_relationship_response(raw)
            if not component_relationships:
                component_relationships = _create_fallback_relationships(all_components)
            prog(f"Relationships: {len(component_relationships)}")

        # --- Step 3: Derive insights (deterministic) ---
        insights = _extract_architectural_insights(all_components, component_relationships)

        # --- Step 4: Generate executive summary (LLM) ---
        if all_components:
            prog("Generating executive summary...")
            summary_prompt = _build_executive_summary_prompt(
                all_components,
                component_relationships,
                insights,
            )
            summary_system = (
                "You are a software architecture analyst that produces clear, concise "
                "Markdown executive summaries. Respond ONLY with Markdown content."
            )
            raw = _call_llm_for_architecture(
                summary_prompt,
                seq_a,
                seq_o,
                seq_g,
                seq_x,
                on_debug,
                system_override=summary_system,
                max_tokens=2000,
            )
            if raw:
                insights["executive_summary"] = _extract_markdown_from_response(raw)
            else:
                insights["executive_summary"] = (
                    f"Architecture consists of {len(all_components)} main components "
                    f"using {insights.get('service_architecture', 'unknown')} architecture pattern."
                )
        else:
            insights["executive_summary"] = "No architectural components identified."
    finally:
        if anthropic_key or openai_key or gemini_key or grok_key:
            if seq_a:
                seq_a.close()
            if seq_o:
                seq_o.close()
            if seq_g:
                seq_g.close()
            if seq_x:
                seq_x.close()

    return {
        "architectural_components": all_components,
        "component_relationships": component_relationships,
        "architectural_insights": insights,
    }


def _analyze_single_file(
    file_path: str,
    local_path: str,
    category: str,
    anthropic_client: Any,
    openai_client: Any,
    gemini_client: Any,
    grok_client: Any,
    on_debug: Callable[[str], None] | None,
) -> dict[str, Any] | None:
    """Read file, build prompt, call LLM, parse. Returns analysis dict or None."""
    content = _read_file_safely_local(local_path)
    if not content:
        return None
    prompt = _build_analysis_prompt(file_path, content, category)
    for attempt in range(3):
        response = _call_llm_for_architecture(
            prompt,
            anthropic_client,
            openai_client,
            gemini_client,
            grok_client,
            on_debug,
        )
        if not response:
            time.sleep(2)
            continue
        parsed = _parse_llm_response(response, file_path, category)
        if parsed:
            return parsed
        time.sleep(2)
    return None


def _make_llm_clients(
    anthropic_key: str | None,
    openai_key: str | None,
    gemini_key: str | None,
    grok_key: str | None,
) -> tuple[Any, Any, Any, Any]:
    """
    Create a fresh pair of httpx.Client instances bound to the caller's thread.
    Each concurrent worker must call this independently — httpx.Client is NOT
    safe to share across threads.  Callers are responsible for closing both.
    """
    import httpx

    a_client = None
    o_client = None
    g_client = None
    x_client = None
    if anthropic_key:
        a_client = httpx.Client(
            base_url="https://api.anthropic.com",
            headers={
                "x-api-key": anthropic_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            timeout=180.0,
        )
    if openai_key:
        o_client = httpx.Client(
            base_url="https://api.openai.com",
            headers={
                "Authorization": f"Bearer {openai_key}",
                "Content-Type": "application/json",
            },
            timeout=180.0,
        )
    if gemini_key:
        g_client = httpx.Client(
            base_url="https://generativelanguage.googleapis.com",
            headers={
                "x-goog-api-key": gemini_key,
                "Content-Type": "application/json",
            },
            timeout=180.0,
        )
    if grok_key:
        x_client = httpx.Client(
            base_url="https://api.x.ai",
            headers={
                "Authorization": f"Bearer {grok_key}",
                "Content-Type": "application/json",
            },
            timeout=180.0,
        )
    return a_client, o_client, g_client, x_client


def run_phase2_with_llm(
    phase1_results: dict[str, Any],
    scope_dirs: dict[str, str],
    sub_audit_uuid: str,
    repo_name: str,
    detector_config: dict[str, Any] | None = None,
    on_progress: Callable[[str], None] | None = None,
    on_debug: Callable[[str], None] | None = None,
    max_workers: int = 4,
) -> dict[str, Any]:
    """
    Run full Phase 2: per-file LLM analysis using local paths from scope_dirs.

    Files are analysed in parallel (up to *max_workers* concurrent LLM calls).
    Each worker owns its own httpx.Client instances to avoid sharing state across
    threads.  Synthesis (Phase 2.5) also parallelises category-level LLM calls.

    Resolves cli://sub_audit_uuid/repo_name/rel paths to local paths.
    Returns phase2 dict with category_analyses populated; server handles Phase 3.
    """
    from codedd_cli.llm.key_manager import LLMKeyManager

    key_mgr = LLMKeyManager()
    anthropic_key = key_mgr.retrieve_key("anthropic")
    openai_key = key_mgr.retrieve_key("openai")
    gemini_key = key_mgr.retrieve_key("gemini")
    grok_key = key_mgr.retrieve_key("grok")
    if not anthropic_key and not openai_key and not gemini_key and not grok_key:
        if on_debug:
            on_debug("No LLM keys configured — skipping Phase 2 LLM analysis")
        return build_phase2_results_empty("No LLM keys; run codedd llm set-key")

    local_base = scope_dirs.get(repo_name, "")
    if not local_base or not os.path.isdir(local_base):
        if on_debug:
            on_debug("No local scope for repo — skipping Phase 2 LLM")
        return build_phase2_results_empty("No local scope for repo")

    prefix = f"cli://{sub_audit_uuid}/{repo_name}/"
    file_categories = phase1_results.get("file_categories") or {}
    if not file_categories:
        return build_phase2_results_empty("No file categories in Phase 1")

    # Build a flat work list: (category, cli_path, local_path)
    work_items: list[tuple[str, str, str]] = []
    for category, files in file_categories.items():
        if category not in CATEGORY_PROMPTS or not files:
            continue
        for file_path in files:
            if not file_path.startswith(prefix):
                continue
            rel = file_path[len(prefix):].lstrip("/")
            local_path = os.path.normpath(os.path.join(local_base, rel))
            if os.path.isfile(local_path):
                work_items.append((category, file_path, local_path))

    total_files = len(work_items)
    category_analyses: dict[str, list[dict[str, Any]]] = {c: [] for c in ARCHITECTURE_CATEGORIES}
    done_counter = [0]
    progress_lock = threading.Lock()
    results_lock = threading.Lock()

    if on_progress:
        on_progress(
            f"Architecture Phase 2: queued {total_files} categorized files for LLM analysis."
        )

    # Report which categories are being processed before dispatching
    for cat in ARCHITECTURE_CATEGORIES:
        count = sum(1 for c, _, _ in work_items if c == cat)
        if count and on_progress:
            on_progress(f"Category {cat}: {count} files queued.")

    def _analyse_item(item: tuple[str, str, str]) -> tuple[str, dict[str, Any] | None]:
        cat, fp, lp = item
        # Each worker creates its own clients — httpx.Client is not thread-safe.
        a_client, o_client, g_client, x_client = _make_llm_clients(
            anthropic_key,
            openai_key,
            gemini_key,
            grok_key,
        )
        try:
            result = _analyze_single_file(fp, lp, cat, a_client, o_client, g_client, x_client, on_debug)
            with progress_lock:
                done_counter[0] += 1
                done = done_counter[0]
            if on_progress and done % 5 == 0:
                on_progress(f"Phase 2 LLM progress: {done}/{total_files} categorized files.")
            return cat, result
        finally:
            if a_client:
                a_client.close()
            if o_client:
                o_client.close()
            if g_client:
                g_client.close()
            if x_client:
                x_client.close()

    workers = max(1, min(max_workers, total_files)) if total_files else 1
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_analyse_item, item): item for item in work_items}
        for future in as_completed(futures):
            try:
                cat, result = future.result()
                if result:
                    with results_lock:
                        category_analyses.setdefault(cat, []).append(result)
            except Exception as exc:
                logger.warning("Architecture per-file worker failed: %s", exc)

    if on_progress:
        on_progress(
            f"Phase 2 LLM completed: {done_counter[0]}/{total_files} categorized files analysed."
        )

    categories_with_results = [c for c, lst in category_analyses.items() if lst]

    # --- Phase 2.5: Synthesise components, relationships, insights locally ---
    if categories_with_results:
        if on_progress:
            on_progress("Synthesising architecture (components, relationships, insights)...")
        synthesis = synthesize_components_locally(
            category_analyses,
            anthropic_key=anthropic_key,
            openai_key=openai_key,
            gemini_key=gemini_key,
            grok_key=grok_key,
            on_progress=on_progress,
            on_debug=on_debug,
            max_workers=max_workers,
        )
    else:
        synthesis = {
            "architectural_components": {},
            "component_relationships": [],
            "architectural_insights": {
                "technology_stack": [],
                "architectural_patterns": [],
                "service_architecture": "unknown",
                "data_architecture": "unknown",
                "deployment_approach": "unknown",
                "development_practices": [],
                "coupling_analysis": {},
                "communication_patterns": {},
                "critical_dependencies": [],
                "executive_summary": "No file categories with results for synthesis.",
            },
        }

    enhanced_technology_detection = {
        "detected_technologies": {},
        "relationship_map": {},
        "technology_count": 0,
        "relationship_count": 0,
    }
    enhanced_relationship_analysis = {
        "relationships": {},
        "component_graph": {},
        "architectural_patterns": [],
        "coupling_analysis": {},
        "communication_patterns": {},
        "critical_dependencies": [],
        "relationship_count": 0,
        "component_count": 0,
    }
    detector_cfg = detector_config or {}
    run_enhanced_detectors = bool(detector_cfg.get("enable_enhanced_detection", True))
    detector_max_file_bytes = int(detector_cfg.get("max_file_size_bytes", _MAX_FILE_BYTES))
    if run_enhanced_detectors:
        try:
            if on_progress:
                on_progress("Running enhanced local technology detection...")
            tech_detector = LocalEnhancedTechnologyDetector(max_file_bytes=detector_max_file_bytes)
            rel_detector = LocalEnhancedRelationshipDetector(max_file_bytes=detector_max_file_bytes)
            analysis_file_paths = phase1_results.get("relevant_files") or []
            enhanced_technology_detection = tech_detector.detect(
                file_paths=analysis_file_paths,
                local_base=local_base,
                cli_prefix=prefix,
            )
            if on_progress:
                on_progress("Running enhanced local relationship detection...")
            enhanced_relationship_analysis = rel_detector.detect(
                file_paths=analysis_file_paths,
                local_base=local_base,
                cli_prefix=prefix,
                detected_technologies=enhanced_technology_detection.get("detected_technologies", {}),
            )
        except Exception as exc:
            logger.warning("Enhanced local architecture detectors failed: %s", exc)

    phase2 = _build_phase2_skeleton(
        category_analyses=category_analyses,
        total_files_analyzed=sum(len(lst) for lst in category_analyses.values()),
        categories_analyzed=categories_with_results,
        executive_summary=synthesis["architectural_insights"].get(
            "executive_summary",
            f"CLI Phase 2: {done_counter[0]} files analysed.",
        ),
    )
    # Overlay synthesis results onto the skeleton
    phase2["architectural_components"] = synthesis["architectural_components"]
    phase2["component_relationships"] = synthesis["component_relationships"]
    phase2["architectural_insights"] = synthesis["architectural_insights"]
    phase2["enhanced_technology_detection"] = enhanced_technology_detection
    phase2["enhanced_relationship_analysis"] = enhanced_relationship_analysis
    phase2["analysis_metadata"]["enhanced_technologies_detected"] = enhanced_technology_detection.get(
        "technology_count", 0
    )
    phase2["analysis_metadata"]["enhanced_relationships_detected"] = enhanced_relationship_analysis.get(
        "relationship_count", 0
    )

    return phase2


def run_architecture_analysis(
    sub_audit_uuid: str,
    repo_name: str,
    file_paths: list[str],
    scope_dirs: dict[str, str] | None = None,
    detector_config: dict[str, Any] | None = None,
    on_progress: Callable[[str], None] | None = None,
    on_debug: Callable[[str], None] | None = None,
    max_workers: int = 6,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """
    Run local architecture Phase 1, Phase 2 and synthesis for one sub-audit.

    file_paths: list of file paths in TypeDB form (cli://uuid/repo/rel).
    scope_dirs: optional mapping repo_name -> local directory; required for full Phase 2.
    Returns (phase1_results, phase2_results) to POST to the server.

    When scope_dirs is provided and LLM keys are configured, runs full Phase 2
    (per-file LLM analysis) **and** synthesis (components, relationships,
    insights) locally using the user's LLM API keys.  The server only needs
    to run Phase 3 (graph construction + TypeDB storage) — no server-side LLM
    calls are required.
    """

    def prog(msg: str) -> None:
        if on_progress:
            on_progress(msg)

    repo_path = f"cli://{sub_audit_uuid}/{repo_name}"
    local_base = scope_dirs.get(repo_name, "") if scope_dirs else ""
    prog("Building file categories (Phase 1)...")
    phase1 = build_phase1_results(
        file_paths,
        repo_path,
        local_base=local_base or None,
        sub_audit_uuid=sub_audit_uuid,
        repo_name=repo_name,
    )

    if scope_dirs and scope_dirs.get(repo_name):
        prog("Running Phase 2 (LLM analysis per file)...")
        phase2 = run_phase2_with_llm(
            phase1,
            scope_dirs=scope_dirs,
            sub_audit_uuid=sub_audit_uuid,
            repo_name=repo_name,
            detector_config=detector_config,
            on_progress=on_progress,
            on_debug=on_debug,
            max_workers=max_workers,
        )
    else:
        prog("Preparing architecture payload (Phase 2 stub; no scope_dirs or LLM)...")
        phase2 = build_phase2_results_empty(
            "No scope_dirs for this repo or LLM not configured; run with --scope or set LLM keys for full Phase 2."
        )

    # Run local archetype classification (T1-T5) using Phase 2 evidence.
    # This gives the user immediate tier feedback in the CLI without waiting
    # for the server's Phase 3 graph + classifier pipeline.
    has_components = bool(phase2.get("architectural_components"))
    has_tech = bool(phase2.get("enhanced_technology_detection", {}).get("detected_technologies"))
    if has_components or has_tech:
        prog("Running archetype classification (T1–T5)...")
        try:
            classification = classify_local(
                phase2_results=phase2,
                repository_name=repo_name,
            )
            phase2["archetype_classification"] = classification
            tier = classification.get("primary_tier", 0)
            name = classification.get("primary_archetype_name", "")
            conf = classification.get("confidence", 0)
            prog(f"Architecture classified: Tier {tier} — {name} ({conf:.0f}% confidence)")
        except Exception as exc:
            logger.warning(f"Local archetype classification failed: {exc}")
            phase2["archetype_classification"] = None

    return phase1, phase2
