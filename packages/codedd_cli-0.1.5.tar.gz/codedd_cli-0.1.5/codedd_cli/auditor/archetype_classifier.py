"""
Local Archetype-Based Scalability Classifier (CLI port)

Maps evidence from the local architecture analysis pipeline (Phase 2 outputs)
onto the 5-tier scalability archetype model:

    Tier 1: Low-Scale Monolith
    Tier 2: Moderate-Scale Modular Monolith
    Tier 3: Mid-Scale Service-Oriented (SOA / "Macro Services")
    Tier 4: High-Scale Microservices
    Tier 5: Real-Time Ultra-Scale Distributed System

This is a CLI-local port of the server-side archetype_classifier.py.  It shares
the same scoring logic (DimensionScorer, TierMatcher, gap analysis) and imports
identical tier definitions.  The only difference is that it does NOT persist
results to PostgreSQL and operates without Phase 3 graph nodes/edges — the
_count_deployable_units method falls back to component-level heuristics when
graph data is unavailable.

Parity reference: E:/CodeDD/django/auditor/auditing_functions/functions/step_5/
                  architecture_analysis/archetype_classifier.py
"""

import logging
import time
from typing import Any

from codedd_cli.auditor.tier_definitions import (
    ARCHETYPE_TIERS,
    ATTENUATION_FACTOR,
    DIMENSION_LABELS,
    DIMENSION_WEIGHTS,
    GAP_RECOMMENDATIONS,
    PENALTY_CAPS,
    TIER_CENTROIDS,
    TIER_PREREQUISITE_GATES,
    build_tier_reference,
    max_qualifying_tier,
    tier_for_dimension_score,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Dimension Scorers
# ---------------------------------------------------------------------------

class DimensionScorer:
    """
    Scores each of the 6 classification dimensions on a 0-100 scale using
    evidence extracted from Phase 2 (LLM synthesis, enhanced technology
    detection, enhanced relationship analysis) outputs.

    Improvements over v1:
    - Evidence items carry a strength tag (strong / medium / weak).
    - Penalty caps enforce hard ceilings when negative signals are present.
    - Deployable-unit detection cross-references Dockerfile / K8s / CI evidence
      instead of naively counting all component/module/service nodes.
    - Cross-dimension attenuation reduces double-counting of multi-role
      technologies (Kafka, Redis, K8s, ...).
    """

    def __init__(self, phase2_results: dict, phase3_results: dict | None = None):
        self.phase2 = phase2_results
        self.phase3 = phase3_results or {}

        self.insights = phase2_results.get('architectural_insights', {})
        self.components = phase2_results.get('architectural_components', {})
        self.relationships = phase2_results.get('component_relationships', [])
        self.tech_detection = phase2_results.get('enhanced_technology_detection', {})
        self.relationship_analysis = phase2_results.get('enhanced_relationship_analysis', {})

        self.detected_techs = self._flatten_technologies()
        self.detected_patterns = self._flatten_patterns()
        self.nodes = self.phase3.get('nodes', [])
        self.edges = self.phase3.get('edges', [])

        self._tech_credit_ledger: dict[str, set[str]] = {}
        self.penalty_signals: dict[str, bool] = {}

    # -- helpers --------------------------------------------------------

    def _flatten_technologies(self) -> list[str]:
        """Collect all detected technology names into a lowercase list.

        Handles two formats for ``detected_technologies``:
        - Server format: ``{tech_name: {...}, ...}`` — keys are tech names.
        - CLI format: ``{category: [{name: tech_name, ...}, ...]}`` — keys
          are category names, values are lists of tech dicts.
        """
        techs: list[str] = []
        detected = self.tech_detection.get('detected_technologies', {})
        if isinstance(detected, dict):
            for key, value in detected.items():
                if isinstance(value, list):
                    # CLI format: category -> list of tech dicts
                    for item in value:
                        if isinstance(item, dict):
                            name = item.get('name', '').lower()
                            if name and name not in techs:
                                techs.append(name)
                else:
                    # Server format: tech_name -> details dict
                    techs.append(key.lower())
        elif isinstance(detected, list):
            for item in detected:
                if isinstance(item, dict):
                    techs.append(item.get('name', '').lower())
                elif isinstance(item, str):
                    techs.append(item.lower())

        tech_stack = self.insights.get('technology_stack', [])
        for t in tech_stack:
            name = t.get('name', '').lower() if isinstance(t, dict) else str(t).lower()
            if name and name not in techs:
                techs.append(name)
        return techs

    def _flatten_patterns(self) -> list[str]:
        """Collect all detected architectural pattern names into a lowercase list."""
        patterns: list[str] = []
        raw = self.insights.get('architectural_patterns', [])
        if isinstance(raw, dict):
            raw = raw.get('patterns', [])
        for p in (raw if isinstance(raw, list) else []):
            patterns.append(str(p).lower())

        arch_patterns = self.phase3.get('architectural_patterns', [])
        for p in (arch_patterns if isinstance(arch_patterns, list) else []):
            val = str(p).lower()
            if val not in patterns:
                patterns.append(val)
        return patterns

    def _has_any(self, haystack: list[str], *needles: str) -> bool:
        return any(
            needle in item
            for item in haystack
            for needle in needles
        )

    def _count_matches(self, haystack: list[str], *needles: str) -> int:
        return sum(
            1 for item in haystack
            if any(needle in item for needle in needles)
        )

    def _evidence(
        self, text: str, strength: str = 'medium'
    ) -> dict[str, str]:
        """Create a structured evidence entry with strength tag."""
        return {'text': text, 'strength': strength}

    def _attenuated_score(
        self, base_points: float, tech_keyword: str, dimension: str
    ) -> float:
        """Return base_points or an attenuated version if this technology
        has already been credited in another dimension."""
        credited_dims = self._tech_credit_ledger.get(tech_keyword, set())
        if dimension in credited_dims:
            return base_points
        if credited_dims:
            self._tech_credit_ledger.setdefault(tech_keyword, set()).add(dimension)
            return base_points * ATTENUATION_FACTOR
        self._tech_credit_ledger.setdefault(tech_keyword, set()).add(dimension)
        return base_points

    # -- deployable unit detection --------------------------------------

    def _count_deployable_units(self) -> tuple[int, int, list[dict[str, str]]]:
        """Distinguish independently deployable units from logical components.

        Returns (deployable_count, logical_count, evidence_list).

        When Phase 3 graph nodes are available, uses container/pipeline node
        types and cross-references with deployment file evidence.  When running
        in CLI mode without graph nodes, falls back to architectural_components
        from the LLM synthesis.
        """
        deployment_evidence_types = {'container', 'pipeline'}
        deployable_node_labels: set[str] = set()
        logical_node_labels: set[str] = set()
        evidence: list[dict[str, str]] = []

        # Deployment file keywords to look for
        deployment_file_keywords = [
            'dockerfile', 'docker-compose', 'deployment.yaml', 'deployment.yml',
            'helm', 'kustomize', '.github/workflows', '.gitlab-ci',
            'jenkinsfile', 'buildspec',
        ]

        if self.nodes:
            # Server path: use Phase 3 graph nodes
            for n in self.nodes:
                ntype = n.get('type', '').lower()
                label = n.get('label', n.get('id', 'unknown'))
                if ntype in deployment_evidence_types:
                    deployable_node_labels.add(label)

            service_nodes = [
                n for n in self.nodes
                if n.get('type') in ('service', 'component', 'module')
            ]

            has_deployment_files = self._has_any(
                [n.get('label', '').lower() for n in self.nodes] +
                [str(f).lower() for f in self.phase2.get('phase1_files', [])
                 if isinstance(f, str)],
                *deployment_file_keywords,
            )

            for sn in service_nodes:
                label = sn.get('label', sn.get('id', 'unknown'))
                if label in deployable_node_labels or has_deployment_files:
                    deployable_node_labels.add(label)
                else:
                    logical_node_labels.add(label)
        else:
            # CLI fallback: use architectural_components from LLM synthesis
            has_deployment_files = (
                self._has_any(self.detected_techs, 'docker', 'kubernetes', 'k8s') or
                self._has_any(self.detected_patterns, 'container', 'docker')
            )

            for comp_key, comp_data in self.components.items():
                if not isinstance(comp_data, dict):
                    continue
                category = comp_data.get('category', '').lower()
                if category in ('infrastructure', 'cicd', 'container'):
                    deployable_node_labels.add(comp_key)
                elif category in ('backend', 'frontend', 'service'):
                    if has_deployment_files:
                        deployable_node_labels.add(comp_key)
                    else:
                        logical_node_labels.add(comp_key)
                else:
                    logical_node_labels.add(comp_key)

        deployable_count = len(deployable_node_labels)
        logical_count = len(logical_node_labels)

        if deployable_count > 0:
            evidence.append(self._evidence(
                f'{deployable_count} independently deployable unit(s) confirmed '
                f'via container/CI evidence',
                'strong',
            ))
        if logical_count > 0:
            evidence.append(self._evidence(
                f'{logical_count} logical component(s) without deployment evidence '
                f'(counted as modules, not services)',
                'weak',
            ))

        return deployable_count, logical_count, evidence

    # -- dimension scorers -----------------------------------------------

    def score_deployment_model(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: single deployable | Tier 5: many independent services."""
        score = 0.0
        evidence: list[dict[str, str]] = []

        deployable_count, logical_count, deploy_evidence = self._count_deployable_units()
        evidence.extend(deploy_evidence)

        total_meaningful = deployable_count + logical_count

        if deployable_count <= 1 and logical_count <= 1:
            score += 5
            evidence.append(self._evidence(
                f'{total_meaningful} deployable unit(s) — single-unit architecture', 'strong'))
        elif deployable_count <= 1 and logical_count <= 5:
            score += 15
            evidence.append(self._evidence(
                f'{deployable_count} deployable + {logical_count} logical — '
                f'modular monolith (logical modules, single deployment)', 'medium'))
        elif deployable_count <= 3:
            score += 30
            evidence.append(self._evidence(
                f'{deployable_count} deployable units — modular monolith range', 'strong'))
        elif deployable_count <= 6:
            score += 50
            evidence.append(self._evidence(
                f'{deployable_count} deployable units — SOA range', 'strong'))
        elif deployable_count <= 15:
            score += 72
            evidence.append(self._evidence(
                f'{deployable_count} deployable units — microservices range', 'strong'))
        else:
            score += 88
            evidence.append(self._evidence(
                f'{deployable_count} deployable units — large-scale microservices', 'strong'))

        if self._has_any(self.detected_patterns, 'microservice'):
            score += 15
            evidence.append(self._evidence('Microservices architecture pattern detected', 'medium'))
        elif self._has_any(self.detected_patterns, 'service-oriented', 'soa', 'macro service'):
            score += 10
            evidence.append(self._evidence('Service-oriented architecture pattern detected', 'medium'))
        elif self._has_any(self.detected_patterns, 'modular-monolith', 'modular monolith', 'bounded context'):
            score += 6
            evidence.append(self._evidence('Modular monolith / bounded contexts detected', 'medium'))
        elif self._has_any(self.detected_patterns, 'monolith'):
            evidence.append(self._evidence('Monolithic architecture pattern detected', 'strong'))
            self.penalty_signals['monolith_detected'] = True

        if self._has_any(self.detected_techs, 'consul', 'eureka', 'istio', 'linkerd', 'envoy'):
            score += 10
            evidence.append(self._evidence('Service mesh / discovery technology detected', 'strong'))

        if self._has_any(self.detected_techs, 'api gateway', 'kong', 'traefik', 'ambassador', 'api-gateway'):
            score += 5
            evidence.append(self._evidence('API gateway detected', 'medium'))

        if self._has_any(self.detected_techs, 'kubernetes', 'k8s'):
            pts = self._attenuated_score(5, 'kubernetes', 'deployment_model')
            score += pts
            if pts > 0:
                evidence.append(self._evidence(
                    f'Kubernetes adds deployment independence (+{pts:.0f} pts)', 'strong'))

        return (min(100.0, score), evidence)

    def score_data_architecture(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: single relational DB | Tier 5: distributed DBs with sharding."""
        score = 0.0
        evidence: list[dict[str, str]] = []

        sql_dbs = ['postgresql', 'postgres', 'mysql', 'mariadb', 'mssql', 'oracle', 'sqlite', 'sql server']
        nosql_dbs = ['mongodb', 'dynamodb', 'couchdb', 'couchbase', 'firestore', 'fauna']
        graph_dbs = ['neo4j', 'typedb', 'arangodb', 'neptune', 'janusgraph', 'dgraph']
        distributed_dbs = ['cassandra', 'cockroachdb', 'spanner', 'tidb', 'vitess', 'yugabyte', 'scylladb']
        search_engines = ['elasticsearch', 'opensearch', 'solr', 'meilisearch', 'typesense']
        cache_dbs = ['redis', 'memcached', 'hazelcast', 'valkey']
        ts_dbs = ['influxdb', 'timescaledb', 'questdb', 'prometheus']

        all_db_groups = [
            ('SQL', sql_dbs), ('NoSQL', nosql_dbs), ('Graph', graph_dbs),
            ('Distributed', distributed_dbs), ('Search', search_engines),
            ('Cache', cache_dbs), ('TimeSeries', ts_dbs),
        ]

        present_groups: list[str] = []
        for group_name, keywords in all_db_groups:
            for kw in keywords:
                if self._has_any(self.detected_techs, kw):
                    if group_name not in present_groups:
                        present_groups.append(group_name)

        db_diversity = len(present_groups)

        if db_diversity == 0:
            score += 5
            evidence.append(self._evidence('No database technologies explicitly detected', 'weak'))
            self.penalty_signals['single_database_only'] = True
        elif db_diversity == 1:
            score += 18
            evidence.append(self._evidence(f'Single database category: {present_groups[0]}', 'strong'))
            self.penalty_signals['single_database_only'] = True
        elif db_diversity == 2:
            score += 40
            evidence.append(self._evidence(
                f'Dual-category data layer: {", ".join(present_groups)}', 'strong'))
        elif db_diversity == 3:
            score += 60
            evidence.append(self._evidence(
                f'Polyglot persistence: {", ".join(present_groups)}', 'strong'))
        else:
            score += 75
            evidence.append(self._evidence(
                f'Rich polyglot persistence ({db_diversity} categories): '
                f'{", ".join(present_groups)}', 'strong'))

        if 'Cache' in present_groups:
            pts = self._attenuated_score(8, 'redis', 'data_architecture')
            score += pts
            evidence.append(self._evidence(
                f'Caching layer detected (+{pts:.0f} pts)', 'strong'))

        if self._has_any(self.detected_patterns, 'read replica', 'read-replica', 'primary-replica', 'leader-follower'):
            score += 6
            evidence.append(self._evidence('Read replica / primary-replica pattern detected', 'medium'))

        if 'Distributed' in present_groups:
            score += 10
            evidence.append(self._evidence('Distributed database technology detected', 'strong'))

        if self._has_any(self.detected_techs, 'vitess', 'citus') or \
           self._has_any(self.detected_patterns, 'sharding', 'partitioning', 'shard'):
            score += 8
            evidence.append(self._evidence('Sharding / partitioning capability detected', 'strong'))

        return (min(100.0, score), evidence)

    def score_communication_style(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: synchronous only | Tier 5: stream processing + event sourcing."""
        score = 0.0
        evidence: list[dict[str, str]] = []
        has_async = False

        has_rest = self._has_any(self.detected_techs, 'rest', 'http', 'express', 'flask', 'fastapi', 'django', 'spring')
        if has_rest:
            score += 15
            evidence.append(self._evidence('Synchronous HTTP/REST communication detected', 'strong'))

        if self._has_any(self.detected_techs, 'grpc', 'protobuf', 'protocol buffer'):
            score += 15
            has_async = True
            evidence.append(self._evidence('gRPC service communication detected', 'strong'))

        if self._has_any(self.detected_techs, 'graphql', 'apollo', 'hasura'):
            score += 8
            evidence.append(self._evidence('GraphQL API layer detected', 'medium'))

        if self._has_any(self.detected_techs, 'websocket', 'socket.io', 'signalr', 'pusher'):
            score += 8
            has_async = True
            evidence.append(self._evidence('WebSocket / real-time communication detected', 'strong'))

        mq_techs = ['rabbitmq', 'activemq', 'sqs', 'celery', 'bull', 'sidekiq', 'resque']
        if self._has_any(self.detected_techs, *mq_techs):
            score += 15
            has_async = True
            evidence.append(self._evidence('Message queue / task queue detected', 'strong'))

        if self._has_any(self.detected_patterns, 'event-driven', 'event driven', 'pub/sub', 'publish-subscribe'):
            score += 12
            has_async = True
            evidence.append(self._evidence('Event-driven architecture pattern detected', 'medium'))

        streaming_techs = ['kafka', 'pulsar', 'kinesis', 'eventbridge', 'nats']
        if self._has_any(self.detected_techs, *streaming_techs):
            matched_tech = next(
                (t for t in streaming_techs if self._has_any(self.detected_techs, t)), 'kafka')
            pts = self._attenuated_score(18, matched_tech, 'communication_style')
            score += pts
            has_async = True
            evidence.append(self._evidence(
                f'Streaming platform detected (+{pts:.0f} pts)', 'strong'))

        stream_proc = ['kafka streams', 'flink', 'spark streaming', 'storm', 'beam', 'ksqldb']
        if self._has_any(self.detected_techs, *stream_proc):
            score += 12
            has_async = True
            evidence.append(self._evidence('Stream processing framework detected', 'strong'))

        if self._has_any(self.detected_patterns, 'event-sourcing', 'event sourcing', 'cqrs'):
            score += 10
            has_async = True
            evidence.append(self._evidence('Event sourcing / CQRS pattern detected', 'medium'))

        if not has_async:
            self.penalty_signals['no_async_messaging'] = True

        return (min(100.0, score), evidence)

    def score_infrastructure_maturity(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: single VM | Tier 5: multi-region K8s with global load balancing."""
        score = 0.0
        evidence: list[dict[str, str]] = []

        has_docker = self._has_any(self.detected_techs, 'docker')
        has_k8s = self._has_any(self.detected_techs, 'kubernetes', 'k8s')

        if has_k8s:
            pts = self._attenuated_score(25, 'kubernetes', 'infrastructure_maturity')
            score += pts
            evidence.append(self._evidence(
                f'Kubernetes orchestration detected (+{pts:.0f} pts)', 'strong'))
        elif has_docker:
            pts = self._attenuated_score(15, 'docker', 'infrastructure_maturity')
            score += pts
            evidence.append(self._evidence(
                f'Docker containerization detected (+{pts:.0f} pts)', 'strong'))
        else:
            evidence.append(self._evidence('No containerization detected', 'strong'))
            self.penalty_signals['no_containerization'] = True

        cloud_techs = ['aws', 'azure', 'gcp', 'google cloud', 'digitalocean', 'heroku', 'vercel', 'cloudflare']
        cloud_matches = [t for t in self.detected_techs if any(c in t for c in cloud_techs)]
        if cloud_matches:
            score += 12
            evidence.append(self._evidence(
                f'Cloud platform detected: {", ".join(cloud_matches[:3])}', 'strong'))

        iac_techs = ['terraform', 'cloudformation', 'pulumi', 'cdk', 'bicep', 'ansible', 'chef', 'puppet']
        if self._has_any(self.detected_techs, *iac_techs):
            score += 10
            evidence.append(self._evidence('Infrastructure as Code detected', 'strong'))

        if self._has_any(self.detected_techs, 'helm', 'kustomize'):
            score += 5
            evidence.append(self._evidence('Kubernetes templating (Helm/Kustomize) detected', 'strong'))

        lb_techs = ['nginx', 'haproxy', 'envoy', 'traefik', 'ingress', 'alb', 'elb', 'cloudfront']
        if self._has_any(self.detected_techs, *lb_techs):
            score += 8
            evidence.append(self._evidence('Load balancing / reverse proxy detected', 'medium'))

        if self._has_any(self.detected_techs, 'hpa', 'keda', 'autoscal', 'fargate', 'cloud run', 'lambda'):
            score += 10
            evidence.append(self._evidence('Auto-scaling capability detected', 'strong'))

        multi_region = ['multi-region', 'multi region', 'route53', 'cloudfront', 'global accelerator',
                        'traffic manager', 'cloud cdn', 'geo-replication', 'geo replication']
        if self._has_any(self.detected_techs, *multi_region) or \
           self._has_any(self.detected_patterns, *multi_region):
            score += 15
            evidence.append(self._evidence('Multi-region deployment capability detected', 'strong'))

        cicd_techs = ['github actions', 'gitlab ci', 'jenkins', 'circleci', 'argo', 'tekton',
                      'buildkite', 'travis', 'drone', 'spinnaker']
        if self._has_any(self.detected_techs, *cicd_techs):
            score += 8
            evidence.append(self._evidence('CI/CD pipeline detected', 'strong'))

        secrets = ['vault', 'aws secrets', 'azure key vault', 'sops', 'sealed-secrets']
        if self._has_any(self.detected_techs, *secrets):
            score += 5
            evidence.append(self._evidence('Secrets management detected', 'medium'))

        return (min(100.0, score), evidence)

    def score_scaling_mechanisms(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: none | Tier 5: sharding + stream processing + geo-replication."""
        score = 0.0
        evidence: list[dict[str, str]] = []
        has_autoscaling = False

        cache_techs = ['redis', 'memcached', 'hazelcast', 'valkey', 'varnish']
        if self._has_any(self.detected_techs, *cache_techs):
            matched = next((t for t in cache_techs if self._has_any(self.detected_techs, t)), 'redis')
            pts = self._attenuated_score(12, matched, 'scaling_mechanisms')
            score += pts
            evidence.append(self._evidence(f'Caching layer detected (+{pts:.0f} pts)', 'strong'))

        cdn_techs = ['cloudfront', 'cloudflare', 'akamai', 'fastly', 'cdn', 'azure cdn']
        if self._has_any(self.detected_techs, *cdn_techs):
            score += 8
            evidence.append(self._evidence('CDN / edge caching detected', 'medium'))

        if self._has_any(self.detected_patterns, 'read replica', 'read-replica', 'primary-replica'):
            score += 8
            evidence.append(self._evidence('Database read replicas detected', 'medium'))

        if self._has_any(self.detected_patterns, 'cqrs', 'command query responsibility'):
            score += 12
            evidence.append(self._evidence('CQRS pattern detected', 'medium'))

        if self._has_any(self.detected_patterns, 'event sourcing', 'event-sourcing'):
            score += 12
            evidence.append(self._evidence('Event sourcing detected', 'medium'))

        streaming = ['kafka', 'pulsar', 'kinesis', 'kafka streams', 'flink', 'spark streaming', 'storm']
        if self._has_any(self.detected_techs, *streaming):
            matched = next((t for t in streaming if self._has_any(self.detected_techs, t)), 'kafka')
            pts = self._attenuated_score(15, matched, 'scaling_mechanisms')
            score += pts
            evidence.append(self._evidence(
                f'Streaming / real-time processing detected (+{pts:.0f} pts)', 'strong'))

        if self._has_any(self.detected_techs, 'vitess', 'citus', 'cockroachdb', 'spanner', 'yugabyte') or \
           self._has_any(self.detected_patterns, 'sharding', 'partitioning', 'shard'):
            score += 15
            evidence.append(self._evidence('Data sharding / partitioning detected', 'strong'))

        if self._has_any(self.detected_techs, 'cockroachdb', 'spanner', 'cosmosdb', 'dynamodb global') or \
           self._has_any(self.detected_patterns, 'geo-replication', 'geo replication', 'multi-region'):
            score += 12
            evidence.append(self._evidence('Geo-replication capability detected', 'strong'))

        if self._has_any(self.detected_techs, 'hpa', 'keda', 'autoscal', 'fargate'):
            pts = self._attenuated_score(8, 'autoscaling', 'scaling_mechanisms')
            score += pts
            has_autoscaling = True
            evidence.append(self._evidence(
                f'Auto-scaling mechanism detected (+{pts:.0f} pts)', 'strong'))

        if not has_autoscaling and score < 20:
            self.penalty_signals['no_autoscaling'] = True

        return (min(100.0, score), evidence)

    def score_operational_maturity(self) -> tuple[float, list[dict[str, str]]]:
        """Tier 1: minimal CI/CD | Tier 5: full observability + distributed tracing."""
        score = 0.0
        evidence: list[dict[str, str]] = []
        has_monitoring = False

        cicd_techs = ['github actions', 'gitlab ci', 'jenkins', 'circleci', 'argo', 'tekton',
                      'buildkite', 'travis', 'drone', 'spinnaker']
        cicd_count = self._count_matches(self.detected_techs, *cicd_techs)
        if cicd_count >= 2:
            score += 15
            evidence.append(self._evidence(f'Multiple CI/CD tools detected ({cicd_count})', 'strong'))
        elif cicd_count == 1:
            score += 10
            evidence.append(self._evidence('CI/CD pipeline detected', 'strong'))

        monitoring = ['prometheus', 'grafana', 'datadog', 'newrelic', 'cloudwatch', 'stackdriver',
                      'dynatrace', 'nagios', 'zabbix', 'pagerduty']
        mon_count = self._count_matches(self.detected_techs, *monitoring)
        if mon_count >= 2:
            matched = next((t for t in monitoring if self._has_any(self.detected_techs, t)), 'prometheus')
            pts = self._attenuated_score(18, matched, 'operational_maturity')
            score += pts
            has_monitoring = True
            evidence.append(self._evidence(
                f'Observability stack detected ({mon_count} tools, +{pts:.0f} pts)', 'strong'))
        elif mon_count == 1:
            matched = next((t for t in monitoring if self._has_any(self.detected_techs, t)), 'prometheus')
            pts = self._attenuated_score(10, matched, 'operational_maturity')
            score += pts
            has_monitoring = True
            evidence.append(self._evidence(f'Monitoring tool detected (+{pts:.0f} pts)', 'medium'))

        logging_techs = ['elk', 'elasticsearch', 'logstash', 'kibana', 'fluentd', 'fluent bit',
                        'loki', 'splunk', 'graylog', 'papertrail']
        if self._has_any(self.detected_techs, *logging_techs):
            score += 10
            has_monitoring = True
            evidence.append(self._evidence('Centralized logging detected', 'strong'))

        tracing = ['jaeger', 'zipkin', 'opentelemetry', 'otel', 'lightstep', 'honeycomb',
                   'aws x-ray', 'xray', 'tempo']
        if self._has_any(self.detected_techs, *tracing):
            score += 15
            evidence.append(self._evidence('Distributed tracing detected', 'strong'))

        alerting = ['pagerduty', 'opsgenie', 'alertmanager', 'victorops', 'incident.io']
        if self._has_any(self.detected_techs, *alerting):
            score += 8
            evidence.append(self._evidence('Alerting / incident management detected', 'medium'))

        feature_flags = ['launchdarkly', 'flagsmith', 'unleash', 'split.io', 'feature flag']
        if self._has_any(self.detected_techs, *feature_flags):
            score += 5
            evidence.append(self._evidence('Feature flag system detected', 'medium'))

        chaos = ['chaos monkey', 'litmus', 'gremlin', 'chaos mesh', 'chaos engineering']
        if self._has_any(self.detected_techs, *chaos):
            score += 8
            evidence.append(self._evidence('Chaos engineering tooling detected', 'strong'))

        gitops = ['argocd', 'argo cd', 'fluxcd', 'flux cd', 'gitops']
        if self._has_any(self.detected_techs, *gitops):
            score += 8
            evidence.append(self._evidence('GitOps / progressive deployment detected', 'strong'))

        sec_scanning = ['snyk', 'trivy', 'sonarqube', 'dependabot', 'renovate', 'owasp', 'codeql']
        if self._has_any(self.detected_techs, *sec_scanning):
            score += 5
            evidence.append(self._evidence('Security scanning in pipeline detected', 'medium'))

        if not has_monitoring:
            self.penalty_signals['no_monitoring'] = True

        return (min(100.0, score), evidence)

    # -- orchestrator ---------------------------------------------------

    def score_all_dimensions(self) -> dict[str, dict[str, Any]]:
        """Run all 6 dimension scorers, apply penalty caps, and return structured results."""
        scorers = {
            'deployment_model': self.score_deployment_model,
            'data_architecture': self.score_data_architecture,
            'communication_style': self.score_communication_style,
            'infrastructure_maturity': self.score_infrastructure_maturity,
            'scaling_mechanisms': self.score_scaling_mechanisms,
            'operational_maturity': self.score_operational_maturity,
        }

        results: dict[str, dict[str, Any]] = {}
        for dim_key, scorer_fn in scorers.items():
            raw_score, evidence = scorer_fn()
            results[dim_key] = {
                'score': round(raw_score, 1),
                'evidence': evidence,
                'label': DIMENSION_LABELS[dim_key],
            }

        applied_caps: list[dict[str, Any]] = []
        for cap_def in PENALTY_CAPS:
            signal = cap_def['signal']
            dim = cap_def['dimension']
            ceiling = cap_def['cap']
            if self.penalty_signals.get(signal) and results[dim]['score'] > ceiling:
                original = results[dim]['score']
                results[dim]['score'] = ceiling
                results[dim]['evidence'].append(self._evidence(
                    f'{cap_def["description"]} Score capped from {original:.0f} to {ceiling}.',
                    'strong',
                ))
                applied_caps.append({
                    'signal': signal,
                    'dimension': dim,
                    'original_score': original,
                    'capped_to': ceiling,
                })

        self._applied_penalty_caps = applied_caps
        return results


# ---------------------------------------------------------------------------
# Tier Matcher
# ---------------------------------------------------------------------------

class TierMatcher:
    """
    Maps a set of 6 dimension scores to the closest archetype tier using:

    1. Per-dimension band-based tier assignment (explicit thresholds).
    2. Weighted Euclidean distance to tier centroids for the overall match.
    3. Prerequisite gates that cap the tier regardless of distance.
    4. Mixed-tier detection for per-dimension spread analysis.
    """

    @staticmethod
    def match(dimension_scores: dict[str, dict[str, Any]]) -> dict[str, Any]:
        """Determine the best-matching tier and enrich dimension_scores."""
        # Step 1: Per-dimension tier assignment using band thresholds
        for dim_key, dim_data in dimension_scores.items():
            dim_data['tier'] = tier_for_dimension_score(dim_key, dim_data['score'])

        # Step 2: Weighted Euclidean distance to each tier centroid
        tier_distances: dict[int, float] = {}
        for tier, centroids in TIER_CENTROIDS.items():
            total = 0.0
            for dim_key, dim_data in dimension_scores.items():
                w = DIMENSION_WEIGHTS[dim_key]
                diff = dim_data['score'] - centroids[dim_key]
                total += w * (diff ** 2)
            tier_distances[tier] = total ** 0.5

        distance_based_tier = min(tier_distances, key=tier_distances.get)

        # Step 3: Apply prerequisite gates
        score_map = {dim: d['score'] for dim, d in dimension_scores.items()}
        gate_ceiling = max_qualifying_tier(score_map)
        primary_tier = min(distance_based_tier, gate_ceiling)

        gate_violations: list[str] = []
        if gate_ceiling < distance_based_tier:
            for t in range(gate_ceiling + 1, distance_based_tier + 1):
                gates = TIER_PREREQUISITE_GATES.get(t, {})
                for dim, threshold in gates.items():
                    actual = score_map.get(dim, 0)
                    if actual < threshold:
                        gate_violations.append(
                            f'{DIMENSION_LABELS.get(dim, dim)} = {actual:.0f} '
                            f'(needs >= {threshold} for Tier {t})'
                        )

        primary_distance = tier_distances[primary_tier]
        max_possible_distance = 100.0 * (sum(w ** 2 for w in DIMENSION_WEIGHTS.values())) ** 0.5
        confidence = max(0.0, min(100.0, 100.0 * (1.0 - primary_distance / max_possible_distance)))

        per_dim_tiers = [d['tier'] for d in dimension_scores.values()]
        tier_spread = max(per_dim_tiers) - min(per_dim_tiers)

        mixed_tier_note = ''
        if tier_spread >= 2:
            detail_parts = []
            for dim_key, dim_data in dimension_scores.items():
                if dim_data['tier'] != primary_tier:
                    detail_parts.append(
                        f"{DIMENSION_LABELS[dim_key]} at Tier {dim_data['tier']}"
                    )
            if detail_parts:
                mixed_tier_note = (
                    f"Mixed-tier profile (spread={tier_spread}): "
                    f"Primary Tier {primary_tier}, but {'; '.join(detail_parts)}"
                )

        return {
            'primary_tier': primary_tier,
            'primary_archetype_name': ARCHETYPE_TIERS[primary_tier]['name'],
            'archetype_description': ARCHETYPE_TIERS[primary_tier]['description'],
            'example_platforms': ARCHETYPE_TIERS[primary_tier]['example_platforms'],
            'confidence': round(confidence, 1),
            'dimension_scores': dimension_scores,
            'mixed_tier_note': mixed_tier_note,
            'dimension_tier_spread': tier_spread,
            'tier_distances': {t: round(d, 2) for t, d in tier_distances.items()},
            'distance_based_tier': distance_based_tier,
            'gate_ceiling': gate_ceiling,
            'gate_violations': gate_violations,
        }


# ---------------------------------------------------------------------------
# Tier Gap Analysis
# ---------------------------------------------------------------------------

def compute_tier_gap_analysis(
    primary_tier: int,
    dimension_scores: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Describe what is needed to advance from the current tier to the next."""
    if primary_tier >= 5:
        return {'status': 'at_maximum_tier', 'actions': {}}

    next_tier = primary_tier + 1
    next_profile = ARCHETYPE_TIERS[next_tier]
    next_centroids = TIER_CENTROIDS[next_tier]
    next_gates = TIER_PREREQUISITE_GATES.get(next_tier, {})
    actions: dict[str, dict[str, Any]] = {}

    for dim_key, dim_data in dimension_scores.items():
        current_score = dim_data['score']
        centroid_target = next_centroids[dim_key]
        gate_target = next_gates.get(dim_key, 0)
        target = max(centroid_target, gate_target)
        gap = target - current_score

        if gap <= 0:
            actions[dim_key] = {
                'status': 'meets_target',
                'current_score': current_score,
                'target_score': target,
                'gap': 0,
            }
        else:
            recs = GAP_RECOMMENDATIONS.get(dim_key, {})
            actions[dim_key] = {
                'status': 'below_target',
                'current_score': current_score,
                'target_score': target,
                'gap': round(gap, 1),
                'recommendation': recs.get(
                    primary_tier,
                    f'Advance {DIMENSION_LABELS.get(dim_key, dim_key)} '
                    f'capabilities toward Tier {next_tier}.',
                ),
            }

    return {
        'current_tier': primary_tier,
        'next_tier': next_tier,
        'next_tier_name': next_profile['name'],
        'actions': actions,
    }


# ---------------------------------------------------------------------------
# Local Classification Entry Point (no PostgreSQL persistence)
# ---------------------------------------------------------------------------

def classify_local(
    phase2_results: dict,
    phase3_results: dict | None = None,
    repository_name: str = '',
) -> dict[str, Any]:
    """Run the full classification pipeline locally (no DB persistence).

    This is the CLI equivalent of ArchetypeClassifier.classify() on the server.
    It scores dimensions, matches tiers, and computes gap analysis, returning
    the complete result dict.
    """
    start_time = time.time()

    scorer = DimensionScorer(phase2_results, phase3_results)
    dimension_scores = scorer.score_all_dimensions()
    match_result = TierMatcher.match(dimension_scores)
    gap_analysis = compute_tier_gap_analysis(
        match_result['primary_tier'],
        match_result['dimension_scores'],
    )

    elapsed = round(time.time() - start_time, 2)

    logger.info(
        f"Archetype classification: Tier {match_result['primary_tier']} "
        f"({match_result['primary_archetype_name']}) "
        f"confidence={match_result['confidence']}%  [{elapsed}s]"
    )

    return {
        'primary_tier': match_result['primary_tier'],
        'primary_archetype_name': match_result['primary_archetype_name'],
        'archetype_description': match_result['archetype_description'],
        'example_platforms': match_result['example_platforms'],
        'confidence': match_result['confidence'],
        'dimension_scores': match_result['dimension_scores'],
        'mixed_tier_note': match_result['mixed_tier_note'],
        'dimension_tier_spread': match_result['dimension_tier_spread'],
        'tier_distances': match_result['tier_distances'],
        'tier_gap_analysis': gap_analysis,
        'tier_reference': build_tier_reference(),
        'detected_patterns': scorer.detected_patterns,
        'detected_technologies': scorer.detected_techs[:50],
        'gate_ceiling': match_result.get('gate_ceiling'),
        'distance_based_tier': match_result.get('distance_based_tier'),
        'gate_violations': match_result.get('gate_violations', []),
        'penalty_caps_applied': getattr(scorer, '_applied_penalty_caps', []),
        'penalty_signals': scorer.penalty_signals,
    }
