"""
Collect git statistics from a local repository for CLI-driven audits.

Produces the same structure as the server's GitStatisticsCollector so that
POST /api/cli/audit/git-statistics/ can persist data for dashboards, velocity
aggregates, and developer expertise. Used when the repo is local (git directory)
and the server has no clone (cli:// root_path).
"""

import os
import subprocess
from collections import defaultdict
from collections.abc import Callable
from datetime import datetime, timedelta
from typing import Any


def _run_git(repo_path: str, cmd: list[str], timeout: int = 300) -> str | None:
    """Run a git command in the repository; returns stdout or None on failure."""
    try:
        full_cmd = ["git", "-C", repo_path] + cmd
        result = subprocess.run(
            full_cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        if result.returncode != 0:
            return None
        return result.stdout.strip() or None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def _default_branch(repo_path: str) -> str:
    """Return default branch (main or master)."""
    branch = _run_git(repo_path, ["rev-parse", "--abbrev-ref", "HEAD"])
    if branch and branch != "HEAD":
        return branch
    for name in ("main", "master"):
        if _run_git(repo_path, ["rev-parse", "--verify", name]):
            return name
    return "main"


def collect_git_statistics(
    repo_path: str,
    repository_name: str | None = None,
    repository_url: str | None = None,
    include_derived_stats: bool = True,
    include_classification: bool = True,
    on_debug: Callable[[str], None] | None = None,
) -> dict[str, Any] | None:
    """
    Collect git statistics from a local repository path.

    Returns a dict compatible with the server's GitStatistics model:
    commit_history, author_stats, merge_stats, branch_stats, meta_info,
    time_based_stats, release_stats, code_churn_stats, collaboration_stats.
    Missing or unsupported metrics are returned as empty dicts.

    Returns None if repo_path is not a git repo or collection fails.
    """
    repo_path = os.path.abspath(repo_path)

    # Use git itself to detect repo membership — handles subdirectories and
    # worktrees where `.git` may be a file rather than a directory.
    inside = _run_git(repo_path, ["rev-parse", "--is-inside-work-tree"])
    if inside != "true":
        if on_debug:
            on_debug(f"Not a git repository: {repo_path}")
        return None

    # Resolve to the repository root so all subsequent git commands operate
    # on the whole repository regardless of which subdirectory was passed in.
    toplevel = _run_git(repo_path, ["rev-parse", "--show-toplevel"])
    if toplevel:
        repo_path = os.path.normpath(toplevel)

    def dbg(msg: str) -> None:
        if on_debug:
            on_debug(msg)

    default_branch = _default_branch(repo_path)
    dbg(f"Collecting git stats for branch {default_branch}")

    # Commit history with file changes (for velocity and developer expertise)
    commit_history = _collect_commit_history(repo_path, default_branch, dbg)
    if commit_history is None:
        commit_history = {"total_commits": 0, "commits": []}
    if include_classification:
        commit_history = _maybe_classify_commit_history(commit_history, dbg)

    # Author statistics aligned with server shape:
    # { "Name <email>": {commit_count, first_commit, last_commit, code_churn, file_patterns} }
    author_stats = _collect_author_stats(repo_path, default_branch, commit_history, dbg)
    merge_stats = _collect_merge_stats(repo_path, default_branch)
    release_stats = _collect_release_stats(repo_path)
    time_based_stats = (
        _derive_time_based_stats(commit_history) if include_derived_stats else {}
    )
    code_churn_stats = (
        _derive_code_churn_stats(commit_history) if include_derived_stats else {}
    )
    collaboration_stats = (
        _collect_collaboration_stats(repo_path, default_branch, commit_history)
        if include_derived_stats
        else {}
    )

    return {
        "commit_history": commit_history,
        "author_stats": author_stats or {},
        "merge_stats": merge_stats,
        "branch_stats": _collect_branch_stats(repo_path, dbg) or {},
        "meta_info": _collect_meta_info(repo_path, default_branch) or {},
        "time_based_stats": time_based_stats,
        "release_stats": release_stats,
        "code_churn_stats": code_churn_stats,
        "collaboration_stats": collaboration_stats,
        "repository_name": repository_name,
        "repository_url": repository_url,
    }


def _maybe_classify_commit_history(
    commit_history: dict[str, Any], dbg: Callable[[str], None]
) -> dict[str, Any]:
    """
    Apply commit classification using the CLI-local classifier.

    The classifier is ported from the server-side module so that the CLI
    can produce ``classification_summary`` data without requiring the
    Django codebase on ``sys.path``.
    """
    try:
        from codedd_cli.auditor.commit_classifier import classify_commit_history

        classified = classify_commit_history(commit_history, time_window_years=2)
        return classified if isinstance(classified, dict) else commit_history
    except Exception as exc:
        dbg(f"Commit classification failed: {exc}")
        return commit_history


def _collect_commit_history(repo_path: str, default_branch: str, dbg: Callable[[str], None]) -> dict | None:
    """Get commit history with file changes (same shape as server)."""
    # One commit per block; format: HASH|||AUTHOR|||DATE|||SUBJECT|||PARENTS
    fmt = "COMMIT_START\n%H|||%an <%ae>|||%aI|||%s|||%P"
    out = _run_git(
        repo_path,
        ["log", default_branch, "--numstat", "--date=iso-strict", f"--pretty=format:{fmt}"],
        timeout=500,
    )
    if not out:
        return {"total_commits": 0, "commits": []}

    blocks = [b for b in out.split("COMMIT_START\n") if b.strip()]
    del out
    commits = []
    for block in blocks:
        lines = block.strip().split("\n")
        if not lines:
            continue
        parts = lines[0].split("|||")
        if len(parts) < 4:
            continue
        hash_val = parts[0]
        author = parts[1]
        commit_date = parts[2]
        message = parts[3]
        file_changes = []
        for line in lines[1:]:
            if not line.strip():
                continue
            try:
                added, deleted, filename = line.split("\t", 2)
                added = int(added) if added != "-" else 0
                deleted = int(deleted) if deleted != "-" else 0
                file_changes.append({"filename": filename, "added": added, "deleted": deleted})
            except (ValueError, TypeError):
                continue
        # %P gives space-separated parent hashes; a merge has >1 parent.
        parents = parts[4].strip() if len(parts) > 4 else ""
        commits.append(
            {
                "hash": hash_val,
                "author": author,
                "date": commit_date,
                "message": message,
                "is_merge": len(parents.split()) > 1,
                "file_changes": file_changes,
            }
        )

    return {"total_commits": len(commits), "commits": commits}


def _collect_author_stats(
    repo_path: str,
    default_branch: str,
    commit_history: dict,
    _dbg: Callable[[str], None],
) -> dict:
    """
    Build author statistics in the same shape as the server collector.

    Returns:
      {
        "Author <email>": {
          "commit_count": int,
          "first_commit": str|None,
          "last_commit": str|None,
          "code_churn": {"additions": int, "deletions": int, "total_changes": int},
          "file_patterns": {"total_files_modified": int, "unique_file_types": int}
        }
      }
    """
    # Server commit_count uses shortlog --no-merges. Keep parity there.
    shortlog_counts: dict[str, int] = {}
    shortlog_out = _run_git(repo_path, ["shortlog", "-sne", "--no-merges", default_branch])
    if shortlog_out:
        for line in shortlog_out.split("\n"):
            if not line.strip():
                continue
            try:
                count, author = line.strip().split("\t", 1)
                shortlog_counts[author] = int(count)
            except (ValueError, TypeError):
                continue

    commits = commit_history.get("commits", []) if isinstance(commit_history, dict) else []
    aggregate: dict[str, dict[str, Any]] = {}
    for commit in commits:
        author = str(commit.get("author", "")).strip()
        if not author:
            continue
        author_bucket = aggregate.setdefault(
            author,
            {
                "derived_commit_count": 0,
                "first_commit_dt": None,
                "last_commit_dt": None,
                "additions": 0,
                "deletions": 0,
                "file_count": 0,
                "extensions": set(),
            },
        )

        author_bucket["derived_commit_count"] += 1
        commit_dt = _parse_commit_datetime(str(commit.get("date", "")))
        if commit_dt:
            first_dt = author_bucket["first_commit_dt"]
            last_dt = author_bucket["last_commit_dt"]
            author_bucket["first_commit_dt"] = commit_dt if first_dt is None else min(first_dt, commit_dt)
            author_bucket["last_commit_dt"] = commit_dt if last_dt is None else max(last_dt, commit_dt)

        for change in commit.get("file_changes", []) or []:
            filename = str(change.get("filename", "")).strip()
            if not filename:
                continue
            added = int(change.get("added", 0) or 0)
            deleted = int(change.get("deleted", 0) or 0)
            author_bucket["additions"] += added
            author_bucket["deletions"] += deleted
            author_bucket["file_count"] += 1
            if "." in filename:
                author_bucket["extensions"].add(filename.rsplit(".", 1)[-1])

    all_authors = set(shortlog_counts.keys()) | set(aggregate.keys())
    author_stats: dict[str, Any] = {}
    for author in all_authors:
        author_data = aggregate.get(author, {})
        additions = int(author_data.get("additions", 0) or 0)
        deletions = int(author_data.get("deletions", 0) or 0)
        first_dt = author_data.get("first_commit_dt")
        last_dt = author_data.get("last_commit_dt")
        commit_count = shortlog_counts.get(author, int(author_data.get("derived_commit_count", 0) or 0))
        extensions = author_data.get("extensions", set()) or set()

        author_stats[author] = {
            "commit_count": int(commit_count),
            "first_commit": first_dt.isoformat() if isinstance(first_dt, datetime) else None,
            "last_commit": last_dt.isoformat() if isinstance(last_dt, datetime) else None,
            "code_churn": {
                "additions": additions,
                "deletions": deletions,
                "total_changes": additions + deletions,
            },
            "file_patterns": {
                "total_files_modified": int(author_data.get("file_count", 0) or 0),
                "unique_file_types": len(extensions),
            },
        }

    return author_stats


def _collect_merge_stats(repo_path: str, default_branch: str) -> dict:
    """Collect merge commit statistics from the default branch."""
    out = _run_git(
        repo_path,
        ["log", "--merges", "--first-parent", default_branch, "--pretty=format:%H|%aN|%aI|%s"],
    )
    if not out:
        return {}

    merges = []
    for line in out.split("\n"):
        if not line.strip():
            continue
        parts = line.split("|", 3)
        if len(parts) != 4:
            continue
        commit_hash, author, date, message = parts
        merges.append(
            {
                "hash": commit_hash,
                "author": author,
                "date": date,
                "message": message,
            }
        )

    return {"total_merges": len(merges), "merges": merges}


def _is_branch_stale(last_commit_date: str, stale_days: int = 90) -> bool:
    """Determine whether a branch is stale from ISO-like date text."""
    when = _parse_commit_datetime(last_commit_date)
    if not when:
        return False
    now = datetime.now(when.tzinfo) if when.tzinfo else datetime.now()
    return (now - when).days > stale_days


def _collect_branch_stats(repo_path: str, _dbg: Callable[[str], None]) -> dict:
    """Collect branch metadata with active/stale counts."""
    out = _run_git(
        repo_path,
        ["branch", "-r", "--format=%(refname:short)|%(committerdate:iso8601)|%(authorname)"],
    )

    branches = []
    if out:
        for line in out.split("\n"):
            if not line.strip():
                continue
            parts = line.split("|", 2)
            if len(parts) != 3:
                continue
            name, last_commit_date, last_author = parts
            branches.append(
                {
                    "name": name,
                    "last_commit_date": last_commit_date,
                    "last_author": last_author,
                    "is_stale": _is_branch_stale(last_commit_date),
                }
            )
    else:
        # Fallback to local branches only when remotes are unavailable.
        local_out = _run_git(repo_path, ["branch", "--format=%(refname:short)"])
        if local_out:
            for name in [n.strip() for n in local_out.split("\n") if n.strip()]:
                branches.append(
                    {
                        "name": name,
                        "last_commit_date": None,
                        "last_author": None,
                        "is_stale": False,
                    }
                )

    if not branches:
        return {}

    return {
        "total_branches": len(branches),
        "active_branches": sum(1 for b in branches if not b["is_stale"]),
        "stale_branches": sum(1 for b in branches if b["is_stale"]),
        "branches": branches,
    }


def _collect_meta_info(repo_path: str, default_branch: str) -> dict:
    """Collect repository metadata aligned to server shape."""
    repo_size = _run_git(repo_path, ["count-objects", "-v"])
    first = _run_git(repo_path, ["log", "--reverse", "--format=%aI", default_branch, "-1"])
    latest = _run_git(repo_path, ["log", "--format=%aI", default_branch, "-1"])
    files_out = _run_git(repo_path, ["ls-files"])
    total_files = files_out.count("\n") + 1 if files_out else 0
    del files_out
    return {
        "repository_size": repo_size,
        "first_commit_date": first,
        "latest_commit_date": latest,
        "total_files": total_files,
        "default_branch": default_branch,
    }


def _parse_commit_datetime(raw: str) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def _derive_time_based_stats(commit_history: dict) -> dict:
    commits = commit_history.get("commits", []) if isinstance(commit_history, dict) else []
    if not commits:
        return {}

    commit_dates: list[datetime] = []
    daily_commits_by_author: dict[str, dict[str, int]] = defaultdict(dict)
    daily_totals: dict[str, int] = defaultdict(int)
    weekly_totals: dict[str, int] = defaultdict(int)

    for commit in commits:
        when = _parse_commit_datetime(str(commit.get("date", "")))
        if not when:
            continue
        commit_dates.append(when)
        day_key = when.strftime("%Y-%m-%d")
        week_key = when.strftime("%Y-W%W")
        author = str(commit.get("author", "unknown")).strip() or "unknown"

        daily_totals[day_key] += 1
        weekly_totals[week_key] += 1
        per_author = daily_commits_by_author[author]
        per_author[day_key] = per_author.get(day_key, 0) + 1

    if not commit_dates:
        return {}

    first_commit = min(commit_dates)
    last_commit = max(commit_dates)
    repo_days = max((last_commit - first_commit).days + 1, 1)
    filled_daily_totals: dict[str, int] = {}
    current = first_commit
    while current <= last_commit:
        key = current.strftime("%Y-%m-%d")
        filled_daily_totals[key] = daily_totals.get(key, 0)
        current += timedelta(days=1)

    return {
        "commit_frequency": {
            "total_commits": len(commit_dates),
            "days_active": repo_days,
            "avg_commits_per_day": len(commit_dates) / repo_days,
            "avg_commits_per_week": len(commit_dates) / max(repo_days / 7, 1),
            "most_active_day": max(daily_totals.items(), key=lambda x: x[1]) if daily_totals else None,
            "most_active_week": max(weekly_totals.items(), key=lambda x: x[1]) if weekly_totals else None,
        },
        "activity_periods": {
            "first_commit_date": first_commit.isoformat(),
            "last_commit_date": last_commit.isoformat(),
            "repository_age_days": repo_days,
            "daily_commit_counts": dict(daily_totals),
            "weekly_commit_counts": dict(weekly_totals),
            "daily_commits_by_author": {k: dict(v) for k, v in daily_commits_by_author.items()},
            "total_daily_commits": filled_daily_totals,
        },
    }


def _derive_code_churn_stats(commit_history: dict) -> dict:
    commits = commit_history.get("commits", []) if isinstance(commit_history, dict) else []
    if not commits:
        return {}

    per_file: dict[str, dict[str, int]] = defaultdict(lambda: {"commits": 0, "added": 0, "deleted": 0})
    total_added = 0
    total_deleted = 0

    for commit in commits:
        for change in commit.get("file_changes", []) or []:
            filename = str(change.get("filename", "")).strip()
            if not filename:
                continue
            added = int(change.get("added", 0) or 0)
            deleted = int(change.get("deleted", 0) or 0)
            per_file[filename]["commits"] += 1
            per_file[filename]["added"] += added
            per_file[filename]["deleted"] += deleted
            total_added += added
            total_deleted += deleted

    most_modified = sorted(
        per_file.items(),
        key=lambda item: (item[1]["commits"], item[1]["added"] + item[1]["deleted"]),
        reverse=True,
    )[:10]

    file_change_values = list(per_file.values())
    return {
        "overall_churn": {
            "total_additions": total_added,
            "total_deletions": total_deleted,
            "total_changes": total_added + total_deleted,
            "ratio_additions_deletions": (total_deleted / total_added) if total_added > 0 else 0,
        },
        "hotspots": {
            "most_modified_files": [
                {
                    "filename": filename,
                    "stats": {
                        "times_modified": stats["commits"],
                        "total_additions": stats["added"],
                        "total_deletions": stats["deleted"],
                        "total_changes": stats["added"] + stats["deleted"],
                    },
                }
                for filename, stats in most_modified
            ]
        },
        "file_stability": {
            "total_files_modified": len(per_file),
            "avg_changes_per_file": (
                (total_added + total_deleted) / len(per_file) if per_file else 0
            ),
            "files_by_churn_level": {
                "high_churn": len(
                    [f for f in file_change_values if (f["added"] + f["deleted"]) > 1000]
                ),
                "medium_churn": len(
                    [
                        f
                        for f in file_change_values
                        if 100 < (f["added"] + f["deleted"]) <= 1000
                    ]
                ),
                "low_churn": len(
                    [f for f in file_change_values if (f["added"] + f["deleted"]) <= 100]
                ),
            },
        },
    }


def _collect_release_stats(repo_path: str) -> dict:
    """Collect release metrics from git tags."""
    out = _run_git(
        repo_path,
        ["tag", "-l", "--format=%(refname:short)|%(creatordate:iso8601)|%(contents:subject)"],
    )
    if not out:
        return {
            "total_releases": 0,
            "releases": [],
            "release_frequency": {
                "avg_days_between_releases": None,
                "min_days_between_releases": None,
                "max_days_between_releases": None,
            },
        }

    releases: list[dict[str, Any]] = []
    for line in out.split("\n"):
        if not line.strip():
            continue
        parts = line.split("|")
        if len(parts) < 2:
            continue
        tag = parts[0]
        date_str = parts[1]
        message = parts[2] if len(parts) > 2 else ""
        parsed_date = _parse_commit_datetime(date_str)
        if not parsed_date:
            continue
        changes = _run_git(repo_path, ["log", "--oneline", f"{tag}^..{tag}"])
        num_changes = len(changes.split("\n")) if changes else 0
        releases.append(
            {
                "tag": tag,
                "date": parsed_date.isoformat(),
                "message": message,
                "changes_count": num_changes,
            }
        )

    releases.sort(key=lambda r: r["date"])
    intervals: list[int] = []
    for idx in range(1, len(releases)):
        current = _parse_commit_datetime(str(releases[idx]["date"]))
        previous = _parse_commit_datetime(str(releases[idx - 1]["date"]))
        if current and previous:
            intervals.append((current - previous).days)

    return {
        "total_releases": len(releases),
        "releases": releases,
        "release_frequency": {
            "avg_days_between_releases": (sum(intervals) / len(intervals)) if intervals else None,
            "min_days_between_releases": min(intervals) if intervals else None,
            "max_days_between_releases": max(intervals) if intervals else None,
        },
    }


def _collect_collaboration_stats(repo_path: str, default_branch: str, commit_history: dict) -> dict:
    """Collect collaboration metrics aligned with server payload shape."""
    commits = commit_history.get("commits", []) if isinstance(commit_history, dict) else []
    authors_from_history = set()
    for commit in commits:
        raw_author = str(commit.get("author", "")).strip()
        if not raw_author:
            continue
        authors_from_history.add(raw_author.split("<", 1)[0].strip())

    # Parse collaboration trailers from commit messages.
    out = _run_git(
        repo_path,
        [
            "log",
            default_branch,
            "--format=COMMIT_START%n%H|||%aN|||%aE%n%B%nCOMMIT_END",
        ],
    )
    co_author_patterns = [
        "Co-authored-by:",
        "Reviewed-by:",
        "Signed-off-by:",
        "Tested-by:",
        "Reported-by:",
        "Acked-by:",
    ]

    collaboration_events: list[dict[str, Any]] = []
    author_collaborations: dict[tuple[str, str], int] = defaultdict(int)
    authors = set(authors_from_history)

    if out:
        blocks = [b for b in out.split("COMMIT_START\n") if b.strip()]
        del out
        for block in blocks:
            if "COMMIT_END" in block:
                block = block.split("COMMIT_END", 1)[0]
            lines = block.split("\n")
            if not lines:
                continue
            header = lines[0]
            parts = header.split("|||")
            if len(parts) != 3:
                continue
            commit_hash, author_name, _ = parts
            author = author_name
            authors.add(author)

            collaborators = set()
            for msg_line in lines[1:]:
                msg_line = msg_line.strip()
                if not msg_line:
                    continue
                for pattern in co_author_patterns:
                    if pattern not in msg_line:
                        continue
                    collab_part = msg_line.split(pattern, 1)[1].strip()
                    collab_name = collab_part.split("<", 1)[0].strip() if "<" in collab_part else collab_part
                    if collab_name and collab_name != author:
                        collaborators.add(collab_name)
                        authors.add(collab_name)

            if collaborators:
                collaboration_events.append(
                    {
                        "commit": commit_hash,
                        "author": author,
                        "collaborators": sorted(collaborators),
                        "type": "co-authorship",
                    }
                )
                for collab in collaborators:
                    pair = tuple(sorted([author, collab]))
                    author_collaborations[pair] += 1

    return {
        "overview": {
            "total_authors": len(authors),
            "total_collaboration_events": len(collaboration_events),
            "avg_collaborations_per_author": (
                len(collaboration_events) / len(authors) if authors else 0
            ),
        },
        "collaboration_network": {
            "top_collaborator_pairs": sorted(
                [
                    {"authors": list(pair), "collaboration_count": count}
                    for pair, count in author_collaborations.items()
                ],
                key=lambda item: item["collaboration_count"],
                reverse=True,
            )[:5],
            "collaboration_events": collaboration_events[:100],
        },
        "author_involvement": {
            "active_authors": len(authors),
            "collaboration_density": (
                len(author_collaborations) / (len(authors) * (len(authors) - 1) / 2)
                if len(authors) > 1
                else 0
            ),
        },
    }
