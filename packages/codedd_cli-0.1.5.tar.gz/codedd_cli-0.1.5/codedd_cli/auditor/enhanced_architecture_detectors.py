"""
Local enhanced architecture detectors for CLI Phase 2.

These detectors intentionally mirror the server's output contract:
- enhanced_technology_detection
- enhanced_relationship_analysis

They run fully on local source files so private code never leaves the machine.
"""

from __future__ import annotations

import json
import os
import re
from collections import defaultdict
from typing import Any


def _safe_read(path: str, max_bytes: int) -> str:
    try:
        if not os.path.isfile(path):
            return ""
        if os.path.getsize(path) > max_bytes:
            return ""
        with open(path, encoding="utf-8", errors="ignore") as fh:
            return fh.read()
    except OSError:
        return ""


def _extract_rel_path(file_path: str, cli_prefix: str) -> str:
    if file_path.startswith(cli_prefix):
        return file_path[len(cli_prefix):].lstrip("/")
    return file_path


def _compute_coupling(component_graph: dict[str, list[str]]) -> dict[str, Any]:
    if not component_graph:
        return {"coupling_level": "unknown", "analysis": "No components found"}

    out_degree: dict[str, int] = {}
    in_degree: dict[str, int] = {}
    for source, targets in component_graph.items():
        out_degree[source] = len(targets)
        in_degree.setdefault(source, 0)
        for target in targets:
            in_degree[target] = in_degree.get(target, 0) + 1
            out_degree.setdefault(target, 0)

    component_count = len(set(out_degree) | set(in_degree))
    if component_count == 0:
        return {"coupling_level": "unknown", "analysis": "No components found"}

    avg_eff = sum(out_degree.values()) / component_count
    avg_aff = sum(in_degree.values()) / component_count
    combined = (avg_eff + avg_aff) / 2

    if combined < 1.5:
        level = "low"
    elif combined < 3.0:
        level = "medium"
    else:
        level = "high"

    highly_coupled = sorted(
        [name for name in out_degree if (out_degree.get(name, 0) + in_degree.get(name, 0)) >= 5]
    )

    return {
        "coupling_level": level,
        "average_efferent_coupling": round(avg_eff, 2),
        "average_afferent_coupling": round(avg_aff, 2),
        "highly_coupled_components": highly_coupled[:20],
        "total_components": component_count,
    }


class LocalEnhancedTechnologyDetector:
    """Heuristic local detector returning server-compatible technology payload."""

    _FILE_HINTS = {
        "dockerfile": ("infrastructure", "Docker"),
        "docker-compose.yml": ("infrastructure", "Docker Compose"),
        "docker-compose.yaml": ("infrastructure", "Docker Compose"),
        "kubernetes.yml": ("infrastructure", "Kubernetes"),
        "kubernetes.yaml": ("infrastructure", "Kubernetes"),
        ".github/workflows": ("ci_cd", "GitHub Actions"),
        ".gitlab-ci.yml": ("ci_cd", "GitLab CI/CD"),
        "Jenkinsfile": ("ci_cd", "Jenkins"),
        "pyproject.toml": ("dependency", "Python"),
        "requirements.txt": ("dependency", "Python"),
        "package.json": ("dependency", "Node.js"),
        "go.mod": ("dependency", "Go"),
        "Cargo.toml": ("dependency", "Rust"),
        "pom.xml": ("dependency", "Java"),
    }

    _DEP_HINTS = {
        "react": ("frontend_frameworks", "React"),
        "next": ("frontend_frameworks", "Next.js"),
        "vue": ("frontend_frameworks", "Vue"),
        "angular": ("frontend_frameworks", "Angular"),
        "fastapi": ("backend_frameworks", "FastAPI"),
        "flask": ("backend_frameworks", "Flask"),
        "django": ("backend_frameworks", "Django"),
        "express": ("backend_frameworks", "Express"),
        "spring": ("backend_frameworks", "Spring"),
        "typescript": ("languages", "TypeScript"),
        "python": ("languages", "Python"),
        "redis": ("databases", "Redis"),
        "postgres": ("databases", "PostgreSQL"),
        "postgresql": ("databases", "PostgreSQL"),
        "mysql": ("databases", "MySQL"),
        "mongodb": ("databases", "MongoDB"),
        "sqlite": ("databases", "SQLite"),
        "rabbitmq": ("messaging", "RabbitMQ"),
        "kafka": ("messaging", "Kafka"),
        "celery": ("messaging", "Celery"),
        "docker": ("infrastructure", "Docker"),
        "kubernetes": ("infrastructure", "Kubernetes"),
    }

    def __init__(self, max_file_bytes: int = 1024 * 1024) -> None:
        self.max_file_bytes = max_file_bytes

    def detect(
        self,
        file_paths: list[str],
        local_base: str,
        cli_prefix: str,
    ) -> dict[str, Any]:
        technology_hits: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
        relationship_map: dict[str, list[Any]] = defaultdict(list)
        all_names: set[str] = set()

        for fp in file_paths:
            rel = _extract_rel_path(fp, cli_prefix)
            file_name = os.path.basename(rel)
            local_path = os.path.normpath(os.path.join(local_base, rel))

            # File-name/structure hints
            lower_rel = rel.lower()
            for hint, (category, name) in self._FILE_HINTS.items():
                if hint.lower() in lower_rel:
                    evidence = [f"filename_match: {hint}"]
                    technology_hits[category][name] = {
                        "name": name,
                        "confidence_score": max(
                            45, technology_hits[category].get(name, {}).get("confidence_score", 0)
                        ),
                        "evidence": sorted(
                            set(technology_hits[category].get(name, {}).get("evidence", []) + evidence)
                        ),
                    }
                    all_names.add(name)

            # Extension language hints
            _, ext = os.path.splitext(file_name.lower())
            if ext in {".py"}:
                technology_hits["languages"]["Python"] = {
                    "name": "Python",
                    "confidence_score": 40,
                    "evidence": ["filename_match: *.py"],
                }
                all_names.add("Python")
            elif ext in {".ts", ".tsx"}:
                technology_hits["languages"]["TypeScript"] = {
                    "name": "TypeScript",
                    "confidence_score": 40,
                    "evidence": [f"filename_match: *{ext}"],
                }
                all_names.add("TypeScript")
            elif ext in {".js", ".jsx"}:
                technology_hits["languages"]["JavaScript"] = {
                    "name": "JavaScript",
                    "confidence_score": 40,
                    "evidence": [f"filename_match: *{ext}"],
                }
                all_names.add("JavaScript")

            # Dependency/content hints
            content = _safe_read(local_path, self.max_file_bytes)
            if not content:
                continue

            if file_name == "package.json":
                try:
                    pkg = json.loads(content)
                    deps = {
                        **(pkg.get("dependencies") or {}),
                        **(pkg.get("devDependencies") or {}),
                    }
                    for dep in deps:
                        d = dep.lower()
                        for needle, (category, tech_name) in self._DEP_HINTS.items():
                            if needle in d:
                                evidence = [f"dependency_found_in_deps: {dep}"]
                                prior = technology_hits[category].get(tech_name, {})
                                technology_hits[category][tech_name] = {
                                    "name": tech_name,
                                    "confidence_score": max(55, prior.get("confidence_score", 0)),
                                    "evidence": sorted(set(prior.get("evidence", []) + evidence)),
                                }
                                all_names.add(tech_name)
                except Exception:
                    pass

            if file_name == "requirements.txt":
                for line in content.splitlines():
                    dep = line.strip()
                    if not dep or dep.startswith("#"):
                        continue
                    pkg_name = re.split(r"[<>=~!]", dep, maxsplit=1)[0].strip().lower()
                    for needle, (category, tech_name) in self._DEP_HINTS.items():
                        if needle in pkg_name:
                            evidence = [f"dependency_found_in_deps: {pkg_name}"]
                            prior = technology_hits[category].get(tech_name, {})
                            technology_hits[category][tech_name] = {
                                "name": tech_name,
                                "confidence_score": max(55, prior.get("confidence_score", 0)),
                                "evidence": sorted(set(prior.get("evidence", []) + evidence)),
                            }
                            all_names.add(tech_name)

            if file_name == "pyproject.toml":
                dep_matches = re.findall(r'["\']([A-Za-z0-9_\-\.]+)["\']\s*[<>=~!]', content)
                for dep in dep_matches:
                    d = dep.lower()
                    for needle, (category, tech_name) in self._DEP_HINTS.items():
                        if needle in d:
                            prior = technology_hits[category].get(tech_name, {})
                            technology_hits[category][tech_name] = {
                                "name": tech_name,
                                "confidence_score": max(50, prior.get("confidence_score", 0)),
                                "evidence": sorted(
                                    set(prior.get("evidence", []) + [f"dependency_found_in_deps: {dep}"])
                                ),
                            }
                            all_names.add(tech_name)

            if "docker-compose" in file_name:
                service_count = len(re.findall(r"^\s{2,}[a-zA-Z0-9_-]+:\s*$", content, flags=re.MULTILINE))
                if service_count > 1:
                    relationship_map["service_dependencies"].append(
                        {"file": rel, "hint": f"docker_compose_services:{service_count}"}
                    )

        detected = {category: list(items.values()) for category, items in technology_hits.items()}
        relationship_count = sum(len(v) for v in relationship_map.values())
        return {
            "detected_technologies": detected,
            "relationship_map": dict(relationship_map),
            "technology_count": len(all_names),
            "relationship_count": relationship_count,
        }


class LocalEnhancedRelationshipDetector:
    """Heuristic local detector for communication/coupling/critical dependencies."""

    def __init__(self, max_file_bytes: int = 1024 * 1024) -> None:
        self.max_file_bytes = max_file_bytes

    def detect(
        self,
        file_paths: list[str],
        local_base: str,
        cli_prefix: str,
        detected_technologies: dict[str, list[dict[str, Any]]],
    ) -> dict[str, Any]:
        relationships: dict[str, list[dict[str, Any]]] = defaultdict(list)
        component_graph: dict[str, set[str]] = defaultdict(set)
        patterns: set[str] = set()

        sync_count = 0
        async_count = 0

        for fp in file_paths:
            rel = _extract_rel_path(fp, cli_prefix)
            local_path = os.path.normpath(os.path.join(local_base, rel))
            content = _safe_read(local_path, self.max_file_bytes)
            if not content:
                continue

            source_component = rel.split("/", 1)[0] if "/" in rel else "root"

            # Import edges -> coupling graph
            for m in re.findall(r"^\s*(?:from|import)\s+([A-Za-z0-9_\.]+)", content, flags=re.MULTILINE):
                target_component = m.split(".", 1)[0]
                if target_component and target_component != source_component:
                    component_graph[source_component].add(target_component)
                    relationships["code_import"].append(
                        {
                            "source_component": source_component,
                            "target_component": target_component,
                            "type": "import",
                            "evidence": f"import:{m}",
                        }
                    )

            # Sync communication indicators
            sync_hits = len(
                re.findall(
                    r"(fetch\(|axios\.|requests\.(get|post|put|delete)\(|httpx\.(get|post|put|delete)\()",
                    content,
                )
            )
            if sync_hits:
                sync_count += sync_hits
                relationships["sync_api_calls"].append({"file": rel, "count": sync_hits})

            # Async communication indicators
            async_hits = len(
                re.findall(
                    r"(publish\(|subscribe\(|kafka|rabbitmq|celery|sqs|sns|websocket|socket\.emit|event_bus)",
                    content.lower(),
                )
            )
            if async_hits:
                async_count += async_hits
                relationships["async_messaging"].append({"file": rel, "count": async_hits})

            if "docker-compose" in rel.lower():
                svc = len(re.findall(r"^\s{2,}[a-zA-Z0-9_-]+:\s*$", content, flags=re.MULTILINE))
                if svc > 1:
                    patterns.add("Microservices Architecture")

        # Infer patterns from technologies as fallback
        flat_tech = {
            item.get("name", "").lower()
            for items in detected_technologies.values()
            for item in items
            if isinstance(item, dict)
        }
        if any(t in flat_tech for t in {"docker", "kubernetes", "docker compose"}):
            patterns.add("Containerized Deployment")
        if any("react" in t or "vue" in t or "angular" in t for t in flat_tech):
            patterns.add("Component-Based Frontend Architecture")
        if any(t in flat_tech for t in {"fastapi", "flask", "django", "express", "spring"}):
            patterns.add("RESTful API Design")
        if not patterns:
            patterns.add("Monolithic Architecture")

        component_graph_lists = {k: sorted(v) for k, v in component_graph.items()}
        coupling_analysis = _compute_coupling(component_graph_lists)

        if sync_count and async_count:
            primary = "hybrid"
        elif async_count:
            primary = "asynchronous"
        elif sync_count:
            primary = "synchronous"
        else:
            primary = "unknown"

        communication_patterns = {
            "primary_communication": primary,
            "sync_relationships": sync_count,
            "async_relationships": async_count,
        }

        # Critical dependencies: components with highest degree.
        degree: dict[str, int] = defaultdict(int)
        for src, tgts in component_graph_lists.items():
            degree[src] += len(tgts)
            for tgt in tgts:
                degree[tgt] += 1
        critical_dependencies = [name for name, _ in sorted(degree.items(), key=lambda kv: kv[1], reverse=True)[:10]]

        relationship_count = sum(len(v) for v in relationships.values())
        return {
            "relationships": dict(relationships),
            "component_graph": component_graph_lists,
            "architectural_patterns": sorted(patterns),
            "coupling_analysis": coupling_analysis,
            "communication_patterns": communication_patterns,
            "critical_dependencies": critical_dependencies,
            "relationship_count": relationship_count,
            "component_count": len(component_graph_lists),
        }
