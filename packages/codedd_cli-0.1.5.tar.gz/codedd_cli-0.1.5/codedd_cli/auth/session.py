"""
Session helpers for ensuring the user is authenticated before running
commands that require a token.
"""

import functools
import time
from collections.abc import Callable

import typer
from rich.console import Console

from codedd_cli.auth.token_manager import TokenManager
from codedd_cli.config.constants import TOKEN_VERIFY_CACHE_TTL_SECONDS
from codedd_cli.config.settings import ConfigManager

console = Console()


def _verify_token_server_side(cfg: ConfigManager) -> bool:
    """
    Return True if the stored token is valid according to the server.

    A successful verification result is cached in ``config.toml`` for
    ``TOKEN_VERIFY_CACHE_TTL_SECONDS`` (default 5 minutes).  Subsequent
    commands that run within the TTL window skip the network round-trip
    entirely.  The cache is invalidated on logout (``clear_session``).

    Network errors are treated as *inconclusive* (return True) so that
    transient connectivity issues don't block commands — each command will
    then surface its own API error naturally.
    """
    # --- cache hit: skip server call if verified recently ---
    last_verified = cfg.token_verified_at
    if last_verified and (time.monotonic() - _monotonic_from_epoch(last_verified)) < TOKEN_VERIFY_CACHE_TTL_SECONDS:
        return True

    # Deferred imports to avoid circular dependency:
    # api.client → auth.token_manager → auth.__init__ → auth.session
    from codedd_cli.api.client import CodeDDClient  # noqa: PLC0415
    from codedd_cli.api.endpoints import Endpoints  # noqa: PLC0415

    try:
        with CodeDDClient(config=cfg) as client:
            resp = client.post(Endpoints.VERIFY_TOKEN)
        if resp.status_code == 200 and resp.json().get("status") == "success":
            # Persist wall-clock timestamp; monotonic offset computed on read.
            cfg.token_verified_at = time.time()
            cfg.save()
            return True
        return False
    except Exception:
        # Inconclusive — let the command fail with its own error if needed.
        return True


def _monotonic_from_epoch(epoch_ts: float) -> float:
    """
    Convert a stored ``time.time()`` wall-clock value to an approximate
    monotonic offset so the cache TTL comparison uses a clock that never
    goes backwards (e.g. on DST changes or NTP adjustments).

    The conversion is: monotonic_now - (time_now - epoch_ts)
    """
    return time.monotonic() - (time.time() - epoch_ts)


def require_auth(func: Callable) -> Callable:
    """
    Decorator that aborts a CLI command when the user is not authenticated.

    Checks:
    1. Config file has a ``token_hint`` (session metadata present).
    2. OS keychain (or ``CODEDD_API_TOKEN`` env-var) has the actual token.
    3. Server confirms the token is still valid — result cached for
       ``TOKEN_VERIFY_CACHE_TTL_SECONDS`` to avoid a network call on every
       rapid-fire command.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        cfg = ConfigManager()
        token = TokenManager.retrieve()

        if not cfg.is_authenticated or not token:
            console.print(
                "[bold red]Not authenticated.[/bold red]  "
                "Run [bold cyan]codedd auth login[/bold cyan] first."
            )
            raise typer.Exit(code=1)

        if not _verify_token_server_side(cfg):
            console.print(
                "[bold red]Authentication token is invalid or has been revoked.[/bold red]  "
                "Run [bold cyan]codedd auth login[/bold cyan] to re-authenticate."
            )
            raise typer.Exit(code=1)

        return func(*args, **kwargs)

    return wrapper
