from setuptools import setup

with open("README.md", "r") as arq:
    readme = arq.read()

setup(name='auth-bff',
    version='0.0.2',
    license='MIT License',
    author='Jhonathan Alves de Carvalho',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='jhonathanalves_br@hotmail.com',
    keywords='auth bff',
    description=u'Auth backend for frontend',
    packages=['auth_bff'],
    install_requires=[
"fastapi==0.135.3",
"httpx==0.28.1",
"setuptools==75.8.0",
"starlette==1.0.0",
    ]
)