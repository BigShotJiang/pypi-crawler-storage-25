# BFF

BFF (Backend-for-Frontend) authentication helper library for Keycloak, designed for FastAPI/Starlette apps.