import json
import uuid
import httpx
from fastapi.responses import RedirectResponse
from starlette import status
import hashlib
import base64
import secrets
from starlette.datastructures import URL
from datetime import datetime, timedelta, timezone
from typing import TypedDict, Any, Unpack
from fastapi import Request, Response

class BFFConfig(TypedDict):
    redis: Any
    keycloak_url: Any
    keycloak_realm: Any
    redirect_url: Any
    redirect_url_callback: Any
    bridge_domain_url: Any
    oauth2_scheme: Any
    decode_token: Any
    cookies: Any

config: BFFConfig = {"cookies": ["client_id", "access_token", "refresh_token", "grant_type"]}

def configure(new_config: BFFConfig = None, **kwargs: Unpack[BFFConfig]):
    if new_config:
        config.update(new_config)
    if kwargs:
        config.update(kwargs)

async def getExpires():
    return datetime.now(timezone.utc) + timedelta(days=7)

async def kc_url(path):
    return f'{config["keycloak_url"]}/realms/{config["keycloak_realm"]}/protocol/openid-connect/{path}'

async def login_bff(client_id, redirect_uri):
    try:
        code_verifier = secrets.token_urlsafe(64)
        state_base64 = {
            "code_verifier": code_verifier,
            "client_id": client_id,
            "redirect_uri": redirect_uri,
        }
        while True:
            state = str(uuid.uuid4())
            ok = await config["redis"].set(f'auth:state:{state}', json.dumps(state_base64), ex=300, nx=True)
            if ok:
                break

        response = RedirectResponse(url=(
            f'{await kc_url("auth")}'
            f"?client_id={client_id}"
            f"&redirect_uri={redirect_uri}"
            f"&response_type=code"
            f"&scope=openid"
            f'&code_challenge={base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).rstrip(b"=").decode()}'
            f"&code_challenge_method=S256"
            f"&state={state}"
        ))
        return response
    except Exception as e:
        return RedirectResponse(url=config["redirect_url_callback"])

async def callback_bff(code, state):
    state_data = json.loads(await config["redis"].getdel(f'auth:state:{state}'))
    code_verifier = state_data["code_verifier"]
    client_id = state_data["client_id"]
    redirect_uri = state_data["redirect_uri"]
    async with httpx.AsyncClient() as requests:
        response = await requests.post(
            f'{await kc_url("token")}',
            data={
                "grant_type": "authorization_code",
                "client_id": client_id,
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": code_verifier,
            }
        )
    response.raise_for_status()
    data = response.json() | state_data
    response = RedirectResponse(url=config["redirect_url"])
    [response.set_cookie(k, data.get(k, ""), httponly=True, secure=True, expires=await getExpires(), samesite="lax", domain=config["bridge_domain_url"]) for k in config["cookies"]]
    return response

async def atualizar_auth_bff(request: Request, response: Response):
    body = {"client_id": request.cookies.get("client_id", ""), "grant_type": "refresh_token", "refresh_token": request.cookies.get("refresh_token", "")}
    async with httpx.AsyncClient() as requests:
        res = await requests.post(await kc_url("token"), data=body, headers={"Content-Type": "application/x-www-form-urlencoded"})
        res.raise_for_status()
        data = res.json()
        [response.set_cookie(k, data.get(k, ""), httponly=True, secure=True, expires=await getExpires(), samesite="lax", domain=config["bridge_domain_url"]) for k in ["access_token", "refresh_token"]]
        return await config["decode_token"](request, data.get('access_token'))

async def buscar_auth_bff(request: Request):
    async with httpx.AsyncClient() as requests:
        return (await requests.get(await kc_url("userinfo"), headers={"Authorization": f'Bearer {await config["oauth2_scheme"](request)}'})).json()

async def deletar_auth_bff(request: Request, response: Response):
    async with httpx.AsyncClient() as requests:
        data={k: request.cookies.get(k, "") for k in config["cookies"]}
        data['token'] = data.get('refresh_token', "")
        await requests.post(await kc_url("revoke"), data=data, headers={"Content-Type": "application/x-www-form-urlencoded"})
        [response.delete_cookie(k, domain=config["bridge_domain_url"]) for k in data]
        response.status_code = status.HTTP_204_NO_CONTENT
        return response

async def auth_bridge_ticket_bff(request: Request, id):
    try:
        data = json.loads(await config["redis"].getdel(f'auth:ticket:{id}'))
        response = RedirectResponse(url=str(URL(config["redirect_url"]).include_query_params(**request.query_params)))
        [response.set_cookie(k, data.get(k, ""), httponly=True, secure=True, expires=await getExpires(), samesite="lax", domain=config["bridge_domain_url"]) for k in config["cookies"]]
        return response
    except Exception as e:
        return RedirectResponse(url=config["redirect_url_callback"])

async def auth_bridge_bff(body):
    data = body.model_dump()
    while True:
        ticket = str(uuid.uuid4())
        ok = await config["redis"].set(f'auth:ticket:{ticket}', json.dumps(data), ex=300, nx=True)
        if ok:
            return {"ticket": ticket}