#!/usr/bin/env python3
import os
import sys
import smtplib
import mimetypes
import argparse
import configparser
from email.message import EmailMessage
from pathlib import Path
from getpass import getpass

CONFIG_FILE = Path.home() / ".msend_config"


def setup_config():
    print("--- msend Configuration Setup ---")
    smtp_server = input("SMTP Server (default: smtp.gmail.com): ") or "smtp.gmail.com"
    smtp_port = input("SMTP Port (default: 465): ") or "465"
    sender_email = input("Your Email Address: ")
    sender_password = getpass("Your App Password (input hidden): ")

    print("\n--- Email Content Configuration ---")
    print(
        "Use '\\n' for line breaks in the body. Use '{filename}' to dynamically insert the file's name."
    )

    default_subject = "File delivery: {filename}"
    subject = input(f"Default Subject (press Enter for default): ") or default_subject

    default_body = (
        "Hello,\\n\\nPlease find the file '{filename}' attached.\\n\\nSent via msend."
    )
    body = input(f"Default Body (press Enter for default): ") or default_body

    config = configparser.ConfigParser()
    config["SMTP"] = {
        "server": smtp_server,
        "port": smtp_port,
        "email": sender_email,
        "password": sender_password,
        "subject": subject,
        "body": body,
    }

    with open(CONFIG_FILE, "w") as configfile:
        config.write(configfile)

    os.chmod(CONFIG_FILE, 0o600)
    print(f"\nConfiguration saved successfully to {CONFIG_FILE}!")


def load_config():
    if not CONFIG_FILE.exists():
        print("Error: Configuration not found.")
        print("Please run 'msend --setup' first to configure your credentials.")
        sys.exit(1)

    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)
    return config["SMTP"]


def send_email_with_attachment(
    recipient, filepath, config, custom_subject=None, custom_body=None
):
    if not os.path.isfile(filepath):
        print(f"Error: The file '{filepath}' does not exist.")
        sys.exit(1)

    filename = os.path.basename(filepath)

    if custom_subject:
        raw_subject = custom_subject
    else:
        raw_subject = config.get("subject")

    formatted_subject = raw_subject.format(filename=filename)

    if custom_body:
        raw_body = custom_body
    else:
        raw_body = config.get("body")

    formatted_body = raw_body.replace("\\n", "\n").format(filename=filename)

    msg = EmailMessage()
    msg["Subject"] = formatted_subject
    msg["From"] = config["email"]
    msg["To"] = recipient
    msg.set_content(formatted_body)

    ctype, encoding = mimetypes.guess_type(filepath)
    if ctype is None or encoding is not None:
        ctype = "application/octet-stream"
    maintype, subtype = ctype.split("/", 1)

    try:
        with open(filepath, "rb") as f:
            msg.add_attachment(
                f.read(), maintype=maintype, subtype=subtype, filename=filename
            )
    except Exception as e:
        print(f"Error reading file: {e}")
        sys.exit(1)

    print(f"Connecting to {config['server']}...")
    try:
        port = int(config["port"])
        if port == 465:
            with smtplib.SMTP_SSL(config["server"], port) as server:
                server.login(config["email"], config["password"])
                server.send_message(msg)
        else:
            with smtplib.SMTP(config["server"], port) as server:
                server.starttls()
                server.login(config["email"], config["password"])
                server.send_message(msg)

        print(f"Success! '{filename}' has been sent to {recipient}.")
    except smtplib.SMTPAuthenticationError:
        print(
            "Error: Authentication failed. Check your email and App Password in 'msend --setup'."
        )
    except Exception as e:
        print(f"Failed to send email: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="Send a file via email from the command line."
    )
    parser.add_argument(
        "--setup", action="store_true", help="Configure your SMTP and email credentials"
    )

    parser.add_argument("-s", "--subject", help="Override the default email subject")
    parser.add_argument(
        "-b", "--body", help="Override the default email body (use \\n for newlines)"
    )

    parser.add_argument("email", nargs="?", help="The recipient's email address")
    parser.add_argument(
        "file", nargs="?", help="The path to the file you want to attach"
    )

    args = parser.parse_args()

    if args.setup:
        setup_config()
        sys.exit(0)

    if not args.email or not args.file:
        parser.print_help()
        sys.exit(1)

    config = load_config()
    send_email_with_attachment(
        args.email,
        args.file,
        config,
        custom_subject=args.subject,
        custom_body=args.body,
    )


if __name__ == "__main__":
    main()
