"""UCP Registry API client."""

from __future__ import annotations

from typing import Any, Optional
from urllib.parse import urlencode

import httpx

from ucpregistry.types import (
    DiscoverOptions,
    EntityVersion,
    Merchant,
    ProductResult,
    PushOptions,
    SearchProductsOptions,
)

DEFAULT_BASE_URL = "https://ucpregistry.com"


class UCPRegistry:
    """Official client for the UCP Registry API.

    Discover UCP merchants, search products across stores,
    and manage registry entities.

    Examples:
        >>> from ucpregistry import UCPRegistry
        >>> registry = UCPRegistry()
        >>> merchants = registry.discover(platform="shopify")

        >>> # With API token for push access
        >>> registry = UCPRegistry(api_key="ucpr_...")
        >>> version = registry.push("merchants", "mystore.com", manifest={...})
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        api_key: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

        headers: dict[str, str] = {
            "Accept": "application/json",
            "User-Agent": "ucpregistry-python/0.1.0",
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        self._client = httpx.Client(headers=headers, timeout=timeout)

    def discover(
        self,
        search: Optional[str] = None,
        platform: Optional[str] = None,
        category: Optional[str] = None,
        has_checkout: Optional[bool] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[Merchant]:
        """Discover UCP-enabled merchants.

        Args:
            search: Keyword search (domain, description, category).
            platform: Filter by platform (shopify, woocommerce, etc.).
            category: Filter by Google Product Taxonomy category.
            has_checkout: Only merchants with checkout capability.
            sort: Sort by ucp_score, response_time, or domain.
            limit: Max results (1-50).

        Returns:
            List of Merchant objects.

        Examples:
            >>> merchants = registry.discover(platform="shopify", limit=5)
            >>> for m in merchants:
            ...     print(m.domain, m.ucp_score)
        """
        params: dict[str, str] = {}
        if search:
            params["search"] = search
        if platform:
            params["platform"] = platform
        if category:
            params["category"] = category
        if sort:
            params["sort"] = sort
        if limit:
            params["per_page"] = str(limit)

        url = f"{self.base_url}/api/v1/merchants"
        if params:
            url += f"?{urlencode(params)}"

        resp = self._client.get(url)
        resp.raise_for_status()
        data = resp.json()

        return [Merchant.from_dict(m) for m in data.get("data", [])]

    def get_merchant(self, domain: str) -> Merchant:
        """Get detailed information about a specific merchant.

        Args:
            domain: The merchant's domain (e.g., "allbirds.com").

        Returns:
            Merchant object with full details.

        Raises:
            httpx.HTTPStatusError: If merchant not found (404).

        Examples:
            >>> m = registry.get_merchant("imageskincare.com")
            >>> print(m.capabilities.checkout)  # True
            >>> print(m.transports)  # ['mcp', 'embedded']
        """
        resp = self._client.get(f"{self.base_url}/api/v1/merchants/{domain}")
        resp.raise_for_status()
        data = resp.json()

        return Merchant.from_dict(data.get("data", data))

    def search_products(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        domain: Optional[str] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[ProductResult]:
        """Search products across all UCP merchants.

        Args:
            query: Search query (product title, type, merchant).
            category: Filter by store category.
            domain: Filter to a specific merchant.
            min_price: Minimum price in dollars.
            max_price: Maximum price in dollars.
            sort: Sort by relevance, price_asc, or price_desc.
            limit: Max results (1-50).

        Returns:
            List of ProductResult objects.

        Examples:
            >>> products = registry.search_products(query="serum", sort="price_asc")
            >>> for p in products:
            ...     print(f"{p.title} - ${p.price} at {p.merchant}")
        """
        params: dict[str, str] = {}
        if query:
            params["q"] = query
        if category:
            params["category"] = category
        if domain:
            params["domain"] = domain
        if min_price is not None:
            params["min_price"] = str(min_price)
        if max_price is not None:
            params["max_price"] = str(max_price)
        if sort:
            params["sort"] = sort
        if limit:
            params["limit"] = str(limit)

        url = f"{self.base_url}/api/v1/products/search"
        if params:
            url += f"?{urlencode(params)}"

        resp = self._client.get(url)
        resp.raise_for_status()
        data = resp.json()

        return [ProductResult.from_dict(p) for p in data.get("data", [])]

    def push(
        self,
        entity_type: str,
        slug: str,
        manifest: dict[str, Any],
        commit_message: Optional[str] = None,
    ) -> EntityVersion:
        """Push a manifest version to an entity.

        Requires an API token with push scope.

        Args:
            entity_type: Entity type ("merchants" or "tools").
            slug: Entity identifier (domain or slug).
            manifest: The manifest data to push.
            commit_message: Description of changes.

        Returns:
            EntityVersion with version number and commit SHA.

        Examples:
            >>> version = registry.push("merchants", "mystore.com",
            ...     manifest={"version": "1.0", "capabilities": ["checkout"]},
            ...     commit_message="Initial push",
            ... )
            >>> print(version.version)  # '1.0.0'
        """
        resp = self._client.post(
            f"{self.base_url}/api/v1/entities/{entity_type}/{slug}/push",
            json={"manifest": manifest, "commit_message": commit_message},
        )
        resp.raise_for_status()

        return EntityVersion.from_dict(resp.json())

    def versions(self, entity_type: str, slug: str) -> list[EntityVersion]:
        """List version history for an entity.

        Requires an API token with read scope.
        """
        resp = self._client.get(
            f"{self.base_url}/api/v1/entities/{entity_type}/{slug}/versions"
        )
        resp.raise_for_status()
        data = resp.json()

        return [EntityVersion.from_dict(v) for v in data.get("data", [])]

    def diff(self, entity_type: str, slug: str, v1: str, v2: str) -> dict[str, Any]:
        """Diff two versions of an entity.

        Requires an API token with read scope.
        """
        resp = self._client.get(
            f"{self.base_url}/api/v1/entities/{entity_type}/{slug}/diff/{v1}/{v2}"
        )
        resp.raise_for_status()

        return resp.json()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> UCPRegistry:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


def create_client(
    base_url: str = DEFAULT_BASE_URL,
    api_key: Optional[str] = None,
) -> UCPRegistry:
    """Create a new UCPRegistry client.

    Examples:
        >>> registry = create_client(api_key="ucpr_...")
    """
    return UCPRegistry(base_url=base_url, api_key=api_key)
