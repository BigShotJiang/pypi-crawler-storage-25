"""UCP Registry — Official Python SDK for merchant discovery and registry management."""

from ucpregistry.client import UCPRegistry, create_client
from ucpregistry.types import (
    DiscoverOptions,
    EntityVersion,
    Merchant,
    MerchantBenchmark,
    MerchantCapabilities,
    ProductResult,
    PushOptions,
    SearchProductsOptions,
)

__version__ = "0.1.0"

__all__ = [
    "UCPRegistry",
    "create_client",
    "Merchant",
    "MerchantCapabilities",
    "MerchantBenchmark",
    "ProductResult",
    "EntityVersion",
    "DiscoverOptions",
    "SearchProductsOptions",
    "PushOptions",
]
