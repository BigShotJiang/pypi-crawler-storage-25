"""Type definitions for UCP Registry SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class MerchantCapabilities:
    """UCP capabilities supported by a merchant."""

    checkout: bool = False
    identity_linking: bool = False
    cart_management: bool = False
    order: bool = False
    payment_token: bool = False
    count: int = 0
    raw: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MerchantCapabilities:
        return cls(
            checkout=data.get("checkout", False),
            identity_linking=data.get("identity_linking", False),
            cart_management=data.get("cart_management", False),
            order=data.get("order", False),
            payment_token=data.get("payment_token", False),
            count=data.get("count", 0),
            raw=data.get("raw", []),
        )


@dataclass
class MerchantBenchmark:
    """Benchmark grade and score."""

    grade: str
    score: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MerchantBenchmark:
        return cls(grade=data["grade"], score=data["score"])


@dataclass
class SampleProduct:
    """A product from a merchant's catalog."""

    title: str
    price: Optional[float] = None
    currency: str = "USD"
    url: Optional[str] = None
    image_url: Optional[str] = None
    product_type: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SampleProduct:
        return cls(
            title=data.get("title", ""),
            price=data.get("price"),
            currency=data.get("currency", "USD"),
            url=data.get("url"),
            image_url=data.get("image_url"),
            product_type=data.get("product_type"),
        )


@dataclass
class Merchant:
    """A UCP-enabled merchant from the registry."""

    domain: str
    status: str
    registry_id: Optional[str] = None
    ucp_score: Optional[int] = None
    platform: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    extended_description: Optional[str] = None
    capabilities: MerchantCapabilities = field(default_factory=MerchantCapabilities)
    transports: list[str] = field(default_factory=list)
    response_time_ms: Optional[int] = None
    ucp_endpoint: Optional[str] = None
    last_checked_at: Optional[str] = None
    benchmark: Optional[MerchantBenchmark] = None
    sample_products: list[SampleProduct] = field(default_factory=list)
    plugins: list[str] = field(default_factory=list)
    extensions: list[str] = field(default_factory=list)
    registry_url: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Merchant:
        caps = data.get("capabilities", {})
        benchmark = data.get("benchmark")
        products = data.get("sample_products", [])

        return cls(
            domain=data.get("domain", ""),
            status=data.get("status", ""),
            registry_id=data.get("registry_id"),
            ucp_score=data.get("ucp_score"),
            platform=data.get("platform"),
            category=data.get("category") or data.get("store_category"),
            description=data.get("description"),
            extended_description=data.get("extended_description"),
            capabilities=MerchantCapabilities.from_dict(caps) if isinstance(caps, dict) else MerchantCapabilities(),
            transports=data.get("transports", []),
            response_time_ms=data.get("response_time_ms"),
            ucp_endpoint=data.get("ucp_endpoint") or data.get("ucp_url"),
            last_checked_at=data.get("last_checked_at"),
            benchmark=MerchantBenchmark.from_dict(benchmark) if benchmark else None,
            sample_products=[SampleProduct.from_dict(p) for p in (products or [])],
            plugins=data.get("plugins", []),
            extensions=data.get("extensions", []),
            registry_url=data.get("registry_url", ""),
        )


@dataclass
class ProductResult:
    """A product from the search API."""

    title: str
    price: Optional[float] = None
    currency: str = "USD"
    url: Optional[str] = None
    image_url: Optional[str] = None
    product_type: Optional[str] = None
    merchant: str = ""
    category: Optional[str] = None
    platform: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProductResult:
        return cls(
            title=data.get("title", ""),
            price=data.get("price"),
            currency=data.get("currency", "USD"),
            url=data.get("url"),
            image_url=data.get("image_url"),
            product_type=data.get("product_type"),
            merchant=data.get("merchant", ""),
            category=data.get("category") or data.get("store_category"),
            platform=data.get("platform"),
        )


@dataclass
class EntityVersion:
    """A version from the push API."""

    version: str
    commit_sha: str
    created_at: str
    diff_summary: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EntityVersion:
        return cls(
            version=data.get("version", ""),
            commit_sha=data.get("commit_sha", ""),
            created_at=data.get("created_at", ""),
            diff_summary=data.get("diff_summary", ""),
        )


@dataclass
class DiscoverOptions:
    """Options for merchant discovery."""

    search: Optional[str] = None
    platform: Optional[str] = None
    category: Optional[str] = None
    has_checkout: Optional[bool] = None
    sort: Optional[str] = None
    limit: Optional[int] = None


@dataclass
class SearchProductsOptions:
    """Options for product search."""

    query: Optional[str] = None
    category: Optional[str] = None
    domain: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    sort: Optional[str] = None
    limit: Optional[int] = None


@dataclass
class PushOptions:
    """Options for pushing a manifest version."""

    manifest: dict[str, Any] = field(default_factory=dict)
    commit_message: Optional[str] = None
