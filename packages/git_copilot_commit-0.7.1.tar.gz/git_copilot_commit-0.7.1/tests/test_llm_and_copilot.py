from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
from rich.console import Console

from git_copilot_commit.llms import copilot
from git_copilot_commit.llms import core as llm


def make_model(
    model_id: str,
    *,
    vendor: str | None = None,
    family: str | None = None,
    context_window_tokens: int | None = None,
    endpoints: tuple[str, ...] = (),
) -> llm.Model:
    return llm.Model(
        id=model_id,
        name=model_id,
        vendor=vendor,
        family=family,
        max_context_window_tokens=context_window_tokens,
        supported_endpoints=endpoints,
    )


def test_normalize_domain_and_url_helpers() -> None:
    assert copilot.normalize_domain(" HTTPS://GHE.Example.COM/path ") == (
        "ghe.example.com"
    )
    assert copilot.normalize_domain("not-a-host") is None
    assert copilot.normalize_domain("bad host.example.com") is None
    assert copilot.normalize_domain(None) is None

    urls = copilot.get_urls("github.example.com")
    assert urls["device_code_url"] == "https://github.example.com/login/device/code"
    assert urls["access_token_url"] == (
        "https://github.example.com/login/oauth/access_token"
    )
    assert urls["copilot_token_url"] == (
        "https://api.github.example.com/copilot_internal/v2/token"
    )

    assert copilot.get_github_api_base_url("github.com") == "https://api.github.com"
    assert copilot.get_github_api_base_url("github.example.com") == (
        "https://api.github.example.com"
    )
    assert copilot.get_base_url_from_token("token;proxy-ep=proxy.example.com") == (
        "https://api.example.com"
    )
    assert copilot.get_base_url_from_token("token-without-proxy-host") is None
    assert (
        copilot.get_copilot_base_url("token;proxy-ep=proxy.enterprise.example.com")
        == "https://api.enterprise.example.com"
    )
    assert (
        copilot.get_copilot_base_url(None, "github.example.com")
        == "https://copilot-api.github.example.com"
    )
    assert copilot.get_copilot_base_url() == "https://api.individual.githubcopilot.com"


def test_credentials_path_uses_platformdirs_state_dir(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    state_dir = tmp_path / "state"
    monkeypatch.setattr(
        copilot,
        "Settings",
        lambda: SimpleNamespace(
            state_dir=state_dir,
            config_file=tmp_path / "config.json",
        ),
    )

    assert copilot.credentials_path() == state_dir / "copilot-auth.json"


def test_save_and_load_credentials_round_trip(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    path = tmp_path / "state" / "copilot-auth.json"
    monkeypatch.setattr(copilot, "credentials_path", lambda: path)
    credentials = copilot.CopilotCredentials(
        github_access_token="ghu_123",
        copilot_token="copilot-token",
        copilot_expires_at=2_000_000_000,
        enterprise_domain="github.example.com",
    )

    saved_path = copilot.save_credentials(credentials)
    loaded = copilot.load_credentials()

    assert saved_path == path
    assert loaded == credentials
    assert oct(saved_path.stat().st_mode & 0o777) == "0o600"


def test_credentials_and_payload_parsers(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(copilot.time, "time", lambda: 1000.0)

    credentials = copilot.CopilotCredentials.from_dict(
        {
            "github_access_token": "ghu_123",
            "copilot_token": "token;proxy-ep=proxy.example.com",
            "copilot_expires_at": 1301,
            "enterprise_domain": "github.example.com",
        }
    )
    assert credentials.to_dict()["github_access_token"] == "ghu_123"
    assert not credentials.is_expired()
    assert credentials.base_url() == "https://api.example.com"

    expired = copilot.CopilotCredentials.from_dict(
        {
            "github_access_token": "ghu_123",
            "copilot_token": "plain-token",
            "copilot_expires_at": 1200,
        }
    )
    assert expired.is_expired()

    with pytest.raises(llm.LLMError):
        copilot.CopilotCredentials.from_dict({"github_access_token": ""})

    model = llm.Model.from_payload(
        {
            "id": "gpt-5.4",
            "name": "GPT-5.4",
            "vendor": "openai",
            "capabilities": {
                "family": "gpt-5",
                "limits": {"max_context_window_tokens": 272000},
            },
            "supported_endpoints": ["/responses", "", 123],
        }
    )
    assert model.family == "gpt-5"
    assert model.max_context_window_tokens == 272000
    assert model.supported_endpoints == ("/responses",)

    with pytest.raises(llm.LLMError):
        llm.Model.from_payload({"name": "Missing id"})

    viewer = copilot.GitHubViewer.from_payload(
        {
            "login": "kd",
            "name": "KD",
            "html_url": "https://github.com/kd",
            "type": "User",
            "plan": {"name": "Pro"},
        }
    )
    assert viewer.login == "kd"
    assert viewer.plan_name == "Pro"

    with pytest.raises(llm.LLMError):
        copilot.GitHubViewer.from_payload({})


def test_pick_model_covers_requested_defaults_and_fallbacks() -> None:
    models = [
        make_model("custom-model", vendor="openai"),
        make_model("gpt-4.1", vendor="openai"),
        make_model("claude-sonnet-4.6", vendor="anthropic"),
    ]

    assert llm.pick_model(models, "claude-sonnet-4.6").id == "claude-sonnet-4.6"

    with pytest.raises(llm.ModelSelectionError) as requested_error:
        llm.pick_model(models, "missing-model")
    assert requested_error.value.requested_model == "missing-model"

    assert (
        llm.pick_model(
            models,
            default_model="custom-model",
            provider_label="GitHub Copilot",
        ).id
        == "custom-model"
    )

    with pytest.raises(llm.ModelSelectionError) as config_error:
        llm.pick_model(
            models,
            default_model="missing-config-model",
            provider_label="GitHub Copilot",
            configured_default_model_path=Path("/tmp/config.json"),
        )
    assert config_error.value.configured_default_model == "missing-config-model"
    assert config_error.value.configured_default_model_path == Path("/tmp/config.json")

    assert llm.pick_model(models).id == "claude-sonnet-4.6"
    assert llm.pick_model([make_model("z-model"), make_model("a-model")]).id == (
        "z-model"
    )


def test_infer_api_surface_and_vendor_filtering() -> None:
    gpt5_model = make_model(
        "gpt-5.4",
        vendor="openai",
        family="gpt-5",
        endpoints=("/responses", "/chat/completions"),
    )
    chat_model = make_model(
        "gpt-4o",
        vendor="openai",
        endpoints=("/chat/completions",),
    )
    anthropic_model = make_model(
        "claude-sonnet-4.6",
        vendor="anthropic",
        endpoints=("/v1/messages",),
    )
    google_model = make_model("gemini-2.5-pro", vendor="google")

    assert llm.infer_api_surface(gpt5_model) == "responses"
    assert llm.infer_api_surface(chat_model) == "chat_completions"
    assert llm.infer_api_surface(anthropic_model) == "anthropic_messages"
    assert llm.infer_api_surface(google_model) == "chat_completions"
    assert llm.format_supported_endpoints(chat_model) == "/chat/completions"
    assert llm.format_supported_endpoints(google_model) == "default"
    assert llm.format_context_window(gpt5_model) == "?"

    assert llm.normalize_vendor_filter(" Gemini ") == "google"
    assert llm.normalize_vendor_filter("claude") == "anthropic"
    assert llm.normalize_vendor_filter("") is None

    models = [gpt5_model, anthropic_model, google_model]
    assert llm.filter_models_by_vendor(models, None) == models
    assert llm.filter_models_by_vendor(models, "gemini") == [google_model]

    with pytest.raises(llm.LLMError) as vendor_error:
        llm.filter_models_by_vendor(models, "mistral")
    assert "anthropic, google, openai" in str(vendor_error.value)


def test_reauthentication_and_json_cache_helpers(tmp_path: Path) -> None:
    assert copilot.should_reauthenticate(llm.LLMHttpError(401, "Unauthorized"))
    assert not copilot.should_reauthenticate(
        llm.LLMHttpError(500, "Internal Server Error")
    )
    assert copilot.should_reauthenticate(
        llm.LLMError("No cached Copilot credentials found.")
    )

    assert copilot.read_json_object(tmp_path / "missing.json") is None

    bad_json = tmp_path / "bad.json"
    bad_json.write_text("{bad", encoding="utf-8")
    with pytest.raises(llm.LLMError):
        copilot.read_json_object(bad_json)

    wrong_type = tmp_path / "list.json"
    wrong_type.write_text("[]", encoding="utf-8")
    with pytest.raises(llm.LLMError):
        copilot.read_json_object(wrong_type)


def test_extract_completion_text_handles_supported_shapes() -> None:
    assert (
        llm.extract_completion_text(
            {"choices": [{"message": {"content": "  feat: add support  "}}]}
        )
        == "feat: add support"
    )

    assert (
        llm.extract_completion_text(
            {
                "choices": [
                    {
                        "message": {
                            "content": [
                                {"text": "feat: first line"},
                                {"content": "second line"},
                                {"ignored": True},
                            ]
                        }
                    }
                ]
            }
        )
        == "feat: first line\nsecond line"
    )

    with pytest.raises(llm.LLMError):
        llm.extract_completion_text({"choices": [{"message": {"content": []}}]})


def test_extract_completion_text_reports_length_limited_reasoning_response() -> None:
    with pytest.raises(llm.LLMError) as error:
        llm.extract_completion_text(
            {
                "choices": [
                    {
                        "finish_reason": "length",
                        "message": {
                            "content": None,
                            "reasoning": "Thinking consumed the response budget.",
                        },
                    }
                ]
            }
        )

    message = str(error.value)
    assert "completion token limit" in message
    assert "reasoning text but no final assistant content" in message
    assert "`max_tokens`" in message


def test_extract_completion_text_reports_provider_finish_reason_value() -> None:
    with pytest.raises(llm.LLMError) as error:
        llm.extract_completion_text(
            {
                "choices": [
                    {
                        "finish_reason": {"code": "provider-specific"},
                        "message": {"content": None},
                    }
                ]
            }
        )

    assert 'finish_reason={"code": "provider-specific"}' in str(error.value)


def test_extract_response_text_handles_text_refusals_and_errors() -> None:
    assert llm.extract_response_text({"output_text": "  feat: add support  "}) == (
        "feat: add support"
    )
    assert (
        llm.extract_response_text(
            {
                "output": [
                    {
                        "content": [
                            {"text": "feat: first line"},
                            {"text": "second line"},
                        ]
                    }
                ]
            }
        )
        == "feat: first line\nsecond line"
    )
    assert (
        llm.extract_response_text(
            {"output": [{"content": [{"refusal": "Refused for safety"}]}]}
        )
        == "Refused for safety"
    )

    with pytest.raises(llm.LLMError):
        llm.extract_response_text({"output": []})


def test_chat_completion_request_disables_qwen_thinking() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        request_payload = json.loads(request.content.decode("utf-8"))
        assert request_payload["model"] == "Qwen/Qwen3.6-35B-A3B"
        assert request_payload["max_tokens"] == 256
        assert request_payload["reasoning_effort"] == "none"
        assert request_payload["chat_template_kwargs"] == {
            "enable_thinking": False,
            "thinking": False,
        }
        return httpx.Response(
            200,
            headers={"content-type": "application/json"},
            json={"choices": [{"message": {"content": "feat: disable thinking"}}]},
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        response = llm.chat_completion_request(
            client,
            "https://example.com/v1/chat/completions",
            {},
            model_id="Qwen/Qwen3.6-35B-A3B",
            prompt="Write a commit message",
            disable_thinking=True,
            max_tokens=256,
        )

    assert response == "feat: disable thinking"


def test_disable_thinking_options_cover_major_model_families() -> None:
    assert llm.disable_thinking_options(
        model_id="gemini-2.5-flash",
        api_surface="chat_completions",
    ) == {"reasoning_effort": "none"}
    assert llm.disable_thinking_options(
        model_id="gpt-5.4",
        api_surface="chat_completions",
    ) == {"reasoning_effort": "minimal"}
    assert llm.disable_thinking_options(
        model_id="gpt-5.3-codex",
        api_surface="chat_completions",
    ) == {"reasoning_effort": "none"}
    assert llm.disable_thinking_options(
        model_id="openai/gpt-oss-120b",
        api_surface="chat_completions",
    ) == {"reasoning_effort": "low"}
    assert llm.disable_thinking_options(
        model_id="claude-sonnet-4.6",
        api_surface="chat_completions",
    ) == {"thinking": {"type": "disabled"}}
    assert llm.disable_thinking_options(
        model_id="Qwen/Qwen3.6-35B-A3B",
        api_surface="chat_completions",
    ) == {
        "reasoning_effort": "none",
        "chat_template_kwargs": {
            "enable_thinking": False,
            "thinking": False,
        },
    }
    assert llm.disable_thinking_options(
        model_id="gpt-5.4",
        api_surface="responses",
    ) == {"reasoning": {"effort": "minimal"}}
    assert llm.disable_thinking_options(
        model_id="gpt-5.3-codex",
        api_surface="responses",
    ) == {"reasoning": {"effort": "none"}}


def test_responses_completion_request_disables_gpt5_thinking() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        request_payload = json.loads(request.content.decode("utf-8"))
        assert request_payload["model"] == "gpt-5.4"
        assert request_payload["max_output_tokens"] == 2048
        assert request_payload["reasoning"] == {"effort": "minimal"}
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            text=(
                "event: response.output_text.delta\n"
                'data: {"delta":"feat: disable thinking"}\n\n'
                "event: response.completed\n"
                'data: {"response":{"status":"completed"}}\n\n'
            ),
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        response = llm.responses_completion_request(
            client,
            "https://example.com/v1/responses",
            {},
            model_id="gpt-5.4",
            prompt="Write a commit message",
            disable_thinking=True,
            max_tokens=2048,
        )

    assert response == "feat: disable thinking"


def test_responses_completion_request_reports_reasoning_token_limit() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            text=(
                "event: response.incomplete\n"
                "data: {"
                '"response":{'
                '"status":"incomplete",'
                '"incomplete_details":{"reason":"max_output_tokens"},'
                '"output":[{"type":"reasoning","content":['
                '{"type":"reasoning_text","text":"thinking"}'
                "]}]"
                "}"
                "}\n\n"
            ),
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        with pytest.raises(llm.LLMError) as error:
            llm.responses_completion_request(
                client,
                "https://example.com/v1/responses",
                {},
                model_id="Qwen/Qwen3.6-35B-A3B",
                prompt="Write a split commit plan",
                disable_thinking=True,
                max_tokens=1024,
            )

    message = str(error.value)
    assert "max_output_tokens" in message
    assert "`--max-tokens`" in message
    assert "/chat/completions" in message


def test_request_json_retries_rate_limits_and_honors_retry_after(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempts = 0
    sleep_calls: list[float] = []

    monkeypatch.setattr(llm.time, "sleep", sleep_calls.append)

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            return httpx.Response(
                429,
                headers={"retry-after": "2"},
                text="rate limited",
                request=request,
            )
        return httpx.Response(
            200,
            headers={"content-type": "application/json"},
            json={"ok": True},
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        payload = llm.request_json(
            client,
            "GET",
            "https://example.com/models",
        )

    assert payload == {"ok": True}
    assert attempts == 2
    assert sleep_calls == [2.0]


def test_request_json_retries_transient_transport_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempts = 0
    sleep_calls: list[float] = []

    def zero_jitter(*values: object) -> float:
        del values
        return 0.0

    monkeypatch.setattr(llm.time, "sleep", sleep_calls.append)
    monkeypatch.setattr(llm.random, "uniform", zero_jitter)

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            raise httpx.ConnectError("temporary network issue", request=request)
        return httpx.Response(
            200,
            headers={"content-type": "application/json"},
            json={"ok": True},
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        payload = llm.request_json(
            client,
            "GET",
            "https://example.com/models",
        )

    assert payload == {"ok": True}
    assert attempts == 2
    assert sleep_calls == [llm.HTTP_RETRY_BASE_DELAY_SECONDS]


def test_complete_text_prompt_retries_retryable_http_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempts = 0
    sleep_calls: list[float] = []

    def zero_jitter(*values: object) -> float:
        del values
        return 0.0

    monkeypatch.setattr(llm.time, "sleep", sleep_calls.append)
    monkeypatch.setattr(llm.random, "uniform", zero_jitter)

    credentials = copilot.CopilotCredentials(
        github_access_token="ghu_123",
        copilot_token="copilot-token",
        copilot_expires_at=2_000_000_000,
    )
    model = make_model(
        "gpt-5.4",
        vendor="openai",
        family="gpt-5",
        endpoints=("/responses",),
    )

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            return httpx.Response(503, text="service unavailable", request=request)

        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            text=(
                "event: response.output_text.delta\n"
                'data: {"delta":"feat: add retries"}\n\n'
                "event: response.completed\n"
                'data: {"response":{"status":"completed"}}\n\n'
            ),
            request=request,
        )

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        completion = copilot.complete_text_prompt(
            client,
            credentials,
            model=model,
            prompt="Write a commit message",
        )

    assert completion == "feat: add retries"
    assert attempts == 2
    assert sleep_calls == [llm.HTTP_RETRY_BASE_DELAY_SECONDS]


def test_render_model_selection_error_and_time_formatting(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    error = llm.ModelSelectionError(
        models=[
            make_model("gpt-5.4", vendor="openai"),
            make_model("claude-sonnet-4.6", vendor="anthropic"),
        ],
        configured_default_model="missing-model",
        configured_default_model_path=Path("/tmp/config.json"),
    )
    console = Console(record=True, width=120)

    console.print(llm.render_model_selection_error(error))
    rendered = console.export_text()

    assert "Model Selection Error" in rendered
    assert "Config model" in rendered
    assert "missing-model" in rendered
    assert "Available Model IDs" in rendered
    assert "gpt-5.4" in rendered

    monkeypatch.setattr(llm.time, "time", lambda: 1_700_000_000.0)
    assert llm.format_relative_duration(3661) == "in 1h 1m"
    assert llm.format_relative_duration(-59) == "59s ago"
    assert llm.format_unix_timestamp(1_700_000_061).endswith("(in 1m 1s)")
    assert llm.format_unix_timestamp(10**20) == str(10**20)


def test_print_model_table_shows_context_window(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    table_console = Console(record=True, width=140)
    monkeypatch.setattr(llm, "console", table_console)

    llm.print_model_table(
        [
            make_model(
                "gpt-5.4",
                vendor="openai",
                context_window_tokens=272000,
                endpoints=("/responses",),
            )
        ]
    )

    rendered = table_console.export_text()

    assert "Context" in rendered
    assert "272,000" in rendered
