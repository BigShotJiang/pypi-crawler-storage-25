__version__: str = "2.1.0"
__version_tuple__: tuple[int, int, int] = (2, 1, 0)
__commit_id__: str | None = None

version = __version__
version_tuple = __version_tuple__
commit_id = __commit_id__
