"""Decorators for `errortools` module."""
