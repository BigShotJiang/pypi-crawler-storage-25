"""Website discovery skill — scan a URL for analytics tags."""

from __future__ import annotations

import logging
import re
import time
from typing import Any
from urllib.parse import urlparse

import httpx

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)

# Patterns to detect analytics providers in page source.
# Each entry: (provider_key, display_name, list of regex patterns, confidence_if_found)
#
# Verified against official documentation 2026-04-16.
# Sources:
#   GA4:       support.google.com/analytics/answer/14171598
#   GTM:       support.google.com/tagmanager/answer/14847097
#   Segment:   segment.com/docs/connections/sources/catalog/libraries/website/javascript
#   Mixpanel:  docs.mixpanel.com/docs/tracking-methods/sdks/javascript
#   Amplitude: amplitude.com/docs/data/sdks/browser-2
#   PostHog:   posthog.com/docs/libraries/js
#   Hotjar:    help.hotjar.com/hc/en-us/articles/115011639927
#   Plausible: plausible.io/docs/plausible-script
#   Fathom:    usefathom.com/docs/script/script-advanced
#   Heap:      developers.heap.io/docs/web
#   Meta Pixel: developers.facebook.com/docs/meta-pixel/get-started
ANALYTICS_PATTERNS: list[tuple[str, str, list[str], str]] = [
    (
        "ga4",
        "Google Analytics 4",
        [
            r"gtag\s*\(\s*['\"]config['\"]",           # gtag('config', 'G-...')
            r"G-[A-Z0-9]{6,12}",                        # GA4 measurement ID
            r"googletagmanager\.com/gtag/js",            # gtag.js loader URL
            r"google-analytics\.com/g/collect",          # GA4 collection endpoint
        ],
        "high",
    ),
    (
        "gtm",
        "Google Tag Manager",
        [
            r"googletagmanager\.com/gtm\.js",            # GTM script loader
            r"GTM-[A-Z0-9]{4,10}",                       # Container ID (variable length)
        ],
        "high",
    ),
    (
        "segment",
        "Segment",
        [
            r"cdn\.segment\.com",                        # Segment CDN host
            r"analytics\.load\(",                        # analytics.load('writeKey')
        ],
        "medium",  # analytics.load is fairly unique but cdn.segment.com alone is definitive
    ),
    (
        "mixpanel",
        "Mixpanel",
        [
            r"cdn\.mxpnl\.com",                          # Mixpanel CDN
            r"mixpanel\.init\(",                          # mixpanel.init('token')
        ],
        "high",
    ),
    (
        "amplitude",
        "Amplitude",
        [
            r"cdn\.amplitude\.com",                      # Amplitude CDN (US)
            r"cdn\.eu\.amplitude\.com",                   # Amplitude CDN (EU)
            r"amplitude\.init\(",                         # Modern SDK init
            r"amplitude\.getInstance\(",                  # Legacy v1 SDK
        ],
        "high",
    ),
    (
        "posthog",
        "PostHog",
        [
            r"i\.posthog\.com",                          # PostHog ingestion domain (us/eu)
            r"posthog\.init\(",                           # posthog.init('token', ...)
            r"assets\.i\.posthog\.com",                   # PostHog asset CDN
        ],
        "high",
    ),
    (
        "hotjar",
        "Hotjar",
        [
            r"static\.hotjar\.com",                      # Hotjar script CDN
            r"_hjSettings",                               # Config object (always present)
        ],
        "high",
    ),
    (
        "plausible",
        "Plausible Analytics",
        [
            r"plausible\.io/js/script",                  # Standard script src
        ],
        "high",
    ),
    (
        "fathom",
        "Fathom Analytics",
        [
            r"cdn\.usefathom\.com",                      # Fathom CDN
        ],
        "high",
    ),
    (
        "heap",
        "Heap Analytics",
        [
            r"cdn\.heapanalytics\.com",                  # Legacy Heap CDN
            r"cdn\.(us|eu)\.heap-api\.com",              # Modern Heap CDN (US/EU)
            r"heap\.load\(",                              # heap.load('appId')
        ],
        "high",
    ),
    (
        "facebook_pixel",
        "Meta Pixel",
        [
            r"connect\.facebook\.net.*fbevents\.js",     # Pixel script loader
            r"fbq\s*\(\s*['\"]init['\"]",                # fbq('init', 'pixelId')
        ],
        "high",
    ),
]


# ── Phase 2: JS fingerprint verification ──────────────────────────────────
#
# After regex detection, we download external scripts from known-safe domains
# and check for provider-specific strings inside the JS. This catches false
# positives (regex matched a generic string) and promotes medium → high
# confidence when the fingerprint confirms.
#
# Each fingerprint is a string that MUST appear in the downloaded JS for
# that provider. Verified against official docs 2026-04-16.

# Verified against actual downloaded scripts 2026-04-16.
# Reference scripts stored in engine/app/templates/discovery_reference_scripts/
JS_FINGERPRINTS: dict[str, list[str]] = {
    # GA4 gtag.js contains googletagmanager.com references
    "ga4": ["googletagmanager.com", "google.com/pagead"],
    # Segment bundle contains api.segment.io and cdn.segment.com
    "segment": ["api.segment.io", "cdn.segment.com"],
    # Mixpanel SDK contains api-js.mixpanel.com and cdn.mxpnl.com
    "mixpanel": ["api-js.mixpanel.com", "cdn.mxpnl.com"],
    # Amplitude SDK contains @amplitude/ package references
    "amplitude": ["@amplitude/", "amplitude"],
    # PostHog bundle contains .i.posthog.com ingestion domain
    "posthog": [".i.posthog.com"],
    # Hotjar npm package references hotjar.com
    "hotjar": ["hotjar.com"],
    # Heap script contains heapanalytics.com references
    "heap": ["heapanalytics.com"],
    # Meta Pixel contains facebook.com/tr collection endpoint
    "facebook_pixel": ["facebook.com/tr", "facebook.com/signals"],
    # Plausible script references plausible in its source
    "plausible": ["plausible"],
    # Fathom script references usefathom
    "fathom": ["usefathom"],
}

# Only download scripts from these domains (prevent SSRF / fetching arbitrary URLs)
SAFE_SCRIPT_DOMAINS = {
    "googletagmanager.com", "google-analytics.com",
    "cdn.segment.com",
    "cdn.mxpnl.com", "mixpanel.com",
    "cdn.amplitude.com", "cdn.eu.amplitude.com",
    "us-assets.i.posthog.com", "eu-assets.i.posthog.com",
    "static.hotjar.com",
    "cdn.heapanalytics.com", "cdn.us.heap-api.com", "cdn.eu.heap-api.com",
    "connect.facebook.net",
    "plausible.io",
    "cdn.usefathom.com",
}


def _extract_script_urls(html: str, base_url: str) -> list[str]:
    """Extract external script src URLs from HTML, filtering to safe domains."""
    pattern = r'<script[^>]+src=["\']([^"\']+)["\']'
    urls = []
    for match in re.finditer(pattern, html, re.IGNORECASE):
        src = match.group(1)
        if src.startswith("//"):
            src = "https:" + src
        elif src.startswith("/"):
            parsed = urlparse(base_url)
            src = f"{parsed.scheme}://{parsed.netloc}{src}"
        elif not src.startswith("http"):
            continue
        if any(domain in src for domain in SAFE_SCRIPT_DOMAINS):
            urls.append(src)
    return urls[:10]  # cap to avoid excessive requests


async def _verify_with_fingerprints(
    client: httpx.AsyncClient,
    detected: list[dict[str, Any]],
    script_urls: list[str],
) -> list[dict[str, Any]]:
    """Download external scripts and check for provider-specific fingerprints.

    - If fingerprint found → confidence becomes 'high', 'verified' flag set
    - If fingerprint NOT found for a 'medium' confidence match → add warning note
    - High confidence matches without fingerprints are left as-is (regex was specific enough)
    """
    if not script_urls:
        return detected

    # Download up to 5 scripts, first 30KB each
    script_contents: list[str] = []
    for url in script_urls[:5]:
        try:
            resp = await client.get(url, timeout=5.0)
            if resp.status_code == 200:
                script_contents.append(resp.text[:30_000])
        except Exception:
            continue

    if not script_contents:
        return detected

    combined = " ".join(script_contents).lower()

    for entry in detected:
        provider = entry["provider"]
        fingerprints = JS_FINGERPRINTS.get(provider)
        if not fingerprints:
            continue

        verified = any(fp.lower() in combined for fp in fingerprints)
        if verified:
            entry["confidence"] = "high"
            entry["verified"] = True
            entry.pop("note", None)
        elif entry["confidence"] == "medium":
            entry["note"] = (
                f"Regex matched but JS fingerprint not confirmed — possible false positive"
            )

    return detected


def _normalise_url(raw: str) -> str:
    """Ensure the URL has a scheme so httpx can fetch it."""
    raw = raw.strip()
    if not raw.startswith(("http://", "https://")):
        raw = f"https://{raw}"
    return raw


def _scan_html(html: str) -> list[dict[str, Any]]:
    """Scan HTML source for known analytics patterns.

    Returns detected providers with evidence: which patterns matched
    and a short snippet of the surrounding HTML for verification.
    """
    detected: list[dict[str, Any]] = []
    seen: set[str] = set()

    for key, display_name, patterns, confidence in ANALYTICS_PATTERNS:
        matches: list[dict[str, str]] = []
        for pattern in patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                # Extract a snippet around the match for evidence
                start = max(0, match.start() - 40)
                end = min(len(html), match.end() + 40)
                snippet = html[start:end].replace("\n", " ").strip()
                matches.append({
                    "pattern": pattern,
                    "snippet": snippet,
                })

        if matches and key not in seen:
            seen.add(key)
            entry: dict[str, Any] = {
                "provider": key,
                "name": display_name,
                "confidence": confidence,
                "evidence": matches,
            }
            if confidence != "high":
                entry["note"] = f"Possible match ({confidence} confidence) — may be a similar script"
            detected.append(entry)

    return detected


class WebsiteDiscoverSkill(BaseSkill):
    name = "website_discover"
    description = (
        "Scan a website URL to detect which analytics and tracking tools are installed. "
        "Use this FIRST when a user mentions their website, asks about their analytics setup, "
        "or wants to know what tracking they have. Also use this when the user asks about "
        "statistics or data from a website but no data sources are connected yet — scanning "
        "the site reveals which providers to connect. "
        "Returns detected providers (GA4, Mixpanel, PostHog, Segment, Amplitude, etc.) "
        "with evidence. After scanning, suggest connecting any detected sources using "
        "configure_source."
    )
    category = "connector"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "The website URL to scan (e.g. 'example.com' or 'https://example.com')",
            },
        },
        "required": ["url"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "detected": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "provider": {"type": "string"},
                        "name": {"type": "string"},
                        "note": {"type": "string", "description": "Only present if match is uncertain"},
                    },
                },
            },
            "page_title": {"type": "string"},
        },
    }
    guide = (
        "Use this during onboarding when the user mentions their website URL. "
        "It scans the page for analytics tags and tells you what's installed. "
        "Entries without a 'note' field are definite matches. Entries with a 'note' "
        "are uncertain — mention them casually (e.g. 'looks like you might also have Segment'). "
        "After discovery, propose connecting any detected sources."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        raw_url = params["url"]
        url = _normalise_url(raw_url)

        try:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=15.0,
                headers={
                    "User-Agent": "Mozilla/5.0 (compatible; Engageable/1.0; analytics-discovery)",
                },
            ) as client:
                resp = await client.get(url)
                resp.raise_for_status()

                html = resp.text
                detected = _scan_html(html)

                # Phase 2: verify regex matches by downloading external scripts
                # and checking for provider-specific fingerprints
                script_urls = _extract_script_urls(html, url)
                if script_urls and detected:
                    detected = await _verify_with_fingerprints(
                        client, detected, script_urls
                    )

            # Extract page title
            title_match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
            page_title = title_match.group(1).strip() if title_match else ""

            elapsed = int((time.monotonic() - t0) * 1000)

            return SkillResult(
                success=True,
                data={
                    "url": url,
                    "detected": detected,
                    "page_title": page_title,
                    "scan_time_ms": elapsed,
                },
                execution_time_ms=elapsed,
            )

        except httpx.HTTPStatusError as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=f"Failed to fetch {url}: HTTP {exc.response.status_code}",
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=f"Failed to scan {url}: {exc}",
                execution_time_ms=elapsed,
            )
