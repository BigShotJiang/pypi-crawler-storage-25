from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal

from engageable.skills.types import SkillResult

if TYPE_CHECKING:
    from mcp.types import Tool


class BaseSkill(ABC):
    """Abstract base for all Engageable skills (connectors and analysis)."""

    name: str
    description: str
    category: Literal["connector", "analysis"]
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    guide: str = ""
    mcp_visible: bool = False

    @abstractmethod
    async def execute(self, params: dict[str, Any]) -> SkillResult:
        """Run the skill with the given parameters."""
        ...

    def to_tool_definition(self) -> dict[str, Any]:
        """Generate an LLM-compatible tool/function definition from this skill."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    def to_mcp_tool(self) -> Tool:
        """Generate an MCP Tool definition from this skill."""
        from mcp.types import Tool

        return Tool(
            name=self.name,
            description=self.description,
            inputSchema=self.input_schema,
        )
