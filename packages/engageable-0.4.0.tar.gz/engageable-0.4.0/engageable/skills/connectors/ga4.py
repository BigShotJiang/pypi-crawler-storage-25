from __future__ import annotations

import logging
import time
from datetime import date, timedelta
from typing import Any

from google.analytics.admin_v1beta import AnalyticsAdminServiceClient
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    DateRange,
    Dimension,
    GetMetadataRequest,
    Metric,
    RunReportRequest,
)
from google.oauth2.credentials import Credentials as OAuthCredentials
from google.oauth2.service_account import Credentials as ServiceAccountCredentials

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)

GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"


def _resolve_date_range(raw: str) -> tuple[str, str]:
    """Turn a shortcut like 'yesterday' or 'last7days' into (start, end) strings."""
    today = date.today()
    lowered = raw.lower().strip()
    if lowered == "yesterday":
        d = today - timedelta(days=1)
        return d.isoformat(), d.isoformat()
    if lowered == "today":
        return today.isoformat(), today.isoformat()
    if lowered in ("last7days", "last_7_days"):
        return (today - timedelta(days=7)).isoformat(), (today - timedelta(days=1)).isoformat()
    if lowered in ("last14days", "last_14_days"):
        return (today - timedelta(days=14)).isoformat(), (today - timedelta(days=1)).isoformat()
    if lowered in ("last30days", "last_30_days"):
        return (today - timedelta(days=30)).isoformat(), (today - timedelta(days=1)).isoformat()
    if ":" in raw:
        parts = raw.split(":", 1)
        return parts[0].strip(), parts[1].strip()
    raise ValueError(f"Unrecognised date_range format: {raw!r}")


def _build_credentials(creds_data: dict) -> OAuthCredentials | ServiceAccountCredentials:
    """Build Google credentials from either OAuth tokens or a service account JSON."""
    if not creds_data:
        raise ValueError("No credentials provided — is a GA4 data source connected?")

    if creds_data.get("auth_type") == "oauth":
        # Read OAuth client ID/secret from credentials dict first (open source),
        # falling back to app settings (hosted).
        client_id = creds_data.get("google_client_id", "")
        client_secret = creds_data.get("google_client_secret", "")
        if not client_id or not client_secret:
            try:
                from engageable.config import get_settings
                settings = get_settings()
                client_id = client_id or settings.google_client_id
                client_secret = client_secret or settings.google_client_secret
            except Exception:
                pass
        if not client_id or not client_secret:
            raise ValueError(
                "GA4 OAuth requires google_client_id and google_client_secret. "
                "For BYOK, use service account credentials instead."
            )

        refresh_token = creds_data.get("refresh_token")
        if not refresh_token:
            logger.warning("GA4 OAuth credentials have no refresh_token — token refresh will fail")

        cred = OAuthCredentials(
            token=creds_data.get("access_token"),
            refresh_token=refresh_token,
            token_uri=GOOGLE_TOKEN_URL,
            client_id=client_id,
            client_secret=client_secret,
            scopes=["https://www.googleapis.com/auth/analytics.readonly"],
        )

        # Always refresh — access tokens expire after 1h and we don't
        # store the expiry timestamp, so the credential object thinks
        # it's still valid even when the token is stale.
        if refresh_token:
            try:
                import google.auth.transport.requests
                cred.refresh(google.auth.transport.requests.Request())
                logger.debug("Refreshed GA4 OAuth token")
            except Exception as exc:
                logger.warning("GA4 token refresh failed: %s", exc)

        return cred

    if not creds_data.get("client_email"):
        raise ValueError(
            "Credentials are not in a recognized format. "
            "Expected OAuth (auth_type='oauth') or service account (client_email). "
            "The user may need to reconnect the data source."
        )

    return ServiceAccountCredentials.from_service_account_info(
        creds_data,
        scopes=["https://www.googleapis.com/auth/analytics.readonly"],
    )


def _persist_refreshed_token(creds_data: dict, credentials: OAuthCredentials) -> None:
    """If the token was refreshed, persist the new access_token back to the DB.

    This is best-effort — if it fails, the next request will just refresh again.
    """
    try:
        if not isinstance(credentials, OAuthCredentials):
            return
        new_token = credentials.token
        old_token = creds_data.get("access_token")
        if new_token and new_token != old_token:
            from supabase import create_client
            from engageable.config import get_settings
            settings = get_settings()
            sb = create_client(settings.supabase_url, settings.supabase_service_role_key)

            # Update the credentials JSONB — find by provider + old access_token
            updated_creds = {**creds_data, "access_token": new_token}
            sb.table("data_source_connections").update({
                "credentials": updated_creds,
            }).eq("provider", "ga4").eq(
                "credentials->>access_token", old_token
            ).execute()
            logger.debug("Persisted refreshed GA4 access token")
    except Exception:
        logger.debug("Failed to persist refreshed token (non-critical)", exc_info=True)


class GA4QuerySkill(BaseSkill):
    name = "ga4_query"
    description = "Query Google Analytics 4 for metrics and dimensions over a date range."
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "property_id": {
                "type": "string",
                "description": "GA4 property ID (numeric, e.g. '123456789')",
            },
            "metrics": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Metric names (e.g. activeUsers, sessions, screenPageViews)",
            },
            "dimensions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Dimension names (e.g. date, country, pagePath)",
            },
            "date_range": {
                "type": "string",
                "description": "Date range: 'yesterday', 'last7days', 'last30days', or 'YYYY-MM-DD:YYYY-MM-DD'",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["property_id", "metrics", "date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "columns": {"type": "array", "items": {"type": "string"}},
            "rows": {"type": "array", "items": {"type": "array"}},
            "metadata": {"type": "object"},
        },
    }
    guide = (
        "Use this skill to fetch data from Google Analytics 4. "
        "You need a property_id and metric names plus a date range. "
        "The credentials and property_id are auto-injected from the connected "
        "data source — just provide the metrics, dimensions, and date_range you want."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            property_id = params["property_id"]
            metric_names = params["metrics"]
            date_range_raw = params["date_range"]
            creds_data = params["credentials"]
            dimension_names = params.get("dimensions", [])

            start_date, end_date = _resolve_date_range(date_range_raw)

            credentials = _build_credentials(creds_data)
            client = BetaAnalyticsDataClient(credentials=credentials)

            request = RunReportRequest(
                property=f"properties/{property_id}",
                metrics=[Metric(name=m) for m in metric_names],
                dimensions=[Dimension(name=d) for d in dimension_names] if dimension_names else [],
                date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
            )
            response = client.run_report(request)

            columns = (
                [d.name for d in (response.dimension_headers or [])]
                + [m.name for m in (response.metric_headers or [])]
            )
            rows: list[list[str | float]] = []
            for row in response.rows or []:
                values: list[str | float] = []
                for dv in row.dimension_values or []:
                    values.append(dv.value)
                for mv in row.metric_values or []:
                    try:
                        values.append(float(mv.value))
                    except ValueError:
                        values.append(mv.value)
                rows.append(values)

            _persist_refreshed_token(creds_data, credentials)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={"columns": columns, "rows": rows, "metadata": {
                    "source": "ga4",
                    "property_id": property_id,
                    "date_range": f"{start_date} to {end_date}",
                    "row_count": len(rows),
                    "query_time_ms": elapsed,
                }},
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("GA4 query failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class GA4ListPropertiesSkill(BaseSkill):
    """List GA4 properties accessible by the OAuth token."""

    name = "ga4_list_properties"
    description = (
        "List all GA4 properties the connected Google account has access to. "
        "Returns property IDs, names, and account names."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": [],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "properties": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "property_id": {"type": "string"},
                        "property_name": {"type": "string"},
                        "account_name": {"type": "string"},
                    },
                },
            },
        },
    }
    guide = (
        "Use this right after GA4 is connected to see what properties the user "
        "has access to. If there's only one, confirm it with the user. If multiple, "
        "ask which one to use. Credentials are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            creds_data = params["credentials"]
            credentials = _build_credentials(creds_data)

            client = AnalyticsAdminServiceClient(credentials=credentials)
            summaries = client.list_account_summaries()

            properties: list[dict[str, str]] = []
            for account in summaries:
                account_name = account.display_name or account.name
                for prop in account.property_summaries or []:
                    prop_id = prop.property.replace("properties/", "")
                    properties.append({
                        "property_id": prop_id,
                        "property_name": prop.display_name or f"Property {prop_id}",
                        "account_name": account_name,
                    })

            _persist_refreshed_token(creds_data, credentials)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "properties": properties,
                    "count": len(properties),
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            logger.warning("GA4 list_properties failed: %s", exc)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class GA4ProbeSkill(BaseSkill):
    """Quick health check — does this GA4 property have data?"""

    name = "ga4_probe"
    description = (
        "Run a quick health check on a GA4 property. Queries activeUsers for "
        "the last 30 days to verify the property has data and is active."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "property_id": {
                "type": "string",
                "description": "GA4 property ID (numeric, e.g. '123456789')",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["property_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "has_data": {"type": "boolean"},
            "active_users_30d": {"type": "integer"},
            "sessions_30d": {"type": "integer"},
            "pageviews_30d": {"type": "integer"},
        },
    }
    guide = (
        "Use this after the user selects a GA4 property to check if it has data. "
        "If has_data is false, the property may be a test account or newly set up. "
        "Credentials and property_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            property_id = params["property_id"]
            creds_data = params["credentials"]
            credentials = _build_credentials(creds_data)
            client = BetaAnalyticsDataClient(credentials=credentials)

            today = date.today()
            start = (today - timedelta(days=30)).isoformat()
            end = (today - timedelta(days=1)).isoformat()

            request = RunReportRequest(
                property=f"properties/{property_id}",
                metrics=[
                    Metric(name="activeUsers"),
                    Metric(name="sessions"),
                    Metric(name="screenPageViews"),
                ],
                date_ranges=[DateRange(start_date=start, end_date=end)],
            )
            response = client.run_report(request)

            active_users = 0
            sessions = 0
            pageviews = 0
            if response.rows:
                row = response.rows[0]
                vals = [mv.value for mv in row.metric_values or []]
                active_users = int(vals[0]) if len(vals) > 0 else 0
                sessions = int(vals[1]) if len(vals) > 1 else 0
                pageviews = int(vals[2]) if len(vals) > 2 else 0

            _persist_refreshed_token(creds_data, credentials)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "has_data": active_users > 0,
                    "active_users_30d": active_users,
                    "sessions_30d": sessions,
                    "pageviews_30d": pageviews,
                    "property_id": property_id,
                    "date_range": f"{start} to {end}",
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )


class GA4GetMetadataSkill(BaseSkill):
    """Discover available metrics, dimensions, and custom events for a GA4 property."""

    name = "ga4_get_metadata"
    description = (
        "Discover what metrics, dimensions, and custom events are available "
        "for a GA4 property. Returns standard and custom fields."
    )
    category = "connector"
    input_schema = {
        "type": "object",
        "properties": {
            "property_id": {
                "type": "string",
                "description": "GA4 property ID (numeric, e.g. '123456789')",
            },
            "credentials": {
                "type": "object",
                "description": "Auto-injected from connected data source. Do NOT provide this.",
            },
        },
        "required": ["property_id"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "standard_metrics": {"type": "array", "items": {"type": "string"}},
            "standard_dimensions": {"type": "array", "items": {"type": "string"}},
            "custom_metrics": {"type": "array", "items": {"type": "string"}},
            "custom_dimensions": {"type": "array", "items": {"type": "string"}},
            "custom_events": {"type": "array", "items": {"type": "string"}},
        },
    }
    guide = (
        "Use this to discover what fields are available for querying on a GA4 property. "
        "Standard fields work on all properties. Custom fields are specific to this property. "
        "Call this during exploration to build the connection profile. "
        "Credentials and property_id are auto-injected."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            property_id = params["property_id"]
            creds_data = params["credentials"]
            credentials = _build_credentials(creds_data)
            client = BetaAnalyticsDataClient(credentials=credentials)

            request = GetMetadataRequest(
                name=f"properties/{property_id}/metadata",
            )
            response = client.get_metadata(request)

            standard_metrics: list[str] = []
            custom_metrics: list[str] = []
            standard_dimensions: list[str] = []
            custom_dimensions: list[str] = []
            custom_events: list[str] = []

            for metric in response.metrics or []:
                api_name = metric.api_name
                if api_name.startswith("customEvent:"):
                    custom_events.append(api_name.replace("customEvent:", ""))
                elif api_name.startswith("customMetric:") or metric.custom_definition:
                    custom_metrics.append(api_name)
                else:
                    standard_metrics.append(api_name)

            for dim in response.dimensions or []:
                api_name = dim.api_name
                if api_name.startswith("customDimension:") or dim.custom_definition:
                    custom_dimensions.append(api_name)
                else:
                    standard_dimensions.append(api_name)

            _persist_refreshed_token(creds_data, credentials)

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "property_id": property_id,
                    "standard_metrics": standard_metrics,
                    "standard_dimensions": standard_dimensions,
                    "custom_metrics": custom_metrics,
                    "custom_dimensions": custom_dimensions,
                    "custom_events": custom_events,
                    "total_metrics": len(standard_metrics) + len(custom_metrics),
                    "total_dimensions": len(standard_dimensions) + len(custom_dimensions),
                },
                execution_time_ms=elapsed,
            )
        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
