"""MCP tool: analyze_cohort — define and compare user cohorts."""

from __future__ import annotations

import logging
import time
from typing import Any

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)


class AnalyzeCohortSkill(BaseSkill):
    """Define user cohorts and compare their behavior."""

    name = "analyze_cohort"
    description = (
        "Define and compare user cohorts by behavior, properties, or time periods. "
        "Use to understand how different groups of users behave differently. "
        "Example queries: 'Compare users who signed up in January vs February', "
        "'How do mobile users differ from desktop users?', "
        "'Compare power users (10+ sessions) vs casual users'. "
        "For retention-specific analysis (D1/D7/D30), use analyze_retention instead. "
        "For comparing a single metric between two periods, use compare_segments instead."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "metric": {
                "type": "string",
                "description": "The metric to compare across cohorts (e.g. 'sessions', 'screenPageViews').",
            },
            "cohort_dimension": {
                "type": "string",
                "description": (
                    "Dimension that defines cohorts. E.g. 'firstSessionDate' (signup cohort), "
                    "'deviceCategory' (mobile vs desktop), 'country', 'userAgeBracket'."
                ),
            },
            "date_range": {
                "type": "string",
                "description": "Date range: 'last30days', 'last90days', or 'YYYY-MM-DD:YYYY-MM-DD'.",
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
        },
        "required": ["metric", "cohort_dimension", "date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "cohorts": {"type": "array"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from engageable.skills.composite.helpers import (
            get_cred_provider, resolve_source, fetch_metric_for_period,
        )
        from engageable.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Fetch metric broken by the cohort dimension
        result = await fetch_metric_for_period(
            registry, cred_provider, source,
            params["metric"], params["date_range"],
            dimension=params["cohort_dimension"],
        )
        if not result.success:
            return result

        # Parse into cohorts
        rows = (result.data or {}).get("rows", [])
        columns = (result.data or {}).get("columns", [])

        if not rows:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "cohorts": [],
                    "summary": "No data found for the specified cohort dimension.",
                    "metadata": {"source": source, "total_time_ms": elapsed},
                },
                execution_time_ms=elapsed,
            )

        # Build cohort list from the dimension breakdown
        cohorts = []
        total = 0
        for row in rows:
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                cohort_name = str(row[0])
                value = float(row[-1]) if isinstance(row[-1], (int, float)) else 0
            elif isinstance(row, dict):
                cohort_name = str(next(iter(row.values())))
                value = float(list(row.values())[-1])
            else:
                continue

            cohorts.append({"cohort": cohort_name, "value": round(value, 2)})
            total += value

        # Sort by value descending
        cohorts.sort(key=lambda c: c["value"], reverse=True)

        # Add share percentage
        for c in cohorts:
            c["share_pct"] = round(c["value"] / total * 100, 1) if total > 0 else 0

        elapsed = int((time.monotonic() - t0) * 1000)

        # Summary
        top = cohorts[:3]
        summary_parts = [
            f"{len(cohorts)} cohorts found for '{params['cohort_dimension']}'.",
            f"Total {params['metric']}: {total:,.0f}.",
        ]
        if top:
            summary_parts.append(
                "Top cohorts: " + ", ".join(
                    f"{c['cohort']} ({c['share_pct']}%)" for c in top
                ) + "."
            )

        return SkillResult(
            success=True,
            data={
                "cohorts": cohorts,
                "total": round(total, 2),
                "num_cohorts": len(cohorts),
                "summary": " ".join(summary_parts),
                "metadata": {
                    "source": source,
                    "metric": params["metric"],
                    "cohort_dimension": params["cohort_dimension"],
                    "date_range": params["date_range"],
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )
