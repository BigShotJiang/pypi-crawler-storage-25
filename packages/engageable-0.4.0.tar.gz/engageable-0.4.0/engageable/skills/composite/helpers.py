"""Shared helpers for composite MCP skills."""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from engageable.mcp.credentials import CredentialProvider, EnvCredentialProvider
from engageable.skills.types import SkillResult


def get_cred_provider(params: dict[str, Any]) -> CredentialProvider:
    """Extract credential provider from params, falling back to env."""
    return params.get("_credential_provider", EnvCredentialProvider())


def resolve_source(params: dict[str, Any], cred_provider: CredentialProvider) -> str | None:
    """Resolve the data source — explicit or auto-select first available."""
    source = params.get("source")
    if source:
        return source
    providers = cred_provider.list_providers()
    return providers[0] if providers else None


def resolve_date_range(raw: str) -> tuple[str, str]:
    """Turn date range shortcuts into (from_date, to_date) ISO strings."""
    today = date.today()
    yesterday = today - timedelta(days=1)
    lowered = raw.lower().strip().replace("_", "")

    lookup = {
        "yesterday": (yesterday, yesterday),
        "today": (today, today),
        "last7days": (today - timedelta(days=7), yesterday),
        "last14days": (today - timedelta(days=14), yesterday),
        "last30days": (today - timedelta(days=30), yesterday),
        "last90days": (today - timedelta(days=90), yesterday),
    }

    if lowered in lookup:
        start, end = lookup[lowered]
        return start.isoformat(), end.isoformat()

    if ":" in raw:
        parts = raw.split(":", 1)
        return parts[0].strip(), parts[1].strip()

    raise ValueError(f"Unrecognised date_range format: {raw!r}")


async def fetch_time_series(
    registry: Any,
    cred_provider: CredentialProvider,
    source: str,
    metric: str,
    date_range: str,
    dimensions: list[str] | None = None,
    granularity: str = "day",
) -> SkillResult:
    """Fetch time-series data from a connector skill.

    Returns the SkillResult from the underlying connector.
    """
    creds = cred_provider.get_credentials(source)
    if creds is None:
        return SkillResult(success=False, error=f"No credentials configured for {source}.")
    config = cred_provider.get_config(source)

    if source == "ga4":
        return await _fetch_ga4(registry, creds, config, metric, date_range, dimensions)
    elif source == "mixpanel":
        return await _fetch_mixpanel(registry, creds, config, metric, date_range, granularity)
    elif source == "posthog":
        return await _fetch_posthog(registry, creds, config, metric, date_range)
    else:
        return SkillResult(success=False, error=f"Unknown source: {source}")


async def fetch_metric_for_period(
    registry: Any,
    cred_provider: CredentialProvider,
    source: str,
    metric: str,
    date_range: str,
    dimension: str | None = None,
) -> SkillResult:
    """Fetch a single metric (optionally broken by a dimension) for a period.

    Unlike fetch_time_series, this does NOT force a date dimension —
    useful for segment comparisons where you want totals per segment.
    """
    creds = cred_provider.get_credentials(source)
    if creds is None:
        return SkillResult(success=False, error=f"No credentials configured for {source}.")
    config = cred_provider.get_config(source)

    if source == "ga4":
        skill = registry.get_skill("ga4_query")
        if skill is None:
            return SkillResult(success=False, error="ga4_query skill not available")
        dims = [dimension] if dimension else []
        return await skill.execute({
            "property_id": config.get("property_id", ""),
            "metrics": [metric],
            "dimensions": dims,
            "date_range": date_range,
            "credentials": creds,
        })
    elif source == "mixpanel":
        skill = registry.get_skill("mixpanel_query")
        if skill is None:
            return SkillResult(success=False, error="mixpanel_query skill not available")
        from_date, to_date = resolve_date_range(date_range)
        return await skill.execute({
            "project_id": config.get("project_id", ""),
            "event": metric,
            "from_date": from_date,
            "to_date": to_date,
            "credentials": creds,
        })
    elif source == "posthog":
        skill = registry.get_skill("posthog_query")
        if skill is None:
            return SkillResult(success=False, error="posthog_query skill not available")
        from_date, to_date = resolve_date_range(date_range)
        dim_select = f", {dimension}" if dimension else ""
        dim_group = f", {dimension}" if dimension else ""
        query = (
            f"SELECT count() AS count{dim_select} "
            f"FROM events WHERE event = '{metric}' "
            f"GROUP BY 1{dim_group}"
        )
        return await skill.execute({
            "project_id": config.get("project_id", ""),
            "query": query,
            "date_from": from_date,
            "date_to": to_date,
            "credentials": creds,
        })
    else:
        return SkillResult(success=False, error=f"Unknown source: {source}")


# ---- Private connector dispatchers ----

async def _fetch_ga4(
    registry: Any, creds: dict, config: dict,
    metric: str, date_range: str, dimensions: list[str] | None,
) -> SkillResult:
    skill = registry.get_skill("ga4_query")
    if skill is None:
        return SkillResult(success=False, error="ga4_query skill not available")
    dims = ["date"]
    if dimensions:
        dims.extend(d for d in dimensions if d != "date")
    return await skill.execute({
        "property_id": config.get("property_id", ""),
        "metrics": [metric],
        "dimensions": dims,
        "date_range": date_range,
        "credentials": creds,
    })


async def _fetch_mixpanel(
    registry: Any, creds: dict, config: dict,
    metric: str, date_range: str, granularity: str,
) -> SkillResult:
    skill = registry.get_skill("mixpanel_query")
    if skill is None:
        return SkillResult(success=False, error="mixpanel_query skill not available")
    from_date, to_date = resolve_date_range(date_range)
    unit = {"day": "day", "week": "week", "month": "month"}.get(granularity, "day")
    return await skill.execute({
        "project_id": config.get("project_id", ""),
        "event": metric,
        "from_date": from_date,
        "to_date": to_date,
        "unit": unit,
        "credentials": creds,
    })


async def _fetch_posthog(
    registry: Any, creds: dict, config: dict,
    metric: str, date_range: str,
) -> SkillResult:
    skill = registry.get_skill("posthog_query")
    if skill is None:
        return SkillResult(success=False, error="posthog_query skill not available")
    from_date, to_date = resolve_date_range(date_range)
    query = (
        f"SELECT toDate(timestamp) AS date, count() AS count "
        f"FROM events WHERE event = '{metric}' "
        f"GROUP BY date ORDER BY date"
    )
    return await skill.execute({
        "project_id": config.get("project_id", ""),
        "query": query,
        "date_from": from_date,
        "date_to": to_date,
        "credentials": creds,
    })
