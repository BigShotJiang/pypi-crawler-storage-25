"""MCP tool: analyze_retention — cohort retention curves from any connected source."""

from __future__ import annotations

import logging
import time
from typing import Any

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)


class AnalyzeRetentionSkill(BaseSkill):
    """Fetch cohort data and build a retention triangle."""

    name = "analyze_retention"
    description = (
        "Cohort retention analysis. Shows what percentage of users return over time. "
        "Builds a retention triangle with D1/D7/D30 (or weekly/monthly) retention rates. "
        "Works with GA4 cohort reports, PostHog raw events, or Mixpanel event data. "
        "Example queries: 'What's our D7 retention?', 'Show me weekly retention cohorts', "
        "'How sticky is the product?'. "
        "Do NOT use for time-series trends (use analyze_trends) or A/B tests (use compare_segments)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "date_range": {
                "type": "string",
                "description": "Date range for cohorts: 'last30days', 'last90days', or 'YYYY-MM-DD:YYYY-MM-DD'.",
            },
            "source": {
                "type": "string",
                "description": "Data source: 'ga4', 'mixpanel', or 'posthog'. Auto-selects if omitted.",
            },
            "period_unit": {
                "type": "string",
                "enum": ["day", "week", "month"],
                "description": "Retention period granularity (default: 'week').",
            },
            "max_periods": {
                "type": "integer",
                "description": "Max retention periods to show (default: 12).",
            },
            "event": {
                "type": "string",
                "description": (
                    "Event that defines 'active' (PostHog/Mixpanel only). "
                    "Defaults to any event. E.g. '$pageview', 'Login'."
                ),
            },
        },
        "required": ["date_range"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "retention": {"type": "object"},
            "summary": {"type": "string"},
            "metadata": {"type": "object"},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from engageable.skills.composite.helpers import (
            get_cred_provider, resolve_date_range, resolve_source,
        )
        from engageable.skills.registry import get_registry

        cred_provider = get_cred_provider(params)
        registry = get_registry()
        source = resolve_source(params, cred_provider)
        period_unit = params.get("period_unit", "week")
        max_periods = params.get("max_periods", 12)

        if not source:
            return SkillResult(
                success=False,
                error="No data sources configured.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Fetch cohort/event data depending on source
        fetch_result = await self._fetch_cohort_data(
            registry, cred_provider, source, params, period_unit,
        )
        if not fetch_result.success:
            return fetch_result

        # Run cohort retention analysis
        retention_skill = registry.get_skill("stats_cohort_retention")
        if retention_skill is None:
            return SkillResult(
                success=False,
                error="stats_cohort_retention skill not available",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        retention_params: dict[str, Any] = {
            "data": fetch_result.data,
            "period_unit": period_unit,
            "max_periods": max_periods,
        }

        # For raw event data (PostHog/Mixpanel), specify user/date columns
        if source in ("posthog", "mixpanel"):
            cols = (fetch_result.data or {}).get("columns", [])
            if "user_id" in cols or "distinct_id" in cols:
                retention_params["user_id_col"] = "distinct_id" if "distinct_id" in cols else "user_id"
                retention_params["event_date_col"] = "date" if "date" in cols else cols[0]

        retention_result = await retention_skill.execute(retention_params)
        elapsed = int((time.monotonic() - t0) * 1000)

        if not retention_result.success:
            return SkillResult(
                success=False,
                error=f"Retention analysis failed: {retention_result.error}",
                execution_time_ms=elapsed,
            )

        ret_data = retention_result.data or {}
        return SkillResult(
            success=True,
            data={
                "retention": {
                    "matrix": ret_data.get("retention_matrix", {}),
                    "cohort_sizes": ret_data.get("cohort_sizes", {}),
                    "average_retention": ret_data.get("average_retention", {}),
                },
                "summary": ret_data.get("summary", ""),
                "metadata": {
                    "source": source,
                    "period_unit": period_unit,
                    "max_periods": max_periods,
                    "num_cohorts": ret_data.get("num_cohorts", 0),
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )

    async def _fetch_cohort_data(
        self,
        registry: Any,
        cred_provider: Any,
        source: str,
        params: dict[str, Any],
        period_unit: str,
    ) -> SkillResult:
        """Fetch data suitable for retention analysis from the source."""
        from engageable.skills.composite.helpers import resolve_date_range

        creds = cred_provider.get_credentials(source)
        if creds is None:
            return SkillResult(success=False, error=f"No credentials for {source}.")
        config = cred_provider.get_config(source)
        from_date, to_date = resolve_date_range(params["date_range"])

        if source == "ga4":
            # GA4 has built-in cohort reporting via dimensions
            skill = registry.get_skill("ga4_query")
            if skill is None:
                return SkillResult(success=False, error="ga4_query skill not available")
            return await skill.execute({
                "property_id": config.get("property_id", ""),
                "metrics": ["cohortActiveUsers"],
                "dimensions": ["cohort", "cohortNthDay"],
                "date_range": params["date_range"],
                "credentials": creds,
            })

        elif source == "posthog":
            skill = registry.get_skill("posthog_query")
            if skill is None:
                return SkillResult(success=False, error="posthog_query skill not available")
            event_filter = ""
            event = params.get("event")
            if event:
                event_filter = f"AND event = '{event}' "
            query = (
                f"SELECT distinct_id, toDate(timestamp) AS date "
                f"FROM events "
                f"WHERE 1=1 {event_filter}"
                f"ORDER BY date"
            )
            return await skill.execute({
                "project_id": config.get("project_id", ""),
                "query": query,
                "date_from": from_date,
                "date_to": to_date,
                "credentials": creds,
            })

        elif source == "mixpanel":
            # Mixpanel doesn't have a direct retention API via Insights,
            # so we fall back to providing the raw event data to the retention skill
            skill = registry.get_skill("mixpanel_query")
            if skill is None:
                return SkillResult(success=False, error="mixpanel_query skill not available")
            event = params.get("event", "")
            if not event:
                return SkillResult(
                    success=False,
                    error="Mixpanel retention requires an 'event' parameter to define what counts as active.",
                )
            return await skill.execute({
                "project_id": config.get("project_id", ""),
                "event": event,
                "from_date": from_date,
                "to_date": to_date,
                "unit": period_unit,
                "credentials": creds,
            })

        return SkillResult(success=False, error=f"Unknown source: {source}")
