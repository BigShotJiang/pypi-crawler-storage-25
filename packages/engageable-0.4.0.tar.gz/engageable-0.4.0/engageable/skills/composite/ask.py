"""MCP tool: ask — natural language analytics question answering.

Lightweight router + summarizer. One LLM call to pick tools, execute them,
one LLM call to summarize results. No LangGraph, no memory, no Supabase.
The Anthropic tool-use API does most of the heavy lifting.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)

# Max tool calls per question to avoid runaway loops
MAX_TOOL_CALLS = 3


class AskSkill(BaseSkill):
    """Natural language analytics question answering."""

    name = "ask"
    description = (
        "Ask a plain English analytics question. Engageable figures out which "
        "data to fetch and how to analyze it. Use this for open-ended questions "
        "like 'What happened to our signup rate last Tuesday?', 'How is the product doing?', "
        "or 'Why did traffic drop last week?'. "
        "Requires at least one connected data source — if none are connected, "
        "use get_sources to check, then website_discover or configure_source to set one up. "
        "For specific analyses, prefer dedicated tools (analyze_trends, compare_segments, etc.)."
    )
    category = "analysis"
    mcp_visible = True
    input_schema = {
        "type": "object",
        "properties": {
            "question": {
                "type": "string",
                "description": "A plain English analytics question.",
            },
        },
        "required": ["question"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "data": {"type": "object"},
            "tools_used": {"type": "array", "items": {"type": "string"}},
        },
    }

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        from engageable.mcp.credentials import CredentialProvider, EnvCredentialProvider
        from engageable.skills.registry import get_registry

        question = params["question"]
        cred_provider: CredentialProvider = params.get(
            "_credential_provider", EnvCredentialProvider()
        )
        registry = get_registry()

        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return SkillResult(
                success=False,
                error="ANTHROPIC_API_KEY not set. Required for the ask tool.",
                execution_time_ms=int((time.monotonic() - t0) * 1000),
            )

        # Build context about available sources
        sources = cred_provider.list_providers()
        source_info = []
        for provider in sources:
            config = cred_provider.get_config(provider)
            source_info.append(f"- {provider}: {json.dumps(config)}")
        sources_text = "\n".join(source_info) if source_info else "No data sources configured."

        # Build tool definitions for the available composite skills (excluding ask itself)
        tools = []
        skill_map: dict[str, BaseSkill] = {}
        for skill in registry.mcp_skills():
            if skill.name == "ask":
                continue
            tool_def = {
                "name": skill.name,
                "description": skill.description,
                "input_schema": skill.input_schema,
            }
            tools.append(tool_def)
            skill_map[skill.name] = skill

        # Step 1: Ask the LLM which tools to call
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)

        system_prompt = (
            "You are an analytics assistant. The user asked a question about their data. "
            "You have access to analytics tools that can query connected data sources. "
            "Choose the right tool(s) to answer the question, then call them.\n\n"
            f"Connected data sources:\n{sources_text}\n\n"
            "Call 1-3 tools to gather the data needed to answer the question. "
            "Be specific with parameters — use the connected sources and sensible defaults."
        )

        messages = [{"role": "user", "content": question}]

        # Tool-use loop: let the LLM call tools until it produces a text response
        all_results: list[dict[str, Any]] = []
        tools_used: list[str] = []
        calls_made = 0

        while calls_made < MAX_TOOL_CALLS:
            response = client.messages.create(
                model="claude-haiku-4-5-20250514",
                max_tokens=2048,
                system=system_prompt,
                tools=tools,
                messages=messages,
            )

            # Collect any text blocks
            text_parts = [
                block.text for block in response.content
                if block.type == "text"
            ]

            # Collect tool-use blocks
            tool_blocks = [
                block for block in response.content
                if block.type == "tool_use"
            ]

            if not tool_blocks:
                # LLM is done calling tools — it gave us a text answer
                break

            # Execute each tool call
            tool_results = []
            for block in tool_blocks:
                calls_made += 1
                tool_name = block.name
                tool_input = block.input

                skill = skill_map.get(tool_name)
                if skill is None:
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": f"Unknown tool: {tool_name}",
                    })
                    continue

                # Inject credential provider
                tool_input["_credential_provider"] = cred_provider
                tools_used.append(tool_name)

                result = await skill.execute(tool_input)
                all_results.append({
                    "tool": tool_name,
                    "success": result.success,
                    "data": result.data,
                    "error": result.error,
                })

                # Send result back to the LLM
                result_text = (
                    json.dumps(result.data, indent=2, default=str)
                    if result.success
                    else f"Error: {result.error}"
                )
                # Truncate very long results
                if len(result_text) > 8000:
                    result_text = result_text[:8000] + "\n... (truncated)"

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result_text,
                })

            # Add assistant message + tool results to conversation
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})

        # Step 2: Get the final answer
        # If the loop ended with text_parts, that's our answer.
        # Otherwise, ask for a summary.
        if text_parts:
            answer = " ".join(text_parts)
        elif all_results:
            # One more LLM call to summarize
            summary_prompt = (
                f"The user asked: {question}\n\n"
                f"Here are the results from the tools:\n"
                f"{json.dumps(all_results, indent=2, default=str)}\n\n"
                "Provide a concise, plain English answer to the user's question "
                "based on these results. Include specific numbers and key insights."
            )
            summary_response = client.messages.create(
                model="claude-haiku-4-5-20250514",
                max_tokens=1024,
                messages=[{"role": "user", "content": summary_prompt}],
            )
            answer = " ".join(
                block.text for block in summary_response.content
                if block.type == "text"
            )
        else:
            answer = "I couldn't find the data needed to answer this question. Check that your data sources are configured."

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "answer": answer,
                "tools_used": tools_used,
                "tool_results": all_results,
                "metadata": {
                    "tool_calls": calls_made,
                    "total_time_ms": elapsed,
                },
            },
            execution_time_ms=elapsed,
        )
