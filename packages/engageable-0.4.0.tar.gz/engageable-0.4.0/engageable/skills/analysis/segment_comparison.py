"""Segment comparison skill — find which segments drive a metric change."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult
from engageable.skills.analysis.utils import to_dataframe, coerce_numeric


class SegmentComparisonSkill(BaseSkill):
    name = "stats_segment_comparison"
    description = (
        "Compare a metric across segments between two periods (current vs baseline). "
        "Identifies which segments drove the overall change, ranked by contribution. "
        "Includes statistical significance per segment."
    )
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "current_data": {
                "type": "object",
                "description": "Current period data as {columns: [...], rows: [[...]]} with a dimension column and a metric column",
            },
            "baseline_data": {
                "type": "object",
                "description": "Baseline/previous period data in the same format",
            },
            "dimension_col": {
                "type": "string",
                "description": "Column name for the segment dimension (e.g. 'country', 'device', 'source')",
            },
            "metric_col": {
                "type": "string",
                "description": "Column name for the metric to compare",
            },
        },
        "required": ["current_data", "baseline_data", "dimension_col", "metric_col"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "overall_change": {"type": "number"},
            "overall_change_pct": {"type": "number"},
            "segments": {"type": "array"},
            "summary": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks 'what caused the drop/increase?', "
        "'which segment is driving this change?', or wants to break down a metric "
        "change by dimension. Provide current and baseline period data with the same "
        "dimension column. Works well with GA4 data broken by country, device, source, etc."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        dim_col = params["dimension_col"]
        metric_col = params["metric_col"]

        current_df = coerce_numeric(to_dataframe(params["current_data"]), columns=[metric_col])
        baseline_df = coerce_numeric(to_dataframe(params["baseline_data"]), columns=[metric_col])

        for label, df in [("current", current_df), ("baseline", baseline_df)]:
            if dim_col not in df.columns:
                raise ValueError(f"Dimension column '{dim_col}' not in {label} data. Columns: {list(df.columns)}")
            if metric_col not in df.columns:
                raise ValueError(f"Metric column '{metric_col}' not in {label} data. Columns: {list(df.columns)}")

        # Aggregate by segment (in case there are multiple rows per segment)
        current_agg = current_df.groupby(dim_col)[metric_col].sum().reset_index()
        baseline_agg = baseline_df.groupby(dim_col)[metric_col].sum().reset_index()

        # Merge
        merged = pd.merge(
            baseline_agg, current_agg,
            on=dim_col, how="outer",
            suffixes=("_baseline", "_current"),
        ).fillna(0)

        baseline_col = f"{metric_col}_baseline"
        current_col = f"{metric_col}_current"

        # Overall totals
        total_baseline = merged[baseline_col].sum()
        total_current = merged[current_col].sum()
        overall_change = total_current - total_baseline
        overall_pct = (overall_change / total_baseline * 100) if total_baseline != 0 else 0.0

        # Per-segment analysis
        segments = []
        for _, row in merged.iterrows():
            seg_name = str(row[dim_col])
            base_val = float(row[baseline_col])
            curr_val = float(row[current_col])
            seg_change = curr_val - base_val
            seg_pct = (seg_change / base_val * 100) if base_val != 0 else (100.0 if curr_val > 0 else 0.0)

            # Contribution to overall change
            contribution = (seg_change / overall_change * 100) if overall_change != 0 else 0.0

            # Significance — proportion test if values look like counts
            significant = None
            p_value = None
            if base_val > 0 and curr_val >= 0:
                # Use a two-proportion z-test approximation
                n1, n2 = max(base_val, 1), max(curr_val, 1)
                p_hat = (base_val + curr_val) / (n1 + n2)
                if p_hat > 0 and p_hat < 1:
                    se = np.sqrt(p_hat * (1 - p_hat) * (1/n1 + 1/n2))
                    if se > 0:
                        z = (curr_val/n2 - base_val/n1) / se
                        p_value = float(2 * scipy_stats.norm.sf(abs(z)))
                        significant = p_value < 0.05

            segments.append({
                "segment": seg_name,
                "baseline_value": round(base_val, 2),
                "current_value": round(curr_val, 2),
                "absolute_change": round(seg_change, 2),
                "percent_change": round(seg_pct, 2),
                "contribution_pct": round(contribution, 1),
                "significant": significant,
                "p_value": round(p_value, 6) if p_value is not None else None,
            })

        # Sort by absolute contribution (biggest movers first)
        segments.sort(key=lambda s: abs(s["contribution_pct"]), reverse=True)

        # Summary
        top_movers = segments[:3]
        mover_parts = []
        for s in top_movers:
            if s["contribution_pct"] != 0:
                mover_parts.append(
                    f"{s['segment']} ({s['percent_change']:+.1f}%, "
                    f"contributing {s['contribution_pct']:.0f}% of total change)"
                )

        summary = (
            f"Overall {metric_col} changed {overall_pct:+.1f}% "
            f"({total_baseline:,.0f} → {total_current:,.0f}). "
        )
        if mover_parts:
            summary += "Top movers: " + "; ".join(mover_parts) + "."
        else:
            summary += "No significant segment-level changes detected."

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "overall_change": round(float(overall_change), 2),
                "overall_change_pct": round(overall_pct, 2),
                "total_baseline": round(total_baseline, 2),
                "total_current": round(total_current, 2),
                "segments": segments,
                "num_segments": len(segments),
                "summary": summary,
            },
            execution_time_ms=elapsed,
        )
