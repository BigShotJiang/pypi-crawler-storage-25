from __future__ import annotations

import math
import time
from typing import Any

import numpy as np
from scipy import stats

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult


class SignificanceTestSkill(BaseSkill):
    name = "stats_significance_test"
    description = "Run a statistical significance test comparing two groups of values."
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "control_values": {
                "type": "array",
                "items": {"type": "number"},
                "description": "Numeric values for the control group",
            },
            "variant_values": {
                "type": "array",
                "items": {"type": "number"},
                "description": "Numeric values for the variant group",
            },
            "method": {
                "type": "string",
                "enum": ["t_test", "chi_squared", "mann_whitney"],
                "description": "Statistical test method (default: t_test)",
            },
            "confidence_level": {
                "type": "number",
                "description": "Confidence level (default 0.95)",
            },
        },
        "required": ["control_values", "variant_values"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "significant": {"type": "boolean"},
            "p_value": {"type": "number"},
            "confidence_interval": {"type": "array", "items": {"type": "number"}},
            "effect_size": {"type": "number"},
            "method_used": {"type": "string"},
            "interpretation_template": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks whether a change, experiment, "
        "or A/B test result is 'real' or 'significant.' Requires at least "
        "30 data points per group for reliable results. If fewer, tell the "
        "user more data is needed. Interpret p < 0.05 as significant by "
        "default, but respect the user's confidence_level if specified. "
        "Related skills: stats_power_analysis (plan sample size before running "
        "a test), stats_bayesian_ab (probability-based alternative that works "
        "well with smaller samples or ongoing experiments)."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            control = np.array(params["control_values"], dtype=float)
            variant = np.array(params["variant_values"], dtype=float)
            method = params.get("method", "t_test")
            confidence = params.get("confidence_level", 0.95)
            alpha = 1.0 - confidence

            if len(control) < 2 or len(variant) < 2:
                return SkillResult(
                    success=False,
                    error="Each group must have at least 2 values",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            if method == "t_test":
                stat_result = stats.ttest_ind(control, variant, equal_var=False)
                p_value = float(stat_result.pvalue)
                method_used = "Welch's t-test"
            elif method == "mann_whitney":
                stat_result = stats.mannwhitneyu(control, variant, alternative="two-sided")
                p_value = float(stat_result.pvalue)
                method_used = "Mann-Whitney U test"
            elif method == "chi_squared":
                table = np.array([
                    [np.sum(control), len(control)],
                    [np.sum(variant), len(variant)],
                ])
                stat_result = stats.chi2_contingency(table)
                p_value = float(stat_result[1])
                method_used = "Chi-squared test"
            else:
                return SkillResult(
                    success=False,
                    error=f"Unknown method: {method}",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            significant = p_value < alpha

            control_mean = float(np.mean(control))
            variant_mean = float(np.mean(variant))
            pooled_std = float(np.sqrt(
                ((len(control) - 1) * np.var(control, ddof=1) +
                 (len(variant) - 1) * np.var(variant, ddof=1)) /
                (len(control) + len(variant) - 2)
            ))
            effect_size = (variant_mean - control_mean) / pooled_std if pooled_std > 0 else 0.0

            diff = variant_mean - control_mean
            se_diff = float(np.sqrt(
                np.var(control, ddof=1) / len(control) +
                np.var(variant, ddof=1) / len(variant)
            ))
            z = stats.norm.ppf(1 - alpha / 2)
            ci_lower = diff - z * se_diff
            ci_upper = diff + z * se_diff

            pct_change = ((variant_mean - control_mean) / control_mean * 100) if control_mean != 0 else float("inf")

            interpretation = (
                f"The difference is {'statistically significant' if significant else 'not statistically significant'} "
                f"(p={p_value:.4f}, {method_used}). "
                f"The variant showed a {pct_change:+.1f}% change compared to control "
                f"(control mean: {control_mean:.2f}, variant mean: {variant_mean:.2f}). "
                f"Effect size (Cohen's d): {effect_size:.3f}."
            )

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "significant": significant,
                    "p_value": round(p_value, 6),
                    "confidence_interval": [round(ci_lower, 4), round(ci_upper, 4)],
                    "effect_size": round(effect_size, 4),
                    "method_used": method_used,
                    "control_mean": round(control_mean, 4),
                    "variant_mean": round(variant_mean, 4),
                    "percent_change": round(pct_change, 2),
                    "interpretation_template": interpretation,
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
