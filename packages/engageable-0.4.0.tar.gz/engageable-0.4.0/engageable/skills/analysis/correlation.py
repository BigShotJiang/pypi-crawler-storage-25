"""Correlation skill — Pearson/Spearman correlation with lag analysis."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult
from engageable.skills.analysis.utils import (
    to_dataframe,
    ensure_date_column,
    coerce_numeric,
    validate_min_rows,
)


class CorrelationSkill(BaseSkill):
    name = "stats_correlation"
    description = (
        "Calculate Pearson and Spearman correlation between two metric time series. "
        "Includes lag analysis to find the best-correlated time offset."
    )
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "data": {
                "type": "object",
                "description": (
                    "Data with at least a date column and two metric columns, "
                    "as {columns: [...], rows: [[...]]}."
                ),
            },
            "metric_a": {
                "type": "string",
                "description": "Name of the first metric column",
            },
            "metric_b": {
                "type": "string",
                "description": "Name of the second metric column",
            },
            "date_col": {
                "type": "string",
                "description": "Name of the date column (auto-detected if omitted)",
            },
            "max_lag": {
                "type": "integer",
                "description": "Maximum lag (in data points) for lag analysis (default: 7)",
            },
        },
        "required": ["data", "metric_a", "metric_b"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "pearson_r": {"type": "number"},
            "pearson_p": {"type": "number"},
            "spearman_r": {"type": "number"},
            "spearman_p": {"type": "number"},
            "best_lag": {"type": "integer"},
            "best_lag_r": {"type": "number"},
            "summary": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks about relationships between two metrics — "
        "'does X correlate with Y?', 'when I increase marketing spend does traffic go up?'. "
        "Needs at least 10 data points. Lag analysis checks if one metric leads/follows the other."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        df = to_dataframe(params["data"])
        df = coerce_numeric(df)
        df, date_col = ensure_date_column(df, params.get("date_col"))

        metric_a = params["metric_a"]
        metric_b = params["metric_b"]

        for col in [metric_a, metric_b]:
            if col not in df.columns:
                raise ValueError(f"Column '{col}' not found. Available: {list(df.columns)}")

        # Drop rows where either metric is NaN
        df = df.dropna(subset=[metric_a, metric_b])
        validate_min_rows(df, 10, "correlation")

        a = df[metric_a].values.astype(float)
        b = df[metric_b].values.astype(float)

        # Standard correlations
        pearson_r, pearson_p = scipy_stats.pearsonr(a, b)
        spearman_r, spearman_p = scipy_stats.spearmanr(a, b)

        # Lag analysis
        max_lag = params.get("max_lag", 7)
        max_lag = min(max_lag, len(a) // 3)  # Don't lag more than 1/3 of data

        lag_results = []
        best_lag = 0
        best_lag_r = float(pearson_r)

        for lag in range(-max_lag, max_lag + 1):
            if lag == 0:
                lag_results.append({"lag": 0, "r": round(float(pearson_r), 4), "p": round(float(pearson_p), 6)})
                continue

            if lag > 0:
                a_shifted = a[lag:]
                b_shifted = b[:len(b) - lag]
            else:
                a_shifted = a[:len(a) + lag]
                b_shifted = b[-lag:]

            if len(a_shifted) < 5:
                continue

            r, p = scipy_stats.pearsonr(a_shifted, b_shifted)
            lag_results.append({"lag": lag, "r": round(float(r), 4), "p": round(float(p), 6)})

            if abs(r) > abs(best_lag_r):
                best_lag = lag
                best_lag_r = float(r)

        # Interpret
        def _strength(r: float) -> str:
            ar = abs(r)
            if ar >= 0.7:
                return "strong"
            if ar >= 0.4:
                return "moderate"
            if ar >= 0.2:
                return "weak"
            return "negligible"

        strength = _strength(pearson_r)
        direction = "positive" if pearson_r > 0 else "negative"
        sig = "statistically significant" if pearson_p < 0.05 else "not statistically significant"

        summary = (
            f"{strength.capitalize()} {direction} correlation between {metric_a} and {metric_b} "
            f"(Pearson r={pearson_r:.3f}, p={pearson_p:.4f}, {sig})."
        )
        if best_lag != 0:
            lag_dir = f"{metric_a} leads {metric_b}" if best_lag > 0 else f"{metric_b} leads {metric_a}"
            summary += (
                f" Best correlation at lag {abs(best_lag)} periods "
                f"(r={best_lag_r:.3f}, {lag_dir})."
            )

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "pearson_r": round(float(pearson_r), 4),
                "pearson_p": round(float(pearson_p), 6),
                "spearman_r": round(float(spearman_r), 4),
                "spearman_p": round(float(spearman_p), 6),
                "best_lag": best_lag,
                "best_lag_r": round(best_lag_r, 4),
                "lag_analysis": lag_results,
                "n_observations": len(a),
                "summary": summary,
            },
            execution_time_ms=elapsed,
        )
