from __future__ import annotations

import logging
import time
from typing import Any

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)


class DataQualitySkill(BaseSkill):
    name = "data_quality_check"
    description = "Run data quality checks on connected sources before analysis — detects broken tracking, missing data, and volume anomalies."
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "company_id": {
                "type": "string",
                "description": "The company ID to check data quality for",
            },
            "connections": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "provider": {"type": "string"},
                        "config": {"type": "object"},
                        "credentials": {"type": "object"},
                        "status": {"type": "string"},
                    },
                },
                "description": "List of active data source connections to check",
            },
        },
        "required": ["company_id", "connections"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "checks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "check": {"type": "string"},
                        "status": {"type": "string", "enum": ["pass", "warning", "fail"]},
                        "detail": {"type": "string"},
                        "connector": {"type": "string"},
                    },
                },
            },
            "overall_status": {"type": "string", "enum": ["pass", "warning", "fail"]},
        },
    }
    guide = (
        "Use this skill before running analysis to verify data integrity. "
        "It checks: data freshness (yesterday has data?), zero/null detection "
        "(metrics suddenly zero?), volume sanity (7d vs prior 7d), and source "
        "availability (can we reach the source?). Results are advisory — they "
        "don't block analysis but should be mentioned to the user if issues are found."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        connections = params.get("connections", [])
        checks: list[dict[str, Any]] = []

        for conn in connections:
            provider = conn.get("provider", "unknown")
            status = conn.get("status", "unknown")

            if status != "ready":
                checks.append({
                    "check": "source_status",
                    "status": "warning",
                    "detail": f"Connection status is '{status}', not 'ready'",
                    "connector": provider,
                })
                continue

            if provider == "ga4":
                ga4_checks = await self._check_ga4(conn)
                checks.extend(ga4_checks)
            elif provider == "posthog":
                posthog_checks = await self._check_posthog(conn)
                checks.extend(posthog_checks)
            elif provider == "mixpanel":
                mixpanel_checks = await self._check_mixpanel(conn)
                checks.extend(mixpanel_checks)
            else:
                checks.append({
                    "check": "source_availability",
                    "status": "warning",
                    "detail": f"No quality checks implemented for provider '{provider}'",
                    "connector": provider,
                })

        # Determine overall status
        statuses = [c["status"] for c in checks]
        if "fail" in statuses:
            overall = "fail"
        elif "warning" in statuses:
            overall = "warning"
        else:
            overall = "pass"

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "checks": checks,
                "overall_status": overall,
            },
            execution_time_ms=elapsed,
        )

    async def _check_ga4(self, conn: dict[str, Any]) -> list[dict[str, Any]]:
        """Run GA4-specific quality checks."""
        checks: list[dict[str, Any]] = []
        config = conn.get("config") or {}
        credentials = conn.get("credentials") or {}
        property_id = config.get("property_id", "")

        if not property_id:
            checks.append({
                "check": "source_availability",
                "status": "fail",
                "detail": "No property_id configured",
                "connector": "ga4",
            })
            return checks

        try:
            from engageable.skills.connectors.ga4 import GA4QuerySkill
            skill = GA4QuerySkill()

            # Check 1: Freshness — does yesterday have data?
            freshness_result = await skill.execute({
                "property_id": property_id,
                "credentials": credentials,
                "metrics": ["activeUsers"],
                "date_range": "yesterday",
            })
            if freshness_result.success and freshness_result.data:
                rows = freshness_result.data.get("rows", [])
                if rows and len(rows) > 0:
                    yesterday_users = rows[0][0] if rows[0] else 0
                    if yesterday_users == 0:
                        checks.append({
                            "check": "freshness",
                            "status": "warning",
                            "detail": "Yesterday shows 0 active users — tracking may be broken",
                            "connector": "ga4",
                        })
                    else:
                        checks.append({
                            "check": "freshness",
                            "status": "pass",
                            "detail": f"Yesterday: {yesterday_users} active users",
                            "connector": "ga4",
                        })
                else:
                    checks.append({
                        "check": "freshness",
                        "status": "warning",
                        "detail": "No data rows returned for yesterday",
                        "connector": "ga4",
                    })
            else:
                checks.append({
                    "check": "freshness",
                    "status": "fail",
                    "detail": f"Failed to query yesterday's data: {freshness_result.error}",
                    "connector": "ga4",
                })

            # Check 2: Volume sanity — 7d vs prior 7d
            current_result = await skill.execute({
                "property_id": property_id,
                "credentials": credentials,
                "metrics": ["activeUsers", "sessions"],
                "date_range": "last7days",
            })
            previous_result = await skill.execute({
                "property_id": property_id,
                "credentials": credentials,
                "metrics": ["activeUsers", "sessions"],
                "date_range": "previous7days",
            })

            if current_result.success and previous_result.success:
                cur_rows = (current_result.data or {}).get("rows", [])
                prev_rows = (previous_result.data or {}).get("rows", [])

                if cur_rows and prev_rows:
                    cur_users = cur_rows[0][0] if cur_rows[0] else 0
                    prev_users = prev_rows[0][0] if prev_rows[0] else 0

                    if prev_users > 0:
                        change_pct = (cur_users - prev_users) / prev_users * 100
                        if abs(change_pct) > 50:
                            checks.append({
                                "check": "volume_sanity",
                                "status": "warning",
                                "detail": (
                                    f"Active users changed {change_pct:+.0f}% week-over-week "
                                    f"(current: {cur_users}, previous: {prev_users})"
                                ),
                                "connector": "ga4",
                            })
                        else:
                            checks.append({
                                "check": "volume_sanity",
                                "status": "pass",
                                "detail": f"Volume stable ({change_pct:+.0f}% WoW)",
                                "connector": "ga4",
                            })
                    elif cur_users == 0:
                        checks.append({
                            "check": "volume_sanity",
                            "status": "fail",
                            "detail": "Zero active users in both current and previous 7 days",
                            "connector": "ga4",
                        })
                    else:
                        checks.append({
                            "check": "volume_sanity",
                            "status": "pass",
                            "detail": f"Current 7d: {cur_users} users (no prior data to compare)",
                            "connector": "ga4",
                        })

        except Exception as exc:
            logger.warning("GA4 quality check failed: %s", exc)
            checks.append({
                "check": "source_availability",
                "status": "fail",
                "detail": f"Could not reach GA4: {str(exc)[:200]}",
                "connector": "ga4",
            })

        return checks

    async def _check_posthog(self, conn: dict[str, Any]) -> list[dict[str, Any]]:
        """Placeholder for PostHog quality checks — implemented when connector is ready."""
        return [{
            "check": "source_availability",
            "status": "pass",
            "detail": "PostHog connection is ready (detailed checks pending connector implementation)",
            "connector": "posthog",
        }]

    async def _check_mixpanel(self, conn: dict[str, Any]) -> list[dict[str, Any]]:
        """Placeholder for Mixpanel quality checks — implemented when connector is ready."""
        return [{
            "check": "source_availability",
            "status": "pass",
            "detail": "Mixpanel connection is ready (detailed checks pending connector implementation)",
            "connector": "mixpanel",
        }]
