"""Trend detection skill — STL decomposition, change-point detection, anomaly flagging."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from statsmodels.tsa.seasonal import STL

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult
from engageable.skills.analysis.utils import (
    to_dataframe,
    ensure_date_column,
    extract_metric_column,
    validate_min_rows,
    coerce_numeric,
)


def _detect_change_points(values: np.ndarray, min_segment_length: int = 5) -> list[int]:
    """Simple change-point detection using cumulative sum (CUSUM).

    Returns indices where significant level shifts occur.
    Falls back to a simpler approach if ruptures is not available.
    """
    try:
        import ruptures
        model = ruptures.Pelt(model="rbf", min_size=min_segment_length).fit(
            values.reshape(-1, 1)
        )
        # pen=np.log(len(values)) * np.var(values) is a BIC-like penalty
        penalty = max(np.log(len(values)) * np.var(values), 1.0)
        breakpoints = model.predict(pen=penalty)
        # ruptures returns the last index as a breakpoint; remove it
        return [bp for bp in breakpoints if bp < len(values)]
    except ImportError:
        pass

    # Fallback: sliding window mean-shift detection
    if len(values) < min_segment_length * 2:
        return []

    change_points = []
    global_mean = np.mean(values)
    global_std = np.std(values)
    if global_std == 0:
        return []

    window = min_segment_length
    for i in range(window, len(values) - window):
        left_mean = np.mean(values[i - window:i])
        right_mean = np.mean(values[i:i + window])
        shift = abs(right_mean - left_mean) / global_std
        if shift > 2.0:  # 2 standard deviations
            # Avoid duplicates within the same region
            if not change_points or (i - change_points[-1]) >= window:
                change_points.append(i)

    return change_points


def _detect_anomalies(residuals: np.ndarray, threshold: float = 2.5) -> list[int]:
    """Flag anomalies as points where residuals exceed threshold × MAD."""
    median = np.median(residuals)
    mad = np.median(np.abs(residuals - median))
    if mad == 0:
        mad = np.std(residuals)
    if mad == 0:
        return []

    z_scores = np.abs(residuals - median) / mad
    return [int(i) for i in np.where(z_scores > threshold)[0]]


class TrendDetectionSkill(BaseSkill):
    name = "stats_trend_detection"
    description = (
        "Detect trends, change points, and anomalies in a time series. "
        "Returns trend direction, decomposition components, change-point locations, "
        "and flagged anomalies."
    )
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "data": {
                "type": "object",
                "description": "Time series data as {columns: [...], rows: [[...]]}",
            },
            "date_col": {
                "type": "string",
                "description": "Name of the date column (auto-detected if omitted)",
            },
            "metric_col": {
                "type": "string",
                "description": "Name of the metric column (auto-detected if omitted)",
            },
            "period": {
                "type": "integer",
                "description": "Seasonal period in data points (default: 7 for daily data)",
            },
        },
        "required": ["data"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "trend_direction": {"type": "string"},
            "trend_slope": {"type": "number"},
            "trend_slope_pct": {"type": "number"},
            "change_points": {"type": "array"},
            "anomaly_indices": {"type": "array"},
            "decomposition": {"type": "object"},
            "summary": {"type": "string"},
        },
    }
    guide = (
        "Use this skill to analyze time series data for trends and anomalies. "
        "Good for answering questions like 'is this metric trending up or down?', "
        "'when did the trend change?', or 'are there any unusual spikes?'. "
        "Needs at least 14 data points (ideally 28+ for reliable seasonal decomposition). "
        "Works best with daily data; set period=7 for weekly seasonality."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()

        df = to_dataframe(params["data"])
        df = coerce_numeric(df)
        df, date_col = ensure_date_column(df, params.get("date_col"))
        metric_col = extract_metric_column(df, params.get("metric_col"), date_col)
        validate_min_rows(df, 14, "trend detection")

        values = df[metric_col].values.astype(float)
        dates = df[date_col].dt.strftime("%Y-%m-%d").tolist()
        period = params.get("period", 7)

        # Ensure period is valid for STL
        if period < 2 or len(values) < period * 2:
            period = min(max(2, len(values) // 3), 7)

        # STL decomposition
        series = pd.Series(values, index=pd.to_datetime(df[date_col]))
        stl = STL(series, period=period, robust=True)
        result = stl.fit()

        trend = result.trend.values
        seasonal = result.seasonal.values
        residuals = result.resid.values

        # Trend direction via linear regression on the trend component
        x = np.arange(len(trend))
        slope, intercept, r_value, p_value, std_err = scipy_stats.linregress(x, trend)

        mean_val = np.mean(values)
        slope_pct = (slope / mean_val * 100) if mean_val != 0 else 0.0

        if p_value > 0.1:
            direction = "flat"
        elif slope > 0:
            direction = "up"
        else:
            direction = "down"

        # Change-point detection
        change_points = _detect_change_points(trend)
        change_point_dates = [dates[i] for i in change_points if i < len(dates)]

        # Anomaly detection on residuals
        anomaly_indices = _detect_anomalies(residuals)
        anomaly_dates = [dates[i] for i in anomaly_indices if i < len(dates)]

        # Build summary
        parts = [f"Trend: {direction} ({slope_pct:+.2f}% per period, p={p_value:.4f})."]
        if change_point_dates:
            parts.append(f"Change points detected at: {', '.join(change_point_dates)}.")
        if anomaly_dates:
            parts.append(f"Anomalies flagged at: {', '.join(anomaly_dates)}.")
        if not change_point_dates and not anomaly_dates:
            parts.append("No significant change points or anomalies detected.")

        elapsed = int((time.monotonic() - t0) * 1000)
        return SkillResult(
            success=True,
            data={
                "trend_direction": direction,
                "trend_slope": round(float(slope), 6),
                "trend_slope_pct": round(slope_pct, 2),
                "trend_p_value": round(float(p_value), 6),
                "trend_r_squared": round(float(r_value ** 2), 4),
                "change_points": [
                    {"index": int(i), "date": dates[i] if i < len(dates) else None}
                    for i in change_points
                ],
                "anomaly_indices": [
                    {"index": int(i), "date": dates[i] if i < len(dates) else None, "value": round(float(values[i]), 2)}
                    for i in anomaly_indices
                    if i < len(values)
                ],
                "decomposition": {
                    "dates": dates,
                    "observed": [round(float(v), 2) for v in values],
                    "trend": [round(float(v), 2) for v in trend],
                    "seasonal": [round(float(v), 2) for v in seasonal],
                    "residual": [round(float(v), 2) for v in residuals],
                },
                "summary": " ".join(parts),
            },
            execution_time_ms=elapsed,
        )
