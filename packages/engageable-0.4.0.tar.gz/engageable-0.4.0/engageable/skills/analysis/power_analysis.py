from __future__ import annotations

import math
import time
from typing import Any

from engageable.skills.base import BaseSkill
from engageable.skills.types import SkillResult


class PowerAnalysisSkill(BaseSkill):
    name = "stats_power_analysis"
    description = "Calculate the required sample size for an A/B test to detect a given effect."
    category = "analysis"
    input_schema = {
        "type": "object",
        "properties": {
            "baseline_rate": {
                "type": "number",
                "description": "Current conversion rate (e.g. 0.05 for 5%)",
            },
            "minimum_detectable_effect": {
                "type": "number",
                "description": "Smallest relative change to detect (e.g. 0.10 for 10% lift)",
            },
            "alpha": {
                "type": "number",
                "description": "Significance level (default 0.05)",
            },
            "power": {
                "type": "number",
                "description": "Statistical power (default 0.80)",
            },
            "daily_traffic": {
                "type": "number",
                "description": "Average daily visitors/events (optional, used to estimate duration)",
            },
        },
        "required": ["baseline_rate", "minimum_detectable_effect"],
    }
    output_schema = {
        "type": "object",
        "properties": {
            "required_sample_per_group": {"type": "integer"},
            "total_sample_needed": {"type": "integer"},
            "estimated_days": {"type": "number"},
            "interpretation_template": {"type": "string"},
        },
    }
    guide = (
        "Use this skill when the user asks 'how long should we run this test?', "
        "'what sample size do we need?', or any question about A/B test planning. "
        "Requires baseline_rate (current conversion rate) and minimum_detectable_effect "
        "(smallest relative lift worth detecting). If the user provides daily traffic, "
        "the skill also estimates how many days the test needs to run. "
        "Related skills: stats_significance_test (after collecting data), "
        "stats_bayesian_ab (for probability-based analysis)."
    )

    async def execute(self, params: dict[str, Any]) -> SkillResult:
        t0 = time.monotonic()
        try:
            baseline = params["baseline_rate"]
            mde = params["minimum_detectable_effect"]
            alpha = params.get("alpha", 0.05)
            power = params.get("power", 0.80)
            daily_traffic = params.get("daily_traffic")

            if baseline <= 0 or baseline >= 1:
                return SkillResult(
                    success=False,
                    error="baseline_rate must be between 0 and 1 (exclusive)",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            if mde <= 0:
                return SkillResult(
                    success=False,
                    error="minimum_detectable_effect must be positive",
                    execution_time_ms=int((time.monotonic() - t0) * 1000),
                )

            from statsmodels.stats.power import NormalIndPower

            analysis = NormalIndPower()

            # Convert relative MDE to absolute effect size (Cohen's h)
            variant_rate = baseline * (1 + mde)
            if variant_rate >= 1:
                variant_rate = 0.999

            # Cohen's h for proportions
            effect_size = 2 * (math.asin(math.sqrt(variant_rate)) - math.asin(math.sqrt(baseline)))

            sample_per_group = math.ceil(
                analysis.solve_power(
                    effect_size=abs(effect_size),
                    alpha=alpha,
                    power=power,
                    alternative="two-sided",
                )
            )
            total_sample = sample_per_group * 2

            estimated_days = None
            if daily_traffic and daily_traffic > 0:
                estimated_days = round(total_sample / daily_traffic, 1)

            interpretation = (
                f"To detect a {mde * 100:.0f}% relative change from a {baseline * 100:.1f}% baseline "
                f"(α={alpha}, power={power * 100:.0f}%), you need {sample_per_group:,} samples per group "
                f"({total_sample:,} total)."
            )
            if estimated_days is not None:
                interpretation += f" At {daily_traffic:,.0f} visitors/day, that's ~{estimated_days} days."

            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=True,
                data={
                    "required_sample_per_group": sample_per_group,
                    "total_sample_needed": total_sample,
                    "estimated_days": estimated_days,
                    "baseline_rate": baseline,
                    "variant_rate": round(variant_rate, 6),
                    "effect_size_cohens_h": round(abs(effect_size), 4),
                    "alpha": alpha,
                    "power": power,
                    "interpretation_template": interpretation,
                },
                execution_time_ms=elapsed,
            )

        except Exception as exc:
            elapsed = int((time.monotonic() - t0) * 1000)
            return SkillResult(
                success=False,
                error=str(exc),
                execution_time_ms=elapsed,
            )
