"""Engageable MCP server.

Dynamically exposes all skills marked with ``mcp_visible = True`` as MCP
tools.  Adding a new BaseSkill subclass with ``mcp_visible = True`` is all
that's needed — no wiring in this file.

Usage (stdio transport):
    python -m app.mcp.server

Usage (SSE transport):
    python -m app.mcp.server --transport sse --port 8080
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from typing import Any

from mcp.server import Server
from mcp.types import TextContent, Tool

from engageable.mcp.credentials import CredentialProvider, EnvCredentialProvider
from engageable.skills.registry import get_registry
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Credential injection
# ---------------------------------------------------------------------------

# Map skill name prefix → provider name
_PROVIDER_PREFIX: dict[str, str] = {
    "ga4_": "ga4",
    "mixpanel_": "mixpanel",
    "posthog_": "posthog",
}


def _inject_credentials(
    skill_name: str,
    params: dict[str, Any],
    cred_provider: CredentialProvider,
) -> dict[str, Any]:
    """Inject credentials and config into skill params if the skill is a
    connector that needs them and they aren't already present.

    Also makes the credential provider available to composite skills that
    need to list or select data sources dynamically.
    """
    params = {**params, "_credential_provider": cred_provider}

    if "credentials" in params:
        return params

    for prefix, provider in _PROVIDER_PREFIX.items():
        if skill_name.startswith(prefix):
            creds = cred_provider.get_credentials(provider)
            if creds is None:
                raise ValueError(
                    f"No credentials configured for {provider}. "
                    f"Set the required environment variables."
                )
            params["credentials"] = creds
            # Merge config (property_id, project_id, etc.) as defaults
            config = cred_provider.get_config(provider)
            for key, value in config.items():
                if key not in params and value:
                    params[key] = value
            return params

    return params


# ---------------------------------------------------------------------------
# Result formatting
# ---------------------------------------------------------------------------


def _format_result(result: SkillResult) -> list[TextContent]:
    """Convert a SkillResult into MCP TextContent responses.

    Uses CSV for tabular data (50% fewer tokens than JSON), puts the summary
    first, and enforces a ~1000 cell budget on large result sets.
    """
    if not result.success:
        return [TextContent(type="text", text=f"Error: {result.error}")]

    from engageable.mcp.formatter import format_skill_result

    text = format_skill_result(result.data)
    return [TextContent(type="text", text=text)]


# ---------------------------------------------------------------------------
# Server factory
# ---------------------------------------------------------------------------


def create_server(
    cred_provider: CredentialProvider | None = None,
) -> Server:
    """Create an MCP Server with all mcp_visible skills registered."""
    if cred_provider is None:
        cred_provider = EnvCredentialProvider()

    registry = get_registry()
    server = Server("engageable")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [skill.to_mcp_tool() for skill in registry.mcp_skills()]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        skill = registry.get_skill(name)
        if skill is None:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

        if not skill.mcp_visible:
            return [TextContent(type="text", text=f"Tool not available via MCP: {name}")]

        params = _inject_credentials(name, arguments, cred_provider)
        result: SkillResult = await skill.execute(params)

        # Persist refreshed credentials (e.g. OAuth token rotation)
        if result.metadata.get("refreshed_credentials"):
            for prefix, provider in _PROVIDER_PREFIX.items():
                if name.startswith(prefix):
                    cred_provider.persist_credentials(
                        provider, result.metadata["refreshed_credentials"]
                    )
                    break

        return _format_result(result)

    mcp_skills = registry.mcp_skills()
    logger.info(
        "MCP server created with %d tools: %s",
        len(mcp_skills),
        ", ".join(s.name for s in mcp_skills),
    )

    return server


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def _load_env() -> None:
    """Load .env files from the repo root (same logic as app.config)."""
    from pathlib import Path

    engine_dir = Path(__file__).resolve().parent.parent.parent
    repo_root = engine_dir.parent

    for name in (".env", ".env.local"):
        env_path = repo_root / name
        if env_path.is_file():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip("'\"")
                if key and key not in os.environ:
                    os.environ[key] = value


def main() -> None:
    parser = argparse.ArgumentParser(description="Engageable MCP server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="MCP transport (default: stdio)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port for SSE transport (default: 8080)",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Log level (default: INFO)",
    )
    args = parser.parse_args()

    # Load env vars from repo .env files so ANTHROPIC_API_KEY and
    # data source credentials are available without explicit config.
    _load_env()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    server = create_server()

    if args.transport == "stdio":
        from mcp.server.stdio import stdio_server

        async def run_stdio() -> None:
            async with stdio_server() as (read_stream, write_stream):
                await server.run(
                    read_stream,
                    write_stream,
                    server.create_initialization_options(),
                )

        asyncio.run(run_stdio())
    else:
        from mcp.server.sse import SseServerTransport
        from starlette.applications import Starlette
        from starlette.routing import Mount, Route
        import uvicorn

        sse = SseServerTransport("/messages/")

        async def handle_sse(request):
            async with sse.connect_sse(
                request.scope, request.receive, request._send
            ) as streams:
                await server.run(
                    streams[0],
                    streams[1],
                    server.create_initialization_options(),
                )

        app = Starlette(
            routes=[
                Route("/sse", endpoint=handle_sse),
                Mount("/messages/", app=sse.handle_post_message),
            ],
        )
        uvicorn.run(app, host="0.0.0.0", port=args.port)


if __name__ == "__main__":
    main()
