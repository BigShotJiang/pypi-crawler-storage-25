"""Allow running the MCP server as: python -m app.mcp"""

from engageable.mcp.server import main

main()
