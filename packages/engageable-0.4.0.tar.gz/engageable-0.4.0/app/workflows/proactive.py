# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Proactive investigation — daily autonomous analysis cycle.

The agent autonomously looks at data, formulates hypotheses, tests them,
and reports interesting findings via the outbound system.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

from supabase import create_client

from app.config import get_settings
from app.workflows.qa import run_qa
from app.memory.structured import get_recent_findings

logger = logging.getLogger(__name__)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


def _parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _normalize_idea_text(text: str) -> str:
    lowered = text.lower()
    normalized = re.sub(r"\s+", " ", lowered).strip()
    normalized = re.sub(r"[^a-z0-9 ]+", "", normalized)
    return normalized


def _select_relevant_recent_findings(
    findings: list[dict[str, Any]],
    *,
    max_age_days: int = 45,
    limit: int = 8,
) -> list[dict[str, Any]]:
    """Keep recent, unique findings for proactive grounding."""
    now = datetime.now(timezone.utc)
    selected: list[dict[str, Any]] = []
    seen_summaries: set[str] = set()

    for finding in findings:
        created_at = _parse_timestamp(finding.get("created_at"))
        if created_at is None:
            continue
        if (now - created_at) > timedelta(days=max_age_days):
            continue

        summary = str(finding.get("summary", "")).strip()
        normalized_summary = _normalize_idea_text(summary)
        if not normalized_summary or normalized_summary in seen_summaries:
            continue

        seen_summaries.add(normalized_summary)
        selected.append(finding)
        if len(selected) >= limit:
            break

    return selected


def _load_recent_posted_ideas(sb, company_id: str, limit: int = 5) -> list[str]:
    result = (
        sb.table("outbound_events")
        .select("payload, composed_message")
        .eq("company_id", company_id)
        .eq("event_type", "proactive_finding")
        .eq("status", "sent")
        .order("sent_at", desc=True)
        .limit(limit)
        .execute()
    )

    ideas: list[str] = []
    for row in result.data or []:
        payload = row.get("payload") or {}
        summary = payload.get("summary") if isinstance(payload, dict) else None
        if isinstance(summary, str) and summary.strip():
            ideas.append(summary.strip())
            continue

        composed = row.get("composed_message")
        if isinstance(composed, str) and composed.strip():
            first_line = composed.strip().splitlines()[0].strip()
            if first_line:
                ideas.append(first_line)

    return ideas


def _load_last_sent_proactive_at(sb, company_id: str) -> datetime | None:
    result = (
        sb.table("outbound_events")
        .select("sent_at, created_at")
        .eq("company_id", company_id)
        .eq("event_type", "proactive_finding")
        .eq("status", "sent")
        .order("sent_at", desc=True)
        .limit(1)
        .execute()
    )
    if not result.data:
        return None
    row = result.data[0]
    return _parse_timestamp(row.get("sent_at")) or _parse_timestamp(row.get("created_at"))


def _load_company_last_read_at(sb, company_id: str) -> datetime | None:
    result = (
        sb.table("notification_preferences")
        .select("last_read_at")
        .eq("company_id", company_id)
        .order("last_read_at", desc=True)
        .limit(1)
        .execute()
    )
    if not result.data:
        return None
    return _parse_timestamp(result.data[0].get("last_read_at"))


async def run_proactive_investigation(company_id: str) -> dict[str, Any]:
    """Run a proactive investigation for a company.

    1. Load context (project, connections, memories, recent findings)
    2. Call the QA agent in 'proactive_investigation' mode
    3. Route findings to outbound events

    Returns a result dict with status and any findings created.
    """
    sb = _get_supabase()

    # Load project
    project_result = sb.table("companies").select("*").eq("id", company_id).limit(1).execute()
    project = project_result.data[0] if project_result.data else None

    # Load connections
    conn_result = sb.table("data_source_connections").select("*").eq(
        "company_id", company_id
    ).eq("is_active", True).execute()
    connections = conn_result.data or []

    if not connections:
        logger.info("Skipping proactive run for %s — no connections", company_id)
        return {"status": "skipped", "reason": "no_connections"}

    # Check that at least one connection is ready
    ready = [c for c in connections if c.get("status") == "ready"]
    if not ready:
        logger.info("Skipping proactive run for %s — no ready connections", company_id)
        return {"status": "skipped", "reason": "no_ready_connections"}

    # Load memories
    mem_result = sb.table("agent_memory").select("category, content").eq(
        "company_id", company_id
    ).order("created_at", desc=False).limit(30).execute()
    memories = mem_result.data or []

    # Load recent findings and keep a relevant subset to ground novelty.
    recent_findings = await get_recent_findings(company_id, limit=30)
    relevant_recent_findings = _select_relevant_recent_findings(recent_findings)

    # Load the last few posted proactive ideas and explicitly avoid repeats.
    recent_posted_ideas = _load_recent_posted_ideas(sb, company_id, limit=5)
    duplicate_blocks = {
        _normalize_idea_text(idea) for idea in recent_posted_ideas if idea.strip()
    }

    question = (
        "Run a proactive investigation. Look at what you know about this "
        "business, pick one hypothesis worth testing today, test it using "
        "your tools, and report back."
    )
    if relevant_recent_findings:
        relevant_lines: list[str] = []
        for finding in relevant_recent_findings[:8]:
            fid = str(finding.get("id", ""))[:8]
            created = str(finding.get("created_at", ""))[:10]
            severity = str(finding.get("severity", "info")).upper()
            summary = str(finding.get("summary", "")).strip()
            relevant_lines.append(f"- {severity} #{fid} ({created}): {summary}")

        question += (
            "\n\nUse these recent learnings as grounding context. "
            "Today's output must either be materially new or a clear follow-up "
            "to one of these items.\n"
            "If follow-up, explicitly reference the prior finding id/date in the saved finding context.\n"
            f"{chr(10).join(relevant_lines)}"
        )
    if recent_posted_ideas:
        idea_lines = "\n".join(f"- {idea}" for idea in recent_posted_ideas)
        question += (
            "\n\nDo not repeat these recently posted proactive ideas. "
            "If you cannot find a materially different insight today, skip creating a new finding.\n"
            f"{idea_lines}"
        )

    # Run the QA agent in proactive investigation mode
    try:
        parts = await run_qa(
            question=question,
            company_id=company_id,
            data_sources=connections,
            user_id="system:proactive",
            project=project,
            recent_findings=relevant_recent_findings,
            memories=memories,
            task="proactive_investigation",
        )

        # Check if the agent created any findings
        new_findings = await get_recent_findings(company_id, limit=3)
        existing_ids = {f.get("id") for f in recent_findings if f.get("id")}
        new_finding_ids = [
            f["id"] for f in new_findings
            if f.get("id") and f["id"] not in existing_ids
        ]

        # Route notable/urgent findings through investigation loop
        for finding in new_findings:
            if finding.get("id") not in new_finding_ids:
                continue
            severity = finding.get("severity", "informational")
            if severity in ("notable", "urgent", "warning", "critical"):
                try:
                    from app.workflows.investigation import run_investigation
                    logger.info(
                        "Routing %s finding to investigation loop: %s",
                        severity, finding.get("summary", "")[:80],
                    )
                    await run_investigation(
                        initial_finding=finding,
                        company_id=company_id,
                        data_sources=connections,
                        user_id="system:proactive",
                        max_rounds=2,  # lighter for background
                    )
                except Exception:
                    logger.exception("Investigation loop failed for finding %s", finding.get("id"))

        duplicate_findings_skipped = 0

        # Queue outbound events for new findings
        for finding in new_findings:
            if finding.get("id") in new_finding_ids:
                summary = str(finding.get("summary", "")).strip()
                normalized_summary = _normalize_idea_text(summary)
                if normalized_summary and normalized_summary in duplicate_blocks:
                    duplicate_findings_skipped += 1
                    logger.info(
                        "Skipping proactive finding for %s due to repeated idea: %s",
                        company_id,
                        summary[:140],
                    )
                    continue
                try:
                    sb.table("outbound_events").insert({
                        "company_id": company_id,
                        "event_type": "proactive_finding",
                        "severity": finding.get("severity", "info"),
                        "finding_id": finding["id"],
                        "payload": {
                            "summary": finding.get("summary", ""),
                            "source": "proactive_investigation",
                        },
                    }).execute()
                except Exception:
                    logger.exception("Failed to queue proactive finding")

        # Extract text response for logging
        text_parts = [p.get("text", "") for p in parts if p.get("type") == "text"]
        response_text = " ".join(text_parts)[:500]

        return {
            "status": "completed",
            "findings_created": max(len(new_finding_ids) - duplicate_findings_skipped, 0),
            "duplicate_findings_skipped": duplicate_findings_skipped,
            "response_preview": response_text,
        }

    except Exception as exc:
        logger.exception("Proactive investigation failed for %s", company_id)
        return {"status": "failed", "error": str(exc)}


async def run_proactive_for_all_companies() -> list[dict[str, Any]]:
    """Run proactive investigation for all eligible companies.

    A company is eligible if it has:
    - At least one active, ready data source connection
    - Not run a proactive investigation in the last 20 hours
    - If latest proactive message has not been seen, wait up to 7 days before generating another
    """
    sb = _get_supabase()

    # Get all companies with active connections
    companies_result = sb.table("companies").select("id, name").execute()
    companies = companies_result.data or []

    results = []
    for company in companies:
        company_id = company["id"]

        # Check if already run recently (reuse the monitor timing pattern)
        recent_events = sb.table("outbound_events").select("id, created_at").eq(
            "company_id", company_id
        ).eq("event_type", "proactive_finding").order(
            "created_at", desc=True
        ).limit(1).execute()

        if recent_events.data:
            last_run = recent_events.data[0].get("created_at", "")
            if last_run:
                last_dt = datetime.fromisoformat(last_run.replace("Z", "+00:00"))
                if (datetime.now(timezone.utc) - last_dt) < timedelta(hours=20):
                    results.append({
                        "company_id": company_id,
                        "status": "skipped",
                        "reason": "ran_recently",
                    })
                    continue

        # If the last proactive message has not been seen, hold new learnings
        # for up to one week to avoid piling up unseen recommendations.
        last_sent_at = _load_last_sent_proactive_at(sb, company_id)
        if last_sent_at:
            last_read_at = _load_company_last_read_at(sb, company_id)
            was_seen = last_read_at is not None and last_read_at >= last_sent_at
            if not was_seen and (datetime.now(timezone.utc) - last_sent_at) < timedelta(days=7):
                results.append({
                    "company_id": company_id,
                    "status": "skipped",
                    "reason": "awaiting_read_of_last_learning",
                })
                continue

        result = await run_proactive_investigation(company_id)
        result["company_id"] = company_id
        results.append(result)

    return results