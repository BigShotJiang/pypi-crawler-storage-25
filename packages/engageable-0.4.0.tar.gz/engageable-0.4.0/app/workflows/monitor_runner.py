# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Monitor execution — fetch data, compare periods, detect breaches, create findings."""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any

from supabase import create_client

from app.config import get_settings
from app.output.finding import Finding, MetricSnapshot
from app.memory.structured import save_finding
from engageable.skills.registry import get_registry

logger = logging.getLogger(__name__)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


def _queue_outbound_event(
    sb,
    company_id: str,
    event_type: str,
    severity: str,
    finding_id: str | None = None,
    monitor_id: str | None = None,
    payload: dict | None = None,
) -> None:
    """Insert an outbound event for later delivery by the outbound agent."""
    try:
        row: dict[str, Any] = {
            "company_id": company_id,
            "event_type": event_type,
            "severity": severity,
            "payload": payload or {},
        }
        if finding_id:
            row["finding_id"] = finding_id
        if monitor_id:
            row["monitor_id"] = monitor_id
        sb.table("outbound_events").insert(row).execute()
    except Exception:
        logger.exception("Failed to queue outbound event")


# ---------------------------------------------------------------------------
# Date range helpers
# ---------------------------------------------------------------------------

def _get_date_ranges(schedule: str) -> tuple[tuple[str, str], tuple[str, str]]:
    """Return (current_period, previous_period) date ranges based on schedule.

    Each range is (start_date, end_date) as ISO strings.
    """
    today = date.today()
    yesterday = today - timedelta(days=1)

    if schedule == "daily":
        current = (yesterday.isoformat(), yesterday.isoformat())
        previous_day = yesterday - timedelta(days=1)
        previous = (previous_day.isoformat(), previous_day.isoformat())

    elif schedule == "weekly":
        current_end = yesterday
        current_start = current_end - timedelta(days=6)
        previous_end = current_start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=6)
        current = (current_start.isoformat(), current_end.isoformat())
        previous = (previous_start.isoformat(), previous_end.isoformat())

    elif schedule == "monthly":
        current_end = yesterday
        current_start = current_end - timedelta(days=29)
        previous_end = current_start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=29)
        current = (current_start.isoformat(), current_end.isoformat())
        previous = (previous_start.isoformat(), previous_end.isoformat())

    else:
        # Default to weekly
        current_end = yesterday
        current_start = current_end - timedelta(days=6)
        previous_end = current_start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=6)
        current = (current_start.isoformat(), current_end.isoformat())
        previous = (previous_start.isoformat(), previous_end.isoformat())

    return current, previous


# ---------------------------------------------------------------------------
# Metric fetching
# ---------------------------------------------------------------------------

async def _fetch_metric_values(
    provider: str,
    metric: str,
    date_range: tuple[str, str],
    connection: dict[str, Any],
    query_params: dict[str, Any] | None = None,
) -> list[float]:
    """Fetch daily values for a metric over a date range.

    Returns a list of daily float values (one per day).
    """
    registry = get_registry()

    if provider == "ga4":
        skill = registry.get_skill("ga4_query")
        if not skill:
            raise RuntimeError("ga4_query skill not registered")

        property_id = (connection.get("config") or {}).get("property_id")
        if not property_id:
            raise RuntimeError("GA4 connection has no property_id configured")

        credentials = connection.get("credentials", {})
        params = {
            "property_id": property_id,
            "metrics": [metric],
            "dimensions": ["date"],
            "date_range": f"{date_range[0]}:{date_range[1]}",
            "credentials": credentials,
            **(query_params or {}),
        }

        result = await skill.execute(params)
        if not result.success:
            raise RuntimeError(f"ga4_query failed: {result.error}")

        # Extract metric values from rows — rows are [date, value]
        values: list[float] = []
        for row in result.data.get("rows", []):
            if len(row) >= 2:
                try:
                    values.append(float(row[1]))
                except (ValueError, TypeError):
                    values.append(0.0)

        return values

    raise RuntimeError(f"Unsupported provider: {provider}")


async def _fetch_metric_total(
    provider: str,
    metric: str,
    date_range: tuple[str, str],
    connection: dict[str, Any],
    query_params: dict[str, Any] | None = None,
) -> float:
    """Fetch a single aggregated value for a metric over a date range."""
    registry = get_registry()

    if provider == "ga4":
        skill = registry.get_skill("ga4_query")
        if not skill:
            raise RuntimeError("ga4_query skill not registered")

        property_id = (connection.get("config") or {}).get("property_id")
        if not property_id:
            raise RuntimeError("GA4 connection has no property_id configured")

        credentials = connection.get("credentials", {})
        params = {
            "property_id": property_id,
            "metrics": [metric],
            "date_range": f"{date_range[0]}:{date_range[1]}",
            "credentials": credentials,
            **(query_params or {}),
        }

        result = await skill.execute(params)
        if not result.success:
            raise RuntimeError(f"ga4_query failed: {result.error}")

        rows = result.data.get("rows", [])
        if rows and len(rows[0]) >= 1:
            try:
                return float(rows[0][0])
            except (ValueError, TypeError):
                return 0.0
        return 0.0

    raise RuntimeError(f"Unsupported provider: {provider}")


# ---------------------------------------------------------------------------
# Significance testing
# ---------------------------------------------------------------------------

async def _run_significance_test(
    current_values: list[float],
    previous_values: list[float],
) -> dict[str, Any] | None:
    """Run a t-test comparing two periods. Returns None if not enough data."""
    if len(current_values) < 2 or len(previous_values) < 2:
        return None

    registry = get_registry()
    skill = registry.get_skill("stats_significance_test")
    if not skill:
        return None

    result = await skill.execute({
        "control_values": previous_values,
        "variant_values": current_values,
        "method": "t_test",
    })

    if result.success:
        return result.data
    return None


# ---------------------------------------------------------------------------
# Core monitor execution
# ---------------------------------------------------------------------------

async def run_single_monitor(
    monitor: dict[str, Any],
    connection: dict[str, Any],
) -> dict[str, Any]:
    """Execute a single monitor check.

    Returns a result dict with status, values, and optional finding.
    """
    sb = _get_supabase()
    company_id = monitor["company_id"]
    monitor_id = monitor["id"]
    metric = monitor["metric"]
    provider = monitor["provider"]
    schedule = monitor["schedule"]
    comparison = monitor.get("comparison", "previous_period")
    threshold = monitor.get("threshold")
    direction = monitor.get("direction", "any")
    query_params = monitor.get("query_params") or {}

    # Create a run record
    run_row = sb.table("monitor_runs").insert({
        "monitor_id": monitor_id,
        "company_id": company_id,
        "status": "ok",
    }).execute()
    run_id = run_row.data[0]["id"] if run_row.data else None

    try:
        current_range, previous_range = _get_date_ranges(schedule)

        # Fetch daily values for both periods (for significance test)
        current_values = await _fetch_metric_values(
            provider, metric, current_range, connection, query_params
        )
        previous_values = await _fetch_metric_values(
            provider, metric, previous_range, connection, query_params
        )

        # Also get aggregated totals for summary
        current_total = sum(current_values) if current_values else 0.0
        previous_total = sum(previous_values) if previous_values else 0.0

        # Calculate change
        if previous_total != 0:
            change_percent = ((current_total - previous_total) / previous_total) * 100
        else:
            change_percent = 0.0 if current_total == 0 else 100.0

        # Determine severity based on threshold
        status = "ok"
        threshold_breached = False

        if threshold is not None and comparison == "previous_period":
            abs_change = abs(change_percent) / 100
            if direction == "any" and abs_change >= threshold:
                threshold_breached = True
            elif direction == "down" and change_percent < 0 and abs_change >= threshold:
                threshold_breached = True
            elif direction == "up" and change_percent > 0 and abs_change >= threshold:
                threshold_breached = True

        # Run significance test if threshold was breached
        sig_result = None
        if threshold_breached and len(current_values) >= 2 and len(previous_values) >= 2:
            sig_result = await _run_significance_test(current_values, previous_values)

        # Determine final status
        finding_id = None
        if threshold_breached:
            if sig_result and sig_result.get("significant"):
                status = "critical" if abs(change_percent) >= 20 else "warning"
            else:
                # Change detected but not statistically significant
                status = "warning"

            # Create a finding
            finding = Finding(
                summary=f"{metric} changed {change_percent:+.1f}% ({schedule})",
                severity=status,
                metrics=[MetricSnapshot(
                    name=metric,
                    current_value=current_total,
                    previous_value=previous_total,
                    change_percent=round(change_percent, 2),
                )],
                evidence=[{
                    "type": "significance_test",
                    "significant": sig_result.get("significant") if sig_result else None,
                    "p_value": sig_result.get("p_value") if sig_result else None,
                    "method": sig_result.get("method_used") if sig_result else None,
                }] if sig_result else [],
                context=f"Monitor: {monitor.get('name', 'Unnamed')}",
                methodology=f"Compared {current_range[0]}–{current_range[1]} vs {previous_range[0]}–{previous_range[1]}",
                data_sources=[provider],
                skill_runs=["ga4_query", "stats_significance_test"] if sig_result else ["ga4_query"],
            )
            finding_id = await save_finding(company_id, finding)

            # Queue outbound event for delivery
            _queue_outbound_event(
                sb, company_id,
                event_type="monitor_alert",
                severity=status,
                finding_id=finding_id,
                monitor_id=monitor_id,
                payload={
                    "monitor_name": monitor.get("name", "Unnamed"),
                    "metric": metric,
                    "change_percent": round(change_percent, 2),
                    "current_value": current_total,
                    "previous_value": previous_total,
                },
            )

        # Build result detail
        detail = {
            "current_range": current_range,
            "previous_range": previous_range,
            "current_total": current_total,
            "previous_total": previous_total,
            "current_daily_values": current_values,
            "previous_daily_values": previous_values,
            "change_percent": round(change_percent, 2),
            "threshold_breached": threshold_breached,
        }
        if sig_result:
            detail["significance"] = {
                "significant": sig_result.get("significant"),
                "p_value": sig_result.get("p_value"),
                "method": sig_result.get("method_used"),
                "effect_size": sig_result.get("effect_size"),
            }

        # Update the run record
        now = datetime.now(timezone.utc).isoformat()
        update = {
            "status": status,
            "current_value": current_total,
            "previous_value": previous_total,
            "change_percent": round(change_percent, 2),
            "significant": sig_result.get("significant") if sig_result else None,
            "p_value": sig_result.get("p_value") if sig_result else None,
            "finding_id": finding_id,
            "detail": detail,
            "completed_at": now,
        }
        if run_id:
            sb.table("monitor_runs").update(update).eq("id", run_id).execute()

        # Update the monitor's last run state
        sb.table("monitors").update({
            "last_run_at": now,
            "last_status": status,
            "last_result": {
                "current_value": current_total,
                "previous_value": previous_total,
                "change_percent": round(change_percent, 2),
                "significant": sig_result.get("significant") if sig_result else None,
                "run_id": run_id,
                "finding_id": finding_id,
            },
        }).eq("id", monitor_id).execute()

        return {
            "monitor_id": monitor_id,
            "run_id": run_id,
            "status": status,
            "current_value": current_total,
            "previous_value": previous_total,
            "change_percent": round(change_percent, 2),
            "threshold_breached": threshold_breached,
            "finding_id": finding_id,
        }

    except Exception as exc:
        logger.exception("Monitor %s failed", monitor_id)
        now = datetime.now(timezone.utc).isoformat()

        if run_id:
            sb.table("monitor_runs").update({
                "status": "error",
                "error_message": str(exc)[:500],
                "completed_at": now,
            }).eq("id", run_id).execute()

        sb.table("monitors").update({
            "last_run_at": now,
            "last_status": "error",
            "last_result": {"error": str(exc)[:200], "run_id": run_id},
        }).eq("id", monitor_id).execute()

        return {
            "monitor_id": monitor_id,
            "run_id": run_id,
            "status": "error",
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Batch runner — runs all due monitors for a company (or all companies)
# ---------------------------------------------------------------------------

def _is_due(monitor: dict[str, Any]) -> bool:
    """Check if a monitor is due to run based on its schedule."""
    last_run = monitor.get("last_run_at")
    if not last_run:
        return True  # Never run before

    schedule = monitor.get("schedule", "weekly")
    if isinstance(last_run, str):
        last_run_dt = datetime.fromisoformat(last_run.replace("Z", "+00:00"))
    else:
        last_run_dt = last_run

    now = datetime.now(timezone.utc)
    elapsed = now - last_run_dt

    if schedule == "daily":
        return elapsed >= timedelta(hours=20)  # ~daily with some buffer
    elif schedule == "weekly":
        return elapsed >= timedelta(days=6)
    elif schedule == "monthly":
        return elapsed >= timedelta(days=27)

    return elapsed >= timedelta(days=6)


async def run_due_monitors(company_id: str | None = None) -> list[dict[str, Any]]:
    """Run all due active monitors. Optionally filter by company.

    Returns a list of run results.
    """
    sb = _get_supabase()

    # Load active monitors
    query = sb.table("monitors").select("*").eq("is_active", True)
    if company_id:
        query = query.eq("company_id", company_id)
    monitors = query.execute().data or []

    # Filter to only due monitors
    due_monitors = [m for m in monitors if _is_due(m)]

    if not due_monitors:
        logger.info("No monitors due to run")
        return []

    logger.info("Running %d due monitors", len(due_monitors))

    # Group by company to load connections once per company
    by_company: dict[str, list[dict]] = {}
    for m in due_monitors:
        by_company.setdefault(m["company_id"], []).append(m)

    results: list[dict[str, Any]] = []

    for cid, company_monitors in by_company.items():
        # Load connections for this company
        connections = sb.table("data_source_connections").select("*").eq(
            "company_id", cid
        ).eq("is_active", True).execute().data or []

        # Build provider -> connection map
        conn_by_provider: dict[str, dict] = {}
        for conn in connections:
            conn_by_provider[conn["provider"]] = conn

        for monitor in company_monitors:
            provider = monitor.get("provider", "ga4")
            connection = conn_by_provider.get(provider)

            if not connection:
                logger.warning(
                    "Monitor %s needs provider %s but no connection found",
                    monitor["id"], provider
                )
                # Mark as error
                now = datetime.now(timezone.utc).isoformat()
                sb.table("monitors").update({
                    "last_run_at": now,
                    "last_status": "error",
                    "last_result": {"error": f"No {provider} connection found"},
                }).eq("id", monitor["id"]).execute()
                results.append({
                    "monitor_id": monitor["id"],
                    "status": "error",
                    "error": f"No {provider} connection found",
                })
                continue

            result = await run_single_monitor(monitor, connection)
            results.append(result)

    return results