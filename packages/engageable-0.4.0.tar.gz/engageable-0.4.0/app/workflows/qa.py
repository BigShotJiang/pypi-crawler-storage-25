# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from __future__ import annotations

import json
import logging
from typing import Any, Annotated, Sequence

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage, ToolMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict

from supabase import create_client

from app.prompts import build_system_prompt
from engageable.skills.registry import get_registry
from engageable.skills.types import SkillResult

logger = logging.getLogger(__name__)


def _get_supabase():
    from app.config import get_settings
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# propose_action tool definition — the agent uses this for write operations
# ---------------------------------------------------------------------------

PROPOSE_ACTION_TOOL = {
    "name": "propose_action",
    "description": (
        "Propose a write action (create, update, delete) for the user to approve. "
        "The user will see a draft card and can Approve, Edit, or Dismiss. "
        "Use this for any action that creates, modifies, or deletes an entity. "
        "Never call write APIs directly — always propose first.\n\n"
        "Supported actions: project.create, project.update, monitor.create, monitor.update, monitor.delete, report.generate, report.delete, channel.create, channel.delete\n\n"
        "IMPORTANT: Do NOT use this for connecting data sources. "
        "Use suggest_connection instead."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": "The action to propose, e.g. 'project.create', 'project.update'",
            },
            "params": {
                "type": "object",
                "description": "Parameters for the action (the API payload)",
            },
            "explanation": {
                "type": "string",
                "description": "Brief human-readable description of what this action does",
            },
            "title": {
                "type": "string",
                "description": "Short title for the draft card, e.g. 'Create Project'",
            },
        },
        "required": ["action", "params", "explanation"],
    },
}

SHOW_INSIGHT_TOOL = {
    "name": "show_insight",
    "description": (
        "Show a structured insight card in the chat with key metrics. "
        "Use this to present important data findings, health check results, "
        "or summaries in a clear visual format with numbers. "
        "The card shows a title, severity badge, up to 6 metrics with values, "
        "and a brief description.\n\n"
        "Use severity 'info' for normal findings, 'warning' for things that need "
        "attention, and 'critical' for urgent issues.\n\n"
        "After calling this tool, you can still add text commentary in your response."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Card title, e.g. 'GA4 Health Check' or 'Weekly Traffic'",
            },
            "severity": {
                "type": "string",
                "enum": ["info", "warning", "critical"],
                "description": "info = normal, warning = needs attention, critical = urgent",
            },
            "metrics": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "label": {"type": "string"},
                        "value": {"type": "string"},
                        "change": {"type": "string", "description": "Optional, e.g. '+12%'"},
                    },
                    "required": ["label", "value"],
                },
                "description": "Key metrics to display (up to 6)",
            },
            "description": {
                "type": "string",
                "description": "Brief interpretation of the data",
            },
        },
        "required": ["title", "severity", "metrics", "description"],
    },
}

UPDATE_CONNECTION_TOOL = {
    "name": "update_connection",
    "description": (
        "Update a data source connection's status and profile after exploration. "
        "This is an auto-execute tool — it runs immediately without user approval "
        "because it's internal bookkeeping (saving what you learned about the data source). "
        "Use this after running introspection steps (ga4_list_properties, ga4_probe, "
        "ga4_get_metadata) to save the results and mark the connection as ready.\n\n"
        "Set status to 'ready' when exploration is complete and the property has data. "
        "Set status to 'needs_input' if you need the user to choose a property. "
        "Set status to 'failed' if the connection has a problem."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "provider": {
                "type": "string",
                "description": "The provider key, e.g. 'ga4'",
            },
            "status": {
                "type": "string",
                "enum": ["exploring", "ready", "needs_input", "failed"],
                "description": "New connection status",
            },
            "display_name": {
                "type": "string",
                "description": "Human-readable name for the connection (e.g. property name)",
            },
            "config": {
                "type": "object",
                "description": "Config updates (e.g. property_id if the user chose one)",
            },
            "profile": {
                "type": "object",
                "description": (
                    "Structured profile from introspection. Include fields like: "
                    "active_users_30d, sessions_30d, pageviews_30d, custom_events, "
                    "custom_dimensions, timezone, data_start_date"
                ),
            },
        },
        "required": ["provider", "status"],
    },
}

SUGGEST_CONNECTION_TOOL = {
    "name": "suggest_connection",
    "description": (
        "Show a connect button for a data source (e.g. GA4, Segment). "
        "Use this when the user agrees to connect a detected analytics provider. "
        "This renders the actual OAuth/connect button inline in chat — "
        "the user clicks it to start the connection flow. "
        "Do NOT use propose_action for connecting data sources."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "provider": {
                "type": "string",
                "description": "The provider key, e.g. 'ga4', 'segment', 'mixpanel'",
            },
            "label": {
                "type": "string",
                "description": "Button label, e.g. 'Connect Google Analytics 4'",
            },
            "message": {
                "type": "string",
                "description": "Brief message shown above the button",
            },
        },
        "required": ["provider", "label", "message"],
    },
}


SAVE_FINDING_TOOL = {
    "name": "save_finding",
    "description": (
        "Save a structured finding to the findings database. Findings are "
        "persisted and can trigger outbound notifications to the team.\n\n"
        "Quality bar — only save if ALL THREE are true:\n"
        "1. UNEXPECTED: would surprise someone who knows the business. Normal "
        "variation or expected seasonality is not a finding.\n"
        "2. SPECIFIC: you identified a segment, dimension, or root cause — not "
        "just an aggregate change.\n"
        "3. ACTIONABLE: recommendation points to a concrete next step.\n\n"
        "severity: 'info' = interesting but not urgent, 'warning' = needs attention, "
        "'critical' = requires immediate action."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "summary": {
                "type": "string",
                "description": "One-sentence summary of the finding",
            },
            "severity": {
                "type": "string",
                "enum": ["info", "warning", "critical"],
                "description": "How urgent this finding is",
            },
            "metrics": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "current_value": {"type": "number"},
                        "previous_value": {"type": "number"},
                        "change_percent": {"type": "number"},
                    },
                    "required": ["name", "current_value"],
                },
                "description": "Key metrics that support this finding",
            },
            "context": {
                "type": "string",
                "description": "Broader context — why this matters for the business",
            },
            "recommendation": {
                "type": "string",
                "description": "What the team should do about it",
            },
            "methodology": {
                "type": "string",
                "description": "Brief description of how you arrived at this finding",
            },
        },
        "required": ["summary", "severity"],
    },
}


SAVE_MEMORY_TOOL = {
    "name": "save_memory",
    "description": (
        "Save a fact or preference about the user's business, goals, or data. "
        "Use this when the user shares context that would be useful in future "
        "conversations — like business goals, key metrics, filters they care about, "
        "or domain knowledge. Memories persist across sessions.\n\n"
        "Examples of good memories:\n"
        "- 'Monthly signup goal is 500 new users'\n"
        "- 'Internal traffic uses @acme.com emails — exclude from reports'\n"
        "- 'Q4 (Oct-Dec) is peak season for this business'\n"
        "- 'Primary conversion event is purchase, not add_to_cart'\n\n"
        "Do NOT save ephemeral things (what the user just asked) or data you can "
        "look up (traffic numbers, metric values). Only save durable context."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "content": {
                "type": "string",
                "description": "The fact or preference to remember",
            },
            "category": {
                "type": "string",
                "enum": ["goal", "filter", "context", "general"],
                "description": (
                    "goal = business targets/KPIs, "
                    "filter = exclusions/segments to apply, "
                    "context = domain knowledge/seasonality, "
                    "general = anything else"
                ),
            },
        },
        "required": ["content", "category"],
    },
}

FORGET_MEMORY_TOOL = {
    "name": "forget_memory",
    "description": (
        "Remove a previously saved memory that is no longer accurate. "
        "Use this when the user corrects a fact or tells you something "
        "has changed. Pass the content (or close match) of the memory to remove."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "content": {
                "type": "string",
                "description": "The memory content to remove (exact or close match)",
            },
        },
        "required": ["content"],
    },
}


LIST_MONITORS_TOOL = {
    "name": "list_monitors",
    "description": (
        "List all monitors configured for this project. "
        "Returns each monitor's name, metric, schedule, threshold, status, and whether it's active. "
        "Use this when the user asks about their monitors, wants to see what's being tracked, "
        "or before suggesting a new monitor (to avoid duplicates)."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

LIST_REPORTS_TOOL = {
    "name": "list_reports",
    "description": (
        "List all generated reports for this project. "
        "Returns each report's title, description, status, chart count, and creation date. "
        "Use this when the user asks about their reports or wants to see what's been generated."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

SHOW_REPORT_TOOL = {
    "name": "show_report",
    "description": (
        "Show an inline preview of an existing report directly in the chat. "
        "Use this when the user asks to see, view, or show a report. "
        "This renders the report's sections, narrative text, and charts "
        "right in the conversation so the user doesn't have to navigate away.\n\n"
        "You need the report's ID. Use list_reports first if you don't know the ID."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "report_id": {
                "type": "string",
                "description": "The UUID of the report to display",
            },
        },
        "required": ["report_id"],
    },
}

SHOW_MONITORS_TOOL = {
    "name": "show_monitors",
    "description": (
        "Show an inline summary of all monitors directly in the chat. "
        "Use this when the user asks to see, view, or check their monitors. "
        "This renders a compact overview of each monitor's name, metric, schedule, "
        "status, and last result right in the conversation.\n\n"
        "Prefer this over list_monitors when the user wants a visual overview."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

SHOW_SOURCES_TOOL = {
    "name": "show_sources",
    "description": (
        "Show an inline summary of all connected data sources directly in the chat. "
        "Use this when the user asks to see, view, or check their data sources / connections. "
        "This renders a compact overview of each connection's provider, name, status, "
        "and key profile metrics right in the conversation.\n\n"
        "Prefer this over describing connections in text when the user wants a visual overview."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

LIST_CHANNELS_TOOL = {
    "name": "list_channels",
    "description": (
        "List all configured delivery channels (Slack, email, webhook) for this project. "
        "Returns each channel's provider, label, and whether it's active. "
        "Use this when the user asks about their notification channels, Slack integration, "
        "or before suggesting a new channel (to avoid duplicates)."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

LIST_DASHBOARDS_TOOL = {
    "name": "list_dashboards",
    "description": (
        "List all KPI dashboards for this project. "
        "Returns each dashboard's id, label, is_active, and bindings. "
        "Use this to check what dashboards exist before creating or modifying one."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

VALIDATE_DASHBOARD_TOOL = {
    "name": "validate_dashboard",
    "description": (
        "Validate a dashboard by fetching live data for all slots. "
        "Returns per-slot status: which slots have data and which failed. "
        "ALWAYS call this after building a dashboard. "
        "If any slots show 'no_data', fix the bindings with dashboard.update."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "dashboard_id": {
                "type": "string",
                "description": "The UUID of the dashboard to validate",
            },
        },
        "required": ["dashboard_id"],
    },
}

BUILD_DASHBOARD_TOOL = {
    "name": "build_dashboard",
    "description": (
        "Build a KPI dashboard from available data. Creates a dashboard with "
        "only the metrics that the connected data source can actually measure.\n\n"
        "Each slot in the bindings must have:\n"
        "- ga4_metric: a real GA4 API metric name (camelCase)\n"
        "- label: what the user sees — must accurately describe the metric\n"
        "- category: 'single_metric', 'time_series', or 'comparison'\n"
        "- size: 'hero', 'compact', 'standard', or 'large'\n"
        "- position: {col, row, colspan} for grid layout\n"
        "- priority: 'high', 'medium', or 'low'\n\n"
        "Rules:\n"
        "- Only include metrics you have verified exist in the data source\n"
        "- Labels must describe what the data IS, not what you wish it was\n"
        "- Better to have 3 accurate slots than 8 misleading ones\n"
        "- Use query_params.dimension for comparison slots"
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "label": {
                "type": "string",
                "description": "Dashboard name (e.g. 'Website Overview')",
            },
            "slots": {
                "type": "object",
                "description": (
                    "Map of slot_id → slot definition. Each slot has: "
                    "ga4_metric, label, category, size, position, priority, "
                    "and optional query_params"
                ),
            },
        },
        "required": ["label", "slots"],
    },
}

RECORD_MEASUREMENT_GAPS_TOOL = {
    "name": "record_measurement_gaps",
    "description": (
        "Record KPIs that the business should track but can't yet measure "
        "with connected data sources. Each gap becomes a persistent item "
        "the user can see and act on.\n\n"
        "Only record gaps for KPIs that are genuinely valuable — not every "
        "conceivable metric. Explain why_needed in business terms and give "
        "a concrete suggested_fix."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "gaps": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "kpi_id": {
                            "type": "string",
                            "description": "Unique identifier (e.g. 'newsletter_signups')",
                        },
                        "kpi_label": {
                            "type": "string",
                            "description": "Human-readable label",
                        },
                        "why_needed": {
                            "type": "string",
                            "description": "Why this KPI matters for the business",
                        },
                        "why_missing": {
                            "type": "string",
                            "description": "Why we can't measure it now",
                        },
                        "suggested_fix": {
                            "type": "string",
                            "description": "How to start measuring it (e.g. 'add GA4 custom event')",
                        },
                        "priority": {
                            "type": "string",
                            "enum": ["high", "medium", "low"],
                        },
                    },
                    "required": ["kpi_id", "kpi_label", "why_needed", "why_missing", "suggested_fix", "priority"],
                },
            },
        },
        "required": ["gaps"],
    },
}

LIST_MEASUREMENT_GAPS_TOOL = {
    "name": "list_measurement_gaps",
    "description": (
        "List measurement gaps for this project. Returns KPIs the business "
        "wants to track but can't yet measure. Use this to reference gaps "
        "in conversation or check if a previously-missing metric is now available."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
    },
}

ASK_BUSINESS_QUESTION_TOOL = {
    "name": "ask_business_question",
    "description": (
        "Ask the user a structured question about their business to fill a gap "
        "in your understanding. Renders as a card with 2-4 options plus optional "
        "free-text. Use this when you need business context before proceeding "
        "(e.g. before building a dashboard, you need to know their north star metric).\n\n"
        "Rules:\n"
        "- Maximum ONE question per session — don't interrogate\n"
        "- Only ask at natural pauses (start of session, after a finding, after a task)\n"
        "- Never ask something you could infer from data or website\n"
        "- The answer writes directly to the business profile"
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "question": {
                "type": "string",
                "description": "The question to ask, e.g. 'What metric do you check every morning?'",
            },
            "options": {
                "type": "array",
                "items": {"type": "string"},
                "description": "2-4 answer options, e.g. ['Growing signups', 'Improving conversion', 'Reducing churn']",
            },
            "allow_freetext": {
                "type": "boolean",
                "description": "Whether to show a free-text 'Something else' option",
                "default": True,
            },
            "profile_field": {
                "type": "string",
                "description": "Which business profile field this answer populates, e.g. 'north_star_metric', 'current_focus'",
            },
        },
        "required": ["question", "options", "profile_field"],
    },
}


class QAState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    company_id: str
    user_id: str
    task: str
    data_sources: list[dict[str, Any]]
    project: dict[str, Any] | None
    proposed_action: dict[str, Any] | None


def _build_skill_tools() -> list[dict[str, Any]]:
    """Convert registered skills into Anthropic tool definitions."""
    registry = get_registry()
    tools = []
    for skill in registry.list_skills():
        tools.append({
            "name": skill.name,
            "description": f"{skill.description}\n\nGuide: {skill.guide}",
            "input_schema": skill.input_schema,
        })
    return tools


async def _call_model(state: QAState) -> dict:
    """Node: send messages to Claude, let it decide which tools to call."""
    from app.config import get_settings, TASK_MODELS, DEFAULT_MODEL
    from app.usage import UsageTrackingHandler
    settings = get_settings()

    if not settings.anthropic_api_key:
        return {
            "messages": [AIMessage(content="Anthropic API key is not configured. Set ANTHROPIC_API_KEY in the engine .env file.")]
        }

    model_cfg = TASK_MODELS.get(state.get("task", ""), DEFAULT_MODEL)

    callbacks = []
    if state.get("user_id"):
        callbacks.append(UsageTrackingHandler(
            company_id=state["company_id"],
            user_id=state["user_id"],
            trigger=state.get("task", "chat"),
        ))

    llm = ChatAnthropic(
        model=model_cfg.id,
        api_key=settings.anthropic_api_key,
        max_tokens=model_cfg.max_tokens,
        callbacks=callbacks,
    )

    # Combine read-only skill tools + propose_action + suggest_connection
    tools = _build_skill_tools()
    tools.append(PROPOSE_ACTION_TOOL)
    tools.append(SUGGEST_CONNECTION_TOOL)
    tools.append(UPDATE_CONNECTION_TOOL)
    tools.append(SHOW_INSIGHT_TOOL)
    tools.append(SAVE_FINDING_TOOL)
    tools.append(SAVE_MEMORY_TOOL)
    tools.append(FORGET_MEMORY_TOOL)
    tools.append(LIST_MONITORS_TOOL)
    tools.append(LIST_REPORTS_TOOL)
    tools.append(SHOW_REPORT_TOOL)
    tools.append(SHOW_MONITORS_TOOL)
    tools.append(SHOW_SOURCES_TOOL)
    tools.append(LIST_CHANNELS_TOOL)
    tools.append(LIST_DASHBOARDS_TOOL)
    tools.append(VALIDATE_DASHBOARD_TOOL)
    tools.append(BUILD_DASHBOARD_TOOL)
    tools.append(RECORD_MEASUREMENT_GAPS_TOOL)
    tools.append(LIST_MEASUREMENT_GAPS_TOOL)
    tools.append(ASK_BUSINESS_QUESTION_TOOL)
    llm = llm.bind_tools(tools)

    response = await llm.ainvoke(state["messages"])
    return {"messages": [response]}


# Map skill name prefixes to their provider for learned notes logging
_SKILL_PROVIDER_MAP = {
    "ga4_": "ga4",
    "posthog_": "posthog",
    "mixpanel_": "mixpanel",
}


async def _log_connector_error(state: QAState, skill_name: str, error: str) -> None:
    """If a connector skill fails, log the error as a learned note on the connection."""
    provider = None
    for prefix, prov in _SKILL_PROVIDER_MAP.items():
        if skill_name.startswith(prefix):
            provider = prov
            break
    if not provider:
        return

    try:
        from app.routes.actions import append_learned_note
        # Truncate very long errors to keep notes useful
        note = f"{skill_name}: {error[:300]}"
        await append_learned_note(
            company_id=state["company_id"],
            provider=provider,
            note=note,
            category="error",
        )
    except Exception:
        logger.debug("Failed to log learned note for %s", skill_name, exc_info=True)


async def _execute_tools(state: QAState) -> dict:
    """Node: execute any tool calls the LLM made."""
    registry = get_registry()
    last_message = state["messages"][-1]

    if not hasattr(last_message, "tool_calls") or not last_message.tool_calls:
        return {"messages": []}

    tool_messages: list[ToolMessage] = []
    proposed_action = None

    for tool_call in last_message.tool_calls:
        skill_name = tool_call["name"]
        skill_args = tool_call["args"]

        # Handle show_insight — render an insight card in chat
        if skill_name == "show_insight":
            proposed_action = {
                "type": "insight_card",
                "title": skill_args.get("title", "Insight"),
                "severity": skill_args.get("severity", "info"),
                "metrics": skill_args.get("metrics", []),
                "description": skill_args.get("description", ""),
            }
            tool_messages.append(ToolMessage(
                content=json.dumps({
                    "status": "displayed",
                    "message": "Insight card shown to the user.",
                }),
                tool_call_id=tool_call["id"],
            ))
            continue

        # Handle save_finding — persist a structured finding to the database
        if skill_name == "save_finding":
            from app.memory.structured import save_finding
            from app.output.finding import Finding, MetricSnapshot

            metrics = [
                MetricSnapshot(
                    name=m["name"],
                    current_value=m["current_value"],
                    previous_value=m.get("previous_value"),
                    change_percent=m.get("change_percent"),
                )
                for m in skill_args.get("metrics", [])
            ]
            finding = Finding(
                summary=skill_args["summary"],
                severity=skill_args.get("severity", "info"),
                metrics=metrics,
                context=skill_args.get("context", ""),
                recommendation=skill_args.get("recommendation", ""),
                methodology=skill_args.get("methodology", ""),
            )
            finding_id = await save_finding(state["company_id"], finding)
            if finding_id:
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "status": "saved",
                        "finding_id": finding_id,
                        "message": "Finding saved and queued for notification.",
                    }),
                    tool_call_id=tool_call["id"],
                ))
            else:
                raise RuntimeError("save_finding returned None — database insert failed")
            continue

        # Handle save_memory — persist a fact with embedding for semantic retrieval
        if skill_name == "save_memory":
            try:
                from app.memory.retrieval import store_memory_with_embedding
                await store_memory_with_embedding(
                    company_id=state["company_id"],
                    content=skill_args["content"],
                    category=skill_args.get("category", "general"),
                )
                tool_messages.append(ToolMessage(
                    content=json.dumps({"status": "saved", "message": "Memory saved."}),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("save_memory failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to save memory: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle forget_memory — remove an outdated memory
        if skill_name == "forget_memory":
            try:
                sb = _get_supabase()
                content_match = skill_args["content"]
                # Find and delete memories with matching content (fuzzy via ilike)
                sb.table("agent_memory").delete().eq(
                    "company_id", state["company_id"]
                ).ilike("content", f"%{content_match}%").execute()
                tool_messages.append(ToolMessage(
                    content=json.dumps({"status": "forgotten", "message": "Memory removed."}),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("forget_memory failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to forget memory: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle list_monitors — read-only, returns monitor list
        if skill_name == "list_monitors":
            try:
                sb = _get_supabase()
                result = sb.table("monitors").select(
                    "id, name, metric, schedule, comparison, threshold, direction, "
                    "channel, is_active, last_run_at, last_status"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=False
                ).execute()
                monitors = result.data or []
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "monitors": monitors,
                        "count": len(monitors),
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("list_monitors failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to list monitors: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle list_reports — read-only, returns report list
        if skill_name == "list_reports":
            try:
                sb = _get_supabase()
                result = sb.table("reports").select(
                    "id, title, description, status, chart_count, created_by, created_at"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=True
                ).execute()
                reports = result.data or []
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "reports": reports,
                        "count": len(reports),
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("list_reports failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to list reports: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle show_report — fetch full report and render inline preview
        if skill_name == "show_report":
            try:
                sb = _get_supabase()
                report_id = skill_args.get("report_id", "")
                result = sb.table("reports").select("*").eq(
                    "id", report_id
                ).limit(1).execute()
                if not result.data:
                    tool_messages.append(ToolMessage(
                        content=json.dumps({"error": "Report not found"}),
                        tool_call_id=tool_call["id"],
                    ))
                else:
                    report = result.data[0]
                    spec = report.get("spec") or {}
                    proposed_action = {
                        "type": "report_preview",
                        "reportId": report["id"],
                        "title": spec.get("title") or report.get("title", "Report"),
                        "description": spec.get("description", ""),
                        "status": report.get("status", "ready"),
                        "chartCount": report.get("chart_count", 0),
                        "createdAt": report.get("created_at", ""),
                        "sections": spec.get("sections", []),
                    }
                    tool_messages.append(ToolMessage(
                        content=json.dumps({
                            "status": "displayed",
                            "message": "Report preview shown to the user.",
                        }),
                        tool_call_id=tool_call["id"],
                    ))
            except Exception as exc:
                logger.exception("show_report failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to show report: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle show_monitors — render inline monitors summary
        if skill_name == "show_monitors":
            try:
                sb = _get_supabase()
                result = sb.table("monitors").select(
                    "id, name, metric, schedule, comparison, threshold, direction, "
                    "channel, is_active, last_run_at, last_status, last_result"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=False
                ).execute()
                monitors = result.data or []
                proposed_action = {
                    "type": "monitors_summary",
                    "monitors": [
                        {
                            "id": m["id"],
                            "name": m["name"],
                            "metric": m["metric"],
                            "schedule": m["schedule"],
                            "threshold": m.get("threshold"),
                            "direction": m.get("direction", "any"),
                            "isActive": m.get("is_active", True),
                            "lastStatus": m.get("last_status"),
                            "lastRunAt": m.get("last_run_at"),
                            "changePercent": (m.get("last_result") or {}).get("change_percent"),
                        }
                        for m in monitors
                    ],
                }
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "status": "displayed",
                        "message": f"Monitors summary shown ({len(monitors)} monitors).",
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("show_monitors failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to show monitors: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle show_sources — render inline data sources summary
        if skill_name == "show_sources":
            try:
                sb = _get_supabase()
                result = sb.table("data_source_connections").select(
                    "id, provider, display_name, status, is_active, profile, "
                    "last_validated_at, validation_error, created_at"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=False
                ).execute()
                connections = result.data or []
                proposed_action = {
                    "type": "sources_summary",
                    "sources": [
                        {
                            "id": c["id"],
                            "provider": c["provider"],
                            "displayName": c.get("display_name") or c["provider"].upper(),
                            "status": c.get("status", "authenticated"),
                            "isActive": c.get("is_active", True),
                            "validationError": c.get("validation_error"),
                            "createdAt": c.get("created_at", ""),
                            "profile": c.get("profile") or {},
                        }
                        for c in connections
                    ],
                }
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "status": "displayed",
                        "message": f"Sources summary shown ({len(connections)} connections).",
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("show_sources failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to show sources: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle list_channels — read-only, returns channel list
        if skill_name == "list_channels":
            try:
                sb = _get_supabase()
                result = sb.table("channels").select(
                    "id, provider, label, slack_team_name, slack_channel_name, "
                    "email_addresses, is_active, created_at"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=False
                ).execute()
                channels = result.data or []
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "channels": channels,
                        "count": len(channels),
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("list_channels failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to list channels: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle ask_business_question — renders a question card in chat
        if skill_name == "ask_business_question":
            proposed_action = {
                "type": "business_question",
                "question": skill_args.get("question", ""),
                "options": skill_args.get("options", []),
                "allow_freetext": skill_args.get("allow_freetext", True),
                "profile_field": skill_args.get("profile_field", ""),
            }
            tool_messages.append(ToolMessage(
                content=json.dumps({
                    "status": "question_shown",
                    "message": "Business question shown to the user. Wait for their answer.",
                }),
                tool_call_id=tool_call["id"],
            ))
            continue

        # Handle build_dashboard — create a skill-based dashboard
        if skill_name == "build_dashboard":
            try:
                from app.routes.actions import _handle_dashboard_create
                user_dict = {"company_id": state["company_id"], "sub": state.get("user_id", "")}
                dashboard = await _handle_dashboard_create({
                    "label": skill_args.get("label", "Overview"),
                    "bindings": skill_args.get("slots", {}),
                    "is_active": True,
                }, user_dict)
                dashboard_id = dashboard.get("id", "")
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "status": "created",
                        "dashboard_id": dashboard_id,
                        "message": f"Dashboard created. Call validate_dashboard with dashboard_id='{dashboard_id}' to verify all slots have data.",
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("build_dashboard failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to build dashboard: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle record_measurement_gaps — persist unmeasurable KPIs
        if skill_name == "record_measurement_gaps":
            try:
                sb = _get_supabase()
                gaps = skill_args.get("gaps", [])
                created = []
                for gap in gaps:
                    result = sb.table("measurement_gaps").upsert(
                        {
                            "company_id": state["company_id"],
                            "kpi_id": gap["kpi_id"],
                            "kpi_label": gap["kpi_label"],
                            "why_needed": gap.get("why_needed", ""),
                            "why_missing": gap.get("why_missing", ""),
                            "suggested_fix": gap.get("suggested_fix", ""),
                            "priority": gap.get("priority", "medium"),
                            "status": "open",
                        },
                        on_conflict="company_id,kpi_id",
                    ).execute()
                    if result.data:
                        created.append(result.data[0].get("kpi_id", ""))
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "status": "recorded",
                        "gaps_count": len(created),
                        "gap_ids": created,
                        "message": f"Recorded {len(created)} measurement gaps.",
                    }),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("record_measurement_gaps failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to record gaps: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle list_measurement_gaps — read gaps
        if skill_name == "list_measurement_gaps":
            try:
                sb = _get_supabase()
                result = sb.table("measurement_gaps").select("*").eq(
                    "company_id", state["company_id"]
                ).order("priority").order("created_at").execute()
                gaps = result.data or []
                tool_messages.append(ToolMessage(
                    content=json.dumps({"gaps": gaps, "count": len(gaps)}),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("list_measurement_gaps failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to list gaps: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle validate_dashboard — checks which slots have live data
        if skill_name == "validate_dashboard":
            try:
                from app.routes.dashboards import validate_dashboard
                dashboard_id = skill_args.get("dashboard_id", "")
                user_dict = {"company_id": state["company_id"], "sub": state.get("user_id", "")}
                validation = await validate_dashboard(dashboard_id, user_dict)
                tool_messages.append(ToolMessage(
                    content=json.dumps(validation),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("validate_dashboard failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Validation failed: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle list_dashboards — read-only, returns dashboard list
        if skill_name == "list_dashboards":
            try:
                sb = _get_supabase()
                result = sb.table("dashboard_instances").select(
                    "id, template_id, label, is_active, bindings, created_at"
                ).eq("company_id", state["company_id"]).order(
                    "created_at", desc=False
                ).execute()
                dashboards = result.data or []
                tool_messages.append(ToolMessage(
                    content=json.dumps({"dashboards": dashboards, "count": len(dashboards)}),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("list_dashboards failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to list dashboards: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle propose_action — don't execute, just capture it
        if skill_name == "propose_action":
            proposed_action = {
                "type": "proposed_action",
                "action": skill_args.get("action", ""),
                "params": skill_args.get("params", {}),
                "explanation": skill_args.get("explanation", ""),
                "title": skill_args.get("title", "Suggested Action"),
                "status": "pending",
            }
            tool_messages.append(ToolMessage(
                content=json.dumps({
                    "status": "proposed",
                    "message": "Action proposed to the user. They will approve, edit, or dismiss it.",
                }),
                tool_call_id=tool_call["id"],
            ))
            continue

        # Handle update_connection — auto-execute, no approval needed
        if skill_name == "update_connection":
            try:
                from app.routes.actions import _handle_connection_update
                params = {
                    "provider": skill_args.get("provider"),
                    "company_id": state["company_id"],
                }
                if "status" in skill_args:
                    params["status"] = skill_args["status"]
                if "profile" in skill_args:
                    params["profile"] = skill_args["profile"]
                if "config" in skill_args:
                    params["config"] = skill_args["config"]
                if "display_name" in skill_args:
                    params["display_name"] = skill_args["display_name"]
                user_dict = {"company_id": state["company_id"], "sub": state.get("user_id", "")}
                result = await _handle_connection_update(params, user_dict)

                # If status changed to "ready", extract profile from events
                if skill_args.get("status") == "ready" and skill_args.get("profile"):
                    try:
                        from app.models.profile_learner import extract_profile_from_events
                        profile_data = skill_args["profile"]
                        events = profile_data.get("custom_events", [])
                        if events:
                            import asyncio
                            asyncio.create_task(
                                extract_profile_from_events(state["company_id"], events)
                            )
                    except Exception:
                        logger.debug("Background data profile extraction failed", exc_info=True)

                tool_messages.append(ToolMessage(
                    content=json.dumps({"status": "updated", "result": result}),
                    tool_call_id=tool_call["id"],
                ))
            except Exception as exc:
                logger.exception("update_connection failed")
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": f"Failed to update connection: {exc}"}),
                    tool_call_id=tool_call["id"],
                ))
            continue

        # Handle suggest_connection — render a connect button in chat
        if skill_name == "suggest_connection":
            proposed_action = {
                "type": "connect_source",
                "provider": skill_args.get("provider", ""),
                "label": skill_args.get("label", "Connect"),
                "message": skill_args.get("message", ""),
            }
            tool_messages.append(ToolMessage(
                content=json.dumps({
                    "status": "suggested",
                    "message": "Connection button shown to the user.",
                }),
                tool_call_id=tool_call["id"],
            ))
            continue

        skill = registry.get_skill(skill_name)
        if skill is None:
            tool_messages.append(ToolMessage(
                content=json.dumps({"error": f"Unknown skill: {skill_name}"}),
                tool_call_id=tool_call["id"],
            ))
            continue

        # Auto-inject credentials from data sources for connector skills.
        # The LLM never has real credentials; they live only in the DB-loaded data_sources.
        if skill_name.startswith("ga4_"):
            injected = False
            for ds in state.get("data_sources", []):
                if ds.get("provider") == "ga4" and ds.get("credentials"):
                    skill_args["credentials"] = ds["credentials"]
                    if "property_id" not in skill_args and ds.get("config", {}).get("property_id"):
                        skill_args["property_id"] = ds["config"]["property_id"]
                    injected = True
                    break
            if not injected:
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "error": "No active GA4 connection found. The user needs to connect GA4 first."
                    }),
                    tool_call_id=tool_call["id"],
                ))
                continue

        if skill_name.startswith("posthog_"):
            injected = False
            for ds in state.get("data_sources", []):
                if ds.get("provider") == "posthog" and ds.get("credentials"):
                    skill_args["credentials"] = ds["credentials"]
                    if "project_id" not in skill_args and ds.get("config", {}).get("project_id"):
                        skill_args["project_id"] = ds["config"]["project_id"]
                    injected = True
                    break
            if not injected:
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "error": "No active PostHog connection found. The user needs to connect PostHog first."
                    }),
                    tool_call_id=tool_call["id"],
                ))
                continue

        if skill_name.startswith("mixpanel_"):
            injected = False
            for ds in state.get("data_sources", []):
                if ds.get("provider") == "mixpanel" and ds.get("credentials"):
                    creds = {**ds["credentials"]}
                    config = ds.get("config") or {}
                    # Inject base_url from config (for EU data residency)
                    if config.get("base_url") and "base_url" not in creds:
                        creds["base_url"] = config["base_url"]
                    skill_args["credentials"] = creds
                    if "project_id" not in skill_args and config.get("project_id"):
                        skill_args["project_id"] = config["project_id"]
                    injected = True
                    break
            if not injected:
                tool_messages.append(ToolMessage(
                    content=json.dumps({
                        "error": "No active Mixpanel connection found. The user needs to connect Mixpanel first."
                    }),
                    tool_call_id=tool_call["id"],
                ))
                continue

        try:
            result: SkillResult = await skill.execute(skill_args)
            if result.success:
                tool_messages.append(ToolMessage(
                    content=json.dumps(result.data),
                    tool_call_id=tool_call["id"],
                ))
            else:
                tool_messages.append(ToolMessage(
                    content=json.dumps({"error": result.error}),
                    tool_call_id=tool_call["id"],
                ))
                # Log connector errors as learned notes
                await _log_connector_error(state, skill_name, result.error or "Unknown error")
        except NotImplementedError as exc:
            tool_messages.append(ToolMessage(
                content=json.dumps({"error": str(exc)}),
                tool_call_id=tool_call["id"],
            ))
        except Exception as exc:
            logger.exception("Skill %s failed", skill_name)
            error_msg = f"Skill execution failed: {exc}"
            tool_messages.append(ToolMessage(
                content=json.dumps({"error": error_msg}),
                tool_call_id=tool_call["id"],
            ))
            # Log connector errors as learned notes
            await _log_connector_error(state, skill_name, error_msg)

    result = {"messages": tool_messages}
    if proposed_action:
        result["proposed_action"] = proposed_action
    return result


def _should_continue(state: QAState) -> str:
    """Edge: if the last message has tool calls, execute them; otherwise finish."""
    last = state["messages"][-1]
    if hasattr(last, "tool_calls") and last.tool_calls:
        return "execute_tools"
    return END


def build_qa_graph() -> StateGraph:
    graph = StateGraph(QAState)

    graph.add_node("call_model", _call_model)
    graph.add_node("execute_tools", _execute_tools)

    graph.set_entry_point("call_model")
    graph.add_conditional_edges("call_model", _should_continue)
    graph.add_edge("execute_tools", "call_model")

    return graph.compile()


def _build_history_messages(chat_history: list[dict[str, Any]]) -> list[BaseMessage]:
    """Convert stored chat messages into LangChain message objects.

    Only includes text messages — skips proposed actions, insight cards, etc.
    to keep context clean and avoid confusing the model.
    """
    messages: list[BaseMessage] = []
    for msg in chat_history:
        content = msg.get("content", {})
        role = msg.get("role", "")

        # Extract text from the content object
        if isinstance(content, dict) and content.get("type") == "text":
            text = content.get("text", "")
        elif isinstance(content, str):
            text = content
        else:
            # Skip non-text messages (proposed actions, insight cards, etc.)
            continue

        if not text:
            continue

        if role == "user":
            messages.append(HumanMessage(content=text))
        elif role == "agent":
            messages.append(AIMessage(content=text))

    return messages


async def run_qa(
    question: str,
    company_id: str,
    data_sources: list[dict[str, Any]] | None = None,
    user_id: str = "",
    task: str = "chat",
    project: dict[str, Any] | None = None,
    chat_history: list[dict[str, Any]] | None = None,
    recent_findings: list[dict[str, Any]] | None = None,
    memories: list[dict[str, Any]] | None = None,
    user_email: str | None = None,
    user_name: str | None = None,
) -> list[dict[str, Any]]:
    """Run the Q&A workflow and return a list of message content dicts.

    Returns a list so we can send both structured content (insight cards,
    proposed actions) and text in the same turn.
    """
    connections = data_sources or []

    # Determine mode override for special tasks
    mode_override = None
    if task == "proactive_investigation":
        mode_override = "proactive_investigation"
    elif task == "outbound":
        mode_override = "outbound"

    # Run data quality checks for analysis tasks with ready connections
    data_quality_results = None
    ready_connections = [c for c in connections if c.get("status") == "ready"]
    if ready_connections and task in ("chat", "proactive_investigation"):
        try:
            from engageable.skills.analysis.data_quality import DataQualitySkill
            dq_skill = DataQualitySkill()
            dq_result = await dq_skill.execute({
                "company_id": company_id,
                "connections": ready_connections,
            })
            if dq_result.success and dq_result.data:
                data_quality_results = dq_result.data
        except Exception:
            logger.debug("Data quality check failed, continuing without it", exc_info=True)

    # Load business profile
    business_profile_data = None
    try:
        bp_result = sb.table("business_profiles").select("profile, completeness").eq(
            "company_id", company_id
        ).limit(1).execute()
        if bp_result.data:
            business_profile_data = bp_result.data[0]
    except Exception:
        logger.debug("Failed to load business profile, continuing without it", exc_info=True)

    system_prompt = build_system_prompt(
        project=project,
        connections=connections,
        recent_findings=recent_findings,
        memories=memories,
        user_email=user_email,
        user_name=user_name,
        mode_override=mode_override,
        data_quality_results=data_quality_results,
        business_profile=business_profile_data,
    )

    # Build message list: system prompt + history + current question
    messages: list[BaseMessage] = [SystemMessage(content=system_prompt)]
    if chat_history:
        messages.extend(_build_history_messages(chat_history))
    messages.append(HumanMessage(content=question))

    workflow = build_qa_graph()

    initial_state: QAState = {
        "messages": messages,
        "company_id": company_id,
        "user_id": user_id,
        "task": task,
        "data_sources": connections,
        "project": project,
        "proposed_action": None,
    }

    result = await workflow.ainvoke(initial_state)

    response_parts: list[dict[str, Any]] = []

    # Extract the final text response first (agent's explanation)
    for msg in reversed(result["messages"]):
        if isinstance(msg, AIMessage) and msg.content and not getattr(msg, "tool_calls", None):
            content = msg.content
            if isinstance(content, list):
                text = "".join(
                    block.get("text", "") if isinstance(block, dict) else str(block)
                    for block in content
                )
            else:
                text = str(content)
            if text.strip():
                response_parts.append({"type": "text", "text": text})
            break

    # Then append the proposed action card (below the explanation)
    if result.get("proposed_action"):
        response_parts.append(result["proposed_action"])

    if not response_parts:
        response_parts.append({
            "type": "text",
            "text": "I wasn't able to generate a response. Please try rephrasing your question.",
        })

    return response_parts