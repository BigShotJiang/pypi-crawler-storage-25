# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Build a ReportSpec from findings + live data queries.

The LLM acts as a compiler: it takes findings, data context, and a topic,
then produces a structured ReportSpec JSON with narrative sections and ChartSpecs.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.config import get_settings, TASK_MODELS, DEFAULT_MODEL
from app.memory.structured import get_recent_findings

logger = logging.getLogger(__name__)


def _get_supabase():
    from supabase import create_client
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


REPORT_SYSTEM_PROMPT = """\
You are a report generator for Engageable, an AI data analyst product.
Your job is to take data findings and produce a structured ReportSpec as JSON.

## Output format

Return ONLY valid JSON matching this schema:

```
{
  "title": "string",
  "description": "string (1-2 sentence summary)",
  "global_parameters": [
    {
      "key": "string",
      "label": "string",
      "type": "date_range | select",
      "default": "any"
    }
  ],
  "sections": [
    {
      "heading": "string",
      "narrative": "string (1-3 paragraphs of analysis in markdown)",
      "charts": [
        {
          "spec": {
            "id": "string (unique)",
            "title": "string",
            "description": "string",
            "query": {
              "connector": "string (e.g. ga4)",
              "connection_id": "string",
              "config": { ... connector-specific query params ... }
            },
            "transform": {
              "x": "string (column key for x-axis)",
              "series": [{ "field": "string", "label": "string" }],
              "pivot": { "dimension": "string", "metric": "string", "top_n": 10 }
            },
            "chart": {
              "type": "line | bar | horizontal_bar | stacked_bar | stacked_area | pie | donut | metric_card | table",
              "height": 400
            },
            "parameters": []
          },
          "width": "full | half | third"
        }
      ]
    }
  ]
}
```

## Chart type guidelines

- Time series data → "line" or "stacked_area"
- Comparisons across categories → "bar" or "horizontal_bar"
- Composition / share → "pie" or "donut"
- Single KPI with trend → "metric_card"
- Detailed breakdown → "table"

## Rules

1. Every section MUST have a "narrative" with human-readable analysis
2. Metric cards are great as the first section for key numbers
3. Use meaningful chart titles — not "Chart 1"
4. For GA4 queries, use real metric names (activeUsers, sessions, screenPageViews, etc.)
5. Include 2-5 sections in a typical report
6. Keep narratives concise — lead with the insight, not the methodology
7. For metric_card chart types, include the metric value in the query config
8. Do NOT include credentials in query configs — they are auto-injected

Return ONLY the JSON. No markdown code fences. No explanation before or after."""


async def build_report(
    company_id: str,
    report_id: str,
    topic: str | None = None,
    date_range: str | None = None,
    finding_ids: list[str] | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    """Build a ReportSpec using the LLM.

    Gathers context (findings, connection info) and asks the LLM to compile
    a structured report.
    """
    settings = get_settings()
    sb = _get_supabase()

    # Gather context
    findings = []
    if finding_ids:
        for fid in finding_ids:
            result = sb.table("findings").select("*").eq("id", fid).limit(1).execute()
            if result.data:
                findings.append(result.data[0])
    else:
        findings = await get_recent_findings(company_id, limit=20)

    # Load connections for query templates
    connections = sb.table("data_source_connections").select(
        "id, provider, display_name, config, profile, status"
    ).eq("company_id", company_id).eq("is_active", True).execute().data or []

    # Build the prompt
    context_parts = []

    if topic:
        context_parts.append(f"Report topic: {topic}")
    if title:
        context_parts.append(f"Suggested title: {title}")
    if date_range:
        context_parts.append(f"Date range: {date_range}")

    # Add connection context
    for conn in connections:
        provider = conn.get("provider", "unknown")
        conn_id = conn.get("id", "")
        display = conn.get("display_name") or provider
        config = conn.get("config") or {}
        profile = conn.get("profile") or {}

        conn_info = f"\nConnected data source: {display} ({provider})"
        conn_info += f"\n  connection_id: {conn_id}"
        if config.get("property_id"):
            conn_info += f"\n  property_id: {config['property_id']}"
        if profile.get("active_users_30d"):
            conn_info += f"\n  ~{profile['active_users_30d']:,} active users (30d)"
        if profile.get("custom_events"):
            conn_info += f"\n  Custom events: {', '.join(profile['custom_events'][:10])}"
        context_parts.append(conn_info)

    # Add findings context
    if findings:
        context_parts.append("\nRecent findings to incorporate:")
        for f in findings[:10]:
            severity = f.get("severity", "info")
            summary = f.get("summary", "")
            metrics = f.get("metrics", [])
            context_parts.append(f"  [{severity}] {summary}")
            for m in metrics:
                name = m.get("name", "")
                current = m.get("current_value")
                change = m.get("change_percent")
                if current is not None:
                    detail = f"    {name}: {current}"
                    if change is not None:
                        detail += f" ({change:+.1f}%)"
                    context_parts.append(detail)
    else:
        context_parts.append(
            "\nNo specific findings available. Generate a general overview report "
            "using the connected data sources. Query for key metrics like "
            "activeUsers, sessions, screenPageViews over the relevant period."
        )

    user_message = "\n".join(context_parts)

    # Call the LLM
    model_cfg = TASK_MODELS.get("report", DEFAULT_MODEL)
    llm = ChatAnthropic(
        model=model_cfg.id,
        api_key=settings.anthropic_api_key,
        max_tokens=4096,
    )

    response = await llm.ainvoke([
        SystemMessage(content=REPORT_SYSTEM_PROMPT),
        HumanMessage(content=user_message),
    ])

    # Parse the JSON response
    content = response.content
    if isinstance(content, list):
        content = "".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        )

    # Strip markdown fences if the LLM added them
    text = content.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]  # drop opening fence
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    try:
        spec = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.error("LLM returned invalid JSON for report %s: %s", report_id, exc)
        # Return a minimal valid spec
        spec = {
            "title": title or "Report",
            "description": "Report generation encountered an error. The AI response was not valid JSON.",
            "sections": [{
                "heading": "Error",
                "narrative": f"Could not parse the generated report. Raw output length: {len(text)} chars.",
                "charts": [],
            }],
        }

    return spec