# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Outbound agent — batch pending events, compose a message, deliver via channels."""

from __future__ import annotations

import json
import logging
from datetime import datetime, time as dt_time, timezone
from typing import Any

from supabase import create_client

from app.config import get_settings, TASK_MODELS
from app.output.slack import deliver_slack
from app.output.email import deliver_email, deliver_engagement_email
from app.output.inapp import deliver_inapp, deliver_inapp_card
from app.prompts import build_system_prompt

logger = logging.getLogger(__name__)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Notification rules
# ---------------------------------------------------------------------------

def _is_in_quiet_hours(prefs: dict[str, Any]) -> bool:
    """Check if the current time falls within quiet hours for this user."""
    quiet_start = prefs.get("quiet_hours_start")
    quiet_end = prefs.get("quiet_hours_end")
    tz_name = prefs.get("timezone", "UTC")

    if not quiet_start or not quiet_end:
        return False

    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo(tz_name)
        now = datetime.now(tz).time()

        # Parse time strings (HH:MM:SS or HH:MM)
        if isinstance(quiet_start, str):
            parts = quiet_start.split(":")
            quiet_start = dt_time(int(parts[0]), int(parts[1]))
        if isinstance(quiet_end, str):
            parts = quiet_end.split(":")
            quiet_end = dt_time(int(parts[0]), int(parts[1]))

        # Handle overnight quiet hours (e.g. 22:00 → 07:00)
        if quiet_start <= quiet_end:
            return quiet_start <= now <= quiet_end
        else:
            return now >= quiet_start or now <= quiet_end
    except Exception:
        logger.warning("Failed to check quiet hours for prefs %s", prefs.get("id"))
        return False


def _severity_meets_threshold(event_severity: str, threshold: str) -> bool:
    """Check if the event severity meets the user's threshold."""
    levels = {"info": 0, "warning": 1, "critical": 2}
    return levels.get(event_severity, 0) >= levels.get(threshold, 0)


def _load_notification_prefs(sb, company_id: str) -> list[dict[str, Any]]:
    """Load notification preferences for a company's users."""
    result = sb.table("notification_preferences").select(
        "*, channels(id, provider, slack_bot_token, slack_channel_id, "
        "slack_webhook_url, email_addresses, is_active)"
    ).eq("company_id", company_id).execute()
    return result.data or []


def _load_active_channels(sb, company_id: str) -> list[dict[str, Any]]:
    """Load all active channels for a company."""
    result = sb.table("channels").select("*").eq(
        "company_id", company_id
    ).eq("is_active", True).execute()
    return result.data or []


# ---------------------------------------------------------------------------
# Message composition via LLM
# ---------------------------------------------------------------------------

async def _compose_message(
    events: list[dict[str, Any]],
    company_id: str,
    project: dict[str, Any] | None = None,
    connections: list[dict[str, Any]] | None = None,
    memories: list[dict[str, Any]] | None = None,
) -> str:
    """Use the LLM to compose a single natural message from batched events."""
    from langchain_anthropic import ChatAnthropic
    from langchain_core.messages import SystemMessage, HumanMessage

    # Build events summary for the prompt
    event_lines = []
    for event in events:
        payload = event.get("payload", {})
        severity = event.get("severity", "info").upper()
        event_type = event.get("event_type", "unknown")

        if event_type == "monitor_alert":
            name = payload.get("monitor_name", "Unknown")
            metric = payload.get("metric", "")
            change = payload.get("change_percent", 0)
            event_lines.append(
                f"- [{severity}] Monitor '{name}': {metric} changed {change:+.1f}% "
                f"(current: {payload.get('current_value', '?')}, previous: {payload.get('previous_value', '?')})"
            )
        elif event_type == "proactive_finding":
            summary = payload.get("summary", "")
            event_lines.append(f"- [{severity}] Proactive finding: {summary}")
        else:
            event_lines.append(f"- [{severity}] {event_type}: {json.dumps(payload)[:200]}")

    events_summary = "\n".join(event_lines) if event_lines else "All monitors OK. No issues detected."

    # Build system prompt in outbound mode
    system_prompt = build_system_prompt(
        project=project,
        connections=connections,
        memories=memories,
        mode_override="outbound",
        events_summary=events_summary,
    )

    settings = get_settings()
    model_config = TASK_MODELS["compose"]
    llm = ChatAnthropic(
        model=model_config.id,
        api_key=settings.anthropic_api_key,
        max_tokens=1024,
    )

    response = await llm.ainvoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content="Compose the outbound message now."),
    ])

    text = response.content

    # Strip any hallucinated tool-call artifacts the LLM may produce.
    # These look like XML blocks: <function_calls>...</function_calls>
    import re
    text = re.sub(r"<function_calls>.*?</function_calls>", "", text, flags=re.DOTALL)
    text = re.sub(r"<invoke\b.*?</invoke>", "", text, flags=re.DOTALL)

    # Clean up leading/trailing whitespace and "Subject:" lines (email-style
    # artefacts that shouldn't appear in chat messages)
    text = re.sub(r"^Subject:.*\n?", "", text, flags=re.MULTILINE)
    text = text.strip()

    return text


# ---------------------------------------------------------------------------
# Finding → insight card conversion
# ---------------------------------------------------------------------------

async def _deliver_finding_cards(
    company_id: str,
    events: list[dict[str, Any]],
) -> None:
    """Look up findings referenced by outbound events and insert insight cards."""
    sb = _get_supabase()

    finding_ids = [
        e["finding_id"] for e in events
        if e.get("finding_id")
    ]
    if not finding_ids:
        return

    result = sb.table("findings").select(
        "id, summary, severity, metrics"
    ).in_("id", finding_ids).execute()

    for finding in result.data or []:
        raw_metrics = finding.get("metrics") or []
        if not raw_metrics:
            continue

        # Convert finding metrics to insight card format
        card_metrics = []
        for m in raw_metrics[:6]:
            entry: dict[str, str] = {
                "label": m.get("name", ""),
                "value": str(m.get("current_value", "")),
            }
            change = m.get("change_percent")
            if change is not None:
                entry["change"] = f"{change:+.1f}%"
            card_metrics.append(entry)

        content: dict[str, Any] = {
            "type": "insight_card",
            "title": finding.get("summary", "Finding"),
            "severity": finding.get("severity", "info"),
            "metrics": card_metrics,
            "description": "",
        }

        try:
            await deliver_inapp_card(company_id, content)
        except Exception as exc:
            logger.warning("Failed to deliver insight card for finding %s: %s", finding["id"], exc)


# ---------------------------------------------------------------------------
# Delivery
# ---------------------------------------------------------------------------

async def _deliver_to_channels(
    company_id: str,
    message: str,
    severity: str,
    channels: list[dict[str, Any]],
    prefs: list[dict[str, Any]],
    project_name: str | None = None,
    events: list[dict[str, Any]] | None = None,
) -> list[str]:
    """Deliver a composed message to all appropriate channels.

    Per-user logic: deliver to users who are awake and whose severity
    threshold is met. Only external channels are subject to quiet hours
    — in-app delivery always happens.

    Returns a list of channel IDs that were delivered to.
    """
    delivered_via = []

    # Always deliver in-app (not gated by quiet hours)
    try:
        # Insert insight cards for findings that have structured data
        await _deliver_finding_cards(company_id, events or [])
        await deliver_inapp(company_id, message, severity)
        delivered_via.append("in-app")
    except Exception as exc:
        logger.warning("In-app delivery failed: %s", exc)

    # Build set of channel IDs that should receive delivery based on
    # per-user preferences. A channel is delivered to if at least one
    # user who subscribes to it is awake and meets severity threshold.
    eligible_channel_ids: set[str] = set()
    has_prefs = False

    for pref in prefs:
        has_prefs = True
        # Skip users in quiet hours (unless critical)
        if _is_in_quiet_hours(pref) and severity != "critical":
            continue
        # Skip users whose severity threshold isn't met
        threshold = pref.get("severity_threshold", "info")
        if not _severity_meets_threshold(severity, threshold):
            continue
        # This user is eligible — include their linked channels
        pref_channels = pref.get("channels")
        if isinstance(pref_channels, list):
            for ch in pref_channels:
                ch_id = ch.get("id") if isinstance(ch, dict) else ch
                if ch_id:
                    eligible_channel_ids.add(ch_id)
        else:
            # No per-user channel linkage — all channels are eligible
            for ch in channels:
                if ch.get("id"):
                    eligible_channel_ids.add(ch["id"])

    # If no notification preferences exist, deliver to all active channels
    if not has_prefs:
        eligible_channel_ids = {ch["id"] for ch in channels if ch.get("id")}

    # Deliver to eligible external channels
    for channel in channels:
        if not channel.get("is_active"):
            continue
        if channel.get("id") not in eligible_channel_ids:
            continue

        provider = channel.get("provider")
        try:
            if provider == "slack":
                await deliver_slack(channel, message, severity)
                delivered_via.append(f"slack:{channel['id']}")
            elif provider == "email":
                await deliver_email(channel, message, severity, project_name=project_name)
                delivered_via.append(f"email:{channel['id']}")
        except Exception as exc:
            logger.warning("Delivery to %s channel %s failed: %s", provider, channel["id"], exc)

    return delivered_via


# ---------------------------------------------------------------------------
# Engagement email processing
# ---------------------------------------------------------------------------

async def _process_engagement_event(event: dict[str, Any], sb) -> str:
    """Process a single engagement_email outbound event.

    Composes the email via AI, sends it with frequency control footer,
    and records the send in engagement_sends.

    Returns: final status ('sent' or 'failed')
    """
    from app.output.engagement_composer import compose_engagement_email, build_rich_user_context
    from app.utils.hmac_tokens import generate_email_token

    payload = event.get("payload", {})
    rule_id = payload.get("rule_id")
    rule_slug = payload.get("rule_slug", "unknown")
    user_id = payload.get("user_id")
    composer_prompt = payload.get("composer_prompt", "")

    if not user_id or not rule_id:
        raise ValueError(f"Engagement event missing user_id or rule_id: {event['id']}")

    # Build rich context for composition
    company_id = event["company_id"]
    user_context = build_rich_user_context(user_id, company_id)

    company_result = sb.table("companies").select("name").eq("id", company_id).limit(1).execute()
    company_context = company_result.data[0] if company_result.data else {"name": ""}

    rule = {
        "id": rule_id,
        "slug": rule_slug,
        "name": rule_slug,
        "composer_prompt": composer_prompt,
    }

    # Compose via AI
    composed = await compose_engagement_email(rule, user_context, company_context)

    # Generate HMAC tokens for footer links
    settings = get_settings()
    base_url = settings.engine_url
    slow_down_token = generate_email_token(user_id, "slow_down")
    unsub_token = generate_email_token(user_id, "unsubscribe")
    slow_down_url = f"{base_url}/api/email/slow-down?token={slow_down_token}"
    unsub_url = f"{base_url}/api/email/unsubscribe?token={unsub_token}"

    # Send the email
    to_email = user_context.get("email")
    if not to_email:
        raise ValueError(f"No email address for user {user_id}")

    result = await deliver_engagement_email(
        to_email=to_email,
        subject=composed["subject"],
        body_markdown=composed["body"],
        slow_down_url=slow_down_url,
        unsubscribe_url=unsub_url,
        project_name=company_context.get("name"),
    )

    # Record in engagement_sends
    sb.table("engagement_sends").insert({
        "user_id": user_id,
        "rule_id": rule_id,
        "company_id": company_id,
        "outbound_event_id": event["id"],
        "subject": composed["subject"],
        "body_markdown": composed["body"],
        "resend_message_id": result.get("id"),
        "status": "sent",
        "sent_at": datetime.now(timezone.utc).isoformat(),
    }).execute()

    return "sent"


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def process_pending_events(company_id: str | None = None) -> dict[str, Any]:
    """Process all pending outbound events.

    Groups events by company, composes a single message per company,
    and delivers to configured channels.

    Returns stats about what was processed.
    """
    sb = _get_supabase()

    # Recover stale "composing" events — if they've been stuck for >5 minutes,
    # reset them to "pending" so they get retried
    from datetime import timedelta
    stale_cutoff = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
    stale_query = sb.table("outbound_events").select("id").eq(
        "status", "composing"
    ).lt("updated_at", stale_cutoff)
    if company_id:
        stale_query = stale_query.eq("company_id", company_id)
    stale_result = stale_query.limit(50).execute()
    for stale in stale_result.data or []:
        sb.table("outbound_events").update({"status": "pending"}).eq(
            "id", stale["id"]
        ).execute()
    if stale_result.data:
        logger.info("Reset %d stale composing events to pending", len(stale_result.data))

    # Load pending events
    query = sb.table("outbound_events").select("*").eq("status", "pending").order(
        "created_at", desc=False
    )
    if company_id:
        query = query.eq("company_id", company_id)
    result = query.limit(100).execute()
    events = result.data or []

    if not events:
        return {"processed": 0, "companies": 0}

    # Gate engagement emails by user cadence before processing
    gated_events = []
    for event in events:
        if event.get("event_type") != "engagement_email":
            gated_events.append(event)
            continue

        user_id = (event.get("payload") or {}).get("user_id")
        if not user_id:
            gated_events.append(event)
            continue

        prefs = sb.table("notification_preferences").select(
            "email_cadence"
        ).eq("user_id", user_id).limit(1).execute()
        cadence = prefs.data[0]["email_cadence"] if prefs.data else "realtime"

        if cadence == "off":
            sb.table("outbound_events").update({
                "status": "skipped",
                "error_message": "User email_cadence is off",
            }).eq("id", event["id"]).execute()
            logger.info("Skipped engagement email for user %s (cadence=off)", user_id)
        elif cadence in ("daily", "weekly", "monthly"):
            sb.table("outbound_events").update({
                "status": "held",
                "error_message": f"Held for {cadence} digest",
            }).eq("id", event["id"]).execute()
            logger.info("Held engagement email for user %s (cadence=%s)", user_id, cadence)
        else:
            gated_events.append(event)

    events = gated_events

    stats = {"processed": 0, "companies": 0, "delivered": 0, "held": 0, "failed": 0}

    # Process engagement emails individually (each targets a specific user)
    engagement_events = [e for e in events if e.get("event_type") == "engagement_email"]
    regular_events = [e for e in events if e.get("event_type") != "engagement_email"]

    for event in engagement_events:
        sb.table("outbound_events").update({"status": "composing"}).eq("id", event["id"]).execute()
        try:
            final_status = await _process_engagement_event(event, sb)
            sb.table("outbound_events").update({
                "status": final_status,
                "sent_at": datetime.now(timezone.utc).isoformat() if final_status == "sent" else None,
            }).eq("id", event["id"]).execute()
            stats["processed"] += 1
            stats["delivered"] += 1
        except Exception as exc:
            logger.exception("Engagement email failed for event %s", event["id"])
            sb.table("outbound_events").update({
                "status": "failed",
                "error_message": str(exc)[:500],
            }).eq("id", event["id"]).execute()
            stats["failed"] += 1

    events = regular_events

    if not events:
        return stats

    # Group by company
    by_company: dict[str, list[dict]] = {}
    for event in events:
        cid = event["company_id"]
        by_company.setdefault(cid, []).append(event)

    for cid, company_events in by_company.items():
        stats["companies"] += 1
        event_ids = [e["id"] for e in company_events]

        # Mark as composing
        for eid in event_ids:
            sb.table("outbound_events").update({"status": "composing"}).eq("id", eid).execute()

        try:
            # Load context
            project_result = sb.table("companies").select("*").eq("id", cid).limit(1).execute()
            project = project_result.data[0] if project_result.data else None

            conn_result = sb.table("data_source_connections").select("*").eq(
                "company_id", cid
            ).eq("is_active", True).execute()
            connections = conn_result.data or []

            mem_result = sb.table("agent_memory").select("category, content").eq(
                "company_id", cid
            ).order("created_at", desc=False).limit(20).execute()
            memories = mem_result.data or []

            # Compose message
            max_severity = max(
                (e.get("severity", "info") for e in company_events),
                key=lambda s: {"info": 0, "warning": 1, "critical": 2}.get(s, 0),
            )
            message = await _compose_message(
                company_events, cid, project, connections, memories,
            )

            # Load channels and preferences
            channels = _load_active_channels(sb, cid)
            prefs = _load_notification_prefs(sb, cid)

            # Deliver
            project_name = project.get("name") if project else None
            delivered_via = await _deliver_to_channels(
                cid, message, max_severity, channels, prefs,
                project_name=project_name,
                events=company_events,
            )

            # Update events
            now = datetime.now(timezone.utc).isoformat()
            final_status = "sent" if delivered_via else "held"
            for eid in event_ids:
                sb.table("outbound_events").update({
                    "status": final_status,
                    "composed_message": message,
                    "delivered_via": delivered_via,
                    "sent_at": now if final_status == "sent" else None,
                }).eq("id", eid).execute()

            stats["processed"] += len(company_events)
            if final_status == "sent":
                stats["delivered"] += len(company_events)
            else:
                stats["held"] += len(company_events)

        except Exception as exc:
            logger.exception("Outbound processing failed for company %s", cid)
            for eid in event_ids:
                sb.table("outbound_events").update({
                    "status": "failed",
                    "error_message": str(exc)[:500],
                }).eq("id", eid).execute()
            stats["failed"] += len(company_events)

    return stats