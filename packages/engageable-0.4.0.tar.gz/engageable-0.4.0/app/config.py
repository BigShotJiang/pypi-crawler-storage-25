# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from pydantic import model_validator
from pydantic_settings import BaseSettings
from functools import lru_cache

# Appended to CORS for any non-production ENGINE_ENV so root `.env` can list prod hosts only
# while local Vite still works (localhost vs 127.0.0.1, port 9100).
_LOCAL_VITE_ORIGINS: tuple[str, ...] = (
    "http://localhost:9100",
    "http://127.0.0.1:9100",
)


def _supabase_url_looks_local(url: str) -> bool:
    u = url.strip().lower()
    return "127.0.0.1" in u or "localhost" in u or ":9120" in u

_ENGINE_DIR = Path(__file__).resolve().parent.parent
_REPO_ROOT = _ENGINE_DIR.parent


def _repo_env_files() -> tuple[str, ...] | None:
    """Load root `.env` first, then `.env.local` (local overrides). Missing files are skipped."""
    paths: list[str] = []
    for name in (".env", ".env.local"):
        p = _REPO_ROOT / name
        if p.is_file():
            paths.append(str(p))
    return tuple(paths) if paths else None


class Settings(BaseSettings):
    supabase_url: str
    supabase_service_role_key: str
    anthropic_api_key: str = ""
    openai_api_key: str = ""  # For text-embedding-3-small (semantic memory)
    resend_api_key: str = ""  # For email delivery
    cron_secret: str = ""  # Shared secret for cron trigger endpoints
    email_token_secret: str = ""  # HMAC secret for email preference tokens (falls back to cron_secret)
    resend_webhook_secret: str = ""  # Resend webhook signing secret for open/click tracking
    engine_env: str = "development"
    log_level: str = "info"
    cors_origins: list[str] = ["http://localhost:9100", "http://127.0.0.1:9100"]

    # Google OAuth (GA4)
    google_client_id: str = ""
    google_client_secret: str = ""
    google_redirect_uri: str = "http://localhost:9101/api/connections/ga4/callback"
    frontend_url: str = "http://localhost:9100"

    # Slack OAuth
    slack_client_id: str = ""
    slack_client_secret: str = ""
    slack_signing_secret: str = ""
    slack_redirect_uri: str = "http://localhost:9101/api/channels/slack/callback"

    # MCP OAuth (hosted MCP endpoint)
    engine_url: str = "http://localhost:9101"  # Base URL for OAuth issuer

    model_config = {
        "env_file": _repo_env_files(),
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @model_validator(mode="after")
    def merge_local_dev_cors_origins(self) -> Settings:
        """Append local Vite origins when running locally or any non-production env.

        - Non-``production`` ``ENGINE_ENV``: merge (covers dev/staging).
        - ``ENGINE_ENV=production`` but ``SUPABASE_URL`` is local (from ``.env.local``): still merge,
          so a prod-like root ``.env`` does not block the browser when only Supabase is overridden locally.
        """
        env = self.engine_env.strip().lower()
        if env == "production" and not _supabase_url_looks_local(self.supabase_url):
            return self
        merged: list[str] = []
        seen: set[str] = set()
        for origin in [*self.cors_origins, *_LOCAL_VITE_ORIGINS]:
            if origin not in seen:
                merged.append(origin)
                seen.add(origin)
        self.cors_origins = merged
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()


def cors_allow_origin_regex(settings: Settings) -> str | None:
    """Regex for Starlette CORSMiddleware — matches local Vite on any port (list alone can miss edge cases)."""
    if settings.engine_env.strip().lower() == "production" and not _supabase_url_looks_local(settings.supabase_url):
        return None
    return r"^http://(localhost|127\.0\.0\.1)(:\d+)?$"


# ---------------------------------------------------------------------------
# LLM model registry — single source of truth for models and pricing
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ModelConfig:
    id: str
    input_cost_per_m: float   # USD per 1M input tokens
    output_cost_per_m: float  # USD per 1M output tokens
    context_window: int = 200_000  # max input tokens
    max_tokens: int = 4096         # max output tokens

    @property
    def input_cost(self) -> float:
        return self.input_cost_per_m / 1_000_000

    @property
    def output_cost(self) -> float:
        return self.output_cost_per_m / 1_000_000


MODELS: dict[str, ModelConfig] = {
    "sonnet": ModelConfig(
        id="claude-sonnet-4-6",
        input_cost_per_m=3.0,
        output_cost_per_m=15.0,
        context_window=200_000,
        max_tokens=64_000,
    ),
    "haiku": ModelConfig(
        id="claude-haiku-4-5",
        input_cost_per_m=1.0,
        output_cost_per_m=5.0,
        context_window=200_000,
        max_tokens=64_000,
    ),
    "opus": ModelConfig(
        id="claude-opus-4-6",
        input_cost_per_m=5.0,
        output_cost_per_m=25.0,
        context_window=200_000,
        max_tokens=128_000,
    ),
}

# Task presets — pick the right model for the job
TASK_MODELS: dict[str, ModelConfig] = {
    "chat": MODELS["sonnet"],           # Interactive Q&A with users
    "analysis": MODELS["sonnet"],       # Deep data analysis & reporting
    "compose": MODELS["haiku"],         # Drafting API calls, SQL, summaries
    "classify": MODELS["haiku"],        # Routing, intent detection, tagging
}

DEFAULT_MODEL = MODELS["sonnet"]