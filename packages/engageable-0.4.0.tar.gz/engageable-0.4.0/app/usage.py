# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""LLM usage tracking via LangChain callback handler."""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from langchain_core.callbacks import AsyncCallbackHandler
from langchain_core.outputs import LLMResult

logger = logging.getLogger(__name__)


def _get_model_costs(model_id: str) -> tuple[float, float]:
    """Return (input_cost_per_token, output_cost_per_token) from the unified config."""
    from app.config import MODELS, DEFAULT_MODEL

    for cfg in MODELS.values():
        if cfg.id == model_id:
            return cfg.input_cost, cfg.output_cost
    return DEFAULT_MODEL.input_cost, DEFAULT_MODEL.output_cost


class UsageTrackingHandler(AsyncCallbackHandler):
    """Captures token usage from each LLM call and logs it to Supabase."""

    def __init__(self, company_id: str, user_id: str, trigger: str = "chat"):
        super().__init__()
        self.company_id = company_id
        self.user_id = user_id
        self.trigger = trigger

    async def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        """Called when an LLM call finishes. Extract usage and persist."""
        try:
            usage = {}
            model = ""

            if response.llm_output:
                usage = response.llm_output.get("usage", {})
                model = response.llm_output.get("model_name", "") or response.llm_output.get("model", "")

            # Some providers put usage in generation_info
            if not usage and response.generations:
                for gen_list in response.generations:
                    for gen in gen_list:
                        info = getattr(gen, "generation_info", {}) or {}
                        if "usage" in info:
                            usage = info["usage"]
                            model = model or info.get("model", "")
                            break
                    if usage:
                        break

            input_tokens = usage.get("input_tokens", 0)
            output_tokens = usage.get("output_tokens", 0)
            total_tokens = input_tokens + output_tokens

            if total_tokens == 0:
                return

            input_cost, output_cost = _get_model_costs(model)
            estimated_cost = (input_tokens * input_cost) + (output_tokens * output_cost)

            await _save_usage(
                company_id=self.company_id,
                user_id=self.user_id,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=total_tokens,
                estimated_cost=estimated_cost,
                trigger=self.trigger,
            )

        except Exception:
            logger.exception("Failed to log LLM usage")


async def _save_usage(
    company_id: str,
    user_id: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    total_tokens: int,
    estimated_cost: float,
    trigger: str,
) -> None:
    from app.config import get_settings
    from supabase import create_client

    settings = get_settings()
    sb = create_client(settings.supabase_url, settings.supabase_service_role_key)

    sb.table("llm_usage").insert({
        "company_id": company_id,
        "user_id": user_id,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": total_tokens,
        "estimated_cost_usd": float(estimated_cost),
        "trigger": trigger,
    }).execute()

    logger.info(
        "LLM usage: model=%s tokens=%d cost=$%.4f company=%s",
        model, total_tokens, estimated_cost, company_id,
    )