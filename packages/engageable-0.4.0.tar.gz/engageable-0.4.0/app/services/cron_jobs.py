# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Shared cron job execution logic.

Used by both the in-process scheduler and the admin manual-trigger endpoint.
"""

from __future__ import annotations

from typing import Any


async def execute_cron_job(job_type: str) -> dict[str, Any]:
    """Execute a single cron job and return a normalized result dict."""
    if job_type == "monitors":
        from app.workflows.monitor_runner import run_due_monitors
        runs = await run_due_monitors()
        findings_created = sum(1 for r in runs if r.get("finding_id"))
        return {
            "monitors_run": len(runs),
            "findings_created": findings_created,
        }

    elif job_type == "outbound":
        from app.workflows.outbound import process_pending_events
        stats = await process_pending_events()
        return {
            "events_processed": stats.get("processed", 0),
            "messages_sent": stats.get("delivered", 0),
            "messages_held": stats.get("held", 0),
            "companies_processed": stats.get("companies", 0),
        }

    elif job_type == "proactive":
        from app.workflows.proactive import run_proactive_for_all_companies
        runs = await run_proactive_for_all_companies()
        findings_created = sum(r.get("findings_created", 0) for r in runs)
        return {
            "companies_processed": len(runs),
            "findings_created": findings_created,
        }

    elif job_type == "evaluate":
        from app.services.eval_signals import detect_drop_offs
        count = await detect_drop_offs()
        return {
            "drop_offs_detected": count,
        }

    elif job_type == "engagement":
        from app.workflows.engagement_evaluator import evaluate_scheduled_rules
        stats = await evaluate_scheduled_rules()
        return {
            "rules_evaluated": stats.get("rules_evaluated", 0),
            "candidates_found": stats.get("candidates_found", 0),
            "events_created": stats.get("events_created", 0),
        }

    elif job_type == "engagement_digest":
        from app.workflows.engagement_digest import process_engagement_digests
        stats = await process_engagement_digests()
        return {
            "users_processed": stats.get("users_processed", 0),
            "emails_sent": stats.get("emails_sent", 0),
            "sends_batched": stats.get("sends_batched", 0),
        }

    else:
        raise ValueError(f"Unknown job type: {job_type}")