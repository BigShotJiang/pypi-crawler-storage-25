# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""LLM-as-judge — uses Haiku to score question-answer quality."""

from __future__ import annotations

import json
import logging
from typing import Any

from app.config import get_settings, TASK_MODELS

logger = logging.getLogger(__name__)


async def judge_conversation(
    question: str,
    answer: str,
    context: str | None = None,
) -> dict[str, Any]:
    """Score a question-answer pair using LLM-as-judge.

    Returns: {quality_score: float 0-1, reasoning: str, dimensions: {accuracy, relevance, completeness}}
    """
    from langchain_anthropic import ChatAnthropic
    from langchain_core.messages import SystemMessage, HumanMessage

    settings = get_settings()
    model_config = TASK_MODELS["classify"]  # Uses Haiku

    llm = ChatAnthropic(
        model=model_config.id,
        api_key=settings.anthropic_api_key,
        max_tokens=512,
    )

    system = (
        "You are an evaluation judge for an AI data analyst. "
        "Score the assistant's answer on three dimensions, each 0.0-1.0:\n"
        "- accuracy: Are the facts and numbers correct? Does the answer avoid fabrication?\n"
        "- relevance: Does the answer address what was asked?\n"
        "- completeness: Does the answer provide enough detail without being verbose?\n\n"
        "Respond with ONLY valid JSON:\n"
        '{"accuracy": 0.0-1.0, "relevance": 0.0-1.0, "completeness": 0.0-1.0, "reasoning": "brief explanation"}'
    )

    user_content = f"Question: {question}\n\nAnswer: {answer}"
    if context:
        user_content += f"\n\nContext: {context}"

    response = await llm.ainvoke([
        SystemMessage(content=system),
        HumanMessage(content=user_content),
    ])

    try:
        result = json.loads(response.content)
        accuracy = float(result.get("accuracy", 0.5))
        relevance = float(result.get("relevance", 0.5))
        completeness = float(result.get("completeness", 0.5))
        quality_score = (accuracy + relevance + completeness) / 3.0

        return {
            "quality_score": round(quality_score, 2),
            "reasoning": result.get("reasoning", ""),
            "dimensions": {
                "accuracy": round(accuracy, 2),
                "relevance": round(relevance, 2),
                "completeness": round(completeness, 2),
            },
            "judge_model": model_config.id,
        }
    except (json.JSONDecodeError, ValueError, TypeError) as exc:
        logger.warning("Failed to parse judge response: %s", exc)
        return {
            "quality_score": 0.5,
            "reasoning": f"Failed to parse judge output: {response.content[:200]}",
            "dimensions": {"accuracy": 0.5, "relevance": 0.5, "completeness": 0.5},
            "judge_model": model_config.id,
        }


async def evaluate_message(
    company_id: str,
    message_id: str,
    question: str,
    answer: str,
) -> str | None:
    """Judge a message and save the evaluation. Returns evaluation ID."""
    from supabase import create_client
    settings = get_settings()
    sb = create_client(settings.supabase_url, settings.supabase_service_role_key)

    result = await judge_conversation(question, answer)

    eval_row = {
        "company_id": company_id,
        "message_id": message_id,
        "signal_type": "llm_judge",
        "quality_score": result["quality_score"],
        "judge_reasoning": result["reasoning"],
        "judge_model": result["judge_model"],
    }

    insert_result = sb.table("evaluations").insert(eval_row).execute()
    if insert_result.data:
        return insert_result.data[0]["id"]
    return None