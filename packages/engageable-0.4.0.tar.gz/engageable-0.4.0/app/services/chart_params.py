# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Chart parameter substitution engine.

Resolves parameter placeholders in chart query configs. Placeholders
use the format {{param_key}} in string values within the config dict.
"""

from __future__ import annotations
from typing import Any
import copy
import re


def resolve_parameters(
    config: dict[str, Any],
    parameters: list[dict[str, Any]],
    overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve parameter placeholders in a query config.

    Args:
        config: The query template config dict (will not be mutated)
        parameters: List of ParameterDef dicts with {key, label, type, default, options?}
        overrides: User-provided parameter values (keys matching ParameterDef.key)

    Returns:
        A new config dict with all {{param_key}} placeholders replaced.
    """
    # Build resolved values: default → override
    resolved: dict[str, Any] = {}
    for param in parameters:
        key = param["key"]
        resolved[key] = param.get("default")

    if overrides:
        for key, value in overrides.items():
            if key in resolved:
                resolved[key] = value

    # Deep-copy config and substitute
    result = copy.deepcopy(config)
    _substitute(result, resolved)
    return result


def _substitute(obj: Any, values: dict[str, Any]) -> None:
    """Recursively substitute {{key}} placeholders in a dict/list structure."""
    if isinstance(obj, dict):
        for k in list(obj.keys()):
            v = obj[k]
            if isinstance(v, str):
                obj[k] = _replace_placeholders(v, values)
            elif isinstance(v, (dict, list)):
                _substitute(v, values)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, str):
                obj[i] = _replace_placeholders(item, values)
            elif isinstance(item, (dict, list)):
                _substitute(item, values)


def _replace_placeholders(text: str, values: dict[str, Any]) -> Any:
    """Replace {{key}} placeholders in a string.

    If the entire string is a single placeholder (e.g. "{{date_range}}"),
    return the raw value (preserving type). Otherwise, do string interpolation.
    """
    # Check if entire string is a single placeholder
    match = re.fullmatch(r'\{\{(\w+)\}\}', text.strip())
    if match:
        key = match.group(1)
        if key in values:
            return values[key]
        return text

    # Otherwise, do string interpolation
    def replacer(m: re.Match) -> str:
        key = m.group(1)
        if key in values:
            val = values[key]
            return str(val) if val is not None else ""
        return m.group(0)  # Leave unresolved placeholders as-is

    return re.sub(r'\{\{(\w+)\}\}', replacer, text)