# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Evaluation signal detection — detects quality issues from conversation patterns."""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any

from supabase import create_client

from app.config import get_settings

logger = logging.getLogger(__name__)

# Patterns that suggest the user is correcting the agent
CORRECTIVE_PATTERNS = [
    r"\bno[,.]?\s",
    r"\bthat'?s?\s+(wrong|incorrect|not right|not what)",
    r"\bi\s+(meant|said|asked)",
    r"\bactually[,.]?\s",
    r"\bnot\s+what\s+i",
    r"\bwrong\b",
    r"\bincorrect\b",
    r"\btry\s+again\b",
    r"\bthat\s+doesn'?t\s+(look|seem|sound)\s+right",
]

CORRECTIVE_RE = re.compile("|".join(CORRECTIVE_PATTERNS), re.IGNORECASE)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


def _insert_evaluation(
    company_id: str,
    message_id: str | None,
    signal_type: str,
    quality_score: float | None = None,
    judge_reasoning: str | None = None,
) -> str | None:
    """Insert an evaluation record. Returns the evaluation ID."""
    sb = _get_supabase()
    row: dict[str, Any] = {
        "company_id": company_id,
        "signal_type": signal_type,
    }
    if message_id:
        row["message_id"] = message_id
    if quality_score is not None:
        row["quality_score"] = quality_score
    if judge_reasoning:
        row["judge_reasoning"] = judge_reasoning

    result = sb.table("evaluations").insert(row).execute()
    if result.data:
        return result.data[0]["id"]
    return None


def detect_corrective_follow_up(
    company_id: str,
    user_message_text: str,
    previous_agent_message_id: str | None = None,
) -> bool:
    """Check if the user's message is a corrective follow-up.

    Returns True if a corrective signal was detected and recorded.
    """
    if not CORRECTIVE_RE.search(user_message_text):
        return False

    eval_id = _insert_evaluation(
        company_id=company_id,
        message_id=previous_agent_message_id,
        signal_type="follow_up",
        quality_score=0.3,
        judge_reasoning=f"User message matched corrective pattern: {user_message_text[:200]}",
    )
    if eval_id:
        logger.info("Corrective follow-up detected for company %s (eval %s)", company_id, eval_id)
    return eval_id is not None


async def detect_reask(
    company_id: str,
    user_message_text: str,
    current_message_id: str | None = None,
) -> bool:
    """Check if the user is re-asking a substantially similar question.

    Uses embedding similarity against recent user messages (last 5 min).
    Returns True if a reask was detected and recorded.
    """
    try:
        from app.memory.retrieval import get_embedding
    except ImportError:
        logger.debug("Embedding support not available, skipping reask detection")
        return False

    sb = _get_supabase()
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()

    # Get recent user messages
    recent = sb.table("chat_messages").select("id, content, created_at").eq(
        "company_id", company_id
    ).eq("role", "user").gt(
        "created_at", cutoff
    ).order("created_at", desc=True).limit(5).execute()

    if not recent.data or len(recent.data) < 2:
        return False

    # Compare current message embedding against recent ones
    try:
        current_embedding = await get_embedding(user_message_text)
    except Exception:
        logger.debug("Failed to get embedding for reask detection")
        return False

    for msg in recent.data[1:]:  # Skip the current message
        msg_text = ""
        content = msg.get("content", {})
        if isinstance(content, dict):
            msg_text = content.get("text", "")
        elif isinstance(content, str):
            msg_text = content

        if not msg_text:
            continue

        try:
            msg_embedding = await get_embedding(msg_text)
            similarity = _cosine_similarity(current_embedding, msg_embedding)
            if similarity > 0.85:
                eval_id = _insert_evaluation(
                    company_id=company_id,
                    message_id=current_message_id,
                    signal_type="reask",
                    quality_score=0.2,
                    judge_reasoning=(
                        f"User re-asked similar question (similarity={similarity:.3f}). "
                        f"Original: {msg_text[:100]}. Reask: {user_message_text[:100]}"
                    ),
                )
                if eval_id:
                    logger.info("Reask detected for company %s (eval %s)", company_id, eval_id)
                return True
        except Exception:
            continue

    return False


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    import numpy as np
    a_arr = np.array(a)
    b_arr = np.array(b)
    dot = np.dot(a_arr, b_arr)
    norm = np.linalg.norm(a_arr) * np.linalg.norm(b_arr)
    if norm == 0:
        return 0.0
    return float(dot / norm)


async def detect_drop_offs(company_id: str | None = None) -> int:
    """Detect drop-offs: agent messages with no user reply for 24h+.

    Designed to be called via cron. Returns count of drop-offs detected.
    """
    sb = _get_supabase()
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()

    # Find agent messages older than 24h that are the latest message in their company
    query = sb.table("chat_messages").select(
        "id, company_id, created_at"
    ).eq("role", "agent").lt("created_at", cutoff).order(
        "created_at", desc=True
    ).limit(100)

    if company_id:
        query = query.eq("company_id", company_id)

    result = query.execute()
    agent_messages = result.data or []

    count = 0
    for msg in agent_messages:
        cid = msg["company_id"]
        msg_time = msg["created_at"]

        # Check if there's a user message after this agent message
        follow_up = sb.table("chat_messages").select("id").eq(
            "company_id", cid
        ).eq("role", "user").gt(
            "created_at", msg_time
        ).limit(1).execute()

        if not follow_up.data:
            # Check if we already recorded this drop-off
            existing = sb.table("evaluations").select("id").eq(
                "message_id", msg["id"]
            ).eq("signal_type", "drop_off").limit(1).execute()

            if not existing.data:
                _insert_evaluation(
                    company_id=cid,
                    message_id=msg["id"],
                    signal_type="drop_off",
                    quality_score=0.5,
                    judge_reasoning="Agent message received no user follow-up for 24h+",
                )
                count += 1

    logger.info("Drop-off detection complete: %d new drop-offs found", count)
    return count