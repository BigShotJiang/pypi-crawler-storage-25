# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from __future__ import annotations

import jwt
from jwt import PyJWKClient
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from functools import lru_cache
from typing import Annotated

from app.config import Settings, get_settings

_bearer = HTTPBearer(auto_error=False)

# Cache user_id → company_id to avoid a DB round-trip on every request.
_company_id_cache: dict[str, str | None] = {}


@lru_cache(maxsize=1)
def _jwks_client(supabase_url: str) -> PyJWKClient:
    jwks_url = f"{supabase_url}/auth/v1/.well-known/jwks.json"
    return PyJWKClient(jwks_url, cache_keys=True)


def _verify_token(token: str, settings: Settings) -> dict:
    """Verify a Supabase JWT and return the decoded claims."""
    client = _jwks_client(settings.supabase_url)
    signing_key = client.get_signing_key_from_jwt(token)
    issuer = f"{settings.supabase_url}/auth/v1"

    claims = jwt.decode(
        token,
        signing_key.key,
        algorithms=["RS256", "ES256"],
        issuer=issuer,
        audience="authenticated",
    )
    return claims


async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    settings: Settings = Depends(get_settings),
) -> dict:
    """FastAPI dependency that extracts and validates the Supabase JWT.

    Returns the decoded claims dict enriched with company_id from user_profiles.
    Always contains at minimum:
      - sub: user UUID
      - email: user email
      - company_id: company UUID (or None)
    """
    if credentials is None:
        raise HTTPException(status_code=401, detail="Missing authorization header")

    try:
        claims = _verify_token(credentials.credentials, settings)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid token: {exc}")

    # Enrich with company_id from user_profiles (not in the JWT)
    if "company_id" not in claims:
        user_id = claims.get("sub")
        cached = _company_id_cache.get(user_id)
        if cached is not None:
            claims["company_id"] = cached
        else:
            try:
                from app.db import get_supabase
                sb = get_supabase()
                result = sb.table("user_profiles").select("company_id").eq(
                    "id", user_id
                ).limit(1).execute()
                if result.data:
                    cid = result.data[0].get("company_id")
                    claims["company_id"] = cid
                    _company_id_cache[user_id] = cid
            except Exception:
                pass  # Non-fatal — some endpoints don't need company_id

    return claims


CurrentUser = Annotated[dict, Depends(get_current_user)]