# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.auth import CurrentUser
from app.config import cors_allow_origin_regex, get_settings
from engageable.skills.registry import get_registry
from app.workflows.qa import run_qa
from app.memory.structured import start_analysis_run, complete_analysis_run
from app.routes.ga4_oauth import router as ga4_oauth_router
from app.routes.chat import router as chat_router
from app.routes.actions import router as actions_router
from app.routes.discover import router as discover_router
from app.routes.monitors import router as monitors_router
from app.routes.reports import router as reports_router
from app.routes.channels import router as channels_router
from app.routes.api_keys import router as api_keys_router
from app.routes.settings import router as settings_router
from app.routes.admin import router as admin_router
from app.routes.cron import router as cron_router
from app.routes.findings import router as findings_router
from app.routes.evaluations import router as evaluations_router
from app.routes.mcp import router as mcp_router
from app.routes.oauth import router as oauth_router
from app.routes.email_preferences import router as email_preferences_router
from app.routes.webhooks import router as webhooks_router
from app.routes.dashboards import router as dashboards_router

settings = get_settings()

app = FastAPI(title="Engageable Engine", version="0.1.0")

_cors_regex = cors_allow_origin_regex(settings)
print(
    f"[engine] CORS allow_origins={settings.cors_origins!r} allow_origin_regex={_cors_regex!r}",
    flush=True,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_origin_regex=_cors_regex,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(ga4_oauth_router)
app.include_router(chat_router)
app.include_router(actions_router)
app.include_router(discover_router)
app.include_router(monitors_router)
app.include_router(reports_router)
app.include_router(channels_router)
app.include_router(api_keys_router)
app.include_router(settings_router)
app.include_router(admin_router)
app.include_router(cron_router)
app.include_router(findings_router)
app.include_router(evaluations_router)
app.include_router(mcp_router)
app.include_router(oauth_router)
app.include_router(email_preferences_router)
app.include_router(webhooks_router)
app.include_router(dashboards_router)


@app.on_event("startup")
async def _startup() -> None:
    registry = get_registry()
    registry.discover_packages("app.skills")
    count = len(registry.list_skills())
    print(f"Skill registry loaded: {count} skill(s) registered")

    # Mount the hosted MCP app (OAuth 2.1 + StreamableHTTP)
    from app.mcp.hosted import create_hosted_mcp_app
    mcp_app = create_hosted_mcp_app(
        issuer_url=settings.engine_url,
        resource_url=f"{settings.engine_url}/mcp",
        frontend_url=settings.frontend_url,
    )
    app.mount("/mcp", mcp_app)
    print(f"Hosted MCP endpoint mounted at /mcp (issuer: {settings.engine_url})")

    from app.scheduler import start_scheduler
    start_scheduler()


@app.on_event("shutdown")
async def _shutdown() -> None:
    from app.scheduler import stop_scheduler
    stop_scheduler()


@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "version": app.version}


@app.get("/skills")
async def list_skills() -> list[dict]:
    registry = get_registry()
    return [
        {"name": s.name, "category": s.category, "description": s.description}
        for s in registry.list_skills()
    ]


class AskRequest(BaseModel):
    question: str
    company_id: str


class AskResponse(BaseModel):
    answer: str
    sources: list[str] = []


async def _load_data_sources(company_id: str) -> list[dict]:
    """Load active data source connections for a company from Supabase."""
    from supabase import create_client
    client = create_client(settings.supabase_url, settings.supabase_service_role_key)
    response = client.table("data_source_connections").select("*").eq(
        "company_id", company_id
    ).eq("is_active", True).execute()
    return response.data or []


@app.post("/api/ask", response_model=AskResponse)
async def ask(body: AskRequest, user: CurrentUser) -> AskResponse:
    run_id = await start_analysis_run(body.company_id, body.question, trigger="api")

    data_sources = await _load_data_sources(body.company_id)

    try:
        result = await run_qa(
            question=body.question,
            company_id=body.company_id,
            data_sources=data_sources,
            user_id=user.get("sub", ""),
        )
        answer = result if isinstance(result, str) else str(result)
        if run_id:
            await complete_analysis_run(run_id, answer, status="completed")
    except Exception as exc:
        if run_id:
            await complete_analysis_run(run_id, "", status="failed", error=str(exc))
        raise

    source_names = [ds.get("provider", "unknown") for ds in data_sources]
    return AskResponse(answer=answer, sources=source_names)