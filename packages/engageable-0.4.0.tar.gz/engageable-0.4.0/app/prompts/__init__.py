# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Dynamic system prompt assembly for the Engageable agent."""

from app.prompts.builder import build_system_prompt, detect_mode

__all__ = ["build_system_prompt", "detect_mode"]