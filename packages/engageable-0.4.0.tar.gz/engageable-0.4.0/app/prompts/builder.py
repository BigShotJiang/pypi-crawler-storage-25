# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Assemble the system prompt from modular blocks and live state."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Literal

from app.prompts.blocks import (
    IDENTITY,
    IDENTITY_NO_PROJECT,
    TONALITY,
    GOAL_ONBOARDING,
    GOAL_CONVERSATIONAL,
    GOAL_PROACTIVE,
    GOAL_OUTBOUND,
    GOAL_PROACTIVE_INVESTIGATION,
    GUARDRAILS,
    TOOL_INSTRUCTIONS,
    STATE_DATA_SOURCES,
    STATE_NO_DATA_SOURCES,
    STATE_BUSINESS_PROFILE,
    STATE_NO_PROFILE,
    STATE_KNOWLEDGE_GATES,
    DATA_QUALITY_WARNINGS,
)
from engageable.skills.registry import get_registry

logger = logging.getLogger(__name__)

Mode = Literal["onboarding", "conversational", "proactive", "outbound", "proactive_investigation"]

# Path to connector knowledge base files
KNOWLEDGE_BASE_DIR = Path(__file__).parent.parent / "connectors" / "knowledge"

# Statuses where the full knowledge base is injected (agent needs it for exploration)
EXPLORING_STATUSES = {"authenticated", "exploring", "needs_input"}


def detect_mode(
    project: dict[str, Any] | None,
    connections: list[dict[str, Any]],
    recent_findings: list[dict[str, Any]] | None = None,
    is_new_session: bool = False,
) -> Mode:
    """Decide which agent mode to use based on current state."""
    if not project or not connections:
        return "onboarding"

    # If any connection still needs exploration, stay in onboarding
    needs_setup = any(
        c.get("status") in EXPLORING_STATUSES for c in connections
    )
    if needs_setup:
        return "onboarding"

    if is_new_session and recent_findings:
        return "proactive"

    return "conversational"


def _render_identity(project: dict[str, Any] | None) -> str:
    if project and project.get("name"):
        return IDENTITY.format(project_name=project["name"])
    return IDENTITY_NO_PROJECT


def _render_goal(
    mode: Mode,
    project: dict[str, Any] | None,
    connections: list[dict[str, Any]],
    recent_findings: list[dict[str, Any]] | None = None,
    user_email: str | None = None,
    user_name: str | None = None,
    **kwargs: Any,
) -> str:
    if mode == "onboarding":
        steps = []
        if not project or not project.get("name"):
            steps.append("- Tell you about their product (creates a project)")
        if not connections:
            steps.append("- Connect a data source (start with Google Analytics)")
        # Check if any connections need exploration
        needs_explore = any(
            c.get("status") in EXPLORING_STATUSES for c in connections
        )
        if needs_explore:
            steps.append("- Explore the newly connected data source (run introspection)")
        if not steps:
            steps.append("- Setup is mostly done — help them ask their first question")

        # Build user context hint for onboarding
        email_hint = ""
        name_hint = f"The user's name is {user_name}. Greet them by first name." if user_name else ""
        if user_email and not project or (project and not project.get("website_url")):
            domain = user_email.split("@")[-1] if "@" in user_email else ""
            generic_domains = {"gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com", "protonmail.com", "aol.com", "mail.com", "live.com"}
            if domain and domain not in generic_domains:
                email_hint = (
                    f"The user's email is {user_email}. If they haven't mentioned their "
                    f"website yet, you can ask if {domain} is their site — it's a natural "
                    f"shortcut to get started with website discovery."
                )
        email_hint = "\n".join(filter(None, [name_hint, email_hint]))

        return GOAL_ONBOARDING.format(
            onboarding_steps="\n".join(steps),
            user_email_hint=email_hint,
        )

    if mode == "proactive" and recent_findings:
        lines = []
        for f in recent_findings[:5]:
            severity = f.get("severity", "info").upper()
            summary = f.get("summary", "")
            lines.append(f"- {severity}: {summary}")
        return GOAL_PROACTIVE.format(recent_summary="\n".join(lines))

    if mode == "outbound":
        events_summary = kwargs.get("events_summary", "No pending events.")
        return GOAL_OUTBOUND.format(events_summary=events_summary)

    if mode == "proactive_investigation":
        memory_lines = []
        for m in (kwargs.get("memories") or [])[:15]:
            memory_lines.append(f"- [{m.get('category', 'general')}] {m.get('content', '')}")
        finding_lines = []
        for f in (recent_findings or [])[:5]:
            fid = str(f.get("id", ""))[:8]
            created = str(f.get("created_at", ""))[:10]
            severity = f.get("severity", "info").upper()
            summary = f.get("summary", "")
            prefix_parts = []
            if fid:
                prefix_parts.append(f"#{fid}")
            if created:
                prefix_parts.append(created)
            prefix = f" ({' | '.join(prefix_parts)})" if prefix_parts else ""
            finding_lines.append(f"- {severity}{prefix}: {summary}")
        return GOAL_PROACTIVE_INVESTIGATION.format(
            memory_context="\n".join(memory_lines) if memory_lines else "No memories yet.",
            recent_findings="\n".join(finding_lines) if finding_lines else "No recent findings.",
        )

    return GOAL_CONVERSATIONAL


def _load_knowledge_base(provider: str) -> str | None:
    """Load the LLM-optimized knowledge base for a connector."""
    kb_path = KNOWLEDGE_BASE_DIR / f"{provider}.md"
    if kb_path.exists():
        return kb_path.read_text()
    return None


def _render_connection_profile(conn: dict[str, Any]) -> str:
    """Render a compact profile summary for a ready connection."""
    provider = conn.get("provider", "unknown")
    display = conn.get("display_name") or provider
    profile = conn.get("profile") or {}
    config = conn.get("config") or {}

    lines = [f"### {display} ({provider}) — ACTIVE & READY"]

    if config.get("property_id"):
        lines.append(f"Property ID: {config['property_id']}")
    if profile.get("data_start_date"):
        lines.append(f"Data available since: {profile['data_start_date']}")
    if profile.get("active_users_30d"):
        lines.append(f"Active users (30d): ~{profile['active_users_30d']:,}")
    if profile.get("custom_events"):
        events = ", ".join(profile["custom_events"][:10])
        lines.append(f"Custom events: {events}")
    if profile.get("custom_dimensions"):
        dims = ", ".join(profile["custom_dimensions"][:10])
        lines.append(f"Custom dimensions: {dims}")
    if profile.get("timezone"):
        lines.append(f"Timezone: {profile['timezone']}")

    lines.append("→ Credentials are auto-injected. Call ga4_query, ga4_probe, etc. directly.")

    return "\n".join(lines)


def _render_exploring_connection(conn: dict[str, Any]) -> str:
    """Render instructions for a connection that needs exploration."""
    provider = conn.get("provider", "unknown")
    display = conn.get("display_name") or provider
    status = conn.get("status", "authenticated")
    config = conn.get("config") or {}

    lines = [f"### {display} ({provider}) — CONNECTED, {status.upper()}"]

    if config.get("property_id"):
        lines.append(f"Property ID: {config['property_id']}")

    lines.append("→ Credentials are auto-injected. You CAN query data right now.")

    if status == "authenticated":
        lines.append(
            f"\n{provider.upper()} is connected and working but hasn't been fully explored yet.\n"
            "When you have the opportunity (e.g. user asks a question or says hello), "
            "run the introspection sequence: list properties, probe for data, discover "
            "available metrics. Then use update_connection to save the profile and set "
            "status to 'ready'.\n"
            "In the meantime, you can already answer data questions using this source."
        )
    elif status == "needs_input":
        lines.append(
            "\nThis connection needs user input before it can be fully configured. "
            "Check the profile for what's needed and ask the user."
        )
    elif status == "exploring":
        lines.append(
            "\nExploration is in progress. Continue the introspection steps."
        )

    return "\n".join(lines)


def _render_data_sources(connections: list[dict[str, Any]]) -> str:
    """Render the data sources section with profiles and knowledge bases."""
    if not connections:
        return STATE_NO_DATA_SOURCES

    source_sections: list[str] = []
    knowledge_bases: list[str] = []

    for conn in connections:
        status = conn.get("status", "authenticated")
        provider = conn.get("provider", "unknown")

        if status == "ready":
            # Compact profile + error reference only
            source_sections.append(_render_connection_profile(conn))
        elif status == "failed":
            display = conn.get("display_name") or provider
            source_sections.append(
                f"### {display} ({provider}) — FAILED\n"
                "This connection has a credential or access problem. "
                "Suggest the user reconnect via the Sources page or use suggest_connection."
            )
        else:
            # Needs exploration — show instructions
            source_sections.append(_render_exploring_connection(conn))
            # Load full knowledge base for exploration
            kb = _load_knowledge_base(provider)
            if kb:
                knowledge_bases.append(kb)

    # Also load error reference for ready connections (they still need it)
    # For now, the error reference is part of the full KB, so we include
    # a note that it's available
    for conn in connections:
        if conn.get("status") == "ready":
            provider = conn.get("provider", "unknown")
            # Load just the error reference section from knowledge base
            kb = _load_knowledge_base(provider)
            if kb:
                # Extract just the error reference section
                error_ref = _extract_section(kb, "Error Reference")
                if error_ref:
                    knowledge_bases.append(
                        f"## {provider.upper()} Error Reference\n{error_ref}"
                    )

    # Build the final section
    parts = [STATE_DATA_SOURCES.format(sources_list="\n\n".join(source_sections))]
    if knowledge_bases:
        parts.append("\n\n---\n\n".join(knowledge_bases))

    return "\n\n".join(parts)


def _extract_section(markdown: str, section_name: str) -> str | None:
    """Extract a section from a markdown document by heading name."""
    lines = markdown.split("\n")
    in_section = False
    section_lines: list[str] = []
    section_level = 0

    for line in lines:
        if line.startswith("#") and section_name.lower() in line.lower():
            in_section = True
            section_level = len(line) - len(line.lstrip("#"))
            continue
        if in_section:
            # Stop at next heading of same or higher level
            if line.startswith("#"):
                heading_level = len(line) - len(line.lstrip("#"))
                if heading_level <= section_level:
                    break
            section_lines.append(line)

    return "\n".join(section_lines).strip() if section_lines else None


def _render_learned_notes(connections: list[dict[str, Any]]) -> str | None:
    """Render any learned notes from connections into a prompt section."""
    notes_sections: list[str] = []

    for conn in connections:
        learned = conn.get("learned") or {}
        notes = learned.get("notes", [])
        if not notes:
            continue

        provider = conn.get("provider", "unknown")
        display = conn.get("display_name") or provider
        note_lines = [f"### Learned notes for {display} ({provider})"]
        for note in notes[-10:]:  # Last 10 notes only
            text = note.get("text") or note.get("fact", "")
            if text:
                category = note.get("category", "")
                prefix = f"[{category}] " if category else ""
                note_lines.append(f"- {prefix}{text}")
        notes_sections.append("\n".join(note_lines))

    if not notes_sections:
        return None

    return "## Things learned about your data sources\n\n" + "\n\n".join(notes_sections)


def _render_knowledge_gates(profile_data: dict[str, Any] | None) -> str | None:
    """Render knowledge gate status — tells the agent what it can/can't do yet."""
    from app.models.business_profile import BusinessProfile, completeness_score, _is_filled
    from app.models.knowledge_gate import ACTION_REQUIREMENTS, FIELD_QUESTIONS

    if profile_data and profile_data.get("profile"):
        profile = BusinessProfile.model_validate(profile_data["profile"])
    else:
        profile = BusinessProfile()

    score = completeness_score(profile)
    lines = []

    for action, reqs in ACTION_REQUIREMENTS.items():
        if action == "answer_question":
            continue  # always allowed, skip

        required = reqs["required_fields"]
        threshold = reqs["threshold"]
        missing = [f for f in required if not _is_filled(profile, f)]

        if not missing and score >= threshold:
            status = "READY"
            detail = ""
        else:
            status = "BLOCKED"
            missing_labels = []
            for f in missing:
                q = FIELD_QUESTIONS.get(f, f)
                missing_labels.append(f"{f} — ask: \"{q}\"")
            detail = " Missing: " + "; ".join(missing_labels)

        action_label = action.replace(".", " ").replace("_", " ").title()
        lines.append(f"- {action_label}: **{status}**{detail}")

    # If everything is ready, don't clutter the prompt
    if all("READY" in line for line in lines):
        return None

    return STATE_KNOWLEDGE_GATES.format(gate_lines="\n".join(lines))


def _render_business_profile(profile_data: dict[str, Any] | None) -> str:
    """Render the business profile block for the system prompt."""
    if not profile_data or not profile_data.get("profile"):
        return STATE_NO_PROFILE

    from app.models.business_profile import BusinessProfile, completeness_score, missing_fields

    profile = BusinessProfile.model_validate(profile_data["profile"])
    score = completeness_score(profile)

    if score == 0:
        return STATE_NO_PROFILE

    lines = []
    if profile.business_type:
        model_str = f" ({profile.business_model})" if profile.business_model else ""
        audience_str = f", {profile.target_audience}" if profile.target_audience else ""
        lines.append(f"Type: {profile.business_type.upper()}{model_str}{audience_str}")
    if profile.north_star_metric:
        lines.append(f"North star: {profile.north_star_metric}")
    if profile.supporting_metrics:
        lines.append(f"Supporting metrics: {', '.join(profile.supporting_metrics)}")
    if profile.current_focus:
        lines.append(f"Current focus: {profile.current_focus}")
    if profile.primary_funnel:
        lines.append(f"Primary funnel: {' → '.join(profile.primary_funnel)}")
    if profile.platforms:
        lines.append(f"Platforms: {', '.join(profile.platforms)}")
    if profile.known_issues:
        lines.append(f"Known issues: {'; '.join(profile.known_issues)}")
    if profile.seasonality:
        lines.append(f"Seasonality: {'; '.join(profile.seasonality)}")
    if profile.team_context:
        lines.append(f"Team: {profile.team_context}")
    if profile.reporting_cadence:
        lines.append(f"Reporting: {profile.reporting_cadence}")

    missing = missing_fields(profile)
    missing_hint = f" (missing: {', '.join(missing)})" if missing else ""

    return STATE_BUSINESS_PROFILE.format(
        profile_summary="\n".join(lines) if lines else "Minimal profile — still learning.",
        completeness_pct=round(score * 100),
        missing_hint=missing_hint,
    )


def _render_tools() -> str:
    registry = get_registry()
    readonly_lines = []
    for skill in registry.list_skills():
        readonly_lines.append(f"- {skill.name}: {skill.description}")
    readonly_lines.append("- list_monitors: List all configured monitors for this project")
    readonly_lines.append("- list_reports: List all generated reports for this project")
    readonly_lines.append("- list_channels: List all delivery channels (Slack, email, webhook)")
    readonly_lines.append("- list_templates: List available KPI dashboard templates")
    readonly_lines.append("- list_dashboards: List the user's current KPI dashboards")
    readonly_lines.append("- validate_dashboard: Check which dashboard slots have live data (call after creating a dashboard)")

    # Write actions we support via propose_action
    write_actions = [
        "- project.create: Create a new project",
        "- project.update: Update project details",
        "- dashboard.create: Create a KPI dashboard from a template",
        "- dashboard.update: Update a dashboard (bindings, label, active state)",
        "- monitor.create: Create a metric monitor",
        "- monitor.update: Update a monitor's config",
        "- monitor.delete: Delete a monitor",
        "- report.generate: Generate a report with charts and narrative",
        "- report.delete: Delete a report",
        "- channel.create: Create a delivery channel (Slack, email, webhook)",
        "- channel.delete: Delete a delivery channel",
    ]

    return TOOL_INSTRUCTIONS.format(
        readonly_tools="\n".join(readonly_lines) if readonly_lines else "- (none connected yet)",
        write_actions="\n".join(write_actions),
    )


def _render_memories(memories: list[dict[str, Any]]) -> str | None:
    """Render saved agent memories into a prompt section."""
    if not memories:
        return None

    # Group by category
    by_cat: dict[str, list[str]] = {}
    for m in memories:
        cat = m.get("category", "general")
        by_cat.setdefault(cat, []).append(m.get("content", ""))

    cat_labels = {
        "goal": "Business Goals & KPIs",
        "filter": "Filters & Exclusions",
        "context": "Domain Context",
        "general": "Other Notes",
    }

    lines = ["## Things you know about this business"]
    for cat, items in by_cat.items():
        label = cat_labels.get(cat, cat.title())
        lines.append(f"\n### {label}")
        for item in items:
            lines.append(f"- {item}")

    lines.append(
        "\nUse these facts when answering questions. If any are outdated, "
        "use forget_memory to remove them and save_memory to add corrections."
    )

    return "\n".join(lines)


def build_system_prompt(
    project: dict[str, Any] | None = None,
    connections: list[dict[str, Any]] | None = None,
    recent_findings: list[dict[str, Any]] | None = None,
    is_new_session: bool = False,
    memories: list[dict[str, Any]] | None = None,
    user_email: str | None = None,
    user_name: str | None = None,
    mode_override: Mode | None = None,
    data_quality_results: dict[str, Any] | None = None,
    business_profile: dict[str, Any] | None = None,
    **kwargs: Any,
) -> str:
    """Assemble the full system prompt from live state.

    Each block is a separate concern. The prompt stays grounded in reality
    because it only mentions what actually exists right now.
    """
    connections = connections or []
    recent_findings = recent_findings or []
    memories = memories or []

    mode = mode_override or detect_mode(project, connections, recent_findings, is_new_session)

    sections = [
        _render_identity(project),
        TONALITY,
        _render_goal(mode, project, connections, recent_findings, user_email=user_email, user_name=user_name, memories=memories, **kwargs),
        _render_business_profile(business_profile),
        _render_data_sources(connections),
    ]

    # Outbound mode is pure composition — no tools are available, so skip the
    # tools section entirely to prevent the LLM from hallucinating tool calls.
    if mode != "outbound":
        sections.append(_render_tools())

        # Show knowledge gate status so agent knows what it can/can't do
        gate_block = _render_knowledge_gates(business_profile)
        if gate_block:
            sections.append(gate_block)

    sections.append(GUARDRAILS)

    # Add memories if any exist (before guardrails)
    rendered_memories = _render_memories(memories)
    if rendered_memories:
        sections.insert(-1, rendered_memories)

    # Add learned notes if any exist (before guardrails)
    learned = _render_learned_notes(connections)
    if learned:
        sections.insert(-1, learned)

    # Add data quality warnings if any issues were found (before guardrails)
    if data_quality_results and data_quality_results.get("overall_status") != "pass":
        quality_lines = []
        for check in data_quality_results.get("checks", []):
            status = check.get("status", "pass").upper()
            connector = check.get("connector", "unknown")
            detail = check.get("detail", "")
            check_name = check.get("check", "unknown")
            quality_lines.append(f"- [{status}] {connector}/{check_name}: {detail}")
        if quality_lines:
            rendered_quality = DATA_QUALITY_WARNINGS.format(
                quality_checks="\n".join(quality_lines),
            )
            sections.insert(-1, rendered_quality)

    return "\n\n".join(sections)