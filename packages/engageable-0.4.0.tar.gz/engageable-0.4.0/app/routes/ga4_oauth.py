# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""GA4 OAuth flow — authorize, callback, and property listing."""

from __future__ import annotations

import json
import logging
import secrets
from datetime import datetime, timezone
from urllib.parse import quote, urlencode

import httpx
from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from supabase import create_client

from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/connections/ga4", tags=["ga4"])

# Google OAuth endpoints
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GA4_ADMIN_API = "https://analyticsadmin.googleapis.com/v1beta"

# Scopes needed: read-only analytics + account listing
SCOPES = [
    "https://www.googleapis.com/auth/analytics.readonly",
]

# In-memory state store for CSRF protection (maps state → {company_id, user_id})
# In production, use Redis or a DB table
_pending_states: dict[str, dict] = {}


@router.get("/authorize")
async def authorize(
    company_id: str = Query(...),
    user_id: str = Query(...),
) -> RedirectResponse:
    """Start the Google OAuth flow. Redirects the user to Google's consent screen."""
    settings = get_settings()

    if not settings.google_client_id:
        raise HTTPException(status_code=500, detail="Google OAuth not configured")

    state = secrets.token_urlsafe(32)
    _pending_states[state] = {"company_id": company_id, "user_id": user_id}

    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "response_type": "code",
        "scope": " ".join(SCOPES),
        "access_type": "offline",
        "prompt": "consent",
        "state": state,
    }
    return RedirectResponse(f"{GOOGLE_AUTH_URL}?{urlencode(params)}")


@router.get("/callback")
async def callback(request: Request) -> RedirectResponse:
    """Handle Google OAuth callback. Exchanges code for tokens, stores connection, redirects to frontend."""
    settings = get_settings()
    params = request.query_params

    try:
        error = params.get("error")
        code = params.get("code")
        state = params.get("state")

        # Handle OAuth errors
        if error:
            logger.warning("GA4 OAuth error: %s", error)
            return RedirectResponse(
                f"{settings.frontend_url}/dashboard?error={error}"
            )

        if not state or state not in _pending_states:
            logger.warning("Invalid or expired state: %s (known states: %d)", state, len(_pending_states))
            return RedirectResponse(
                f"{settings.frontend_url}/dashboard?error=invalid_state"
            )

        pending = _pending_states.pop(state)
        company_id = pending["company_id"]
        user_id = pending["user_id"]

        if not code:
            return RedirectResponse(
                f"{settings.frontend_url}/dashboard?error=no_code"
            )

        # Exchange authorization code for tokens
        async with httpx.AsyncClient() as client:
            token_resp = await client.post(
                GOOGLE_TOKEN_URL,
                data={
                    "code": code,
                    "client_id": settings.google_client_id,
                    "client_secret": settings.google_client_secret,
                    "redirect_uri": settings.google_redirect_uri,
                    "grant_type": "authorization_code",
                },
            )

        if token_resp.status_code != 200:
            logger.error("Token exchange failed: %s", token_resp.text)
            return RedirectResponse(
                f"{settings.frontend_url}/dashboard?error=token_exchange_failed"
            )

        tokens = token_resp.json()
        access_token = tokens["access_token"]
        refresh_token = tokens.get("refresh_token")

        # Fetch GA4 account summaries to find property name
        property_name = None
        property_id = None
        async with httpx.AsyncClient() as client:
            accounts_resp = await client.get(
                f"{GA4_ADMIN_API}/accountSummaries",
                headers={"Authorization": f"Bearer {access_token}"},
            )
        if accounts_resp.status_code == 200:
            summaries = accounts_resp.json()
            for account in summaries.get("accountSummaries", []):
                for prop in account.get("propertySummaries", []):
                    property_id = prop["property"].replace("properties/", "")
                    property_name = prop.get("displayName", f"GA4 Property {property_id}")
                    break
                if property_id:
                    break
        else:
            logger.error("GA4 Admin API failed (%d): %s", accounts_resp.status_code, accounts_resp.text)

        if not property_id:
            logger.warning("No GA4 properties found for user %s", user_id)
            return RedirectResponse(
                f"{settings.frontend_url}/dashboard?error=no_properties"
            )

        # Store connection in Supabase using service role (bypasses RLS)
        sb = create_client(settings.supabase_url, settings.supabase_service_role_key)

        existing = sb.table("data_source_connections").select("id").eq(
            "company_id", company_id
        ).eq("provider", "ga4").execute()

        credentials = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": tokens.get("token_type", "Bearer"),
            "auth_type": "oauth",
        }

        config = {
            "property_id": property_id,
        }

        now = datetime.now(timezone.utc).isoformat()

        if existing.data:
            sb.table("data_source_connections").update({
                "credentials": credentials,
                "config": config,
                "display_name": property_name,
                "is_active": True,
                "status": "authenticated",
                "validation_error": "",
                "last_validated_at": now,
            }).eq("id", existing.data[0]["id"]).execute()
        else:
            sb.table("data_source_connections").insert({
                "company_id": company_id,
                "provider": "ga4",
                "display_name": property_name,
                "credentials": credentials,
                "config": config,
                "is_active": True,
                "status": "authenticated",
                "last_validated_at": now,
            }).execute()

        return RedirectResponse(
            f"{settings.frontend_url}/dashboard?connected=ga4&property={quote(property_name or '')}"
        )

    except Exception as exc:
        logger.exception("GA4 OAuth callback failed")
        return RedirectResponse(
            f"{settings.frontend_url}/dashboard?error=server_error&detail={quote(str(exc))}"
        )