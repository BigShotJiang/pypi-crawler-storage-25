# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Admin endpoints — super-admin only. User management, usage logs."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.auth import CurrentUser
from app.db import get_supabase as _get_supabase

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin", tags=["admin"])


# Cache super-admin checks per user_id for the lifetime of the process.
# Safe because role changes are rare and a restart clears the cache.
_super_admin_cache: set[str] = set()


def _require_super_admin(user: dict):
    """Check that the caller is a super-admin. Raises 403 if not."""
    user_id = user.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if user_id in _super_admin_cache:
        return
    sb = _get_supabase()
    result = sb.table("user_profiles").select("role").eq("id", user_id).limit(1).execute()
    if not result.data or result.data[0].get("role") != "super-admin":
        raise HTTPException(status_code=403, detail="Super-admin access required")
    _super_admin_cache.add(user_id)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

@router.get("/users")
async def list_users(user: CurrentUser):
    """List all users across all companies."""
    _require_super_admin(user)
    sb = _get_supabase()
    result = sb.table("user_profiles").select(
        "id, email, display_name, role, company_id, is_active, created_at, updated_at"
    ).order("created_at", desc=True).execute()

    # Fetch company names for display
    companies = {}
    if result.data:
        company_ids = list({r["company_id"] for r in result.data if r.get("company_id")})
        if company_ids:
            comp_result = sb.table("companies").select("id, name").in_("id", company_ids).execute()
            companies = {c["id"]: c["name"] for c in (comp_result.data or [])}

    users = []
    for row in (result.data or []):
        row["company_name"] = companies.get(row.get("company_id"))
        users.append(row)

    return users


class UserUpdate(BaseModel):
    is_active: bool | None = None
    role: str | None = None
    company_id: str | None = None


class InviteUserRequest(BaseModel):
    email: str
    company_id: str
    role: str = "viewer"
    display_name: str | None = None


@router.patch("/users/{user_id}")
async def update_user(user_id: str, body: UserUpdate, user: CurrentUser):
    """Update a user's active status, role, or company."""
    _require_super_admin(user)

    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    sb = _get_supabase()
    result = sb.table("user_profiles").update(update_data).eq("id", user_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="User not found")
    return result.data[0]


@router.post("/users/invite")
async def invite_user(body: InviteUserRequest, user: CurrentUser):
    """Invite a new user: create Supabase auth user, profile, and send invite email."""
    _require_super_admin(user)
    sb = _get_supabase()

    # Check if user already exists
    existing = sb.table("user_profiles").select("id").eq("email", body.email).limit(1).execute()
    if existing.data:
        raise HTTPException(status_code=409, detail="User with this email already exists")

    # Get company name for the email
    company = sb.table("companies").select("name").eq("id", body.company_id).limit(1).execute()
    if not company.data:
        raise HTTPException(status_code=404, detail="Company not found")
    company_name = company.data[0]["name"]

    # Get inviter display name
    inviter_id = user.get("sub")
    inviter_profile = sb.table("user_profiles").select("display_name, email").eq("id", inviter_id).limit(1).execute()
    inviter_name = None
    if inviter_profile.data:
        inviter_name = inviter_profile.data[0].get("display_name") or inviter_profile.data[0].get("email")

    # Create auth user via Supabase Admin API (same pattern as udda-mono admin POST)
    auth_resp = sb.auth.admin.create_user({
        "email": body.email,
        "email_confirm": True,
        "user_metadata": {
            "display_name": body.display_name or body.email.split("@")[0],
            "role": body.role,
        },
    })
    new_user_id = auth_resp.user.id if auth_resp.user else None

    if not new_user_id:
        raise HTTPException(status_code=500, detail="Failed to create auth user")

    # Assign company (handle_new_user trigger creates user_profiles row)
    sb.table("user_profiles").update({
        "company_id": body.company_id,
        "role": body.role,
    }).eq("id", str(new_user_id)).execute()

    # Check template send_mode before sending
    tpl_row = sb.table("email_templates").select("send_mode").eq("slug", "user-invite").limit(1).execute()
    send_mode = tpl_row.data[0]["send_mode"] if tpl_row.data else "always_send"

    from app.config import get_settings
    settings = get_settings()
    login_url = f"{settings.frontend_url}/login"

    resend_message_id = None
    email_error = None
    email_skipped = send_mode == "dont_send"

    if not email_skipped:
        try:
            from app.output.invite_email import send_invite_email
            result = await send_invite_email(
                to_email=body.email,
                inviter_name=inviter_name,
                company_name=company_name,
                login_url=login_url,
            )
            resend_message_id = result.get("id")
        except Exception as exc:
            email_error = str(exc)[:500]
            logger.exception("Failed to send invite email to %s", body.email)

    # Log the invitation
    status = "skipped" if email_skipped else ("sent" if resend_message_id else "email_failed")
    sb.table("invite_log").insert({
        "email": body.email,
        "user_id": str(new_user_id),
        "invited_by": inviter_id,
        "company_id": body.company_id,
        "resend_message_id": resend_message_id,
        "status": status,
    }).execute()

    return {
        "user_id": str(new_user_id),
        "email": body.email,
        "company_name": company_name,
        "email_sent": resend_message_id is not None,
        "email_skipped": email_skipped,
        "email_error": email_error,
    }


@router.get("/invite-log")
async def list_invite_log(user: CurrentUser, limit: int = 50):
    """Recent user invitations (transactional email audit)."""
    _require_super_admin(user)
    sb = _get_supabase()
    lim = min(limit, 100)
    result = (
        sb.table("invite_log")
        .select("id, email, user_id, invited_by, company_id, resend_message_id, status, created_at")
        .order("created_at", desc=True)
        .limit(lim)
        .execute()
    )
    rows: list[dict[str, Any]] = list(result.data or [])
    cids = list({r["company_id"] for r in rows if r.get("company_id")})
    names: dict[str, str] = {}
    if cids:
        cr = sb.table("companies").select("id, name").in_("id", cids).execute()
        for c in cr.data or []:
            names[str(c["id"])] = c["name"]
    for row in rows:
        cid = row.get("company_id")
        row["company_name"] = names.get(str(cid)) if cid else None
    return rows


# ---------------------------------------------------------------------------
# Email templates — CRUD + preview
# ---------------------------------------------------------------------------

@router.get("/email-templates")
async def list_email_templates(user: CurrentUser):
    """List all email templates."""
    _require_super_admin(user)
    sb = _get_supabase()
    result = sb.table("email_templates").select("*").order("slug").execute()
    return result.data or []


@router.get("/email-templates/{slug}")
async def get_email_template(slug: str, user: CurrentUser):
    """Get a single email template by slug."""
    _require_super_admin(user)
    sb = _get_supabase()
    result = sb.table("email_templates").select("*").eq("slug", slug).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Template not found")
    return result.data[0]


class EmailTemplateUpdate(BaseModel):
    subject: str | None = None
    body_html: str | None = None
    cta_text: str | None = None
    cta_url: str | None = None
    send_mode: str | None = None


@router.put("/email-templates/{slug}")
async def update_email_template(slug: str, body: EmailTemplateUpdate, user: CurrentUser):
    """Update an email template's editable fields."""
    _require_super_admin(user)
    sb = _get_supabase()

    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = sb.table("email_templates").update(update_data).eq("slug", slug).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Template not found")
    return result.data[0]


@router.post("/email-templates/{slug}/preview")
async def preview_email_template(slug: str, user: CurrentUser):
    """Render the email template with sample data and return the HTML."""
    _require_super_admin(user)
    sb = _get_supabase()

    tpl = sb.table("email_templates").select("*").eq("slug", slug).limit(1).execute()
    if not tpl.data:
        raise HTTPException(status_code=404, detail="Template not found")
    template = tpl.data[0]

    from app.output.invite_email import render_invite_html
    html = render_invite_html(
        user_email="jane@example.com",
        inviter_name="Per",
        company_name="Acme Corp",
        login_url="https://www.engageable.tech/login",
        template_overrides=template,
    )
    return {"html": html, "subject": template["subject"]}


# ---------------------------------------------------------------------------
# User detail (for admin user page)
# ---------------------------------------------------------------------------

@router.get("/users/{user_id}/detail")
async def get_user_detail(user_id: str, user: CurrentUser):
    """Get comprehensive user detail including connections, monitors, findings, sendouts."""
    _require_super_admin(user)
    sb = _get_supabase()

    # User profile
    profile_result = sb.table("user_profiles").select(
        "id, email, display_name, role, company_id, is_active, created_at, updated_at"
    ).eq("id", user_id).limit(1).execute()

    if not profile_result.data:
        raise HTTPException(status_code=404, detail="User not found")

    profile = profile_result.data[0]
    company_id = profile.get("company_id")

    # Company name
    company_name = None
    if company_id:
        comp_result = sb.table("companies").select("name").eq("id", company_id).limit(1).execute()
        if comp_result.data:
            company_name = comp_result.data[0]["name"]

    # Connections (scoped to company)
    connections: list[dict[str, Any]] = []
    if company_id:
        conn_result = sb.table("data_source_connections").select(
            "id, provider, is_active, status, created_at"
        ).eq("company_id", company_id).order("created_at", desc=True).execute()
        connections = conn_result.data or []

    # Monitors (scoped to company)
    monitors: list[dict[str, Any]] = []
    if company_id:
        mon_result = sb.table("monitors").select(
            "id, name, metric, schedule, is_active, last_status, last_run_at"
        ).eq("company_id", company_id).order("created_at", desc=True).execute()
        monitors = mon_result.data or []

    # Findings (scoped to company, recent 20)
    findings: list[dict[str, Any]] = []
    if company_id:
        find_result = sb.table("findings").select(
            "id, summary, severity, created_at, metrics"
        ).eq("company_id", company_id).order("created_at", desc=True).limit(20).execute()
        findings = find_result.data or []

    # Outbound events (scoped to company, recent 30)
    outbound_events: list[dict[str, Any]] = []
    if company_id:
        out_result = sb.table("outbound_events").select(
            "id, event_type, severity, status, composed_message, created_at, sent_at"
        ).eq("company_id", company_id).order("created_at", desc=True).limit(30).execute()
        outbound_events = out_result.data or []

    # Chat stats (message count + last message)
    chat_stats = {"total_messages": 0, "last_message_at": None}
    if company_id:
        chat_result = sb.table("chat_messages").select(
            "id, created_at"
        ).eq("company_id", company_id).order("created_at", desc=True).limit(1).execute()
        # Count total — Supabase doesn't do COUNT easily, so use a reasonable approach
        count_result = sb.table("chat_messages").select(
            "id", count="exact"
        ).eq("company_id", company_id).execute()
        chat_stats["total_messages"] = count_result.count or 0
        if chat_result.data:
            chat_stats["last_message_at"] = chat_result.data[0]["created_at"]

    # Evaluation stats
    eval_stats = {"total": 0, "average_score": None, "by_verdict": {"good": 0, "bad": 0, "unclear": 0, "unreviewed": 0}}
    if company_id:
        eval_result = sb.table("evaluations").select("quality_score, admin_verdict").eq(
            "company_id", company_id
        ).execute()
        evals = eval_result.data or []
        eval_stats["total"] = len(evals)
        scores = [e["quality_score"] for e in evals if e.get("quality_score") is not None]
        if scores:
            eval_stats["average_score"] = round(sum(scores) / len(scores), 4)
        for e in evals:
            verdict = e.get("admin_verdict")
            if verdict in ("good", "bad", "unclear"):
                eval_stats["by_verdict"][verdict] += 1
            else:
                eval_stats["by_verdict"]["unreviewed"] += 1

    return {
        **profile,
        "company_name": company_name,
        "connections": connections,
        "monitors": monitors,
        "findings": findings,
        "outbound_events": outbound_events,
        "chat_stats": chat_stats,
        "eval_stats": eval_stats,
    }


@router.get("/users/{user_id}/chat")
async def get_user_chat(
    user_id: str,
    user: CurrentUser,
    company_id: str | None = None,
    limit: int = 50,
):
    """Get chat history for a user's company (for admin impersonation view)."""
    _require_super_admin(user)
    sb = _get_supabase()

    # Resolve company_id from user if not provided
    if not company_id:
        profile = sb.table("user_profiles").select("company_id").eq("id", user_id).limit(1).execute()
        if profile.data and profile.data[0].get("company_id"):
            company_id = profile.data[0]["company_id"]

    if not company_id:
        return []

    result = sb.table("chat_messages").select(
        "id, role, content, metadata, created_at"
    ).eq("company_id", company_id).order("created_at", desc=True).limit(limit).execute()

    # Return in chronological order (oldest first)
    messages = result.data or []
    messages.reverse()
    return messages


# ---------------------------------------------------------------------------
# Log (LLM usage + activity)
# ---------------------------------------------------------------------------

@router.get("/log")
async def get_log(
    user: CurrentUser,
    limit: int = 100,
    company_id: str | None = None,
    user_id: str | None = None,
):
    """Get admin activity log.

    Returns a merged timeline of:
    - llm_usage rows
    - cron_runs rows (system-level)
    """
    _require_super_admin(user)
    sb = _get_supabase()

    query = sb.table("llm_usage").select("*").order("created_at", desc=True).limit(limit)
    if company_id:
        query = query.eq("company_id", company_id)
    if user_id:
        query = query.eq("user_id", user_id)

    result = query.execute()

    # Enrich LLM rows with user emails and company names
    llm_rows: list[dict[str, Any]] = list(result.data or [])
    if llm_rows:
        uids = list({r["user_id"] for r in llm_rows if r.get("user_id")})
        cids = list({r["company_id"] for r in llm_rows if r.get("company_id")})

        users_map = {}
        if uids:
            u_result = sb.table("user_profiles").select("id, email, display_name").in_("id", uids).execute()
            users_map = {u["id"]: u for u in (u_result.data or [])}

        companies_map = {}
        if cids:
            c_result = sb.table("companies").select("id, name").in_("id", cids).execute()
            companies_map = {c["id"]: c["name"] for c in (c_result.data or [])}

        for row in llm_rows:
            u = users_map.get(row.get("user_id"), {})
            row["user_email"] = u.get("email")
            row["user_display_name"] = u.get("display_name")
            row["company_name"] = companies_map.get(row.get("company_id"))
            row["entry_type"] = "llm_usage"

    # Include system cron jobs in global and per-user timelines.
    include_cron = user_id is not None or (company_id is None and user_id is None)
    cron_rows: list[dict[str, Any]] = []
    if include_cron:
        cron_result = (
            sb.table("cron_runs")
            .select("id, job_type, status, trigger, started_at, duration_ms, error, result")
            .order("started_at", desc=True)
            .limit(limit)
            .execute()
        )
        for row in (cron_result.data or []):
            cron_rows.append({
                "id": f"cron-{row['id']}",
                "entry_type": "cron_run",
                "created_at": row.get("started_at"),
                "trigger": row.get("trigger"),
                "job_type": row.get("job_type"),
                "status": row.get("status"),
                "duration_ms": row.get("duration_ms"),
                "error": row.get("error"),
                "result": row.get("result"),
                "user_id": None,
                "user_email": "System",
                "user_display_name": "System Cron",
                "company_id": None,
                "company_name": None,
            })

    merged = llm_rows + cron_rows
    merged.sort(key=lambda r: r.get("created_at") or "", reverse=True)
    return merged[:limit]


@router.get("/log/summary")
async def get_log_summary(user: CurrentUser):
    """Get aggregate usage stats."""
    _require_super_admin(user)
    sb = _get_supabase()

    # Total usage
    result = sb.table("llm_usage").select("*").execute()
    rows = result.data or []

    total_tokens = sum(r.get("total_tokens", 0) for r in rows)
    total_cost = sum(float(r.get("estimated_cost_usd", 0)) for r in rows)
    total_calls = len(rows)

    # Per-company breakdown
    by_company: dict[str, dict] = {}
    for r in rows:
        cid = r.get("company_id", "unknown")
        if cid not in by_company:
            by_company[cid] = {"tokens": 0, "cost": 0.0, "calls": 0}
        by_company[cid]["tokens"] += r.get("total_tokens", 0)
        by_company[cid]["cost"] += float(r.get("estimated_cost_usd", 0))
        by_company[cid]["calls"] += 1

    return {
        "total_tokens": total_tokens,
        "total_cost_usd": round(total_cost, 4),
        "total_calls": total_calls,
        "by_company": by_company,
    }


# ---------------------------------------------------------------------------
# Companies overview
# ---------------------------------------------------------------------------

@router.get("/companies")
async def list_companies(user: CurrentUser):
    """List all companies with user counts."""
    _require_super_admin(user)
    sb = _get_supabase()

    companies = sb.table("companies").select("*").order("created_at", desc=True).execute()
    users = sb.table("user_profiles").select("company_id").execute()

    # Count users per company
    user_counts: dict[str, int] = {}
    for u in (users.data or []):
        cid = u.get("company_id")
        if cid:
            user_counts[cid] = user_counts.get(cid, 0) + 1

    result = []
    for c in (companies.data or []):
        c["user_count"] = user_counts.get(c["id"], 0)
        result.append(c)

    return result


# ---------------------------------------------------------------------------
# Cron job history and manual trigger
# ---------------------------------------------------------------------------

@router.get("/cron/history")
async def get_cron_history(
    user: CurrentUser,
    job_type: str | None = None,
    limit: int = 50,
):
    """Get cron job run history with results."""
    _require_super_admin(user)
    sb = _get_supabase()

    query = sb.table("cron_runs").select("*").order("started_at", desc=True).limit(limit)
    if job_type:
        query = query.eq("job_type", job_type)

    result = query.execute()
    return result.data or []


class CronTriggerRequest(BaseModel):
    job_type: str  # "monitors", "outbound", "proactive", "evaluate", or "all"


@router.post("/cron/trigger")
async def trigger_cron(body: CronTriggerRequest, user: CurrentUser):
    """Manually trigger a cron job (or all jobs in sequence).

    Records the run in cron_runs with trigger='manual'.
    """
    _require_super_admin(user)
    sb = _get_supabase()

    from datetime import datetime, timezone
    from app.services.cron_jobs import execute_cron_job

    job_types = (
        ["monitors", "proactive", "outbound", "evaluate", "engagement", "engagement_digest"]
        if body.job_type == "all"
        else [body.job_type]
    )

    results = []
    for jt in job_types:
        # Create run record
        started_at = datetime.now(timezone.utc)
        run_row = sb.table("cron_runs").insert({
            "job_type": jt,
            "status": "running",
            "trigger": "manual",
            "started_at": started_at.isoformat(),
        }).execute()
        run_id = run_row.data[0]["id"] if run_row.data else None

        try:
            run_result = await execute_cron_job(jt)
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            if run_id:
                sb.table("cron_runs").update({
                    "status": "success",
                    "completed_at": completed_at.isoformat(),
                    "duration_ms": duration_ms,
                    "result": run_result,
                }).eq("id", run_id).execute()

            results.append({"job_type": jt, "status": "success", "result": run_result})

        except Exception as exc:
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)
            error_msg = str(exc)[:500]

            if run_id:
                sb.table("cron_runs").update({
                    "status": "error",
                    "completed_at": completed_at.isoformat(),
                    "duration_ms": duration_ms,
                    "error": error_msg,
                }).eq("id", run_id).execute()

            results.append({"job_type": jt, "status": "error", "error": error_msg})
            logger.exception("Manual cron trigger failed for %s", jt)

    return {"triggered": len(job_types), "results": results}


# ---------------------------------------------------------------------------
# Detected tools (analytics tracking discovery)
# ---------------------------------------------------------------------------

@router.get("/detected-tools")
async def list_detected_tools(
    user: CurrentUser,
    company_id: str | None = None,
):
    """List all detected analytics tools across companies.

    Each entry shows the provider, confidence, how many times it was detected,
    evidence (URLs + matched patterns + snippets), and whether it's connected.
    """
    _require_super_admin(user)
    sb = _get_supabase()

    query = sb.table("detected_tools").select(
        "*, companies(name)"
    ).order("last_seen_at", desc=True)
    if company_id:
        query = query.eq("company_id", company_id)

    result = query.execute()

    # Flatten company name
    rows = result.data or []
    for row in rows:
        company = row.pop("companies", None)
        row["company_name"] = company.get("name") if company else None

    return rows


@router.get("/site-scans")
async def list_site_scans(
    user: CurrentUser,
    company_id: str | None = None,
    limit: int = 50,
):
    """List recent site scans with results."""
    _require_super_admin(user)
    sb = _get_supabase()

    query = sb.table("site_scans").select("*").order("created_at", desc=True).limit(limit)
    if company_id:
        query = query.eq("company_id", company_id)

    result = query.execute()
    return result.data or []


class RescanRequest(BaseModel):
    company_id: str
    url: str | None = None


@router.post("/detected-tools/rescan")
async def rescan_company(body: RescanRequest, user: CurrentUser):
    """Re-scan a company's website to refresh detected tools."""
    _require_super_admin(user)
    sb = _get_supabase()

    # Get company website URL
    url = body.url
    if not url:
        company = sb.table("companies").select("website_url").eq(
            "id", body.company_id
        ).limit(1).execute()
        if company.data and company.data[0].get("website_url"):
            url = company.data[0]["website_url"]

    if not url:
        raise HTTPException(status_code=400, detail="No URL provided and company has no website_url set")

    # Run the discovery skill
    from engageable.skills.registry import get_registry
    registry = get_registry()
    skill = registry.get_skill("website_discover")
    if not skill:
        raise HTTPException(status_code=500, detail="Website discovery skill not available")

    result = await skill.execute({"url": url})
    if not result.success:
        raise HTTPException(status_code=502, detail=f"Scan failed: {result.error}")

    # Persist results
    from app.routes.discover import _upsert_detected_tool
    for tool in result.data.get("detected", []):
        _upsert_detected_tool(sb, body.company_id, url, tool)

    # Record the scan
    user_id = user.get("sub")
    sb.table("site_scans").insert({
        "company_id": body.company_id,
        "url": result.data["url"],
        "page_title": result.data.get("page_title", ""),
        "tools_found": len(result.data.get("detected", [])),
        "scan_time_ms": result.data.get("scan_time_ms"),
        "triggered_by": user_id,
    }).execute()

    return result.data


# ---------------------------------------------------------------------------
# Backfill embeddings for agent_memory
# ---------------------------------------------------------------------------

@router.post("/backfill-embeddings")
async def backfill_embeddings(user: CurrentUser, company_id: str | None = None):
    """Generate embeddings for agent_memory rows that don't have them."""
    _require_super_admin(user)
    from app.memory.retrieval import backfill_embeddings as do_backfill
    result = await do_backfill(company_id)
    return result


# ---------------------------------------------------------------------------
# Engagement rules and sends
# ---------------------------------------------------------------------------

@router.get("/engagement/rules")
async def list_engagement_rules(user: CurrentUser):
    """List all engagement rules with send counts."""
    _require_super_admin(user)
    sb = _get_supabase()

    rules = sb.table("engagement_rules").select("*").order("slug").execute()
    rows: list[dict[str, Any]] = list(rules.data or [])

    # Attach send counts per rule
    for rule in rows:
        sends = sb.table("engagement_sends").select("id, status", count="exact").eq(
            "rule_id", rule["id"]
        ).execute()
        total = sends.count or 0
        sent = len([s for s in (sends.data or []) if s.get("status") == "sent"])
        rule["send_count"] = total
        rule["sent_count"] = sent

    return rows


class EngagementRuleUpdate(BaseModel):
    enabled: bool | None = None
    composer_prompt: str | None = None
    cooldown_hours: int | None = None
    cadence: str | None = None


@router.put("/engagement/rules/{slug}")
async def update_engagement_rule(slug: str, body: EngagementRuleUpdate, user: CurrentUser):
    """Update an engagement rule."""
    _require_super_admin(user)
    sb = _get_supabase()

    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = sb.table("engagement_rules").update(update_data).eq("slug", slug).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Rule not found")
    return result.data[0]


@router.get("/engagement/sends")
async def list_engagement_sends(
    user: CurrentUser,
    rule_slug: str | None = None,
    company_id: str | None = None,
    limit: int = 50,
):
    """List recent engagement sends with open/click data."""
    _require_super_admin(user)
    sb = _get_supabase()

    query = sb.table("engagement_sends").select(
        "*, engagement_rules(slug, name)"
    ).order("created_at", desc=True).limit(min(limit, 200))

    if company_id:
        query = query.eq("company_id", company_id)

    result = query.execute()
    rows: list[dict[str, Any]] = list(result.data or [])

    # Filter by rule slug if requested (post-query since it's a join)
    if rule_slug:
        rows = [r for r in rows if (r.get("engagement_rules") or {}).get("slug") == rule_slug]

    # Enrich with user email
    user_ids = list({r["user_id"] for r in rows if r.get("user_id")})
    users_map: dict[str, str] = {}
    if user_ids:
        users = sb.table("user_profiles").select("id, email").in_("id", user_ids).execute()
        users_map = {u["id"]: u.get("email", "") for u in (users.data or [])}

    for row in rows:
        row["user_email"] = users_map.get(row.get("user_id", ""))
        rule = row.pop("engagement_rules", None)
        row["rule_slug"] = rule.get("slug") if rule else None
        row["rule_name"] = rule.get("name") if rule else None

    return rows


@router.get("/engagement/stats")
async def get_engagement_stats(user: CurrentUser):
    """Aggregate engagement email metrics."""
    _require_super_admin(user)
    sb = _get_supabase()

    sends = sb.table("engagement_sends").select(
        "status, opened_at, clicked_at, rule_id"
    ).execute()
    rows = sends.data or []

    total = len(rows)
    sent = sum(1 for r in rows if r.get("status") == "sent")
    opened = sum(1 for r in rows if r.get("opened_at"))
    clicked = sum(1 for r in rows if r.get("clicked_at"))

    # Cadence changes (slow-downs and unsubscribes)
    # Count users with non-default cadence as a proxy
    prefs = sb.table("notification_preferences").select(
        "email_cadence"
    ).neq("email_cadence", "realtime").execute()
    cadence_changes = len(prefs.data or [])
    unsubscribed = sum(1 for p in (prefs.data or []) if p.get("email_cadence") == "off")

    # Per-rule breakdown
    rules = sb.table("engagement_rules").select("id, slug").execute()
    rule_map = {r["id"]: r["slug"] for r in (rules.data or [])}

    by_rule: dict[str, dict] = {}
    for row in rows:
        slug = rule_map.get(row.get("rule_id", ""), "unknown")
        if slug not in by_rule:
            by_rule[slug] = {"sent": 0, "opened": 0, "clicked": 0}
        if row.get("status") == "sent":
            by_rule[slug]["sent"] += 1
        if row.get("opened_at"):
            by_rule[slug]["opened"] += 1
        if row.get("clicked_at"):
            by_rule[slug]["clicked"] += 1

    return {
        "total_sent": sent,
        "total_opened": opened,
        "total_clicked": clicked,
        "open_rate": round(opened / sent, 2) if sent else 0,
        "click_rate": round(clicked / sent, 2) if sent else 0,
        "slow_downs": cadence_changes - unsubscribed,
        "unsubscribes": unsubscribed,
        "by_rule": by_rule,
    }