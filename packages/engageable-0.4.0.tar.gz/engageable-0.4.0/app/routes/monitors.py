# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Monitor CRUD endpoints — create, list, update, delete, pause/resume."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["monitors"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------

class MonitorCreate(BaseModel):
    company_id: str
    name: str
    metric: str
    provider: str = "ga4"
    query_params: dict[str, Any] = {}
    schedule: str = "weekly"
    comparison: str = "previous_period"
    threshold: float | None = None
    direction: str = "any"
    channel: str = "chat"
    channel_config: dict[str, Any] = {}


class MonitorUpdate(BaseModel):
    name: str | None = None
    metric: str | None = None
    query_params: dict[str, Any] | None = None
    schedule: str | None = None
    comparison: str | None = None
    threshold: float | None = None
    direction: str | None = None
    channel: str | None = None
    channel_config: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/monitors")
async def create_monitor(body: MonitorCreate, user: CurrentUser):
    """Create a new monitor."""
    company_id = body.company_id

    sb = _get_supabase()
    row = {
        "company_id": company_id,
        "name": body.name,
        "metric": body.metric,
        "provider": body.provider,
        "query_params": body.query_params,
        "schedule": body.schedule,
        "comparison": body.comparison,
        "threshold": body.threshold,
        "direction": body.direction,
        "channel": body.channel,
        "channel_config": body.channel_config,
    }
    result = sb.table("monitors").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create monitor")
    return result.data[0]


@router.get("/monitors")
async def list_monitors(company_id: str, user: CurrentUser):
    """List all monitors for a company."""
    sb = _get_supabase()
    result = sb.table("monitors").select("*").eq(
        "company_id", company_id
    ).order("created_at", desc=False).execute()
    return result.data or []


@router.get("/monitors/{monitor_id}")
async def get_monitor(monitor_id: str, user: CurrentUser):
    """Get a single monitor by ID."""
    sb = _get_supabase()
    result = sb.table("monitors").select("*").eq("id", monitor_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")
    return result.data[0]


@router.patch("/monitors/{monitor_id}")
async def update_monitor(monitor_id: str, body: MonitorUpdate, user: CurrentUser):
    """Update a monitor's configuration."""
    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    sb = _get_supabase()
    result = sb.table("monitors").update(update_data).eq("id", monitor_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")
    return result.data[0]


@router.delete("/monitors/{monitor_id}")
async def delete_monitor(monitor_id: str, user: CurrentUser):
    """Delete a monitor."""
    sb = _get_supabase()
    result = sb.table("monitors").delete().eq("id", monitor_id).execute()
    return {"deleted": True}


@router.post("/monitors/{monitor_id}/pause")
async def pause_monitor(monitor_id: str, user: CurrentUser):
    """Pause a monitor (set is_active = false)."""
    sb = _get_supabase()
    result = sb.table("monitors").update({"is_active": False}).eq("id", monitor_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")
    return result.data[0]


@router.post("/monitors/{monitor_id}/resume")
async def resume_monitor(monitor_id: str, user: CurrentUser):
    """Resume a paused monitor (set is_active = true)."""
    sb = _get_supabase()
    result = sb.table("monitors").update({"is_active": True}).eq("id", monitor_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")
    return result.data[0]


# ---------------------------------------------------------------------------
# Execution endpoints
# ---------------------------------------------------------------------------

@router.post("/monitors/run")
async def run_monitors(company_id: str | None = None, user: CurrentUser = None):
    """Run all due monitors (optionally for a specific company).

    This is the endpoint called by a cron trigger.
    """
    from app.workflows.monitor_runner import run_due_monitors
    results = await run_due_monitors(company_id=company_id)
    return {
        "ran": len(results),
        "results": results,
    }


@router.post("/monitors/{monitor_id}/run")
async def run_single(monitor_id: str, user: CurrentUser):
    """Manually trigger a single monitor run (ignores schedule)."""
    from app.workflows.monitor_runner import run_single_monitor

    sb = _get_supabase()
    monitor_result = sb.table("monitors").select("*").eq("id", monitor_id).limit(1).execute()
    if not monitor_result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")

    monitor = monitor_result.data[0]
    provider = monitor.get("provider", "ga4")

    conn_result = sb.table("data_source_connections").select("*").eq(
        "company_id", monitor["company_id"]
    ).eq("provider", provider).eq("is_active", True).limit(1).execute()

    if not conn_result.data:
        raise HTTPException(status_code=400, detail=f"No active {provider} connection found")

    result = await run_single_monitor(monitor, conn_result.data[0])
    return result


@router.get("/monitors/{monitor_id}/runs")
async def list_monitor_runs(monitor_id: str, user: CurrentUser, limit: int = 20):
    """List recent runs for a monitor."""
    sb = _get_supabase()
    result = sb.table("monitor_runs").select("*").eq(
        "monitor_id", monitor_id
    ).order("started_at", desc=True).limit(limit).execute()
    return result.data or []


# ---------------------------------------------------------------------------
# Handler for proposed actions (called from actions.py)
# ---------------------------------------------------------------------------

async def _handle_monitor_create(params: dict, user: CurrentUser) -> dict:
    """Create a monitor via the proposed action flow."""
    company_id = user.get("company_id") or params.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    sb = _get_supabase()
    row = {
        "company_id": company_id,
        "name": params.get("name", "Untitled Monitor"),
        "metric": params.get("metric", ""),
        "provider": params.get("provider", "ga4"),
        "query_params": params.get("query_params", {}),
        "schedule": params.get("schedule", "weekly"),
        "comparison": params.get("comparison", "previous_period"),
        "threshold": params.get("threshold"),
        "direction": params.get("direction", "any"),
        "channel": params.get("channel", "chat"),
        "channel_config": params.get("channel_config", {}),
    }
    result = sb.table("monitors").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create monitor")
    return result.data[0]


async def _handle_monitor_update(params: dict, user: CurrentUser) -> dict:
    """Update a monitor via the proposed action flow."""
    monitor_id = params.get("monitor_id") or params.get("id")
    if not monitor_id:
        raise HTTPException(status_code=400, detail="No monitor_id")

    update_data = {k: v for k, v in params.items() if k not in ("monitor_id", "id", "company_id")}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    sb = _get_supabase()
    result = sb.table("monitors").update(update_data).eq("id", monitor_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Monitor not found")
    return result.data[0]


async def _handle_monitor_delete(params: dict, user: CurrentUser) -> dict:
    """Delete a monitor via the proposed action flow."""
    monitor_id = params.get("monitor_id") or params.get("id")
    if not monitor_id:
        raise HTTPException(status_code=400, detail="No monitor_id")

    sb = _get_supabase()
    sb.table("monitors").delete().eq("id", monitor_id).execute()
    return {"deleted": True, "id": monitor_id}