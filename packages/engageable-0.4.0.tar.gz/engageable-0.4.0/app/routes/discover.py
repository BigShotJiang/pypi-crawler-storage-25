# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Website discovery endpoint — scan a URL for analytics tags and persist results."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings
from engageable.skills.registry import get_registry

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["discover"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


class DiscoverRequest(BaseModel):
    url: str


@router.post("/discover")
async def discover(body: DiscoverRequest, user: CurrentUser):
    """Scan a website URL, return detected analytics providers, and persist the results."""
    registry = get_registry()
    skill = registry.get_skill("website_discover")
    if skill is None:
        return {"error": "Website discovery skill not available"}

    result = await skill.execute({"url": body.url})
    if not result.success:
        return {"error": result.error}

    # Resolve company_id from user
    user_id = user.get("sub")
    sb = _get_supabase()
    company_id = None
    if user_id:
        profile = sb.table("user_profiles").select("company_id").eq("id", user_id).limit(1).execute()
        if profile.data and profile.data[0].get("company_id"):
            company_id = profile.data[0]["company_id"]

    # Persist each detected tool
    if company_id and result.data.get("detected"):
        for tool in result.data["detected"]:
            _upsert_detected_tool(sb, company_id, body.url, tool)

        # Record the scan itself
        sb.table("site_scans").insert({
            "company_id": company_id,
            "url": result.data["url"],
            "page_title": result.data.get("page_title", ""),
            "tools_found": len(result.data["detected"]),
            "scan_time_ms": result.data.get("scan_time_ms"),
            "triggered_by": user_id,
        }).execute()

    # Background: extract business profile from website
    if company_id:
        try:
            import asyncio
            from app.models.profile_learner import extract_profile_from_website
            asyncio.create_task(
                extract_profile_from_website(company_id, body.url)
            )
        except Exception:
            logger.debug("Background website profile extraction failed", exc_info=True)

    return result.data


def _upsert_detected_tool(
    sb,
    company_id: str,
    url: str,
    tool: dict[str, Any],
) -> None:
    """Insert or update a detected tool for a company.

    If we've seen this provider before for this company, increment the
    detection count and update evidence. Otherwise create a new record.
    """
    provider = tool["provider"]

    # Check if already detected for this company
    existing = sb.table("detected_tools").select("id, detection_count, evidence_urls").eq(
        "company_id", company_id
    ).eq("provider", provider).limit(1).execute()

    evidence_entry = {
        "url": url,
        "confidence": tool.get("confidence", "high"),
        "evidence": tool.get("evidence", []),
    }

    if existing.data:
        # Update — increment count, append evidence URL if new
        row = existing.data[0]
        evidence_urls = row.get("evidence_urls") or []
        # Only append if this URL isn't already tracked
        known_urls = {e.get("url") for e in evidence_urls if isinstance(e, dict)}
        if url not in known_urls:
            evidence_urls.append(evidence_entry)

        sb.table("detected_tools").update({
            "detection_count": row["detection_count"] + 1,
            "evidence_urls": evidence_urls,
            "last_seen_at": "now()",
        }).eq("id", row["id"]).execute()
    else:
        # Insert new detection
        sb.table("detected_tools").insert({
            "company_id": company_id,
            "provider": provider,
            "display_name": tool.get("name", provider),
            "confidence": tool.get("confidence", "high"),
            "detection_count": 1,
            "evidence_urls": [evidence_entry],
            "is_connected": False,
        }).execute()