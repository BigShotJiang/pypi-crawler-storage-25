# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""API key management — create, list, revoke keys for external access."""

from __future__ import annotations

import hashlib
import logging
import secrets

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["api-keys"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


def _generate_key() -> tuple[str, str, str]:
    """Generate a new API key, returning (full_key, prefix, hash)."""
    raw = secrets.token_urlsafe(32)
    full_key = f"eng_{raw}"
    prefix = full_key[:12]
    key_hash = hashlib.sha256(full_key.encode()).hexdigest()
    return full_key, prefix, key_hash


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ApiKeyCreate(BaseModel):
    company_id: str
    label: str
    scopes: list[str] = ["read"]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/api-keys")
async def create_api_key(body: ApiKeyCreate, user: CurrentUser):
    """Create a new API key. Returns the full key ONCE — it cannot be retrieved later."""
    user_id = user.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="No user ID")

    full_key, prefix, key_hash = _generate_key()

    sb = _get_supabase()
    row = {
        "company_id": body.company_id,
        "created_by": user_id,
        "label": body.label,
        "key_prefix": prefix,
        "key_hash": key_hash,
        "scopes": body.scopes,
    }
    result = sb.table("api_keys").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create API key")

    # Return the full key only on creation
    record = result.data[0]
    record["key"] = full_key
    return record


@router.get("/api-keys")
async def list_api_keys(company_id: str, user: CurrentUser):
    """List all API keys for a company (without the actual key values)."""
    sb = _get_supabase()
    result = sb.table("api_keys").select(
        "id, company_id, created_by, label, key_prefix, scopes, last_used_at, is_active, expires_at, created_at"
    ).eq("company_id", company_id).order("created_at", desc=True).execute()
    return result.data or []


@router.delete("/api-keys/{key_id}")
async def revoke_api_key(key_id: str, user: CurrentUser):
    """Revoke (deactivate) an API key."""
    sb = _get_supabase()
    result = sb.table("api_keys").update({"is_active": False}).eq("id", key_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="API key not found")
    return {"revoked": True, "id": key_id}


@router.delete("/api-keys/{key_id}/permanent")
async def delete_api_key(key_id: str, user: CurrentUser):
    """Permanently delete an API key."""
    sb = _get_supabase()
    sb.table("api_keys").delete().eq("id", key_id).execute()
    return {"deleted": True, "id": key_id}