# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Evaluations API — admin review of agent quality."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["evaluations"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


@router.get("/evaluations")
async def list_evaluations(
    company_id: str,
    user: CurrentUser,
    signal_type: str | None = None,
    admin_verdict: str | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List evaluations, filterable by signal type and admin verdict."""
    sb = _get_supabase()

    query = sb.table("evaluations").select(
        "id, company_id, message_id, signal_type, quality_score, "
        "judge_reasoning, judge_model, admin_verdict, admin_notes, created_at"
    ).eq("company_id", company_id).order("created_at", desc=True)

    if signal_type:
        query = query.eq("signal_type", signal_type)
    if admin_verdict:
        query = query.eq("admin_verdict", admin_verdict)

    query = query.range(offset, offset + limit - 1)
    result = query.execute()
    return result.data or []


class EvaluationVerdictRequest(BaseModel):
    admin_verdict: str  # "good", "bad", "unclear"
    admin_notes: str | None = None


@router.patch("/evaluations/{evaluation_id}")
async def update_evaluation_verdict(
    evaluation_id: str,
    body: EvaluationVerdictRequest,
    user: CurrentUser,
):
    """Set admin verdict on an evaluation."""
    if body.admin_verdict not in ("good", "bad", "unclear"):
        raise HTTPException(status_code=400, detail="admin_verdict must be 'good', 'bad', or 'unclear'")

    sb = _get_supabase()
    update = {"admin_verdict": body.admin_verdict}
    if body.admin_notes is not None:
        update["admin_notes"] = body.admin_notes

    result = sb.table("evaluations").update(update).eq("id", evaluation_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Evaluation not found")
    return result.data[0]


@router.get("/evaluations/stats")
async def evaluation_stats(company_id: str, user: CurrentUser):
    """Get summary stats for evaluations."""
    sb = _get_supabase()

    all_evals = sb.table("evaluations").select(
        "signal_type, quality_score, admin_verdict"
    ).eq("company_id", company_id).execute()
    evals = all_evals.data or []

    total = len(evals)
    by_signal = {}
    by_verdict = {"good": 0, "bad": 0, "unclear": 0, "unreviewed": 0}
    scores = []

    for e in evals:
        signal = e.get("signal_type", "unknown")
        by_signal[signal] = by_signal.get(signal, 0) + 1
        verdict = e.get("admin_verdict")
        if verdict in by_verdict:
            by_verdict[verdict] += 1
        else:
            by_verdict["unreviewed"] += 1
        if e.get("quality_score") is not None:
            scores.append(float(e["quality_score"]))

    avg_score = sum(scores) / len(scores) if scores else None

    return {
        "total": total,
        "by_signal_type": by_signal,
        "by_verdict": by_verdict,
        "average_quality_score": round(avg_score, 2) if avg_score is not None else None,
    }