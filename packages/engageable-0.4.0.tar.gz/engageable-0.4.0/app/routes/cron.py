# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Cron trigger endpoints — scheduled jobs for monitors, outbound, proactive.

These endpoints are called by external schedulers (Vercel Cron, pg_cron, etc.)
using a shared CRON_SECRET header, or manually via JWT auth.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from app.auth import CurrentUser, get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/cron", tags=["cron"])


async def _cron_auth(request: Request) -> None:
    """Allow access via JWT (manual/testing) or CRON_SECRET header (scheduler)."""
    secret = request.headers.get("x-cron-secret")
    if secret:
        from app.config import get_settings
        settings = get_settings()
        expected = getattr(settings, "cron_secret", "")
        if not expected:
            raise HTTPException(status_code=500, detail="CRON_SECRET not configured on server")
        if secret != expected:
            raise HTTPException(status_code=401, detail="Invalid cron secret")
        return  # Authorized via secret

    # Fall back to JWT auth
    try:
        await get_current_user(request)
    except HTTPException:
        raise HTTPException(status_code=401, detail="Unauthorized — provide x-cron-secret header or JWT")


@router.post("/monitors", dependencies=[Depends(_cron_auth)])
async def run_monitors(company_id: str | None = None):
    """Run all due monitors. Optionally filter by company.

    Called on schedule (e.g. every 6 hours) or manually.
    """
    from app.workflows.monitor_runner import run_due_monitors
    results = await run_due_monitors(company_id)
    return {
        "ran": len(results),
        "results": results,
    }


@router.post("/outbound", dependencies=[Depends(_cron_auth)])
async def run_outbound(company_id: str | None = None):
    """Process pending outbound events — compose and deliver messages.

    Called on schedule (e.g. every 15 minutes) or manually.
    """
    from app.workflows.outbound import process_pending_events
    stats = await process_pending_events(company_id)
    return stats


@router.post("/proactive", dependencies=[Depends(_cron_auth)])
async def run_proactive(company_id: str | None = None):
    """Run proactive investigation for eligible companies.

    Called on schedule (e.g. daily at 6 AM) or manually.
    """
    if company_id:
        from app.workflows.proactive import run_proactive_investigation
        result = await run_proactive_investigation(company_id)
        return {"results": [result]}
    else:
        from app.workflows.proactive import run_proactive_for_all_companies
        results = await run_proactive_for_all_companies()
        return {"results": results}


@router.post("/evaluate", dependencies=[Depends(_cron_auth)])
async def run_evaluate(company_id: str | None = None):
    """Detect drop-offs and run batch evaluation.

    Called on schedule (e.g. daily) or manually.
    """
    from app.services.eval_signals import detect_drop_offs
    count = await detect_drop_offs(company_id)
    return {"drop_offs_detected": count}


@router.post("/engagement", dependencies=[Depends(_cron_auth)])
async def run_engagement():
    """Evaluate engagement rules and create outbound events for matching users.

    Called on schedule (e.g. daily at 7 AM) or manually.
    """
    from app.workflows.engagement_evaluator import evaluate_scheduled_rules
    stats = await evaluate_scheduled_rules()
    return stats


@router.post("/engagement_digest", dependencies=[Depends(_cron_auth)])
async def run_engagement_digest():
    """Process held engagement emails — batch into digests based on user cadence.

    Called on schedule (e.g. daily at 8 AM) or manually.
    """
    from app.workflows.engagement_digest import process_engagement_digests
    stats = await process_engagement_digests()
    return stats