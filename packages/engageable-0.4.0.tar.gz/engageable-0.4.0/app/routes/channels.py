# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Channel CRUD endpoints — manage delivery channels (Slack, email, webhook)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["channels"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ChannelCreate(BaseModel):
    company_id: str
    provider: str  # 'slack', 'email', 'webhook'
    label: str
    slack_team_id: str | None = None
    slack_team_name: str | None = None
    slack_channel_id: str | None = None
    slack_channel_name: str | None = None
    slack_bot_token: str | None = None
    slack_webhook_url: str | None = None
    email_addresses: list[str] | None = None
    webhook_url: str | None = None
    webhook_secret: str | None = None


class ChannelUpdate(BaseModel):
    label: str | None = None
    slack_channel_id: str | None = None
    slack_channel_name: str | None = None
    email_addresses: list[str] | None = None
    webhook_url: str | None = None
    is_active: bool | None = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/channels")
async def create_channel(body: ChannelCreate, user: CurrentUser):
    """Create a new delivery channel."""
    sb = _get_supabase()
    row = body.model_dump(exclude_none=True)
    result = sb.table("channels").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create channel")
    return result.data[0]


@router.get("/channels")
async def list_channels(company_id: str, user: CurrentUser):
    """List all channels for a company."""
    sb = _get_supabase()
    result = sb.table("channels").select("*").eq(
        "company_id", company_id
    ).order("created_at", desc=False).execute()
    return result.data or []


@router.get("/channels/{channel_id}")
async def get_channel(channel_id: str, user: CurrentUser):
    """Get a single channel by ID."""
    sb = _get_supabase()
    result = sb.table("channels").select("*").eq("id", channel_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Channel not found")
    return result.data[0]


@router.patch("/channels/{channel_id}")
async def update_channel(channel_id: str, body: ChannelUpdate, user: CurrentUser):
    """Update a channel's configuration."""
    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    sb = _get_supabase()
    result = sb.table("channels").update(update_data).eq("id", channel_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Channel not found")
    return result.data[0]


@router.delete("/channels/{channel_id}")
async def delete_channel(channel_id: str, user: CurrentUser):
    """Delete a channel."""
    sb = _get_supabase()
    sb.table("channels").delete().eq("id", channel_id).execute()
    return {"deleted": True}


# ---------------------------------------------------------------------------
# Slack OAuth flow
# ---------------------------------------------------------------------------

@router.get("/channels/slack/install")
async def slack_install_url(company_id: str, user: CurrentUser):
    """Generate the Slack OAuth install URL.

    The user clicks this to add the Slack bot to their workspace.
    Requires SLACK_CLIENT_ID to be configured.
    """
    settings = get_settings()
    client_id = settings.slack_client_id
    if not client_id:
        raise HTTPException(
            status_code=501,
            detail="Slack integration not configured. Set SLACK_CLIENT_ID in environment.",
        )

    redirect_uri = settings.slack_redirect_uri
    scopes = "channels:read,chat:write,incoming-webhook"
    state = f"{company_id}:{user.get('sub', '')}"

    url = (
        f"https://slack.com/oauth/v2/authorize"
        f"?client_id={client_id}"
        f"&scope={scopes}"
        f"&redirect_uri={redirect_uri}"
        f"&state={state}"
    )
    return {"url": url}


@router.get("/channels/slack/callback")
async def slack_callback(code: str, state: str):
    """Handle the Slack OAuth callback.

    Exchanges the code for tokens and creates a channel record.
    """
    import httpx

    settings = get_settings()
    if not settings.slack_client_id or not settings.slack_client_secret:
        raise HTTPException(status_code=501, detail="Slack not configured")

    # Parse state
    parts = state.split(":", 1)
    if len(parts) != 2:
        raise HTTPException(status_code=400, detail="Invalid state parameter")
    company_id, user_id = parts

    # Exchange code for token
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://slack.com/api/oauth.v2.access",
            data={
                "client_id": settings.slack_client_id,
                "client_secret": settings.slack_client_secret,
                "code": code,
                "redirect_uri": settings.slack_redirect_uri,
            },
        )
        data = resp.json()

    if not data.get("ok"):
        logger.error("Slack OAuth failed: %s", data.get("error"))
        raise HTTPException(status_code=400, detail=f"Slack OAuth failed: {data.get('error')}")

    # Extract tokens and workspace info
    team = data.get("team", {})
    incoming_webhook = data.get("incoming_webhook", {})
    bot_token = data.get("access_token", "")

    # Create channel record
    sb = _get_supabase()
    channel_row = {
        "company_id": company_id,
        "provider": "slack",
        "label": incoming_webhook.get("channel", team.get("name", "Slack")),
        "slack_team_id": team.get("id"),
        "slack_team_name": team.get("name"),
        "slack_channel_id": incoming_webhook.get("channel_id"),
        "slack_channel_name": incoming_webhook.get("channel"),
        "slack_bot_token": bot_token,
        "slack_webhook_url": incoming_webhook.get("url"),
    }
    sb.table("channels").insert(channel_row).execute()

    # Redirect back to settings
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=f"{settings.frontend_url}/dashboard/settings?slack=connected")


# ---------------------------------------------------------------------------
# Test: send a test message to a channel
# ---------------------------------------------------------------------------

@router.post("/channels/{channel_id}/test")
async def test_channel(channel_id: str, user: CurrentUser):
    """Send a test message to verify a channel works."""
    sb = _get_supabase()
    result = sb.table("channels").select("*").eq("id", channel_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Channel not found")

    channel = result.data[0]

    if channel["provider"] == "slack":
        token = channel.get("slack_bot_token")
        channel_id_slack = channel.get("slack_channel_id")
        webhook_url = channel.get("slack_webhook_url")

        if webhook_url:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.post(webhook_url, json={
                    "text": "Test message from Engageable. Your Slack channel is connected!"
                })
                if resp.status_code != 200:
                    raise HTTPException(status_code=502, detail="Slack webhook delivery failed")
        elif token and channel_id_slack:
            import httpx
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    "https://slack.com/api/chat.postMessage",
                    headers={"Authorization": f"Bearer {token}"},
                    json={
                        "channel": channel_id_slack,
                        "text": "Test message from Engageable. Your Slack channel is connected!",
                    },
                )
                data = resp.json()
                if not data.get("ok"):
                    raise HTTPException(status_code=502, detail=f"Slack error: {data.get('error')}")
        else:
            raise HTTPException(status_code=400, detail="No Slack token or webhook configured")
    else:
        raise HTTPException(status_code=400, detail=f"Test not implemented for {channel['provider']}")

    return {"success": True, "message": "Test message sent"}


# ---------------------------------------------------------------------------
# Handlers for proposed actions (called from actions.py)
# ---------------------------------------------------------------------------

async def _handle_channel_create(params: dict, user: CurrentUser) -> dict:
    """Create a channel via the proposed action flow."""
    company_id = user.get("company_id") or params.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    sb = _get_supabase()
    row = {
        "company_id": company_id,
        "provider": params.get("provider", "slack"),
        "label": params.get("label", params.get("channel_name", "Untitled Channel")),
    }

    # Slack-specific fields
    if row["provider"] == "slack":
        if params.get("slack_channel_name"):
            row["slack_channel_name"] = params["slack_channel_name"]
        if params.get("slack_channel_id"):
            row["slack_channel_id"] = params["slack_channel_id"]

    # Email-specific
    if row["provider"] == "email" and params.get("email_addresses"):
        row["email_addresses"] = params["email_addresses"]

    result = sb.table("channels").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create channel")
    return result.data[0]


async def _handle_channel_delete(params: dict, user: CurrentUser) -> dict:
    """Delete a channel via the proposed action flow."""
    channel_id = params.get("channel_id") or params.get("id")
    if not channel_id:
        raise HTTPException(status_code=400, detail="No channel_id")

    sb = _get_supabase()
    sb.table("channels").delete().eq("id", channel_id).execute()
    return {"deleted": True, "id": channel_id}