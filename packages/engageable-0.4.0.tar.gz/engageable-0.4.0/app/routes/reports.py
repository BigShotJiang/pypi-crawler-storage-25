# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Report CRUD + generation endpoints."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["reports"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ReportGenerateRequest(BaseModel):
    company_id: str
    title: str | None = None
    description: str | None = None
    topic: str | None = None  # e.g. "weekly traffic summary"
    date_range: str | None = None  # e.g. "last_7_days"
    finding_ids: list[str] | None = None  # specific findings to include


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/reports")
async def list_reports(company_id: str, user: CurrentUser):
    """List reports for a company."""
    sb = _get_supabase()
    result = sb.table("reports").select(
        "id, company_id, title, description, status, chart_count, created_by, created_at, updated_at"
    ).eq("company_id", company_id).order("created_at", desc=True).execute()
    return result.data or []


@router.get("/reports/{report_id}")
async def get_report(report_id: str, user: CurrentUser):
    """Get a single report with full spec."""
    sb = _get_supabase()
    result = sb.table("reports").select("*").eq("id", report_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Report not found")
    return result.data[0]


@router.post("/reports/generate")
async def generate_report(body: ReportGenerateRequest, user: CurrentUser):
    """Generate a new report using the LLM + findings data.

    Creates a report record immediately (status=generating), then builds it.
    Returns the report record so the frontend can navigate to it.
    """
    sb = _get_supabase()
    company_id = body.company_id

    # Create a placeholder report
    row = {
        "company_id": company_id,
        "title": body.title or "Report",
        "description": body.description or "",
        "status": "generating",
        "created_by": user.get("sub", "agent"),
    }
    result = sb.table("reports").insert(row).execute()
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create report")

    report = result.data[0]
    report_id = report["id"]

    # Build the report in the background-ish (still awaited for now)
    try:
        from app.workflows.report_builder import build_report
        spec = await build_report(
            company_id=company_id,
            report_id=report_id,
            topic=body.topic,
            date_range=body.date_range,
            finding_ids=body.finding_ids,
            title=body.title,
        )

        chart_count = sum(
            len(s.get("charts", [])) for s in spec.get("sections", [])
        )

        sb.table("reports").update({
            "spec": spec,
            "title": spec.get("title", body.title or "Report"),
            "description": spec.get("description", ""),
            "status": "ready",
            "chart_count": chart_count,
            "finding_ids": body.finding_ids or [],
        }).eq("id", report_id).execute()

        # Refetch the full report
        final = sb.table("reports").select("*").eq("id", report_id).limit(1).execute()
        return final.data[0] if final.data else report

    except Exception as exc:
        logger.exception("Report generation failed for %s", report_id)
        sb.table("reports").update({
            "status": "failed",
            "description": f"Generation failed: {str(exc)[:200]}",
        }).eq("id", report_id).execute()
        raise HTTPException(status_code=500, detail=f"Report generation failed: {exc}")


class ChartQueryRequest(BaseModel):
    connector: str
    connection_id: str
    config: dict
    parameter_overrides: dict | None = None


@router.post("/reports/chart-data")
async def chart_data(body: ChartQueryRequest, user: CurrentUser):
    """Execute a chart query and return { columns, rows }.

    Loads the connection credentials server-side and runs the query
    through the appropriate connector skill.
    """
    sb = _get_supabase()

    # Load the connection (and its credentials)
    conn_result = sb.table("data_source_connections").select(
        "id, provider, config, credentials"
    ).eq("id", body.connection_id).limit(1).execute()

    if not conn_result.data:
        raise HTTPException(status_code=404, detail="Connection not found")

    conn = conn_result.data[0]

    # Resolve parameter overrides if provided
    query_config = body.config
    if body.parameter_overrides:
        from app.services.chart_params import resolve_parameters
        parameters = query_config.get("parameters", [])
        query_config = resolve_parameters(query_config, parameters, body.parameter_overrides)

    if body.connector == "ga4":
        from engageable.skills.connectors.ga4 import GA4QuerySkill

        skill = GA4QuerySkill()
        params = {
            **query_config,
            "credentials": conn.get("credentials") or {},
            "property_id": query_config.get("property_id")
                or (conn.get("config") or {}).get("property_id", ""),
        }

        # Ensure required fields
        if not params.get("metrics"):
            params["metrics"] = ["activeUsers", "sessions"]
        if not params.get("date_range"):
            params["date_range"] = "last30days"

        result = await skill.execute(params)
        if not result.success:
            logger.warning("Chart query failed: %s", result.error)
            raise HTTPException(status_code=502, detail=f"Chart query failed: {result.error}")
        return {
            "columns": result.data.get("columns", []) if result.data else [],
            "rows": result.data.get("rows", []) if result.data else [],
        }

    if body.connector == "posthog":
        from engageable.skills.connectors.posthog import PostHogQuerySkill

        skill = PostHogQuerySkill()
        params = {
            **query_config,
            "credentials": conn.get("credentials") or {},
            "project_id": query_config.get("project_id")
                or (conn.get("config") or {}).get("project_id", ""),
        }

        result = await skill.execute(params)
        if not result.success:
            logger.warning("PostHog chart query failed: %s", result.error)
            raise HTTPException(status_code=502, detail=f"Chart query failed: {result.error}")
        return {
            "columns": result.data.get("columns", []) if result.data else [],
            "rows": result.data.get("rows", []) if result.data else [],
        }

    if body.connector == "mixpanel":
        from engageable.skills.connectors.mixpanel import MixpanelQuerySkill

        skill = MixpanelQuerySkill()
        params = {
            **query_config,
            "credentials": conn.get("credentials") or {},
            "project_id": query_config.get("project_id")
                or (conn.get("config") or {}).get("project_id", ""),
        }

        result = await skill.execute(params)
        if not result.success:
            logger.warning("Mixpanel chart query failed: %s", result.error)
            raise HTTPException(status_code=502, detail=f"Chart query failed: {result.error}")
        return {
            "columns": result.data.get("columns", []) if result.data else [],
            "rows": result.data.get("rows", []) if result.data else [],
        }

    raise HTTPException(status_code=400, detail=f"Unsupported connector: {body.connector}")


@router.delete("/reports/{report_id}")
async def delete_report(report_id: str, user: CurrentUser):
    """Delete a report."""
    sb = _get_supabase()
    sb.table("reports").delete().eq("id", report_id).execute()
    return {"deleted": True}


# ---------------------------------------------------------------------------
# Action handlers (called from actions.py for proposed action flow)
# ---------------------------------------------------------------------------

async def _handle_report_generate(params: dict, user: CurrentUser) -> dict:
    """Generate a report via the proposed action flow."""
    company_id = user.get("company_id") or params.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    body = ReportGenerateRequest(
        company_id=company_id,
        title=params.get("title"),
        description=params.get("description"),
        topic=params.get("topic"),
        date_range=params.get("date_range"),
        finding_ids=params.get("finding_ids"),
    )
    return await generate_report(body, user)


async def _handle_report_delete(params: dict, user: CurrentUser) -> dict:
    """Delete a report via the proposed action flow."""
    report_id = params.get("report_id") or params.get("id")
    if not report_id:
        raise HTTPException(status_code=400, detail="No report_id")

    sb = _get_supabase()
    sb.table("reports").delete().eq("id", report_id).execute()
    return {"deleted": True, "id": report_id}