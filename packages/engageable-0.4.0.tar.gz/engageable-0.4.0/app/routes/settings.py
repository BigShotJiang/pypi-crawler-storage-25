# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Settings endpoints — profile updates, team management."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["settings"])


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------

class ProfileUpdate(BaseModel):
    display_name: str | None = None
    email: str | None = None


@router.get("/settings/profile")
async def get_profile(user: CurrentUser):
    """Get the current user's profile."""
    user_id = user.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="No user ID")

    sb = _get_supabase()
    result = sb.table("user_profiles").select("*").eq("id", user_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    return result.data[0]


@router.patch("/settings/profile")
async def update_profile(body: ProfileUpdate, user: CurrentUser):
    """Update the current user's profile."""
    user_id = user.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="No user ID")

    update_data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    sb = _get_supabase()
    result = sb.table("user_profiles").update(update_data).eq("id", user_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    return result.data[0]


# ---------------------------------------------------------------------------
# Team (company members)
# ---------------------------------------------------------------------------

@router.get("/settings/team")
async def list_team(company_id: str, user: CurrentUser):
    """List all team members for a company."""
    sb = _get_supabase()
    result = sb.table("user_profiles").select(
        "id, email, display_name, role, created_at"
    ).eq("company_id", company_id).order("created_at", desc=False).execute()
    return result.data or []