# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Findings API — browse, retrieve, and manage finding lifecycle."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["findings"])

FINDING_FIELDS = (
    "id, company_id, summary, severity, category, source, structured_data, "
    "metrics, context, recommendation, methodology, data_sources, "
    "state, related_issue_id, first_detected_at, last_verified_at, "
    "created_at, analysis_run_id"
)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


@router.get("/findings")
async def list_findings(
    company_id: str,
    user: CurrentUser,
    severity: str | None = None,
    category: str | None = None,
    state: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List findings for a company, with optional filters."""
    sb = _get_supabase()

    query = sb.table("findings").select(FINDING_FIELDS).eq(
        "company_id", company_id
    ).order("created_at", desc=True)

    if severity:
        query = query.eq("severity", severity)
    if category:
        query = query.eq("category", category)
    if state:
        query = query.eq("state", state)
    if date_from:
        query = query.gte("created_at", date_from)
    if date_to:
        query = query.lte("created_at", date_to)

    query = query.range(offset, offset + limit - 1)
    result = query.execute()
    return result.data or []


@router.get("/findings/outstanding")
async def list_outstanding_issues(
    company_id: str,
    user: CurrentUser,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List outstanding issues — findings acknowledged but not yet resolved."""
    sb = _get_supabase()
    result = sb.table("findings").select(FINDING_FIELDS).eq(
        "company_id", company_id
    ).eq(
        "state", "outstanding"
    ).order("last_verified_at", desc=True).range(
        offset, offset + limit - 1
    ).execute()
    return result.data or []


@router.get("/findings/{finding_id}")
async def get_finding(finding_id: str, user: CurrentUser):
    """Get a single finding with full detail."""
    sb = _get_supabase()
    result = sb.table("findings").select("*").eq("id", finding_id).limit(1).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Finding not found")
    return result.data[0]


class FindingStateUpdate(BaseModel):
    state: str


@router.patch("/findings/{finding_id}/state")
async def update_finding_state(
    finding_id: str, body: FindingStateUpdate, user: CurrentUser
):
    """Transition a finding's state (acknowledge, dismiss, resolve)."""
    valid_states = {"new", "outstanding", "resolved", "dismissed"}
    if body.state not in valid_states:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid state: {body.state}. Must be one of {valid_states}",
        )

    sb = _get_supabase()

    # Verify finding exists
    existing = sb.table("findings").select("id, state").eq(
        "id", finding_id
    ).limit(1).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail="Finding not found")

    updates: dict[str, Any] = {"state": body.state}

    # When acknowledging, set last_verified_at
    if body.state == "outstanding":
        updates["last_verified_at"] = datetime.now(timezone.utc).isoformat()

    result = sb.table("findings").update(updates).eq("id", finding_id).execute()
    return result.data[0] if result.data else {"ok": True}
