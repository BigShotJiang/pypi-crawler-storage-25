# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Action execution endpoint — handles approve/dismiss of proposed actions."""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["actions"])


class ExecuteActionRequest(BaseModel):
    action: str
    params: dict


class ExecuteActionResponse(BaseModel):
    success: bool
    result: dict | None = None
    error: str | None = None


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


# ---------------------------------------------------------------------------
# Action handlers — one per action type
# ---------------------------------------------------------------------------

async def _handle_project_create(params: dict, user: CurrentUser) -> dict:
    sb = _get_supabase()
    company_id = user.get("company_id") or params.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id available")

    update_data = {}
    if params.get("name"):
        update_data["name"] = params["name"]
    if params.get("website_url"):
        update_data["website_url"] = params["website_url"]

    if update_data:
        result = sb.table("companies").update(update_data).eq("id", company_id).execute()
        return {"id": company_id, **(result.data[0] if result.data else update_data)}

    return {"id": company_id}


async def _handle_project_update(params: dict, user: CurrentUser) -> dict:
    sb = _get_supabase()
    company_id = params.get("company_id") or user.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    update_data = {k: v for k, v in params.items() if k not in ("company_id", "id")}
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = sb.table("companies").update(update_data).eq("id", company_id).execute()
    return result.data[0] if result.data else update_data


async def _handle_connection_update(params: dict, user: CurrentUser) -> dict:
    """Update a data source connection's status, profile, or learned notes."""
    sb = _get_supabase()
    company_id = user.get("company_id") or params.get("company_id")
    connection_id = params.get("connection_id")
    provider = params.get("provider")

    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    if connection_id:
        query = sb.table("data_source_connections").select("*").eq("id", connection_id)
    elif provider:
        query = sb.table("data_source_connections").select("*").eq(
            "company_id", company_id
        ).eq("provider", provider).limit(1)
    else:
        raise HTTPException(status_code=400, detail="Need connection_id or provider")

    existing = query.execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail="Connection not found")

    conn = existing.data[0]
    update_data: dict = {}

    if "status" in params:
        update_data["status"] = params["status"]
    if "profile" in params:
        update_data["profile"] = params["profile"]
    if "config" in params:
        merged_config = {**(conn.get("config") or {}), **params["config"]}
        update_data["config"] = merged_config
    if "display_name" in params:
        update_data["display_name"] = params["display_name"]

    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = sb.table("data_source_connections").update(update_data).eq(
        "id", conn["id"]
    ).execute()
    return result.data[0] if result.data else update_data


async def append_learned_note(
    company_id: str,
    provider: str,
    note: str,
    category: str = "error",
    max_notes: int = 50,
) -> None:
    """Append a learned note to a connection's learned.notes array.

    Deduplicates by note text. Keeps the most recent max_notes entries.
    Categories: 'error', 'schema', 'quota', 'user'.
    """
    sb = _get_supabase()
    existing = sb.table("data_source_connections").select("id, learned").eq(
        "company_id", company_id
    ).eq("provider", provider).limit(1).execute()

    if not existing.data:
        return

    conn = existing.data[0]
    learned = conn.get("learned") or {"notes": []}
    notes = learned.get("notes", [])

    # Deduplicate — don't add the same note text again
    if any(n.get("text") == note for n in notes):
        return

    notes.append({
        "text": note,
        "category": category,
        "ts": datetime.now(timezone.utc).isoformat(),
    })

    # Keep only the most recent entries
    if len(notes) > max_notes:
        notes = notes[-max_notes:]

    learned["notes"] = notes
    sb.table("data_source_connections").update({"learned": learned}).eq(
        "id", conn["id"]
    ).execute()


async def _handle_finding_acknowledge(params: dict, user: CurrentUser) -> dict:
    """Move a finding to 'outstanding' — user has seen it, agent keeps monitoring."""
    sb = _get_supabase()
    finding_id = params.get("finding_id")
    if not finding_id:
        raise HTTPException(status_code=400, detail="finding_id required")

    result = sb.table("findings").update({
        "state": "outstanding",
        "last_verified_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", finding_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Finding not found")
    return result.data[0]


async def _handle_finding_dismiss(params: dict, user: CurrentUser) -> dict:
    """Dismiss a finding — agent won't bring it up again."""
    sb = _get_supabase()
    finding_id = params.get("finding_id")
    if not finding_id:
        raise HTTPException(status_code=400, detail="finding_id required")

    result = sb.table("findings").update({
        "state": "dismissed",
    }).eq("id", finding_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Finding not found")
    return result.data[0]


async def _handle_finding_resolve(params: dict, user: CurrentUser) -> dict:
    """Mark a finding as resolved."""
    sb = _get_supabase()
    finding_id = params.get("finding_id")
    if not finding_id:
        raise HTTPException(status_code=400, detail="finding_id required")

    result = sb.table("findings").update({
        "state": "resolved",
        "last_verified_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", finding_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Finding not found")
    return result.data[0]


async def _handle_dashboard_create(params: dict, user: CurrentUser) -> dict:
    """Create a dashboard instance (skill-based or legacy template-based)."""
    sb = _get_supabase()
    company_id = user.get("company_id") or params.get("company_id")
    if not company_id:
        raise HTTPException(status_code=400, detail="No company_id")

    row: dict[str, Any] = {
        "company_id": company_id,
        "label": params.get("label", "Overview"),
        "bindings": params.get("bindings", {}),
        "is_active": params.get("is_active", True),
    }
    if params.get("template_id"):
        row["template_id"] = params["template_id"]

    result = sb.table("dashboard_instances").insert(row).execute()
    return result.data[0] if result.data else {}


async def _handle_dashboard_update(params: dict, user: CurrentUser) -> dict:
    """Update a dashboard instance (bindings, label, etc)."""
    sb = _get_supabase()
    dashboard_id = params.get("dashboard_id")
    if not dashboard_id:
        raise HTTPException(status_code=400, detail="dashboard_id required")

    updates = {k: v for k, v in params.items() if k in ("label", "bindings", "is_active")}
    if not updates:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = sb.table("dashboard_instances").update(updates).eq(
        "id", dashboard_id
    ).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    return result.data[0]


# Registry of action handlers
ACTION_HANDLERS = {
    "project.create": _handle_project_create,
    "project.update": _handle_project_update,
    "connection.update": _handle_connection_update,
    "finding.acknowledge": _handle_finding_acknowledge,
    "finding.dismiss": _handle_finding_dismiss,
    "finding.resolve": _handle_finding_resolve,
    "dashboard.create": _handle_dashboard_create,
    "dashboard.update": _handle_dashboard_update,
}


def _get_monitor_handler(action: str):
    """Lazy-load monitor handlers to avoid circular imports."""
    from app.routes.monitors import (
        _handle_monitor_create,
        _handle_monitor_update,
        _handle_monitor_delete,
    )
    return {
        "monitor.create": _handle_monitor_create,
        "monitor.update": _handle_monitor_update,
        "monitor.delete": _handle_monitor_delete,
    }.get(action)


def _get_report_handler(action: str):
    """Lazy-load report handlers to avoid circular imports."""
    from app.routes.reports import (
        _handle_report_generate,
        _handle_report_delete,
    )
    return {
        "report.generate": _handle_report_generate,
        "report.delete": _handle_report_delete,
    }.get(action)


def _get_channel_handler(action: str):
    """Lazy-load channel handlers to avoid circular imports."""
    from app.routes.channels import (
        _handle_channel_create,
        _handle_channel_delete,
    )
    return {
        "channel.create": _handle_channel_create,
        "channel.delete": _handle_channel_delete,
    }.get(action)


@router.post("/actions/execute", response_model=ExecuteActionResponse)
async def execute_action(body: ExecuteActionRequest, user: CurrentUser):
    """Execute an approved proposed action."""
    handler = ACTION_HANDLERS.get(body.action)

    # Check monitor actions (lazy-loaded)
    if not handler and body.action.startswith("monitor."):
        handler = _get_monitor_handler(body.action)

    # Check report actions (lazy-loaded)
    if not handler and body.action.startswith("report."):
        handler = _get_report_handler(body.action)

    # Check channel actions (lazy-loaded)
    if not handler and body.action.startswith("channel."):
        handler = _get_channel_handler(body.action)

    if not handler:
        supported = list(ACTION_HANDLERS.keys()) + [
            "monitor.create", "monitor.update", "monitor.delete",
            "report.generate", "report.delete",
            "channel.create", "channel.delete",
            "finding.acknowledge", "finding.dismiss", "finding.resolve",
            "dashboard.create", "dashboard.update",
        ]
        raise HTTPException(
            status_code=400,
            detail=f"Unknown action: {body.action}. Supported: {', '.join(supported)}",
        )

    try:
        result = await handler(body.params, user)
        return ExecuteActionResponse(success=True, result=result)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Action %s failed", body.action)
        return ExecuteActionResponse(success=False, error=str(exc))