# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Chat endpoint — send a message, get a streaming agent response."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from supabase import create_client

from app.auth import CurrentUser
from app.config import get_settings
from app.workflows.qa import run_qa

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["chat"])


class ChatRequest(BaseModel):
    message: str
    company_id: str


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


def _save_message(company_id: str, role: str, content: dict, metadata: dict | None = None):
    """Persist a chat message to Supabase."""
    sb = _get_supabase()
    row = {
        "company_id": company_id,
        "role": role,
        "content": content,
        "metadata": metadata or {},
    }
    result = sb.table("chat_messages").insert(row).execute()
    return result.data[0] if result.data else None


def _load_project(company_id: str) -> dict | None:
    """Load the company/project record."""
    sb = _get_supabase()
    response = sb.table("companies").select("*").eq("id", company_id).limit(1).execute()
    return response.data[0] if response.data else None


def _load_data_sources(company_id: str) -> list[dict]:
    """Load active data source connections for a company."""
    sb = _get_supabase()
    response = sb.table("data_source_connections").select("*").eq(
        "company_id", company_id
    ).eq("is_active", True).execute()
    return response.data or []


async def _load_agent_memories(company_id: str, query: str | None = None) -> list[dict]:
    """Load agent memories — semantic retrieval if query provided, else all."""
    if query:
        from app.memory.retrieval import retrieve_relevant_memories
        return await retrieve_relevant_memories(company_id, query, top_k=20)

    sb = _get_supabase()
    response = sb.table("agent_memory").select("category, content").eq(
        "company_id", company_id
    ).order("created_at", desc=False).limit(50).execute()
    return response.data or []


def _load_chat_history(company_id: str, limit: int = 20) -> list[dict]:
    """Load recent chat messages for conversation context.

    Returns messages in chronological order (oldest first), excluding the
    current user message which is passed separately.
    """
    sb = _get_supabase()
    # Fetch the most recent N messages (desc), then reverse for chronological order
    response = sb.table("chat_messages").select("role, content").eq(
        "company_id", company_id
    ).order("created_at", desc=True).limit(limit).execute()
    rows = response.data or []
    rows.reverse()
    return rows


async def _handle_business_question_answer(
    company_id: str, user_message: str, chat_history: list[dict] | None
) -> None:
    """If the last agent message was a business_question card, write the
    user's answer directly to the business profile.

    This runs BEFORE the agent processes the message, so the profile is
    updated by the time the agent builds its next response.
    """
    if not chat_history:
        return

    # Find the most recent agent message
    for msg in reversed(chat_history):
        if msg.get("role") != "agent":
            continue
        content = msg.get("content")
        if isinstance(content, dict) and content.get("type") == "business_question":
            profile_field = content.get("profile_field", "")
            if not profile_field:
                return
            # The user's message IS the answer
            try:
                from app.models.profile_store import update_profile
                await update_profile(
                    company_id,
                    {profile_field: user_message.strip()},
                    source="stated",
                    confidence=1.0,
                    evidence=f"User answered business question: {content.get('question', '')}",
                )
                logger.info(
                    "Business question answered: %s = %s (company %s)",
                    profile_field, user_message[:50], company_id,
                )
            except Exception:
                logger.debug("Failed to write business question answer to profile", exc_info=True)
            return
        # If the most recent agent message isn't a business_question, stop looking
        return


async def _generate_sse(
    company_id: str,
    user_id: str,
    user_message: str,
    data_sources: list[dict],
    project: dict | None,
    chat_history: list[dict] | None = None,
    memories: list[dict] | None = None,
    user_email: str | None = None,
    user_name: str | None = None,
):
    """Run the QA workflow and yield SSE events."""
    try:
        # Check if the user is answering a pending business question
        await _handle_business_question_answer(company_id, user_message, chat_history)

        # Signal that the agent is thinking
        yield f"event: thinking\ndata: {json.dumps({'status': 'thinking'})}\n\n"

        # Run the agent — returns a list of message parts
        parts = await run_qa(
            question=user_message,
            company_id=company_id,
            data_sources=data_sources,
            user_id=user_id,
            project=project,
            chat_history=chat_history,
            memories=memories,
            user_email=user_email,
            user_name=user_name,
        )

        # Send each message part (insight card + text, or just text, etc.)
        for part in parts:
            saved = _save_message(company_id, "agent", part)
            yield f"event: message\ndata: {json.dumps({'id': saved['id'] if saved else None, 'role': 'agent', 'content': part})}\n\n"

        yield f"event: done\ndata: {json.dumps({'status': 'done'})}\n\n"

        # Background: extract business context from conversation
        try:
            from app.models.profile_learner import extract_profile_from_conversation
            import asyncio
            conv_messages = [
                {"role": m.get("role", "user"), "content": m.get("content", "")}
                for m in (chat_history or [])
            ]
            conv_messages.append({"role": "user", "content": user_message})
            for part in parts:
                if isinstance(part, dict) and part.get("type") == "text":
                    conv_messages.append({"role": "agent", "content": part.get("text", "")})
            asyncio.create_task(
                extract_profile_from_conversation(company_id, conv_messages)
            )
        except Exception:
            logger.debug("Background conversation extraction failed", exc_info=True)

    except Exception as exc:
        logger.exception("Chat agent failed")

        error_str = str(exc)
        if "credit balance is too low" in error_str or "billing" in error_str.lower():
            user_msg = "The AI service is temporarily unavailable. Please contact your administrator."
        elif "rate_limit" in error_str.lower() or "429" in error_str:
            user_msg = "I'm receiving too many requests right now. Please try again in a moment."
        elif "overloaded" in error_str.lower() or "529" in error_str:
            user_msg = "The AI service is currently under heavy load. Please try again shortly."
        else:
            user_msg = "Sorry, something went wrong processing your request. Please try again."

        error_content = {"type": "text", "text": user_msg}
        _save_message(company_id, "agent", error_content, {"error": True, "detail": error_str})

        yield f"event: error\ndata: {json.dumps({'error': user_msg, 'content': error_content})}\n\n"


@router.post("/chat")
async def chat(body: ChatRequest, user: CurrentUser):
    """Send a chat message and get a streaming response."""
    company_id = body.company_id

    # Load conversation history BEFORE saving the new message
    # (so we don't duplicate the current message in history + question)
    chat_history = _load_chat_history(company_id)

    # Save the user message
    user_content = {"type": "text", "text": body.message}
    saved_user = _save_message(company_id, "user", user_content)

    if not saved_user:
        raise HTTPException(status_code=500, detail="Failed to save message")

    # Detect quality signals from this user message
    try:
        from app.services.eval_signals import detect_corrective_follow_up
        sb = _get_supabase()
        # Get the most recent agent message before this one
        prev_agent = sb.table("chat_messages").select("id").eq(
            "company_id", company_id
        ).eq("role", "agent").order("created_at", desc=True).limit(1).execute()
        prev_agent_id = prev_agent.data[0]["id"] if prev_agent.data else None
        detect_corrective_follow_up(company_id, body.message, prev_agent_id)
    except Exception:
        pass  # Signal detection is advisory, never block chat

    # Load project, data sources, and agent memories (semantic retrieval)
    project = _load_project(company_id)
    data_sources = _load_data_sources(company_id)
    memories = await _load_agent_memories(company_id, query=body.message)

    user_id = user.get("sub", "")
    user_email = user.get("email", "")

    # Load user's display name from profile (column is display_name per schema)
    user_name = None
    if user_id:
        sb = _get_supabase()
        profile = sb.table("user_profiles").select("display_name").eq("id", user_id).limit(1).execute()
        if profile.data and profile.data[0].get("display_name"):
            user_name = profile.data[0]["display_name"]

    return StreamingResponse(
        _generate_sse(company_id, user_id, body.message, data_sources, project, chat_history, memories, user_email=user_email, user_name=user_name),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


class UpdateMessageRequest(BaseModel):
    content: dict


@router.patch("/chat/messages/{message_id}")
async def update_message(message_id: str, body: UpdateMessageRequest, user: CurrentUser):
    """Update a chat message's content (e.g. proposed action status)."""
    sb = _get_supabase()
    result = sb.table("chat_messages").update(
        {"content": body.content}
    ).eq("id", message_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Message not found")
    return result.data[0]


@router.get("/chat/unread-count")
async def unread_count(company_id: str, user: CurrentUser):
    """Return the number of unread agent messages since last_read_at."""
    user_id = user.get("sub", "")
    sb = _get_supabase()

    # Get last_read_at from notification_preferences
    prefs = sb.table("notification_preferences").select("last_read_at").eq(
        "user_id", user_id
    ).eq("company_id", company_id).limit(1).execute()

    last_read = prefs.data[0]["last_read_at"] if prefs.data and prefs.data[0].get("last_read_at") else None

    # Count agent messages after last_read_at
    query = sb.table("chat_messages").select("id", count="exact").eq(
        "company_id", company_id
    ).eq("role", "agent")

    if last_read:
        query = query.gt("created_at", last_read)

    result = query.execute()
    return {"count": result.count or 0, "last_read_at": last_read}


class MarkReadRequest(BaseModel):
    company_id: str


@router.post("/chat/mark-read")
async def mark_read(body: MarkReadRequest, user: CurrentUser):
    """Update last_read_at to now for this user+company."""
    user_id = user.get("sub", "")
    sb = _get_supabase()
    now = datetime.now(timezone.utc).isoformat()

    # Upsert: update if exists, create if not
    existing = sb.table("notification_preferences").select("id").eq(
        "user_id", user_id
    ).eq("company_id", body.company_id).limit(1).execute()

    if existing.data:
        sb.table("notification_preferences").update(
            {"last_read_at": now}
        ).eq("id", existing.data[0]["id"]).execute()
    else:
        sb.table("notification_preferences").insert({
            "user_id": user_id,
            "company_id": body.company_id,
            "last_read_at": now,
        }).execute()

    return {"last_read_at": now}


@router.get("/chat/history")
async def chat_history(
    company_id: str,
    user: CurrentUser,
    limit: int = 50,
    before: str | None = None,
):
    """Load chat history for a company.

    Returns messages in chronological order (oldest first).
    Use `before` (ISO timestamp) to paginate backwards (load older messages).
    """
    sb = _get_supabase()
    query = sb.table("chat_messages").select("*").eq(
        "company_id", company_id
    ).order("created_at", desc=True).limit(limit)

    if before:
        query = query.lt("created_at", before)

    result = query.execute()
    rows = result.data or []
    rows.reverse()  # Return chronological order
    return rows