# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""In-process cron scheduler using APScheduler.

Runs inside the FastAPI process on Fly. Calls job functions directly — no HTTP
round-trip or shared secret needed. Records each run in the ``cron_runs`` table
so the admin UI stays up to date.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.config import get_settings

logger = logging.getLogger(__name__)

_scheduler: AsyncIOScheduler | None = None

# UTC schedule matching the original pg_cron migration
_JOBS: list[tuple[str, int, int]] = [
    # (job_type, hour, minute)
    ("monitors",  6, 0),
    ("proactive", 6, 1),
    ("outbound",  6, 5),
    ("evaluate",  7, 0),
    ("engagement", 7, 30),
    ("engagement_digest", 8, 0),
]


async def _run_and_record(job_type: str) -> None:
    """Execute a cron job and persist the result to ``cron_runs``."""
    from supabase import create_client
    from app.services.cron_jobs import execute_cron_job

    settings = get_settings()
    sb = create_client(settings.supabase_url, settings.supabase_service_role_key)

    started_at = datetime.now(timezone.utc)
    run_row = sb.table("cron_runs").insert({
        "job_type": job_type,
        "status": "running",
        "trigger": "scheduled",
        "started_at": started_at.isoformat(),
    }).execute()
    run_id = run_row.data[0]["id"] if run_row.data else None

    try:
        result = await execute_cron_job(job_type)
        completed_at = datetime.now(timezone.utc)
        duration_ms = int((completed_at - started_at).total_seconds() * 1000)

        if run_id:
            sb.table("cron_runs").update({
                "status": "success",
                "completed_at": completed_at.isoformat(),
                "duration_ms": duration_ms,
                "result": result,
            }).eq("id", run_id).execute()

        logger.info("Cron %s completed in %dms: %s", job_type, duration_ms, result)

    except Exception as exc:
        completed_at = datetime.now(timezone.utc)
        duration_ms = int((completed_at - started_at).total_seconds() * 1000)
        error_msg = str(exc)[:500]

        if run_id:
            sb.table("cron_runs").update({
                "status": "error",
                "completed_at": completed_at.isoformat(),
                "duration_ms": duration_ms,
                "error": error_msg,
            }).eq("id", run_id).execute()

        logger.exception("Cron %s failed after %dms", job_type, duration_ms)


def start_scheduler() -> None:
    """Create and start the APScheduler instance. Safe to call once at startup."""
    global _scheduler

    settings = get_settings()
    if settings.engine_env.strip().lower() != "production":
        logger.info("Skipping cron scheduler in non-production env (%s)", settings.engine_env)
        return

    _scheduler = AsyncIOScheduler(timezone="UTC")

    for job_type, hour, minute in _JOBS:
        _scheduler.add_job(
            _run_and_record,
            trigger=CronTrigger(hour=hour, minute=minute, timezone="UTC"),
            args=[job_type],
            id=f"engageable-{job_type}",
            name=f"cron:{job_type}",
            replace_existing=True,
        )

    _scheduler.start()
    next_runs = ", ".join(
        f"{j.id} @ {j.next_run_time:%H:%M}" for j in _scheduler.get_jobs()
    )
    print(f"[engine] Cron scheduler started with {len(_JOBS)} jobs: {next_runs}", flush=True)
    logger.info("Cron scheduler started with %d jobs: %s", len(_JOBS), next_runs)


def stop_scheduler() -> None:
    """Gracefully shut down the scheduler."""
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        logger.info("Cron scheduler stopped")
        _scheduler = None