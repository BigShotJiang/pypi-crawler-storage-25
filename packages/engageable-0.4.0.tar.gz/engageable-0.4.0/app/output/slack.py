# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Slack output — format messages as Block Kit and deliver via Web API."""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def format_answer_as_blocks(answer: str, sources: list[str] | None = None) -> list[dict[str, Any]]:
    """Convert a plain-text answer into Slack Block Kit blocks."""
    blocks: list[dict[str, Any]] = [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": answer},
        }
    ]

    if sources:
        blocks.append({"type": "divider"})
        blocks.append({
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"Sources: {', '.join(sources)}",
                }
            ],
        })

    return blocks


def format_finding_as_blocks(finding: dict[str, Any]) -> list[dict[str, Any]]:
    """Convert a Finding dict into Slack Block Kit blocks."""
    severity_emoji = {
        "info": "i",
        "warning": "!",
        "critical": "!!",
    }

    severity = finding.get("severity", "info")
    emoji = severity_emoji.get(severity, "i")

    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"[{emoji}] {finding.get('summary', 'Analysis Result')}",
            },
        },
    ]

    if finding.get("context"):
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": finding["context"]},
        })

    if finding.get("recommendation"):
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*Recommendation:* {finding['recommendation']}",
            },
        })

    if finding.get("methodology"):
        blocks.append({"type": "divider"})
        blocks.append({
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"_Methodology: {finding['methodology']}_",
                }
            ],
        })

    return blocks


def format_outbound_message(message: str, severity: str = "info") -> list[dict[str, Any]]:
    """Format an agent-composed outbound message as Slack blocks."""
    blocks: list[dict[str, Any]] = [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": message},
        },
        {"type": "divider"},
        {
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": "_Sent by Engageable_"},
            ],
        },
    ]
    return blocks


async def deliver_slack(
    channel: dict[str, Any],
    message: str,
    severity: str = "info",
    thread_ts: str | None = None,
) -> dict[str, Any]:
    """Deliver a message to a Slack channel.

    Uses bot token + chat.postMessage first, falls back to webhook.
    Returns the Slack API response.
    """
    bot_token = channel.get("slack_bot_token")
    channel_id = channel.get("slack_channel_id")
    webhook_url = channel.get("slack_webhook_url")

    blocks = format_outbound_message(message, severity)

    if bot_token and channel_id:
        payload: dict[str, Any] = {
            "channel": channel_id,
            "blocks": blocks,
            "text": message[:150],  # Fallback text for notifications
        }
        if thread_ts:
            payload["thread_ts"] = thread_ts

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {bot_token}"},
                json=payload,
            )
            data = resp.json()
            if not data.get("ok"):
                raise RuntimeError(f"Slack API error: {data.get('error')}")
            return data

    if webhook_url:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                webhook_url,
                json={"blocks": blocks, "text": message[:150]},
            )
            if resp.status_code != 200:
                raise RuntimeError(f"Slack webhook failed: {resp.status_code}")
            return {"ok": True, "via": "webhook"}

    raise RuntimeError("No Slack bot token or webhook configured on this channel")