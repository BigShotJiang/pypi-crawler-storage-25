# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""In-app output — insert a message into the chat history."""

from __future__ import annotations

import logging
from typing import Any

from supabase import create_client

from app.config import get_settings

logger = logging.getLogger(__name__)


def _get_supabase():
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


async def deliver_inapp(
    company_id: str,
    message: str,
    severity: str = "info",
) -> dict[str, Any]:
    """Insert an agent message into chat_messages so it appears in the chat.

    This is used for outbound notifications that should surface in the
    user's chat history (e.g. "Good morning — here's what happened overnight").
    """
    sb = _get_supabase()

    content: dict[str, Any] = {
        "type": "text",
        "text": message,
    }

    metadata: dict[str, Any] = {
        "source": "outbound",
        "severity": severity,
    }

    result = sb.table("chat_messages").insert({
        "company_id": company_id,
        "role": "agent",
        "content": content,
        "metadata": metadata,
    }).execute()

    if not result.data:
        raise RuntimeError("Failed to insert in-app message")

    return result.data[0]


async def deliver_inapp_card(
    company_id: str,
    content: dict[str, Any],
) -> dict[str, Any]:
    """Insert a structured card (e.g. insight_card) into chat_messages."""
    sb = _get_supabase()

    result = sb.table("chat_messages").insert({
        "company_id": company_id,
        "role": "agent",
        "content": content,
        "metadata": {"source": "outbound"},
    }).execute()

    if not result.data:
        raise RuntimeError("Failed to insert in-app card")

    return result.data[0]