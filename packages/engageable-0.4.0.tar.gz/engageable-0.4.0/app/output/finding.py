# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class MetricSnapshot:
    name: str
    current_value: float
    previous_value: float | None = None
    change_percent: float | None = None


@dataclass
class Finding:
    summary: str
    severity: str = "info"
    metrics: list[MetricSnapshot] = field(default_factory=list)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    context: str = ""
    recommendation: str = ""
    methodology: str = ""
    data_sources: list[str] = field(default_factory=list)
    skill_runs: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    analysis_run_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "summary": self.summary,
            "severity": self.severity,
            "metrics": [
                {
                    "name": m.name,
                    "current_value": m.current_value,
                    "previous_value": m.previous_value,
                    "change_percent": m.change_percent,
                }
                for m in self.metrics
            ],
            "evidence": self.evidence,
            "context": self.context,
            "recommendation": self.recommendation,
            "methodology": self.methodology,
            "data_sources": self.data_sources,
            "skill_runs": self.skill_runs,
            "analysis_run_id": self.analysis_run_id,
        }