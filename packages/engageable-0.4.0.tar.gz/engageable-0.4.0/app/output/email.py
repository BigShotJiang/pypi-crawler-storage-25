# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Email output — deliver messages via Resend API."""

from __future__ import annotations

import logging
import re
from typing import Any

import httpx

from app.config import get_settings

logger = logging.getLogger(__name__)

RESEND_API_URL = "https://api.resend.com/emails"

# Design tokens matching the app's dark theme
_BG = "#0a0a0f"
_BG_CARD = "#111118"
_BG_SUBTLE = "#1a1a24"
_BORDER = "#ffffff0d"  # white/5
_TEXT = "#ffffffe6"  # white/90
_TEXT_MUTED = "#ffffff66"  # white/40
_TEXT_DIM = "#ffffff40"  # white/25
_ACCENT = "#9b1a9b"  # hsl(303 84% 33%)
_ACCENT_LIGHT = "#c840c8"

_SEVERITY_COLORS = {
    "info": "#3B82F6",
    "warning": "#F59E0B",
    "critical": "#EF4444",
}


def _md_to_html(text: str) -> str:
    """Convert agent markdown text to HTML paragraphs with inline formatting."""
    # Process block-level first: split into paragraphs
    paragraphs = re.split(r'\n{2,}', text.strip())
    html_parts = []

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # Check if it's a markdown table
        lines = para.split('\n')
        if len(lines) >= 2 and '|' in lines[0] and re.match(r'^[\s|:-]+$', lines[1]):
            html_parts.append(_render_table(lines))
            continue

        # Check if it's a list
        if all(re.match(r'^[-*]\s', l.strip()) for l in lines if l.strip()):
            items = []
            for l in lines:
                l = l.strip()
                if l.startswith(('- ', '* ')):
                    items.append(f'<li style="color:{_TEXT};font-size:15px;line-height:1.6;padding:2px 0;">{_inline(l[2:])}</li>')
            html_parts.append(f'<ul style="margin:0 0 4px;padding-left:20px;">{"".join(items)}</ul>')
            continue

        # Regular paragraph — apply inline formatting
        inline = _inline(para.replace('\n', '<br>'))
        html_parts.append(f'<p style="margin:0 0 16px;color:{_TEXT};font-size:15px;line-height:1.6;">{inline}</p>')

    return ''.join(html_parts)


def _inline(text: str) -> str:
    """Apply inline markdown formatting: bold, italic, code, links."""
    # Bold: **text**
    text = re.sub(
        r'\*\*(.+?)\*\*',
        rf'<span style="display:inline-block;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:1px 6px;border-radius:4px;font-size:13px;font-weight:500;color:{_TEXT};">\1</span>',
        text,
    )
    # Inline code: `text`
    text = re.sub(
        r'`(.+?)`',
        rf'<code style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:1px 6px;border-radius:4px;font-size:13px;font-family:monospace;color:{_TEXT};">\1</code>',
        text,
    )
    # Links: [text](url)
    text = re.sub(
        r'\[(.+?)\]\((.+?)\)',
        rf'<a href="\2" style="color:{_ACCENT_LIGHT};text-decoration:none;">\1</a>',
        text,
    )
    return text


def _render_table(lines: list[str]) -> str:
    """Render a markdown table as an HTML table matching the app's dark style."""
    # Parse header
    headers = [c.strip() for c in lines[0].strip('|').split('|')]
    # Skip separator row (line 1)
    rows = []
    for line in lines[2:]:
        if line.strip():
            cells = [c.strip() for c in line.strip('|').split('|')]
            rows.append(cells)

    th_style = f'text-align:left;font-size:11px;color:{_TEXT_MUTED};text-transform:uppercase;letter-spacing:0.05em;font-weight:500;padding:10px 16px;'
    td_style = f'font-size:14px;color:{_TEXT};padding:10px 16px;'

    header_html = ''.join(f'<th style="{th_style}">{_inline(h)}</th>' for h in headers)
    rows_html = ''
    for row in rows:
        cells = ''.join(f'<td style="{td_style}">{_inline(c)}</td>' for c in row)
        rows_html += f'<tr style="border-bottom:1px solid rgba(255,255,255,0.03);">{cells}</tr>'

    return f'''<div style="margin:8px 0 16px;border-radius:12px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.015);overflow:hidden;">
      <table style="width:100%;border-collapse:collapse;">
        <thead style="border-bottom:1px solid rgba(255,255,255,0.06);"><tr>{header_html}</tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>'''


def _render_html(
    message: str,
    severity: str = "info",
    project_name: str | None = None,
    footer_links: dict[str, str] | None = None,
) -> str:
    """Render a dark-themed HTML email matching the Engageable chat UI.

    footer_links: optional dict with 'slow_down_url' and 'unsubscribe_url' keys
    for engagement email frequency control.
    """
    accent = _SEVERITY_COLORS.get(severity, _SEVERITY_COLORS["info"])
    body_html = _md_to_html(message)

    frequency_footer = ""
    if footer_links:
        slow_down = footer_links.get("slow_down_url", "")
        unsub = footer_links.get("unsubscribe_url", "")
        if slow_down and unsub:
            frequency_footer = f"""
      <p style="margin:12px 0 0;font-size:12px;color:{_TEXT_DIM};">
        Too many emails?
        <a href="{slow_down}" style="color:{_TEXT_MUTED};text-decoration:underline;">Slow down</a>
        or
        <a href="{unsub}" style="color:{_TEXT_MUTED};text-decoration:underline;">unsubscribe</a>.
      </p>"""

    return f"""\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Engageable</title>
</head>
<body style="margin:0;padding:0;background:{_BG};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',sans-serif;-webkit-font-smoothing:antialiased;">
  <div style="max-width:640px;margin:0 auto;padding:40px 20px;">

    <!--[if mso]><table width="640" align="center"><tr><td><![endif]-->

    <!-- Header -->
    <div style="padding:0 0 24px;">
      <span style="font-size:16px;font-weight:700;color:{_TEXT};letter-spacing:-0.01em;">Engageable</span>
      {f'<span style="font-size:12px;color:{_TEXT_DIM};margin-left:8px;">{project_name}</span>' if project_name else ''}
    </div>

    <!-- Severity accent bar -->
    <div style="height:2px;background:{accent};border-radius:1px;margin-bottom:24px;opacity:0.6;"></div>

    <!-- Message body -->
    <div style="background:{_BG_CARD};border:1px solid {_BORDER};border-radius:16px;padding:28px 24px;">
      {body_html}
    </div>

    <!-- Footer -->
    <div style="padding:24px 0 0;text-align:center;">
      <p style="margin:0 0 8px;font-size:12px;color:{_TEXT_DIM};">
        Sent by Engageable &middot; Your AI data analyst
      </p>
      <p style="margin:0;font-size:11px;color:{_TEXT_DIM};">
        <a href="{{{{settings_url}}}}" style="color:{_TEXT_DIM};text-decoration:underline;">Notification settings</a>
      </p>{frequency_footer}
    </div>

    <!--[if mso]></td></tr></table><![endif]-->

  </div>
</body>
</html>"""


async def deliver_email(
    channel: dict[str, Any],
    message: str,
    severity: str = "info",
    subject: str | None = None,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Deliver an email via Resend API.

    The channel dict must contain 'email_addresses' (list of strings).
    """
    settings = get_settings()
    api_key = settings.resend_api_key
    if not api_key:
        raise RuntimeError("RESEND_API_KEY not configured. Cannot send email.")

    addresses = channel.get("email_addresses") or []
    if not addresses:
        raise RuntimeError("No email addresses configured on this channel")

    if not subject:
        # Generate subject from first line of message
        first_line = message.split("\n")[0][:80].strip()
        # Strip markdown formatting from subject
        first_line = re.sub(r'\*\*(.+?)\*\*', r'\1', first_line)
        first_line = re.sub(r'`(.+?)`', r'\1', first_line)
        subject = first_line if first_line else "Update from Engageable"

    html = _render_html(message, severity, project_name=project_name)

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            RESEND_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "from": "Engageable <updates@engageable.io>",
                "to": addresses,
                "subject": subject,
                "html": html,
            },
        )
        if resp.status_code >= 400:
            raise RuntimeError(f"Resend API error {resp.status_code}: {resp.text}")
        return resp.json()


async def deliver_engagement_email(
    to_email: str,
    subject: str,
    body_markdown: str,
    slow_down_url: str,
    unsubscribe_url: str,
    project_name: str | None = None,
) -> dict[str, Any]:
    """Deliver an AI-composed engagement email to a single user.

    Includes frequency control footer with slow-down and unsubscribe links.
    """
    settings = get_settings()
    api_key = settings.resend_api_key
    if not api_key:
        raise RuntimeError("RESEND_API_KEY not configured. Cannot send email.")

    html = _render_html(
        body_markdown,
        severity="info",
        project_name=project_name,
        footer_links={
            "slow_down_url": slow_down_url,
            "unsubscribe_url": unsubscribe_url,
        },
    )

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            RESEND_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "from": "Engageable <updates@engageable.io>",
                "to": [to_email],
                "subject": subject,
                "html": html,
            },
        )
        if resp.status_code >= 400:
            raise RuntimeError(f"Resend API error {resp.status_code}: {resp.text}")
        return resp.json()