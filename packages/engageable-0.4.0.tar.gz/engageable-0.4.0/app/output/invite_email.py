# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Invite email — branded transactional email sent when a user is invited.

The email layout (header, pill, gradient bar, card, footer) is fixed to match
the Engageable front page. The *content* inside the card — subject, body text,
CTA label — is loaded from the ``email_templates`` table so admins can edit it
from the admin UI without touching code.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.config import get_settings

logger = logging.getLogger(__name__)

RESEND_API_URL = "https://api.resend.com/emails"

# Brand tokens (match src/index.css + Hero.tsx)
_BG = "#0a0a0f"
_BG_CARD = "#111118"
_BORDER = "rgba(255,255,255,0.05)"
_TEXT = "#ffffffee"
_TEXT_MUTED = "#ffffff99"
_TEXT_DIM = "#ffffff44"
_GRADIENT_START = "#b62d63"
_GRADIENT_END = "#a8307a"

# Fallback content if DB template has no body_html yet
_DEFAULT_BODY = (
    "You've been invited{{ company_line }} Engageable — your dedicated team of "
    "AI data analysts that crunch your data while you work on the fun stuff."
)
_DEFAULT_SUBJECT = "You've been invited to Engageable"
_DEFAULT_CTA = "Get Started"


def _interpolate(text: str, variables: dict[str, str]) -> str:
    """Replace {{ var }} placeholders with values."""
    for key, value in variables.items():
        text = text.replace("{{ " + key + " }}", value)
        text = text.replace("{{" + key + "}}", value)
    return text


def render_invite_html(
    *,
    user_email: str,
    inviter_name: str | None = None,
    company_name: str | None = None,
    login_url: str = "https://www.engageable.tech/login",
    template_overrides: dict[str, Any] | None = None,
) -> str:
    """Render a branded invitation email.

    ``template_overrides`` can supply ``subject``, ``body_html``, ``cta_text``,
    ``cta_url`` from the DB ``email_templates`` row. Any empty/missing fields
    fall back to hardcoded defaults.
    """
    tpl = template_overrides or {}

    invited_by = f" by {inviter_name}" if inviter_name else ""
    company_line = f" to join <strong>{company_name}</strong> on" if company_name else " to"

    variables = {
        "user_email": user_email,
        "inviter_name": inviter_name or "the team",
        "company_name": company_name or "your team",
        "login_url": login_url,
        "invited_by": invited_by,
        "company_line": company_line,
    }

    cta_text = tpl.get("cta_text") or _DEFAULT_CTA
    cta_url = tpl.get("cta_url") or login_url
    cta_url = _interpolate(cta_url, variables)

    cta_button_html = (
        f'<a href="{cta_url}" style="display:inline-block;padding:14px 36px;'
        f"background:linear-gradient(90deg,{_GRADIENT_START},{_GRADIENT_END});"
        f'color:#ffffff;font-size:16px;font-weight:600;text-decoration:none;'
        f'border-radius:8px;letter-spacing:-0.01em;">{cta_text}</a>'
    )

    variables["cta_button"] = cta_button_html

    body_raw = tpl.get("body_html") or _DEFAULT_BODY
    has_inline_cta = "cta_button" in body_raw and ("{{cta_button}}" in body_raw or "{{ cta_button }}" in body_raw)

    body_text = _interpolate(body_raw, variables)

    return f"""\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>You're invited to Engageable</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:{_BG};font-family:Roboto,-apple-system,BlinkMacSystemFont,'Segoe UI','Helvetica Neue',sans-serif;-webkit-font-smoothing:antialiased;">
  <div style="max-width:600px;margin:0 auto;padding:48px 24px;">

    <!--[if mso]><table width="600" align="center"><tr><td><![endif]-->

    <!-- Logo with asterisk -->
    <div style="text-align:center;padding-bottom:32px;">
      <span style="font-size:22px;font-weight:700;color:{_TEXT};letter-spacing:-0.02em;">
        <span style="color:{_GRADIENT_START};font-size:26px;vertical-align:middle;">&#10033;</span>
        Engageable
      </span>
    </div>

    <!-- Card -->
    <div style="background:{_BG_CARD};border:1px solid {_BORDER};border-radius:16px;padding:36px 32px;text-align:center;">

      <div style="margin:0 0 {'0' if has_inline_cta else '28px'};font-size:16px;line-height:1.7;color:{_TEXT_MUTED};">
        {body_text}
      </div>

      {'<!-- CTA placed inline via variable -->' if has_inline_cta else f"""<!-- CTA -->
      <a href="{cta_url}" style="display:inline-block;padding:14px 36px;background:linear-gradient(90deg,{_GRADIENT_START},{_GRADIENT_END});color:#ffffff;font-size:16px;font-weight:600;text-decoration:none;border-radius:8px;letter-spacing:-0.01em;">
        {cta_text}
      </a>

      <p style="margin:24px 0 0;font-size:13px;color:{_TEXT_DIM};line-height:1.5;">
        Sign in with <strong style="color:{_TEXT_MUTED};">{user_email}</strong> to get started.
      </p>"""}
    </div>

    <!-- Footer -->
    <div style="padding:28px 0 0;text-align:center;">
      <p style="margin:0 0 6px;font-size:12px;color:{_TEXT_DIM};">
        Engageable &middot; Agentic User Analytics &amp; Insights
      </p>
      <p style="margin:0;font-size:11px;color:{_TEXT_DIM};">
        If you didn't expect this invitation, you can safely ignore this email.
      </p>
    </div>

    <!--[if mso]></td></tr></table><![endif]-->

  </div>
</body>
</html>"""


async def _load_template(slug: str = "user-invite") -> dict[str, Any] | None:
    """Load an email template from the DB. Returns None if not found."""
    from supabase import create_client
    settings = get_settings()
    sb = create_client(settings.supabase_url, settings.supabase_service_role_key)
    result = sb.table("email_templates").select("*").eq("slug", slug).limit(1).execute()
    return result.data[0] if result.data else None


async def send_invite_email(
    *,
    to_email: str,
    inviter_name: str | None = None,
    company_name: str | None = None,
    login_url: str = "https://www.engageable.tech/login",
) -> dict:
    """Send an invitation email via Resend, using DB template for content."""
    settings = get_settings()
    api_key = settings.resend_api_key
    if not api_key:
        raise RuntimeError("RESEND_API_KEY not configured. Cannot send invite email.")

    template = await _load_template("user-invite")

    subject = _DEFAULT_SUBJECT
    if template and template.get("subject"):
        variables = {
            "user_email": to_email,
            "inviter_name": inviter_name or "the team",
            "company_name": company_name or "your team",
        }
        subject = _interpolate(template["subject"], variables)

    html = render_invite_html(
        user_email=to_email,
        inviter_name=inviter_name,
        company_name=company_name,
        login_url=login_url,
        template_overrides=template,
    )

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            RESEND_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "from": "Engageable <hello@engageable.io>",
                "to": [to_email],
                "subject": subject,
                "html": html,
            },
        )
        if resp.status_code >= 400:
            raise RuntimeError(f"Resend API error {resp.status_code}: {resp.text}")
        return resp.json()