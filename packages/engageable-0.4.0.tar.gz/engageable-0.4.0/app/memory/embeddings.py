# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Embedding generation for semantic memory retrieval.

Uses OpenAI text-embedding-3-small (1536 dimensions).
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.config import get_settings

logger = logging.getLogger(__name__)

EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_DIMS = 1536


async def generate_embedding(text: str) -> list[float]:
    """Generate an embedding vector for the given text.

    Uses OpenAI's text-embedding-3-small model (1536 dims).
    Raises on failure — callers should handle or fall back.
    """
    settings = get_settings()
    api_key = settings.openai_api_key
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY not configured. Required for semantic memory embeddings."
        )

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            "https://api.openai.com/v1/embeddings",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": EMBEDDING_MODEL,
                "input": text[:8000],  # API limit safety
            },
        )
        resp.raise_for_status()
        data = resp.json()

    return data["data"][0]["embedding"]


async def generate_embeddings_batch(texts: list[str]) -> list[list[float]]:
    """Generate embeddings for multiple texts in one API call.

    OpenAI supports batch input — more efficient than individual calls.
    """
    settings = get_settings()
    api_key = settings.openai_api_key
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not configured.")

    # Truncate each text
    truncated = [t[:8000] for t in texts]

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(
            "https://api.openai.com/v1/embeddings",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": EMBEDDING_MODEL,
                "input": truncated,
            },
        )
        resp.raise_for_status()
        data = resp.json()

    # Sort by index to maintain order
    sorted_data = sorted(data["data"], key=lambda x: x["index"])
    return [item["embedding"] for item in sorted_data]