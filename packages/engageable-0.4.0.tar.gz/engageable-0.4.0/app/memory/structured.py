# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from app.config import get_settings
from app.output.finding import Finding

logger = logging.getLogger(__name__)


def _get_supabase():
    from supabase import create_client
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


async def save_finding(company_id: str, finding: Finding) -> str | None:
    """Persist a Finding to the findings table. Returns the finding ID."""
    try:
        client = _get_supabase()
        data = finding.to_dict()
        data["company_id"] = company_id
        data["metrics"] = json.loads(json.dumps(data["metrics"]))
        data["evidence"] = json.loads(json.dumps(data["evidence"]))

        result = client.table("findings").insert(data).execute()
        if result.data:
            return result.data[0]["id"]
        return None
    except Exception:
        logger.exception("Failed to save finding")
        return None


async def start_analysis_run(
    company_id: str,
    question: str,
    trigger: str = "api",
) -> str | None:
    """Create an analysis_runs record. Returns the run ID."""
    try:
        client = _get_supabase()
        result = client.table("analysis_runs").insert({
            "company_id": company_id,
            "trigger_source": trigger,
            "question": question,
            "status": "running",
        }).execute()
        if result.data:
            return result.data[0]["id"]
        return None
    except Exception:
        logger.exception("Failed to start analysis run")
        return None


async def complete_analysis_run(
    run_id: str,
    answer: str,
    status: str = "completed",
    error: str | None = None,
) -> None:
    """Mark an analysis run as completed or failed."""
    try:
        client = _get_supabase()
        update: dict[str, Any] = {
            "status": status,
            "answer": answer,
            "completed_at": datetime.utcnow().isoformat(),
        }
        if error:
            update["error_message"] = error
        client.table("analysis_runs").update(update).eq("id", run_id).execute()
    except Exception:
        logger.exception("Failed to complete analysis run %s", run_id)


async def get_recent_findings(
    company_id: str,
    limit: int = 10,
) -> list[dict[str, Any]]:
    """Fetch recent findings for a company."""
    try:
        client = _get_supabase()
        result = (
            client.table("findings")
            .select("*")
            .eq("company_id", company_id)
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        return result.data or []
    except Exception:
        logger.exception("Failed to fetch findings")
        return []