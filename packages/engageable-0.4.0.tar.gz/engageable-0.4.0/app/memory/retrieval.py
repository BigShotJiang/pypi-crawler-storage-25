# Copyright 2025-2026 Brightspeed AB
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/engageable-tech/engageable-mcp/blob/main/LICENSE
#
# Change Date: 2029-03-26
# Change License: Apache License, Version 2.0

"""Semantic memory retrieval — cosine similarity search via pgvector."""

from __future__ import annotations

import logging
from typing import Any

from app.config import get_settings
from app.memory.embeddings import generate_embedding

logger = logging.getLogger(__name__)


def _get_supabase():
    from supabase import create_client
    settings = get_settings()
    return create_client(settings.supabase_url, settings.supabase_service_role_key)


async def retrieve_relevant_memories(
    company_id: str,
    query: str,
    top_k: int = 20,
) -> list[dict[str, Any]]:
    """Retrieve the most relevant memories for a query using cosine similarity.

    Falls back to loading all memories if embedding generation fails or
    no embeddings exist yet.
    """
    try:
        query_embedding = await generate_embedding(query)
    except Exception as exc:
        logger.warning("Embedding generation failed, falling back to all memories: %s", exc)
        return _load_all_memories(company_id)

    try:
        sb = _get_supabase()
        # Use pgvector's cosine distance operator via RPC
        # The <=> operator returns cosine distance (1 - cosine_similarity)
        result = sb.rpc(
            "match_agent_memories",
            {
                "p_company_id": company_id,
                "p_embedding": query_embedding,
                "p_match_count": top_k,
            },
        ).execute()

        if result.data:
            return result.data

        # If RPC doesn't exist yet or returns empty, fall back
        logger.info("match_agent_memories RPC returned no results, falling back")
        return _load_all_memories(company_id)

    except Exception as exc:
        logger.warning("Semantic retrieval failed, falling back: %s", exc)
        return _load_all_memories(company_id)


def _load_all_memories(company_id: str, limit: int = 50) -> list[dict[str, Any]]:
    """Fallback: load all memories without semantic filtering."""
    sb = _get_supabase()
    result = sb.table("agent_memory").select("category, content").eq(
        "company_id", company_id
    ).order("created_at", desc=False).limit(limit).execute()
    return result.data or []


async def store_memory_with_embedding(
    company_id: str,
    content: str,
    category: str = "general",
) -> str | None:
    """Save a memory and generate its embedding.

    Returns the memory ID or None on failure.
    """
    from app.memory.embeddings import generate_embedding

    sb = _get_supabase()

    # Insert the memory first
    row: dict[str, Any] = {
        "company_id": company_id,
        "category": category,
        "content": content,
    }

    # Try to generate embedding
    try:
        embedding = await generate_embedding(content)
        row["embedding"] = embedding
    except Exception as exc:
        logger.warning("Failed to generate embedding for memory, saving without: %s", exc)

    result = sb.table("agent_memory").insert(row).execute()
    if result.data:
        return result.data[0]["id"]
    return None


async def backfill_embeddings(company_id: str | None = None) -> dict[str, int]:
    """Generate embeddings for memories that don't have them yet.

    Returns counts of processed, succeeded, and failed.
    """
    from app.memory.embeddings import generate_embeddings_batch

    sb = _get_supabase()
    query = sb.table("agent_memory").select("id, content").is_("embedding", "null")
    if company_id:
        query = query.eq("company_id", company_id)

    result = query.limit(500).execute()
    rows = result.data or []

    if not rows:
        return {"total": 0, "succeeded": 0, "failed": 0}

    # Process in batches of 50
    batch_size = 50
    succeeded = 0
    failed = 0

    for i in range(0, len(rows), batch_size):
        batch = rows[i:i + batch_size]
        texts = [r["content"] for r in batch]

        try:
            embeddings = await generate_embeddings_batch(texts)
            for row, embedding in zip(batch, embeddings):
                sb.table("agent_memory").update(
                    {"embedding": embedding}
                ).eq("id", row["id"]).execute()
                succeeded += 1
        except Exception as exc:
            logger.warning("Batch embedding failed: %s", exc)
            failed += len(batch)

    return {"total": len(rows), "succeeded": succeeded, "failed": failed}