"""Tests for the CohortRetentionSkill."""

import pandas as pd
import pytest

from engageable.skills.analysis.cohort_retention import CohortRetentionSkill


@pytest.fixture
def skill():
    return CohortRetentionSkill()


# --- Aggregated input mode ----------------------------------------------------


@pytest.mark.asyncio
async def test_perfect_retention(skill):
    """All periods retain every user → retention rates are 1.0."""
    data = {
        "columns": ["cohort", "period", "users"],
        "rows": [
            ["Jan", 0, 100],
            ["Jan", 1, 100],
            ["Jan", 2, 100],
            ["Feb", 0, 80],
            ["Feb", 1, 80],
            ["Feb", 2, 80],
        ],
    }
    result = await skill.execute({
        "data": data,
        "cohort_col": "cohort",
        "period_col": "period",
        "user_count_col": "users",
    })
    assert result.success is True

    matrix = result.data["retention_matrix"]
    for cohort in matrix.values():
        for period, rate in cohort.items():
            assert rate == 1.0, f"Expected 1.0 retention, got {rate}"


@pytest.mark.asyncio
async def test_zero_retention(skill):
    """Users only appear in period 0 → subsequent periods have 0.0 retention."""
    data = {
        "columns": ["cohort", "period", "users"],
        "rows": [
            ["Jan", 0, 100],
            ["Jan", 1, 0],
            ["Jan", 2, 0],
            ["Feb", 0, 80],
            ["Feb", 1, 0],
            ["Feb", 2, 0],
        ],
    }
    result = await skill.execute({
        "data": data,
        "cohort_col": "cohort",
        "period_col": "period",
        "user_count_col": "users",
    })
    assert result.success is True

    matrix = result.data["retention_matrix"]
    for cohort_data in matrix.values():
        for period, rate in cohort_data.items():
            if int(period) == 0:
                assert rate == 1.0
            else:
                assert rate == 0.0


@pytest.mark.asyncio
async def test_known_triangle(skill):
    """Verify exact retention rates for a hand-crafted triangle."""
    data = {
        "columns": ["cohort", "period", "users"],
        "rows": [
            ["Jan", 0, 100],
            ["Jan", 1, 50],
            ["Jan", 2, 25],
            ["Feb", 0, 80],
            ["Feb", 1, 40],
            # Feb period 2 is missing (NaN)
            ["Mar", 0, 60],
            # Mar period 1 and 2 are missing
        ],
    }
    result = await skill.execute({
        "data": data,
        "cohort_col": "cohort",
        "period_col": "period",
        "user_count_col": "users",
    })
    assert result.success is True

    matrix = result.data["retention_matrix"]

    # Jan: P0 = 1.0, P1 = 50/100 = 0.5, P2 = 25/100 = 0.25
    assert matrix["Jan"]["0"] == 1.0
    assert matrix["Jan"]["1"] == 0.5
    assert matrix["Jan"]["2"] == 0.25

    # Feb: P0 = 1.0, P1 = 40/80 = 0.5
    assert matrix["Feb"]["0"] == 1.0
    assert matrix["Feb"]["1"] == 0.5
    assert "2" not in matrix["Feb"]  # not present because it was NaN


@pytest.mark.asyncio
async def test_single_cohort(skill):
    """All users in one cohort → exactly one cohort in output."""
    data = {
        "columns": ["cohort", "period", "users"],
        "rows": [
            ["Jan", 0, 50],
            ["Jan", 1, 30],
            ["Jan", 2, 10],
        ],
    }
    result = await skill.execute({
        "data": data,
        "cohort_col": "cohort",
        "period_col": "period",
        "user_count_col": "users",
    })
    assert result.success is True
    assert result.data["num_cohorts"] == 1


# --- Raw events mode ----------------------------------------------------------


@pytest.mark.asyncio
async def test_raw_events_mode(skill):
    """Build retention from raw (user_id, event_date) pairs."""
    # User 1: events on day 1 and day 8 (week 0 and 1)
    # User 2: event on day 1 only (week 0)
    # User 3: events on day 1, day 8, day 15 (week 0, 1, 2)
    data = {
        "columns": ["user_id", "event_date"],
        "rows": [
            ["u1", "2025-01-01"],
            ["u1", "2025-01-08"],
            ["u2", "2025-01-01"],
            ["u3", "2025-01-01"],
            ["u3", "2025-01-08"],
            ["u3", "2025-01-15"],
        ],
    }
    result = await skill.execute({
        "data": data,
        "user_id_col": "user_id",
        "event_date_col": "event_date",
        "period_unit": "week",
    })
    assert result.success is True
    assert result.data["num_cohorts"] == 1

    # All 3 users started in the same cohort week → period 0 retention = 1.0
    matrix = result.data["retention_matrix"]
    cohort_key = list(matrix.keys())[0]
    assert matrix[cohort_key]["0"] == 1.0
