import pytest
from engageable.skills.analysis.bayesian_ab import BayesianABSkill


@pytest.fixture
def skill():
    return BayesianABSkill()


@pytest.mark.asyncio
async def test_clear_winner(skill):
    result = await skill.execute({
        "control_successes": 100,
        "control_trials": 1000,
        "variant_successes": 150,
        "variant_trials": 1000,
    })
    assert result.success is True
    assert result.data["probability_variant_better"] > 0.95


@pytest.mark.asyncio
async def test_clear_loser(skill):
    result = await skill.execute({
        "control_successes": 150,
        "control_trials": 1000,
        "variant_successes": 100,
        "variant_trials": 1000,
    })
    assert result.success is True
    assert result.data["probability_variant_better"] < 0.05


@pytest.mark.asyncio
async def test_identical_groups(skill):
    result = await skill.execute({
        "control_successes": 100,
        "control_trials": 1000,
        "variant_successes": 100,
        "variant_trials": 1000,
    })
    assert result.success is True
    assert 0.45 <= result.data["probability_variant_better"] <= 0.55


@pytest.mark.asyncio
async def test_small_sample(skill):
    result = await skill.execute({
        "control_successes": 1,
        "control_trials": 10,
        "variant_successes": 2,
        "variant_trials": 10,
    })
    assert result.success is True
    ci = result.data["credible_interval_95"]
    span = ci[1] - ci[0]
    assert span > 0.5


@pytest.mark.asyncio
async def test_zero_conversions(skill):
    result = await skill.execute({
        "control_successes": 0,
        "control_trials": 1000,
        "variant_successes": 5,
        "variant_trials": 1000,
    })
    assert result.success is True


@pytest.mark.asyncio
async def test_successes_exceed_trials(skill):
    result = await skill.execute({
        "control_successes": 200,
        "control_trials": 100,
        "variant_successes": 50,
        "variant_trials": 100,
    })
    assert result.success is False


@pytest.mark.asyncio
async def test_zero_trials(skill):
    result = await skill.execute({
        "control_successes": 0,
        "control_trials": 0,
        "variant_successes": 50,
        "variant_trials": 100,
    })
    assert result.success is False


@pytest.mark.asyncio
async def test_deterministic(skill):
    params = {
        "control_successes": 100,
        "control_trials": 1000,
        "variant_successes": 120,
        "variant_trials": 1000,
    }
    result1 = await skill.execute(params)
    result2 = await skill.execute(params)
    assert result1.success is True
    assert result2.success is True
    assert result1.data["probability_variant_better"] == result2.data["probability_variant_better"]
