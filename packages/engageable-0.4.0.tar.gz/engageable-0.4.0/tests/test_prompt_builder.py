"""Tests for prompt builder: mode detection and system prompt assembly."""

import pytest
from unittest.mock import MagicMock

from app.prompts.builder import detect_mode, build_system_prompt


# ---------------------------------------------------------------------------
# detect_mode — pure function, no mocking
# ---------------------------------------------------------------------------

def test_no_project():
    assert detect_mode(project=None, connections=[]) == "onboarding"


def test_no_connections():
    assert detect_mode(project={"name": "Test"}, connections=[]) == "onboarding"


def test_exploring_connection():
    assert detect_mode(
        project={"name": "Test"},
        connections=[{"status": "authenticated"}],
    ) == "onboarding"


def test_all_ready():
    assert detect_mode(
        project={"name": "Test"},
        connections=[{"status": "ready"}],
    ) == "conversational"


def test_new_session_with_findings():
    assert detect_mode(
        project={"name": "Test"},
        connections=[{"status": "ready"}],
        recent_findings=[{"severity": "warning", "summary": "test"}],
        is_new_session=True,
    ) == "proactive"


def test_new_session_no_findings():
    assert detect_mode(
        project={"name": "Test"},
        connections=[{"status": "ready"}],
        recent_findings=[],
        is_new_session=True,
    ) == "conversational"


# ---------------------------------------------------------------------------
# build_system_prompt — needs get_registry mock
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_registry(mocker):
    """Mock get_registry so build_system_prompt doesn't need real skills."""
    mock_reg = MagicMock()
    mock_reg.list_skills.return_value = []
    mocker.patch("app.prompts.builder.get_registry", return_value=mock_reg)
    return mock_reg


def test_includes_project_name(mock_registry):
    result = build_system_prompt(
        project={"name": "Acme Corp"},
        connections=[{"status": "ready", "provider": "ga4"}],
    )
    assert "Acme Corp" in result


def test_data_quality_warning_included(mock_registry):
    result = build_system_prompt(
        project={"name": "Test"},
        connections=[{"status": "ready", "provider": "ga4"}],
        data_quality_results={
            "overall_status": "warning",
            "checks": [
                {"check": "freshness", "status": "warning", "detail": "test warning", "connector": "ga4"},
            ],
        },
    )
    assert "Data Quality Warnings" in result


def test_no_quality_section_when_pass(mock_registry):
    result = build_system_prompt(
        project={"name": "Test"},
        connections=[{"status": "ready", "provider": "ga4"}],
        data_quality_results={
            "overall_status": "pass",
            "checks": [],
        },
    )
    assert "Data Quality Warnings" not in result


def test_memories_rendered(mock_registry):
    result = build_system_prompt(
        project={"name": "Test"},
        connections=[{"status": "ready", "provider": "ga4"}],
        memories=[{"category": "goal", "content": "Increase signups by 20%"}],
    )
    assert "Things you know about this business" in result
    assert "Increase signups by 20%" in result
