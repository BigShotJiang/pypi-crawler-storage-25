import pytest
from engageable.skills.analysis.data_quality import DataQualitySkill


@pytest.fixture
def skill():
    return DataQualitySkill()


@pytest.mark.asyncio
async def test_no_connections(skill):
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [],
    })
    assert result.success is True
    assert result.data["overall_status"] == "pass"
    assert result.data["checks"] == []


@pytest.mark.asyncio
async def test_non_ready_connection(skill):
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "ga4", "status": "exploring", "config": {}, "credentials": {}},
        ],
    })
    assert result.success is True
    checks = result.data["checks"]
    assert len(checks) == 1
    assert checks[0]["status"] == "warning"
    assert "exploring" in checks[0]["detail"]


@pytest.mark.asyncio
async def test_unknown_provider(skill):
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "unknown_db", "status": "ready", "config": {}, "credentials": {}},
        ],
    })
    assert result.success is True
    checks = result.data["checks"]
    assert len(checks) == 1
    assert checks[0]["status"] == "warning"
    assert "No quality checks implemented" in checks[0]["detail"]


@pytest.mark.asyncio
async def test_overall_status_warning(skill, mocker):
    mocker.patch.object(DataQualitySkill, "_check_ga4", return_value=[
        {"check": "freshness", "status": "pass", "detail": "OK", "connector": "ga4"},
        {"check": "volume_sanity", "status": "warning", "detail": "Volume dropped", "connector": "ga4"},
    ])
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "ga4", "status": "ready", "config": {"property_id": "123"}, "credentials": {}},
        ],
    })
    assert result.success is True
    assert result.data["overall_status"] == "warning"


@pytest.mark.asyncio
async def test_overall_status_fail(skill, mocker):
    mocker.patch.object(DataQualitySkill, "_check_ga4", return_value=[
        {"check": "freshness", "status": "pass", "detail": "OK", "connector": "ga4"},
        {"check": "volume_sanity", "status": "fail", "detail": "Zero users", "connector": "ga4"},
    ])
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "ga4", "status": "ready", "config": {"property_id": "123"}, "credentials": {}},
        ],
    })
    assert result.success is True
    assert result.data["overall_status"] == "fail"


@pytest.mark.asyncio
async def test_all_pass(skill, mocker):
    mocker.patch.object(DataQualitySkill, "_check_ga4", return_value=[
        {"check": "freshness", "status": "pass", "detail": "OK", "connector": "ga4"},
        {"check": "volume_sanity", "status": "pass", "detail": "Stable", "connector": "ga4"},
    ])
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "ga4", "status": "ready", "config": {"property_id": "123"}, "credentials": {}},
        ],
    })
    assert result.success is True
    assert result.data["overall_status"] == "pass"


@pytest.mark.asyncio
async def test_ga4_no_property_id(skill):
    result = await skill.execute({
        "company_id": "test-co",
        "connections": [
            {"provider": "ga4", "status": "ready", "config": {}, "credentials": {}},
        ],
    })
    assert result.success is True
    checks = result.data["checks"]
    assert len(checks) == 1
    assert checks[0]["status"] == "fail"
    assert "No property_id configured" in checks[0]["detail"]
