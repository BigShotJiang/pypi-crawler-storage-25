"""Tests for the SegmentComparisonSkill."""

import pytest

from engageable.skills.analysis.segment_comparison import SegmentComparisonSkill


@pytest.fixture
def skill():
    return SegmentComparisonSkill()


def _seg_data(rows):
    """Shortcut to build {columns, rows} for segment data."""
    return {
        "columns": ["country", "sessions"],
        "rows": rows,
    }


# --- Contribution analysis ----------------------------------------------------


@pytest.mark.asyncio
async def test_one_segment_drives_change(skill):
    """Only segment A changes → its contribution should be ~100%."""
    baseline = _seg_data([["A", 100], ["B", 100]])
    current = _seg_data([["A", 200], ["B", 100]])

    result = await skill.execute({
        "current_data": current,
        "baseline_data": baseline,
        "dimension_col": "country",
        "metric_col": "sessions",
    })
    assert result.success is True

    segments = {s["segment"]: s for s in result.data["segments"]}
    assert abs(segments["A"]["contribution_pct"] - 100.0) < 1.0


@pytest.mark.asyncio
async def test_equal_change(skill):
    """Both segments grow by +50% → each contributes ~50% of overall change."""
    baseline = _seg_data([["A", 100], ["B", 100]])
    current = _seg_data([["A", 150], ["B", 150]])

    result = await skill.execute({
        "current_data": current,
        "baseline_data": baseline,
        "dimension_col": "country",
        "metric_col": "sessions",
    })
    assert result.success is True

    segments = {s["segment"]: s for s in result.data["segments"]}
    assert abs(segments["A"]["contribution_pct"] - 50.0) < 1.0
    assert abs(segments["B"]["contribution_pct"] - 50.0) < 1.0


# --- Appearing / disappearing segments ----------------------------------------


@pytest.mark.asyncio
async def test_new_segment_appears(skill):
    """Segment B appears in current but not in baseline → baseline_value = 0."""
    baseline = _seg_data([["A", 100]])
    current = _seg_data([["A", 100], ["B", 50]])

    result = await skill.execute({
        "current_data": current,
        "baseline_data": baseline,
        "dimension_col": "country",
        "metric_col": "sessions",
    })
    assert result.success is True

    segments = {s["segment"]: s for s in result.data["segments"]}
    assert segments["B"]["baseline_value"] == 0
    assert segments["B"]["current_value"] == 50


@pytest.mark.asyncio
async def test_segment_disappears(skill):
    """Segment B in baseline but gone from current → current_value = 0."""
    baseline = _seg_data([["A", 100], ["B", 50]])
    current = _seg_data([["A", 100]])

    result = await skill.execute({
        "current_data": current,
        "baseline_data": baseline,
        "dimension_col": "country",
        "metric_col": "sessions",
    })
    assert result.success is True

    segments = {s["segment"]: s for s in result.data["segments"]}
    assert segments["B"]["current_value"] == 0


# --- Edge case: zero baseline -------------------------------------------------


@pytest.mark.asyncio
async def test_zero_baseline(skill):
    """All baseline values are zero → division-by-zero handled gracefully."""
    baseline = _seg_data([["A", 0], ["B", 0]])
    current = _seg_data([["A", 50], ["B", 30]])

    result = await skill.execute({
        "current_data": current,
        "baseline_data": baseline,
        "dimension_col": "country",
        "metric_col": "sessions",
    })
    assert result.success is True
    assert result.data["overall_change_pct"] == 0.0
