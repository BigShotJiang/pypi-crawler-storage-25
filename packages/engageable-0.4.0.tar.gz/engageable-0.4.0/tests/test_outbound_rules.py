"""Tests for outbound notification rule helpers."""

import pytest
from datetime import datetime, time as dt_time
from unittest.mock import MagicMock

from app.workflows.outbound import _is_in_quiet_hours, _severity_meets_threshold


def _mock_now_at(hour, minute=0):
    """Create a mock datetime that returns a specific time for .now()."""
    mock_dt = MagicMock(wraps=datetime)
    mock_now = MagicMock()
    mock_now.time.return_value = dt_time(hour, minute)
    mock_dt.now.return_value = mock_now
    return mock_dt


# ── _is_in_quiet_hours ──────────────────────────────────────────────


def test_inside_overnight_range(mocker):
    mocker.patch("app.workflows.outbound.datetime", _mock_now_at(23, 0))
    prefs = {
        "quiet_hours_start": "22:00",
        "quiet_hours_end": "07:00",
        "timezone": "UTC",
    }
    assert _is_in_quiet_hours(prefs) is True


def test_outside_overnight_range(mocker):
    mocker.patch("app.workflows.outbound.datetime", _mock_now_at(12, 0))
    prefs = {
        "quiet_hours_start": "22:00",
        "quiet_hours_end": "07:00",
        "timezone": "UTC",
    }
    assert _is_in_quiet_hours(prefs) is False


def test_non_overnight_range_inside(mocker):
    mocker.patch("app.workflows.outbound.datetime", _mock_now_at(12, 0))
    prefs = {
        "quiet_hours_start": "09:00",
        "quiet_hours_end": "17:00",
        "timezone": "UTC",
    }
    assert _is_in_quiet_hours(prefs) is True


def test_non_overnight_range_outside(mocker):
    mocker.patch("app.workflows.outbound.datetime", _mock_now_at(20, 0))
    prefs = {
        "quiet_hours_start": "09:00",
        "quiet_hours_end": "17:00",
        "timezone": "UTC",
    }
    assert _is_in_quiet_hours(prefs) is False


def test_no_prefs_set():
    assert _is_in_quiet_hours({}) is False


def test_invalid_timezone(mocker):
    mocker.patch(
        "app.workflows.outbound.datetime",
        _mock_now_at(23, 0),
    )
    prefs = {
        "quiet_hours_start": "22:00",
        "quiet_hours_end": "07:00",
        "timezone": "Invalid/Zone",
    }
    assert _is_in_quiet_hours(prefs) is False


# ── _severity_meets_threshold ───────────────────────────────────────


def test_info_below_warning():
    assert _severity_meets_threshold("info", "warning") is False


def test_critical_above_info():
    assert _severity_meets_threshold("critical", "info") is True


def test_warning_meets_warning():
    assert _severity_meets_threshold("warning", "warning") is True


def test_unknown_severity():
    assert _severity_meets_threshold("unknown", "warning") is False


def test_info_meets_info():
    assert _severity_meets_threshold("info", "info") is True


def test_critical_meets_critical():
    assert _severity_meets_threshold("critical", "critical") is True
