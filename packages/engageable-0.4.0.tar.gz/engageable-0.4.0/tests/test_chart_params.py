"""Tests for chart parameter resolution."""

import pytest
from app.services.chart_params import resolve_parameters


def test_single_placeholder():
    config = {"metric": "{{metric}}"}
    params = [{"key": "metric", "default": "users"}]
    result = resolve_parameters(config, params, overrides={"metric": "sessions"})
    assert result == {"metric": "sessions"}


def test_type_preservation():
    config = {"limit": "{{count}}"}
    params = [{"key": "count", "default": 10}]
    result = resolve_parameters(config, params)
    assert result == {"limit": 10}
    assert isinstance(result["limit"], int)


def test_mixed_string():
    config = {"q": "SELECT {{col}} FROM {{table}}"}
    params = [
        {"key": "col", "default": "users"},
        {"key": "table", "default": "analytics"},
    ]
    result = resolve_parameters(config, params)
    assert result == {"q": "SELECT users FROM analytics"}


def test_nested_config():
    config = {"a": {"b": "{{x}}"}}
    params = [{"key": "x", "default": 42}]
    result = resolve_parameters(config, params)
    assert result == {"a": {"b": 42}}


def test_list_values():
    config = {"items": ["{{a}}", "{{b}}"]}
    params = [
        {"key": "a", "default": 1},
        {"key": "b", "default": 2},
    ]
    result = resolve_parameters(config, params)
    assert result == {"items": [1, 2]}


def test_default_used():
    config = {"range": "{{period}}"}
    params = [{"key": "period", "default": "7d"}]
    result = resolve_parameters(config, params)
    assert result == {"range": "7d"}


def test_override_beats_default():
    config = {"range": "{{period}}"}
    params = [{"key": "period", "default": "7d"}]
    result = resolve_parameters(config, params, overrides={"period": "30d"})
    assert result == {"range": "30d"}


def test_unresolved_placeholder():
    config = {"x": "{{unknown}}"}
    params = []
    result = resolve_parameters(config, params)
    assert result == {"x": "{{unknown}}"}


def test_no_mutation():
    config = {"metric": "{{metric}}", "nested": {"val": "{{val}}"}}
    params = [
        {"key": "metric", "default": "users"},
        {"key": "val", "default": 99},
    ]
    original_config = {"metric": "{{metric}}", "nested": {"val": "{{val}}"}}
    resolve_parameters(config, params, overrides={"metric": "sessions"})
    assert config == original_config


def test_none_override_value():
    config = {"x": "{{val}}"}
    params = [{"key": "val", "default": "hello"}]
    result = resolve_parameters(config, params, overrides={"val": None})
    assert result == {"x": None}
