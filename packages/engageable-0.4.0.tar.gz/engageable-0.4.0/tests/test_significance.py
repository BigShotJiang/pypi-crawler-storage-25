import asyncio
import pytest
from engageable.skills.analysis.significance import SignificanceTestSkill


@pytest.fixture
def skill():
    return SignificanceTestSkill()


@pytest.mark.asyncio
async def test_significant_difference(skill):
    result = await skill.execute({
        "control_values": [10, 12, 11, 13, 10, 11, 12, 10, 11, 13,
                           10, 12, 11, 13, 10, 11, 12, 10, 11, 13,
                           10, 12, 11, 13, 10, 11, 12, 10, 11, 13],
        "variant_values": [20, 22, 21, 23, 20, 21, 22, 20, 21, 23,
                           20, 22, 21, 23, 20, 21, 22, 20, 21, 23,
                           20, 22, 21, 23, 20, 21, 22, 20, 21, 23],
    })
    assert result.success is True
    assert result.data["significant"] is True
    assert result.data["p_value"] < 0.001
    assert result.data["method_used"] == "Welch's t-test"


@pytest.mark.asyncio
async def test_no_significant_difference(skill):
    result = await skill.execute({
        "control_values": [10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9, 10.1,
                           10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9, 10.1,
                           10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9, 10.1],
        "variant_values": [10.0, 10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9,
                           10.0, 10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9,
                           10.0, 10.1, 10.2, 9.9, 10.0, 10.1, 9.8, 10.3, 10.0, 9.9],
    })
    assert result.success is True
    assert result.data["significant"] is False
    assert result.data["p_value"] > 0.05


@pytest.mark.asyncio
async def test_mann_whitney(skill):
    result = await skill.execute({
        "control_values": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "variant_values": [11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
        "method": "mann_whitney",
    })
    assert result.success is True
    assert result.data["significant"] is True
    assert result.data["method_used"] == "Mann-Whitney U test"


@pytest.mark.asyncio
async def test_too_few_values(skill):
    result = await skill.execute({
        "control_values": [1],
        "variant_values": [2],
    })
    assert result.success is False
    assert "at least 2" in result.error


@pytest.mark.asyncio
async def test_large_identical_samples(skill):
    """100 identical values per group → not significant, high p-value (or NaN which counts as not significant)."""
    import math
    values = [50.0] * 100
    result = await skill.execute({
        "control_values": values,
        "variant_values": values,
    })
    assert result.success is True
    assert result.data["significant"] is False
    # When all values are identical the t-test p-value may be NaN;
    # NaN is not < alpha so significant == False, which is correct.
    p = result.data["p_value"]
    assert p > 0.5 or math.isnan(p)


@pytest.mark.asyncio
async def test_one_group_all_zeros(skill):
    """Control all zeros, variant ascending — must not crash on effect_size division."""
    control = [0.0] * 30
    variant = [float(i) for i in range(1, 31)]
    result = await skill.execute({
        "control_values": control,
        "variant_values": variant,
    })
    assert result.success is True
