"""Tests for the ForecastSkill."""

import numpy as np
import pandas as pd
import pytest

from engageable.skills.analysis.forecast import ForecastSkill


@pytest.fixture
def skill():
    return ForecastSkill()


def _make_ts(n: int, value_fn):
    """Build a {columns, rows} dict with *n* daily data points."""
    dates = pd.date_range("2025-01-01", periods=n, freq="D")
    return {
        "columns": ["date", "sessions"],
        "rows": [
            [d.strftime("%Y-%m-%d"), value_fn(i)] for i, d in enumerate(dates)
        ],
    }


# --- Forecast direction -------------------------------------------------------


@pytest.mark.asyncio
async def test_linear_growth(skill):
    """Steadily increasing series → forecast continues upward."""
    data = _make_ts(120, lambda i: 10 + 2 * i)
    result = await skill.execute({"data": data})
    assert result.success is True

    forecast = result.data["forecast"]
    assert len(forecast) > 0
    last_historical = 10 + 2 * 119  # value at i=119
    last_forecast_value = forecast[-1]["value"]
    assert last_forecast_value > last_historical, (
        f"Forecast ({last_forecast_value}) should exceed last historical ({last_historical})"
    )


@pytest.mark.asyncio
async def test_flat_series(skill):
    """Constant series → forecast stays near the constant value."""
    data = _make_ts(120, lambda _: 50)
    result = await skill.execute({"data": data})
    assert result.success is True

    for point in result.data["forecast"]:
        assert abs(point["value"] - 50) <= 10, (
            f"Forecast value {point['value']} deviates too far from 50"
        )


# --- Edge cases ---------------------------------------------------------------


@pytest.mark.asyncio
async def test_short_series(skill):
    """Exactly 14 data points (the minimum) → still produces a forecast."""
    data = _make_ts(14, lambda i: 100 + i)
    result = await skill.execute({"data": data})
    assert result.success is True
    assert len(result.data["forecast"]) > 0


@pytest.mark.asyncio
async def test_too_few_rows(skill):
    data = _make_ts(1, lambda _: 42)
    with pytest.raises(ValueError):
        await skill.execute({"data": data})


# --- Confidence intervals -----------------------------------------------------


@pytest.mark.asyncio
async def test_confidence_intervals(skill):
    """Every forecast point must satisfy lower <= value <= upper."""
    data = _make_ts(120, lambda i: 50 + i * 0.5)
    result = await skill.execute({"data": data})
    assert result.success is True

    for point in result.data["forecast"]:
        assert point["lower"] <= point["value"] <= point["upper"], (
            f"CI violation: lower={point['lower']}, value={point['value']}, upper={point['upper']}"
        )
