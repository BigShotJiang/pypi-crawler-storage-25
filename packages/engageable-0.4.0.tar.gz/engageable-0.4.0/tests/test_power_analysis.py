import pytest
from engageable.skills.analysis.power_analysis import PowerAnalysisSkill


@pytest.fixture
def skill():
    return PowerAnalysisSkill()


@pytest.mark.asyncio
async def test_typical_case(skill):
    result = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.10,
    })
    assert result.success is True
    assert result.data["required_sample_per_group"] > 0
    assert result.data["total_sample_needed"] == result.data["required_sample_per_group"] * 2


@pytest.mark.asyncio
async def test_with_daily_traffic(skill):
    result = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.10,
        "daily_traffic": 1000,
    })
    assert result.success is True
    assert result.data["estimated_days"] is not None
    assert result.data["estimated_days"] > 0
    assert isinstance(result.data["estimated_days"], (int, float))


@pytest.mark.asyncio
async def test_large_mde_smaller_sample(skill):
    result_small_mde = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.10,
    })
    result_large_mde = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.50,
    })
    assert result_small_mde.success is True
    assert result_large_mde.success is True
    assert result_large_mde.data["required_sample_per_group"] < result_small_mde.data["required_sample_per_group"]


@pytest.mark.asyncio
async def test_baseline_zero(skill):
    result = await skill.execute({
        "baseline_rate": 0.0,
        "minimum_detectable_effect": 0.10,
    })
    assert result.success is False


@pytest.mark.asyncio
async def test_baseline_one(skill):
    result = await skill.execute({
        "baseline_rate": 1.0,
        "minimum_detectable_effect": 0.10,
    })
    assert result.success is False


@pytest.mark.asyncio
async def test_negative_mde(skill):
    result = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": -0.10,
    })
    assert result.success is False


@pytest.mark.asyncio
async def test_custom_alpha_power(skill):
    result_default = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.10,
    })
    result_strict = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.10,
        "alpha": 0.01,
        "power": 0.90,
    })
    assert result_default.success is True
    assert result_strict.success is True
    assert result_strict.data["required_sample_per_group"] > result_default.data["required_sample_per_group"]


@pytest.mark.asyncio
async def test_very_small_mde(skill):
    result = await skill.execute({
        "baseline_rate": 0.05,
        "minimum_detectable_effect": 0.01,
    })
    assert result.success is True
    assert result.data["required_sample_per_group"] > 100000
