"""Tests for the CorrelationSkill."""

import numpy as np
import pandas as pd
import pytest

from engageable.skills.analysis.correlation import CorrelationSkill


@pytest.fixture
def skill():
    return CorrelationSkill()


def _make_corr_data(n: int, fn_a, fn_b):
    """Build {columns, rows} with a date, metric_a, and metric_b."""
    dates = pd.date_range("2025-01-01", periods=n, freq="D")
    return {
        "columns": ["date", "metric_a", "metric_b"],
        "rows": [
            [d.strftime("%Y-%m-%d"), fn_a(i), fn_b(i)] for i, d in enumerate(dates)
        ],
    }


# --- Correlation strength -----------------------------------------------------


@pytest.mark.asyncio
async def test_perfect_positive(skill):
    data = _make_corr_data(50, lambda i: i + 1, lambda i: (i + 1) * 2)
    result = await skill.execute({
        "data": data,
        "metric_a": "metric_a",
        "metric_b": "metric_b",
    })
    assert result.success is True
    assert result.data["pearson_r"] > 0.99


@pytest.mark.asyncio
async def test_perfect_negative(skill):
    data = _make_corr_data(50, lambda i: i + 1, lambda i: -(i + 1))
    result = await skill.execute({
        "data": data,
        "metric_a": "metric_a",
        "metric_b": "metric_b",
    })
    assert result.success is True
    assert result.data["pearson_r"] < -0.99


@pytest.mark.asyncio
async def test_no_correlation(skill):
    rng = np.random.RandomState(42)
    random_values = rng.random(50).tolist()
    data = _make_corr_data(50, lambda i: i + 1, lambda i: random_values[i])
    result = await skill.execute({
        "data": data,
        "metric_a": "metric_a",
        "metric_b": "metric_b",
    })
    assert result.success is True
    assert abs(result.data["pearson_r"]) < 0.3


# --- Lag analysis -------------------------------------------------------------


@pytest.mark.asyncio
async def test_lagged_correlation(skill):
    """metric_b is metric_a shifted by 3 periods → best lag should capture the offset."""
    n = 50
    lag = 3
    # Use a signal with variation (sine wave) so the lag is detectable.
    rng = np.random.RandomState(99)
    a_values = [np.sin(i * 0.3) * 10 + 50 + rng.normal(0, 0.5) for i in range(n)]
    # metric_b is metric_a shifted right by 3 (first 3 values are noise)
    b_values = [50.0] * lag + a_values[:n - lag]

    dates = pd.date_range("2025-01-01", periods=n, freq="D")
    data = {
        "columns": ["date", "metric_a", "metric_b"],
        "rows": [
            [d.strftime("%Y-%m-%d"), round(a_values[i], 2), round(b_values[i], 2)]
            for i, d in enumerate(dates)
        ],
    }
    result = await skill.execute({
        "data": data,
        "metric_a": "metric_a",
        "metric_b": "metric_b",
        "max_lag": 7,
    })
    assert result.success is True
    # The best lag should be near 3 (positive or negative depending on direction)
    assert abs(abs(result.data["best_lag"]) - lag) <= 2, (
        f"Expected best lag near {lag}, got {result.data['best_lag']}"
    )
    assert abs(result.data["best_lag_r"]) > 0.7


# --- Validation errors --------------------------------------------------------


@pytest.mark.asyncio
async def test_missing_column(skill):
    """Requesting a column that doesn't exist raises ValueError with 'not found'."""
    dates = pd.date_range("2025-01-01", periods=50, freq="D")
    data = {
        "columns": ["date", "metric_a"],
        "rows": [[d.strftime("%Y-%m-%d"), i] for i, d in enumerate(dates)],
    }
    with pytest.raises(ValueError, match="not found"):
        await skill.execute({
            "data": data,
            "metric_a": "metric_a",
            "metric_b": "metric_b",
        })
