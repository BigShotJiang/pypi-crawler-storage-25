"""Tests for evaluation signal detection."""

import pytest
from unittest.mock import MagicMock

from app.services.eval_signals import (
    detect_corrective_follow_up,
    _cosine_similarity,
    CORRECTIVE_RE,
)


# ---------------------------------------------------------------------------
# _cosine_similarity — pure function, no mocking
# ---------------------------------------------------------------------------

def test_identical_vectors():
    assert _cosine_similarity([1, 0, 0], [1, 0, 0]) == pytest.approx(1.0)


def test_orthogonal_vectors():
    assert _cosine_similarity([1, 0], [0, 1]) == pytest.approx(0.0)


def test_zero_vector():
    assert _cosine_similarity([0, 0, 0], [1, 2, 3]) == pytest.approx(0.0)


def test_opposite_vectors():
    assert _cosine_similarity([1, 0], [-1, 0]) == pytest.approx(-1.0)


def test_similar_vectors():
    sim = _cosine_similarity([1, 2, 3], [1, 2, 4])
    assert sim > 0.95


# ---------------------------------------------------------------------------
# CORRECTIVE_RE — pure regex, no mocking
# ---------------------------------------------------------------------------

def test_matches_thats_wrong():
    assert CORRECTIVE_RE.search("that's wrong") is not None


def test_matches_i_meant():
    assert CORRECTIVE_RE.search("I meant weekly not monthly") is not None


def test_matches_try_again():
    assert CORRECTIVE_RE.search("try again with last month") is not None


def test_no_match_normal():
    assert CORRECTIVE_RE.search("Show me traffic for March") is None


def test_matches_actually():
    assert CORRECTIVE_RE.search("actually, use sessions not users") is not None


# ---------------------------------------------------------------------------
# detect_corrective_follow_up — needs Supabase mock
# ---------------------------------------------------------------------------

def test_corrective_inserts_evaluation(mocker):
    mock_sb = MagicMock()
    mock_sb.table.return_value.insert.return_value.execute.return_value = MagicMock(
        data=[{"id": "eval-1"}]
    )
    mocker.patch("app.services.eval_signals._get_supabase", return_value=mock_sb)

    result = detect_corrective_follow_up("co-1", "no that's wrong", "msg-1")
    assert result is True

    mock_sb.table.assert_called_with("evaluations")
    mock_sb.table.return_value.insert.assert_called_once()


def test_no_match_no_insert(mocker):
    mock_sb = MagicMock()
    mocker.patch("app.services.eval_signals._get_supabase", return_value=mock_sb)

    result = detect_corrective_follow_up("co-1", "Show me traffic", "msg-1")
    assert result is False

    mock_sb.table.return_value.insert.assert_not_called()
