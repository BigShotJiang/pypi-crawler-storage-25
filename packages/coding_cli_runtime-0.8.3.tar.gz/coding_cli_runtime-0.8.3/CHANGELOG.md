# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

## [0.8.3] - 2026-04-25

### Changed
- Added Copilot `gpt-5.5` to the packaged reasoning baseline with
  `low` / `medium` / `high` / `xhigh` `--reasoning-effort` support.

### Fixed
- Copilot failures from CAPI/model-service 500 responses are now classified as
  transient so callers with retry budgets retry the CLI process instead of
  failing after one attempt.

## [0.8.2] - 2026-04-24

### Changed
- Refreshed the packaged Codex model fallback catalog to the current
  `~/.codex/models_cache.json` snapshot, adding `gpt-5.5` and the latest
  `gpt-5.4-mini` / `codex-auto-review` entries while dropping stale retired
  Codex models from the hardcoded fallback.
- Codex provider specs now derive `default_model` from the highest-priority
  visible resolved catalog entry instead of pinning a stale `gpt-5.3-codex`
  default even when the live Codex CLI cache exposes newer models.
- Copilot preview execution no longer requests or models the CLI `--share`
  Markdown export. Stdout/stderr remain the only direct rendered-output
  fallback, and structured transcript JSONL remains the canonical transcript
  surface.
- Removed the preview `share_output_path` / `share_output_text` API fields
  from Copilot request/result and validation result objects.
- Transcript-facts metadata no longer advertises Copilot Markdown share
  exports as a current human-readable transcript sidecar.

## [0.8.1] - 2026-04-23

### Added
- Added a preview companion-asset bundle that ships with the package and can
  be inspected or exported with
  `python -m coding_cli_runtime.companion_assets show-manifest` and
  `python -m coding_cli_runtime.companion_assets export --dest ...`.
- Added a preview `install-codex-skill` helper that installs a thin
  Codex-compatible skill derived from the package-owned companion bundle,
  so downstream users can install package guidance without cloning this repo.

### Changed
- Documented the preview companion-asset install/export surface in the package
  README and docs index, while keeping the package-neutral bundle as the
  canonical source of truth for agent-framework-specific exports.

## [0.8.0] - 2026-04-23

### Added
- Added `derive_transcript_facts(...)`, `TranscriptFactsV1`, and the exported
  transcript-surface constants so callers can derive a small provider-agnostic
  facts view from Claude, Codex, Copilot, and Gemini transcripts without
  reimplementing provider-specific transcript parsers.

### Changed
- Copilot preview execution now treats stdout as the canonical output payload
  and preserves the share export as a sidecar, aligning parsed output with the
  same direct-response surface used by the other provider adapters.
- Transcript-facts parsing now treats structured transcripts as canonical when
  they exist and documents the preserved human-readable sidecars separately.
- Documented Copilot's stdout/share/transcript split in the package-owned
  Copilot knowledge notes and transcript-facts docs, including repo-sensitive
  probe guidance for fresh Copilot evidence runs.

### Fixed
- Codex fresh sessions no longer incorrectly require `output_schema_path`
  when callers intentionally use schema-less freeform execution, and the
  documented file-reference contract now matches the actual unsupported state.
- Gemini JSON extraction now skips malformed early brace candidates in favor
  of later valid JSON, making mixed prose + JSON outputs parse more reliably.

## [0.7.0] - 2026-04-19

### Added
- Added typed preview control-resolution surfaces:
  `ProviderControlResolution`, `UnsupportedControlMode`,
  `ControlDefaultSource`, and `resolve_provider_model_control_resolution(...)`.
- Added preview `validate_structured_output(...)` plus
  `StructuredValidationResult` for preserving parsed payloads, validation
  errors, and artifact/session paths when structured output is parseable but
  invalid.
- Added a Copilot structured/local-multimodal recipe under
  `docs/examples/copilot_structured_multimodal.md`.
- Added preview CLI session continuation support to the provider adapters for
  Claude, Copilot, Gemini, and Codex. Preview requests can now continue the
  latest same-workdir session or resume a specific `session_id` /
  `session_path`, and adapter results preserve the resolved continuation
  metadata.

### Changed
- Preview launch/result adapters for Claude, Codex, Copilot, and Gemini now
  expose typed `control_resolution` alongside existing launch/result data so
  callers can inspect requested, applied, ignored, defaulted, and unknown
  provider-control states.
- Codex preview execution can now opt into strict unsupported-control
  rejection for generic `model_controls` inputs instead of only recording
  ignored controls.
- Copilot preview launch metadata now reports known provider-default reasoning
  effort in `effective_controls` when no explicit effort was requested, and
  adaptive Claude preview results now distinguish unknown model defaults from
  the absence of a default.
- Preview provider adapters now expose typed continuation resolution on launch
  preview and execution results so callers can see whether a run started fresh
  or resumed a specific native CLI session.
- Codex preview continuation now uses the CLI's native `exec resume` flow with
  an explicit reduced contract: fresh runs may use native schema-enforced
  output, while resumed runs omit `output_schema_path` and rely on post-parse
  validation when callers still want validation.

### Fixed
- Claude failure classification now treats newer quota wording such as
  `You've hit your limit` and `usage limit` as `rate_limited` instead of
  falling through to `unknown`.
- Copilot fresh runs now preserve the provider-native session artifact for
  later `session_path` continuation instead of preferring mirrored transcript
  captures, and resumed read-only Codex runs no longer silently enable
  `--full-auto`.

## [0.6.0] - 2026-04-17

### Added
- Added Claude Code `claude-opus-4-7` to the package model catalog with
  model-specific reasoning metadata and support for
  `low` / `medium` / `high` / `xhigh` / `max` effort levels.
- Added Copilot `claude-opus-4.7` metadata to the packaged Copilot baseline
  with verified medium-only reasoning support.

### Changed
- Claude reasoning metadata is now model-specific instead of using one global
  effort policy. Claude 4.6 models expose
  `low` / `medium` / `high` / `max`, while Opus 4.7 additionally exposes
  `xhigh` and no longer advertises legacy fixed thinking-token budgets.
- Copilot model metadata now preserves model-specific supported reasoning
  efforts even when a model exposes a fixed default rather than an editable
  control, so callers can validate requests against package-owned facts.

### Fixed
- Copilot preview adapters now validate `reasoning_effort` against
  model-specific package metadata, so medium-only models like
  `claude-opus-4.7` reject unsupported values instead of silently passing
  them through.
- Clarified provider metadata provenance for generated command-builder inputs:
  Codex can follow the live local CLI cache, while Copilot continues to use
  the checked-in verified baseline because no equivalent stable local catalog
  is available.

## [0.5.1] - 2026-04-13

### Added
- The stable root package now makes the preview adapter namespace discoverable
  as `coding_cli_runtime.providers` via lazy module attribute access, so users
  inspecting the installed package can find the provider-aware runtime layer
  without importing it eagerly.
- Added preview ergonomic session lookup aliases under
  `coding_cli_runtime.providers`: `find_claude_session(...)`,
  `find_codex_session(...)`, `find_gemini_session(...)`, and
  `find_copilot_session(...)`.

### Changed
- Clarified the package API map across the root module and README so the
  stable core surface and preview adapter surface are easier to distinguish.
- Wildcard imports from the stable root no longer pull the preview `providers`
  namespace into caller scope, keeping the stable/preview boundary stricter.
- Documented the distinction between the stable low-level root
  `find_claude_session(...)` / `find_codex_session(...)` path helpers and the
  preview typed session lookup APIs under `coding_cli_runtime.providers`.

## [0.5.0] - 2026-04-13

### Added
- Preview provider-aware adapters under `coding_cli_runtime.providers` for
  Claude, Codex, Copilot, and Gemini. Each provider now exposes typed
  request/result APIs plus `run_raw()`, `run()`, `run_sync()`,
  `prepare_launch()`, `find_session()`, `get_conversation()`, and
  `parse_output()` helpers.
- Preview shared adapter types: `ProviderLaunchPreview`,
  `ProviderExecEvent`, `ProviderRawExecution`, and the thin
  `run_provider_exec()` / `run_provider_exec_sync()` cross-provider
  dispatcher.

### Changed
- The package now exposes a stable core API at `coding_cli_runtime` plus
  preview provider-aware adapters at `coding_cli_runtime.providers`.
- Provider-owned structured-output parsing, session discovery, conversation
  retrieval, launch preview, typed adapter events, and provider-specific
  recovery behavior are now available for all four supported providers.
- Exported `get_copilot_stream_choices()` from the top-level package so
  callers can derive Copilot stream controls from package metadata.

### Fixed
- Copilot adapter failure classification now preserves process-log-enriched
  detail on final attempts, and Copilot parsing falls back cleanly from
  unusable `--share` output to stdout when needed.
- Codex adapter failures now classify state-db/rollout issues and support the
  explicit ephemeral-retry recovery path exposed by the preview adapters.

## [0.4.1] - 2026-04-10

### Added
- `list_provider_ids()` — returns the list of supported provider IDs.

### Changed
- Headless launch helpers (`build_claude_headless_core`,
  `build_codex_headless_core`, `build_copilot_headless_core`,
  `build_gemini_headless_core`) now accept an optional `contract` parameter
  to skip redundant `get_provider_contract()` lookups when the caller already
  has a contract instance. Passing a contract for the wrong provider raises
  `ValueError`.

### Fixed
- `resolve_auth()` now stays aligned with package-owned provider metadata, so
  auth detection remains correct when provider definitions evolve.

## [0.4.0] - 2026-04-09

### Added
- `OutputContract`, `IoContract`, `SessionDiscoveryContract`,
  `DiagnosticsContract` sub-contracts on `ProviderContract`, with data
  populated for all four providers.
- `WorkspaceEnvVar` structured type with `name` + `value_source` semantics
  (replaces bare env-var name strings in `IoContract.workspace_env_vars`).
- `WorkspaceEnvValueSource` — closed vocabulary (`"execution_dir"` /
  `"workspace_root"`) for `WorkspaceEnvVar.value_source`.
- `resolve_workspace_env()` — turns `IoContract.workspace_env_vars` into a
  concrete env overlay from an execution directory.
- `resolve_session_search_paths()` — expands `SessionDiscoveryContract`
  roots into concrete host paths.
- `is_provider_installed()` — checks whether a provider CLI binary is on
  PATH.
- README sections: "Query provider I/O conventions" and "Common integration
  tasks" with copy-pasteable examples.
- `WorkspaceEnvVar` added to key-types table in README.

### Changed
- Gemini `session_glob` tightened from `"*.json"` to `"*/chats/session-*.json"`
  to match the real `tmp/{hash}/chats/session-*.json` layout.
- Claude `session_glob` tightened from `"*.jsonl"` to
  `"*/conversation.jsonl"` to match per-project subdirectory structure.

## [0.3.0] - 2026-04-09

### Added
- Per-provider headless launch helpers: `build_claude_headless_core()`,
  `build_codex_headless_core()`, `build_copilot_headless_core()`,
  `build_gemini_headless_core()`. These emit the standard non-interactive
  flags for each provider; callers append app-specific tails.
- Session log discovery section in README.
- API summary table in README.

### Changed
- `build_codex_exec_spec()` now delegates to `build_codex_headless_core()`.
  Existing `full_auto` and `skip_git_repo_check` behavior is preserved.
- README rewritten with task-oriented examples, `run_interactive_session`
  usage, `uv add` install, and API summary.

## [0.2.0] - 2026-04-08

### Added
- `ProviderContract` API — structured, nested metadata for all four provider
  CLIs (Claude, Codex, Gemini, Copilot). Composed of `AuthContract`,
  `PathContract`, `HeadlessContract`, `PromptTransport`, `ApprovalContract`,
  `SandboxContract`.
- `get_provider_contract(provider_id)` — returns structured contract for a
  provider.
- `build_env_overlay(contract, api_key, base_url)` — builds provider-specific
  env var overlay from contract metadata.
- `resolve_config_paths(contract, containerized)` — resolves host and container
  config directory paths.
- `render_prompt(transport, prompt)` — resolves prompt delivery into argv args +
  stdin text based on provider transport mode.
- `PromptPayload` dataclass for resolved prompt delivery.
- `resolve_auth()` — resolves provider auth status from environment.
- `__version__` attribute.
- `CONTRIBUTING.md` with development setup and quality checks.

### Changed
- `run_interactive_session()` observability kwargs (`job_name`, `phase_tag`)
  now have sensible defaults so callers don't need to supply them.
- `CliRunResult.command` type widened from `tuple[str, ...]` to `Sequence[str]`.
- Provider model catalogs resolved with three-tier fallback: user override
  file > live CLI discovery > hardcoded fallback.

### Fixed
- Copilot BYOK (`COPILOT_PROVIDER_API_KEY`) now discoverable via contract
  but not reported as "required" in `resolve_auth()` — BYOK is opt-in.

## [0.1.0] - 2026-04-07

### Added
- Provider metadata and controls for Claude, Codex, Copilot, and Gemini CLIs.
- Shared request/result contracts (`CliRunRequest`, `CliRunResult`, `CliLaunchSpec`).
- Schema loading and payload validation (`load_schema`, `validate_payload`).
- Synchronous and asynchronous subprocess execution helpers.
- Interactive session execution with transcript mirroring.
- Session log discovery and parsing utilities.
- Claude reasoning policy resolution.
- Log redaction helpers.
- Copilot reasoning log parsing and classification.
- PEP 561 `py.typed` markers for typed package support.
- Packaged JSON schemas and Copilot reasoning baseline data.
- Playground knowledge base with probing guides and experiment templates.
