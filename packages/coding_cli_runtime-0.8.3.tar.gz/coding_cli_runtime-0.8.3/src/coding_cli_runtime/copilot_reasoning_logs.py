"""Copilot reasoning/session and process-log parsing helpers."""

from __future__ import annotations

import json
import re
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .session_logs import normalize_path_str, scan_session_dir

SESSION_ID_RE = re.compile(r"\*\*Session ID:\*\*\s*`([^`]+)`")
DEFAULT_REASONING_RE = re.compile(r"defaultReasoningEffort=([A-Za-z0-9_-]+)")
DEFAULT_SESSION_LOOKBACK_SECONDS = 180.0


@dataclass(frozen=True)
class CopilotSessionState:
    session_id: str
    events_path: Path
    cwd: str


def _parse_json_object_from_offset(text: str, offset: int) -> dict[str, Any] | None:
    start = text.find("{", offset)
    if start < 0:
        return None
    try:
        parsed, _ = json.JSONDecoder().raw_decode(text[start:])
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, Mapping):
        return None
    return dict(parsed)


def _iter_json_objects(text: str) -> Iterator[Any]:
    decoder = json.JSONDecoder()
    cursor = 0
    while True:
        start = text.find("{", cursor)
        if start < 0:
            return
        try:
            parsed, end = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            cursor = start + 1
            continue
        yield parsed
        cursor = start + end


def extract_session_id(markdown_text: str) -> str | None:
    match = SESSION_ID_RE.search(markdown_text)
    return match.group(1) if match else None


def extract_final_request_options(log_text: str) -> dict[str, Any]:
    marker = "Final request options:"
    idx = log_text.find(marker)
    if idx >= 0:
        parsed = _parse_json_object_from_offset(log_text, idx)
        if parsed is not None:
            return parsed

    latest_properties: dict[str, Any] | None = None
    for parsed in _iter_json_objects(log_text):
        if not isinstance(parsed, Mapping):
            continue
        kind = parsed.get("kind")
        properties = parsed.get("properties")
        if (
            kind == "model_resolution_info"
            and isinstance(properties, Mapping)
            and (
                properties.get("reasoning_effort") is not None
                or properties.get("thinking_budget") is not None
            )
        ):
            latest_properties = dict(properties)
    return latest_properties or {}


def classify_reasoning_fields(options: Mapping[str, Any]) -> tuple[str, str, str, str]:
    reasoning_effort = options.get("reasoning_effort")
    thinking_budget = options.get("thinking_budget")
    if reasoning_effort is not None:
        value = str(reasoning_effort)
        return "reasoning_effort", value, value, ""
    if thinking_budget is not None:
        value = str(thinking_budget)
        return "thinking_budget", value, "", value
    return "none", "", "", ""


def extract_default_reasoning(log_text: str) -> str:
    match = DEFAULT_REASONING_RE.search(log_text)
    return match.group(1) if match else ""


def _extract_matching_session_state(
    events_path: Path,
    *,
    expected_workdir: str,
    max_lines: int = 40,
) -> CopilotSessionState | None:
    session_id = events_path.parent.name or ""
    if not session_id:
        return None
    try:
        with events_path.open("r", encoding="utf-8") as handle:
            for _ in range(max_lines):
                line = handle.readline()
                if not line:
                    break
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("type") != "session.start":
                    continue
                data = record.get("data")
                if not isinstance(data, Mapping):
                    continue
                context = data.get("context")
                if not isinstance(context, Mapping):
                    continue
                cwd = context.get("cwd")
                if not isinstance(cwd, str):
                    continue
                normalized = normalize_path_str(cwd)
                if normalized != expected_workdir:
                    continue
                return CopilotSessionState(
                    session_id=session_id,
                    events_path=events_path,
                    cwd=normalized,
                )
    except OSError:
        return None
    return None


def find_recent_session_for_workdir(
    workdir: str | Path,
    since_ts: float,
    *,
    session_root: Path | None = None,
    lookback_seconds: float = DEFAULT_SESSION_LOOKBACK_SECONDS,
    max_candidates: int = 400,
) -> CopilotSessionState | None:
    root = (
        Path(session_root)
        if session_root is not None
        else Path.home() / ".copilot" / "session-state"
    )
    normalized_workdir = normalize_path_str(str(Path(workdir).expanduser()))
    matches = scan_session_dir(
        root,
        glob_pattern="*/events.jsonl",
        since_ts=since_ts,
        mtime_buffer=lookback_seconds,
        max_candidates=max_candidates,
        extract_fn=lambda path: _extract_matching_session_state(
            path,
            expected_workdir=normalized_workdir,
        ),
    )
    if not matches:
        return None
    return matches[0][2]


def find_process_log_for_session(
    session_id: str,
    logs_dir: Path,
    *,
    max_candidates: int = 400,
) -> Path | None:
    if not session_id or not logs_dir.exists():
        return None

    candidates: list[tuple[float, Path]] = []
    for path in logs_dir.glob("process-*.log"):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        candidates.append((mtime, path))

    candidates.sort(key=lambda item: item[0], reverse=True)
    for _, path in candidates[:max_candidates]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if session_id in text:
            return path
    return None
