"""Minimal JSON-schema-like validation for shared runtime contracts."""

from __future__ import annotations

from typing import Any

from .json_io import load_packaged_json_object, packaged_resource_exists


class SchemaValidationError(ValueError):
    """Raised when payload validation against shared schema fails."""


def _schema_resource_name(schema_name: str) -> str:
    if not schema_name.endswith(".json"):
        schema_name = f"{schema_name}.json"
    return schema_name


def load_schema(schema_name: str) -> dict[str, Any]:
    resource_name = _schema_resource_name(schema_name)
    if not packaged_resource_exists("schemas", resource_name):
        raise FileNotFoundError(f"schema not found: schemas/{resource_name}")
    return load_packaged_json_object("schemas", resource_name)


def _python_type_matches(value: Any, expected_type: str) -> bool:
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return (isinstance(value, int) or isinstance(value, float)) and not isinstance(value, bool)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "null":
        return value is None
    if expected_type == "array":
        return isinstance(value, list)
    if expected_type == "boolean":
        return isinstance(value, bool)
    return True


def _allowed_types(prop_schema: dict[str, Any]) -> list[str]:
    type_field = prop_schema.get("type")
    if isinstance(type_field, str):
        return [type_field]
    if isinstance(type_field, list):
        return [item for item in type_field if isinstance(item, str)]
    return []


def validate_payload(payload: Any, schema_name: str) -> None:
    schema = load_schema(schema_name)
    if not isinstance(payload, dict):
        raise SchemaValidationError("payload must be an object")

    required = schema.get("required") or []
    for key in required:
        if key not in payload:
            raise SchemaValidationError(f"missing required field: {key}")

    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return

    for key, prop_schema in properties.items():
        if key not in payload:
            continue
        if not isinstance(prop_schema, dict):
            continue
        value = payload[key]
        allowed_types = _allowed_types(prop_schema)
        if allowed_types and not any(_python_type_matches(value, t) for t in allowed_types):
            raise SchemaValidationError(
                f"invalid type for field '{key}': "
                f"expected {allowed_types}, got {type(value).__name__}"
            )

        nested_required = prop_schema.get("required") or []
        if isinstance(value, dict) and isinstance(nested_required, list):
            for nested_key in nested_required:
                if nested_key not in value:
                    raise SchemaValidationError(f"missing required field: {key}.{nested_key}")

            nested_props = prop_schema.get("properties")
            if isinstance(nested_props, dict):
                for nested_key, nested_schema in nested_props.items():
                    if nested_key not in value or not isinstance(nested_schema, dict):
                        continue
                    nested_value = value[nested_key]
                    nested_types = _allowed_types(nested_schema)
                    if nested_types and not any(
                        _python_type_matches(nested_value, t) for t in nested_types
                    ):
                        raise SchemaValidationError(
                            "invalid type for field "
                            f"'{key}.{nested_key}': expected {nested_types}, "
                            f"got {type(nested_value).__name__}"
                        )
