"""Per-provider headless launch core helpers.

Each helper emits the standard headless launch args for its provider,
derived from ``ProviderContract.headless``. Consumers append their own
app-specific tails (tool restrictions, output paths, prompt, etc.).

These helpers are the canonical source for headless launch flag assembly
within ``coding_cli_runtime``. In-repo consumers (feather, codex_cli,
provider_contracts builder) delegate to them. App-generation provider
wrappers may still assemble flags directly when their command construction
is interleaved with consumer-specific logic (reasoning config, output
format, artifact paths).
"""

from __future__ import annotations

from .provider_contracts import ProviderContract, get_provider_contract


def _check_provider(contract: ProviderContract | None, expected: str) -> ProviderContract:
    """Resolve and validate contract matches the expected provider."""
    if contract is None:
        return get_provider_contract(expected)
    if contract.provider_id != expected:
        raise ValueError(f"Expected {expected!r} contract, got {contract.provider_id!r}")
    return contract


def build_claude_headless_core(
    model: str,
    *,
    binary: str | None = None,
    permission_mode: str | None = None,
    skip_permissions: bool = True,
    contract: ProviderContract | None = None,
) -> list[str]:
    """Build Claude headless launch core args.

    Returns args up to and including ``--model``. Does NOT include prompt,
    output format, tool restrictions, or other app-specific flags.
    """
    c = _check_provider(contract, "claude")
    h = c.headless
    cmd: list[str] = [binary or c.binary]
    cmd.extend(h.activation_args)
    if h.approval.permission_mode_flag:
        mode = permission_mode or h.approval.default_permission_mode
        if mode:
            cmd.extend([h.approval.permission_mode_flag, mode])
    if skip_permissions and h.approval.flag:
        cmd.append(h.approval.flag)
    cmd.extend(["--model", model])
    return cmd


def build_codex_headless_core(
    model: str,
    *,
    binary: str | None = None,
    sandbox_mode: str | None = None,
    full_auto: bool = True,
    skip_git_repo_check: bool = True,
    contract: ProviderContract | None = None,
) -> list[str]:
    """Build Codex headless launch core args.

    Returns args including ``exec``, ``--full-auto``, ``--sandbox``,
    ``--skip-git-repo-check``, and ``--model``. Does NOT include
    ``-C``, ``-o``, ``--output-schema``, or reasoning config.

    Args:
        full_auto: Include ``--full-auto`` (default True).
        skip_git_repo_check: Include ``--skip-git-repo-check`` (default True).
    """
    c = _check_provider(contract, "codex")
    h = c.headless
    cmd: list[str] = [binary or c.binary]
    cmd.extend(h.activation_args)
    if full_auto and h.noninteractive_mode_flag:
        cmd.append(h.noninteractive_mode_flag)
    if h.sandbox is not None:
        mode = sandbox_mode or h.sandbox.writable_mode
        cmd.extend([h.sandbox.flag, mode])
    if skip_git_repo_check and h.requires_git_repo and h.skip_git_repo_flag:
        cmd.append(h.skip_git_repo_flag)
    cmd.extend(["--model", model])
    return cmd


def build_copilot_headless_core(
    model: str,
    *,
    binary: str | None = None,
    stream: str | None = None,
    contract: ProviderContract | None = None,
) -> list[str]:
    """Build Copilot headless launch core args.

    Returns args including activation (``--no-ask-user``,
    ``--no-custom-instructions``), ``--allow-all``, ``--stream``,
    and ``--model``. Does NOT include ``-p`` or
    force-implementation.
    """
    c = _check_provider(contract, "copilot")
    h = c.headless
    cmd: list[str] = [binary or c.binary]
    cmd.extend(h.activation_args)
    if h.approval.flag:
        cmd.append(h.approval.flag)
    cmd.extend(["--model", model])
    if h.stream_flag:
        stream_value = stream or h.default_stream_mode
        if stream_value:
            cmd.extend([h.stream_flag, stream_value])
    return cmd


def build_gemini_headless_core(
    model: str,
    *,
    binary: str | None = None,
    contract: ProviderContract | None = None,
) -> list[str]:
    """Build Gemini headless launch core args.

    Returns args including approval flag (``--yolo``) and ``--model``.
    Does NOT include ``--prompt ""`` activation (that's part of prompt
    transport, handled by ``render_prompt()``).
    """
    c = _check_provider(contract, "gemini")
    h = c.headless
    cmd: list[str] = [binary or c.binary]
    cmd.extend(h.activation_args)
    if h.approval.flag:
        cmd.append(h.approval.flag)
    cmd.extend(["--model", model])
    return cmd
