"""Shared provider capability metadata for wrappers and helper tools.

Provider catalogs intentionally come from the best available source per provider.
Codex can read a live local models cache, while Copilot currently relies on a
checked-in verified baseline because it does not expose an equivalent stable
local catalog file.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

from .json_io import load_packaged_json_object
from .reasoning import (
    CLAUDE_DEFAULT_THINKING_TOKENS,
    CLAUDE_EFFORT_CHOICES,
    claude_supports_legacy_thinking_tokens,
    get_claude_effort_levels_for_model,
)

_logger = logging.getLogger(__name__)

COPILOT_BASELINE_RESOURCE = "copilot_reasoning_baseline.json"
_CONFIG_DIR_ENV = "CODING_CLI_RUNTIME_CONFIG_DIR"
# Codex is the one provider that currently offers a stable local catalog cache
# suitable for latest-local-state UI/runtime metadata.
_CODEX_CACHE_PATH = Path("~/.codex/models_cache.json").expanduser()


@dataclass(frozen=True)
class ChoiceSpec:
    value: str
    label: str | None = None
    description: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"value": self.value}
        if self.label is not None:
            payload["label"] = self.label
        if self.description is not None:
            payload["description"] = self.description
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


@dataclass(frozen=True)
class ControlSpec:
    name: str
    kind: str
    label: str
    description: str | None = None
    choices: tuple[ChoiceSpec, ...] = ()
    default: str | int | float | bool | None = None
    required: bool = False
    editable: bool = True
    advanced: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def choice_values(self) -> tuple[str, ...]:
        return tuple(choice.value for choice in self.choices)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "kind": self.kind,
            "label": self.label,
            "editable": self.editable,
            "advanced": self.advanced,
            "required": self.required,
        }
        if self.description is not None:
            payload["description"] = self.description
        if self.default is not None:
            payload["default"] = self.default
        if self.choices:
            payload["choices"] = [choice.to_dict() for choice in self.choices]
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


@dataclass(frozen=True)
class ModelSpec:
    name: str
    description: str | None = None
    controls: tuple[ControlSpec, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def control(self, name: str) -> ControlSpec | None:
        return next((control for control in self.controls if control.name == name), None)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": self.name}
        if self.description is not None:
            payload["description"] = self.description
        if self.controls:
            payload["controls"] = [control.to_dict() for control in self.controls]
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


@dataclass(frozen=True)
class ProviderSpec:
    provider_id: str
    label: str
    model_source: str
    default_model: str | None
    default_concurrency: int
    models: tuple[ModelSpec, ...]
    controls: tuple[ControlSpec, ...] = ()
    notes: tuple[str, ...] = ()
    allow_custom_model_override: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def model_names(self) -> tuple[str, ...]:
        return tuple(model.name for model in self.models)

    def model(self, name: str) -> ModelSpec | None:
        return next((model for model in self.models if model.name == name), None)

    def control(self, name: str) -> ControlSpec | None:
        return next((control for control in self.controls if control.name == name), None)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "providerId": self.provider_id,
            "label": self.label,
            "modelSource": self.model_source,
            "defaultConcurrency": self.default_concurrency,
            "models": [model.to_dict() for model in self.models],
            "allowCustomModelOverride": self.allow_custom_model_override,
        }
        if self.default_model is not None:
            payload["defaultModel"] = self.default_model
        if self.controls:
            payload["controls"] = [control.to_dict() for control in self.controls]
        if self.notes:
            payload["notes"] = list(self.notes)
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


def _choice_specs(*values: str) -> tuple[ChoiceSpec, ...]:
    return tuple(ChoiceSpec(value=value) for value in values)


def _codex_model_spec(
    *,
    name: str,
    description: str,
    default_reasoning: str,
    reasoning_levels: tuple[str, ...],
    visibility: str,
    priority: int,
) -> ModelSpec:
    return ModelSpec(
        name=name,
        description=description,
        controls=(
            ControlSpec(
                name="model_reasoning",
                kind="choice",
                label="Reasoning effort",
                required=False,
                default=default_reasoning,
                choices=_choice_specs(*reasoning_levels),
            ),
        ),
        metadata={
            "catalogPriority": priority,
            "catalogVisibility": visibility,
        },
    )


# Mirrors the local Codex CLI model catalog (`~/.codex/models_cache.json`) as of
# codex-cli 0.124.0 / catalog fetch 2026-04-24. `gpt-5.3-codex-spark` is
# intentionally excluded because the CLI marks it `supported_in_api=false`.
CODEX_MODEL_SPECS = (
    _codex_model_spec(
        name="gpt-5.4",
        description="Strong model for everyday coding.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="list",
        priority=-1,
    ),
    _codex_model_spec(
        name="gpt-5.5",
        description="Frontier model for complex coding, research, and real-world work.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="list",
        priority=0,
    ),
    _codex_model_spec(
        name="gpt-5.4-mini",
        description="Small, fast, and cost-efficient model for simpler coding tasks.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="list",
        priority=4,
    ),
    _codex_model_spec(
        name="gpt-5.3-codex",
        description="Coding-optimized model.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="list",
        priority=6,
    ),
    _codex_model_spec(
        name="gpt-5.2",
        description="Optimized for professional work and long-running agents.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="list",
        priority=10,
    ),
    _codex_model_spec(
        name="codex-auto-review",
        description="Automatic approval review model for Codex.",
        default_reasoning="medium",
        reasoning_levels=("low", "medium", "high", "xhigh"),
        visibility="hide",
        priority=29,
    ),
)

CLAUDE_OUTPUT_FORMAT_CHOICES = (
    ChoiceSpec(value="text", metadata={"suffix": ".txt"}),
    ChoiceSpec(value="json", metadata={"suffix": ".json"}),
    ChoiceSpec(value="stream-json", metadata={"suffix": ".jsonl"}),
)
CLAUDE_PERMISSION_MODE_CHOICES = tuple(
    ChoiceSpec(value=value) for value in ("acceptEdits", "bypassPermissions", "default", "plan")
)
CLAUDE_REASONING_MODE_CHOICES = tuple(
    ChoiceSpec(value=value) for value in ("script_default", "effort", "thinking_tokens", "disabled")
)


def _build_claude_model_spec(model_name: str) -> ModelSpec:
    effort_levels = get_claude_effort_levels_for_model(model_name)
    supports_legacy_tokens = claude_supports_legacy_thinking_tokens(model_name)
    controls: list[ControlSpec] = []
    metadata: dict[str, Any] = {
        "adaptiveThinking": bool(effort_levels),
        "legacyThinkingTokensSupported": supports_legacy_tokens,
    }
    if effort_levels:
        controls.append(
            ControlSpec(
                name="effort",
                kind="choice",
                label="Adaptive thinking effort",
                choices=tuple(ChoiceSpec(value=value) for value in effort_levels),
                metadata={"supported": True},
            )
        )
        metadata["supportedEffortLevels"] = effort_levels
    if supports_legacy_tokens:
        controls.append(
            ControlSpec(
                name="thinking_tokens",
                kind="int",
                label="Thinking tokens",
                default=CLAUDE_DEFAULT_THINKING_TOKENS,
            )
        )
        metadata["defaultThinkingTokens"] = CLAUDE_DEFAULT_THINKING_TOKENS
    return ModelSpec(
        name=model_name,
        controls=tuple(controls),
        metadata=metadata,
    )


CLAUDE_MODEL_SPECS = tuple(
    _build_claude_model_spec(model_name)
    for model_name in (
        "claude-haiku-4-5-20251001",
        "claude-sonnet-4-5-20250929",
        "claude-sonnet-4-6",
        "claude-opus-4-1-20250805",
        "claude-opus-4-6",
        "claude-opus-4-7",
    )
)

GEMINI_MODEL_SPECS = tuple(
    ModelSpec(name=model_name)
    for model_name in (
        "gemini-3-flash-preview",
        "gemini-3-pro-preview",
        "gemini-3.1-pro-preview",
    )
)


def _load_copilot_model_specs(
    resource_name: str = COPILOT_BASELINE_RESOURCE,
) -> tuple[ModelSpec, ...]:
    """Load the checked-in Copilot capability baseline.

    Unlike Codex, Copilot does not currently expose a stable local machine-readable
    model catalog that this package can consume at runtime, so the Copilot catalog
    remains a verified checked-in baseline.
    """
    payload = load_packaged_json_object(resource_name)
    model_payload = payload.get("models")
    if not isinstance(model_payload, dict):
        raise ValueError(f"Invalid Copilot baseline model payload: {resource_name}")
    models: list[ModelSpec] = []
    for model_name, raw in model_payload.items():
        if not isinstance(raw, dict):
            continue
        schema = str(raw.get("schema", "")).strip() or "none"
        value = raw.get("value")
        default_reasoning = raw.get("default_reasoning")
        metadata: dict[str, Any] = {"reasoningSchema": schema}
        controls: tuple[ControlSpec, ...] = ()
        if value is not None:
            metadata["reasoningValue"] = str(value)
        if default_reasoning is not None:
            metadata["defaultReasoning"] = str(default_reasoning)
        supported_reasoning_raw = raw.get("supported_reasoning_efforts")
        if isinstance(supported_reasoning_raw, (list, tuple)):
            supported_reasoning = tuple(
                str(item).strip().lower() for item in supported_reasoning_raw if str(item).strip()
            )
            if supported_reasoning:
                metadata["supportedReasoningEfforts"] = supported_reasoning
            if schema == "reasoning_effort" and len(supported_reasoning) > 1:
                control_default = None
                if default_reasoning is not None:
                    control_default = str(default_reasoning)
                elif value is not None:
                    control_default = str(value)
                controls = (
                    ControlSpec(
                        name="model_reasoning",
                        kind="choice",
                        label="Reasoning effort",
                        description="Passed through Copilot CLI via --reasoning-effort.",
                        required=False,
                        default=control_default,
                        choices=_choice_specs(*supported_reasoning),
                    ),
                )
        models.append(ModelSpec(name=model_name, controls=controls, metadata=metadata))
    return tuple(models)


def _config_dir() -> Path:
    """Return the user config directory for provider overrides."""
    env = os.getenv(_CONFIG_DIR_ENV)
    if env:
        return Path(env).expanduser()
    return Path("~/.config/coding-cli-runtime").expanduser()


def _parse_model_specs_from_raw(models_raw: list[Any]) -> tuple[ModelSpec, ...]:
    """Parse a list of model entries (strings or dicts) into ModelSpec tuples."""
    models: list[ModelSpec] = []
    for raw in models_raw:
        if isinstance(raw, str):
            models.append(ModelSpec(name=raw))
            continue
        if not isinstance(raw, dict):
            continue
        name = raw.get("name")
        if not isinstance(name, str):
            continue
        controls: list[ControlSpec] = []
        for ctrl in raw.get("controls", []):
            if not isinstance(ctrl, dict) or "name" not in ctrl:
                continue
            choices = tuple(
                ChoiceSpec(value=str(c["value"]) if isinstance(c, dict) else str(c))
                for c in ctrl.get("choices", [])
                if (isinstance(c, dict) and "value" in c) or isinstance(c, str)
            )
            controls.append(
                ControlSpec(
                    name=str(ctrl["name"]),
                    kind=str(ctrl.get("kind", "choice")),
                    label=str(ctrl.get("label", ctrl["name"])),
                    description=ctrl.get("description"),
                    choices=choices,
                    default=ctrl.get("default"),
                    required=bool(ctrl.get("required", False)),
                )
            )
        metadata = raw.get("metadata", {})
        if not isinstance(metadata, dict):
            metadata = {}
        models.append(
            ModelSpec(
                name=name,
                description=raw.get("description"),
                controls=tuple(controls),
                metadata=metadata,
            )
        )
    return tuple(models)


def _load_user_provider_override(
    provider_id: str,
) -> tuple[tuple[ModelSpec, ...], str | None] | None:
    """Load user override from config dir.  Returns (models, default_model) or None."""
    path = _config_dir() / "providers" / f"{provider_id}.json"
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            _logger.warning("Ignoring invalid override file (not an object): %s", path)
            return None
        models_raw = payload.get("models")
        if not isinstance(models_raw, list) or not models_raw:
            _logger.warning("Ignoring override file (missing/empty models list): %s", path)
            return None
        models = _parse_model_specs_from_raw(models_raw)
        if not models:
            return None
        default_model = payload.get("default_model")
        if default_model is not None and not isinstance(default_model, str):
            default_model = None
        _logger.debug("Loaded %d model(s) from user override: %s", len(models), path)
        return models, default_model
    except Exception:
        _logger.warning("Failed to read provider override: %s", path, exc_info=True)
        return None


def _load_codex_live_catalog() -> tuple[ModelSpec, ...] | None:
    """Parse ``~/.codex/models_cache.json`` into ModelSpec tuples.

    Returns *None* on any failure so the caller falls back to the hardcoded
    catalog.  The Codex CLI auto-refreshes this file; the format may change
    without notice, so every access is wrapped defensively.
    """
    if not _CODEX_CACHE_PATH.is_file():
        return None
    try:
        payload = json.loads(_CODEX_CACHE_PATH.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return None
        models_raw = payload.get("models")
        if not isinstance(models_raw, list):
            return None
        models: list[ModelSpec] = []
        for raw in models_raw:
            if not isinstance(raw, dict):
                continue
            slug = raw.get("slug") or raw.get("display_name")
            if not isinstance(slug, str):
                continue
            if not raw.get("supported_in_api", True):
                continue
            description = raw.get("description", "")
            default_reasoning = str(raw.get("default_reasoning_level", "medium"))
            levels_raw = raw.get("supported_reasoning_levels", [])
            reasoning_levels = tuple(
                str(r["effort"]) for r in levels_raw if isinstance(r, dict) and "effort" in r
            )
            visibility = raw.get("visibility", "list")
            priority = raw.get("priority", 0)
            controls: tuple[ControlSpec, ...] = ()
            if reasoning_levels:
                controls = (
                    ControlSpec(
                        name="model_reasoning",
                        kind="choice",
                        label="Reasoning effort",
                        required=False,
                        default=default_reasoning,
                        choices=_choice_specs(*reasoning_levels),
                    ),
                )
            models.append(
                ModelSpec(
                    name=slug,
                    description=description if isinstance(description, str) else "",
                    controls=controls,
                    metadata={"catalogPriority": priority, "catalogVisibility": visibility},
                )
            )
        if not models:
            return None
        _logger.debug("Loaded %d model(s) from Codex CLI cache: %s", len(models), _CODEX_CACHE_PATH)
        return tuple(models)
    except Exception:
        _logger.debug("Failed to read Codex models cache", exc_info=True)
        return None


def _resolve_models(
    provider_id: str,
    *,
    live_loader: Callable[[], tuple[ModelSpec, ...] | None] | None = None,
    hardcoded: tuple[ModelSpec, ...],
) -> tuple[tuple[ModelSpec, ...], str | None]:
    """Return (models, override_default_model) using: user file > live > hardcoded."""
    override = _load_user_provider_override(provider_id)
    if override is not None:
        return override
    if live_loader is not None:
        live = live_loader()
        if live is not None:
            return live, None
    return hardcoded, None


def _default_visible_model_name(models: tuple[ModelSpec, ...]) -> str | None:
    visible: list[tuple[int, int, str]] = []
    fallback_name: str | None = None
    for index, model in enumerate(models):
        if model.metadata.get("catalogVisibility") == "hide":
            continue
        if fallback_name is None:
            fallback_name = model.name
        priority = model.metadata.get("catalogPriority")
        if isinstance(priority, int):
            visible.append((priority, index, model.name))
    if visible:
        visible.sort()
        return visible[0][2]
    if fallback_name is not None:
        return fallback_name
    if models:
        return models[0].name
    return None


@lru_cache(maxsize=1)
def list_provider_specs() -> tuple[ProviderSpec, ...]:
    copilot_models = _load_copilot_model_specs()

    claude_models, claude_default = _resolve_models("claude", hardcoded=CLAUDE_MODEL_SPECS)
    gemini_models, gemini_default = _resolve_models("gemini", hardcoded=GEMINI_MODEL_SPECS)
    codex_models, codex_default = _resolve_models(
        "codex", live_loader=_load_codex_live_catalog, hardcoded=CODEX_MODEL_SPECS
    )
    copilot_override = _load_user_provider_override("copilot")
    if copilot_override is not None:
        copilot_models, copilot_default = copilot_override
    else:
        copilot_default = None

    return (
        ProviderSpec(
            provider_id="claude",
            label="Claude",
            model_source="override" if claude_default is not None else "code",
            default_model=claude_default or "claude-sonnet-4-6",
            default_concurrency=3,
            models=claude_models,
            controls=(
                ControlSpec(
                    name="reasoning_mode",
                    kind="choice",
                    label="Reasoning mode",
                    default="script_default",
                    choices=CLAUDE_REASONING_MODE_CHOICES,
                ),
                ControlSpec(
                    name="output_format",
                    kind="choice",
                    label="Output format",
                    default="text",
                    choices=CLAUDE_OUTPUT_FORMAT_CHOICES,
                ),
                ControlSpec(
                    name="permission_mode",
                    kind="choice",
                    label="Permission mode",
                    default="bypassPermissions",
                    choices=CLAUDE_PERMISSION_MODE_CHOICES,
                ),
                ControlSpec(
                    name="skip_permissions",
                    kind="bool",
                    label="Skip permissions",
                    default=True,
                ),
            ),
            notes=(
                "Adaptive thinking effort is model-specific.",
                "Claude Opus 4.7 uses adaptive reasoning without fixed thinking token budgets.",
                "Older effort-capable Claude models still preserve script-default"
                " compatibility via --thinking-tokens 8192 when no reasoning flag is given.",
            ),
        ),
        ProviderSpec(
            provider_id="gemini",
            label="Gemini",
            model_source="override" if gemini_default is not None else "code",
            default_model=gemini_default or "gemini-3-pro-preview",
            default_concurrency=3,
            models=gemini_models,
            controls=(
                ControlSpec(
                    name="auto_approve",
                    kind="bool",
                    label="Auto approve",
                    default=True,
                ),
                ControlSpec(
                    name="gif_fallback_retry",
                    kind="bool",
                    label="GIF fallback retry",
                    default=True,
                    advanced=True,
                ),
            ),
            notes=("This wrapper does not expose a reasoning control.",),
        ),
        ProviderSpec(
            provider_id="codex",
            label="Codex",
            model_source=(
                "override"
                if codex_default is not None
                else "codex_cli_cache"
                if codex_models is not CODEX_MODEL_SPECS
                else "code"
            ),
            default_model=codex_default or _default_visible_model_name(codex_models),
            default_concurrency=6,
            models=codex_models,
            controls=(),
            notes=(
                "Reasoning effort is model-specific and defaults"
                " to the selected model's catalog default.",
            ),
        ),
        ProviderSpec(
            provider_id="copilot",
            label="Copilot",
            model_source="override" if copilot_default is not None else "baseline_catalog",
            default_model=copilot_default or "claude-sonnet-4.5",
            default_concurrency=2,
            models=copilot_models,
            controls=(
                ControlSpec(name="allow_all", kind="bool", label="Allow all", default=True),
                ControlSpec(name="ask_user", kind="bool", label="Ask user", default=False),
                ControlSpec(
                    name="use_custom_instructions",
                    kind="bool",
                    label="Use custom instructions",
                    default=False,
                ),
                ControlSpec(
                    name="stream",
                    kind="choice",
                    label="Stream output",
                    default="on",
                    choices=(ChoiceSpec(value="on"), ChoiceSpec(value="off")),
                ),
                ControlSpec(
                    name="force_implementation",
                    kind="bool",
                    label="Force implementation",
                    default=True,
                ),
            ),
            notes=(
                "Copilot model options come from the checked-in reasoning baseline.",
                "Reasoning metadata is informational only until the wrapper"
                " exposes user-facing overrides.",
            ),
            allow_custom_model_override=True,
        ),
    )


@lru_cache(maxsize=1)
def provider_specs_by_id() -> dict[str, ProviderSpec]:
    return {spec.provider_id: spec for spec in list_provider_specs()}


def get_provider_spec(provider_id: str) -> ProviderSpec:
    try:
        return provider_specs_by_id()[provider_id]
    except KeyError as exc:
        raise KeyError(f"Unknown provider spec: {provider_id}") from exc


def serialize_provider_specs() -> list[dict[str, Any]]:
    return [spec.to_dict() for spec in list_provider_specs()]


def get_codex_supported_models() -> dict[str, dict[str, Any]]:
    provider = get_provider_spec("codex")
    supported: dict[str, dict[str, Any]] = {}
    for model in provider.models:
        reasoning = model.control("model_reasoning")
        entry: dict[str, Any] = {
            "description": model.description or "",
            "reasoning": reasoning.choice_values() if reasoning else (),
        }
        if reasoning and reasoning.default is not None:
            entry["default_reasoning"] = reasoning.default
        supported[model.name] = entry
    return supported


def get_claude_model_candidates() -> tuple[str, ...]:
    return get_provider_spec("claude").model_names


def get_claude_default_model() -> str:
    return get_provider_spec("claude").default_model or "claude-sonnet-4-6"


def get_claude_effort_levels(model: str | None = None) -> tuple[str, ...]:
    if model is None:
        return CLAUDE_EFFORT_CHOICES
    model_spec = get_provider_spec("claude").model(model)
    if model_spec is None:
        return ()
    effort = model_spec.control("effort")
    return effort.choice_values() if effort else ()


def get_claude_permission_modes() -> tuple[str, ...]:
    control = get_provider_spec("claude").control("permission_mode")
    return control.choice_values() if control else ()


def get_claude_output_suffixes() -> dict[str, str]:
    control = get_provider_spec("claude").control("output_format")
    if control is None:
        return {}
    return {choice.value: str(choice.metadata.get("suffix", "")) for choice in control.choices}


def get_gemini_model_options() -> tuple[str, ...]:
    return get_provider_spec("gemini").model_names


def get_gemini_default_model() -> str:
    return get_provider_spec("gemini").default_model or "gemini-3-pro-preview"


def get_copilot_default_model() -> str:
    return get_provider_spec("copilot").default_model or "claude-sonnet-4.5"


def get_copilot_model_catalog() -> tuple[str, ...]:
    return get_provider_spec("copilot").model_names


def get_copilot_stream_choices() -> tuple[str, ...]:
    control = get_provider_spec("copilot").control("stream")
    return control.choice_values() if control else ()
