"""Provider auth resolution contract for shared runtime."""

from __future__ import annotations

import os
from dataclasses import dataclass

from .contracts import AuthMode
from .provider_contracts import get_provider_contract, list_provider_ids


@dataclass(frozen=True)
class AuthResolution:
    provider: str
    mode: AuthMode
    required_env: tuple[str, ...]
    present_env: tuple[str, ...]
    missing_env: tuple[str, ...]
    hint: str


def _build_provider_env_hints() -> dict[str, tuple[tuple[str, ...], str]]:
    """Derive auth env hints from the authoritative provider contracts.

    Only ``api_key_env_var`` (primary auth) populates ``required_env``.
    ``byok_api_key_env_var`` is an opt-in override and should not appear
    as "required" or "missing" — callers discover BYOK via the contract.
    """
    hints: dict[str, tuple[tuple[str, ...], str]] = {}
    for provider_id in list_provider_ids():
        contract = get_provider_contract(provider_id)
        auth = contract.auth
        env_vars: list[str] = []
        if auth.api_key_env_var:
            env_vars.append(auth.api_key_env_var)
        if env_vars:
            hint = f"Use CLI login or set {env_vars[0]}."
        elif auth.byok_api_key_env_var:
            hint = f"Use CLI login. BYOK available via {auth.byok_api_key_env_var}."
        else:
            hint = "Use CLI login (no env-based auth path available)."
        hints[provider_id] = (tuple(env_vars), hint)
    return hints


_PROVIDER_ENV_HINTS = _build_provider_env_hints()


def resolve_auth(provider: str, env: dict[str, str] | None = None) -> AuthResolution:
    provider_key = provider.strip().lower()
    required_env, hint = _PROVIDER_ENV_HINTS.get(
        provider_key,
        (tuple(), "Unknown provider; configure CLI login or provider token env vars."),
    )
    current_env = env if env is not None else os.environ

    present_env = tuple(key for key in required_env if current_env.get(key))
    missing_env = tuple(key for key in required_env if key not in present_env)

    if required_env and present_env:
        mode = AuthMode.ENV
    else:
        mode = AuthMode.CLI_LOGIN

    return AuthResolution(
        provider=provider_key,
        mode=mode,
        required_env=required_env,
        present_env=present_env,
        missing_env=missing_env,
        hint=hint,
    )
