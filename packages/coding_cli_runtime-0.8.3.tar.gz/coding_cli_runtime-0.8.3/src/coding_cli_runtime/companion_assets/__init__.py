from __future__ import annotations

import argparse
import json
import os
import shutil
from importlib.abc import Traversable
from importlib.resources import files
from pathlib import Path
from typing import Any

from .. import __version__
from ..json_io import load_packaged_json_object

COMPANION_BUNDLE_SCHEMA_VERSION = "coding-cli-runtime.companion_bundle.v1"
DEFAULT_CODEX_SKILL_NAME = "coding-cli-runtime"


class CompanionAssetError(RuntimeError):
    """Raised when packaged companion assets are missing or incompatible."""


def companion_bundle_root() -> Traversable:
    return files(__package__).joinpath("bundle")


def load_companion_bundle_manifest() -> dict[str, Any]:
    payload = load_packaged_json_object("companion_assets", "bundle", "manifest.json")
    schema_version = payload.get("schema_version")
    if schema_version != COMPANION_BUNDLE_SCHEMA_VERSION:
        raise CompanionAssetError(
            "Unsupported companion bundle schema "
            f"{schema_version!r}; expected {COMPANION_BUNDLE_SCHEMA_VERSION!r}"
        )
    resolved = dict(payload)
    resolved["package_version"] = __version__
    return resolved


def _copy_bundle_tree(source: Traversable, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for child in source.iterdir():
        target = destination / child.name
        if child.is_dir():
            _copy_bundle_tree(child, target)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(child.read_bytes())


def _replace_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()


def _prepare_directory_target(destination: Path, *, force: bool) -> Path:
    destination = destination.expanduser().resolve()
    if destination.exists():
        if not destination.is_dir():
            raise NotADirectoryError(f"Destination is not a directory: {destination}")
        if any(destination.iterdir()):
            if not force:
                raise FileExistsError(f"Destination already exists and is not empty: {destination}")
            shutil.rmtree(destination)
            destination.mkdir(parents=True, exist_ok=True)
        return destination
    destination.mkdir(parents=True, exist_ok=True)
    return destination


def export_companion_bundle(destination: Path, *, force: bool = False) -> Path:
    destination = _prepare_directory_target(Path(destination), force=force)
    _copy_bundle_tree(companion_bundle_root(), destination)
    manifest_path = destination / "manifest.json"
    manifest_path.write_text(
        json.dumps(load_companion_bundle_manifest(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return destination


def default_codex_skill_root() -> Path:
    codex_home = Path(os.environ.get("CODEX_HOME", "~/.codex")).expanduser()
    return codex_home / "skills"


def _render_codex_skill_markdown(manifest: dict[str, Any]) -> str:
    exports = manifest.get("export_targets", {})
    codex_target = exports.get("codex_skill", {})
    name = codex_target.get("name", DEFAULT_CODEX_SKILL_NAME)
    description = codex_target.get("description")
    if not isinstance(description, str) or not description.strip():
        raise CompanionAssetError("Companion bundle is missing codex_skill description metadata")
    guide_text = companion_bundle_root().joinpath("guide.md").read_text(encoding="utf-8").strip()
    package_version = manifest.get("package_version", __version__)
    return (
        "---\n"
        f"name: {name}\n"
        f"description: {description.strip()}\n"
        "---\n\n"
        f"_Generated from the preview `coding-cli-runtime` companion bundle "
        f"shipped with package version `{package_version}`._\n\n"
        f"{guide_text}\n"
    )


def install_codex_skill(
    *,
    destination_root: Path | None = None,
    skill_name: str | None = None,
    force: bool = False,
) -> Path:
    manifest = load_companion_bundle_manifest()
    destination_root = (
        Path(destination_root).expanduser().resolve()
        if destination_root is not None
        else default_codex_skill_root().resolve()
    )
    if destination_root.exists() and not destination_root.is_dir():
        raise NotADirectoryError(f"Skill root is not a directory: {destination_root}")
    destination_root.mkdir(parents=True, exist_ok=True)
    target_name = skill_name or manifest.get("export_targets", {}).get("codex_skill", {}).get(
        "name", DEFAULT_CODEX_SKILL_NAME
    )
    skill_dir = destination_root / str(target_name)
    if skill_dir.exists():
        if not force:
            raise FileExistsError(f"Skill destination already exists: {skill_dir}")
        _replace_path(skill_dir)
    skill_dir.mkdir(parents=True, exist_ok=True)
    references_dir = skill_dir / "references"
    references_source = companion_bundle_root().joinpath("references")
    _copy_bundle_tree(references_source, references_dir)
    (skill_dir / "SKILL.md").write_text(
        _render_codex_skill_markdown(manifest),
        encoding="utf-8",
    )
    return skill_dir


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Export or install coding-cli-runtime companion assets."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    export_parser = subparsers.add_parser(
        "export",
        help="Export the package-neutral companion bundle to a directory.",
    )
    export_parser.add_argument("--dest", type=Path, required=True, help="Destination directory.")
    export_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing non-empty destination directory.",
    )

    install_parser = subparsers.add_parser(
        "install-codex-skill",
        help="Install a Codex-compatible skill derived from the packaged bundle.",
    )
    install_parser.add_argument(
        "--dest-root",
        type=Path,
        help="Skill root directory. Defaults to $CODEX_HOME/skills or ~/.codex/skills.",
    )
    install_parser.add_argument(
        "--skill-name",
        type=str,
        help=f"Override the installed skill directory name (default: {DEFAULT_CODEX_SKILL_NAME}).",
    )
    install_parser.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing installed skill directory.",
    )

    subparsers.add_parser(
        "show-manifest",
        help="Print the resolved packaged companion-bundle manifest as JSON.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.command == "export":
        destination = export_companion_bundle(args.dest, force=args.force)
        print(destination)
        return 0
    if args.command == "install-codex-skill":
        skill_dir = install_codex_skill(
            destination_root=args.dest_root,
            skill_name=args.skill_name,
            force=args.force,
        )
        print(skill_dir)
        return 0
    if args.command == "show-manifest":
        print(json.dumps(load_companion_bundle_manifest(), indent=2, sort_keys=True))
        return 0
    parser.error(f"Unknown command: {args.command}")
    return 2


__all__ = [
    "COMPANION_BUNDLE_SCHEMA_VERSION",
    "DEFAULT_CODEX_SKILL_NAME",
    "CompanionAssetError",
    "companion_bundle_root",
    "default_codex_skill_root",
    "export_companion_bundle",
    "install_codex_skill",
    "load_companion_bundle_manifest",
    "main",
]
