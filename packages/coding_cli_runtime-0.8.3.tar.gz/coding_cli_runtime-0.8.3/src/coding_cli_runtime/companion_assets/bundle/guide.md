## Use This Companion

Use this package-owned companion when you are consuming `coding-cli-runtime`
from another repository and need help choosing the right surface, interpreting
artifact fields, or debugging provider drift.

This companion is package-generic. It does not encode repo-specific workflows
such as `app-generation`, benchmark export, or compare-app rollout policy.

## Routing

- Use the stable root package for shared execution primitives, provider specs,
  provider contracts, schema helpers, and transcript-facts derivation.
- Use `coding_cli_runtime.providers.*` when you need provider-aware launch,
  parsing, conversation lookup, or continuation behavior.
- Read [`references/surface-map.md`](references/surface-map.md) when you need
  to decide which output or transcript field is canonical for a workflow.
- Read [`references/debugging.md`](references/debugging.md) when you are
  diagnosing provider drift or a mismatch between direct output, sidecars, and
  structured transcripts.

## Guardrails

- Prefer provider-owned transcript inputs over ad hoc parsing of human-readable
  sidecars.
- Treat `response` as the canonical preserved final-answer path when it is
  present; keep `artifact` as the generic primary artifact field.
- Treat `raw_output_artifact` as provider-direct output, not automatically as
  the final answer.
- Treat `conversation_log` as the transcript input surface, not a Markdown
  summary or rendered share view.

## Canonical References

- Package overview: `coding-cli-runtime/README.md`
- Package docs index: `coding-cli-runtime/docs/README.md`
- Transcript facts contract: `coding-cli-runtime/docs/TRANSCRIPT_FACTS.md`
- Provider/runtime architecture: `coding-cli-runtime/docs/PROVIDER_CONTRACT_API_PLAN.md`
- Package-owned probe knowledge base: `coding-cli-runtime/playground/README.md`
