"""Session log discovery helpers shared across provider wrappers."""

from __future__ import annotations

import json
import os
import re
from collections.abc import Callable
from pathlib import Path
from typing import TypeVar

_T = TypeVar("_T")


def normalize_path_str(path_str: str) -> str:
    try:
        return str(Path(path_str).resolve())
    except OSError:
        return os.path.normpath(path_str)


# ---------------------------------------------------------------------------
# Generic session-directory scanning primitive
# ---------------------------------------------------------------------------


def scan_session_dir(
    directory: Path,
    *,
    glob_pattern: str = "*.jsonl",
    since_ts: float,
    mtime_buffer: float = 15.0,
    extract_fn: Callable[[Path], _T | None],
    max_candidates: int = 200,
) -> list[tuple[float, Path, _T]]:
    """Scan a directory for session files, filter by mtime, extract metadata.

    Returns a list of ``(mtime, path, extracted)`` tuples sorted by mtime
    descending. Provider-specific ranking/selection stays with the caller.

    Args:
        directory: Directory to scan.
        glob_pattern: Glob pattern for session files (default: ``*.jsonl``).
        since_ts: Only include files with mtime >= ``since_ts - mtime_buffer``.
        mtime_buffer: Seconds of slack before ``since_ts`` (default: 15).
        extract_fn: Called on each candidate path. Return ``None`` to skip.
        max_candidates: Max number of candidates to process after mtime filter.
    """
    if not directory.exists():
        return []

    candidates: list[tuple[float, Path]] = []
    try:
        for path in directory.rglob(glob_pattern):
            try:
                mtime = path.stat().st_mtime
            except OSError:
                continue
            if mtime >= since_ts - mtime_buffer:
                candidates.append((mtime, path))
    except (OSError, RuntimeError):
        return []

    candidates.sort(key=lambda item: item[0], reverse=True)

    results: list[tuple[float, Path, _T]] = []
    for mtime, path in candidates[:max_candidates]:
        extracted = extract_fn(path)
        if extracted is not None:
            results.append((mtime, path, extracted))
    return results


def codex_session_roots() -> list[Path]:
    base = Path.home() / ".codex"
    return [base / "sessions", base / "archived_sessions"]


def claude_project_roots() -> list[Path]:
    return [Path.home() / ".claude" / "projects"]


def claude_project_key(workdir: Path) -> str:
    normalized = workdir.as_posix().lstrip("/")
    if not normalized:
        return "-"
    slug = re.sub(r"[^A-Za-z0-9-]", "-", normalized)
    return f"-{slug}"


def codex_session_matches(log_path: Path, workdir: str, *, max_lines: int = 50) -> bool:
    try:
        with log_path.open("r", encoding="utf-8") as handle:
            for _ in range(max_lines):
                line = handle.readline()
                if not line:
                    break
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                payload = record.get("payload")
                if not isinstance(payload, dict):
                    continue
                cwd = payload.get("cwd")
                if isinstance(cwd, str) and normalize_path_str(cwd) == workdir:
                    return True
    except OSError:
        return False
    return False


def find_codex_session(
    workdir: str,
    since_ts: float,
    *,
    session_roots: list[Path] | None = None,
    max_scan: int = 200,
) -> Path | None:
    """Return the newest matching Codex session log path.

    This is the stable low-level path scan helper. For preview adapter-owned
    lookup semantics and typed results, use
    ``coding_cli_runtime.providers.codex.find_session(...)``.
    """

    def safe_mtime(path: Path) -> float | None:
        try:
            return path.stat().st_mtime
        except OSError:
            return None

    roots = session_roots if session_roots is not None else codex_session_roots()
    candidates: list[tuple[float, Path]] = []
    for root in roots:
        if not root.exists():
            continue
        try:
            for path in root.rglob("*.jsonl"):
                mtime = safe_mtime(path)
                if mtime is None:
                    continue
                if mtime >= since_ts - 15:
                    candidates.append((mtime, path))
        except (OSError, RuntimeError):
            continue
    if not candidates:
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    for _, path in candidates[:max_scan]:
        if codex_session_matches(path, workdir):
            return path
    return None


def find_claude_session(
    workdir: str,
    since_ts: float,
    *,
    project_roots: list[Path] | None = None,
    max_scan: int = 200,
) -> Path | None:
    """Return the newest matching Claude session log path.

    This is the stable low-level path scan helper. For preview adapter-owned
    lookup semantics and typed results, use
    ``coding_cli_runtime.providers.claude.find_session(...)``.
    """

    def safe_mtime(path: Path) -> float | None:
        try:
            return path.stat().st_mtime
        except OSError:
            return None

    workdir_path = Path(normalize_path_str(workdir))
    project_key = claude_project_key(workdir_path)
    roots = project_roots if project_roots is not None else claude_project_roots()
    candidates: list[tuple[float, Path]] = []
    for root in roots:
        project_dir = root / project_key
        if not project_dir.exists():
            continue
        try:
            for path in project_dir.glob("*.jsonl"):
                mtime = safe_mtime(path)
                if mtime is None:
                    continue
                if mtime >= since_ts - 10:
                    candidates.append((mtime, path))
        except (OSError, RuntimeError):
            continue

    if not candidates:
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[:max_scan][0][1]
