from __future__ import annotations

import json
from collections.abc import Mapping
from importlib.resources import files
from pathlib import Path
from typing import Any


def load_json_value(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_json_object(path: Path) -> dict[str, Any]:
    payload = load_json_value(path)
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected JSON object in {path}")
    return dict(payload)


def load_optional_json_object(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        payload = load_json_value(path)
    except (OSError, ValueError):
        return None
    if not isinstance(payload, Mapping):
        return None
    return dict(payload)


def _package_resource(*path_parts: str) -> Any:
    package = __package__
    if not package:
        raise RuntimeError("Package resources are unavailable outside package context")
    return files(package).joinpath(*path_parts)


def packaged_resource_exists(*path_parts: str) -> bool:
    return bool(_package_resource(*path_parts).is_file())


def load_packaged_json_value(*path_parts: str) -> Any:
    resource = _package_resource(*path_parts)
    if not resource.is_file():
        raise FileNotFoundError(f"packaged resource not found: {'/'.join(path_parts)}")
    return json.loads(resource.read_text(encoding="utf-8"))


def load_packaged_json_object(*path_parts: str) -> dict[str, Any]:
    payload = load_packaged_json_value(*path_parts)
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected JSON object in packaged resource {'/'.join(path_parts)}")
    return dict(payload)


def load_jsonl_rows_text(text: str, *, skip_invalid: bool = False) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        payload = raw_line.strip()
        if not payload:
            continue
        try:
            decoded = json.loads(payload)
        except json.JSONDecodeError as exc:
            if skip_invalid:
                continue
            raise ValueError(f"Invalid JSON on line {line_number}") from exc
        if not isinstance(decoded, Mapping):
            if skip_invalid:
                continue
            raise ValueError(f"Expected JSON object on line {line_number}")
        rows.append(dict(decoded))
    return rows


def load_jsonl_rows(path: Path, *, skip_invalid: bool = False) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return load_jsonl_rows_text(path.read_text(encoding="utf-8"), skip_invalid=skip_invalid)
