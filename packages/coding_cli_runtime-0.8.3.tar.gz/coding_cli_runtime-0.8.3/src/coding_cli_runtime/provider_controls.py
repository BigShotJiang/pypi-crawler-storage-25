"""Provider model-control normalization helpers."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any

from .reasoning import CLAUDE_EFFORT_CHOICES

PROVIDER_SUPPORTED_MODEL_CONTROLS: dict[str, set[str]] = {
    "codex": {"reasoning_effort"},
    "claude": {"effort", "thinking_tokens"},
    "copilot": {"reasoning_effort"},
    "gemini": set(),
}


class UnsupportedControlMode(str, Enum):
    RECORD = "record"
    ERROR = "error"


class ControlDefaultSource(str, Enum):
    ADAPTER_DEFAULT = "adapter_default"
    PROVIDER_DEFAULT = "provider_default"


@dataclass(frozen=True)
class ProviderControlResolution:
    provider: str
    requested: Mapping[str, Any]
    applied: Mapping[str, Any]
    ignored: Mapping[str, Any]
    defaulted: Mapping[str, Any]
    default_sources: Mapping[str, ControlDefaultSource]
    unknown_default_keys: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "requested", dict(self.requested))
        object.__setattr__(self, "applied", dict(self.applied))
        object.__setattr__(self, "ignored", dict(self.ignored))
        object.__setattr__(self, "defaulted", dict(self.defaulted))
        object.__setattr__(self, "default_sources", dict(self.default_sources))
        object.__setattr__(self, "unknown_default_keys", tuple(self.unknown_default_keys))


def _normalize_unsupported_control_mode(
    value: UnsupportedControlMode | str | None,
) -> UnsupportedControlMode:
    if isinstance(value, UnsupportedControlMode):
        return value
    normalized = str(value or UnsupportedControlMode.RECORD.value).strip().lower()
    if normalized == UnsupportedControlMode.ERROR.value:
        return UnsupportedControlMode.ERROR
    return UnsupportedControlMode.RECORD


def build_provider_control_resolution(
    *,
    provider: str,
    requested: Mapping[str, Any] | None = None,
    applied: Mapping[str, Any] | None = None,
    ignored: Mapping[str, Any] | None = None,
    defaulted: Mapping[str, Any] | None = None,
    default_sources: Mapping[str, ControlDefaultSource | str] | None = None,
    unknown_default_keys: tuple[str, ...] | list[str] | None = None,
    unsupported_control_mode: UnsupportedControlMode | str | None = None,
) -> ProviderControlResolution:
    normalized_provider = str(provider).strip().lower()
    requested_map = dict(requested or {})
    applied_map = dict(applied or {})
    ignored_map = dict(ignored or {})
    defaulted_map = dict(defaulted or {})
    normalized_default_sources: dict[str, ControlDefaultSource] = {}
    for key, value in (default_sources or {}).items():
        normalized_key = str(key).strip()
        if not normalized_key:
            continue
        if isinstance(value, ControlDefaultSource):
            normalized_default_sources[normalized_key] = value
            continue
        normalized_value = str(value).strip().lower()
        if normalized_value == ControlDefaultSource.ADAPTER_DEFAULT.value:
            normalized_default_sources[normalized_key] = ControlDefaultSource.ADAPTER_DEFAULT
        elif normalized_value == ControlDefaultSource.PROVIDER_DEFAULT.value:
            normalized_default_sources[normalized_key] = ControlDefaultSource.PROVIDER_DEFAULT

    mode = _normalize_unsupported_control_mode(unsupported_control_mode)
    if mode is UnsupportedControlMode.ERROR and ignored_map:
        names = ", ".join(sorted(ignored_map))
        raise ValueError(
            f"Unsupported model controls for provider '{normalized_provider}': {names}"
        )

    return ProviderControlResolution(
        provider=normalized_provider,
        requested=requested_map,
        applied=applied_map,
        ignored=ignored_map,
        defaulted=defaulted_map,
        default_sources=normalized_default_sources,
        unknown_default_keys=tuple(unknown_default_keys or ()),
    )


def _normalize_reasoning_effort(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _normalize_thinking_tokens(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return max(int(value), 0)
    if isinstance(value, str):
        try:
            parsed = int(value.strip())
        except ValueError:
            return None
        return max(parsed, 0)
    return None


def _normalize_claude_effort(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    if normalized in CLAUDE_EFFORT_CHOICES:
        return normalized
    return None


def resolve_provider_model_controls(
    *,
    provider: str,
    model_reasoning: str | None = None,
    thinking_tokens: int | None = None,
    effort: str | None = None,
    model_controls: dict[str, Any] | None = None,
    unsupported_control_mode: UnsupportedControlMode | str | None = None,
) -> dict[str, Any]:
    resolution = resolve_provider_model_control_resolution(
        provider=provider,
        model_reasoning=model_reasoning,
        thinking_tokens=thinking_tokens,
        effort=effort,
        model_controls=model_controls,
        unsupported_control_mode=unsupported_control_mode,
    )

    return {
        "provider": resolution.provider,
        "requested": dict(resolution.requested),
        "applied": dict(resolution.applied),
        "ignored": dict(resolution.ignored),
        "ignored_keys": sorted(resolution.ignored),
        "defaulted": dict(resolution.defaulted),
        "default_sources": dict(resolution.default_sources),
        "unknown_default_keys": list(resolution.unknown_default_keys),
    }


def resolve_provider_model_control_resolution(
    *,
    provider: str,
    model_reasoning: str | None = None,
    thinking_tokens: int | None = None,
    effort: str | None = None,
    model_controls: dict[str, Any] | None = None,
    unsupported_control_mode: UnsupportedControlMode | str | None = None,
) -> ProviderControlResolution:
    provider_value = str(provider).strip().lower()
    requested_raw: dict[str, Any] = {}

    if isinstance(model_controls, dict):
        for key, value in model_controls.items():
            if isinstance(key, str):
                requested_raw[key] = value

    if "reasoning_effort" not in requested_raw and model_reasoning is not None:
        requested_raw["reasoning_effort"] = model_reasoning
    if "thinking_tokens" not in requested_raw and thinking_tokens is not None:
        requested_raw["thinking_tokens"] = thinking_tokens
    if "effort" not in requested_raw and effort is not None:
        requested_raw["effort"] = effort

    requested: dict[str, Any] = {}
    reasoning_effort = _normalize_reasoning_effort(requested_raw.get("reasoning_effort"))
    if reasoning_effort is not None:
        requested["reasoning_effort"] = reasoning_effort

    tokens_value = _normalize_thinking_tokens(requested_raw.get("thinking_tokens"))
    if tokens_value is not None:
        requested["thinking_tokens"] = tokens_value

    effort_value = _normalize_claude_effort(requested_raw.get("effort"))
    if effort_value is not None:
        requested["effort"] = effort_value

    supported = PROVIDER_SUPPORTED_MODEL_CONTROLS.get(provider_value, set())
    applied = {key: requested[key] for key in sorted(requested) if key in supported}
    ignored = {key: requested[key] for key in sorted(requested) if key not in supported}

    return build_provider_control_resolution(
        provider=provider_value,
        requested=requested,
        applied=applied,
        ignored=ignored,
        unsupported_control_mode=unsupported_control_mode,
    )


def build_model_id(model: str, *, applied_controls: dict[str, Any] | None = None) -> str:
    controls = dict(applied_controls or {})
    if not controls:
        return model
    if set(controls.keys()) == {"reasoning_effort"}:
        return f"{model}:{controls['reasoning_effort']}"
    suffix = ",".join(f"{key}={controls[key]}" for key in sorted(controls))
    return f"{model}:{suffix}"
