"""Preview Codex runtime adapter."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path, PurePosixPath
from typing import Any, cast

from ..codex_cli import CodexExecSpec, build_codex_exec_spec
from ..contracts import CliRunResult, ErrorCode
from ..failure_classification import FailureClassification, classify_provider_failure
from ..provider_contracts import (
    build_env_overlay,
    get_provider_contract,
    resolve_session_search_paths,
)
from ..provider_controls import ProviderControlResolution, UnsupportedControlMode
from ..session_execution import (
    InteractiveCliRunResult,
    SessionExecutionTimeoutError,
    SessionProgressEvent,
    TranscriptMirrorStrategy,
    mirror_session_transcript,
    run_interactive_session,
)
from ..session_logs import find_codex_session, normalize_path_str
from ._common import (
    build_progress_callback,
    build_raw_execution,
    default_execution_id,
    emit_provider_event,
    materialize_prefixed_references,
    merge_env,
    prepare_destination_path,
    redact_env_for_preview,
    run_sync_via_asyncio,
)
from ._types import (
    AttemptFinishedEventData,
    AttemptStartedEventData,
    ParseFinishedEventData,
    ProviderContinuationMode,
    ProviderContinuationResolution,
    ProviderEventCallback,
    ProviderEventKind,
    ProviderLaunchPreview,
    ProviderRawExecution,
    RecoveryAppliedEventData,
    normalize_continuation_request,
)

_LOGGER = logging.getLogger(__name__)

SUPPORT_STATE = "sync_parity"
_MAX_CODEX_SESSION_SCAN = 200
_DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS = 1.0


class CodexSessionLookupStatus(str, Enum):
    FOUND = "found"
    NOT_FOUND = "not_found"


@dataclass(frozen=True)
class CodexExecRequest:
    model: str
    prompt: str
    cwd: Path
    output_schema_path: Path | None = None
    output_path: Path | None = None
    continuation_mode: ProviderContinuationMode | str = ProviderContinuationMode.NEW
    session_id: str | None = None
    session_path: Path | None = None
    binary: str = "codex"
    model_reasoning: str | None = None
    model_controls: dict[str, Any] | None = None
    unsupported_control_mode: UnsupportedControlMode | str = UnsupportedControlMode.RECORD
    sandbox: str = "danger-full-access"
    full_auto: bool = True
    skip_git_repo_check: bool = True
    extra_args: tuple[str, ...] = ()
    timeout_seconds: float | None = None
    env: dict[str, str] | None = None
    api_key: str | None = None
    base_url: str | None = None
    transcript_path: Path | None = None
    transcript_progress_callback: Callable[[SessionProgressEvent], None] | None = None
    event_callback: ProviderEventCallback | None = None
    transient_retries: int = 0
    transient_retry_backoff_seconds: float = _DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS
    ephemeral_retry_on_state_db_failure: bool = False
    execution_id: str = field(default_factory=default_execution_id)

    def __post_init__(self) -> None:
        object.__setattr__(self, "cwd", Path(self.cwd))
        object.__setattr__(self, "extra_args", tuple(self.extra_args))
        normalized_mode, normalized_session_id, normalized_session_path = (
            normalize_continuation_request(
                self.continuation_mode,
                session_id=self.session_id,
                session_path=self.session_path,
            )
        )
        object.__setattr__(self, "continuation_mode", normalized_mode)
        object.__setattr__(self, "session_id", normalized_session_id)
        object.__setattr__(self, "session_path", normalized_session_path)
        if self.output_schema_path is not None:
            object.__setattr__(self, "output_schema_path", Path(self.output_schema_path))
        if self.env is not None:
            object.__setattr__(self, "env", dict(self.env))
        if self.output_path is not None:
            object.__setattr__(self, "output_path", Path(self.output_path))
        if self.transcript_path is not None:
            object.__setattr__(self, "transcript_path", Path(self.transcript_path))
        if self.model_controls is not None:
            object.__setattr__(self, "model_controls", dict(self.model_controls))
        _validate_output_schema_compatibility(self)


@dataclass(frozen=True)
class CodexParsedOutput:
    parsed_payload: dict[str, object] | None
    normalized_text: str
    parse_skipped: bool = False
    parse_error: str | None = None


@dataclass(frozen=True)
class CodexRetryRecord:
    attempt_index: int
    category: str
    delay_seconds: float
    launch_variant: str = "default"


@dataclass(frozen=True)
class CodexSessionLookupResult:
    status: CodexSessionLookupStatus
    path: Path | None = None
    matched_by: str | None = None

    def __post_init__(self) -> None:
        if self.path is not None:
            object.__setattr__(self, "path", Path(self.path))


@dataclass(frozen=True)
class CodexConversationResult:
    status: CodexSessionLookupStatus
    source_path: Path | None
    text: str
    line_count: int

    def __post_init__(self) -> None:
        if self.source_path is not None:
            object.__setattr__(self, "source_path", Path(self.source_path))


@dataclass(frozen=True)
class CodexExecResult:
    request: CodexExecRequest
    launch: CodexExecSpec
    raw_result: InteractiveCliRunResult | CliRunResult
    raw_execution: ProviderRawExecution
    parsed_output: CodexParsedOutput
    effective_reasoning: str
    applied_controls: dict[str, Any]
    control_resolution: ProviderControlResolution
    continuation_resolution: ProviderContinuationResolution
    retry_history: tuple[CodexRetryRecord, ...] = ()
    failure_classification: FailureClassification | None = None
    session_lookup: CodexSessionLookupResult | None = None
    output_path: Path | None = None

    def __post_init__(self) -> None:
        if self.output_path is not None:
            object.__setattr__(self, "output_path", Path(self.output_path))
        object.__setattr__(self, "applied_controls", dict(self.applied_controls))
        object.__setattr__(self, "retry_history", tuple(self.retry_history))


@dataclass(frozen=True)
class _CodexSessionMetadata:
    path: Path
    session_id: str | None
    cwd: str | None
    mtime: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "path", Path(self.path))


def materialize_prompt_file_references(
    prompt_text: str,
    file_paths: tuple[str | Path, ...] | list[str | Path],
) -> str:
    prefix = get_provider_contract("codex").io.file_reference_prefix
    if not prefix:
        raise NotImplementedError(
            "Codex prompt file references are not enabled in coding_cli_runtime"
        )
    normalized_paths = tuple(Path(path) for path in file_paths)
    return materialize_prefixed_references(
        prompt_text,
        normalized_paths,
        prefix=prefix,
        singular_label="File reference",
        plural_label="File references",
    )


def _validate_output_schema_compatibility(request: CodexExecRequest) -> None:
    """Enforce Codex schema compatibility across fresh and resumed sessions.

    Fresh runs may opt into native ``--output-schema`` enforcement, but schema-less
    runs are also valid for freeform/provider-artifact flows. Resumed runs must
    omit the flag because ``codex exec resume`` does not support it.
    """
    mode = cast(ProviderContinuationMode, request.continuation_mode)
    if mode is ProviderContinuationMode.NEW:
        return
    if request.output_schema_path is not None:
        raise ValueError(
            "Codex continuation does not support native --output-schema; "
            "use a fresh session for schema-enforced output."
        )


def _new_continuation_resolution(request: CodexExecRequest) -> ProviderContinuationResolution:
    return ProviderContinuationResolution(
        requested_mode=cast(ProviderContinuationMode, request.continuation_mode),
        requested_session_id=request.session_id,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.NEW,
        native_strategy="fresh",
    )


def _read_codex_session_metadata(log_path: Path) -> _CodexSessionMetadata | None:
    try:
        mtime = log_path.stat().st_mtime
    except OSError:
        return None
    try:
        with log_path.open("r", encoding="utf-8") as handle:
            for _ in range(20):
                line = handle.readline()
                if not line:
                    break
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(record, dict):
                    continue
                payload = record.get("payload")
                if not isinstance(payload, dict):
                    continue
                session_id = payload.get("id")
                cwd = payload.get("cwd")
                return _CodexSessionMetadata(
                    path=log_path,
                    session_id=session_id if isinstance(session_id, str) else None,
                    cwd=normalize_path_str(cwd) if isinstance(cwd, str) else None,
                    mtime=mtime,
                )
    except OSError:
        return None
    return None


def _iter_codex_session_metadata(
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> list[_CodexSessionMetadata]:
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("codex"))
    )
    candidates: list[_CodexSessionMetadata] = []
    for root in roots:
        if not root.exists():
            continue
        try:
            for path in root.rglob("*.jsonl"):
                metadata = _read_codex_session_metadata(path)
                if metadata is not None:
                    candidates.append(metadata)
        except (OSError, RuntimeError):
            continue
    candidates.sort(key=lambda item: item.mtime, reverse=True)
    return candidates


def _find_latest_resumable_session(
    workdir: Path,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _CodexSessionMetadata | None:
    normalized_workdir = normalize_path_str(str(workdir.resolve()))
    for metadata in _iter_codex_session_metadata(session_roots=session_roots):
        if metadata.cwd == normalized_workdir:
            return metadata
    return None


def _find_codex_session_by_id(
    workdir: Path,
    session_id: str,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _CodexSessionMetadata | None:
    normalized_workdir = normalize_path_str(str(workdir.resolve()))
    for metadata in _iter_codex_session_metadata(session_roots=session_roots):
        if metadata.session_id != session_id:
            continue
        if metadata.cwd is not None and metadata.cwd != normalized_workdir:
            return None
        return metadata
    return None


def _resolve_session_path_metadata(request: CodexExecRequest) -> _CodexSessionMetadata:
    if request.session_path is None:
        raise ValueError("Codex session_path continuation requires a session_path")
    session_path = request.session_path.resolve()
    metadata = _read_codex_session_metadata(session_path)
    if metadata is None:
        raise ValueError(f"Codex session_path could not be read: {session_path}")
    expected_cwd = normalize_path_str(str(request.cwd.resolve()))
    if metadata.cwd is not None and metadata.cwd != expected_cwd:
        raise ValueError(
            "Codex session_path belongs to a different workdir: "
            f"{metadata.cwd!r} != {expected_cwd!r}"
        )
    if metadata.session_id is None:
        raise ValueError("Codex session_path did not contain a session id")
    return metadata


def _resolve_continuation(request: CodexExecRequest) -> ProviderContinuationResolution:
    mode = cast(ProviderContinuationMode, request.continuation_mode)
    if mode is ProviderContinuationMode.NEW:
        return _new_continuation_resolution(request)

    if mode is ProviderContinuationMode.CONTINUE_LATEST:
        metadata = _find_latest_resumable_session(request.cwd)
        if metadata is None or metadata.session_id is None:
            raise ValueError(f"No resumable Codex session found for {request.cwd}")
        return ProviderContinuationResolution(
            requested_mode=mode,
            resolved_mode=ProviderContinuationMode.CONTINUE_LATEST,
            resolved_session_id=metadata.session_id,
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="latest",
        )

    if mode is ProviderContinuationMode.SESSION_ID:
        if request.session_id is None:
            raise ValueError("Codex session_id continuation requires a session_id")
        metadata = _find_codex_session_by_id(request.cwd, request.session_id)
        if metadata is None:
            raise ValueError(
                f"Codex session_id {request.session_id!r} was not found for workdir {request.cwd}"
            )
        return ProviderContinuationResolution(
            requested_mode=mode,
            requested_session_id=request.session_id,
            resolved_mode=ProviderContinuationMode.SESSION_ID,
            resolved_session_id=request.session_id,
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="session_id",
        )

    metadata = _resolve_session_path_metadata(request)
    return ProviderContinuationResolution(
        requested_mode=mode,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.SESSION_PATH,
        resolved_session_id=metadata.session_id,
        resolved_session_path=metadata.path,
        native_strategy="resume",
        matched_by="session_path",
    )


def _effective_output_path(request: CodexExecRequest) -> Path:
    return prepare_destination_path(
        request.output_path,
        prefix="codex_output_",
        suffix=".json",
        execution_id=request.execution_id,
    )


def _build_launch(
    request: CodexExecRequest,
    *,
    output_path: Path,
    continuation_resolution: ProviderContinuationResolution | None = None,
    use_ephemeral: bool = False,
) -> CodexExecSpec:
    extra_args = list(request.extra_args)
    if use_ephemeral and "--ephemeral" not in extra_args:
        extra_args.append("--ephemeral")
    resolved_continuation = (
        continuation_resolution
        if continuation_resolution is not None
        else _resolve_continuation(request)
    )
    return build_codex_exec_spec(
        codex_bin=request.binary,
        model=request.model,
        cwd=request.cwd,
        output_schema_path=request.output_schema_path,
        output_path=output_path,
        resume_session_id=resolved_continuation.resolved_session_id,
        model_reasoning=request.model_reasoning,
        model_controls=request.model_controls,
        json_output=True,
        sandbox=request.sandbox,
        full_auto=request.full_auto,
        skip_git_repo_check=request.skip_git_repo_check,
        extra_args=tuple(extra_args),
        unsupported_control_mode=request.unsupported_control_mode,
    )


def _build_exec_env(request: CodexExecRequest) -> dict[str, str]:
    from ..provider_contracts import get_provider_contract

    overlay = build_env_overlay(
        get_provider_contract("codex"),
        api_key=request.api_key,
        base_url=request.base_url,
    )
    return merge_env(request.env, overlay=overlay)


def _preview_exec_env(request: CodexExecRequest) -> dict[str, str]:
    from ..provider_contracts import get_provider_contract

    return {
        **(request.env or {}),
        **build_env_overlay(
            get_provider_contract("codex"),
            api_key=request.api_key,
            base_url=request.base_url,
        ),
    }


def _transcript_destination(request: CodexExecRequest, *, create_parent: bool) -> Path:
    return prepare_destination_path(
        request.transcript_path,
        prefix="codex_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
        create_parent=create_parent,
    )


def prepare_launch(request: CodexExecRequest) -> ProviderLaunchPreview:
    output_path = prepare_destination_path(
        request.output_path,
        prefix="codex_output_",
        suffix=".json",
        execution_id=request.execution_id,
        create_parent=False,
    )
    transcript_path = _transcript_destination(request, create_parent=False)
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(
        request,
        output_path=output_path,
        continuation_resolution=continuation_resolution,
        use_ephemeral="--ephemeral" in request.extra_args,
    )
    return _build_launch_preview_from_launch(
        request,
        launch=launch,
        output_path=output_path,
        transcript_path=transcript_path,
        continuation_resolution=continuation_resolution,
    )


def _build_launch_preview_from_launch(
    request: CodexExecRequest,
    *,
    launch: CodexExecSpec,
    output_path: Path,
    transcript_path: Path,
    continuation_resolution: ProviderContinuationResolution,
) -> ProviderLaunchPreview:
    return ProviderLaunchPreview(
        cmd_parts=tuple(launch.cmd_parts),
        display_text=launch.display_text,
        cwd=request.cwd,
        stdin_text=request.prompt,
        output_paths=(
            output_path,
            _transcript_destination(request, create_parent=False),
        ),
        effective_controls={
            "model": request.model,
            "effective_reasoning": launch.effective_reasoning,
            "applied_controls": dict(launch.applied_controls),
            "sandbox": request.sandbox,
            "full_auto": request.full_auto,
            "skip_git_repo_check": request.skip_git_repo_check,
            "ephemeral": "--ephemeral" in launch.cmd_parts,
            "schema_enforced_output": request.output_schema_path is not None,
            "continuation_mode": continuation_resolution.resolved_mode.value,
            "resumed_session_id": continuation_resolution.resolved_session_id,
        },
        redacted_env=redact_env_for_preview(_preview_exec_env(request)),
        control_resolution=launch.control_resolution,
        continuation_resolution=continuation_resolution,
    )


def find_session(
    workdir: str | Path,
    since_ts: float,
    *,
    session_roots: list[Path] | None = None,
) -> CodexSessionLookupResult:
    path = find_codex_session(
        normalize_path_str(str(Path(workdir).resolve())),
        since_ts,
        session_roots=session_roots,
        max_scan=_MAX_CODEX_SESSION_SCAN,
    )
    if path is None:
        return CodexSessionLookupResult(status=CodexSessionLookupStatus.NOT_FOUND)
    return CodexSessionLookupResult(
        status=CodexSessionLookupStatus.FOUND,
        path=path,
        matched_by="cwd",
    )


def get_conversation(source: CodexSessionLookupResult | Path) -> CodexConversationResult:
    if isinstance(source, CodexSessionLookupResult):
        if source.status is not CodexSessionLookupStatus.FOUND or source.path is None:
            return CodexConversationResult(
                status=source.status,
                source_path=source.path,
                text="",
                line_count=0,
            )
        source_path = source.path
    else:
        source_path = Path(source)
        if not source_path.exists():
            return CodexConversationResult(
                status=CodexSessionLookupStatus.NOT_FOUND,
                source_path=source_path,
                text="",
                line_count=0,
            )
    text = source_path.read_text(encoding="utf-8")
    return CodexConversationResult(
        status=CodexSessionLookupStatus.FOUND,
        source_path=source_path,
        text=text,
        line_count=len(text.splitlines()),
    )


def parse_output(output_text: str) -> CodexParsedOutput:
    stripped = output_text.strip()
    if not stripped:
        return CodexParsedOutput(parsed_payload=None, normalized_text="", parse_skipped=True)
    try:
        parsed = json.loads(stripped)
    except Exception as exc:
        return CodexParsedOutput(
            parsed_payload=None, normalized_text=stripped, parse_error=str(exc)
        )
    if not isinstance(parsed, dict):
        return CodexParsedOutput(
            parsed_payload=None,
            normalized_text=stripped,
            parse_error="Codex manifest must be a JSON object",
        )

    raw_files = parsed.get("files", [])
    files: list[dict[str, str]] = []
    if isinstance(raw_files, dict):
        for path, contents in raw_files.items():
            if isinstance(path, str) and isinstance(contents, str):
                files.append({"path": path, "contents": contents})
    elif isinstance(raw_files, list):
        for entry in raw_files:
            if not isinstance(entry, dict):
                continue
            path = entry.get("path")
            contents = entry.get("contents")
            if isinstance(path, str) and isinstance(contents, str):
                files.append({"path": path, "contents": contents})
    parsed["files"] = files
    normalized_text = json.dumps(parsed, indent=2)
    return CodexParsedOutput(parsed_payload=parsed, normalized_text=normalized_text)


def materialize_files(
    target_root: str | Path,
    files: list[dict[str, object]],
) -> list[Path]:
    root = Path(target_root)
    written_paths: list[Path] = []
    for entry in files:
        rel = entry.get("path")
        contents = entry.get("contents")
        if not isinstance(rel, str) or not isinstance(contents, str):
            raise ValueError("Manifest file entries must contain string path and contents")
        rel_path = PurePosixPath(rel)
        if rel_path.is_absolute() or ".." in rel_path.parts:
            raise ValueError(f"Invalid file path in manifest: {rel}")
        target = root / Path(*rel_path.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(contents, encoding="utf-8")
        written_paths.append(target)
    return written_paths


async def _run_raw_with_context(
    request: CodexExecRequest,
    *,
    launch: CodexExecSpec,
    launch_preview: ProviderLaunchPreview,
    continuation_resolution: ProviderContinuationResolution,
) -> tuple[
    InteractiveCliRunResult | CliRunResult,
    CodexSessionLookupResult | None,
    Path,
    tuple[CodexRetryRecord, ...],
]:
    output_path = _effective_output_path(request)
    transcript_path = prepare_destination_path(
        request.transcript_path,
        prefix="codex_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
    )
    retry_history: list[CodexRetryRecord] = []
    retries_used = 0
    use_ephemeral = "--ephemeral" in request.extra_args
    current_attempt = 0

    while True:
        try:
            output_path.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            _LOGGER.debug("Unable to clear stale Codex output path %s before attempt", output_path)

        current_launch = launch
        current_launch_preview = launch_preview
        if use_ephemeral != ("--ephemeral" in launch.cmd_parts):
            current_launch = _build_launch(
                request,
                output_path=output_path,
                continuation_resolution=continuation_resolution,
                use_ephemeral=use_ephemeral,
            )
            current_launch_preview = _build_launch_preview_from_launch(
                request,
                launch=current_launch,
                output_path=output_path,
                transcript_path=transcript_path,
                continuation_resolution=continuation_resolution,
            )
        current_attempt += 1
        emit_provider_event(
            callback=request.event_callback,
            provider="codex",
            attempt_index=current_attempt,
            kind=ProviderEventKind.ATTEMPT_STARTED,
            data=AttemptStartedEventData(
                launch=current_launch_preview,
                max_cli_attempts=max(1, request.transient_retries + 1)
                + (1 if request.ephemeral_retry_on_state_db_failure else 0),
            ),
            logger=_LOGGER,
        )
        raw_result, session_lookup = await _run_single_attempt(
            request,
            launch=current_launch,
            transcript_path=transcript_path,
            continuation_resolution=continuation_resolution,
            attempt_index=current_attempt,
        )
        emit_provider_event(
            callback=request.event_callback,
            provider="codex",
            attempt_index=current_attempt,
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=raw_result.returncode,
                timed_out=getattr(raw_result, "timed_out", False),
                conversation_path=getattr(raw_result, "conversation_path", None),
                started_at=getattr(raw_result, "started_at", None),
                cli_attempt_used=getattr(raw_result, "cli_attempt_used", current_attempt),
                max_cli_attempts=getattr(raw_result, "max_cli_attempts", current_attempt),
            ),
            logger=_LOGGER,
        )
        if _returncode(raw_result) in (None, 0):
            return raw_result, session_lookup, output_path, tuple(retry_history)

        failure, _ = _classify_attempt_failure(raw_result)
        if failure is None:
            return raw_result, session_lookup, output_path, tuple(retry_history)

        next_use_ephemeral = use_ephemeral
        launch_variant = "default"
        allow_retry = False
        if (
            failure.category == "state_db_locked"
            and request.ephemeral_retry_on_state_db_failure
            and not use_ephemeral
        ):
            next_use_ephemeral = True
            launch_variant = "ephemeral"
            allow_retry = True
        elif failure.retryable and retries_used < max(0, request.transient_retries):
            retries_used += 1
            allow_retry = True

        if not allow_retry:
            return raw_result, session_lookup, output_path, tuple(retry_history)

        delay = max(0.0, request.transient_retry_backoff_seconds) * (len(retry_history) + 1)
        retry_history.append(
            CodexRetryRecord(
                attempt_index=len(retry_history) + 1,
                category=failure.category,
                delay_seconds=delay,
                launch_variant=launch_variant,
            )
        )
        emit_provider_event(
            callback=request.event_callback,
            provider="codex",
            attempt_index=current_attempt,
            kind=ProviderEventKind.RECOVERY_APPLIED,
            data=RecoveryAppliedEventData(
                category=failure.category,
                delay_seconds=delay,
                next_attempt_index=current_attempt + 1,
                launch_variant=launch_variant,
            ),
            logger=_LOGGER,
        )
        if delay > 0:
            await asyncio.sleep(delay)
        use_ephemeral = next_use_ephemeral


def _stdout_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stdout_text
    return raw_result.stdout.decode("utf-8", errors="replace")


def _stderr_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stderr_text
    return raw_result.stderr.decode("utf-8", errors="replace")


def _returncode(raw_result: InteractiveCliRunResult | CliRunResult) -> int | None:
    return raw_result.returncode


def _classify_attempt_failure(
    raw_result: InteractiveCliRunResult | CliRunResult,
) -> tuple[FailureClassification | None, str]:
    detail = _stderr_text(raw_result).strip() or _stdout_text(raw_result).strip()
    if not detail:
        return None, ""
    return classify_provider_failure(provider="codex", stderr_text=detail), detail


async def _run_single_attempt(
    request: CodexExecRequest,
    *,
    launch: CodexExecSpec,
    transcript_path: Path,
    continuation_resolution: ProviderContinuationResolution,
    attempt_index: int,
) -> tuple[InteractiveCliRunResult | CliRunResult, CodexSessionLookupResult | None]:
    start_ts = None
    raw_result: InteractiveCliRunResult | CliRunResult
    session_lookup: CodexSessionLookupResult | None

    def locate_source() -> Path | None:
        if continuation_resolution.resolved_session_path is not None:
            return continuation_resolution.resolved_session_path
        if start_ts is None:
            return None
        lookup = find_session(request.cwd, start_ts)
        return lookup.path if lookup.status is CodexSessionLookupStatus.FOUND else None

    transcript_strategy = TranscriptMirrorStrategy(
        provider_label="Codex",
        destination=transcript_path,
        locate_source=locate_source,
        poll_interval=1.0,
        progress_callback=build_progress_callback(
            provider="codex",
            get_attempt_index=lambda: attempt_index,
            event_callback=request.event_callback,
            transcript_progress_callback=request.transcript_progress_callback,
            logger=_LOGGER,
        ),
    )
    start_ts = time.time()
    try:
        raw_result = await run_interactive_session(
            cmd_parts=launch.cmd_parts,
            cwd=request.cwd,
            stdin_text=request.prompt,
            logger=_LOGGER,
            provider_label="Codex",
            job_name=request.cwd.name or "codex",
            process_label="Codex process",
            timeout_seconds=request.timeout_seconds,
            env=_build_exec_env(request),
            transcript_factory=lambda proc: mirror_session_transcript(
                job_name=request.cwd.name or "codex",
                phase_tag="",
                logger=_LOGGER,
                proc=proc,
                strategy=transcript_strategy,
            ),
        )
        session_lookup = _resolve_session_lookup_from_result(
            request,
            raw_result,
            continuation_resolution=continuation_resolution,
        )
        if session_lookup is None and raw_result.conversation_path is not None:
            session_lookup = CodexSessionLookupResult(
                status=CodexSessionLookupStatus.FOUND,
                path=raw_result.conversation_path,
                matched_by="transcript_capture",
            )
        return raw_result, session_lookup
    except SessionExecutionTimeoutError as exc:
        raw_result = CliRunResult(
            command=launch.cmd_parts,
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=0.0,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=str(exc),
        )
        session_lookup = None
        if continuation_resolution.resolved_session_path is not None:
            session_lookup = CodexSessionLookupResult(
                status=CodexSessionLookupStatus.FOUND,
                path=continuation_resolution.resolved_session_path,
                matched_by=continuation_resolution.matched_by,
            )
        elif getattr(exc, "conversation_path", None) is not None:
            session_lookup = CodexSessionLookupResult(
                status=CodexSessionLookupStatus.FOUND,
                path=exc.conversation_path,
                matched_by="transcript_capture",
            )
        return raw_result, session_lookup


def _resolve_session_lookup_from_result(
    request: CodexExecRequest,
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    continuation_resolution: ProviderContinuationResolution,
) -> CodexSessionLookupResult | None:
    if continuation_resolution.resolved_session_path is not None:
        return CodexSessionLookupResult(
            status=CodexSessionLookupStatus.FOUND,
            path=continuation_resolution.resolved_session_path,
            matched_by=continuation_resolution.matched_by,
        )
    started_at = getattr(raw_result, "started_at", None)
    if started_at is None:
        return None
    return find_session(request.cwd, started_at)


def _build_exec_result(
    request: CodexExecRequest,
    launch: CodexExecSpec,
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    continuation_resolution: ProviderContinuationResolution,
    output_path: Path,
    retry_history: tuple[CodexRetryRecord, ...] = (),
    session_lookup: CodexSessionLookupResult | None = None,
) -> CodexExecResult:
    if output_path.exists():
        try:
            output_text = output_path.read_text(encoding="utf-8")
        except OSError:
            output_text = ""
    else:
        output_text = ""
    parsed_output = parse_output(output_text)
    if parsed_output.parsed_payload is not None and parsed_output.normalized_text:
        output_path.write_text(parsed_output.normalized_text, encoding="utf-8")
    failure_classification = None
    if _returncode(raw_result) not in (None, 0):
        detail = _stderr_text(raw_result).strip() or _stdout_text(raw_result).strip()
        if detail:
            failure_classification = classify_provider_failure(
                provider="codex",
                stderr_text=detail,
            )
    return CodexExecResult(
        request=request,
        launch=launch,
        raw_result=raw_result,
        raw_execution=build_raw_execution(
            raw_result,
            conversation_path=session_lookup.path if session_lookup is not None else None,
        ),
        parsed_output=parsed_output,
        effective_reasoning=launch.effective_reasoning,
        applied_controls=launch.applied_controls,
        control_resolution=launch.control_resolution,
        continuation_resolution=continuation_resolution,
        retry_history=retry_history,
        failure_classification=failure_classification,
        session_lookup=session_lookup,
        output_path=output_path,
    )


async def run_raw(request: CodexExecRequest) -> InteractiveCliRunResult | CliRunResult:
    continuation_resolution = _resolve_continuation(request)
    output_path = _effective_output_path(request)
    launch = _build_launch(
        request,
        output_path=output_path,
        continuation_resolution=continuation_resolution,
    )
    launch_preview = _build_launch_preview_from_launch(
        request,
        launch=launch,
        output_path=output_path,
        transcript_path=_transcript_destination(request, create_parent=False),
        continuation_resolution=continuation_resolution,
    )
    raw_result, _, _, _ = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    return raw_result


async def run(request: CodexExecRequest) -> CodexExecResult:
    continuation_resolution = _resolve_continuation(request)
    output_path = _effective_output_path(request)
    launch = _build_launch(
        request,
        output_path=output_path,
        continuation_resolution=continuation_resolution,
    )
    launch_preview = _build_launch_preview_from_launch(
        request,
        launch=launch,
        output_path=output_path,
        transcript_path=_transcript_destination(request, create_parent=False),
        continuation_resolution=continuation_resolution,
    )
    raw_result, session_lookup, _, retry_history = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    result = _build_exec_result(
        request,
        launch,
        raw_result,
        continuation_resolution=continuation_resolution,
        output_path=output_path,
        retry_history=retry_history,
        session_lookup=session_lookup,
    )
    emit_provider_event(
        callback=request.event_callback,
        provider="codex",
        attempt_index=max(1, getattr(raw_result, "cli_attempt_used", len(retry_history) + 1)),
        kind=ProviderEventKind.PARSE_FINISHED,
        data=ParseFinishedEventData(
            parse_skipped=result.parsed_output.parse_skipped,
            parse_error=result.parsed_output.parse_error,
        ),
        logger=_LOGGER,
    )
    return result


def run_sync(request: CodexExecRequest) -> CodexExecResult:
    return cast(CodexExecResult, run_sync_via_asyncio(run(request)))


__all__ = [
    "CodexConversationResult",
    "CodexExecRequest",
    "CodexExecResult",
    "CodexParsedOutput",
    "CodexRetryRecord",
    "CodexSessionLookupResult",
    "CodexSessionLookupStatus",
    "SUPPORT_STATE",
    "find_session",
    "get_conversation",
    "materialize_files",
    "materialize_prompt_file_references",
    "parse_output",
    "prepare_launch",
    "run",
    "run_raw",
    "run_sync",
]
