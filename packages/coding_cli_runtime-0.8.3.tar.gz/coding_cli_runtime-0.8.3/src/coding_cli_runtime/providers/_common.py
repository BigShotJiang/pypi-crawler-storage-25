"""Internal helpers shared by preview Stage 5 provider adapters."""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from ..contracts import CliRunResult
from ..session_execution import InteractiveCliRunResult, SessionProgressEvent
from ._types import (
    ProviderEventCallback,
    ProviderEventKind,
    ProviderExecEvent,
    ProviderRawExecution,
    TranscriptProgressEventData,
)


def merge_env(
    base_env: dict[str, str] | None,
    *,
    overlay: dict[str, str] | None = None,
) -> dict[str, str]:
    env = dict(os.environ)
    if base_env:
        env.update(base_env)
    if overlay:
        env.update(overlay)
    return env


def default_execution_id() -> str:
    return uuid4().hex


def _temp_execution_root(execution_id: str | None) -> Path:
    token = execution_id or default_execution_id()
    return Path(tempfile.gettempdir()) / "coding-cli-runtime" / token


def prepare_destination_path(
    path: str | Path | None,
    *,
    prefix: str,
    suffix: str,
    execution_id: str | None = None,
    create_parent: bool = True,
) -> Path:
    if path is not None:
        destination = Path(path)
        if create_parent:
            destination.parent.mkdir(parents=True, exist_ok=True)
        return destination
    destination = _temp_execution_root(execution_id) / f"{prefix}{suffix}"
    if create_parent:
        destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def read_text_if_exists(path: Path | None) -> str | None:
    if path is None or not path.exists():
        return None
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return None


def materialize_prefixed_references(
    prompt_text: str,
    file_paths: tuple[Path, ...],
    *,
    prefix: str,
    singular_label: str = "File reference",
    plural_label: str = "File references",
) -> str:
    if not file_paths:
        return prompt_text
    rendered: list[str] = []
    for path in file_paths:
        normalized = Path(path)
        if normalized.is_absolute():
            raise ValueError(
                f"Prompt file references must be relative paths. Got absolute path: {normalized}"
            )
        rendered.append(f"{prefix}{normalized.as_posix()}")
    suffix = "\n".join(rendered)
    prompt_prefix = prompt_text.rstrip()
    if prompt_prefix:
        return f"{prompt_prefix}\n\n{suffix}\n"
    return f"{suffix}\n"


def redact_env_for_preview(env: Mapping[str, str] | None) -> dict[str, str]:
    if not env:
        return {}
    redacted: dict[str, str] = {}
    for key, value in env.items():
        upper = key.upper()
        if any(marker in upper for marker in ("KEY", "TOKEN", "SECRET", "PASSWORD")):
            redacted[key] = "<redacted>"
        else:
            redacted[key] = value
    return redacted


def emit_provider_event(
    *,
    callback: ProviderEventCallback | None,
    provider: str,
    attempt_index: int,
    kind: ProviderEventKind,
    data: Any,
    logger: logging.Logger,
) -> None:
    if callback is None:
        return
    try:
        callback(
            ProviderExecEvent(
                kind=kind,
                provider=provider,
                attempt_index=attempt_index,
                data=data,
            )
        )
    except Exception as exc:
        logger.debug(
            "Provider event callback failed for %s %s/%s: %s",
            provider,
            kind.value,
            attempt_index,
            exc,
        )


def build_progress_callback(
    *,
    provider: str,
    get_attempt_index: Callable[[], int],
    event_callback: ProviderEventCallback | None,
    transcript_progress_callback: Callable[[SessionProgressEvent], None] | None,
    logger: logging.Logger,
) -> Callable[[SessionProgressEvent], None] | None:
    if event_callback is None and transcript_progress_callback is None:
        return None

    def callback(event: SessionProgressEvent) -> None:
        if transcript_progress_callback is not None:
            transcript_progress_callback(event)
        emit_provider_event(
            callback=event_callback,
            provider=provider,
            attempt_index=get_attempt_index(),
            kind=ProviderEventKind.TRANSCRIPT_PROGRESS,
            data=TranscriptProgressEventData(progress=event),
            logger=logger,
        )

    return callback


def build_raw_execution(
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    conversation_path: Path | None = None,
    started_at: float | None = None,
) -> ProviderRawExecution:
    if isinstance(raw_result, CliRunResult):
        stdout = raw_result.stdout_text.encode("utf-8")
        stderr = raw_result.stderr_text.encode("utf-8")
        timed_out = raw_result.timed_out
        resolved_conversation_path = conversation_path
        resolved_started_at = (
            started_at
            if isinstance(started_at, (int, float))
            else getattr(raw_result, "started_at", None)
        )
        finished_at = None
        if isinstance(resolved_started_at, (int, float)):
            finished_at = datetime.fromtimestamp(
                float(resolved_started_at) + max(0.0, raw_result.duration_seconds),
                tz=timezone.utc,
            )
        return ProviderRawExecution(
            returncode=raw_result.returncode,
            timed_out=timed_out,
            stdout=stdout,
            stderr=stderr,
            conversation_path=resolved_conversation_path,
            started_at=resolved_started_at
            if isinstance(resolved_started_at, (int, float))
            else None,
            finished_at=finished_at,
            native_result=raw_result,
        )

    return ProviderRawExecution(
        returncode=raw_result.returncode,
        timed_out=False,
        stdout=raw_result.stdout,
        stderr=raw_result.stderr,
        conversation_path=raw_result.conversation_path or conversation_path,
        started_at=raw_result.started_at,
        finished_at=None,
        native_result=raw_result,
    )


def run_sync_via_asyncio(coro: Any) -> Any:
    return asyncio.run(coro)
