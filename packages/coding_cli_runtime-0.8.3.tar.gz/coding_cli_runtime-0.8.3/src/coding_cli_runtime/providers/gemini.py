"""Preview Gemini runtime adapter."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import shlex
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, cast

from ..contracts import CliLaunchSpec, CliRunResult, ErrorCode
from ..failure_classification import FailureClassification, classify_provider_failure
from ..headless import build_gemini_headless_core
from ..provider_contracts import (
    build_env_overlay,
    get_provider_contract,
    render_prompt,
    resolve_session_search_paths,
    resolve_workspace_env,
)
from ..provider_controls import ProviderControlResolution, build_provider_control_resolution
from ..session_execution import (
    InteractiveCliRunResult,
    SessionExecutionTimeoutError,
    SessionProgressEvent,
    SessionRetryDecision,
    TranscriptMirrorStrategy,
    mirror_session_transcript,
    run_interactive_session,
)
from ._common import (
    build_progress_callback,
    build_raw_execution,
    default_execution_id,
    emit_provider_event,
    materialize_prefixed_references,
    merge_env,
    prepare_destination_path,
    redact_env_for_preview,
    run_sync_via_asyncio,
)
from ._types import (
    AttemptFinishedEventData,
    AttemptStartedEventData,
    ParseFinishedEventData,
    ProviderContinuationMode,
    ProviderContinuationResolution,
    ProviderEventCallback,
    ProviderEventKind,
    ProviderLaunchPreview,
    ProviderRawExecution,
    RecoveryAppliedEventData,
    normalize_continuation_request,
)

_LOGGER = logging.getLogger(__name__)

SUPPORT_STATE = "sync_parity"
_DEFAULT_TRANSIENT_RETRIES = 2
_DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS = 3.0


class GeminiSessionLookupStatus(str, Enum):
    FOUND = "found"
    NOT_FOUND = "not_found"


@dataclass(frozen=True)
class GeminiExecRequest:
    model: str
    prompt: str
    cwd: Path
    continuation_mode: ProviderContinuationMode | str = ProviderContinuationMode.NEW
    session_id: str | None = None
    session_path: Path | None = None
    binary: str | None = None
    api_key: str | None = None
    base_url: str | None = None
    extra_args: tuple[str, ...] = ()
    timeout_seconds: float | None = None
    env: dict[str, str] | None = None
    transcript_path: Path | None = None
    transcript_progress_callback: Callable[[SessionProgressEvent], None] | None = None
    event_callback: ProviderEventCallback | None = None
    transient_retries: int = _DEFAULT_TRANSIENT_RETRIES
    transient_retry_backoff_seconds: float = _DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS
    execution_id: str = field(default_factory=default_execution_id)

    def __post_init__(self) -> None:
        object.__setattr__(self, "cwd", Path(self.cwd))
        object.__setattr__(self, "extra_args", tuple(self.extra_args))
        normalized_mode, normalized_session_id, normalized_session_path = (
            normalize_continuation_request(
                self.continuation_mode,
                session_id=self.session_id,
                session_path=self.session_path,
            )
        )
        object.__setattr__(self, "continuation_mode", normalized_mode)
        object.__setattr__(self, "session_id", normalized_session_id)
        object.__setattr__(self, "session_path", normalized_session_path)
        if self.env is not None:
            object.__setattr__(self, "env", dict(self.env))
        if self.transcript_path is not None:
            object.__setattr__(self, "transcript_path", Path(self.transcript_path))


@dataclass(frozen=True)
class GeminiParsedOutput:
    parsed_payload: object | None
    normalized_text: str
    extracted_json_text: str | None = None
    parse_skipped: bool = False
    parse_error: str | None = None


@dataclass(frozen=True)
class GeminiRetryRecord:
    attempt_index: int
    category: str
    delay_seconds: float


@dataclass(frozen=True)
class GeminiSessionLookupResult:
    status: GeminiSessionLookupStatus
    path: Path | None = None
    matched_by: str | None = None
    candidate_count: int = 0
    project_hash: str | None = None

    def __post_init__(self) -> None:
        if self.path is not None:
            object.__setattr__(self, "path", Path(self.path))


@dataclass(frozen=True)
class GeminiConversationResult:
    status: GeminiSessionLookupStatus
    source_path: Path | None
    text: str
    line_count: int

    def __post_init__(self) -> None:
        if self.source_path is not None:
            object.__setattr__(self, "source_path", Path(self.source_path))


@dataclass(frozen=True)
class GeminiExecResult:
    request: GeminiExecRequest
    launch: CliLaunchSpec
    raw_result: InteractiveCliRunResult | CliRunResult
    raw_execution: ProviderRawExecution
    parsed_output: GeminiParsedOutput
    control_resolution: ProviderControlResolution
    continuation_resolution: ProviderContinuationResolution
    retry_history: tuple[GeminiRetryRecord, ...] = ()
    failure_classification: FailureClassification | None = None
    session_lookup: GeminiSessionLookupResult | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "retry_history", tuple(self.retry_history))


@dataclass(frozen=True)
class _GeminiSessionMetadata:
    path: Path
    project_hash: str | None
    start_time_ts: float | None
    last_updated_ts: float | None
    mtime_ts: float


def _gemini_project_hash(workdir: Path) -> str:
    return hashlib.sha256(str(workdir.resolve()).encode("utf-8")).hexdigest()


def _gemini_chat_dir_candidates(workdir: Path, *, tmp_root: Path) -> list[Path]:
    working_name = workdir.name
    normalized_name = re.sub(r"[^A-Za-z0-9._-]+", "-", working_name).strip("-_.") or working_name
    candidates = [
        tmp_root / _gemini_project_hash(workdir) / "chats",
        tmp_root / working_name / "chats",
        tmp_root / working_name.replace("_", "-") / "chats",
        tmp_root / normalized_name / "chats",
        tmp_root / normalized_name.replace("_", "-") / "chats",
        tmp_root / "workspace" / "chats",
    ]
    return list(dict.fromkeys(candidates))


def _parse_gemini_session_timestamp(raw: object) -> float | None:
    if not isinstance(raw, str) or not raw.strip():
        return None
    candidate = raw.strip()
    if candidate.endswith("Z"):
        candidate = candidate[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(candidate).timestamp()
    except ValueError:
        return None


def _read_gemini_session_metadata(path: Path) -> _GeminiSessionMetadata | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    try:
        mtime_ts = path.stat().st_mtime
    except OSError:
        return None
    project_hash = payload.get("projectHash")
    return _GeminiSessionMetadata(
        path=path,
        project_hash=project_hash if isinstance(project_hash, str) else None,
        start_time_ts=_parse_gemini_session_timestamp(payload.get("startTime")),
        last_updated_ts=_parse_gemini_session_timestamp(payload.get("lastUpdated")),
        mtime_ts=mtime_ts,
    )


def _session_matches_call_window(metadata: _GeminiSessionMetadata, since_ts: float) -> bool:
    if metadata.start_time_ts is not None:
        return metadata.start_time_ts >= since_ts - 10
    fallback_ts = (
        metadata.last_updated_ts if metadata.last_updated_ts is not None else metadata.mtime_ts
    )
    return fallback_ts >= since_ts - 10


def _session_sort_key(metadata: _GeminiSessionMetadata) -> tuple[float, float]:
    primary = metadata.start_time_ts
    if primary is None:
        primary = (
            metadata.last_updated_ts if metadata.last_updated_ts is not None else metadata.mtime_ts
        )
    return (primary, metadata.mtime_ts)


def _latest_gemini_session(
    chats_dir: Path,
    since_ts: float | None,
    *,
    expected_project_hash: str | None = None,
) -> _GeminiSessionMetadata | None:
    if not chats_dir.exists():
        return None
    candidates: list[_GeminiSessionMetadata] = []
    for path in chats_dir.glob("session-*.json"):
        metadata = _read_gemini_session_metadata(path)
        if metadata is None:
            continue
        if expected_project_hash and metadata.project_hash != expected_project_hash:
            continue
        if since_ts is None or _session_matches_call_window(metadata, since_ts):
            candidates.append(metadata)
    if not candidates:
        return None
    candidates.sort(key=_session_sort_key, reverse=True)
    return candidates[0]


def find_session(
    workdir: str | Path,
    since_ts: float,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> GeminiSessionLookupResult:
    workdir_path = Path(workdir).resolve()
    expected_project_hash = _gemini_project_hash(workdir_path)
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("gemini"))
    )
    candidates: list[_GeminiSessionMetadata] = []
    for root in roots:
        for chats_dir in _gemini_chat_dir_candidates(workdir_path, tmp_root=root):
            match = _latest_gemini_session(
                chats_dir,
                since_ts,
                expected_project_hash=expected_project_hash,
            )
            if match is not None:
                candidates.append(match)

    if not candidates:
        fallback_matches: list[_GeminiSessionMetadata] = []
        for root in roots:
            for path in root.glob("*/chats/session-*.json"):
                metadata = _read_gemini_session_metadata(path)
                if metadata is None:
                    continue
                if metadata.project_hash != expected_project_hash:
                    continue
                if _session_matches_call_window(metadata, since_ts):
                    fallback_matches.append(metadata)
        candidates = fallback_matches

    if not candidates:
        return GeminiSessionLookupResult(
            status=GeminiSessionLookupStatus.NOT_FOUND,
            project_hash=expected_project_hash,
        )
    candidates.sort(key=_session_sort_key, reverse=True)
    selected = candidates[0]
    return GeminiSessionLookupResult(
        status=GeminiSessionLookupStatus.FOUND,
        path=selected.path,
        matched_by="project_hash",
        candidate_count=len(candidates),
        project_hash=expected_project_hash,
    )


def get_conversation(source: GeminiSessionLookupResult | Path) -> GeminiConversationResult:
    if isinstance(source, GeminiSessionLookupResult):
        if source.status is not GeminiSessionLookupStatus.FOUND or source.path is None:
            return GeminiConversationResult(
                status=source.status,
                source_path=source.path,
                text="",
                line_count=0,
            )
        source_path = source.path
    else:
        source_path = Path(source)
        if not source_path.exists():
            return GeminiConversationResult(
                status=GeminiSessionLookupStatus.NOT_FOUND,
                source_path=source_path,
                text="",
                line_count=0,
            )
    text = source_path.read_text(encoding="utf-8")
    return GeminiConversationResult(
        status=GeminiSessionLookupStatus.FOUND,
        source_path=source_path,
        text=text,
        line_count=len(text.splitlines()),
    )


def materialize_prompt_file_references(
    prompt_text: str,
    file_paths: tuple[str | Path, ...] | list[str | Path],
) -> str:
    prefix = get_provider_contract("gemini").io.file_reference_prefix
    if not prefix:
        raise NotImplementedError(
            "Gemini prompt file references are not enabled in coding_cli_runtime"
        )
    normalized_paths = tuple(Path(path) for path in file_paths)
    return materialize_prefixed_references(
        prompt_text,
        normalized_paths,
        prefix=prefix,
        singular_label="File reference",
        plural_label="File references",
    )


def _new_continuation_resolution(request: GeminiExecRequest) -> ProviderContinuationResolution:
    return ProviderContinuationResolution(
        requested_mode=cast(ProviderContinuationMode, request.continuation_mode),
        requested_session_id=request.session_id,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.NEW,
        native_strategy="fresh",
    )


def _find_latest_resumable_session(
    workdir: Path,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _GeminiSessionMetadata | None:
    workdir_path = workdir.resolve()
    expected_project_hash = _gemini_project_hash(workdir_path)
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("gemini"))
    )
    candidates: list[_GeminiSessionMetadata] = []
    for root in roots:
        for chats_dir in _gemini_chat_dir_candidates(workdir_path, tmp_root=root):
            match = _latest_gemini_session(
                chats_dir,
                None,
                expected_project_hash=expected_project_hash,
            )
            if match is not None:
                candidates.append(match)
    if not candidates:
        return None
    candidates.sort(key=_session_sort_key, reverse=True)
    return candidates[0]


def _find_gemini_session_by_id(
    workdir: Path,
    session_id: str,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _GeminiSessionMetadata | None:
    workdir_path = workdir.resolve()
    expected_project_hash = _gemini_project_hash(workdir_path)
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("gemini"))
    )
    for root in roots:
        for path in root.glob("*/chats/session-*.json"):
            metadata = _read_gemini_session_metadata(path)
            if metadata is None:
                continue
            if metadata.project_hash != expected_project_hash:
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if payload.get("sessionId") == session_id:
                return metadata
    return None


def _resolve_session_path_metadata(
    request: GeminiExecRequest,
) -> tuple[_GeminiSessionMetadata, str]:
    if request.session_path is None:
        raise ValueError("Gemini session_path continuation requires a session_path")
    session_path = request.session_path.resolve()
    metadata = _read_gemini_session_metadata(session_path)
    if metadata is None:
        raise ValueError(f"Gemini session_path could not be read: {session_path}")
    expected_project_hash = _gemini_project_hash(request.cwd.resolve())
    if metadata.project_hash is not None and metadata.project_hash != expected_project_hash:
        raise ValueError(
            "Gemini session_path belongs to a different project/workdir: "
            f"{metadata.project_hash!r} != {expected_project_hash!r}"
        )
    try:
        payload = json.loads(session_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Gemini session_path could not be parsed: {session_path}") from exc
    session_id = payload.get("sessionId")
    if not isinstance(session_id, str) or not session_id.strip():
        raise ValueError("Gemini session_path did not contain a sessionId")
    return metadata, session_id.strip()


def _resolve_continuation(request: GeminiExecRequest) -> ProviderContinuationResolution:
    mode = cast(ProviderContinuationMode, request.continuation_mode)
    if mode is ProviderContinuationMode.NEW:
        return _new_continuation_resolution(request)

    if mode is ProviderContinuationMode.CONTINUE_LATEST:
        metadata = _find_latest_resumable_session(request.cwd)
        if metadata is None:
            raise ValueError(f"No resumable Gemini session found for {request.cwd}")
        payload = json.loads(metadata.path.read_text(encoding="utf-8"))
        session_id = payload.get("sessionId")
        if not isinstance(session_id, str) or not session_id.strip():
            raise ValueError(f"Gemini latest session does not expose a sessionId: {metadata.path}")
        return ProviderContinuationResolution(
            requested_mode=mode,
            resolved_mode=ProviderContinuationMode.CONTINUE_LATEST,
            resolved_session_id=session_id.strip(),
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="project_hash_latest",
        )

    if mode is ProviderContinuationMode.SESSION_ID:
        if request.session_id is None:
            raise ValueError("Gemini session_id continuation requires a session_id")
        metadata = _find_gemini_session_by_id(request.cwd, request.session_id)
        if metadata is None:
            raise ValueError(
                f"Gemini session_id {request.session_id!r} was not found for workdir {request.cwd}"
            )
        return ProviderContinuationResolution(
            requested_mode=mode,
            requested_session_id=request.session_id,
            resolved_mode=ProviderContinuationMode.SESSION_ID,
            resolved_session_id=request.session_id,
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="session_id",
        )

    metadata, session_id = _resolve_session_path_metadata(request)
    return ProviderContinuationResolution(
        requested_mode=mode,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.SESSION_PATH,
        resolved_session_id=session_id,
        resolved_session_path=metadata.path,
        native_strategy="resume",
        matched_by="session_path",
    )


def _build_launch(
    request: GeminiExecRequest,
    *,
    continuation_resolution: ProviderContinuationResolution | None = None,
) -> CliLaunchSpec:
    contract = get_provider_contract("gemini")
    resolved_continuation = (
        continuation_resolution
        if continuation_resolution is not None
        else _resolve_continuation(request)
    )
    cmd_parts = build_gemini_headless_core(request.model, binary=request.binary)
    if resolved_continuation.resolved_mode is not ProviderContinuationMode.NEW:
        if resolved_continuation.resolved_session_id is None:
            raise ValueError("Gemini continuation requires a resolved session_id")
        cmd_parts.extend(["--resume", resolved_continuation.resolved_session_id])
    payload = render_prompt(contract.headless.prompt, request.prompt)
    cmd_parts.extend(payload.args)
    if request.extra_args:
        cmd_parts.extend(request.extra_args)
    display = " ".join([*(shlex.quote(part) for part in cmd_parts), "<prompt>"])
    return CliLaunchSpec(
        cmd_parts=tuple(cmd_parts),
        display_text=display,
        stdin_text=payload.stdin_text,
    )


def _build_exec_env(request: GeminiExecRequest) -> dict[str, str]:
    contract = get_provider_contract("gemini")
    overlay = build_env_overlay(
        contract,
        api_key=request.api_key,
        base_url=request.base_url,
    )
    overlay.update(resolve_workspace_env(contract, request.cwd))
    return merge_env(request.env, overlay=overlay)


def _preview_exec_env(request: GeminiExecRequest) -> dict[str, str]:
    contract = get_provider_contract("gemini")
    overlay = build_env_overlay(
        contract,
        api_key=request.api_key,
        base_url=request.base_url,
    )
    overlay.update(resolve_workspace_env(contract, request.cwd))
    return {**(request.env or {}), **overlay}


def _transcript_destination(request: GeminiExecRequest, *, create_parent: bool) -> Path:
    return prepare_destination_path(
        request.transcript_path,
        prefix="gemini_conversation_",
        suffix=".json",
        execution_id=request.execution_id,
        create_parent=create_parent,
    )


def _build_control_resolution() -> ProviderControlResolution:
    return build_provider_control_resolution(provider="gemini")


def _prepare_launch_preview(
    request: GeminiExecRequest,
    *,
    launch: CliLaunchSpec,
    continuation_resolution: ProviderContinuationResolution,
) -> ProviderLaunchPreview:
    return ProviderLaunchPreview(
        cmd_parts=launch.cmd_parts,
        display_text=launch.display_text,
        cwd=request.cwd,
        stdin_text=launch.stdin_text,
        output_paths=(_transcript_destination(request, create_parent=False),),
        effective_controls={
            "model": request.model,
            "prompt_delivery": get_provider_contract("gemini").headless.prompt.delivery,
            "continuation_mode": continuation_resolution.resolved_mode.value,
            "resumed_session_id": continuation_resolution.resolved_session_id,
        },
        redacted_env=redact_env_for_preview(_preview_exec_env(request)),
        control_resolution=_build_control_resolution(),
        continuation_resolution=continuation_resolution,
    )


def prepare_launch(request: GeminiExecRequest) -> ProviderLaunchPreview:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(request, continuation_resolution=continuation_resolution)
    return _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )


def _repair_invalid_escape_sequences(text: str) -> str:
    return re.sub(r"\\([^\"\\/bfnrtu])", r"\\\\\1", text)


def _extract_json_candidate(raw_text: str) -> str:
    stripped = raw_text.strip()
    if stripped.startswith("```"):
        stripped = stripped.split("\n", 1)[1] if "\n" in stripped else ""
        if stripped.endswith("```"):
            stripped = stripped[: stripped.rfind("```")]
    stripped = stripped.strip()
    try:
        json.loads(stripped)
        return stripped
    except Exception:
        pass

    start_indices = [index for index, char in enumerate(stripped) if char in "{["]
    if not start_indices:
        return stripped
    for start in start_indices:
        opening = stripped[start]
        closing = "}" if opening == "{" else "]"
        depth = 0
        in_string = False
        escape = False
        for index in range(start, len(stripped)):
            char = stripped[index]
            if in_string:
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
                continue
            if char == opening:
                depth += 1
                continue
            if char == closing:
                depth -= 1
                if depth == 0:
                    candidate = stripped[start : index + 1]
                    try:
                        json.loads(candidate)
                        return candidate
                    except Exception:
                        repaired = _repair_invalid_escape_sequences(candidate)
                        try:
                            json.loads(repaired)
                            return repaired
                        except Exception:
                            continue
    repaired = _repair_invalid_escape_sequences(stripped)
    try:
        json.loads(repaired)
        return repaired
    except Exception:
        return stripped


def parse_output(output_text: str) -> GeminiParsedOutput:
    if not output_text.strip():
        return GeminiParsedOutput(
            parsed_payload=None,
            normalized_text="",
            parse_skipped=True,
        )
    candidate = _extract_json_candidate(output_text)
    try:
        parsed = json.loads(candidate)
    except Exception as exc:
        return GeminiParsedOutput(
            parsed_payload=None,
            normalized_text=candidate,
            extracted_json_text=candidate if candidate != output_text.strip() else None,
            parse_error=str(exc),
        )
    return GeminiParsedOutput(
        parsed_payload=parsed,
        normalized_text=candidate,
        extracted_json_text=candidate,
    )


def _stdout_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stdout_text
    return raw_result.stdout.decode("utf-8", errors="replace")


def _stderr_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stderr_text
    return raw_result.stderr.decode("utf-8", errors="replace")


def _returncode(raw_result: InteractiveCliRunResult | CliRunResult) -> int | None:
    return raw_result.returncode


async def _run_raw_with_context(
    request: GeminiExecRequest,
    *,
    launch: CliLaunchSpec,
    launch_preview: ProviderLaunchPreview,
    continuation_resolution: ProviderContinuationResolution,
) -> tuple[
    InteractiveCliRunResult | CliRunResult,
    tuple[GeminiRetryRecord, ...],
    GeminiSessionLookupResult | None,
]:
    retry_history: list[GeminiRetryRecord] = []
    max_cli_attempts = max(1, request.transient_retries + 1)
    current_attempt = 0
    raw_result: InteractiveCliRunResult | CliRunResult
    transcript_path = prepare_destination_path(
        request.transcript_path,
        prefix="gemini_conversation_",
        suffix=".json",
        execution_id=request.execution_id,
    )
    progress_callback = build_progress_callback(
        provider="gemini",
        get_attempt_index=lambda: max(1, current_attempt),
        event_callback=request.event_callback,
        transcript_progress_callback=request.transcript_progress_callback,
        logger=_LOGGER,
    )

    def locate_source() -> Path | None:
        lookup = find_session(request.cwd, start_ts)
        return lookup.path if lookup.status is GeminiSessionLookupStatus.FOUND else None

    transcript_strategy = TranscriptMirrorStrategy(
        provider_label="Gemini",
        destination=transcript_path,
        locate_source=locate_source,
        poll_interval=1.0,
        refresh_source_each_poll=True,
        progress_callback=progress_callback,
    )
    start_ts = datetime.now().timestamp()

    async def create_process(
        *cmd_parts: str,
        **kwargs: Any,
    ) -> asyncio.subprocess.Process:
        nonlocal current_attempt
        current_attempt += 1
        emit_provider_event(
            callback=request.event_callback,
            provider="gemini",
            attempt_index=current_attempt,
            kind=ProviderEventKind.ATTEMPT_STARTED,
            data=AttemptStartedEventData(
                launch=launch_preview,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return await asyncio.create_subprocess_exec(*cmd_parts, **kwargs)

    def retry_decider(
        result: InteractiveCliRunResult,
        cli_attempt: int,
        max_cli_attempts: int,
    ) -> SessionRetryDecision:
        failure = classify_provider_failure(
            provider="gemini",
            stderr_text=result.stderr.decode("utf-8", errors="replace"),
        )
        should_retry = failure.retryable and cli_attempt < max(1, max_cli_attempts)
        delay = (
            max(0.0, request.transient_retry_backoff_seconds) * cli_attempt if should_retry else 0.0
        )
        if should_retry:
            retry_history.append(
                GeminiRetryRecord(
                    attempt_index=cli_attempt,
                    category=failure.category,
                    delay_seconds=delay,
                )
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="gemini",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.ATTEMPT_FINISHED,
                data=AttemptFinishedEventData(
                    returncode=result.returncode,
                    timed_out=False,
                    conversation_path=result.conversation_path,
                    started_at=result.started_at,
                    cli_attempt_used=result.cli_attempt_used,
                    max_cli_attempts=result.max_cli_attempts,
                ),
                logger=_LOGGER,
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="gemini",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.RECOVERY_APPLIED,
                data=RecoveryAppliedEventData(
                    category=failure.category,
                    delay_seconds=delay,
                    next_attempt_index=cli_attempt + 1,
                ),
                logger=_LOGGER,
            )
        return SessionRetryDecision(
            retry=should_retry,
            delay_seconds=delay,
            category=failure.category,
        )

    try:
        raw_result = await run_interactive_session(
            cmd_parts=launch.cmd_parts,
            cwd=request.cwd,
            stdin_text=launch.stdin_text,
            logger=_LOGGER,
            provider_label="Gemini",
            job_name=request.cwd.name or "gemini",
            process_label="Gemini process",
            timeout_seconds=request.timeout_seconds,
            env=_build_exec_env(request),
            transcript_factory=lambda proc: mirror_session_transcript(
                job_name=request.cwd.name or "gemini",
                phase_tag="",
                logger=_LOGGER,
                proc=proc,
                strategy=transcript_strategy,
            ),
            create_process=create_process,
            max_cli_attempts=max_cli_attempts,
            retry_decider=retry_decider,
        )
        emit_provider_event(
            callback=request.event_callback,
            provider="gemini",
            attempt_index=max(1, getattr(raw_result, "cli_attempt_used", current_attempt or 1)),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=raw_result.returncode,
                timed_out=getattr(raw_result, "timed_out", False),
                conversation_path=getattr(raw_result, "conversation_path", None),
                started_at=getattr(raw_result, "started_at", None),
                cli_attempt_used=getattr(raw_result, "cli_attempt_used", None),
                max_cli_attempts=getattr(raw_result, "max_cli_attempts", max_cli_attempts),
            ),
            logger=_LOGGER,
        )
        if continuation_resolution.resolved_session_path is not None:
            session_lookup = GeminiSessionLookupResult(
                status=GeminiSessionLookupStatus.FOUND,
                path=continuation_resolution.resolved_session_path,
                matched_by=continuation_resolution.matched_by,
                candidate_count=1,
                project_hash=_gemini_project_hash(request.cwd),
            )
        else:
            session_lookup = find_session(request.cwd, raw_result.started_at)
            if (
                session_lookup.status is not GeminiSessionLookupStatus.FOUND
                and raw_result.conversation_path is not None
            ):
                session_lookup = GeminiSessionLookupResult(
                    status=GeminiSessionLookupStatus.FOUND,
                    path=raw_result.conversation_path,
                    matched_by="transcript_capture",
                    candidate_count=1,
                    project_hash=_gemini_project_hash(request.cwd),
                )
        return raw_result, tuple(retry_history), session_lookup
    except SessionExecutionTimeoutError as exc:
        raw_result = CliRunResult(
            command=launch.cmd_parts,
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=0.0,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=str(exc),
        )
        transcript_lookup: GeminiSessionLookupResult | None = None
        if continuation_resolution.resolved_session_path is not None:
            transcript_lookup = GeminiSessionLookupResult(
                status=GeminiSessionLookupStatus.FOUND,
                path=continuation_resolution.resolved_session_path,
                matched_by=continuation_resolution.matched_by,
                candidate_count=1,
                project_hash=_gemini_project_hash(request.cwd),
            )
        else:
            transcript_lookup = GeminiSessionLookupResult(
                status=GeminiSessionLookupStatus.FOUND,
                path=getattr(exc, "conversation_path", None),
                matched_by=(
                    "transcript_capture" if getattr(exc, "conversation_path", None) else None
                ),
                candidate_count=1 if getattr(exc, "conversation_path", None) else 0,
                project_hash=_gemini_project_hash(request.cwd),
            )
        if transcript_lookup is not None and transcript_lookup.path is None:
            transcript_lookup = None
        emit_provider_event(
            callback=request.event_callback,
            provider="gemini",
            attempt_index=max(1, current_attempt or 1),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=None,
                timed_out=True,
                conversation_path=getattr(exc, "conversation_path", None),
                started_at=getattr(exc, "started_at", start_ts),
                cli_attempt_used=current_attempt or 1,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return raw_result, tuple(retry_history), transcript_lookup


def _build_exec_result(
    request: GeminiExecRequest,
    launch: CliLaunchSpec,
    continuation_resolution: ProviderContinuationResolution,
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    retry_history: tuple[GeminiRetryRecord, ...] = (),
    session_lookup: GeminiSessionLookupResult | None = None,
) -> GeminiExecResult:
    stdout_text = _stdout_text(raw_result)
    stderr_text = _stderr_text(raw_result)
    parsed_output = parse_output(stdout_text)
    failure_classification = None
    if _returncode(raw_result) not in (None, 0):
        if stderr_text.strip():
            failure_classification = classify_provider_failure(
                provider="gemini",
                stderr_text=stderr_text,
            )
    return GeminiExecResult(
        request=request,
        launch=launch,
        raw_result=raw_result,
        raw_execution=build_raw_execution(
            raw_result,
            conversation_path=session_lookup.path if session_lookup is not None else None,
        ),
        parsed_output=parsed_output,
        control_resolution=_build_control_resolution(),
        continuation_resolution=continuation_resolution,
        retry_history=retry_history,
        failure_classification=failure_classification,
        session_lookup=session_lookup,
    )


async def run_raw(request: GeminiExecRequest) -> InteractiveCliRunResult | CliRunResult:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(request, continuation_resolution=continuation_resolution)
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )
    raw_result, _, _ = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    return raw_result


async def run(request: GeminiExecRequest) -> GeminiExecResult:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(request, continuation_resolution=continuation_resolution)
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )
    raw_result, retry_history, session_lookup = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    result = _build_exec_result(
        request,
        launch,
        continuation_resolution,
        raw_result,
        retry_history=retry_history,
        session_lookup=session_lookup,
    )
    emit_provider_event(
        callback=request.event_callback,
        provider="gemini",
        attempt_index=max(1, getattr(raw_result, "cli_attempt_used", len(retry_history) + 1)),
        kind=ProviderEventKind.PARSE_FINISHED,
        data=ParseFinishedEventData(
            parse_skipped=result.parsed_output.parse_skipped,
            parse_error=result.parsed_output.parse_error,
        ),
        logger=_LOGGER,
    )
    return result


def run_sync(request: GeminiExecRequest) -> GeminiExecResult:
    return cast(GeminiExecResult, run_sync_via_asyncio(run(request)))


__all__ = [
    "GeminiConversationResult",
    "GeminiExecRequest",
    "GeminiExecResult",
    "GeminiParsedOutput",
    "GeminiRetryRecord",
    "GeminiSessionLookupResult",
    "GeminiSessionLookupStatus",
    "SUPPORT_STATE",
    "find_session",
    "get_conversation",
    "materialize_prompt_file_references",
    "parse_output",
    "prepare_launch",
    "run",
    "run_raw",
    "run_sync",
]
