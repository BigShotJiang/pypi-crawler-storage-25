"""Preview helpers for validating parsed structured adapter output."""

from __future__ import annotations

from pathlib import Path

from ..schema_validation import SchemaValidationError, validate_payload
from ._types import StructuredValidationResult


def validate_structured_output(
    *,
    provider: str,
    model: str,
    schema_name: str,
    parsed_payload: object | None,
    transcript_path: str | Path | None = None,
    session_path: str | Path | None = None,
) -> StructuredValidationResult:
    normalized_transcript_path = Path(transcript_path) if transcript_path is not None else None
    normalized_session_path = Path(session_path) if session_path is not None else None

    if parsed_payload is None:
        return StructuredValidationResult(
            provider=provider,
            model=model,
            schema_name=schema_name,
            parsed_payload=None,
            valid=False,
            validation_error="No parsed payload available for validation.",
            transcript_path=normalized_transcript_path,
            session_path=normalized_session_path,
        )

    try:
        validate_payload(parsed_payload, schema_name)
    except SchemaValidationError as exc:
        return StructuredValidationResult(
            provider=provider,
            model=model,
            schema_name=schema_name,
            parsed_payload=parsed_payload,
            valid=False,
            validation_error=str(exc),
            transcript_path=normalized_transcript_path,
            session_path=normalized_session_path,
        )

    return StructuredValidationResult(
        provider=provider,
        model=model,
        schema_name=schema_name,
        parsed_payload=parsed_payload,
        valid=True,
        transcript_path=normalized_transcript_path,
        session_path=normalized_session_path,
    )


__all__ = ["validate_structured_output"]
