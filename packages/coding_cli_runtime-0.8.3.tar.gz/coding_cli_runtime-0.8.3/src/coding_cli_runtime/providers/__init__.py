"""Preview provider-aware runtime adapters.

Provider modules remain the canonical preview API. Flat aliases exported here
exist only as discoverability shims for obvious entry points.
"""

from ..provider_controls import ControlDefaultSource, ProviderControlResolution
from . import claude, codex, copilot, gemini
from ._types import (
    AttemptFinishedEventData,
    AttemptStartedEventData,
    ParseFinishedEventData,
    ProviderContinuationMode,
    ProviderContinuationResolution,
    ProviderEventCallback,
    ProviderEventKind,
    ProviderExecEvent,
    ProviderLaunchPreview,
    ProviderRawExecution,
    RecoveryAppliedEventData,
    StructuredValidationResult,
    TranscriptProgressEventData,
)
from .dispatcher import (
    ProviderExecRequest,
    ProviderExecResult,
    run_provider_exec,
    run_provider_exec_sync,
)
from .validation import validate_structured_output

find_claude_session = claude.find_session
find_codex_session = codex.find_session
find_copilot_session = copilot.find_session
find_gemini_session = gemini.find_session

__all__ = [
    "AttemptFinishedEventData",
    "AttemptStartedEventData",
    "ControlDefaultSource",
    "ParseFinishedEventData",
    "ProviderContinuationMode",
    "ProviderContinuationResolution",
    "ProviderEventCallback",
    "ProviderControlResolution",
    "ProviderEventKind",
    "ProviderExecEvent",
    "ProviderExecRequest",
    "ProviderExecResult",
    "ProviderLaunchPreview",
    "ProviderRawExecution",
    "RecoveryAppliedEventData",
    "StructuredValidationResult",
    "TranscriptProgressEventData",
    "claude",
    "codex",
    "copilot",
    "find_claude_session",
    "find_codex_session",
    "find_copilot_session",
    "find_gemini_session",
    "gemini",
    "run_provider_exec",
    "run_provider_exec_sync",
    "validate_structured_output",
]
