"""Thin cross-provider dispatch for preview Stage 5 adapters."""

from __future__ import annotations

from typing import TypeAlias, cast

from . import claude, codex, copilot, gemini
from ._common import run_sync_via_asyncio

ProviderExecRequest: TypeAlias = (
    claude.ClaudeExecRequest
    | codex.CodexExecRequest
    | copilot.CopilotExecRequest
    | gemini.GeminiExecRequest
)

ProviderExecResult: TypeAlias = (
    claude.ClaudeExecResult
    | codex.CodexExecResult
    | copilot.CopilotExecResult
    | gemini.GeminiExecResult
)


async def run_provider_exec(request: ProviderExecRequest) -> ProviderExecResult:
    if isinstance(request, claude.ClaudeExecRequest):
        return await claude.run(request)
    if isinstance(request, gemini.GeminiExecRequest):
        return await gemini.run(request)
    if isinstance(request, copilot.CopilotExecRequest):
        return await copilot.run(request)
    if isinstance(request, codex.CodexExecRequest):
        return await codex.run(request)
    raise TypeError(f"Unsupported provider exec request type: {type(request)!r}")


def run_provider_exec_sync(request: ProviderExecRequest) -> ProviderExecResult:
    return cast(ProviderExecResult, run_sync_via_asyncio(run_provider_exec(request)))


__all__ = [
    "ProviderExecRequest",
    "ProviderExecResult",
    "run_provider_exec",
    "run_provider_exec_sync",
]
