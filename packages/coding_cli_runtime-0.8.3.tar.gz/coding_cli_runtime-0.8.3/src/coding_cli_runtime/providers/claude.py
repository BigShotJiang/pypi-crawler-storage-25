"""Preview Claude runtime adapter."""

from __future__ import annotations

import asyncio
import json
import logging
import shlex
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, cast

from ..contracts import (
    ClaudeReasoningPolicy,
    CliLaunchSpec,
    CliRunResult,
    ErrorCode,
)
from ..failure_classification import FailureClassification, classify_provider_failure
from ..headless import build_claude_headless_core
from ..provider_contracts import (
    build_env_overlay,
    get_provider_contract,
    resolve_session_search_paths,
)
from ..provider_controls import ProviderControlResolution, build_provider_control_resolution
from ..reasoning import get_claude_effort_levels_for_model, resolve_claude_reasoning_policy
from ..session_execution import (
    InteractiveCliRunResult,
    SessionExecutionTimeoutError,
    SessionProgressEvent,
    SessionRetryDecision,
    TranscriptMirrorStrategy,
    mirror_session_transcript,
    run_interactive_session,
)
from ..session_logs import normalize_path_str
from ._common import (
    build_progress_callback,
    build_raw_execution,
    default_execution_id,
    emit_provider_event,
    materialize_prefixed_references,
    merge_env,
    prepare_destination_path,
    redact_env_for_preview,
    run_sync_via_asyncio,
)
from ._types import (
    AttemptFinishedEventData,
    AttemptStartedEventData,
    ParseFinishedEventData,
    ProviderContinuationMode,
    ProviderContinuationResolution,
    ProviderEventCallback,
    ProviderEventKind,
    ProviderLaunchPreview,
    ProviderRawExecution,
    RecoveryAppliedEventData,
    normalize_continuation_request,
)

_LOGGER = logging.getLogger(__name__)

SUPPORT_STATE = "sync_parity"
_CLAUDE_SUPPORTED_OUTPUT_FORMATS = frozenset(("text", "json", "stream-json"))
_CLAUDE_SESSION_SCAN_LINE_LIMIT = 20
_CLAUDE_SESSION_MTIME_BUFFER_SECONDS = 10.0
_DEFAULT_TRANSIENT_RETRIES = 2
_DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS = 3.0


class ClaudeSessionLookupStatus(str, Enum):
    FOUND = "found"
    NOT_FOUND = "not_found"
    AMBIGUOUS = "ambiguous"


class ClaudeLookupMode(str, Enum):
    STRICT_PROMPT = "strict_prompt"
    PROMPT_THEN_LATEST = "prompt_then_latest"


@dataclass(frozen=True)
class ClaudeExecRequest:
    model: str
    prompt: str
    cwd: Path
    continuation_mode: ProviderContinuationMode | str = ProviderContinuationMode.NEW
    session_id: str | None = None
    session_path: Path | None = None
    output_format: str = "text"
    binary: str | None = None
    permission_mode: str | None = None
    skip_permissions: bool = True
    api_key: str | None = None
    base_url: str | None = None
    effort: str | None = None
    thinking_tokens: int | None = None
    append_system_prompt: str | None = None
    extra_args: tuple[str, ...] = ()
    timeout_seconds: float | None = None
    env: dict[str, str] | None = None
    transcript_path: Path | None = None
    transcript_progress_callback: Callable[[SessionProgressEvent], None] | None = None
    event_callback: ProviderEventCallback | None = None
    transient_retries: int = _DEFAULT_TRANSIENT_RETRIES
    transient_retry_backoff_seconds: float = _DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS
    execution_id: str = field(default_factory=default_execution_id)

    def __post_init__(self) -> None:
        object.__setattr__(self, "cwd", Path(self.cwd))
        object.__setattr__(self, "extra_args", tuple(self.extra_args))
        normalized_mode, normalized_session_id, normalized_session_path = (
            normalize_continuation_request(
                self.continuation_mode,
                session_id=self.session_id,
                session_path=self.session_path,
            )
        )
        object.__setattr__(self, "continuation_mode", normalized_mode)
        object.__setattr__(self, "session_id", normalized_session_id)
        object.__setattr__(self, "session_path", normalized_session_path)
        if self.env is not None:
            object.__setattr__(self, "env", dict(self.env))
        if self.transcript_path is not None:
            object.__setattr__(self, "transcript_path", Path(self.transcript_path))


@dataclass(frozen=True)
class ClaudeParsedOutput:
    output_format: str
    parsed_payload: object | None
    structured_output: dict[str, object] | None
    parse_skipped: bool = False
    parse_error: str | None = None


@dataclass(frozen=True)
class ClaudeRetryRecord:
    attempt_index: int
    category: str
    delay_seconds: float


@dataclass(frozen=True)
class ClaudeSessionLookupResult:
    status: ClaudeSessionLookupStatus
    path: Path | None = None
    session_id: str | None = None
    matched_by: str | None = None
    candidate_count: int = 0
    candidate_paths: tuple[Path, ...] = ()

    def __post_init__(self) -> None:
        if self.path is not None:
            object.__setattr__(self, "path", Path(self.path))
        object.__setattr__(
            self,
            "candidate_paths",
            tuple(Path(path) for path in self.candidate_paths),
        )


@dataclass(frozen=True)
class ClaudeConversationResult:
    status: ClaudeSessionLookupStatus
    source_path: Path | None
    session_id: str | None
    text: str
    line_count: int

    def __post_init__(self) -> None:
        if self.source_path is not None:
            object.__setattr__(self, "source_path", Path(self.source_path))


@dataclass(frozen=True)
class ClaudeExecResult:
    request: ClaudeExecRequest
    launch: CliLaunchSpec
    raw_result: InteractiveCliRunResult | CliRunResult
    raw_execution: ProviderRawExecution
    parsed_output: ClaudeParsedOutput
    reasoning_policy: ClaudeReasoningPolicy
    control_resolution: ProviderControlResolution
    continuation_resolution: ProviderContinuationResolution
    retry_history: tuple[ClaudeRetryRecord, ...] = ()
    failure_classification: FailureClassification | None = None
    session_lookup: ClaudeSessionLookupResult | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "retry_history", tuple(self.retry_history))


@dataclass(frozen=True)
class _ClaudeSessionCandidate:
    path: Path
    session_id: str | None
    cwd: str | None
    prompt_text: str | None
    mtime: float


def _normalize_output_format(value: str) -> str:
    normalized = value.strip().lower()
    if normalized not in _CLAUDE_SUPPORTED_OUTPUT_FORMATS:
        supported = ", ".join(sorted(_CLAUDE_SUPPORTED_OUTPUT_FORMATS))
        raise ValueError(f"Unsupported Claude output format {value!r}; expected one of {supported}")
    return normalized


def _normalize_prompt_text_for_match(text: str | None) -> str | None:
    if not isinstance(text, str):
        return None
    normalized = text.replace("\r\n", "\n").strip()
    return normalized or None


def _claude_project_key(workdir: Path) -> str:
    normalized = workdir.as_posix().lstrip("/")
    if not normalized:
        return "-"
    slug = "".join(ch if ch.isalnum() or ch == "-" else "-" for ch in normalized)
    return f"-{slug}"


def _append_thinking_args(cmd_parts: list[str], thinking_tokens: int | None) -> None:
    if not thinking_tokens or thinking_tokens <= 0:
        return
    tokens_str = str(thinking_tokens)
    cmd_parts.extend(["--max-thinking-tokens", tokens_str])
    settings_payload = json.dumps({"env": {"MAX_THINKING_TOKENS": tokens_str}})
    cmd_parts.extend(["--settings", settings_payload])


def _append_reasoning_args(
    cmd_parts: list[str],
    policy: ClaudeReasoningPolicy,
) -> None:
    if policy.mode == "effort" and policy.effective_effort:
        cmd_parts.extend(["--effort", policy.effective_effort])
        return
    if policy.mode == "legacy_tokens":
        _append_thinking_args(cmd_parts, policy.thinking_tokens)
        return
    if policy.mode == "disabled" and policy.disable_via_env_setting:
        settings_payload = json.dumps({"env": {"MAX_THINKING_TOKENS": "0"}})
        cmd_parts.extend(["--settings", settings_payload])


def _resolve_reasoning_policy(request: ClaudeExecRequest) -> ClaudeReasoningPolicy:
    return resolve_claude_reasoning_policy(
        model=request.model,
        thinking_tokens=request.thinking_tokens,
        effort=request.effort,
    )


def _new_continuation_resolution(request: ClaudeExecRequest) -> ProviderContinuationResolution:
    return ProviderContinuationResolution(
        requested_mode=cast(ProviderContinuationMode, request.continuation_mode),
        requested_session_id=request.session_id,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.NEW,
        native_strategy="fresh",
    )


def _build_launch(
    request: ClaudeExecRequest,
    *,
    continuation_resolution: ProviderContinuationResolution | None = None,
) -> tuple[CliLaunchSpec, ClaudeReasoningPolicy, ProviderContinuationResolution]:
    output_format = _normalize_output_format(request.output_format)
    policy = _resolve_reasoning_policy(request)
    resolved_continuation = (
        continuation_resolution
        if continuation_resolution is not None
        else _resolve_continuation(request)
    )
    cmd_parts = build_claude_headless_core(
        request.model,
        binary=request.binary,
        permission_mode=request.permission_mode,
        skip_permissions=request.skip_permissions,
    )
    if output_format == "stream-json":
        cmd_parts.append("--verbose")
    cmd_parts.extend(["--output-format", output_format])
    _append_reasoning_args(cmd_parts, policy)
    if request.append_system_prompt:
        cmd_parts.extend(["--append-system-prompt", request.append_system_prompt])
    if resolved_continuation.resolved_mode is not ProviderContinuationMode.NEW:
        if resolved_continuation.resolved_session_id is None:
            raise ValueError("Claude continuation requires a resolved session_id")
        cmd_parts.extend(["--resume", resolved_continuation.resolved_session_id])
    if request.extra_args:
        cmd_parts.extend(request.extra_args)
    cmd_display = " ".join([*(shlex.quote(part) for part in cmd_parts), "<prompt>"])
    return (
        CliLaunchSpec(
            cmd_parts=tuple(cmd_parts),
            display_text=cmd_display,
            stdin_text=request.prompt,
        ),
        policy,
        resolved_continuation,
    )


def _build_exec_env(request: ClaudeExecRequest) -> dict[str, str]:
    overlay = build_env_overlay(
        get_provider_contract("claude"),
        api_key=request.api_key,
        base_url=request.base_url,
    )
    return merge_env(request.env, overlay=overlay)


def _preview_exec_env(request: ClaudeExecRequest) -> dict[str, str]:
    return {
        **(request.env or {}),
        **build_env_overlay(
            get_provider_contract("claude"),
            api_key=request.api_key,
            base_url=request.base_url,
        ),
    }


def _transcript_destination(request: ClaudeExecRequest, *, create_parent: bool) -> Path:
    return prepare_destination_path(
        request.transcript_path,
        prefix="claude_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
        create_parent=create_parent,
    )


def _build_control_resolution(
    request: ClaudeExecRequest,
    policy: ClaudeReasoningPolicy,
) -> ProviderControlResolution:
    requested: dict[str, object] = {}
    if isinstance(request.effort, str) and request.effort.strip():
        requested["effort"] = request.effort.strip().lower()
    if isinstance(request.thinking_tokens, int):
        requested["thinking_tokens"] = max(int(request.thinking_tokens), 0)

    applied: dict[str, object] = {}
    ignored: dict[str, object] = {}
    unknown_default_keys: tuple[str, ...] = ()
    if policy.mode == "effort" and policy.effective_effort:
        applied["effort"] = policy.effective_effort
        if "thinking_tokens" in requested:
            ignored["thinking_tokens"] = requested["thinking_tokens"]
    elif policy.mode in {"legacy_tokens", "disabled"} and policy.thinking_tokens is not None:
        applied["thinking_tokens"] = policy.thinking_tokens
    elif policy.mode == "none" and "effort" not in requested and "thinking_tokens" not in requested:
        if get_claude_effort_levels_for_model(request.model):
            unknown_default_keys = ("effort",)

    return build_provider_control_resolution(
        provider="claude",
        requested=requested,
        applied=applied,
        ignored=ignored,
        unknown_default_keys=unknown_default_keys,
    )


def _prepare_launch_preview(
    request: ClaudeExecRequest,
    *,
    launch: CliLaunchSpec,
    policy: ClaudeReasoningPolicy,
    continuation_resolution: ProviderContinuationResolution,
) -> ProviderLaunchPreview:
    contract = get_provider_contract("claude")
    control_resolution = _build_control_resolution(request, policy)
    return ProviderLaunchPreview(
        cmd_parts=launch.cmd_parts,
        display_text=launch.display_text,
        cwd=request.cwd,
        stdin_text=launch.stdin_text,
        output_paths=(_transcript_destination(request, create_parent=False),),
        effective_controls={
            "model": request.model,
            "output_format": _normalize_output_format(request.output_format),
            "permission_mode": request.permission_mode
            or contract.headless.approval.default_permission_mode,
            "skip_permissions": request.skip_permissions,
            "reasoning_mode": policy.mode,
            "effective_effort": policy.effective_effort,
            "thinking_tokens": policy.thinking_tokens,
            "append_system_prompt": bool(request.append_system_prompt),
            "continuation_mode": continuation_resolution.resolved_mode.value,
            "resumed_session_id": continuation_resolution.resolved_session_id,
        },
        redacted_env=redact_env_for_preview(_preview_exec_env(request)),
        control_resolution=control_resolution,
        continuation_resolution=continuation_resolution,
    )


def prepare_launch(request: ClaudeExecRequest) -> ProviderLaunchPreview:
    launch, policy, continuation_resolution = _build_launch(request)
    return _prepare_launch_preview(
        request,
        launch=launch,
        policy=policy,
        continuation_resolution=continuation_resolution,
    )


def parse_output(output_text: str, output_format: str) -> ClaudeParsedOutput:
    normalized = _normalize_output_format(output_format)
    if normalized == "text":
        return ClaudeParsedOutput(
            output_format=normalized,
            parsed_payload=None,
            structured_output=None,
            parse_skipped=True,
        )
    try:
        parsed = _parse_claude_structured_output(output_text, normalized)
    except Exception as exc:
        return ClaudeParsedOutput(
            output_format=normalized,
            parsed_payload=None,
            structured_output=None,
            parse_error=str(exc),
        )
    structured_output = None
    if isinstance(parsed, dict):
        payload = parsed.get("structured_output")
        if isinstance(payload, dict):
            structured_output = payload
    return ClaudeParsedOutput(
        output_format=normalized,
        parsed_payload=parsed,
        structured_output=structured_output,
    )


def extract_structured_output_payload(
    output_text: str,
    *,
    output_format: str = "json",
) -> dict[str, object]:
    parsed = parse_output(output_text, output_format)
    if parsed.parse_error:
        raise ValueError(parsed.parse_error)
    if parsed.structured_output is None:
        raise ValueError("Claude structured output envelope missing structured_output object")
    return parsed.structured_output


def materialize_prompt_file_references(
    prompt_text: str,
    file_paths: tuple[str | Path, ...] | list[str | Path],
) -> str:
    prefix = get_provider_contract("claude").io.file_reference_prefix
    if not prefix:
        raise NotImplementedError(
            "Claude prompt file references are not enabled in coding_cli_runtime"
        )
    normalized_paths = tuple(Path(path) for path in file_paths)
    return materialize_prefixed_references(
        prompt_text,
        normalized_paths,
        prefix=prefix,
        singular_label="File reference",
        plural_label="File references",
    )


def _parse_claude_structured_output(output_text: str, output_format: str) -> object:
    if output_format == "json":
        return json.loads(output_text)
    if output_format == "stream-json":
        last_payload: object | None = None
        result_payload: object | None = None
        for raw_line in output_text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            parsed = json.loads(line)
            last_payload = parsed
            if isinstance(parsed, dict) and parsed.get("type") == "result":
                result_payload = parsed
        if result_payload is not None:
            return result_payload
        if last_payload is not None:
            return last_payload
        raise ValueError("Claude stream-json output was empty")
    raise ValueError(f"Unsupported Claude structured output format: {output_format}")


def _extract_claude_session_candidate(path: Path) -> _ClaudeSessionCandidate | None:
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return None

    session_id: str | None = None
    cwd: str | None = None
    prompt_text: str | None = None
    try:
        with path.open("r", encoding="utf-8") as handle:
            for _ in range(_CLAUDE_SESSION_SCAN_LINE_LIMIT):
                line = handle.readline()
                if not line:
                    break
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(payload, dict):
                    continue
                current_session_id = payload.get("sessionId")
                if isinstance(current_session_id, str) and current_session_id.strip():
                    session_id = current_session_id
                current_cwd = payload.get("cwd")
                if isinstance(current_cwd, str) and current_cwd.strip():
                    cwd = normalize_path_str(current_cwd)
                if prompt_text is None:
                    if (
                        payload.get("type") == "queue-operation"
                        and payload.get("operation") == "enqueue"
                    ):
                        prompt_text = _normalize_prompt_text_for_match(payload.get("content"))
                    elif payload.get("type") == "user":
                        message = payload.get("message")
                        if isinstance(message, dict) and message.get("role") == "user":
                            prompt_text = _normalize_prompt_text_for_match(message.get("content"))
                if session_id and cwd and prompt_text:
                    break
    except OSError:
        return None

    return _ClaudeSessionCandidate(
        path=path,
        session_id=session_id,
        cwd=cwd,
        prompt_text=prompt_text,
        mtime=mtime,
    )


def _find_claude_session_candidates(
    project_dir: Path,
    since_ts: float | None,
) -> list[_ClaudeSessionCandidate]:
    if not project_dir.exists():
        return []
    candidates: list[_ClaudeSessionCandidate] = []
    try:
        for path in project_dir.glob("*.jsonl"):
            candidate = _extract_claude_session_candidate(path)
            if candidate is None:
                continue
            if (
                since_ts is None
                or candidate.mtime >= since_ts - _CLAUDE_SESSION_MTIME_BUFFER_SECONDS
            ):
                candidates.append(candidate)
    except OSError:
        return []
    candidates.sort(key=lambda item: item.mtime, reverse=True)
    return candidates


def _select_claude_session_candidate(
    candidates: list[_ClaudeSessionCandidate],
    *,
    workdir: Path,
    prompt_text: str,
) -> _ClaudeSessionCandidate | None:
    expected_cwd = normalize_path_str(str(workdir.resolve()))
    expected_prompt = _normalize_prompt_text_for_match(prompt_text)
    if expected_prompt is None:
        return None

    full_matches = [
        candidate
        for candidate in candidates
        if candidate.cwd == expected_cwd and candidate.prompt_text == expected_prompt
    ]
    if full_matches:
        return full_matches[0]

    prompt_only_matches = [
        candidate
        for candidate in candidates
        if candidate.prompt_text == expected_prompt and candidate.cwd is None
    ]
    if len(prompt_only_matches) == 1:
        return prompt_only_matches[0]
    return None


def _find_claude_session_in_dirs(
    project_dirs: list[Path],
    since_ts: float | None,
    *,
    workdir: Path,
    prompt_text: str,
) -> _ClaudeSessionCandidate | None:
    candidates: list[_ClaudeSessionCandidate] = []
    for project_dir in project_dirs:
        candidates.extend(_find_claude_session_candidates(project_dir, since_ts))
    if not candidates:
        return None
    return _select_claude_session_candidate(
        sorted(candidates, key=lambda item: item.mtime, reverse=True),
        workdir=workdir,
        prompt_text=prompt_text,
    )


def _claude_project_dirs(
    workdir: Path,
    *,
    project_roots: list[Path] | tuple[Path, ...] | None = None,
) -> list[Path]:
    resolved_workdir = workdir.resolve()
    roots = (
        [Path(root) for root in project_roots]
        if project_roots is not None
        else list(resolve_session_search_paths(get_provider_contract("claude")))
    )
    project_key = _claude_project_key(resolved_workdir)
    return [root / project_key for root in roots]


def _find_latest_resumable_session(
    workdir: Path,
    *,
    project_roots: list[Path] | tuple[Path, ...] | None = None,
) -> _ClaudeSessionCandidate | None:
    candidates: list[_ClaudeSessionCandidate] = []
    for project_dir in _claude_project_dirs(workdir, project_roots=project_roots):
        candidates.extend(_find_claude_session_candidates(project_dir, None))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item.mtime, reverse=True)
    return candidates[0]


def _find_claude_session_by_id(
    workdir: Path,
    session_id: str,
    *,
    project_roots: list[Path] | tuple[Path, ...] | None = None,
) -> _ClaudeSessionCandidate | None:
    expected_cwd = normalize_path_str(str(workdir.resolve()))
    candidates: list[_ClaudeSessionCandidate] = []
    for project_dir in _claude_project_dirs(workdir, project_roots=project_roots):
        candidates.extend(_find_claude_session_candidates(project_dir, None))
    for candidate in sorted(candidates, key=lambda item: item.mtime, reverse=True):
        if candidate.session_id != session_id:
            continue
        if candidate.cwd is not None and candidate.cwd != expected_cwd:
            continue
        return candidate
    return None


def _resolve_session_path_candidate(
    request: ClaudeExecRequest,
) -> _ClaudeSessionCandidate:
    if request.session_path is None:
        raise ValueError("Claude session_path continuation requires a session_path")
    session_path = request.session_path.resolve()
    candidate = _extract_claude_session_candidate(session_path)
    if candidate is None:
        raise ValueError(f"Claude session_path could not be read: {session_path}")
    expected_cwd = normalize_path_str(str(request.cwd.resolve()))
    if candidate.cwd is not None and candidate.cwd != expected_cwd:
        raise ValueError(
            "Claude session_path belongs to a different workdir: "
            f"{candidate.cwd!r} != {expected_cwd!r}"
        )
    if candidate.session_id is None:
        raise ValueError("Claude session_path did not contain a sessionId")
    return candidate


def _resolve_continuation(request: ClaudeExecRequest) -> ProviderContinuationResolution:
    mode = cast(ProviderContinuationMode, request.continuation_mode)
    if mode is ProviderContinuationMode.NEW:
        return _new_continuation_resolution(request)

    if mode is ProviderContinuationMode.CONTINUE_LATEST:
        candidate = _find_latest_resumable_session(request.cwd)
        if candidate is None or candidate.session_id is None:
            raise ValueError(f"No resumable Claude session found for {request.cwd}")
        return ProviderContinuationResolution(
            requested_mode=mode,
            resolved_mode=ProviderContinuationMode.CONTINUE_LATEST,
            resolved_session_id=candidate.session_id,
            resolved_session_path=candidate.path,
            native_strategy="resume",
            matched_by="latest",
        )

    if mode is ProviderContinuationMode.SESSION_ID:
        if request.session_id is None:
            raise ValueError("Claude session_id continuation requires a session_id")
        candidate = _find_claude_session_by_id(request.cwd, request.session_id)
        if candidate is None:
            raise ValueError(
                f"Claude session_id {request.session_id!r} was not found for workdir {request.cwd}"
            )
        return ProviderContinuationResolution(
            requested_mode=mode,
            requested_session_id=request.session_id,
            resolved_mode=ProviderContinuationMode.SESSION_ID,
            resolved_session_id=request.session_id,
            resolved_session_path=candidate.path,
            native_strategy="resume",
            matched_by="session_id",
        )

    candidate = _resolve_session_path_candidate(request)
    return ProviderContinuationResolution(
        requested_mode=mode,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.SESSION_PATH,
        resolved_session_id=candidate.session_id,
        resolved_session_path=candidate.path,
        native_strategy="resume",
        matched_by="session_path",
    )


def find_session(
    workdir: str | Path,
    since_ts: float,
    *,
    prompt_text: str | None = None,
    lookup_mode: ClaudeLookupMode | str = ClaudeLookupMode.STRICT_PROMPT,
    project_roots: list[Path] | tuple[Path, ...] | None = None,
) -> ClaudeSessionLookupResult:
    if not isinstance(lookup_mode, ClaudeLookupMode):
        lookup_mode = ClaudeLookupMode(str(lookup_mode).strip().lower())
    workdir_path = Path(normalize_path_str(str(Path(workdir).resolve())))
    roots = (
        [Path(root) for root in project_roots]
        if project_roots is not None
        else list(resolve_session_search_paths(get_provider_contract("claude")))
    )
    project_key = _claude_project_key(workdir_path)
    candidates: list[_ClaudeSessionCandidate] = []
    for root in roots:
        candidates.extend(_find_claude_session_candidates(root / project_key, since_ts))
    if not candidates:
        return ClaudeSessionLookupResult(status=ClaudeSessionLookupStatus.NOT_FOUND)

    candidates.sort(key=lambda item: item.mtime, reverse=True)
    normalized_prompt = _normalize_prompt_text_for_match(prompt_text)
    if normalized_prompt is None:
        selected = candidates[0]
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=selected.path,
            session_id=selected.session_id,
            matched_by="latest",
            candidate_count=len(candidates),
        )

    expected_cwd = normalize_path_str(str(workdir_path.resolve()))
    full_matches = [
        candidate
        for candidate in candidates
        if candidate.cwd == expected_cwd and candidate.prompt_text == normalized_prompt
    ]
    if full_matches:
        selected = full_matches[0]
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=selected.path,
            session_id=selected.session_id,
            matched_by="cwd_and_prompt",
            candidate_count=len(full_matches),
        )

    prompt_only_matches = [
        candidate
        for candidate in candidates
        if candidate.prompt_text == normalized_prompt and candidate.cwd is None
    ]
    if len(prompt_only_matches) == 1:
        selected = prompt_only_matches[0]
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=selected.path,
            session_id=selected.session_id,
            matched_by="prompt_only",
            candidate_count=1,
        )
    if prompt_only_matches:
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.AMBIGUOUS,
            candidate_count=len(prompt_only_matches),
            candidate_paths=tuple(candidate.path for candidate in prompt_only_matches),
            matched_by="prompt_only",
        )

    if lookup_mode is ClaudeLookupMode.PROMPT_THEN_LATEST:
        selected = candidates[0]
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=selected.path,
            session_id=selected.session_id,
            matched_by="latest_fallback",
            candidate_count=len(candidates),
        )

    return ClaudeSessionLookupResult(
        status=ClaudeSessionLookupStatus.NOT_FOUND,
        candidate_count=len(candidates),
    )


def _filter_conversation_text(
    source: Path,
    *,
    start_ts: float | None,
    session_id: str | None,
) -> tuple[str, int]:
    if start_ts is None and session_id is None:
        text = source.read_text(encoding="utf-8")
        return text, len(text.splitlines())

    lines: list[str] = []
    cutoff_ts = (start_ts - _CLAUDE_SESSION_MTIME_BUFFER_SECONDS) if start_ts is not None else None
    with source.open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(payload, dict):
                continue
            if session_id and payload.get("sessionId") != session_id:
                continue
            if cutoff_ts is not None:
                timestamp_str = payload.get("timestamp")
                if not isinstance(timestamp_str, str):
                    continue
                try:
                    msg_ts = datetime.fromisoformat(
                        timestamp_str.replace("Z", "+00:00")
                    ).timestamp()
                except ValueError:
                    continue
                if msg_ts < cutoff_ts:
                    continue
            lines.append(line.rstrip("\n"))
    text = "\n".join(lines)
    if lines:
        text = f"{text}\n"
    return text, len(lines)


def get_conversation(
    source: ClaudeSessionLookupResult | Path,
    *,
    start_ts: float | None = None,
    session_id: str | None = None,
) -> ClaudeConversationResult:
    if isinstance(source, ClaudeSessionLookupResult):
        if source.status is not ClaudeSessionLookupStatus.FOUND or source.path is None:
            return ClaudeConversationResult(
                status=source.status,
                source_path=source.path,
                session_id=source.session_id,
                text="",
                line_count=0,
            )
        source_path = source.path
        effective_session_id = session_id if session_id is not None else source.session_id
    else:
        source_path = Path(source)
        if not source_path.exists():
            return ClaudeConversationResult(
                status=ClaudeSessionLookupStatus.NOT_FOUND,
                source_path=source_path,
                session_id=session_id,
                text="",
                line_count=0,
            )
        effective_session_id = session_id

    text, line_count = _filter_conversation_text(
        source_path,
        start_ts=start_ts,
        session_id=effective_session_id,
    )
    return ClaudeConversationResult(
        status=ClaudeSessionLookupStatus.FOUND,
        source_path=source_path,
        session_id=effective_session_id,
        text=text,
        line_count=line_count,
    )


def _build_failure_detail(
    *,
    stdout: bytes,
    stderr: bytes,
) -> tuple[str, str, str]:
    stderr_text = stderr.decode("utf-8", errors="replace").strip()
    stdout_text = stdout.decode("utf-8", errors="replace").strip()
    if stderr_text and stdout_text and stdout_text != stderr_text:
        return f"{stderr_text} | stdout: {stdout_text}", stderr_text, stdout_text
    if stderr_text:
        return stderr_text, stderr_text, stdout_text
    if stdout_text:
        return f"stdout: {stdout_text}", stderr_text, stdout_text
    return "no stderr/stdout output", stderr_text, stdout_text


def _should_retry_claude_failure(
    *,
    classification_retryable: bool,
    classification_category: str,
    stderr_text: str,
    stdout_text: str,
) -> bool:
    if classification_retryable:
        return True
    return (
        classification_category == "unknown"
        and not stderr_text.strip()
        and bool(stdout_text.strip())
    )


def _resolve_session_lookup_from_result(
    request: ClaudeExecRequest,
    *,
    started_at: float | None,
    transcript_path: Path | None,
    continuation_resolution: ProviderContinuationResolution,
) -> ClaudeSessionLookupResult | None:
    if continuation_resolution.resolved_session_path is not None:
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=continuation_resolution.resolved_session_path,
            session_id=continuation_resolution.resolved_session_id,
            matched_by=continuation_resolution.matched_by,
            candidate_count=1,
        )
    if started_at is not None:
        resolved = find_session(request.cwd, started_at, prompt_text=request.prompt)
        if resolved.status is ClaudeSessionLookupStatus.FOUND:
            return resolved
    if transcript_path is not None and transcript_path.exists():
        return ClaudeSessionLookupResult(
            status=ClaudeSessionLookupStatus.FOUND,
            path=transcript_path,
            matched_by="transcript_capture",
            candidate_count=1,
        )
    return None


def _build_transcript_strategy(
    request: ClaudeExecRequest,
    *,
    start_ts: float,
    progress_callback: Callable[[SessionProgressEvent], None] | None,
    continuation_resolution: ProviderContinuationResolution,
) -> TranscriptMirrorStrategy:
    actual_cwd = Path.cwd().resolve()
    request_cwd = request.cwd.resolve()
    roots = list(resolve_session_search_paths(get_provider_contract("claude")))
    project_dirs: list[Path] = []
    for root in roots:
        for candidate_cwd in (request_cwd, actual_cwd):
            project_dirs.append(root / _claude_project_key(candidate_cwd))
    deduped_dirs = list(dict.fromkeys(project_dirs))
    destination = prepare_destination_path(
        request.transcript_path,
        prefix="claude_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
    )

    def locate() -> _ClaudeSessionCandidate | None:
        if continuation_resolution.resolved_mode is not ProviderContinuationMode.NEW:
            if continuation_resolution.resolved_session_path is not None:
                candidate = _extract_claude_session_candidate(
                    continuation_resolution.resolved_session_path
                )
                if candidate is not None:
                    return candidate
            resolved_session_id = continuation_resolution.resolved_session_id
            if resolved_session_id is not None:
                candidates: list[_ClaudeSessionCandidate] = []
                for project_dir in deduped_dirs:
                    candidates.extend(_find_claude_session_candidates(project_dir, None))
                for candidate in sorted(candidates, key=lambda item: item.mtime, reverse=True):
                    if candidate.session_id == resolved_session_id:
                        return candidate
        return _find_claude_session_in_dirs(
            deduped_dirs,
            start_ts,
            workdir=request_cwd,
            prompt_text=request.prompt,
        )

    def source_identity(source: object) -> object:
        if isinstance(source, _ClaudeSessionCandidate):
            return (
                normalize_path_str(str(source.path.resolve())),
                source.session_id,
            )
        return source

    def source_exists(source: object) -> bool:
        return isinstance(source, _ClaudeSessionCandidate) and source.path.exists()

    def describe_source(source: object) -> str:
        if isinstance(source, _ClaudeSessionCandidate):
            return str(source.path)
        return str(source)

    def copy_source(source: object, destination_path: Path) -> None:
        if not isinstance(source, _ClaudeSessionCandidate):
            raise TypeError(f"Unexpected Claude transcript source: {type(source)!r}")
        text, _ = _filter_conversation_text(
            source.path,
            start_ts=start_ts,
            session_id=source.session_id,
        )
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        destination_path.write_text(text, encoding="utf-8")

    return TranscriptMirrorStrategy(
        provider_label="Claude",
        destination=destination,
        locate_source=locate,
        source_identity=source_identity,
        source_exists=source_exists,
        describe_source=describe_source,
        copy_source=copy_source,
        final_copy_source=copy_source,
        poll_interval=1.0,
        refresh_source_each_poll=True,
        final_retry_attempts=10,
        final_retry_initial_delay_seconds=1.0,
        final_retry_backoff_multiplier=2.0,
        progress_callback=progress_callback,
    )


async def _run_raw_with_context(
    request: ClaudeExecRequest,
    *,
    launch: CliLaunchSpec,
    launch_preview: ProviderLaunchPreview,
    continuation_resolution: ProviderContinuationResolution,
) -> tuple[
    InteractiveCliRunResult | CliRunResult,
    tuple[ClaudeRetryRecord, ...],
    ClaudeSessionLookupResult | None,
]:
    retry_history: list[ClaudeRetryRecord] = []
    start_ts = time.time()
    max_cli_attempts = max(1, request.transient_retries + 1)
    current_attempt = 0
    raw_result: InteractiveCliRunResult | CliRunResult

    def get_attempt_index() -> int:
        return max(1, current_attempt)

    progress_callback = build_progress_callback(
        provider="claude",
        get_attempt_index=get_attempt_index,
        event_callback=request.event_callback,
        transcript_progress_callback=request.transcript_progress_callback,
        logger=_LOGGER,
    )
    transcript_strategy = _build_transcript_strategy(
        request,
        start_ts=start_ts,
        progress_callback=progress_callback,
        continuation_resolution=continuation_resolution,
    )

    async def create_process(
        *cmd_parts: str,
        **kwargs: Any,
    ) -> asyncio.subprocess.Process:
        nonlocal current_attempt
        current_attempt += 1
        emit_provider_event(
            callback=request.event_callback,
            provider="claude",
            attempt_index=current_attempt,
            kind=ProviderEventKind.ATTEMPT_STARTED,
            data=AttemptStartedEventData(
                launch=launch_preview,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return await asyncio.create_subprocess_exec(*cmd_parts, **kwargs)

    def retry_decider(
        result: InteractiveCliRunResult,
        cli_attempt: int,
        max_cli_attempts: int,
    ) -> SessionRetryDecision:
        failure_detail, stderr_text, stdout_text = _build_failure_detail(
            stdout=result.stdout,
            stderr=result.stderr,
        )
        failure = classify_provider_failure(provider="claude", stderr_text=failure_detail)
        should_retry = _should_retry_claude_failure(
            classification_retryable=failure.retryable,
            classification_category=failure.category,
            stderr_text=stderr_text,
            stdout_text=stdout_text,
        )
        delay = (
            max(0.0, request.transient_retry_backoff_seconds) * cli_attempt
            if should_retry and cli_attempt < max(1, max_cli_attempts)
            else 0.0
        )
        if should_retry:
            retry_history.append(
                ClaudeRetryRecord(
                    attempt_index=cli_attempt,
                    category=failure.category,
                    delay_seconds=delay,
                )
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="claude",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.ATTEMPT_FINISHED,
                data=AttemptFinishedEventData(
                    returncode=result.returncode,
                    timed_out=False,
                    conversation_path=result.conversation_path,
                    started_at=result.started_at,
                    cli_attempt_used=result.cli_attempt_used,
                    max_cli_attempts=result.max_cli_attempts,
                ),
                logger=_LOGGER,
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="claude",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.RECOVERY_APPLIED,
                data=RecoveryAppliedEventData(
                    category=failure.category,
                    delay_seconds=delay,
                    next_attempt_index=cli_attempt + 1,
                ),
                logger=_LOGGER,
            )
        return SessionRetryDecision(
            retry=should_retry,
            delay_seconds=delay,
            category=failure.category,
        )

    try:
        raw_result = await run_interactive_session(
            cmd_parts=launch.cmd_parts,
            cwd=request.cwd,
            stdin_text=launch.stdin_text,
            logger=_LOGGER,
            provider_label="Claude",
            job_name=request.cwd.name or "claude",
            process_label="Claude process",
            timeout_seconds=request.timeout_seconds,
            env=_build_exec_env(request),
            transcript_factory=lambda proc: mirror_session_transcript(
                job_name=request.cwd.name or "claude",
                phase_tag="",
                logger=_LOGGER,
                proc=proc,
                strategy=transcript_strategy,
            ),
            create_process=create_process,
            max_cli_attempts=max_cli_attempts,
            retry_decider=retry_decider,
        )
        emit_provider_event(
            callback=request.event_callback,
            provider="claude",
            attempt_index=max(1, getattr(raw_result, "cli_attempt_used", current_attempt or 1)),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=raw_result.returncode,
                timed_out=getattr(raw_result, "timed_out", False),
                conversation_path=getattr(raw_result, "conversation_path", None),
                started_at=getattr(raw_result, "started_at", None),
                cli_attempt_used=getattr(raw_result, "cli_attempt_used", None),
                max_cli_attempts=getattr(raw_result, "max_cli_attempts", max_cli_attempts),
            ),
            logger=_LOGGER,
        )
        session_lookup = _resolve_session_lookup_from_result(
            request,
            started_at=raw_result.started_at,
            transcript_path=raw_result.conversation_path,
            continuation_resolution=continuation_resolution,
        )
        return raw_result, tuple(retry_history), session_lookup
    except SessionExecutionTimeoutError as exc:
        raw_result = CliRunResult(
            command=launch.cmd_parts,
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=0.0,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=str(exc),
        )
        session_lookup = _resolve_session_lookup_from_result(
            request,
            started_at=getattr(exc, "started_at", start_ts),
            transcript_path=getattr(exc, "conversation_path", None),
            continuation_resolution=continuation_resolution,
        )
        emit_provider_event(
            callback=request.event_callback,
            provider="claude",
            attempt_index=max(1, current_attempt or 1),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=None,
                timed_out=True,
                conversation_path=getattr(exc, "conversation_path", None),
                started_at=getattr(exc, "started_at", start_ts),
                cli_attempt_used=current_attempt or 1,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return raw_result, tuple(retry_history), session_lookup


def _stdout_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stdout_text
    return raw_result.stdout.decode("utf-8", errors="replace")


def _stderr_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stderr_text
    return raw_result.stderr.decode("utf-8", errors="replace")


def _returncode(raw_result: InteractiveCliRunResult | CliRunResult) -> int | None:
    return raw_result.returncode


def _build_exec_result(
    request: ClaudeExecRequest,
    launch: CliLaunchSpec,
    policy: ClaudeReasoningPolicy,
    continuation_resolution: ProviderContinuationResolution,
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    retry_history: tuple[ClaudeRetryRecord, ...] = (),
    session_lookup: ClaudeSessionLookupResult | None = None,
) -> ClaudeExecResult:
    stdout_text = _stdout_text(raw_result)
    stderr_text = _stderr_text(raw_result)
    if stdout_text.strip():
        parsed_output = parse_output(stdout_text, request.output_format)
    else:
        parsed_output = ClaudeParsedOutput(
            output_format=_normalize_output_format(request.output_format),
            parsed_payload=None,
            structured_output=None,
            parse_skipped=True,
        )
    failure_classification = None
    if _returncode(raw_result) not in (None, 0):
        failure_detail = stderr_text.strip() or stdout_text.strip()
        if failure_detail:
            failure_classification = classify_provider_failure(
                provider="claude",
                stderr_text=failure_detail,
            )
    control_resolution = _build_control_resolution(request, policy)
    return ClaudeExecResult(
        request=request,
        launch=launch,
        raw_result=raw_result,
        raw_execution=build_raw_execution(
            raw_result,
            conversation_path=session_lookup.path if session_lookup is not None else None,
        ),
        parsed_output=parsed_output,
        reasoning_policy=policy,
        control_resolution=control_resolution,
        continuation_resolution=continuation_resolution,
        retry_history=retry_history,
        failure_classification=failure_classification,
        session_lookup=session_lookup,
    )


async def run_raw(request: ClaudeExecRequest) -> InteractiveCliRunResult | CliRunResult:
    launch, _policy, continuation_resolution = _build_launch(request)
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        policy=_policy,
        continuation_resolution=continuation_resolution,
    )
    raw_result, _, _ = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    return raw_result


async def run(request: ClaudeExecRequest) -> ClaudeExecResult:
    launch, policy, continuation_resolution = _build_launch(request)
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        policy=policy,
        continuation_resolution=continuation_resolution,
    )
    raw_result, retry_history, session_lookup = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    result = _build_exec_result(
        request,
        launch,
        policy,
        continuation_resolution,
        raw_result,
        retry_history=retry_history,
        session_lookup=session_lookup,
    )
    emit_provider_event(
        callback=request.event_callback,
        provider="claude",
        attempt_index=max(1, getattr(raw_result, "cli_attempt_used", len(retry_history) + 1)),
        kind=ProviderEventKind.PARSE_FINISHED,
        data=ParseFinishedEventData(
            parse_skipped=result.parsed_output.parse_skipped,
            parse_error=result.parsed_output.parse_error,
        ),
        logger=_LOGGER,
    )
    return result


def run_sync(request: ClaudeExecRequest) -> ClaudeExecResult:
    return cast(ClaudeExecResult, run_sync_via_asyncio(run(request)))


__all__ = [
    "ClaudeConversationResult",
    "ClaudeExecRequest",
    "ClaudeExecResult",
    "ClaudeLookupMode",
    "ClaudeParsedOutput",
    "ClaudeRetryRecord",
    "ClaudeSessionLookupResult",
    "ClaudeSessionLookupStatus",
    "SUPPORT_STATE",
    "extract_structured_output_payload",
    "find_session",
    "get_conversation",
    "materialize_prompt_file_references",
    "parse_output",
    "prepare_launch",
    "run",
    "run_raw",
    "run_sync",
]
