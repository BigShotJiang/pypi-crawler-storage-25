"""Shared preview Layer 2 types for provider runtime adapters."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from ..provider_controls import ProviderControlResolution
from ..session_execution import SessionProgressEvent


class ProviderContinuationMode(str, Enum):
    NEW = "new"
    CONTINUE_LATEST = "continue_latest"
    SESSION_ID = "session_id"
    SESSION_PATH = "session_path"


@dataclass(frozen=True)
class ProviderContinuationResolution:
    requested_mode: ProviderContinuationMode
    requested_session_id: str | None = None
    requested_session_path: Path | None = None
    resolved_mode: ProviderContinuationMode = ProviderContinuationMode.NEW
    resolved_session_id: str | None = None
    resolved_session_path: Path | None = None
    native_strategy: str | None = None
    matched_by: str | None = None

    def __post_init__(self) -> None:
        if self.requested_session_path is not None:
            object.__setattr__(self, "requested_session_path", Path(self.requested_session_path))
        if self.resolved_session_path is not None:
            object.__setattr__(self, "resolved_session_path", Path(self.resolved_session_path))


def normalize_continuation_request(
    continuation_mode: ProviderContinuationMode | str | None,
    *,
    session_id: str | None = None,
    session_path: str | Path | None = None,
) -> tuple[ProviderContinuationMode, str | None, Path | None]:
    mode = ProviderContinuationMode.NEW
    if continuation_mode is not None:
        if isinstance(continuation_mode, ProviderContinuationMode):
            mode = continuation_mode
        else:
            mode = ProviderContinuationMode(str(continuation_mode).strip().lower())

    normalized_session_id = None
    if isinstance(session_id, str):
        normalized_session_id = session_id.strip() or None

    normalized_session_path = None
    if session_path is not None:
        normalized_session_path = Path(session_path)

    if mode is ProviderContinuationMode.NEW:
        if normalized_session_id is not None or normalized_session_path is not None:
            raise ValueError("Fresh sessions cannot also specify session_id or session_path")
        return mode, None, None

    if mode is ProviderContinuationMode.CONTINUE_LATEST:
        if normalized_session_id is not None or normalized_session_path is not None:
            raise ValueError(
                "continue_latest cannot be combined with explicit session_id or session_path"
            )
        return mode, None, None

    if mode is ProviderContinuationMode.SESSION_ID:
        if normalized_session_id is None:
            raise ValueError("session_id continuation requires a non-empty session_id")
        if normalized_session_path is not None:
            raise ValueError("session_id continuation cannot also specify session_path")
        return mode, normalized_session_id, None

    if normalized_session_path is None:
        raise ValueError("session_path continuation requires a session_path")
    if normalized_session_id is not None:
        raise ValueError("session_path continuation cannot also specify session_id")
    return mode, None, normalized_session_path


@dataclass(frozen=True)
class ProviderLaunchPreview:
    cmd_parts: tuple[str, ...]
    display_text: str
    cwd: Path
    stdin_text: str | None
    output_paths: tuple[Path, ...]
    effective_controls: Mapping[str, object]
    redacted_env: Mapping[str, str]
    control_resolution: ProviderControlResolution | None = None
    continuation_resolution: ProviderContinuationResolution | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "cwd", Path(self.cwd))
        object.__setattr__(self, "cmd_parts", tuple(self.cmd_parts))
        object.__setattr__(self, "output_paths", tuple(Path(path) for path in self.output_paths))
        object.__setattr__(self, "effective_controls", dict(self.effective_controls))
        object.__setattr__(self, "redacted_env", dict(self.redacted_env))


class ProviderEventKind(str, Enum):
    ATTEMPT_STARTED = "attempt_started"
    TRANSCRIPT_PROGRESS = "transcript_progress"
    RECOVERY_APPLIED = "recovery_applied"
    ATTEMPT_FINISHED = "attempt_finished"
    PARSE_FINISHED = "parse_finished"


@dataclass(frozen=True)
class AttemptStartedEventData:
    launch: ProviderLaunchPreview
    max_cli_attempts: int


@dataclass(frozen=True)
class TranscriptProgressEventData:
    progress: SessionProgressEvent


@dataclass(frozen=True)
class RecoveryAppliedEventData:
    category: str | None
    delay_seconds: float
    next_attempt_index: int
    launch_variant: str | None = None


@dataclass(frozen=True)
class AttemptFinishedEventData:
    returncode: int | None
    timed_out: bool
    conversation_path: Path | None
    started_at: float | None
    cli_attempt_used: int | None
    max_cli_attempts: int | None

    def __post_init__(self) -> None:
        if self.conversation_path is not None:
            object.__setattr__(self, "conversation_path", Path(self.conversation_path))


@dataclass(frozen=True)
class ParseFinishedEventData:
    parse_skipped: bool
    parse_error: str | None


ProviderExecEventData = (
    AttemptStartedEventData
    | TranscriptProgressEventData
    | RecoveryAppliedEventData
    | AttemptFinishedEventData
    | ParseFinishedEventData
)


@dataclass(frozen=True)
class ProviderExecEvent:
    kind: ProviderEventKind
    provider: str
    attempt_index: int
    data: ProviderExecEventData


ProviderEventCallback = Callable[[ProviderExecEvent], None]


@dataclass(frozen=True)
class ProviderRawExecution:
    returncode: int | None
    timed_out: bool
    stdout: bytes
    stderr: bytes
    conversation_path: Path | None
    started_at: float | None
    finished_at: datetime | None
    native_result: Any

    def __post_init__(self) -> None:
        if self.conversation_path is not None:
            object.__setattr__(self, "conversation_path", Path(self.conversation_path))


@dataclass(frozen=True)
class StructuredValidationResult:
    provider: str
    model: str
    schema_name: str
    parsed_payload: object | None
    valid: bool
    validation_error: str | None = None
    transcript_path: Path | None = None
    session_path: Path | None = None

    def __post_init__(self) -> None:
        if self.transcript_path is not None:
            object.__setattr__(self, "transcript_path", Path(self.transcript_path))
        if self.session_path is not None:
            object.__setattr__(self, "session_path", Path(self.session_path))


__all__ = [
    "AttemptFinishedEventData",
    "AttemptStartedEventData",
    "ProviderContinuationMode",
    "ProviderContinuationResolution",
    "ParseFinishedEventData",
    "ProviderEventCallback",
    "ProviderEventKind",
    "ProviderExecEvent",
    "ProviderLaunchPreview",
    "ProviderRawExecution",
    "RecoveryAppliedEventData",
    "StructuredValidationResult",
    "TranscriptProgressEventData",
    "normalize_continuation_request",
]
