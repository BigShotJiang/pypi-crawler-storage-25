"""Preview Copilot runtime adapter."""

from __future__ import annotations

import asyncio
import json
import logging
import shlex
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, cast

from ..contracts import CliLaunchSpec, CliRunResult, ErrorCode
from ..failure_classification import FailureClassification, classify_provider_failure
from ..headless import build_copilot_headless_core
from ..provider_contracts import (
    build_env_overlay,
    get_provider_contract,
    resolve_session_search_paths,
)
from ..provider_controls import (
    ControlDefaultSource,
    ProviderControlResolution,
    build_provider_control_resolution,
)
from ..provider_specs import get_provider_spec
from ..session_execution import (
    InteractiveCliRunResult,
    SessionExecutionTimeoutError,
    SessionProgressEvent,
    SessionRetryDecision,
    TranscriptMirrorStrategy,
    mirror_session_transcript,
    run_interactive_session,
)
from ..session_logs import normalize_path_str
from ._common import (
    build_progress_callback,
    build_raw_execution,
    default_execution_id,
    emit_provider_event,
    materialize_prefixed_references,
    merge_env,
    prepare_destination_path,
    redact_env_for_preview,
    run_sync_via_asyncio,
)
from ._types import (
    AttemptFinishedEventData,
    AttemptStartedEventData,
    ParseFinishedEventData,
    ProviderContinuationMode,
    ProviderContinuationResolution,
    ProviderEventCallback,
    ProviderEventKind,
    ProviderLaunchPreview,
    ProviderRawExecution,
    RecoveryAppliedEventData,
    normalize_continuation_request,
)

_LOGGER = logging.getLogger(__name__)

SUPPORT_STATE = "sync_parity"
_DEFAULT_TRANSIENT_RETRIES = 2
_DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS = 3.0
_MAX_COPILOT_SESSION_SCAN = 200
_MAX_COPILOT_PROCESS_LOG_SCAN = 200
_COPILOT_PROCESS_LOG_LOOKBACK_SECONDS = 180.0
_COPILOT_FAILURE_LOG_MARKERS = (
    "error loading models",
    "failed to list models: 429",
    "too many requests",
    "failed to start mcp client",
    "failed to open sse stream",
    "failed to get response from the ai model",
    "capierror: 500",
    "database is locked",
    "no authentication information found",
    "runpromptmode: exiting with code",
)


class CopilotSessionLookupStatus(str, Enum):
    FOUND = "found"
    NOT_FOUND = "not_found"


@dataclass(frozen=True)
class CopilotExecRequest:
    model: str
    prompt: str
    cwd: Path
    continuation_mode: ProviderContinuationMode | str = ProviderContinuationMode.NEW
    session_id: str | None = None
    session_path: Path | None = None
    binary: str | None = None
    stream: str | None = None
    reasoning_effort: str | None = None
    api_key: str | None = None
    base_url: str | None = None
    extra_args: tuple[str, ...] = ()
    timeout_seconds: float | None = None
    env: dict[str, str] | None = None
    transcript_path: Path | None = None
    transcript_progress_callback: Callable[[SessionProgressEvent], None] | None = None
    event_callback: ProviderEventCallback | None = None
    transient_retries: int = _DEFAULT_TRANSIENT_RETRIES
    transient_retry_backoff_seconds: float = _DEFAULT_TRANSIENT_RETRY_BACKOFF_SECONDS
    execution_id: str = field(default_factory=default_execution_id)

    def __post_init__(self) -> None:
        object.__setattr__(self, "cwd", Path(self.cwd))
        object.__setattr__(self, "extra_args", tuple(self.extra_args))
        normalized_mode, normalized_session_id, normalized_session_path = (
            normalize_continuation_request(
                self.continuation_mode,
                session_id=self.session_id,
                session_path=self.session_path,
            )
        )
        object.__setattr__(self, "continuation_mode", normalized_mode)
        object.__setattr__(self, "session_id", normalized_session_id)
        object.__setattr__(self, "session_path", normalized_session_path)
        if self.env is not None:
            object.__setattr__(self, "env", dict(self.env))
        if self.transcript_path is not None:
            object.__setattr__(self, "transcript_path", Path(self.transcript_path))
        normalized_reasoning_effort = _normalize_reasoning_effort_for_model(
            self.model,
            self.reasoning_effort,
        )
        object.__setattr__(self, "reasoning_effort", normalized_reasoning_effort)


def _supported_reasoning_efforts_for_model(model: str) -> tuple[str, ...]:
    model_spec = get_provider_spec("copilot").model(model)
    if model_spec is None:
        return ()
    reasoning_control = model_spec.control("model_reasoning")
    if reasoning_control is not None:
        return reasoning_control.choice_values()
    raw_supported_reasoning = model_spec.metadata.get("supportedReasoningEfforts")
    if not isinstance(raw_supported_reasoning, (list, tuple)):
        return ()
    return tuple(str(item).strip().lower() for item in raw_supported_reasoning if str(item).strip())


def _normalize_reasoning_effort_for_model(model: str, reasoning_effort: str | None) -> str | None:
    if reasoning_effort is None:
        return None
    normalized = str(reasoning_effort).strip().lower()
    if not normalized:
        return None
    supported_reasoning = _supported_reasoning_efforts_for_model(model)
    if supported_reasoning and normalized not in supported_reasoning:
        allowed_display = ", ".join(supported_reasoning)
        raise ValueError(
            f"Copilot model '{model}' only supports reasoning levels: {allowed_display}. "
            f"Received '{reasoning_effort}'."
        )
    return normalized


@dataclass(frozen=True)
class CopilotParsedOutput:
    output_text: str
    output_source: str
    parse_skipped: bool = False
    parse_error: str | None = None


@dataclass(frozen=True)
class CopilotRetryRecord:
    attempt_index: int
    category: str
    delay_seconds: float


@dataclass(frozen=True)
class CopilotSessionLookupResult:
    status: CopilotSessionLookupStatus
    path: Path | None = None
    matched_by: str | None = None
    candidate_count: int = 0

    def __post_init__(self) -> None:
        if self.path is not None:
            object.__setattr__(self, "path", Path(self.path))


@dataclass(frozen=True)
class CopilotConversationResult:
    status: CopilotSessionLookupStatus
    source_path: Path | None
    text: str
    line_count: int

    def __post_init__(self) -> None:
        if self.source_path is not None:
            object.__setattr__(self, "source_path", Path(self.source_path))


@dataclass(frozen=True)
class CopilotExecResult:
    request: CopilotExecRequest
    launch: CliLaunchSpec
    raw_result: InteractiveCliRunResult | CliRunResult
    raw_execution: ProviderRawExecution
    parsed_output: CopilotParsedOutput
    control_resolution: ProviderControlResolution
    continuation_resolution: ProviderContinuationResolution
    retry_history: tuple[CopilotRetryRecord, ...] = ()
    failure_classification: FailureClassification | None = None
    session_lookup: CopilotSessionLookupResult | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "retry_history", tuple(self.retry_history))


def materialize_prompt_file_references(
    prompt_text: str,
    file_paths: tuple[str | Path, ...] | list[str | Path],
) -> str:
    prefix = get_provider_contract("copilot").io.file_reference_prefix
    if not prefix:
        raise NotImplementedError(
            "Copilot prompt file references are not enabled in coding_cli_runtime"
        )
    normalized_paths = tuple(Path(path) for path in file_paths)
    return materialize_prefixed_references(
        prompt_text,
        normalized_paths,
        prefix=prefix,
        singular_label="File reference",
        plural_label="File references",
    )


def _new_continuation_resolution(request: CopilotExecRequest) -> ProviderContinuationResolution:
    return ProviderContinuationResolution(
        requested_mode=cast(ProviderContinuationMode, request.continuation_mode),
        requested_session_id=request.session_id,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.NEW,
        native_strategy="fresh",
    )


def _build_launch(
    request: CopilotExecRequest,
    *,
    continuation_resolution: ProviderContinuationResolution | None = None,
) -> CliLaunchSpec:
    resolved_continuation = (
        continuation_resolution
        if continuation_resolution is not None
        else _resolve_continuation(request)
    )
    cmd_parts = build_copilot_headless_core(
        request.model,
        binary=request.binary,
        stream=request.stream,
    )
    if resolved_continuation.resolved_mode is not ProviderContinuationMode.NEW:
        if resolved_continuation.resolved_session_id is None:
            raise ValueError("Copilot continuation requires a resolved session_id")
        cmd_parts.append(f"--resume={resolved_continuation.resolved_session_id}")
    cmd_parts.extend(["-p", request.prompt])
    if request.reasoning_effort:
        cmd_parts.extend(["--reasoning-effort", request.reasoning_effort])
    if request.extra_args:
        cmd_parts.extend(request.extra_args)

    display_parts: list[str] = []
    prompt_replaced = False
    for part in cmd_parts:
        if part == request.prompt and not prompt_replaced:
            display_parts.append("<prompt>")
            prompt_replaced = True
        else:
            display_parts.append(shlex.quote(part))
    return CliLaunchSpec(
        cmd_parts=tuple(cmd_parts),
        display_text=" ".join(display_parts),
        stdin_text=None,
    )


def _build_exec_env(request: CopilotExecRequest) -> dict[str, str]:
    overlay = build_env_overlay(
        get_provider_contract("copilot"),
        api_key=request.api_key,
        base_url=request.base_url,
    )
    return merge_env(request.env, overlay=overlay)


def _build_control_resolution(request: CopilotExecRequest) -> ProviderControlResolution:
    requested: dict[str, object] = {}
    if isinstance(request.reasoning_effort, str) and request.reasoning_effort.strip():
        requested["reasoning_effort"] = request.reasoning_effort.strip().lower()
    applied = dict(requested)

    defaulted: dict[str, object] = {}
    default_sources: dict[str, ControlDefaultSource] = {}
    unknown_default_keys: tuple[str, ...] = ()
    if "reasoning_effort" not in requested:
        model_spec = get_provider_spec("copilot").model(request.model)
        if model_spec is not None:
            default_reasoning = model_spec.metadata.get("defaultReasoning")
            if isinstance(default_reasoning, str) and default_reasoning.strip():
                defaulted["reasoning_effort"] = default_reasoning.strip().lower()
                default_sources["reasoning_effort"] = ControlDefaultSource.PROVIDER_DEFAULT
            elif model_spec.metadata.get("reasoningSchema") == "reasoning_effort":
                unknown_default_keys = ("reasoning_effort",)

    return build_provider_control_resolution(
        provider="copilot",
        requested=requested,
        applied=applied,
        defaulted=defaulted,
        default_sources=default_sources,
        unknown_default_keys=unknown_default_keys,
    )


def _preview_exec_env(request: CopilotExecRequest) -> dict[str, str]:
    return {
        **(request.env or {}),
        **build_env_overlay(
            get_provider_contract("copilot"),
            api_key=request.api_key,
            base_url=request.base_url,
        ),
    }


def _transcript_destination(request: CopilotExecRequest, *, create_parent: bool) -> Path:
    return prepare_destination_path(
        request.transcript_path,
        prefix="copilot_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
        create_parent=create_parent,
    )


def _prepare_launch_preview(
    request: CopilotExecRequest,
    *,
    launch: CliLaunchSpec,
    continuation_resolution: ProviderContinuationResolution,
) -> ProviderLaunchPreview:
    contract = get_provider_contract("copilot")
    control_resolution = _build_control_resolution(request)
    effective_reasoning = None
    if isinstance(request.reasoning_effort, str) and request.reasoning_effort.strip():
        effective_reasoning = request.reasoning_effort
    else:
        default_reasoning = control_resolution.defaulted.get("reasoning_effort")
        if isinstance(default_reasoning, str) and default_reasoning.strip():
            effective_reasoning = default_reasoning
    return ProviderLaunchPreview(
        cmd_parts=launch.cmd_parts,
        display_text=launch.display_text,
        cwd=request.cwd,
        stdin_text=launch.stdin_text,
        output_paths=(_transcript_destination(request, create_parent=False),),
        effective_controls={
            "model": request.model,
            "stream": request.stream or contract.headless.default_stream_mode,
            "reasoning_effort": effective_reasoning,
            "continuation_mode": continuation_resolution.resolved_mode.value,
            "resumed_session_id": continuation_resolution.resolved_session_id,
        },
        redacted_env=redact_env_for_preview(_preview_exec_env(request)),
        control_resolution=control_resolution,
        continuation_resolution=continuation_resolution,
    )


def prepare_launch(request: CopilotExecRequest) -> ProviderLaunchPreview:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(
        request,
        continuation_resolution=continuation_resolution,
    )
    return _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )


@dataclass(frozen=True)
class _CopilotSessionMetadata:
    path: Path
    session_id: str | None
    cwd: str | None
    mtime: float


def _read_copilot_session_metadata(events_path: Path) -> _CopilotSessionMetadata | None:
    try:
        mtime = events_path.stat().st_mtime
    except OSError:
        return None
    cwd = None
    try:
        with events_path.open("r", encoding="utf-8") as handle:
            for _ in range(20):
                line = handle.readline()
                if not line:
                    break
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("type") != "session.start":
                    continue
                data = record.get("data") or {}
                context = data.get("context") or {}
                raw_cwd = context.get("cwd")
                if isinstance(raw_cwd, str) and raw_cwd.strip():
                    cwd = normalize_path_str(raw_cwd)
    except OSError:
        return None
    return _CopilotSessionMetadata(
        path=events_path,
        session_id=events_path.parent.name or None,
        cwd=cwd,
        mtime=mtime,
    )


def _copilot_session_matches(events_path: Path, workdir: str) -> bool:
    metadata = _read_copilot_session_metadata(events_path)
    return metadata is not None and metadata.cwd == workdir


def _iter_copilot_session_metadata(
    *,
    session_roots: tuple[Path, ...] | list[Path],
) -> list[_CopilotSessionMetadata]:
    candidates: list[_CopilotSessionMetadata] = []
    for root in session_roots:
        if not root.exists():
            continue
        try:
            for path in root.iterdir():
                if not path.is_dir():
                    continue
                events_path = path / "events.jsonl"
                if not events_path.exists():
                    continue
                metadata = _read_copilot_session_metadata(events_path)
                if metadata is not None:
                    candidates.append(metadata)
        except OSError:
            continue
    candidates.sort(key=lambda item: item.mtime, reverse=True)
    return candidates


def _find_latest_resumable_session(
    workdir: Path,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _CopilotSessionMetadata | None:
    normalized_workdir = normalize_path_str(str(workdir.resolve()))
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("copilot"))
    )
    for metadata in _iter_copilot_session_metadata(session_roots=roots):
        if metadata.cwd == normalized_workdir:
            return metadata
    return None


def _find_copilot_session_by_id(
    workdir: Path,
    session_id: str,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> _CopilotSessionMetadata | None:
    normalized_workdir = normalize_path_str(str(workdir.resolve()))
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("copilot"))
    )
    for root in roots:
        metadata = _read_copilot_session_metadata(root / session_id / "events.jsonl")
        if metadata is None:
            continue
        if metadata.cwd is not None and metadata.cwd != normalized_workdir:
            return None
        return metadata
    return None


def _resolve_session_path_metadata(request: CopilotExecRequest) -> _CopilotSessionMetadata:
    if request.session_path is None:
        raise ValueError("Copilot session_path continuation requires a session_path")
    events_path = request.session_path.resolve()
    metadata = _read_copilot_session_metadata(events_path)
    if metadata is None:
        raise ValueError(f"Copilot session_path could not be read: {events_path}")
    expected_cwd = normalize_path_str(str(request.cwd.resolve()))
    if metadata.cwd is not None and metadata.cwd != expected_cwd:
        raise ValueError(
            "Copilot session_path belongs to a different workdir: "
            f"{metadata.cwd!r} != {expected_cwd!r}"
        )
    return metadata


def _resolve_continuation(request: CopilotExecRequest) -> ProviderContinuationResolution:
    mode = cast(ProviderContinuationMode, request.continuation_mode)
    if mode is ProviderContinuationMode.NEW:
        return _new_continuation_resolution(request)

    if mode is ProviderContinuationMode.CONTINUE_LATEST:
        metadata = _find_latest_resumable_session(request.cwd)
        if metadata is None or metadata.session_id is None:
            raise ValueError(f"No resumable Copilot session found for {request.cwd}")
        return ProviderContinuationResolution(
            requested_mode=mode,
            resolved_mode=ProviderContinuationMode.CONTINUE_LATEST,
            resolved_session_id=metadata.session_id,
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="latest",
        )

    if mode is ProviderContinuationMode.SESSION_ID:
        if request.session_id is None:
            raise ValueError("Copilot session_id continuation requires a session_id")
        metadata = _find_copilot_session_by_id(request.cwd, request.session_id)
        if metadata is None:
            raise ValueError(
                f"Copilot session_id {request.session_id!r} was not found for workdir {request.cwd}"
            )
        return ProviderContinuationResolution(
            requested_mode=mode,
            requested_session_id=request.session_id,
            resolved_mode=ProviderContinuationMode.SESSION_ID,
            resolved_session_id=request.session_id,
            resolved_session_path=metadata.path,
            native_strategy="resume",
            matched_by="session_id",
        )

    metadata = _resolve_session_path_metadata(request)
    if metadata.session_id is None:
        raise ValueError("Copilot session_path did not resolve to a session_id")
    return ProviderContinuationResolution(
        requested_mode=mode,
        requested_session_path=request.session_path,
        resolved_mode=ProviderContinuationMode.SESSION_PATH,
        resolved_session_id=metadata.session_id,
        resolved_session_path=metadata.path,
        native_strategy="resume",
        matched_by="session_path",
    )


def find_session(
    workdir: str | Path,
    since_ts: float,
    *,
    session_roots: tuple[Path, ...] | list[Path] | None = None,
) -> CopilotSessionLookupResult:
    normalized_workdir = normalize_path_str(str(Path(workdir).resolve()))
    roots = (
        tuple(Path(root) for root in session_roots)
        if session_roots is not None
        else resolve_session_search_paths(get_provider_contract("copilot"))
    )
    candidates: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        try:
            for path in root.iterdir():
                if not path.is_dir():
                    continue
                events_path = path / "events.jsonl"
                if not events_path.exists():
                    continue
                try:
                    if events_path.stat().st_mtime >= since_ts - 15:
                        candidates.append(events_path)
                except OSError:
                    continue
        except OSError:
            continue
    if not candidates:
        return CopilotSessionLookupResult(status=CopilotSessionLookupStatus.NOT_FOUND)
    candidates.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    for events_path in candidates[:_MAX_COPILOT_SESSION_SCAN]:
        if _copilot_session_matches(events_path, normalized_workdir):
            return CopilotSessionLookupResult(
                status=CopilotSessionLookupStatus.FOUND,
                path=events_path,
                matched_by="cwd",
                candidate_count=len(candidates),
            )
    return CopilotSessionLookupResult(
        status=CopilotSessionLookupStatus.NOT_FOUND, candidate_count=len(candidates)
    )


def get_conversation(source: CopilotSessionLookupResult | Path) -> CopilotConversationResult:
    if isinstance(source, CopilotSessionLookupResult):
        if source.status is not CopilotSessionLookupStatus.FOUND or source.path is None:
            return CopilotConversationResult(
                status=source.status,
                source_path=source.path,
                text="",
                line_count=0,
            )
        source_path = source.path
    else:
        source_path = Path(source)
        if not source_path.exists():
            return CopilotConversationResult(
                status=CopilotSessionLookupStatus.NOT_FOUND,
                source_path=source_path,
                text="",
                line_count=0,
            )
    text = source_path.read_text(encoding="utf-8")
    return CopilotConversationResult(
        status=CopilotSessionLookupStatus.FOUND,
        source_path=source_path,
        text=text,
        line_count=len(text.splitlines()),
    )


def _find_recent_copilot_process_log_for_workdir(
    *,
    workdir: str,
    since_ts: float,
    log_root: Path | None = None,
) -> Path | None:
    root = log_root or (Path.home() / ".copilot" / "logs")
    if not root.exists():
        return None
    target = f"cwd={normalize_path_str(workdir)}"
    try:
        candidates = sorted(
            root.glob("process-*.log"), key=lambda path: path.stat().st_mtime, reverse=True
        )
    except OSError:
        return None
    for path in candidates[:_MAX_COPILOT_PROCESS_LOG_SCAN]:
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        if mtime < since_ts - _COPILOT_PROCESS_LOG_LOOKBACK_SECONDS:
            break
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if target in text:
            return path
    return None


def _extract_copilot_log_failure_lines(log_text: str, *, limit: int = 6) -> list[str]:
    matches: list[str] = []
    seen: set[str] = set()
    for line in log_text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lowered = stripped.lower()
        if not any(marker in lowered for marker in _COPILOT_FAILURE_LOG_MARKERS):
            continue
        if stripped in seen:
            continue
        seen.add(stripped)
        matches.append(stripped)
    return matches[-limit:]


def _extract_copilot_process_failure_detail(
    *,
    workdir: Path,
    since_ts: float,
    log_root: Path | None = None,
) -> tuple[str | None, Path | None]:
    log_path = _find_recent_copilot_process_log_for_workdir(
        workdir=str(workdir),
        since_ts=since_ts,
        log_root=log_root,
    )
    if log_path is None:
        return None, None
    try:
        log_text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None, log_path
    lines = _extract_copilot_log_failure_lines(log_text)
    if not lines:
        return None, log_path
    return f"copilot process log ({log_path}): {' | '.join(lines)}", log_path


def _merge_failure_details(stderr_text: str, log_detail: str | None) -> str:
    stderr_detail = stderr_text.strip()
    if stderr_detail and log_detail:
        return f"{stderr_detail}\n{log_detail}"
    if stderr_detail:
        return stderr_detail
    if log_detail:
        return log_detail
    return "no stderr output captured"


def _classify_attempt_failure(
    request: CopilotExecRequest,
    raw_result: InteractiveCliRunResult | CliRunResult,
) -> tuple[FailureClassification, str]:
    stderr_text = _stderr_text(raw_result)
    failure = classify_provider_failure(provider="copilot", stderr_text=stderr_text)
    log_detail = None
    if not stderr_text.strip() or failure.category == "unknown":
        log_detail, _ = _extract_copilot_process_failure_detail(
            workdir=request.cwd,
            since_ts=getattr(raw_result, "started_at", time.time()),
        )
    failure_detail = _merge_failure_details(stderr_text, log_detail)
    return classify_provider_failure(provider="copilot", stderr_text=failure_detail), failure_detail


def parse_output(
    *,
    stdout_text: str,
    stderr_text: str = "",
) -> CopilotParsedOutput:
    if stdout_text.strip():
        return CopilotParsedOutput(
            output_text=stdout_text,
            output_source="stdout",
        )
    if stderr_text.strip():
        return CopilotParsedOutput(
            output_text=stderr_text,
            output_source="stderr",
        )
    return CopilotParsedOutput(
        output_text="",
        output_source="none",
        parse_skipped=True,
        parse_error="Copilot produced no stdout or stderr payload",
    )


def _stdout_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stdout_text
    return raw_result.stdout.decode("utf-8", errors="replace")


def _stderr_text(raw_result: InteractiveCliRunResult | CliRunResult) -> str:
    if isinstance(raw_result, CliRunResult):
        return raw_result.stderr_text
    return raw_result.stderr.decode("utf-8", errors="replace")


def _returncode(raw_result: InteractiveCliRunResult | CliRunResult) -> int | None:
    return raw_result.returncode


def _resolve_session_lookup_from_result(
    continuation_resolution: ProviderContinuationResolution,
) -> CopilotSessionLookupResult | None:
    if continuation_resolution.resolved_session_path is not None:
        return CopilotSessionLookupResult(
            status=CopilotSessionLookupStatus.FOUND,
            path=continuation_resolution.resolved_session_path,
            matched_by=continuation_resolution.matched_by,
            candidate_count=1,
        )
    return None


async def _run_raw_with_context(
    request: CopilotExecRequest,
    *,
    launch: CliLaunchSpec,
    launch_preview: ProviderLaunchPreview,
    continuation_resolution: ProviderContinuationResolution,
) -> tuple[
    InteractiveCliRunResult | CliRunResult,
    tuple[CopilotRetryRecord, ...],
    CopilotSessionLookupResult | None,
    str | None,
]:
    retry_history: list[CopilotRetryRecord] = []
    failure_detail_by_attempt: dict[int, str] = {}
    max_cli_attempts = max(1, request.transient_retries + 1)
    current_attempt = 0
    raw_result: InteractiveCliRunResult | CliRunResult
    transcript_path = prepare_destination_path(
        request.transcript_path,
        prefix="copilot_conversation_",
        suffix=".jsonl",
        execution_id=request.execution_id,
    )
    start_ts = None
    progress_callback = build_progress_callback(
        provider="copilot",
        get_attempt_index=lambda: max(1, current_attempt),
        event_callback=request.event_callback,
        transcript_progress_callback=request.transcript_progress_callback,
        logger=_LOGGER,
    )

    def locate_source() -> Path | None:
        if start_ts is None:
            return None
        lookup = find_session(request.cwd, start_ts)
        return lookup.path if lookup.status is CopilotSessionLookupStatus.FOUND else None

    transcript_strategy = TranscriptMirrorStrategy(
        provider_label="Copilot",
        destination=transcript_path,
        locate_source=locate_source,
        poll_interval=1.0,
        refresh_source_each_poll=True,
        progress_callback=progress_callback,
    )

    async def create_process(
        *cmd_parts: str,
        **kwargs: Any,
    ) -> asyncio.subprocess.Process:
        nonlocal current_attempt
        current_attempt += 1
        emit_provider_event(
            callback=request.event_callback,
            provider="copilot",
            attempt_index=current_attempt,
            kind=ProviderEventKind.ATTEMPT_STARTED,
            data=AttemptStartedEventData(
                launch=launch_preview,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return await asyncio.create_subprocess_exec(*cmd_parts, **kwargs)

    def retry_decider(
        result: InteractiveCliRunResult,
        cli_attempt: int,
        max_cli_attempts: int,
    ) -> SessionRetryDecision:
        failure, failure_detail = _classify_attempt_failure(request, result)
        failure_detail_by_attempt[cli_attempt] = failure_detail
        should_retry = failure.retryable and cli_attempt < max(1, max_cli_attempts)
        delay = (
            max(0.0, request.transient_retry_backoff_seconds) * cli_attempt if should_retry else 0.0
        )
        if should_retry:
            retry_history.append(
                CopilotRetryRecord(
                    attempt_index=cli_attempt,
                    category=failure.category,
                    delay_seconds=delay,
                )
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="copilot",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.ATTEMPT_FINISHED,
                data=AttemptFinishedEventData(
                    returncode=result.returncode,
                    timed_out=False,
                    conversation_path=result.conversation_path,
                    started_at=result.started_at,
                    cli_attempt_used=result.cli_attempt_used,
                    max_cli_attempts=result.max_cli_attempts,
                ),
                logger=_LOGGER,
            )
            emit_provider_event(
                callback=request.event_callback,
                provider="copilot",
                attempt_index=cli_attempt,
                kind=ProviderEventKind.RECOVERY_APPLIED,
                data=RecoveryAppliedEventData(
                    category=failure.category,
                    delay_seconds=delay,
                    next_attempt_index=cli_attempt + 1,
                ),
                logger=_LOGGER,
            )
        return SessionRetryDecision(
            retry=should_retry,
            delay_seconds=delay,
            category=failure.category,
        )

    start_ts = time.time()
    try:
        raw_result = await run_interactive_session(
            cmd_parts=launch.cmd_parts,
            cwd=request.cwd,
            stdin_text=None,
            logger=_LOGGER,
            provider_label="Copilot",
            job_name=request.cwd.name or "copilot",
            process_label="Copilot process",
            timeout_seconds=request.timeout_seconds,
            env=_build_exec_env(request),
            transcript_factory=lambda proc: mirror_session_transcript(
                job_name=request.cwd.name or "copilot",
                phase_tag="",
                logger=_LOGGER,
                proc=proc,
                strategy=transcript_strategy,
            ),
            create_process=create_process,
            max_cli_attempts=max_cli_attempts,
            retry_decider=retry_decider,
        )
        session_lookup = _resolve_session_lookup_from_result(
            continuation_resolution,
        )
        if session_lookup is None:
            session_lookup = find_session(request.cwd, raw_result.started_at)
            if (
                session_lookup.status is not CopilotSessionLookupStatus.FOUND
                and raw_result.conversation_path is not None
            ):
                session_lookup = CopilotSessionLookupResult(
                    status=CopilotSessionLookupStatus.FOUND,
                    path=raw_result.conversation_path,
                    matched_by="transcript_capture",
                    candidate_count=1,
                )
        final_detail = None
        if raw_result.returncode not in (None, 0):
            final_detail = failure_detail_by_attempt.get(raw_result.cli_attempt_used)
            if final_detail is None:
                _, final_detail = _classify_attempt_failure(request, raw_result)
        emit_provider_event(
            callback=request.event_callback,
            provider="copilot",
            attempt_index=max(1, getattr(raw_result, "cli_attempt_used", current_attempt or 1)),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=raw_result.returncode,
                timed_out=getattr(raw_result, "timed_out", False),
                conversation_path=getattr(raw_result, "conversation_path", None),
                started_at=getattr(raw_result, "started_at", None),
                cli_attempt_used=getattr(raw_result, "cli_attempt_used", None),
                max_cli_attempts=getattr(raw_result, "max_cli_attempts", max_cli_attempts),
            ),
            logger=_LOGGER,
        )
        return raw_result, tuple(retry_history), session_lookup, final_detail
    except SessionExecutionTimeoutError as exc:
        raw_result = CliRunResult(
            command=launch.cmd_parts,
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=0.0,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=str(exc),
        )
        session_lookup = _resolve_session_lookup_from_result(
            continuation_resolution,
        )
        if session_lookup is None and getattr(exc, "conversation_path", None) is not None:
            session_lookup = CopilotSessionLookupResult(
                status=CopilotSessionLookupStatus.FOUND,
                path=exc.conversation_path,
                matched_by="transcript_capture",
                candidate_count=1,
            )
        emit_provider_event(
            callback=request.event_callback,
            provider="copilot",
            attempt_index=max(1, current_attempt or 1),
            kind=ProviderEventKind.ATTEMPT_FINISHED,
            data=AttemptFinishedEventData(
                returncode=None,
                timed_out=True,
                conversation_path=getattr(exc, "conversation_path", None),
                started_at=getattr(exc, "started_at", start_ts),
                cli_attempt_used=current_attempt or 1,
                max_cli_attempts=max_cli_attempts,
            ),
            logger=_LOGGER,
        )
        return raw_result, tuple(retry_history), session_lookup, None


def _build_exec_result(
    request: CopilotExecRequest,
    launch: CliLaunchSpec,
    continuation_resolution: ProviderContinuationResolution,
    raw_result: InteractiveCliRunResult | CliRunResult,
    *,
    failure_detail: str | None = None,
    retry_history: tuple[CopilotRetryRecord, ...] = (),
    session_lookup: CopilotSessionLookupResult | None = None,
) -> CopilotExecResult:
    stdout_text = _stdout_text(raw_result)
    stderr_text = _stderr_text(raw_result)
    parsed_output = parse_output(
        stdout_text=stdout_text,
        stderr_text=stderr_text,
    )
    failure_classification = None
    if _returncode(raw_result) not in (None, 0):
        detail = failure_detail or _merge_failure_details(stderr_text, None)
        if detail.strip():
            failure_classification = classify_provider_failure(
                provider="copilot",
                stderr_text=detail,
            )
    control_resolution = _build_control_resolution(request)
    return CopilotExecResult(
        request=request,
        launch=launch,
        raw_result=raw_result,
        raw_execution=build_raw_execution(
            raw_result,
            conversation_path=session_lookup.path if session_lookup is not None else None,
        ),
        parsed_output=parsed_output,
        control_resolution=control_resolution,
        continuation_resolution=continuation_resolution,
        retry_history=retry_history,
        failure_classification=failure_classification,
        session_lookup=session_lookup,
    )


async def run_raw(request: CopilotExecRequest) -> InteractiveCliRunResult | CliRunResult:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(
        request,
        continuation_resolution=continuation_resolution,
    )
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )
    raw_result, _, _, _ = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    return raw_result


async def run(request: CopilotExecRequest) -> CopilotExecResult:
    continuation_resolution = _resolve_continuation(request)
    launch = _build_launch(
        request,
        continuation_resolution=continuation_resolution,
    )
    launch_preview = _prepare_launch_preview(
        request,
        launch=launch,
        continuation_resolution=continuation_resolution,
    )
    raw_result, retry_history, session_lookup, failure_detail = await _run_raw_with_context(
        request,
        launch=launch,
        launch_preview=launch_preview,
        continuation_resolution=continuation_resolution,
    )
    result = _build_exec_result(
        request,
        launch,
        continuation_resolution,
        raw_result,
        failure_detail=failure_detail,
        retry_history=retry_history,
        session_lookup=session_lookup,
    )
    emit_provider_event(
        callback=request.event_callback,
        provider="copilot",
        attempt_index=max(1, getattr(raw_result, "cli_attempt_used", len(retry_history) + 1)),
        kind=ProviderEventKind.PARSE_FINISHED,
        data=ParseFinishedEventData(
            parse_skipped=result.parsed_output.parse_skipped,
            parse_error=result.parsed_output.parse_error,
        ),
        logger=_LOGGER,
    )
    return result


def run_sync(request: CopilotExecRequest) -> CopilotExecResult:
    return cast(CopilotExecResult, run_sync_via_asyncio(run(request)))


__all__ = [
    "CopilotConversationResult",
    "CopilotExecRequest",
    "CopilotExecResult",
    "CopilotParsedOutput",
    "CopilotRetryRecord",
    "CopilotSessionLookupResult",
    "CopilotSessionLookupStatus",
    "SUPPORT_STATE",
    "find_session",
    "get_conversation",
    "materialize_prompt_file_references",
    "parse_output",
    "prepare_launch",
    "run",
    "run_raw",
    "run_sync",
]
