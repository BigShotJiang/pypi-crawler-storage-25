"""Core contracts for shared CLI runtime execution."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class ErrorCode(str, Enum):
    NONE = "none"
    SPAWN_FAILED = "spawn_failed"
    TIMED_OUT = "timed_out"
    NON_ZERO_EXIT = "non_zero_exit"


class AuthMode(str, Enum):
    NONE = "none"
    ENV = "env"
    CLI_LOGIN = "cli_login"
    TOKEN_FILE = "token_file"


@dataclass(frozen=True)
class CliRunRequest:
    cmd_parts: tuple[str, ...]
    cwd: Path
    stdin_text: str | None = None
    env: dict[str, str] | None = None
    timeout_seconds: float | None = None
    stdout_stream_path: Path | None = None
    stderr_stream_path: Path | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "cmd_parts", tuple(self.cmd_parts))
        if self.env is not None:
            object.__setattr__(self, "env", dict(self.env))


@dataclass(frozen=True)
class CliLaunchSpec:
    cmd_parts: tuple[str, ...]
    display_text: str
    stdin_text: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "cmd_parts", tuple(self.cmd_parts))


@dataclass(frozen=True)
class CliRunResult:
    command: Sequence[str]
    returncode: int | None
    stdout_text: str
    stderr_text: str
    duration_seconds: float
    timed_out: bool
    error_code: ErrorCode
    error_message: str | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "command", tuple(self.command))


@dataclass(frozen=True)
class ClaudeReasoningPolicy:
    mode: str
    effective_effort: str | None
    effort_source: str | None
    thinking_tokens: int | None
    disable_via_env_setting: bool = False
