"""Provider-native transcript parsing into shared derived facts.

Raw transcript formats remain provider-specific. This module exposes a small,
versioned, provider-agnostic facts API that downstream consumers can reuse
without depending on the underlying event schemas directly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CANONICAL_TRANSCRIPT_INPUTS: dict[str, str] = {
    "claude": "claude_conversation.jsonl",
    "codex": "codex_conversation.jsonl",
    "copilot": "copilot_conversation.jsonl",
    "gemini": "gemini_conversation.json",
}

HUMAN_READABLE_TRANSCRIPT_SIDECARS: dict[str, tuple[str, ...]] = {}


class TranscriptFactsError(ValueError):
    """Raised when a structured transcript exists but cannot be parsed safely."""


def _clean_string(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    return text or None


def _read_json_object(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise TranscriptFactsError(f"failed to read transcript {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise TranscriptFactsError(
            f"invalid JSON transcript {path}: line {exc.lineno} column {exc.colno}: {exc.msg}"
        ) from exc
    if not isinstance(parsed, dict):
        raise TranscriptFactsError(f"invalid JSON transcript {path}: expected top-level object")
    return parsed if isinstance(parsed, dict) else None


def _read_jsonl_objects(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    records: list[dict[str, Any]] = []
    try:
        with path.open(encoding="utf-8") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    parsed = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise TranscriptFactsError(
                        f"invalid JSONL transcript {path}: line {line_number}: {exc.msg}"
                    ) from exc
                if not isinstance(parsed, dict):
                    raise TranscriptFactsError(
                        f"invalid JSONL transcript {path}: line {line_number}: expected object"
                    )
                records.append(parsed)
    except OSError as exc:
        raise TranscriptFactsError(f"failed to read transcript {path}: {exc}") from exc
    return records


def _extract_text_from_content_blocks(content: object) -> tuple[str | None, int]:
    tool_count = 0
    if isinstance(content, str):
        return _clean_string(content), 0
    if not isinstance(content, list):
        return None, 0
    parts: list[str] = []
    for block in content:
        if isinstance(block, str):
            text = _clean_string(block)
            if text:
                parts.append(text)
            continue
        if not isinstance(block, dict):
            continue
        block_type = _clean_string(block.get("type")) or ""
        if block_type in {"tool_use", "server_tool_use", "function_call", "tool_call"}:
            tool_count += 1
        text = _clean_string(block.get("text"))
        if text:
            parts.append(text)
    joined = "\n".join(parts).strip()
    return joined or None, tool_count


def _extract_text_from_claude_message(message: object) -> tuple[str | None, int]:
    if not isinstance(message, dict):
        return None, 0
    return _extract_text_from_content_blocks(message.get("content"))


def _extract_text_from_gemini_message(message: object) -> tuple[str | None, int]:
    if not isinstance(message, dict):
        return None, 0
    return _extract_text_from_content_blocks(message.get("content"))


def _extract_text_from_codex_record(record: object) -> tuple[str | None, int]:
    tool_count = 0
    parts: list[str] = []

    def _visit(value: object) -> None:
        nonlocal tool_count
        if isinstance(value, dict):
            block_type = _clean_string(value.get("type")) or ""
            if block_type in {"function_call", "tool_call", "tool_use", "custom_tool_call"}:
                tool_count += 1
            text = _clean_string(value.get("text"))
            if text:
                parts.append(text)
            output_text = _clean_string(value.get("output_text"))
            if output_text:
                parts.append(output_text)
            for child in value.values():
                _visit(child)
        elif isinstance(value, list):
            for child in value:
                _visit(child)

    _visit(record)
    joined = "\n".join(dict.fromkeys(part for part in parts if part)).strip()
    return joined or None, tool_count


@dataclass(frozen=True)
class TranscriptFactsV1:
    assistant_messages: int = 0
    content_messages: int = 0
    reasoning_only_messages: int = 0
    mixed_messages: int = 0
    tool_execution_start_count: int = 0
    final_content: str | None = None

    @property
    def version(self) -> int:
        return 1

    def to_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "assistant_messages": self.assistant_messages,
            "content_messages": self.content_messages,
            "reasoning_only_messages": self.reasoning_only_messages,
            "mixed_messages": self.mixed_messages,
            "tool_execution_start_count": self.tool_execution_start_count,
            "final_content": self.final_content,
        }


EMPTY_TRANSCRIPT_FACTS_V1 = TranscriptFactsV1()


def _derive_copilot_facts(records: list[dict[str, Any]]) -> TranscriptFactsV1:
    assistant_messages = 0
    content_messages = 0
    reasoning_only_messages = 0
    mixed_messages = 0
    tool_execution_start_count = 0
    final_content: str | None = None
    for record in records:
        if record.get("type") == "tool.execution_start":
            tool_execution_start_count += 1
            continue
        if record.get("type") != "assistant.message":
            continue
        assistant_messages += 1
        data = record.get("data")
        if not isinstance(data, dict):
            continue
        content = _clean_string(data.get("content"))
        reasoning = _clean_string(data.get("reasoningText"))
        has_content = content is not None
        has_reasoning = reasoning is not None
        if has_content:
            content_messages += 1
            final_content = content
        if has_reasoning and not has_content:
            reasoning_only_messages += 1
        if has_reasoning and has_content:
            mixed_messages += 1
    return TranscriptFactsV1(
        assistant_messages=assistant_messages,
        content_messages=content_messages,
        reasoning_only_messages=reasoning_only_messages,
        mixed_messages=mixed_messages,
        tool_execution_start_count=tool_execution_start_count,
        final_content=final_content,
    )


def _derive_claude_facts(records: list[dict[str, Any]]) -> TranscriptFactsV1:
    assistant_messages = 0
    content_messages = 0
    tool_execution_start_count = 0
    final_content: str | None = None
    for record in records:
        is_assistant = record.get("type") == "assistant"
        message = record.get("message")
        if isinstance(message, dict) and message.get("role") == "assistant":
            is_assistant = True
        if not is_assistant:
            continue
        assistant_messages += 1
        content, tool_count = _extract_text_from_claude_message(message)
        tool_execution_start_count += tool_count
        if content is not None:
            content_messages += 1
            final_content = content
    return TranscriptFactsV1(
        assistant_messages=assistant_messages,
        content_messages=content_messages,
        tool_execution_start_count=tool_execution_start_count,
        final_content=final_content,
    )


def _derive_gemini_facts(payload: dict[str, Any]) -> TranscriptFactsV1:
    assistant_messages = 0
    content_messages = 0
    tool_execution_start_count = 0
    final_content: str | None = None
    for message in payload.get("messages", []):
        if not isinstance(message, dict):
            continue
        if _clean_string(message.get("type")) != "gemini":
            continue
        assistant_messages += 1
        content, tool_count = _extract_text_from_gemini_message(message)
        tool_execution_start_count += tool_count
        if content is not None:
            content_messages += 1
            final_content = content
    return TranscriptFactsV1(
        assistant_messages=assistant_messages,
        content_messages=content_messages,
        tool_execution_start_count=tool_execution_start_count,
        final_content=final_content,
    )


def _derive_codex_facts(records: list[dict[str, Any]]) -> TranscriptFactsV1:
    assistant_messages = 0
    content_messages = 0
    tool_execution_start_count = 0
    final_content: str | None = None
    fallback_content: str | None = None
    tool_call_types = {"function_call", "tool_call", "tool_use", "custom_tool_call"}
    for record in records:
        record_type = _clean_string(record.get("type")) or ""
        if record_type == "response_item":
            payload = record.get("payload")
            if not isinstance(payload, dict):
                continue
            payload_type = _clean_string(payload.get("type")) or ""
            if payload_type in tool_call_types:
                tool_execution_start_count += 1
                continue
            if payload_type == "message" and _clean_string(payload.get("role")) == "assistant":
                assistant_messages += 1
                content, tool_count = _extract_text_from_codex_record(payload.get("content"))
                tool_execution_start_count += tool_count
                if content is not None:
                    content_messages += 1
                    final_content = content
                continue
            continue
        if record_type == "event_msg":
            payload = record.get("payload")
            if not isinstance(payload, dict):
                continue
            payload_type = _clean_string(payload.get("type")) or ""
            if payload_type == "agent_message":
                fallback_content = _clean_string(payload.get("message")) or fallback_content
            elif payload_type in tool_call_types:
                tool_execution_start_count += 1
            continue

        is_assistant = False
        if record_type == "assistant":
            is_assistant = True
        elif record.get("role") == "assistant":
            is_assistant = True
        elif (
            isinstance(record.get("message"), dict) and record["message"].get("role") == "assistant"
        ):
            is_assistant = True
        elif isinstance(record.get("item"), dict) and record["item"].get("role") == "assistant":
            is_assistant = True
        elif record_type == "response.completed" or record_type.endswith("response.completed"):
            is_assistant = True
        if not is_assistant:
            continue
        assistant_messages += 1
        content, tool_count = _extract_text_from_codex_record(record)
        tool_execution_start_count += tool_count
        if content is not None:
            content_messages += 1
            final_content = content
    if final_content is None and fallback_content is not None:
        final_content = fallback_content
        assistant_messages = max(assistant_messages, 1)
        content_messages = max(content_messages, 1)
    return TranscriptFactsV1(
        assistant_messages=assistant_messages,
        content_messages=content_messages,
        tool_execution_start_count=tool_execution_start_count,
        final_content=final_content,
    )


def derive_transcript_facts(
    provider: str | None,
    transcript_path: str | Path | None,
) -> TranscriptFactsV1:
    if transcript_path is None:
        return EMPTY_TRANSCRIPT_FACTS_V1
    normalized_provider = (_clean_string(provider) or "").lower()
    if normalized_provider not in CANONICAL_TRANSCRIPT_INPUTS:
        raise TranscriptFactsError(f"unsupported transcript facts provider: {provider!r}")
    path = Path(transcript_path)
    if normalized_provider == "copilot":
        return _derive_copilot_facts(_read_jsonl_objects(path))
    if normalized_provider == "claude":
        return _derive_claude_facts(_read_jsonl_objects(path))
    if normalized_provider == "gemini":
        payload = _read_json_object(path) or {}
        return _derive_gemini_facts(payload)
    if normalized_provider == "codex":
        return _derive_codex_facts(_read_jsonl_objects(path))
    raise TranscriptFactsError(f"unsupported transcript facts provider: {provider!r}")
