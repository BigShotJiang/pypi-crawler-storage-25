"""Async subprocess execution wrapper with normalized result shape."""

from __future__ import annotations

import asyncio
import subprocess
import threading
import time
from pathlib import Path
from typing import BinaryIO

from .contracts import CliRunRequest, CliRunResult, ErrorCode


def _decode_output(payload: bytes | str | None) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    return payload.decode("utf-8", errors="replace")


def _open_stream_handle(path: Path | None) -> BinaryIO | None:
    if path is None:
        return None
    path.parent.mkdir(parents=True, exist_ok=True)
    return path.open("wb")


def _stream_pipe(
    pipe: BinaryIO | None,
    chunks: list[bytes],
    stream_handle: BinaryIO | None,
) -> None:
    if pipe is None:
        return
    while True:
        chunk = pipe.read(4096)
        if not chunk:
            break
        chunks.append(chunk)
        if stream_handle is not None:
            stream_handle.write(chunk)
            stream_handle.flush()


async def run_cli_command(request: CliRunRequest) -> CliRunResult:
    started = time.monotonic()
    try:
        proc = await asyncio.create_subprocess_exec(
            *request.cmd_parts,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            stdin=(
                asyncio.subprocess.PIPE
                if request.stdin_text is not None
                else asyncio.subprocess.DEVNULL
            ),
            cwd=str(request.cwd),
            env=request.env,
        )
    except Exception as exc:
        duration = time.monotonic() - started
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.SPAWN_FAILED,
            error_message=str(exc),
        )

    stdin_bytes = request.stdin_text.encode("utf-8") if request.stdin_text is not None else None
    try:
        if request.timeout_seconds and request.timeout_seconds > 0:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=stdin_bytes), timeout=request.timeout_seconds
            )
        else:
            stdout, stderr = await proc.communicate(input=stdin_bytes)
    except TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        await proc.wait()
        duration = time.monotonic() - started
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=duration,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=f"process timed out after {request.timeout_seconds}s",
        )

    duration = time.monotonic() - started
    stdout_text = stdout.decode("utf-8", errors="replace")
    stderr_text = stderr.decode("utf-8", errors="replace")

    if proc.returncode != 0:
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=proc.returncode,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.NON_ZERO_EXIT,
            error_message=f"process exited with code {proc.returncode}",
        )

    return CliRunResult(
        command=list(request.cmd_parts),
        returncode=proc.returncode,
        stdout_text=stdout_text,
        stderr_text=stderr_text,
        duration_seconds=duration,
        timed_out=False,
        error_code=ErrorCode.NONE,
        error_message=None,
    )


def run_cli_command_sync(request: CliRunRequest) -> CliRunResult:
    started = time.monotonic()
    stdin_bytes = request.stdin_text.encode("utf-8") if request.stdin_text is not None else None
    timeout = (
        request.timeout_seconds if request.timeout_seconds and request.timeout_seconds > 0 else None
    )
    stream_requested = (
        request.stdout_stream_path is not None or request.stderr_stream_path is not None
    )
    if stream_requested:
        return _run_cli_command_sync_streaming(
            request=request,
            started=started,
            stdin_bytes=stdin_bytes,
            timeout=timeout,
        )

    try:
        run_kwargs = {
            "cwd": str(request.cwd),
            "env": request.env,
            "input": stdin_bytes,
            "capture_output": True,
            "timeout": timeout,
            "check": False,
        }
        if request.stdin_text is None:
            run_kwargs["stdin"] = subprocess.DEVNULL
        completed = subprocess.run(
            request.cmd_parts,
            **run_kwargs,  # type: ignore[call-overload]
        )
        duration = time.monotonic() - started
    except subprocess.TimeoutExpired as exc:
        duration = time.monotonic() - started
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=None,
            stdout_text=_decode_output(exc.stdout),
            stderr_text=_decode_output(exc.stderr),
            duration_seconds=duration,
            timed_out=True,
            error_code=ErrorCode.TIMED_OUT,
            error_message=f"process timed out after {request.timeout_seconds}s",
        )
    except Exception as exc:
        duration = time.monotonic() - started
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=None,
            stdout_text="",
            stderr_text="",
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.SPAWN_FAILED,
            error_message=str(exc),
        )

    stdout_text = _decode_output(completed.stdout)
    stderr_text = _decode_output(completed.stderr)
    if completed.returncode != 0:
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=completed.returncode,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.NON_ZERO_EXIT,
            error_message=f"process exited with code {completed.returncode}",
        )

    return CliRunResult(
        command=list(request.cmd_parts),
        returncode=completed.returncode,
        stdout_text=stdout_text,
        stderr_text=stderr_text,
        duration_seconds=duration,
        timed_out=False,
        error_code=ErrorCode.NONE,
        error_message=None,
    )


def _run_cli_command_sync_streaming(
    *,
    request: CliRunRequest,
    started: float,
    stdin_bytes: bytes | None,
    timeout: float | None,
) -> CliRunResult:
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    stdout_stream = _open_stream_handle(request.stdout_stream_path)
    stderr_stream = _open_stream_handle(request.stderr_stream_path)
    proc: subprocess.Popen[bytes] | None = None
    stdin_thread: threading.Thread | None = None
    stdout_thread: threading.Thread | None = None
    stderr_thread: threading.Thread | None = None
    try:
        proc = subprocess.Popen(
            request.cmd_parts,
            cwd=str(request.cwd),
            env=request.env,
            stdin=(subprocess.PIPE if request.stdin_text is not None else subprocess.DEVNULL),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        def _write_stdin() -> None:
            if proc is None or proc.stdin is None:
                return
            try:
                if stdin_bytes is not None:
                    proc.stdin.write(stdin_bytes)
                    proc.stdin.flush()
            except (BrokenPipeError, OSError):
                pass
            finally:
                try:
                    proc.stdin.close()
                except OSError:
                    pass

        if request.stdin_text is not None:
            stdin_thread = threading.Thread(target=_write_stdin, daemon=True)
            stdin_thread.start()
        stdout_thread = threading.Thread(
            target=_stream_pipe,
            args=(proc.stdout, stdout_chunks, stdout_stream),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=_stream_pipe,
            args=(proc.stderr, stderr_chunks, stderr_stream),
            daemon=True,
        )
        stdout_thread.start()
        stderr_thread.start()

        timed_out = False
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            proc.wait()

        if stdin_thread is not None:
            stdin_thread.join()
        if stdout_thread is not None:
            stdout_thread.join()
        if stderr_thread is not None:
            stderr_thread.join()

        duration = time.monotonic() - started
        stdout_text = _decode_output(b"".join(stdout_chunks))
        stderr_text = _decode_output(b"".join(stderr_chunks))
        if timed_out:
            return CliRunResult(
                command=list(request.cmd_parts),
                returncode=None,
                stdout_text=stdout_text,
                stderr_text=stderr_text,
                duration_seconds=duration,
                timed_out=True,
                error_code=ErrorCode.TIMED_OUT,
                error_message=f"process timed out after {request.timeout_seconds}s",
            )
        if proc.returncode != 0:
            return CliRunResult(
                command=list(request.cmd_parts),
                returncode=proc.returncode,
                stdout_text=stdout_text,
                stderr_text=stderr_text,
                duration_seconds=duration,
                timed_out=False,
                error_code=ErrorCode.NON_ZERO_EXIT,
                error_message=f"process exited with code {proc.returncode}",
            )
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=proc.returncode,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.NONE,
            error_message=None,
        )
    except Exception as exc:
        duration = time.monotonic() - started
        return CliRunResult(
            command=list(request.cmd_parts),
            returncode=None,
            stdout_text=_decode_output(b"".join(stdout_chunks)),
            stderr_text=_decode_output(b"".join(stderr_chunks)),
            duration_seconds=duration,
            timed_out=False,
            error_code=ErrorCode.SPAWN_FAILED,
            error_message=str(exc),
        )
    finally:
        if proc is not None:
            for pipe in (proc.stdin, proc.stdout, proc.stderr):
                if pipe is None:
                    continue
                try:
                    pipe.close()
                except OSError:
                    pass
        if stdout_stream is not None:
            stdout_stream.close()
        if stderr_stream is not None:
            stderr_stream.close()
