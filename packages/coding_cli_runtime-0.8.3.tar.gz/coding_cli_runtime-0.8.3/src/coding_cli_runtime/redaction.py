"""Log redaction helpers for shared runtime diagnostics."""

from __future__ import annotations

import re

SENSITIVE_PATTERNS = (
    re.compile(r"(api[_-]?key\s*[=:]\s*)([^\s\"']+)", re.IGNORECASE),
    re.compile(r"(authorization\s*[:=]\s*bearer\s+)([^\s\"']+)", re.IGNORECASE),
    re.compile(r"(token\s*[=:]\s*)([^\s\"']+)", re.IGNORECASE),
)


def redact_text(text: str) -> str:
    if not text:
        return text
    redacted = text
    for pattern in SENSITIVE_PATTERNS:
        redacted = pattern.sub(r"\1<redacted>", redacted)
    return redacted
