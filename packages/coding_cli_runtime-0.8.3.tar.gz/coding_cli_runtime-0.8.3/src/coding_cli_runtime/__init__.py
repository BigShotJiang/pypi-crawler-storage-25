"""Stable core runtime primitives for orchestrating LLM provider CLIs.

The root package exposes the stable metadata and execution substrate.
Preview provider-aware adapters live under ``coding_cli_runtime.providers``
and are exposed lazily via module attribute access.
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

from .auth import AuthResolution, resolve_auth
from .codex_cli import CodexExecSpec, build_codex_exec_spec
from .contracts import (
    AuthMode,
    ClaudeReasoningPolicy,
    CliLaunchSpec,
    CliRunRequest,
    CliRunResult,
    ErrorCode,
)
from .failure_classification import FailureClassification, classify_provider_failure
from .headless import (
    build_claude_headless_core,
    build_codex_headless_core,
    build_copilot_headless_core,
    build_gemini_headless_core,
)
from .provider_contracts import (
    ApprovalContract,
    AuthContract,
    DiagnosticsContract,
    HeadlessContract,
    IoContract,
    OutputContract,
    PathContract,
    PromptPayload,
    PromptTransport,
    ProviderContract,
    SandboxContract,
    SessionDiscoveryContract,
    WorkspaceEnvValueSource,
    WorkspaceEnvVar,
    build_env_overlay,
    get_provider_contract,
    is_provider_installed,
    list_provider_ids,
    render_prompt,
    resolve_config_paths,
    resolve_session_search_paths,
    resolve_workspace_env,
)
from .provider_controls import (
    ControlDefaultSource,
    ProviderControlResolution,
    UnsupportedControlMode,
    build_model_id,
    resolve_provider_model_control_resolution,
    resolve_provider_model_controls,
)
from .provider_specs import (
    ChoiceSpec,
    ControlSpec,
    ModelSpec,
    ProviderSpec,
    get_claude_default_model,
    get_claude_effort_levels,
    get_claude_model_candidates,
    get_claude_output_suffixes,
    get_claude_permission_modes,
    get_codex_supported_models,
    get_copilot_default_model,
    get_copilot_model_catalog,
    get_copilot_stream_choices,
    get_gemini_default_model,
    get_gemini_model_options,
    get_provider_spec,
    list_provider_specs,
    serialize_provider_specs,
)
from .reasoning import resolve_claude_reasoning_policy
from .redaction import redact_text
from .schema_validation import SchemaValidationError, load_schema, validate_payload
from .session_execution import (
    InteractiveCliRunResult,
    SessionExecutionTimeoutError,
    SessionProgressEvent,
    SessionRetryDecision,
    TranscriptMirrorStrategy,
    mirror_session_transcript,
    run_interactive_session,
)
from .session_logs import (
    claude_project_key,
    find_claude_session,
    find_codex_session,
    normalize_path_str,
)
from .subprocess_runner import run_cli_command, run_cli_command_sync
from .transcript_facts import (
    CANONICAL_TRANSCRIPT_INPUTS,
    EMPTY_TRANSCRIPT_FACTS_V1,
    HUMAN_READABLE_TRANSCRIPT_SIDECARS,
    TranscriptFactsError,
    TranscriptFactsV1,
    derive_transcript_facts,
)

__version__ = "0.8.3"


def __getattr__(name: str) -> Any:
    if name == "providers":
        module = import_module(f"{__name__}.providers")
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*globals().keys(), "providers"})


__all__ = [
    "ApprovalContract",
    "AuthContract",
    "AuthMode",
    "AuthResolution",
    "CliRunRequest",
    "CliRunResult",
    "CodexExecSpec",
    "ChoiceSpec",
    "ClaudeReasoningPolicy",
    "CliLaunchSpec",
    "ControlSpec",
    "DiagnosticsContract",
    "ErrorCode",
    "FailureClassification",
    "HeadlessContract",
    "IoContract",
    "ModelSpec",
    "OutputContract",
    "PathContract",
    "PromptPayload",
    "PromptTransport",
    "ProviderContract",
    "ProviderSpec",
    "SandboxContract",
    "SchemaValidationError",
    "SessionDiscoveryContract",
    "WorkspaceEnvVar",
    "WorkspaceEnvValueSource",
    "CANONICAL_TRANSCRIPT_INPUTS",
    "InteractiveCliRunResult",
    "SessionProgressEvent",
    "SessionRetryDecision",
    "SessionExecutionTimeoutError",
    "EMPTY_TRANSCRIPT_FACTS_V1",
    "HUMAN_READABLE_TRANSCRIPT_SIDECARS",
    "TranscriptMirrorStrategy",
    "TranscriptFactsError",
    "TranscriptFactsV1",
    "build_claude_headless_core",
    "build_codex_exec_spec",
    "build_codex_headless_core",
    "build_copilot_headless_core",
    "build_env_overlay",
    "build_gemini_headless_core",
    "get_claude_default_model",
    "get_claude_effort_levels",
    "get_claude_model_candidates",
    "get_claude_output_suffixes",
    "get_claude_permission_modes",
    "get_codex_supported_models",
    "get_copilot_default_model",
    "get_copilot_model_catalog",
    "get_copilot_stream_choices",
    "get_gemini_default_model",
    "get_gemini_model_options",
    "get_provider_contract",
    "get_provider_spec",
    "is_provider_installed",
    "list_provider_ids",
    "list_provider_specs",
    "build_model_id",
    "ControlDefaultSource",
    "classify_provider_failure",
    "load_schema",
    "ProviderControlResolution",
    "render_prompt",
    "resolve_auth",
    "resolve_claude_reasoning_policy",
    "resolve_config_paths",
    "resolve_provider_model_control_resolution",
    "resolve_provider_model_controls",
    "resolve_session_search_paths",
    "resolve_workspace_env",
    "redact_text",
    "derive_transcript_facts",
    "claude_project_key",
    "find_claude_session",
    "find_codex_session",
    "normalize_path_str",
    "mirror_session_transcript",
    "run_cli_command",
    "run_cli_command_sync",
    "run_interactive_session",
    "serialize_provider_specs",
    "UnsupportedControlMode",
    "validate_payload",
]
