"""Reusable Codex CLI launch helpers."""

from __future__ import annotations

import json
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .provider_controls import (
    ProviderControlResolution,
    UnsupportedControlMode,
    resolve_provider_model_control_resolution,
)


@dataclass(frozen=True)
class CodexExecSpec:
    cmd_parts: tuple[str, ...]
    display_text: str
    applied_controls: dict[str, Any]
    effective_reasoning: str
    control_resolution: ProviderControlResolution


def _resolve_codex_reasoning(
    *,
    model_reasoning: str | None = None,
    model_controls: dict[str, Any] | None = None,
    unsupported_control_mode: UnsupportedControlMode | str | None = None,
) -> tuple[ProviderControlResolution, dict[str, Any], str]:
    controls = resolve_provider_model_control_resolution(
        provider="codex",
        model_reasoning=model_reasoning,
        model_controls=model_controls,
        unsupported_control_mode=unsupported_control_mode,
    )
    applied_controls = dict(controls.applied)
    effective_reasoning_raw = applied_controls.get("reasoning_effort")
    if isinstance(effective_reasoning_raw, str) and effective_reasoning_raw.strip():
        return controls, applied_controls, effective_reasoning_raw
    if isinstance(model_reasoning, str) and model_reasoning.strip():
        return controls, applied_controls, model_reasoning
    raise ValueError("Codex launch requires a reasoning effort")


def build_codex_exec_spec(
    *,
    codex_bin: str,
    model: str,
    cwd: Path,
    output_schema_path: Path | None,
    output_path: Path,
    resume_session_id: str | None = None,
    model_reasoning: str | None = None,
    model_controls: dict[str, Any] | None = None,
    json_output: bool,
    sandbox: str,
    full_auto: bool = True,
    skip_git_repo_check: bool = True,
    extra_args: tuple[str, ...] | list[str] | None = None,
    stdin_placeholder: str | None = "<prompt>",
    unsupported_control_mode: UnsupportedControlMode | str | None = None,
) -> CodexExecSpec:
    control_resolution, applied_controls, effective_reasoning = _resolve_codex_reasoning(
        model_reasoning=model_reasoning,
        model_controls=model_controls,
        unsupported_control_mode=unsupported_control_mode,
    )
    reasoning_config_value = json.dumps(effective_reasoning)
    cmd_parts: list[str] = [str(codex_bin), "exec"]
    if resume_session_id is not None:
        cmd_parts.append("resume")
    if resume_session_id is None:
        from .headless import build_codex_headless_core

        cmd_parts = build_codex_headless_core(
            model,
            binary=str(codex_bin),
            sandbox_mode=sandbox if sandbox else None,
            full_auto=full_auto,
            skip_git_repo_check=skip_git_repo_check,
        )
    else:
        if sandbox == "danger-full-access":
            cmd_parts.append("--dangerously-bypass-approvals-and-sandbox")
        elif sandbox != "read-only" and full_auto:
            cmd_parts.append("--full-auto")
        if skip_git_repo_check:
            cmd_parts.append("--skip-git-repo-check")
        cmd_parts.extend(["--model", model])
    if json_output:
        cmd_parts.append("--json")
    cmd_parts.extend(["--config", f"model_reasoning_effort={reasoning_config_value}"])
    if resume_session_id is None:
        cmd_parts.extend(["-C", str(cwd)])
    cmd_parts.extend(["-o", str(output_path)])
    if output_schema_path is not None:
        cmd_parts.extend(["--output-schema", str(output_schema_path)])
    if extra_args:
        cmd_parts.extend([str(part) for part in extra_args])
    if resume_session_id is not None:
        cmd_parts.extend([resume_session_id, "-"])
    display_parts = [shlex.quote(part) for part in cmd_parts]
    if stdin_placeholder is not None:
        display_parts.append(stdin_placeholder)
    return CodexExecSpec(
        cmd_parts=tuple(cmd_parts),
        display_text=" ".join(display_parts),
        applied_controls=applied_controls,
        effective_reasoning=effective_reasoning,
        control_resolution=control_resolution,
    )
