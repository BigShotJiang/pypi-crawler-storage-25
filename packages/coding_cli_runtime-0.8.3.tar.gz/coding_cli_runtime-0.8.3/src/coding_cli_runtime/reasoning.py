"""Reasoning control policy helpers shared across Claude callers."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import ClaudeReasoningPolicy


@dataclass(frozen=True)
class _ClaudeReasoningCapability:
    effort_levels: tuple[str, ...] = ()
    legacy_thinking_tokens_supported: bool = True


_CLAUDE_REASONING_CAPABILITIES: tuple[tuple[str, _ClaudeReasoningCapability], ...] = (
    (
        "claude-sonnet-4-6",
        _ClaudeReasoningCapability(
            effort_levels=("low", "medium", "high", "max"),
            legacy_thinking_tokens_supported=True,
        ),
    ),
    (
        "claude-opus-4-6",
        _ClaudeReasoningCapability(
            effort_levels=("low", "medium", "high", "max"),
            legacy_thinking_tokens_supported=True,
        ),
    ),
    (
        "claude-opus-4-7",
        _ClaudeReasoningCapability(
            effort_levels=("low", "medium", "high", "xhigh", "max"),
            legacy_thinking_tokens_supported=False,
        ),
    ),
)
CLAUDE_ADAPTIVE_THINKING_MODELS: tuple[str, ...] = tuple(
    model_name
    for model_name, capability in _CLAUDE_REASONING_CAPABILITIES
    if capability.effort_levels
)
CLAUDE_EFFORT_CHOICES: tuple[str, ...] = ("low", "medium", "high", "xhigh", "max")
CLAUDE_DEFAULT_THINKING_TOKENS = 8192


def _resolve_claude_reasoning_capability(model: str | None) -> _ClaudeReasoningCapability:
    normalized = (model or "").strip().lower()
    if not normalized:
        return _ClaudeReasoningCapability()
    for model_prefix, capability in _CLAUDE_REASONING_CAPABILITIES:
        if normalized.startswith(model_prefix):
            return capability
    return _ClaudeReasoningCapability()


def get_claude_effort_levels_for_model(model: str | None) -> tuple[str, ...]:
    return _resolve_claude_reasoning_capability(model).effort_levels


def claude_supports_legacy_thinking_tokens(model: str | None) -> bool:
    return _resolve_claude_reasoning_capability(model).legacy_thinking_tokens_supported


def _normalize_claude_effort(value: str | None, *, model: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    allowed_levels = get_claude_effort_levels_for_model(model) or CLAUDE_EFFORT_CHOICES
    if normalized in allowed_levels:
        return normalized
    return None


def _uses_claude_adaptive_thinking_model(model: str | None) -> bool:
    return bool(get_claude_effort_levels_for_model(model))


def resolve_claude_reasoning_policy(
    *,
    model: str | None,
    thinking_tokens: int | None,
    effort: str | None,
) -> ClaudeReasoningPolicy:
    normalized_tokens: int | None = None
    if isinstance(thinking_tokens, int):
        normalized_tokens = max(int(thinking_tokens), 0)
    normalized_effort = _normalize_claude_effort(effort, model=model)
    adaptive_model = _uses_claude_adaptive_thinking_model(model)
    allowed_efforts = get_claude_effort_levels_for_model(model)
    explicit_effort = isinstance(effort, str) and bool(effort.strip())
    if explicit_effort:
        if not adaptive_model:
            raise ValueError(f"Claude model '{model}' does not support --effort.")
        if normalized_effort is None:
            supported = ", ".join(allowed_efforts)
            raise ValueError(
                f"Claude model '{model}' only supports effort levels: {supported}. "
                f"Received '{effort}'."
            )

    if adaptive_model:
        if normalized_effort:
            # --effort explicitly set: use it, ignore thinking tokens.
            return ClaudeReasoningPolicy(
                mode="effort",
                effective_effort=normalized_effort,
                effort_source="flag",
                thinking_tokens=None,
            )
        if normalized_tokens is None:
            # Neither --effort nor --thinking-tokens: let Claude Code
            # handle its own defaults.
            return ClaudeReasoningPolicy(
                mode="none",
                effective_effort=None,
                effort_source=None,
                thinking_tokens=None,
            )
        if not claude_supports_legacy_thinking_tokens(model):
            raise ValueError(
                f"Claude model '{model}' does not support fixed thinking token budgets; "
                "use --effort instead."
            )
        if normalized_tokens <= 0:
            return ClaudeReasoningPolicy(
                mode="disabled",
                effective_effort=None,
                effort_source="thinking_tokens<=0",
                thinking_tokens=0,
                disable_via_env_setting=True,
            )
        # --thinking-tokens passed without --effort: respect the explicit
        # token budget and pass it through to the CLI as-is.
        return ClaudeReasoningPolicy(
            mode="legacy_tokens",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=normalized_tokens,
        )

    if explicit_effort:
        raise ValueError(f"Claude model '{model}' does not support --effort.")
    if normalized_tokens is None:
        return ClaudeReasoningPolicy(
            mode="none",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=None,
        )
    if normalized_tokens > 0:
        return ClaudeReasoningPolicy(
            mode="legacy_tokens",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=normalized_tokens,
        )
    return ClaudeReasoningPolicy(
        mode="disabled",
        effective_effort=None,
        effort_source="thinking_tokens<=0",
        thinking_tokens=0,
        disable_via_env_setting=False,
    )
