"""Structured provider contract metadata and composable helpers.

This module is the authoritative source for provider identity, auth env vars,
config paths, and headless launch conventions. It exposes frozen dataclasses
that consumers can read selectively — no obligation to use the full structure.

Public stable API:
    get_provider_contract, build_env_overlay, resolve_config_paths, render_prompt,
    resolve_workspace_env, resolve_session_search_paths, is_provider_installed

Internal (not exported from __init__):
    _build_non_interactive_run
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, TypeAlias

from .contracts import AuthMode

# ---------------------------------------------------------------------------
# Sub-contract types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AuthContract:
    """How a provider authenticates."""

    api_key_env_var: str | None
    byok_api_key_env_var: str | None
    base_url_env_var: str | None
    supported_modes: tuple[AuthMode, ...]
    default_mode: AuthMode


@dataclass(frozen=True)
class PathContract:
    """Where a provider stores config on disk."""

    config_dir: str
    container_config_dir: str


@dataclass(frozen=True)
class PromptTransport:
    """How the prompt reaches the CLI process.

    ``delivery`` is the preferred launch convention:
    - ``"stdin"``: prompt on stdin, no prompt-related argv.
    - ``"flag"``: prompt passed via a command-line flag (e.g. ``-p``).
    - ``"stdin_with_activation"``: activation args enter headless mode,
      real prompt on stdin (Gemini: ``--prompt ""``).

    ``flag`` records the flag name even when ``delivery`` is ``"stdin"``
    so callers who prefer argv delivery can use it directly.
    """

    delivery: str
    flag: str | None
    activation_args: tuple[str, ...]


@dataclass(frozen=True)
class PromptPayload:
    """Resolved prompt delivery: what goes in argv vs stdin."""

    args: tuple[str, ...]
    stdin_text: str | None


@dataclass(frozen=True)
class ApprovalContract:
    """How write access / tool approval works."""

    flag: str | None
    permission_mode_flag: str | None
    permission_modes: tuple[str, ...]
    default_permission_mode: str | None


@dataclass(frozen=True)
class SandboxContract:
    """How sandboxing works (Codex-specific)."""

    flag: str
    modes: tuple[str, ...]
    writable_mode: str
    read_only_mode: str


@dataclass(frozen=True)
class HeadlessContract:
    """Everything needed to run a provider CLI non-interactively."""

    activation_args: tuple[str, ...]
    prompt: PromptTransport
    approval: ApprovalContract
    sandbox: SandboxContract | None
    noninteractive_mode_flag: str | None
    requires_git_repo: bool
    skip_git_repo_flag: str | None
    stream_flag: str | None
    stream_modes: tuple[str, ...] | None
    default_stream_mode: str | None


@dataclass(frozen=True)
class OutputContract:
    """How the CLI delivers structured output."""

    format_flag: str | None
    supported_formats: tuple[str, ...]
    default_format: str | None
    output_path_flag: str | None
    schema_path_flag: str | None


WorkspaceEnvValueSource: TypeAlias = Literal["execution_dir", "workspace_root"]


@dataclass(frozen=True)
class WorkspaceEnvVar:
    """An environment variable expected by the provider CLI."""

    name: str
    value_source: WorkspaceEnvValueSource


@dataclass(frozen=True)
class IoContract:
    """Provider-specific I/O conventions beyond prompt transport."""

    file_reference_prefix: str | None
    # Whether the CLI can consume prompt-associated images directly from path references
    # without additional repo-authored wrapper prose.
    supports_prompt_image_references: bool
    workspace_env_vars: tuple[WorkspaceEnvVar, ...]


@dataclass(frozen=True)
class SessionDiscoveryContract:
    """Where session logs live and how to find them."""

    session_roots: tuple[str, ...]
    session_glob: str


@dataclass(frozen=True)
class DiagnosticsContract:
    """Where provider diagnostic logs live."""

    log_glob: str


@dataclass(frozen=True)
class ProviderContract:
    """Structured metadata about a provider CLI.

    Composed of focused sub-contracts. Consumers drill into whichever
    sub-contract they need. This is reference data, not a control plane.
    """

    provider_id: str
    binary: str
    auth: AuthContract
    paths: PathContract
    headless: HeadlessContract
    output: OutputContract
    io: IoContract
    session_discovery: SessionDiscoveryContract | None
    diagnostics: DiagnosticsContract | None
    notes: tuple[str, ...]


# ---------------------------------------------------------------------------
# NonInteractiveRunSpec (used by the private builder)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NonInteractiveRunSpec:
    """Ready-to-use spec for a non-interactive CLI invocation."""

    cmd_parts: tuple[str, ...]
    env_overlay: dict[str, str]
    stdin_text: str | None
    host_config_dir: str
    container_config_dir: str
    preconditions: tuple[str, ...]


# ---------------------------------------------------------------------------
# Per-provider contract data
# ---------------------------------------------------------------------------

_CLAUDE_CONTRACT = ProviderContract(
    provider_id="claude",
    binary="claude",
    auth=AuthContract(
        api_key_env_var="CLAUDE_API_KEY",
        byok_api_key_env_var=None,
        base_url_env_var="ANTHROPIC_BASE_URL",
        supported_modes=(AuthMode.CLI_LOGIN, AuthMode.ENV),
        default_mode=AuthMode.CLI_LOGIN,
    ),
    paths=PathContract(
        config_dir="~/.claude",
        container_config_dir="/root/.claude",
    ),
    headless=HeadlessContract(
        activation_args=("--print",),
        prompt=PromptTransport(delivery="stdin", flag="-p", activation_args=()),
        approval=ApprovalContract(
            flag="--dangerously-skip-permissions",
            permission_mode_flag="--permission-mode",
            permission_modes=(
                "bypassPermissions",
                "acceptEdits",
                "default",
                "plan",
            ),
            default_permission_mode="bypassPermissions",
        ),
        sandbox=None,
        noninteractive_mode_flag=None,
        requires_git_repo=False,
        skip_git_repo_flag=None,
        stream_flag=None,
        stream_modes=None,
        default_stream_mode=None,
    ),
    output=OutputContract(
        format_flag="--output-format",
        supported_formats=("text", "json", "stream-json"),
        default_format="text",
        output_path_flag=None,
        schema_path_flag=None,
    ),
    io=IoContract(
        file_reference_prefix="@",
        supports_prompt_image_references=False,
        workspace_env_vars=(),
    ),
    session_discovery=SessionDiscoveryContract(
        session_roots=("projects",),
        session_glob="*/conversation.jsonl",
    ),
    diagnostics=None,
    notes=("File references in prompts use @filename syntax.",),
)

_CODEX_CONTRACT = ProviderContract(
    provider_id="codex",
    binary="codex",
    auth=AuthContract(
        api_key_env_var="OPENAI_API_KEY",
        byok_api_key_env_var=None,
        base_url_env_var="OPENAI_BASE_URL",
        supported_modes=(AuthMode.CLI_LOGIN, AuthMode.ENV),
        default_mode=AuthMode.CLI_LOGIN,
    ),
    paths=PathContract(
        config_dir="~/.codex",
        container_config_dir="/root/.codex",
    ),
    headless=HeadlessContract(
        activation_args=("exec",),
        prompt=PromptTransport(delivery="stdin", flag=None, activation_args=()),
        approval=ApprovalContract(
            flag=None,
            permission_mode_flag=None,
            permission_modes=(),
            default_permission_mode=None,
        ),
        sandbox=SandboxContract(
            flag="--sandbox",
            modes=("danger-full-access", "read-only"),
            writable_mode="danger-full-access",
            read_only_mode="read-only",
        ),
        noninteractive_mode_flag="--full-auto",
        requires_git_repo=True,
        skip_git_repo_flag="--skip-git-repo-check",
        stream_flag=None,
        stream_modes=None,
        default_stream_mode=None,
    ),
    output=OutputContract(
        format_flag=None,
        supported_formats=("json",),
        default_format="json",
        output_path_flag="-o",
        schema_path_flag="--output-schema",
    ),
    io=IoContract(
        file_reference_prefix=None,
        supports_prompt_image_references=False,
        workspace_env_vars=(),
    ),
    session_discovery=SessionDiscoveryContract(
        session_roots=("sessions", "archived_sessions"),
        session_glob="*.jsonl",
    ),
    diagnostics=None,
    notes=(
        "codex exec defaults to a read-only sandbox in non-interactive mode; "
        "use --sandbox danger-full-access for write access.",
        "Prompt-associated @file references are not yet enabled in coding_cli_runtime.",
    ),
)

_GEMINI_CONTRACT = ProviderContract(
    provider_id="gemini",
    binary="gemini",
    auth=AuthContract(
        api_key_env_var="GEMINI_API_KEY",
        byok_api_key_env_var=None,
        base_url_env_var="GOOGLE_GEMINI_BASE_URL",
        supported_modes=(AuthMode.CLI_LOGIN, AuthMode.ENV),
        default_mode=AuthMode.CLI_LOGIN,
    ),
    paths=PathContract(
        config_dir="~/.gemini",
        container_config_dir="/root/.gemini",
    ),
    headless=HeadlessContract(
        activation_args=(),
        prompt=PromptTransport(
            delivery="stdin_with_activation",
            flag=None,
            activation_args=("--prompt", ""),
        ),
        approval=ApprovalContract(
            flag="--yolo",
            permission_mode_flag=None,
            permission_modes=(),
            default_permission_mode=None,
        ),
        sandbox=None,
        noninteractive_mode_flag=None,
        requires_git_repo=False,
        skip_git_repo_flag=None,
        stream_flag=None,
        stream_modes=None,
        default_stream_mode=None,
    ),
    output=OutputContract(
        format_flag=None,
        supported_formats=(),
        default_format=None,
        output_path_flag=None,
        schema_path_flag=None,
    ),
    io=IoContract(
        file_reference_prefix="@",
        supports_prompt_image_references=True,
        workspace_env_vars=(
            WorkspaceEnvVar(
                name="GEMINI_CLI_IDE_WORKSPACE_PATH",
                value_source="execution_dir",
            ),
        ),
    ),
    session_discovery=SessionDiscoveryContract(
        session_roots=("tmp",),
        session_glob="*/chats/session-*.json",
    ),
    diagnostics=None,
    notes=(
        'Gemini requires --prompt "" to activate headless mode; '
        "the real prompt is delivered on stdin.",
        "Gemini output format is prompt-directed, not CLI-flag-driven.",
        "File references in prompts use @filename syntax.",
    ),
)

_COPILOT_CONTRACT = ProviderContract(
    provider_id="copilot",
    binary="copilot",
    auth=AuthContract(
        api_key_env_var=None,
        byok_api_key_env_var="COPILOT_PROVIDER_API_KEY",
        base_url_env_var="COPILOT_PROVIDER_BASE_URL",
        supported_modes=(AuthMode.CLI_LOGIN, AuthMode.ENV),
        default_mode=AuthMode.CLI_LOGIN,
    ),
    paths=PathContract(
        config_dir="~/.copilot",
        container_config_dir="/root/.copilot",
    ),
    headless=HeadlessContract(
        activation_args=("--no-ask-user", "--no-custom-instructions"),
        prompt=PromptTransport(delivery="flag", flag="-p", activation_args=()),
        approval=ApprovalContract(
            flag="--allow-all",
            permission_mode_flag=None,
            permission_modes=(),
            default_permission_mode=None,
        ),
        sandbox=None,
        noninteractive_mode_flag=None,
        requires_git_repo=False,
        skip_git_repo_flag=None,
        stream_flag="--stream",
        stream_modes=("on", "off"),
        default_stream_mode="on",
    ),
    output=OutputContract(
        format_flag=None,
        supported_formats=(),
        default_format=None,
        output_path_flag=None,
        schema_path_flag=None,
    ),
    io=IoContract(
        file_reference_prefix="@",
        supports_prompt_image_references=False,
        workspace_env_vars=(),
    ),
    session_discovery=SessionDiscoveryContract(
        session_roots=("session-state",),
        session_glob="*/events.jsonl",
    ),
    diagnostics=DiagnosticsContract(
        log_glob="logs/process-*.log",
    ),
    notes=(
        "Copilot default auth is CLI login (api_key_env_var is None). "
        "BYOK is available via COPILOT_PROVIDER_API_KEY.",
        "File references in prompts use @filename syntax.",
    ),
)

_CONTRACTS: dict[str, ProviderContract] = {
    "claude": _CLAUDE_CONTRACT,
    "codex": _CODEX_CONTRACT,
    "gemini": _GEMINI_CONTRACT,
    "copilot": _COPILOT_CONTRACT,
}


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------


def list_provider_ids() -> list[str]:
    """Return the list of supported provider IDs."""
    return list(_CONTRACTS.keys())


def get_provider_contract(provider_id: str) -> ProviderContract:
    """Return structured contract metadata for a provider.

    Raises ``ValueError`` for unknown provider IDs.
    """
    key = provider_id.strip().lower()
    contract = _CONTRACTS.get(key)
    if contract is None:
        raise ValueError(
            f"Unknown provider: {provider_id!r}. Supported: {', '.join(sorted(_CONTRACTS))}"
        )
    return contract


def build_env_overlay(
    contract: ProviderContract,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
) -> dict[str, str]:
    """Build provider-specific env var overlay from contract metadata.

    Returns a dict to merge with ``os.environ``. Only includes vars that
    have a non-None value. Callers must do
    ``{**os.environ, **overlay}`` before passing to subprocess.
    """
    overlay: dict[str, str] = {}
    if api_key is not None:
        env_var = contract.auth.api_key_env_var or contract.auth.byok_api_key_env_var
        if env_var is not None:
            overlay[env_var] = api_key
    if base_url is not None and contract.auth.base_url_env_var is not None:
        overlay[contract.auth.base_url_env_var] = base_url
    return overlay


def resolve_workspace_env(
    contract: ProviderContract,
    execution_dir: str | Path,
    *,
    workspace_root: str | Path | None = None,
) -> dict[str, str]:
    """Resolve provider workspace env vars from contract metadata."""
    resolved: dict[str, str] = {}
    execution_dir_str = str(Path(execution_dir).expanduser())
    workspace_root_str = None
    if workspace_root is not None:
        workspace_root_str = str(Path(workspace_root).expanduser())

    for item in contract.io.workspace_env_vars:
        if item.value_source == "execution_dir":
            resolved[item.name] = execution_dir_str
            continue
        if item.value_source == "workspace_root":
            if workspace_root_str is None:
                raise ValueError(f"{item.name} requires workspace_root, but none was provided")
            resolved[item.name] = workspace_root_str
            continue
        raise ValueError(f"Unknown workspace env value source: {item.value_source!r}")

    return resolved


def resolve_config_paths(
    contract: ProviderContract,
    *,
    containerized: bool = False,
) -> tuple[str, str]:
    """Return ``(host_config_dir, effective_config_dir)`` from contract.

    When ``containerized=True``, effective is the container path.
    When ``containerized=False``, effective is the host path (expanded).
    """
    host = str(Path(contract.paths.config_dir).expanduser())
    if containerized:
        return host, contract.paths.container_config_dir
    return host, host


def resolve_session_search_paths(
    contract: ProviderContract,
    *,
    config_dir: str | Path | None = None,
) -> tuple[Path, ...]:
    """Expand contract session roots into concrete host paths."""
    discovery = contract.session_discovery
    if discovery is None:
        return ()
    base_dir = (
        Path(config_dir).expanduser()
        if config_dir is not None
        else Path(contract.paths.config_dir).expanduser()
    )
    return tuple(base_dir / root for root in discovery.session_roots)


def render_prompt(
    transport: PromptTransport,
    prompt: str,
) -> PromptPayload:
    """Resolve prompt delivery into args + stdin_text.

    - ``delivery="flag"``: args=(flag, prompt), stdin_text=None
    - ``delivery="stdin"``: args=(), stdin_text=prompt
    - ``delivery="stdin_with_activation"``: args=activation_args, stdin_text=prompt
    """
    if transport.delivery == "flag":
        if transport.flag is None:
            raise ValueError("PromptTransport delivery='flag' but flag is None")
        return PromptPayload(args=(transport.flag, prompt), stdin_text=None)
    if transport.delivery == "stdin":
        return PromptPayload(args=(), stdin_text=prompt)
    if transport.delivery == "stdin_with_activation":
        return PromptPayload(args=transport.activation_args, stdin_text=prompt)
    raise ValueError(f"Unknown prompt delivery mode: {transport.delivery!r}")


def is_provider_installed(provider_id: str) -> bool:
    """Return whether the provider CLI binary is available on PATH."""
    contract = get_provider_contract(provider_id)
    return shutil.which(contract.binary) is not None


# ---------------------------------------------------------------------------
# Private builder (internal convenience, not public API)
# ---------------------------------------------------------------------------


def _build_non_interactive_run(
    provider_id: str,
    *,
    model: str,
    prompt: str,
    binary: str | None = None,
    codex_sandbox_mode: str | None = None,
    containerized: bool = False,
    api_key: str | None = None,
    base_url: str | None = None,
    permission_mode: str | None = None,
    stream: str | None = None,
    extra_flags: tuple[str, ...] = (),
) -> NonInteractiveRunSpec:
    """Build a non-interactive CLI run spec. Internal convenience.

    Delegates headless core arg assembly to ``headless.build_*_headless_core()``
    helpers, which derive flags from ``ProviderContract.headless``.
    """
    from .headless import (
        build_claude_headless_core,
        build_codex_headless_core,
        build_copilot_headless_core,
        build_gemini_headless_core,
    )

    contract = get_provider_contract(provider_id)
    h = contract.headless

    # Registry-based dispatch to per-provider headless core builders
    _HEADLESS_BUILDERS: dict[str, Any] = {
        "claude": lambda: build_claude_headless_core(
            model, binary=binary, permission_mode=permission_mode, contract=contract
        ),
        "codex": lambda: build_codex_headless_core(
            model, binary=binary, sandbox_mode=codex_sandbox_mode, contract=contract
        ),
        "copilot": lambda: build_copilot_headless_core(
            model, binary=binary, stream=stream, contract=contract
        ),
        "gemini": lambda: build_gemini_headless_core(model, binary=binary, contract=contract),
    }

    key = provider_id.strip().lower()
    builder = _HEADLESS_BUILDERS.get(key)
    if builder is not None:
        cmd = builder()
    else:
        # Fallback for unknown providers — generic assembly
        bin_name = binary or contract.binary
        cmd = [bin_name, *h.activation_args]
        if h.noninteractive_mode_flag:
            cmd.append(h.noninteractive_mode_flag)
        if h.sandbox is not None:
            mode = codex_sandbox_mode or h.sandbox.writable_mode
            cmd.extend([h.sandbox.flag, mode])
        if h.requires_git_repo and h.skip_git_repo_flag:
            cmd.append(h.skip_git_repo_flag)
        if h.approval.flag:
            cmd.append(h.approval.flag)
        if h.approval.permission_mode_flag:
            mode_value = permission_mode or h.approval.default_permission_mode
            if mode_value:
                cmd.extend([h.approval.permission_mode_flag, mode_value])
        cmd.extend(["--model", model])
        if h.stream_flag:
            stream_value = stream or h.default_stream_mode
            if stream_value:
                cmd.extend([h.stream_flag, stream_value])

    # Prompt
    payload = render_prompt(h.prompt, prompt)
    cmd.extend(payload.args)

    # Extra flags
    cmd.extend(extra_flags)

    # Env overlay
    env_overlay = build_env_overlay(contract, api_key=api_key, base_url=base_url)

    # Config paths
    host_dir, effective_dir = resolve_config_paths(contract, containerized=containerized)

    # Preconditions
    preconditions: list[str] = []
    if h.requires_git_repo:
        preconditions.append("Codex requires a git repo; --skip-git-repo-check is included.")

    return NonInteractiveRunSpec(
        cmd_parts=tuple(cmd),
        env_overlay=env_overlay,
        stdin_text=payload.stdin_text,
        host_config_dir=host_dir,
        container_config_dir=contract.paths.container_config_dir,
        preconditions=tuple(preconditions),
    )
