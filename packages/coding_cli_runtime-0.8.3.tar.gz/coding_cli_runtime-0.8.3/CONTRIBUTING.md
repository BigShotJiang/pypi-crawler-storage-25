# Contributing to coding-cli-runtime

## Development setup

```bash
cd packages/coding-cli-runtime

# Install dependencies with uv (recommended)
uv sync --group dev

# Or use pip
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Quality checks

```bash
# Run all checks (same as CI)
uv run --project . --group dev python -m ruff check src tests
uv run --project . --group dev python -m ruff format --check src tests
uv run --project . --group dev python -m mypy src
uv run --project . --group dev python -m pytest --cov=coding_cli_runtime --cov-report=term --cov-fail-under=72

# Pre-commit (if installed)
uv run --project . --group dev pre-commit run --all-files

# Build and validate
uv run --project . --group dev python -m build --no-isolation --sdist --wheel
uv run --project . --group dev python -m twine check dist/*
```

The package coverage gate is intentionally set to `72%`. The least-covered
modules are the process/session substrate (`subprocess_runner.py`,
`session_execution.py`) where confidence comes more from focused adapter tests,
real-CLI smoke coverage, and downstream consumer regressions than from forcing
synthetic line coverage on TTY/process-group behavior.

Authenticated real-CLI continuation smoke coverage is available as an opt-in
test slice. Run it from the `packages/coding-cli-runtime` directory:

```bash
CKRT_RUN_REAL_CLI_E2E=1 uv run --project . --group dev python -m pytest \
  tests/test_real_cli_continuation_e2e.py -q
```

Those tests are intentionally out of the default suite because they require
local CLI auth/quota and exercise the live provider binaries.

## Pull request process

1. Run all quality checks locally before pushing.
2. Update `CHANGELOG.md` under `[Unreleased]` for any user-visible changes.
3. CI enforces the same checks — PRs must pass before merge.
