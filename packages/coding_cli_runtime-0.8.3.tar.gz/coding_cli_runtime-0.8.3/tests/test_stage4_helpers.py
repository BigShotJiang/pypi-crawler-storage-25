"""Tests for consumer-UX helpers."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from coding_cli_runtime import (
    IoContract,
    WorkspaceEnvVar,
    get_provider_contract,
    is_provider_installed,
    resolve_session_search_paths,
    resolve_workspace_env,
)
from coding_cli_runtime import provider_contracts as provider_contracts_mod
from coding_cli_runtime.providers._common import materialize_prefixed_references


class TestResolveWorkspaceEnv:
    def test_gemini_workspace_env_uses_execution_dir(self) -> None:
        contract = get_provider_contract("gemini")

        env = resolve_workspace_env(contract, "/tmp/run-dir")

        assert env == {"GEMINI_CLI_IDE_WORKSPACE_PATH": "/tmp/run-dir"}

    def test_provider_with_no_workspace_env_vars_returns_empty_dict(self) -> None:
        contract = get_provider_contract("claude")

        env = resolve_workspace_env(contract, "/tmp/run-dir")

        assert env == {}

    def test_workspace_root_value_source_requires_workspace_root(self) -> None:
        base = get_provider_contract("claude")
        contract = replace(
            base,
            io=IoContract(
                file_reference_prefix=None,
                supports_prompt_image_references=False,
                workspace_env_vars=(
                    WorkspaceEnvVar(
                        name="TEST_WORKSPACE_ROOT",
                        value_source="workspace_root",
                    ),
                ),
            ),
        )

        with pytest.raises(ValueError, match="requires workspace_root"):
            resolve_workspace_env(contract, "/tmp/execution-dir")

        env = resolve_workspace_env(
            contract,
            "/tmp/execution-dir",
            workspace_root="/tmp/workspace-root",
        )
        assert env == {"TEST_WORKSPACE_ROOT": "/tmp/workspace-root"}


class TestResolveSessionSearchPaths:
    def test_gemini_defaults_to_config_dir_tmp_root(self) -> None:
        contract = get_provider_contract("gemini")

        paths = resolve_session_search_paths(contract)

        assert paths == (Path("~/.gemini").expanduser() / "tmp",)

    def test_defaults_to_contract_config_dir(self) -> None:
        contract = get_provider_contract("claude")

        paths = resolve_session_search_paths(contract)

        assert paths == (Path("~/.claude").expanduser() / "projects",)

    def test_honors_config_dir_override(self) -> None:
        contract = get_provider_contract("codex")

        paths = resolve_session_search_paths(contract, config_dir="/tmp/codex-config")

        assert paths == (
            Path("/tmp/codex-config") / "sessions",
            Path("/tmp/codex-config") / "archived_sessions",
        )

    def test_returns_empty_tuple_when_session_discovery_is_none(self) -> None:
        base = get_provider_contract("copilot")
        contract = replace(base, session_discovery=None)

        paths = resolve_session_search_paths(contract)

        assert paths == ()


class TestMaterializePrefixedReferences:
    def test_reference_only_inputs_do_not_gain_leading_blank_lines(self) -> None:
        rendered = materialize_prefixed_references(
            "",
            (Path("_inputs/spec.pdf"),),
            prefix="@",
        )

        assert rendered == "@_inputs/spec.pdf\n"


class TestIsProviderInstalled:
    def test_returns_true_when_binary_is_found(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(provider_contracts_mod.shutil, "which", lambda _: "/usr/bin/claude")

        assert is_provider_installed("claude") is True

    def test_returns_false_when_binary_is_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(provider_contracts_mod.shutil, "which", lambda _: None)

        assert is_provider_installed("copilot") is False
