from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

_RUN_REAL_CLI_E2E = os.getenv("CKRT_RUN_REAL_CLI_E2E") == "1"
pytestmark = pytest.mark.skipif(
    not _RUN_REAL_CLI_E2E,
    reason="set CKRT_RUN_REAL_CLI_E2E=1 to run authenticated real transcript-probe e2e tests",
)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def test_real_transcript_probe_manifest_round_trips_for_all_providers(tmp_path: Path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "transcript-probes"
        / "run_probe.py"
    )
    output_dir = tmp_path / "probe-output"

    completed = subprocess.run(
        [sys.executable, str(script_path), "--output-dir", str(output_dir)],
        cwd=repo_root,
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr

    manifest_path = output_dir / "manifest.json"
    report_path = output_dir / "run_report.md"
    assert manifest_path.exists()
    assert report_path.exists()

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["providers_requested"] == ["claude", "codex", "gemini", "copilot"]

    entries = {entry["provider"]: entry for entry in manifest["results"]}
    assert set(entries) == {"claude", "codex", "gemini", "copilot"}

    for provider, entry in entries.items():
        assert entry["status"] == "ok", (provider, entry.get("error"))
        assert entry["observed_cli_version"]
        transcript_path = output_dir / entry["transcript_path"]
        stdout_path = output_dir / entry["stdout_path"]
        stderr_path = output_dir / entry["stderr_path"]
        facts_path = output_dir / entry["facts_path"]
        assert transcript_path.exists(), provider
        assert stdout_path.exists(), provider
        assert stderr_path.exists(), provider
        assert facts_path.exists(), provider
        assert entry["facts"] is not None
        assert entry["facts"]["assistant_messages"] >= 1

    copilot_entry = entries["copilot"]
    assert copilot_entry["parsed_output_source"] == "stdout"
