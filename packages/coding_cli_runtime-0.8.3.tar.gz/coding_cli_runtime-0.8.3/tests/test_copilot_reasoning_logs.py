from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from coding_cli_runtime.copilot_reasoning_logs import (
    classify_reasoning_fields,
    extract_default_reasoning,
    extract_final_request_options,
    extract_session_id,
    find_process_log_for_session,
    find_recent_session_for_workdir,
)


def test_extract_session_id() -> None:
    markdown = "# Share Export\n\n**Session ID:** `session-123`\n"

    assert extract_session_id(markdown) == "session-123"
    assert extract_session_id("missing") is None


def test_extract_final_request_options_parses_nested_json_block() -> None:
    log_text = """
prefix text
Final request options: {"reasoning_effort":"medium","nested":{"label":"{kept}"}}
suffix text
"""

    assert extract_final_request_options(log_text) == {
        "reasoning_effort": "medium",
        "nested": {"label": "{kept}"},
    }


def test_extract_final_request_options_rejects_non_object_payload() -> None:
    log_text = "Final request options: [1, 2, 3]"

    assert extract_final_request_options(log_text) == {}


def test_extract_final_request_options_falls_back_to_model_resolution_telemetry() -> None:
    log_text = """
2026-04-22T16:43:46.270Z [INFO] [Telemetry] cli.telemetry:
{
  "kind": "model_resolution_info",
  "properties": {
    "cli_model": "claude-opus-4.6",
    "reasoning_effort": "high"
  },
  "session_id": "session-123"
}
"""

    assert extract_final_request_options(log_text) == {
        "cli_model": "claude-opus-4.6",
        "reasoning_effort": "high",
    }


@pytest.mark.parametrize(
    ("options", "expected"),
    [
        (
            {"reasoning_effort": "high"},
            ("reasoning_effort", "high", "high", ""),
        ),
        (
            {"thinking_budget": 0},
            ("thinking_budget", "0", "", "0"),
        ),
        ({}, ("none", "", "", "")),
    ],
)
def test_classify_reasoning_fields(
    options: dict[str, object], expected: tuple[str, str, str, str]
) -> None:
    assert classify_reasoning_fields(options) == expected


def test_extract_default_reasoning() -> None:
    log_text = "descriptor defaultReasoningEffort=medium more text"

    assert extract_default_reasoning(log_text) == "medium"
    assert extract_default_reasoning("missing") == ""


def test_find_process_log_for_session_returns_newest_match(tmp_path: Path) -> None:
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()

    older = logs_dir / "process-old.log"
    newer = logs_dir / "process-new.log"
    ignored = logs_dir / "notes.log"

    older.write_text("session-123 older", encoding="utf-8")
    newer.write_text("session-123 newer", encoding="utf-8")
    ignored.write_text("session-123 ignored", encoding="utf-8")

    os.utime(older, (1_700_000_000, 1_700_000_000))
    os.utime(newer, (1_700_000_100, 1_700_000_100))

    assert find_process_log_for_session("session-123", logs_dir) == newer
    assert find_process_log_for_session("missing", logs_dir) is None
    assert find_process_log_for_session("", logs_dir) is None


def test_find_recent_session_for_workdir_returns_newest_matching_events_file(
    tmp_path: Path,
) -> None:
    session_root = tmp_path / "session-state"
    workdir = tmp_path / "probe-workdir"
    workdir.mkdir()

    old_events = session_root / "session-old" / "events.jsonl"
    new_events = session_root / "session-new" / "events.jsonl"
    wrong_events = session_root / "session-wrong" / "events.jsonl"
    old_events.parent.mkdir(parents=True)
    new_events.parent.mkdir(parents=True)
    wrong_events.parent.mkdir(parents=True)

    payload = json.dumps(
        {
            "type": "session.start",
            "data": {"context": {"cwd": str(workdir)}},
        }
    )
    old_events.write_text(payload + "\n", encoding="utf-8")
    new_events.write_text(payload + "\n", encoding="utf-8")
    wrong_events.write_text(
        json.dumps(
            {
                "type": "session.start",
                "data": {"context": {"cwd": str(tmp_path / "other")}},
            }
        )
        + "\n",
        encoding="utf-8",
    )

    os.utime(old_events, (1_700_000_000, 1_700_000_000))
    os.utime(new_events, (1_700_000_100, 1_700_000_100))
    os.utime(wrong_events, (1_700_000_200, 1_700_000_200))

    match = find_recent_session_for_workdir(
        workdir,
        since_ts=1_700_000_110,
        session_root=session_root,
    )

    assert match is not None
    assert match.session_id == "session-new"
    assert match.events_path == new_events
    assert match.cwd == str(workdir.resolve())
