"""Tests for preview Stage 5 provider adapters."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from coding_cli_runtime import UnsupportedControlMode, get_copilot_stream_choices, providers
from coding_cli_runtime.providers import _common as provider_common
from coding_cli_runtime.providers import claude, codex, copilot, gemini
from coding_cli_runtime.providers._types import ProviderContinuationMode, ProviderEventKind
from coding_cli_runtime.providers.dispatcher import run_provider_exec
from coding_cli_runtime.providers.validation import validate_structured_output
from coding_cli_runtime.session_execution import InteractiveCliRunResult


def _interactive_result(
    *,
    stdout: str = "",
    stderr: str = "",
    returncode: int | None = 0,
    conversation_path: Path | None = None,
    started_at: float | None = None,
    cli_attempt_used: int = 1,
    max_cli_attempts: int = 1,
) -> InteractiveCliRunResult:
    return InteractiveCliRunResult(
        stdout=stdout.encode("utf-8"),
        stderr=stderr.encode("utf-8"),
        returncode=returncode,
        conversation_path=conversation_path,
        cli_attempt_used=cli_attempt_used,
        max_cli_attempts=max_cli_attempts,
        started_at=started_at or time.time(),
    )


def _write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(json.dumps(record) for record in records) + "\n", encoding="utf-8")


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


class TestClaudeAdapter:
    def test_materialize_prompt_file_references_appends_at_paths(self) -> None:
        prompt = claude.materialize_prompt_file_references(
            "Use the files.",
            ["_inputs/hero.png", Path("_inputs/spec.pdf")],
        )

        assert prompt == "Use the files.\n\n@_inputs/hero.png\n@_inputs/spec.pdf\n"

    def test_prepare_launch_maps_continue_latest_to_explicit_resume(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        project_dir = tmp_path / claude._claude_project_key(workdir)
        session_path = project_dir / "latest.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(workdir),
                    "sessionId": "session-latest",
                }
            ],
        )
        monkeypatch.setattr(claude, "resolve_session_search_paths", lambda _contract: [tmp_path])

        preview = claude.prepare_launch(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="New prompt",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert "--resume" in preview.cmd_parts
        assert "session-latest" in preview.cmd_parts
        assert preview.continuation_resolution is not None
        assert (
            preview.continuation_resolution.requested_mode
            is ProviderContinuationMode.CONTINUE_LATEST
        )
        assert (
            preview.continuation_resolution.resolved_mode
            is ProviderContinuationMode.CONTINUE_LATEST
        )
        assert preview.continuation_resolution.resolved_session_id == "session-latest"
        assert preview.continuation_resolution.resolved_session_path == session_path

    def test_prepare_launch_translates_session_path_to_resume(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_path = tmp_path / "session.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(workdir),
                    "sessionId": "session-from-path",
                }
            ],
        )
        monkeypatch.setattr(claude, "resolve_session_search_paths", lambda _contract: [tmp_path])

        preview = claude.prepare_launch(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="New prompt",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.SESSION_PATH,
                session_path=session_path,
            )
        )

        assert preview.continuation_resolution is not None
        assert (
            preview.continuation_resolution.resolved_mode is ProviderContinuationMode.SESSION_PATH
        )
        assert preview.continuation_resolution.resolved_session_id == "session-from-path"
        assert preview.continuation_resolution.resolved_session_path == session_path
        assert preview.continuation_resolution.native_strategy == "resume"
        assert "--resume" in preview.cmd_parts
        assert "session-from-path" in preview.cmd_parts

    def test_prepare_launch_rejects_explicit_session_id_from_other_workdir(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        other_workdir = tmp_path / "other"
        other_workdir.mkdir()
        other_project_dir = tmp_path / claude._claude_project_key(other_workdir)
        _write_jsonl(
            other_project_dir / "other.jsonl",
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(other_workdir),
                    "sessionId": "other-session",
                }
            ],
        )
        monkeypatch.setattr(claude, "resolve_session_search_paths", lambda _contract: [tmp_path])

        with pytest.raises(ValueError, match="was not found"):
            claude.prepare_launch(
                claude.ClaudeExecRequest(
                    model="claude-sonnet-4-6",
                    prompt="New prompt",
                    cwd=workdir,
                    continuation_mode=ProviderContinuationMode.SESSION_ID,
                    session_id="other-session",
                )
            )

    def test_prepare_launch_rejects_session_path_without_session_id(
        self,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_path = tmp_path / "session.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(workdir),
                }
            ],
        )

        with pytest.raises(ValueError, match="sessionId"):
            claude.prepare_launch(
                claude.ClaudeExecRequest(
                    model="claude-sonnet-4-6",
                    prompt="New prompt",
                    cwd=workdir,
                    continuation_mode=ProviderContinuationMode.SESSION_PATH,
                    session_path=session_path,
                )
            )

    def test_parse_output_prefers_stream_result_payload(self) -> None:
        output_text = "\n".join(
            [
                json.dumps({"type": "status", "message": "working"}),
                json.dumps({"type": "result", "structured_output": {"answer": 42}}),
                json.dumps({"type": "status", "message": "done"}),
            ]
        )

        parsed = claude.parse_output(output_text, "stream-json")

        assert parsed.structured_output == {"answer": 42}
        assert parsed.parse_error is None

    def test_find_session_supports_prompt_then_latest_lookup_mode(self, tmp_path: Path) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        project_dir = tmp_path / claude._claude_project_key(workdir)
        newer = project_dir / "newer.jsonl"
        older = project_dir / "older.jsonl"
        _write_jsonl(
            older,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Different prompt",
                    "cwd": str(workdir),
                    "sessionId": "session-older",
                }
            ],
        )
        _write_jsonl(
            newer,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Another prompt",
                    "cwd": str(workdir),
                    "sessionId": "session-newer",
                }
            ],
        )
        newer.touch()
        newer_ts = newer.stat().st_mtime
        older_ts = newer_ts - 10
        os.utime(older, (older_ts, older_ts))

        strict = claude.find_session(
            workdir,
            time.time(),
            prompt_text="missing prompt",
            project_roots=[tmp_path],
        )
        compat = claude.find_session(
            workdir,
            time.time(),
            prompt_text="missing prompt",
            lookup_mode=claude.ClaudeLookupMode.PROMPT_THEN_LATEST,
            project_roots=[tmp_path],
        )

        assert strict.status is claude.ClaudeSessionLookupStatus.NOT_FOUND
        assert compat.status is claude.ClaudeSessionLookupStatus.FOUND
        assert compat.path == newer
        assert compat.matched_by == "latest_fallback"

    def test_prepare_launch_resolves_latest_session_for_relative_cwd(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        project_dir = tmp_path / claude._claude_project_key(workdir)
        session_path = project_dir / "latest.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(workdir),
                    "sessionId": "relative-cwd-session",
                }
            ],
        )
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(claude, "resolve_session_search_paths", lambda _contract: [tmp_path])

        preview = claude.prepare_launch(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="New prompt",
                cwd=Path("workspace"),
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert preview.continuation_resolution is not None
        assert preview.continuation_resolution.resolved_session_id == "relative-cwd-session"

    def test_run_sync_preserves_raw_retry_and_session_data(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        captured: dict[str, object] = {}
        transcript_path = tmp_path / "claude.jsonl"

        async def fake_run_interactive_session(**kwargs):
            captured.update(kwargs)
            return _interactive_result(
                stdout='{"structured_output":{"ok":true}}',
                conversation_path=transcript_path,
                started_at=123.0,
            )

        monkeypatch.setattr(claude, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            claude,
            "find_session",
            lambda *_args, **_kwargs: claude.ClaudeSessionLookupResult(
                status=claude.ClaudeSessionLookupStatus.FOUND,
                path=tmp_path / "source.jsonl",
                session_id="session-1",
                matched_by="cwd_and_prompt",
                candidate_count=1,
            ),
        )

        result = claude.run_sync(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="Build a widget",
                cwd=tmp_path,
                output_format="json",
                api_key="sk-test",
                base_url="https://example.test",
                transient_retries=2,
            )
        )

        assert captured["stdin_text"] == "Build a widget"
        assert captured["env"]["CLAUDE_API_KEY"] == "sk-test"
        assert captured["env"]["ANTHROPIC_BASE_URL"] == "https://example.test"
        assert captured["max_cli_attempts"] == 3
        assert result.parsed_output.structured_output == {"ok": True}
        assert result.retry_history == ()
        assert result.session_lookup is not None
        assert result.session_lookup.session_id == "session-1"
        assert result.raw_execution.stdout == b'{"structured_output":{"ok":true}}'
        assert result.raw_execution.conversation_path == transcript_path
        assert result.raw_execution.native_result is result.raw_result
        assert result.control_resolution.requested == {}
        assert result.control_resolution.applied == {}
        assert result.control_resolution.ignored == {}
        assert result.control_resolution.unknown_default_keys == ("effort",)

    @pytest.mark.asyncio
    async def test_run_continuation_locates_transcript_by_resolved_session(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        project_dir = tmp_path / claude._claude_project_key(workdir)
        session_path = project_dir / "conversation.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "queue-operation",
                    "operation": "enqueue",
                    "content": "Earlier prompt",
                    "cwd": str(workdir),
                    "sessionId": "continued-session",
                }
            ],
        )
        monkeypatch.setattr(claude, "resolve_session_search_paths", lambda _contract: [tmp_path])

        captured: dict[str, object] = {}

        async def fake_mirror_session_transcript(**kwargs):
            captured["located_source"] = kwargs["strategy"].locate_source()
            return kwargs["strategy"].destination

        async def fake_run_interactive_session(**kwargs):
            await kwargs["transcript_factory"](object())
            return _interactive_result(
                stdout='{"structured_output":{"ok":true}}',
                conversation_path=tmp_path / "captured.jsonl",
                started_at=123.0,
            )

        monkeypatch.setattr(claude, "mirror_session_transcript", fake_mirror_session_transcript)
        monkeypatch.setattr(claude, "run_interactive_session", fake_run_interactive_session)

        result = await claude.run(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="Brand new prompt",
                cwd=workdir,
                output_format="json",
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        located_source = captured["located_source"]
        assert located_source is not None
        assert located_source.path == session_path
        assert result.continuation_resolution.resolved_session_id == "continued-session"

    def test_prepare_launch_is_side_effect_free_and_deterministic(
        self,
        tmp_path: Path,
    ) -> None:
        request = claude.ClaudeExecRequest(
            model="claude-sonnet-4-6",
            prompt="Build a widget",
            cwd=tmp_path,
            output_format="json",
            execution_id="claude-preview",
        )

        preview = claude.prepare_launch(request)

        assert preview.display_text.endswith("<prompt>")
        assert preview.output_paths == (
            Path("/tmp/coding-cli-runtime/claude-preview/claude_conversation_.jsonl"),
        )
        assert not preview.output_paths[0].parent.exists()
        assert preview.control_resolution is not None
        assert preview.control_resolution.requested == {}
        assert preview.control_resolution.unknown_default_keys == ("effort",)

    def test_progress_callback_emits_transcript_events_and_preserves_legacy_callback(
        self, tmp_path: Path
    ) -> None:
        seen = []
        legacy = []
        callback = provider_common.build_progress_callback(
            provider="claude",
            get_attempt_index=lambda: 2,
            event_callback=seen.append,
            transcript_progress_callback=legacy.append,
            logger=claude._LOGGER,
        )
        assert callback is not None

        progress = claude.SessionProgressEvent(
            event_type="provider_call_heartbeat",
            conversation_path=tmp_path / "claude.jsonl",
            activity_kind="transcript_growth",
            mirrored_bytes=42,
            last_activity_at=123.0,
        )
        callback(progress)

        assert legacy == [progress]
        assert len(seen) == 1
        assert seen[0].kind is ProviderEventKind.TRANSCRIPT_PROGRESS
        assert seen[0].attempt_index == 2
        assert seen[0].data.progress == progress


class TestProviderNamespace:
    def test_session_lookup_aliases_delegate_to_provider_modules(self) -> None:
        assert providers.find_claude_session is providers.claude.find_session
        assert providers.find_codex_session is providers.codex.find_session
        assert providers.find_copilot_session is providers.copilot.find_session
        assert providers.find_gemini_session is providers.gemini.find_session


class TestGeminiAdapter:
    def test_prepare_launch_maps_continue_latest_to_explicit_resume(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "gemini-root"
        project_hash = gemini._gemini_project_hash(workdir)
        session_path = session_root / project_hash / "chats" / "session-latest.json"
        _write_json(
            session_path,
            {
                "sessionId": "gemini-session-latest",
                "projectHash": project_hash,
                "startTime": "2026-04-19T07:23:42.883Z",
                "lastUpdated": "2026-04-19T07:24:10.030Z",
                "messages": [],
            },
        )
        monkeypatch.setattr(
            gemini,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        preview = gemini.prepare_launch(
            gemini.GeminiExecRequest(
                model="gemini-2.5-flash",
                prompt="New prompt",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert "--resume" in preview.cmd_parts
        assert "gemini-session-latest" in preview.cmd_parts
        assert preview.continuation_resolution is not None
        assert (
            preview.continuation_resolution.resolved_mode
            is ProviderContinuationMode.CONTINUE_LATEST
        )
        assert preview.continuation_resolution.resolved_session_id == "gemini-session-latest"
        assert preview.continuation_resolution.resolved_session_path == session_path

    def test_prepare_launch_rejects_session_path_from_other_project(
        self,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_path = tmp_path / "foreign-session.json"
        _write_json(
            session_path,
            {
                "sessionId": "foreign-gemini-session",
                "projectHash": "other-project-hash",
                "messages": [],
            },
        )

        with pytest.raises(ValueError, match="different project/workdir"):
            gemini.prepare_launch(
                gemini.GeminiExecRequest(
                    model="gemini-2.5-flash",
                    prompt="New prompt",
                    cwd=workdir,
                    continuation_mode=ProviderContinuationMode.SESSION_PATH,
                    session_path=session_path,
                )
            )

    @pytest.mark.asyncio
    async def test_run_continuation_uses_resolved_session_lookup(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "gemini-root"
        project_hash = gemini._gemini_project_hash(workdir)
        session_path = session_root / project_hash / "chats" / "session-latest.json"
        _write_json(
            session_path,
            {
                "sessionId": "gemini-session-latest",
                "projectHash": project_hash,
                "messages": [],
            },
        )
        monkeypatch.setattr(
            gemini,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        async def fake_run_interactive_session(**_kwargs):
            return _interactive_result(stdout='{"files":[]}', stderr="", started_at=200.0)

        monkeypatch.setattr(gemini, "run_interactive_session", fake_run_interactive_session)

        result = await gemini.run(
            gemini.GeminiExecRequest(
                model="gemini-2.5-flash",
                prompt="Continue generation",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert result.continuation_resolution.resolved_session_id == "gemini-session-latest"
        assert result.session_lookup is not None
        assert result.session_lookup.path == session_path
        assert result.raw_execution.conversation_path == session_path
        assert result.parsed_output.parsed_payload == {"files": []}

    def test_parse_output_strips_fences_and_repairs_invalid_escape(self) -> None:
        raw = r"```json" "\n" r'{"path":"src\widget\main.ts","ok":true}' "\n```"

        parsed = gemini.parse_output(raw)

        assert parsed.parse_error is None
        assert parsed.parsed_payload == {"path": "src\\widget\\main.ts", "ok": True}

    def test_parse_output_skips_invalid_early_brace_and_extracts_later_json(self) -> None:
        raw = (
            "**Delivering the Output** Here is an invalid sketch "
            '{token:"nope"} before the real payload.\n\n'
            '{"token":"GEMINI-PROBE-OK"}'
        )

        parsed = gemini.parse_output(raw)

        assert parsed.parse_error is None
        assert parsed.parsed_payload == {"token": "GEMINI-PROBE-OK"}
        assert parsed.extracted_json_text == '{"token":"GEMINI-PROBE-OK"}'

    def test_materialize_prompt_file_references_appends_at_paths(self) -> None:
        prompt = gemini.materialize_prompt_file_references(
            "Use the files.",
            ["_inputs/hero.png", Path("_inputs/spec.pdf")],
        )

        assert prompt == "Use the files.\n\n@_inputs/hero.png\n@_inputs/spec.pdf\n"

    def test_materialize_prompt_file_references_rejects_absolute_paths(
        self, tmp_path: Path
    ) -> None:
        with pytest.raises(ValueError, match="relative paths"):
            gemini.materialize_prompt_file_references(
                "Use the files.",
                [tmp_path / "hero.png"],
            )

    def test_find_session_prefers_matching_project_hash(self, tmp_path: Path) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "gemini"
        project_hash = gemini._gemini_project_hash(workdir)
        session_path = session_root / project_hash / "chats" / "session-1.json"
        session_path.parent.mkdir(parents=True)
        session_path.write_text(
            json.dumps(
                {
                    "projectHash": project_hash,
                    "startTime": "2026-04-13T12:00:05Z",
                    "lastUpdated": "2026-04-13T12:00:06Z",
                }
            ),
            encoding="utf-8",
        )

        result = gemini.find_session(
            workdir,
            datetime_to_ts("2026-04-13T12:00:10Z"),
            session_roots=[session_root],
        )

        assert result.status is gemini.GeminiSessionLookupStatus.FOUND
        assert result.path == session_path

    @pytest.mark.asyncio
    async def test_run_records_retry_history_for_transient_failure(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        captured: dict[str, object] = {}

        async def fake_run_interactive_session(**kwargs):
            captured.update(kwargs)
            first = _interactive_result(
                stderr="getaddrinfo EAI_AGAIN", returncode=1, started_at=100.0
            )
            decision = kwargs["retry_decider"](first, 1, kwargs["max_cli_attempts"])
            assert decision.retry is True
            return _interactive_result(
                stdout='{"files":[]}', conversation_path=tmp_path / "gemini.json", started_at=101.0
            )

        monkeypatch.setattr(gemini, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            gemini,
            "find_session",
            lambda *_args, **_kwargs: gemini.GeminiSessionLookupResult(
                status=gemini.GeminiSessionLookupStatus.FOUND,
                path=tmp_path / "gemini.json",
                matched_by="project_hash",
                candidate_count=1,
                project_hash="hash",
            ),
        )

        result = await gemini.run(
            gemini.GeminiExecRequest(
                model="gemini-3-pro-preview",
                prompt="Generate JSON",
                cwd=tmp_path,
                api_key="gm-test",
                transient_retries=2,
            )
        )

        assert captured["env"]["GEMINI_API_KEY"] == "gm-test"
        assert captured["env"]["GEMINI_CLI_IDE_WORKSPACE_PATH"] == str(tmp_path)
        assert len(result.retry_history) == 1
        assert result.retry_history[0].category == "network_transient"
        assert result.raw_execution.stdout == b'{"files":[]}'
        assert result.raw_execution.native_result is result.raw_result

    def test_prepare_launch_uses_workspace_env_and_transcript_preview_path(
        self, tmp_path: Path
    ) -> None:
        preview = gemini.prepare_launch(
            gemini.GeminiExecRequest(
                model="gemini-3-pro-preview",
                prompt="Generate JSON",
                cwd=tmp_path,
                execution_id="gemini-preview",
            )
        )

        assert preview.output_paths == (
            Path("/tmp/coding-cli-runtime/gemini-preview/gemini_conversation_.json"),
        )
        assert preview.redacted_env["GEMINI_CLI_IDE_WORKSPACE_PATH"] == str(tmp_path)


class TestCopilotAdapter:
    def test_prepare_launch_maps_continue_latest_to_explicit_resume(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "copilot-root"
        events_path = session_root / "session-123" / "events.jsonl"
        _write_jsonl(
            events_path,
            [
                {
                    "type": "session.start",
                    "data": {"context": {"cwd": str(workdir)}},
                }
            ],
        )
        monkeypatch.setattr(
            copilot,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        preview = copilot.prepare_launch(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.6",
                prompt="New prompt",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert "--resume=session-123" in preview.cmd_parts
        assert preview.continuation_resolution is not None
        assert (
            preview.continuation_resolution.resolved_mode
            is ProviderContinuationMode.CONTINUE_LATEST
        )
        assert preview.continuation_resolution.resolved_session_id == "session-123"
        assert preview.continuation_resolution.resolved_session_path == events_path

    def test_prepare_launch_rejects_explicit_session_id_from_other_workdir(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        other_workdir = tmp_path / "other"
        other_workdir.mkdir()
        session_root = tmp_path / "copilot-root"
        events_path = session_root / "session-foreign" / "events.jsonl"
        _write_jsonl(
            events_path,
            [
                {
                    "type": "session.start",
                    "data": {"context": {"cwd": str(other_workdir)}},
                }
            ],
        )
        monkeypatch.setattr(
            copilot,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        with pytest.raises(ValueError, match="was not found"):
            copilot.prepare_launch(
                copilot.CopilotExecRequest(
                    model="claude-sonnet-4.6",
                    prompt="New prompt",
                    cwd=workdir,
                    continuation_mode=ProviderContinuationMode.SESSION_ID,
                    session_id="session-foreign",
                )
            )

    @pytest.mark.asyncio
    async def test_run_continuation_uses_resolved_session_lookup(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "copilot-root"
        events_path = session_root / "session-123" / "events.jsonl"
        _write_jsonl(
            events_path,
            [
                {
                    "type": "session.start",
                    "data": {"context": {"cwd": str(workdir)}},
                }
            ],
        )
        monkeypatch.setattr(
            copilot,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        async def fake_run_interactive_session(**_kwargs):
            return _interactive_result(stdout="stdout output", stderr="", started_at=100.0)

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.6",
                prompt="Continue",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
            )
        )

        assert result.continuation_resolution.resolved_session_id == "session-123"
        assert result.session_lookup is not None
        assert result.session_lookup.path == events_path
        assert result.session_lookup.matched_by == "latest"
        assert result.raw_execution.conversation_path == events_path
        assert result.parsed_output.output_source == "stdout"

    def test_parse_output_prefers_stdout(self) -> None:
        stdout_only = copilot.parse_output(stdout_text="stdout")

        assert stdout_only.output_source == "stdout"
        assert stdout_only.output_text == "stdout"

    def test_request_rejects_invalid_reasoning_for_opus47(self) -> None:
        with pytest.raises(ValueError, match="only supports reasoning levels: medium"):
            copilot.CopilotExecRequest(
                model="claude-opus-4.7",
                prompt="Ship it",
                cwd=Path("/tmp"),
                reasoning_effort="high",
            )

    def test_request_allows_medium_reasoning_for_opus47(self) -> None:
        request = copilot.CopilotExecRequest(
            model="claude-opus-4.7",
            prompt="Ship it",
            cwd=Path("/tmp"),
            reasoning_effort="medium",
        )

        assert request.reasoning_effort == "medium"

    def test_request_allows_all_gpt55_reasoning_efforts(self) -> None:
        for effort in ("low", "medium", "high", "xhigh"):
            request = copilot.CopilotExecRequest(
                model="gpt-5.5",
                prompt="Ship it",
                cwd=Path("/tmp"),
                reasoning_effort=effort,
            )

            assert request.reasoning_effort == effort

    def test_prepare_launch_exposes_provider_default_reasoning_resolution(
        self,
        tmp_path: Path,
    ) -> None:
        preview = copilot.prepare_launch(
            copilot.CopilotExecRequest(
                model="claude-opus-4.7",
                prompt="Annotate this image",
                cwd=tmp_path,
                execution_id="copilot-default-reasoning",
            )
        )

        assert preview.control_resolution is not None
        assert preview.control_resolution.requested == {}
        assert preview.control_resolution.defaulted == {"reasoning_effort": "medium"}
        assert preview.control_resolution.default_sources["reasoning_effort"].value == (
            "provider_default"
        )
        assert preview.effective_controls["reasoning_effort"] == "medium"

    def test_materialize_prompt_file_references_appends_at_paths(self) -> None:
        prompt = copilot.materialize_prompt_file_references(
            "Prompt",
            ["_inputs/image.png", Path("_inputs/spec.pdf")],
        )

        assert prompt == "Prompt\n\n@_inputs/image.png\n@_inputs/spec.pdf\n"

    def test_find_session_matches_workdir(self, tmp_path: Path) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "sessions"
        events_path = session_root / "abc" / "events.jsonl"
        _write_jsonl(
            events_path,
            [
                {
                    "type": "session.start",
                    "data": {
                        "context": {"cwd": str(workdir)},
                    },
                }
            ],
        )

        result = copilot.find_session(workdir, time.time(), session_roots=[session_root])

        assert result.status is copilot.CopilotSessionLookupStatus.FOUND
        assert result.path == events_path

    @pytest.mark.asyncio
    async def test_run_uses_process_log_detail_for_retry(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        async def fake_run_interactive_session(**kwargs):
            first = _interactive_result(stderr="", returncode=1, started_at=100.0)
            decision = kwargs["retry_decider"](first, 1, kwargs["max_cli_attempts"])
            assert decision.retry is True
            return _interactive_result(
                stdout="", stderr="", conversation_path=tmp_path / "copilot.jsonl", started_at=101.0
            )

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "_extract_copilot_process_failure_detail",
            lambda **_kwargs: ("failed to list models: 429", tmp_path / "process.log"),
        )
        monkeypatch.setattr(
            copilot,
            "find_session",
            lambda *_args, **_kwargs: copilot.CopilotSessionLookupResult(
                status=copilot.CopilotSessionLookupStatus.FOUND,
                path=tmp_path / "copilot.jsonl",
                matched_by="cwd",
                candidate_count=1,
            ),
        )

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.5",
                prompt="Ship it",
                cwd=tmp_path,
                transient_retries=2,
            )
        )

        assert len(result.retry_history) == 1
        assert result.retry_history[0].category == "startup_rate_limited"
        assert result.parsed_output.output_source == "none"
        assert result.parsed_output.output_text == ""

    @pytest.mark.asyncio
    async def test_run_prefers_native_session_lookup_over_transcript_capture(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        native_events_path = tmp_path / "native" / "events.jsonl"

        async def fake_run_interactive_session(**_kwargs):
            return _interactive_result(
                stdout="stdout output",
                stderr="",
                conversation_path=tmp_path / "transcript.jsonl",
                started_at=101.0,
            )

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "find_session",
            lambda *_args, **_kwargs: copilot.CopilotSessionLookupResult(
                status=copilot.CopilotSessionLookupStatus.FOUND,
                path=native_events_path,
                matched_by="cwd",
                candidate_count=1,
            ),
        )

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.6",
                prompt="Ship it",
                cwd=tmp_path,
            )
        )

        assert result.session_lookup is not None
        assert result.session_lookup.path == native_events_path
        assert result.session_lookup.matched_by == "cwd"
        assert result.raw_execution.conversation_path == tmp_path / "transcript.jsonl"

    @pytest.mark.asyncio
    async def test_run_failure_classification_uses_process_log_detail(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        async def fake_run_interactive_session(**kwargs):
            return _interactive_result(
                stdout="",
                stderr="",
                returncode=1,
                started_at=100.0,
                cli_attempt_used=kwargs["max_cli_attempts"],
                max_cli_attempts=kwargs["max_cli_attempts"],
            )

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "_extract_copilot_process_failure_detail",
            lambda **_kwargs: ("failed to list models: 429", tmp_path / "process.log"),
        )

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.5",
                prompt="Ship it",
                cwd=tmp_path,
                transient_retries=1,
            )
        )

        assert result.failure_classification is not None
        assert result.failure_classification.category == "startup_rate_limited"
        assert result.raw_execution.returncode == 1
        assert result.raw_execution.native_result is result.raw_result

    @pytest.mark.asyncio
    async def test_run_reports_none_without_stdout(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        async def fake_run_interactive_session(**_kwargs):
            return _interactive_result(stdout="", stderr="", started_at=100.0)

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "find_session",
            lambda *_args, **_kwargs: copilot.CopilotSessionLookupResult(
                status=copilot.CopilotSessionLookupStatus.NOT_FOUND,
                candidate_count=0,
            ),
        )

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.5",
                prompt="Ship it",
                cwd=tmp_path,
            )
        )

        assert result.parsed_output.output_source == "none"

    @pytest.mark.asyncio
    async def test_run_returns_timed_out_result_with_transcript_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        conversation_path = tmp_path / "copilot.jsonl"

        async def fake_run_interactive_session(**_kwargs):
            raise copilot.SessionExecutionTimeoutError(
                "Copilot timed out",
                conversation_path=conversation_path,
                started_at=100.0,
            )

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.5",
                prompt="Ship it",
                cwd=tmp_path,
            )
        )

        assert result.raw_result.timed_out is True
        assert result.raw_execution.timed_out is True
        assert result.raw_execution.conversation_path == conversation_path
        assert result.session_lookup is not None
        assert result.session_lookup.path == conversation_path
        assert result.parsed_output.output_source == "none"

    @pytest.mark.asyncio
    async def test_run_uses_stdout_without_share_output(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        async def fake_run_interactive_session(**_kwargs):
            return _interactive_result(stdout="stdout output", stderr="", started_at=100.0)

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "find_session",
            lambda *_args, **_kwargs: copilot.CopilotSessionLookupResult(
                status=copilot.CopilotSessionLookupStatus.NOT_FOUND,
                candidate_count=0,
            ),
        )

        result = await copilot.run(
            copilot.CopilotExecRequest(
                model="claude-sonnet-4.5",
                prompt="Ship it",
                cwd=tmp_path,
                stream="on",
                reasoning_effort="high",
            )
        )

        assert result.parsed_output.output_source == "stdout"
        assert result.parsed_output.output_text == "stdout output"

    @pytest.mark.asyncio
    async def test_prepare_launch_transcript_path_matches_runtime(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        request = copilot.CopilotExecRequest(
            model="claude-sonnet-4.5",
            prompt="Ship it",
            cwd=tmp_path,
            execution_id="copilot-preview",
        )
        preview = copilot.prepare_launch(request)
        launched: dict[str, object] = {}

        async def fake_run_interactive_session(**kwargs):
            launched["cmd_parts"] = kwargs["cmd_parts"]
            return _interactive_result(stdout="ok", stderr="", started_at=100.0)

        monkeypatch.setattr(copilot, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            copilot,
            "find_session",
            lambda *_args, **_kwargs: copilot.CopilotSessionLookupResult(
                status=copilot.CopilotSessionLookupStatus.NOT_FOUND,
                candidate_count=0,
            ),
        )

        await copilot.run(request)

        cmd_parts = list(launched["cmd_parts"])
        assert "--share" not in cmd_parts
        assert preview.output_paths[0] == Path(
            "/tmp/coding-cli-runtime/copilot-preview/copilot_conversation_.jsonl"
        )


class TestCodexAdapter:
    def test_materialize_prompt_file_references_is_explicitly_unsupported(self) -> None:
        with pytest.raises(NotImplementedError):
            codex.materialize_prompt_file_references(
                "Use the files.",
                ["_inputs/hero.png", Path("_inputs/spec.pdf")],
            )

    def test_parse_output_normalizes_files_dict_to_list(self) -> None:
        parsed = codex.parse_output(
            '{"name":"app","instructions":"do it","files":{"a.txt":"hello"}}'
        )

        assert parsed.parse_error is None
        assert parsed.parsed_payload is not None
        assert parsed.parsed_payload["files"] == [{"path": "a.txt", "contents": "hello"}]

    def test_prepare_launch_allows_fresh_session_without_output_schema(
        self,
        tmp_path: Path,
    ) -> None:
        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                model_reasoning="medium",
            )
        )

        assert "--output-schema" not in preview.cmd_parts
        assert preview.output_paths[0].suffix == ".json"

    def test_prepare_launch_rejects_continuation_with_schema_output(
        self,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")

        with pytest.raises(ValueError, match="does not support native --output-schema"):
            codex.prepare_launch(
                codex.CodexExecRequest(
                    model="gpt-5.4",
                    prompt="Continue",
                    cwd=tmp_path,
                    output_schema_path=schema_path,
                    continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
                    model_reasoning="medium",
                )
            )

    def test_prepare_launch_maps_continue_latest_to_explicit_resume(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "codex-sessions"
        session_path = session_root / "session-latest.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "codex-session-latest",
                        "cwd": str(workdir),
                    },
                }
            ],
        )
        monkeypatch.setattr(
            codex,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Continue generation",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
                model_reasoning="medium",
            )
        )

        assert preview.continuation_resolution is not None
        assert preview.continuation_resolution.resolved_session_id == "codex-session-latest"
        assert preview.continuation_resolution.resolved_session_path == session_path
        assert preview.continuation_resolution.matched_by == "latest"
        assert preview.continuation_resolution.native_strategy == "resume"
        assert "resume" in preview.cmd_parts
        assert "codex-session-latest" in preview.cmd_parts
        assert "-" in preview.cmd_parts
        assert "--output-schema" not in preview.cmd_parts
        assert preview.effective_controls["schema_enforced_output"] is False

    def test_prepare_launch_translates_session_path_to_resume(
        self,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_path = tmp_path / "session.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "codex-session-from-path",
                        "cwd": str(workdir),
                    },
                }
            ],
        )

        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Continue from path",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.SESSION_PATH,
                session_path=session_path,
                model_reasoning="medium",
            )
        )

        assert preview.continuation_resolution is not None
        assert preview.continuation_resolution.resolved_session_id == "codex-session-from-path"
        assert preview.continuation_resolution.resolved_session_path == session_path
        assert preview.continuation_resolution.matched_by == "session_path"
        assert preview.continuation_resolution.native_strategy == "resume"
        assert "resume" in preview.cmd_parts
        assert "codex-session-from-path" in preview.cmd_parts

    def test_prepare_launch_read_only_continuation_does_not_enable_full_auto(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "codex-sessions"
        session_path = session_root / "session-read-only.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "codex-session-read-only",
                        "cwd": str(workdir),
                    },
                }
            ],
        )
        monkeypatch.setattr(
            codex,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Continue in read-only mode",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
                model_reasoning="medium",
                sandbox="read-only",
            )
        )

        assert "--full-auto" not in preview.cmd_parts
        assert "--dangerously-bypass-approvals-and-sandbox" not in preview.cmd_parts

    def test_prepare_launch_rejects_explicit_session_id_from_other_workdir(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        foreign = tmp_path / "foreign"
        foreign.mkdir()
        session_root = tmp_path / "codex-sessions"
        session_path = session_root / "session-foreign.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "codex-session-foreign",
                        "cwd": str(foreign),
                    },
                }
            ],
        )
        monkeypatch.setattr(
            codex,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        with pytest.raises(ValueError, match="was not found for workdir"):
            codex.prepare_launch(
                codex.CodexExecRequest(
                    model="gpt-5.4",
                    prompt="Continue generation",
                    cwd=workdir,
                    continuation_mode=ProviderContinuationMode.SESSION_ID,
                    session_id="codex-session-foreign",
                    model_reasoning="medium",
                )
            )

    def test_prepare_launch_exposes_control_resolution_with_ignored_controls(
        self,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")

        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                model_reasoning="medium",
                model_controls={"effort": "high"},
            )
        )

        assert preview.control_resolution is not None
        assert preview.control_resolution.requested == {
            "effort": "high",
            "reasoning_effort": "medium",
        }
        assert preview.control_resolution.applied == {"reasoning_effort": "medium"}
        assert preview.control_resolution.ignored == {"effort": "high"}

    def test_prepare_launch_can_error_on_unsupported_controls(
        self,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")

        with pytest.raises(ValueError, match="Unsupported model controls for provider 'codex'"):
            codex.prepare_launch(
                codex.CodexExecRequest(
                    model="gpt-5.4",
                    prompt="Generate files",
                    cwd=tmp_path,
                    output_schema_path=schema_path,
                    model_reasoning="medium",
                    model_controls={"effort": "high"},
                    unsupported_control_mode=UnsupportedControlMode.ERROR,
                )
            )

    @pytest.mark.asyncio
    async def test_run_reads_and_normalizes_output_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        output_path = tmp_path / "nested" / "codex" / "output.json"
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")

        async def fake_run_interactive_session(**kwargs):
            cmd_parts = list(kwargs["cmd_parts"])
            file_path = Path(cmd_parts[cmd_parts.index("-o") + 1])
            file_path.write_text(
                json.dumps(
                    {
                        "name": "app",
                        "instructions": "Ship it",
                        "files": {"src/main.ts": "console.log('hi')"},
                    }
                ),
                encoding="utf-8",
            )
            return _interactive_result(
                stdout="", stderr="", conversation_path=tmp_path / "codex.jsonl", started_at=200.0
            )

        monkeypatch.setattr(codex, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            codex,
            "find_session",
            lambda *_args, **_kwargs: codex.CodexSessionLookupResult(
                status=codex.CodexSessionLookupStatus.FOUND,
                path=tmp_path / "codex.jsonl",
                matched_by="cwd",
            ),
        )

        result = await codex.run(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                output_path=output_path,
                model_reasoning="medium",
            )
        )

        assert result.output_path == output_path
        assert result.parsed_output.parsed_payload is not None
        assert result.parsed_output.parsed_payload["files"] == [
            {"path": "src/main.ts", "contents": "console.log('hi')"}
        ]
        assert result.raw_execution.conversation_path == tmp_path / "codex.jsonl"
        assert result.raw_execution.native_result is result.raw_result
        assert json.loads(output_path.read_text(encoding="utf-8"))["files"] == [
            {"path": "src/main.ts", "contents": "console.log('hi')"}
        ]

    @pytest.mark.asyncio
    async def test_run_retries_with_ephemeral_on_state_db_failure(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")
        launches: list[tuple[str, ...]] = []

        async def fake_run_interactive_session(**kwargs):
            launches.append(tuple(kwargs["cmd_parts"]))
            output_index = kwargs["cmd_parts"].index("-o") + 1
            output_path = Path(kwargs["cmd_parts"][output_index])
            if "--ephemeral" not in kwargs["cmd_parts"]:
                return _interactive_result(
                    stderr="state db: database is locked",
                    returncode=1,
                    started_at=200.0,
                )
            output_path.write_text(
                json.dumps(
                    {
                        "name": "app",
                        "instructions": "Ship it",
                        "files": {"src/main.ts": "console.log('hi')"},
                    }
                ),
                encoding="utf-8",
            )
            return _interactive_result(stdout="", stderr="", started_at=201.0)

        monkeypatch.setattr(codex, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            codex,
            "find_session",
            lambda *_args, **_kwargs: codex.CodexSessionLookupResult(
                status=codex.CodexSessionLookupStatus.NOT_FOUND,
            ),
        )

        result = await codex.run(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                model_reasoning="medium",
                ephemeral_retry_on_state_db_failure=True,
                transient_retry_backoff_seconds=0.0,
            )
        )

        assert len(launches) == 2
        assert "--ephemeral" not in launches[0]
        assert "--ephemeral" in launches[1]
        assert len(result.retry_history) == 1
        assert result.retry_history[0].category == "state_db_locked"
        assert result.retry_history[0].launch_variant == "ephemeral"
        assert result.parsed_output.parsed_payload is not None

    @pytest.mark.asyncio
    async def test_run_emits_attempt_recovery_and_parse_events(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")
        events = []
        call_count = 0

        async def fake_run_interactive_session(**kwargs):
            nonlocal call_count
            call_count += 1
            output_index = kwargs["cmd_parts"].index("-o") + 1
            output_path = Path(kwargs["cmd_parts"][output_index])
            if call_count == 1:
                return _interactive_result(
                    stderr="state db: database is locked",
                    returncode=1,
                    started_at=200.0,
                )
            output_path.write_text(
                json.dumps(
                    {
                        "name": "app",
                        "instructions": "Ship it",
                        "files": {"src/main.ts": "console.log('hi')"},
                    }
                ),
                encoding="utf-8",
            )
            return _interactive_result(stdout="", stderr="", started_at=201.0)

        monkeypatch.setattr(codex, "run_interactive_session", fake_run_interactive_session)
        monkeypatch.setattr(
            codex,
            "find_session",
            lambda *_args, **_kwargs: codex.CodexSessionLookupResult(
                status=codex.CodexSessionLookupStatus.NOT_FOUND,
            ),
        )

        result = await codex.run(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                model_reasoning="medium",
                ephemeral_retry_on_state_db_failure=True,
                transient_retry_backoff_seconds=0.0,
                event_callback=events.append,
                execution_id="codex-events",
            )
        )

        assert result.parsed_output.parsed_payload is not None
        assert [event.kind for event in events] == [
            ProviderEventKind.ATTEMPT_STARTED,
            ProviderEventKind.ATTEMPT_FINISHED,
            ProviderEventKind.RECOVERY_APPLIED,
            ProviderEventKind.ATTEMPT_STARTED,
            ProviderEventKind.ATTEMPT_FINISHED,
            ProviderEventKind.PARSE_FINISHED,
        ]
        assert events[0].data.launch.effective_controls["ephemeral"] is False
        assert events[3].data.launch.effective_controls["ephemeral"] is True

    def test_prepare_launch_uses_deterministic_output_and_transcript_paths(
        self,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")

        preview = codex.prepare_launch(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                model_reasoning="medium",
                execution_id="codex-preview",
            )
        )

        assert preview.output_paths == (
            Path("/tmp/coding-cli-runtime/codex-preview/codex_output_.json"),
            Path("/tmp/coding-cli-runtime/codex-preview/codex_conversation_.jsonl"),
        )
        assert not preview.output_paths[0].parent.exists()

    @pytest.mark.asyncio
    async def test_run_continuation_uses_resolved_session_lookup_without_schema(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        workdir = tmp_path / "workspace"
        workdir.mkdir()
        session_root = tmp_path / "codex-sessions"
        session_path = session_root / "session-resume.jsonl"
        _write_jsonl(
            session_path,
            [
                {
                    "type": "session_meta",
                    "payload": {
                        "id": "codex-session-resume",
                        "cwd": str(workdir),
                    },
                }
            ],
        )
        monkeypatch.setattr(
            codex,
            "resolve_session_search_paths",
            lambda _contract: (session_root,),
        )

        async def fake_run_interactive_session(**kwargs):
            cmd_parts = list(kwargs["cmd_parts"])
            file_path = Path(cmd_parts[cmd_parts.index("-o") + 1])
            file_path.write_text(
                json.dumps(
                    {
                        "name": "app",
                        "instructions": "Resume it",
                        "files": {"src/main.ts": "console.log('resumed')"},
                    }
                ),
                encoding="utf-8",
            )
            return _interactive_result(stdout="", stderr="", started_at=250.0)

        monkeypatch.setattr(codex, "run_interactive_session", fake_run_interactive_session)

        result = await codex.run(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Continue generation",
                cwd=workdir,
                continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
                model_reasoning="medium",
            )
        )

        assert result.continuation_resolution.resolved_session_id == "codex-session-resume"
        assert result.session_lookup is not None
        assert result.session_lookup.path == session_path
        assert result.session_lookup.matched_by == "latest"
        assert result.raw_execution.conversation_path == session_path
        assert result.parsed_output.parsed_payload is not None
        assert result.parsed_output.parsed_payload["files"] == [
            {"path": "src/main.ts", "contents": "console.log('resumed')"}
        ]

    @pytest.mark.asyncio
    async def test_run_returns_timed_out_result_with_transcript_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        schema_path = tmp_path / "schema.json"
        schema_path.write_text('{"type":"object"}', encoding="utf-8")
        conversation_path = tmp_path / "codex.jsonl"

        async def fake_run_interactive_session(**_kwargs):
            raise codex.SessionExecutionTimeoutError(
                "Codex timed out",
                conversation_path=conversation_path,
                started_at=200.0,
            )

        monkeypatch.setattr(codex, "run_interactive_session", fake_run_interactive_session)

        result = await codex.run(
            codex.CodexExecRequest(
                model="gpt-5.4",
                prompt="Generate files",
                cwd=tmp_path,
                output_schema_path=schema_path,
                model_reasoning="medium",
            )
        )

        assert result.raw_result.timed_out is True
        assert result.raw_execution.timed_out is True
        assert result.raw_execution.conversation_path == conversation_path
        assert result.session_lookup is not None
        assert result.session_lookup.path == conversation_path
        assert result.parsed_output.parse_skipped is True


class TestStructuredValidationHelper:
    def test_validate_structured_output_preserves_payload_error_and_paths(
        self,
        tmp_path: Path,
    ) -> None:
        transcript_path = tmp_path / "conversation.jsonl"
        session_path = tmp_path / "session.jsonl"

        result = validate_structured_output(
            provider="copilot",
            model="claude-sonnet-4.6",
            schema_name="normalized_run_result.v1",
            parsed_payload={"provider": "copilot"},
            transcript_path=transcript_path,
            session_path=session_path,
        )

        assert result.valid is False
        assert result.parsed_payload == {"provider": "copilot"}
        assert result.validation_error is not None
        assert "missing required field" in result.validation_error
        assert result.transcript_path == transcript_path
        assert result.session_path == session_path


class TestDispatcherAndMetadata:
    @pytest.mark.asyncio
    async def test_run_provider_exec_dispatches_to_provider_module(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        expected = object()

        async def fake_run(_request):
            return expected

        monkeypatch.setattr(claude, "run", fake_run)

        result = await run_provider_exec(
            claude.ClaudeExecRequest(
                model="claude-sonnet-4-6",
                prompt="Build",
                cwd=tmp_path,
            )
        )

        assert result is expected

    def test_get_copilot_stream_choices(self) -> None:
        assert get_copilot_stream_choices() == ("on", "off")


def datetime_to_ts(value: str) -> float:
    return gemini.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
