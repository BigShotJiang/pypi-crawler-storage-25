from __future__ import annotations

import stat
from pathlib import Path

from coding_cli_runtime.providers import (
    ProviderEventKind,
    copilot,
)


def _write_retrying_copilot_stub(tmp_path: Path) -> Path:
    stub_path = tmp_path / "copilot_retry_stub.sh"
    stub_path.write_text(
        """#!/usr/bin/env bash
set -euo pipefail

state_dir="${CKRT_STUB_STATE_DIR:?}"
mkdir -p "$state_dir"
attempt_file="$state_dir/attempt.txt"
attempt="0"
if [[ -f "$attempt_file" ]]; then
  attempt="$(cat "$attempt_file")"
fi
attempt="$((attempt + 1))"
printf '%s' "$attempt" >"$attempt_file"

if [[ "$attempt" -eq 1 ]]; then
  printf 'failed to list models: 429\\n' >&2
  exit 1
fi

printf 'STUB-COPILOT-OK\\n'
""",
        encoding="utf-8",
    )
    stub_path.chmod(stub_path.stat().st_mode | stat.S_IXUSR)
    return stub_path


def test_copilot_stub_retry_integration_records_retry_history(tmp_path: Path) -> None:
    stub_path = _write_retrying_copilot_stub(tmp_path)
    workdir = tmp_path / "copilot"
    workdir.mkdir()

    result = copilot.run_sync(
        copilot.CopilotExecRequest(
            model="claude-sonnet-4.6",
            prompt="Reply with exactly STUB-COPILOT-OK and nothing else. Do not use markdown.",
            cwd=workdir,
            binary=str(stub_path),
            transient_retries=1,
            transient_retry_backoff_seconds=0.0,
            env={"CKRT_STUB_STATE_DIR": str(tmp_path / "state")},
        )
    )

    assert result.raw_execution.returncode == 0
    assert result.parsed_output.output_source == "stdout"
    assert result.parsed_output.output_text.strip() == "STUB-COPILOT-OK"
    assert len(result.retry_history) == 1
    assert result.retry_history[0].category == "startup_rate_limited"


def test_copilot_stub_retry_integration_emits_attempt_recovery_and_parse_events(
    tmp_path: Path,
) -> None:
    stub_path = _write_retrying_copilot_stub(tmp_path)
    workdir = tmp_path / "copilot-events"
    workdir.mkdir()
    events = []

    result = copilot.run_sync(
        copilot.CopilotExecRequest(
            model="claude-sonnet-4.6",
            prompt="Reply with exactly STUB-COPILOT-OK and nothing else. Do not use markdown.",
            cwd=workdir,
            binary=str(stub_path),
            transient_retries=1,
            transient_retry_backoff_seconds=0.0,
            env={"CKRT_STUB_STATE_DIR": str(tmp_path / "state-events")},
            event_callback=events.append,
        )
    )

    assert result.parsed_output.output_text.strip() == "STUB-COPILOT-OK"
    assert [event.kind for event in events] == [
        ProviderEventKind.ATTEMPT_STARTED,
        ProviderEventKind.ATTEMPT_FINISHED,
        ProviderEventKind.RECOVERY_APPLIED,
        ProviderEventKind.ATTEMPT_STARTED,
        ProviderEventKind.ATTEMPT_FINISHED,
        ProviderEventKind.PARSE_FINISHED,
    ]
    assert events[0].data.max_cli_attempts == 2
    assert events[2].data.category == "startup_rate_limited"
