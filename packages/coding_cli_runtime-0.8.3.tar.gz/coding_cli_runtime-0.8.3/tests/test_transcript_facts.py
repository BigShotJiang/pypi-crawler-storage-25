from __future__ import annotations

from pathlib import Path

import pytest

from coding_cli_runtime import (
    CANONICAL_TRANSCRIPT_INPUTS,
    EMPTY_TRANSCRIPT_FACTS_V1,
    HUMAN_READABLE_TRANSCRIPT_SIDECARS,
    TranscriptFactsError,
    TranscriptFactsV1,
    derive_transcript_facts,
)

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "transcripts"


def test_canonical_transcript_inputs_cover_supported_coding_clis() -> None:
    assert CANONICAL_TRANSCRIPT_INPUTS == {
        "claude": "claude_conversation.jsonl",
        "codex": "codex_conversation.jsonl",
        "copilot": "copilot_conversation.jsonl",
        "gemini": "gemini_conversation.json",
    }
    assert HUMAN_READABLE_TRANSCRIPT_SIDECARS == {}


def test_derive_transcript_facts_copilot_fixture() -> None:
    facts = derive_transcript_facts("copilot", FIXTURES_DIR / "copilot_conversation.jsonl")

    assert facts == TranscriptFactsV1(
        assistant_messages=2,
        content_messages=1,
        reasoning_only_messages=1,
        mixed_messages=0,
        tool_execution_start_count=1,
        final_content="Final answer text.",
    )


def test_derive_transcript_facts_claude_fixture() -> None:
    facts = derive_transcript_facts("claude", FIXTURES_DIR / "claude_conversation.jsonl")

    assert facts == TranscriptFactsV1(
        assistant_messages=3,
        content_messages=1,
        reasoning_only_messages=0,
        mixed_messages=0,
        tool_execution_start_count=1,
        final_content="<html>done</html>",
    )


def test_derive_transcript_facts_gemini_fixture() -> None:
    facts = derive_transcript_facts("gemini", FIXTURES_DIR / "gemini_conversation.json")

    assert facts == TranscriptFactsV1(
        assistant_messages=2,
        content_messages=2,
        reasoning_only_messages=0,
        mixed_messages=0,
        tool_execution_start_count=1,
        final_content="<svg>done</svg>",
    )


def test_derive_transcript_facts_codex_fixture() -> None:
    facts = derive_transcript_facts("codex", FIXTURES_DIR / "codex_conversation.jsonl")

    assert facts == TranscriptFactsV1(
        assistant_messages=1,
        content_messages=1,
        reasoning_only_messages=0,
        mixed_messages=0,
        tool_execution_start_count=1,
        final_content='{"answer":"Final codex answer"}',
    )


def test_derive_transcript_facts_codex_legacy_response_completed_shape(tmp_path) -> None:
    transcript = tmp_path / "codex_conversation.jsonl"
    transcript.write_text(
        "\n".join(
            [
                '{"type":"session_meta","payload":{"id":"session-redacted"}}',
                (
                    '{"type":"response.completed","output_text":"Legacy codex answer",'
                    '"events":[{"type":"tool_call","name":"write_file"}]}'
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    facts = derive_transcript_facts("codex", transcript)

    assert facts == TranscriptFactsV1(
        assistant_messages=1,
        content_messages=1,
        reasoning_only_messages=0,
        mixed_messages=0,
        tool_execution_start_count=1,
        final_content="Legacy codex answer",
    )


def test_derive_transcript_facts_codex_agent_message_fallback(tmp_path) -> None:
    transcript = tmp_path / "codex_conversation.jsonl"
    transcript.write_text(
        "\n".join(
            [
                '{"type":"session_meta","payload":{"id":"session-redacted"}}',
                (
                    '{"type":"event_msg","payload":{"type":"agent_message",'
                    '"message":"Fallback codex answer","phase":"final_answer"}}'
                ),
                (
                    '{"type":"event_msg","payload":{"type":"task_complete",'
                    '"last_agent_message":"Fallback codex answer"}}'
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    facts = derive_transcript_facts("codex", transcript)

    assert facts == TranscriptFactsV1(
        assistant_messages=1,
        content_messages=1,
        reasoning_only_messages=0,
        mixed_messages=0,
        tool_execution_start_count=0,
        final_content="Fallback codex answer",
    )


def test_derive_transcript_facts_returns_empty_for_missing_or_none_inputs() -> None:
    assert (
        derive_transcript_facts("copilot", FIXTURES_DIR / "missing.jsonl")
        == EMPTY_TRANSCRIPT_FACTS_V1
    )
    assert derive_transcript_facts("copilot", None) == EMPTY_TRANSCRIPT_FACTS_V1


def test_derive_transcript_facts_raises_for_unknown_provider_ids() -> None:
    with pytest.raises(TranscriptFactsError, match="unsupported transcript facts provider"):
        derive_transcript_facts("unknown", FIXTURES_DIR / "copilot_conversation.jsonl")


def test_derive_transcript_facts_raises_for_malformed_existing_jsonl_transcript(tmp_path) -> None:
    transcript = tmp_path / "copilot_conversation.jsonl"
    transcript.write_text('{"type":"assistant.message"}\nnot-json\n', encoding="utf-8")

    with pytest.raises(TranscriptFactsError, match="invalid JSONL transcript"):
        derive_transcript_facts("copilot", transcript)


def test_derive_transcript_facts_raises_for_malformed_existing_json_transcript(tmp_path) -> None:
    transcript = tmp_path / "gemini_conversation.json"
    transcript.write_text("{not-json}", encoding="utf-8")

    with pytest.raises(TranscriptFactsError, match="invalid JSON transcript"):
        derive_transcript_facts("gemini", transcript)
