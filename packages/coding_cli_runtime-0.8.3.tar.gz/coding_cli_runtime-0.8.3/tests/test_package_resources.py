from __future__ import annotations

import os
import subprocess
import sys
from importlib.resources import files

from coding_cli_runtime import get_copilot_model_catalog, get_provider_spec, load_schema
from coding_cli_runtime.json_io import load_packaged_json_object


def test_packaged_schema_loads() -> None:
    schema = load_schema("normalized_run_result.v1")
    assert schema["type"] == "object"
    assert "properties" in schema


def test_packaged_copilot_baseline_loads() -> None:
    catalog = get_copilot_model_catalog()
    assert "claude-sonnet-4.5" in catalog
    assert "claude-opus-4.7" in catalog
    assert "goldeneye" in catalog
    assert "gpt-5.5" in catalog
    provider = get_provider_spec("copilot")
    model = provider.model("claude-sonnet-4.5")
    assert model is not None
    assert model.metadata["reasoningSchema"] == "thinking_budget"
    opus47 = provider.model("claude-opus-4.7")
    assert opus47 is not None
    assert opus47.metadata["reasoningSchema"] == "reasoning_effort"
    assert opus47.metadata["reasoningValue"] == "medium"
    assert opus47.metadata["defaultReasoning"] == "medium"
    assert opus47.metadata["supportedReasoningEfforts"] == ("medium",)
    assert opus47.control("model_reasoning") is None
    goldeneye = provider.model("goldeneye")
    assert goldeneye is not None
    goldeneye_reasoning = goldeneye.control("model_reasoning")
    assert goldeneye_reasoning is not None
    assert goldeneye_reasoning.choice_values() == ("low", "medium", "high")
    gpt55 = provider.model("gpt-5.5")
    assert gpt55 is not None
    assert gpt55.metadata["reasoningSchema"] == "reasoning_effort"
    assert gpt55.metadata["reasoningValue"] == "medium"
    assert gpt55.metadata["defaultReasoning"] == "medium"
    assert gpt55.metadata["supportedReasoningEfforts"] == (
        "low",
        "medium",
        "high",
        "xhigh",
    )
    gpt55_reasoning = gpt55.control("model_reasoning")
    assert gpt55_reasoning is not None
    assert gpt55_reasoning.choice_values() == ("low", "medium", "high", "xhigh")
    assert gpt55_reasoning.default == "medium"


def test_coding_cli_runtime_submodule_alias_loads_packaged_resources() -> None:
    payload = load_packaged_json_object("copilot_reasoning_baseline.json")
    assert "models" in payload
    assert "claude-sonnet-4.5" in payload["models"]
    assert payload["models"]["claude-opus-4.7"]["schema"] == "reasoning_effort"
    assert payload["models"]["claude-opus-4.7"]["supported_reasoning_efforts"] == ["medium"]
    assert payload["models"]["claude-opus-4.7"]["source_cli_version"] == "1.0.31"
    assert payload["models"]["gpt-5.5"]["supported_reasoning_efforts"] == [
        "low",
        "medium",
        "high",
        "xhigh",
    ]
    assert payload["models"]["gpt-5.5"]["source_cli_version"] == "1.0.36"


def test_companion_bundle_manifest_and_references_load() -> None:
    payload = load_packaged_json_object("companion_assets", "bundle", "manifest.json")
    assert payload["schema_version"] == "coding-cli-runtime.companion_bundle.v1"
    assert payload["preview"] is True
    assert payload["primary_assets"]["guide"] == "guide.md"
    guide_text = (
        files("coding_cli_runtime.companion_assets")
        .joinpath("bundle", "guide.md")
        .read_text(encoding="utf-8")
    )
    assert "artifact" in guide_text
    assert "conversation_log" in guide_text
    for reference_name in ("surface-map.md", "debugging.md"):
        reference_text = (
            files("coding_cli_runtime.companion_assets")
            .joinpath("bundle", "references", reference_name)
            .read_text(encoding="utf-8")
        )
        assert "app-generation" not in reference_text
        assert "compare-app" not in reference_text
        assert "data/artifacts_benchmark" not in reference_text


def test_subprocess_import_uses_packaged_runtime(tmp_path) -> None:
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    command = [
        sys.executable,
        "-c",
        (
            "import coding_cli_runtime, json;"
            "print(json.dumps({'path': coding_cli_runtime.__file__,"
            "'models': sorted(coding_cli_runtime.get_copilot_model_catalog())[:2]}))"
        ),
    ]
    result = subprocess.run(
        command,
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    assert result.returncode == 0, result.stderr
    assert "coding_cli_runtime" in result.stdout
    assert "models" in result.stdout
