"""Tests for provider_contracts module."""

from __future__ import annotations

import pytest

from coding_cli_runtime.contracts import AuthMode
from coding_cli_runtime.provider_contracts import (
    PromptTransport,
    ProviderContract,
    _build_non_interactive_run,
    build_env_overlay,
    get_provider_contract,
    render_prompt,
    resolve_config_paths,
)

ALL_PROVIDERS = ("claude", "codex", "gemini", "copilot")


# ── get_provider_contract ──────────────────────────────────────────────


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_get_provider_contract_returns_contract(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    assert isinstance(c, ProviderContract)
    assert c.provider_id == provider_id


def test_get_provider_contract_unknown_raises() -> None:
    with pytest.raises(ValueError, match="Unknown provider"):
        get_provider_contract("unknown_provider")


# ── Sub-contract consistency ───────────────────────────────────────────


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_git_repo_consistency(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    if c.headless.requires_git_repo:
        assert c.headless.skip_git_repo_flag is not None


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_permission_mode_consistency(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    a = c.headless.approval
    if a.permission_mode_flag is not None:
        assert len(a.permission_modes) > 0
        assert a.default_permission_mode in a.permission_modes


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_sandbox_consistency(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    s = c.headless.sandbox
    if s is not None:
        assert len(s.modes) > 0
        assert s.writable_mode in s.modes
        assert s.read_only_mode in s.modes


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_stream_consistency(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    h = c.headless
    if h.stream_flag is not None:
        assert h.stream_modes is not None
        assert len(h.stream_modes) > 0
        assert h.default_stream_mode in h.stream_modes


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_auth_modes_consistency(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    assert AuthMode.CLI_LOGIN in c.auth.supported_modes
    assert AuthMode.ENV in c.auth.supported_modes
    assert c.auth.default_mode in c.auth.supported_modes


# ── Auth fields ────────────────────────────────────────────────────────


@pytest.mark.parametrize("provider_id", ("claude", "codex", "gemini"))
def test_primary_auth_env_var_set(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    assert c.auth.api_key_env_var is not None


def test_copilot_byok_env_var() -> None:
    c = get_provider_contract("copilot")
    assert c.auth.api_key_env_var is None
    assert c.auth.byok_api_key_env_var == "COPILOT_PROVIDER_API_KEY"


# ── Paths ──────────────────────────────────────────────────────────────


@pytest.mark.parametrize("provider_id", ALL_PROVIDERS)
def test_config_dir_starts_with_tilde(provider_id: str) -> None:
    c = get_provider_contract(provider_id)
    assert c.paths.config_dir.startswith("~/")


# ── Prompt transport ──────────────────────────────────────────────────


def test_gemini_uses_stdin_with_activation() -> None:
    c = get_provider_contract("gemini")
    assert c.headless.prompt.delivery == "stdin_with_activation"
    assert c.headless.prompt.activation_args == ("--prompt", "")


def test_claude_uses_stdin_with_flag_alternative() -> None:
    c = get_provider_contract("claude")
    assert c.headless.prompt.delivery == "stdin"
    assert c.headless.prompt.flag == "-p"


def test_copilot_uses_flag_delivery() -> None:
    c = get_provider_contract("copilot")
    assert c.headless.prompt.delivery == "flag"
    assert c.headless.prompt.flag == "-p"


def test_codex_uses_stdin_delivery() -> None:
    c = get_provider_contract("codex")
    assert c.headless.prompt.delivery == "stdin"
    assert c.headless.prompt.flag is None


# ── Copilot activation_args ───────────────────────────────────────────


def test_copilot_activation_args() -> None:
    c = get_provider_contract("copilot")
    assert "--no-ask-user" in c.headless.activation_args
    assert "--no-custom-instructions" in c.headless.activation_args


# ── build_env_overlay ─────────────────────────────────────────────────


def test_build_env_overlay_claude_api_key() -> None:
    c = get_provider_contract("claude")
    overlay = build_env_overlay(c, api_key="sk-test")
    assert overlay == {"CLAUDE_API_KEY": "sk-test"}


def test_build_env_overlay_copilot_byok() -> None:
    c = get_provider_contract("copilot")
    overlay = build_env_overlay(c, api_key="byok-key")
    assert overlay == {"COPILOT_PROVIDER_API_KEY": "byok-key"}


def test_build_env_overlay_with_base_url() -> None:
    c = get_provider_contract("gemini")
    overlay = build_env_overlay(c, base_url="https://custom.example.com")
    assert overlay == {"GOOGLE_GEMINI_BASE_URL": "https://custom.example.com"}


def test_build_env_overlay_empty_when_no_values() -> None:
    c = get_provider_contract("claude")
    overlay = build_env_overlay(c)
    assert overlay == {}


def test_build_env_overlay_both_key_and_url() -> None:
    c = get_provider_contract("codex")
    overlay = build_env_overlay(c, api_key="sk-test", base_url="https://custom.example.com")
    assert overlay == {
        "OPENAI_API_KEY": "sk-test",
        "OPENAI_BASE_URL": "https://custom.example.com",
    }


# ── resolve_config_paths ─────────────────────────────────────────────


def test_resolve_config_paths_host() -> None:
    c = get_provider_contract("claude")
    host, effective = resolve_config_paths(c, containerized=False)
    assert not host.startswith("~")
    assert host == effective


def test_resolve_config_paths_containerized() -> None:
    c = get_provider_contract("claude")
    host, effective = resolve_config_paths(c, containerized=True)
    assert not host.startswith("~")
    assert effective == "/root/.claude"


# ── render_prompt ─────────────────────────────────────────────────────


def test_render_prompt_flag_delivery() -> None:
    transport = PromptTransport(delivery="flag", flag="-p", activation_args=())
    payload = render_prompt(transport, "hello")
    assert payload.args == ("-p", "hello")
    assert payload.stdin_text is None


def test_render_prompt_stdin_delivery() -> None:
    transport = PromptTransport(delivery="stdin", flag="-p", activation_args=())
    payload = render_prompt(transport, "hello")
    assert payload.args == ()
    assert payload.stdin_text == "hello"


def test_render_prompt_stdin_with_activation() -> None:
    transport = PromptTransport(
        delivery="stdin_with_activation", flag=None, activation_args=("--prompt", "")
    )
    payload = render_prompt(transport, "hello")
    assert payload.args == ("--prompt", "")
    assert payload.stdin_text == "hello"


def test_render_prompt_flag_delivery_missing_flag_raises() -> None:
    transport = PromptTransport(delivery="flag", flag=None, activation_args=())
    with pytest.raises(ValueError, match="flag is None"):
        render_prompt(transport, "hello")


# ── _build_non_interactive_run ────────────────────────────────────────


def test_builder_claude_command_shape() -> None:
    spec = _build_non_interactive_run("claude", model="claude-sonnet-4-6", prompt="do stuff")
    assert spec.cmd_parts[0] == "claude"
    assert "--print" in spec.cmd_parts
    assert "--model" in spec.cmd_parts
    assert "claude-sonnet-4-6" in spec.cmd_parts
    assert "--dangerously-skip-permissions" in spec.cmd_parts
    assert "--permission-mode" in spec.cmd_parts
    assert "bypassPermissions" in spec.cmd_parts
    assert spec.stdin_text == "do stuff"
    # prompt NOT in argv (stdin delivery)
    assert "do stuff" not in spec.cmd_parts
    # container_config_dir is always the container path regardless of containerized flag
    assert spec.container_config_dir == "/root/.claude"


def test_builder_codex_writable() -> None:
    spec = _build_non_interactive_run("codex", model="gpt-5.4", prompt="fix bug")
    assert "exec" in spec.cmd_parts
    assert "--full-auto" in spec.cmd_parts
    assert "--sandbox" in spec.cmd_parts
    assert "danger-full-access" in spec.cmd_parts
    assert "--skip-git-repo-check" in spec.cmd_parts
    assert spec.stdin_text == "fix bug"


def test_builder_codex_read_only() -> None:
    spec = _build_non_interactive_run(
        "codex", model="gpt-5.4", prompt="classify", codex_sandbox_mode="read-only"
    )
    assert "--sandbox" in spec.cmd_parts
    idx = list(spec.cmd_parts).index("--sandbox")
    assert spec.cmd_parts[idx + 1] == "read-only"
    assert "--full-auto" in spec.cmd_parts


def test_builder_gemini_activation_args() -> None:
    spec = _build_non_interactive_run("gemini", model="gemini-3-pro-preview", prompt="build app")
    assert "--yolo" in spec.cmd_parts
    assert "--prompt" in spec.cmd_parts
    idx = list(spec.cmd_parts).index("--prompt")
    assert spec.cmd_parts[idx + 1] == ""
    assert spec.stdin_text == "build app"


def test_builder_copilot_headless_flags() -> None:
    spec = _build_non_interactive_run("copilot", model="gpt-5.4", prompt="do task")
    assert "--no-ask-user" in spec.cmd_parts
    assert "--no-custom-instructions" in spec.cmd_parts
    assert "--allow-all" in spec.cmd_parts
    assert "--stream" in spec.cmd_parts
    assert "on" in spec.cmd_parts
    assert "-p" in spec.cmd_parts
    assert "do task" in spec.cmd_parts
    assert spec.stdin_text is None


def test_builder_copilot_stream_off() -> None:
    spec = _build_non_interactive_run("copilot", model="gpt-5.4", prompt="task", stream="off")
    idx = list(spec.cmd_parts).index("--stream")
    assert spec.cmd_parts[idx + 1] == "off"


def test_builder_claude_permission_mode_override() -> None:
    spec = _build_non_interactive_run(
        "claude", model="claude-sonnet-4-6", prompt="x", permission_mode="acceptEdits"
    )
    idx = list(spec.cmd_parts).index("--permission-mode")
    assert spec.cmd_parts[idx + 1] == "acceptEdits"


def test_builder_api_key_env_overlay() -> None:
    spec = _build_non_interactive_run("copilot", model="m", prompt="p", api_key="byok-key")
    assert spec.env_overlay == {"COPILOT_PROVIDER_API_KEY": "byok-key"}


def test_builder_extra_flags() -> None:
    spec = _build_non_interactive_run(
        "claude", model="m", prompt="p", extra_flags=("--verbose", "--foo")
    )
    assert "--verbose" in spec.cmd_parts
    assert "--foo" in spec.cmd_parts


def test_builder_binary_override() -> None:
    spec = _build_non_interactive_run("claude", model="m", prompt="p", binary="/custom/claude")
    assert spec.cmd_parts[0] == "/custom/claude"


def test_builder_env_overlay_empty_by_default() -> None:
    spec = _build_non_interactive_run("claude", model="m", prompt="p")
    assert spec.env_overlay == {}
