from __future__ import annotations

import json
import os
import shutil
import uuid
from pathlib import Path

import pytest

from coding_cli_runtime import derive_transcript_facts
from coding_cli_runtime.providers import claude, codex, copilot, gemini

_RUN_REAL_CLI_E2E = os.getenv("CKRT_RUN_REAL_CLI_E2E") == "1"
pytestmark = pytest.mark.skipif(
    not _RUN_REAL_CLI_E2E,
    reason="set CKRT_RUN_REAL_CLI_E2E=1 to run authenticated real-CLI output contract e2e tests",
)

_CLAUDE_SMOKE_MODEL = "claude-haiku-4-5-20251001"
_CODEX_SMOKE_MODEL = "gpt-5.4-mini"
_GEMINI_SMOKE_MODEL = "gemini-2.5-flash"
_COPILOT_SMOKE_MODEL = "gpt-5.4-mini"


def _require_binary(name: str) -> None:
    if shutil.which(name) is None:
        pytest.skip(f"{name} is not installed")


def _token(prefix: str) -> str:
    return f"CKRT-{prefix}-{uuid.uuid4().hex[:8]}"


def _claude_harmless_echo_prompt(marker: str) -> str:
    return (
        "This is a harmless smoke-test marker, not a secret or credential. "
        f"Reply with exactly {marker} and nothing else."
    )


def _gemini_harmless_json_prompt(token: str) -> str:
    return (
        "This is a harmless smoke-test marker, not a secret or credential. "
        f'Reply with exactly {{"token":"{token}"}} and nothing else. '
        "Output raw JSON only. Do not use markdown or code fences."
    )


def _run_gemini_live_request(
    request: gemini.GeminiExecRequest,
    *,
    timeout_retries: int = 1,
) -> gemini.GeminiExecResult:
    last_result: gemini.GeminiExecResult | None = None
    for _ in range(timeout_retries + 1):
        result = gemini.run_sync(request)
        last_result = result
        if not getattr(result.raw_result, "timed_out", False):
            return result
    assert last_result is not None
    return last_result


def test_real_claude_output_contract_round_trips_through_transcript_facts(tmp_path: Path) -> None:
    _require_binary("claude")
    workdir = tmp_path / "claude"
    workdir.mkdir()
    token = _token("CLAUDE-OUTPUT")
    transcript_path = workdir / "claude_conversation.jsonl"

    result = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(token),
            cwd=workdir,
            output_format="text",
            transcript_path=transcript_path,
            timeout_seconds=180,
        )
    )

    assert result.raw_execution.returncode == 0
    assert transcript_path.exists()
    assert token in result.raw_execution.stdout.decode("utf-8", errors="replace")

    facts = derive_transcript_facts("claude", transcript_path)
    assert facts.content_messages >= 1
    assert facts.final_content == token


def test_real_codex_output_contract_round_trips_through_transcript_facts(tmp_path: Path) -> None:
    _require_binary("codex")
    workdir = tmp_path / "codex"
    workdir.mkdir()
    token = _token("CODEX-OUTPUT")
    transcript_path = workdir / "codex_conversation.jsonl"
    schema_path = workdir / "schema.json"
    schema_path.write_text(
        json.dumps(
            {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            }
        )
        + "\n",
        encoding="utf-8",
    )

    result = codex.run_sync(
        codex.CodexExecRequest(
            model=_CODEX_SMOKE_MODEL,
            prompt=f'Reply with a JSON object where "answer" is exactly "{token}".',
            cwd=workdir,
            output_schema_path=schema_path,
            transcript_path=transcript_path,
            timeout_seconds=240,
            model_reasoning="medium",
        )
    )

    assert result.raw_execution.returncode == 0
    assert transcript_path.exists()
    assert result.parsed_output.parsed_payload is not None
    assert result.parsed_output.parsed_payload["answer"] == token
    assert result.parsed_output.parsed_payload["files"] == []

    facts = derive_transcript_facts("codex", transcript_path)
    assert facts.content_messages >= 1
    assert facts.final_content is not None
    assert json.loads(facts.final_content)["answer"] == token


def test_real_gemini_output_contract_round_trips_through_transcript_facts(tmp_path: Path) -> None:
    _require_binary("gemini")
    workdir = tmp_path / "gemini"
    workdir.mkdir()
    token = _token("GEMINI-OUTPUT")
    transcript_path = workdir / "gemini_conversation.json"

    result = _run_gemini_live_request(
        gemini.GeminiExecRequest(
            model=_GEMINI_SMOKE_MODEL,
            prompt=_gemini_harmless_json_prompt(token),
            cwd=workdir,
            transcript_path=transcript_path,
            timeout_seconds=180,
        )
    )

    assert result.raw_execution.returncode == 0
    assert transcript_path.exists()
    assert result.parsed_output.parsed_payload == {"token": token}

    facts = derive_transcript_facts("gemini", transcript_path)
    assert facts.content_messages >= 1
    assert facts.final_content is not None
    assert gemini.parse_output(facts.final_content).parsed_payload == {"token": token}


def test_real_copilot_output_contract_round_trips_through_transcript_facts(tmp_path: Path) -> None:
    _require_binary("copilot")
    workdir = tmp_path / "copilot"
    workdir.mkdir()
    token = _token("COPILOT-OUTPUT")
    transcript_path = workdir / "copilot_conversation.jsonl"

    result = copilot.run_sync(
        copilot.CopilotExecRequest(
            model=_COPILOT_SMOKE_MODEL,
            prompt=f"Reply with exactly {token} and nothing else. Do not use markdown.",
            cwd=workdir,
            transcript_path=transcript_path,
            reasoning_effort="medium",
            timeout_seconds=240,
        )
    )

    assert result.raw_execution.returncode == 0
    assert transcript_path.exists()
    assert result.parsed_output.output_source == "stdout"
    assert token in result.parsed_output.output_text

    facts = derive_transcript_facts("copilot", transcript_path)
    assert facts.content_messages >= 1
    assert facts.final_content == token
