"""Tests for the three-tier catalog resolution and session defaults."""

from __future__ import annotations

import inspect
import json
import logging
from pathlib import Path

import pytest

from coding_cli_runtime.provider_specs import (
    ModelSpec,
    _config_dir,
    _load_codex_live_catalog,
    _load_user_provider_override,
    _parse_model_specs_from_raw,
    _resolve_models,
    get_provider_spec,
)
from coding_cli_runtime.session_execution import run_interactive_session

# ---------------------------------------------------------------------------
# _parse_model_specs_from_raw
# ---------------------------------------------------------------------------


def test_parse_bare_string_models() -> None:
    models = _parse_model_specs_from_raw(["alpha", "beta"])
    assert len(models) == 2
    assert models[0].name == "alpha"
    assert models[1].name == "beta"


def test_parse_dict_models_with_controls() -> None:
    raw = [
        {
            "name": "my-model",
            "description": "Custom model",
            "controls": [
                {
                    "name": "reasoning",
                    "kind": "choice",
                    "label": "Reasoning",
                    "choices": [{"value": "low"}, {"value": "high"}],
                    "default": "low",
                }
            ],
            "metadata": {"custom": True},
        }
    ]
    models = _parse_model_specs_from_raw(raw)
    assert len(models) == 1
    m = models[0]
    assert m.name == "my-model"
    assert m.description == "Custom model"
    assert m.metadata == {"custom": True}
    ctrl = m.control("reasoning")
    assert ctrl is not None
    assert ctrl.choice_values() == ("low", "high")
    assert ctrl.default == "low"


def test_parse_skips_invalid_entries() -> None:
    models = _parse_model_specs_from_raw([42, None, {"no_name_key": True}, "valid"])
    assert len(models) == 1
    assert models[0].name == "valid"


def test_parse_string_choices() -> None:
    raw = [
        {
            "name": "m",
            "controls": [
                {"name": "c", "choices": ["a", "b"]},
            ],
        }
    ]
    models = _parse_model_specs_from_raw(raw)
    ctrl = models[0].control("c")
    assert ctrl is not None
    assert ctrl.choice_values() == ("a", "b")


# ---------------------------------------------------------------------------
# _load_user_provider_override
# ---------------------------------------------------------------------------


def test_user_override_file_not_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    assert _load_user_provider_override("claude") is None


def test_user_override_loads_valid_json(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    override_dir = tmp_path / "providers"
    override_dir.mkdir()
    (override_dir / "claude.json").write_text(
        json.dumps(
            {
                "default_model": "claude-custom-7",
                "models": ["claude-custom-7", "claude-old-6"],
            }
        )
    )
    result = _load_user_provider_override("claude")
    assert result is not None
    models, default = result
    assert len(models) == 2
    assert models[0].name == "claude-custom-7"
    assert default == "claude-custom-7"


def test_user_override_ignores_malformed_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    override_dir = tmp_path / "providers"
    override_dir.mkdir()
    (override_dir / "gemini.json").write_text("not json at all {{{")
    assert _load_user_provider_override("gemini") is None


def test_user_override_ignores_empty_models(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    override_dir = tmp_path / "providers"
    override_dir.mkdir()
    (override_dir / "codex.json").write_text(json.dumps({"models": []}))
    assert _load_user_provider_override("codex") is None


# ---------------------------------------------------------------------------
# _config_dir
# ---------------------------------------------------------------------------


def test_config_dir_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("CODING_CLI_RUNTIME_CONFIG_DIR", raising=False)
    d = _config_dir()
    assert d == Path("~/.config/coding-cli-runtime").expanduser()


def test_config_dir_env_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", "/tmp/my-overrides")
    assert _config_dir() == Path("/tmp/my-overrides")


# ---------------------------------------------------------------------------
# _load_codex_live_catalog
# ---------------------------------------------------------------------------


def test_codex_live_catalog_parses_valid_cache(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache = {
        "fetched_at": "2026-04-07T00:00:00Z",
        "models": [
            {
                "slug": "gpt-6",
                "description": "Next gen.",
                "default_reasoning_level": "high",
                "supported_reasoning_levels": [
                    {"effort": "low"},
                    {"effort": "high"},
                ],
                "visibility": "list",
                "priority": 0,
                "supported_in_api": True,
            },
            {
                "slug": "gpt-6-spark",
                "supported_in_api": False,
            },
        ],
    }
    cache_path = tmp_path / "models_cache.json"
    cache_path.write_text(json.dumps(cache))
    monkeypatch.setattr("coding_cli_runtime.provider_specs._CODEX_CACHE_PATH", cache_path)
    result = _load_codex_live_catalog()
    assert result is not None
    assert len(result) == 1  # gpt-6-spark filtered out
    assert result[0].name == "gpt-6"
    assert result[0].description == "Next gen."
    reasoning = result[0].control("model_reasoning")
    assert reasoning is not None
    assert reasoning.choice_values() == ("low", "high")
    assert reasoning.default == "high"


def test_codex_live_catalog_returns_none_on_missing_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        "coding_cli_runtime.provider_specs._CODEX_CACHE_PATH",
        tmp_path / "nonexistent.json",
    )
    assert _load_codex_live_catalog() is None


def test_codex_live_catalog_returns_none_on_bad_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache_path = tmp_path / "models_cache.json"
    cache_path.write_text("{bad json")
    monkeypatch.setattr("coding_cli_runtime.provider_specs._CODEX_CACHE_PATH", cache_path)
    assert _load_codex_live_catalog() is None


def test_codex_live_catalog_returns_none_on_unexpected_schema(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache_path = tmp_path / "models_cache.json"
    cache_path.write_text(json.dumps({"models": "not-a-list"}))
    monkeypatch.setattr("coding_cli_runtime.provider_specs._CODEX_CACHE_PATH", cache_path)
    assert _load_codex_live_catalog() is None


# ---------------------------------------------------------------------------
# _resolve_models  (three-tier: user override > live > hardcoded)
# ---------------------------------------------------------------------------


def test_resolve_uses_hardcoded_when_no_override_or_live(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    hardcoded = (ModelSpec(name="fallback"),)
    models, default = _resolve_models("test-provider", hardcoded=hardcoded)
    assert models is hardcoded
    assert default is None


def test_resolve_prefers_live_over_hardcoded(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    live = (ModelSpec(name="live-model"),)
    hardcoded = (ModelSpec(name="fallback"),)
    models, default = _resolve_models(
        "test-provider", live_loader=lambda: live, hardcoded=hardcoded
    )
    assert models is live
    assert default is None


def test_resolve_prefers_user_override_over_live(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    override_dir = tmp_path / "providers"
    override_dir.mkdir()
    (override_dir / "test-provider.json").write_text(
        json.dumps({"models": ["user-model"], "default_model": "user-model"})
    )
    live = (ModelSpec(name="live-model"),)
    hardcoded = (ModelSpec(name="fallback"),)
    models, default = _resolve_models(
        "test-provider", live_loader=lambda: live, hardcoded=hardcoded
    )
    assert len(models) == 1
    assert models[0].name == "user-model"
    assert default == "user-model"


def test_resolve_falls_through_when_live_returns_none(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path))
    hardcoded = (ModelSpec(name="fallback"),)
    models, default = _resolve_models(
        "test-provider", live_loader=lambda: None, hardcoded=hardcoded
    )
    assert models is hardcoded


def test_codex_provider_defaults_to_highest_priority_visible_live_model(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache = {
        "fetched_at": "2026-04-24T10:17:11Z",
        "models": [
            {
                "slug": "hidden-review",
                "description": "Hidden review model.",
                "default_reasoning_level": "medium",
                "supported_reasoning_levels": [
                    {"effort": "low"},
                    {"effort": "medium"},
                ],
                "visibility": "hide",
                "priority": 20,
                "supported_in_api": True,
            },
            {
                "slug": "gpt-5.4",
                "description": "Everyday coding model.",
                "default_reasoning_level": "medium",
                "supported_reasoning_levels": [
                    {"effort": "low"},
                    {"effort": "medium"},
                    {"effort": "high"},
                    {"effort": "xhigh"},
                ],
                "visibility": "list",
                "priority": 5,
                "supported_in_api": True,
            },
            {
                "slug": "gpt-5.5",
                "description": "Frontier coding model.",
                "default_reasoning_level": "medium",
                "supported_reasoning_levels": [
                    {"effort": "low"},
                    {"effort": "medium"},
                    {"effort": "high"},
                    {"effort": "xhigh"},
                ],
                "visibility": "list",
                "priority": 0,
                "supported_in_api": True,
            },
        ],
    }
    cache_path = tmp_path / "models_cache.json"
    cache_path.write_text(json.dumps(cache))
    monkeypatch.setenv("CODING_CLI_RUNTIME_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.setattr("coding_cli_runtime.provider_specs._CODEX_CACHE_PATH", cache_path)
    monkeypatch.setattr(
        "coding_cli_runtime.provider_specs._load_user_provider_override",
        lambda _provider: None,
    )

    from coding_cli_runtime import provider_specs as provider_specs_mod

    provider_specs_mod.provider_specs_by_id.cache_clear()
    provider_specs_mod.list_provider_specs.cache_clear()
    try:
        provider = get_provider_spec("codex")
    finally:
        provider_specs_mod.provider_specs_by_id.cache_clear()
        provider_specs_mod.list_provider_specs.cache_clear()

    assert provider.model_source == "codex_cli_cache"
    assert provider.default_model == "gpt-5.5"


# ---------------------------------------------------------------------------
# run_interactive_session: observability param defaults
# ---------------------------------------------------------------------------


def test_run_interactive_session_defaults_are_optional() -> None:
    """All observability params should have defaults in the signature."""
    sig = inspect.signature(run_interactive_session)
    for name in ("provider_label", "job_name", "phase_tag", "process_label", "timeout_seconds"):
        param = sig.parameters[name]
        assert param.default is not inspect.Parameter.empty, f"{name} should have a default value"


@pytest.mark.asyncio
async def test_run_interactive_session_works_with_minimal_args() -> None:
    """Calling with only the required params should succeed (not raise TypeError)."""
    import sys

    result = await run_interactive_session(
        cmd_parts=[sys.executable, "-c", "print('hello')"],
        cwd=Path.cwd(),
        stdin_text=None,
        logger=logging.getLogger("test"),
    )
    assert result.returncode == 0
    assert b"hello" in result.stdout
