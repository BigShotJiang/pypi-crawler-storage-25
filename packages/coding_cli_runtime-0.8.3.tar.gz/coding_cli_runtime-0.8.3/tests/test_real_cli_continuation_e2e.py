from __future__ import annotations

import json
import os
import shutil
import uuid
from pathlib import Path

import pytest

from coding_cli_runtime.providers import claude, codex, copilot, gemini
from coding_cli_runtime.providers._types import ProviderContinuationMode

_RUN_REAL_CLI_E2E = os.getenv("CKRT_RUN_REAL_CLI_E2E") == "1"
pytestmark = pytest.mark.skipif(
    not _RUN_REAL_CLI_E2E,
    reason="set CKRT_RUN_REAL_CLI_E2E=1 to run authenticated real-CLI continuation e2e tests",
)

_CLAUDE_SMOKE_MODEL = "claude-haiku-4-5-20251001"
_CODEX_SMOKE_MODEL = "gpt-5.4-mini"
_GEMINI_SMOKE_MODEL = "gemini-2.5-flash"
_COPILOT_SMOKE_MODEL = "gpt-5.4-mini"


def _require_binary(name: str) -> None:
    if shutil.which(name) is None:
        pytest.skip(f"{name} is not installed")


def _token(prefix: str) -> str:
    return f"CKRT-{prefix}-{uuid.uuid4().hex[:8]}"


def _claude_harmless_echo_prompt(marker: str) -> str:
    return (
        "This is a harmless smoke-test marker, not a secret or credential. "
        f"Reply with exactly {marker} and nothing else."
    )


def _gemini_harmless_json_prompt(token: str) -> str:
    return (
        "This is a harmless smoke-test marker, not a secret or credential. "
        f'Reply with exactly {{"token":"{token}"}} and nothing else. '
        "Output raw JSON only. Do not use markdown or code fences."
    )


def _run_gemini_live_request(
    request: gemini.GeminiExecRequest,
    *,
    timeout_retries: int = 1,
) -> gemini.GeminiExecResult:
    last_result: gemini.GeminiExecResult | None = None
    for _ in range(timeout_retries + 1):
        result = gemini.run_sync(request)
        last_result = result
        if not getattr(result.raw_result, "timed_out", False):
            return result
    assert last_result is not None
    return last_result


def test_real_claude_session_id_continuation(tmp_path: Path) -> None:
    _require_binary("claude")
    workdir = tmp_path / "claude"
    workdir.mkdir()
    first_token = _token("CLAUDE-FRESH")
    second_token = _token("CLAUDE-RESUME")

    first = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(first_token),
            cwd=workdir,
            output_format="text",
            timeout_seconds=180,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.session_id is not None
    assert first_token in first.raw_execution.stdout.decode("utf-8", errors="replace")

    resumed = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(second_token),
            cwd=workdir,
            output_format="text",
            timeout_seconds=180,
            continuation_mode=ProviderContinuationMode.SESSION_ID,
            session_id=first.session_lookup.session_id,
        )
    )
    assert resumed.continuation_resolution.resolved_session_id == first.session_lookup.session_id
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert second_token in resumed.raw_execution.stdout.decode("utf-8", errors="replace")


def test_real_claude_continue_latest_picks_newest_session(tmp_path: Path) -> None:
    _require_binary("claude")
    workdir = tmp_path / "claude-latest"
    workdir.mkdir()
    first_token = _token("CLAUDE-LATEST-OLD")
    second_token = _token("CLAUDE-LATEST-NEW")
    resume_token = _token("CLAUDE-LATEST-RESUME")

    first = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(first_token),
            cwd=workdir,
            output_format="text",
            timeout_seconds=180,
        )
    )
    second = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(second_token),
            cwd=workdir,
            output_format="text",
            timeout_seconds=180,
        )
    )

    assert first.session_lookup is not None
    assert first.session_lookup.session_id is not None
    assert second.session_lookup is not None
    assert second.session_lookup.session_id is not None
    assert first.session_lookup.session_id != second.session_lookup.session_id

    resumed = claude.run_sync(
        claude.ClaudeExecRequest(
            model=_CLAUDE_SMOKE_MODEL,
            prompt=_claude_harmless_echo_prompt(resume_token),
            cwd=workdir,
            output_format="text",
            timeout_seconds=180,
            continuation_mode=ProviderContinuationMode.CONTINUE_LATEST,
        )
    )
    assert resumed.continuation_resolution.resolved_session_id == second.session_lookup.session_id
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == second.session_lookup.path
    assert resume_token in resumed.raw_execution.stdout.decode("utf-8", errors="replace")


def test_real_copilot_session_path_continuation(tmp_path: Path) -> None:
    _require_binary("copilot")
    workdir = tmp_path / "copilot"
    workdir.mkdir()
    first_token = _token("COPILOT-FRESH")
    second_token = _token("COPILOT-RESUME")

    first = copilot.run_sync(
        copilot.CopilotExecRequest(
            model=_COPILOT_SMOKE_MODEL,
            prompt=f"Reply with exactly {first_token} and nothing else. Do not use markdown.",
            cwd=workdir,
            reasoning_effort="medium",
            timeout_seconds=240,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None
    assert first.parsed_output.output_source == "stdout"
    assert first_token in first.parsed_output.output_text

    resumed = copilot.run_sync(
        copilot.CopilotExecRequest(
            model=_COPILOT_SMOKE_MODEL,
            prompt=f"Reply with exactly {second_token} and nothing else. Do not use markdown.",
            cwd=workdir,
            reasoning_effort="medium",
            timeout_seconds=240,
            continuation_mode=ProviderContinuationMode.SESSION_PATH,
            session_path=first.session_lookup.path,
        )
    )
    assert resumed.continuation_resolution.resolved_session_path == first.session_lookup.path
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert resumed.parsed_output.output_source == "stdout"
    assert second_token in resumed.parsed_output.output_text


def test_real_copilot_cross_workdir_session_path_rejected(tmp_path: Path) -> None:
    _require_binary("copilot")
    source_workdir = tmp_path / "copilot-source"
    source_workdir.mkdir()
    other_workdir = tmp_path / "copilot-other"
    other_workdir.mkdir()
    first_token = _token("COPILOT-CROSS")

    first = copilot.run_sync(
        copilot.CopilotExecRequest(
            model=_COPILOT_SMOKE_MODEL,
            prompt=f"Reply with exactly {first_token} and nothing else. Do not use markdown.",
            cwd=source_workdir,
            reasoning_effort="medium",
            timeout_seconds=240,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None

    with pytest.raises(ValueError, match="belongs to a different workdir"):
        copilot.prepare_launch(
            copilot.CopilotExecRequest(
                model=_COPILOT_SMOKE_MODEL,
                prompt="This should not run.",
                cwd=other_workdir,
                reasoning_effort="medium",
                continuation_mode=ProviderContinuationMode.SESSION_PATH,
                session_path=first.session_lookup.path,
            )
        )


def test_real_gemini_session_path_continuation(tmp_path: Path) -> None:
    _require_binary("gemini")
    workdir = tmp_path / "gemini"
    workdir.mkdir()
    first_token = _token("GEMINI-FRESH")
    second_token = _token("GEMINI-RESUME")

    first = _run_gemini_live_request(
        gemini.GeminiExecRequest(
            model=_GEMINI_SMOKE_MODEL,
            prompt=_gemini_harmless_json_prompt(first_token),
            cwd=workdir,
            timeout_seconds=180,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None
    assert first.parsed_output.parsed_payload == {"token": first_token}

    resumed = _run_gemini_live_request(
        gemini.GeminiExecRequest(
            model=_GEMINI_SMOKE_MODEL,
            prompt=_gemini_harmless_json_prompt(second_token),
            cwd=workdir,
            timeout_seconds=180,
            continuation_mode=ProviderContinuationMode.SESSION_PATH,
            session_path=first.session_lookup.path,
        )
    )
    assert resumed.continuation_resolution.resolved_session_path == first.session_lookup.path
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert resumed.parsed_output.parsed_payload == {"token": second_token}


def test_real_gemini_session_id_continuation(tmp_path: Path) -> None:
    _require_binary("gemini")
    workdir = tmp_path / "gemini-session-id"
    workdir.mkdir()
    first_token = _token("GEMINI-ID-FRESH")
    second_token = _token("GEMINI-ID-RESUME")

    first = _run_gemini_live_request(
        gemini.GeminiExecRequest(
            model=_GEMINI_SMOKE_MODEL,
            prompt=_gemini_harmless_json_prompt(first_token),
            cwd=workdir,
            timeout_seconds=180,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None
    first_session_payload = json.loads(first.session_lookup.path.read_text(encoding="utf-8"))
    first_session_id = first_session_payload["sessionId"]

    resumed = _run_gemini_live_request(
        gemini.GeminiExecRequest(
            model=_GEMINI_SMOKE_MODEL,
            prompt=_gemini_harmless_json_prompt(second_token),
            cwd=workdir,
            timeout_seconds=180,
            continuation_mode=ProviderContinuationMode.SESSION_ID,
            session_id=first_session_id,
        )
    )
    assert resumed.continuation_resolution.resolved_session_id == first_session_id
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert resumed.parsed_output.parsed_payload == {"token": second_token}


def test_real_codex_fresh_schema_and_resume_without_schema(tmp_path: Path) -> None:
    _require_binary("codex")
    workdir = tmp_path / "codex"
    workdir.mkdir()
    schema_path = workdir / "schema.json"
    schema_path.write_text(
        json.dumps(
            {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            }
        ),
        encoding="utf-8",
    )
    first_token = _token("CODEX-FRESH")
    second_token = _token("CODEX-RESUME")

    first = codex.run_sync(
        codex.CodexExecRequest(
            model=_CODEX_SMOKE_MODEL,
            prompt=(
                f"Reply with a JSON object matching the schema where "
                f'"answer" is exactly "{first_token}".'
            ),
            cwd=workdir,
            output_schema_path=schema_path,
            model_reasoning="medium",
            timeout_seconds=240,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None
    assert first.parsed_output.parsed_payload is not None
    assert first.parsed_output.parsed_payload["answer"] == first_token

    with pytest.raises(ValueError, match="does not support native --output-schema"):
        codex.prepare_launch(
            codex.CodexExecRequest(
                model=_CODEX_SMOKE_MODEL,
                prompt="This should fail",
                cwd=workdir,
                output_schema_path=schema_path,
                continuation_mode=ProviderContinuationMode.SESSION_PATH,
                session_path=first.session_lookup.path,
                model_reasoning="medium",
            )
        )

    resumed = codex.run_sync(
        codex.CodexExecRequest(
            model=_CODEX_SMOKE_MODEL,
            prompt=(f'Reply with exactly {{"answer":"{second_token}"}} and nothing else.'),
            cwd=workdir,
            continuation_mode=ProviderContinuationMode.SESSION_PATH,
            session_path=first.session_lookup.path,
            model_reasoning="medium",
            timeout_seconds=240,
        )
    )
    assert resumed.continuation_resolution.resolved_session_path == first.session_lookup.path
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert resumed.parsed_output.parsed_payload is not None
    assert resumed.parsed_output.parsed_payload["answer"] == second_token


def test_real_codex_session_id_continuation(tmp_path: Path) -> None:
    _require_binary("codex")
    workdir = tmp_path / "codex-session-id"
    workdir.mkdir()
    schema_path = workdir / "schema.json"
    schema_path.write_text(
        json.dumps(
            {
                "type": "object",
                "properties": {"answer": {"type": "string"}},
                "required": ["answer"],
                "additionalProperties": False,
            }
        ),
        encoding="utf-8",
    )
    first_token = _token("CODEX-ID-FRESH")
    second_token = _token("CODEX-ID-RESUME")

    first = codex.run_sync(
        codex.CodexExecRequest(
            model=_CODEX_SMOKE_MODEL,
            prompt=(
                f"Reply with a JSON object matching the schema where "
                f'"answer" is exactly "{first_token}".'
            ),
            cwd=workdir,
            output_schema_path=schema_path,
            model_reasoning="medium",
            timeout_seconds=240,
        )
    )
    assert first.session_lookup is not None
    assert first.session_lookup.path is not None
    assert first.session_lookup.matched_by == "cwd"

    with first.session_lookup.path.open("r", encoding="utf-8") as handle:
        session_id = None
        for line in handle:
            payload = json.loads(line)
            data = payload.get("payload")
            if isinstance(data, dict) and isinstance(data.get("id"), str):
                session_id = data["id"]
                break
    assert isinstance(session_id, str) and session_id

    resumed = codex.run_sync(
        codex.CodexExecRequest(
            model=_CODEX_SMOKE_MODEL,
            prompt=(f'Reply with exactly {{"answer":"{second_token}"}} and nothing else.'),
            cwd=workdir,
            continuation_mode=ProviderContinuationMode.SESSION_ID,
            session_id=session_id,
            model_reasoning="medium",
            timeout_seconds=240,
        )
    )
    assert resumed.continuation_resolution.resolved_session_id == session_id
    assert resumed.session_lookup is not None
    assert resumed.session_lookup.path == first.session_lookup.path
    assert resumed.parsed_output.parsed_payload is not None
    assert resumed.parsed_output.parsed_payload["answer"] == second_token
