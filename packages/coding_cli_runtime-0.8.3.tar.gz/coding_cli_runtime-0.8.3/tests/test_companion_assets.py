from __future__ import annotations

import json
from pathlib import Path

import pytest

from coding_cli_runtime import __version__
from coding_cli_runtime.companion_assets import (
    COMPANION_BUNDLE_SCHEMA_VERSION,
    DEFAULT_CODEX_SKILL_NAME,
    CompanionAssetError,
    export_companion_bundle,
    install_codex_skill,
    load_companion_bundle_manifest,
)


def test_load_companion_bundle_manifest_includes_package_version() -> None:
    manifest = load_companion_bundle_manifest()
    assert manifest["schema_version"] == COMPANION_BUNDLE_SCHEMA_VERSION
    assert manifest["package_version"] == __version__
    assert manifest["export_targets"]["codex_skill"]["name"] == DEFAULT_CODEX_SKILL_NAME


def test_load_companion_bundle_manifest_fails_closed_on_schema_mismatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "coding_cli_runtime.companion_assets.load_packaged_json_object",
        lambda *parts: {"schema_version": "unexpected"},
    )
    with pytest.raises(CompanionAssetError):
        load_companion_bundle_manifest()


def test_export_companion_bundle_copies_bundle_and_replaces_stale_files(tmp_path: Path) -> None:
    destination = tmp_path / "bundle"
    destination.mkdir()
    stale_path = destination / "stale.txt"
    stale_path.write_text("stale", encoding="utf-8")

    exported = export_companion_bundle(destination, force=True)

    assert exported == destination.resolve()
    assert not stale_path.exists()
    manifest = json.loads((destination / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["package_version"] == __version__
    assert (destination / "guide.md").exists()
    assert (destination / "references" / "surface-map.md").exists()


def test_install_codex_skill_writes_skill_and_references(tmp_path: Path) -> None:
    destination_root = tmp_path / "skills"

    skill_dir = install_codex_skill(destination_root=destination_root)

    assert skill_dir == destination_root.resolve() / DEFAULT_CODEX_SKILL_NAME
    skill_text = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
    assert skill_text.startswith("---\nname: coding-cli-runtime\n")
    assert "preview `coding-cli-runtime` companion bundle" in skill_text
    assert "references/surface-map.md" in skill_text
    assert (skill_dir / "references" / "surface-map.md").exists()
    assert (skill_dir / "references" / "debugging.md").exists()
