from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import stat
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _load_transcript_probe_module():
    script_path = (
        _repo_root()
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "transcript-probes"
        / "run_probe.py"
    )
    spec = importlib.util.spec_from_file_location("transcript_probe_run_probe", script_path)
    module = importlib.util.module_from_spec(spec)
    assert spec is not None and spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _write_copilot_stub(tmp_path: Path) -> Path:
    stub_path = tmp_path / "copilot_stub.sh"
    stub_path.write_text(
        """#!/usr/bin/env bash
set -euo pipefail

printf 'stub-output\\n'
printf 'stub-stderr\\n' >&2
""",
        encoding="utf-8",
    )
    stub_path.chmod(stub_path.stat().st_mode | stat.S_IXUSR)
    return stub_path


def _run_subprocess(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
    return completed


def test_copilot_reasoning_probe_dry_run_uses_package_local_results(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "copilot-cli"
        / "experiments"
        / "reasoning_effort_probe.py"
    )
    results_root = script_path.parent / "results"
    before = set(results_root.glob("reasoning_probe_*")) if results_root.exists() else set()

    completed = _run_subprocess(
        [
            sys.executable,
            str(script_path),
            "--dry-run",
            "--max-models",
            "1",
            "--max-prompts",
            "1",
        ],
        cwd=tmp_path,
    )

    match = re.search(r"^Output dir:\s+(.+)$", completed.stdout, re.MULTILINE)
    assert match, completed.stdout
    output_dir = Path(match.group(1).strip())
    assert output_dir.parent == results_root
    assert output_dir.exists()
    assert (output_dir / "manifest.json").exists()
    assert (output_dir / "raw").is_dir()

    after = set(results_root.glob("reasoning_probe_*")) if results_root.exists() else set()
    created = after - before
    assert output_dir in created or output_dir.exists()
    shutil.rmtree(output_dir)


def test_claude_effort_probe_dry_run_uses_package_local_results(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "claude-code"
        / "experiments"
        / "effort_probe.py"
    )
    results_root = script_path.parent / "results"
    before = set(results_root.glob("effort_probe_*")) if results_root.exists() else set()

    completed = _run_subprocess(
        [
            sys.executable,
            str(script_path),
            "--dry-run",
            "--model",
            "claude-opus-4-6",
            "--effort",
            "low",
            "--method",
            "flag",
        ],
        cwd=tmp_path,
    )

    match = re.search(r"^\[dry-run\] output_dir=(.+)$", completed.stdout, re.MULTILINE)
    assert match, completed.stdout
    output_dir = Path(match.group(1).strip())
    assert output_dir.parent == results_root
    assert output_dir.exists()
    assert (output_dir / "raw").is_dir()

    after = set(results_root.glob("effort_probe_*")) if results_root.exists() else set()
    created = after - before
    assert output_dir in created or output_dir.exists()
    shutil.rmtree(output_dir)


def test_transcript_probe_dry_run_uses_package_local_results(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "transcript-probes"
        / "run_probe.py"
    )
    results_root = script_path.parent / "results"
    before = set(results_root.glob("transcript_probe_*")) if results_root.exists() else set()

    completed = _run_subprocess(
        [
            sys.executable,
            str(script_path),
            "--dry-run",
            "--provider",
            "claude",
            "--provider",
            "codex",
            "--provider",
            "gemini",
            "--provider",
            "copilot",
        ],
        cwd=tmp_path,
    )

    match = re.search(r"^Output dir:\s+(.+)$", completed.stdout, re.MULTILINE)
    assert match, completed.stdout
    output_dir = Path(match.group(1).strip())
    assert output_dir.parent == results_root
    assert output_dir.exists()
    assert (output_dir / "manifest.json").exists()
    assert (output_dir / "run_report.md").exists()
    assert (output_dir / "raw").is_dir()

    manifest = json.loads((output_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["providers_requested"] == ["claude", "codex", "gemini", "copilot"]
    assert [entry["status"] for entry in manifest["results"]] == [
        "dry_run",
        "dry_run",
        "dry_run",
        "dry_run",
    ]

    after = set(results_root.glob("transcript_probe_*")) if results_root.exists() else set()
    created = after - before
    assert output_dir in created or output_dir.exists()
    shutil.rmtree(output_dir)


def test_transcript_probe_marks_nonzero_provider_result_as_failed(tmp_path, monkeypatch) -> None:
    probe_module = _load_transcript_probe_module()
    output_dir = tmp_path / "probe-output"

    class _Failure:
        category = "rate_limited"

    class _RawExecution:
        returncode = 1
        stdout = b""
        stderr = b"rate limited"

    class _Result:
        raw_execution = _RawExecution()
        failure_classification = _Failure()

    monkeypatch.setattr(
        probe_module,
        "_run_version_command",
        lambda _binary: probe_module.VersionCommandResult(
            command=("claude", "--version"),
            returncode=0,
            parsed_version="1.2.3",
            stdout_text="claude 1.2.3",
            stderr_text="",
        ),
    )
    monkeypatch.setattr(probe_module, "_build_request", lambda *args, **kwargs: object())
    monkeypatch.setattr(probe_module.claude, "run_sync", lambda _request: _Result())

    entry = probe_module._run_provider_probe(
        provider="claude",
        binary="claude",
        model="claude-haiku-4-5-20251001",
        prompt=(
            "This is a harmless smoke-test marker, not a secret or credential. "
            "Reply with exactly CLAUDE-PROBE-OK and nothing else."
        ),
        output_dir=output_dir,
        timeout_seconds=30.0,
    )

    assert entry["status"] == "failed"
    assert entry["returncode"] == 1
    assert entry["failure_classification"] == "rate_limited"


def test_transcript_probe_main_returns_nonzero_when_any_provider_failed(
    tmp_path, monkeypatch
) -> None:
    probe_module = _load_transcript_probe_module()
    output_dir = tmp_path / "probe-output"

    monkeypatch.setattr(
        probe_module,
        "parse_args",
        lambda: argparse.Namespace(
            output_dir=str(output_dir),
            providers=["claude"],
            claude_bin="claude",
            codex_bin="codex",
            gemini_bin="gemini",
            copilot_bin="copilot",
            claude_model="claude-haiku-4-5-20251001",
            codex_model="gpt-5.4-mini",
            gemini_model="gemini-2.5-flash",
            copilot_model="gpt-5.4-mini",
            timeout_seconds=30.0,
            dry_run=False,
        ),
    )
    monkeypatch.setattr(
        probe_module,
        "_run_provider_probe",
        lambda *args, **kwargs: {
            "provider": "claude",
            "status": "failed",
            "requested_model": "claude-haiku-4-5-20251001",
            "observed_cli_version": "1.2.3",
            "facts": None,
        },
    )

    assert probe_module.main() == 1
    manifest = json.loads((output_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["results"][0]["status"] == "failed"


def test_transcript_probe_copilot_writes_facts_and_share_artifact(tmp_path, monkeypatch) -> None:
    probe_module = _load_transcript_probe_module()
    output_dir = tmp_path / "probe-output"

    monkeypatch.setattr(
        probe_module,
        "_run_version_command",
        lambda _binary: probe_module.VersionCommandResult(
            command=("copilot", "--version"),
            returncode=0,
            parsed_version="1.0.35-4",
            stdout_text="copilot 1.0.35-4",
            stderr_text="",
        ),
    )

    def fake_run_sync(request):
        request.transcript_path.write_text(
            "\n".join(
                [
                    json.dumps(
                        {
                            "type": "session.start",
                            "data": {
                                "sessionId": "stub-session",
                                "copilotVersion": "1.0.35-4",
                                "selectedModel": "gpt-5.4-mini",
                            },
                        }
                    ),
                    json.dumps(
                        {
                            "type": "assistant.message",
                            "data": {"content": "", "reasoningText": "thinking"},
                        }
                    ),
                    json.dumps(
                        {
                            "type": "assistant.message",
                            "data": {"content": "COPILOT-PROBE-OK"},
                        }
                    ),
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        return SimpleNamespace(
            raw_execution=SimpleNamespace(
                returncode=0,
                stdout=b"COPILOT-PROBE-OK\n",
                stderr=b"",
            ),
            failure_classification=None,
            parsed_output=SimpleNamespace(
                output_source="stdout",
            ),
        )

    monkeypatch.setattr(probe_module.copilot, "run_sync", fake_run_sync)

    entry = probe_module._run_provider_probe(
        provider="copilot",
        binary="copilot",
        model="gpt-5.4-mini",
        prompt="Reply with exactly COPILOT-PROBE-OK and nothing else. Do not use markdown.",
        output_dir=output_dir,
        timeout_seconds=30.0,
    )

    assert entry["status"] == "ok"
    assert entry["parsed_output_source"] == "stdout"
    assert entry["transcript_metadata"] == {
        "session_id": "stub-session",
        "cli_version": "1.0.35-4",
        "model": "gpt-5.4-mini",
    }
    assert entry["facts"]["assistant_messages"] == 2
    assert entry["facts"]["content_messages"] == 1
    assert entry["facts"]["reasoning_only_messages"] == 1
    assert entry["facts"]["final_content"] == "COPILOT-PROBE-OK"
    facts_path = output_dir / entry["facts_path"]
    assert facts_path.exists()


def test_copilot_shell_experiments_use_results_dir_and_relative_scripts(tmp_path) -> None:
    repo_root = _repo_root()
    experiments_dir = (
        repo_root / "packages" / "coding-cli-runtime" / "playground" / "copilot-cli" / "experiments"
    )
    stub_path = _write_copilot_stub(tmp_path)
    caller_cwd = tmp_path / "caller"
    caller_cwd.mkdir()
    base_env = dict(os.environ)
    base_env["COPILOT_BIN"] = str(stub_path)
    base_env["MODEL"] = "stub-model"
    base_env["PYTHON_BIN"] = sys.executable

    cases = [
        (
            "text_access.sh",
            [
                "no_at.stdout.txt",
                "no_at.stderr.txt",
                "with_at.stdout.txt",
                "with_at.stderr.txt",
                "run_info.txt",
                "work/secret_note.txt",
            ],
        ),
        (
            "image_access.sh",
            [
                "no_at.stdout.txt",
                "no_at.stderr.txt",
                "with_at.stdout.txt",
                "with_at.stderr.txt",
                "run_info.txt",
                "work/color_grid.png",
            ],
        ),
        (
            "streaming_check.sh",
            [
                "stream.stdout.txt",
                "stream.stderr.txt",
                "run_info.txt",
                "work/prompt.txt",
            ],
        ),
    ]

    for script_name, expected_files in cases:
        run_dir = tmp_path / script_name.replace(".sh", "")
        env = dict(base_env)
        env["RESULTS_DIR"] = str(run_dir)
        completed = _run_subprocess(
            ["bash", str(experiments_dir / script_name)],
            cwd=caller_cwd,
            env=env,
        )
        assert completed.stderr == ""
        for relative_path in expected_files:
            assert (run_dir / relative_path).exists(), relative_path
        stderr_files = sorted(run_dir.glob("*.stderr.txt"))
        assert stderr_files
        for stderr_file in stderr_files:
            assert "stub-stderr" in stderr_file.read_text(encoding="utf-8")


def test_run_all_aggregates_copilot_experiment_outputs(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "copilot-cli"
        / "experiments"
        / "run_all.sh"
    )
    stub_path = _write_copilot_stub(tmp_path)
    output_root = tmp_path / "run_all"
    caller_cwd = tmp_path / "caller"
    caller_cwd.mkdir()
    env = dict(os.environ)
    env["COPILOT_BIN"] = str(stub_path)
    env["MODEL"] = "stub-model"
    env["PYTHON_BIN"] = sys.executable
    env["RESULTS_DIR"] = str(output_root)

    completed = _run_subprocess(["bash", str(script_path)], cwd=caller_cwd, env=env)

    assert f"Results saved under: {output_root}" in completed.stdout
    assert (output_root / "text_access" / "run_info.txt").exists()
    assert (output_root / "image_access" / "run_info.txt").exists()
    assert (output_root / "streaming_check" / "run_info.txt").exists()
