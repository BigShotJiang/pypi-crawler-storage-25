"""Tests for headless cores and legacy session log helpers."""

from __future__ import annotations

import json
import os
from pathlib import Path

from coding_cli_runtime.headless import (
    build_claude_headless_core,
    build_codex_headless_core,
    build_copilot_headless_core,
    build_gemini_headless_core,
)
from coding_cli_runtime.session_logs import (
    claude_project_key,
    claude_project_roots,
    codex_session_matches,
    codex_session_roots,
    find_claude_session,
    find_codex_session,
    scan_session_dir,
)

# ── headless launch cores ─────────────────────────────────────────────


class TestClaudeHeadlessCore:
    def test_default(self) -> None:
        cmd = build_claude_headless_core("claude-sonnet-4-6")
        assert cmd[0] == "claude"
        assert "--print" in cmd
        assert "--permission-mode" in cmd
        assert "bypassPermissions" in cmd
        assert "--dangerously-skip-permissions" in cmd
        assert "--model" in cmd
        assert "claude-sonnet-4-6" in cmd

    def test_custom_binary(self) -> None:
        cmd = build_claude_headless_core("m", binary="/custom/claude")
        assert cmd[0] == "/custom/claude"

    def test_permission_mode_override(self) -> None:
        cmd = build_claude_headless_core("m", permission_mode="acceptEdits")
        idx = cmd.index("--permission-mode")
        assert cmd[idx + 1] == "acceptEdits"

    def test_skip_permissions_false(self) -> None:
        cmd = build_claude_headless_core("m", skip_permissions=False)
        assert "--dangerously-skip-permissions" not in cmd
        assert "--permission-mode" in cmd

    def test_no_prompt_in_output(self) -> None:
        cmd = build_claude_headless_core("m")
        assert "-p" not in cmd


class TestCodexHeadlessCore:
    def test_default(self) -> None:
        cmd = build_codex_headless_core("gpt-5.4")
        assert cmd[0] == "codex"
        assert "exec" in cmd
        assert "--full-auto" in cmd
        assert "--sandbox" in cmd
        assert "danger-full-access" in cmd
        assert "--skip-git-repo-check" in cmd
        assert "--model" in cmd
        assert "gpt-5.4" in cmd

    def test_read_only_sandbox(self) -> None:
        cmd = build_codex_headless_core("m", sandbox_mode="read-only")
        idx = cmd.index("--sandbox")
        assert cmd[idx + 1] == "read-only"
        assert "--full-auto" in cmd

    def test_custom_binary(self) -> None:
        cmd = build_codex_headless_core("m", binary="/custom/codex")
        assert cmd[0] == "/custom/codex"

    def test_no_output_path_flags(self) -> None:
        cmd = build_codex_headless_core("m")
        assert "-C" not in cmd
        assert "-o" not in cmd
        assert "--output-schema" not in cmd


class TestCopilotHeadlessCore:
    def test_default(self) -> None:
        cmd = build_copilot_headless_core("gpt-5.4")
        assert cmd[0] == "copilot"
        assert "--no-ask-user" in cmd
        assert "--no-custom-instructions" in cmd
        assert "--allow-all" in cmd
        assert "--stream" in cmd
        assert "on" in cmd
        assert "--model" in cmd

    def test_stream_off(self) -> None:
        cmd = build_copilot_headless_core("m", stream="off")
        idx = cmd.index("--stream")
        assert cmd[idx + 1] == "off"

    def test_no_prompt_flag(self) -> None:
        cmd = build_copilot_headless_core("m")
        assert "-p" not in cmd

    def test_custom_binary(self) -> None:
        cmd = build_copilot_headless_core("m", binary="/custom/copilot")
        assert cmd[0] == "/custom/copilot"


class TestGeminiHeadlessCore:
    def test_default(self) -> None:
        cmd = build_gemini_headless_core("gemini-3-pro-preview")
        assert cmd[0] == "gemini"
        assert "--yolo" in cmd
        assert "--model" in cmd
        assert "gemini-3-pro-preview" in cmd

    def test_no_prompt_activation(self) -> None:
        # --prompt "" is prompt transport, not headless core
        cmd = build_gemini_headless_core("m")
        assert "--prompt" not in cmd

    def test_custom_binary(self) -> None:
        cmd = build_gemini_headless_core("m", binary="/custom/gemini")
        assert cmd[0] == "/custom/gemini"


class TestBuilderDelegation:
    """Verify _build_non_interactive_run still produces correct output after delegation."""

    def test_claude_via_builder(self) -> None:
        from coding_cli_runtime.provider_contracts import _build_non_interactive_run

        spec = _build_non_interactive_run("claude", model="claude-sonnet-4-6", prompt="test")
        assert "--print" in spec.cmd_parts
        assert "--dangerously-skip-permissions" in spec.cmd_parts
        assert spec.stdin_text == "test"

    def test_codex_via_builder(self) -> None:
        from coding_cli_runtime.provider_contracts import _build_non_interactive_run

        spec = _build_non_interactive_run("codex", model="gpt-5.4", prompt="fix")
        assert "exec" in spec.cmd_parts
        assert "--full-auto" in spec.cmd_parts

    def test_copilot_via_builder(self) -> None:
        from coding_cli_runtime.provider_contracts import _build_non_interactive_run

        spec = _build_non_interactive_run("copilot", model="m", prompt="task")
        assert "--no-ask-user" in spec.cmd_parts
        assert "--allow-all" in spec.cmd_parts

    def test_gemini_via_builder(self) -> None:
        from coding_cli_runtime.provider_contracts import _build_non_interactive_run

        spec = _build_non_interactive_run("gemini", model="m", prompt="build")
        assert "--yolo" in spec.cmd_parts


# ── scan_session_dir ──────────────────────────────────────────────────


class TestScanSessionDir:
    def _write_jsonl(self, path: Path, records: list[dict]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(json.dumps(r) for r in records) + "\n", encoding="utf-8")

    def test_empty_dir(self, tmp_path: Path) -> None:
        results = scan_session_dir(
            tmp_path,
            since_ts=0.0,
            extract_fn=lambda p: p.name,
        )
        assert results == []

    def test_nonexistent_dir(self, tmp_path: Path) -> None:
        results = scan_session_dir(
            tmp_path / "nonexistent",
            since_ts=0.0,
            extract_fn=lambda p: p.name,
        )
        assert results == []

    def test_finds_matching_files(self, tmp_path: Path) -> None:
        self._write_jsonl(tmp_path / "session1.jsonl", [{"type": "start"}])
        self._write_jsonl(tmp_path / "session2.jsonl", [{"type": "start"}])

        results = scan_session_dir(
            tmp_path,
            since_ts=0.0,
            extract_fn=lambda p: p.name,
        )
        assert len(results) == 2

    def test_extract_fn_filters(self, tmp_path: Path) -> None:
        self._write_jsonl(tmp_path / "good.jsonl", [{"type": "start"}])
        self._write_jsonl(tmp_path / "bad.jsonl", [{"type": "start"}])

        results = scan_session_dir(
            tmp_path,
            since_ts=0.0,
            extract_fn=lambda p: p.name if "good" in p.name else None,
        )
        assert len(results) == 1
        assert results[0][2] == "good.jsonl"

    def test_sorted_by_mtime_descending(self, tmp_path: Path) -> None:
        import time

        p1 = tmp_path / "old.jsonl"
        self._write_jsonl(p1, [{"x": 1}])
        time.sleep(0.05)
        p2 = tmp_path / "new.jsonl"
        self._write_jsonl(p2, [{"x": 2}])

        results = scan_session_dir(
            tmp_path,
            since_ts=0.0,
            extract_fn=lambda p: p.name,
        )
        assert results[0][2] == "new.jsonl"

    def test_custom_glob_pattern(self, tmp_path: Path) -> None:
        (tmp_path / "session.jsonl").write_text("{}\n")
        (tmp_path / "session.json").write_text("{}\n")

        results = scan_session_dir(
            tmp_path,
            glob_pattern="*.json",
            since_ts=0.0,
            extract_fn=lambda p: p.name,
        )
        assert len(results) == 1
        assert results[0][2] == "session.json"

    def test_max_candidates_limits(self, tmp_path: Path) -> None:
        for i in range(5):
            self._write_jsonl(tmp_path / f"s{i}.jsonl", [{"i": i}])

        results = scan_session_dir(
            tmp_path,
            since_ts=0.0,
            extract_fn=lambda p: p.name,
            max_candidates=2,
        )
        assert len(results) == 2


class TestLegacySessionLookupHelpers:
    def _write_jsonl(self, path: Path, records: list[dict]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(json.dumps(r) for r in records) + "\n", encoding="utf-8")

    def test_codex_session_roots_and_claude_project_roots_use_home(
        self, monkeypatch, tmp_path: Path
    ) -> None:
        monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))

        assert codex_session_roots() == [
            tmp_path / ".codex" / "sessions",
            tmp_path / ".codex" / "archived_sessions",
        ]
        assert claude_project_roots() == [tmp_path / ".claude" / "projects"]

    def test_claude_project_key_slugifies_workdir(self) -> None:
        assert claude_project_key(Path("/tmp/my project/repo")) == "-tmp-my-project-repo"
        assert claude_project_key(Path("/")) == "-"

    def test_codex_session_matches_matching_cwd(self, tmp_path: Path) -> None:
        workspace = str((tmp_path / "repo").resolve())
        log_path = tmp_path / "events.jsonl"
        self._write_jsonl(
            log_path,
            [
                {"bad": "record"},
                {"payload": {"cwd": workspace}},
            ],
        )

        assert codex_session_matches(log_path, workspace)
        assert not codex_session_matches(log_path, str((tmp_path / "other").resolve()))

    def test_find_codex_session_returns_latest_matching_candidate(self, tmp_path: Path) -> None:
        workspace = str((tmp_path / "repo").resolve())
        root = tmp_path / "sessions"
        root.mkdir()
        newer_non_match = root / "newer.jsonl"
        older_match = root / "older.jsonl"
        other_workspace = str((tmp_path / "other").resolve())
        self._write_jsonl(newer_non_match, [{"payload": {"cwd": other_workspace}}])
        self._write_jsonl(older_match, [{"payload": {"cwd": workspace}}])
        os.utime(newer_non_match, (200.0, 200.0))
        os.utime(older_match, (100.0, 100.0))

        assert find_codex_session(workspace, 0.0, session_roots=[root]) == older_match

    def test_find_claude_session_returns_latest_project_file(self, tmp_path: Path) -> None:
        workdir = tmp_path / "repo"
        project_dir = tmp_path / "projects" / claude_project_key(workdir)
        older = project_dir / "older.jsonl"
        newer = project_dir / "newer.jsonl"
        self._write_jsonl(older, [{"type": "message"}])
        self._write_jsonl(newer, [{"type": "message"}])
        os.utime(older, (100.0, 100.0))
        os.utime(newer, (200.0, 200.0))

        assert (
            find_claude_session(str(workdir), 0.0, project_roots=[tmp_path / "projects"]) == newer
        )
