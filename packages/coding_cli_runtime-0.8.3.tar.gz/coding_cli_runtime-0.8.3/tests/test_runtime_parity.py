from __future__ import annotations

from pathlib import Path


def test_app_generation_mirror_sources_are_removed() -> None:
    repo_root = Path(__file__).resolve().parents[3]
    mirror_root = repo_root / "app-generation" / "coding_cli_runtime"
    mirror_files = [
        path.relative_to(mirror_root)
        for path in sorted(mirror_root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    ]
    assert not mirror_files, (
        f"Expected no tracked runtime files under {mirror_root}, found: {mirror_files}"
    )


def test_app_generation_legacy_baseline_copy_is_removed() -> None:
    repo_root = Path(__file__).resolve().parents[3]
    legacy_baseline = repo_root / "app-generation" / "copilot_reasoning_baseline.json"
    assert not legacy_baseline.exists()
