# Example prompts

Try these in any MCP client once `flights-mcp` is connected.

## Airport lookup
> Resolve "Tokyo" to airports.
→ `search_airports(query="Tokyo")`

## Basic search
> Find a round-trip JFK→LHR, leaving 2026-09-12, returning 2026-09-20, 1 adult, business class.
→ `search_flights(origin="JFK", destination="LHR", departure_date="2026-09-12", return_date="2026-09-20", cabin_class="business")`

## Optimal-path with custom weights
> Find the best 3 options SFO→SIN on 2026-07-04 — layovers matter more than price.
→ `find_optimal_path(origin="SFO", destination="SIN", departure_date="2026-07-04", top_n=3, weight_price=0.15, weight_layover_quality=0.40, weight_duration=0.25)`

## Cheapest dates
> What's the cheapest day to fly LAX→NRT this quarter?
→ `cheapest_dates(origin="LAX", destination="NRT")`

## Layover analysis
> Break down the layovers in offer `<offer_id>`.
→ `analyze_layovers(offer_id="<offer_id>")`

## Side-by-side
> Compare offers `<id_a>` and `<id_b>`.
→ `compare_offers(offer_ids=["<id_a>", "<id_b>"])`
