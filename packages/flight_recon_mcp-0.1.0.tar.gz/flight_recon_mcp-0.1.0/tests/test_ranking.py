from datetime import datetime, timedelta

from flights_mcp.models import (
    BaggageAllowance,
    Carrier,
    FlightOffer,
    Itinerary,
    Layover,
    Segment,
    parse_iso_duration,
    format_minutes,
)
from flights_mcp.ranking import (
    RankingWeights,
    rank_offers,
    score_layover,
    seat_quality_score,
    stops_score,
)


def _seg(origin: str, dest: str, depart: datetime, duration_min: int,
         carrier_name: str = "Test Air", legroom: str | None = None) -> Segment:
    return Segment(
        origin=origin,
        destination=dest,
        departure_at=depart,
        arrival_at=depart + timedelta(minutes=duration_min),
        duration_minutes=duration_min,
        marketing_carrier=Carrier(iata="ZZ", name=carrier_name),
        flight_number="1",
        legroom=legroom,
    )


def _offer(*, price: float, segs: list[Segment], layovers: list[Layover] | None = None,
           bookable_seats: int | None = None, carbon: float | None = None,
           offer_id: str = "x") -> FlightOffer:
    duration = sum(s.duration_minutes for s in segs) + sum(l.duration_minutes for l in (layovers or []))
    itin = Itinerary(segments=segs, duration_minutes=duration, layovers=layovers or [])
    return FlightOffer(
        id=offer_id,
        provider="rapidapi",
        total_amount=price,
        currency="USD",
        itineraries=[itin],
        passenger_count=1,
        bookable_seats=bookable_seats,
        baggage=BaggageAllowance(checked_pieces=1),
        carbon_emissions_kg=carbon,
    )


def test_parse_iso_duration():
    assert parse_iso_duration("PT5H30M") == 330
    assert parse_iso_duration("PT45M") == 45
    assert parse_iso_duration("P1DT2H") == 1440 + 120
    assert parse_iso_duration(None) == 0
    assert parse_iso_duration("garbage") == 0


def test_format_minutes():
    assert format_minutes(0) == "0m"
    assert format_minutes(330) == "5h 30m"
    assert format_minutes(1500) == "1d 1h"


def test_score_layover_sweet_spot():
    s, notes = score_layover(Layover(airport="AMS", duration_minutes=120))
    assert s >= 0.95
    assert any("Comfortable" in n for n in notes)


def test_score_layover_too_short():
    s, notes = score_layover(Layover(airport="ORD", duration_minutes=30))
    assert s < 0.5
    assert any("below" in n.lower() for n in notes)


def test_score_layover_overnight_penalty():
    base, _ = score_layover(Layover(airport="DOH", duration_minutes=120))
    overnight, _ = score_layover(Layover(airport="DOH", duration_minutes=120, overnight=True))
    assert overnight < base


def test_stops_score_monotonic():
    nonstop = _offer(price=300, segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)])
    one_stop = _offer(
        price=250,
        segs=[
            _seg("A", "C", datetime(2026, 1, 1, 8), 120),
            _seg("C", "B", datetime(2026, 1, 1, 12), 120),
        ],
        layovers=[Layover(airport="C", duration_minutes=60)],
    )
    assert stops_score(nonstop.itineraries) > stops_score(one_stop.itineraries)


def test_seat_quality_low_inventory_warning():
    low = _offer(price=300, segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)], bookable_seats=2)
    plenty = _offer(price=300, segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)], bookable_seats=9)
    sl, _ = seat_quality_score(low)
    sp, _ = seat_quality_score(plenty)
    assert sl < sp


def test_rank_offers_prefers_cheaper_nonstop_with_default_weights():
    cheap_direct = _offer(
        price=300,
        segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)],
        offer_id="cheap-direct",
    )
    expensive_connect = _offer(
        price=600,
        segs=[
            _seg("A", "C", datetime(2026, 1, 1, 8), 120),
            _seg("C", "B", datetime(2026, 1, 1, 12), 120),
        ],
        layovers=[Layover(airport="C", duration_minutes=120)],
        offer_id="exp-connect",
    )
    ranked = rank_offers([cheap_direct, expensive_connect])
    assert ranked[0].offer.id == "cheap-direct"


def test_rank_offers_weights_can_flip_winner():
    cheap_red_eye = _offer(
        price=300,
        segs=[
            _seg("A", "C", datetime(2026, 1, 1, 23), 180),
            _seg("C", "B", datetime(2026, 1, 2, 4), 180),
        ],
        layovers=[Layover(airport="C", duration_minutes=60, overnight=True)],
        offer_id="cheap-red-eye",
    )
    premium_direct = _offer(
        price=550,
        segs=[_seg("A", "B", datetime(2026, 1, 1, 9), 240, legroom="34 in")],
        bookable_seats=9,
        offer_id="premium-direct",
    )
    # Heavily weight layover + seat quality + duration; price gets little weight.
    weights = RankingWeights(
        price=0.10,
        duration=0.25,
        stops=0.20,
        layover_quality=0.25,
        seat_quality=0.20,
        carbon=0.0,
    )
    ranked = rank_offers([cheap_red_eye, premium_direct], weights=weights)
    assert ranked[0].offer.id == "premium-direct"


def test_rank_offers_carbon_breaks_ties():
    a = _offer(
        price=400, segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)],
        offer_id="green", carbon=180,
    )
    b = _offer(
        price=400, segs=[_seg("A", "B", datetime(2026, 1, 1, 8), 240)],
        offer_id="dirty", carbon=320,
    )
    ranked = rank_offers([a, b], weights=RankingWeights(
        price=0.0, duration=0.0, stops=0.0, layover_quality=0.0, seat_quality=0.0, carbon=1.0,
    ))
    assert ranked[0].offer.id == "green"
