"""Unified flight-data models. Both providers normalise into these shapes
so downstream tools (ranking, comparison, seat-map lookup) work uniformly."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

CabinClass = Literal["economy", "premium_economy", "business", "first"]


_ISO_DURATION = re.compile(
    r"^P(?:(?P<d>\d+)D)?(?:T(?:(?P<h>\d+)H)?(?:(?P<m>\d+)M)?(?:(?P<s>\d+)S)?)?$"
)


def parse_iso_duration(value: str | None) -> int:
    """Parse ISO-8601 duration like 'PT5H30M' into minutes. Returns 0 on bad input."""
    if not value:
        return 0
    m = _ISO_DURATION.match(value)
    if not m:
        return 0
    parts = {k: int(v) if v else 0 for k, v in m.groupdict().items()}
    return parts["d"] * 1440 + parts["h"] * 60 + parts["m"] + (parts["s"] // 60)


def format_minutes(total: int) -> str:
    """Render minutes as e.g. '5h 30m' or '1d 4h 10m'."""
    if total <= 0:
        return "0m"
    days, rem = divmod(total, 1440)
    hours, mins = divmod(rem, 60)
    bits = []
    if days:
        bits.append(f"{days}d")
    if hours:
        bits.append(f"{hours}h")
    if mins or not bits:
        bits.append(f"{mins}m")
    return " ".join(bits)


class Airport(BaseModel):
    iata: str
    icao: str | None = None
    name: str
    city: str | None = None
    country: str | None = None
    country_code: str | None = None
    timezone: str | None = None
    latitude: float | None = None
    longitude: float | None = None


class Carrier(BaseModel):
    iata: str | None = None
    name: str | None = None


class Segment(BaseModel):
    """A single take-off-to-touchdown leg."""

    origin: str  # IATA
    destination: str  # IATA
    departure_at: datetime
    arrival_at: datetime
    duration_minutes: int
    marketing_carrier: Carrier
    operating_carrier: Carrier | None = None
    flight_number: str | None = None
    aircraft: str | None = None
    cabin_class: CabinClass | None = None
    fare_basis: str | None = None
    booking_class: str | None = None
    legroom: str | None = None  # e.g. "32 in"
    amenities: list[str] = Field(default_factory=list)
    origin_terminal: str | None = None
    destination_terminal: str | None = None


class Layover(BaseModel):
    airport: str  # IATA where the layover happens
    duration_minutes: int
    overnight: bool = False
    terminal_change: bool | None = None  # None if unknown


class Itinerary(BaseModel):
    """One direction of travel (outbound or return) — a sequence of segments."""

    segments: list[Segment]
    duration_minutes: int
    layovers: list[Layover] = Field(default_factory=list)

    @property
    def stops(self) -> int:
        return max(0, len(self.segments) - 1)


class BaggageAllowance(BaseModel):
    cabin_pieces: int | None = None
    cabin_kg: float | None = None
    checked_pieces: int | None = None
    checked_kg: float | None = None


class FlightOffer(BaseModel):
    """A bookable (or quoted) flight option, normalised across providers."""

    id: str
    provider: Literal["rapidapi"]
    total_amount: float
    currency: str
    itineraries: list[Itinerary]
    passenger_count: int
    cabin_class: CabinClass | None = None
    bookable_seats: int | None = None  # surfaced when a provider exposes it; otherwise None
    baggage: BaggageAllowance | None = None
    refundable: bool | None = None
    changeable: bool | None = None
    carbon_emissions_kg: float | None = None  # SerpApi provides; Duffel does not
    booking_token: str | None = None  # SerpApi: opaque token used to fetch OTA links
    expires_at: datetime | None = None
    raw: dict | None = None  # provider-native payload, kept for advanced callers
