"""Multi-criteria scoring for flight offers.

Each criterion is normalised to [0, 1] across the candidate set (1 = best);
the final score is a weighted sum with caller-tunable weights.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from flights_mcp.models import FlightOffer, Itinerary, Layover

# Hub airports known for reliable connections (long runways, large staff, good wayfinding).
# Used as a rough proxy when we have no per-airport quality feed.
_PREMIUM_HUBS = {
    "SIN", "HKG", "ICN", "NRT", "HND", "TPE", "DOH", "DXB", "AUH",
    "ZRH", "AMS", "CPH", "HEL", "MUC", "FRA", "VIE", "CDG", "LHR",
    "ATL", "DTW", "MSP", "SEA", "IAH", "DFW",
}
_TROUBLE_HUBS = {
    # Notoriously congested or weather-prone with high reroute risk.
    "EWR", "LGA", "ORD", "PHL", "MIA", "FCO", "MAD",
}


@dataclass(frozen=True)
class RankingWeights:
    price: float = 0.35
    duration: float = 0.20
    stops: float = 0.15
    layover_quality: float = 0.15
    seat_quality: float = 0.10
    carbon: float = 0.05

    def normalise(self) -> "RankingWeights":
        total = self.price + self.duration + self.stops + self.layover_quality + self.seat_quality + self.carbon
        if total <= 0:
            return RankingWeights()
        return RankingWeights(
            price=self.price / total,
            duration=self.duration / total,
            stops=self.stops / total,
            layover_quality=self.layover_quality / total,
            seat_quality=self.seat_quality / total,
            carbon=self.carbon / total,
        )


@dataclass
class ScoredOffer:
    offer: FlightOffer
    score: float
    breakdown: dict = field(default_factory=dict)
    rationale: list[str] = field(default_factory=list)


def score_layover(layover: Layover) -> tuple[float, list[str]]:
    """Score a single layover on [0,1] and emit human-readable notes."""
    notes: list[str] = []
    score = 1.0
    mins = layover.duration_minutes
    # Sweet spot: 60–180 min. Too short risks misconnect, too long burns the day.
    if mins < 45:
        score -= 0.6
        notes.append(f"{mins}m connection at {layover.airport} is below most carriers' MCT")
    elif mins < 60:
        score -= 0.35
        notes.append(f"Tight {mins}m connection at {layover.airport}")
    elif 60 <= mins <= 180:
        notes.append(f"Comfortable {mins}m at {layover.airport}")
    elif 180 < mins <= 360:
        score -= 0.15
        notes.append(f"Longer {mins}m wait at {layover.airport}")
    else:
        score -= 0.35
        notes.append(f"Very long {mins}m layover at {layover.airport}")
    if layover.overnight:
        score -= 0.15
        notes.append("Overnight layover — likely lodging cost")
    if layover.terminal_change is True:
        score -= 0.10
        notes.append("Terminal change required")
    if layover.airport in _TROUBLE_HUBS:
        score -= 0.10
        notes.append(f"{layover.airport} has elevated delay risk")
    elif layover.airport in _PREMIUM_HUBS:
        score += 0.05
        notes.append(f"{layover.airport} is a premium connecting hub")
    return max(0.0, min(1.0, score)), notes


def layover_score(itineraries: Iterable[Itinerary]) -> tuple[float, list[str]]:
    notes: list[str] = []
    scores: list[float] = []
    for itin in itineraries:
        for lay in itin.layovers:
            s, n = score_layover(lay)
            scores.append(s)
            notes.extend(n)
    if not scores:
        return 1.0, ["No layovers"]
    return sum(scores) / len(scores), notes


def seat_quality_score(offer: FlightOffer) -> tuple[float, list[str]]:
    notes: list[str] = []
    score = 0.5
    # bookable_seats is a strong signal — low number means flight is filling up.
    if offer.bookable_seats is not None:
        if offer.bookable_seats <= 2:
            score = 0.3
            notes.append(f"Only {offer.bookable_seats} bookable seat(s) left")
        elif offer.bookable_seats <= 5:
            score = 0.55
            notes.append(f"{offer.bookable_seats} bookable seats — filling up")
        else:
            score = 0.85
            notes.append(f"{offer.bookable_seats}+ bookable seats")
    # Legroom hint from SerpApi
    legrooms = [seg.legroom for itin in offer.itineraries for seg in itin.segments if seg.legroom]
    if legrooms:
        notes.append("Legroom: " + ", ".join(sorted(set(legrooms))))
        # 32"+ is acceptable; 30" or less is tight.
        try:
            min_inches = min(int(l.split()[0]) for l in legrooms if l and l.split()[0].isdigit())
            if min_inches >= 33:
                score = max(score, 0.9)
            elif min_inches <= 30:
                score = min(score, 0.4)
        except Exception:
            pass
    return max(0.0, min(1.0, score)), notes


def stops_score(itineraries: Iterable[Itinerary]) -> float:
    max_stops = max((itin.stops for itin in itineraries), default=0)
    return {0: 1.0, 1: 0.7, 2: 0.4}.get(max_stops, 0.2)


def _normalise_inverse(values: list[float]) -> list[float]:
    """Lower input = higher output, scaled to [0,1] across the set."""
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return [1.0] * len(values)
    return [1 - (v - lo) / (hi - lo) for v in values]


def rank_offers(
    offers: list[FlightOffer],
    *,
    weights: RankingWeights | None = None,
) -> list[ScoredOffer]:
    if not offers:
        return []
    w = (weights or RankingWeights()).normalise()
    prices = [o.total_amount for o in offers]
    durations = [
        sum(itin.duration_minutes for itin in o.itineraries) for o in offers
    ]
    carbons = [o.carbon_emissions_kg or 0.0 for o in offers]

    price_n = _normalise_inverse(prices)
    duration_n = _normalise_inverse(durations)
    carbon_n = _normalise_inverse(carbons) if any(c > 0 for c in carbons) else [1.0] * len(offers)

    scored: list[ScoredOffer] = []
    for i, offer in enumerate(offers):
        s_stops = stops_score(offer.itineraries)
        s_lay, lay_notes = layover_score(offer.itineraries)
        s_seat, seat_notes = seat_quality_score(offer)
        breakdown = {
            "price": round(price_n[i], 3),
            "duration": round(duration_n[i], 3),
            "stops": round(s_stops, 3),
            "layover_quality": round(s_lay, 3),
            "seat_quality": round(s_seat, 3),
            "carbon": round(carbon_n[i], 3),
        }
        score = (
            w.price * price_n[i]
            + w.duration * duration_n[i]
            + w.stops * s_stops
            + w.layover_quality * s_lay
            + w.seat_quality * s_seat
            + w.carbon * carbon_n[i]
        )
        rationale = [
            f"Price {offer.total_amount:.0f} {offer.currency} → {breakdown['price']:.2f}",
            f"Total duration {durations[i]}m → {breakdown['duration']:.2f}",
            f"Max stops {max((it.stops for it in offer.itineraries), default=0)} → {breakdown['stops']:.2f}",
            *lay_notes,
            *seat_notes,
        ]
        if offer.carbon_emissions_kg:
            rationale.append(f"Carbon {offer.carbon_emissions_kg:.0f} kg → {breakdown['carbon']:.2f}")
        scored.append(ScoredOffer(offer=offer, score=round(score, 4), breakdown=breakdown, rationale=rationale))

    scored.sort(key=lambda x: x.score, reverse=True)
    return scored
