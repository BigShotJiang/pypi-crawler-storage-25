from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Config:
    rapidapi_key: str | None
    rapidapi_flights_host: str
    default_currency: str
    default_market: str
    default_country: str
    search_cache_ttl: int
    airport_cache_ttl: int
    log_level: str

    @property
    def has_rapidapi(self) -> bool:
        return bool(self.rapidapi_key)


def load_config() -> Config:
    return Config(
        rapidapi_key=os.getenv("RAPIDAPI_KEY") or None,
        rapidapi_flights_host=os.getenv("RAPIDAPI_FLIGHTS_HOST", "sky-scrapper.p.rapidapi.com"),
        default_currency=os.getenv("DEFAULT_CURRENCY", "USD"),
        default_market=os.getenv("DEFAULT_MARKET", "en-US"),
        default_country=os.getenv("DEFAULT_COUNTRY", "US"),
        search_cache_ttl=int(os.getenv("SEARCH_CACHE_TTL", "300")),
        airport_cache_ttl=int(os.getenv("AIRPORT_CACHE_TTL", "86400")),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )
