"""flights-mcp server — flight reconnaissance over MCP.

Single provider: RapidAPI Sky-Scrapper (free tier, instant signup).
Run with:  python -m flights_mcp     (stdio transport)
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import asdict
from typing import Any

from mcp.server.fastmcp import FastMCP

from flights_mcp.cache import TTLCache
from flights_mcp.config import Config, configure_logging, load_config
from flights_mcp.models import CabinClass, FlightOffer, format_minutes
from flights_mcp.providers import (
    ProviderError,
    RapidApiFlightsProvider,
    SearchSlice,
)
from flights_mcp.ranking import RankingWeights, rank_offers, score_layover

log = logging.getLogger("flights_mcp")


class FlightHub:
    """Holds the Sky-Scrapper client + caches + offer memory."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.provider: RapidApiFlightsProvider | None = (
            RapidApiFlightsProvider(
                config.rapidapi_key,
                host=config.rapidapi_flights_host,
                market=config.default_market,
                country=config.default_country,
                currency=config.default_currency,
            )
            if config.has_rapidapi else None
        )
        self._search_cache = TTLCache(default_ttl=config.search_cache_ttl)
        self._airport_cache = TTLCache(default_ttl=config.airport_cache_ttl)
        self._offer_store: dict[str, FlightOffer] = {}

    def remember(self, offers: list[FlightOffer]) -> None:
        for o in offers:
            if o.id:
                self._offer_store[o.id] = o

    def recall(self, offer_id: str) -> FlightOffer | None:
        return self._offer_store.get(offer_id)

    async def aclose(self) -> None:
        if self.provider:
            await self.provider.aclose()


_hub: FlightHub | None = None
mcp = FastMCP("flights-mcp")


def _need_provider() -> RapidApiFlightsProvider:
    if _hub is None:
        raise RuntimeError("server not initialised")
    if not _hub.provider:
        raise RuntimeError(
            "RAPIDAPI_KEY is not set. Sign up at https://rapidapi.com, subscribe to "
            "https://rapidapi.com/apiheya/api/sky-scrapper (BASIC = free, 100/mo), and "
            "drop the X-RapidAPI-Key into your .env."
        )
    return _hub.provider


def _hub_must() -> FlightHub:
    if _hub is None:
        raise RuntimeError("server not initialised")
    return _hub


def _safe_offer_summary(o: FlightOffer) -> dict[str, Any]:
    d = o.model_dump(mode="json", exclude={"raw"})
    d["total_duration_minutes"] = sum(it.duration_minutes for it in o.itineraries)
    d["total_duration"] = format_minutes(d["total_duration_minutes"])
    d["max_stops"] = max((it.stops for it in o.itineraries), default=0)
    return d


# ===================================================================
# Tools
# ===================================================================

@mcp.tool()
async def search_airports(query: str, limit: int = 10) -> list[dict]:
    """Resolve a city or airport name to IATA codes via Sky-Scrapper.

    Args:
        query: City name, airport name, or 3-letter IATA code.
        limit: Max number of results (default 10).
    """
    hub = _hub_must()
    provider = _need_provider()
    cache_key = f"airports::{query.lower()}::{limit}"
    cached = hub._airport_cache.get(cache_key)
    if cached:
        return cached
    try:
        airports = await provider.search_airports(query, limit=limit)
    except ProviderError as exc:
        raise RuntimeError(str(exc)) from exc
    result = [a.model_dump() for a in airports]
    hub._airport_cache.set(cache_key, result)
    return result


@mcp.tool()
async def search_flights(
    origin: str,
    destination: str,
    departure_date: str,
    return_date: str | None = None,
    adults: int = 1,
    children: int = 0,
    infants: int = 0,
    cabin_class: CabinClass = "economy",
    currency: str | None = None,
    max_results: int = 20,
) -> dict:
    """Search flights via Sky-Scrapper (Skyscanner inventory).

    Returns offers with every segment, layover, price, carrier, and duration.
    One-way (omit return_date) or round-trip.

    Args:
        origin: 3-letter IATA code or city name (e.g. JFK, "New York").
        destination: 3-letter IATA code or city name.
        departure_date: YYYY-MM-DD.
        return_date: YYYY-MM-DD; omit for one-way.
        adults / children / infants: passenger counts.
        cabin_class: economy | premium_economy | business | first.
        currency: ISO currency code, e.g. USD.
        max_results: Cap on offers returned.
    """
    hub = _hub_must()
    provider = _need_provider()
    slices = [SearchSlice(origin, destination, departure_date)]
    if return_date:
        slices.append(SearchSlice(destination, origin, return_date))
    cache_key = json.dumps({
        "k": "search",
        "s": [(s.origin, s.destination, s.date) for s in slices],
        "p": [adults, children, infants],
        "c": cabin_class,
        "cur": currency or hub.config.default_currency,
        "m": max_results,
    }, sort_keys=True)
    cached = hub._search_cache.get(cache_key)
    if cached:
        return cached
    try:
        offers = await provider.search_flights(
            slices, adults=adults, children=children, infants=infants,
            cabin_class=cabin_class, currency=currency or hub.config.default_currency,
            max_results=max_results,
        )
    except ProviderError as exc:
        raise RuntimeError(str(exc)) from exc
    hub.remember(offers)
    out = {"count": len(offers), "offers": [_safe_offer_summary(o) for o in offers]}
    hub._search_cache.set(cache_key, out)
    return out


@mcp.tool()
async def cheapest_dates(
    origin: str,
    destination: str,
    currency: str = "USD",
) -> dict:
    """Per-day price calendar for a route (Sky-Scrapper price calendar).

    Returns one row per available day with the lowest one-way price seen and a
    `group` label (`low` / `medium` / `high`) relative to the route's typical fare.
    """
    provider = _need_provider()
    try:
        rows = await provider.cheapest_dates(origin, destination, currency=currency)
    except ProviderError as exc:
        raise RuntimeError(str(exc)) from exc
    return {"origin": origin.upper(), "destination": destination.upper(), "dates": rows}


@mcp.tool()
async def analyze_layovers(offer_id: str) -> dict:
    """Score every layover in an offer on connection-time risk, terminal change,
    overnight burden, and airport quality. Call after search_flights."""
    hub = _hub_must()
    offer = hub.recall(offer_id)
    if not offer:
        raise RuntimeError(f"Offer {offer_id} not in memory. Run search_flights first.")
    rows = []
    for itin_idx, itin in enumerate(offer.itineraries):
        for lay in itin.layovers:
            score, notes = score_layover(lay)
            rows.append({
                "itinerary": itin_idx,
                "airport": lay.airport,
                "duration_minutes": lay.duration_minutes,
                "duration": format_minutes(lay.duration_minutes),
                "overnight": lay.overnight,
                "terminal_change": lay.terminal_change,
                "score": round(score, 3),
                "notes": notes,
            })
    return {"offer_id": offer_id, "layovers": rows}


@mcp.tool()
async def rank_options(
    offer_ids: list[str],
    weight_price: float = 0.40,
    weight_duration: float = 0.25,
    weight_stops: float = 0.15,
    weight_layover_quality: float = 0.15,
    weight_seat_quality: float = 0.05,
) -> dict:
    """Score previously-fetched offers by a weighted combination of price,
    duration, stops, layover quality, and seat quality. Returns offers ranked
    best → worst with a per-criterion breakdown and human-readable rationale.

    Weights are auto-normalised — pass any positive numbers.
    """
    hub = _hub_must()
    offers = [hub.recall(oid) for oid in offer_ids]
    missing = [oid for oid, o in zip(offer_ids, offers) if not o]
    if missing:
        raise RuntimeError(f"Offers not in memory: {missing}. Run a search first.")
    offers = [o for o in offers if o]
    weights = RankingWeights(
        price=weight_price, duration=weight_duration, stops=weight_stops,
        layover_quality=weight_layover_quality, seat_quality=weight_seat_quality,
        carbon=0.0,
    )
    scored = rank_offers(offers, weights=weights)
    return {
        "weights": asdict(weights.normalise()),
        "ranked": [
            {
                "offer_id": s.offer.id, "score": s.score,
                "breakdown": s.breakdown, "rationale": s.rationale,
                "summary": _safe_offer_summary(s.offer),
            }
            for s in scored
        ],
    }


@mcp.tool()
async def find_optimal_path(
    origin: str,
    destination: str,
    departure_date: str,
    return_date: str | None = None,
    adults: int = 1,
    children: int = 0,
    infants: int = 0,
    cabin_class: CabinClass = "economy",
    top_n: int = 5,
    weight_price: float = 0.40,
    weight_duration: float = 0.25,
    weight_stops: float = 0.15,
    weight_layover_quality: float = 0.15,
    weight_seat_quality: float = 0.05,
    currency: str = "USD",
) -> dict:
    """End-to-end: search Sky-Scrapper, score every offer, return the top N with
    per-criterion rationale.

    Heavily-weight `layover_quality` for long-haul trips with bad airports,
    or `duration` if you can't afford a day-killer connection.
    """
    hub = _hub_must()
    provider = _need_provider()
    slices = [SearchSlice(origin, destination, departure_date)]
    if return_date:
        slices.append(SearchSlice(destination, origin, return_date))
    try:
        offers = await provider.search_flights(
            slices, adults=adults, children=children, infants=infants,
            cabin_class=cabin_class, currency=currency, max_results=30,
        )
    except ProviderError as exc:
        raise RuntimeError(str(exc)) from exc
    hub.remember(offers)

    weights = RankingWeights(
        price=weight_price, duration=weight_duration, stops=weight_stops,
        layover_quality=weight_layover_quality, seat_quality=weight_seat_quality,
        carbon=0.0,
    )
    scored = rank_offers(offers, weights=weights)[:top_n]
    return {
        "origin": origin.upper(), "destination": destination.upper(),
        "departure_date": departure_date, "return_date": return_date,
        "offer_count": len(offers),
        "weights": asdict(weights.normalise()),
        "top": [
            {
                "rank": i + 1, "offer_id": s.offer.id,
                "score": s.score, "breakdown": s.breakdown,
                "rationale": s.rationale, "summary": _safe_offer_summary(s.offer),
            }
            for i, s in enumerate(scored)
        ],
    }


@mcp.tool()
async def compare_offers(offer_ids: list[str]) -> dict:
    """Side-by-side comparison of two or more offers in memory."""
    if len(offer_ids) < 2:
        raise RuntimeError("compare_offers needs at least two offer_ids")
    hub = _hub_must()
    offers = [hub.recall(oid) for oid in offer_ids]
    missing = [oid for oid, o in zip(offer_ids, offers) if not o]
    if missing:
        raise RuntimeError(f"Offers not in memory: {missing}. Run a search first.")

    def carriers(o: FlightOffer) -> list[str]:
        seen: list[str] = []
        for it in o.itineraries:
            for seg in it.segments:
                name = seg.marketing_carrier.name or seg.marketing_carrier.iata or "?"
                if name not in seen:
                    seen.append(name)
        return seen

    def layover_summary(o: FlightOffer) -> list[str]:
        out = []
        for it in o.itineraries:
            for lay in it.layovers:
                tag = f"{lay.airport} {format_minutes(lay.duration_minutes)}"
                if lay.overnight:
                    tag += " (overnight)"
                if lay.terminal_change:
                    tag += " (terminal change)"
                out.append(tag)
        return out

    rows = []
    for o in offers:
        if not o:
            continue
        rows.append({
            "offer_id": o.id,
            "price": f"{o.total_amount:.0f} {o.currency}",
            "total_duration": format_minutes(sum(it.duration_minutes for it in o.itineraries)),
            "stops": max((it.stops for it in o.itineraries), default=0),
            "carriers": carriers(o),
            "layovers": layover_summary(o),
            "baggage": o.baggage.model_dump() if o.baggage else None,
        })
    return {"comparison": rows}


# ===================================================================
# Entry point
# ===================================================================

def main() -> None:
    global _hub
    config = load_config()
    configure_logging(config.log_level)
    if not config.has_rapidapi:
        log.warning(
            "RAPIDAPI_KEY is not set — every tool will fail. "
            "Copy .env.example to .env and add your key from "
            "https://rapidapi.com/apiheya/api/sky-scrapper"
        )
    _hub = FlightHub(config)
    log.info("flights-mcp ready")
    try:
        mcp.run()
    finally:
        try:
            asyncio.run(_hub.aclose())
        except Exception:  # noqa: BLE001
            pass


if __name__ == "__main__":
    main()
