from __future__ import annotations

import time
from threading import Lock
from typing import Any


class TTLCache:
    """Tiny thread-safe TTL cache. Per-key expiry; lazy eviction on read."""

    def __init__(self, default_ttl: int = 300, max_entries: int = 512) -> None:
        self._default_ttl = default_ttl
        self._max_entries = max_entries
        self._store: dict[str, tuple[float, Any]] = {}
        self._lock = Lock()

    def get(self, key: str) -> Any | None:
        with self._lock:
            entry = self._store.get(key)
            if not entry:
                return None
            expires, value = entry
            if expires < time.time():
                self._store.pop(key, None)
                return None
            return value

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        if (ttl or self._default_ttl) <= 0:
            return
        with self._lock:
            if len(self._store) >= self._max_entries:
                # drop the soonest-to-expire entry
                soonest = min(self._store.items(), key=lambda kv: kv[1][0])[0]
                self._store.pop(soonest, None)
            self._store[key] = (time.time() + (ttl or self._default_ttl), value)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()
