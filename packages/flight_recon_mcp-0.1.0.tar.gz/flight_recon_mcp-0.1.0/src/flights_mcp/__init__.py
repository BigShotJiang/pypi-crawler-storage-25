"""flights-mcp: comprehensive flight reconnaissance over MCP."""

__version__ = "0.1.0"
