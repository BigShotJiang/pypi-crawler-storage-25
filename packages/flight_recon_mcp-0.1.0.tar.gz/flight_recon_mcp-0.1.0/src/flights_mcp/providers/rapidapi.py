"""RapidAPI Sky-Scrapper client (https://rapidapi.com/apiheya/api/sky-scrapper).

Free-tier signup is instant — RapidAPI account → 'Subscribe to Test' → BASIC plan.
Endpoints used:
- GET /api/v1/flights/searchAirport     → resolve queries to skyId + entityId
- GET /api/v2/flights/searchFlights     → one-way / round-trip search
- GET /api/v1/flights/getPriceCalendar  → monthly fare minimums (cheapest-dates)

We try v2 of searchFlights first (current as of late 2026) and fall back to v1
because both versions are live on RapidAPI and individual subscribers may have
access to one but not the other.
"""
from __future__ import annotations

import logging
from datetime import datetime

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from flights_mcp.models import (
    Airport,
    BaggageAllowance,
    CabinClass,
    Carrier,
    FlightOffer,
    Itinerary,
    Layover,
    Segment,
)
from flights_mcp.providers.base import FlightProvider, ProviderError, SearchSlice

log = logging.getLogger(__name__)


class RapidApiFlightsProvider(FlightProvider):
    name = "rapidapi"

    def __init__(self, api_key: str, *, host: str = "sky-scrapper.p.rapidapi.com",
                 timeout: float = 30.0, market: str = "en-US",
                 country: str = "US", currency: str = "USD") -> None:
        self._host = host
        self._market = market
        self._country = country
        self._currency = currency
        self._client = httpx.AsyncClient(
            base_url=f"https://{host}",
            timeout=timeout,
            headers={
                "X-RapidAPI-Key": api_key,
                "X-RapidAPI-Host": host,
                "Accept": "application/json",
            },
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    @retry(
        retry=retry_if_exception_type(httpx.TransportError),
        wait=wait_exponential(multiplier=0.5, max=4),
        stop=stop_after_attempt(3),
        reraise=True,
    )
    async def _get(self, path: str, params: dict) -> dict:
        try:
            resp = await self._client.get(path, params=params)
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"network error: {exc}") from exc
        if resp.status_code == 429:
            raise ProviderError(self.name, "rate limit hit (RapidAPI free tier = 100/mo)", status=429)
        if resp.status_code >= 400:
            raise ProviderError(self.name, f"{resp.status_code} {resp.text[:300]}", status=resp.status_code)
        payload = resp.json()
        # Sky-Scrapper wraps everything in {status: bool, data: ...} or {message, status}.
        if isinstance(payload, dict) and payload.get("status") is False:
            raise ProviderError(self.name, str(payload.get("message", payload))[:300])
        return payload

    # ---------------- Airports ----------------

    async def search_airports(self, query: str, *, limit: int = 10) -> list[Airport]:
        data = await self._get(
            "/api/v1/flights/searchAirport",
            params={"query": query, "locale": self._market},
        )
        rows = (data.get("data") or [])[:limit]
        out: list[Airport] = []
        for row in rows:
            nav = row.get("navigation") or {}
            presentation = row.get("presentation") or {}
            relevant_flight_params = nav.get("relevantFlightParams") or {}
            iata = relevant_flight_params.get("skyId") or row.get("skyId") or ""
            # navigation.entityType == "AIRPORT" or "CITY"
            name = presentation.get("title") or row.get("name") or iata
            subtitle = presentation.get("subtitle") or ""
            out.append(Airport(
                iata=iata,
                name=name,
                city=subtitle or None,
                country=subtitle.split(",")[-1].strip() if "," in subtitle else None,
            ))
        return out

    async def _resolve_entity(self, code_or_query: str) -> tuple[str, str]:
        """Return (skyId, entityId) for a 3-letter IATA or free-text query."""
        data = await self._get(
            "/api/v1/flights/searchAirport",
            params={"query": code_or_query, "locale": self._market},
        )
        rows = data.get("data") or []
        if not rows:
            raise ProviderError(self.name, f"no airport match for '{code_or_query}'")
        first = rows[0]
        nav = first.get("navigation") or {}
        params = nav.get("relevantFlightParams") or {}
        sky_id = params.get("skyId") or first.get("skyId")
        entity_id = params.get("entityId") or nav.get("entityId") or first.get("entityId")
        if not (sky_id and entity_id):
            raise ProviderError(self.name, f"airport lookup missing skyId/entityId for {code_or_query}")
        return sky_id, entity_id

    # ---------------- Flight search ----------------

    async def search_flights(
        self,
        slices: list[SearchSlice],
        *,
        adults: int = 1,
        children: int = 0,
        infants: int = 0,
        cabin_class: CabinClass = "economy",
        max_connections: int | None = None,  # noqa: ARG002 — not exposed by Sky-Scrapper
        currency: str | None = None,
        max_results: int = 20,
    ) -> list[FlightOffer]:
        if not slices:
            return []
        first, second = slices[0], (slices[1] if len(slices) > 1 else None)
        origin_sky, origin_entity = await self._resolve_entity(first.origin)
        dest_sky, dest_entity = await self._resolve_entity(first.destination)

        params: dict = {
            "originSkyId": origin_sky,
            "destinationSkyId": dest_sky,
            "originEntityId": origin_entity,
            "destinationEntityId": dest_entity,
            "date": first.date,
            "cabinClass": cabin_class,
            "adults": adults,
            "children": children,
            "infants": infants,
            "sortBy": "best",
            "currency": currency or self._currency,
            "market": self._market,
            "countryCode": self._country,
        }
        if second:
            params["returnDate"] = second.date

        # Try v2 first; fall back to v1 if the account doesn't have v2 access.
        try:
            payload = await self._get("/api/v2/flights/searchFlights", params=params)
        except ProviderError as exc:
            if exc.status not in (401, 403, 404):
                raise
            log.info("Sky-Scrapper v2 unavailable (%s), falling back to v1", exc.status)
            payload = await self._get("/api/v1/flights/searchFlights", params=params)

        data = payload.get("data") or {}
        itineraries_raw = data.get("itineraries") or []
        offers: list[FlightOffer] = []
        for it in itineraries_raw[:max_results]:
            try:
                offers.append(self._offer_from_sky(it, pax_count=adults + children + infants,
                                                  fallback_currency=currency or self._currency))
            except Exception as exc:  # noqa: BLE001
                log.warning("Skipping malformed Sky-Scrapper itinerary: %s", exc)
        return offers

    def _offer_from_sky(self, it: dict, *, pax_count: int, fallback_currency: str) -> FlightOffer:
        price = it.get("price") or {}
        raw_price = price.get("raw")
        if raw_price is None:
            raw_price = float((price.get("formatted") or "0").replace(",", "").lstrip("$£€¥"))
        legs = it.get("legs") or []
        itineraries = [self._leg_to_itinerary(leg) for leg in legs]
        bookable = it.get("score")  # Sky-Scrapper doesn't expose seat count
        return FlightOffer(
            id=it.get("id") or "",
            provider="rapidapi",
            total_amount=float(raw_price or 0),
            currency=(price.get("currency") or fallback_currency or "USD"),
            itineraries=itineraries,
            passenger_count=pax_count,
            cabin_class=None,
            baggage=BaggageAllowance(),
            raw=it,
        )

    @staticmethod
    def _leg_to_itinerary(leg: dict) -> Itinerary:
        segments_raw = leg.get("segments") or []
        segments = [RapidApiFlightsProvider._segment_from_sky(s) for s in segments_raw]
        layovers: list[Layover] = []
        for prev, nxt in zip(segments, segments[1:]):
            mins = max(0, int((nxt.departure_at - prev.arrival_at).total_seconds() // 60))
            overnight = prev.arrival_at.date() != nxt.departure_at.date()
            layovers.append(Layover(
                airport=prev.destination,
                duration_minutes=mins,
                overnight=overnight,
                terminal_change=None,
            ))
        total = int(leg.get("durationInMinutes") or sum(s.duration_minutes for s in segments))
        return Itinerary(segments=segments, duration_minutes=total, layovers=layovers)

    @staticmethod
    def _segment_from_sky(seg: dict) -> Segment:
        origin = seg.get("origin") or {}
        destination = seg.get("destination") or {}
        marketing = (seg.get("marketingCarrier") or {})
        operating = (seg.get("operatingCarrier") or {})
        return Segment(
            origin=origin.get("displayCode") or origin.get("iata") or origin.get("id") or "",
            destination=destination.get("displayCode") or destination.get("iata") or destination.get("id") or "",
            departure_at=RapidApiFlightsProvider._parse_dt(seg.get("departure")),
            arrival_at=RapidApiFlightsProvider._parse_dt(seg.get("arrival")),
            duration_minutes=int(seg.get("durationInMinutes") or 0),
            marketing_carrier=Carrier(
                iata=marketing.get("alternateId") or marketing.get("displayCode"),
                name=marketing.get("name"),
            ),
            operating_carrier=Carrier(
                iata=operating.get("alternateId") or operating.get("displayCode"),
                name=operating.get("name"),
            ) if operating else None,
            flight_number=str(seg.get("flightNumber") or ""),
            aircraft=None,
        )

    @staticmethod
    def _parse_dt(value: str | None) -> datetime:
        if not value:
            return datetime.min
        # Sky-Scrapper returns "2026-06-15T08:00:00"
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
        return datetime.min

    # ---------------- Cheapest dates (price calendar) ----------------

    async def cheapest_dates(
        self,
        origin: str,
        destination: str,
        *,
        currency: str = "USD",
    ) -> list[dict]:
        origin_sky, _ = await self._resolve_entity(origin)
        dest_sky, _ = await self._resolve_entity(destination)
        # Use the first of the current month as anchor.
        from_date = datetime.utcnow().strftime("%Y-%m-01")
        data = await self._get(
            "/api/v1/flights/getPriceCalendar",
            params={
                "originSkyId": origin_sky,
                "destinationSkyId": dest_sky,
                "fromDate": from_date,
                "currency": currency,
            },
        )
        rows: list[dict] = []
        days = ((data.get("data") or {}).get("flights") or {}).get("days") or []
        for d in days:
            if d.get("price") is None:
                continue
            rows.append({
                "date": d.get("day"),
                "price": d.get("price"),
                "group": d.get("group"),  # "low"|"medium"|"high"
                "currency": currency,
            })
        return rows
