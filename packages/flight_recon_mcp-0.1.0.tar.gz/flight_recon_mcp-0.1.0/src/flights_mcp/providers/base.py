from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date

from flights_mcp.models import Airport, CabinClass, FlightOffer


class ProviderError(RuntimeError):
    """Wrap any provider-side error (network, auth, 4xx, 5xx, parse)."""

    def __init__(self, provider: str, message: str, *, status: int | None = None) -> None:
        super().__init__(f"[{provider}] {message}")
        self.provider = provider
        self.status = status


class SearchSlice:
    """One leg of a journey: origin → destination on a given date."""

    __slots__ = ("origin", "destination", "date", "departure_time")

    def __init__(self, origin: str, destination: str, departure_date: str | date,
                 departure_time: str | None = None) -> None:
        self.origin = origin.upper()
        self.destination = destination.upper()
        self.date = str(departure_date)
        self.departure_time = departure_time


class FlightProvider(ABC):
    name: str

    @abstractmethod
    async def search_airports(self, query: str, *, limit: int = 10) -> list[Airport]: ...

    @abstractmethod
    async def search_flights(
        self,
        slices: list[SearchSlice],
        *,
        adults: int = 1,
        children: int = 0,
        infants: int = 0,
        cabin_class: CabinClass = "economy",
        max_connections: int | None = None,
        currency: str | None = None,
        max_results: int = 20,
    ) -> list[FlightOffer]: ...

    async def cheapest_dates(
        self,
        origin: str,
        destination: str,
        *,
        currency: str = "USD",
    ) -> list[dict]:
        raise NotImplementedError(f"{self.name} does not implement cheapest_dates")

    async def flight_inspiration(
        self,
        origin: str,
        *,
        max_price: float | None = None,
        currency: str = "USD",
    ) -> list[dict]:
        raise NotImplementedError(f"{self.name} does not implement flight_inspiration")

    async def aclose(self) -> None:
        return None
