/**
 * VoiceSetupWizard tests — Mission v0.30.0 §T2.4.
 *
 * Covers the 5-step state machine: devices → record → results
 * (with retry path) → save → done. Each step's transition rule is
 * pinned by an explicit assertion to guard against the reducer
 * drifting in future refactors.
 */
import { describe, it, expect, beforeEach, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@/test/test-utils";

import { VoiceSetupWizard } from "./VoiceSetupWizard";

const mockGet = vi.fn();
const mockPost = vi.fn();

vi.mock("@/lib/api", () => ({
  api: {
    get: (...args: unknown[]) => mockGet(...args),
    post: (...args: unknown[]) => mockPost(...args),
  },
}));

const DEVICES_RESPONSE = {
  devices: [
    {
      device_id: "dev-1",
      name: "Microphone Array",
      friendly_name: "Built-in Microphone",
      max_input_channels: 2,
      default_sample_rate: 48000,
      is_default: true,
      diagnosis_hint: "ready",
    },
    {
      device_id: "dev-2",
      name: "USB Mic",
      friendly_name: "Razer Seiren",
      max_input_channels: 1,
      default_sample_rate: 16000,
      is_default: false,
      diagnosis_hint: "warning_low_channels",
    },
  ],
  total_count: 2,
  default_device_id: "dev-1",
};

const TEST_RESULT_OK = {
  session_id: "s-1",
  success: true,
  duration_actual_s: 3.0,
  sample_rate_hz: 16000,
  level_rms_dbfs: -20.5,
  level_peak_dbfs: -8.0,
  snr_db: 22.0,
  clipping_detected: false,
  silent_capture: false,
  diagnosis: "ok",
};

const DIAGNOSTIC_RESPONSE = {
  platform: "win32",
  voice_clarity_active: false,
  active_capture_device: "Built-in Microphone",
  ready: true,
  recommendations: [] as string[],
};

beforeEach(() => {
  mockGet.mockReset();
  mockPost.mockReset();
  // Default for telemetry POSTs (Mission v0.30.1 §T1.2) — wizard now
  // emits step_dwell + completion via api.post on every transition;
  // tests that exercise specific endpoints override this with their
  // own mockResolvedValueOnce. Without a default, every transition
  // would crash on .catch() since the unstubbed mock returns undefined.
  mockPost.mockResolvedValue({});
});

describe("VoiceSetupWizard — devices step", () => {
  it("renders the loading state on mount", () => {
    mockGet.mockReturnValue(new Promise(() => {})); // never resolves
    render(<VoiceSetupWizard />);
    expect(screen.getByText("Detecting microphones…")).toBeInTheDocument();
  });

  it("renders device list after fetch resolves", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    expect(screen.getByText("Razer Seiren")).toBeInTheDocument();
  });

  it("transitions to record step on device click", async () => {
    mockGet.mockResolvedValueOnce(DEVICES_RESPONSE);
    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    expect(screen.getByText(/Step 2 of 4/)).toBeInTheDocument();
  });
});

describe("VoiceSetupWizard — record + results flow", () => {
  it("records → results → diagnosis OK → advance enabled", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    // Discriminate by URL — telemetry POSTs (Mission v0.30.1 §T1.2)
    // share the mock with /test-record, so a once-pin would race.
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));

    await waitFor(() => {
      expect(screen.getByText("Recording looks good.")).toBeInTheDocument();
    });
    expect(screen.getByText(/-20.5 dBFS/)).toBeInTheDocument();
    expect(screen.getByText("Save selection")).toBeInTheDocument();
  });

  it("renders backend diagnosis_hint as actionable paragraph for non-ok diagnoses (T2.7)", async () => {
    // Mission MISSION-voice-linux-silent-mic-remediation-2026-05-04
    // §Phase 2 T2.7 — when the backend returns a non-empty
    // diagnosis_hint on a failure verdict, the results step MUST
    // render it as a paragraph below the diagnosis label. Pre-T2.7
    // the hint was emitted but never rendered, so operators saw
    // only the short i18n label and had no actionable next step.
    const TEST_RESULT_NO_AUDIO_LINUX = {
      session_id: "s-2",
      success: true,
      duration_actual_s: 3.0,
      sample_rate_hz: 16000,
      level_rms_dbfs: -83.0,
      level_peak_dbfs: -78.0,
      snr_db: null,
      clipping_detected: false,
      silent_capture: true,
      diagnosis: "no_audio",
      diagnosis_hint:
        "No usable signal captured. On Linux+PipeWire this is " +
        "almost always either an ALSA mixer state issue OR a " +
        "WirePlumber default-source routing issue. Run amixer + wpctl.",
    };
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_NO_AUDIO_LINUX);
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));

    // The actionable hint paragraph should appear below the diagnosis
    // label. We assert on the unique substring the backend embeds for
    // Linux platforms.
    await waitFor(() => {
      expect(screen.getByText(/amixer.*wpctl/i)).toBeInTheDocument();
    });
  });

  it("does NOT render diagnosis_hint paragraph for ok diagnosis (T2.7)", async () => {
    // OK verdict carries a hint too ("Microphone looks good.") but
    // the success badge already conveys the message — rendering both
    // would be visually noisy. Guard: hint paragraph hidden when isOk.
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    const TEST_RESULT_OK_WITH_HINT = {
      ...TEST_RESULT_OK,
      diagnosis_hint: "Microphone looks good.",
    };
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK_WITH_HINT);
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));

    await waitFor(() => {
      expect(screen.getByText("Recording looks good.")).toBeInTheDocument();
    });
    // Hint paragraph should be absent for ok verdict.
    expect(screen.queryByText("Microphone looks good.")).not.toBeInTheDocument();
  });

  it("retry returns from results → record", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    // Discriminate by URL — telemetry POSTs (Mission v0.30.1 §T1.2)
    // share the mock with /test-record, so a once-pin would race.
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));
    await waitFor(() => {
      expect(screen.getByText("Try again")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Try again"));
    expect(screen.getByText(/Step 2 of 4/)).toBeInTheDocument();
  });
});

describe("VoiceSetupWizard — A/B telemetry (Mission v0.30.1 §T1.2)", () => {
  it("emits step_dwell on step transition", async () => {
    mockGet.mockResolvedValueOnce(DEVICES_RESPONSE);
    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    // devices → record transition fires step_dwell for "devices".
    fireEvent.click(screen.getByText("Built-in Microphone"));

    await waitFor(() => {
      const telemetryCalls = mockPost.mock.calls.filter(
        ([path]) => path === "/api/voice/wizard/telemetry",
      );
      expect(telemetryCalls.length).toBeGreaterThanOrEqual(1);
      const [, body] = telemetryCalls[0];
      expect(body.event).toBe("step_dwell");
      expect(body.step).toBe("devices");
      expect(typeof body.duration_ms).toBe("number");
      expect(body.duration_ms).toBeGreaterThanOrEqual(0);
    });
  });

  it("emits completion=abandoned on unmount before reaching done", async () => {
    mockGet.mockResolvedValueOnce(DEVICES_RESPONSE);
    const { unmount } = render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    unmount();

    await waitFor(() => {
      const completionCalls = mockPost.mock.calls.filter(
        ([path, body]) =>
          path === "/api/voice/wizard/telemetry" &&
          body.event === "completion",
      );
      expect(completionCalls.length).toBe(1);
      const [, body] = completionCalls[0];
      expect(body.outcome).toBe("abandoned");
      expect(body.exit_step).toBe("devices");
    });
  });

  it("emits completion=completed when wizard reaches done", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      if (path === "/api/voice/enable") {
        // v0.31.4 GAP 1: Save now POSTs /api/voice/enable; this test
        // exercises the completion-telemetry path so it must mock the
        // enable endpoint as success. Pre-v0.31.4 Save was a stub
        // (no enable call), so this mock didn't exist.
        return Promise.resolve({ ok: true });
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));
    await waitFor(() => {
      expect(screen.getByText("Save selection")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Save selection"));
    fireEvent.click(screen.getByText("Save"));

    await waitFor(() => {
      const completionCalls = mockPost.mock.calls.filter(
        ([path, body]) =>
          path === "/api/voice/wizard/telemetry" &&
          body.event === "completion" &&
          body.outcome === "completed",
      );
      expect(completionCalls.length).toBe(1);
      expect(completionCalls[0][1].exit_step).toBe("done");
    });
  });
});

describe("VoiceSetupWizard — save + done", () => {
  // v0.31.4 GAP 1 closure: pre-v0.31.4 ``handleSave`` was a stub —
  // it dispatched ``advanceToDone`` locally without calling
  // ``/api/voice/enable``. The fix wires it to the real persist
  // endpoint. Tests below verify:
  //   1. happy path: 200 OK from ``/api/voice/enable`` → advance + onComplete
  //   2. error path: ``ok: false`` response → error banner, NO advance
  //   3. exception path: rejected promise → error banner, NO advance

  it("save → POSTs /api/voice/enable + advances on 200", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      if (path === "/api/voice/enable") {
        return Promise.resolve({ ok: true });
      }
      return Promise.resolve({});
    });

    const onComplete = vi.fn();
    render(<VoiceSetupWizard onComplete={onComplete} />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));
    await waitFor(() => {
      expect(screen.getByText("Save selection")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Save selection"));
    expect(screen.getByText("Save")).toBeInTheDocument();
    fireEvent.click(screen.getByText("Save"));

    await waitFor(() => {
      // The handleSave POST to /api/voice/enable must have fired.
      const enableCalls = mockPost.mock.calls.filter(
        ([path]) => path === "/api/voice/enable",
      );
      expect(enableCalls.length).toBe(1);
      // Body carries the operator's mic selection (input_device).
      // The fixture uses ``"dev-1"`` (non-numeric); parseInt returns
      // NaN; impl emits ``null``. Production device_ids are numeric
      // strings (e.g. ``"5"`` for PortAudio device 5) and would parse
      // to the int. The null fallback lets the backend resolver pick.
      expect(enableCalls[0][1]).toEqual({ input_device: null });
    });
    await waitFor(() => {
      expect(screen.getByText(/All set/)).toBeInTheDocument();
    });
    expect(onComplete).toHaveBeenCalledWith("dev-1");
  });

  it("save → error response does NOT advance + shows error banner", async () => {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      if (path === "/api/voice/enable") {
        return Promise.resolve({ ok: false, error: "missing_deps" });
      }
      return Promise.resolve({});
    });

    const onComplete = vi.fn();
    render(<VoiceSetupWizard onComplete={onComplete} />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));
    await waitFor(() => {
      expect(screen.getByText("Save selection")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Save selection"));
    fireEvent.click(screen.getByText("Save"));

    await waitFor(() => {
      // Error banner from the dispatched ``error`` action surfaces.
      expect(screen.getByText(/missing_deps/)).toBeInTheDocument();
    });
    // Must NOT have advanced to "done" — onComplete unchanged.
    expect(onComplete).not.toHaveBeenCalled();
    expect(screen.queryByText(/All set/)).not.toBeInTheDocument();
  });
});

describe("VoiceSetupWizard — handleSave structured error parsing (T3.3 / M3.d)", () => {
  // v0.31.6 T3.3 closure: pre-v0.31.6 a thrown ``ApiError`` whose
  // ``.message`` carried a JSON body was dumped raw into the operator's
  // red banner (e.g. ``{"error":"missing_deps","missing_deps":[...]}``).
  // The fix mirrors VoiceStep::enableWithDevices and parses the JSON
  // to surface i18n'd messages for known failure modes; falls back to
  // the raw message for unknown ``error`` codes (or non-JSON bodies)
  // so operators retain a copy/paste-for-support escape hatch.

  /**
   * Drive the wizard to the save step, then click Save with the
   * api.post mock configured to throw an ApiError-shaped Error whose
   * message is the given JSON string body. Tests assert on the
   * resulting error-banner copy.
   */
  async function _driveToSaveAndError(rawJsonBody: string): Promise<void> {
    mockGet.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/devices") return Promise.resolve(DEVICES_RESPONSE);
      if (path === "/api/voice/wizard/diagnostic") return Promise.resolve(DIAGNOSTIC_RESPONSE);
      return Promise.reject(new Error("unknown path"));
    });
    mockPost.mockImplementation((path: string) => {
      if (path === "/api/voice/wizard/test-record") {
        return Promise.resolve(TEST_RESULT_OK);
      }
      if (path === "/api/voice/enable") {
        // Synthesise an ApiError-equivalent: an Error whose .message
        // is the raw JSON body. The wizard's catch reads err.message
        // verbatim (same contract as ApiError exposes), so a plain
        // Error suffices for the parse-or-fallback branches.
        return Promise.reject(new Error(rawJsonBody));
      }
      return Promise.resolve({});
    });

    render(<VoiceSetupWizard />);
    await waitFor(() => {
      expect(screen.getByText("Built-in Microphone")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Built-in Microphone"));
    fireEvent.click(screen.getByText("Start 3-second recording"));
    await waitFor(() => {
      expect(screen.getByText("Save selection")).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("Save selection"));
    fireEvent.click(screen.getByText("Save"));
  }

  it("missing_deps surfaces i18n key + comma-joined deps", async () => {
    await _driveToSaveAndError(
      JSON.stringify({
        error: "missing_deps",
        missing_deps: ["onnxruntime", "soundfile"],
      }),
    );

    await waitFor(() => {
      // i18n EN: "Missing voice dependencies: {{deps}}. Install with: ..."
      // The {{deps}} interpolation must yield "onnxruntime, soundfile".
      expect(
        screen.getByText(/Missing voice dependencies: onnxruntime, soundfile/),
      ).toBeInTheDocument();
    });
    // The raw JSON must NOT appear — operator should never see the
    // body dumped into the banner.
    expect(screen.queryByText(/"missing_deps"/)).not.toBeInTheDocument();
  });

  it("missing_deps with object-shaped deps normalises to module names", async () => {
    // VoiceStep contract: missing_deps may arrive as
    // [{ module, package }, ...] instead of plain strings. The
    // wizard's fallback must extract the ``module`` field rather
    // than dump "[object Object]".
    await _driveToSaveAndError(
      JSON.stringify({
        error: "missing_deps",
        missing_deps: [
          { module: "onnxruntime", package: "onnxruntime" },
          { module: "soundfile", package: "soundfile" },
        ],
      }),
    );

    await waitFor(() => {
      expect(
        screen.getByText(/Missing voice dependencies: onnxruntime, soundfile/),
      ).toBeInTheDocument();
    });
  });

  it("capture_silence surfaces dedicated i18n key", async () => {
    await _driveToSaveAndError(JSON.stringify({ error: "capture_silence" }));

    await waitFor(() => {
      expect(
        screen.getByText(/Mic captured silence/),
      ).toBeInTheDocument();
    });
    expect(screen.queryByText(/"capture_silence"/)).not.toBeInTheDocument();
  });

  it("capture_device_contended surfaces dedicated i18n key", async () => {
    await _driveToSaveAndError(
      JSON.stringify({
        error: "capture_device_contended",
        alternatives: [{ index: 1, name: "Alt mic" }],
      }),
    );

    await waitFor(() => {
      expect(
        screen.getByText(/Mic device is in use by another application/),
      ).toBeInTheDocument();
    });
    expect(
      screen.queryByText(/"capture_device_contended"/),
    ).not.toBeInTheDocument();
  });

  it("unknown error code falls back to raw message (copy/paste escape hatch)", async () => {
    // Unknown ``error`` field — the wizard preserves the raw body so
    // an operator opening a support ticket can copy/paste verbatim.
    const rawBody = JSON.stringify({
      error: "some_unmapped_failure",
      detail: "garbled backend response",
    });
    await _driveToSaveAndError(rawBody);

    await waitFor(() => {
      // Raw JSON surfaces (the fallback path) — operator sees the
      // ``some_unmapped_failure`` string verbatim. Match on the
      // unique error-code substring, not the JSON braces (which are
      // i18n-stable but visually noisy in this assertion).
      expect(
        screen.getByText(/some_unmapped_failure/),
      ).toBeInTheDocument();
    });
  });

  it("non-JSON message falls back to raw message", async () => {
    // ApiError.message can be a plain text body (e.g. proxy 502).
    // JSON.parse fails, so the fallback path engages and surfaces
    // the raw text verbatim.
    await _driveToSaveAndError("Bad Gateway");

    await waitFor(() => {
      expect(screen.getByText("Bad Gateway")).toBeInTheDocument();
    });
  });
});
