from pathlib import Path

from codemarp.cli.main import analyze_command, build_parser
from codemarp.pipeline.apply_view import ViewType


def _make_repo(tmp_path: Path) -> Path:
    repo = tmp_path / "repo"
    pkg = repo / "app"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "worker.py").write_text(
        "def work():\n    return 1\n",
        encoding="utf-8",
    )
    (pkg / "main.py").write_text(
        "from app.worker import work\n"
        "\n"
        "def run(flag: bool = True):\n"
        "    if flag:\n"
        "        work()\n"
        "    return 1\n",
        encoding="utf-8",
    )

    return repo


def _run_analyze_from_args(args) -> None:
    analyze_command(
        root=Path(args.root),
        out=Path(args.out),
        view=ViewType(args.view),
        focus=args.focus,
        module=args.module,
        max_depth=args.max_depth,
    )


def test_cli_smoke_full_view_writes_expected_outputs(tmp_path: Path) -> None:
    repo = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    parser = build_parser()
    args = parser.parse_args(["analyze", str(repo), "--out", str(out_dir)])

    _run_analyze_from_args(args)

    assert (out_dir / "graph.json").exists()
    assert (out_dir / "high_level.mmd").exists()
    assert (out_dir / "mid_level.mmd").exists()
    assert (out_dir / "mid_level.json").exists()


def test_cli_smoke_trace_view_writes_expected_outputs(tmp_path: Path) -> None:
    repo = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    parser = build_parser()
    args = parser.parse_args(
        [
            "analyze",
            str(repo),
            "--view",
            "trace",
            "--focus",
            "app.main:run",
            "--max-depth",
            "2",
            "--out",
            str(out_dir),
        ]
    )

    _run_analyze_from_args(args)

    assert (out_dir / "graph.json").exists()
    assert (out_dir / "high_level.mmd").exists()
    assert (out_dir / "mid_level.mmd").exists()
    assert (out_dir / "mid_level.json").exists()


def test_cli_smoke_low_view_writes_expected_outputs_and_styles(tmp_path: Path) -> None:
    repo = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    parser = build_parser()
    args = parser.parse_args(
        [
            "analyze",
            str(repo),
            "--view",
            "low",
            "--focus",
            "app.main:run",
            "--out",
            str(out_dir),
        ]
    )

    _run_analyze_from_args(args)

    low_level_mmd = out_dir / "low_level.mmd"
    low_level_json = out_dir / "low_level.json"

    assert (out_dir / "graph.json").exists()
    assert (out_dir / "high_level.mmd").exists()
    assert low_level_mmd.exists()
    assert low_level_json.exists()

    content = low_level_mmd.read_text(encoding="utf-8")
    assert "classDef decision" in content
    assert "classDef merge" in content
    assert "classDef terminal" in content


def test_cli_smoke_module_view_writes_expected_outputs(tmp_path: Path) -> None:
    repo = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    parser = build_parser()
    args = parser.parse_args(
        [
            "analyze",
            str(repo),
            "--view",
            "module",
            "--module",
            "app.main",
            "--out",
            str(out_dir),
        ]
    )

    _run_analyze_from_args(args)

    assert (out_dir / "graph.json").exists()
    assert (out_dir / "high_level.mmd").exists()
    assert (out_dir / "mid_level.mmd").exists()
    assert (out_dir / "mid_level.json").exists()
