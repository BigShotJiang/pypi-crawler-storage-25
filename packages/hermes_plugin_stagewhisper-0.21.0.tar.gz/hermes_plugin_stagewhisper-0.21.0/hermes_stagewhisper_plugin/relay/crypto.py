"""X25519 key exchange + XChaCha20-Poly1305 envelope crypto.

Wire-compatible with the TypeScript OpenClaw plugin
(integrations/openclaw-stagewhisper-channel/src/crypto.ts).
"""

from __future__ import annotations

import base64
import json
import os
import uuid as _uuid
from collections import deque
from typing import Any, Literal

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.ciphers.aead import XChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ENVELOPE_VERSION = "static_v1"
_ENVELOPE_HKDF_INFO = b"stagewhisper-byo-envelope-v1"
_REPLAY_GUARD_MAX_IDS = 10_000

_AAD_FIELDS: tuple[str, ...] = (
    "content_type",
    "correlation_id",
    "message_id",
    "sender_role",
    "session_id",
    "version",
)

SenderRole = Literal["desktop", "plugin"]
ContentType = Literal[
    "reasoning_input",
    "reasoning_output",
    "tool_intent",
    "tool_result",
    "task_content",
    "task_reply",
]


class IdentityKeypair:
    def __init__(self, secret_key: bytes) -> None:
        if len(secret_key) != 32:
            raise ValueError(f"Secret key must be 32 bytes, got {len(secret_key)}")
        self._secret = secret_key
        self._public = x25519.X25519PrivateKey.from_private_bytes(secret_key).public_key()

    @classmethod
    def generate(cls) -> IdentityKeypair:
        return cls(os.urandom(32))

    @classmethod
    def from_secret_bytes(cls, data: bytes) -> IdentityKeypair:
        return cls(data)

    def secret_bytes(self) -> bytes:
        return self._secret

    def public_key_bytes(self) -> bytes:
        return self._public.public_bytes_raw()

    def public_key_base64(self) -> str:
        return _to_base64(self.public_key_bytes())

    @staticmethod
    def public_key_from_base64(b64: str) -> bytes:
        data = _from_base64(b64)
        if len(data) != 32:
            raise ValueError(f"Public key must be 32 bytes, got {len(data)}")
        return data

    def diffie_hellman(self, peer_public: bytes) -> bytes:
        priv = x25519.X25519PrivateKey.from_private_bytes(self._secret)
        peer_pub = x25519.X25519PublicKey.from_public_bytes(peer_public)
        return priv.exchange(peer_pub)

    def derive_envelope_key(self, peer_public: bytes) -> bytes:
        shared = self.diffie_hellman(peer_public)
        hkdf = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=_ENVELOPE_HKDF_INFO)
        return hkdf.derive(shared)


def _build_aad(meta: dict[str, Any]) -> bytes:
    aad_obj = {field: meta[field] for field in _AAD_FIELDS}
    return json.dumps(aad_obj, separators=(",", ":")).encode()


def seal(
    key: bytes,
    sender_role: SenderRole,
    session_id: str,
    correlation_id: str,
    content_type: ContentType,
    plaintext: bytes,
) -> dict:
    message_id = str(_uuid.uuid4())
    nonce = os.urandom(24)

    meta: dict[str, Any] = {
        "version": ENVELOPE_VERSION,
        "sender_role": sender_role,
        "message_id": message_id,
        "session_id": session_id,
        "correlation_id": correlation_id,
        "content_type": content_type,
    }

    cipher = XChaCha20Poly1305(key)
    ciphertext = cipher.encrypt(nonce, plaintext, _build_aad(meta))

    return {
        **meta,
        "nonce": _to_base64(nonce),
        "ciphertext": _to_base64(ciphertext),
    }


def open_envelope(key: bytes, envelope: dict) -> bytes:
    if envelope.get("version") != ENVELOPE_VERSION:
        raise ValueError(f"Unsupported envelope version: {envelope.get('version')}")

    nonce = _from_base64(envelope["nonce"])
    if len(nonce) != 24:
        raise ValueError(f"Nonce must be 24 bytes, got {len(nonce)}")

    ciphertext = _from_base64(envelope["ciphertext"])
    cipher = XChaCha20Poly1305(key)
    return cipher.decrypt(nonce, ciphertext, _build_aad(envelope))


def seal_json(
    key: bytes,
    sender_role: SenderRole,
    session_id: str,
    correlation_id: str,
    content_type: ContentType,
    value,
) -> dict:
    plaintext = json.dumps(value, separators=(",", ":")).encode()
    return seal(key, sender_role, session_id, correlation_id, content_type, plaintext)


def open_json(key: bytes, envelope: dict):
    plaintext = open_envelope(key, envelope)
    return json.loads(plaintext)


class ReplayGuard:
    """In-memory, per-process. A relay restart resets the guard, so the actual
    defenses against replay are nonce uniqueness and short envelope deadlines."""

    def __init__(self) -> None:
        self._seen: set[str] = set()
        self._order: deque[str] = deque()

    def check(self, message_id: str) -> None:
        if message_id in self._seen:
            raise ValueError(f"Replay detected: duplicate message_id {message_id}")
        while len(self._seen) >= _REPLAY_GUARD_MAX_IDS:
            oldest = self._order.popleft()
            self._seen.discard(oldest)
        self._seen.add(message_id)
        self._order.append(message_id)


def open_checked(key: bytes, envelope: dict, replay_guard: ReplayGuard) -> bytes:
    replay_guard.check(envelope["message_id"])
    return open_envelope(key, envelope)


def open_json_checked(key: bytes, envelope: dict, replay_guard: ReplayGuard):
    replay_guard.check(envelope["message_id"])
    return open_json(key, envelope)


def _to_base64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def _from_base64(b64: str) -> bytes:
    return base64.b64decode(b64)
