"""Reasoning job execution via Hermes's main LLM.

Mirrors the exact provider/credential/model-normalization path that the
Hermes TUI uses for a user turn. Specifically: resolve_runtime_provider
(handles Nous Portal OAuth, base URL, API key), normalize_model_for_provider
(translates aliases like deepseek/deepseek-v4-flash → deepseek-v4-flash),
then the OpenAI-compatible chat completions endpoint.

The plugin never holds its own LLM credentials.
"""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

_MODEL_OVERRIDE = os.getenv("STAGEWHISPER_REASONING_MODEL", "") or None


class HostLLMUnavailable(RuntimeError):
    pass


def _load_hermes_runtime():
    try:
        from agent.auxiliary_client import resolve_provider_client
        from hermes_cli.config import load_config
        from hermes_cli.runtime_provider import resolve_runtime_provider
    except ImportError as exc:
        raise HostLLMUnavailable(
            "hermes_cli/agent imports failed. The plugin must run inside the "
            "Hermes venv (~/.hermes/hermes-agent/venv)."
        ) from exc
    return load_config, resolve_runtime_provider, resolve_provider_client


def _resolve_main_runtime(model_override: str | None) -> dict[str, Any]:
    load_config, resolve_runtime_provider, _ = _load_hermes_runtime()

    cfg = load_config()
    model_cfg = cfg.get("model", {}) if isinstance(cfg, dict) else {}
    requested = (model_cfg.get("provider") or "auto").strip().lower()
    raw_model = (model_override or model_cfg.get("default") or "").strip()

    runtime = resolve_runtime_provider(
        requested=requested,
        explicit_api_key=(model_cfg.get("api_key") or "").strip() or None,
        explicit_base_url=(model_cfg.get("base_url") or "").strip() or None,
        target_model=raw_model or None,
    )
    runtime.setdefault("provider", requested)
    runtime["model"] = raw_model
    return runtime


def _build_llm_client(runtime: dict[str, Any]) -> tuple[Any, str]:
    _, _, resolve_provider_client = _load_hermes_runtime()

    client, resolved_model = resolve_provider_client(
        provider=runtime["provider"],
        model=runtime.get("model") or None,
        api_mode=runtime.get("api_mode"),
        explicit_base_url=runtime.get("base_url") or None,
        explicit_api_key=runtime.get("api_key") or None,
        async_mode=True,
    )
    if client is None:
        raise HostLLMUnavailable(
            f"resolve_provider_client returned no client for provider="
            f"{runtime.get('provider')!r} model={runtime.get('model')!r}"
        )
    return client, resolved_model or runtime.get("model") or ""


async def call_main_llm(
    messages: list[dict[str, Any]],
    *,
    max_tokens: int | None = None,
    temperature: float | None = None,
    timeout: float | None = None,
    model: str | None = None,
):
    runtime = _resolve_main_runtime(model)
    client, resolved_model = _build_llm_client(runtime)

    kwargs: dict[str, Any] = {
        "model": resolved_model,
        "messages": messages,
    }
    if max_tokens is not None:
        kwargs["max_tokens"] = max_tokens
    if temperature is not None:
        kwargs["temperature"] = temperature
    if timeout is not None:
        kwargs["timeout"] = timeout
    if runtime.get("provider") == "nous":
        kwargs["extra_body"] = {"tags": ["product=stagewhisper-hermes-plugin"]}

    return await client.chat.completions.create(**kwargs)


def _build_chat_prompt(
    payload: dict[str, Any],
    response_schema: dict[str, Any],
    purpose: str,
) -> list[dict[str, Any]]:
    system_instruction = payload.get("system_instruction", "")
    user_input = json.dumps(payload, separators=(",", ":"))

    system_parts = [
        f'You are a structured reasoning engine for the "{purpose}" task.',
        "You MUST respond with a JSON object conforming to this schema.",
        "Output ONLY valid JSON. No markdown fences, no explanation, no extra text.",
        "",
        "JSON Schema:",
        json.dumps(response_schema, indent=2),
    ]
    if system_instruction:
        system_parts = [system_instruction, ""] + system_parts

    return [
        {"role": "system", "content": "\n".join(system_parts)},
        {"role": "user", "content": user_input},
    ]


def _parse_json_output(text: str) -> dict[str, Any] | None:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        end = next(
            (i for i in range(len(lines) - 1, -1, -1) if lines[i].strip() == "```"),
            len(lines),
        )
        cleaned = "\n".join(lines[1:end]).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return None


def _extract_text(response: Any) -> str | None:
    try:
        choice = response.choices[0]
        message = getattr(choice, "message", None)
        if message is None and isinstance(choice, dict):
            message = choice.get("message")
        content = getattr(message, "content", None)
        if content is None and isinstance(message, dict):
            content = message.get("content")
        return content if isinstance(content, str) else None
    except (AttributeError, IndexError, KeyError, TypeError):
        return None


def _extract_usage(response: Any) -> dict[str, int]:
    usage = getattr(response, "usage", None)
    if usage is None and isinstance(response, dict):
        usage = response.get("usage")
    if usage is None:
        return {"input_tokens": 0, "output_tokens": 0}

    def _g(key: str) -> int:
        v = getattr(usage, key, None)
        if v is None and isinstance(usage, dict):
            v = usage.get(key)
        return int(v) if isinstance(v, (int, float)) else 0

    return {
        "input_tokens": _g("prompt_tokens") or _g("input_tokens"),
        "output_tokens": _g("completion_tokens") or _g("output_tokens"),
    }


def _extract_id(response: Any) -> str | None:
    rid = getattr(response, "id", None)
    if rid is None and isinstance(response, dict):
        rid = response.get("id")
    return rid if isinstance(rid, str) else None


def _extract_model(response: Any) -> str | None:
    m = getattr(response, "model", None)
    if m is None and isinstance(response, dict):
        m = response.get("model")
    return m if isinstance(m, str) else None


async def call_host_llm_text(
    messages: list[dict[str, Any]],
    *,
    max_tokens: int = 512,
    temperature: float = 0.7,
    timeout: float = 60,
    model: str | None = None,
) -> tuple[str, str | None, str | None]:
    response = await call_main_llm(
        messages,
        max_tokens=max_tokens,
        temperature=temperature,
        timeout=timeout,
        model=model or _MODEL_OVERRIDE,
    )
    text = _extract_text(response) or ""
    return text, _extract_id(response), _extract_model(response)


async def execute_reasoning_job(
    job: dict[str, Any],
    display_model: str | None,
) -> dict[str, Any]:
    job_id = job["job_id"]
    purpose = job.get("purpose", "live_analysis")
    response_schema = job.get("response_schema", {})
    payload = job.get("payload", {})

    deadline_ms = _deadline_ms_from(job.get("deadline_at"))
    if deadline_ms <= 0:
        return _failure(
            job_id,
            display_model,
            "timed_out",
            "deadline_expired_before_start",
            "Job deadline had already passed when execution began",
        )

    requested_model = job.get("model") or _MODEL_OVERRIDE
    messages = _build_chat_prompt(payload, response_schema, purpose)
    timeout = min(deadline_ms / 1000, 120)

    try:
        response = await call_main_llm(
            messages,
            max_tokens=4096,
            temperature=0.1,
            timeout=timeout,
            model=requested_model,
        )
    except HostLLMUnavailable as exc:
        return _failure(job_id, display_model, "failed", "host_llm_unavailable", str(exc))
    except Exception as exc:
        logger.error("Reasoning job %s failed during LLM call: %s", job_id, exc)
        return _failure(job_id, requested_model or display_model, "failed", "llm_error", str(exc))

    text = _extract_text(response)
    model_ref = _extract_model(response) or requested_model or display_model
    if not text:
        return _failure(
            job_id,
            model_ref,
            "failed",
            "empty_response",
            "Host LLM returned no text content",
        )

    parsed = _parse_json_output(text)
    if parsed is None:
        return {
            "job_id": job_id,
            "status": "failed",
            "provider_run_id": _extract_id(response),
            "model_ref": model_ref,
            "usage": _extract_usage(response),
            "output": None,
            "error_code": "response_parse_error",
            "error_message": "Response text is not valid JSON",
        }

    return {
        "job_id": job_id,
        "status": "completed",
        "provider_run_id": _extract_id(response),
        "model_ref": model_ref,
        "usage": _extract_usage(response),
        "output": parsed,
        "error_code": None,
        "error_message": None,
    }


async def probe_llm() -> dict[str, Any]:
    try:
        text, _, model = await call_host_llm_text(
            [{"role": "user", "content": "Reply with exactly: OK"}],
            max_tokens=512,
            temperature=0.0,
            timeout=20,
        )
    except HostLLMUnavailable as exc:
        return {"ok": False, "model": None, "error": str(exc)}
    except Exception as exc:
        return {"ok": False, "model": None, "error": str(exc)}

    if not text:
        return {"ok": False, "model": model, "error": "empty_response"}
    return {"ok": True, "model": model, "error": None}


def _deadline_ms_from(deadline_at: str | None) -> int:
    if not deadline_at:
        return 120_000
    try:
        iso = (
            deadline_at.replace("Z", "+00:00")
            if deadline_at.endswith("Z")
            else deadline_at
        )
        deadline_dt = datetime.fromisoformat(iso)
        if deadline_dt.tzinfo is None:
            deadline_dt = deadline_dt.replace(tzinfo=timezone.utc)
        return int((deadline_dt.timestamp() - time.time()) * 1000)
    except (ValueError, OverflowError):
        return -1


def _failure(
    job_id: str,
    model_ref: str | None,
    status: str,
    error_code: str,
    error_message: str,
) -> dict[str, Any]:
    return {
        "job_id": job_id,
        "status": status,
        "provider_run_id": None,
        "model_ref": model_ref,
        "usage": None,
        "output": None,
        "error_code": error_code,
        "error_message": error_message,
    }
