from __future__ import annotations

import json

import pytest

from hermes_stagewhisper_plugin.relay.crypto import (
    ENVELOPE_VERSION,
    IdentityKeypair,
    ReplayGuard,
    open_envelope,
    open_json,
    open_json_checked,
    seal,
    seal_json,
    _build_aad,
)


def _peer_pair() -> tuple[IdentityKeypair, IdentityKeypair, bytes]:
    desktop = IdentityKeypair.generate()
    plugin = IdentityKeypair.generate()
    desktop_key = desktop.derive_envelope_key(plugin.public_key_bytes())
    plugin_key = plugin.derive_envelope_key(desktop.public_key_bytes())
    assert desktop_key == plugin_key
    return desktop, plugin, desktop_key


def test_round_trip_bytes() -> None:
    _, _, key = _peer_pair()
    plaintext = b"hello from stagewhisper"

    envelope = seal(
        key=key,
        sender_role="desktop",
        session_id="sess-1",
        correlation_id="corr-1",
        content_type="reasoning_input",
        plaintext=plaintext,
    )

    assert envelope["version"] == ENVELOPE_VERSION
    assert envelope["sender_role"] == "desktop"
    assert envelope["session_id"] == "sess-1"
    assert envelope["correlation_id"] == "corr-1"
    assert envelope["content_type"] == "reasoning_input"
    assert "nonce" in envelope and "ciphertext" in envelope and "message_id" in envelope

    decrypted = open_envelope(key, envelope)
    assert decrypted == plaintext


def test_round_trip_json() -> None:
    _, _, key = _peer_pair()
    payload = {"prompt": "say hi", "model": "deepseek-v4-flash", "n": 7}

    envelope = seal_json(
        key=key,
        sender_role="plugin",
        session_id="sess-2",
        correlation_id="corr-2",
        content_type="reasoning_output",
        value=payload,
    )

    assert json.loads(open_envelope(key, envelope)) == payload


def test_tamper_detection_aad() -> None:
    _, _, key = _peer_pair()
    envelope = seal(
        key=key,
        sender_role="desktop",
        session_id="sess-1",
        correlation_id="corr-1",
        content_type="reasoning_input",
        plaintext=b"x",
    )
    tampered = dict(envelope)
    tampered["session_id"] = "different-session"
    with pytest.raises(Exception):
        open_envelope(key, tampered)


def test_tamper_detection_ciphertext() -> None:
    _, _, key = _peer_pair()
    envelope = seal(
        key=key,
        sender_role="desktop",
        session_id="sess-1",
        correlation_id="corr-1",
        content_type="reasoning_input",
        plaintext=b"x",
    )
    tampered = dict(envelope)
    tampered["ciphertext"] = "AA" + envelope["ciphertext"][2:]
    with pytest.raises(Exception):
        open_envelope(key, tampered)


def test_open_with_wrong_key_fails() -> None:
    _, _, key = _peer_pair()
    other = IdentityKeypair.generate().derive_envelope_key(IdentityKeypair.generate().public_key_bytes())
    envelope = seal(key, "desktop", "s", "c", "reasoning_input", b"hi")
    with pytest.raises(Exception):
        open_envelope(other, envelope)


def test_replay_guard_rejects_duplicate() -> None:
    _, _, key = _peer_pair()
    envelope = seal_json(key, "desktop", "s", "c", "reasoning_input", {"a": 1})
    guard = ReplayGuard()
    open_json_checked(key, envelope, guard)
    with pytest.raises(ValueError, match="Replay detected"):
        open_json_checked(key, envelope, guard)


def test_replay_guard_evicts_oldest() -> None:
    from hermes_stagewhisper_plugin.relay import crypto

    _, _, key = _peer_pair()
    guard = ReplayGuard()
    capacity = crypto._REPLAY_GUARD_MAX_IDS

    first_envelope = seal_json(key, "desktop", "s", "c", "reasoning_input", {"i": 0})
    open_json_checked(key, first_envelope, guard)

    for i in range(capacity):
        env = seal_json(key, "desktop", "s", "c", "reasoning_input", {"i": i + 1})
        open_json_checked(key, env, guard)

    open_json_checked(key, first_envelope, guard)


def test_aad_contains_only_declared_fields() -> None:
    from hermes_stagewhisper_plugin.relay.crypto import _AAD_FIELDS

    meta = {
        "version": "static_v1",
        "sender_role": "desktop",
        "message_id": "m",
        "session_id": "s",
        "correlation_id": "c",
        "content_type": "reasoning_input",
    }
    aad = json.loads(_build_aad(meta))
    assert set(aad.keys()) == set(_AAD_FIELDS)


def test_envelope_unsupported_version_rejected() -> None:
    _, _, key = _peer_pair()
    envelope = seal(key, "desktop", "s", "c", "reasoning_input", b"x")
    envelope["version"] = "static_v0"
    with pytest.raises(ValueError, match="Unsupported envelope version"):
        open_envelope(key, envelope)


def test_x25519_round_trip_keypair_serialization() -> None:
    kp = IdentityKeypair.generate()
    restored = IdentityKeypair.from_secret_bytes(kp.secret_bytes())
    assert restored.public_key_bytes() == kp.public_key_bytes()


def test_open_json() -> None:
    _, _, key = _peer_pair()
    envelope = seal_json(key, "desktop", "s", "c", "reasoning_input", {"x": [1, 2, 3]})
    assert open_json(key, envelope) == {"x": [1, 2, 3]}
