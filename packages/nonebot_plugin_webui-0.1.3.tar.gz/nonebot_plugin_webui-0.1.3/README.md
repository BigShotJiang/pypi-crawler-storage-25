# nonebot-plugin-webui

一个面向 NoneBot2 的 WebUI 插件雏形，目标是集中管理 NoneBot 运行配置、已加载插件、插件设置与插件商店。

## 当前能力

- 挂载到 FastAPI 驱动提供的 `server_app`
- 查看 NoneBot 运行信息
- 查看已读取的配置项，并自动遮蔽疑似密钥、令牌、密码字段
- 查看已加载插件与 `PluginMetadata`
- 从 NoneBot 官方 registry 拉取插件商店列表，并给出 `nb plugin install` 命令
- 提供 WebUI 虚拟聊天环境，可触发 NoneBot matcher
- 内置 `/ai` 命令，可通过 WebUI 模型提供商配置调用 OpenAI 兼容大模型

## 使用方式

安装到你的 NoneBot 项目环境后，在入口中加载插件：

```python
nonebot.load_plugin("nonebot_plugin_webui")
```

确保项目使用 FastAPI 驱动，例如：

```dotenv
DRIVER=~fastapi
```

启动 NoneBot 后访问：

```text
http://127.0.0.1:8080/webui
```

## 配置

```dotenv
WEBUI_PATH=/webui
WEBUI_STORE_URL=https://registry.nonebot.dev/plugins.json
WEBUI_STORE_TIMEOUT=10

# 可选：启用 WebUI 登录保护
# 设置后访问 WebUI 需要输入该令牌
WEBUI_ACCESS_TOKEN=change-me

# 登录账号固定为 admin，初始密码为 WEBUI_ACCESS_TOKEN。
# 数据库不可用时也会使用这个本地保底密码登录。

# 数据库配置不放在 .env 中。
# WebUI 默认使用 .nonebot-plugin-webui/webui.sqlite3，
# 可在 WebUI 的“配置 / 数据库”面板中修改并测试连接。

# 可选：作为 WebUI 模型提供商设置的回退值
# 推荐直接在 WebUI 的“模型”页面配置
WEBUI_AI_API_KEY=sk-...
WEBUI_AI_BASE_URL=https://api.openai.com/v1
WEBUI_AI_MODEL=gpt-4o-mini
```

AI 模型提供商设置会保存到运行目录下：

```text
.nonebot-plugin-webui/webui.sqlite3
```

数据库连接配置会保存到运行目录下的本地 JSON 文件，作为启动期保底配置：

```text
.nonebot-plugin-webui/database.json
```

如果数据库不可用，WebUI 会回退读取 `.nonebot-plugin-webui/settings.json`，并允许使用本地保底登录令牌进入界面修复数据库配置。

## 路线图

- 支持编辑 `.env` / `.env.*` 配置文件并生成变更预览
- 为插件配置类生成可编辑表单
- 调用 `nb-cli` 安装、更新、卸载插件
- 增加鉴权与访问控制
- 前端迁移到正式构建链并补充更完整的状态管理
