/// <reference types="vite/client" />

declare const __WEBUI_VERSION__: string;
