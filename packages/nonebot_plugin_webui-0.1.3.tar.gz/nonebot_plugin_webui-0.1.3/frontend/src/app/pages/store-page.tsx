import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Home, RefreshCw, Search, Trash2, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  getStorePlugins,
  installStorePlugin,
  uninstallStorePlugin,
  updateAllPluginPackages,
  updatePluginPackage,
  taskWebSocketUrl,
  type StorePlugin,
  type WebuiTask,
  type WebuiTaskMessage,
} from "@/lib/api";
import { useUiStore } from "@/stores/ui-store";
import { cn } from "@/lib/utils";

const protectedPluginModules = new Set([
  "nonebot_plugin_webui",
  "nonebot_plugin_orm",
  "nonebot_plugin_localstore",
]);
const protectedPluginPackages = new Set([
  "nonebot-plugin-webui",
  "nonebot-plugin-orm",
  "nonebot-plugin-localstore",
]);

type StoreUpdateTarget = {
  module_name: string;
  package_name: string;
  name: string;
};

export function StorePage() {
  const storeSearch = useUiStore((state) => state.storeSearch);
  const setStoreSearch = useUiStore((state) => state.setStoreSearch);
  const queryClient = useQueryClient();
  const [submitted, setSubmitted] = useState(storeSearch);
  const [type, setType] = useState("");
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState("name");
  const [installMessage, setInstallMessage] = useState("");
  const [installTask, setInstallTask] = useState<WebuiTask | null>(null);
  const [pendingUninstall, setPendingUninstall] = useState<StorePlugin | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const store = useQuery({
    queryKey: ["store", submitted, type, page, sort],
    queryFn: () => getStorePlugins(submitted, { type, page, page_size: 24, sort }),
  });

  useEffect(() => {
    return () => socketRef.current?.close();
  }, []);

  const installMutation = useMutation({
    mutationFn: (payload: { plugin: StorePlugin; action: "install" | "uninstall" }) =>
      (payload.action === "install" ? installStorePlugin : uninstallStorePlugin)({
        package_name: payload.plugin.package_name,
        module_name: payload.plugin.module_name,
        name: payload.plugin.name,
      }),
    onMutate: () => {
      setInstallMessage("正在创建任务...");
      setInstallTask(null);
      socketRef.current?.close();
    },
    onSuccess: (data) => {
      setInstallTask(data.task);
      setInstallMessage("任务已创建，正在连接实时日志...");
      connectTaskSocket(data.task_id);
    },
    onError: () => setInstallMessage("安装请求失败"),
  });

  const updateMutation = useMutation({
    mutationFn: (payload: { plugins: StoreUpdateTarget[]; all: boolean }) =>
      payload.all
        ? updateAllPluginPackages(
            payload.plugins.map((plugin) => ({
              module_name: plugin.module_name,
              package_name: plugin.package_name,
              name: plugin.name,
            })),
          )
        : updatePluginPackage({
            module_name: payload.plugins[0].module_name,
            package_name: payload.plugins[0].package_name,
            name: payload.plugins[0].name,
          }),
    onMutate: () => {
      setInstallMessage("正在创建更新任务...");
      setInstallTask(null);
      socketRef.current?.close();
    },
    onSuccess: (data) => {
      setInstallTask(data.task);
      setInstallMessage("更新任务已创建，正在连接实时日志...");
      connectTaskSocket(data.task_id, "更新中，正在接收实时日志...");
    },
    onError: () => setInstallMessage("更新请求失败"),
  });

  const connectTaskSocket = (taskId: string, openMessage = "任务运行中，正在接收实时日志...") => {
    const socket = new WebSocket(taskWebSocketUrl(taskId));
    socketRef.current = socket;
    socket.onopen = () => setInstallMessage(openMessage);
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data) as WebuiTaskMessage;
      if (message.type === "error") {
        setInstallMessage(message.message);
        return;
      }
      setInstallTask(message.task);
      if (message.type === "done") {
        const ok = message.task.status === "success";
        setInstallMessage(
          ok ? "任务完成，重启 NoneBot 后状态完全生效。" : "任务失败，请查看日志。",
        );
        void queryClient.invalidateQueries({ queryKey: ["store"] });
        void queryClient.invalidateQueries({ queryKey: ["plugins"] });
      }
    };
    socket.onerror = () => setInstallMessage("实时日志连接失败");
  };

  const visiblePlugins = store.data?.items ?? [];
  const pluginTypes = useMemo(() => {
    return store.data?.types ?? [];
  }, [store.data?.types]);
  const updateTargets = store.data?.update_targets ?? [];
  const totalPages =
    store.data?.pages ??
    Math.max(1, Math.ceil((store.data?.total ?? visiblePlugins.length) / (store.data?.page_size ?? 24)));
  const currentPage = store.data?.page ?? page;
  const cacheUpdatedAt = store.data?.cache_updated_at
    ? new Date(store.data.cache_updated_at * 1000).toLocaleString()
    : "";
  const cacheSource = translateCacheSource(
    store.data?.cache_source,
    store.data?.cached,
    store.data?.cache_updated_at,
  );

  return (
    <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>插件商店</CardTitle>
          <CardDescription>来自 NoneBot registry 的插件索引</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Button
            variant="outline"
            onClick={() => updateMutation.mutate({ plugins: updateTargets, all: true })}
            disabled={
              updateTargets.length === 0 ||
              updateMutation.isPending ||
              installTask?.status === "running"
            }
          >
            <RefreshCw className="size-4" />
            更新全部
          </Button>
          <Input
            value={storeSearch}
            onChange={(event) => setStoreSearch(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                setPage(1);
                setSubmitted(storeSearch);
              }
            }}
            placeholder="搜索插件、作者、标签"
            className="w-80 max-sm:w-full"
          />
          <select
            value={type}
            onChange={(event) => {
              setPage(1);
              setType(event.target.value);
            }}
            className="h-9 rounded-lg border bg-card px-3 text-sm"
          >
            <option value="">全部类型</option>
            {pluginTypes.map((item) => (
              <option key={item} value={item}>
                {translatePluginType(item)}
              </option>
            ))}
          </select>
          <select
            value={sort}
            onChange={(event) => {
              setPage(1);
              setSort(event.target.value);
            }}
            className="h-9 rounded-lg border bg-card px-3 text-sm"
          >
            <option value="name">按名称</option>
            <option value="installed">按安装状态</option>
            <option value="package">按包名</option>
            <option value="-version">按版本</option>
          </select>
          <Button
            onClick={() => {
              setPage(1);
              setSubmitted(storeSearch);
            }}
          >
            <Search className="h-4 w-4" />
            搜索
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 rounded-md border bg-muted/40 px-3 py-2 text-sm text-muted-foreground">
          {store.data
            ? `当前显示 ${visiblePlugins.length} 个，共匹配 ${store.data.total} 个，第 ${currentPage} / ${totalPages} 页，缓存 ${cacheSource}，更新时间 ${cacheUpdatedAt || "未知"}，来源 ${store.data.source}`
            : "正在载入商店索引"}
        </div>
        {installMessage ? (
          <div
            className={cn(
              "mb-4 rounded-md border px-3 py-2 text-sm",
              installMessage.includes("失败")
                ? "border-destructive/30 bg-destructive/10 text-destructive"
                : "border-primary/20 bg-primary/10 text-primary",
            )}
          >
            {installMessage}
          </div>
        ) : null}
        {installTask?.logs.length ? (
          <pre className="mb-4 max-h-56 overflow-auto rounded-md border bg-background p-3 text-xs leading-relaxed text-muted-foreground">
            {installTask.logs.join("\n")}
          </pre>
        ) : null}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {visiblePlugins.map((plugin) => (
            <article key={`${plugin.package_name}:${plugin.module_name}`} className="flex min-h-60 flex-col gap-3 rounded-xl border bg-card p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <h3 className="flex min-w-0 flex-wrap items-center gap-2 text-lg font-semibold">
                  <span className="truncate">{plugin.name}</span>
                  {plugin.version ? (
                    <span className="rounded-md bg-muted px-1.5 py-0.5 text-xs font-medium text-muted-foreground">
                      v{plugin.version}
                    </span>
                  ) : null}
                  {plugin.update_available ? (
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-7 text-primary hover:text-primary"
                      onClick={() => updateMutation.mutate({ plugins: [plugin], all: false })}
                      disabled={
                        isProtectedStorePlugin(plugin) ||
                        updateMutation.isPending ||
                        installTask?.status === "running"
                      }
                      title={`更新到 v${plugin.latest_version ?? ""}`}
                    >
                      <RefreshCw className="size-4" />
                      <span className="sr-only">更新插件</span>
                    </Button>
                  ) : null}
                </h3>
                <Badge className={plugin.installed ? "bg-emerald-100 text-emerald-800" : plugin.valid ? "bg-primary/10 text-primary" : "bg-amber-100 text-amber-800"}>
                  {plugin.installed ? "已安装" : plugin.valid ? "可安装" : "未校验"}
                </Badge>
              </div>
              <p className="min-h-12 text-sm leading-6 text-muted-foreground">
                {plugin.description || "未提供商店描述"}
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>{plugin.package_name}</Badge>
                {plugin.type ? <Badge>{translatePluginType(plugin.type)}</Badge> : null}
                {plugin.current_version ? <Badge>当前 {plugin.current_version}</Badge> : null}
                {plugin.tags.slice(0, 4).map((tag) => (
                  <Badge key={tag}>{tag}</Badge>
                ))}
              </div>
              <div className="mt-auto flex items-end justify-between gap-3 border-t pt-3 text-sm">
                <code className="min-w-0 break-all text-xs text-muted-foreground">
                  {plugin.install_command}
                </code>
                <div className="flex shrink-0 items-center gap-1.5">
                  {plugin.homepage ? (
                    <a
                      className="inline-flex size-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                      href={plugin.homepage}
                      target="_blank"
                      rel="noreferrer"
                      title="打开主页"
                    >
                      <Home className="size-4" />
                      <span className="sr-only">打开主页</span>
                    </a>
                  ) : null}
                  <Button
                    size="icon"
                    variant={plugin.installed ? "ghost" : "default"}
                    className="size-8"
                    onClick={() => installMutation.mutate({ plugin, action: "install" })}
                    disabled={installMutation.isPending || installTask?.status === "running"}
                    title={plugin.installed ? "重新安装" : "安装插件"}
                  >
                    <Download className="size-4" />
                    <span className="sr-only">{plugin.installed ? "重新安装" : "安装插件"}</span>
                  </Button>
                  {plugin.installed ? (
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => setPendingUninstall(plugin)}
                      disabled={
                        isProtectedStorePlugin(plugin) ||
                        installMutation.isPending ||
                        installTask?.status === "running"
                      }
                      title={
                        isProtectedStorePlugin(plugin) ? "核心插件不能卸载" : "卸载插件"
                      }
                    >
                      <Trash2 className="size-4" />
                      <span className="sr-only">卸载插件</span>
                    </Button>
                  ) : null}
                </div>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between gap-3 text-sm text-muted-foreground">
          <span>
            第 {currentPage} / {totalPages} 页
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((value) => Math.max(1, value - 1))}
              disabled={page <= 1 || store.isFetching}
            >
              上一页
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
              disabled={page >= totalPages || store.isFetching}
            >
              下一页
            </Button>
          </div>
        </div>
        {pendingUninstall ? (
          <div className="fixed inset-0 z-[100] grid place-items-center bg-background/45 p-4 backdrop-blur-sm">
            <Card className="w-full max-w-md gap-4 p-5 shadow-2xl">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-base font-semibold">卸载插件</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    确定卸载 {pendingUninstall.name} 吗？运行中的插件需要重启后才会完全移除。
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={() => setPendingUninstall(null)}
                >
                  <X className="size-4" />
                  <span className="sr-only">关闭</span>
                </Button>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setPendingUninstall(null)}>
                  取消
                </Button>
                <Button
                  className="bg-destructive text-white hover:bg-destructive/90"
                  onClick={() => {
                    installMutation.mutate({ plugin: pendingUninstall, action: "uninstall" });
                    setPendingUninstall(null);
                  }}
                >
                  确认卸载
                </Button>
              </div>
            </Card>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

function isProtectedStorePlugin(plugin: StorePlugin) {
  return (
    protectedPluginModules.has(plugin.module_name) ||
    protectedPluginPackages.has(plugin.package_name)
  );
}

function translatePluginType(type: string) {
  const labels: Record<string, string> = {
    application: "应用插件",
    library: "库插件",
  };
  return labels[type] || type;
}

function translateCacheSource(source?: string, cached?: boolean, updatedAt?: number) {
  const labels: Record<string, string> = {
    database: "数据库",
    memory: "内存",
    remote: "远端",
  };
  if (source) return labels[source] || source;
  if (cached || updatedAt) return "数据库";
  return "未知";
}
