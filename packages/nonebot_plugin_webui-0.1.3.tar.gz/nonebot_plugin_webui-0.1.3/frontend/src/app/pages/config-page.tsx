import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { useEffect, useMemo, useState } from "react";

import { DataTable } from "@/app/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  getConfig,
  getDatabaseSettings,
  testDatabaseSettings,
  updateDatabaseSettings,
  type ConfigItem,
} from "@/lib/api";

export function ConfigPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [secretOnly, setSecretOnly] = useState(false);
  const config = useQuery({ queryKey: ["config"], queryFn: getConfig });
  const database = useQuery({ queryKey: ["settings", "database"], queryFn: getDatabaseSettings });
  const [databaseUrl, setDatabaseUrl] = useState("");
  const [databaseEnabled, setDatabaseEnabled] = useState(true);
  const [databaseMessage, setDatabaseMessage] = useState("");

  useEffect(() => {
    if (!database.data) {
      return;
    }
    setDatabaseUrl(database.data.url);
    setDatabaseEnabled(database.data.enabled);
  }, [database.data]);

  const testMutation = useMutation({
    mutationFn: () => testDatabaseSettings({ enabled: databaseEnabled, url: databaseUrl }),
    onSuccess: (data) => setDatabaseMessage(data.ok ? "数据库连接正常" : data.error || "数据库连接失败"),
    onError: (error) => setDatabaseMessage(error instanceof Error ? error.message : "数据库连接失败"),
  });

  const saveMutation = useMutation({
    mutationFn: () => updateDatabaseSettings({ enabled: databaseEnabled, url: databaseUrl }),
    onSuccess: async () => {
      setDatabaseMessage("数据库配置已保存");
      await queryClient.invalidateQueries({ queryKey: ["settings", "database"] });
    },
    onError: (error) => setDatabaseMessage(error instanceof Error ? error.message : "数据库配置保存失败"),
  });

  const columns = useMemo<ColumnDef<ConfigItem>[]>(
    () => [
      {
        accessorKey: "key",
        header: "键",
        cell: ({ row }) => <code>{row.original.key}</code>,
      },
      {
        accessorKey: "value",
        header: "值",
        cell: ({ row }) => (
          <code className="break-all">
            {typeof row.original.value === "string"
              ? row.original.value
              : JSON.stringify(row.original.value)}
          </code>
        ),
      },
      { accessorKey: "type", header: "类型" },
      {
        accessorKey: "masked",
        header: "状态",
        cell: ({ row }) =>
          row.original.masked ? (
            <Badge className="bg-amber-100 text-amber-800">masked</Badge>
          ) : (
            <Badge className="bg-emerald-100 text-emerald-800">visible</Badge>
          ),
      },
    ],
    [],
  );

  const data = (config.data?.items ?? []).filter((item) => {
    const matchesSearch = item.key.toLowerCase().includes(search.toLowerCase());
    const matchesSecret = !secretOnly || item.masked;
    return matchesSearch && matchesSecret;
  });

  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
          <div>
            <CardTitle>数据库</CardTitle>
            <CardDescription>
              WebUI 数据默认写入本地 SQLite；连接失败时会回退本地配置和保底登录。
            </CardDescription>
          </div>
          <div className="flex flex-wrap justify-end gap-2">
            <Badge className={database.data?.available ? undefined : "bg-destructive text-white"}>
              {database.data?.available ? "已连接" : "未连接"}
            </Badge>
            {database.data?.fallback_login ? (
              <Badge className="border-border bg-background text-muted-foreground">保底登录可用</Badge>
            ) : null}
          </div>
        </CardHeader>
        <CardContent className="grid gap-3">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={databaseEnabled}
              onChange={(event) => setDatabaseEnabled(event.target.checked)}
            />
            启用数据库
          </label>
          <Input
            value={databaseUrl}
            onChange={(event) => setDatabaseUrl(event.target.value)}
            placeholder="sqlite:///D:/Project/nonebot-plugin-webui/.nonebot-plugin-webui/webui.sqlite3"
          />
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={() => testMutation.mutate()}
              disabled={testMutation.isPending || !databaseUrl}
            >
              测试连接
            </Button>
            <Button
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending || !databaseUrl}
            >
              保存数据库配置
            </Button>
          </div>
          {database.data?.error ? (
            <div className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {database.data.error}
            </div>
          ) : null}
          {databaseMessage ? (
            <div className="rounded-md border bg-muted/25 px-3 py-2 text-sm text-muted-foreground">
              {databaseMessage}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>运行配置</CardTitle>
          <CardDescription>NoneBot 已读取的配置，敏感字段自动遮蔽</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索配置项"
            className="w-72 max-sm:w-full"
          />
          <label className="flex h-9 items-center gap-2 rounded-lg border bg-card px-3 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={secretOnly}
              onChange={(event) => setSecretOnly(event.target.checked)}
            />
            仅敏感项
          </label>
        </div>
      </CardHeader>
      <CardContent className="px-0 sm:px-6">
        <DataTable columns={columns} data={data} />
      </CardContent>
      </Card>
    </div>
  );
}
