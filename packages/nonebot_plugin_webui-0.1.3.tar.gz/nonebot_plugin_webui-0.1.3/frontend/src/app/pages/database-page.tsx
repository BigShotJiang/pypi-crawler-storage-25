import { useMutation, useQuery } from "@tanstack/react-query";
import { Database, Play } from "lucide-react";
import { useEffect, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  executeDatabaseSql,
  getDatabaseTableRows,
  getDatabaseTableSchema,
  getDatabaseTables,
  type SqlExecuteResponse,
} from "@/lib/api";
import { cn } from "@/lib/utils";

export function DatabasePage() {
  const [sql, setSql] = useState("SELECT * FROM webui_kv LIMIT 20");
  const [selected, setSelected] = useState("");
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState("");
  const [order, setOrder] = useState<"asc" | "desc">("asc");
  const [view, setView] = useState<"data" | "schema" | "sql">("data");
  const tables = useQuery({ queryKey: ["database", "tables"], queryFn: getDatabaseTables });
  const rows = useQuery({
    queryKey: ["database", selected, page, sort, order],
    queryFn: () => getDatabaseTableRows(selected, { page, page_size: 20, sort, order }),
    enabled: Boolean(selected) && view === "data",
  });
  const schema = useQuery({
    queryKey: ["database", selected, "schema"],
    queryFn: () => getDatabaseTableSchema(selected),
    enabled: Boolean(selected) && view === "schema",
  });
  const [sqlResult, setSqlResult] = useState<SqlExecuteResponse | null>(null);
  const [sqlMessage, setSqlMessage] = useState("");
  const execute = useMutation({
    mutationFn: () => executeDatabaseSql(sql),
    onSuccess: (data) => {
      setSqlResult(data);
      setSqlMessage(`执行完成，${data.elapsed_ms} ms，影响/返回 ${data.rowcount} 行`);
      setView("sql");
    },
    onError: () => setSqlMessage("SQL 执行失败"),
  });

  useEffect(() => {
    const first = tables.data?.tables[0]?.name;
    if (!selected && first) setSelected(first);
  }, [selected, tables.data?.tables]);

  const tableRows = rows.data?.rows ?? [];
  const tableColumns = rows.data?.columns ?? [];

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle>数据库</CardTitle>
        <CardDescription>执行 SQL，查看数据表内容和表结构</CardDescription>
      </CardHeader>
      <CardContent className="grid h-[calc(100svh-12rem)] grid-rows-[128px_1fr] gap-4">
        <div className="flex min-h-0 flex-col overflow-hidden rounded-lg border">
          <div className="flex h-10 items-center justify-between border-b bg-muted/20 px-3">
            <span className="text-sm font-medium">SQL</span>
            <div className="flex items-center gap-2">
              {sqlMessage ? <Badge>{sqlMessage}</Badge> : null}
              <Button size="sm" onClick={() => execute.mutate()} disabled={execute.isPending}>
                <Play className="size-4" />
                执行
              </Button>
            </div>
          </div>
          <textarea
            value={sql}
            onChange={(event) => setSql(event.target.value)}
            spellCheck={false}
            className="min-h-0 flex-1 resize-none bg-muted/30 p-3 font-mono text-sm leading-6 text-foreground outline-none placeholder:text-muted-foreground"
          />
        </div>

        <div className="grid min-h-0 grid-cols-[260px_1fr] gap-4 max-lg:grid-cols-1">
          <div className="min-h-0 overflow-hidden rounded-lg border">
            <div className="flex h-10 items-center gap-2 border-b bg-muted/20 px-3 text-sm font-medium">
              <Database className="size-4" />
              数据表
            </div>
            <div className="h-[calc(100%-2.5rem)] overflow-auto p-2">
              {tables.data?.tables.map((table) => (
                <button
                  type="button"
                  key={table.name}
                  onClick={() => {
                    setSelected(table.name);
                    setPage(1);
                    setSort("");
                  }}
                  className={cn(
                    "flex h-8 w-full items-center rounded-md px-2 text-left text-sm hover:bg-accent",
                    selected === table.name && "bg-accent text-primary",
                  )}
                >
                  <span className="truncate">{table.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="min-h-0 overflow-hidden rounded-lg border">
            <div className="flex h-10 items-center justify-between gap-3 border-b bg-muted/20 px-3">
              <span className="truncate text-sm font-medium">{selected || "选择数据表"}</span>
              <div className="flex items-center gap-2">
                <Button size="sm" variant={view === "data" ? "default" : "outline"} onClick={() => setView("data")}>
                  数据内容
                </Button>
                <Button size="sm" variant={view === "schema" ? "default" : "outline"} onClick={() => setView("schema")}>
                  表结构
                </Button>
                <Button size="sm" variant={view === "sql" ? "default" : "outline"} onClick={() => setView("sql")}>
                  SQL 结果
                </Button>
              </div>
            </div>
            {view === "sql" ? (
              <ResultTable columns={sqlResult?.columns ?? []} rows={sqlResult?.rows ?? []} />
            ) : view === "schema" ? (
              <ResultTable
                columns={["name", "type", "nullable", "default", "primary_key"]}
                rows={schema.data?.columns ?? []}
              />
            ) : (
              <>
                <ResultTable
                  columns={tableColumns}
                  rows={tableRows}
                  onSort={(column) => {
                    setPage(1);
                    if (sort === column) setOrder(order === "asc" ? "desc" : "asc");
                    else {
                      setSort(column);
                      setOrder("asc");
                    }
                  }}
                  sort={sort}
                  order={order}
                />
                <div className="flex h-11 items-center justify-between border-t px-3 text-sm text-muted-foreground">
                  <span>
                    第 {rows.data?.page ?? page} / {rows.data?.pages ?? 1} 页，共 {rows.data?.total ?? 0} 行
                  </span>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))}>
                      上一页
                    </Button>
                    <Button size="sm" variant="outline" disabled={page >= (rows.data?.pages ?? 1)} onClick={() => setPage((value) => value + 1)}>
                      下一页
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ResultTable({
  columns,
  rows,
  onSort,
  sort,
  order,
}: {
  columns: string[];
  rows: Record<string, unknown>[];
  onSort?: (column: string) => void;
  sort?: string;
  order?: string;
}) {
  return (
    <div className="h-[calc(100%-2.5rem)] overflow-auto">
      <table className="w-full min-w-max text-left text-sm">
        <thead className="sticky top-0 z-10 bg-background">
          <tr className="border-b">
            {columns.map((column) => (
              <th key={column} className="px-3 py-2 font-medium">
                <button
                  type="button"
                  className={cn("text-left", onSort && "hover:text-primary")}
                  onClick={() => onSort?.(column)}
                >
                  {column}
                  {sort === column ? ` ${order === "desc" ? "↓" : "↑"}` : ""}
                </button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className="border-b last:border-0">
              {columns.map((column) => (
                <td key={column} className="max-w-[360px] truncate px-3 py-2 text-muted-foreground">
                  {formatCell(row[column])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length ? <div className="p-4 text-sm text-muted-foreground">暂无数据</div> : null}
    </div>
  );
}

function formatCell(value: unknown) {
  if (value === null || value === undefined) return "NULL";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}
