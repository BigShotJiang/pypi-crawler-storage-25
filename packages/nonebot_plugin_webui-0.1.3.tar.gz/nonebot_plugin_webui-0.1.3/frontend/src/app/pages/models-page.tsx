import { useMutation, useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { Check, Gauge, Plus, RefreshCw, Save, Trash2, Wifi } from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  fetchAIModels,
  getAISettings,
  testAIModel,
  testAIProvider,
  updateAISettings,
  type AIProvider,
  type AISettings,
} from "@/lib/api";
import { queryClient } from "@/lib/query-client";
import { cn } from "@/lib/utils";

const defaultProvider = (): AIProvider => ({
  id: `provider-${crypto.randomUUID()}`,
  name: "OpenAI 兼容提供商",
  enabled: true,
  api_key: "",
  has_api_key: false,
  base_url: "https://api.openai.com/v1",
  models: [{ id: "gpt-4o-mini", enabled: true }],
  default_model: "gpt-4o-mini",
  timeout: 60,
});

export function ModelsPage() {
  const query = useQuery({ queryKey: ["settings", "ai"], queryFn: getAISettings });
  const [settings, setSettings] = useState<AISettings | null>(null);
  const [activeId, setActiveId] = useState("");
  const [notice, setNotice] = useState("");
  const [customModel, setCustomModel] = useState("");
  const [modelTestResult, setModelTestResult] = useState<
    Record<string, { status: "success"; latency: number } | { status: "error" }>
  >({});

  useEffect(() => {
    if (!query.data) {
      return;
    }
    setSettings(query.data);
    setActiveId((current) => current || query.data.default_provider_id || query.data.providers[0]?.id || "");
  }, [query.data]);

  const activeProvider = useMemo(
    () => settings?.providers.find((provider) => provider.id === activeId) ?? settings?.providers[0],
    [activeId, settings?.providers],
  );

  const saveMutation = useMutation({
    mutationFn: updateAISettings,
    onSuccess: (data) => {
      setSettings(data);
      queryClient.setQueryData(["settings", "ai"], data);
      setNotice("设置已保存。");
    },
  });

  const modelsMutation = useMutation({
    mutationFn: fetchAIModels,
    onSuccess: (data) => {
      if (!activeProvider) return;
      updateProvider(activeProvider.id, {
        models: mergeModels(activeProvider.models, data.models),
        default_model: activeProvider.default_model || data.models[0] || "",
      });
      setNotice(`已获取 ${data.models.length} 个模型，用时 ${data.latency_ms}ms。`);
    },
  });

  const modelTestMutation = useMutation({
    mutationFn: testAIModel,
    onSuccess: (data) => {
      setModelTestResult((current) => ({
        ...current,
        [data.model]: { status: "success", latency: data.latency_ms },
      }));
      setNotice(`${data.model} 连接正常。`);
    },
    onError: (_error, variables) => {
      setModelTestResult((current) => ({
        ...current,
        [variables.model]: { status: "error" },
      }));
    },
  });

  const testMutation = useMutation({
    mutationFn: testAIProvider,
    onSuccess: (data) => {
      setNotice(`连接正常，延迟 ${data.latency_ms}ms，模型数量 ${data.models_count}。`);
    },
  });

  function updateSettings(patch: Partial<AISettings>) {
    setSettings((current) => (current ? { ...current, ...patch } : current));
  }

  function updateProvider(id: string, patch: Partial<AIProvider>) {
    setSettings((current) =>
      current
        ? {
            ...current,
            providers: current.providers.map((provider) =>
              provider.id === id ? { ...provider, ...patch } : provider,
            ),
          }
        : current,
    );
  }

  function addProvider() {
    const provider = defaultProvider();
    setSettings((current) =>
      current
        ? {
            ...current,
            providers: [...current.providers, provider],
            default_provider_id: current.default_provider_id || provider.id,
          }
        : current,
    );
    setActiveId(provider.id);
  }

  function removeProvider(id: string) {
    setSettings((current) => {
      if (!current || current.providers.length <= 1) return current;
      const providers = current.providers.filter((provider) => provider.id !== id);
      return {
        ...current,
        providers,
        default_provider_id:
          current.default_provider_id === id ? providers[0]?.id || "" : current.default_provider_id,
      };
    });
    setActiveId((current) => (current === id ? "" : current));
  }

  function save(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    if (!settings) return;
    const providers = settings.providers.map((provider) => ({
      ...provider,
      models: dedupeModels(provider.models),
      default_model:
        provider.default_model ||
        provider.models.find((model) => model.enabled)?.id ||
        "",
    }));
    saveMutation.mutate({ ...settings, providers });
  }

  function probePayload(provider: AIProvider) {
    return {
      api_key: provider.api_key,
      base_url: provider.base_url,
      timeout: provider.timeout,
    };
  }

  function modelProbePayload(provider: AIProvider, model: string) {
    return {
      ...probePayload(provider),
      model,
    };
  }

  if (query.isLoading || !settings) {
    return <div className="text-sm text-muted-foreground">正在加载模型提供商...</div>;
  }

  return (
    <div className="grid h-[calc(100svh-8rem)] min-h-[620px] grid-cols-[320px_minmax(0,1fr)] gap-4 max-lg:h-auto max-lg:grid-cols-1">
      <Card className="min-h-0">
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle>模型提供商</CardTitle>
              <CardDescription>管理 OpenAI 兼容模型接入</CardDescription>
            </div>
            <Button size="icon" variant="outline" onClick={addProvider} title="添加提供商">
              <Plus className="size-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="grid gap-2">
          {settings.providers.map((provider) => (
            <button
              key={provider.id}
              type="button"
              onClick={() => setActiveId(provider.id)}
              className={cn(
                "rounded-md border bg-background p-3 text-left text-sm transition-colors hover:bg-accent",
                provider.id === activeProvider?.id && "border-primary bg-accent",
              )}
            >
              <div className="mb-1 flex items-center justify-between gap-2">
                <span className="truncate font-medium">{provider.name}</span>
                {settings.default_provider_id === provider.id ? <Badge>默认</Badge> : null}
              </div>
              <div className="truncate text-xs text-muted-foreground">{provider.base_url}</div>
              <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                <span>{provider.models.length} 个模型</span>
                <span>{provider.enabled ? "已启用" : "已停用"}</span>
              </div>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="min-h-0 overflow-hidden">
        <CardHeader className="border-b">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle>提供商配置</CardTitle>
              <CardDescription>保存后 `/ai` 会使用默认提供商和默认模型</CardDescription>
            </div>
            <Button type="submit" form="model-provider-form" disabled={saveMutation.isPending}>
              <Save className="size-4" />
              保存
            </Button>
          </div>
        </CardHeader>

        {activeProvider ? (
          <form
            id="model-provider-form"
            data-slot="card-content"
            onSubmit={save}
            className="grid max-h-[calc(100svh-12rem)] gap-4 overflow-y-auto p-4 px-6"
          >
            <section className="grid gap-4 rounded-lg border bg-muted/20 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-semibold">基础信息</div>
                  <div className="text-xs text-muted-foreground">OpenAI 兼容接口、认证与默认模型</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">启用</span>
                  <Switch
                    checked={activeProvider.enabled}
                    onCheckedChange={(checked: boolean) =>
                      updateProvider(activeProvider.id, { enabled: checked })
                    }
                  />
                </div>
              </div>

              <div className="grid grid-cols-[minmax(0,1fr)_220px] gap-4 max-lg:grid-cols-1">
                <Field label="名称">
                  <Input
                    value={activeProvider.name}
                    onChange={(event) => updateProvider(activeProvider.id, { name: event.target.value })}
                  />
                </Field>
                <Field label="默认模型">
                  <select
                    value={activeProvider.default_model}
                    onChange={(event) =>
                      updateProvider(activeProvider.id, { default_model: event.target.value })
                    }
                    className="h-9 rounded-md border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {[
                      ...new Set(
                        [
                          activeProvider.default_model,
                          ...activeProvider.models.filter((model) => model.enabled).map((model) => model.id),
                        ].filter(Boolean),
                      ),
                    ].map((model) => (
                        <option key={model} value={model}>
                          {model}
                        </option>
                      ))}
                  </select>
                </Field>
              </div>

              <Field label="API Key">
                <Input
                  value={activeProvider.api_key}
                  onChange={(event) => updateProvider(activeProvider.id, { api_key: event.target.value })}
                  placeholder="sk-..."
                />
              </Field>

              <div className="grid grid-cols-[minmax(0,1fr)_120px] gap-4 max-md:grid-cols-1">
                <Field label="Base URL">
                  <Input
                    value={activeProvider.base_url}
                    onChange={(event) => updateProvider(activeProvider.id, { base_url: event.target.value })}
                    placeholder="https://api.openai.com/v1"
                  />
                </Field>
                <Field label="超时">
                  <Input
                    type="number"
                    min={1}
                    max={300}
                    value={activeProvider.timeout}
                    onChange={(event) =>
                      updateProvider(activeProvider.id, { timeout: Number(event.target.value) })
                    }
                  />
                </Field>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => modelsMutation.mutate(probePayload(activeProvider))}
                  disabled={modelsMutation.isPending}
                >
                  <RefreshCw className="size-4" />
                  获取模型列表
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => testMutation.mutate(probePayload(activeProvider))}
                  disabled={testMutation.isPending}
                >
                  <Wifi className="size-4" />
                  测试提供商
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => updateSettings({ default_provider_id: activeProvider.id })}
                >
                  <Check className="size-4" />
                  设为默认
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => removeProvider(activeProvider.id)}
                  disabled={settings.providers.length <= 1}
                >
                  <Trash2 className="size-4" />
                  删除
                </Button>
              </div>
            </section>

            <section className="grid gap-3 rounded-lg border bg-muted/20 p-4">
              <div className="flex items-center justify-between gap-3 max-md:flex-col max-md:items-stretch">
                <div>
                  <div className="text-sm font-semibold">模型列表</div>
                  <div className="text-xs text-muted-foreground">启用模型、设置默认模型并测试单模型延迟</div>
                </div>
                <div className="flex gap-2 max-sm:flex-col">
                  <Input
                    value={customModel}
                    onChange={(event) => setCustomModel(event.target.value)}
                    placeholder="自定义模型 ID"
                    className="w-56 max-sm:w-full"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const id = customModel.trim();
                      if (!id) return;
                      updateProvider(activeProvider.id, {
                        models: mergeModels(activeProvider.models, [id]),
                        default_model: activeProvider.default_model || id,
                      });
                      setCustomModel("");
                    }}
                  >
                    <Plus className="size-4" />
                    添加模型
                  </Button>
                </div>
              </div>

              <div className="overflow-hidden rounded-md border bg-background">
                <div className="grid grid-cols-[minmax(0,1fr)_80px_90px_90px_44px] gap-2 border-b bg-muted/50 px-3 py-2 text-xs font-medium text-muted-foreground max-md:hidden">
                  <div>模型</div>
                  <div>状态</div>
                  <div>默认</div>
                  <div>测速</div>
                  <div />
                </div>
                {activeProvider.models.length ? (
                  activeProvider.models.map((model) => (
                    <div
                      key={model.id}
                      className="grid grid-cols-[minmax(0,1fr)_80px_90px_90px_44px] items-center gap-2 border-b px-3 py-2 text-sm last:border-b-0 max-md:grid-cols-1 max-md:items-stretch"
                    >
                      <div className="min-w-0">
                        <div className="truncate font-mono">{model.id}</div>
                        <div
                          className={cn(
                            "text-xs text-muted-foreground",
                            modelTestResult[model.id]?.status === "error" && "text-destructive",
                          )}
                        >
                          {formatModelTestResult(modelTestResult[model.id])}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 max-md:justify-between">
                        <span className="hidden text-xs text-muted-foreground max-md:inline">启用</span>
                        <Switch
                          checked={model.enabled}
                          onCheckedChange={(checked: boolean) =>
                            updateProvider(activeProvider.id, {
                              models: activeProvider.models.map((item) =>
                                item.id === model.id ? { ...item, enabled: checked } : item,
                              ),
                            })
                          }
                        />
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        variant={activeProvider.default_model === model.id ? "default" : "outline"}
                        onClick={() => updateProvider(activeProvider.id, { default_model: model.id })}
                      >
                        默认
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => modelTestMutation.mutate(modelProbePayload(activeProvider, model.id))}
                        disabled={modelTestMutation.isPending}
                      >
                        <Gauge className="size-4" />
                        测速
                      </Button>
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        onClick={() => {
                          const models = activeProvider.models.filter((item) => item.id !== model.id);
                          updateProvider(activeProvider.id, {
                            models,
                            default_model:
                              activeProvider.default_model === model.id
                                ? models.find((item) => item.enabled)?.id || ""
                                : activeProvider.default_model,
                          });
                        }}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="p-3 text-sm text-muted-foreground">暂无模型，点击“获取模型列表”或手动添加。</div>
                )}
              </div>
            </section>

            <section className="grid gap-4 rounded-lg border bg-muted/20 p-4">
              <div>
                <div className="text-sm font-semibold">全局参数</div>
                <div className="text-xs text-muted-foreground">作用于所有模型提供商的 AI 对话行为</div>
              </div>
              <div className="grid grid-cols-[minmax(0,1fr)_120px] gap-4 max-md:grid-cols-1">
                <Field label="系统提示词">
                  <textarea
                    value={settings.system_prompt}
                    onChange={(event) => updateSettings({ system_prompt: event.target.value })}
                    className="min-h-24 resize-y rounded-md border bg-background px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  />
                </Field>
                <Field label="上下文">
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={settings.history_limit}
                    onChange={(event) => updateSettings({ history_limit: Number(event.target.value) })}
                  />
                </Field>
              </div>
            </section>

            {notice ? <div className="text-sm text-muted-foreground">{notice}</div> : null}
            {saveMutation.isError || modelsMutation.isError || testMutation.isError || modelTestMutation.isError ? (
              <div className="text-sm text-destructive">
                {formatError(
                  saveMutation.error ||
                    modelsMutation.error ||
                    testMutation.error ||
                    modelTestMutation.error,
                )}
              </div>
            ) : null}
          </form>
        ) : null}
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
    </label>
  );
}

function formatError(error: unknown) {
  if (error instanceof AxiosError) {
    return error.response?.data?.detail || error.message;
  }
  return error instanceof Error ? error.message : "操作失败";
}

function formatModelTestResult(
  result: { status: "success"; latency: number } | { status: "error" } | undefined,
) {
  if (!result) {
    return "未测速";
  }
  if (result.status === "error") {
    return "失败";
  }
  return `${result.latency}ms`;
}

function mergeModels(current: { id: string; enabled: boolean }[], incoming: string[]) {
  return dedupeModels([
    ...current,
    ...incoming.filter(Boolean).map((id) => ({ id, enabled: true })),
  ]);
}

function dedupeModels(models: { id: string; enabled: boolean }[]) {
  const seen = new Set<string>();
  return models
    .map((model) => ({ ...model, id: model.id.trim() }))
    .filter((model) => {
      if (!model.id || seen.has(model.id)) return false;
      seen.add(model.id);
      return true;
    });
}
