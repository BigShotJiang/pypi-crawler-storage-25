import { useMutation, useQuery } from "@tanstack/react-query";
import { FileCode, FileText, Folder, RotateCcw, Save } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getFileContent, listFiles, saveFileContent, type FileEntry } from "@/lib/api";
import { cn } from "@/lib/utils";

export function FilesPage() {
  const [path, setPath] = useState("");
  const [selected, setSelected] = useState("");
  const [content, setContent] = useState("");
  const [original, setOriginal] = useState("");
  const [eol, setEol] = useState<"LF" | "CRLF">("LF");
  const [language, setLanguage] = useState("text");
  const [wrap, setWrap] = useState(true);
  const [minimap, setMinimap] = useState(true);
  const [message, setMessage] = useState("");
  const files = useQuery({ queryKey: ["files", path], queryFn: () => listFiles(path) });
  const file = useQuery({
    queryKey: ["files", "content", selected],
    queryFn: () => getFileContent(selected),
    enabled: Boolean(selected),
  });

  useEffect(() => {
    if (!file.data) return;
    setContent(file.data.content);
    setOriginal(file.data.content);
    setEol(file.data.eol);
    setLanguage(file.data.language);
    setMessage("");
  }, [file.data]);

  const dirty = content !== original;
  const save = useMutation({
    mutationFn: () => saveFileContent(selected, { content, eol }),
    onSuccess: () => {
      setOriginal(content);
      setMessage("已保存");
    },
    onError: () => setMessage("保存失败"),
  });

  const lines = useMemo(() => content.split(/\r?\n/), [content]);

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle>文件系统</CardTitle>
        <CardDescription>浏览当前 NoneBot 项目目录，编辑文本、Python、JSON 和 YAML 文件</CardDescription>
      </CardHeader>
      <CardContent className="grid h-[calc(100svh-12rem)] grid-cols-[300px_1fr] gap-4 max-lg:grid-cols-1">
        <div className="min-h-0 overflow-hidden rounded-lg border bg-muted/20">
          <div className="flex h-10 items-center gap-2 border-b px-3 text-sm text-muted-foreground">
            <Folder className="size-4" />
            <span className="truncate">/{files.data?.path}</span>
          </div>
          <div className="h-[calc(100%-2.5rem)] overflow-auto p-2">
            {files.data?.parent !== null && files.data?.parent !== undefined ? (
              <FileRow entry={{ name: "..", path: files.data.parent, type: "directory", size: 0, modified_at: 0 }} onOpen={(entry) => setPath(entry.path)} />
            ) : null}
            {files.data?.entries.map((entry) => (
              <FileRow
                key={entry.path}
                entry={entry}
                active={selected === entry.path}
                onOpen={(item) => {
                  if (item.type === "directory") setPath(item.path);
                  else setSelected(item.path);
                }}
              />
            ))}
          </div>
        </div>

        <div className="flex min-h-0 flex-col overflow-hidden rounded-lg border">
          <div className="flex min-h-12 flex-wrap items-center gap-2 border-b bg-muted/20 px-3">
            <FileCode className="size-4 text-muted-foreground" />
            <span className="min-w-0 flex-1 truncate text-sm font-medium">
              {selected || "选择一个文件开始编辑"}
            </span>
            {dirty ? (
              <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
                未保存
              </Badge>
            ) : null}
            <select value={language} onChange={(event) => setLanguage(event.target.value)} className="h-8 rounded-md border bg-background px-2 text-sm">
              <option value="text">Plain Text</option>
              <option value="python">Python</option>
              <option value="json">JSON</option>
              <option value="yaml">YAML</option>
            </select>
            <select value={eol} onChange={(event) => setEol(event.target.value as "LF" | "CRLF")} className="h-8 rounded-md border bg-background px-2 text-sm">
              <option value="LF">LF</option>
              <option value="CRLF">CRLF</option>
            </select>
            <Button variant="outline" size="sm" onClick={() => setWrap(!wrap)}>
              {wrap ? "自动换行" : "不换行"}
            </Button>
            <Button variant="outline" size="sm" onClick={() => setMinimap(!minimap)}>
              {minimap ? "小地图开" : "小地图关"}
            </Button>
            <Button variant="outline" size="sm" disabled={!dirty} onClick={() => setContent(original)}>
              <RotateCcw className="size-4" />
              重置
            </Button>
            <Button size="sm" disabled={!selected || !dirty || save.isPending} onClick={() => save.mutate()}>
              <Save className="size-4" />
              保存
            </Button>
          </div>
          {message ? <div className="border-b px-3 py-2 text-sm text-primary">{message}</div> : null}
          <div className="grid min-h-0 flex-1 grid-cols-[1fr_auto] bg-muted/30 text-foreground">
            <div className="grid min-h-0 grid-cols-[54px_1fr] overflow-hidden">
              <div className="select-none overflow-hidden border-r bg-muted/50 py-3 text-right font-mono text-xs leading-6 text-muted-foreground">
                {lines.map((_, index) => (
                  <div key={index} className="px-2">{index + 1}</div>
                ))}
              </div>
              <textarea
                value={content}
                onChange={(event) => setContent(event.target.value)}
                spellCheck={false}
                className={cn(
                  "h-full min-h-0 resize-none overflow-auto bg-background/70 p-3 font-mono text-sm leading-6 text-foreground outline-none placeholder:text-muted-foreground",
                  wrap ? "whitespace-pre-wrap" : "whitespace-pre",
                )}
                placeholder="文件内容"
              />
            </div>
            {minimap ? (
              <div className="hidden w-24 overflow-hidden border-l bg-muted/50 p-2 font-mono text-[3px] leading-[4px] text-muted-foreground xl:block">
                {content.slice(0, 6000)}
              </div>
            ) : null}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function FileRow({
  entry,
  active,
  onOpen,
}: {
  entry: FileEntry;
  active?: boolean;
  onOpen: (entry: FileEntry) => void;
}) {
  const Icon = entry.type === "directory" ? Folder : FileText;
  return (
    <button
      type="button"
      onClick={() => onOpen(entry)}
      className={cn(
        "flex h-8 w-full items-center gap-2 rounded-md px-2 text-left text-sm hover:bg-accent",
        active && "bg-accent text-primary",
      )}
    >
      <Icon className="size-4 shrink-0 text-muted-foreground" />
      <span className="truncate">{entry.name}</span>
    </button>
  );
}
