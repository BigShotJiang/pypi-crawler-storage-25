import { useQuery } from "@tanstack/react-query";
import {
  Boxes,
  Cpu,
  Database,
  HardDrive,
  MemoryStick,
  Plug,
  Settings,
  Workflow,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { AdminSectionCard } from "@/components/admin-section-card";
import { AdminStatCard, AdminStatsGrid } from "@/components/admin-stats";
import { ConnectedBotList } from "@/components/connected-bot-list";
import { DetailRow } from "@/components/detail-row";
import { getBots, getConfig, getPlugins, getRuntime, getRuntimeMetrics } from "@/lib/api";

export function OverviewPage() {
  const runtime = useQuery({ queryKey: ["runtime"], queryFn: getRuntime });
  const metrics = useQuery({
    queryKey: ["runtime", "metrics"],
    queryFn: getRuntimeMetrics,
    refetchInterval: 5000,
  });
  const config = useQuery({ queryKey: ["config"], queryFn: getConfig });
  const plugins = useQuery({ queryKey: ["plugins"], queryFn: getPlugins });
  const bots = useQuery({
    queryKey: ["bots"],
    queryFn: getBots,
    refetchInterval: 5000,
  });

  const loaded = plugins.data?.loaded ?? [];
  const matchers = loaded.reduce((total, plugin) => total + plugin.matcher_count, 0);
  const memory = metrics.data?.memory;
  const disk = metrics.data?.disk;
  const process = metrics.data?.process;

  return (
    <div className="grid gap-4">
      <AdminStatsGrid className="mt-0">
        <AdminStatCard
          title="CPU"
          value={formatPercent(metrics.data?.cpu.percent)}
          desc={formatCpuDesc(metrics.data)}
          icon={Cpu}
          progress={metrics.data?.cpu.percent}
          tone={getUsageTone(metrics.data?.cpu.percent)}
        />
        <AdminStatCard
          title="内存"
          value={formatPercent(memory?.percent)}
          desc={memory ? `${formatBytes(memory.used)} / ${formatBytes(memory.total)}` : "系统内存"}
          icon={MemoryStick}
          progress={memory?.percent}
          tone={getUsageTone(memory?.percent)}
        />
        <AdminStatCard
          title="进程内存"
          value={process ? formatBytes(process.memory_rss) : "-"}
          desc={process ? `RSS / ${process.threads} 线程` : "当前进程"}
          icon={Database}
          progress={process?.memory_percent}
          tone="primary"
        />
        <AdminStatCard
          title="磁盘"
          value={formatPercent(disk?.percent)}
          desc={disk ? `${formatBytes(disk.used)} / ${formatBytes(disk.total)}` : "工作目录所在磁盘"}
          icon={HardDrive}
          progress={disk?.percent}
          tone={getUsageTone(disk?.percent)}
        />
        <AdminStatCard title="已加载插件" value={loaded.length ? String(loaded.length) : "-"} desc="当前实例" icon={Plug} tone="primary" />
        <AdminStatCard title="可用插件" value={String(plugins.data?.available.length ?? "-")} desc="NoneBot 可发现插件" icon={Boxes} tone="primary" />
        <AdminStatCard title="配置项" value={String(config.data?.items.length ?? "-")} desc="驱动配置展开项" icon={Settings} tone="primary" />
        <AdminStatCard title="Matcher 总数" value={String(matchers)} desc="当前已注册响应器" icon={Workflow} tone="primary" />
      </AdminStatsGrid>

      <div className="grid grid-cols-[.85fr_1.15fr] gap-4 max-lg:grid-cols-1">
        <Card className="gap-0 overflow-hidden p-0">
          <AdminSectionCard
            title="连接的 Bot"
            description="当前 NoneBot 实例已连接的机器人"
            className="[&>div]:px-4 [&>div]:py-4"
            action={bots.isLoading ? <Badge>加载中</Badge> : null}
          >
            <ConnectedBotList
              data={bots.data}
              isError={bots.isError}
              emptyDescription="例如 NapCat / OneBot 适配器连接后会显示在这里。"
            />
          </AdminSectionCard>
        </Card>

        <Card className="gap-0 overflow-hidden p-0">
          <AdminSectionCard
            title="运行信息"
            description="当前进程、驱动、版本与挂载路径"
            className="[&>div]:px-4 [&>div]:py-4"
            action={
              runtime.isLoading || metrics.isLoading || config.isLoading ? (
                <Badge>加载中</Badge>
              ) : null
            }
          >
            <div className="grid gap-3">
              <div className="grid grid-cols-2 gap-3 max-md:grid-cols-1">
                <DetailPanel>
                  <DetailRow label="驱动" value={runtime.data?.driver} />
                  <DetailRow label="NoneBot" value={runtime.data?.nonebot_version} />
                  <DetailRow label="Python" value={runtime.data?.python_version} />
                  <DetailRow label="进程 PID" value={runtime.data?.pid} />
                </DetailPanel>
                <DetailPanel>
                  <DetailRow
                    label="进程运行"
                    value={process ? formatDuration(Date.now() / 1000 - process.started_at) : "-"}
                  />
                  <DetailRow
                    label="系统运行"
                    value={
                      metrics.data
                        ? formatDuration(metrics.data.timestamp - metrics.data.system.started_at)
                        : "-"
                    }
                  />
                  <DetailRow label="挂载路径" value={runtime.data?.webui_path} />
                  <DetailRow
                    label="监控更新时间"
                    value={
                      metrics.data
                        ? new Date(metrics.data.timestamp * 1000).toLocaleTimeString()
                        : "-"
                    }
                  />
                </DetailPanel>
              </div>
              <DetailPanel>
                <DetailRow label="平台" value={runtime.data?.platform} valueClassName="break-all" />
                <DetailRow label="工作目录" value={runtime.data?.cwd} valueClassName="break-all" />
              </DetailPanel>
            </div>
          </AdminSectionCard>
        </Card>
      </div>
    </div>
  );
}

function DetailPanel({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid gap-3 rounded-lg border bg-muted/25 p-4">{children}</div>
  );
}

function formatPercent(value?: number) {
  return typeof value === "number" ? `${value.toFixed(1)}%` : "-";
}

function getUsageTone(value?: number) {
  if (typeof value !== "number") {
    return "primary";
  }
  if (value >= 90) {
    return "danger";
  }
  if (value >= 80) {
    return "warning";
  }
  return "primary";
}

function formatBytes(value?: number) {
  if (typeof value !== "number") {
    return "-";
  }

  const units = ["B", "KB", "MB", "GB", "TB"];
  let size = value;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${size.toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

function formatDuration(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) {
    return "-";
  }

  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (days > 0) {
    return `${days} 天 ${hours} 小时`;
  }
  if (hours > 0) {
    return `${hours} 小时 ${minutes} 分钟`;
  }
  return `${minutes} 分钟`;
}

function formatCpuDesc(metrics?: Awaited<ReturnType<typeof getRuntimeMetrics>>) {
  if (!metrics) {
    return "系统 CPU";
  }

  const physical = metrics.cpu.physical_count ? `${metrics.cpu.physical_count} 物理核` : "";
  const logical = metrics.cpu.logical_count ? `${metrics.cpu.logical_count} 逻辑核` : "";
  return [physical, logical].filter(Boolean).join(" / ") || "系统 CPU";
}
