import {
  Activity,
  Bell,
  Bot,
  Check,
  ChevronDown,
  Copy,
  Database,
  Gauge,
  Layers,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  Trash2,
} from "lucide-react";
import { useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { AdminSectionCard } from "@/components/admin-section-card";
import { AdminStatCard, AdminStatsGrid } from "@/components/admin-stats";
import { DetailRow } from "@/components/detail-row";
import { TableSkeleton } from "@/components/table-skeleton";
import { cn } from "@/lib/utils";

export function ComponentsPage() {
  const [enabled, setEnabled] = useState(true);

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-xl font-semibold">组件挑选</h1>
        <p className="text-sm text-muted-foreground">
          开发用组件样板页。后续你可以直接指定这里的组件样式来套到具体页面。
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4 max-lg:grid-cols-1">
        <PreviewCard title="按钮" desc="操作、提交、图标按钮">
          <div className="flex flex-wrap gap-2">
            <Button>默认</Button>
            <Button variant="outline">描边</Button>
            <Button variant="secondary">次要</Button>
            <Button variant="ghost">幽灵</Button>
            <Button variant="destructive">危险</Button>
            <Button variant="link">链接</Button>
            <Button size="icon" variant="outline">
              <Settings className="size-4" />
            </Button>
          </div>
        </PreviewCard>

        <PreviewCard title="表单控件" desc="输入框、开关、状态">
          <div className="grid gap-3">
            <Input placeholder="搜索插件或配置" />
            <div className="flex items-center justify-between rounded-md border p-2">
              <span className="text-sm">启用提供商</span>
              <Switch checked={enabled} onCheckedChange={setEnabled} />
            </div>
          </div>
        </PreviewCard>

        <PreviewCard title="徽标" desc="状态、分类、计数">
          <div className="flex flex-wrap gap-2">
            <Badge>默认</Badge>
            <Badge className="bg-primary text-primary-foreground">已启用</Badge>
            <Badge className="border-destructive/40 bg-destructive/10 text-destructive">
              失败
            </Badge>
            <Badge className="bg-emerald-500/10 text-emerald-600">在线</Badge>
          </div>
        </PreviewCard>

        <PreviewCard title="工具条" desc="搜索、刷新、更多操作">
          <div className="flex items-center gap-2">
            <div className="flex h-9 min-w-0 flex-1 items-center gap-2 rounded-md border px-3 text-sm text-muted-foreground">
              <Search className="size-4" />
              搜索
            </div>
            <Button size="icon" variant="outline">
              <Bell className="size-4" />
            </Button>
            <Button size="icon" variant="outline">
              <MoreHorizontal className="size-4" />
            </Button>
          </div>
        </PreviewCard>
      </div>

      <div className="grid grid-cols-[1fr_1fr] gap-4 max-xl:grid-cols-1">
        <PreviewCard title="设置表单块" desc="适合模型、插件、系统配置页面">
          <div className="grid gap-4 rounded-lg border bg-muted/20 p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">基础信息</div>
                <div className="text-xs text-muted-foreground">连接配置与默认行为</div>
              </div>
              <Switch checked />
            </div>
            <div className="grid grid-cols-[1fr_180px] gap-3 max-md:grid-cols-1">
              <Field label="名称">
                <Input value="OpenAI" readOnly />
              </Field>
              <Field label="默认模型">
                <select className="h-9 rounded-md border bg-background px-3 text-sm">
                  <option>gpt-4o-mini</option>
                </select>
              </Field>
            </div>
            <Field label="Base URL">
              <Input value="https://api.openai.com/v1" readOnly />
            </Field>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline">
                <Copy className="size-4" />
                复制配置
              </Button>
              <Button variant="outline">
                <Check className="size-4" />
                测试连接
              </Button>
            </div>
          </div>
        </PreviewCard>

        <PreviewCard title="模型列表块" desc="适合提供商模型、插件列表、任务列表">
          <div className="overflow-hidden rounded-md border bg-background">
            <div className="grid grid-cols-[1fr_80px_90px_44px] gap-2 border-b bg-muted/50 px-3 py-2 text-xs font-medium text-muted-foreground">
              <div>名称</div>
              <div>状态</div>
              <div>操作</div>
              <div />
            </div>
            {["gpt-4o-mini", "gpt-4.1-mini", "custom-model"].map((model, index) => (
              <div
                key={model}
                className="grid grid-cols-[1fr_80px_90px_44px] items-center gap-2 border-b px-3 py-2 text-sm last:border-b-0"
              >
                <div className="min-w-0">
                  <div className="truncate font-mono">{model}</div>
                  <div
                    className={cn(
                      "text-xs text-muted-foreground",
                      index === 2 && "text-destructive",
                    )}
                  >
                    {index === 0 ? "128ms" : index === 1 ? "未测速" : "失败"}
                  </div>
                </div>
                <Switch checked={index !== 2} />
                <Button size="sm" variant={index === 0 ? "default" : "outline"}>
                  默认
                </Button>
                <Button size="icon" variant="outline">
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ))}
          </div>
        </PreviewCard>

        <PreviewCard title="概览统计" desc="替代信息面板，适合首页和状态概览">
          <div className="grid grid-cols-2 gap-2">
            <AdminStatCard title="已安装插件" value="12" desc="本地可用插件数量" icon={Layers} />
            <AdminStatCard title="启用模型" value="4" desc="可用于聊天的模型" icon={Bot} />
            <AdminStatCard title="平均延迟" value="168ms" desc="最近一次测速结果" icon={Gauge} />
            <AdminStatCard title="运行状态" value="正常" desc="NoneBot 运行中" icon={Activity} />
          </div>
        </PreviewCard>

        <PreviewCard title="空状态" desc="适合无模型、无插件、无搜索结果">
          <div className="flex min-h-48 flex-col items-center justify-center rounded-lg border border-dashed bg-muted/20 p-6 text-center">
            <Bot className="mb-3 size-8 text-muted-foreground" />
            <div className="font-medium">暂无模型</div>
            <div className="mt-1 text-sm text-muted-foreground">
              获取模型列表或手动添加自定义模型。
            </div>
            <Button className="mt-4" variant="outline">
              <Plus className="size-4" />
              添加模型
            </Button>
          </div>
        </PreviewCard>
      </div>

      <PreviewCard title="密集表格头" desc="适合后续插件商店和配置管理">
        <div className="overflow-hidden rounded-md border">
          <div className="flex items-center gap-2 border-b bg-muted/40 p-3">
            <div className="flex h-9 min-w-0 flex-1 items-center gap-2 rounded-md border bg-background px-3 text-sm text-muted-foreground">
              <Search className="size-4" />
              搜索名称、描述或标签
            </div>
            <Button variant="outline">
              筛选
              <ChevronDown className="size-4" />
            </Button>
            <Button>
              <Plus className="size-4" />
              新增
            </Button>
          </div>
          <div className="grid grid-cols-[1fr_120px_120px_80px] border-b bg-muted/30 px-3 py-2 text-xs font-medium text-muted-foreground">
            <div>名称</div>
            <div>类型</div>
            <div>状态</div>
            <div>操作</div>
          </div>
          {["nonebot-plugin-webui", "nonebot-plugin-apscheduler", "nonebot-plugin-alconna"].map(
            (name) => (
              <div
                key={name}
                className="grid grid-cols-[1fr_120px_120px_80px] items-center border-b px-3 py-2 text-sm last:border-b-0"
              >
                <div className="truncate font-medium">{name}</div>
                <div className="text-muted-foreground">插件</div>
                <div>
                  <Badge className="bg-emerald-500/10 text-emerald-600">可用</Badge>
                </div>
                <div>
                  <Button size="icon" variant="ghost">
                    <MoreHorizontal className="size-4" />
                  </Button>
                </div>
              </div>
            ),
          )}
        </div>
      </PreviewCard>

      <div className="grid gap-3">
        <div>
          <h2 className="text-base font-semibold">Pos Admin 通用组件</h2>
          <p className="text-sm text-muted-foreground">
            从 pos-admin 抽过来的低依赖组件，适合配置页、详情页、管理表格和概览页。
          </p>
        </div>

        <div className="overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm">
          <AdminSectionCard
            title="分区设置卡片"
            description="适合把一个页面拆成多个连续配置区域，比普通卡片更像后台设置页。"
            action={<Button size="sm">保存</Button>}
          >
            <div className="grid gap-3">
              <Field label="服务名称">
                <Input value="NoneBot WebUI" readOnly />
              </Field>
              <div className="flex items-center justify-between rounded-md border bg-background px-3 py-2">
                <div>
                  <div className="text-sm font-medium">自动刷新状态</div>
                  <div className="text-xs text-muted-foreground">后台运行状态变化时同步更新页面</div>
                </div>
                <Switch checked />
              </div>
            </div>
          </AdminSectionCard>

          <AdminSectionCard
            title="详情信息行"
            description="适合抽屉、详情页、运行状态面板里的键值信息。"
          >
            <div className="grid gap-3 rounded-lg border bg-background p-4">
              <DetailRow icon={Bot} label="当前实例" value="local-nonebot" />
              <DetailRow icon={Database} label="配置目录" value=".nonebot-plugin-webui" />
              <DetailRow
                icon={Activity}
                label="连接状态"
                value={<Badge className="bg-emerald-500/10 text-emerald-600">正常</Badge>}
              />
            </div>
          </AdminSectionCard>
        </div>

        <AdminStatsGrid>
          <AdminStatCard title="已安装插件" value="12" desc="本地可用插件数量" icon={Layers} />
          <AdminStatCard title="启用模型" value="4" desc="可用于聊天的模型" icon={Bot} />
          <AdminStatCard title="平均延迟" value="168ms" desc="最近一次测速结果" icon={Gauge} />
          <AdminStatCard title="运行状态" value="正常" desc="NoneBot 运行中" icon={Activity} />
        </AdminStatsGrid>

        <div className="grid grid-cols-[1fr_1fr] gap-4 max-xl:grid-cols-1">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>CardAction / CardFooter</CardTitle>
                <CardDescription>pos-admin 卡片结构，右上角可直接放操作。</CardDescription>
              </div>
              <CardAction>
                <Button size="sm" variant="outline">
                  <Plus className="size-4" />
                  添加
                </Button>
              </CardAction>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
                这个结构适合插件商店条目、模型提供商详情、配置组详情。
              </div>
            </CardContent>
            <CardFooter className="justify-between border-t text-sm text-muted-foreground">
              <span>最后同步：刚刚</span>
              <Button size="sm" variant="link">
                查看详情
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>表格骨架屏</CardTitle>
              <CardDescription>适合插件列表、模型列表加载中占位。</CardDescription>
            </CardHeader>
            <CardContent>
              <TableSkeleton rows={5} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function PreviewCard({
  title,
  desc,
  children,
}: {
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{desc}</CardDescription>
      </CardHeader>
      <CardContent>
        {children}
      </CardContent>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
    </label>
  );
}
