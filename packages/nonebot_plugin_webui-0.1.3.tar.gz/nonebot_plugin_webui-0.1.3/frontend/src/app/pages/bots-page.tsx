import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Cable, Download, Plus, Save, Trash2 } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { AdminSectionCard } from "@/components/admin-section-card";
import { ConnectedBotList } from "@/components/connected-bot-list";
import { DetailRow } from "@/components/detail-row";
import {
  type BotAdapterStatus,
  type BotConnectionSettings,
  type ConnectedBot,
  type WebuiTask,
  type WebuiTaskMessage,
  getBotSettings,
  getBots,
  installBotAdapter,
  taskWebSocketUrl,
  updateBotSettings,
} from "@/lib/api";
import { cn } from "@/lib/utils";

const adapterOptions = [
  {
    value: "onebot-v11",
    label: "OneBot v11",
    install: "pip install nonebot-adapter-onebot",
    modes: ["reverse-ws", "forward-ws", "http"],
    defaults: { name: "NapCat QQ", connection_mode: "reverse-ws", path: "/onebot/v11/ws" },
  },
  {
    value: "onebot-v12",
    label: "OneBot v12",
    install: "pip install nonebot-adapter-onebot",
    modes: ["reverse-ws", "forward-ws", "http"],
    defaults: { name: "OneBot v12", connection_mode: "reverse-ws", path: "/onebot/v12/ws" },
  },
  {
    value: "console",
    label: "Console",
    install: "pip install nonebot-adapter-console",
    modes: ["console"],
    defaults: { name: "本地 Console", connection_mode: "console", path: "/" },
  },
  {
    value: "telegram",
    label: "Telegram",
    install: "pip install nonebot-adapter-telegram",
    modes: ["platform"],
    defaults: { name: "Telegram Bot", connection_mode: "platform", path: "/" },
  },
  {
    value: "discord",
    label: "Discord",
    install: "pip install nonebot-adapter-discord",
    modes: ["platform"],
    defaults: { name: "Discord Bot", connection_mode: "platform", path: "/" },
  },
] as const;

const modeOptions = [
  { value: "reverse-ws", label: "反向 WebSocket" },
  { value: "forward-ws", label: "正向 WebSocket" },
  { value: "http", label: "HTTP" },
  { value: "console", label: "本地 Console" },
  { value: "platform", label: "平台 API" },
] as const;

function createConnection(): BotConnectionSettings {
  const id = crypto.randomUUID();
  return {
    id,
    name: "NapCat QQ",
    enabled: true,
    adapter: "onebot-v11",
    connection_mode: "reverse-ws",
    host: "127.0.0.1",
    port: 8080,
    path: "/onebot/v11/ws",
    access_token: "",
    self_id: "",
    note: "",
  };
}

export function BotsPage() {
  const queryClient = useQueryClient();
  const connectedBots = useQuery({
    queryKey: ["bots"],
    queryFn: getBots,
    refetchInterval: 5000,
  });
  const settings = useQuery({ queryKey: ["settings", "bots"], queryFn: getBotSettings });
  const [connections, setConnections] = useState<BotConnectionSettings[]>([]);
  const [savedConnections, setSavedConnections] = useState<BotConnectionSettings[]>([]);
  const [selectedId, setSelectedId] = useState<string>("");
  const [installMessage, setInstallMessage] = useState<string>("");
  const [installTask, setInstallTask] = useState<WebuiTask | null>(null);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    return () => socketRef.current?.close();
  }, []);

  useEffect(() => {
    if (!settings.data) {
      return;
    }
    setConnections(settings.data.connections);
    setSavedConnections(settings.data.connections);
    setSelectedId((current) => current || settings.data.connections[0]?.id || "");
  }, [settings.data]);

  const selected = useMemo(
    () => connections.find((item) => item.id === selectedId) ?? connections[0],
    [connections, selectedId],
  );

  const saveMutation = useMutation({
    mutationFn: (nextConnections?: BotConnectionSettings[]) =>
      updateBotSettings({ connections: nextConnections ?? connections }),
    onSuccess: (data) => {
      setConnections(data.connections);
      setSavedConnections(data.connections);
      void queryClient.invalidateQueries({ queryKey: ["settings", "bots"] });
    },
  });

  const installMutation = useMutation({
    mutationFn: (adapter: string) => installBotAdapter(adapter),
    onMutate: () => {
      setInstallMessage("正在创建安装任务...");
      setInstallTask(null);
      socketRef.current?.close();
    },
    onSuccess: (data) => {
      setInstallTask(data.task);
      setInstallMessage("安装任务已创建，正在连接实时日志...");
      connectTaskSocket(data.task_id);
    },
    onError: (error) => {
      const message = error instanceof Error ? error.message : "安装请求失败";
      setInstallMessage(message);
    },
  });

  const connectTaskSocket = (taskId: string) => {
    const socket = new WebSocket(taskWebSocketUrl(taskId));
    socketRef.current = socket;

    socket.onopen = () => setInstallMessage("安装中，正在接收实时日志...");
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data) as WebuiTaskMessage;
      if (message.type === "error") {
        setInstallMessage(message.message);
        return;
      }

      setInstallTask(message.task);
      if (message.type === "done") {
        const result = message.task.result;
        setInstallMessage(
          message.task.status === "success"
            ? `${result?.label || "适配器"} 安装完成，重启 NoneBot 后即可自动注册。`
            : `${result?.label || "适配器"} 安装失败：${
                message.task.error || result?.output || `退出码 ${result?.exit_code ?? "-"}`
              }`,
        );
        void queryClient.invalidateQueries({ queryKey: ["settings", "bots"] });
      }
    };
    socket.onerror = () => setInstallMessage("实时日志连接失败，请检查后端是否已重启。");
    socket.onclose = () => {
      if (socketRef.current === socket) {
        socketRef.current = null;
      }
    };
  };

  const updateSelected = (patch: Partial<BotConnectionSettings>) => {
    if (!selected) {
      return;
    }
    setConnections((items) =>
      items.map((item) => (item.id === selected.id ? { ...item, ...patch } : item)),
    );
  };

  const addConnection = () => {
    const item = createConnection();
    setConnections((items) => [...items, item]);
    setSelectedId(item.id);
  };

  const removeSelected = () => {
    if (!selected) {
      return;
    }
    const next = connections.filter((item) => item.id !== selected.id);
    setSelectedId(next[0]?.id || "");
    if (savedConnections.some((item) => item.id === selected.id)) {
      saveMutation.mutate(next);
      return;
    }
    setConnections(next);
  };

  const adapter = adapterOptions.find((item) => item.value === selected?.adapter);
  const hasUnsavedChanges = !isSameConnections(connections, savedConnections);
  const selectedSaved = selected ? savedConnections.some((item) => item.id === selected.id) : false;
  const adapterStatus = getCurrentAdapterStatus(
    selected?.adapter,
    settings.data?.adapters,
    selected?.runtime,
  );
  const availableModeOptions = getModeOptions(selected?.adapter);
  const connectionAddress = selected ? getConnectionAddress(selected) : "-";
  const envSnippet = selected ? getEnvSnippet(selected) : "";
  const showNetworkFields = selected ? usesNetworkFields(selected.connection_mode) : false;
  const selectedConnectionBots = selected
    ? {
        items: (connectedBots.data?.items ?? []).filter((bot) =>
          isBotMatchedConnection(bot, selected),
        ),
        total: (connectedBots.data?.items ?? []).filter((bot) =>
          isBotMatchedConnection(bot, selected),
        ).length,
      }
    : undefined;

  const updateAdapter = (value: string) => {
    const option = adapterOptions.find((item) => item.value === value);
    if (!option) {
      updateSelected({ adapter: value });
      return;
    }

    const nextMode = (option.modes as readonly string[]).includes(selected?.connection_mode || "")
      ? selected?.connection_mode
      : option.defaults.connection_mode;

    updateSelected({
      adapter: option.value,
      connection_mode: nextMode,
      path: option.defaults.path,
      name: selected?.name || option.defaults.name,
    });
  };

  const updateMode = (value: string) => {
    updateSelected({
      connection_mode: value,
      path: getDefaultPath(selected?.adapter, value),
    });
  };

  return (
    <div className="grid gap-4">
      <div>
        <h1 className="text-xl font-semibold">机器人连接</h1>
        <p className="text-sm text-muted-foreground">
          管理适配器连接配置，并查看当前已连接的 Bot 实例。
        </p>
      </div>

      <div className="grid grid-cols-[280px_minmax(0,1fr)] gap-4 max-lg:grid-cols-1">
        <Card className="gap-0 overflow-hidden p-0">
          <AdminSectionCard
            title="连接配置"
            description="保存多个适配器连接方案"
            className="[&>div]:px-4 [&>div]:py-4"
            action={
              <Button size="sm" onClick={addConnection}>
                <Plus className="size-4" />
                新增
              </Button>
            }
          >
            <div className="grid gap-2">
              {connections.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSelectedId(item.id)}
                  className={cn(
                    "grid gap-1 rounded-lg border bg-muted/25 p-3 text-start transition-colors",
                    selected?.id === item.id && "border-primary/50 bg-accent text-accent-foreground",
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-medium">{item.name}</span>
                    <Badge className={getConnectionBadgeClass(item, savedConnections)}>
                      {getConnectionBadgeText(item, savedConnections)}
                    </Badge>
                  </div>
                  <div className="truncate text-xs text-muted-foreground">
                    {adapterOptions.find((option) => option.value === item.adapter)?.label ||
                      item.adapter}
                    {" / "}
                    {modeOptions.find((option) => option.value === item.connection_mode)?.label ||
                      item.connection_mode}
                  </div>
                </button>
              ))}
              {!connections.length ? (
                <div className="rounded-lg border border-dashed bg-muted/25 p-6 text-center text-sm text-muted-foreground">
                  暂无连接配置
                </div>
              ) : null}
            </div>
          </AdminSectionCard>
        </Card>

        <div className="grid gap-4">
          <Card className="gap-0 overflow-hidden p-0">
            <AdminSectionCard
              title="当前配置连接状态"
              description="只显示左侧当前选中配置对应的 Bot"
              className="[&>div]:px-4 [&>div]:py-4"
              action={connectedBots.isLoading ? <Badge>刷新中</Badge> : null}
            >
              <ConnectedBotList
                data={selectedConnectionBots}
                isError={connectedBots.isError}
                emptyDescription="当前配置还没有匹配到已连接的 Bot，请填写 Bot self_id 后再判断对应关系。"
              />
            </AdminSectionCard>
          </Card>

          <Card className="gap-0 overflow-hidden p-0">
            <AdminSectionCard
              title="适配器配置"
              description={
                hasUnsavedChanges
                  ? "当前有未保存改动，保存后才会写入配置文件"
                  : "保存后会在下次 NoneBot 启动时自动尝试加载对应适配器"
              }
              className="[&>div]:px-4 [&>div]:py-4"
              action={
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={removeSelected} disabled={!selected}>
                    <Trash2 className="size-4" />
                    {selectedSaved ? "删除配置" : "删除草稿"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => saveMutation.mutate(undefined)}
                    disabled={saveMutation.isPending || !hasUnsavedChanges}
                  >
                    <Save className="size-4" />
                    {hasUnsavedChanges ? "保存改动" : "已保存"}
                  </Button>
                </div>
              }
            >
              {selected ? (
                <div className="grid gap-4">
                  {hasUnsavedChanges ? (
                    <div className="rounded-lg border border-primary/20 bg-primary/10 px-3 py-2 text-sm text-primary">
                      新增和修改会先保留在当前页面，点击保存改动后才会真正写入配置。删除已保存配置会立即提交。
                    </div>
                  ) : null}
                  <div className="flex items-center justify-between rounded-lg border bg-muted/25 p-3">
                    <div>
                      <div className="text-sm font-medium">启用连接</div>
                      <div className="text-xs text-muted-foreground">停用后只保留配置，不参与生成连接方案</div>
                    </div>
                    <Switch
                      checked={selected.enabled}
                      onCheckedChange={(enabled) => updateSelected({ enabled })}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 max-md:grid-cols-1">
                    <Field label="名称">
                      <Input
                        value={selected.name}
                        onChange={(event) => updateSelected({ name: event.target.value })}
                      />
                    </Field>
                    <Field label="Bot self_id">
                      <Input
                        value={selected.self_id}
                        placeholder="例如 QQ 号"
                        onChange={(event) => updateSelected({ self_id: event.target.value })}
                      />
                    </Field>
                    <Field label="适配器">
                      <NativeSelect
                        value={selected.adapter}
                        onChange={updateAdapter}
                        options={adapterOptions}
                      />
                    </Field>
                    <Field label="连接方式">
                      <NativeSelect
                        value={selected.connection_mode}
                        onChange={updateMode}
                        options={availableModeOptions}
                      />
                    </Field>
                    {showNetworkFields ? (
                      <>
                        <Field label="Host">
                          <Input
                            value={selected.host}
                            onChange={(event) => updateSelected({ host: event.target.value })}
                          />
                        </Field>
                        <Field label="Port">
                          <Input
                            type="number"
                            value={selected.port}
                            onChange={(event) => updateSelected({ port: Number(event.target.value) })}
                          />
                        </Field>
                        <Field label="Path">
                          <Input
                            value={selected.path}
                            onChange={(event) => updateSelected({ path: event.target.value })}
                          />
                        </Field>
                      </>
                    ) : null}
                    <Field label="Access Token">
                      <Input
                        value={selected.access_token}
                        placeholder="没有就留空"
                        onChange={(event) => updateSelected({ access_token: event.target.value })}
                      />
                    </Field>
                  </div>

                  <Field label="备注">
                    <Input
                      value={selected.note}
                      placeholder="例如 NapCat 本机反向 WebSocket"
                      onChange={(event) => updateSelected({ note: event.target.value })}
                    />
                  </Field>

                  <div className="grid gap-3 rounded-lg border bg-muted/25 p-4">
                    <div className="flex items-center justify-between gap-4 text-sm">
                      <span className="flex shrink-0 items-center gap-2 text-muted-foreground">
                        <Cable className="size-3.5" />
                        安装命令
                      </span>
                      <div className="flex min-w-0 items-center justify-end gap-2">
                        <span className="truncate text-right font-medium">
                          {adapter?.install || "-"}
                        </span>
                        {adapterStatus && !adapterStatus.installed ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => installMutation.mutate(selected.adapter)}
                            disabled={installMutation.isPending || installTask?.status === "running"}
                          >
                            <Download className="size-4" />
                            {installMutation.isPending || installTask?.status === "running"
                              ? "安装中"
                              : "安装"}
                          </Button>
                        ) : null}
                      </div>
                    </div>
                    <DetailRow
                      label="适配器包"
                      value={adapterStatus.installed ? "已安装" : "未安装"}
                      valueClassName={adapterStatus?.installed ? undefined : "text-destructive"}
                    />
                    <DetailRow
                      label="本次启动"
                      value={
                        adapterStatus?.registered
                          ? "已注册"
                          : selected.enabled && adapterStatus?.installed
                            ? "未生效，需重启"
                            : "未注册"
                      }
                      valueClassName={adapterStatus?.registered ? undefined : "text-muted-foreground"}
                    />
                    <DetailRow
                      label="连接地址"
                      value={connectionAddress}
                      valueClassName="break-all"
                    />
                    {envSnippet ? (
                      <DetailRow
                        label=".env 配置"
                        value={envSnippet}
                        valueClassName="break-all"
                      />
                    ) : null}
                    {adapterStatus?.error ? (
                      <DetailRow
                        label="注册错误"
                        value={adapterStatus.error}
                        valueClassName="break-all text-destructive"
                      />
                    ) : null}
                    <DetailRow
                      label="生效方式"
                      value="保存后插件会在下次启动时按启用配置自动注册 Adapter；如果当前显示未生效，重启 NoneBot 后再查看状态。"
                      valueClassName="break-all"
                    />
                    {installMessage ? (
                      <div
                        className={cn(
                          "rounded-md border px-3 py-2 text-xs",
                          installMessage.includes("失败")
                            ? "border-destructive/30 bg-destructive/10 text-destructive"
                            : "border-primary/20 bg-primary/10 text-primary",
                        )}
                      >
                        {installMessage}
                      </div>
                    ) : null}
                    {installTask?.logs.length ? (
                      <pre className="max-h-56 overflow-auto rounded-md border bg-background p-3 text-xs leading-relaxed text-muted-foreground">
                        {installTask.logs.join("\n")}
                      </pre>
                    ) : null}
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-dashed bg-muted/25 p-6 text-center text-sm text-muted-foreground">
                  先新增一个连接配置。
                </div>
              )}
            </AdminSectionCard>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5 text-sm">
      <span className="font-medium">{label}</span>
      {children}
    </label>
  );
}

function getModeOptions(adapter?: string) {
  const option = adapterOptions.find((item) => item.value === adapter);
  if (!option) {
    return modeOptions;
  }
  return modeOptions.filter((item) => (option.modes as readonly string[]).includes(item.value));
}

function getConnectionBadgeText(
  connection: BotConnectionSettings,
  savedConnections: BotConnectionSettings[],
) {
  const saved = savedConnections.find((item) => item.id === connection.id);
  if (!saved) {
    return "未保存";
  }
  if (!isSameConnection(connection, saved)) {
    return "已修改";
  }
  return connection.enabled ? "启用" : "停用";
}

function getConnectionBadgeClass(
  connection: BotConnectionSettings,
  savedConnections: BotConnectionSettings[],
) {
  const saved = savedConnections.find((item) => item.id === connection.id);
  if (!saved || !isSameConnection(connection, saved)) {
    return "border-primary/30 bg-primary/10 text-primary";
  }
  return connection.enabled ? undefined : "bg-muted text-muted-foreground";
}

function isSameConnections(
  current: BotConnectionSettings[],
  saved: BotConnectionSettings[],
) {
  if (current.length !== saved.length) {
    return false;
  }
  return current.every((item, index) => isSameConnection(item, saved[index]));
}

function isSameConnection(left: BotConnectionSettings, right?: BotConnectionSettings) {
  if (!right) {
    return false;
  }
  return JSON.stringify(normalizeConnectionForCompare(left)) === JSON.stringify(normalizeConnectionForCompare(right));
}

function normalizeConnectionForCompare(connection: BotConnectionSettings) {
  return {
    id: connection.id,
    name: connection.name,
    enabled: connection.enabled,
    adapter: connection.adapter,
    connection_mode: connection.connection_mode,
    host: connection.host,
    port: connection.port,
    path: connection.path,
    access_token: connection.access_token,
    self_id: connection.self_id,
    note: connection.note,
  };
}

function isBotMatchedConnection(bot: ConnectedBot, connection: BotConnectionSettings) {
  if (!connection.self_id || bot.self_id !== connection.self_id) {
    return false;
  }

  if (connection.adapter === "onebot-v11") {
    return normalizeText(bot.adapter).includes("onebot v11");
  }
  if (connection.adapter === "onebot-v12") {
    return normalizeText(bot.adapter).includes("onebot v12");
  }
  if (connection.adapter === "console") {
    return normalizeText(bot.adapter).includes("console");
  }
  if (connection.adapter === "telegram") {
    return normalizeText(bot.adapter).includes("telegram");
  }
  if (connection.adapter === "discord") {
    return normalizeText(bot.adapter).includes("discord");
  }
  return false;
}

function normalizeText(value?: string | null) {
  return (value || "").trim().toLowerCase();
}

function getCurrentAdapterStatus(
  adapter?: string,
  statuses: BotAdapterStatus[] = [],
  runtime?: BotConnectionSettings["runtime"],
): BotAdapterStatus {
  const savedStatus = statuses.find((item) => item.adapter === adapter);
  if (savedStatus) {
    return savedStatus;
  }
  if (runtime && runtime.adapter === adapter) {
    return runtime;
  }

  const option = adapterOptions.find((item) => item.value === adapter);
  return {
    adapter: adapter || "",
    label: option?.label || adapter || "未知适配器",
    supported: Boolean(option),
    installed: false,
    registered: false,
    install_command: option?.install || "",
    error: null,
  };
}

function getDefaultPath(adapter?: string, mode?: string) {
  if (mode === "console" || mode === "platform") {
    return "/";
  }
  if (mode === "forward-ws" || mode === "http") {
    return "/";
  }
  if (adapter === "onebot-v12") {
    return "/onebot/v12/ws";
  }
  return "/onebot/v11/ws";
}

function usesNetworkFields(mode: string) {
  return mode === "reverse-ws" || mode === "forward-ws" || mode === "http";
}

function normalizePath(path: string) {
  const value = path.trim() || "/";
  return value.startsWith("/") ? value : `/${value}`;
}

function getConnectionAddress(connection: BotConnectionSettings) {
  const path = normalizePath(connection.path);
  if (connection.connection_mode === "console") {
    return "本地终端交互，无需连接地址";
  }
  if (connection.connection_mode === "platform") {
    return "由平台适配器配置项决定，无固定连接地址";
  }
  if (connection.connection_mode === "http") {
    return `http://${connection.host}:${connection.port}${path}`;
  }
  return `ws://${connection.host}:${connection.port}${path}`;
}

function getEnvSnippet(connection: BotConnectionSettings) {
  if (connection.adapter !== "onebot-v11" && connection.adapter !== "onebot-v12") {
    return "";
  }

  const prefix = connection.adapter === "onebot-v12" ? "ONEBOT_V12" : "ONEBOT";
  const id = connection.self_id || (connection.adapter === "onebot-v12" ? "你的Bot ID" : "你的QQ号");

  if (connection.connection_mode === "forward-ws") {
    return `${prefix}_WS_URLS=["ws://${connection.host}:${connection.port}"]`;
  }
  if (connection.connection_mode === "http") {
    return `${prefix}_API_ROOTS={"${id}": "http://${connection.host}:${connection.port}/"}`;
  }
  return "";
}

function NativeSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (value: string) => void;
  options: readonly { value: string; label: string }[];
}) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="h-9 rounded-md border bg-background px-3 text-sm outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}
