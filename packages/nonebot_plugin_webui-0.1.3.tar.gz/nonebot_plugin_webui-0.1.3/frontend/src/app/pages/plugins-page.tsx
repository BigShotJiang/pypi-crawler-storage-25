import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Home, RefreshCw, Settings, Trash2, X } from "lucide-react";
import { useMemo, useRef, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  getPluginConfig,
  getPlugins,
  setPluginEnabled,
  taskWebSocketUrl,
  uninstallStorePlugin,
  updateAllPluginPackages,
  updatePluginConfig,
  updatePluginPackage,
  type LoadedPlugin,
  type WebuiTask,
  type WebuiTaskMessage,
} from "@/lib/api";
import { cn } from "@/lib/utils";

const protectedPluginModules = new Set([
  "nonebot_plugin_webui",
  "nonebot_plugin_orm",
  "nonebot_plugin_localstore",
]);

export function PluginsPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [selected, setSelected] = useState<LoadedPlugin | null>(null);
  const [configText, setConfigText] = useState("{}");
  const [formValues, setFormValues] = useState<Record<string, unknown>>({});
  const [jsonMode, setJsonMode] = useState(false);
  const [configError, setConfigError] = useState("");
  const [taskMessage, setTaskMessage] = useState("");
  const [task, setTask] = useState<WebuiTask | null>(null);
  const [pendingUninstall, setPendingUninstall] = useState<LoadedPlugin | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const plugins = useQuery({ queryKey: ["plugins"], queryFn: getPlugins });
  const pluginConfig = useQuery({
    queryKey: ["plugins", "config", selected?.module_name],
    queryFn: () => getPluginConfig(selected?.module_name || ""),
    enabled: Boolean(selected),
  });

  const saveConfig = useMutation({
    mutationFn: (payload: { moduleName: string; values: Record<string, unknown> }) =>
      updatePluginConfig(payload.moduleName, { enabled: true, values: payload.values }),
    onSuccess: async () => {
      setConfigError("配置已保存，重启 NoneBot 后对插件初始化生效。");
      await queryClient.invalidateQueries({ queryKey: ["plugins"] });
    },
    onError: () => setConfigError("保存失败"),
  });

  const uninstallMutation = useMutation({
    mutationFn: (plugin: LoadedPlugin) =>
      uninstallStorePlugin({
        package_name: plugin.module_name.replace(/_/g, "-"),
        module_name: plugin.module_name,
        name: plugin.metadata?.name || plugin.name,
      }),
    onMutate: () => {
      setTaskMessage("正在创建卸载任务...");
      setTask(null);
      socketRef.current?.close();
    },
    onSuccess: (data) => {
      setTask(data.task);
      setTaskMessage("卸载任务已创建，正在连接实时日志...");
      const socket = new WebSocket(taskWebSocketUrl(data.task_id));
      socketRef.current = socket;
      socket.onopen = () => setTaskMessage("卸载中，正在接收实时日志...");
      socket.onmessage = (event) => {
        const message = JSON.parse(event.data) as WebuiTaskMessage;
        if (message.type === "error") {
          setTaskMessage(message.message);
          return;
        }
        setTask(message.task);
        if (message.type === "done") {
          setTaskMessage(
            message.task.status === "success"
              ? "卸载完成，重启 NoneBot 后状态完全生效。"
              : "卸载失败，请查看日志。",
          );
          void queryClient.invalidateQueries({ queryKey: ["plugins"] });
        }
      };
      socket.onerror = () => setTaskMessage("实时日志连接失败");
    },
    onError: () => setTaskMessage("卸载请求失败"),
  });

  const updateMutation = useMutation({
    mutationFn: (payload: { plugins: LoadedPlugin[]; all: boolean }) =>
      payload.all
        ? updateAllPluginPackages(
            payload.plugins.map((plugin) => ({
              module_name: plugin.module_name,
              package_name: plugin.package_name,
              name: plugin.metadata?.name || plugin.name,
            })),
          )
        : updatePluginPackage({
            module_name: payload.plugins[0].module_name,
            package_name: payload.plugins[0].package_name,
            name: payload.plugins[0].metadata?.name || payload.plugins[0].name,
          }),
    onMutate: () => {
      setTaskMessage("正在创建更新任务...");
      setTask(null);
      socketRef.current?.close();
    },
    onSuccess: (data) => {
      setTask(data.task);
      setTaskMessage("更新任务已创建，正在连接实时日志...");
      const socket = new WebSocket(taskWebSocketUrl(data.task_id));
      socketRef.current = socket;
      socket.onopen = () => setTaskMessage("更新中，正在接收实时日志...");
      socket.onmessage = (event) => {
        const message = JSON.parse(event.data) as WebuiTaskMessage;
        if (message.type === "error") {
          setTaskMessage(message.message);
          return;
        }
        setTask(message.task);
        if (message.type === "done") {
          setTaskMessage(
            message.task.status === "success"
              ? "更新完成，重启 NoneBot 后状态完全生效。"
              : "更新失败，请查看日志。",
          );
          void queryClient.invalidateQueries({ queryKey: ["plugins"] });
        }
      };
      socket.onerror = () => setTaskMessage("实时日志连接失败");
    },
    onError: () => setTaskMessage("更新请求失败"),
  });

  const togglePluginMutation = useMutation({
    mutationFn: (payload: { plugin: LoadedPlugin; enabled: boolean }) =>
      setPluginEnabled(payload.plugin.module_name, {
        enabled: payload.enabled,
        package_name:
          payload.plugin.managed?.package_name || payload.plugin.module_name.replace(/_/g, "-"),
      }),
    onSuccess: async (data) => {
      setTaskMessage(data.runtime.message || (data.enabled ? "插件已启用" : "插件已关闭"));
      await queryClient.invalidateQueries({ queryKey: ["plugins"] });
    },
    onError: () => setTaskMessage("插件开关保存失败"),
  });

  const filtered = useMemo(() => {
    return (plugins.data?.loaded ?? []).filter((plugin) => {
      const meta = plugin.metadata ?? {};
      const haystack = [plugin.name, plugin.module_name, meta.name, meta.description]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(search.toLowerCase()) && (!type || meta.type === type);
    });
  }, [plugins.data?.loaded, search, type]);

  const pluginTypes = useMemo(() => {
    return Array.from(
      new Set((plugins.data?.loaded ?? []).map((plugin) => plugin.metadata?.type).filter(Boolean)),
    ).sort() as string[];
  }, [plugins.data?.loaded]);
  const updatablePlugins = useMemo(
    () =>
      (plugins.data?.loaded ?? []).filter(
        (plugin) =>
          plugin.update_available &&
          !protectedPluginModules.has(plugin.module_name) &&
          plugin.package_name,
      ),
    [plugins.data?.loaded],
  );

  return (
    <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>已加载插件</CardTitle>
          <CardDescription>模块、matcher 数量与插件配置 schema</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Button
            variant="outline"
            onClick={() => updateMutation.mutate({ plugins: updatablePlugins, all: true })}
            disabled={
              updatablePlugins.length === 0 ||
              updateMutation.isPending ||
              task?.status === "running"
            }
          >
            <RefreshCw className="size-4" />
            更新全部
          </Button>
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索插件"
            className="w-72 max-sm:w-full"
          />
          <select
            value={type}
            onChange={(event) => setType(event.target.value)}
            className="h-9 rounded-lg border bg-card px-3 text-sm"
          >
            <option value="">全部类型</option>
            {pluginTypes.map((item) => (
              <option key={item} value={item}>
                {translatePluginType(item)}
              </option>
            ))}
          </select>
        </div>
      </CardHeader>
      <CardContent>
        {taskMessage ? (
          <div
            className={cn(
              "mb-4 rounded-md border px-3 py-2 text-sm",
              taskMessage.includes("失败")
                ? "border-destructive/30 bg-destructive/10 text-destructive"
                : "border-primary/20 bg-primary/10 text-primary",
            )}
          >
            {taskMessage}
          </div>
        ) : null}
        {task?.logs.length ? (
          <pre className="mb-4 max-h-56 overflow-auto rounded-md border bg-background p-3 text-xs leading-relaxed text-muted-foreground">
            {task.logs.join("\n")}
          </pre>
        ) : null}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {filtered.map((plugin) => {
            const meta = plugin.metadata ?? {};
            const protectedPlugin = protectedPluginModules.has(plugin.module_name);
            return (
              <article key={plugin.module_name} className="flex min-h-56 flex-col gap-3 rounded-xl border bg-card p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="flex min-w-0 flex-wrap items-center gap-2 text-lg font-semibold">
                    <span className="truncate">{meta.name || plugin.name}</span>
                    {plugin.version ? (
                      <span className="rounded-md bg-muted px-1.5 py-0.5 text-xs font-medium text-muted-foreground">
                        v{plugin.version}
                      </span>
                    ) : null}
                    {plugin.update_available ? (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7 text-primary hover:text-primary"
                        onClick={() => updateMutation.mutate({ plugins: [plugin], all: false })}
                        disabled={
                          protectedPlugin ||
                          updateMutation.isPending ||
                          task?.status === "running"
                        }
                        title={`更新到 v${plugin.latest_version ?? ""}`}
                      >
                        <RefreshCw className="size-4" />
                        <span className="sr-only">更新插件</span>
                      </Button>
                    ) : null}
                  </h3>
                  <div className="flex items-center gap-2">
                    {meta.type ? <Badge>{translatePluginType(meta.type)}</Badge> : null}
                    <Switch
                      checked={!plugin.runtime_disabled && plugin.managed?.enabled !== false}
                      onCheckedChange={(enabled) =>
                        togglePluginMutation.mutate({ plugin, enabled })
                      }
                      disabled={protectedPlugin || togglePluginMutation.isPending}
                      title={protectedPlugin ? "核心插件不能关闭" : "启用或关闭插件"}
                    />
                  </div>
                </div>
                <p className="min-h-12 text-sm leading-6 text-muted-foreground">
                  {meta.description || "未提供插件描述"}
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge>{plugin.module_name}</Badge>
                  <Badge>{plugin.matcher_count} 个响应器</Badge>
                  {meta.config_schema ? (
                    <Badge className="bg-emerald-100 text-emerald-800">有配置项</Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-800">无配置项</Badge>
                  )}
                  {plugin.runtime_disabled || plugin.managed?.enabled === false ? (
                    <Badge className="bg-destructive/10 text-destructive">已关闭</Badge>
                  ) : protectedPlugin ? (
                    <Badge className="bg-primary/10 text-primary">核心插件</Badge>
                  ) : (
                    <Badge className="bg-emerald-100 text-emerald-800">已启用</Badge>
                  )}
                </div>
                <div className="mt-auto flex items-end justify-between gap-3 border-t pt-3 text-sm">
                  <span className="min-w-0 text-muted-foreground">
                    {plugin.sub_plugins.length} 个内置子插件
                  </span>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {meta.homepage ? (
                      <a
                        className="inline-flex size-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                        href={meta.homepage}
                        target="_blank"
                        rel="noreferrer"
                        title="打开主页"
                      >
                        <Home className="size-4" />
                        <span className="sr-only">打开主页</span>
                      </a>
                    ) : null}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-8"
                      onClick={() => {
                        setSelected(plugin);
                        setConfigError("");
                        setJsonMode(false);
                        void getPluginConfig(plugin.module_name).then((data) => {
                          const values = mergeDefaultsFromSchema(data.schema, data.values ?? {});
                          setFormValues(values);
                          setConfigText(JSON.stringify(values, null, 2));
                        });
                      }}
                      disabled={!meta.config_schema}
                      title={meta.config_schema ? "配置插件" : "这个插件没有可配置项"}
                    >
                      <Settings className="size-4" />
                      <span className="sr-only">配置插件</span>
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => setPendingUninstall(plugin)}
                      disabled={
                        protectedPlugin || uninstallMutation.isPending || task?.status === "running"
                      }
                      title={protectedPlugin ? "核心插件不能卸载" : "卸载插件"}
                    >
                      <Trash2 className="size-4" />
                      <span className="sr-only">卸载插件</span>
                    </Button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </CardContent>

      {selected ? (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-background/45 p-4 backdrop-blur-sm">
          <Card className="max-h-[90svh] w-full max-w-3xl overflow-hidden p-0 shadow-2xl">
            <CardHeader className="border-b p-5">
              <CardTitle>{selected.metadata?.name || selected.name} 配置</CardTitle>
              <CardDescription>
                保存到 WebUI 管理配置。已加载插件通常需要重启 NoneBot 后重新初始化才会读取新值。
              </CardDescription>
            </CardHeader>
            <CardContent className="grid min-h-0 gap-4 overflow-auto p-5">
              <div className="flex justify-end">
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    if (!jsonMode) {
                      setConfigText(JSON.stringify(formValues, null, 2));
                    } else {
                      try {
                        const values = JSON.parse(configText) as Record<string, unknown>;
                        if (values && typeof values === "object" && !Array.isArray(values)) {
                          setFormValues(values);
                          setConfigError("");
                        }
                      } catch {
                        setConfigError("配置 JSON 格式不正确");
                        return;
                      }
                    }
                    setJsonMode(!jsonMode);
                  }}
                >
                  {jsonMode ? "表单编辑" : "编辑 JSON"}
                </Button>
              </div>
              {pluginConfig.data?.schema ? (
                <div className="rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
                  <div className="mb-2 font-medium text-foreground">配置 Schema 字段</div>
                  <div className="grid gap-1">
                    {Object.entries(
                      (pluginConfig.data.schema.properties as Record<string, unknown>) ?? {},
                    ).map(([key, value]) => (
                      <div key={key} className="grid grid-cols-[180px_1fr] gap-3">
                        <code className="text-foreground">{key}</code>
                        <span className="truncate">{describeSchemaProperty(value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
                  这个插件没有声明配置 schema，可以直接编辑 JSON。
                </div>
              )}
              {jsonMode ? (
                <label className="grid gap-2 text-sm font-medium">
                  配置 JSON
                  <textarea
                    value={configText}
                    onChange={(event) => setConfigText(event.target.value)}
                    className="min-h-72 rounded-md border bg-background p-3 font-mono text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    spellCheck={false}
                  />
                </label>
              ) : pluginConfig.data?.schema?.properties ? (
                <div className="grid gap-3">
                  {Object.entries(
                    pluginConfig.data.schema.properties as Record<string, unknown>,
                  ).map(([key, schema]) => (
                    <SchemaField
                      key={key}
                      name={key}
                      schema={schema}
                      value={formValues[key]}
                      onChange={(value) => {
                        setFormValues((current) => ({ ...current, [key]: value }));
                        setConfigError("");
                      }}
                    />
                  ))}
                </div>
              ) : (
                <label className="grid gap-2 text-sm font-medium">
                  配置 JSON
                  <textarea
                    value={configText}
                    onChange={(event) => setConfigText(event.target.value)}
                    className="min-h-72 rounded-md border bg-background p-3 font-mono text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    spellCheck={false}
                  />
                </label>
              )}
              {configError ? (
                <div
                  className={cn(
                    "rounded-md border px-3 py-2 text-sm",
                    configError.includes("失败") || configError.includes("JSON")
                      ? "border-destructive/30 bg-destructive/10 text-destructive"
                      : "border-primary/20 bg-primary/10 text-primary",
                  )}
                >
                  {configError}
                </div>
              ) : null}
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSelected(null)}>
                  关闭
                </Button>
                <Button
                  onClick={() => {
                    try {
                      const values = pluginConfig.data?.schema?.properties
                        ? formValues
                        : (JSON.parse(configText) as Record<string, unknown>);
                      if (!values || Array.isArray(values) || typeof values !== "object") {
                        setConfigError("配置 JSON 必须是对象");
                        return;
                      }
                      saveConfig.mutate({ moduleName: selected.module_name, values });
                    } catch {
                      setConfigError("配置 JSON 格式不正确");
                    }
                  }}
                  disabled={saveConfig.isPending}
                >
                  {saveConfig.isPending ? "保存中" : "保存配置"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {pendingUninstall ? (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-background/45 p-4 backdrop-blur-sm">
          <Card className="w-full max-w-md gap-4 p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-base font-semibold">卸载插件</div>
                <div className="mt-1 text-sm text-muted-foreground">
                  确定卸载 {pendingUninstall.metadata?.name || pendingUninstall.name} 吗？运行中的插件需要重启后才会完全移除。
                </div>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-8"
                onClick={() => setPendingUninstall(null)}
              >
                <X className="size-4" />
                <span className="sr-only">关闭</span>
              </Button>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setPendingUninstall(null)}>
                取消
              </Button>
              <Button
                className="bg-destructive text-white hover:bg-destructive/90"
                onClick={() => {
                  uninstallMutation.mutate(pendingUninstall);
                  setPendingUninstall(null);
                }}
              >
                确认卸载
              </Button>
            </div>
          </Card>
        </div>
      ) : null}
    </Card>
  );
}

function describeSchemaProperty(value: unknown) {
  if (!value || typeof value !== "object") {
    return "";
  }
  const property = value as Record<string, unknown>;
  return [property.title, property.type, property.description].filter(Boolean).join(" / ");
}

function translatePluginType(type: string) {
  const labels: Record<string, string> = {
    application: "应用插件",
    library: "库插件",
  };
  return labels[type] || type;
}

function SchemaField({
  name,
  schema,
  value,
  onChange,
}: {
  name: string;
  schema: unknown;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const property = normalizeSchema(schema);
  const title = typeof property.title === "string" ? property.title : name;
  const description = typeof property.description === "string" ? property.description : "";
  const type = property.type;
  const enumValues = Array.isArray(property.enum) ? property.enum : null;
  const stringValue = value == null ? "" : String(value);
  const multilineString =
    type === "string" &&
    (stringValue.includes("\n") ||
      stringValue.includes("\\n") ||
      stringValue.length > 80 ||
      name.toLowerCase().includes("template"));
  const displayStringValue =
    multilineString && stringValue.includes("\\n") && !stringValue.includes("\n")
      ? stringValue.replace(/\\n/g, "\n")
      : stringValue;

  const updateObjectChild = (key: string, nextValue: unknown) => {
    const objectValue =
      value && typeof value === "object" && !Array.isArray(value)
        ? (value as Record<string, unknown>)
        : {};
    onChange({ ...objectValue, [key]: nextValue });
  };

  return (
    <label className="grid gap-2 rounded-md border bg-background p-3 text-sm">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="font-medium">{title}</div>
          <code className="text-xs text-muted-foreground">{name}</code>
          {description ? (
            <div className="mt-1 text-xs leading-5 text-muted-foreground">{description}</div>
          ) : null}
        </div>
        {type ? <Badge>{String(type)}</Badge> : null}
      </div>
      {enumValues ? (
        <select
          value={value == null ? "" : String(value)}
          onChange={(event) => onChange(event.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          <option value="">未设置</option>
          {enumValues.map((item) => (
            <option key={String(item)} value={String(item)}>
              {String(item)}
            </option>
          ))}
        </select>
      ) : type === "boolean" ? (
        <div className="flex items-center gap-2">
          <Switch checked={Boolean(value)} onCheckedChange={onChange} />
          <span className="text-xs text-muted-foreground">{Boolean(value) ? "启用" : "关闭"}</span>
        </div>
      ) : type === "integer" || type === "number" ? (
        <Input
          type="number"
          value={value == null ? "" : String(value)}
          onChange={(event) => {
            const raw = event.target.value;
            onChange(raw === "" ? undefined : type === "integer" ? Number.parseInt(raw, 10) : Number(raw));
          }}
        />
      ) : type === "array" ? (
        <ArrayField schema={property} value={value} onChange={onChange} />
      ) : type === "object" && property.properties && typeof property.properties === "object" ? (
        <div className="grid gap-2 rounded-md border bg-muted/20 p-2">
          {Object.entries(property.properties as Record<string, unknown>).map(([childKey, childSchema]) => (
            <SchemaField
              key={childKey}
              name={childKey}
              schema={childSchema}
              value={
                value && typeof value === "object" && !Array.isArray(value)
                  ? (value as Record<string, unknown>)[childKey]
                  : undefined
              }
              onChange={(nextValue) => updateObjectChild(childKey, nextValue)}
            />
          ))}
        </div>
      ) : type === "object" ? (
        <ObjectPairsField value={value} onChange={onChange} />
      ) : multilineString ? (
        <textarea
          value={displayStringValue}
          onChange={(event) => onChange(event.target.value)}
          className="min-h-40 rounded-md border bg-background p-3 font-mono text-sm leading-6 outline-none focus-visible:ring-2 focus-visible:ring-ring"
          spellCheck={false}
        />
      ) : (
        <Input
          value={stringValue}
          onChange={(event) => onChange(event.target.value)}
        />
      )}
    </label>
  );
}

function ArrayField({
  schema,
  value,
  onChange,
}: {
  schema: Record<string, unknown>;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const items = Array.isArray(value) ? value : [];
  const itemSchema = schema.items ?? { type: "string" };

  return (
    <div className="grid gap-2">
      {items.map((item, index) => (
        <div key={index} className="grid grid-cols-[1fr_auto] gap-2">
          <SchemaField
            name={`第 ${index + 1} 项`}
            schema={itemSchema}
            value={item}
            onChange={(nextValue) => {
              const next = [...items];
              next[index] = nextValue;
              onChange(next);
            }}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-1"
            onClick={() => onChange(items.filter((_, itemIndex) => itemIndex !== index))}
          >
            删除
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-fit"
        onClick={() => onChange([...items, defaultValueForSchema(itemSchema)])}
      >
        添加一项
      </Button>
    </div>
  );
}

function ObjectPairsField({
  value,
  onChange,
}: {
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const objectValue =
    value && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : {};
  const entries = Object.entries(objectValue);

  const updateKey = (oldKey: string, newKey: string) => {
    const next = { ...objectValue };
    const current = next[oldKey];
    delete next[oldKey];
    if (newKey) {
      next[newKey] = current;
    }
    onChange(next);
  };

  return (
    <div className="grid gap-2">
      {entries.map(([key, item]) => (
        <div key={key} className="grid grid-cols-[minmax(120px,0.45fr)_1fr_auto] gap-2">
          <Input value={key} onChange={(event) => updateKey(key, event.target.value)} />
          <Input
            value={item == null ? "" : String(item)}
            onChange={(event) => onChange({ ...objectValue, [key]: event.target.value })}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              const next = { ...objectValue };
              delete next[key];
              onChange(next);
            }}
          >
            删除
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-fit"
        onClick={() => {
          const base = "key";
          let index = entries.length + 1;
          let nextKey = `${base}_${index}`;
          while (nextKey in objectValue) {
            index += 1;
            nextKey = `${base}_${index}`;
          }
          onChange({ ...objectValue, [nextKey]: "" });
        }}
      >
        添加字段
      </Button>
    </div>
  );
}

function defaultValueForSchema(schema: unknown) {
  const property = normalizeSchema(schema);
  if (property.default !== undefined) {
    return property.default;
  }
  if (property.type === "boolean") {
    return false;
  }
  if (property.type === "integer" || property.type === "number") {
    return 0;
  }
  if (property.type === "array") {
    return [];
  }
  if (property.type === "object") {
    return {};
  }
  return "";
}

function mergeDefaultsFromSchema(
  schema: Record<string, unknown> | null | undefined,
  values: Record<string, unknown>,
) {
  const properties =
    schema?.properties && typeof schema.properties === "object"
      ? (schema.properties as Record<string, unknown>)
      : {};
  const defaults: Record<string, unknown> = {};
  for (const [key, property] of Object.entries(properties)) {
    const defaultValue = defaultValueFromSchema(property);
    if (defaultValue !== undefined) {
      defaults[key] = defaultValue;
    }
  }
  return { ...defaults, ...values };
}

function defaultValueFromSchema(schema: unknown): unknown {
  const property = normalizeSchema(schema);
  if (property.default !== undefined) {
    return property.default;
  }
  if (property.type === "object") {
    const properties =
      property.properties && typeof property.properties === "object"
        ? (property.properties as Record<string, unknown>)
        : null;
    if (!properties) {
      return undefined;
    }
    const value: Record<string, unknown> = {};
    for (const [key, childSchema] of Object.entries(properties)) {
      const childDefault = defaultValueFromSchema(childSchema);
      if (childDefault !== undefined) {
        value[key] = childDefault;
      }
    }
    return Object.keys(value).length ? value : undefined;
  }
  if (property.type === "array" && Array.isArray(property.default)) {
    return property.default;
  }
  return undefined;
}

function normalizeSchema(schema: unknown): Record<string, unknown> {
  if (!schema || typeof schema !== "object") {
    return {};
  }
  const property = schema as Record<string, unknown>;
  if (Array.isArray(property.anyOf)) {
    const concrete = property.anyOf.find(
      (item) =>
        item &&
        typeof item === "object" &&
        (item as Record<string, unknown>).type !== "null",
    );
    return { ...property, ...(concrete as Record<string, unknown> | undefined) };
  }
  return property;
}
