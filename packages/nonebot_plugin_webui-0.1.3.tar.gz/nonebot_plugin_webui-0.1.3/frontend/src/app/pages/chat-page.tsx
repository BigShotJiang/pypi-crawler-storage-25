import { useMutation } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { Bot, RotateCcw, SendHorizontal, UserRound } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { sendChatMessage } from "@/lib/api";
import { cn } from "@/lib/utils";

type ChatMessage = {
  id: string;
  role: "user" | "bot" | "system";
  text: string;
  status?: "error";
};

const initialMessages: ChatMessage[] = [
  {
    id: "intro",
    role: "system",
    text: "这是 WebUI 虚拟聊天环境。输入 /ai 你的问题 可以调用内置 AI matcher，输入 /ai_clear 可以清空当前上下文。",
  },
];

export function ChatPage() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const sessionId = useMemo(() => `webui-${crypto.randomUUID()}`, []);

  const sendMutation = useMutation({
    mutationFn: sendChatMessage,
    onSuccess: (data) => {
      setMessages((items) => [
        ...items,
        ...(data.replies.length
          ? data.replies.map((reply) => ({
              id: crypto.randomUUID(),
              role: "bot" as const,
              text: reply,
            }))
          : [
              {
                id: crypto.randomUUID(),
                role: "system" as const,
                text: "没有插件回复这条消息。",
              },
            ]),
      ]);
      setMessage("");
    },
    onError: (error) => {
      const detail =
        error instanceof AxiosError
          ? error.response?.data?.detail || error.message
          : error instanceof Error
            ? error.message
            : "消息处理失败";
      setMessages((items) => [
        ...items,
        {
          id: crypto.randomUUID(),
          role: "system",
          status: "error",
          text: String(detail),
        },
      ]);
    },
  });

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = message.trim();
    if (!text || sendMutation.isPending) {
      return;
    }

    setMessages((items) => [
      ...items,
      {
        id: crypto.randomUUID(),
        role: "user",
        text,
      },
    ]);
    sendMutation.mutate({
      message: text,
      session_id: sessionId,
    });
  }

  return (
    <div className="grid h-[calc(100svh-8rem)] min-h-[560px] grid-cols-[280px_minmax(0,1fr)] gap-4 max-lg:h-auto max-lg:grid-cols-1">
      <Card className="min-h-0">
        <CardHeader>
          <CardTitle>Web 聊天</CardTitle>
          <CardDescription>模拟用户消息并触发 NoneBot 插件</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="rounded-md border bg-muted/40 p-3 text-sm">
            <div className="mb-2 flex items-center gap-2 font-medium">
              <Bot className="size-4" />
              虚拟 Bot
            </div>
            <InfoRow label="适配器" value="WebUI" />
            <InfoRow label="Bot ID" value="webui" />
            <InfoRow label="用户 ID" value="webui-user" />
          </div>

          <div className="rounded-md border bg-muted/40 p-3 text-sm">
            <div className="mb-2 font-medium">测试方式</div>
            <p className="text-muted-foreground">
              可以直接输入命令测试，例如
              <code className="mx-1 rounded bg-background px-1 py-0.5">/ai 介绍一下 NoneBot</code>
              或 echo 插件常用的
              <code className="mx-1 rounded bg-background px-1 py-0.5">/echo hello</code>
              。
            </p>
          </div>

          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setMessages(initialMessages);
              setMessage("");
            }}
          >
            <RotateCcw className="size-4" />
            清空对话
          </Button>
        </CardContent>
      </Card>

      <Card className="flex min-h-0 flex-col overflow-hidden">
        <CardHeader className="border-b">
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle>对话框</CardTitle>
              <CardDescription>消息会进入 NoneBot 事件处理流程</CardDescription>
            </div>
            <Badge className="bg-primary text-primary-foreground">WebUI</Badge>
          </div>
        </CardHeader>
        <CardContent className="flex min-h-0 flex-1 flex-col p-0">
          <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((item) => (
              <MessageBubble key={item.id} message={item} />
            ))}
            {sendMutation.isPending ? (
              <div className="flex justify-start">
                <div className="rounded-lg border bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
                  正在处理...
                </div>
              </div>
            ) : null}
          </div>

          <form onSubmit={handleSubmit} className="flex gap-2 border-t p-3">
            <Input
              value={message}
              onChange={(event) => setMessage(event.target.value)}
              placeholder="输入消息，例如 /ai 介绍一下 NoneBot"
              disabled={sendMutation.isPending}
            />
            <Button type="submit" disabled={!message.trim() || sendMutation.isPending}>
              <SendHorizontal className="size-4" />
              发送
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const isBot = message.role === "bot";
  return (
    <div className={cn("flex gap-2", isUser ? "justify-end" : "justify-start")}>
      {!isUser ? (
        <div className="mt-1 flex size-7 shrink-0 items-center justify-center rounded-md border bg-background">
          {isBot ? <Bot className="size-4" /> : <UserRound className="size-4" />}
        </div>
      ) : null}
      <div
        className={cn(
          "max-w-[78%] rounded-lg px-3 py-2 text-sm leading-relaxed",
          isUser ? "bg-primary text-primary-foreground" : "border bg-muted/50",
          isBot && "bg-background",
          message.status === "error" && "border-destructive/50 text-destructive",
        )}
      >
        {message.text}
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[72px_minmax(0,1fr)] gap-2 py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="truncate font-medium">{value}</span>
    </div>
  );
}
