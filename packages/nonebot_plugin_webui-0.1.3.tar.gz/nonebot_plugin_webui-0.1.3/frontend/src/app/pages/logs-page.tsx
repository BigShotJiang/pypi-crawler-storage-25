import { useEffect, useMemo, useRef, useState } from "react";
import { Eraser, Pause, Play } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getLogsSnapshot, logsWebSocketUrl, type LogItem } from "@/lib/api";
import { cn } from "@/lib/utils";

const levels = ["all", "error", "warning", "info", "debug", "trace", "success"];

export function LogsPage() {
  const [items, setItems] = useState<LogItem[]>([]);
  const [level, setLevel] = useState("all");
  const [search, setSearch] = useState("");
  const [autoScroll, setAutoScroll] = useState(true);
  const [connected, setConnected] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let socket: WebSocket | null = null;
    void getLogsSnapshot().then((data) => setItems(data.items));
    socket = new WebSocket(logsWebSocketUrl());
    socket.onopen = () => setConnected(true);
    socket.onclose = () => setConnected(false);
    socket.onerror = () => setConnected(false);
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data) as
        | { type: "snapshot"; items: LogItem[] }
        | { type: "log"; item: LogItem };
      if (message.type === "snapshot") setItems(message.items);
      if (message.type === "log") {
        setItems((current) => [...current.slice(-999), message.item]);
      }
    };
    return () => socket?.close();
  }, []);

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return items.filter((item) => {
      const levelMatched = level === "all" || item.level === level;
      const searchMatched =
        !needle ||
        item.message.toLowerCase().includes(needle) ||
        item.name.toLowerCase().includes(needle);
      return levelMatched && searchMatched;
    });
  }, [items, level, search]);

  useEffect(() => {
    if (autoScroll) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [autoScroll, filtered.length]);

  return (
    <Card className="overflow-hidden">
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-lg:grid-cols-1">
        <div>
          <CardTitle>实时日志</CardTitle>
          <CardDescription>查看 NoneBot 运行日志，支持级别筛选、搜索、清空和自动滚动</CardDescription>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge
            className={
              connected
                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300"
                : "bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300"
            }
          >
            {connected ? "已连接" : "未连接"}
          </Badge>
          <select value={level} onChange={(event) => setLevel(event.target.value)} className="h-9 rounded-lg border bg-card px-3 text-sm">
            {levels.map((item) => (
              <option key={item} value={item}>
                {translateLevel(item)}
              </option>
            ))}
          </select>
          <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="搜索日志内容" className="w-64" />
          <Button variant="outline" onClick={() => setAutoScroll(!autoScroll)}>
            {autoScroll ? <Pause className="size-4" /> : <Play className="size-4" />}
            {autoScroll ? "停止滚动" : "自动滚动"}
          </Button>
          <Button variant="outline" onClick={() => setItems([])}>
            <Eraser className="size-4" />
            清空日志
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[calc(100svh-14rem)] overflow-auto rounded-lg border bg-muted/30 p-3 font-mono text-sm text-foreground">
          {filtered.map((item, index) => (
            <div key={`${item.time}-${index}`} className="grid grid-cols-[168px_80px_180px_1fr] gap-3 border-b py-1.5 last:border-0">
              <span className="text-muted-foreground">{new Date(item.time * 1000).toLocaleString()}</span>
              <span className={cn("font-semibold", levelColor(item.level))}>{item.level.toUpperCase()}</span>
              <span className="truncate text-muted-foreground">{item.name}</span>
              <span className="whitespace-pre-wrap break-words">{item.message}</span>
            </div>
          ))}
          {!filtered.length ? <div className="text-muted-foreground">暂无日志</div> : null}
          <div ref={bottomRef} />
        </div>
      </CardContent>
    </Card>
  );
}

function translateLevel(level: string) {
  const labels: Record<string, string> = {
    all: "全部级别",
    error: "Error",
    warning: "Warning",
    info: "Info",
    debug: "Debug",
    trace: "Trace",
    success: "Success",
  };
  return labels[level] || level;
}

function levelColor(level: string) {
  if (level === "error") return "text-red-600 dark:text-red-400";
  if (level === "warning") return "text-amber-600 dark:text-amber-300";
  if (level === "info") return "text-sky-600 dark:text-sky-300";
  if (level === "debug") return "text-violet-600 dark:text-violet-300";
  if (level === "success") return "text-emerald-600 dark:text-emerald-300";
  return "text-foreground";
}
