import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { KeyRound, LogOut, RotateCw, X } from "lucide-react";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { changePassword, getAuthStatus, logout, restartRuntime, type AuthStatus } from "@/lib/api";
import { cn } from "@/lib/utils";

type AccountActionsProps = {
  collapsed: boolean;
  textVisible: boolean;
  textMounted: boolean;
};

export function AccountActions({ collapsed, textVisible, textMounted }: AccountActionsProps) {
  const queryClient = useQueryClient();
  const auth = useQuery({ queryKey: ["auth", "status"], queryFn: getAuthStatus });
  const [passwordOpen, setPasswordOpen] = useState(false);
  const [restartOpen, setRestartOpen] = useState(false);
  const [username, setUsername] = useState("admin");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const logoutMutation = useMutation({
    mutationFn: logout,
    onSuccess: async () => {
      queryClient.setQueryData<AuthStatus>(["auth", "status"], (current) => ({
        enabled: true,
        authenticated: false,
        username: current?.username || currentUsername,
      }));
      await queryClient.invalidateQueries({ queryKey: ["auth", "status"] });
    },
  });

  const restartMutation = useMutation({
    mutationFn: restartRuntime,
  });

  const passwordMutation = useMutation({
    mutationFn: changePassword,
    onSuccess: () => {
      setCurrentPassword("");
      setNewPassword("");
      setPasswordOpen(false);
      queryClient.setQueryData<AuthStatus>(["auth", "status"], {
        enabled: true,
        authenticated: false,
        username: username.trim() || currentUsername,
      });
      void queryClient.invalidateQueries({ queryKey: ["auth", "status"] });
    },
    onError: () => {
      setMessage("密码修改失败");
    },
  });

  const authEnabled = Boolean(auth.data?.enabled);
  const currentUsername = auth.data?.username || "admin";

  useEffect(() => {
    if (auth.data?.username && !passwordOpen) {
      setUsername(auth.data.username);
    }
  }, [auth.data?.username, passwordOpen]);

  const submitPassword = () => {
    setMessage(null);
    if (!username.trim()) {
      setMessage("新用户名不能为空");
      return;
    }
    if (newPassword.length < 6) {
      setMessage("新密码至少 6 位");
      return;
    }
    passwordMutation.mutate({
      username: currentUsername,
      new_username: username,
      current_password: currentPassword,
      new_password: newPassword,
    });
  };

  const restart = () => {
    setRestartOpen(false);
    restartMutation.mutate();
  };

  return (
    <div
      data-slot="sidebar-footer"
      className="grid gap-2 border-t border-sidebar-border/60 px-2 py-2"
    >
      <button
        type="button"
        className={footerButtonClass()}
        onClick={() => setRestartOpen(true)}
        disabled={restartMutation.isPending}
        title="重启系统"
      >
        <span className={footerIconClass()}>
          <RotateCw className={cn("size-[23px]", restartMutation.isPending && "animate-spin")} />
        </span>
        <span className={footerTextClass(textVisible, textMounted)}>重启系统</span>
      </button>

      {authEnabled ? (
        <>
          <button
            type="button"
            className={footerButtonClass()}
            title="修改用户名密码"
            onClick={() => {
              setMessage(null);
              setPasswordOpen(true);
            }}
          >
            <span className={footerIconClass()}>
              <KeyRound className="size-[23px]" />
            </span>
            <span className={footerTextClass(textVisible, textMounted)}>修改密码</span>
          </button>

          <button
            type="button"
            className={cn(
              footerButtonClass(),
              "text-destructive hover:bg-destructive/10 hover:text-destructive",
            )}
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            title="退出登录"
          >
            <span className={footerIconClass()}>
              <LogOut className="size-[23px]" />
            </span>
            <span className={footerTextClass(textVisible, textMounted)}>退出登录</span>
          </button>
        </>
      ) : null}

      {passwordOpen
        ? createPortal(
        <div className="fixed inset-0 z-[100] grid place-items-center bg-background/45 p-4 backdrop-blur-sm">
          <Card className="w-full max-w-lg gap-4 p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-base font-semibold">修改用户名密码</div>
                <div className="mt-1 text-sm text-muted-foreground">
                  修改成功后会退出登录，需要使用新的账号密码重新进入。
                </div>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-8"
                onClick={() => setPasswordOpen(false)}
              >
                <X className="size-4" />
                <span className="sr-only">关闭</span>
              </Button>
            </div>
            <Separator />
            <form
              className="grid gap-4"
              onSubmit={(event) => {
                event.preventDefault();
                submitPassword();
              }}
            >
              <label className="grid gap-1.5 text-xs font-medium">
                当前密码
                <Input
                  value={currentPassword}
                  onChange={(event) => setCurrentPassword(event.target.value)}
                  type="password"
                  autoComplete="current-password"
                  className="h-9 text-sm"
                />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="grid gap-1.5 text-xs font-medium">
                  新用户名
                  <Input
                    value={username}
                    onChange={(event) => setUsername(event.target.value)}
                    autoComplete="username"
                    className="h-9 text-sm"
                  />
                </label>
                <label className="grid gap-1.5 text-xs font-medium">
                  新密码
                  <Input
                    value={newPassword}
                    onChange={(event) => setNewPassword(event.target.value)}
                    type="password"
                    autoComplete="new-password"
                    className="h-9 text-sm"
                  />
                </label>
              </div>
              {message ? (
                <div
                  className={cn(
                    "text-xs",
                    message.includes("失败") ||
                      message.includes("不能为空") ||
                      message.includes("至少")
                      ? "text-destructive"
                      : "text-muted-foreground",
                  )}
                >
                  {message}
                </div>
              ) : null}
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setPasswordOpen(false)}>
                  取消
                </Button>
                <Button type="submit" disabled={passwordMutation.isPending}>
                  {passwordMutation.isPending ? "保存中" : "保存并退出登录"}
                </Button>
              </div>
            </form>
          </Card>
        </div>,
            document.body,
          )
        : null}

      {restartOpen
        ? createPortal(
        <div className="fixed inset-0 z-[100] grid place-items-center bg-background/45 p-4 backdrop-blur-sm">
          <Card className="w-full max-w-md gap-4 p-5 shadow-2xl">
            <div>
                <div className="text-base font-semibold">重启系统</div>
              <div className="mt-1 text-sm text-muted-foreground">
                当前 WebUI 和机器人连接会短暂断开，进程会重新执行当前启动命令。
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setRestartOpen(false)}>
                取消
              </Button>
              <Button type="button" onClick={restart} disabled={restartMutation.isPending}>
                确认重启
              </Button>
            </div>
          </Card>
        </div>,
            document.body,
          )
        : null}
    </div>
  );
}

function footerButtonClass() {
  return cn(
    "relative h-[42px] w-full overflow-hidden rounded-md px-2 text-start text-[19px] text-sidebar-foreground outline-hidden ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50",
  );
}

function footerIconClass() {
  return cn(
    "absolute top-1/2 flex size-10 -translate-y-1/2 items-center justify-center rounded-md",
    "left-2 translate-x-0",
  );
}

function footerTextClass(textVisible: boolean, textMounted: boolean) {
  return cn(
    "ms-12 truncate transition-opacity duration-200",
    textVisible ? "opacity-100" : "opacity-0",
    !textMounted && "w-0",
  );
}
