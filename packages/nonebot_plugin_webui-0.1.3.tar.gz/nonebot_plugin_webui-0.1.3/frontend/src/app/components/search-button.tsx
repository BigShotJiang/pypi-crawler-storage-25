import * as Dialog from "@radix-ui/react-dialog";
import { useNavigate } from "@tanstack/react-router";
import {
  Bot,
  Boxes,
  BrainCircuit,
  Check,
  Component,
  LayoutDashboard,
  MessageSquare,
  Moon,
  Palette,
  RefreshCw,
  SearchIcon,
  Settings,
  Store,
  Sun,
} from "lucide-react";
import type { ComponentProps, KeyboardEvent, ReactNode } from "react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/query-client";
import { cn } from "@/lib/utils";
import { useUiStore } from "@/stores/ui-store";

type SearchButtonProps = ComponentProps<"button"> & {
  placeholder?: string;
};

export function SearchButton({
  className = "",
  placeholder = "Search",
  ...props
}: SearchButtonProps) {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const setTheme = useUiStore((state) => state.setTheme);
  const setPalette = useUiStore((state) => state.setPalette);
  const setLayoutMode = useUiStore((state) => state.setLayoutMode);

  const commands = useMemo<CommandItem[]>(
    () => [
      {
        id: "page-overview",
        title: "打开总览",
        description: "查看运行状态、插件和基础指标",
        group: "页面",
        icon: <LayoutDashboard />,
        keywords: "overview dashboard home zonglan shouye",
        run: () => navigate({ to: "/" }),
      },
      {
        id: "page-bots",
        title: "打开机器人",
        description: "管理适配器连接和 Bot 实例",
        group: "页面",
        icon: <Bot />,
        keywords: "bots robot adapter onebot napcat jiqiren shipeiqi",
        run: () => navigate({ to: "/bots" }),
      },
      {
        id: "page-config",
        title: "打开配置",
        description: "管理 NoneBot 配置项",
        group: "页面",
        icon: <Settings />,
        keywords: "config settings peizhi",
        run: () => navigate({ to: "/config" }),
      },
      {
        id: "page-chat",
        title: "打开聊天",
        description: "使用 WebUI 虚拟会话测试机器人",
        group: "页面",
        icon: <MessageSquare />,
        keywords: "chat ai duihua liaotian",
        run: () => navigate({ to: "/chat" }),
      },
      {
        id: "page-models",
        title: "打开模型",
        description: "管理 AI 提供商和模型列表",
        group: "页面",
        icon: <BrainCircuit />,
        keywords: "models ai openai provider moxing",
        run: () => navigate({ to: "/models" }),
      },
      {
        id: "page-components",
        title: "打开组件",
        description: "查看可复用 UI 组件样式",
        group: "页面",
        icon: <Component />,
        keywords: "components ui zujian",
        run: () => navigate({ to: "/components" }),
      },
      {
        id: "page-plugins",
        title: "打开插件",
        description: "查看已加载插件",
        group: "页面",
        icon: <Boxes />,
        keywords: "plugins chajian",
        run: () => navigate({ to: "/plugins" }),
      },
      {
        id: "page-store",
        title: "打开商店",
        description: "浏览插件商店",
        group: "页面",
        icon: <Store />,
        keywords: "store market shangdian",
        run: () => navigate({ to: "/store" }),
      },
      {
        id: "theme-light",
        title: "切换到浅色模式",
        description: "固定使用浅色主题",
        group: "操作",
        icon: <Sun />,
        keywords: "light theme qianse",
        run: () => setTheme("light"),
      },
      {
        id: "theme-dark",
        title: "切换到深色模式",
        description: "固定使用深色主题",
        group: "操作",
        icon: <Moon />,
        keywords: "dark theme shense",
        run: () => setTheme("dark"),
      },
      {
        id: "theme-system",
        title: "跟随系统主题",
        description: "根据系统偏好自动切换明暗",
        group: "操作",
        icon: <Settings />,
        keywords: "system theme xitong",
        run: () => setTheme("system"),
      },
      {
        id: "palette-jade",
        title: "配色：青绿",
        description: "使用默认青绿色控制台配色",
        group: "配色",
        icon: <Palette />,
        keywords: "jade green qinglv",
        run: () => setPalette("jade"),
      },
      {
        id: "palette-indigo",
        title: "配色：靛蓝",
        description: "使用偏产品后台的蓝紫配色",
        group: "配色",
        icon: <Palette />,
        keywords: "indigo blue dianlan",
        run: () => setPalette("indigo"),
      },
      {
        id: "palette-rose",
        title: "配色：玫瑰",
        description: "使用更醒目的玫瑰色主色",
        group: "配色",
        icon: <Palette />,
        keywords: "rose pink meigui",
        run: () => setPalette("rose"),
      },
      {
        id: "palette-amber",
        title: "配色：琥珀",
        description: "使用偏暖的琥珀色主色",
        group: "配色",
        icon: <Palette />,
        keywords: "amber yellow hupo",
        run: () => setPalette("amber"),
      },
      {
        id: "palette-zinc",
        title: "配色：石墨",
        description: "使用低饱和中性色方案",
        group: "配色",
        icon: <Palette />,
        keywords: "zinc gray graphite shimo",
        run: () => setPalette("zinc"),
      },
      {
        id: "layout-default",
        title: "布局：默认",
        description: "展开左侧菜单栏",
        group: "布局",
        icon: <PanelIcon />,
        keywords: "layout default moren",
        run: () => setLayoutMode("default"),
      },
      {
        id: "layout-compact",
        title: "布局：紧凑",
        description: "仅显示左侧菜单图标",
        group: "布局",
        icon: <PanelIcon />,
        keywords: "layout compact jin cou icon",
        run: () => setLayoutMode("compact"),
      },
      {
        id: "layout-full",
        title: "布局：完整布局",
        description: "左侧菜单以抽屉方式展开",
        group: "布局",
        icon: <PanelIcon />,
        keywords: "layout full wanzheng",
        run: () => setLayoutMode("full"),
      },
      {
        id: "refresh",
        title: "刷新数据",
        description: "重新请求当前已缓存的数据",
        group: "操作",
        icon: <RefreshCw />,
        keywords: "refresh reload shuaxin",
        run: () => queryClient.invalidateQueries(),
      },
    ],
    [navigate, setLayoutMode, setPalette, setTheme],
  );

  const filteredCommands = useMemo(() => {
    const value = normalizeSearch(query);
    if (!value) {
      return commands;
    }

    return commands.filter((item) =>
      normalizeSearch(`${item.title} ${item.description} ${item.group} ${item.keywords}`).includes(
        value,
      ),
    );
  }, [commands, query]);

  useEffect(() => {
    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      const target = event.target;
      const editingText =
        target instanceof HTMLElement &&
        (target.isContentEditable ||
          target.matches("input, textarea, select") ||
          target.closest("[role='dialog']"));

      if (editingText) {
        return;
      }

      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen((value) => !value);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (!open) {
      setQuery("");
      setActiveIndex(0);
      return;
    }

    window.setTimeout(() => inputRef.current?.focus(), 0);
  }, [open]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query]);

  const executeCommand = (command: CommandItem) => {
    command.run();
    setOpen(false);
  };

  const handleInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((value) => Math.min(value + 1, filteredCommands.length - 1));
      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((value) => Math.max(value - 1, 0));
      return;
    }

    if (event.key === "Enter") {
      event.preventDefault();
      const command = filteredCommands[activeIndex];
      if (command) {
        executeCommand(command);
      }
    }
  };

  const groupedCommands = groupCommands(filteredCommands);

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <Button
          {...props}
          variant="outline"
          className={cn(
            "group relative h-8 w-full flex-1 justify-start rounded-md bg-muted/25 text-sm font-normal text-muted-foreground shadow-none hover:bg-accent sm:w-40 sm:pe-12 md:flex-none lg:w-52 xl:w-64",
            className,
          )}
          aria-keyshortcuts="Meta+K Control+K"
        >
          <SearchIcon
            aria-hidden="true"
            className="absolute inset-s-1.5 top-1/2 size-4 -translate-y-1/2"
          />
          <span className="ms-4">{placeholder}</span>
          <kbd className="pointer-events-none absolute inset-e-[0.3rem] top-[0.3rem] hidden h-5 items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100 select-none group-hover:bg-accent sm:flex">
            <span className="text-xs">⌘</span>K
          </kbd>
        </Button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm" />
        <Dialog.Content className="fixed left-1/2 top-[12svh] z-50 grid w-[min(calc(100vw-2rem),42rem)] -translate-x-1/2 overflow-hidden rounded-xl border bg-popover text-popover-foreground shadow-2xl outline-none">
          <Dialog.Title className="sr-only">命令搜索</Dialog.Title>
          <div className="flex h-12 items-center gap-3 border-b px-4">
            <SearchIcon className="size-4 shrink-0 text-muted-foreground" />
            <input
              ref={inputRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={handleInputKeyDown}
              placeholder="搜索页面、操作、配色或布局"
              className="h-full min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            <kbd className="rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
              ESC
            </kbd>
          </div>

          <div className="max-h-[min(28rem,60svh)] overflow-y-auto p-2">
            {filteredCommands.length ? (
              groupedCommands.map(([group, items]) => (
                <div key={group} className="not-first:mt-2">
                  <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
                    {group}
                  </div>
                  <div className="grid gap-1">
                    {items.map(({ command: item, index }) => {
                      const active = index === activeIndex;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onMouseEnter={() => setActiveIndex(index)}
                          onClick={() => executeCommand(item)}
                          className={cn(
                            "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-start text-sm outline-none transition-colors",
                            active
                              ? "bg-accent text-accent-foreground"
                              : "text-popover-foreground hover:bg-accent hover:text-accent-foreground",
                          )}
                        >
                          <span
                            className={cn(
                              "flex size-8 shrink-0 items-center justify-center rounded-md border bg-background text-muted-foreground",
                              active && "border-primary/30 text-primary",
                            )}
                          >
                            {item.icon}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-medium">{item.title}</span>
                            <span className="block truncate text-xs text-muted-foreground">
                              {item.description}
                            </span>
                          </span>
                          {active ? <Check className="size-4 shrink-0 text-primary" /> : null}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
            ) : (
              <div className="flex min-h-32 flex-col items-center justify-center text-center">
                <SearchIcon className="mb-2 size-6 text-muted-foreground" />
                <div className="text-sm font-medium">没有找到结果</div>
                <div className="mt-1 text-xs text-muted-foreground">换个关键词试试</div>
              </div>
            )}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

type CommandItem = {
  id: string;
  title: string;
  description: string;
  group: string;
  icon: ReactNode;
  keywords: string;
  run: () => void;
};

function normalizeSearch(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

function groupCommands(commands: CommandItem[]) {
  return commands.reduce<Array<[string, Array<{ command: CommandItem; index: number }>]>>(
    (groups, command, index) => {
    const group = groups.find(([name]) => name === command.group);
    if (group) {
      group[1].push({ command, index });
    } else {
      groups.push([command.group, [{ command, index }]]);
    }
    return groups;
    },
    [],
  );
}

function PanelIcon() {
  return (
    <svg
      aria-hidden="true"
      className="size-4"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M9 3v18" />
    </svg>
  );
}
