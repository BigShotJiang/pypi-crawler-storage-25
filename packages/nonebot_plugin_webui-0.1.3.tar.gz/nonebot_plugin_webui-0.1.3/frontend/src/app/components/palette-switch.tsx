import { Check, Palette } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useUiStore } from "@/stores/ui-store";

const palettes = [
  { value: "jade", label: "青绿", color: "bg-[#218579]" },
  { value: "indigo", label: "靛蓝", color: "bg-[#5167d6]" },
  { value: "rose", label: "玫瑰", color: "bg-[#c75277]" },
  { value: "amber", label: "琥珀", color: "bg-[#b7791f]" },
  { value: "zinc", label: "石墨", color: "bg-[#3f4650]" },
] as const;

export function PaletteSwitch() {
  const palette = useUiStore((state) => state.palette);
  const setPalette = useUiStore((state) => state.setPalette);

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="scale-95 rounded-full">
          <Palette className="size-[1.2rem]" />
          <span className="sr-only">切换配色</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-36">
        {palettes.map((item) => (
          <DropdownMenuItem key={item.value} onClick={() => setPalette(item.value)}>
            <span className={cn("size-3 rounded-full ring-1 ring-border", item.color)} />
            {item.label}
            <Check size={14} className={cn("ms-auto", palette !== item.value && "hidden")} />
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
