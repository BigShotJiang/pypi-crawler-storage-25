import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LockKeyhole } from "lucide-react";
import { useState, type ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getAuthStatus, login } from "@/lib/api";

export function AuthGate({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const auth = useQuery({ queryKey: ["auth", "status"], queryFn: getAuthStatus, retry: false });

  const loginMutation = useMutation({
    mutationFn: () => login({ username, password }),
    onSuccess: async () => {
      setError("");
      await queryClient.invalidateQueries({ queryKey: ["auth", "status"] });
    },
    onError: () => setError("访问令牌不正确"),
  });

  if (auth.isLoading) {
    return (
      <div className="grid min-h-screen place-items-center bg-background text-sm text-muted-foreground">
        正在检查登录状态...
      </div>
    );
  }

  if (auth.isError) {
    return (
      <div className="grid min-h-screen place-items-center bg-background p-4">
        <Card className="w-full max-w-sm gap-3 p-6 text-center">
          <div className="text-lg font-semibold">无法连接 WebUI 后端</div>
          <div className="text-sm text-muted-foreground">
            请重启 python bot.py，确认 /webui/api/auth/status 可访问。
          </div>
        </Card>
      </div>
    );
  }

  if (!auth.data?.enabled || auth.data.authenticated) {
    return <>{children}</>;
  }

  return (
    <div className="grid min-h-screen place-items-center bg-background p-4">
      <Card className="w-full max-w-sm gap-5 p-6">
        <div className="grid gap-2 text-center">
          <div className="mx-auto flex size-11 items-center justify-center rounded-full border bg-muted/40">
            <LockKeyhole className="size-5 text-primary" />
          </div>
          <div className="text-lg font-semibold">登录 NoneBot WebUI</div>
          <div className="text-sm text-muted-foreground">默认账号 admin，初始密码为 WEBUI_ACCESS_TOKEN</div>
        </div>
        <form
          className="grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            loginMutation.mutate();
          }}
        >
          <Input
            autoFocus
            value={username}
            placeholder="账号"
            autoComplete="username"
            onChange={(event) => setUsername(event.target.value)}
          />
          <Input
            value={password}
            type="password"
            placeholder="密码"
            autoComplete="current-password"
            onChange={(event) => setPassword(event.target.value)}
          />
          {error ? <div className="text-sm text-destructive">{error}</div> : null}
          <Button type="submit" disabled={!username || !password || loginMutation.isPending}>
            {loginMutation.isPending ? "登录中" : "登录"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
