import { Link, useRouterState } from "@tanstack/react-router";
import {
  Boxes,
  Bot,
  BrainCircuit,
  Component,
  Database,
  FileText,
  LayoutDashboard,
  MessageSquare,
  PanelLeft,
  Settings,
  ScrollText,
  Store,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

import { AccountActions } from "@/app/components/account-actions";
import { ConfigDrawer } from "@/app/components/config-drawer";
import { PaletteSwitch } from "@/app/components/palette-switch";
import { SearchButton } from "@/app/components/search-button";
import { ThemeSwitch } from "@/app/components/theme-switch";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { useUiStore } from "@/stores/ui-store";

const nav = [
  { to: "/", label: "总览", icon: LayoutDashboard },
  { to: "/bots", label: "机器人", icon: Bot },
  { to: "/config", label: "配置", icon: Settings },
  { to: "/chat", label: "聊天", icon: MessageSquare },
  { to: "/models", label: "模型", icon: BrainCircuit },
  { to: "/plugins", label: "插件", icon: Boxes },
  { to: "/store", label: "商店", icon: Store },
  { to: "/files", label: "文件", icon: FileText },
  { to: "/database", label: "数据库", icon: Database },
  { to: "/logs", label: "实时日志", icon: ScrollText },
  { to: "/components", label: "组件", icon: Component },
];

const titles = Object.fromEntries(nav.map((item) => [item.to, item.label])) as Record<
  string,
  string
>;

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(max-width: 767px)");
    const update = () => setIsMobile(media.matches);

    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  return isMobile;
}

function getSidebarLayoutState({
  layoutMode,
  sidebarVariant,
  sidebarCollapsed,
  offcanvasOpen,
}: {
  layoutMode: "default" | "compact" | "full";
  sidebarVariant: "inset" | "floating" | "sidebar";
  sidebarCollapsed: boolean;
  offcanvasOpen: boolean;
}) {
  const fullLayout = layoutMode === "full";
  const compactLayout = layoutMode === "compact" || sidebarCollapsed;
  const insetLayout = sidebarVariant === "inset";
  const floatingLayout = sidebarVariant === "floating";
  const standardLayout = sidebarVariant === "sidebar";
  const contentCollapsed = compactLayout || (fullLayout && !offcanvasOpen);
  const collapsedSidebarWidth = "w-[90px]";
  const expandedSidebarWidth = "w-60";

  return {
    fullLayout,
    insetLayout,
    floatingLayout,
    standardLayout,
    contentCollapsed,
    state: contentCollapsed ? "collapsed" : "expanded",
    collapsible: fullLayout ? "offcanvas" : compactLayout ? "icon" : "",
    gapWidth: fullLayout
      ? offcanvasOpen
        ? compactLayout
          ? collapsedSidebarWidth
          : expandedSidebarWidth
        : "w-0"
      : compactLayout
        ? collapsedSidebarWidth
        : expandedSidebarWidth,
    containerWidth: contentCollapsed ? collapsedSidebarWidth : expandedSidebarWidth,
    triggerTitle: fullLayout || compactLayout ? "展开侧栏" : "收起侧栏",
  };
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const sidebarCollapsed = useUiStore((state) => state.sidebarCollapsed);
  const sidebarVariant = useUiStore((state) => state.sidebarVariant);
  const layoutMode = useUiStore((state) => state.layoutMode);
  const offcanvasOpen = useUiStore((state) => state.offcanvasOpen);
  const setOffcanvasOpen = useUiStore((state) => state.setOffcanvasOpen);
  const toggleSidebar = useUiStore((state) => state.toggleSidebar);
  const isMobile = useIsMobile();
  const sidebar = getSidebarLayoutState({
    layoutMode,
    sidebarVariant,
    sidebarCollapsed,
    offcanvasOpen,
  });
  const sidebarContentCollapsed = !isMobile && sidebar.contentCollapsed;
  const sidebarOpen = isMobile ? offcanvasOpen : true;
  const closeMobileSidebar = () => {
    if (isMobile) {
      setOffcanvasOpen(false);
    }
  };
  const [menuTextVisible, setMenuTextVisible] = useState(!sidebarContentCollapsed);
  const [menuTextMounted, setMenuTextMounted] = useState(!sidebarContentCollapsed);
  const wideWorkspace = ["/files", "/database", "/logs"].includes(pathname);
  const logoSrc =
    window.location.port === "5173"
      ? "/api/static/logo.png"
      : `/${window.location.pathname.split("/").filter(Boolean)[0] ?? "webui"}/api/static/logo.png`;

  useEffect(() => {
    if (sidebarContentCollapsed) {
      setMenuTextVisible(false);
      const timer = window.setTimeout(() => setMenuTextMounted(false), 220);
      return () => window.clearTimeout(timer);
    }
    setMenuTextMounted(true);
    const frame = window.requestAnimationFrame(() => setMenuTextVisible(true));
    return () => window.cancelAnimationFrame(frame);
  }, [sidebarContentCollapsed]);

  return (
    <div
      data-slot="app-shell"
      data-variant={sidebar.insetLayout ? "inset" : sidebar.floatingLayout ? "floating" : "sidebar"}
      className={cn(
        "group/sidebar-wrapper flex h-svh w-full overflow-hidden",
        sidebar.insetLayout ? "bg-sidebar" : "bg-background",
      )}
    >
      {offcanvasOpen ? (
        <button
          type="button"
          aria-label="关闭侧栏"
          className="fixed inset-0 z-[60] bg-background/45 backdrop-blur-[2px] md:hidden"
          onClick={() => setOffcanvasOpen(false)}
        />
      ) : null}
      <aside
        data-slot="sidebar"
        data-state={sidebar.state}
        data-collapsible={sidebar.collapsible}
        data-variant={sidebarVariant}
        data-side="start"
        className={cn(
          "group peer shrink-0 bg-transparent text-sidebar-foreground",
          "fixed inset-y-0 start-0 z-[70] transition-[width] duration-300 ease-linear md:relative md:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          sidebar.gapWidth,
          "max-md:w-56",
        )}
      >
        <div
          data-slot="sidebar-container"
          className={cn(
            "fixed inset-y-0 z-30 flex transition-[inset-inline-start,width] duration-300 ease-linear",
            sidebar.fullLayout ? "-start-56" : "start-0",
            !isMobile && sidebar.standardLayout && "border-e border-sidebar-border",
            !isMobile && (sidebar.floatingLayout || sidebar.insetLayout) && "p-2",
            !isMobile && sidebar.fullLayout && "border-e border-sidebar-border",
            !isMobile && sidebar.fullLayout && sidebar.insetLayout && "border-e-0",
            !isMobile && sidebar.fullLayout && offcanvasOpen && "start-0",
            !isMobile && sidebar.fullLayout && offcanvasOpen && sidebar.standardLayout && "shadow-xl",
            !isMobile && sidebar.fullLayout && sidebar.floatingLayout && "p-2 border-e-0",
            !isMobile && sidebar.containerWidth,
            !isMobile && sidebar.contentCollapsed && "w-[90px] min-w-[90px]",
            "max-md:start-0 max-md:w-56 max-md:p-2",
          )}
        >
          <div
            data-sidebar="sidebar"
            data-slot="sidebar-inner"
            className={cn(
              "flex h-full w-full flex-col bg-sidebar",
              sidebar.floatingLayout && "rounded-lg border border-sidebar-border shadow-sm",
              "max-md:rounded-xl max-md:border max-md:border-sidebar-border max-md:shadow-2xl",
            )}
          >
            <div data-slot="sidebar-header" className="flex min-w-0 flex-col gap-2 overflow-hidden px-2 py-1.5">
              <div
                data-slot="sidebar-brand"
                className={cn(
                  "flex h-14 w-full items-center gap-2 overflow-hidden rounded-md px-1 py-1 text-start text-[13px]",
                )}
              >
                <span
                  className={cn(
                    "flex size-12 shrink-0 items-center justify-center overflow-visible rounded-md",
                    sidebarContentCollapsed && "size-12",
                  )}
                >
                  <img
                    src={logoSrc}
                    alt="NoneBot WebUI"
                    className="max-h-full max-w-full rounded-md object-contain"
                  />
                </span>
                {!sidebarContentCollapsed && (
                  <div className="grid min-w-0 w-fit max-w-full gap-1 text-start leading-none">
                    <div className="truncate text-[17px] font-semibold">NoneBot WebUI</div>
                    <div className="justify-self-end text-xs font-semibold leading-none text-primary">
                      v{__WEBUI_VERSION__}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div
              data-slot="sidebar-content"
              className={cn(
                "flex min-h-0 flex-1 flex-col gap-1 overflow-x-hidden overflow-y-auto px-2 py-1",
              )}
            >
              <div data-slot="sidebar-group" className="relative flex w-full min-w-0 flex-col">
                <div data-slot="sidebar-group-content" className="w-full text-sm">
                  <ul
                    data-slot="sidebar-menu"
                    className="flex w-full min-w-0 flex-col gap-2"
                  >
                    {nav.map((item) => {
                      const Icon = item.icon;
                      const active = pathname === item.to;
                      return (
                        <li
                          key={item.to}
                          data-slot="sidebar-menu-item"
                          className="group/menu-item relative"
                        >
                          <Link
                            data-slot="sidebar-menu-button"
                            data-active={active}
                            data-size="default"
                            to={item.to}
                            onClick={closeMobileSidebar}
                            className={cn(
                              "peer/menu-button relative flex h-[42px] w-full items-center overflow-hidden rounded-md text-start text-[19px] outline-hidden ring-sidebar-ring hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground",
                              active &&
                                !sidebarContentCollapsed &&
                                "bg-sidebar-accent font-semibold text-primary",
                            )}
                            title={item.label}
                          >
                            <span
                              className={cn(
                                "absolute top-1/2 flex size-10 shrink-0 -translate-y-1/2 items-center justify-center rounded-md [&>svg]:size-[23px] [&>svg]:shrink-0",
                                "left-2 translate-x-0",
                                active &&
                                  sidebarContentCollapsed &&
                                  "bg-sidebar-accent text-primary",
                              )}
                            >
                              <Icon />
                            </span>
                            <span
                              className={cn(
                                "ms-12 truncate transition-opacity duration-200",
                                menuTextVisible ? "opacity-100" : "opacity-0",
                                !menuTextMounted && "w-0",
                              )}
                            >
                              {item.label}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>
            </div>

            <AccountActions
              collapsed={sidebarContentCollapsed}
              textVisible={menuTextVisible}
              textMounted={menuTextMounted}
            />

            <button
              data-slot="sidebar-rail"
              aria-label="Toggle Sidebar"
              tabIndex={-1}
              onClick={toggleSidebar}
              title="Toggle Sidebar"
              className="absolute inset-y-0 -end-4 z-20 hidden w-4 -translate-x-1/2 after:absolute after:inset-y-0 after:start-1/2 after:w-0.5 hover:after:bg-sidebar-border rtl:translate-x-1/2 sm:flex"
            />
          </div>
        </div>
      </aside>

      <div
        data-slot="workspace-frame"
        className={cn(
          "relative flex min-w-0 flex-1 flex-col overflow-hidden bg-background max-md:m-0 max-md:h-svh max-md:rounded-none",
          sidebar.insetLayout && "m-2 h-[calc(100svh-1rem)] rounded-xl border border-border/60 shadow-sm",
          sidebar.insetLayout && !sidebar.contentCollapsed && "ms-0",
          sidebar.floatingLayout && "h-svh",
          sidebar.standardLayout && "h-svh",
        )}
      >
        <header
          data-slot="topbar"
          className="z-50 h-16 shrink-0 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
        >
          <div className="relative flex h-full items-center gap-3 px-4 sm:gap-4">
            <Button
              data-sidebar="trigger"
              data-slot="sidebar-trigger"
              variant="outline"
              size="icon"
              className="size-7 max-md:scale-125"
              onClick={toggleSidebar}
              title={sidebar.triggerTitle}
            >
              <PanelLeft className="size-4" aria-hidden="true" />
              <span className="sr-only">Toggle Sidebar</span>
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <SearchButton className="me-auto" placeholder={`搜索${titles[pathname] ?? ""}`} />
            <ThemeSwitch />
            <PaletteSwitch />
            <ConfigDrawer />
          </div>
        </header>

        <main data-slot="workspace" className="min-h-0 flex-1 overflow-y-auto px-4 py-6">
          <div
            className={cn(
              "@7xl/content:mx-auto @7xl/content:w-full",
              wideWorkspace ? "@7xl/content:max-w-none" : "@7xl/content:max-w-7xl",
            )}
          >
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
