import axios from "axios";

export type RuntimeInfo = {
  driver: string;
  nonebot_version: string | null;
  python_version: string;
  platform: string;
  cwd: string;
  webui_path: string;
  pid: number;
  process_started_at: number;
  system_started_at: number;
};

export type AuthStatus = {
  enabled: boolean;
  authenticated: boolean;
  username: string;
};

export type RuntimeMetrics = {
  timestamp: number;
  cpu: {
    percent: number;
    logical_count: number | null;
    physical_count: number | null;
  };
  memory: {
    total: number;
    available: number;
    used: number;
    percent: number;
  };
  disk: {
    total: number;
    used: number;
    free: number;
    percent: number;
  };
  process: {
    pid: number;
    cpu_percent: number;
    memory_rss: number;
    memory_vms: number;
    memory_percent: number;
    threads: number;
    started_at: number;
  };
  system: {
    started_at: number;
  };
};

export type ConfigItem = {
  key: string;
  value: unknown;
  type: string;
  masked: boolean;
};

export type DatabaseSettings = {
  enabled: boolean;
  url: string;
  available: boolean;
  error?: string | null;
  fallback_login: boolean;
};

export type PluginMetadata = {
  name?: string;
  description?: string;
  usage?: string;
  type?: string;
  homepage?: string;
  supported_adapters?: string[];
  config_schema?: Record<string, unknown> | null;
  config_schema_error?: string | null;
  extra?: Record<string, unknown>;
};

export type LoadedPlugin = {
  name: string;
  module_name: string;
  package_name: string;
  metadata: PluginMetadata | null;
  matcher_count: number;
  sub_plugins: string[];
  managed?: ManagedPlugin | null;
  runtime_disabled?: boolean;
  version?: string | null;
  latest_version?: string | null;
  update_available?: boolean;
};

export type ManagedPlugin = {
  module_name: string;
  package_name: string;
  enabled: boolean;
  configured: boolean;
};

export type PluginsResponse = {
  loaded: LoadedPlugin[];
  available: string[];
  managed: ManagedPlugin[];
};

export type ConnectedBot = {
  id: string;
  self_id: string;
  type?: string | null;
  platform?: string | null;
  adapter?: string | null;
  protocol?: string | null;
  nickname?: string | null;
  avatar_url?: string | null;
  friend_count?: number | null;
  group_count?: number | null;
  detail_error?: string | null;
};

export type BotsResponse = {
  items: ConnectedBot[];
  total: number;
};

export type BotConnectionSettings = {
  id: string;
  name: string;
  enabled: boolean;
  adapter: string;
  connection_mode: string;
  host: string;
  port: number;
  path: string;
  access_token: string;
  self_id: string;
  note: string;
  runtime?: BotConnectionRuntime;
};

export type BotAdapterStatus = {
  adapter: string;
  label: string;
  supported: boolean;
  installed: boolean;
  registered: boolean;
  install_command: string;
  error?: string | null;
};

export type BotConnectionRuntime = BotAdapterStatus & {
  connect_url: string;
  env_snippet: string;
  restart_required: boolean;
};

export type BotSettings = {
  connections: BotConnectionSettings[];
  adapters: BotAdapterStatus[];
};

export type BotSettingsPayload = {
  connections: BotConnectionSettings[];
};

export type BotAdapterInstallResponse = {
  task_id: string;
  task: WebuiTask;
};

export type WebuiTask = {
  id: string;
  title: string;
  status: "pending" | "running" | "success" | "failed";
  created_at: number;
  updated_at: number;
  logs: string[];
  result?: {
    ok?: boolean;
    adapter?: string;
    label?: string;
    command?: string;
    exit_code?: number;
    output?: string;
    installed?: boolean;
  } | null;
  error?: string | null;
};

export type WebuiTaskMessage =
  | { type: "snapshot" | "status" | "log" | "done"; line?: string; task: WebuiTask }
  | { type: "error"; message: string };

export type StorePlugin = {
  name: string;
  module_name: string;
  package_name: string;
  description: string;
  homepage?: string;
  author: string;
  tags: string[];
  type?: string;
  version?: string;
  valid?: boolean;
  is_official: boolean;
  install_command: string;
  installed: boolean;
  loaded: boolean;
  managed: boolean;
  current_version?: string | null;
  latest_version?: string | null;
  update_available?: boolean;
};

export type StorePluginsResponse = {
  items: StorePlugin[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
  sort: string;
  types: string[];
  update_targets: Array<{ module_name: string; package_name: string; name: string }>;
  cached?: boolean;
  cache_updated_at?: number;
  cache_source?: "database" | "memory" | "remote";
  source: string;
};

export type ChatMessagePayload = {
  message: string;
  user_id?: string;
  session_id?: string;
};

export type ChatMessageResponse = {
  ok: boolean;
  message: string;
  replies: string[];
};

export type AISettings = {
  enabled: boolean;
  default_provider_id: string;
  system_prompt: string;
  history_limit: number;
  providers: AIProvider[];
};

export type AIProvider = {
  id: string;
  name: string;
  enabled: boolean;
  api_key: string;
  has_api_key: boolean;
  base_url: string;
  models: AIModel[];
  default_model: string;
  timeout: number;
};

export type AIModel = {
  id: string;
  enabled: boolean;
};

export type FileEntry = {
  name: string;
  path: string;
  type: "directory" | "file";
  size: number;
  modified_at: number;
};

export type FileListResponse = {
  root: string;
  path: string;
  parent?: string | null;
  entries: FileEntry[];
};

export type FileContentResponse = {
  path: string;
  name: string;
  content: string;
  language: "text" | "python" | "json" | "yaml" | string;
  eol: "LF" | "CRLF";
  size: number;
  modified_at: number;
};

export type DatabaseTable = {
  name: string;
};

export type DatabaseRowsResponse = {
  table: string;
  columns: string[];
  rows: Record<string, unknown>[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
  sort: string;
  order: string;
};

export type DatabaseSchemaResponse = {
  table: string;
  columns: Array<{
    name: string;
    type: string;
    nullable: boolean;
    default?: string | null;
    primary_key: boolean;
  }>;
};

export type SqlExecuteResponse = {
  columns: string[];
  rows: Record<string, unknown>[];
  rowcount: number;
  elapsed_ms: number;
};

export type LogItem = {
  time: number;
  level: string;
  message: string;
  name: string;
};

function apiPrefix() {
  if (window.location.port === "5173") {
    return "/api";
  }

  const base = window.location.pathname.split("/").filter(Boolean)[0] ?? "webui";
  return `/${base}/api`;
}

export const api = axios.create({
  baseURL: apiPrefix(),
  timeout: 15000,
});

export async function getRuntime() {
  const response = await api.get<RuntimeInfo>("/runtime");
  return response.data;
}

export async function getAuthStatus() {
  const response = await api.get<AuthStatus>("/auth/status");
  return response.data;
}

export async function login(payload: { username: string; password: string }) {
  const response = await api.post<{ ok: boolean }>("/auth/login", payload);
  return response.data;
}

export async function logout() {
  const response = await api.post<{ ok: boolean }>("/auth/logout");
  return response.data;
}

export async function changePassword(payload: {
  username: string;
  new_username: string;
  current_password: string;
  new_password: string;
}) {
  const response = await api.post<{ ok: boolean; database_saved: boolean }>(
    "/auth/password",
    payload,
  );
  return response.data;
}

export async function restartRuntime() {
  const response = await api.post<{ ok: boolean; message: string }>("/runtime/restart");
  return response.data;
}

export async function getRuntimeMetrics() {
  const response = await api.get<RuntimeMetrics>("/runtime/metrics");
  return response.data;
}

export async function getConfig() {
  const response = await api.get<{ items: ConfigItem[] }>("/config");
  return response.data;
}

export async function getDatabaseSettings() {
  const response = await api.get<DatabaseSettings>("/settings/database");
  return response.data;
}

export async function updateDatabaseSettings(payload: { enabled: boolean; url: string }) {
  const response = await api.put<DatabaseSettings>("/settings/database", payload);
  return response.data;
}

export async function testDatabaseSettings(payload: { enabled: boolean; url: string }) {
  const response = await api.post<{ ok: boolean; error?: string | null }>(
    "/settings/database/test",
    payload,
  );
  return response.data;
}

export async function getPlugins() {
  const response = await api.get<PluginsResponse>("/plugins");
  return response.data;
}

export async function getBots() {
  const response = await api.get<BotsResponse>("/bots");
  return response.data;
}

export async function getBotSettings() {
  const response = await api.get<BotSettings>("/settings/bots");
  return response.data;
}

export async function updateBotSettings(payload: BotSettingsPayload) {
  const response = await api.put<BotSettings>("/settings/bots", payload);
  return response.data;
}

export async function installBotAdapter(adapter: string) {
  const response = await api.post<BotAdapterInstallResponse>(
    `/settings/bots/adapters/${encodeURIComponent(adapter)}/install`,
  );
  return response.data;
}

export async function installStorePlugin(payload: {
  package_name: string;
  module_name: string;
  name: string;
}) {
  const response = await api.post<BotAdapterInstallResponse>("/store/plugins/install", payload);
  return response.data;
}

export async function uninstallStorePlugin(payload: {
  package_name: string;
  module_name: string;
  name: string;
}) {
  const response = await api.post<BotAdapterInstallResponse>("/store/plugins/uninstall", payload);
  return response.data;
}

export async function getPluginConfig(moduleName: string) {
  const response = await api.get<{
    module_name: string;
    enabled: boolean;
    values: Record<string, unknown>;
    schema?: Record<string, unknown> | null;
    restart_required: boolean;
  }>(`/settings/plugins/${encodeURIComponent(moduleName)}`);
  return response.data;
}

export async function updatePluginConfig(
  moduleName: string,
  payload: { enabled: boolean; values: Record<string, unknown> },
) {
  const response = await api.put<{
    module_name: string;
    enabled: boolean;
    values: Record<string, unknown>;
    schema?: Record<string, unknown> | null;
    restart_required: boolean;
  }>(`/settings/plugins/${encodeURIComponent(moduleName)}`, payload);
  return response.data;
}

export async function setPluginEnabled(
  moduleName: string,
  payload: { enabled: boolean; package_name?: string },
) {
  const response = await api.patch<{
    module_name: string;
    enabled: boolean;
    runtime: { applied: boolean; mode: string; message: string };
    restart_required: boolean;
  }>(`/settings/plugins/${encodeURIComponent(moduleName)}/enabled`, payload);
  return response.data;
}

export async function updatePluginPackage(payload: {
  module_name: string;
  package_name: string;
  name: string;
}) {
  const response = await api.post<BotAdapterInstallResponse>("/plugins/update", payload);
  return response.data;
}

export async function updateAllPluginPackages(
  plugins: Array<{ module_name: string; package_name: string; name: string }>,
) {
  const response = await api.post<BotAdapterInstallResponse>("/plugins/update-all", { plugins });
  return response.data;
}

export function taskWebSocketUrl(taskId: string) {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const path =
    window.location.port === "5173"
      ? `/api/ws/tasks/${encodeURIComponent(taskId)}`
      : `${apiPrefix()}/ws/tasks/${encodeURIComponent(taskId)}`;
  return `${protocol}//${window.location.host}${path}`;
}

export function logsWebSocketUrl() {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const path = window.location.port === "5173" ? "/api/ws/logs" : `${apiPrefix()}/ws/logs`;
  return `${protocol}//${window.location.host}${path}`;
}

export async function getStorePlugins(
  query = "",
  params: { type?: string; page?: number; page_size?: number; sort?: string; refresh?: boolean } = {},
) {
  const response = await api.get<StorePluginsResponse>("/store/plugins", {
    params: { ...params, ...(query ? { q: query } : {}) },
  });
  return response.data;
}

export async function listFiles(path = "") {
  const response = await api.get<FileListResponse>("/files", { params: { path } });
  return response.data;
}

export async function getFileContent(path: string) {
  const response = await api.get<FileContentResponse>("/files/content", { params: { path } });
  return response.data;
}

export async function saveFileContent(path: string, payload: { content: string; eol: "LF" | "CRLF" }) {
  const response = await api.put<{ ok: boolean; path: string; size: number; modified_at: number }>(
    "/files/content",
    payload,
    { params: { path } },
  );
  return response.data;
}

export async function getDatabaseTables() {
  const response = await api.get<{ tables: DatabaseTable[] }>("/database/tables");
  return response.data;
}

export async function getDatabaseTableRows(
  table: string,
  params: { page?: number; page_size?: number; sort?: string; order?: string } = {},
) {
  const response = await api.get<DatabaseRowsResponse>(
    `/database/tables/${encodeURIComponent(table)}/rows`,
    { params },
  );
  return response.data;
}

export async function getDatabaseTableSchema(table: string) {
  const response = await api.get<DatabaseSchemaResponse>(
    `/database/tables/${encodeURIComponent(table)}/schema`,
  );
  return response.data;
}

export async function executeDatabaseSql(sql: string) {
  const response = await api.post<SqlExecuteResponse>("/database/sql", { sql });
  return response.data;
}

export async function getLogsSnapshot() {
  const response = await api.get<{ items: LogItem[] }>("/logs");
  return response.data;
}

export async function sendChatMessage(payload: ChatMessagePayload) {
  const response = await api.post<ChatMessageResponse>("/chat/message", payload);
  return response.data;
}

export async function getAISettings() {
  const response = await api.get<AISettings>("/settings/ai");
  return response.data;
}

export async function updateAISettings(payload: AISettings) {
  const response = await api.put<AISettings>("/settings/ai", payload);
  return response.data;
}

export async function fetchAIModels(payload: {
  api_key?: string;
  base_url: string;
  timeout: number;
}) {
  const response = await api.post<{ models: string[]; latency_ms: number }>(
    "/settings/ai/models",
    payload,
  );
  return response.data;
}

export async function testAIProvider(payload: {
  api_key?: string;
  base_url: string;
  timeout: number;
}) {
  const response = await api.post<{ ok: boolean; latency_ms: number; models_count: number }>(
    "/settings/ai/test",
    payload,
  );
  return response.data;
}

export async function testAIModel(payload: {
  api_key?: string;
  base_url: string;
  timeout: number;
  model: string;
}) {
  const response = await api.post<{ ok: boolean; model: string; latency_ms: number }>(
    "/settings/ai/test-model",
    payload,
  );
  return response.data;
}
