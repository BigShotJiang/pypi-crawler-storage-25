import { Outlet, createRootRoute, createRoute } from "@tanstack/react-router";

import { Shell } from "@/app/shell";
import { BotsPage } from "@/app/pages/bots-page";
import { ChatPage } from "@/app/pages/chat-page";
import { ComponentsPage } from "@/app/pages/components-page";
import { ConfigPage } from "@/app/pages/config-page";
import { DatabasePage } from "@/app/pages/database-page";
import { FilesPage } from "@/app/pages/files-page";
import { LogsPage } from "@/app/pages/logs-page";
import { ModelsPage } from "@/app/pages/models-page";
import { OverviewPage } from "@/app/pages/overview-page";
import { PluginsPage } from "@/app/pages/plugins-page";
import { StorePage } from "@/app/pages/store-page";

const rootRoute = createRootRoute({
  component: () => (
    <Shell>
      <Outlet />
    </Shell>
  ),
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: OverviewPage,
});

const configRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/config",
  component: ConfigPage,
});

const botsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/bots",
  component: BotsPage,
});

const chatRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/chat",
  component: ChatPage,
});

const modelsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/models",
  component: ModelsPage,
});

const componentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/components",
  component: ComponentsPage,
});

const pluginsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/plugins",
  component: PluginsPage,
});

const storeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/store",
  component: StorePage,
});

const filesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/files",
  component: FilesPage,
});

const databaseRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/database",
  component: DatabasePage,
});

const logsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/logs",
  component: LogsPage,
});

export const routeTree = rootRoute.addChildren([
  indexRoute,
  botsRoute,
  configRoute,
  chatRoute,
  modelsRoute,
  componentsRoute,
  pluginsRoute,
  storeRoute,
  filesRoute,
  databaseRoute,
  logsRoute,
]);
