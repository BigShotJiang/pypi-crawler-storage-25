import type { ComponentType, ReactNode } from "react";

import { cn } from "@/lib/utils";

type DetailRowProps = {
  icon?: ComponentType<{ className?: string }>;
  label: string;
  value: ReactNode;
  valueClassName?: string;
  className?: string;
};

export function DetailRow({
  icon: Icon,
  label,
  value,
  valueClassName,
  className,
}: DetailRowProps) {
  return (
    <div className={cn("flex items-start justify-between gap-4 text-sm", className)}>
      <span className="flex shrink-0 items-center gap-2 text-muted-foreground">
        {Icon && <Icon className="size-3.5" />}
        {label}
      </span>
      <span className={cn("min-w-0 text-right font-medium", valueClassName)}>
        {value ?? "-"}
      </span>
    </div>
  );
}
