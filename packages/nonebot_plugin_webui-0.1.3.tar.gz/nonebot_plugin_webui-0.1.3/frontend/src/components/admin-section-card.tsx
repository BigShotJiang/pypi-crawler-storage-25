import type { ReactNode } from "react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

type AdminSectionCardProps = {
  title: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  contentClassName?: string;
};

export function AdminSectionCard({
  title,
  description,
  action,
  children,
  className,
  contentClassName,
}: AdminSectionCardProps) {
  return (
    <Card
      className={cn(
        "gap-0 rounded-none border-0 border-b border-border/70 bg-transparent py-0 shadow-none last:border-b-0",
        className,
      )}
    >
      <div className="px-7 py-7">
        <CardHeader
          className={cn("gap-1.5 p-0", action && "grid-cols-[minmax(0,1fr)_auto]")}
        >
          <div className="min-w-0">
            <CardTitle className="text-base leading-6 font-medium">{title}</CardTitle>
            {description ? (
              <CardDescription className="mt-1.5 text-sm leading-5">
                {description}
              </CardDescription>
            ) : null}
          </div>
          {action ? <div className="self-start justify-self-end">{action}</div> : null}
        </CardHeader>
        <CardContent className={cn("min-w-0 p-0 pt-6", contentClassName)}>
          {children}
        </CardContent>
      </div>
    </Card>
  );
}
