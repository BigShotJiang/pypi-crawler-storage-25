import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type TableSkeletonProps = {
  rows?: number;
  cellHeight?: string;
  className?: string;
};

export function TableSkeleton({
  rows = 5,
  cellHeight = "h-12",
  className = "space-y-2",
}: TableSkeletonProps) {
  return (
    <div className={className}>
      {Array.from({ length: rows }).map((_, index) => (
        <Skeleton key={index} className={cn(cellHeight, "w-full")} />
      ))}
    </div>
  );
}
