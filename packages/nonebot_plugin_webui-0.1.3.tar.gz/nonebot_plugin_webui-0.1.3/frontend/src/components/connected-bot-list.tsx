import { Bot } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import type { BotsResponse, ConnectedBot } from "@/lib/api";

type ConnectedBotListProps = {
  data?: BotsResponse;
  isError?: boolean;
  emptyDescription?: string;
};

export function ConnectedBotList({
  data,
  isError = false,
  emptyDescription = "适配器连接后会显示在这里。",
}: ConnectedBotListProps) {
  const items = data?.items ?? [];

  return (
    <div className="grid gap-3">
      {items.map((bot) => (
        <ConnectedBotCard key={bot.id} bot={bot} />
      ))}
      {isError ? (
        <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">
          无法读取已连接 Bot，请查看 NoneBot 后端日志。
        </div>
      ) : null}
      {!isError && !items.length ? (
        <div className="rounded-lg border border-dashed bg-muted/25 p-6 text-center">
          <Bot className="mx-auto mb-2 size-7 text-muted-foreground" />
          <div className="text-sm font-medium">暂无连接的 Bot</div>
          <div className="mt-1 text-xs text-muted-foreground">{emptyDescription}</div>
        </div>
      ) : null}
    </div>
  );
}

function ConnectedBotCard({ bot }: { bot: ConnectedBot }) {
  return (
    <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-lg border bg-muted/25 p-3">
      <div className="flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-full border bg-background">
        {bot.avatar_url ? (
          <img
            src={bot.avatar_url}
            alt={bot.nickname || bot.self_id}
            className="size-full object-cover"
          />
        ) : (
          <Bot className="size-5 text-muted-foreground" />
        )}
      </div>
      <div className="min-w-0">
        <div className="truncate text-sm font-medium">{bot.nickname || bot.self_id}</div>
        <div className="truncate text-xs text-muted-foreground">
          {[bot.protocol, bot.adapter || "未知适配器", bot.self_id].filter(Boolean).join(" / ")}
        </div>
      </div>
      <div className="flex flex-wrap justify-end gap-1.5">
        <Badge>在线</Badge>
        {typeof bot.friend_count === "number" ? (
          <Badge className="border-border bg-background text-muted-foreground">
            好友 {bot.friend_count}
          </Badge>
        ) : null}
        {typeof bot.group_count === "number" ? (
          <Badge className="border-border bg-background text-muted-foreground">
            群 {bot.group_count}
          </Badge>
        ) : null}
        {bot.platform ? (
          <Badge className="border-border bg-background text-muted-foreground">
            {bot.platform}
          </Badge>
        ) : null}
        {bot.type ? <Badge className="bg-muted text-muted-foreground">{bot.type}</Badge> : null}
      </div>
    </div>
  );
}
