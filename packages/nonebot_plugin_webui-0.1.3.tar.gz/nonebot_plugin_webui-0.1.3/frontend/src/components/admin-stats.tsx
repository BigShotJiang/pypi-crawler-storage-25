import type { ComponentType, ReactNode } from "react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type AdminStatsGridProps = {
  children: ReactNode;
  className?: string;
};

export function AdminStatsGrid({ children, className }: AdminStatsGridProps) {
  return (
    <div className={cn("mt-4 grid flex-none grid-cols-2 gap-2 xl:grid-cols-4", className)}>
      {children}
    </div>
  );
}

type AdminStatCardProps = {
  title: string;
  value: string;
  desc: string;
  icon: ComponentType<{ className?: string }>;
  progress?: number;
  tone?: "default" | "primary" | "warning" | "danger";
};

export function AdminStatCard({
  title,
  value,
  desc,
  icon: Icon,
  progress,
  tone = "default",
}: AdminStatCardProps) {
  const normalizedProgress =
    typeof progress === "number" ? Math.max(0, Math.min(progress, 100)) : undefined;

  return (
    <Card className="gap-1.5 py-2.5 xl:gap-4 xl:py-4">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 px-3 pb-0 xl:px-4 xl:pb-1">
        <CardTitle className="text-xs font-medium xl:text-sm">{title}</CardTitle>
        <Icon
          className={cn(
            "size-3.5 xl:size-4",
            tone === "default" && "text-muted-foreground",
            tone === "primary" && "text-primary",
            tone === "warning" && "text-chart-2",
            tone === "danger" && "text-destructive",
          )}
        />
      </CardHeader>
      <CardContent className="px-3 xl:px-4">
        <div className="text-lg font-bold tabular-nums xl:text-xl">{value}</div>
        <p className="truncate text-[11px] text-muted-foreground xl:text-xs">{desc}</p>
        <div
          className={cn(
            "mt-3 h-1.5 overflow-hidden rounded-full",
            typeof normalizedProgress === "number" ? "bg-muted" : "bg-transparent",
          )}
        >
          {typeof normalizedProgress === "number" ? (
            <div
              className={cn(
                "h-full rounded-full transition-[width]",
                tone === "danger"
                  ? "bg-destructive"
                  : tone === "warning"
                    ? "bg-chart-2"
                    : "bg-primary",
              )}
              style={{ width: `${normalizedProgress}%` }}
            />
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
