import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { readFileSync } from "node:fs";
import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";

const projectToml = readFileSync(new URL("../pyproject.toml", import.meta.url), "utf-8");
const version = projectToml.match(/^version\s*=\s*"([^"]+)"/m)?.[1] ?? "0.0.0";
const backend = process.env.WEBUI_DEV_BACKEND || "http://127.0.0.1:8080";

export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  define: {
    __WEBUI_VERSION__: JSON.stringify(version),
  },
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    emptyOutDir: true,
    outDir: "../nonebot_plugin_webui/static",
  },
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: backend,
        ws: true,
        rewrite: (path) => `/webui${path}`,
      },
    },
  },
});
