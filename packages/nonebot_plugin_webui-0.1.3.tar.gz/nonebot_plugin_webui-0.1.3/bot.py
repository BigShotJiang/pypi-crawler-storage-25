import nonebot
import socket


HOST = "0.0.0.0"
DISPLAY_HOST = "127.0.0.1"
PORT = 8080


def find_available_port(host: str, preferred_port: int, attempts: int = 20) -> int:
    for port in range(preferred_port, preferred_port + attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            if sock.connect_ex((host, port)) != 0:
                return port
    raise RuntimeError(
        f"No available port found from {preferred_port} to {preferred_port + attempts - 1}"
    )


port = find_available_port(DISPLAY_HOST, PORT)

nonebot.init(driver="~fastapi")
nonebot.load_builtin_plugin("echo")
nonebot.load_plugin("nonebot_plugin_webui")


if __name__ == "__main__":
    if port != PORT:
        nonebot.logger.warning(
            "Port {} is already in use, using http://{}:{}/webui instead",
            PORT,
            DISPLAY_HOST,
            port,
        )
    nonebot.run(host=HOST, port=port)
