from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable


TaskRunner = Callable[[Callable[[str], Awaitable[None]]], Awaitable[dict[str, Any]]]


@dataclass
class TaskState:
    id: str
    title: str
    status: str = "pending"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    logs: list[str] = field(default_factory=list)
    result: dict[str, Any] | None = None
    error: str | None = None
    subscribers: set[asyncio.Queue[dict[str, Any]]] = field(default_factory=set)


class TaskManager:
    def __init__(self) -> None:
        self._tasks: dict[str, TaskState] = {}

    def create(self, title: str, runner: TaskRunner) -> TaskState:
        task = TaskState(id=uuid.uuid4().hex, title=title)
        self._tasks[task.id] = task
        asyncio.create_task(self._run(task, runner))
        return task

    def get(self, task_id: str) -> TaskState | None:
        return self._tasks.get(task_id)

    async def subscribe(self, task_id: str) -> asyncio.Queue[dict[str, Any]] | None:
        task = self.get(task_id)
        if task is None:
            return None

        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        task.subscribers.add(queue)
        await queue.put({"type": "snapshot", "task": dump_task(task)})
        return queue

    def unsubscribe(self, task_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        task = self.get(task_id)
        if task is not None:
            task.subscribers.discard(queue)

    async def _run(self, task: TaskState, runner: TaskRunner) -> None:
        task.status = "running"
        await self._publish(task, {"type": "status", "task": dump_task(task)})

        async def emit(line: str) -> None:
            value = line.rstrip()
            if not value:
                return
            task.logs.append(value)
            task.logs = task.logs[-300:]
            task.updated_at = time.time()
            await self._publish(task, {"type": "log", "line": value, "task": dump_task(task)})

        try:
            task.result = await runner(emit)
            task.status = "success" if task.result.get("ok") else "failed"
        except Exception as exc:
            task.error = str(exc)
            task.status = "failed"
        finally:
            task.updated_at = time.time()
            await self._publish(task, {"type": "done", "task": dump_task(task)})

    async def _publish(self, task: TaskState, message: dict[str, Any]) -> None:
        for queue in list(task.subscribers):
            await queue.put(message)


def dump_task(task: TaskState) -> dict[str, Any]:
    return {
        "id": task.id,
        "title": task.title,
        "status": task.status,
        "created_at": task.created_at,
        "updated_at": task.updated_at,
        "logs": task.logs,
        "result": task.result,
        "error": task.error,
    }


tasks = TaskManager()
