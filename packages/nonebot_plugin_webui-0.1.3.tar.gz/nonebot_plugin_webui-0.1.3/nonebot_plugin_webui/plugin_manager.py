from __future__ import annotations

import asyncio
import sys
from importlib.metadata import PackageNotFoundError, version
from shutil import which
from typing import Any, Awaitable, Callable


Emit = Callable[[str], Awaitable[None]]


def package_version(package_name: str) -> str | None:
    candidates = {
        package_name,
        package_name.replace("_", "-"),
        package_name.replace("-", "_"),
    }
    for name in candidates:
        try:
            return version(name)
        except PackageNotFoundError:
            continue
    return None


def is_package_installed(package_name: str) -> bool:
    return package_version(package_name) is not None


async def install_plugin_package_stream(package_name: str, emit: Emit) -> dict[str, Any]:
    package = package_name.strip()
    if not package:
        return {
            "ok": False,
            "package_name": package,
            "command": "",
            "exit_code": -1,
            "output": "Package name is required",
            "installed": False,
        }

    nb = which("nb")
    if nb:
        command = [nb, "plugin", "install", package]
    else:
        command = [sys.executable, "-m", "pip", "install", package]

    await emit(f"$ {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    lines: list[str] = []
    if process.stdout is not None:
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            text = line.decode(errors="replace").rstrip()
            lines.append(text)
            await emit(text)

    exit_code = await process.wait()
    installed = is_package_installed(package)
    return {
        "ok": exit_code == 0 and installed,
        "package_name": package,
        "command": " ".join(command),
        "exit_code": exit_code,
        "output": "\n".join(lines[-80:]),
        "installed": installed,
        "current_version": package_version(package),
        "used_cli": bool(nb),
    }


async def uninstall_plugin_package_stream(package_name: str, emit: Emit) -> dict[str, Any]:
    package = package_name.strip()
    if not package:
        return {
            "ok": False,
            "package_name": package,
            "command": "",
            "exit_code": -1,
            "output": "Package name is required",
            "installed": False,
        }

    nb = which("nb")
    if nb:
        command = [nb, "plugin", "uninstall", package]
        input_text = "y\n"
    else:
        command = [sys.executable, "-m", "pip", "uninstall", "-y", package]
        input_text = None

    await emit(f"$ {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdin=asyncio.subprocess.PIPE if input_text else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    if input_text and process.stdin is not None:
        process.stdin.write(input_text.encode())
        await process.stdin.drain()
        process.stdin.close()

    lines: list[str] = []
    if process.stdout is not None:
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            text = line.decode(errors="replace").rstrip()
            lines.append(text)
            await emit(text)

    exit_code = await process.wait()
    installed = is_package_installed(package)
    return {
        "ok": exit_code == 0 and not installed,
        "package_name": package,
        "command": " ".join(command),
        "exit_code": exit_code,
        "output": "\n".join(lines[-80:]),
        "installed": installed,
        "used_cli": bool(nb),
    }


async def update_plugin_package_stream(package_name: str, emit: Emit) -> dict[str, Any]:
    package = package_name.strip()
    if not package:
        return {
            "ok": False,
            "package_name": package,
            "command": "",
            "exit_code": -1,
            "output": "Package name is required",
            "installed": False,
        }

    nb = which("nb")
    if nb:
        command = [nb, "plugin", "update", package]
    else:
        command = [sys.executable, "-m", "pip", "install", "--upgrade", package]

    await emit(f"$ {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    lines: list[str] = []
    if process.stdout is not None:
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            text = line.decode(errors="replace").rstrip()
            lines.append(text)
            await emit(text)

    exit_code = await process.wait()
    installed = is_package_installed(package)
    return {
        "ok": exit_code == 0 and installed,
        "package_name": package,
        "command": " ".join(command),
        "exit_code": exit_code,
        "output": "\n".join(lines[-80:]),
        "installed": installed,
        "current_version": package_version(package),
        "used_cli": bool(nb),
    }
