from typing import Any, Optional

from nonebot import get_driver

try:
    from nonebot import get_plugin_config
except ImportError:  # pragma: no cover
    get_plugin_config = None
from pydantic import BaseModel, Field


class Config(BaseModel):
    webui_path: str = Field(default="/webui")
    webui_access_token: Optional[Any] = Field(default=None)
    webui_auth_cookie_name: str = Field(default="nonebot_webui_session")
    webui_store_url: str = Field(default="https://registry.nonebot.dev/plugins.json")
    webui_store_timeout: float = Field(default=10)
    webui_store_cache_ttl: float = Field(default=3600)
    webui_store_refresh_interval: float = Field(default=3600)
    webui_ai_enabled: bool = Field(default=True)
    webui_ai_api_key: Optional[str] = Field(default=None)
    webui_ai_base_url: str = Field(default="https://api.openai.com/v1")
    webui_ai_model: str = Field(default="gpt-4o-mini")
    webui_ai_system_prompt: str = Field(
        default="你是 NoneBot WebUI 中的 AI 助手，回答要简洁、准确。"
    )
    webui_ai_timeout: float = Field(default=60)
    webui_ai_history_limit: int = Field(default=12)

    class Config:
        extra = "ignore"


def get_config() -> Config:
    if get_plugin_config is not None:
        return get_plugin_config(Config)

    driver_config = get_driver().config
    if hasattr(driver_config, "dict"):
        return Config(**driver_config.dict())
    if hasattr(driver_config, "model_dump"):
        return Config(**driver_config.model_dump())
    return Config()
