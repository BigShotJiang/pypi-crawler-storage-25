from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from importlib import import_module, invalidate_caches, util
from typing import Any, Awaitable, Callable

from nonebot import logger

from .settings import BotConnectionSettings


@dataclass(frozen=True)
class AdapterSpec:
    key: str
    label: str
    package: str
    module: str
    pip_package: str
    install_command: str
    adapter_attr: str = "Adapter"


ADAPTER_SPECS: dict[str, AdapterSpec] = {
    "onebot-v11": AdapterSpec(
        key="onebot-v11",
        label="OneBot v11",
        package="nonebot.adapters.onebot",
        module="nonebot.adapters.onebot.v11",
        pip_package="nonebot-adapter-onebot",
        install_command="pip install nonebot-adapter-onebot",
    ),
    "onebot-v12": AdapterSpec(
        key="onebot-v12",
        label="OneBot v12",
        package="nonebot.adapters.onebot",
        module="nonebot.adapters.onebot.v12",
        pip_package="nonebot-adapter-onebot",
        install_command="pip install nonebot-adapter-onebot",
    ),
    "console": AdapterSpec(
        key="console",
        label="Console",
        package="nonebot.adapters.console",
        module="nonebot.adapters.console",
        pip_package="nonebot-adapter-console",
        install_command="pip install nonebot-adapter-console",
    ),
    "telegram": AdapterSpec(
        key="telegram",
        label="Telegram",
        package="nonebot.adapters.telegram",
        module="nonebot.adapters.telegram",
        pip_package="nonebot-adapter-telegram",
        install_command="pip install nonebot-adapter-telegram",
    ),
    "discord": AdapterSpec(
        key="discord",
        label="Discord",
        package="nonebot.adapters.discord",
        module="nonebot.adapters.discord",
        pip_package="nonebot-adapter-discord",
        install_command="pip install nonebot-adapter-discord",
    ),
}

REGISTERED_ADAPTERS: set[str] = set()
REGISTER_ERRORS: dict[str, str] = {}


def register_configured_adapters(driver: Any, connections: list[BotConnectionSettings]) -> None:
    adapters = sorted({item.adapter for item in connections if item.enabled})
    for adapter in adapters:
        spec = ADAPTER_SPECS.get(adapter)
        if spec is None:
            REGISTER_ERRORS[adapter] = "Unsupported adapter"
            logger.warning("Unsupported bot adapter config: {}", adapter)
            continue

        if not is_adapter_installed(spec):
            REGISTER_ERRORS[adapter] = f"Adapter package is not installed: {spec.install_command}"
            logger.warning(
                "Bot adapter {} is not installed, install with: {}",
                spec.label,
                spec.install_command,
            )
            continue

        try:
            module = import_module(spec.module)
            adapter_class = getattr(module, spec.adapter_attr)
            driver.register_adapter(adapter_class)
        except Exception as exc:
            message = str(exc)
            if "already" in message.lower() and "register" in message.lower():
                REGISTERED_ADAPTERS.add(adapter)
                REGISTER_ERRORS.pop(adapter, None)
                logger.info("Bot adapter already registered: {}", spec.label)
                continue

            REGISTER_ERRORS[adapter] = message
            logger.warning("Failed to register bot adapter {}: {}", spec.label, exc)
        else:
            REGISTERED_ADAPTERS.add(adapter)
            REGISTER_ERRORS.pop(adapter, None)
            logger.info("Bot adapter registered from WebUI config: {}", spec.label)


def is_adapter_installed(spec: AdapterSpec) -> bool:
    return util.find_spec(spec.package) is not None


async def install_adapter_package(adapter: str, timeout: float = 300) -> dict[str, Any]:
    spec = ADAPTER_SPECS.get(adapter)
    if spec is None:
        return {
            "ok": False,
            "adapter": adapter,
            "label": adapter,
            "command": "",
            "exit_code": 1,
            "output": "Unsupported adapter",
            "installed": False,
        }

    command = [sys.executable, "-m", "pip", "install", spec.pip_package]
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )

    try:
        stdout, _ = await asyncio.wait_for(process.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        return {
            "ok": False,
            "adapter": adapter,
            "label": spec.label,
            "command": " ".join(command),
            "exit_code": -1,
            "output": f"Install timed out after {timeout:.0f} seconds",
            "installed": is_adapter_installed(spec),
        }

    output = stdout.decode("utf-8", errors="replace").strip()
    invalidate_caches()
    installed = is_adapter_installed(spec)

    if installed:
        REGISTER_ERRORS.pop(adapter, None)

    return {
        "ok": process.returncode == 0 and installed,
        "adapter": adapter,
        "label": spec.label,
        "command": " ".join(command),
        "exit_code": process.returncode,
        "output": output[-4000:],
        "installed": installed,
    }


async def install_adapter_package_stream(
    adapter: str,
    emit: Callable[[str], Awaitable[None]],
    timeout: float = 300,
) -> dict[str, Any]:
    spec = ADAPTER_SPECS.get(adapter)
    if spec is None:
        await emit("Unsupported adapter")
        return {
            "ok": False,
            "adapter": adapter,
            "label": adapter,
            "command": "",
            "exit_code": 1,
            "output": "Unsupported adapter",
            "installed": False,
        }

    command = [sys.executable, "-m", "pip", "install", spec.pip_package]
    await emit(f"$ {' '.join(command)}")

    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )

    output_lines: list[str] = []

    async def read_output() -> None:
        if process.stdout is None:
            return
        while True:
            line = await process.stdout.readline()
            if not line:
                break
            text = line.decode("utf-8", errors="replace").rstrip()
            output_lines.append(text)
            await emit(text)

    try:
        await asyncio.wait_for(read_output(), timeout=timeout)
        exit_code = await process.wait()
    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        await emit(f"Install timed out after {timeout:.0f} seconds")
        return {
            "ok": False,
            "adapter": adapter,
            "label": spec.label,
            "command": " ".join(command),
            "exit_code": -1,
            "output": f"Install timed out after {timeout:.0f} seconds",
            "installed": is_adapter_installed(spec),
        }

    invalidate_caches()
    installed = is_adapter_installed(spec)

    if installed:
        REGISTER_ERRORS.pop(adapter, None)
        await emit("Adapter package is installed. Restart NoneBot to register it.")

    output = "\n".join(output_lines).strip()
    return {
        "ok": exit_code == 0 and installed,
        "adapter": adapter,
        "label": spec.label,
        "command": " ".join(command),
        "exit_code": exit_code,
        "output": output[-4000:],
        "installed": installed,
    }


def get_adapter_status(adapter: str) -> dict[str, Any]:
    spec = ADAPTER_SPECS.get(adapter)
    if spec is None:
        return {
            "adapter": adapter,
            "label": adapter,
            "supported": False,
            "installed": False,
            "registered": False,
            "install_command": "",
            "error": REGISTER_ERRORS.get(adapter, "Unsupported adapter"),
        }

    return {
        "adapter": adapter,
        "label": spec.label,
        "supported": True,
        "installed": is_adapter_installed(spec),
        "registered": adapter in REGISTERED_ADAPTERS,
        "install_command": spec.install_command,
        "error": REGISTER_ERRORS.get(adapter),
    }


def get_all_adapter_statuses() -> list[dict[str, Any]]:
    return [get_adapter_status(adapter) for adapter in sorted(ADAPTER_SPECS)]


def get_connection_runtime(
    connection: BotConnectionSettings,
) -> dict[str, Any]:
    path = connection.path if connection.path.startswith("/") else f"/{connection.path}"
    if connection.connection_mode == "console":
        connect_url = "本地终端交互，无需连接地址"
    elif connection.connection_mode == "platform":
        connect_url = "由平台适配器配置项决定，无固定连接地址"
    else:
        protocol = "http" if connection.connection_mode == "http" else "ws"
        connect_url = f"{protocol}://{connection.host}:{connection.port}{path}"

    env_snippet = ""
    if connection.adapter == "onebot-v11":
        if connection.connection_mode == "forward-ws":
            env_snippet = f'ONEBOT_WS_URLS=["ws://{connection.host}:{connection.port}"]'
        elif connection.connection_mode == "http":
            key = connection.self_id or "你的QQ号"
            env_snippet = f'ONEBOT_API_ROOTS={{"{key}": "http://{connection.host}:{connection.port}/"}}'
    elif connection.adapter == "onebot-v12":
        if connection.connection_mode == "forward-ws":
            env_snippet = f'ONEBOT_V12_WS_URLS=["ws://{connection.host}:{connection.port}"]'
        elif connection.connection_mode == "http":
            key = connection.self_id or "你的Bot ID"
            env_snippet = f'ONEBOT_V12_API_ROOTS={{"{key}": "http://{connection.host}:{connection.port}/"}}'

    status = get_adapter_status(connection.adapter)
    return {
        **status,
        "connect_url": connect_url,
        "env_snippet": env_snippet,
        "restart_required": connection.enabled and not status["registered"],
    }
