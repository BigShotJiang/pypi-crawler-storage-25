from __future__ import annotations

from collections import defaultdict
import httpx
from nonebot import on_command
from nonebot.adapters import Event, Message
from nonebot.params import CommandArg

from .config import get_config
from .settings import AIConfig, AISettings, get_default_ai_provider

_sessions: dict[str, list[dict[str, str]]] = defaultdict(list)

ai = on_command("ai", aliases={"AI"}, priority=20, block=True)
ai_clear = on_command("ai_clear", aliases={"清空AI", "清空ai"}, priority=20, block=True)


@ai.handle()
async def handle_ai(event: Event, args: Message = CommandArg()) -> None:
    prompt = str(args).strip()
    if not prompt:
        await ai.finish("请输入要问 AI 的内容，例如：/ai 你好")

    ai_config, provider = get_default_ai_provider(get_config())
    if not ai_config.enabled:
        await ai.finish("AI 功能未启用。")
    if provider is None:
        await ai.finish("没有可用的 AI 模型提供商，请先在 WebUI 的模型页添加提供商。")
    if not provider.api_key:
        await ai.finish("AI API Key 未配置，请先在 WebUI 的模型页保存提供商设置。")

    session_id = event.get_session_id()
    history = _sessions[session_id]
    history.append({"role": "user", "content": prompt})
    del history[: max(0, len(history) - ai_config.history_limit)]

    try:
        reply = await _request_ai(ai_config, provider, history)
    except Exception as exc:
        history.pop()
        await ai.finish(f"AI 请求失败：{exc}")

    history.append({"role": "assistant", "content": reply})
    del history[: max(0, len(history) - ai_config.history_limit)]
    await ai.finish(reply)


@ai_clear.handle()
async def handle_ai_clear(event: Event) -> None:
    _sessions.pop(event.get_session_id(), None)
    await ai_clear.finish("AI 对话上下文已清空。")


async def _request_ai(
    ai_config: AIConfig,
    provider: AISettings,
    history: list[dict[str, str]],
) -> str:
    base_url = provider.base_url.rstrip("/")
    model = provider.default_model
    enabled_models = [item.id for item in provider.models if item.enabled]
    if model not in enabled_models:
        model = enabled_models[0] if enabled_models else ""
    if not model:
        raise RuntimeError("当前提供商没有启用的模型。")

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": ai_config.system_prompt},
            *history,
        ],
    }
    headers = {
        "Authorization": f"Bearer {provider.api_key}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=provider.timeout) as client:
        response = await client.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        data = response.json()

    content = data["choices"][0]["message"].get("content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        return "".join(
            part.get("text", "")
            for part in content
            if isinstance(part, dict) and part.get("type") == "text"
        ).strip()
    return str(content).strip()
