from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import platform
import sys
import time
from collections import deque
from importlib.metadata import PackageNotFoundError, distributions, version
from pathlib import Path
from typing import Any

import httpx
import nonebot
import psutil
from nonebot import logger
from fastapi import APIRouter, Depends, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from pydantic import BaseModel, Field
from sqlalchemy import inspect as sa_inspect, text

from .bot_adapters import (
    get_all_adapter_statuses,
    get_connection_runtime,
    install_adapter_package_stream,
)
from .config import Config
from .database import (
    DatabaseConfig,
    database,
    load_fallback_auth,
    load_fallback_token,
    save_database_config,
    save_fallback_token,
    test_database_url,
)
from .plugin_manager import (
    install_plugin_package_stream,
    package_version,
    uninstall_plugin_package_stream,
    update_plugin_package_stream,
)
from .settings import (
    AIConfig,
    AIModel,
    AISettings,
    BotConfig,
    BotConnectionSettings,
    ManagedPluginSettings,
    PluginConfig,
    dump_ai_settings_for_ui,
    load_settings,
    save_settings,
)
from .tasks import dump_task, tasks
from .virtual_chat import dispatch_webui_message

SECRET_KEYWORDS = (
    "token",
    "secret",
    "password",
    "passwd",
    "key",
    "access",
    "authorization",
    "credential",
)

_disabled_plugin_matchers: dict[str, list[tuple[int, type[Any]]]] = {}
PROTECTED_PLUGIN_MODULES = {
    "nonebot_plugin_webui",
    "nonebot_plugin_orm",
    "nonebot_plugin_localstore",
}
PROTECTED_PLUGIN_PACKAGES = {
    "nonebot-plugin-webui",
    "nonebot-plugin-orm",
    "nonebot-plugin-localstore",
}
STORE_CACHE_KEY = "store.plugins.registry"
_store_cache_lock = asyncio.Lock()
_store_registry_memory_cache: dict[str, Any] | None = None
_log_buffer: deque[dict[str, Any]] = deque(maxlen=1000)
_log_subscribers: set[asyncio.Queue[dict[str, Any]]] = set()
_log_handler_id: int | None = None


class ChatMessageRequest(BaseModel):
    message: str = Field(min_length=1)
    user_id: str = "webui-user"
    session_id: str = "webui-session"


class AISettingsPayload(BaseModel):
    enabled: bool
    default_provider_id: str
    system_prompt: str = ""
    history_limit: int = Field(ge=0, le=100)
    providers: list["AIProviderPayload"]


class AIProviderPayload(BaseModel):
    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    enabled: bool = True
    api_key: str | None = None
    base_url: str = Field(min_length=1)
    models: list["AIModelPayload"] = Field(default_factory=list)
    default_model: str = ""
    timeout: float = Field(ge=1, le=300)


class AIModelPayload(BaseModel):
    id: str = Field(min_length=1)
    enabled: bool = True


class AIProviderProbePayload(BaseModel):
    api_key: str | None = None
    base_url: str = Field(min_length=1)
    timeout: float = Field(default=30, ge=1, le=300)


class AIModelProbePayload(AIProviderProbePayload):
    model: str = Field(min_length=1)


class BotConnectionPayload(BaseModel):
    id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    enabled: bool = True
    adapter: str = Field(min_length=1)
    connection_mode: str = Field(min_length=1)
    host: str = Field(min_length=1)
    port: int = Field(ge=1, le=65535)
    path: str = "/"
    access_token: str = ""
    self_id: str = ""
    note: str = ""


class BotSettingsPayload(BaseModel):
    connections: list[BotConnectionPayload] = Field(default_factory=list)


class LoginPayload(BaseModel):
    username: str = "admin"
    password: str | None = None
    token: str | None = None


class PasswordChangePayload(BaseModel):
    username: str = "admin"
    new_username: str = Field(min_length=1, max_length=64)
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=6)


class DatabaseSettingsPayload(BaseModel):
    enabled: bool = True
    url: str = Field(min_length=1)


class StorePluginInstallPayload(BaseModel):
    package_name: str = Field(min_length=1)
    module_name: str = Field(min_length=1)
    name: str = ""


class StorePluginUninstallPayload(StorePluginInstallPayload):
    pass


class PluginUpdatePayload(BaseModel):
    module_name: str = Field(min_length=1)
    package_name: str = Field(min_length=1)
    name: str = ""


class PluginsUpdatePayload(BaseModel):
    plugins: list[PluginUpdatePayload] = Field(default_factory=list)


class PluginConfigPayload(BaseModel):
    values: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class PluginEnabledPayload(BaseModel):
    enabled: bool
    package_name: str = ""


class FileSavePayload(BaseModel):
    content: str
    eol: str = "LF"


class SqlExecutePayload(BaseModel):
    sql: str


def create_router(config: Config) -> APIRouter:
    async def require_webui_auth(request: Request) -> None:
        if not _is_api_path(request.url.path, config):
            return
        if _is_auth_path(request.url.path):
            return
        if not _auth_enabled(config):
            return
        if not _is_authenticated(request.cookies.get(config.webui_auth_cookie_name), config):
            raise HTTPException(status_code=401, detail="Unauthorized")

    router = APIRouter()
    static_dir = Path(__file__).parent / "static"
    auth_dependencies = [Depends(require_webui_auth)]
    store_refresh_task: asyncio.Task[None] | None = None

    @router.on_event("startup")
    async def start_store_cache_worker() -> None:
        nonlocal store_refresh_task
        _ensure_log_capture()
        if config.webui_store_refresh_interval <= 0:
            return
        store_refresh_task = asyncio.create_task(_store_cache_worker(config))

    @router.on_event("shutdown")
    async def stop_store_cache_worker() -> None:
        if store_refresh_task is None:
            return
        store_refresh_task.cancel()
        try:
            await store_refresh_task
        except asyncio.CancelledError:
            pass

    @router.get("", include_in_schema=False)
    async def index_without_slash() -> RedirectResponse:
        return RedirectResponse(f"{config.webui_path.rstrip('/')}/")

    @router.get("/", include_in_schema=False)
    async def index() -> HTMLResponse:
        return HTMLResponse(_html_with_favicon(static_dir / "index.html", config))

    @router.get("/api/static/logo.png", include_in_schema=False)
    async def logo() -> FileResponse:
        logo_path = static_dir / "logo.png"
        if not logo_path.exists():
            raise HTTPException(status_code=404, detail="Logo not found")
        return FileResponse(logo_path)

    @router.get("/api/auth/status")
    async def auth_status(request: Request) -> dict[str, Any]:
        enabled = _auth_enabled(config)
        return {
            "enabled": enabled,
            "authenticated": not enabled
            or _is_authenticated(request.cookies.get(config.webui_auth_cookie_name), config),
            "username": _auth_username(config),
        }

    @router.post("/api/auth/login")
    async def auth_login(payload: LoginPayload, response: Response) -> dict[str, Any]:
        if not _auth_enabled(config):
            return {"ok": True}
        username = payload.username.strip() or "admin"
        password = payload.password or payload.token or ""
        if not password:
            raise HTTPException(status_code=401, detail="Invalid username or password")

        db_verified = database.verify_user_token(username, password)
        if not _verify_user_password(username, password, config):
            raise HTTPException(status_code=401, detail="Invalid username or password")
        if db_verified is True and not _fallback_access_token(config):
            save_fallback_token(password, username)

        response.set_cookie(
            key=config.webui_auth_cookie_name,
            value=_session_cookie_value(config),
            max_age=60 * 60 * 24 * 7,
            httponly=True,
            samesite="strict",
            secure=False,
            path="/",
        )
        return {"ok": True}

    @router.post("/api/auth/logout")
    async def auth_logout(response: Response) -> dict[str, Any]:
        _delete_auth_cookie(response, config)
        return {"ok": True}

    @router.post("/api/auth/password")
    async def auth_change_password(
        payload: PasswordChangePayload,
        response: Response,
    ) -> dict[str, Any]:
        username = payload.username.strip() or "admin"
        new_username = payload.new_username.strip()
        if not new_username:
            raise HTTPException(status_code=400, detail="Username is required")
        if not _verify_user_password(username, payload.current_password, config):
            raise HTTPException(status_code=401, detail="Invalid current password")

        database_saved = database.replace_auth_user(new_username, payload.new_password)
        save_fallback_token(payload.new_password, new_username)
        _delete_auth_cookie(response, config)
        return {"ok": True, "database_saved": database_saved}

    @router.get("/api/settings/database", dependencies=auth_dependencies)
    async def get_database_settings() -> dict[str, Any]:
        return database.status()

    @router.put("/api/settings/database", dependencies=auth_dependencies)
    async def update_database_settings(payload: DatabaseSettingsPayload) -> dict[str, Any]:
        old_config = database.config
        next_config = save_database_config(
            DatabaseConfig(enabled=payload.enabled, url=payload.url.strip())
        )
        database.initialize()
        if payload.enabled and not database.available:
            save_database_config(old_config)
            database.initialize()
            raise HTTPException(
                status_code=400,
                detail=f"Database connection failed: {database.error}",
            )
        return database.status()

    @router.post("/api/settings/database/test", dependencies=auth_dependencies)
    async def test_database_settings(payload: DatabaseSettingsPayload) -> dict[str, Any]:
        if not payload.enabled:
            return {"ok": True, "error": None}
        return test_database_url(payload.url.strip())

    @router.get("/api/runtime", dependencies=auth_dependencies)
    async def runtime() -> dict[str, Any]:
        driver = nonebot.get_driver()
        process = psutil.Process()
        return {
            "driver": getattr(driver, "type", driver.__class__.__name__),
            "nonebot_version": _package_version("nonebot2"),
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "cwd": str(Path.cwd()),
            "webui_path": config.webui_path,
            "pid": process.pid,
            "process_started_at": process.create_time(),
            "system_started_at": psutil.boot_time(),
        }

    @router.get("/api/runtime/metrics", dependencies=auth_dependencies)
    async def runtime_metrics() -> dict[str, Any]:
        process = psutil.Process()
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage(str(Path.cwd().anchor or Path.cwd()))
        process_memory = process.memory_info()

        return {
            "timestamp": time.time(),
            "cpu": {
                "percent": psutil.cpu_percent(interval=None),
                "logical_count": psutil.cpu_count(logical=True),
                "physical_count": psutil.cpu_count(logical=False),
            },
            "memory": {
                "total": memory.total,
                "available": memory.available,
                "used": memory.used,
                "percent": memory.percent,
            },
            "disk": {
                "total": disk.total,
                "used": disk.used,
                "free": disk.free,
                "percent": disk.percent,
            },
            "process": {
                "pid": process.pid,
                "cpu_percent": process.cpu_percent(interval=None),
                "memory_rss": process_memory.rss,
                "memory_vms": process_memory.vms,
                "memory_percent": process.memory_percent(),
                "threads": process.num_threads(),
                "started_at": process.create_time(),
            },
            "system": {
                "started_at": psutil.boot_time(),
            },
        }

    @router.post("/api/runtime/restart", dependencies=auth_dependencies)
    async def restart_runtime() -> dict[str, Any]:
        asyncio.create_task(_restart_process())
        return {"ok": True, "message": "NoneBot is restarting"}

    @router.get("/api/config", dependencies=auth_dependencies)
    async def runtime_config() -> dict[str, Any]:
        driver_config = nonebot.get_driver().config
        return {
            "items": _flatten_config(_dump_model(driver_config)),
            "masked_keywords": SECRET_KEYWORDS,
        }

    @router.get("/api/plugins", dependencies=auth_dependencies)
    async def plugins() -> dict[str, Any]:
        loaded_plugins = sorted(nonebot.get_loaded_plugins(), key=lambda item: item.name)
        available_names = sorted(nonebot.get_available_plugin_names())
        managed_plugins = load_settings().plugins.items
        return {
            "loaded": await _serialize_plugins_with_update_check(loaded_plugins, managed_plugins),
            "available": available_names,
            "managed": [_dump_managed_plugin(item) for item in managed_plugins],
        }

    @router.get("/api/settings/plugins/{module_name}", dependencies=auth_dependencies)
    async def get_plugin_config(module_name: str) -> dict[str, Any]:
        settings = load_settings()
        managed = _find_managed_plugin(settings.plugins, module_name)
        plugin = _find_loaded_plugin(module_name)
        schema = _plugin_config_schema(plugin) if plugin is not None else None
        return {
            "module_name": module_name,
            "enabled": managed.enabled if managed else True,
            "values": managed.config if managed else {},
            "schema": schema,
            "restart_required": True,
        }

    @router.put("/api/settings/plugins/{module_name}", dependencies=auth_dependencies)
    async def update_plugin_config(
        module_name: str,
        payload: PluginConfigPayload,
    ) -> dict[str, Any]:
        settings = load_settings()
        managed = _find_managed_plugin(settings.plugins, module_name)
        if managed is None:
            managed = ManagedPluginSettings(module_name=module_name)
            settings.plugins.items.append(managed)
        managed.enabled = payload.enabled
        managed.config = payload.values
        save_settings(settings)
        _apply_plugin_config_values(payload.values)
        return {
            "module_name": module_name,
            "enabled": managed.enabled,
            "values": managed.config,
            "schema": _plugin_config_schema(_find_loaded_plugin(module_name)),
            "restart_required": True,
        }

    @router.patch("/api/settings/plugins/{module_name}/enabled", dependencies=auth_dependencies)
    async def update_plugin_enabled(
        module_name: str,
        payload: PluginEnabledPayload,
    ) -> dict[str, Any]:
        if module_name in PROTECTED_PLUGIN_MODULES and not payload.enabled:
            raise HTTPException(status_code=400, detail="Core plugin cannot be disabled")
        settings = load_settings()
        managed = _find_managed_plugin(settings.plugins, module_name)
        if managed is None:
            managed = ManagedPluginSettings(
                module_name=module_name,
                package_name=payload.package_name,
            )
            settings.plugins.items.append(managed)
        elif payload.package_name and not managed.package_name:
            managed.package_name = payload.package_name
        managed.enabled = payload.enabled
        save_settings(settings)

        runtime = _set_plugin_runtime_enabled(module_name, payload.enabled)
        return {
            "module_name": module_name,
            "enabled": managed.enabled,
            "runtime": runtime,
            "restart_required": not runtime["applied"],
        }

    @router.get("/api/bots", dependencies=auth_dependencies)
    async def bots() -> dict[str, Any]:
        connected_bots = nonebot.get_bots()
        items = []
        for bot_id, bot in sorted(connected_bots.items(), key=lambda item: str(item[0])):
            items.append(await _serialize_bot(bot_id, bot))

        return {
            "items": items,
            "total": len(connected_bots),
        }

    @router.get("/api/settings/bots", dependencies=auth_dependencies)
    async def get_bot_settings() -> dict[str, Any]:
        return _dump_bot_settings(load_settings().bots)

    @router.put("/api/settings/bots", dependencies=auth_dependencies)
    async def update_bot_settings(payload: BotSettingsPayload) -> dict[str, Any]:
        settings = load_settings()
        settings.bots = BotConfig(
            connections=[
                BotConnectionSettings(
                    id=item.id.strip(),
                    name=item.name.strip(),
                    enabled=item.enabled,
                    adapter=item.adapter.strip(),
                    connection_mode=item.connection_mode.strip(),
                    host=item.host.strip(),
                    port=item.port,
                    path=_normalize_path(item.path),
                    access_token=item.access_token,
                    self_id=item.self_id.strip(),
                    note=item.note,
                )
                for item in payload.connections
                if item.id.strip() and item.name.strip()
            ]
        )
        save_settings(settings)
        return _dump_bot_settings(settings.bots)

    @router.post("/api/settings/bots/adapters/{adapter}/install", dependencies=auth_dependencies)
    async def install_bot_adapter(adapter: str) -> dict[str, Any]:
        async def runner(emit):
            result = await install_adapter_package_stream(adapter, emit)
            if not result["command"]:
                raise HTTPException(status_code=404, detail=result["output"])
            return result

        task = tasks.create(f"安装适配器 {adapter}", runner)
        return {"task_id": task.id, "task": dump_task(task)}

    @router.get("/api/tasks/{task_id}", dependencies=auth_dependencies)
    async def get_task(task_id: str) -> dict[str, Any]:
        task = tasks.get(task_id)
        if task is None:
            raise HTTPException(status_code=404, detail="Task not found")
        return dump_task(task)

    @router.websocket("/api/ws/tasks/{task_id}")
    async def task_websocket(websocket: WebSocket, task_id: str) -> None:
        if _auth_enabled(config) and not _is_authenticated(
            websocket.cookies.get(config.webui_auth_cookie_name),
            config,
        ):
            await websocket.close(code=1008)
            return
        await websocket.accept()
        queue = await tasks.subscribe(task_id)
        if queue is None:
            await websocket.send_json({"type": "error", "message": "Task not found"})
            await websocket.close()
            return

        try:
            while True:
                message = await queue.get()
                await websocket.send_json(message)
                if message["type"] == "done":
                    await websocket.close()
                    return
        except WebSocketDisconnect:
            return
        finally:
            tasks.unsubscribe(task_id, queue)

    @router.get("/api/files", dependencies=auth_dependencies)
    async def list_files(path: str = "") -> dict[str, Any]:
        target = _resolve_workspace_path(path)
        if not target.exists():
            raise HTTPException(status_code=404, detail="Path not found")
        if not target.is_dir():
            raise HTTPException(status_code=400, detail="Path is not a directory")

        entries = []
        for child in sorted(target.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower())):
            stat = child.stat()
            entries.append(
                {
                    "name": child.name,
                    "path": _relative_workspace_path(child),
                    "type": "directory" if child.is_dir() else "file",
                    "size": stat.st_size,
                    "modified_at": stat.st_mtime,
                }
            )
        return {
            "root": str(Path.cwd()),
            "path": _relative_workspace_path(target),
            "parent": _relative_workspace_path(target.parent) if target != Path.cwd().resolve() else None,
            "entries": entries,
        }

    @router.get("/api/files/content", dependencies=auth_dependencies)
    async def read_file_content(path: str) -> dict[str, Any]:
        target = _resolve_workspace_path(path)
        if not target.exists() or not target.is_file():
            raise HTTPException(status_code=404, detail="File not found")
        data = target.read_bytes()
        if b"\x00" in data[:4096]:
            raise HTTPException(status_code=400, detail="Binary file cannot be edited")
        text_value = data.decode("utf-8", errors="replace")
        return {
            "path": _relative_workspace_path(target),
            "name": target.name,
            "content": text_value,
            "language": _detect_file_language(target, text_value),
            "eol": "CRLF" if "\r\n" in text_value else "LF",
            "size": len(data),
            "modified_at": target.stat().st_mtime,
        }

    @router.put("/api/files/content", dependencies=auth_dependencies)
    async def save_file_content(path: str, payload: FileSavePayload) -> dict[str, Any]:
        target = _resolve_workspace_path(path)
        if not target.exists() or not target.is_file():
            raise HTTPException(status_code=404, detail="File not found")
        content = payload.content.replace("\r\n", "\n").replace("\r", "\n")
        if payload.eol.upper() == "CRLF":
            content = content.replace("\n", "\r\n")
        target.write_text(content, encoding="utf-8", newline="")
        return {
            "ok": True,
            "path": _relative_workspace_path(target),
            "size": target.stat().st_size,
            "modified_at": target.stat().st_mtime,
        }

    @router.get("/api/database/tables", dependencies=auth_dependencies)
    async def database_tables() -> dict[str, Any]:
        engine = _require_database_engine()
        inspector = sa_inspect(engine)
        tables = sorted(inspector.get_table_names())
        return {"tables": [{"name": table} for table in tables]}

    @router.get("/api/database/tables/{table_name}/schema", dependencies=auth_dependencies)
    async def database_table_schema(table_name: str) -> dict[str, Any]:
        engine = _require_database_engine()
        inspector = sa_inspect(engine)
        _ensure_table_exists(inspector, table_name)
        return {
            "table": table_name,
            "columns": [
                {
                    "name": column["name"],
                    "type": str(column["type"]),
                    "nullable": column.get("nullable", True),
                    "default": str(column.get("default")) if column.get("default") is not None else None,
                    "primary_key": bool(column.get("primary_key")),
                }
                for column in inspector.get_columns(table_name)
            ],
        }

    @router.get("/api/database/tables/{table_name}/rows", dependencies=auth_dependencies)
    async def database_table_rows(
        table_name: str,
        page: int = 1,
        page_size: int = 20,
        sort: str = "",
        order: str = "asc",
    ) -> dict[str, Any]:
        engine = _require_database_engine()
        inspector = sa_inspect(engine)
        _ensure_table_exists(inspector, table_name)
        columns = [column["name"] for column in inspector.get_columns(table_name)]
        page = max(1, page)
        page_size = max(1, min(page_size, 200))
        offset = (page - 1) * page_size
        preparer = engine.dialect.identifier_preparer
        table_sql = preparer.quote(table_name)
        order_sql = ""
        if sort:
            if sort not in columns:
                raise HTTPException(status_code=400, detail="Invalid sort column")
            direction = "DESC" if order.lower() == "desc" else "ASC"
            order_sql = f" ORDER BY {preparer.quote(sort)} {direction}"
        with engine.begin() as connection:
            total = connection.execute(text(f"SELECT COUNT(*) FROM {table_sql}")).scalar_one()
            result = connection.execute(
                text(f"SELECT * FROM {table_sql}{order_sql} LIMIT :limit OFFSET :offset"),
                {"limit": page_size, "offset": offset},
            )
            rows = [_serialize_row(row._mapping) for row in result]
        return {
            "table": table_name,
            "columns": columns,
            "rows": rows,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": max(1, (int(total) + page_size - 1) // page_size),
            "sort": sort,
            "order": order,
        }

    @router.post("/api/database/sql", dependencies=auth_dependencies)
    async def execute_database_sql(payload: SqlExecutePayload) -> dict[str, Any]:
        engine = _require_database_engine()
        sql = payload.sql.strip()
        if not sql:
            raise HTTPException(status_code=400, detail="SQL is required")
        if ";" in sql.rstrip(";"):
            raise HTTPException(status_code=400, detail="Only one SQL statement is allowed")
        started = time.perf_counter()
        with engine.begin() as connection:
            result = connection.execute(text(sql))
            if result.returns_rows:
                rows = [_serialize_row(row._mapping) for row in result.fetchmany(200)]
                columns = list(result.keys())
                rowcount = len(rows)
            else:
                rows = []
                columns = []
                rowcount = result.rowcount
        return {
            "columns": columns,
            "rows": rows,
            "rowcount": rowcount,
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 2),
        }

    @router.get("/api/logs", dependencies=auth_dependencies)
    async def logs_snapshot() -> dict[str, Any]:
        return {"items": list(_log_buffer)}

    @router.websocket("/api/ws/logs")
    async def logs_websocket(websocket: WebSocket) -> None:
        if _auth_enabled(config) and not _is_authenticated(
            websocket.cookies.get(config.webui_auth_cookie_name),
            config,
        ):
            await websocket.close(code=1008)
            return
        await websocket.accept()
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=200)
        _log_subscribers.add(queue)
        try:
            await websocket.send_json({"type": "snapshot", "items": list(_log_buffer)})
            while True:
                item = await queue.get()
                await websocket.send_json({"type": "log", "item": item})
        except WebSocketDisconnect:
            return
        finally:
            _log_subscribers.discard(queue)

    @router.post("/api/chat/message", dependencies=auth_dependencies)
    async def chat_message(payload: ChatMessageRequest) -> dict[str, Any]:
        try:
            replies = await dispatch_webui_message(
                payload.message,
                user_id=payload.user_id,
                session_id=payload.session_id,
            )
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to dispatch WebUI message: {exc}",
            ) from exc

        return {
            "ok": True,
            "message": payload.message,
            "replies": replies,
        }

    @router.get("/api/settings/ai", dependencies=auth_dependencies)
    async def get_ai_settings() -> dict[str, Any]:
        settings = load_settings()
        return dump_ai_settings_for_ui(settings.ai, config)

    @router.put("/api/settings/ai", dependencies=auth_dependencies)
    async def update_ai_settings(payload: AISettingsPayload) -> dict[str, Any]:
        settings = load_settings()
        providers: list[AISettings] = []
        for provider in payload.providers:
            api_key = provider.api_key.strip() if provider.api_key else None
            models = [
                AIModel(id=model.id.strip(), enabled=model.enabled)
                for model in provider.models
                if model.id.strip()
            ]
            default_model = provider.default_model.strip()
            if not default_model:
                default_model = next((model.id for model in models if model.enabled), "")

            providers.append(
                AISettings(
                    id=provider.id.strip(),
                    name=provider.name.strip(),
                    enabled=provider.enabled,
                    api_key=api_key,
                    base_url=provider.base_url.strip().rstrip("/"),
                    models=models,
                    default_model=default_model,
                    timeout=provider.timeout,
                )
            )

        settings.ai = AIConfig(
            enabled=payload.enabled,
            default_provider_id=payload.default_provider_id,
            system_prompt=payload.system_prompt,
            history_limit=payload.history_limit,
            providers=providers,
        )
        save_settings(settings)
        return dump_ai_settings_for_ui(settings.ai, config)

    @router.post("/api/settings/ai/models", dependencies=auth_dependencies)
    async def list_ai_models(payload: AIProviderProbePayload) -> dict[str, Any]:
        started = time.perf_counter()
        data = await _fetch_ai_models(payload)
        return {
            "models": data,
            "latency_ms": round((time.perf_counter() - started) * 1000),
        }

    @router.post("/api/settings/ai/test", dependencies=auth_dependencies)
    async def test_ai_provider(payload: AIProviderProbePayload) -> dict[str, Any]:
        started = time.perf_counter()
        models = await _fetch_ai_models(payload)
        return {
            "ok": True,
            "latency_ms": round((time.perf_counter() - started) * 1000),
            "models_count": len(models),
        }

    @router.post("/api/settings/ai/test-model", dependencies=auth_dependencies)
    async def test_ai_model(payload: AIModelProbePayload) -> dict[str, Any]:
        started = time.perf_counter()
        await _test_ai_model(payload)
        return {
            "ok": True,
            "model": payload.model,
            "latency_ms": round((time.perf_counter() - started) * 1000),
        }

    @router.get("/api/store/plugins", dependencies=auth_dependencies)
    async def store_plugins(
        q: str = "",
        type: str = "",
        page: int = 1,
        page_size: int = 24,
        sort: str = "name",
        refresh: bool = False,
    ) -> dict[str, Any]:
        page = max(1, page)
        page_size = max(1, min(page_size, 100))
        try:
            cache = await _get_store_registry(config, refresh=refresh)
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to fetch NoneBot plugin registry: {exc}",
            ) from exc

        runtime_context = _store_runtime_context()
        items = [
            _enrich_store_item(item, runtime_context)
            for item in _extract_store_items(cache["payload"])
        ]
        if q:
            needle = q.casefold()
            items = [
                item
                for item in items
                if needle in " ".join(str(value) for value in item.values()).casefold()
            ]
        types = sorted(
            {str(item.get("type")) for item in items if item.get("type")},
            key=str.casefold,
        )
        if type:
            items = [item for item in items if item.get("type") == type]

        items = _sort_store_items(items, sort)
        update_targets = [
            {
                "module_name": item.get("module_name"),
                "package_name": item.get("package_name"),
                "name": item.get("name"),
            }
            for item in items
            if item.get("update_available")
            and item.get("module_name")
            and item.get("package_name")
            and item.get("module_name") not in PROTECTED_PLUGIN_MODULES
            and item.get("package_name") not in PROTECTED_PLUGIN_PACKAGES
        ]
        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size

        return {
            "items": items[start:end],
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": max(1, (total + page_size - 1) // page_size),
            "sort": sort,
            "types": types,
            "update_targets": update_targets,
            "source": config.webui_store_url,
            "cached": cache.get("cached", True),
            "cache_updated_at": cache["updated_at"],
            "cache_source": cache.get("cache_source") or "database",
        }

    @router.post("/api/store/plugins/install", dependencies=auth_dependencies)
    async def install_store_plugin(payload: StorePluginInstallPayload) -> dict[str, Any]:
        package_name = payload.package_name.strip()
        module_name = payload.module_name.strip()

        async def runner(emit):
            result = await install_plugin_package_stream(package_name, emit)
            if result["ok"]:
                settings = load_settings()
                managed = _find_managed_plugin(settings.plugins, module_name)
                if managed is None:
                    settings.plugins.items.append(
                        ManagedPluginSettings(
                            module_name=module_name,
                            package_name=package_name,
                            enabled=True,
                        )
                    )
                else:
                    managed.package_name = package_name
                    managed.enabled = True
                save_settings(settings)
                await emit("插件已加入 WebUI 管理列表，重启 NoneBot 后会尝试加载。")
            return result | {"module_name": module_name, "name": payload.name}

        task = tasks.create(f"安装插件 {payload.name or module_name}", runner)
        return {"task_id": task.id, "task": dump_task(task)}

    @router.post("/api/store/plugins/uninstall", dependencies=auth_dependencies)
    async def uninstall_store_plugin(payload: StorePluginUninstallPayload) -> dict[str, Any]:
        package_name = payload.package_name.strip()
        module_name = payload.module_name.strip()
        if module_name in PROTECTED_PLUGIN_MODULES or package_name in PROTECTED_PLUGIN_PACKAGES:
            raise HTTPException(status_code=400, detail="Core plugin cannot be uninstalled")

        async def runner(emit):
            result = await uninstall_plugin_package_stream(package_name, emit)
            if result["ok"]:
                settings = load_settings()
                settings.plugins.items = [
                    item for item in settings.plugins.items if item.module_name != module_name
                ]
                save_settings(settings)
                await emit("插件已从 WebUI 管理列表移除。重启 NoneBot 后卸载状态完全生效。")
            return result | {"module_name": module_name, "name": payload.name}

        task = tasks.create(f"卸载插件 {payload.name or module_name}", runner)
        return {"task_id": task.id, "task": dump_task(task)}

    @router.post("/api/plugins/update", dependencies=auth_dependencies)
    async def update_plugin(payload: PluginUpdatePayload) -> dict[str, Any]:
        package_name = payload.package_name.strip()
        module_name = payload.module_name.strip()

        async def runner(emit):
            result = await update_plugin_package_stream(package_name, emit)
            return result | {"module_name": module_name, "name": payload.name}

        task = tasks.create(f"更新插件 {payload.name or module_name}", runner)
        return {"task_id": task.id, "task": dump_task(task)}

    @router.post("/api/plugins/update-all", dependencies=auth_dependencies)
    async def update_all_plugins(payload: PluginsUpdatePayload) -> dict[str, Any]:
        targets = [
            item
            for item in payload.plugins
            if item.package_name.strip()
            and item.module_name not in PROTECTED_PLUGIN_MODULES
            and item.package_name not in PROTECTED_PLUGIN_PACKAGES
        ]

        async def runner(emit):
            results = []
            for item in targets:
                await emit(f"开始更新 {item.name or item.module_name}")
                result = await update_plugin_package_stream(item.package_name.strip(), emit)
                results.append(result | {"module_name": item.module_name, "name": item.name})
            ok = all(result.get("ok") for result in results) if results else True
            return {"ok": ok, "updated": len(results), "results": results}

        task = tasks.create("更新全部插件", runner)
        return {"task_id": task.id, "task": dump_task(task)}

    @router.get("/{path:path}", include_in_schema=False)
    async def spa_fallback(path: str) -> HTMLResponse:
        if path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not Found")
        return HTMLResponse(_html_with_favicon(static_dir / "index.html", config))

    return router


async def _fetch_ai_models(payload: AIProviderProbePayload) -> list[str]:
    headers = {"Content-Type": "application/json"}
    if payload.api_key:
        headers["Authorization"] = f"Bearer {payload.api_key}"

    try:
        async with httpx.AsyncClient(timeout=payload.timeout) as client:
            response = await client.get(
                f"{payload.base_url.strip().rstrip('/')}/models",
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Failed to fetch model list: {exc}",
        ) from exc

    raw_models = data.get("data", []) if isinstance(data, dict) else []
    models = [
        str(item.get("id"))
        for item in raw_models
        if isinstance(item, dict) and item.get("id")
    ]
    return sorted(models)


async def _test_ai_model(payload: AIModelProbePayload) -> None:
    headers = {"Content-Type": "application/json"}
    if payload.api_key:
        headers["Authorization"] = f"Bearer {payload.api_key}"

    body = {
        "model": payload.model,
        "messages": [
            {"role": "user", "content": "ping"},
        ],
        "max_tokens": 1,
    }

    try:
        async with httpx.AsyncClient(timeout=payload.timeout) as client:
            response = await client.post(
                f"{payload.base_url.strip().rstrip('/')}/chat/completions",
                headers=headers,
                json=body,
            )
            response.raise_for_status()
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Failed to test model {payload.model}: {exc}",
        ) from exc


def _package_version(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def _dump_model(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if hasattr(value, "dict"):
        return value.dict()
    if isinstance(value, dict):
        return value
    return {
        key: item
        for key, item in vars(value).items()
        if not key.startswith("_")
    }


def _flatten_config(data: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for key in sorted(data):
        value = data[key]
        masked = _is_secret_key(key)
        items.append(
            {
                "key": key,
                "value": "***" if masked and value not in (None, "") else value,
                "type": type(value).__name__,
                "masked": masked,
            }
        )
    return items


def _is_secret_key(key: str) -> bool:
    lowered = key.casefold()
    return any(keyword in lowered for keyword in SECRET_KEYWORDS)


async def _serialize_plugins_with_update_check(
    plugins: list[Any],
    managed_plugins: list[ManagedPluginSettings],
) -> list[dict[str, Any]]:
    items = [_serialize_plugin(plugin) for plugin in plugins]
    async with httpx.AsyncClient(timeout=3) as client:
        latest_versions = await asyncio.gather(
            *[
                _fetch_latest_package_version(client, item["package_name"])
                for item in items
            ],
            return_exceptions=True,
        )

    for item, latest in zip(items, latest_versions):
        latest_version = latest if isinstance(latest, str) else None
        current_version = item.get("version")
        item["latest_version"] = latest_version
        item["update_available"] = _is_newer_version(latest_version, current_version)
    return items


def _serialize_plugin(plugin: Any) -> dict[str, Any]:
    metadata = getattr(plugin, "metadata", None)
    managed = _find_managed_plugin(load_settings().plugins, plugin.module_name)
    package_name = _plugin_package_name(plugin.module_name, managed.package_name if managed else "")
    return {
        "name": plugin.name,
        "module_name": plugin.module_name,
        "package_name": package_name,
        "metadata": _serialize_metadata(metadata),
        "matcher_count": len(getattr(plugin, "matcher", set()) or set()),
        "sub_plugins": sorted(child.name for child in getattr(plugin, "sub_plugins", set())),
        "managed": _dump_managed_plugin(managed) if managed else None,
        "runtime_disabled": plugin.module_name in _disabled_plugin_matchers,
        "version": _plugin_version(plugin.module_name, package_name),
    }


def _find_loaded_plugin(module_name: str) -> Any | None:
    for plugin in nonebot.get_loaded_plugins():
        if plugin.module_name == module_name or plugin.name == module_name:
            return plugin
    return None


def _find_managed_plugin(
    settings: PluginConfig,
    module_name: str,
) -> ManagedPluginSettings | None:
    for item in settings.items:
        if item.module_name == module_name:
            return item
    return None


def _dump_managed_plugin(plugin: ManagedPluginSettings) -> dict[str, Any]:
    return {
        "module_name": plugin.module_name,
        "package_name": plugin.package_name,
        "enabled": plugin.enabled,
        "configured": bool(plugin.config),
    }


def _plugin_version(module_name: str, package_name: str = "") -> str | None:
    candidates = [
        package_name,
        module_name,
        module_name.replace("_", "-"),
        module_name.replace("-", "_"),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        current = package_version(candidate)
        if current:
            return current
    return None


def _plugin_package_name(module_name: str, package_name: str = "") -> str:
    return package_name or module_name.replace("_", "-")


async def _fetch_latest_package_version(client: httpx.AsyncClient, package_name: str) -> str | None:
    if not package_name:
        return None
    try:
        response = await client.get(f"https://pypi.org/pypi/{package_name}/json")
        response.raise_for_status()
        data = response.json()
        version_value = data.get("info", {}).get("version")
        return str(version_value) if version_value else None
    except Exception:
        return None


def _is_newer_version(latest: str | None, current: Any) -> bool:
    if not latest or not current:
        return False
    try:
        from packaging.version import Version

        return Version(str(latest)) > Version(str(current))
    except Exception:
        return str(latest) != str(current)


def _set_plugin_runtime_enabled(module_name: str, enabled: bool) -> dict[str, Any]:
    plugin = _find_loaded_plugin(module_name)
    if enabled:
        restored = _restore_plugin_matchers(module_name)
        if plugin is None:
            try:
                loaded = nonebot.load_plugin(module_name)
            except Exception as exc:
                return {
                    "applied": False,
                    "mode": "load",
                    "message": f"插件加载失败：{exc}",
                }
            return {
                "applied": bool(loaded),
                "mode": "load",
                "message": "插件已尝试加载" if loaded else "插件加载未返回有效对象",
            }
        return {
            "applied": True,
            "mode": "matchers",
            "message": f"已恢复 {restored} 个响应器",
        }

    if plugin is None:
        return {
            "applied": True,
            "mode": "not-loaded",
            "message": "插件当前未加载，下次启动会保持关闭",
        }
    disabled = _disable_plugin_matchers(module_name, plugin)
    return {
        "applied": disabled > 0,
        "mode": "matchers",
        "message": f"已临时禁用 {disabled} 个响应器"
        if disabled
        else "未找到可热禁用的响应器，可能需要重启生效",
    }


def _disable_plugin_matchers(module_name: str, plugin: Any) -> int:
    from nonebot.matcher import matchers

    plugin_matchers = set(getattr(plugin, "matcher", set()) or set())
    if not plugin_matchers:
        return 0
    stored = _disabled_plugin_matchers.setdefault(module_name, [])
    disabled = 0
    for priority, matcher_list in list(matchers.items()):
        remaining = []
        for matcher in matcher_list:
            if matcher in plugin_matchers:
                if not any(item[1] is matcher for item in stored):
                    stored.append((priority, matcher))
                disabled += 1
            else:
                remaining.append(matcher)
        matchers[priority] = remaining
    return disabled


def _restore_plugin_matchers(module_name: str) -> int:
    from nonebot.matcher import matchers

    stored = _disabled_plugin_matchers.pop(module_name, [])
    restored = 0
    for priority, matcher in stored:
        matcher_list = matchers.setdefault(priority, [])
        if matcher not in matcher_list:
            matcher_list.append(matcher)
            restored += 1
    return restored


def _plugin_config_schema(plugin: Any | None) -> dict[str, Any] | None:
    if plugin is None:
        return None
    metadata = getattr(plugin, "metadata", None)
    config_model = getattr(metadata, "config", None) if metadata is not None else None
    return _model_schema(config_model)


def _apply_plugin_config_values(values: dict[str, Any]) -> None:
    driver_config = nonebot.get_driver().config
    for key, value in values.items():
        if key:
            setattr(driver_config, key, value)


async def _serialize_bot(bot_id: str, bot: Any) -> dict[str, Any]:
    adapter = getattr(bot, "adapter", None)
    adapter_name = None
    if adapter is not None:
        get_name = getattr(adapter, "get_name", None)
        adapter_name = get_name() if callable(get_name) else adapter.__class__.__name__

    self_id = _safe_text(getattr(bot, "self_id", bot_id))
    payload = {
        "id": _safe_text(bot_id),
        "self_id": self_id,
        "type": _safe_optional_text(getattr(bot, "type", None)),
        "platform": _safe_optional_text(getattr(bot, "platform", None)),
        "adapter": _safe_optional_text(adapter_name),
        "protocol": _infer_bot_protocol(adapter_name, self_id),
        "nickname": None,
        "avatar_url": _qq_avatar_url(self_id),
        "friend_count": None,
        "group_count": None,
        "detail_error": None,
    }
    payload.update(await _get_bot_details(bot, self_id))
    return payload


def _infer_bot_protocol(adapter_name: Any, self_id: str) -> str | None:
    adapter = _safe_optional_text(adapter_name)
    lowered = (adapter or "").casefold()
    if "onebot" in lowered and self_id.isdigit():
        return "QQ"
    if "telegram" in lowered:
        return "Telegram"
    if "discord" in lowered:
        return "Discord"
    if "console" in lowered:
        return "Console"
    return None


async def _get_bot_details(bot: Any, self_id: str) -> dict[str, Any]:
    details: dict[str, Any] = {}

    login_info = await _call_bot_api(bot, "get_login_info")
    if isinstance(login_info, dict):
        details["nickname"] = _safe_optional_text(login_info.get("nickname"))
        user_id = login_info.get("user_id")
        if user_id is not None:
            details["avatar_url"] = _qq_avatar_url(_safe_text(user_id))

    friends = await _call_bot_api(bot, "get_friend_list")
    if isinstance(friends, list):
        details["friend_count"] = len(friends)

    groups = await _call_bot_api(bot, "get_group_list")
    if isinstance(groups, list):
        details["group_count"] = len(groups)

    return details


async def _call_bot_api(bot: Any, api: str) -> Any:
    call_api = getattr(bot, "call_api", None)
    if not callable(call_api):
        return None

    try:
        return await asyncio.wait_for(call_api(api), timeout=3)
    except Exception:
        return None


def _qq_avatar_url(self_id: str) -> str | None:
    if not self_id.isdigit():
        return None
    return f"https://q1.qlogo.cn/g?b=qq&nk={self_id}&s=640"


def _safe_text(value: Any) -> str:
    return str(value)


def _safe_optional_text(value: Any) -> str | None:
    if value is None or callable(value):
        return None
    return str(value)


def _dump_bot_settings(settings: BotConfig) -> dict[str, Any]:
    return {
        "connections": [
            {
                "id": item.id,
                "name": item.name,
                "enabled": item.enabled,
                "adapter": item.adapter,
                "connection_mode": item.connection_mode,
                "host": item.host,
                "port": item.port,
                "path": item.path,
                "access_token": item.access_token,
                "self_id": item.self_id,
                "note": item.note,
                "runtime": get_connection_runtime(item),
            }
            for item in settings.connections
        ],
        "adapters": get_all_adapter_statuses(),
    }


def _normalize_path(path: str) -> str:
    value = path.strip() or "/"
    return value if value.startswith("/") else f"/{value}"


def _html_with_favicon(path: Path, config: Config) -> str:
    html = path.read_text(encoding="utf-8")
    if 'rel="icon"' in html:
        return html
    favicon = f'{config.webui_path.rstrip("/") or "/webui"}/api/static/logo.png'
    return html.replace(
        "<title>NoneBot WebUI</title>",
        f'<link rel="icon" type="image/png" href="{favicon}" />\n    <title>NoneBot WebUI</title>',
    )


def _serialize_metadata(metadata: Any) -> dict[str, Any] | None:
    if metadata is None:
        return None

    config_model = getattr(metadata, "config", None)
    config_schema, config_schema_error = _model_schema_result(config_model)
    return {
        "name": getattr(metadata, "name", None),
        "description": getattr(metadata, "description", None),
        "usage": getattr(metadata, "usage", None),
        "type": getattr(metadata, "type", None),
        "homepage": getattr(metadata, "homepage", None),
        "supported_adapters": sorted(getattr(metadata, "supported_adapters", []) or []),
        "config_schema": config_schema,
        "config_schema_error": config_schema_error,
        "extra": getattr(metadata, "extra", {}) or {},
    }


def _model_schema(model: Any) -> dict[str, Any] | None:
    schema, _ = _model_schema_result(model)
    return schema


def _model_schema_result(model: Any) -> tuple[dict[str, Any] | None, str | None]:
    if model is None:
        return None, None
    try:
        if hasattr(model, "model_json_schema"):
            return model.model_json_schema(), None
        if hasattr(model, "schema"):
            return model.schema(), None
    except Exception as exc:
        return None, str(exc)
    return None, None


def _extract_store_items(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        raw_items = payload.get("plugins") or payload.get("items") or payload.get("data") or []
    elif isinstance(payload, list):
        raw_items = payload
    else:
        raw_items = []

    items: list[dict[str, Any]] = []
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue

        homepage = raw.get("homepage") or raw.get("link")
        module_name = raw.get("module_name") or raw.get("module") or raw.get("name")
        package_name = (
            raw.get("project_name")
            or raw.get("project_link")
            or raw.get("package")
            or module_name
        )
        plugin_name = raw.get("name") or raw.get("module_name") or package_name

        items.append(
            {
                "name": plugin_name,
                "module_name": module_name,
                "package_name": package_name,
                "description": raw.get("desc") or raw.get("description") or "",
                "homepage": homepage,
                "author": raw.get("author") or "",
                "tags": _normalize_tags(raw.get("tags") or []),
                "type": raw.get("type"),
                "version": raw.get("version"),
                "valid": raw.get("valid"),
                "is_official": bool(raw.get("is_official", False)),
                "install_command": f"nb plugin install {package_name}",
            }
        )

    return items


async def _store_cache_worker(config: Config) -> None:
    await asyncio.sleep(2)
    while True:
        try:
            await _refresh_store_registry(config)
        except Exception:
            pass
        await asyncio.sleep(max(60, config.webui_store_refresh_interval))


async def _get_store_registry(config: Config, refresh: bool = False) -> dict[str, Any]:
    cache = _read_store_registry_cache(config) or _read_store_registry_memory_cache(config)
    now = time.time()
    ttl = max(60, config.webui_store_cache_ttl)
    stale = cache is None or now - float(cache["updated_at"] or 0) > ttl
    if refresh or cache is None:
        return await _refresh_store_registry(config)
    if stale and not _store_cache_lock.locked():
        asyncio.create_task(_refresh_store_registry(config))
    return cache


async def _refresh_store_registry(config: Config) -> dict[str, Any]:
    global _store_registry_memory_cache
    async with _store_cache_lock:
        payload = await _fetch_store_registry(config)
        cache = {
            "url": config.webui_store_url,
            "payload": payload,
            "updated_at": time.time(),
            "cached": True,
            "cache_source": "remote",
        }
        saved = database.write_json(STORE_CACHE_KEY, cache)
        _store_registry_memory_cache = cache | {
            "cache_source": "remote" if saved else "memory",
        }
        return cache


async def _fetch_store_registry(config: Config) -> Any:
    async with httpx.AsyncClient(timeout=config.webui_store_timeout) as client:
        response = await client.get(config.webui_store_url)
        response.raise_for_status()
        return response.json()


def _read_store_registry_cache(config: Config) -> dict[str, Any] | None:
    cache = database.read_json(STORE_CACHE_KEY)
    if not cache or cache.get("url") != config.webui_store_url:
        return None
    payload = cache.get("payload")
    if payload is None:
        return None
    return {
        "url": config.webui_store_url,
        "payload": payload,
        "updated_at": float(cache.get("updated_at") or 0),
        "cached": True,
        "cache_source": "database",
    }


def _read_store_registry_memory_cache(config: Config) -> dict[str, Any] | None:
    cache = _store_registry_memory_cache
    if not cache or cache.get("url") != config.webui_store_url:
        return None
    payload = cache.get("payload")
    if payload is None:
        return None
    return {
        "url": config.webui_store_url,
        "payload": payload,
        "updated_at": float(cache.get("updated_at") or 0),
        "cached": True,
        "cache_source": "memory",
    }


def _store_runtime_context() -> dict[str, Any]:
    loaded_plugins = nonebot.get_loaded_plugins()
    loaded_modules = {
        plugin.module_name
        for plugin in loaded_plugins
        if getattr(plugin, "module_name", None)
    }
    loaded_names = {
        plugin.name for plugin in loaded_plugins if getattr(plugin, "name", None)
    }
    managed_modules = {
        plugin.module_name
        for plugin in load_settings().plugins.items
        if plugin.module_name
    }
    return {
        "loaded_modules": loaded_modules,
        "loaded_names": loaded_names,
        "managed_modules": managed_modules,
        "package_versions": _installed_package_versions(),
    }


def _installed_package_versions() -> dict[str, str]:
    versions: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata.get("Name")
        if not name:
            continue
        normalized = _normalize_package_name(name)
        versions[normalized] = distribution.version
    return versions


def _normalize_package_name(name: str) -> str:
    return name.replace("_", "-").lower()


def _package_version_from_context(package_name: str, context: dict[str, Any]) -> str | None:
    versions = context["package_versions"]
    return versions.get(_normalize_package_name(package_name))


def _enrich_store_item(item: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    package_name = str(item.get("package_name") or "")
    module_name = str(item.get("module_name") or "")
    loaded = module_name in context["loaded_modules"] or module_name in context["loaded_names"]
    managed = module_name in context["managed_modules"]
    current_version = _package_version_from_context(package_name, context)
    return {
        **item,
        "installed": bool(current_version or loaded or managed),
        "loaded": loaded,
        "managed": managed,
        "current_version": current_version,
        "latest_version": item.get("version"),
        "update_available": _is_newer_version(item.get("version"), current_version),
    }


def _sort_store_items(items: list[dict[str, Any]], sort: str) -> list[dict[str, Any]]:
    reverse = sort.startswith("-")
    key = sort[1:] if reverse else sort
    if key == "installed":
        return sorted(
            items,
            key=lambda item: (not bool(item.get("installed")), str(item.get("name") or "").casefold()),
            reverse=reverse,
        )
    if key == "version":
        return sorted(
            items,
            key=lambda item: _version_sort_key(item.get("version")),
            reverse=reverse,
        )
    if key == "package":
        return sorted(
            items,
            key=lambda item: str(item.get("package_name") or "").casefold(),
            reverse=reverse,
        )
    return sorted(
        items,
        key=lambda item: str(item.get("name") or item.get("module_name") or "").casefold(),
        reverse=reverse,
    )


def _version_sort_key(version: Any) -> tuple[int, Any]:
    if not version:
        return (0, "")
    try:
        from packaging.version import Version

        return (1, Version(str(version)))
    except Exception:
        return (0, str(version))


def _normalize_tags(tags: Any) -> list[str]:
    normalized: list[str] = []
    if not isinstance(tags, list):
        return normalized

    for tag in tags:
        if isinstance(tag, str):
            normalized.append(tag)
        elif isinstance(tag, dict) and tag.get("label"):
            normalized.append(str(tag["label"]))

    return normalized


def _workspace_root() -> Path:
    return Path.cwd().resolve()


def _resolve_workspace_path(path: str) -> Path:
    root = _workspace_root()
    target = (root / path).resolve() if path else root
    if target != root and root not in target.parents:
        raise HTTPException(status_code=400, detail="Path is outside workspace")
    return target


def _relative_workspace_path(path: Path) -> str:
    root = _workspace_root()
    resolved = path.resolve()
    if resolved == root:
        return ""
    return resolved.relative_to(root).as_posix()


def _detect_file_language(path: Path, content: str) -> str:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return "python"
    if suffix == ".json":
        return "json"
    if suffix in {".yaml", ".yml"}:
        return "yaml"
    stripped = content.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        return "json"
    if ":" in content and any(line.strip().endswith(":") for line in content.splitlines()[:20]):
        return "yaml"
    return "text"


def _require_database_engine():
    if not database.available or database.engine is None:
        raise HTTPException(status_code=503, detail=database.error or "Database is unavailable")
    return database.engine


def _ensure_table_exists(inspector: Any, table_name: str) -> None:
    if table_name not in inspector.get_table_names():
        raise HTTPException(status_code=404, detail="Table not found")


def _serialize_row(row: Any) -> dict[str, Any]:
    serialized: dict[str, Any] = {}
    for key, value in dict(row).items():
        if isinstance(value, bytes):
            serialized[key] = value.hex()
        elif isinstance(value, (str, int, float, bool)) or value is None:
            serialized[key] = value
        else:
            serialized[key] = str(value)
    return serialized


def _ensure_log_capture() -> None:
    global _log_handler_id
    if _log_handler_id is not None:
        return
    _log_handler_id = logger.add(_capture_log_message, level="DEBUG", format="{message}")


def _capture_log_message(message: Any) -> None:
    record = message.record
    item = {
        "time": record["time"].timestamp(),
        "level": record["level"].name.lower(),
        "message": record["message"],
        "name": record["name"],
    }
    _log_buffer.append(item)
    stale: list[asyncio.Queue[dict[str, Any]]] = []
    for queue in _log_subscribers:
        try:
            queue.put_nowait(item)
        except asyncio.QueueFull:
            stale.append(queue)
    for queue in stale:
        _log_subscribers.discard(queue)


def _is_api_path(path: str, config: Config) -> bool:
    base_path = config.webui_path.rstrip("/") or "/webui"
    return path.startswith(f"{base_path}/api/")


def _is_auth_path(path: str) -> bool:
    return "/api/auth/" in path


def _is_authenticated(cookie: str | None, config: Config) -> bool:
    if not _auth_enabled(config):
        return True
    if not cookie:
        return False
    return hmac.compare_digest(cookie, _session_cookie_value(config))


def _delete_auth_cookie(response: Response, config: Config) -> None:
    response.delete_cookie(
        key=config.webui_auth_cookie_name,
        path="/",
        secure=False,
        httponly=True,
        samesite="strict",
    )


def _verify_user_password(username: str, password: str, config: Config) -> bool:
    if load_fallback_token():
        return _verify_fallback_password(username, password, config)
    db_verified = database.verify_user_token(username, password)
    return db_verified is True or _verify_fallback_password(username, password, config)


def _verify_fallback_password(username: str, password: str, config: Config) -> bool:
    fallback = load_fallback_auth()
    fallback_username = fallback["username"]
    fallback_token = fallback["token"]
    if not fallback_token:
        fallback_token = _access_token(config)
    return (
        bool(fallback_token)
        and hmac.compare_digest(username, fallback_username)
        and hmac.compare_digest(password, fallback_token)
    )


def _session_cookie_value(config: Config) -> str:
    token = _fallback_access_token(config)
    return hmac.new(
        token.encode("utf-8"),
        b"nonebot-plugin-webui-session",
        hashlib.sha256,
    ).hexdigest()


def _auth_enabled(config: Config) -> bool:
    return bool(_fallback_access_token(config)) or database.get_auth_username() is not None


def _auth_username(config: Config) -> str:
    fallback = load_fallback_auth()
    if fallback["token"]:
        return fallback["username"] or "admin"
    return database.get_auth_username() or fallback["username"] or "admin"


def _fallback_access_token(config: Config) -> str:
    saved_token = load_fallback_token()
    if saved_token:
        return saved_token
    return _access_token(config)


def _access_token(config: Config) -> str:
    if config.webui_access_token is None:
        return ""
    return str(config.webui_access_token)


async def _restart_process() -> None:
    await asyncio.sleep(0.5)
    os.execv(sys.executable, [sys.executable, *sys.argv])
