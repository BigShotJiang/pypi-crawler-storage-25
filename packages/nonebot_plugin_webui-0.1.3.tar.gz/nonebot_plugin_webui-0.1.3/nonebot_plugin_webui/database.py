from __future__ import annotations

import hashlib
import json
import secrets
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from sqlalchemy import MetaData, Table, create_engine, delete, insert, select, update
from sqlalchemy import Boolean, Column, Float, Integer, String, Text
from sqlalchemy.engine import Engine

SETTINGS_DIR = Path.cwd() / ".nonebot-plugin-webui"
DATABASE_CONFIG_FILE = SETTINGS_DIR / "database.json"
FALLBACK_AUTH_FILE = SETTINGS_DIR / "fallback-auth.json"


def default_database_url() -> str:
    database_path = (SETTINGS_DIR / "webui.sqlite3").resolve()
    return f"sqlite:///{database_path.as_posix()}"


class DatabaseConfig(BaseModel):
    enabled: bool = True
    url: str = Field(default_factory=default_database_url)


metadata = MetaData()

kv_table = Table(
    "webui_kv",
    metadata,
    Column("key", String(128), primary_key=True),
    Column("value", Text, nullable=False),
    Column("updated_at", Float, nullable=False),
)

auth_users_table = Table(
    "webui_auth_users",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("username", String(64), unique=True, nullable=False),
    Column("token_hash", String(128), nullable=False),
    Column("enabled", Boolean, nullable=False, default=True),
    Column("created_at", Float, nullable=False),
    Column("updated_at", Float, nullable=False),
)


class DatabaseManager:
    def __init__(self) -> None:
        self.config = load_database_config()
        self.engine: Engine | None = None
        self.available = False
        self.error: str | None = None

    def initialize(self) -> None:
        self.config = load_database_config()
        if not self.config.enabled:
            self.engine = None
            self.available = False
            self.error = "Database is disabled"
            return

        try:
            SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
            engine = create_engine(self.config.url, future=True)
            metadata.create_all(engine)
        except Exception as exc:
            self.engine = None
            self.available = False
            self.error = str(exc)
            return

        self.engine = engine
        self.available = True
        self.error = None

    def read_json(self, key: str) -> dict[str, Any] | None:
        if not self.available or self.engine is None:
            return None

        try:
            with self.engine.begin() as connection:
                row = connection.execute(
                    select(kv_table.c.value).where(kv_table.c.key == key)
                ).first()
            if row is None:
                return None
            return json.loads(row[0])
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return None

    def write_json(self, key: str, value: dict[str, Any]) -> bool:
        if not self.available or self.engine is None:
            return False

        payload = json.dumps(value, ensure_ascii=False)
        now = time.time()
        try:
            with self.engine.begin() as connection:
                existing = connection.execute(
                    select(kv_table.c.key).where(kv_table.c.key == key)
                ).first()
                if existing:
                    connection.execute(
                        update(kv_table)
                        .where(kv_table.c.key == key)
                        .values(value=payload, updated_at=now)
                    )
                else:
                    connection.execute(
                        insert(kv_table).values(key=key, value=payload, updated_at=now)
                    )
            return True
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return False

    def upsert_admin_token(self, token: str) -> bool:
        return self.replace_auth_user("admin", token)

    def replace_auth_user(self, username: str, token: str) -> bool:
        username = username.strip()
        if not username or not token or not self.available or self.engine is None:
            return False

        now = time.time()
        token_hash = hash_token(token)
        try:
            with self.engine.begin() as connection:
                connection.execute(delete(auth_users_table))
                connection.execute(
                    insert(auth_users_table).values(
                        username=username,
                        token_hash=token_hash,
                        enabled=True,
                        created_at=now,
                        updated_at=now,
                    )
                )
            return True
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return False

    def verify_admin_token(self, token: str) -> bool | None:
        return self.verify_user_token("admin", token)

    def verify_user_token(self, username: str, token: str) -> bool | None:
        username = username.strip()
        if not self.available or self.engine is None:
            return None

        try:
            with self.engine.begin() as connection:
                row = connection.execute(
                    select(auth_users_table.c.token_hash, auth_users_table.c.enabled).where(
                        auth_users_table.c.username == username
                    )
                ).first()
            if row is None or not row[1]:
                return None
            return secrets.compare_digest(hash_token(token), row[0])
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return None

    def get_auth_username(self) -> str | None:
        if not self.available or self.engine is None:
            return None

        try:
            with self.engine.begin() as connection:
                row = connection.execute(
                    select(auth_users_table.c.username)
                    .where(auth_users_table.c.enabled == True)  # noqa: E712
                    .order_by(auth_users_table.c.id.asc())
                ).first()
            return str(row[0]) if row else None
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return None

    def clear_auth_users(self) -> bool:
        if not self.available or self.engine is None:
            return False
        try:
            with self.engine.begin() as connection:
                connection.execute(delete(auth_users_table))
            return True
        except Exception as exc:
            self.available = False
            self.error = str(exc)
            return False

    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.config.enabled,
            "url": self.config.url,
            "available": self.available,
            "error": self.error,
            "fallback_login": bool(load_fallback_token()),
        }


def load_database_config() -> DatabaseConfig:
    if not DATABASE_CONFIG_FILE.exists():
        return DatabaseConfig()

    try:
        return DatabaseConfig(**json.loads(DATABASE_CONFIG_FILE.read_text("utf-8")))
    except Exception:
        return DatabaseConfig()


def save_database_config(config: DatabaseConfig) -> DatabaseConfig:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    DATABASE_CONFIG_FILE.write_text(
        json.dumps(config.model_dump(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return config


def test_database_url(url: str) -> dict[str, Any]:
    try:
        engine = create_engine(url, future=True)
        with engine.begin() as connection:
            connection.execute(select(1))
        engine.dispose()
        return {"ok": True, "error": None}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def load_fallback_token() -> str:
    return load_fallback_auth()["token"]


def load_fallback_auth() -> dict[str, str]:
    if FALLBACK_AUTH_FILE.exists():
        try:
            data = json.loads(FALLBACK_AUTH_FILE.read_text("utf-8"))
            token = data.get("token")
            username = data.get("username") or "admin"
            return {
                "username": str(username),
                "token": str(token) if token else "",
            }
        except Exception:
            return {"username": "admin", "token": ""}
    return {"username": "admin", "token": ""}


def save_fallback_token(token: str, username: str = "admin") -> None:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    FALLBACK_AUTH_FILE.write_text(
        json.dumps(
            {"username": username.strip() or "admin", "token": token},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


database = DatabaseManager()
