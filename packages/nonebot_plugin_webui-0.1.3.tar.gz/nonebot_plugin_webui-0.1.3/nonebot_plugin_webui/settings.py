from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field

from .config import Config
from .database import database

SETTINGS_DIR = Path.cwd() / ".nonebot-plugin-webui"
SETTINGS_FILE = SETTINGS_DIR / "settings.json"
MASKED_SECRET = "********"


class AIModel(BaseModel):
    id: str
    enabled: bool = True


class AISettings(BaseModel):
    id: str = "openai"
    name: str = "OpenAI"
    enabled: bool = True
    api_key: Optional[str] = None
    base_url: str = "https://api.openai.com/v1"
    models: list[AIModel] = Field(default_factory=lambda: [AIModel(id="gpt-4o-mini")])
    default_model: str = "gpt-4o-mini"
    timeout: float = Field(default=60, ge=1, le=300)


class AIConfig(BaseModel):
    enabled: bool = True
    default_provider_id: str = "openai"
    system_prompt: str = "你是 NoneBot WebUI 中的 AI 助手，回答要简洁、准确。"
    history_limit: int = Field(default=12, ge=0, le=100)
    providers: list[AISettings] = Field(default_factory=lambda: [AISettings()])


class BotConnectionSettings(BaseModel):
    id: str
    name: str
    enabled: bool = True
    adapter: str = "onebot-v11"
    connection_mode: str = "reverse-ws"
    host: str = "127.0.0.1"
    port: int = Field(default=8080, ge=1, le=65535)
    path: str = "/onebot/v11/ws"
    access_token: str = ""
    self_id: str = ""
    note: str = ""


class BotConfig(BaseModel):
    connections: list[BotConnectionSettings] = Field(default_factory=list)


class ManagedPluginSettings(BaseModel):
    module_name: str
    package_name: str = ""
    enabled: bool = True
    config: dict[str, Any] = Field(default_factory=dict)


class PluginConfig(BaseModel):
    items: list[ManagedPluginSettings] = Field(default_factory=list)


class Settings(BaseModel):
    ai: AIConfig = Field(default_factory=AIConfig)
    bots: BotConfig = Field(default_factory=BotConfig)
    plugins: PluginConfig = Field(default_factory=PluginConfig)


def load_settings() -> Settings:
    data = database.read_json("settings")
    if data is not None:
        return _normalize_settings(data)

    if not SETTINGS_FILE.exists():
        return Settings()
    try:
        return _normalize_settings(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        return Settings()


def save_settings(settings: Settings) -> Settings:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    data = _model_dump(settings)
    database.write_json("settings", data)
    SETTINGS_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return settings


def get_effective_ai_config(config: Config) -> AIConfig:
    saved = load_settings().ai
    providers = saved.providers or [AISettings()]
    if config.webui_ai_api_key and not any(provider.api_key for provider in providers):
        providers = [
            AISettings(
                id="env-openai",
                name="OpenAI (.env)",
                enabled=True,
                api_key=config.webui_ai_api_key,
                base_url=config.webui_ai_base_url,
                models=[config.webui_ai_model],
                default_model=config.webui_ai_model,
                timeout=config.webui_ai_timeout,
            ),
            *providers,
        ]

    return AIConfig(
        enabled=saved.enabled,
        default_provider_id=saved.default_provider_id,
        system_prompt=saved.system_prompt or config.webui_ai_system_prompt,
        history_limit=saved.history_limit,
        providers=providers,
    )


def get_default_ai_provider(config: Config) -> tuple[AIConfig, AISettings] | tuple[AIConfig, None]:
    ai = get_effective_ai_config(config)
    providers = [provider for provider in ai.providers if provider.enabled]
    provider = next(
        (item for item in providers if item.id == ai.default_provider_id),
        providers[0] if providers else None,
    )
    return ai, provider


def dump_ai_settings_for_ui(settings: AIConfig, config: Config) -> dict[str, Any]:
    effective = get_effective_ai_config(config)
    return {
        "enabled": settings.enabled,
        "default_provider_id": settings.default_provider_id,
        "system_prompt": settings.system_prompt,
        "history_limit": settings.history_limit,
        "providers": [
            {
                "id": provider.id,
                "name": provider.name,
                "enabled": provider.enabled,
                "api_key": provider.api_key or "",
                "has_api_key": bool(provider.api_key),
                "base_url": provider.base_url,
                "models": [_model_dump(model) for model in provider.models],
                "default_model": provider.default_model,
                "timeout": provider.timeout,
            }
            for provider in effective.providers
        ],
    }


def _model_dump(model: BaseModel) -> dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump(mode="json")
    return model.dict()


def _normalize_settings(data: dict[str, Any]) -> Settings:
    ai = data.get("ai")
    if isinstance(ai, dict) and "providers" not in ai:
        provider = AISettings(
            id="openai",
            name="OpenAI",
            enabled=bool(ai.get("enabled", True)),
            api_key=ai.get("api_key"),
            base_url=ai.get("base_url") or "https://api.openai.com/v1",
            models=[AIModel(id=ai.get("model") or "gpt-4o-mini")],
            default_model=ai.get("model") or "gpt-4o-mini",
            timeout=ai.get("timeout") or 60,
        )
        data["ai"] = {
            "enabled": bool(ai.get("enabled", True)),
            "default_provider_id": provider.id,
            "system_prompt": ai.get("system_prompt")
            or "你是 NoneBot WebUI 中的 AI 助手，回答要简洁、准确。",
            "history_limit": ai.get("history_limit") or 12,
            "providers": [_model_dump(provider)],
        }
    return Settings(**data)


def migrate_settings_to_database() -> None:
    if not database.available:
        return
    if database.read_json("settings") is not None:
        return
    if SETTINGS_FILE.exists():
        try:
            settings = _normalize_settings(
                json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            )
        except Exception:
            settings = Settings()
    else:
        settings = Settings()
    database.write_json("settings", _model_dump(settings))
