from __future__ import annotations

import time
from typing import Any, Iterable

import nonebot
from nonebot.adapters import Adapter, Bot, Event, Message, MessageSegment
from nonebot.message import handle_event


class WebUIMessageSegment(MessageSegment["WebUIMessage"]):
    @classmethod
    def text(cls, text: str) -> "WebUIMessageSegment":
        return cls(type="text", data={"text": text})

    @classmethod
    def get_message_class(cls) -> type["WebUIMessage"]:
        return WebUIMessage

    def is_text(self) -> bool:
        return self.type == "text"

    def __str__(self) -> str:
        if self.type == "text":
            return str(self.data.get("text", ""))
        return str(self.data)


class WebUIMessage(Message[WebUIMessageSegment]):
    @classmethod
    def get_segment_class(cls) -> type[WebUIMessageSegment]:
        return WebUIMessageSegment

    @staticmethod
    def _construct(msg: str) -> Iterable[WebUIMessageSegment]:
        yield WebUIMessageSegment.text(msg)


class WebUIMessageEvent(Event):
    time: int
    self_id: str
    user_id: str
    session_id: str
    message_id: str
    message: WebUIMessage
    raw_message: str
    to_me: bool = True

    def get_type(self) -> str:
        return "message"

    def get_event_name(self) -> str:
        return "webui.message"

    def get_event_description(self) -> str:
        return self.raw_message

    def get_user_id(self) -> str:
        return self.user_id

    def get_session_id(self) -> str:
        return self.session_id

    def get_message(self) -> WebUIMessage:
        return self.message

    def is_tome(self) -> bool:
        return self.to_me


class WebUIAdapter(Adapter):
    @classmethod
    def get_name(cls) -> str:
        return "WebUI"

    async def _call_api(self, bot: Bot, api: str, **data: Any) -> Any:
        if api in {"send_msg", "send_message"}:
            message = data.get("message", "")
            return await bot.send(data.get("event"), message)
        raise NotImplementedError(f"WebUI virtual adapter does not support API {api!r}")


class WebUIBot(Bot):
    def __init__(self) -> None:
        super().__init__(WebUIAdapter(nonebot.get_driver()), "webui")
        self.replies: list[str] = []

    async def send(
        self,
        event: Event,
        message: str | Message | MessageSegment,
        **kwargs: Any,
    ) -> dict[str, Any]:
        text = str(message)
        self.replies.append(text)
        return {
            "message_id": f"webui-reply-{len(self.replies)}",
            "message": text,
        }


async def dispatch_webui_message(
    message: str,
    *,
    user_id: str = "webui-user",
    session_id: str = "webui-session",
) -> list[str]:
    bot = WebUIBot()
    event = WebUIMessageEvent(
        time=int(time.time()),
        self_id=bot.self_id,
        user_id=user_id,
        session_id=session_id,
        message_id=f"webui-{time.time_ns()}",
        message=WebUIMessage(message),
        raw_message=message,
        to_me=True,
    )
    await handle_event(bot, event)
    return bot.replies
