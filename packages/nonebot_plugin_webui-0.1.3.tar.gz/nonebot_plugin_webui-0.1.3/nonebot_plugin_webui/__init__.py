from pathlib import Path

import nonebot
from nonebot import get_driver, logger, require
from nonebot.plugin import PluginMetadata

from . import ai as _ai  # noqa: F401
from .bot_adapters import register_configured_adapters
from .config import Config, get_config
from .database import database, load_fallback_auth, save_fallback_token
from .routes import create_router
from .settings import load_settings, migrate_settings_to_database

require("nonebot_plugin_orm")

__plugin_meta__ = PluginMetadata(
    name="NoneBot WebUI",
    description="管理 NoneBot 运行配置、插件信息和插件商店的 WebUI。",
    usage="使用 FastAPI 驱动启动 NoneBot 后访问 /webui。",
    type="application",
    config=Config,
    supported_adapters=None,
)

_driver = get_driver()
_config = get_config()


def _initialize_storage() -> None:
    database.initialize()
    fallback_auth = load_fallback_auth()
    initial_token = str(_config.webui_access_token) if _config.webui_access_token is not None else ""

    if database.available:
        migrate_settings_to_database()
        if fallback_auth["token"]:
            database.replace_auth_user(fallback_auth["username"], fallback_auth["token"])
        elif initial_token and database.get_auth_username() is None:
            database.replace_auth_user("admin", initial_token)
            save_fallback_token(initial_token)
        logger.info("NoneBot WebUI database ready: {}", database.config.url)
    else:
        if initial_token and not fallback_auth["token"]:
            save_fallback_token(initial_token)
        logger.warning("NoneBot WebUI database unavailable: {}", database.error)


def _register_bot_adapters() -> None:
    settings = load_settings()
    register_configured_adapters(_driver, settings.bots.connections)


def _load_managed_plugins() -> None:
    settings = load_settings()
    for plugin in settings.plugins.items:
        if not plugin.enabled or plugin.module_name == "nonebot_plugin_webui":
            continue
        for key, value in plugin.config.items():
            if key:
                setattr(_driver.config, key, value)
        try:
            nonebot.load_plugin(plugin.module_name)
            logger.info("WebUI managed plugin loaded: {}", plugin.module_name)
        except Exception as exc:
            logger.warning(
                "Failed to load WebUI managed plugin {}: {}",
                plugin.module_name,
                exc,
            )


def _mount_webui() -> None:
    server_app = getattr(_driver, "server_app", None)
    if server_app is None:
        logger.warning("nonebot-plugin-webui requires the FastAPI driver to mount WebUI")
        return

    try:
        from fastapi.staticfiles import StaticFiles
    except ImportError:
        logger.warning("FastAPI is not installed, nonebot-plugin-webui cannot mount")
        return

    static_dir = Path(__file__).parent / "static"
    base_path = _config.webui_path.rstrip("/") or "/webui"

    server_app.include_router(create_router(_config), prefix=base_path)
    server_app.mount(
        f"{base_path}/assets",
        StaticFiles(directory=static_dir / "assets"),
        name="nonebot_webui_assets",
    )
    logger.info("NoneBot WebUI mounted at {}", base_path)


_initialize_storage()
_load_managed_plugins()
_register_bot_adapters()
_mount_webui()
