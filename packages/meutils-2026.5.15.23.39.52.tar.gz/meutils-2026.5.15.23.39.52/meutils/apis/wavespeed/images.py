#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : images
# @Time         : 2026/3/20 14:23
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.pipe import *
from meutils.llm.clients import AsyncOpenAI
from meutils.schemas.image_types import ImageRequest, ImagesResponse
from meutils.schemas.openai_types import CompletionRequest


async def generate(request: ImageRequest, api_key: Optional[str] = None) -> ImagesResponse:
    client = AsyncOpenAI(base_url="https://llm.wavespeed.ai/v1", api_key=api_key or os.getenv("WAVESPEED_API_KEY"))

    request = CompletionRequest(model=request.model, messages=[{"role": "user", "content": request.prompt}])
    client.chat.completions.create()



"""

 curl https://llm.wavespeed.ai/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer " \
  -d '{
    "model": "google/gemini-3.1-flash-image-preview",
    "messages": [{"role": "user", "content": "a cat"}]
  }'



"""