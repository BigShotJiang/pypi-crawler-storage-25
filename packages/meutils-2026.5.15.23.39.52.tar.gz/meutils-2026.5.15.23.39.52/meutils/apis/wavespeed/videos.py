#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : videos
# @Time         : 2026/3/20 14:23
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :
import os

from meutils.pipe import *
from meutils.schemas.video_types import SoraVideoRequest, Video
from meutils.llm.clients import AsyncOpenAI

BASE_URL = "https://api.wavespeed.ai/api/v3"


class Tasks(object):

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None):
        self.client = AsyncOpenAI(base_url=BASE_URL, api_key=api_key or os.getenv("WAVESPEED_API_KEY"))

    async def create(self, request: SoraVideoRequest):
        path = "/openai/sora-2/characters"
        payload = {
            "name": request.name,
            "video": request.video
        }

        # openai/sora-2/image-to-video?webhook=https://your.app/endpoint

        if "characters" in request.model:
            path = "/openai/sora-2/characters"
            payload = {
                "name": request.name,
                "video": request.video
            }

        elif request.input_reference:
            path = "/openai/sora-2/image-to-video"
        """
        
{
    "id": "abc123-def456-...",
    "status": "completed",
    "outputs": ["https://cdn.wavespeed.ai/outputs/xxx.png"]
}
        """

        logger.debug(payload)

        response = await self.client.post(path=path, body=payload, cast_to=object)
        logger.debug(response)
        """
        {
        'code': 200, 
        'message': 'success', 
        'data': {'id': '0a3049ade0ac4a1f9b4a1bda3dcfb51b', 'model': 'openai/sora-2/characters', 'outputs': [], 
        'urls': {'get': 'https://api.wavespeed.ai/api/v3/predictions/0a3049ade0ac4a1f9b4a1bda3dcfb51b/result'}, 
        'has_nsfw_contents': [], 'status': 'created', 'created_at': '2026-03-23T02:42:27.808Z', 'code': 0, 'error': '', 'executionTime': 0, 'timings': {'inference': 0}}
        }
        """
        data = response.get("data") or {}

        if task_id := data.get("id"):
            video = Video(
                id=task_id,
                status=data.get("status"),
            )
            return video

        logger.error(f"Failed to create task: {response}")
        video = Video(
            status=data.get("status"),
            error=response
        )
        return video

    async def get(self, task_id: str):
        path = f"/predictions/{task_id}/result"
        response = await self.client.get(path=path, cast_to=object)
        logger.debug(response)
        data = response.get("data") or {}
        if data.get("status") in {"completed", "created", "processing"}:
            video = Video(
                id=task_id,
                status=data.get("status"),
            )
            return video


        video = Video(
            status=data.get("status"),
            error=response
        )
        return video

if __name__ == '__main__':
    data = {
        "name": "Joe",
        "video": "https://static.wavespeed.ai/examples/c5826986b1304cb3bd6eb3ea269dd2bd/1773739446924793785_InY8irAK.mp4"
    }
    request = SoraVideoRequest(**data)

    t = Tasks()

    # arun(t.create(request))

    task_id = '70df47effd644002a719aa985124b548'
    arun(t.get(task_id))
