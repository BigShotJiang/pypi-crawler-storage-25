#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : openai_videos
# @Time         : 2026/1/27 19:21
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :

from meutils.pipe import *

from fal_client import AsyncClient
from meutils.schemas.video_types import SoraVideoRequest, Video


class Tasks(object):

    def __init__(self, base_url: Optional[str] = None, api_key: str = None):
        self.api_key = api_key
        self.client = AsyncClient(key=api_key)

    async def create(self, request: SoraVideoRequest):
        application = request.model

        payload = {
            "prompt": request.prompt
        }

        if request.model.startswith(("fal-ai/sora",)):
            payload["duration"] = min(int(request.seconds or 4), 12)

            if request.resolution:
                payload['resolution'] = request.resolution

            if request.aspect_ratio:
                payload['aspect_ratio'] = request.aspect_ratio

            if images := request.input_reference:
                payload['image_url'] = images[0]

        elif request.model.startswith(("fal-ai/veo",)):
            if request.aspect_ratio not in {"9:16", "16:9", "auto"}:
                request.aspect_ratio = "9:16"

            if int(request.seconds or 1) not in {4, 6, 8}:  # 1080p => 8
                request.seconds = 4

            if request.generate_audio is False:
                payload['generate_audio'] = False

            _ = {
                "aspect_ratio": request.aspect_ratio,
                "duration": f"{request.seconds}s",
                "resolution": request.resolution,
                "generate_audio": True,
                "safety_tolerance": "6",

                "auto_fix": True
            }
            payload.update(_)
            if request.input_reference:
                if len(request.input_reference) > 1:
                    application = "fal-ai/veo3.1/reference-to-video"
                    payload['image_urls'] = request.input_reference
                else:
                    application = "fal-ai/veo3.1/image-to-video"
                    payload['image_url'] = request.input_reference[0]

            if request.first_frame_image:
                application = "fal-ai/veo3.1/lite/first-last-frame-to-video"
                payload['first_frame_url'] = request.first_frame_image
                payload['last_frame_url'] = request.last_frame_image

        logger.debug(bjson(payload))

        response = await self.client.submit(
            application=application,
            arguments=payload
        )
        logger.debug(response.__class__.__name__)  # Queued, InProgress, COMPLETED
        logger.debug(response.__dict__)  # Queued, InProgress, COMPLETED

        task_id = f"{application.replace('/', '_').replace('lite', 'llll')}__{response.request_id}"

        return Video(id=task_id, status=response.__dict__)

    async def get(self, task_id: str, api_key: Optional[str] = None):
        if api_key:
            self.client = AsyncClient(key=api_key)

        application, fal_task_id = task_id.split('__')
        application = application.replace('_', '/').replace('_', '/').replace('llll', 'lite')

        response = await self.client.status(application, fal_task_id, with_logs=True)

        status = response.__class__.__name__

        logger.debug(f"status => {status}")  # Queued, InProgress, COMPLETED
        logger.debug(response.__dict__)  # Queued, InProgress, COMPLETED

        error = None
        if metrics := response.__dict__.get("metrics"):  # {'inference_time': 17.29231595993042}
            logger.debug(metrics)
            try:
                response = await self.client.result(application, fal_task_id)

            except Exception as e:

                status = "failed"
                error = str(e)

                logger.error(str(e))
                """
                [{'loc': ['body', 'aspect_ratio'], 'msg': "unexpected value; permitted: '9:16', '16:9'", 'type': 'value_error.const', 'ctx': {'given': 'auto', 'permitted': ['9:16', '16:9']}}]
                """

        logger.debug(response)

        if hasattr(response, "video") and (url := (response.get("video") or {}).get("url")):
            return Video(id=task_id, status=status, video_url=url, progress=100)

        return Video(id=task_id, status=status, error=error)


if __name__ == '__main__':
    # {
    #     "prompt": "A woman looks into the camera, breathes in, then exclaims energetically, \"have you guys checked out Veo3.1 First-Last-Frame-to-Video on Fal? It's incredible!\"",
    #     "aspect_ratio": "auto",
    #     "duration": "8s",
    #     "resolution": "720p",
    #     "generate_audio": true,
    #     "safety_tolerance": "4",
    #     "first_frame_url": "https://storage.googleapis.com/falserverless/example_inputs/veo31-flf2v-input-1.jpeg",
    #     "last_frame_url": "https://storage.googleapis.com/falserverless/example_inputs/veo31-flf2v-input-2.jpeg"
    # }
    model = "fal-ai/veo3.1/lite_720p"
    # model = "fal-ai/veo3.1/lite"

    request = SoraVideoRequest(model=model, duration=4, prompt='a dog')

    api_key = os.getenv("FAL_KEY")
    t = Tasks(api_key=api_key)

    # arun(t.create(request))
    #
    # task_id = "fal-ai_veo3.1_llll__019d6cac-9461-7730-895b-6c73f4d4b3d9"
    # task_id = "fal-ai_veo3.1_llll__019d6cb1-9f95-7930-8749-8e5f5faf5cc6"
    task_id = "fal-ai_veo3.1_image-to-video__019da99a-9764-7050-80f6-6ca99be22c59"

    # 观察 是否完成  progress=0
    # Video(id='fal-ai_veo3.1_llll__019d6cfc-0fa0-7e80-af50-b4db1cd9cef9', completed_at=None, created_at=1776677104,
    #       error=None, expires_at=None, model='', object='video', progress=0, prompt=None, remixed_from_video_id=None,
    #       seconds=None, size=None, status='completed', video_url=None, metadata=None, polling_url=None, usage=None)

    # task_id = "fal-ai_veo3.1_image-to-video__019daa26-0def-7931-9db9-d3922d1f9188"

    api_key = "2d1f089b-647f-4442-8ef1-8859b4f38a39:60abd46dbd42e2112e4cf57b776d451d"

    task_id = "fal-ai_veo3.1_image-to-video__019e2ad9-cd35-7a00-b8f0-12d6b3af07f2"
    arun(t.get(task_id, api_key))
