#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : videos
# @Time         : 2025/6/11 15:13
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :
import json

from meutils.pipe import *
from meutils.io.files_utils import to_url, to_base64
from meutils.decorators.retry import retrying
from meutils.apis.oneapi.utils import polling_keys

from meutils.llm.clients import AsyncClient
from meutils.schemas.openai_types import CompletionRequest
from meutils.schemas.video_types import SoraVideoRequest, SeedRequest, Video
from meutils.schemas.image_types import ImageRequest

from meutils.db.redis_db import redis_aclient
from meutils.llm.check_utils import check_token_for_volc
# from meutils.llm.check_utils import check_token_for_volc_with_cache as check_token_for_volc


from fastapi import APIRouter, File, UploadFile, Query, Form, Depends, Request, HTTPException, status, BackgroundTasks

# Please activate

# await polling_keys('volc')

from openai import AsyncClient, APIStatusError

BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"

"""
curl -X POST https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ark-976ea817-2007-435c-9697-add33c9037d1-0059c" \
  -d '{
    "model": "doubao-seedance-2-0-fast-260128",
    "content": [
         {
            "type": "text",
            "text": "全程使用视频1的第一视角构图，全程使用音频1作为背景音乐。第一人称视角果茶宣传广告，seedance牌「苹苹安安」苹果果茶限定款；首帧为图片1，你的手摘下一颗带晨露的阿克苏红苹果，轻脆的苹果碰撞声；2-4 秒：快速切镜，你的手将苹果块投入雪克杯，加入冰块与茶底，用力摇晃，冰块碰撞声与摇晃声卡点轻快鼓点，背景音：「鲜切现摇」；4-6 秒：第一人称成品特写，分层果茶倒入透明杯，你的手轻挤奶盖在顶部铺展，在杯身贴上粉红包标，镜头拉近看奶盖与果茶的分层纹理；6-8 秒：第一人称手持举杯，你将图片2中的果茶举到镜头前（模拟递到观众面前的视角），杯身标签清晰可见，背景音「来一口鲜爽」，尾帧定格为图片2。背景声音统一为女生音色。"
        },
        {
            "type": "image_url",
            "image_url": {
                "url": "https://ark-project.tos-cn-beijing.volces.com/doc_image/r2v_tea_pic1.jpg"
            },
            "role": "reference_image"
        },
        {
            "type": "image_url",
            "image_url": {
                "url": "https://ark-project.tos-cn-beijing.volces.com/doc_image/r2v_tea_pic2.jpg"
            },
            "role": "reference_image"
        },
        {
          "type": "video_url",
          "video_url": {
              "url": "https://ark-project.tos-cn-beijing.volces.com/doc_video/r2v_tea_video1.mp4"
          },
          "role": "reference_video"
        },
        {
          "type": "audio_url",
          "audio_url": {
              "url": "https://ark-project.tos-cn-beijing.volces.com/doc_audio/r2v_tea_audio1.mp3"
          },
          "role": "reference_audio"
        }
    ],
    "generate_audio":true,
    "ratio": "16:9",
    "duration": 11,
    "watermark": false
}'
"""


class Tasks(object):

    def __init__(self, base_url: Optional[str] = None, api_key: str = None):
        base_url = base_url or BASE_URL

        self.client = AsyncClient(api_key=api_key, base_url=base_url)

    async def _create(self, request: SeedRequest):  # todo   todo 存储数据
        _ = json.dumps(request.content).replace('--', '')
        request.content = json.loads(_)

        payload = request.model_dump(exclude_none=True)

        logger.debug(bjson(payload))

        response = await self.client.post(
            path="/contents/generations/tasks",
            cast_to=object,
            body=payload
        )

        logger.debug(bjson(response)) # doubao-seedance-2-0-v2v

        return response

    async def _get(self, task_id: str):
        response = await self.client.get(
            path=f"/contents/generations/tasks/{task_id}",
            cast_to=object,
        )
        return response

    # async def create(self, request: Union[SoraVideoRequest, CompletionRequest]):  # callback_url 优先取
    #
    #     payload = {
    #         "model": request.model,
    #
    #         "generate_audio": True,
    #         "watermark": False,
    #         "return_last_frame": True,
    #
    #         "ratio": "16:9",
    #         "duration": 11,
    #     }
    #
    #     if isinstance(request, SoraVideoRequest):
    #         if request.aspect_ratio:
    #             payload['aspect_ratio'] = request.aspect_ratio
    #
    #         if request.aspect_ratio:
    #             payload['resolution'] = request.resolution
    #
    #         payload['content'] = [
    #             {
    #                 "type": "text",
    #                 "text": request.prompt.replace('--', '---')  # -- => ---
    #             }
    #         ]
    #
    #         if image_urls := request.input_reference:
    #             payload['content'] += [{
    #                 "type": "image_url",
    #                 "image_url": {
    #                     "url": url
    #                 },
    #                 "role": "reference_image"
    #             }
    #                 for url in image_urls
    #             ]
    #
    #         if request.audio:
    #             payload['content'] += [{
    #                 "type": "audio_url",
    #                 "audio_url": {
    #                     "url": request.audio
    #                 },
    #                 "role": "reference_audio"
    #             }
    #             ]
    #
    #         if request.video:
    #             payload['content'] += [{
    #                 "type": "video_url",
    #                 "video_url": {
    #                     "url": request.video
    #                 },
    #                 "role": "reference_video"
    #             }
    #             ]
    #
    #         logany(bjson(payload))
    #
    #     try:
    #         response = await client.post(
    #             path="/contents/generations/tasks",
    #             cast_to=object,
    #             body=payload
    #         )
    #
    #         logger.debug(bjson(response))
    #
    #         # {"request_id": "5945e180-c2df-d23a-38ef-3554893b3edb"}
    #
    #         return Video(id=response.get("request_id"))
    #
    #     except APIStatusError as e:
    #         error = {
    #             "code": e.code,
    #             "message": e.message,
    #         }
    #         return Video(status="failed", error=error)
    #
    #     #
    #
    #     #
    #     # if task_id := response.get('id'):
    #     #     await redis_aclient.set(task_id, api_key, ex=7 * 24 * 3600)
    #     #
    #     # return response  # {'id': 'cgt-20250611152553-r46ql'}
    #
    # async def get(self, task_id: str):
    #     try:
    #         response = await self.client.get(f"/videos/{task_id}", cast_to=object)
    #
    #         logger.debug(bjson(response))
    #
    #         video = Video(
    #             id=task_id,
    #             status=response,
    #
    #             model=response.get("model"),
    #             seconds=response.get("duration"),
    #
    #             video_url=response.get("video", {}).get("url"),
    #
    #         )
    #
    #         if video.video_url:
    #             video.progress = 100
    #             video.status = "completed"
    #
    #         return video
    #
    #     except APIStatusError as e:
    #         error = {
    #             "code": e.code,
    #             "message": e.message,
    #         }
    #         logger.debug(error)
    #         return Video(id=task_id, status="failed", error=error)


# 执行异步函数
if __name__ == "__main__":

    api_key = "1561597b-25d0-4d26-9378-b9dd7529acc9"  # 欠费
    model = "doubao-seedance-1-5-pro-251215"

    request = SeedRequest(
        model=model,
        content=[
            {
                "type": "text",
                "text": "--rs 1 全程使用视频1的第一视角构图，全程使用音频1作为背景音乐。第一人称视角果茶宣传广告，seedance牌「苹苹安安」苹果果茶限定款；首帧为图片1，你的手摘下一颗带晨露的阿克苏红苹果，轻脆的苹果碰撞声；2-4 秒：快速切镜，你的手将苹果块投入雪克杯，加入冰块与茶底，用力摇晃，冰块碰撞声与摇晃声卡点轻快鼓点，背景音：「鲜切现摇」；4-6 秒：第一人称成品特写，分层果茶倒入透明杯，你的手轻挤奶盖在顶部铺展，在杯身贴上粉红包标，镜头拉近看奶盖与果茶的分层纹理；6-8 秒：第一人称手持举杯，你将图片2中的果茶举到镜头前（模拟递到观众面前的视角），杯身标签清晰可见，背景音「来一口鲜爽」，尾帧定格为图片2。背景声音统一为女生音色。"
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": "https://ark-project.tos-cn-beijing.volces.com/doc_image/r2v_tea_pic1.jpg"
                },
                "role": "reference_image"
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": "https://ark-project.tos-cn-beijing.volces.com/doc_image/r2v_tea_pic2.jpg"
                },
                "role": "reference_image"
            },
            {
                "type": "video_url",
                "video_url": {
                    "url": "https://ark-project.tos-cn-beijing.volces.com/doc_video/r2v_tea_video1.mp4"
                },
                "role": "reference_video"
            },
            {
                "type": "audio_url",
                "audio_url": {
                    "url": "https://ark-project.tos-cn-beijing.volces.com/doc_audio/r2v_tea_audio1.mp3"
                },
                "role": "reference_audio"
            }
        ]
    )

    arun(Tasks(api_key=api_key)._create(request))
    # r = arun(create_task(request, api_key))
    # r = {'id': 'cgt-20250612172542-6nbt2'}

    # arun(get_task(r.get('id')))

    # arun(get_task("cgt-20250707162431-smhwc"))

    # arun(get_task("cgt-20250707160713-j8kll"))
