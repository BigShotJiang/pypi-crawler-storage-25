# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tzafon import Lightcone, AsyncLightcone
from tests.utils import assert_matches_type
from tzafon.types import ResponseCreateResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestResponses:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Lightcone) -> None:
        response = client.responses.create(
            input="string",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Lightcone) -> None:
        response = client.responses.create(
            input="string",
            background=True,
            cache_salt="cache_salt",
            enable_response_messages=True,
            include=["code_interpreter_call.outputs"],
            include_stop_str_in_output=True,
            instructions="instructions",
            logit_bias={"foo": 0},
            max_output_tokens=0,
            max_tool_calls=0,
            metadata={"foo": "string"},
            mm_processor_kwargs={"foo": "bar"},
            model="model",
            parallel_tool_calls=True,
            previous_input_messages=[
                {
                    "author": {
                        "role": "user",
                        "name": "name",
                    },
                    "channel": "channel",
                    "content": [{}],
                    "content_type": "content_type",
                    "recipient": "recipient",
                }
            ],
            previous_response_id="previous_response_id",
            priority=0,
            prompt={
                "id": "id",
                "variables": {"foo": "string"},
                "version": "version",
            },
            prompt_cache_key="prompt_cache_key",
            reasoning={
                "effort": "none",
                "generate_summary": "auto",
                "summary": "auto",
            },
            request_id="request_id",
            service_tier="auto",
            skip_special_tokens=True,
            store=True,
            stream=True,
            temperature=0,
            text={
                "format": {"type": "text"},
                "verbosity": "low",
            },
            tool_choice="none",
            tools=[
                {
                    "name": "name",
                    "type": "function",
                    "description": "description",
                    "parameters": {"foo": "bar"},
                    "strict": True,
                }
            ],
            top_k=0,
            top_logprobs=0,
            top_p=0,
            truncation="auto",
            user="user",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Lightcone) -> None:
        http_response = client.responses.with_raw_response.create(
            input="string",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = http_response.parse()
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Lightcone) -> None:
        with client.responses.with_streaming_response.create(
            input="string",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = http_response.parse()
            assert_matches_type(ResponseCreateResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Lightcone) -> None:
        response = client.responses.retrieve(
            response_id="response_id",
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: Lightcone) -> None:
        response = client.responses.retrieve(
            response_id="response_id",
            starting_after=0,
            stream=True,
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Lightcone) -> None:
        http_response = client.responses.with_raw_response.retrieve(
            response_id="response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = http_response.parse()
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Lightcone) -> None:
        with client.responses.with_streaming_response.retrieve(
            response_id="response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = http_response.parse()
            assert_matches_type(object, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Lightcone) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            client.responses.with_raw_response.retrieve(
                response_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_cancel(self, client: Lightcone) -> None:
        response = client.responses.cancel(
            "response_id",
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_cancel(self, client: Lightcone) -> None:
        http_response = client.responses.with_raw_response.cancel(
            "response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = http_response.parse()
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_cancel(self, client: Lightcone) -> None:
        with client.responses.with_streaming_response.cancel(
            "response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = http_response.parse()
            assert_matches_type(object, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_cancel(self, client: Lightcone) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            client.responses.with_raw_response.cancel(
                "",
            )


class TestAsyncResponses:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLightcone) -> None:
        response = await async_client.responses.create(
            input="string",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightcone) -> None:
        response = await async_client.responses.create(
            input="string",
            background=True,
            cache_salt="cache_salt",
            enable_response_messages=True,
            include=["code_interpreter_call.outputs"],
            include_stop_str_in_output=True,
            instructions="instructions",
            logit_bias={"foo": 0},
            max_output_tokens=0,
            max_tool_calls=0,
            metadata={"foo": "string"},
            mm_processor_kwargs={"foo": "bar"},
            model="model",
            parallel_tool_calls=True,
            previous_input_messages=[
                {
                    "author": {
                        "role": "user",
                        "name": "name",
                    },
                    "channel": "channel",
                    "content": [{}],
                    "content_type": "content_type",
                    "recipient": "recipient",
                }
            ],
            previous_response_id="previous_response_id",
            priority=0,
            prompt={
                "id": "id",
                "variables": {"foo": "string"},
                "version": "version",
            },
            prompt_cache_key="prompt_cache_key",
            reasoning={
                "effort": "none",
                "generate_summary": "auto",
                "summary": "auto",
            },
            request_id="request_id",
            service_tier="auto",
            skip_special_tokens=True,
            store=True,
            stream=True,
            temperature=0,
            text={
                "format": {"type": "text"},
                "verbosity": "low",
            },
            tool_choice="none",
            tools=[
                {
                    "name": "name",
                    "type": "function",
                    "description": "description",
                    "parameters": {"foo": "bar"},
                    "strict": True,
                }
            ],
            top_k=0,
            top_logprobs=0,
            top_p=0,
            truncation="auto",
            user="user",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightcone) -> None:
        http_response = await async_client.responses.with_raw_response.create(
            input="string",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = await http_response.parse()
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightcone) -> None:
        async with async_client.responses.with_streaming_response.create(
            input="string",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = await http_response.parse()
            assert_matches_type(ResponseCreateResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightcone) -> None:
        response = await async_client.responses.retrieve(
            response_id="response_id",
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncLightcone) -> None:
        response = await async_client.responses.retrieve(
            response_id="response_id",
            starting_after=0,
            stream=True,
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightcone) -> None:
        http_response = await async_client.responses.with_raw_response.retrieve(
            response_id="response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = await http_response.parse()
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightcone) -> None:
        async with async_client.responses.with_streaming_response.retrieve(
            response_id="response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = await http_response.parse()
            assert_matches_type(object, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightcone) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            await async_client.responses.with_raw_response.retrieve(
                response_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_cancel(self, async_client: AsyncLightcone) -> None:
        response = await async_client.responses.cancel(
            "response_id",
        )
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_cancel(self, async_client: AsyncLightcone) -> None:
        http_response = await async_client.responses.with_raw_response.cancel(
            "response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = await http_response.parse()
        assert_matches_type(object, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_cancel(self, async_client: AsyncLightcone) -> None:
        async with async_client.responses.with_streaming_response.cancel(
            "response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = await http_response.parse()
            assert_matches_type(object, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_cancel(self, async_client: AsyncLightcone) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            await async_client.responses.with_raw_response.cancel(
                "",
            )
