"""Layout — grid and faceting."""
