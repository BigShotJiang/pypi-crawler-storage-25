"""Plotting functions

Some of these functions require the model run for all EU countries for many
scenarios to have been aggregated inside post_processor/agg_combos.py.

Usage:

    >>> from eu_cbm_hat.plot.lulucf_plots import plot_sink_by_country
    >>> from eu_cbm_hat.plot.scenarios import plot_hexprov
    >>> from eu_cbm_hat.plot.scenarios import plot_harvest_demand
    >>> from eu_cbm_hat.plot.scenarios import plot_nai, plot_nai_eu

The arguments to these plotting functions are likely to change over time. These
plotting functions where originally created in a notebook at
eu_cbm_explore/scenarios/ssp2_fair_degrowth/ssp2_fair_owc.ipynb

Define a palette to use these plots


"""
import re
import pandas as pd
import seaborn
import seaborn.objects as so
import seaborn as sns
import matplotlib.pyplot as plt


# Rename pathways for the paper
def rename_combo_to_pathway(combo_name):
    """Rename a combo to a pathway
    For example:
        >>> rename_combo_to_pathway("pikssp2_owc_min")
    """
    out = re.sub("pik|_fel1", "", combo_name)
    #out = re.sub("min", "l", out)
    #out = re.sub("max", "h", out)
    return out

def plot_sink_by_country_old (df, y, col_wrap=None, palette=None):
    """Facet plot of CO2 forest sink by country"""
    if col_wrap is None:
        col_wrap = round(len(df["country"].unique()) / 9) + 1
    df = df.copy()
    df[y + "mt"] = df[y] / 1e6
    g = seaborn.relplot(
        data=df,
        x="year",
        y=y + "mt",
        col="country",
        hue="pathway",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False},
    )
    g.set_titles(row_template="{row_name}", col_template="{col_name}")  # , size=30)
    g.fig.set_size_inches(20, 15)
    g.fig.subplots_adjust(hspace=0.3, top=0.95)
    g.set_ylabels(f"{y} MtCO2 eq")
    g.fig.suptitle(f"{y}")
    return g

def plot_sink_by_country(df, y, col_wrap=None, palette=None):
    """Facet plot of CO2 forest sink by country"""
    if col_wrap is None:
        col_wrap = round(len(df["country"].unique()) / 9) + 1
    df = df.copy()
    df[y + "mt"] = df[y] / 1e6

    # Set global font size and line width without grids and with a clean background
    sns.set_theme(style='white', font_scale=1.5, rc={'lines.linewidth': 2.5})

    g = sns.relplot(
        data=df,
        x="year",
        y=y + "mt",
        col="country",
        hue="pathway",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": True},
        linewidth=2.5  # Set the line thickness
    )
    
    # Remove the y-axis labels for each subplot
    for ax in g.axes.flat:
        ax.set_ylabel('')
    
    # Set the size of the figure
    g.fig.set_size_inches(20, 15)
    
    # Set a single Y-axis label for the entire figure
    g.fig.text(0.01, 0.5, f"{y} (MtCO2 eq)", va='center', rotation='vertical', fontsize=16)

    # Remove grid lines
    for ax in g.axes.flat:
        ax.grid(False)

    g.fig.suptitle(f"{y}", fontsize=20)

    # Adjust the subplot parameters to give more space for the legend
    g.fig.subplots_adjust(bottom=0.1, top=0.95, hspace=0.3)  # Adjust the top and bottom

    # Draw the legend
    g._legend.remove()
    g.fig.legend(loc='lower center', bbox_to_anchor=(0.5, -0.05), ncol=3)

    return g


def plot_hexprov(df, y, col_wrap=None, palette=None):
    """Facet plot of harvest demand per country for a given product"""
    if col_wrap is None:
        col_wrap = round(len(df["country"].unique()) / 9) + 1
    g = seaborn.relplot(
        data=df,
        x="year",
        y=y,
        col="country",
        hue="pathway",
        style="element",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False},
    )
    g.set(xticks=[2010, 2030, 2050, 2070])
    g.fig.subplots_adjust(top=0.95)
    g.set_titles(row_template="{row_name}", col_template="{col_name}")
    g.fig.set_size_inches(20, 15)
    g.fig.subplots_adjust(hspace=0.3)
    return g

import matplotlib.pyplot as plt

def plot_hexprov_regions(df, y, col_wrap=None, palette=None):
    """Facet plot of harvest demand per country for a given product"""
    if col_wrap is None:
        col_wrap = round(len(df["region_name"].unique()) / 9) + 1

    # Replace NA values with a specific color (e.g., white)
    #df_filtered= df.fillna(value={'year': 0, y: 0})  # Replace NA with 0 or any other value
    df_filtered= df[df["year"]>= 2020]
    
    g = sns.relplot(
        data=df_filtered,
        x="year",
        y=y,
        col="region_name",
        hue="pathway",
        style="element",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False}
    )
    g.set(xticks=[2020, 2030, 2050, 2070])
    g.fig.subplots_adjust(top=0.95)
    g.set_titles(row_template="{row_name}", col_template="{col_name}")
    g.fig.set_size_inches(20, 15)
    g.fig.subplots_adjust(hspace=0.3)

    # Customize the plot to represent NA values as white color
    for ax in g.axes.flat:
        ax.plot([2020, 2070], [0, 0], color="white", linestyle="--")  # Replace NA values with white color

    return g

def plot_hexprov_irw_fw(df, col_wrap=None, palette=None):
    """Facet plot of harvest demand per country for a given product"""
    if col_wrap is None:
        col_wrap = round(len(df["country"].unique()) / 9) + 1

    # Since 'harvest_demand_irw' and 'harvest_demand_fw' are not separate columns,
    # we will assume that the 'harvest' column contains these values.
    df_filtered = df[df['element'].isin(['harvest_demand_irw', 'harvest_demand_fw'])]

    g_ms = sns.relplot(
    data=df_filtered,
    x="year",
    y="harvest",
    col="country",
    hue="pathway",
    style="element",
    kind="line",
    col_wrap=3,
    facet_kws={"sharey": False, "sharex": False},
    )
    g_ms.set(xticks=[2010, 2030, 2050, 2070])
    g_ms.fig.subplots_adjust(top=0.95)
    g_ms.set_titles(row_template="{row_name}", col_template="{col_name}")
    g_ms.fig.set_size_inches(20, 15)
    g_ms.fig.subplots_adjust(hspace=0.3)
    return g_ms


def plot_harvest_demand(df, palette=None):
    """Facet plot of harvest demand per country for a given product"""
    col_wrap = round(len(df["country"].unique()) / 9) + 1
    g = seaborn.relplot(
        data=df,
        x="year",
        y="demand",
        col="country",
        hue="combo_name",
        style="faostat_name",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False},
    )
    g.fig.subplots_adjust(top=0.95)
    g.fig.suptitle(f"Industrial roundwood harvest demand from the economic model")
    g.set_titles(row_template="{row_name}", col_template="{col_name}")
    g.fig.set_size_inches(20, 15)
    g.fig.subplots_adjust(hspace=0.3)
    return g


def plot_nai(df, y, ylabel, forest_type=None, palette=None):
    """Plot Net Annual Increment"""
    g = seaborn.relplot(
        data=df,
        x="year",
        y=y,
        col="country",
        hue="pathway",
        kind="line",
        col_wrap=5,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False},
    )
    status = df["status"].unique()[0]
    title = f"Net Annual Increment {status}"
    if forest_type is not None:
        title += f" forest type: {forest_type}"
    g.fig.suptitle(title)
    g.set_titles(row_template="", col_template="{col_name}")
    g.fig.supylabel(ylabel)
    g.fig.set_size_inches(15, 15)
    g.fig.subplots_adjust(hspace=0.3)
    g.fig.subplots_adjust(top=0.90, left=0.08, right=0.88)
    file_name = f"nai_{y}_{status}_by_country.png"
    return g


def plot_nai_eu(df, y, palette=None):
    """Plot Net Annual Increment in the EU"""
    g = seaborn.relplot(
        data=df,
        x="year",
        y=y,
        col="status",
        hue="pathway",
        kind="line",
        col_wrap=1,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False},
    )
    g.set_titles(row_template="{row_name}", col_template="{col_name}")
    g.fig.supylabel("NAI in million m3")
    g.fig.set_size_inches(12, 10)
    g.fig.subplots_adjust(hspace=0.3)
    g.fig.subplots_adjust(top=0.90, right=0.88)
    return g


def plot_sink_composition(df, selected_years, index):
    """Bar plot of the sink composition for all years
    Facet on pathway, with years on the x axis.
        >>> plot_sink_composition(sink_by_country_groups,
        ...                       [2030, 2050, 2070],
        ...                       index = ["pathway", "year", "country_group"])
        >>> plot_sink_composition(sink_eu,
        ...                       [2030, 2050, 2070],
        ...                       index=["pathway", "year"])
    """
    # Compute dom sink and select years
    df["dom_sink"] = df[["litter_sink", "dead_wood_sink"]].sum(axis=1)
    selected_columns = ["living_biomass_sink", "dom_sink", "soil_sink", "hwp_sink_bau"]
    selector = df["year"].isin(selected_years)
    df = df.loc[selector, index + selected_columns].copy()
    df[selected_columns] = df[selected_columns] / 1e6
    # Reshape to long format
    df_long = df.melt(id_vars=index, var_name="sink", value_name="value")
    # Plot
    p = so.Plot(df_long, x="year", y="value", color="sink")
    p = p.add(so.Bar(), so.Stack())
    if "country_group" in index:
        p = p.facet("pathway", "country_group").share(x=False)
        p = p.layout(size=(14, 9), engine="tight")
    else:
        p = p.facet("pathway").share(x=False)
        p = p.layout(size=(10, 8), engine="tight")
    palette = {
        "living_biomass_sink": "forestgreen",
        "dom_sink": "gold",
        "soil_sink": "black",
        "hwp_sink_bau": "chocolate",
    }
    p = p.scale(x=so.Continuous().tick(at=selected_years), color=palette)
    p = p.label(x="", y="Million t CO2 eq", color="")
    return p


def plot_sink_by_regions(df, y, col_wrap=None, palette=None):
    """Facet plot of harvest demand per country for a given product"""
    if col_wrap is None:
        col_wrap = round(len(df["region_name"].unique()) / 9) + 1

    # Replace NA values with a specific color (e.g., white)
    df_filled = df.fillna(value={'year': 0, y: 0})  # Replace NA with 0 or any other value

    g = sns.relplot(
        data=df_filled,
        x="year",
        y=y,
        col="region_name",
        hue="pathway",
        kind="line",
        col_wrap=col_wrap,
        palette=palette,
        facet_kws={"sharey": False, "sharex": False}
    )
    g.set(xticks=[2010, 2030, 2050, 2070])
    g.set_titles(row_template="{row_name}", col_template="{col_name}")
    g.fig.set_size_inches(20, 15)
    g.fig.subplots_adjust(hspace=0.3)

    # Remove grid lines
    for ax in g.axes.flat:
        ax.grid(False)

    # Adjust the subplot parameters to reduce space on the right and below
    g.fig.subplots_adjust(left=0.08, bottom=0.08, top=0.92, right=0.92)

    # Draw the legend and place it below the plots
    g._legend.remove()
    g.fig.legend(loc='lower center', bbox_to_anchor=(0.5, -0.05), ncol=3)

    g.fig.suptitle(f"{y}", fontsize=20)

    return g


def plot_total_sink_vs_ref(
    df,
    ref_combos=None,
    packages=None,
    y="total_sink",
    palette=None,
):
    """Time-series comparison of all scenarios vs. their _ref baseline, EU only.

    Creates a 3-panel figure (one per simulation package: reference_bnc,
    reference_low_sink_2050, reference_high_sink_2050). Within each panel
    all EU-level annual total-sink time series for that package are drawn;
    the _ref scenario is highlighted with a thicker dashed line.  A grey
    band marks the 2046-2050 analysis window.

    Parameters
    ----------
    df:
        As returned by ``read_agg_combo_output(scenarios,
        "total_sink_by_year_all_countries.parquet")``.  Must contain
        ``combo_name``, ``country``, ``year``, and the column named by ``y``.
    ref_combos:
        The three reference scenario names, one per package, in the same
        order as ``packages``.  Defaults to
        ``["reference_bnc_ref",
           "reference_low_sink_2050_ref",
           "reference_high_sink_2050_ref"]``.
    packages:
        Combo-name prefix for each panel.  Defaults to
        ``["reference_bnc",
           "reference_low_sink_2050",
           "reference_high_sink_2050"]``.
    y:
        Sink column to plot (default ``"total_sink"``).
    palette:
        Optional colour palette (list or seaborn palette name) for scenario
        lines.  When ``None`` the ``"tab10"`` palette is used.

    Returns
    -------
    matplotlib.figure.Figure

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_total_sink_vs_ref
        >>> scenarios = [
        ...     "reference_bnc_ref", "reference_bnc_nmf",
        ...     "reference_low_sink_2050_ref", "reference_low_sink_2050_nmf",
        ...     "reference_high_sink_2050_ref", "reference_high_sink_2050_nmf",
        ... ]
        >>> df = read_agg_combo_output(scenarios, "total_sink_by_year_all_countries.parquet")
        >>> fig = plot_total_sink_vs_ref(df)

    """
    if ref_combos is None:
        ref_combos = [
            "reference_bnc_ref",
            "reference_low_sink_2050_ref",
            "reference_high_sink_2050_ref",
        ]
    if packages is None:
        packages = [
            "reference_bnc",
            "reference_low_sink_2050",
            "reference_high_sink_2050",
        ]

    y_mt = y + "_mt"
    df_eu = df[df["country"] == "EU"].copy()
    df_eu[y_mt] = df_eu[y] / 1e6

    sns.set_theme(style="white", font_scale=1.3, rc={"lines.linewidth": 2.0})
    fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=True)
    fig.suptitle(
        f"EU {y.replace('_', ' ')} – all scenarios vs. _ref baseline",
        fontsize=14,
    )

    panel_labels = [
        "continuous",
        "low sink 2050",
        "high sink 2050",
    ]

    for ax, pkg, ref, label in zip(axes, packages, ref_combos, panel_labels):
        mask = df_eu["combo_name"].str.startswith(pkg)
        df_pkg = df_eu.loc[mask]
        combos_in_pkg = sorted(df_pkg["combo_name"].unique())

        colors = sns.color_palette(palette or "tab10", n_colors=len(combos_in_pkg))
        color_map = dict(zip(combos_in_pkg, colors))

        for combo in combos_in_pkg:
            subset = df_pkg[df_pkg["combo_name"] == combo].sort_values("year")
            is_ref = combo == ref
            ax.plot(
                subset["year"],
                subset[y_mt],
                label=combo,
                color=color_map[combo],
                linewidth=3.0 if is_ref else 1.5,
                linestyle="--" if is_ref else "-",
                zorder=5 if is_ref else 2,
            )

        # Shade the 2046-2050 analysis window
        ax.axvspan(2046, 2050, alpha=0.10, color="grey")

        ax.set_title(label, fontsize=12)
        ax.set_xlabel("Year")
        ax.grid(False)
        ax.legend(fontsize=7, frameon=False, loc="lower left",
                  bbox_to_anchor=(0.0, 0.0), ncol=1)

    axes[0].set_ylabel(f"{y.replace('_', ' ')} (MtCO₂ eq yr⁻¹)")
    plt.tight_layout()
    return fig


def plot_sink_diff_vs_ref(
    df_diff,
    y="total_sink_diff",
    palette=None,
    exclude_ref=True,
):
    """Horizontal bar chart of EU total-sink anomaly vs. family reference – 2046-2050.

    Three panels side by side (one per simulation family: bnc,
    low_sink_2050, high_sink_2050). Each panel shows one horizontal bar
    per *_ref* scenario in that family, sized by the absolute difference
    in EU mean annual total sink relative to the family reference scenario.
    Green bars indicate a stronger sink than the reference; red bars a
    weaker sink.

    Parameters
    ----------
    df_diff:
        As returned by
        ``eu_sink_diff_vs_ref_2046_2050()`` from
        ``eu_cbm_hat.post_processor.agg_combos``.
    y:
        Column to plot (default ``"total_sink_diff"``).
    palette:
        Two-element list ``[positive_colour, negative_colour]``.
        Defaults to ``["#2ca02c", "#d62728"]`` (green / red).
    exclude_ref:
        When ``True`` (default) the family reference scenario (diff = 0)
        is omitted from the bars; pass ``False`` to include it.

    Returns
    -------
    matplotlib.figure.Figure

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output, eu_sink_diff_vs_ref_2046_2050)
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_sink_diff_vs_ref
        >>> scenarios = [
        ...     "reference_bnc_ref", "max_stock_bnc_ref",
        ...     "max_rotation_bnc_ref", "min_rotation_bnc_ref",
        ...     "continous_cover_bnc_ref",
        ...     "forestpaths_rot+10_bnc_ref", "forestpaths_rot-10_bnc_ref",
        ...     "forestpaths_high_thinnings_bnc_ref",
        ...     "forestpaths_low_thinnings_bnc_ref",
        ...     # add low_sink_2050 and high_sink_2050 variants as needed
        ... ]
        >>> df = read_agg_combo_output(scenarios, "total_sink_by_year_all_countries.parquet")
        >>> diff = eu_sink_diff_vs_ref_2046_2050(df)
        >>> fig = plot_sink_diff_vs_ref(diff)

    """
    if palette is None:
        pos_col, neg_col = "#2ca02c", "#d62728"
    else:
        pos_col, neg_col = palette[0], palette[1]

    families = ["bnc", "low_sink_2050", "high_sink_2050"]
    family_titles = {
        "bnc":            "continuous",
        "low_sink_2050":  "low sink 2050",
        "high_sink_2050": "high sink 2050",
    }
    y_mt = y + "_mt"
    ylabel = f"{y.replace('_diff', '').replace('_', ' ')} anomaly (MtCO₂ eq yr⁻¹)"

    sns.set_theme(style="white", font_scale=1.2)
    fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=False)
    fig.suptitle(
        f"EU {y.replace('_diff', '').replace('_', ' ')} anomaly vs. family reference"
        " – 2046-2050 mean",
        fontsize=14,
    )

    # Compute a single scenario order from the bnc family (first non-empty family
    # as fallback), sorted by value ascending, then reuse it in all three panels.
    df_for_order = df_diff.copy()
    if exclude_ref:
        df_for_order = df_for_order[df_for_order["base_scenario"] != "reference"]
    df_for_order[y_mt] = df_for_order[y] / 1e6

    ref_family = next(
        (f for f in families if not df_for_order[df_for_order["family"] == f].empty),
        families[0],
    )
    scenario_order = (
        df_for_order[df_for_order["family"] == ref_family]
        .sort_values(y_mt, ascending=True)["base_scenario"]
        .tolist()
    )
    # Append any scenarios present in other families but missing from ref_family
    all_scenarios = df_for_order["base_scenario"].unique().tolist()
    scenario_order += [s for s in all_scenarios if s not in scenario_order]

    for ax, family in zip(axes, families):
        df_fam = df_diff[df_diff["family"] == family].copy()

        if exclude_ref:
            df_fam = df_fam[df_fam["base_scenario"] != "reference"]

        if df_fam.empty:
            ax.set_title(family_titles[family], fontsize=12)
            ax.text(0.5, 0.5, "no data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=11)
            continue

        df_fam[y_mt] = df_fam[y] / 1e6
        # Reindex to the shared order (fill missing scenarios with 0)
        df_fam = (
            df_fam.set_index("base_scenario")
            .reindex(scenario_order)
            .reset_index()
            .fillna({y_mt: 0})
        )

        colors = [pos_col if v >= 0 else neg_col for v in df_fam[y_mt]]
        ax.barh(
            df_fam["base_scenario"],
            df_fam[y_mt],
            color=colors,
            edgecolor="white",
            linewidth=0.5,
        )
        ax.axvline(0, color="black", linewidth=1.0)
        ax.set_title(family_titles[family], fontsize=12)
        ax.set_xlabel(ylabel, fontsize=10)
        ax.grid(axis="x", linestyle="--", linewidth=0.5, alpha=0.5)
        ax.set_axisbelow(True)

    axes[0].set_ylabel("Scenario", fontsize=11)
    plt.tight_layout()
    return fig


def plot_combined_pct_diff_vs_ref(
    df_sink_diff,
    df_harvest_diff,
    sink_col="total_sink",
    harvest_col="total_harvest_ub_provided",
    sink_palette=None,
    harvest_palette=None,
    exclude_ref=True,
    scenario_labels=None,
):
    """1×3 grouped bar chart: sink % anomaly and harvest % anomaly in the same panel.

    For each simulation family (bnc, low_sink_2050, high_sink_2050) one panel
    is drawn.  Each scenario gets two horizontal bars stacked vertically:

    * Upper bar — ``sink_col`` % deviation from the family reference (green
      shades).
    * Lower bar — ``harvest_col`` % deviation from the family reference (blue
      shades).

    Positive bars are plotted in the saturated colour; negative bars in the
    muted shade of the same hue, so metric identity (sink vs. harvest) is
    always legible regardless of direction.

    Both metrics are expressed as ``diff / |reference_value| × 100`` so they
    share a common percentage scale.  Scenario order is fixed across all three
    panels, sorted by sink % in the first non-empty family (ascending).

    Parameters
    ----------
    df_sink_diff:
        As returned by ``eu_sink_diff_vs_ref_2046_2050()`` — must include
        ``*_ref`` columns.
    df_harvest_diff:
        As returned by ``eu_harvest_diff_vs_ref_2046_2050()`` — must include
        ``*_ref`` columns.
    sink_col:
        Base sink column (default ``"total_sink"``).
    harvest_col:
        Base harvest column (default ``"total_harvest_ub_provided"``).
    sink_palette:
        ``[positive_colour, negative_colour]`` for sink bars.
        Default: ``["#2ca02c", "#d62728"]`` (green / red).
    harvest_palette:
        ``[positive_colour, negative_colour]`` for harvest bars.
        Default: ``["#1f77b4", "#c49a6c"]`` (dark blue / light brown).
    exclude_ref:
        When ``True`` (default) the family reference scenario (0 % diff)
        is omitted.

    Returns
    -------
    matplotlib.figure.Figure

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output,
        ...     eu_sink_diff_vs_ref_2046_2050,
        ...     eu_harvest_diff_vs_ref_2046_2050,
        ... )
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_combined_pct_diff_vs_ref
        >>> df_sink = read_agg_combo_output(scenarios, "total_sink_by_year_all_countries.parquet")
        >>> df_harv = read_agg_combo_output(scenarios, "hexprov_by_year_all_countries.parquet")
        >>> diff_s = eu_sink_diff_vs_ref_2046_2050(df_sink)
        >>> diff_h = eu_harvest_diff_vs_ref_2046_2050(df_harv)
        >>> fig = plot_combined_pct_diff_vs_ref(diff_s, diff_h)

    """
    if sink_palette is None:
        sink_pos, sink_neg = "#2ca02c", "#d62728"
    else:
        sink_pos, sink_neg = sink_palette[0], sink_palette[1]

    if harvest_palette is None:
        harv_pos, harv_neg = "#1f77b4", "#c49a6c"
    else:
        harv_pos, harv_neg = harvest_palette[0], harvest_palette[1]

    families = ["bnc", "low_sink_2050", "high_sink_2050"]
    family_titles = {
        "bnc":            "continuous",
        "low_sink_2050":  "low sink 2050",
        "high_sink_2050": "high sink 2050",
    }

    sink_diff_col    = sink_col    + "_diff"
    sink_ref_col     = sink_col    + "_ref"
    harvest_diff_col = harvest_col + "_diff"
    harvest_ref_col  = harvest_col + "_ref"

    df_s = df_sink_diff.copy()
    df_h = df_harvest_diff.copy()

    if exclude_ref:
        df_s = df_s[df_s["base_scenario"] != "reference"]
        df_h = df_h[df_h["base_scenario"] != "reference"]

    # % anomaly: diff / |ref| × 100
    df_s["_pct"] = df_s[sink_diff_col] / df_s[sink_ref_col].abs() * 100
    df_h["_pct"] = df_h[harvest_diff_col] / df_h[harvest_ref_col].abs() * 100

    # Shared scenario order: sort by sink % in the first non-empty family
    ref_family = next(
        (f for f in families if not df_s[df_s["family"] == f].empty),
        families[0],
    )
    scenario_order = (
        df_s[df_s["family"] == ref_family]
        .sort_values("_pct", ascending=True)["base_scenario"]
        .tolist()
    )
    all_scenarios = df_s["base_scenario"].unique().tolist()
    scenario_order += [s for s in all_scenarios if s not in scenario_order]

    n_scen  = len(scenario_order)
    bar_h   = 0.38          # height of each bar within the 1-unit slot
    y_pos   = range(n_scen) # integer y positions (one per scenario)

    sns.set_theme(style="white", font_scale=1.2)
    fig, axes = plt.subplots(1, 3, figsize=(18, max(6, n_scen * 0.55 + 2)), sharey=True)
    fig.suptitle(
        "EU scenario anomaly vs. family reference – 2046-2050 mean  (% of reference value)",
        fontsize=14,
    )

    xlabel = "% deviation from family reference"

    for col_idx, family in enumerate(families):
        ax = axes[col_idx]

        # Build lookup dicts scenario → pct for this family
        s_pct = (
            df_s[df_s["family"] == family]
            .set_index("base_scenario")["_pct"]
            .to_dict()
        )
        h_pct = (
            df_h[df_h["family"] == family]
            .set_index("base_scenario")["_pct"]
            .to_dict()
        )

        if not s_pct and not h_pct:
            ax.set_title(family_titles[family], fontsize=12)
            ax.text(0.5, 0.5, "no data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=11)
            continue

        for i, scen in enumerate(scenario_order):
            v_s = s_pct.get(scen, 0.0)
            v_h = h_pct.get(scen, 0.0)

            ax.barh(
                i + bar_h / 2, v_s, bar_h,
                color=sink_pos if v_s >= 0 else sink_neg,
                edgecolor="white", linewidth=0.4,
            )
            ax.barh(
                i - bar_h / 2, v_h, bar_h,
                color=harv_pos if v_h >= 0 else harv_neg,
                hatch="///", edgecolor="black", linewidth=0.4,
            )

        ax.set_yticks(list(y_pos))
        tick_labels = [scenario_labels.get(s, s) if scenario_labels else s for s in scenario_order]
        ax.set_yticklabels(tick_labels, fontsize=9)
        ax.axvline(0, color="black", linewidth=1.0)
        ax.set_title(family_titles[family], fontsize=12)
        ax.set_xlabel(xlabel, fontsize=10)
        ax.grid(axis="x", linestyle="--", linewidth=0.5, alpha=0.5)
        ax.set_axisbelow(True)

    # Panel labels a), b), c)
    for ax, label in zip(axes, ["a)", "b)", "c)"]):
        ax.text(
            0.02, 0.98, label,
            transform=ax.transAxes,
            fontsize=13, fontweight="bold",
            va="top", ha="left",
        )

    # Legend (drawn once on the right of the figure)
    import matplotlib.patches as mpatches
    legend_handles = [
        mpatches.Patch(color=sink_pos, label=f"{sink_col.replace('_',' ')} +"),
        mpatches.Patch(color=sink_neg, label=f"{sink_col.replace('_',' ')} −"),
        mpatches.Patch(facecolor=harv_neg, hatch="///", edgecolor="black", linewidth=1.0, label=f"{harvest_col.replace('_',' ')} −"),
    ]
    fig.legend(
        handles=legend_handles,
        fontsize=9,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.04),
        ncol=4,
        frameon=False,
    )

    plt.tight_layout()
    return fig


def plot_combined_pct_diff_couples(
    diff_s_ref,
    diff_s_nmf,
    diff_h_ref,
    diff_h_nmf,
    sink_col="total_sink",
    harvest_col="total_harvest_ub_provided",
    exclude_ref=True,
    scenario_labels=None,
):
    """1×3 grouped bar chart showing _ref and _nmf scenario couples.

    Extends :func:`plot_combined_pct_diff_vs_ref` by displaying four bars
    per scenario in each family panel:

    * sink _ref    — dark green (positive) / dark red (negative)
    * sink _nmf    — light green (positive) / salmon (negative)
    * harvest _ref — dark blue (positive) / light brown (negative)  + hatch
    * harvest _nmf — light blue (positive) / tan (negative)         + hatch

    Both sink and harvest are expressed as ``diff / |reference| × 100``.
    Scenario order is fixed across all three panels (sorted by sink _ref %,
    ascending, from the first non-empty family).

    Parameters
    ----------
    diff_s_ref:
        ``eu_sink_diff_vs_ref_2046_2050(df, combo_suffix="_ref")``
    diff_s_nmf:
        ``eu_sink_diff_vs_ref_2046_2050(df, combo_suffix="_nmf")``
    diff_h_ref:
        ``eu_harvest_diff_vs_ref_2046_2050(df, combo_suffix="_ref")``
    diff_h_nmf:
        ``eu_harvest_diff_vs_ref_2046_2050(df, combo_suffix="_nmf")``
    sink_col:
        Base sink column (default ``"total_sink"``).
    harvest_col:
        Base harvest column (default ``"total_harvest_ub_provided"``).
    exclude_ref:
        Omit the family reference scenario (0 % diff) when ``True`` (default).

    Returns
    -------
    matplotlib.figure.Figure

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output,
        ...     eu_sink_diff_vs_ref_2046_2050,
        ...     eu_harvest_diff_vs_ref_2046_2050,
        ... )
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_combined_pct_diff_couples
        >>> df_sink = read_agg_combo_output(scenarios_all, "total_sink_by_year_all_countries.parquet")
        >>> df_harv = read_agg_combo_output(scenarios_all, "hexprov_by_year_all_countries.parquet")
        >>> diff_s_ref = eu_sink_diff_vs_ref_2046_2050(df_sink, combo_suffix="_ref")
        >>> diff_s_nmf = eu_sink_diff_vs_ref_2046_2050(df_sink, combo_suffix="_nmf")
        >>> diff_h_ref = eu_harvest_diff_vs_ref_2046_2050(df_harv, combo_suffix="_ref")
        >>> diff_h_nmf = eu_harvest_diff_vs_ref_2046_2050(df_harv, combo_suffix="_nmf")
        >>> fig = plot_combined_pct_diff_couples(diff_s_ref, diff_s_nmf, diff_h_ref, diff_h_nmf)

    """
    s_ref_colors = ("#2ca02c", "#d62728")
    s_nmf_colors = ("#98df8a", "#ff9896")
    h_ref_colors = ("#1f77b4", "#c49a6c")
    h_nmf_colors = ("#aec7e8", "#ddb892")

    families = ["bnc", "low_sink_2050", "high_sink_2050"]
    family_titles = {
        "bnc":            "continuous",
        "low_sink_2050":  "low sink 2050",
        "high_sink_2050": "high sink 2050",
    }

    s_diff_col = sink_col    + "_diff"
    s_ref_col  = sink_col    + "_ref"
    h_diff_col = harvest_col + "_diff"
    h_ref_col  = harvest_col + "_ref"

    def _pct(df_in, diff_col, ref_col):
        out = df_in.copy()
        if exclude_ref:
            out = out[out["base_scenario"] != "reference"]
        out["_pct"] = out[diff_col] / out[ref_col].abs() * 100
        return out

    ds_ref = _pct(diff_s_ref, s_diff_col, s_ref_col)
    ds_nmf = _pct(diff_s_nmf, s_diff_col, s_ref_col)
    dh_ref = _pct(diff_h_ref, h_diff_col, h_ref_col)
    dh_nmf = _pct(diff_h_nmf, h_diff_col, h_ref_col)

    # Shared scenario order from sink _ref in the first non-empty family
    ref_family = next(
        (f for f in families if not ds_ref[ds_ref["family"] == f].empty),
        families[0],
    )
    scenario_order = (
        ds_ref[ds_ref["family"] == ref_family]
        .sort_values("_pct", ascending=True)["base_scenario"]
        .tolist()
    )
    all_scens = ds_ref["base_scenario"].unique().tolist()
    scenario_order += [s for s in all_scens if s not in scenario_order]

    # Group _reg scenarios at bottom, _ms at top (preserves within-group _pct order)
    if scenario_labels:
        def _grp(s):
            lbl = scenario_labels.get(s, s)
            if lbl.endswith("_reg"):
                return 0
            if lbl.endswith("_ms"):
                return 1
            return 2
        scenario_order = sorted(scenario_order, key=_grp)

    n_scen = len(scenario_order)
    bar_h   = 0.20
    offsets = [+1.5 * bar_h, +0.5 * bar_h, -0.5 * bar_h, -1.5 * bar_h]
    # sink bars: no hatch; harvest _ref: "///"; harvest _nmf: "xxx"
    hatches = [None, None, "///", "xxx"]

    sns.set_theme(style="white", font_scale=1.2)
    fig, axes = plt.subplots(
        1, 3,
        figsize=(18, max(6, n_scen * 0.7 + 2)),
        sharey=True,
    )
    fig.suptitle(
        "EU scenario anomaly (_ref and _nmf) vs. family reference – 2046-2050 mean"
        "  (% of reference value)",
        fontsize=14,
    )

    xlabel = "% deviation from family reference"

    for col_idx, family in enumerate(families):
        ax = axes[col_idx]

        all_dfs   = [ds_ref, ds_nmf, dh_ref, dh_nmf]
        all_colors = [s_ref_colors, s_nmf_colors, h_ref_colors, h_nmf_colors]
        pct_maps = [
            df_in[df_in["family"] == family]
            .set_index("base_scenario")["_pct"]
            .to_dict()
            for df_in in all_dfs
        ]

        if all(not m for m in pct_maps):
            ax.set_title(family_titles[family], fontsize=12)
            ax.text(0.5, 0.5, "no data", ha="center", va="center",
                    transform=ax.transAxes, fontsize=11)
            continue

        for i, scen in enumerate(scenario_order):
            for k, (pct_map, (pos_c, neg_c)) in enumerate(zip(pct_maps, all_colors)):
                v = pct_map.get(scen, 0.0)
                h = hatches[k]
                ax.barh(
                    i + offsets[k], v, bar_h,
                    color=pos_c if v >= 0 else neg_c,
                    hatch=h,
                    edgecolor="black" if h else "white",
                    linewidth=0.4,
                )

        ax.set_yticks(list(range(n_scen)))
        tick_labels = [scenario_labels.get(s, s) if scenario_labels else s for s in scenario_order]
        ax.set_yticklabels(tick_labels, fontsize=9)
        ax.axvline(0, color="black", linewidth=1.0)
        ax.set_title(family_titles[family], fontsize=12)
        ax.set_xlabel(xlabel, fontsize=10)
        ax.grid(axis="x", linestyle="--", linewidth=0.5, alpha=0.5)
        ax.set_axisbelow(True)

        ax.text(0.02, 0.98, ["a)", "b)", "c)"][col_idx],
                transform=ax.transAxes, fontsize=13, fontweight="bold",
                va="top", ha="left")

    import matplotlib.patches as mpatches
    legend_handles = [
        mpatches.Patch(facecolor=s_ref_colors[0], label="sink _ref  +"),
        mpatches.Patch(facecolor=s_ref_colors[1], label="sink _ref  −"),
        mpatches.Patch(facecolor=s_nmf_colors[0], label="sink _nmf  +"),
        mpatches.Patch(facecolor=s_nmf_colors[1], label="sink _nmf  −"),
        mpatches.Patch(facecolor=h_ref_colors[1], hatch="///", edgecolor="black",
                       linewidth=1.0, label="harvest _ref  −"),
        mpatches.Patch(facecolor=h_nmf_colors[1], hatch="xxx", edgecolor="black",
                       linewidth=1.0, label="harvest _nmf  −"),
    ]
    fig.legend(
        handles=legend_handles,
        fontsize=9,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.04),
        ncol=6,
        frameon=False,
    )

    plt.tight_layout()
    return fig


def plot_combined_pct_diff_couples_by_region(
    region_diffs,
    sink_col="total_sink",
    harvest_col="total_harvest_ub_provided",
    exclude_ref=True,
    scenario_labels=None,
):
    """n_regions×3 figure: one row per EU region, Figure-9-like columns.

    Parameters
    ----------
    region_diffs : dict
        ``{region_name: (diff_s_ref, diff_s_nmf, diff_h_ref, diff_h_nmf)}``,
        each DataFrame as returned by
        :func:`~eu_cbm_hat.post_processor.agg_combos.eu_sink_diff_vs_ref_2046_2050`
        or :func:`~eu_cbm_hat.post_processor.agg_combos.eu_harvest_diff_vs_ref_2046_2050`
        called with the matching ``region`` and ``combo_suffix`` arguments.

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output,
        ...     eu_sink_diff_vs_ref_2046_2050,
        ...     eu_harvest_diff_vs_ref_2046_2050,
        ...     SCENARIO_LABELS, regions,
        ... )
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_combined_pct_diff_couples_by_region
        >>> region_diffs = {}
        >>> for rname in regions:
        ...     region_diffs[rname] = (
        ...         eu_sink_diff_vs_ref_2046_2050(df_sink, combo_suffix="_ref", region=rname),
        ...         eu_sink_diff_vs_ref_2046_2050(df_sink, combo_suffix="_nmf", region=rname),
        ...         eu_harvest_diff_vs_ref_2046_2050(df_harv, combo_suffix="_ref", region=rname),
        ...         eu_harvest_diff_vs_ref_2046_2050(df_harv, combo_suffix="_nmf", region=rname),
        ...     )
        >>> fig = plot_combined_pct_diff_couples_by_region(
        ...     region_diffs, scenario_labels=SCENARIO_LABELS)

    """
    import matplotlib.patches as mpatches

    s_ref_colors = ("#2ca02c", "#d62728")
    s_nmf_colors = ("#98df8a", "#ff9896")
    h_ref_colors = ("#1f77b4", "#c49a6c")
    h_nmf_colors = ("#aec7e8", "#ddb892")

    families = ["bnc", "low_sink_2050", "high_sink_2050"]
    family_titles = {
        "bnc":            "continuous",
        "low_sink_2050":  "low sink 2050",
        "high_sink_2050": "high sink 2050",
    }

    s_diff_col = sink_col    + "_diff"
    s_ref_col  = sink_col    + "_ref"
    h_diff_col = harvest_col + "_diff"
    h_ref_col  = harvest_col + "_ref"

    def _pct(df_in, diff_col, ref_col):
        out = df_in.copy()
        if exclude_ref:
            out = out[out["base_scenario"] != "reference"]
        out["_pct"] = out[diff_col] / out[ref_col].abs() * 100
        return out

    pct_data = {
        rname: (
            _pct(ds_ref, s_diff_col, s_ref_col),
            _pct(ds_nmf, s_diff_col, s_ref_col),
            _pct(dh_ref, h_diff_col, h_ref_col),
            _pct(dh_nmf, h_diff_col, h_ref_col),
        )
        for rname, (ds_ref, ds_nmf, dh_ref, dh_nmf) in region_diffs.items()
    }

    # Global scenario order: average sink _ref pct across all regions, bnc family
    all_ds_ref = pd.concat([v[0] for v in pct_data.values()], ignore_index=True)
    ref_family = next(
        (f for f in families if not all_ds_ref[all_ds_ref["family"] == f].empty),
        families[0],
    )
    scenario_order = (
        all_ds_ref[all_ds_ref["family"] == ref_family]
        .groupby("base_scenario", as_index=False)["_pct"].mean()
        .sort_values("_pct", ascending=True)["base_scenario"]
        .tolist()
    )
    all_scens = all_ds_ref["base_scenario"].unique().tolist()
    scenario_order += [s for s in all_scens if s not in scenario_order]

    if scenario_labels:
        def _grp(s):
            lbl = scenario_labels.get(s, s)
            if lbl.endswith("_reg"):
                return 0
            if lbl.endswith("_ms"):
                return 1
            return 2
        scenario_order = sorted(scenario_order, key=_grp)

    region_names = list(region_diffs.keys())
    n_regions = len(region_names)
    n_scen    = len(scenario_order)
    bar_h     = 0.20
    offsets   = [+1.5 * bar_h, +0.5 * bar_h, -0.5 * bar_h, -1.5 * bar_h]
    hatches   = [None, None, "///", "xxx"]
    xlabel    = "% anomaly vs. family reference"

    sns.set_theme(style="white", font_scale=1.0)
    fig, axes = plt.subplots(
        n_regions, 3,
        figsize=(18, n_regions * max(5, n_scen * 0.6 + 1.5)),
        sharey=True,
        squeeze=False,
    )
    fig.suptitle(
        "EU scenario anomaly (_ref and _nmf) by region vs. family reference – 2046-2050 mean",
        fontsize=13, y=1.01,
    )

    panel_letters = [chr(ord("a") + i) for i in range(n_regions * 3)]

    for row_idx, region_name in enumerate(region_names):
        ds_ref, ds_nmf, dh_ref, dh_nmf = pct_data[region_name]

        for col_idx, family in enumerate(families):
            ax = axes[row_idx, col_idx]

            filt_s_ref = ds_ref[ds_ref["family"] == family].set_index("base_scenario")["_pct"]
            filt_s_nmf = ds_nmf[ds_nmf["family"] == family].set_index("base_scenario")["_pct"]
            filt_h_ref = dh_ref[dh_ref["family"] == family].set_index("base_scenario")["_pct"]
            filt_h_nmf = dh_nmf[dh_nmf["family"] == family].set_index("base_scenario")["_pct"]

            for filt, cpair, offset, hatch in zip(
                [filt_s_ref, filt_s_nmf, filt_h_ref, filt_h_nmf],
                [s_ref_colors, s_nmf_colors, h_ref_colors, h_nmf_colors],
                offsets, hatches,
            ):
                for i, scen in enumerate(scenario_order):
                    v = filt.get(scen, float("nan"))
                    if pd.isna(v):
                        continue
                    c = cpair[0] if v >= 0 else cpair[1]
                    ax.barh(
                        i + offset, v, bar_h,
                        color=c,
                        hatch=hatch,
                        edgecolor="black" if hatch else "white",
                        linewidth=0.4,
                    )

            ax.set_yticks(list(range(n_scen)))
            if col_idx == 0:
                tick_labels = [
                    scenario_labels.get(s, s) if scenario_labels else s
                    for s in scenario_order
                ]
                ax.set_yticklabels(tick_labels, fontsize=8)
            ax.axvline(0, color="black", linewidth=1.0)
            if row_idx == 0:
                ax.set_title(family_titles[family], fontsize=11)
            ax.set_xlabel(xlabel, fontsize=9)
            ax.grid(axis="x", linestyle="--", linewidth=0.5, alpha=0.5)
            ax.set_axisbelow(True)

            letter = panel_letters[row_idx * 3 + col_idx]
            ax.text(
                0.02, 0.98, f"{letter})",
                transform=ax.transAxes, fontsize=11, fontweight="bold",
                va="top", ha="left",
            )

        # Region label to the right of the last panel in each row
        axes[row_idx, -1].annotate(
            region_name.replace("_", " "),
            xy=(1.03, 0.5), xycoords="axes fraction",
            fontsize=11, fontweight="bold", va="center", ha="left",
            annotation_clip=False,
        )

    legend_handles = [
        mpatches.Patch(facecolor=s_ref_colors[0], label="sink _ref  +"),
        mpatches.Patch(facecolor=s_ref_colors[1], label="sink _ref  −"),
        mpatches.Patch(facecolor=s_nmf_colors[0], label="sink _nmf  +"),
        mpatches.Patch(facecolor=s_nmf_colors[1], label="sink _nmf  −"),
        mpatches.Patch(facecolor=h_ref_colors[1], hatch="///", edgecolor="black",
                       linewidth=1.0, label="harvest _ref  −"),
        mpatches.Patch(facecolor=h_nmf_colors[1], hatch="xxx", edgecolor="black",
                       linewidth=1.0, label="harvest _nmf  −"),
    ]
    fig.legend(
        handles=legend_handles,
        fontsize=9,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.02),
        ncol=6,
        frameon=False,
    )

    plt.tight_layout()
    return fig
