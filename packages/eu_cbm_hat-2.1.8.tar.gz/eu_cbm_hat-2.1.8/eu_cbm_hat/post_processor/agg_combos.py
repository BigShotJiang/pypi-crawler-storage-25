"""
Aggregate scenario combination output and store them in the `eu_cbm_data/output_agg` directory.

For example, gather only one output table (the yearly sink output) for the "reference"
scenario combination for all countries and save it to a CSV file.

    >>> from eu_cbm_hat.post_processor.agg_combos import save_df_all_countries_to_csv
    >>> save_df_all_countries_to_csv(combo_name="reference", runner_method_name="post_processor.sink.df_agg_by_year")

Another example that gathers many output tables for the "reference" scenario
combination for all countries and save all combined output tables to different
parquet files.

    >>> from eu_cbm_hat.post_processor.agg_combos import save_agg_combo_output
    >>> save_agg_combo_output("reference")

Other examples below explain how to run only some of the post processing steps.
This was useful as we were developing these output aggregation methods, we
often wanted to update only one type of output table for all scenarios at once,
and not have to wait to update all output tables for all scenarios.

- Save a specific data frame for all countries and all scenario combinations to
  parquet files

    >>> from eu_cbm_hat.post_processor.agg_combos import apply_to_all_combos
    >>> from eu_cbm_hat.post_processor.agg_combos import apply_to_all_countries
    >>> from eu_cbm_hat.post_processor.agg_combos import get_df_one_country
    >>> from eu_cbm_hat.post_processor.agg_combos import harvest_exp_prov_one_country
    >>> from eu_cbm_hat.post_processor.agg_combos import nai_one_country
    >>> from eu_cbm_hat.post_processor.agg_combos import output_agg_dir
    >>> from eu_cbm_hat.post_processor.agg_combos import pools_length_one_country

    >>> combos = ["pikssp2_fel1", "pikssp2_owc_max", "pikssp2_owc_min",
    >>>           "pikfair_fel1", "pikfair_owc_max", "pikfair_owc_min"]
    >>> apply_to_all_combos(pools_length_one_country, combos, "pools_length.parquet")
    >>> apply_to_all_combos(nai_one_country, combos, "nai_by_year_st.parquet", groupby=["status"])
    >>> apply_to_all_combos(harvest_exp_prov_one_country, combos,
    ...                     "hexprov_by_year.parquet", groupby=["year"])
    >>> apply_to_all_combos(area_one_country, combos, "area_st_ft_agecl.parquet",
    ...                     groupby=["year", "status", "forest_type", "age_class"])
    >>> apply_to_all_combos(harvest_exp_prov_one_country, combos, "hexprov_by_year_ft_dist.parquet",
    ...                     groupby=["year", "forest_type", "con_broad", "disturbance_type"])
    >>> apply_to_all_combos(get_df_one_country, combos, "stock_agg_by_year_ldist.parquet",
    ...                     groupby=["year", "last_disturbance"], runner_method_name="post_processor.stock.df_agg")

- Open the resulting parquet files to check the content of the data frames

    >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
    >>> sink = read_agg_combo_output(["reference", "pikfair"], "sink_by_year.parquet")
    >>> nai_st = read_agg_combo_output(combos, "nai_by_year_st_test_to_delete.parquet")
    >>> pools_length = read_agg_combo_output(combos, "pools_length.parquet")

- Save a specific data frame for all countries and only one scenario
  combination to parquet files

    >>> from eu_cbm_hat.post_processor.agg_combos import apply_to_all_countries
    >>> from eu_cbm_hat.post_processor.agg_combos import output_agg_dir
    >>> from eu_cbm_hat.post_processor.agg_combos import sink_one_country
    >>> combo_name = "reference"
    >>> combo_dir = output_agg_dir / combo_name
    >>> sink = apply_to_all_countries(
    >>>     sink_one_country, combo_name=combo_name, groupby="year"
    >>> )
    >>> sink.to_parquet(combo_dir / "sink_by_year_test_to_delete.parquet")
    >>> nai_st = apply_to_all_countries(nai_one_country, combo_name=combo_name, groupby=["status"])
    >>> nai_st.to_parquet(combo_dir / "nai_by_year_st_test_to_delete.parquet")
    >>> pools_length = apply_to_all_countries(pools_length_one_country, combo_name)
    >>> pools_length.to_parquet(combo_dir / "pools_length.parquet")

- Get data frames in all countries:

    >>> from eu_cbm_hat.post_processor.agg_combos import get_df_all_countries
    >>> # Events templates raw in all countries. This includes all scenarios,
    >>> # use with caution, it requires further filtering on the scenario column
    >>> # which is different than the combo_name column. The scenario column is given
    >>> # by runner.combo  runner.combo.config["events_templates"] variable.
    >>> events_templates_all = get_df_all_countries(
    >>>     combo_name="reference",
    >>>     runner_method_name="silv.events.raw"
    >>> )
    >>> # Load wood density and bark fraction in all countries.
    >>> wood_density_bark_all = get_df_all_countries(
    >>>     combo_name="reference",
    >>>     runner_method_name="post_processor.wood_density_bark_frac"
    >>> )
    >>> # Load inventory in all countries and sum the area by management type
    >>> inventory_all = get_df_all_countries(
    >>>     combo_name="reference",
    >>>     runner_method_name="country.orig_data.__getitem__",
    >>>     item=("mgmt", "inventory")
    >>> )
    >>> inventory_all["area"] = inventory_all["area"].astype(float)
    >>> inv_agg = inventory_all.groupby(["mgmt_strategy"]).agg(area = ("area","sum"))
    >>> inv_agg = inv_agg.assign(share = lambda x: x.area / x.area.sum())

- HWP results for one country, all countries in a scenario, multiple scenarios,
  and regional aggregates:

    >>> from eu_cbm_hat.post_processor.agg_combos import hwp_one_country
    >>> from eu_cbm_hat.post_processor.agg_combos import hwp_eu
    >>> from eu_cbm_hat.post_processor.agg_combos import hwp_all_scenarios
    >>> from eu_cbm_hat.post_processor.agg_combos import hwp_by_region

    >>> # Single country
    >>> df_lu = hwp_one_country("reference", "LU")

    >>> # All countries for one scenario, with EU aggregate row
    >>> df_ref = hwp_eu("reference")

    >>> # Multiple scenarios × all their countries
    >>> scenarios = ["reference", "intensive"]
    >>> df_all = hwp_all_scenarios(scenarios)

    >>> # Multiple scenarios × a subset of countries
    >>> df_sub = hwp_all_scenarios(scenarios, countries=["LU", "AT", "DE"])

    >>> # All countries plus regional aggregates for one scenario
    >>> df_reg = hwp_by_region("reference")

- *Implementation note*: this script cannot be made a method of the
  combos/base_combo.py/Combination class because of circular references such as
  post_processor/harvest.py importing "continent" and "combined".

    >>> from eu_cbm_hat.info.harvest import combined
    >>> from eu_cbm_hat.core.continent import continent

    - To avoid these imports, functions in post_processor/harvest.py could be refactored.
    - Removing the "continent" could be done by changing functions to pass runner
      objects as arguments instead of creating the runner from the continent object.
    - The call to combined could be removed by loading the harvest demand table
      directly from CSV files.

- Collect one output table across many scenarios (recommended for notebooks):

    >>> from eu_cbm_hat.post_processor.agg_combos import (
    ...     collect_scenarios,
    ...     sink_d_ar_fl_all_countries_annual,
    ...     sink_d_ar_fl_all_countries_period,
    ...     harvest_vol_d_ar_fl_all_countries_annual,
    ...     harvest_vol_d_ar_fl_all_countries_period,
    ... )
    >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]

    >>> # Process all scenarios and return a concatenated DataFrame with EU row
    >>> sink_annual = collect_scenarios(
    ...     scenarios,
    ...     sink_d_ar_fl_all_countries_annual,
    ...     "sink_d_ar_fl_by_year.parquet",
    ... )

    >>> # Add a new scenario without reprocessing existing ones (append mode)
    >>> all_scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf", "new_scenario"]
    >>> sink_annual = collect_scenarios(
    ...     all_scenarios,
    ...     sink_d_ar_fl_all_countries_annual,
    ...     "sink_d_ar_fl_by_year.parquet",
    ...     append=True,
    ... )

    >>> # Reprocess only a failed/corrupted scenario, leave all others intact
    >>> sink_annual = collect_scenarios(
    ...     all_scenarios,
    ...     sink_d_ar_fl_all_countries_annual,
    ...     "sink_d_ar_fl_by_year.parquet",
    ...     rerun=["reference_bnc_ref"],
    ... )

    >>> # Period-aggregated harvest
    >>> harvest_period = collect_scenarios(
    ...     scenarios,
    ...     harvest_vol_d_ar_fl_all_countries_period,
    ...     "harvest_vol_d_ar_fl_by_period.parquet",
    ... )

"""

from typing import Union, List
import pandas
import warnings
from tqdm import tqdm
from p_tqdm import p_umap
from eu_cbm_hat.core.continent import continent
from eu_cbm_hat.post_processor.convert import ton_carbon_to_m3_ob
from eu_cbm_hat.post_processor.select_hwp_scenario import select_hwp_scenario
from eu_cbm_hat.constants import eu_cbm_data_pathlib

# Define where to store the data
output_agg_dir = eu_cbm_data_pathlib / "output_agg"
output_agg_dir.mkdir(exist_ok=True)

# ISO-2 ↔ country name mapping shared across notebooks
iso2_to_name = {
    "AT": "Austria",     "BE": "Belgium",     "BG": "Bulgaria",
    "CZ": "Czechia",     "DE": "Germany",     "DK": "Denmark",
    "EE": "Estonia",     "ES": "Spain",       "FI": "Finland",
    "FR": "France",      "GR": "Greece",      "HR": "Croatia",
    "HU": "Hungary",     "IE": "Ireland",     "IT": "Italy",
    "LT": "Lithuania",   "LU": "Luxembourg",  "LV": "Latvia",
    "NL": "Netherlands", "PL": "Poland",      "PT": "Portugal",
    "RO": "Romania",     "SE": "Sweden",      "SI": "Slovenia",
    "SK": "Slovakia",    "EU": "EU",
}
name_to_iso2 = {v: k for k, v in iso2_to_name.items()}


def place_combo_name_and_country_first(df, runner):
    """Add combo name and country code to a data frame,
    place them as first columns"""
    df["combo_name"] = runner.combo.short_name
    df["iso2_code"] = runner.country.iso2_code
    df["country"] = runner.country.country_name
    cols = list(df.columns)
    cols = cols[-3:] + cols[:-3]
    return df[cols]


def get_df_one_country(combo_name, iso2_code, runner_method_name, **kwargs):
    """A generic function that returns the data frame output of the given
    runner method. See example use in the `get_df_all_countries()` function.
    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    method = runner
    for method_name in runner_method_name.split("."):
        method = getattr(method, method_name)
    # If it's a @cached_property that returns a data frame directly
    if method.__class__.__name__ ==  "DataFrame":
        df = method
    # Otherwise call the method with additional arguments
    else:
        df = method(**kwargs)
    df = place_combo_name_and_country_first(df, runner)
    return df


def apply_to_all_countries(data_func, combo_name, **kwargs):
    """Apply a function to many countries"""
    df_all = pandas.DataFrame()
    country_codes = continent.combos[combo_name].runners.keys()
    for key in tqdm(country_codes):
        try:
            df = data_func(combo_name, key, **kwargs)
            df_all = pandas.concat([df, df_all])
        except FileNotFoundError as e_file:
            print(e_file)
        except ValueError as e_value:
            print(key, e_value)
        except KeyError as e_key:
            print(key, e_key)
        except OSError as e_os:
            print(f"OSError for combo={combo_name} country={key}: {e_os}")
            raise
    df_all.reset_index(inplace=True, drop=True)
    return df_all


def get_df_all_countries(combo_name, runner_method_name, **kwargs):
    """Get a data frame for all countries.

    Check wood density and bark fraction in all countries:

        >>> from eu_cbm_hat.post_processor.agg_combos import get_df_all_countries
        >>> wood_density_bark_all = get_df_all_countries(
        ...     combo_name="reference",
        ...     runner_method_name="post_processor.wood_density_bark_frac"
        ... )

    Check aggregated stock in all countries:

        >>> stock_agg_all = get_df_all_countries(
        ...     combo_name="reference",
        ...     runner_method_name="post_processor.stock.df_agg",
        ...     groupby = ["year", "last_disturbance"],
        ... )

    Area in all countries grouped by status, forest type, age and disturbances:

        >>> area_sfad_all = get_df_all_countries(
        ...     combo_name="reference",
        ...     runner_method_name="post_processor.area.df_agg",
        ...     groupby = ["year", 'status', "forest_type", "age","disturbance_type"],
        ... )

    Note: data types should be harmonized to avoid this error when writing to a parquet file
    ArrowTypeError: ("Expected bytes, got a 'int' object", 'Conversion failed for column climate with type object')
    """
    df_all = apply_to_all_countries(
        data_func=get_df_one_country,
        combo_name=combo_name,
        runner_method_name=runner_method_name,
        **kwargs,
    )
    return df_all


def save_df_all_countries_to_csv(combo_name, runner_method_name, **kwargs):
    """Gather the given data frame for the given scenario combination in all
    countries, then save it to a CSV file.

    The last element of the runner method name will be used as the CSV file
    name. CSV files for the "reference" scenario will be written to the
    `eu_cbm_data/output_agg/reference` directory.

    For example :

        >>> from eu_cbm_hat.post_processor.agg_combos import save_df_all_countries_to_csv
        >>> save_df_all_countries_to_csv(combo_name="reference", runner_method_name="post_processor.sink.df_agg_by_year")
        >>> save_df_all_countries_to_csv(combo_name="reference", runner_method_name="post_processor.hwp.stock_sink_results")
        >>> save_df_all_countries_to_csv("reference", "post_processor.hwp.build_hwp_stock_since_1900")
        >>> save_df_all_countries_to_csv("reference", "post_processor.hwp.build_hwp_stock_since_1990")
        >>> save_df_all_countries_to_csv(combo_name="timba", runner_method_name="post_processor.harvest.expected_provided", groupby="year")

    """
    combo_agg_dir = eu_cbm_data_pathlib / "output_agg" / combo_name
    combo_agg_dir.mkdir(exist_ok=True)
    df = get_df_all_countries(
        combo_name=combo_name,
        runner_method_name=runner_method_name,
        **kwargs
    )
    kwargs_suffix = "".join(
        f"_{k}_{'_'.join(v) if isinstance(v, list) else v}"
        for k, v in kwargs.items()
    )
    csv_filename = runner_method_name.replace(".", "_") + kwargs_suffix + ".csv"
    df.to_csv(combo_agg_dir / csv_filename, index=False)


def apply_to_all_countries_and_save(args):
    """Get data for all countries and save it to a parquet file

    This function is to be used with
        - p_umap() in apply_to_all_combos().
        - and in save_agg_combo_output
    """
    data_func, combo_name, file_path, groupby, runner_method_name = args
    # Have to check if defined or not because combo_name is passed in **kwargs
    # TODO: check if it's possible to pass groupby, runner_method_name and
    # combo_name in kwargs
    try:
        if groupby is None and runner_method_name is None:
            print(f"Processing {combo_name} {data_func}.")
            df = apply_to_all_countries(data_func=data_func, combo_name=combo_name)
        elif runner_method_name is None:
            print(f"Processing {combo_name} {data_func} grouped by {groupby}.")
            df = apply_to_all_countries(
                data_func=data_func, combo_name=combo_name, groupby=groupby
            )
        else:
            msg = f"Processing {combo_name} {data_func} with {runner_method_name} "
            msg += f"grouped by {groupby}."
            print(msg)
            df = apply_to_all_countries(
                data_func=data_func, combo_name=combo_name, groupby=groupby, runner_method_name=runner_method_name
            )
    except Exception as e:
        raise RuntimeError(f"Failed for combo={combo_name} file={file_path.name}") from e
    df.to_parquet(file_path)


def apply_to_all_combos(
    data_func,
    combo_names,
    file_name,
    groupby=None,
    runner_method_name=None,
    append: bool = False,
    rerun: list = None,
):
    """Apply a function to all scenario combinations and save to parquet files

    This saves data for all countries in all scenario combinations into the
    given parquet file name. One file for each sub-directory in the
    eu_cbm_data/output_agg directory. These files can then be read and
    concatenated later with the read_agg_combo_output() function.

    Parameters
    ----------
    data_func:
        A ``*_one_country`` function from this module.
    combo_names:
        List of scenario combination names.
    file_name:
        Parquet file name written into each combo's output_agg sub-directory.
    groupby:
        Optional groupby columns passed to the data function.
    runner_method_name:
        Optional runner method name passed to the data function.
    append:
        When ``True``, skip any combo whose output parquet file already exists.
        Ignored for any combo listed in ``rerun``.
    rerun:
        List of combo names to force-reprocess and overwrite, regardless of
        whether their parquet already exists.  All other combos are skipped.
        Use this to replace specific failed or corrupted scenarios without
        reprocessing everything, e.g. ``rerun=["reference_bnc_ref"]``.

    Usage with the get_df_one_country function:

        >>> from eu_cbm_hat.post_processor.agg_combos import apply_to_all_combos
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> from eu_cbm_hat.post_processor.agg_combos import get_df_one_country
        >>> apply_to_all_combos(get_df_one_country, ["reference", "pikfair_fel1"], "stock_agg_example_to_delete.parquet", ["year", "last_disturbance"], "post_processor.stock.df_agg")
        >>> # Read the parquet file
        >>> stock_agg = read_agg_combo_output(["reference", "pikfair_fel1"], "stock_agg_example_to_delete.parquet")

        >>> # Reprocess only a failed scenario, leave all others intact
        >>> apply_to_all_combos(get_df_one_country, ["reference", "pikfair_fel1"],
        ...                     "stock_agg_example_to_delete.parquet",
        ...                     ["year", "last_disturbance"], "post_processor.stock.df_agg",
        ...                     rerun=["reference_bnc_ref"])

   It can also be used with a custom function:

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_exp_prov_one_country
        >>> apply_to_all_combos(harvest_exp_prov_one_country, ["reference", "pikfair_fel1"], "hexprov_example_to_delete.parquet",
        ...                     groupby=["year", "forest_type", "con_broad", "disturbance_type"])
        >>> hexprov = read_agg_combo_output(["reference", "pikfair_fel1"], "hexprov_example_to_delete.parquet")

    """
    combo_names = [c for c in combo_names if isinstance(c, str)]
    rerun_set = set(rerun) if rerun else set()

    for combo_name in combo_names:
        (output_agg_dir / combo_name).mkdir(exist_ok=True)

    if rerun_set:
        combos_to_run = [c for c in combo_names if c in rerun_set]
        print(f"Rerunning {len(combos_to_run)} combo(s): {sorted(combos_to_run)}")
    elif append:
        combos_to_run = [
            c for c in combo_names
            if not (output_agg_dir / c / file_name).exists()
        ]
        skipped = set(combo_names) - set(combos_to_run)
        if skipped:
            print(f"Skipping {len(skipped)} already-processed combo(s): {sorted(skipped)}")
    else:
        combos_to_run = combo_names

    if not combos_to_run:
        return []

    items = [
        (
            data_func,
            combo_name,
            output_agg_dir / combo_name / file_name,
            groupby,
            runner_method_name,
        )
        for combo_name in combos_to_run
    ]
    result = p_umap(apply_to_all_countries_and_save, items, num_cpus=4)
    return result


def save_agg_combo_output(combo_name: str):
    """Aggregate scenario combination output and store them in parquet files
    inside the `eu_cbm_data/output_agg` directory.

    Example save all post-processing data frames to `eu_cbm_data/output_agg`
    for one combo:

        >>> from eu_cbm_hat.post_processor.agg_combos import save_agg_combo_output
        >>> save_agg_combo_output("reference")

    Save for many scenario combinations in a loop:

        >>> for x in ["reference", "pikssp2", "pikfair"]:
        >>>     save_agg_combo_output(x)

    """
    combo_dir = output_agg_dir / combo_name
    combo_dir.mkdir(exist_ok=True)
    parameters = [
        {
            "data_func": harvest_exp_prov_one_country,
            "groupby": ["year"],
            "file_name": "hexprov_by_year.parquet",
        },
        {
            "data_func": harvest_exp_prov_one_country,
            "groupby": ["year", "forest_type", "con_broad", "disturbance_type"],
            "file_name": "hexprov_by_year_ft_dist.parquet",
        },
        {
            "data_func": sink_one_country,
            "groupby": "year",
            "file_name": "sink_by_year.parquet",
        },
        {
            "data_func": sink_one_country,
            "groupby": ["year", "status", "region"],
            "file_name": "sink_by_year_st_rg.parquet",
        },
        {
            "data_func": area_by_status_one_country,
            "groupby": None,
            "file_name": "area_by_year_status.parquet",
        },
        {
            "data_func": harvest_area_by_dist_one_country,
            "groupby": None,
            "file_name": "harvest_area_by_year_dist.parquet",
        },
        {
            "data_func": nai_one_country,
            "groupby": ["status"],
            "file_name": "nai_by_year_st.parquet",
        },
        {
            "data_func": area_by_age_class_one_country,
            "groupby": ["year", "status", "age_class"],
            "file_name": "area_by_age_class.parquet",
        },
        {
            "data_func": share_thinn_final_cut,
            "groupby": None,
            "file_name": "share_thinn_final_cut.parquet",
        },
                {
            "data_func": hwp_ms_eu,
            "groupby": None,
            "file_name": "hwp_ms_eu.parquet",
        },
        {
            "data_func": sink_d_ar_fl_one_country,
            "groupby": ["year", "status"],
            "file_name": "sink_d_ar_fl_by_year.parquet",
        },
        {
            "data_func": harvest_vol_d_ar_fl_one_country,
            "groupby": None,
            "file_name": "harvest_vol_d_ar_fl_by_year.parquet",
        },
        {
            "data_func": total_sink_by_year_one_country,
            "groupby": None,
            "file_name": "total_sink_by_year.parquet",
        },
        ]
    # List of parameters to be fed p_umap
    items = [
        (
            param["data_func"],
            combo_name,
            output_agg_dir / combo_name / param["file_name"],  # file path
            param["groupby"],
            param.get("runner_method_name", None)
        )
        for param in parameters
    ]
    result = p_umap(apply_to_all_countries_and_save, items, num_cpus=4)
    return result


def _run_all_countries_func_and_save(args):
    """Worker used by collect_scenarios: call an *_all_countries_* function
    for one scenario combination and save the result to a parquet file."""
    all_countries_func, combo_name, file_path = args
    print(f"Processing {combo_name} with {all_countries_func.__name__}.")
    try:
        df = all_countries_func(combo_name)
    except Exception as e:
        raise RuntimeError(f"Failed for combo={combo_name} in {all_countries_func.__name__}") from e
    df.to_parquet(file_path)


def collect_scenarios(
    combo_names: list,
    all_countries_func,
    file_name: str,
    append: bool = False,
    rerun: list = None,
) -> pandas.DataFrame:
    """Collect one output table across many scenario combinations and return
    a single concatenated DataFrame (also saved as parquet per combo).

    This is the recommended replacement for hand-written scenario loops in
    notebooks.  Each scenario runs in a separate process via p_umap; within
    each scenario countries are iterated by the ``all_countries_func``.
    The EU aggregate row is included because ``all_countries_func`` is one of
    the ``*_all_countries_*`` functions that already build it.

    Parameters
    ----------
    combo_names:
        List of scenario combination names, e.g.
        ["reference_bnc_nmf", "max_rotation_bnc_nmf"].
    all_countries_func:
        An ``*_all_countries_*`` function from this module — one that accepts
        only ``combo_name`` and already appends EU (and optionally regional)
        aggregate rows.  E.g. ``sink_d_ar_fl_all_countries_annual``,
        ``harvest_vol_d_ar_fl_all_countries_annual``.
    file_name:
        Parquet file name written into each combo's output_agg sub-directory,
        e.g. "sink_d_ar_fl_by_year.parquet".
    append:
        When ``True``, skip any combo whose output parquet file already exists
        and only process the new ones.  All combos (existing + new) are still
        read back and returned in the concatenated result.  Default ``False``
        reprocesses every combo.  Ignored for any combo listed in ``rerun``.
    rerun:
        List of combo names to fully reprocess and overwrite, regardless of
        whether their parquet already exists.  All other combos in
        ``combo_names`` are read from disk unchanged.  Use this to replace the
        output of specific failed or corrupted scenarios without touching the
        rest, e.g. ``rerun=["reference_bnc_ref"]``.

    Returns
    -------
    pandas.DataFrame
        All scenarios concatenated, including EU aggregate rows, with
        ``combo_name`` as first column.

    Examples
    --------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     collect_scenarios,
        ...     sink_d_ar_fl_all_countries_annual,
        ...     sink_d_ar_fl_all_countries_period,
        ...     harvest_vol_d_ar_fl_all_countries_annual,
        ...     harvest_vol_d_ar_fl_all_countries_period,
        ... )
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]  # add more as needed
        >>> # Annual sink with EU row
        >>> sink_annual = collect_scenarios(
        ...     scenarios,
        ...     sink_d_ar_fl_all_countries_annual,
        ...     "sink_d_ar_fl_by_year.parquet",
        ... )
        >>> # Append a new scenario without reprocessing existing ones
        >>> all_scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf", "new_scenario"]
        >>> sink_annual = collect_scenarios(
        ...     all_scenarios,
        ...     sink_d_ar_fl_all_countries_annual,
        ...     "sink_d_ar_fl_by_year.parquet",
        ...     append=True,
        ... )
        >>> # Reprocess only a failed/corrupted scenario, leave all others intact
        >>> sink_annual = collect_scenarios(
        ...     all_scenarios,
        ...     sink_d_ar_fl_all_countries_annual,
        ...     "sink_d_ar_fl_by_year.parquet",
        ...     rerun=["reference_bnc_ref"],
        ... )
        >>> # Period-aggregated harvest with EU row
        >>> harvest_period = collect_scenarios(
        ...     scenarios,
        ...     harvest_vol_d_ar_fl_all_countries_period,
        ...     "harvest_vol_d_ar_fl_by_period.parquet",
        ... )

    """
    # Guard: a bare string would be iterated character-by-character below
    if isinstance(combo_names, str):
        combo_names = [combo_names]
    # Drop any non-string entries (e.g. accidental Ellipsis placeholders)
    combo_names = [c for c in combo_names if isinstance(c, str)]
    rerun_set = set(rerun) if rerun else set()

    # Ensure output sub-directories exist
    for combo_name in combo_names:
        (output_agg_dir / combo_name).mkdir(exist_ok=True)

    if rerun_set:
        combos_to_run = [c for c in combo_names if c in rerun_set]
        print(f"Rerunning {len(combos_to_run)} combo(s): {sorted(combos_to_run)}")
    elif append:
        combos_to_run = [
            c for c in combo_names
            if not (output_agg_dir / c / file_name).exists()
        ]
        skipped = set(combo_names) - set(combos_to_run)
        if skipped:
            print(f"Skipping {len(skipped)} already-processed combo(s): {sorted(skipped)}")
    else:
        combos_to_run = combo_names

    if combos_to_run:
        items = [
            (
                all_countries_func,
                combo_name,
                output_agg_dir / combo_name / file_name,
            )
            for combo_name in combos_to_run
        ]
        p_umap(_run_all_countries_func_and_save, items, num_cpus=4)

    # Read back and concatenate all saved files
    return read_agg_combo_output(combo_names, file_name)


def read_agg_combo_output(combo_name: list, file_name: str):
    """Read the aggregated combo output for the given list of combo names and
    the given file name. Return a concatenated data frame with data from all
    combos for that file.

    Example use:

        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> sink = read_agg_combo_output(["reference", "pikfair"], "sink_by_year.parquet")
        >>> hexprov = read_agg_combo_output(["reference", "pikfair"], "hexprov_by_year.parquet")

    """
    df_all = pandas.DataFrame()
    df = pandas.DataFrame()
    for this_combo_name in combo_name:
        try:
            df = pandas.read_parquet(output_agg_dir / this_combo_name / file_name)
        except FileNotFoundError as error:
            print(error)
        df_all = pandas.concat([df_all, df])
    df_all.reset_index(inplace=True, drop=True)
    return df_all

# better check sink.py
def sink_one_country(
    combo_name: str,
    iso2_code: str,
    groupby: Union[List[str], str],
):
    """Sum the pools for the given country and add information on the combo
    country code

    The `groupby` argument specify the aggregation level. In addition to
    "year", one or more classifiers can be used for example "forest_type".

    The `pools_dict` argument is a dictionary mapping an aggregated pool name
    with the corresponding pools that should be aggregated into it. If you
    don't specify it, the function will used the default pools dict. The
    groupby argument makes it possible to specify how the sink rows will be
    grouped: by year, region, status and climate.

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_one_country
        >>> ie_sink_y = sink_one_country("reference", "IE", groupby="year")
        >>> ie_sink_ys = sink_one_country("reference", "IE", groupby=["year", "status"])
        >>> lu_sink_y = sink_one_country("reference", "LU", groupby="year")
        >>> lu_sink_ys = sink_one_country("reference", "LU", groupby=["year", "status"])
        >>> lu_sink_yrc = sink_one_country("reference", "LU", groupby=["year", "region", "climate"])
        >>> hu_sink_y = sink_one_country("reference", "HU", groupby="year")

    Specify your own `pools_dict`:

        >>> pools_dict = {
        >>>     "living_biomass": [
        >>>         "softwood_merch",
        >>>         "softwood_other",
        >>>         "softwood_foliage",
        >>>         "softwood_coarse_roots",
        >>>         "softwood_fine_roots",
        >>>         "hardwood_merch",
        >>>         "hardwood_foliage",
        >>>         "hardwood_other",
        >>>         "hardwood_coarse_roots",
        >>>         "hardwood_fine_roots",
        >>>     ],
        >>>     "soil" : [
        >>>         "below_ground_very_fast_soil",
        >>>         "below_ground_slow_soil",
        >>>     ]
        >>> }
        >>> lu_sink_by_year = sink_one_country("reference", "LU", groupby="year", pools_dict=pools_dict)
        >>> index = ["year", "forest_type"]
        >>> lu_sink_by_y_ft = sink_one_country("reference", "LU", groupby=index, pools_dict=pools_dict)

    Sum flux pools and compute the sink

    Only return data for countries in which the model run was successful in
    storing the output data. Print an error message if the file is missing, but
    do not raise an error.

    Define a sink_all_countries function for the following examples

        >>> from eu_cbm_hat.post_processor.sink_all_countries import sink_one_country
        >>> def sink_all_countries(combo_name, groupby):
        >>>     df_all = apply_to_all_countries(
        >>>         sink_one_country, combo_name=combo_name, groupby=groupby
        >>>     )
        >>>     return df_all
        >>> sink = sink_all_countries("reference", "year")

    The purpose of this script is to compute the sink for all countries

    The following code summarises the flux_pool output for each country.

    For each year in each country:
    - aggregate the living biomass pools
    - compute the stock change
    - multiply by -44/12 to get the sink.


    Usage example (see also functions documentation bellow).

    Get the biomass sink for 2 scenarios:

        >>> import pandas
        >>> # Replace these by the relevant scenario combinations
        >>> sinkfair = sink_all_countries("pikfair", "year")
        >>> sinkbau =  sink_all_countries("pikssp2", "year")
        >>> df_all = pandas.concat([sinkfair, sinkbau])
        >>> df_all.reset_index(inplace=True, drop=True)
        >>> df_all.sort_values("country", inplace=True)

    Note the area is stable through time, transition rules only make it move from
    one set of classifiers to another set of classifiers.

        from eu_cbm_hat.core.continent import continent
        runner = continent.combos["pikfair"].runners["IE"][-1]
        classifiers = runner.output.classif_df
        index = ["identifier", "timestep"]
        pools = runner.output["pools"].merge(classifiers, "left", on=index)
        area_status = (pools.groupby(["timestep", "status"])["area"]
                       .agg("sum")
                       .reset_index()
                       .pivot(columns="status", index="timestep", values="area")
                       )
        cols = df.columns
        area_status["sum"] = area_status.sum(axis=1)

    The following code chunk is a justification of why we need to look at the
    carbon content of soils in this convoluted way. Because a few afforested plots
    have AR present in the first time step, then we cannot compute a difference to
    the previous time step, and we need . In Ireland for example the following
    identifiers have "AR" present in their first time step:

        from eu_cbm_hat.core.continent import continent
        runner = continent.combos['reference'].runners['IE'][-1]
        # Load pools
        classifiers = runner.output.classif_df
        classifiers["year"] = runner.country.timestep_to_year(classifiers["timestep"])
        index = ["identifier", "timestep"]
        df = runner.output["pools"].merge(classifiers, "left", on=index)
        # Show the first time step of each identifier with AR status
        df["min_timestep"] = df.groupby("identifier")["timestep"].transform(min)
        selector = df["status"].str.contains("AR")
        selector &= df["timestep"] == df["min_timestep"]
        ar_first = df.loc[selector]
        ar_first[["identifier", "timestep", "status", "area", "below_ground_slow_soil"]]

    Aggregate by year, status, region and climate

    TODO: complete this example
    Compute the sink along the status
    Provide an example that Aggregate columns that contains "AR", such as
    ["AR_ForAWS", "AR_ForNAWS"] to a new column called "AR_historical".

        >>> for new_column, columns_to_sum in aggregation_dict.items():
        >>>     df[new_column] = df[columns_to_sum].sum(axis=1)
        >>>     df.drop(columns=columns_to_sum, inplace=True)

    """
    if "year" not in groupby:
        raise ValueError("Year has to be in the group by variables")
    if isinstance(groupby, str):
        groupby = [groupby]
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df_agg = runner.post_processor.sink.df_agg(groupby=groupby)
    df_agg = place_combo_name_and_country_first(df_agg, runner)
    return df_agg

def sink_d_ar_fl_one_country_period(
    combo_name: str,
    iso2_code: str,
    groupby: Union[List[str], str],
):
    """Sum the pools for the given country and add information on the combo
    country code

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_d_ar_fl_one_country_period
        >>> sink = sink_d_ar_fl_one_country_period("reference", "ZZ", groupby=["year", "status"])
    
    """
    if "year" not in groupby:
        raise ValueError("Year has to be in the group by variables")
    if isinstance(groupby, str):
        groupby = [groupby]
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df_agg = runner.post_processor.sink.sink_d_ar_fl_period()
    df_agg = place_combo_name_and_country_first(df_agg, runner)
    return df_agg

def sink_d_ar_fl_one_country_annual(
    combo_name: str,
    iso2_code: str,
    groupby: Union[List[str], str] = None,
):
    """Annual sink by status (D, AR, ForAWS, ForAWS+ForNAWS) for one country.

    Calls runner.post_processor.sink.sink_d_ar_fl_annual which returns
    annual data with a ``year`` column (no period aggregation).

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_d_ar_fl_annual_one_country
        >>> sink_d_ar_fl_annual_one_country("reference", "LU")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.sink.sink_d_ar_fl_annual()
    df = place_combo_name_and_country_first(df, runner)
    return df


def sink_d_ar_fl_all_countries_annual(combo_name: str, groupby: Union[List[str], str] = None):
    """Annual sink by status for all countries, with an EU aggregate row.

    Statuses: D (Deforestation), AR, ForAWS, ForAWS+ForNAWS.
    Uses sink_d_ar_fl_annual which preserves the ``year`` column.

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_d_ar_fl_all_countries_annual
        >>> sink_d_ar_fl_all_countries_annual("reference")

    """
    df_all = apply_to_all_countries(
        sink_d_ar_fl_one_country_annual, combo_name=combo_name
    )

    df_all = df_all[df_all['country'] != 'EU']

    sum_cols = ['living_biomass_sink', 'total_sink', 'total_forest_area']
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    df_eu = (
        df_all.groupby(['year', 'status'], as_index=False)[sum_cols]
        .sum()
    )
    df_eu['country'] = 'EU'
    df_eu['combo_name'] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


def total_sink_by_year_one_country(combo_name: str, iso2_code: str):
    """Annual sink breakdown from runner.post_processor.sink.df_agg_by_year
    for one country.  Renames ``sim_sink`` to ``total_sink``.

        >>> from eu_cbm_hat.post_processor.agg_combos import total_sink_by_year_one_country
        >>> total_sink_by_year_one_country("reference_bnc_nmf", "LU")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.sink.df_agg_by_year.rename(columns={"sim_sink": "total_sink"})
    df = place_combo_name_and_country_first(df, runner)
    return df


def total_sink_by_year_all_countries(combo_name: str):
    """Annual sink breakdown for all countries, with an EU aggregate row.

    Collects ``runner.post_processor.sink.df_agg_by_year`` (``sim_sink``
    renamed to ``total_sink``) for every country, then appends an EU total
    row obtained by summing all member-state values per year.

    Use with :func:`collect_scenarios` to save one parquet file per scenario:

        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     total_sink_by_year_all_countries, collect_scenarios)
        >>> scenarios = ['reference_bnc_nmf', 'reference_low_sink_2050_nmf',
        ...              'reference_high_sink_2050_nmf']
        >>> df = collect_scenarios(
        ...     scenarios,
        ...     total_sink_by_year_all_countries,
        ...     "total_sink_by_year.parquet",
        ... )

    """
    df_all = apply_to_all_countries(total_sink_by_year_one_country, combo_name=combo_name)
    df_all = df_all[df_all["country"] != "EU"]

    sum_cols = [
        "living_biomass_sink", "litter_sink", "dead_wood_sink",
        "mineral_soils_sink", "organic_soils_emissions", "total_sink",
    ]
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    df_eu = df_all.groupby(["year"], as_index=False)[sum_cols].sum()
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


# Simulation package prefixes in longest-first order to avoid prefix collisions
# (e.g. "reference_high_sink_2050" must be tested before "reference_bnc").
_SINK_PACKAGE_PREFIXES = [
    ("reference_high_sink_2050", "reference_high_sink_2050_ref"),
    ("reference_low_sink_2050",  "reference_low_sink_2050_ref"),
    ("reference_bnc",            "reference_bnc_ref"),
]

# Family definitions: (family_label, combo_name_suffix, reference_combo_name).
# Longest suffix first to avoid false matches
# (e.g. "_high_sink_2050_ref" before "_bnc_ref").
_SINK_FAMILIES = [
    ("high_sink_2050", "_high_sink_2050_ref", "reference_high_sink_2050_ref"),
    ("low_sink_2050",  "_low_sink_2050_ref",  "reference_low_sink_2050_ref"),
    ("bnc",            "_bnc_ref",            "reference_bnc_ref"),
]

_SINK_FAMILIES_NMF = [
    ("high_sink_2050", "_high_sink_2050_nmf", "reference_high_sink_2050_nmf"),
    ("low_sink_2050",  "_low_sink_2050_nmf",  "reference_low_sink_2050_nmf"),
    ("bnc",            "_bnc_nmf",            "reference_bnc_nmf"),
]

_SINK_FAMILIES_BY_SUFFIX = {"_ref": _SINK_FAMILIES, "_nmf": _SINK_FAMILIES_NMF}

SCENARIO_LABELS = {
    "max_stock":                  "max_stock_ms",
    "max_rotation":               "max_rotation_reg",
    "min_rotation":               "min_rotation_reg",
    "continous_cover":            "continous_cover_ms",
    "forestpaths_rot+10":         "rot+10_ms",
    "forestpaths_rot-10":         "rot-10_ms",
    "forestpaths_high_thinnings": "high_thinnings_ms",
    "forestpaths_low_thinnings":  "low_thinnings_ms",
}


def eu_ref_sink_2046_2050(df: pandas.DataFrame) -> pandas.DataFrame:
    """EU total sink for *_ref* scenarios, averaged over the 2046-2050 period.

    Filters the all-scenarios sink DataFrame for EU rows, scenario
    combinations whose name ends in ``_ref``, and the 5-year period
    2046-2050.  A ``package`` column identifies which of the three
    simulation bundles (reference_bnc, reference_low_sink_2050,
    reference_high_sink_2050) each _ref scenario belongs to.  The
    5-year period convention matches the rest of this module: periods
    start in 2026 and are labelled "YYYY-YYYY".

    Parameters
    ----------
    df:
        As returned by
        ``read_agg_combo_output(scenarios,
        "total_sink_by_year_all_countries.parquet")``.

    Returns
    -------
    pandas.DataFrame
        Columns: ``combo_name``, ``package``, ``period``, then all sink
        component columns present in *df*, averaged over the five annual
        values in 2046-2050.

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output, eu_ref_sink_2046_2050)
        >>> scenarios = [
        ...     "reference_bnc_ref", "reference_bnc_nmf",
        ...     "reference_low_sink_2050_ref", "reference_low_sink_2050_nmf",
        ...     "reference_high_sink_2050_ref", "reference_high_sink_2050_nmf",
        ... ]
        >>> df = read_agg_combo_output(scenarios, "total_sink_by_year_all_countries.parquet")
        >>> result = eu_ref_sink_2046_2050(df)

    """
    # 1. EU rows for _ref scenarios only
    mask = df["combo_name"].str.endswith("_ref") & (df["country"] == "EU")
    df_eu = df.loc[mask].copy()

    # 2. Assign 5-year period labels (same convention as rest of module)
    df_eu = df_eu[df_eu["year"] >= 2026].copy()
    df_eu["period_start"] = 2026 + 5 * ((df_eu["year"] - 2026) // 5)
    df_eu["period"] = (
        df_eu["period_start"].astype(str) + "-"
        + (df_eu["period_start"] + 4).astype(str)
    )
    df_eu = df_eu.drop(columns=["period_start"])

    # 3. Keep only the 2046-2050 period
    df_eu = df_eu[df_eu["period"] == "2046-2050"]

    # 4. Average the 5 annual values within the period
    sink_cols = [
        "living_biomass_sink", "litter_sink", "dead_wood_sink",
        "mineral_soils_sink", "organic_soils_emissions", "total_sink",
    ]
    sink_cols = [c for c in sink_cols if c in df_eu.columns]
    df_eu = df_eu.groupby(["combo_name", "period"], as_index=False)[sink_cols].mean()

    # 5. Tag each row with its simulation package (longest prefix first)
    def _get_package(name):
        for pkg, _ in _SINK_PACKAGE_PREFIXES:
            if name.startswith(pkg):
                return pkg
        return "other"

    df_eu["package"] = df_eu["combo_name"].map(_get_package)

    cols = ["combo_name", "package", "period"] + sink_cols
    return df_eu[cols].reset_index(drop=True)


def eu_sink_diff_vs_ref_2046_2050(
    df: pandas.DataFrame,
    combo_suffix: str = "_ref",
    region: str = None,
) -> pandas.DataFrame:
    """EU total-sink anomaly (scenario − family reference) for 2046-2050.

    For every scenario combination whose name ends in *combo_suffix*
    (``"_ref"`` or ``"_nmf"``), this function:

    1. Keeps EU rows and years ≥ 2026.
    2. Assigns 5-year period labels (same 2026-anchor convention as the
       rest of the module).
    3. Averages the sink components over the 2046-2050 period.
    4. Detects the simulation family from the combo-name suffix
       (``_bnc_ref``, ``_low_sink_2050_ref``, ``_high_sink_2050_ref``).
    5. Subtracts the family reference value
       (``reference_bnc_ref`` / ``reference_low_sink_2050_ref`` /
       ``reference_high_sink_2050_ref``) to yield signed anomalies.

    The period "2046-2050" aligns with the 5-year windows used across
    this module (first window: 2026-2030, …, last window before 2051:
    2046-2050).

    Parameters
    ----------
    df:
        As returned by
        ``read_agg_combo_output(scenarios,
        "total_sink_by_year_all_countries.parquet")``.

    Returns
    -------
    pandas.DataFrame
        Columns: ``combo_name``, ``base_scenario``, ``family``,
        ``period``, plus one ``*_diff`` column and one ``*_ref`` column
        per sink component present in *df* (same units as the source:
        tCO₂ eq).  ``*_ref`` holds the family reference absolute value
        and enables computing percentage anomalies.  The family reference
        scenario is included with all ``*_diff`` values equal to zero.

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     read_agg_combo_output, eu_sink_diff_vs_ref_2046_2050)
        >>> scenarios = [
        ...     "reference_bnc_ref",
        ...     "max_stock_bnc_ref", "max_rotation_bnc_ref",
        ...     "min_rotation_bnc_ref", "continous_cover_bnc_ref",
        ...     "forestpaths_rot+10_bnc_ref", "forestpaths_rot-10_bnc_ref",
        ...     "forestpaths_high_thinnings_bnc_ref",
        ...     "forestpaths_low_thinnings_bnc_ref",
        ...     "reference_low_sink_2050_ref",
        ...     "max_stock_low_sink_2050_ref", "max_rotation_low_sink_2050_ref",
        ...     "reference_high_sink_2050_ref",
        ...     "max_stock_high_sink_2050_ref", "max_rotation_high_sink_2050_ref",
        ... ]
        >>> df = read_agg_combo_output(scenarios, "total_sink_by_year_all_countries.parquet")
        >>> diff = eu_sink_diff_vs_ref_2046_2050(df)

    """
    families = _SINK_FAMILIES_BY_SUFFIX.get(combo_suffix, _SINK_FAMILIES)

    sink_cols = [
        "living_biomass_sink", "litter_sink", "dead_wood_sink",
        "mineral_soils_sink", "organic_soils_emissions", "total_sink",
    ]
    sink_cols = [c for c in sink_cols if c in df.columns]

    # 1. Select rows: EU aggregate or regional sum over individual countries
    combo_mask = df["combo_name"].str.endswith(combo_suffix)
    if region is None:
        df_eu = df.loc[combo_mask & (df["country"] == "EU")].copy()
    else:
        df_eu = (
            df.loc[combo_mask & df["iso2_code"].isin(regions[region])]
            .groupby(["combo_name", "year"], as_index=False)[sink_cols]
            .sum()
        )

    # 2. Assign 5-year period labels (same convention as rest of module)
    df_eu = df_eu[df_eu["year"] >= 2026].copy()
    df_eu["period_start"] = 2026 + 5 * ((df_eu["year"] - 2026) // 5)
    df_eu["period"] = (
        df_eu["period_start"].astype(str) + "-"
        + (df_eu["period_start"] + 4).astype(str)
    )
    df_eu = df_eu.drop(columns=["period_start"])

    # 3. Keep only the 2046-2050 period
    df_eu = df_eu[df_eu["period"] == "2046-2050"]

    # 4. Average the 5 annual values within the period
    df_eu = df_eu.groupby(["combo_name", "period"], as_index=False)[sink_cols].mean()

    # 5. Detect family and base scenario name from suffix (longest first)
    def _get_family(name):
        for family, suffix, _ in families:
            if name.endswith(suffix):
                return family
        return "other"

    def _get_base(name):
        for _, suffix, _ in families:
            if name.endswith(suffix):
                return name[: -len(suffix)]
        return name

    df_eu["family"] = df_eu["combo_name"].map(_get_family)
    df_eu["base_scenario"] = df_eu["combo_name"].map(_get_base)

    # 6. For each family subtract the family reference values
    rows = []
    for family, _, ref_combo in families:
        df_fam = df_eu[df_eu["family"] == family]
        ref_rows = df_fam[df_fam["combo_name"] == ref_combo]
        if ref_rows.empty:
            continue
        ref_vals = ref_rows[sink_cols].iloc[0]
        for _, row in df_fam.iterrows():
            entry = {
                "combo_name":    row["combo_name"],
                "base_scenario": row["base_scenario"],
                "family":        family,
                "period":        row["period"],
            }
            for col in sink_cols:
                entry[col + "_diff"] = row[col] - ref_vals[col]
                entry[col + "_ref"]  = ref_vals[col]
            rows.append(entry)

    diff_cols = [c + "_diff" for c in sink_cols]
    ref_cols  = [c + "_ref"  for c in sink_cols]
    return pandas.DataFrame(
        rows,
        columns=["combo_name", "base_scenario", "family", "period"] + diff_cols + ref_cols,
    ).reset_index(drop=True)


def eu_harvest_diff_vs_ref_2046_2050(
    df: pandas.DataFrame,
    combo_suffix: str = "_ref",
    region: str = None,
) -> pandas.DataFrame:
    """EU harvest anomaly (scenario − family reference) for 2046-2050.

    Mirrors :func:`eu_sink_diff_vs_ref_2046_2050` but operates on harvest
    volume columns.  The input is expected to already contain EU aggregate
    rows as produced by :func:`harvest_exp_prov_all_countries_eu` via
    :func:`collect_scenarios`.

    For every scenario combination ending in ``_ref`` this function:

    1. Filters for EU rows.
    2. Assigns 5-year period labels (same 2026-anchor convention).
    3. Averages over the 2046-2050 period.
    4. Detects the simulation family from the combo-name suffix.
    5. Subtracts the family reference value to yield signed anomalies.

    Parameters
    ----------
    df:
        As returned by
        ``read_agg_combo_output(scenarios, "hexprov_by_year_all_countries.parquet")``,
        where the parquet was saved with :func:`collect_scenarios` using
        :func:`harvest_exp_prov_all_countries_eu`.

    Returns
    -------
    pandas.DataFrame
        Columns: ``combo_name``, ``base_scenario``, ``family``,
        ``period``, plus one ``*_diff`` column and one ``*_ref`` column
        per harvest component present in *df* (m³ UB / OB).  ``*_ref``
        holds the family reference absolute value and enables computing
        percentage anomalies.  The family reference scenario is included
        with all ``*_diff`` values equal to zero.

    Example
    -------
        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     collect_scenarios, read_agg_combo_output,
        ...     harvest_exp_prov_all_countries_eu,
        ...     eu_harvest_diff_vs_ref_2046_2050)
        >>> from eu_cbm_hat.plot.lulucf_plots import plot_sink_diff_vs_ref
        >>> scenarios = [
        ...     "reference_bnc_ref",
        ...     "max_stock_bnc_ref", "max_rotation_bnc_ref",
        ...     "min_rotation_bnc_ref", "continous_cover_bnc_ref",
        ...     "forestpaths_rot+10_bnc_ref", "forestpaths_rot-10_bnc_ref",
        ...     "forestpaths_high_thinnings_bnc_ref",
        ...     "forestpaths_low_thinnings_bnc_ref",
        ...     # add low_sink_2050 and high_sink_2050 variants as needed
        ... ]
        >>> df = read_agg_combo_output(scenarios, "hexprov_by_year_all_countries.parquet")
        >>> diff = eu_harvest_diff_vs_ref_2046_2050(df)
        >>> fig = plot_sink_diff_vs_ref(diff, y="total_harvest_ub_provided_diff")

    """
    harvest_cols = [
        "total_harvest_ub_provided", "total_harvest_ob_provided",
        "irw_harvest_prov_ub", "fw_harvest_prov_ub",
        "irw_demand", "fw_demand", "rw_demand",
    ]
    harvest_cols = [c for c in harvest_cols if c in df.columns]

    families = _SINK_FAMILIES_BY_SUFFIX.get(combo_suffix, _SINK_FAMILIES)

    # 1. Select rows: EU aggregate or regional sum over individual countries
    combo_mask = df["combo_name"].str.endswith(combo_suffix)
    if region is None:
        df_eu = df.loc[combo_mask & (df["country"] == "EU")].copy()
    else:
        df_eu = (
            df.loc[combo_mask & df["iso2_code"].isin(regions[region])]
            .groupby(["combo_name", "year"], as_index=False)[harvest_cols]
            .sum()
        )

    # 2. Assign 5-year period labels (same convention as rest of module)
    df_eu = df_eu[df_eu["year"] >= 2026].copy()
    df_eu["period_start"] = 2026 + 5 * ((df_eu["year"] - 2026) // 5)
    df_eu["period"] = (
        df_eu["period_start"].astype(str) + "-"
        + (df_eu["period_start"] + 4).astype(str)
    )
    df_eu = df_eu.drop(columns=["period_start"])

    # 3. Keep only the 2046-2050 period
    df_eu = df_eu[df_eu["period"] == "2046-2050"]

    # 4. Average the 5 annual values within the period
    df_eu = df_eu.groupby(["combo_name", "period"], as_index=False)[harvest_cols].mean()

    # 5. Detect family and base scenario name from suffix (longest first)
    def _get_family(name):
        for family, suffix, _ in families:
            if name.endswith(suffix):
                return family
        return "other"

    def _get_base(name):
        for _, suffix, _ in families:
            if name.endswith(suffix):
                return name[: -len(suffix)]
        return name

    df_eu["family"] = df_eu["combo_name"].map(_get_family)
    df_eu["base_scenario"] = df_eu["combo_name"].map(_get_base)

    # 6. For each family subtract the family reference values
    rows = []
    for family, _, ref_combo in families:
        df_fam = df_eu[df_eu["family"] == family]
        ref_rows = df_fam[df_fam["combo_name"] == ref_combo]
        if ref_rows.empty:
            continue
        ref_vals = ref_rows[harvest_cols].iloc[0]
        for _, row in df_fam.iterrows():
            entry = {
                "combo_name":    row["combo_name"],
                "base_scenario": row["base_scenario"],
                "family":        family,
                "period":        row["period"],
            }
            for col in harvest_cols:
                entry[col + "_diff"] = row[col] - ref_vals[col]
                entry[col + "_ref"]  = ref_vals[col]
            rows.append(entry)

    diff_cols = [c + "_diff" for c in harvest_cols]
    ref_cols  = [c + "_ref"  for c in harvest_cols]
    return pandas.DataFrame(
        rows,
        columns=["combo_name", "base_scenario", "family", "period"] + diff_cols + ref_cols,
    ).reset_index(drop=True)


def sink_d_ar_fl_all_countries_period(combo_name: str, groupby: Union[List[str], str] = None):
    """
    sink on status in wide format for all countries in the given scenario
    combination.
    """
    if groupby is None:
        groupby = ["year", "status"]
    df_all = apply_to_all_countries(
        sink_d_ar_fl_one_country_period, combo_name=combo_name, groupby=groupby
    )

    # Remove possible pre‑existing EU rows
    df_all = df_all[df_all['country'] != 'EU']

    # --------------------------------------------------------------
    #  Use the *period* column (not year) for the EU aggregation
    # --------------------------------------------------------------
    df_eu = (
            df_all.groupby(["period", "status"])
            .apply(
                lambda x: pandas.Series(
                    {
                        "country": "EU",
                        "living_biomass_sink": x["living_biomass_sink"].sum(),
                        "total_sink": x["total_sink"].sum(),
                        # ``deforestation_emission`` may have been dropped in step 7;
                        # use .get() to avoid a KeyError.
                        #"deforestation_emission": x.get("deforestation_emission", 0).sum(),
                    }
                )
            )
            .reset_index()
        )


    df_eu["combo_name"] = combo_name

    # Concatenate the original DataFrame with the new EU row
    df_eu["combo_name"] = combo_name
    df_all = pandas.concat([df_all, df_eu], ignore_index=True)
    return df_all

def harvest_vol_d_ar_fl_one_country(
    combo_name: str,
    iso2_code: str,
):
    """Harvest provided by status for one country.

    Calls runner.post_processor.harvest.provided_vol_d_ar_fl, which returns
    harvest volume (total_harvest_ub_provided) grouped by year, status,
    con_broad and silv_practice.  Statuses present in the output are:
    D, AR, ForAWS, ForAWS+ForNAWS.

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_vol_d_ar_fl_one_country
        >>> harvest_vol_d_ar_fl_one_country("reference", "LU")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.harvest.provided_vol_d_ar_fl
    df = place_combo_name_and_country_first(df, runner)
    return df

def harvest_vol_d_ar_fl_all_countries_annual(combo_name: str):
    """Harvest provided by status for all countries, annual time step.

    Statuses: D, AR, ForAWS, ForAWS+ForNAWS.
    An EU aggregate row (sum over all member states) is appended for each
    year × status combination.

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_vol_d_ar_fl_all_countries_annual
        >>> harvest_vol_d_ar_fl_all_countries_annual("reference")

    """
    df_all = apply_to_all_countries(
        harvest_vol_d_ar_fl_one_country, combo_name=combo_name
    )

    # Remove possible pre-existing EU rows
    df_all = df_all[df_all['country'] != 'EU']

    # Build EU aggregate: sum harvest volume by year and status
    df_eu = (
        df_all.groupby(['year', 'status'])
        .apply(
            lambda x: pandas.Series({
                'country': 'EU',
                'total_harvest_ub_provided': x['total_harvest_ub_provided'].sum(),
            })
        )
        .reset_index()
    )
    df_eu['combo_name'] = combo_name

    df_all = pandas.concat([df_all, df_eu], ignore_index=True)
    return df_all

def harvest_vol_d_ar_fl_all_countries_period(combo_name: str):
    """Harvest provided by status for all countries, aggregated by period.

    Statuses: D, AR, ForAWS, ForAWS+ForNAWS.
    5-year periods starting in 2026 are computed from the year column
    (same convention as sink_d_ar_fl).  Annual values are averaged within
    each country × status × period, then an EU aggregate row (sum over all
    member states) is appended for each period × status combination.

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_vol_d_ar_fl_all_countries_period
        >>> harvest_vol_d_ar_fl_all_countries_period("reference")

    """
    df_all = apply_to_all_countries(
        harvest_vol_d_ar_fl_one_country, combo_name=combo_name
    )

    # Remove possible pre-existing EU rows
    df_all = df_all[df_all['country'] != 'EU']

    # Build 5-year period labels (matching the convention in sink_d_ar_fl)
    df_all = df_all[df_all['year'] >= 2026]
    df_all['period_start'] = 2026 + 5 * ((df_all['year'] - 2026) // 5)
    df_all['period'] = (
        df_all['period_start'].astype(str) + '-' +
        (df_all['period_start'] + 4).astype(str)
    )
    df_all = df_all.drop(columns=['period_start'])

    # Average annual harvest within each country × status × period
    group_cols = ['combo_name', 'iso2_code', 'country', 'period', 'status']
    df_all = (
        df_all.groupby(group_cols, as_index=False)[['total_harvest_ub_provided']]
        .mean()
    )

    # Build EU aggregate: sum member-state means by period and status
    df_eu = (
        df_all.groupby(['period', 'status'], as_index=False)[['total_harvest_ub_provided']]
        .sum()
    )
    df_eu['country'] = 'EU'
    df_eu['combo_name'] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)

# ---------------------------------------------------------------------------
# Regional groupings of EU member states.
# Commented-out alternatives are kept for reference.
# ---------------------------------------------------------------------------
regions = {
    'Southern': ['GR', 'HR', 'SI', 'IT', 'ES', 'PT'],
    'Central_East': ['AT', 'BG','CZ', 'HU', 'PL', 'RO', 'SK'],
    'Western': ['BE', 'DE', 'DK', 'NL', 'LU', 'FR', 'IR'],
    'Northern':  ['FI', 'SE', 'LT', 'LV', 'EE'],
    # 'East':    ['BG', 'HU', 'HR', 'SI', 'RO', 'PL'],
    # 'Central': ['AT', 'BE', 'CZ', 'DE', 'FR', 'IR', 'NL', 'SK', 'LU'],
    # 'North':   ['DK', 'EE', 'FI', 'SE', 'LT', 'LV'],
    # 'South':   ['IT', 'ES', 'PT', 'GR'],
}

# Flat lookup: iso2_code → region name
_iso_to_region = {iso: region for region, isos in regions.items() for iso in isos}

def sink_d_ar_fl_by_region_annual(combo_name: str):
    """Sink by status for all countries plus regional aggregates, annual time step.

    Statuses: D (Deforestation), AR, ForAWS, ForAWS+ForNAWS.
    One aggregate row per region × year × status is appended to the
    individual-country rows.  Regions are defined by the module-level
    ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_d_ar_fl_by_region_annual
        >>> sink_d_ar_fl_by_region_annual("reference")

    """
    df_all = apply_to_all_countries(
        sink_d_ar_fl_one_country_annual, combo_name=combo_name, groupby=["year", "status"]
    )
    df_all = df_all[df_all['country'] != 'EU']

    # Tag each row with its region (NaN for countries not in any region)
    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    sum_cols = ['total_forest_area', 'living_biomass_sink', 'total_sink', 'deforestation_emission']
    # Keep only columns that actually exist (sink_d_ar_fl drops deforestation_emission in step 7)
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['year', 'status', 'eu_region'], as_index=False)[sum_cols]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)

def sink_d_ar_fl_by_region_period(combo_name: str):
    """Sink by status for all countries plus regional aggregates, aggregated by period.

    Statuses: D (Deforestation), AR, ForAWS, ForAWS+ForNAWS.
    One aggregate row per region × period × status is appended to the
    individual-country rows.  Regions are defined by the module-level
    ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import sink_d_ar_fl_by_region_period
        >>> sink_d_ar_fl_by_region_period("reference")

    """
    df_all = apply_to_all_countries(
        sink_d_ar_fl_one_country_period, combo_name=combo_name, groupby=["year", "status"]
    )
    df_all = df_all[df_all['country'] != 'EU']

    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    sum_cols = ['living_biomass_sink', 'total_sink', 'deforestation_emission']
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['period', 'status', 'eu_region'], as_index=False)[sum_cols]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)

def harvest_vol_d_ar_fl_by_region_annual(combo_name: str):
    """Harvest provided by status for all countries plus regional aggregates, annual time step.

    Statuses: D, AR, ForAWS, ForAWS+ForNAWS.
    One aggregate row per region × year × status is appended to the
    individual-country rows.  Regions are defined by the module-level
    ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_vol_d_ar_fl_by_region_annual
        >>> harvest_vol_d_ar_fl_by_region_annual("reference")

    """
    df_all = apply_to_all_countries(
        harvest_vol_d_ar_fl_one_country, combo_name=combo_name
    )
    df_all = df_all[df_all['country'] != 'EU']

    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['year', 'status', 'eu_region'], as_index=False)[['total_harvest_ub_provided']]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def harvest_vol_d_ar_fl_by_region_period(combo_name: str):
    """Harvest provided by status for all countries plus regional aggregates, aggregated by period.

    Statuses: D, AR, ForAWS, ForAWS+ForNAWS.
    5-year periods starting in 2026 are computed from the year column
    (same convention as sink_d_ar_fl).  Annual values are averaged within
    each country × status × period, then one regional aggregate row
    (sum of member-state means) per region × period × status is appended.
    Regions are defined by the module-level ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_vol_d_ar_fl_by_region_period
        >>> harvest_vol_d_ar_fl_by_region_period("reference")

    """
    df_all = apply_to_all_countries(
        harvest_vol_d_ar_fl_one_country, combo_name=combo_name
    )
    df_all = df_all[df_all['country'] != 'EU']

    # Build 5-year period labels
    df_all = df_all[df_all['year'] >= 2026]
    df_all['period_start'] = 2026 + 5 * ((df_all['year'] - 2026) // 5)
    df_all['period'] = (
        df_all['period_start'].astype(str) + '-' +
        (df_all['period_start'] + 4).astype(str)
    )
    df_all = df_all.drop(columns=['period_start'])

    # Average annual harvest within each country × status × period
    group_cols = ['combo_name', 'iso2_code', 'country', 'period', 'status']
    df_all = (
        df_all.groupby(group_cols, as_index=False)[['total_harvest_ub_provided']]
        .mean()
    )

    # Tag each row with its region
    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    # Build regional aggregates: sum member-state means by region × period × status
    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['period', 'status', 'eu_region'], as_index=False)[['total_harvest_ub_provided']]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)

def area_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """area provided in one country

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import area_one_country
        >>> area_one_country("reference", "ZZ", ["year", 'status', "forest_type", "age","disturbance_type"])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df_agg = runner.post_processor.area.df_agg(groupby)
    df_agg = place_combo_name_and_country_first(df_agg, runner)
    return df_agg

def area_by_status_one_country(combo_name: str, iso2_code: str):
    """Area in wide format with one column for each status.

    This table describes the movement from non forested to forested areas.
    Afforestation and deforestation influence the changes in area. Total area
    remains the same.

    Usage:

        >>> from eu_cbm_hat.post_processor.area import area_by_status_one_country
        >>> from eu_cbm_hat.post_processor.area import apply_to_all_countries
        >>> area_by_status_one_country("reference", "ZZ")
        >>> ast_ie = area_by_status_one_country("reference", "IE")
        >>> # Load data for all countries
        >>> ast = apply_to_all_countries(area_by_status_one_country, combo_name="reference")
        >>> # Place total area column last
        >>> cols = list(ast.columns)
        >>> cols.remove("total_area")
        >>> cols += ["total_area"]
        >>> ast = ast[cols]

    """
    groupby = ["year", "status", "disturbance_type"]
    df = area_one_country(combo_name=combo_name, iso2_code=iso2_code, groupby=groupby)
    # Change disturbance deforestation to status D
    selector = df["disturbance_type"] == 7
    df.loc[selector, "status"] = "D"
    # Aggregate
    index = ["year", "status"]
    df = df.groupby(index)["area"].agg("sum").reset_index()
    # Pivot to wide format
    df_wide = df.pivot(index="year", columns="status", values="area")
    # Add the total area
    df_wide["total_area"] = df_wide.sum(axis=1)
    df_wide.reset_index(inplace=True)
    # Remove the sometimes confusing axis name
    df_wide.rename_axis(columns=None, inplace=True)
    # Place combo name, country code as first columns
    df_wide["combo_name"] = combo_name
    df_wide["iso2_code"] = iso2_code
    cols = list(df_wide.columns)
    cols = cols[-2:] + cols[:-2]
    return df_wide[cols]


def area_by_age_class_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Area in wide format with one column for ageclass.
        from eu_cbm_hat.post_processor.area import aarea_by_age_class_one_country
        area_by_age_class_one_country("reference", ["year", "status", "con_broad", "disturbance_type"])
    """
    groupby = ["year", "status", "age_class"]
    df = area_one_country(combo_name=combo_name, iso2_code=iso2_code, groupby=groupby)
    df=df[['combo_name', 'iso2_code', 'country', 'year', 'age_class', 'area']]
    return df

def area_by_age_class_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """NAI area by status in wide format for all countries in the given scenario combination.

    >>> from eu_cbm_hat.post_processor.area import area_by_age_class_all_countries
    >>> area_by_age_class_all_countries("reference", ["year", "status", "con_broad", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        area_by_age_class_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all

def area_by_status_selected_years_one_country(combo_name: str, iso2_code: str):
    """Area aggregated by year and status for one country, filtered to 2020,
    2030 and 2050, with bare 'NF' status excluded.

    For statuses starting with 'NF_' (e.g. NF_ForAWS, NF_ForNAWS), the annual
    flow is replaced with the cumulative sum starting from 2021 (the year after
    the base year 2020).  This means 2020 = 0 (baseline, no deforestation
    counted yet), 2030 = total area deforested 2021–2030, and 2050 = total area
    deforested 2021–2050.  Any pre-2020 historical NF_ flows are intentionally
    excluded.

    Calls ``runner.post_processor.area.df_agg(["year", "status"])`` and
    keeps only the ``area`` column alongside the index columns.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import area_by_status_selected_years_one_country
        >>> area_by_status_selected_years_one_country("reference_bnc_nmf", "LU")

    """
    SELECTED_YEARS = [2020, 2030, 2050]
    BASE_YEAR = min(SELECTED_YEARS)  # 2020 — deforestation accumulates from BASE_YEAR+1

    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.area.df_agg(["year", "status"])
    df = df[df["status"] != "NF"].copy()

    # NF_ statuses report area deforested in each individual year.
    # Accumulate from BASE_YEAR+1 only, so BASE_YEAR shows zero (no prior
    # deforestation counted) and subsequent years carry the running total.
    nf_mask = df["status"].str.startswith("NF_")
    if nf_mask.any():
        df_nf = (
            df[nf_mask & (df["year"] > BASE_YEAR)]
            .sort_values("year")
            .copy()
        )
        df_nf["area"] = df_nf.groupby("status")["area"].cumsum()
        df = pandas.concat([df[~nf_mask], df_nf], ignore_index=True)

    df = df[df["year"].isin(SELECTED_YEARS)][["year", "status", "area"]]
    df = place_combo_name_and_country_first(df, runner)
    return df


def area_by_status_all_countries(combo_name: str):
    """Area by status for 2020, 2030 and 2050, all countries + EU aggregate.

    Collects ``area_by_status_selected_years_one_country`` for every country,
    excludes 'NF', then appends an EU total row obtained by summing ``area``
    per (year, status) across all member states.

    Use with :func:`collect_scenarios` to save one parquet file per scenario:

        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     area_by_status_all_countries, collect_scenarios)
        >>> scenarios = ['reference_bnc_nmf', 'reference_low_sink_2050_nmf',
        ...              'reference_high_sink_2050_nmf']
        >>> df = collect_scenarios(
        ...     scenarios,
        ...     area_by_status_all_countries,
        ...     "area_by_status_all_countries.parquet",
        ... )

    """
    df_all = apply_to_all_countries(
        area_by_status_selected_years_one_country, combo_name=combo_name
    )
    df_all = df_all[df_all["country"] != "EU"]

    df_eu = (
        df_all.groupby(["year", "status"], as_index=False)["area"].sum()
    )
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


def nd_harvest_one_country(combo_name: str, iso2_code: str):
    """Natural-disturbance harvest by silvicultural group for one country.

    Calls ``runner.post_processor.nd.nd_harvest``, which returns harvest
    volume grouped by ``year`` and ``silv_practice``
    (thinnings, final_cut, salvage, wildfire).

        >>> from eu_cbm_hat.post_processor.agg_combos import nd_harvest_one_country
        >>> nd_harvest_one_country("reference_bnc_nmf", "LU")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.nd.nd_harvest
    df = place_combo_name_and_country_first(df, runner)
    return df


def nd_harvest_all_countries_period(combo_name: str):
    """Natural-disturbance harvest by silvicultural group for all countries,
    aggregated to 5-year period averages.

    5-year periods starting in 2026 follow the same convention used for
    sink and harvest (``period_start = 2026 + 5 * ((year - 2026) // 5)``).
    Annual values are averaged within each country × silv_practice × period,
    then an EU aggregate row (sum of member-state means) is appended for each
    period × silv_practice combination.

    Value columns: ``total_harvest_ub_provided`` (m³ u.b.),
    ``total_harvest_ob_provided`` (m³ o.b.), ``area`` (ha).

    Use with :func:`collect_scenarios` to save one parquet file per scenario:

        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     nd_harvest_all_countries_period, collect_scenarios)
        >>> scenarios = ['reference_bnc_nmf', 'reference_low_sink_2050_nmf',
        ...              'reference_high_sink_2050_nmf']
        >>> df = collect_scenarios(
        ...     scenarios,
        ...     nd_harvest_all_countries_period,
        ...     "nd_harvest_all_countries_period.parquet",
        ... )

    """
    df_all = apply_to_all_countries(
        nd_harvest_one_country, combo_name=combo_name
    )

    # Remove possible pre-existing EU rows
    df_all = df_all[df_all["country"] != "EU"]

    # Build 5-year period labels (matching the convention in sink_d_ar_fl)
    df_all = df_all[df_all["year"] >= 2026].copy()
    df_all["period_start"] = 2026 + 5 * ((df_all["year"] - 2026) // 5)
    df_all["period"] = (
        df_all["period_start"].astype(str) + "-" +
        (df_all["period_start"] + 4).astype(str)
    )
    df_all = df_all.drop(columns=["period_start"])

    # Annual average within each country × silv_practice × period
    harvest_cols = ["total_harvest_ub_provided", "total_harvest_ob_provided", "area"]
    group_cols = ["combo_name", "iso2_code", "country", "period", "silv_practice"]
    df_all = (
        df_all.groupby(group_cols, as_index=False)[harvest_cols]
        .mean()
    )

    # EU aggregate: sum member-state means by period and silv_practice
    df_eu = (
        df_all.groupby(["period", "silv_practice"], as_index=False)[harvest_cols]
        .sum()
    )
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


def share_thinn_final_cut(combo_name: str, iso2_code: str):
    """Area in wide format with one column for each status.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import share_thinn_final_cut
        >>> hare_thinn_final_cut("reference", "LU")

    """
    groupby = ['year', 'con_broad', 'silv_practice']
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df_shares = runner.post_processor.harvest.provided_shares
    df_shares ["scenario"] = runner.combo.short_name
    df_shares ["region"] = runner.country.country_name
    return df_shares

""
def harvest_area_by_dist_one_country(combo_name: str, iso2_code: str):
    """Area in wide format with one column for each status.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_area_by_dist_one_country
        >>> harvest_area_by_dist_one_country("reference", "LU")

    """
    groupby = ["year", "disturbance_type", "disturbance"]
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.harvest.area_agg(groupby=groupby)
    df = place_combo_name_and_country_first(df, runner)
    return df


def nai_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Net Annual Increment data by status and forest type

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_one_country
        >>> nai_one_country("reference", "LU", ["status"])
        >>> nai_one_country("reference", "LU", ["status", "forest_type"])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.nai.df_agg(groupby=groupby)
    df = place_combo_name_and_country_first(df, runner)
    return df


def nai_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """NAI area by status in wide format for all countries in the given scenario combination.

    >>> from eu_cbm_hat.post_processor.agg_combos import nai_all_countries
    >>> nai_all_countries("reference", ["year", "status", "con_broad", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        nai_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all

def nai_con_broad_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Net Annual Increment data by status and con_broad

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_one_country
        >>> nai_one_country("reference", "LU", ["status"])
        >>> nai_one_country("reference", "LU", ["status", "forest_type"])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.nai.df_agg_con_broad(groupby=groupby)
    df = place_combo_name_and_country_first(df, runner)
    return df

def nai_con_broad_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """NAI area by status in wide format for all countries in the given scenario combination.

    >>> from eu_cbm_hat.post_processor.area import nai_all_countries
    >>> nai_all_countries("reference", ["year", "status", "con_broad", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        nai_con_broad_one_country, combo_name=combo_name, groupby=groupby
    )
    cols_to_keep = ['combo_name', 'country', 'year', 'status', 'con_broad',
       'area', 'nai_merch', 'gai_merch','nai_agb', 'gai_agb', 'nai_merch_ha', 'gai_merch_ha', 'nai_agb_ha','gai_agb_ha']
    df_all = df_all[cols_to_keep]
    return df_all

def weighted_nai_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Net Annual Increment data weighted by status

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import weighted_nai_one_country
        >>> weighted_nai_one_country("reference", "LU", ["status"])
        >>> weighted_nai_one_country("reference", "LU", ["status", "forest_type"])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.nai.df_agg(groupby=groupby)
    df = place_combo_name_and_country_first(df, runner)
    
    # exclude NF lands
    df = df[~df['status'].str.contains('NF')]

    # Calculate the weighted values for nai_merch_ha and gai_merch_ha by multiplying by area
    df['weighted_merch_nai'] = df['nai_merch_ha'] * df['area']
    df['weighted_merch_gai'] = df['gai_merch_ha'] * df['area']
    df['weighted_agb_nai'] = df['nai_agb_ha'] * df['area']
    df['weighted_agb_gai'] = df['gai_agb_ha'] * df['area']
    

    # Group by the necessary columns and sum the weighted values and the area
    grouped = df.groupby(['country', 'year']).agg(
        total_weighted_nai_merch=('weighted_merch_nai', 'sum'),
        total_weighted_gai_merch=('weighted_merch_gai', 'sum'),
        total_weighted_nai_agb=('weighted_agb_nai', 'sum'),
        total_weighted_gai_agb=('weighted_agb_gai', 'sum'),
        total_area=('area', 'sum')
    ).reset_index()
    
    # Calculate the weighted averages
    grouped['nai_merch_ha'] = grouped['total_weighted_nai_merch'] / grouped['total_area']
    grouped['gai_merch_ha'] = grouped['total_weighted_gai_merch'] / grouped['total_area']
    grouped['nai_agb_ha'] = grouped['total_weighted_nai_agb'] / grouped['total_area']
    grouped['gai_agb_ha'] = grouped['total_weighted_gai_agb'] / grouped['total_area']

    grouped = grouped.rename(columns = {'total_area':'area', 'total_weighted_nai_merch':'nai_merch', 'total_weighted_gai_merch':'gai_merch',
                                       'total_weighted_nai_agb':'nai_agb', 'total_weighted_gai_agb':'gai_agb'})
    grouped['combo_name'] = combo_name
    
    # Select the relevant columns for the final output
    final_df = grouped[['combo_name','country', 'year', 'area', 'nai_merch', 'gai_merch',
                       'nai_agb', 'gai_agb', 'nai_merch_ha', 'gai_merch_ha', 
                        'nai_agb_ha', 'gai_agb_ha']]
    return final_df

def nai_all_countries_weighted_nai_eu(combo_name: str, groupby: Union[List[str], str]):
    """
    This function nai for all countries and EU, 
    calculates the sums and weighted averages for the 'eu' iso2_code.
    """
    
    df_all = apply_to_all_countries(
        weighted_nai_one_country, combo_name=combo_name, groupby=groupby
    )
    
    # Filter out the 'eu' code if it already exists
    df_all = df_all[df_all['country'] != 'EU']
    
    # Group by year and calculate the sums and weighted averages
    df_eu = df_all.groupby('year').apply(
        lambda x: pandas.Series({
            'country': 'EU',
            'combo_name': combo_name,
            #'status': '',  # You can set this to any value you want
            'area': x['area'].sum(),
            'nai_merch': x['nai_merch'].sum(),
            'gai_merch': x['gai_merch'].sum(),
            'nai_agb': x['nai_agb'].sum(),
            'gai_agb': x['gai_agb'].sum(),
            'nai_merch_ha': (x['nai_merch_ha'] * x['area']).sum() / x['area'].sum(),
            'gai_merch_ha': (x['gai_merch_ha'] * x['area']).sum() / x['area'].sum(),
            'nai_agb_ha': (x['nai_agb_ha'] * x['area']).sum() / x['area'].sum(),
            'gai_agb_ha': (x['gai_agb_ha'] * x['area']).sum() / x['area'].sum()
        })
    ).reset_index()
    
    # Reset the index to create a new column for the year
    df_eu = df_eu.rename(columns={'index': 'year'})
    
    # Concatenate the original DataFrame with the new 'eu' DataFrame
    df_all = pandas.concat([df_all, df_eu], ignore_index=True)

    return df_all


def nai_all_countries_eu(combo_name: str) -> pandas.DataFrame:
    """NAI and GAI totals and forest area aggregated by year for all countries plus an EU row.

    Per-status rows from :func:`nai_one_country` are summed to a single annual
    total per country.  The EU row is the sum across all countries for each year.
    Per-hectare values (``*_ha``) are re-derived from the summed totals and area.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_all_countries_eu
        >>> nai_all_countries_eu("reference")

    """
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_all = apply_to_all_countries(nai_one_country, combo_name=combo_name, groupby=["status"])
    df_all = df_all[df_all["country"] != "EU"]

    # Sum across statuses → one row per (country, year)
    df_country = (
        df_all.groupby(["combo_name", "country", "year"])[sum_cols]
        .sum()
        .reset_index()
    )

    # EU aggregate: sum all countries per year
    df_eu = (
        df_country.groupby("year")[sum_cols]
        .sum()
        .reset_index()
    )
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name

    df_out = pandas.concat([df_country, df_eu], ignore_index=True)

    # Re-derive per-hectare values from summed totals
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_out[col + "_ha"] = df_out[col] / df_out["area"]

    return df_out


def nai_by_region(combo_name: str) -> pandas.DataFrame:
    """NAI and GAI totals and forest area aggregated by year, for all countries
    plus one aggregate row per EU region.

    Per-status rows from :func:`nai_one_country` are summed to a single annual
    total per country first.  Regional rows are then the sum of countries
    belonging to each region (see module-level ``regions`` dictionary).
    Per-hectare values (``*_ha``) are re-derived from the summed totals and area.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_by_region
        >>> nai_by_region("reference")

    """
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_all = apply_to_all_countries(nai_one_country, combo_name=combo_name, groupby=["status"])
    df_all = df_all[df_all["country"] != "EU"]

    # Collapse statuses → one row per (country, year)
    df_country = (
        df_all.groupby(["combo_name", "iso2_code", "country", "year"])[sum_cols]
        .sum()
        .reset_index()
    )
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_country[col + "_ha"] = df_country[col] / df_country["area"]

    # Tag each country row with its region
    df_country["eu_region"] = df_country["iso2_code"].map(_iso_to_region)

    # Regional aggregates: sum across countries within each (year, region)
    df_reg = (
        df_country.dropna(subset=["eu_region"])
        .groupby(["year", "eu_region"])[sum_cols]
        .sum()
        .reset_index()
        .rename(columns={"eu_region": "country"})
    )
    df_reg["combo_name"] = combo_name
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_reg[col + "_ha"] = df_reg[col] / df_reg["area"]

    return pandas.concat([df_country, df_reg], ignore_index=True)


def _nai_country_period_means(combo_name: str) -> pandas.DataFrame:
    """Internal helper: per-country annual totals averaged over 5-yr periods from 2026."""
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_all = apply_to_all_countries(nai_one_country, combo_name=combo_name, groupby=["status"])
    df_all = df_all[df_all["country"] != "EU"]

    # Collapse statuses → annual total per country
    df_country = (
        df_all.groupby(["combo_name", "iso2_code", "country", "year"])[sum_cols]
        .sum()
        .reset_index()
    )

    # Filter to projection period and build 5-year period labels
    df_country = df_country[df_country["year"] >= 2026].copy()
    df_country["period_start"] = 2026 + 5 * ((df_country["year"] - 2026) // 5)
    df_country["period"] = (
        df_country["period_start"].astype(str) + "-" +
        (df_country["period_start"] + 4).astype(str)
    )
    df_country = df_country.drop(columns=["period_start", "year"])

    # Annual average within each (country, period)
    df_country = df_country.groupby(
        ["combo_name", "iso2_code", "country", "period"], as_index=False
    )[sum_cols].mean()

    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_country[col + "_ha"] = df_country[col] / df_country["area"]

    return df_country


def nai_eu_period(combo_name: str) -> pandas.DataFrame:
    """NAI and GAI annual averages over 5-year periods starting 2026, for all
    countries plus an EU aggregate row.

    Per-status rows are summed to annual country totals, then averaged within
    each 5-year period.  The EU row is the sum of country means per period.
    Per-hectare values are re-derived from the averaged totals.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_eu_period
        >>> nai_eu_period("reference")

    """
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_country = _nai_country_period_means(combo_name)

    df_eu = df_country.groupby("period", as_index=False)[sum_cols].sum()
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_eu[col + "_ha"] = df_eu[col] / df_eu["area"]

    return pandas.concat([df_country, df_eu], ignore_index=True)


def _nai_country_period_means_with_status(combo_name: str) -> pandas.DataFrame:
    """Like _nai_country_period_means but retains the status column throughout."""
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_all = apply_to_all_countries(nai_one_country, combo_name=combo_name, groupby=["status"])
    df_all = df_all[df_all["country"] != "EU"]

    df_all = df_all[df_all["year"] >= 2026].copy()
    df_all["period_start"] = 2026 + 5 * ((df_all["year"] - 2026) // 5)
    df_all["period"] = (
        df_all["period_start"].astype(str) + "-" +
        (df_all["period_start"] + 4).astype(str)
    )
    df_all = df_all.drop(columns=["period_start", "year"])

    df_country = df_all.groupby(
        ["combo_name", "iso2_code", "country", "status", "period"], as_index=False
    )[sum_cols].mean()

    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_country[col + "_ha"] = df_country[col] / df_country["area"]

    return df_country


def nai_eu_period_with_status(combo_name: str) -> pandas.DataFrame:
    """NAI/GAI period means for all countries plus EU total, retaining status.

    Like :func:`nai_eu_period` but keeps the ``status`` column (ForAWS,
    ForNAWS, …) so results can be filtered to a single forest status.

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_eu_period_with_status
        >>> nai_eu_period_with_status("reference_bnc_nmf")

    """
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_country = _nai_country_period_means_with_status(combo_name)

    df_eu = df_country.groupby(["status", "period"], as_index=False)[sum_cols].sum()
    df_eu["country"] = "EU"
    df_eu["combo_name"] = combo_name
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_eu[col + "_ha"] = df_eu[col] / df_eu["area"]

    return pandas.concat([df_country, df_eu], ignore_index=True)


def collect_nai_eu_period_with_status(
    combo_names: list,
    file_name: str = "nai_eu_period_status.parquet",
) -> pandas.DataFrame:
    """Collect NAI/GAI period means retaining the status column.

    Like calling ``collect_scenarios(combo_names, nai_eu_period)`` but the
    resulting parquet includes a ``status`` column so figures and tables can
    be filtered to ForAWS, ForNAWS, etc.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_nai_eu_period_with_status
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_nai_eu_period_with_status(scenarios)

    """
    return collect_scenarios(combo_names, nai_eu_period_with_status, file_name)


def nai_by_region_period(combo_name: str) -> pandas.DataFrame:
    """NAI and GAI annual averages over 5-year periods starting 2026, for all
    countries plus one aggregate row per EU region.

    Per-status rows are summed to annual country totals, then averaged within
    each 5-year period.  Regional rows are the sum of member-state means per
    region × period.  Regions are defined by the module-level ``regions`` dictionary.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_by_region_period
        >>> nai_by_region_period("reference")

    """
    sum_cols = ["area", "nai_merch", "gai_merch", "nai_agb", "gai_agb"]

    df_country = _nai_country_period_means(combo_name)
    df_country["eu_region"] = df_country["iso2_code"].map(_iso_to_region)

    df_reg = (
        df_country.dropna(subset=["eu_region"])
        .groupby(["period", "eu_region"], as_index=False)[sum_cols]
        .sum()
        .rename(columns={"eu_region": "country"})
    )
    df_reg["combo_name"] = combo_name
    for col in ["nai_merch", "gai_merch", "nai_agb", "gai_agb"]:
        df_reg[col + "_ha"] = df_reg[col] / df_reg["area"]

    return pandas.concat([df_country, df_reg], ignore_index=True)


def weighted_nai_con_broad_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Net Annual Increment data weighted by status

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import nai_one_country
        >>> nai_one_country("reference", "LU", ["status"])
        >>> nai_one_country("reference", "LU", ["status", "forest_type"])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.nai.df_agg_con_broad(groupby=groupby)
    df = place_combo_name_and_country_first(df, runner)
    # Calculate the weighted values for nai_merch_ha and gai_merch_ha by multiplying by area
    df['weighted_nai'] = df['nai_merch_ha'] * df['area']
    df['weighted_gai'] = df['gai_merch_ha'] * df['area']
    
    # Group by the necessary columns and sum the weighted values and the area
    grouped = df.groupby(['country', 'year', 'con_broad']).agg(
        total_weighted_nai=('weighted_nai', 'sum'),
        total_weighted_gai=('weighted_gai', 'sum'),
        total_area=('area', 'sum')
    ).reset_index()
    
    # Calculate the weighted averages
    grouped['avg_nai_merch_ha'] = grouped['total_weighted_nai'] / grouped['total_area']
    grouped['avg_gai_merch_ha'] = grouped['total_weighted_gai'] / grouped['total_area']
    
    # Select the relevant columns for the final output
    final_df = grouped[['country', 'year', 'con_broad', 'avg_nai_merch_ha', 'avg_gai_merch_ha']]
    return final_df

def weighted_nai_con_broad_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """NAI area by status in wide format for all countries in the given scenario combination.

    >>> from eu_cbm_hat.post_processor.area import nai_all_countries
    >>> nai_all_countries("reference", ["year", "status", "con_broad", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        weighted_nai_con_broad_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all

def area_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """area area by status in wide format for all countries in the given scenario combination.

    >>> from eu_cbm_hat.post_processor.area import area_all_countries
    >>> area_all_countries("reference", ["year", "status", "con_broad", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        area_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all


def harvest_exp_prov_one_country(
    combo_name: str, iso2_code: str, groupby: Union[List[str], str]
):
    """Harvest excepted provided in one country

    There is a groupby  argument because we get the harvest expected from the
    hat output of disturbances allocated by hat which are allocated at some
    level of classifier groupings (other classifiers might have question marks
    i.e. where harvest can be allocated to any value of that particular
    classifier).

    In case the groupby argument is equal to "year", we also add the harvest
    demand from the economic model.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_exp_prov_one_country
        >>> import pandas
        >>> pandas.set_option('display.precision', 0) # Display rounded numbers
        >>> harvest_exp_prov_one_country("reference", "ZZ", "year")
        >>> harvest_exp_prov_one_country("reference", "ZZ", ["year", "forest_type"])
        >>> harvest_exp_prov_one_country("reference", "ZZ", ["year", "disturbance_type"])

    """
    if isinstance(groupby, str):
        groupby = [groupby]

    # TODO: current version of harvest_exp_one_country() only contains HAT
    # disturbances. This should also provide static events that generate fluxes
    # to products especially in the historical period
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.harvest.expected_provided(groupby=groupby)
    df_all = place_combo_name_and_country_first(df, runner)

    return df_all


def harvest_exp_prov_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """Information on both harvest expected and provided for all countries in
    the combo_name.

    Some countries might have NA values. If the model didn't run successfully
    for those countries i.e. the output flux table was missing.

    Example use:

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_exp_prov_all_countries
        >>> harvest_exp_prov_all_countries("reference", "year")
        >>> harvest_exp_prov_all_countries("reference", ["year", "forest_type", "disturbance_type"])

    """
    df_all = apply_to_all_countries(
        harvest_exp_prov_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all

def harvest_exp_prov_all_countries_eu(combo_name: str, groupby: Union[List[str], str] = "year"):
    """
    This function harvest for all countries and EU,
    calculates the sums and weighted averages for the 'eu' iso2_code.
    """
    df_all = apply_to_all_countries(
        harvest_exp_prov_one_country, combo_name=combo_name, groupby=groupby
    )

    df_all = df_all[df_all['country'] != 'EU']
    # 'scenario' column leaks in from the demand merge in expected_provided();
    # drop it here to avoid a duplicate when the notebook renames combo_name → scenario.
    df_all = df_all.drop(columns=['scenario'], errors='ignore')

    sum_cols = ['rw_demand', 'fw_demand', 'irw_demand',
                'irw_harvest_prov_ub', 'total_harvest_ub_provided', 'total_harvest_ob_provided']
    group_cols = groupby if isinstance(groupby, list) else [groupby]

    df_eu = (
        df_all.groupby(group_cols)[sum_cols]
        .sum()
        .reset_index()
    )
    df_eu['country'] = 'EU'
    df_eu['combo_name'] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


def volume_biomass_standing_stocks_one_country(
    combo_name: str, iso2_code: str, groupby: Union[List[str], str]
):
    """
    Dynamics of standing stock volume and biomass per country per scenario. 
    
    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import volume_stock_one_country
        >>> import pandas
        >>> pandas.set_option('display.precision', 0) # Display rounded numbers
        >>> volume_stock_one_country("reference", "ZZ", "year")
        >>> volume_stock_one_country("reference", "ZZ", ["year", "status"])

    """
    if isinstance(groupby, str):
        groupby = [groupby]
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.stock.volume_biomass_standing_stocks(groupby=groupby)
    #print(df.head(3))
    df = place_combo_name_and_country_first(df, runner)
    return df

def volume_biomass_standing_stocks_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """Dynamics of standing stock volume and biomass per country for all countries, per scenario.
    Example use:

        >>> from eu_cbm_hat.post_processor.agg_combos import harvest_exp_prov_all_countries
        >>> harvest_exp_prov_all_countries("reference", "year")
        >>> harvest_exp_prov_all_countries("reference", ["year", "status"])

    """
    df_all = apply_to_all_countries(
        volume_stock_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all

def volume_biomass_standing_stocks_region(combo_name: str, groupby: Union[List[str], str]):
    """Standing stock volume and biomass for all countries, plus regional aggregates.

    Calls ``volume_biomass_standing_stocks_one_country`` for every country,
    then appends one aggregate row per region × groupby combination.
    Per-hectare metrics are recomputed from the summed totals and area.
    Regions are defined by the module-level ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import volume_biomass_standing_stocks_region
        >>> volume_biomass_standing_stocks_region("reference", ["year", "status"])

    """
    if isinstance(groupby, str):
        groupby = [groupby]

    df_all = apply_to_all_countries(
        volume_biomass_standing_stocks_one_country, combo_name=combo_name, groupby=groupby
    )

    if df_all.empty or 'country' not in df_all.columns:
        raise RuntimeError(
            f"volume_biomass_standing_stocks_region: apply_to_all_countries returned no "
            f"data for combo '{combo_name}'. All per-country calls likely failed — run "
            f"volume_biomass_standing_stocks_one_country('{combo_name}', 'AT', {groupby}) "
            f"directly to see the underlying error."
        )

    df_all = df_all[df_all['country'] != 'EU']
    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    sum_cols = [
        'con_standing_for_biomass', 'broad_standing_for_biomass',
        'con_standing_for_volume', 'broad_standing_for_volume',
        'area',
    ]
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(groupby + ['eu_region'], as_index=False)[sum_cols]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    df_reg['standing_stock_biomass'] = df_reg['con_standing_for_biomass'] + df_reg['broad_standing_for_biomass']
    df_reg['standing_stock_volume'] = df_reg['con_standing_for_volume'] + df_reg['broad_standing_for_volume']
    df_reg['standing_stock_biomass_ha'] = df_reg['standing_stock_biomass'] / df_reg['area']
    df_reg['standing_stock_volume_ha'] = df_reg['standing_stock_volume'] / df_reg['area']

    return pandas.concat([df_all, df_reg], ignore_index=True)

def volume_biomass_standing_stocks_region_annual(combo_name: str):
    """Standing stock volume and biomass by region, annual time step.

    Wrapper around ``volume_biomass_standing_stocks_region`` with
    ``groupby=["year", "status"]``, so it can be passed directly to
    ``collect_scenarios``.

        >>> from eu_cbm_hat.post_processor.agg_combos import (
        ...     collect_scenarios,
        ...     volume_biomass_standing_stocks_region_annual,
        ... )
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_scenarios(
        ...     scenarios,
        ...     volume_biomass_standing_stocks_region_annual,
        ...     "volume_biomass_standing_stocks_by_region_year.parquet",
        ... )

    """
    return volume_biomass_standing_stocks_region(combo_name, groupby=["year", "status"])


def area_age_class_one_country(
    combo_name: str, iso2_code: str, years: list = None
):
    """Area by age class for one country.

    Calls ``runner.post_processor.area.df_agg_by_classifiers_age`` and
    attaches combo name and country identifiers.

        >>> from eu_cbm_hat.post_processor.agg_combos import area_age_class_one_country
        >>> area_age_class_one_country("reference_bnc_nmf", "AT", years=[2020, 2050, 2070])

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.area.df_agg_by_classifiers_age(years=years)
    df = place_combo_name_and_country_first(df, runner)
    return df


def area_age_class_by_region(combo_name: str, years: list = None):
    """Area by age class aggregated to EU regions, with simple sum per region.

    Calls ``area_age_class_one_country`` for every country in the combo,
    then appends one aggregate row per region × year × age_class.
    Regions are defined by the module-level ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import area_age_class_by_region
        >>> df = area_age_class_by_region("reference_bnc_nmf", years=[2020, 2050, 2070])

    """
    df_all = apply_to_all_countries(
        area_age_class_one_country, combo_name=combo_name, years=years
    )
    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['year', 'age_class', 'eu_region'], as_index=False)['area']
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def collect_area_age_class_by_region(
    combo_names: list,
    years: list = None,
    file_name: str = "area_age_class_by_region.parquet",
) -> pandas.DataFrame:
    """Collect area by age class per EU region across many scenario combinations.

    Wrapper around :func:`collect_scenarios` that fixes the ``years`` argument
    of :func:`area_age_class_by_region` so it can be passed as a plain
    callable.  One parquet file per scenario is written to the combo's
    ``output_agg`` directory; all scenarios are returned as a single DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_area_age_class_by_region
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_area_age_class_by_region(scenarios, years=[2020, 2050, 2070])

    """
    def _func(combo_name):
        return area_age_class_by_region(combo_name, years=years)
    _func.__name__ = "area_age_class_by_region"
    return collect_scenarios(combo_names, _func, file_name)


def merch_stock_age_class_one_country(combo_name: str, iso2_code: str):
    """Merchantable stock by age class for one country.

    Calls ``runner.post_processor.stock.merch_stock_age_class`` and
    attaches combo name and country identifiers.

        >>> from eu_cbm_hat.post_processor.agg_combos import merch_stock_age_class_one_country
        >>> merch_stock_age_class_one_country("reference_bnc_nmf", "AT")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.stock.merch_stock_age_class(groupby=["year"])
    df = place_combo_name_and_country_first(df, runner)
    return df


def merch_stock_age_class_by_region(combo_name: str):
    """Merchantable stock by age class aggregated to EU regions.

    Calls ``merch_stock_age_class_one_country`` for every country in the combo,
    then appends one aggregate row per region × year × age_class.
    Regions are defined by the module-level ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import merch_stock_age_class_by_region
        >>> df = merch_stock_age_class_by_region("reference_bnc_nmf")

    """
    df_all = apply_to_all_countries(
        merch_stock_age_class_one_country, combo_name=combo_name
    )

    sum_cols = ["softwood_merch_tc", "hardwood_merch_tc", "area"]

    df_all["eu_region"] = df_all["iso2_code"].map(_iso_to_region)
    df_reg = (
        df_all.dropna(subset=["eu_region"])
        .groupby(["year", "age_class", "eu_region"], as_index=False)[sum_cols]
        .sum()
        .rename(columns={"eu_region": "country"})
    )
    df_reg["combo_name"] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def collect_merch_stock_age_class_by_region(
    combo_names: list,
    file_name: str = "merch_stock_age_class_by_region.parquet",
) -> pandas.DataFrame:
    """Collect merchantable stock by age class per EU region across many scenario combinations.

    Wrapper around :func:`collect_scenarios` that calls
    :func:`merch_stock_age_class_by_region` for each combo.  One parquet file
    per scenario is written to the combo's ``output_agg`` directory; all
    scenarios are returned as a single DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_merch_stock_age_class_by_region
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_merch_stock_age_class_by_region(scenarios)

    """
    return collect_scenarios(combo_names, merch_stock_age_class_by_region, file_name)


def merch_stock_age_class_one_country_with_status(combo_name: str, iso2_code: str):
    """Merchantable stock by age class and status for one country.

    Like :func:`merch_stock_age_class_one_country` but includes ``status``
    in the groupby so results can be split into ForAWS / ForNAWS etc.
    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.stock.merch_stock_age_class(groupby=["year", "status"])
    df = place_combo_name_and_country_first(df, runner)
    return df


def merch_stock_age_class_by_region_with_status(combo_name: str):
    """Merchantable stock by age class and status aggregated to EU regions.

    Like :func:`merch_stock_age_class_by_region` but retains the ``status``
    column so the output can be filtered to ForAWS, ForNAWS, etc.
    """
    df_all = apply_to_all_countries(
        merch_stock_age_class_one_country_with_status, combo_name=combo_name
    )

    sum_cols = ["softwood_merch_tc", "hardwood_merch_tc", "area"]

    df_all["eu_region"] = df_all["iso2_code"].map(_iso_to_region)
    df_reg = (
        df_all.dropna(subset=["eu_region"])
        .groupby(["year", "status", "age_class", "eu_region"], as_index=False)[sum_cols]
        .sum()
        .rename(columns={"eu_region": "country"})
    )
    df_reg["combo_name"] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def collect_merch_stock_age_class_by_region_with_status(
    combo_names: list,
    file_name: str = "merch_stock_age_class_by_region_status.parquet",
) -> pandas.DataFrame:
    """Collect merchantable stock by age class and status per EU region.

    Like :func:`collect_merch_stock_age_class_by_region` but the resulting
    parquet includes a ``status`` column (ForAWS, ForNAWS, …) so individual
    figures can filter to a single forest status.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_merch_stock_age_class_by_region_with_status
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_merch_stock_age_class_by_region_with_status(scenarios)

    """
    return collect_scenarios(
        combo_names, merch_stock_age_class_by_region_with_status, file_name
    )


def soc_one_country(combo_name: str, iso2_code: str, groupby: Union[List[str], str]):
    """Harvest provided in one country
    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import soc_one_country
        >>> dw_zz = soc_one_country("reference", "ZZ", ["year", 'status', "disturbance_type"])

    """
    index = ["identifier", "timestep"]
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    # Load Area
    cols_to_keep = [
        "area",
        "softwood_merch",
        "hardwood_merch",
        "medium_soil",
        "softwood_stem_snag",
        "hardwood_stem_snag",
        # new ones
        "above_ground_very_fast_soil",
        "below_ground_very_fast_soil",
        "above_ground_fast_soil",
        "below_ground_fast_soil",
        "above_ground_slow_soil",
        "below_ground_slow_soil",
        "softwood_branch_snag",
        "hardwood_branch_snag",
    ]
    df = runner.output["pools"][index + cols_to_keep]
    df["year"] = runner.country.timestep_to_year(df["timestep"])
    # Add classifiers
    df = df.merge(runner.output.classif_df, on=index)
    # Disturbance type information
    dist = runner.output["parameters"][index + ["disturbance_type"]]
    df = df.merge(dist, on=index)
    # Aggregate
    # df_agg = df.groupby(groupby)["medium_soil"].agg("sum").reset_index()

    # Aggregate separately for softwood and hardwood
    df_agg = df.groupby(groupby).agg(
        softwood_stem_snag_tc=("softwood_stem_snag", "sum"),
        softwood_merch_tc=("softwood_merch", "sum"),
        hardwood_stem_snag_tc=("hardwood_stem_snag", "sum"),
        hardwood_merch_tc=("hardwood_merch", "sum"),
        medium_tc=("medium_soil", "sum"),
        # new ones
        above_ground_very_fast_soil_tc=("above_ground_very_fast_soil", sum),
        below_ground_very_fast_soil_tc=("below_ground_very_fast_soil", sum),
        above_ground_fast_soil_tc=("above_ground_fast_soil", sum),
        below_ground_fast_soil_tc=("below_ground_fast_soil", sum),
        above_ground_slow_soil_tc=("above_ground_slow_soil", sum),
        below_ground_slow_soil_tc=("below_ground_slow_soil", sum),
        area=("area", "sum"),
    )
    df_agg.reset_index(inplace=True)
    df_agg["softwood_standing_dw_ratio"] = (
        df_agg["softwood_stem_snag_tc"] / df_agg["softwood_merch_tc"]
    )
    df_agg["hardwood_standing_dw_ratio"] = (
        df_agg["hardwood_stem_snag_tc"] / df_agg["hardwood_merch_tc"]
    )
    # agregate over con and broad
    df_agg["standing_dw_c_per_ha"] = (
        df_agg["hardwood_stem_snag_tc"] + df_agg["softwood_stem_snag_tc"]
    ) / df_agg["area"]
    df_agg["laying_dw_c_per_ha"] = df_agg["medium_tc"] / df_agg["area"]

    # Place combo name, country code and country name as first columns
    df_agg["combo_name"] = combo_name
    df_agg["iso2_code"] = runner.country.iso2_code
    df_agg["country"] = runner.country.country_name
    cols = list(df_agg.columns)
    # cols = ['softwood_stem_snag_tc', 'softwood_merch_tc',
    # 'hardwood_stem_snag_tc', 'hardwood_merch_tc', 'area', 'medium_tc',
    # 'softwood_standing_dw_ratio', 'hardwood_standing_dw_ratio',
    # 'standing_dw_c_per_ha', 'laying_dw_c_per_ha']
    cols = cols[-3:] + cols[:-3]
    return df_agg[cols]


def soc_all_countries(combo_name: str, groupby: Union[List[str], str]):
    """Harvest area by status in wide format for all countries in the given scenario combination."""
    df_all = apply_to_all_countries(
        soc_one_country, combo_name=combo_name, groupby=groupby
    )
    return df_all


def pools_length_one_country(
    combo_name: str,
    iso2_code: str,
):
    """Number of rows in the pools table

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import pools_length_one_country
        >>> pools_length_one_country("reference", "LU")

    """
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    pools = runner.post_processor.pools
    df = pools.value_counts(["year"], sort=False).reset_index()
    df = place_combo_name_and_country_first(df, runner)
    # Fix for older versions of pandas
    df.rename(columns={0: "count"}, inplace=True)
    return df


def fw_source_provided_one_country(
    combo_name: str, iso2_code: str, groupby: Union[List[str], str]
    ):
    """Harvest excepted provided in one country

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import fw_source_provided_one_country
        >>> import pandas
        >>> pandas.set_option('display.precision', 0) # Display rounded numbers
        >>> fw_source_provided_one_country("year")


    """
    if isinstance(groupby, str):
        groupby = [groupby]

    # TODO: current version of harvest_exp_one_country() only contains HAT
    # disturbances. This should also provide static events that generate fluxes
    # to products especially in the historical period
    runner = continent.combos[combo_name].runners[iso2_code][-1]
    df = runner.post_processor.harvest.provided_fw()
    df = place_combo_name_and_country_first(df, runner)
    return df
    
def fw_source_provided_eu(combo_name: str, groupby: Union[List[str], str]):
    """
    This function nai for all countries and EU, 
    calculates the sums and weighted averages for the 'eu' iso2_code.
    """
    
    df_all = apply_to_all_countries(
        fw_source_provided_one_country, combo_name=combo_name, groupby=groupby
    )
    
    # Filter out the 'eu' code if it already exists
    df_all = df_all[df_all['country'] != 'EU']
   
    # Group by year and calculate the sums and weighted averages
    df_eu = df_all.groupby('year').apply(
        lambda x: pandas.Series({
            'country': 'EU',
            #'combo_name': combo_name,
            #'status': '',  # You can set this to any value you want
            # totals
            'total_harvest_ub_provided': x['total_harvest_ub_provided'].sum(),
            'total_harvest_ob_provided': x['total_harvest_ob_provided'].sum(),
            'irw_fw_harvest_prov_ub': x['irw_fw_harvest_prov_ub'].sum(),
            'irw_fw_harvest_prov_ob': x['irw_fw_harvest_prov_ob'].sum(),
            'irw_fw_harvest_prov_merch_ub': x['irw_fw_harvest_prov_merch_ub'].sum(),
            'irw_fw_harvest_prov_other_ub': x['irw_fw_harvest_prov_merch_ob'].sum(),
            'irw_fw_harvest_prov_stem_snag_ub': x['irw_fw_harvest_prov_stem_snag_ub'].sum(),
            'irw_fw_harvest_prov_branch_snag_ub': x['irw_fw_harvest_prov_stem_snag_ob'].sum(),
            'fw_harvest_prov_ub': x['fw_harvest_prov_ub'].sum(),
            'fw_harvest_prov_ob': x['fw_harvest_prov_ob'].sum(),
            'fw_harvest_prov_merch_ub': x['fw_harvest_prov_merch_ub'].sum(),
            'fw_harvest_prov_merch_ob': x['fw_harvest_prov_merch_ob'].sum(),
            'fw_harvest_prov_other_ub': x['fw_harvest_prov_other_ub'].sum(),
            'fw_harvest_prov_other_ob': x['fw_harvest_prov_other_ob'].sum(),
            'fw_harvest_prov_stem_snag_ub': x['fw_harvest_prov_stem_snag_ub'].sum(),
            'fw_harvest_prov_stem_snag_ob': x['fw_harvest_prov_stem_snag_ob'].sum(),
            'fw_harvest_prov_branch_snag_ub': x['fw_harvest_prov_branch_snag_ub'].sum(),
            'fw_harvest_prov_branch_snag_ob': x['fw_harvest_prov_branch_snag_ob'].sum(),
            'total_fw_ub_provided': x['total_fw_ub_provided'].sum(),
            'total_fw_ob_provided': x['total_fw_ob_provided'].sum(),
            # fractions
            'total_fw_ub_in_total_harvest_ub_frac': (x['total_fw_ub_in_total_harvest_ub_frac'] * x['area']).sum() / x['area'].sum(),
            'irw_fw_ub_in_total_fw_ub_frac': (x['irw_fw_ub_in_total_fw_ub_frac'] * x['area']).sum() / x['area'].sum(),
            'fw_ub_in_total_fw_ub_frac': (x['fw_ub_in_total_fw_ub_frac'] * x['area']).sum() / x['area'].sum(),
            'irw_fw_merch_ub_in_irw_fw_ub_provided_frac': (x['irw_fw_merch_ub_in_irw_fw_ub_provided_frac'] * x['area']).sum() / x['area'].sum(),
            'fw_merch_ub_in_fw_ub_provided_frac': (x['fw_merch_ub_in_fw_ub_provided_frac'] * x['area']).sum() / x['area'].sum()    
        })
    ).reset_index()
    
    # Reset the index to create a new column for the year
    df_eu = df_eu.rename(columns={'index': 'year'})
    
    # Concatenate the original DataFrame with the new 'eu' DataFrame
    df_all = pandas.concat([df_all, df_eu], ignore_index=True)
    
    return df_all


def hwp_one_country(combo_name: str, iso2_code: str) -> pandas.DataFrame:
    """HWP stock and sink results for one country using the default scenario parameters.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import hwp_one_country
        >>> hwp_one_country("reference", "LU")

    """
    hwp = select_hwp_scenario(
        iso2_code=iso2_code,
        forest_mgmt_scenario=combo_name,
        hwp_frac_scenario="default",
        n_years_dom_frac=3,
        no_export_no_import=False,
        recycling=False,
    )
    df = hwp.stock_sink_results
    df = place_combo_name_and_country_first(df, hwp.runner)
    return df


def hwp_eu(
    combo_name: str = "reference_bnc_nmf",
    hwp_allocation_method: str | None = None,
    ) -> pandas.DataFrame:
    """
    Add a synthetic EU row by summing all country rows per year.
    """

    df_all = apply_to_all_countries(hwp_one_country, combo_name=combo_name)

    if hwp_allocation_method is not None:
        df_all["hwp_allocation_method"] = hwp_allocation_method

    sum_cols = [
        "crf_hwp_tco2",
        "hwp_tot_stock_tc_1900",
        "hwp_tot_sink_tco2_1900",
        "hwp_loss_1900",
        "hwp_tot_stock_tc_1990",
        "hwp_tot_sink_tco2_1990",
        "hwp_loss_1990",
        "fw_primary_ghg_co2_eq",
        "fw_secondary_ghg_co2_eq",
        "fw_primary_co2",
        "fw_secondary_co2",
        "waste_co2_eq",
    ]
    sum_cols = [c for c in sum_cols if c in df_all.columns]

    eu = (
        df_all.groupby("year", as_index=False)[sum_cols]
        .sum()
        .assign(combo_name=combo_name, iso2_code="EU", country="EU", member_state="EU")
    )

    return pandas.concat([df_all, eu], ignore_index=True)


_HWP_SUM_COLS = [
    "crf_hwp_tco2",
    "hwp_tot_stock_tc_1900",
    "hwp_tot_sink_tco2_1900",
    "hwp_loss_1900",
    "hwp_tot_stock_tc_1990",
    "hwp_tot_sink_tco2_1990",
    "hwp_loss_1990",
    "fw_primary_ghg_co2_eq",
    "fw_secondary_ghg_co2_eq",
    "fw_primary_co2",
    "fw_secondary_co2",
    "waste_co2_eq",
]


def hwp_all_scenarios(
    scenarios: List[str],
    countries: List[str] = None,
    ) -> pandas.DataFrame:
    """Run HWP stock-and-sink results for a list of scenarios and countries.

    Iterates over every (scenario, country) combination and collects
    ``hwp_one_country`` output into a single DataFrame.  When *countries* is
    omitted every country available for each scenario is used.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import hwp_all_scenarios
        >>> df = hwp_all_scenarios(["reference", "intensive"], ["LU", "AT"])

    """
    frames = []
    for scenario in scenarios:
        country_codes = (
            countries
            if countries is not None
            else list(continent.combos[scenario].runners.keys())
        )
        for ms in tqdm(country_codes, desc=scenario):
            try:
                frames.append(hwp_one_country(scenario, ms))
            except FileNotFoundError as e:
                print(e)
            except (ValueError, KeyError) as e:
                print(ms, e)
    if not frames:
        return pandas.DataFrame()
    return pandas.concat(frames, ignore_index=True)


def hwp_by_region(combo_name: str) -> pandas.DataFrame:
    """HWP stock-and-sink results for all countries plus regional aggregates.

    Individual country rows are returned unchanged; one additional row per
    region × year is appended.  Regions are defined by the module-level
    ``regions`` dictionary.

    Usage:

        >>> from eu_cbm_hat.post_processor.agg_combos import hwp_by_region
        >>> hwp_by_region("reference")

    """
    df_all = apply_to_all_countries(hwp_one_country, combo_name=combo_name)
    df_all = df_all[df_all["country"] != "EU"]

    df_all["eu_region"] = df_all["iso2_code"].map(_iso_to_region)

    sum_cols = [c for c in _HWP_SUM_COLS if c in df_all.columns]

    df_reg = (
        df_all.dropna(subset=["eu_region"])
        .groupby(["year", "eu_region"], as_index=False)[sum_cols]
        .sum()
        .rename(columns={"eu_region": "country"})
    )
    df_reg["combo_name"] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def collect_hwp_by_region(
    combo_names: List[str],
    file_name: str = "hwp_by_region.parquet",
) -> pandas.DataFrame:
    """Collect HWP stock-and-sink results with EU-region aggregates across many
    scenario combinations.

    One parquet file per scenario is written to the combo's ``output_agg``
    directory; all scenarios are returned as a single DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_hwp_by_region
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_hwp_by_region(scenarios)
        >>> # Read back later without recomputing:
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> df = read_agg_combo_output(scenarios, "hwp_by_region.parquet")

    """
    return collect_scenarios(combo_names, hwp_by_region, file_name)


def collect_hwp_by_eu(
    combo_names: List[str],
    file_name: str = "hwp_eu.parquet",
) -> pandas.DataFrame:
    """Collect HWP stock-and-sink results with EU aggregate row across many
    scenario combinations.

    Wraps :func:`hwp_eu` (all countries + synthetic EU row) via
    :func:`collect_scenarios`.  One parquet file per scenario is written to the
    combo's ``output_agg`` directory; all scenarios are returned as a single
    DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_hwp_by_eu
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_hwp_by_eu(scenarios)
        >>> # Read back later without recomputing:
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> df = read_agg_combo_output(scenarios, "hwp_eu.parquet")

    """
    return collect_scenarios(combo_names, hwp_eu, file_name)


def hwp_by_eu_period(combo_name: str) -> pandas.DataFrame:
    """HWP stock-and-sink for all countries plus EU aggregate, averaged over
    5-year periods starting in 2026.

    Annual values are averaged within each country x period, then an EU
    aggregate row (sum of country means) is appended for each period.
    Follows the same period convention as :func:`harvest_vol_d_ar_fl_all_countries_period`.

        >>> from eu_cbm_hat.post_processor.agg_combos import hwp_by_eu_period
        >>> hwp_by_eu_period("reference_bnc_nmf")

    """
    df_all = apply_to_all_countries(hwp_one_country, combo_name=combo_name)
    df_all = df_all[df_all['country'] != 'EU']

    # Build 5-year period labels
    df_all = df_all[df_all['year'] >= 2026]
    df_all['period_start'] = 2026 + 5 * ((df_all['year'] - 2026) // 5)
    df_all['period'] = (
        df_all['period_start'].astype(str) + '-' +
        (df_all['period_start'] + 4).astype(str)
    )
    df_all = df_all.drop(columns=['period_start'])

    sum_cols = [c for c in _HWP_SUM_COLS if c in df_all.columns]

    # Average annual values within each country x period
    group_cols = ['combo_name', 'iso2_code', 'country', 'period']
    df_all = df_all.groupby(group_cols, as_index=False)[sum_cols].mean()

    # EU aggregate: sum of country means per period
    df_eu = df_all.groupby(['period'], as_index=False)[sum_cols].sum()
    df_eu['country'] = 'EU'
    df_eu['combo_name'] = combo_name

    return pandas.concat([df_all, df_eu], ignore_index=True)


def hwp_by_region_period(combo_name: str) -> pandas.DataFrame:
    """HWP stock-and-sink for all countries plus regional aggregates, averaged
    over 5-year periods starting in 2026.

    Annual values are averaged within each country x period, then one
    regional aggregate row (sum of member-state means) per region x period
    is appended.  Regions are defined by the module-level ``regions`` dictionary.

        >>> from eu_cbm_hat.post_processor.agg_combos import hwp_by_region_period
        >>> hwp_by_region_period("reference_bnc_nmf")

    """
    df_all = apply_to_all_countries(hwp_one_country, combo_name=combo_name)
    df_all = df_all[df_all['country'] != 'EU']

    # Build 5-year period labels
    df_all = df_all[df_all['year'] >= 2026]
    df_all['period_start'] = 2026 + 5 * ((df_all['year'] - 2026) // 5)
    df_all['period'] = (
        df_all['period_start'].astype(str) + '-' +
        (df_all['period_start'] + 4).astype(str)
    )
    df_all = df_all.drop(columns=['period_start'])

    sum_cols = [c for c in _HWP_SUM_COLS if c in df_all.columns]

    # Average annual values within each country x period
    group_cols = ['combo_name', 'iso2_code', 'country', 'period']
    df_all = df_all.groupby(group_cols, as_index=False)[sum_cols].mean()

    # Tag each row with its region
    df_all['eu_region'] = df_all['iso2_code'].map(_iso_to_region)

    # Regional aggregates: sum of member-state means per region x period
    df_reg = (
        df_all.dropna(subset=['eu_region'])
        .groupby(['period', 'eu_region'], as_index=False)[sum_cols]
        .sum()
        .rename(columns={'eu_region': 'country'})
    )
    df_reg['combo_name'] = combo_name

    return pandas.concat([df_all, df_reg], ignore_index=True)


def collect_hwp_by_eu_period(
    combo_names: List[str],
    file_name: str = "hwp_by_eu_period.parquet",
) -> pandas.DataFrame:
    """Collect 5-year period HWP results with EU aggregate row across many
    scenario combinations.

    One parquet file per scenario is written to the combo's ``output_agg``
    directory; all scenarios are returned as a single DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_hwp_by_eu_period
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_hwp_by_eu_period(scenarios)
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> df = read_agg_combo_output(scenarios, "hwp_by_eu_period.parquet")

    """
    return collect_scenarios(combo_names, hwp_by_eu_period, file_name)


def collect_hwp_by_region_period(
    combo_names: List[str],
    file_name: str = "hwp_by_region_period.parquet",
) -> pandas.DataFrame:
    """Collect 5-year period HWP results with EU-region aggregates across many
    scenario combinations.

    One parquet file per scenario is written to the combo's ``output_agg``
    directory; all scenarios are returned as a single DataFrame.

        >>> from eu_cbm_hat.post_processor.agg_combos import collect_hwp_by_region_period
        >>> scenarios = ["reference_bnc_nmf", "max_rotation_bnc_nmf"]
        >>> df = collect_hwp_by_region_period(scenarios)
        >>> from eu_cbm_hat.post_processor.agg_combos import read_agg_combo_output
        >>> df = read_agg_combo_output(scenarios, "hwp_by_region_period.parquet")

    """
    return collect_scenarios(combo_names, hwp_by_region_period, file_name)