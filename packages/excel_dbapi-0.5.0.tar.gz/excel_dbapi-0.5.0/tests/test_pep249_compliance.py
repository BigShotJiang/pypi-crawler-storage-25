"""Tests for PEP 249 compliance details."""

from pathlib import Path
from typing import Any
import datetime

from openpyxl import Workbook
import importlib
import pytest

from excel_dbapi.connection import ExcelConnection
from excel_dbapi.engines.base import TableData, WorkbookBackend
from excel_dbapi.exceptions import InterfaceError
import excel_dbapi


class TestModuleLevelExports:
    """PEP 249 §1 requires module-level constants and exception exports."""

    def test_apilevel(self) -> None:

        assert excel_dbapi.apilevel == "2.0"

    def test_threadsafety(self) -> None:

        assert excel_dbapi.threadsafety == 1

    def test_paramstyle(self) -> None:

        assert excel_dbapi.paramstyle == "qmark"

    @pytest.mark.parametrize(
        "name",
        [
            "Error",
            "Warning",
            "InterfaceError",
            "DatabaseError",
            "DataError",
            "OperationalError",
            "IntegrityError",
            "InternalError",
            "ProgrammingError",
            "NotSupportedError",
        ],
    )
    def test_exception_exported(self, name: str) -> None:

        cls = getattr(excel_dbapi, name)
        assert cls is not None
        # Must be importable as a class
        assert isinstance(cls, type)

    def test_exception_hierarchy(self) -> None:
        """PEP 249 exception inheritance must be correct."""

        assert issubclass(excel_dbapi.Warning, Exception)
        assert issubclass(excel_dbapi.Error, Exception)
        assert issubclass(excel_dbapi.InterfaceError, excel_dbapi.Error)
        assert issubclass(excel_dbapi.DatabaseError, excel_dbapi.Error)
        assert issubclass(excel_dbapi.DataError, excel_dbapi.DatabaseError)
        assert issubclass(excel_dbapi.OperationalError, excel_dbapi.DatabaseError)
        assert issubclass(excel_dbapi.IntegrityError, excel_dbapi.DatabaseError)
        assert issubclass(excel_dbapi.InternalError, excel_dbapi.DatabaseError)
        assert issubclass(excel_dbapi.ProgrammingError, excel_dbapi.DatabaseError)
        assert issubclass(excel_dbapi.NotSupportedError, excel_dbapi.DatabaseError)

    def test_connect_function(self) -> None:

        assert callable(excel_dbapi.connect)

    def test_all_contains_exceptions(self) -> None:

        for name in [
            "Error",
            "Warning",
            "InterfaceError",
            "DatabaseError",
            "DataError",
            "OperationalError",
            "IntegrityError",
            "InternalError",
            "ProgrammingError",
            "NotSupportedError",
        ]:
            assert name in excel_dbapi.__all__, f"{name} missing from __all__"


class TestCursorPEP249Stubs:
    """PEP 249 requires setinputsizes / setoutputsize on Cursor."""

    @pytest.fixture
    def cursor(self, tmp_path):

        path = str(tmp_path / "test.xlsx")
        wb = Workbook()
        ws = wb.active
        assert ws is not None
        ws.title = "Sheet1"
        ws.append(["id", "name"])
        wb.save(path)


        conn = ExcelConnection(path)
        cur = conn.cursor()
        yield cur
        conn.close()

    def test_setinputsizes_exists_and_returns_none(self, cursor) -> None:
        result = cursor.setinputsizes([10, 20])
        assert result is None

    def test_setoutputsize_exists_and_returns_none(self, cursor) -> None:
        result = cursor.setoutputsize(1000)
        assert result is None

    def test_setoutputsize_with_column(self, cursor) -> None:
        result = cursor.setoutputsize(1000, column=0)
        assert result is None

    def test_setinputsizes_raises_on_closed_cursor(self, cursor) -> None:

        cursor.close()
        with pytest.raises(InterfaceError):
            cursor.setinputsizes([])

    def test_setoutputsize_raises_on_closed_cursor(self, cursor) -> None:

        cursor.close()
        with pytest.raises(InterfaceError):
            cursor.setoutputsize(100)


class TestWorkbookBackendContract:
    def test_raises_not_implemented(self) -> None:


        class Stub(WorkbookBackend):
            @property
            def readonly(self) -> bool:
                return False

            @property
            def supports_transactions(self) -> bool:
                return True

            def load(self) -> None:
                pass

            def save(self) -> None:
                pass

            def snapshot(self) -> Any:
                return None

            def restore(self, snapshot: Any) -> None:
                pass

            def list_sheets(self) -> list[str]:
                return ["Sheet1"]

            def read_sheet(self, sheet_name: str) -> TableData:
                return TableData(headers=["id"], rows=[[1]])

            def write_sheet(self, sheet_name: str, data: TableData) -> None:
                pass

            def append_row(self, sheet_name: str, row: list[Any]) -> int:
                return 1

            def create_sheet(self, name: str, headers: list[str]) -> None:
                pass

            def drop_sheet(self, name: str) -> None:
                pass

        engine = Stub("dummy.xlsx")
        assert engine.list_sheets() == ["Sheet1"]


class TestConnectSanitizeFormulasParam:
    """connect() and ExcelConnection accept sanitize_formulas parameter."""

    @pytest.fixture
    def xlsx_path(self, tmp_path):

        path = str(tmp_path / "test.xlsx")
        wb = Workbook()
        ws = wb.active
        assert ws is not None
        ws.title = "Sheet1"
        ws.append(["id", "name"])
        wb.save(path)
        return path

    def test_connect_default_sanitize(self, xlsx_path: str) -> None:

        conn = excel_dbapi.connect(xlsx_path)
        assert conn.engine.sanitize_formulas is True
        conn.close()

    def test_connect_disable_sanitize(self, xlsx_path: str) -> None:

        conn = excel_dbapi.connect(xlsx_path, sanitize_formulas=False)
        assert conn.engine.sanitize_formulas is False
        conn.close()

    def test_connection_default_sanitize(self, xlsx_path: str) -> None:

        conn = ExcelConnection(xlsx_path)
        assert conn.engine.sanitize_formulas is True
        conn.close()

    def test_connection_disable_sanitize(self, xlsx_path: str) -> None:

        conn = ExcelConnection(xlsx_path, sanitize_formulas=False)
        assert conn.engine.sanitize_formulas is False
        conn.close()


class TestPep249ConstructorsAndTypeObjects:
    def test_datetime_constructors(self) -> None:

        assert excel_dbapi.Date(2026, 4, 14) == datetime.date(2026, 4, 14)
        assert excel_dbapi.Time(9, 8, 7) == datetime.time(9, 8, 7)
        assert excel_dbapi.Timestamp(2026, 4, 14, 9, 8, 7) == datetime.datetime(
            2026, 4, 14, 9, 8, 7
        )

    def test_tick_constructors(self) -> None:

        ticks = 1_700_000_000.0
        assert excel_dbapi.DateFromTicks(ticks) == datetime.date.fromtimestamp(ticks)
        assert (
            excel_dbapi.TimeFromTicks(ticks)
            == datetime.datetime.fromtimestamp(ticks).time()
        )
        assert excel_dbapi.TimestampFromTicks(ticks) == datetime.datetime.fromtimestamp(
            ticks
        )

    def test_binary_constructor(self) -> None:

        assert excel_dbapi.Binary("abc") == b"abc"
        assert excel_dbapi.Binary(b"xyz") == b"xyz"

    def test_type_objects_exported_and_comparable(self) -> None:

        for name in [
            "Date",
            "Time",
            "Timestamp",
            "DateFromTicks",
            "TimeFromTicks",
            "TimestampFromTicks",
            "Binary",
            "STRING",
            "BINARY",
            "NUMBER",
            "DATETIME",
            "ROWID",
        ]:
            assert name in excel_dbapi.__all__

        assert excel_dbapi.STRING.__eq__(str)
        assert excel_dbapi.BINARY.__eq__(bytes)
        assert excel_dbapi.NUMBER.__eq__(int)
        assert excel_dbapi.DATETIME.__eq__(datetime.datetime)
        assert excel_dbapi.ROWID.__eq__(int)



def _make_xlsx(
    path: Path,
    sheet: str = "users",
    headers: list[str] | None = None,
    rows: list[list[Any]] | None = None,
) -> str:
    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = sheet
    for h in headers or ["id", "name"]:
        pass
    ws.append(headers or ["id", "name"])
    for row in rows or []:
        ws.append(row)
    fpath = str(path)
    wb.save(fpath)
    wb.close()
    return fpath

class TestPackageVersion:
    """Fix 3: __version__ matches pyproject.toml."""

    def test_version_is_not_hardcoded_030(self) -> None:
        """__version__ should NOT be the old hardcoded '0.3.0'."""

        assert excel_dbapi.__version__ != "0.3.0"

    def test_version_matches_pyproject(self) -> None:
        """__version__ matches the version in pyproject.toml."""

        try:
            toml_module = importlib.import_module("tomllib")
        except ModuleNotFoundError:
            toml_module = importlib.import_module("tomli")

        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        with open(pyproject, "rb") as f:
            data = toml_module.load(f)
        expected = data["project"]["version"]


        # In editable installs the version comes from importlib.metadata
        # which reads pyproject.toml, so they should match.
        assert excel_dbapi.__version__ == expected

    def test_version_fallback_format(self) -> None:
        """Version is a valid semver-like string (not empty)."""

        parts = excel_dbapi.__version__.split(".")
        assert len(parts) >= 2, (
            f"Version {excel_dbapi.__version__!r} is not semver-like"
        )
