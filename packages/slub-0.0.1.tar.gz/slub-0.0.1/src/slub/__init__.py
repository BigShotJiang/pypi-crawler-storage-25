"""slub — stub package, placeholder on PyPI."""
