"""Internal streaming helpers for public SDK event streams."""

from __future__ import annotations

from typing import Any, Dict, Iterator, Optional, Set


_INTERNAL_STREAM_EVENT_TYPES = {
    "client_service_call",
    "client_service_response",
    "model_raw_delta",
}


def _public_service_call_event(event: Dict[str, Any]) -> Dict[str, Any]:
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    service_name = str(data.get("service_name", "")).strip()
    public_data: Dict[str, Any] = {
        "service_name": service_name,
        "client_managed": event.get("type") == "client_service_call",
    }
    call_id = str(data.get("call_id", "")).strip()
    if call_id:
        public_data["call_id"] = call_id

    return {
        "type": "service_call",
        "timestamp": event.get("timestamp"),
        "process_id": event.get("process_id"),
        "iteration": event.get("iteration"),
        "data": public_data,
    }


def _normalize_public_stream_event(
    event: Dict[str, Any],
    *,
    allowed_builtin_services: Optional[Set[str]] = None,
    allow_raw_client_services: bool = False,
) -> Dict[str, Any] | None:
    event_type = event.get("type")
    if event_type == "service_call":
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        service_name = str(data.get("service_name", "")).strip()
        if service_name == "done":
            return None
        if allowed_builtin_services is not None and service_name not in allowed_builtin_services:
            return None
        return _public_service_call_event(event)
    if event_type == "service_response":
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        service_name = str(data.get("service_name", "")).strip()
        if not service_name or service_name == "done":
            return None
        if allowed_builtin_services is not None and service_name not in allowed_builtin_services:
            return None
        return event
    if event_type in {"client_service_call", "model_raw_delta"}:
        if allow_raw_client_services:
            return event
        return None
    if event_type in _INTERNAL_STREAM_EVENT_TYPES:
        return None
    return event


def _coalesce_deltas(
    events: Iterator[Dict[str, Any]],
    *,
    allowed_builtin_services: Optional[Set[str]] = None,
    allow_raw_client_services: bool = False,
) -> Iterator[Dict[str, Any]]:
    """Keep visible deltas immediate while normalizing public progress events."""
    for event in events:
        normalized = _normalize_public_stream_event(
            event,
            allowed_builtin_services=allowed_builtin_services,
            allow_raw_client_services=allow_raw_client_services,
        )
        if normalized is None:
            continue
        yield normalized
