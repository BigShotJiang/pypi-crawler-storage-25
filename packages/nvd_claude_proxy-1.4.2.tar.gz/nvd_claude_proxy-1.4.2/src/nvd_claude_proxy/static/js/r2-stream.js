const state = {
  paused: false,
  eventsSeen: 0,
  activeReq: '—',
  lastStage: '—',
  outputTokens: 0,
};

const el = (id) => document.getElementById(id);
const timeline = el('timeline');
const laneLifecycle = el('laneLifecycle');
const laneContent = el('laneContent');
const laneTools = el('laneTools');
const laneDiag = el('laneDiag');
const connState = el('connState');

const colorClass = (stage, payload = {}) => {
  if (stage === 'message_start' || stage === 'message_stop') return 'c-message_start';
  if (stage === 'message_delta' || stage === 'message_delta_progress') return 'c-message_delta';
  if (stage === 'ping') return 'c-ping';
  if (stage === 'error') return 'c-error';
  if (stage === 'content_block_start' && payload.content_block?.type === 'tool_use') return 'c-content_block_start-tool_use';
  if (stage === 'content_block_start' && payload.content_block?.type === 'text') return 'c-content_block_start-text';
  if (stage === 'content_block_delta' && payload.delta?.type === 'thinking_delta') return 'c-content_block_delta-thinking_delta';
  if (stage === 'content_block_delta' && payload.delta?.type === 'text_delta') return 'c-text_delta';
  if (stage === 'content_block_delta' && payload.delta?.type === 'input_json_delta') return 'c-input_json_delta';
  if (stage === 'content_block_delta' && payload.delta?.type === 'signature_delta') return 'c-signature_delta';
  if (stage === 'content_block_stop') return 'c-content_block_stop';
  return 'c-ping';
};

const laneFor = (stage, payload = {}) => {
  if (['message_start', 'message_delta', 'message_delta_progress', 'message_stop'].includes(stage)) return laneLifecycle;
  if (stage === 'ping' || stage === 'error') return laneDiag;
  if (payload.content_block?.type === 'tool_use' || payload.delta?.type === 'input_json_delta') return laneTools;
  return laneContent;
};

const chipLabel = (stage, payload = {}) => {
  if (stage === 'content_block_start' && payload.content_block?.type === 'tool_use') return 'tool_use:' + (payload.content_block.name || 'unknown');
  if (stage === 'content_block_delta' && payload.delta?.type) return payload.delta.type;
  if (stage === 'message_delta_progress') return 'usage progress';
  return stage;
};

function updateStats() {
  el('eventsSeen').textContent = String(state.eventsSeen);
  el('activeReq').textContent = state.activeReq;
  el('lastStage').textContent = state.lastStage;
  el('outputTok').textContent = String(state.outputTokens);
}

function addChip(stage, payload) {
  const lane = laneFor(stage, payload);
  const chip = document.createElement('div');
  chip.className = 'chip';
  chip.innerHTML = '<span class="dot" style="color:' + dotColor(stage, payload) + '; background:' + dotColor(stage, payload) + '"></span><span>' + escapeHtml(chipLabel(stage, payload)) + '</span>';
  lane.prepend(chip);
  while (lane.children.length > 16) lane.removeChild(lane.lastChild);
}

function dotColor(stage, payload = {}) {
  if (stage === 'message_start' || stage === 'message_stop') return 'var(--green)';
  if (stage === 'message_delta' || stage === 'message_delta_progress') return 'var(--indigo)';
  if (stage === 'ping') return 'var(--gray)';
  if (stage === 'error') return 'var(--red)';
  if (payload.content_block?.type === 'tool_use' || payload.delta?.type === 'input_json_delta') return 'var(--violet)';
  if (payload.delta?.type === 'thinking_delta' || payload.delta?.type === 'signature_delta') return 'var(--amber)';
  return 'var(--blue)';
}

function escapeHtml(s) {
  return String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function addTimelineEvent(msg) {
  const card = document.createElement('div');
  card.className = 'event ' + colorClass(msg.stage, msg.payload);
  const pretty = JSON.stringify(msg.payload || {}, null, 2);
  card.innerHTML = 
    '<div class="event-head">' +
      '<div class="event-name">' + escapeHtml(msg.stage) + '</div>' +
      '<div class="event-seq">#' + escapeHtml(msg.seq) + '</div>' +
    '</div>' +
    '<div class="event-meta">request: ' + escapeHtml(msg.request_id || '—') + '</div>' +
    '<pre class="event-json">' + escapeHtml(pretty) + '</pre>';
  timeline.prepend(card);
  while (timeline.children.length > 80) timeline.removeChild(timeline.lastChild);
}

function handleMessage(msg) {
  state.eventsSeen += 1;
  state.activeReq = msg.request_id || state.activeReq;
  state.lastStage = msg.stage || '—';
  if (msg.stage === 'message_delta' || msg.stage === 'message_delta_progress') {
    const usage = msg.payload?.usage || {};
    state.outputTokens = usage.output_tokens || state.outputTokens;
  }
  updateStats();
  addTimelineEvent(msg);
  addChip(msg.stage, msg.payload || {});
  if (!state.paused) timeline.scrollTop = 0;
}

async function loadMeta() {
  const [viz, health] = await Promise.all([
    fetch('/v1/stream/visualization').then(r => r.json()),
    fetch('/healthz').then(r => r.json()),
  ]);
  el('profileName').textContent = health.profile || 'r2';
  el('vizEnabled').textContent = viz.enabled ? 'enabled' : 'disabled';
  el('pingValue').textContent = String(viz.ping_interval_seconds) + 's';
  el('deltaValue').textContent = String(viz.text_delta_chars) + ' chars';
  el('progressValue').textContent = viz.message_delta_every_block ? 'block-level' : 'final-only';
}

function connect() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const ws = new WebSocket(proto + '//' + location.host + '/ws/stream-visualization');
  connState.textContent = 'Live';
  connState.className = 'status-live';
  ws.onopen = () => {
    connState.textContent = 'Live';
    connState.className = 'status-live';
  };
  ws.onmessage = (event) => {
    try { handleMessage(JSON.parse(event.data)); } catch (e) { console.error(e); }
  };
  ws.onclose = () => {
    connState.textContent = 'Reconnecting…';
    connState.className = 'status-wait';
    setTimeout(connect, 1500);
  };
  ws.onerror = () => {
    connState.textContent = 'Link error';
    connState.className = 'status-wait';
  };
  setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) ws.send('ping');
  }, 12000);
}

document.getElementById('clearBtn').addEventListener('click', () => {
  timeline.innerHTML = '';
  laneLifecycle.innerHTML = '';
  laneContent.innerHTML = '';
  laneTools.innerHTML = '';
  laneDiag.innerHTML = '';
  state.eventsSeen = 0;
  state.lastStage = '—';
  state.outputTokens = 0;
  updateStats();
});

document.getElementById('pauseBtn').addEventListener('click', (e) => {
  state.paused = !state.paused;
  e.currentTarget.textContent = state.paused ? 'Resume auto-scroll' : 'Pause auto-scroll';
});

loadMeta().catch(console.error);
updateStats();
connect();