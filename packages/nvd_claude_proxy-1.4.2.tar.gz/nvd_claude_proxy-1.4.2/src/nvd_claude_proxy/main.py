"""Entrypoint: `python -m nvd_claude_proxy.main` or `nvd-claude-proxy`.

Default runtime is the classic low-latency R2 server optimized for Claude Code.
"""

from __future__ import annotations

from .r2 import main as r2_main


def run() -> None:
    r2_main()


if __name__ == "__main__":
    run()
