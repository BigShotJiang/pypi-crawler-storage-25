#!/usr/bin/env python3
"""Low-latency R2 runtime for nvd-claude-proxy.

A lightweight Anthropic Messages → NVIDIA NIM proxy optimized for fast Claude
Code interaction on the hosted NVIDIA catalog. This keeps the packaging and CLI
of nvd-claude-proxy while providing a minimal runtime path with fewer moving
parts than the full production app.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import secrets
import time
from contextlib import asynccontextmanager
from typing import AsyncIterator

import httpx
import orjson
import uvicorn
from fastapi import FastAPI, HTTPException, Request, WebSocket
from fastapi.responses import ORJSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from ._version import __version__

NVIDIA_API_KEY = os.environ.get("NVIDIA_API_KEY")
NVIDIA_BASE_URL = os.environ.get("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1")
PROXY_HOST = os.environ.get("PROXY_HOST", "127.0.0.1")
PROXY_PORT = int(os.environ.get("PROXY_PORT", os.environ.get("R2_PROXY_PORT", "8787")))
PROXY_API_KEY = os.environ.get("PROXY_API_KEY") or None
LOG_LEVEL = os.environ.get("LOG_LEVEL", "info")
PING_INTERVAL = float(os.environ.get("R2_PING_INTERVAL", "15.0"))
TEXT_DELTA_CHARS = int(os.environ.get("R2_TEXT_DELTA_CHARS", "6"))
DEFAULT_MAX_TOKENS = int(os.environ.get("NCP_DEFAULT_MAX_TOKENS", os.environ.get("R2_DEFAULT_MAX_TOKENS", "12000")))
HARD_MAX_TOKENS = int(os.environ.get("NCP_HARD_MAX_TOKENS", os.environ.get("R2_HARD_MAX_TOKENS", "12000")))
DEFAULT_MODEL = os.environ.get("NCP_DEFAULT_MODEL", "nvidia/llama-3.3-nemotron-super-49b-v1.5")
MODEL_CONTEXT_WINDOWS = {
    "nvidia/llama-3.3-nemotron-super-49b-v1.5": 131072,
    "moonshotai/kimi-k2.6": 131072,
    "qwen/qwen3-coder-480b-a35b-instruct": 131072,
    "qwen/qwen3-235b-a22b": 131072,
    "deepseek-ai/deepseek-v4-flash": 1000000,
    "deepseek-ai/deepseek-v4-pro": 1000000,
    "meta/llama-4-maverick-17b-128e-instruct": 1000000,
    "meta/llama-4-scout-17b-16e-instruct": 10000000,
    "mistralai/mistral-small-4-119b-2603": 131072,
    "google/gemma-4-31b-it": 131072,
    "minimaxai/minimax-m2.7": 204800,
}
DEFAULT_MAX_TOKENS = int(os.environ.get("NCP_DEFAULT_MAX_TOKENS", os.environ.get("R2_DEFAULT_MAX_TOKENS", "12000")))
DEFAULT_FALLBACK_MODELS = [m.strip() for m in os.environ.get("NCP_FALLBACK_MODELS", "meta/llama-4-maverick-17b-128e-instruct,deepseek-ai/deepseek-v4-flash,qwen/qwen3-coder-480b-a35b-instruct").split(",") if m.strip()]
STREAM_EVENT_ID_HEADER = os.environ.get("R2_STREAM_EVENT_ID_HEADER", "x-ncp-event-id")
STREAM_VISUALIZATION = os.environ.get("R2_STREAM_VISUALIZATION", "1").strip().lower() not in {"0", "false", "no"}
MESSAGE_DELTA_EVERY_BLOCK = os.environ.get("R2_MESSAGE_DELTA_EVERY_BLOCK", "1").strip().lower() not in {"0", "false", "no"}
SERVER_TOOL_RE = re.compile(r"_20\d{6}$")
THINK_RE = re.compile(r"<think>(.*?)</think>", re.DOTALL)
_SPLIT_RE = re.compile(r"(\s+|[.,;:!?)\]\}]|[(\[\{])")
_THINK_OPEN = "<think>"
_THINK_CLOSE = "</think>"
FINISH_TO_STOP = {
    "stop": "end_turn",
    "length": "max_tokens",
    "tool_calls": "tool_use",
    "function_call": "tool_use",
    "content_filter": "refusal",
    None: "end_turn",
}
STATUS_TO_ERR = {
    400: "invalid_request_error", 401: "authentication_error",
    403: "permission_error", 404: "not_found_error",
    413: "request_too_large", 422: "invalid_request_error",
    429: "rate_limit_error", 500: "api_error", 502: "api_error",
    503: "overloaded_error", 504: "api_error", 529: "overloaded_error",
}


class PubSub:
    def __init__(self) -> None:
        self.subscribers: list[WebSocket] = []

    async def subscribe(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self.subscribers.append(websocket)

    def unsubscribe(self, websocket: WebSocket) -> None:
        if websocket in self.subscribers:
            self.subscribers.remove(websocket)

    async def broadcast(self, message: dict) -> None:
        if not self.subscribers:
            return
        for subscriber in list(self.subscribers):
            try:
                await subscriber.send_json(message)
            except Exception:
                self.unsubscribe(subscriber)


@asynccontextmanager
async def lifespan(app: FastAPI):
    if not NVIDIA_API_KEY:
        raise RuntimeError("NVIDIA_API_KEY env var is required")
    try:
        import h2  # noqa: F401
        http2 = True
    except ImportError:
        http2 = False
    app.state.pubsub = PubSub()
    app.state.nvidia = httpx.AsyncClient(
        base_url=NVIDIA_BASE_URL,
        http2=http2,
        timeout=httpx.Timeout(connect=10.0, read=600.0, write=30.0, pool=10.0),
        limits=httpx.Limits(max_connections=100, max_keepalive_connections=20, keepalive_expiry=60.0),
        headers={
            "Authorization": f"Bearer {NVIDIA_API_KEY}",
            "Accept": "application/json",
            "User-Agent": f"nvd-claude-proxy-r2/{__version__} (h2={int(http2)})",
        },
    )
    yield
    await app.state.nvidia.aclose()


app = FastAPI(
    title="nvd-claude-proxy-r2",
    version=__version__,
    lifespan=lifespan,
    default_response_class=ORJSONResponse,
)

static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.isdir(static_dir):
    app.mount("/dashboard-assets", StaticFiles(directory=static_dir), name="dashboard-assets")


def new_request_id() -> str:
    return "req_" + secrets.token_urlsafe(18)


def new_msg_id() -> str:
    return "msg_" + secrets.token_urlsafe(18)


def new_tool_id() -> str:
    return "toolu_" + secrets.token_urlsafe(18)


def new_signature() -> str:
    return "proxy-" + secrets.token_urlsafe(24)


def map_error_type(status: int) -> str:
    return STATUS_TO_ERR.get(status, "api_error")


def _iso8601(epoch_s: int) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch_s))


def response_headers(request_id: str) -> dict[str, str]:
    return {
        "anthropic-version": "2023-06-01",
        "x-anthropic-type": "anthropic-api-response",
        "anthropic-request-id": request_id,
        "request-id": request_id,
        "anthropic-organization-id": "nvd-proxy-r2",
    }


def stream_headers(request_id: str) -> dict[str, str]:
    return {
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
        "Content-Encoding": "identity",
        **response_headers(request_id),
    }


def check_auth(request: Request):
    if not PROXY_API_KEY:
        return
    presented = (
        request.headers.get("x-api-key")
        or request.headers.get("authorization", "").removeprefix("Bearer ").strip()
    )
    if presented != PROXY_API_KEY:
        raise HTTPException(401, {
            "type": "error",
            "error": {"type": "authentication_error", "message": "invalid proxy api key"},
        })


def flatten_system(system) -> str | None:
    if system is None:
        return None
    if isinstance(system, str):
        return system
    parts = [b.get("text", "") for b in system if isinstance(b, dict) and b.get("type") == "text"]
    return "\n\n".join(parts) or None


def image_block_to_openai(block: dict) -> dict:
    src = block.get("source") or {}
    t = src.get("type")
    if t == "url":
        return {"type": "image_url", "image_url": {"url": src["url"]}}
    if t == "base64":
        return {"type": "image_url", "image_url": {"url": f"data:{src['media_type']};base64,{src['data']}"}}
    raise ValueError(f"unsupported image source type: {t}")


def translate_messages(messages: list[dict], tool_id_map: dict[str, str]) -> list[dict]:
    out: list[dict] = []
    for m in messages:
        role = m.get("role")
        content = m.get("content")
        if isinstance(content, str):
            out.append({"role": role, "content": content})
            continue
        text_parts: list[dict] = []
        tool_calls: list[dict] = []
        tool_results: list[dict] = []
        for block in content or []:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text_parts.append({"type": "text", "text": block.get("text", "")})
            elif btype == "image":
                text_parts.append(image_block_to_openai(block))
            elif btype == "tool_use":
                tool_id_map[block["id"]] = block["id"]
                tool_calls.append({
                    "id": block["id"],
                    "type": "function",
                    "function": {
                        "name": block["name"],
                        "arguments": json.dumps(block.get("input") or {}),
                    },
                })
            elif btype == "tool_result":
                tid = block["tool_use_id"]
                openai_id = tool_id_map.get(tid, tid)
                raw = block.get("content", "")
                if isinstance(raw, list):
                    raw = "".join(b.get("text", "") for b in raw if isinstance(b, dict) and b.get("type") == "text")
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": openai_id,
                    "content": str(raw) if raw is not None else "",
                })
        if role == "assistant":
            msg: dict = {"role": "assistant"}
            if text_parts:
                msg["content"] = "".join(p["text"] for p in text_parts) if all(p["type"] == "text" for p in text_parts) else text_parts
            else:
                msg["content"] = None
            if tool_calls:
                msg["tool_calls"] = tool_calls
            out.append(msg)
        else:
            if text_parts:
                out.append({
                    "role": "user",
                    "content": "".join(p["text"] for p in text_parts) if all(p["type"] == "text" for p in text_parts) else text_parts,
                })
            out.extend(tool_results)
    return out


def translate_tools(tools: list[dict] | None) -> list[dict] | None:
    if not tools:
        return None
    out = []
    for t in tools:
        if SERVER_TOOL_RE.search(t.get("type") or ""):
            continue
        out.append({
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description") or "",
                "parameters": t.get("input_schema") or {"type": "object", "properties": {}},
            },
        })
    return out or None


def translate_tool_choice(tc):
    if tc is None:
        return None
    if isinstance(tc, str):
        return tc
    t = tc.get("type")
    if t == "auto":
        return "auto"
    if t == "any":
        return "required"
    if t == "none":
        return "none"
    if t == "tool":
        return {"type": "function", "function": {"name": tc["name"]}}
    return "auto"


def candidate_models(primary: str) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for model in [primary, *DEFAULT_FALLBACK_MODELS]:
        if model and model not in seen:
            out.append(model)
            seen.add(model)
    return out


def _extract_upstream_error_text(resp: httpx.Response) -> str:
    try:
        payload = resp.json()
    except Exception:
        return resp.text[:800]
    if isinstance(payload, dict):
        detail = payload.get("detail")
        if isinstance(detail, dict) and detail.get("message"):
            return str(detail.get("message"))[:800]
        if payload.get("message"):
            return str(payload.get("message"))[:800]
        if payload.get("error"):
            return str(payload.get("error"))[:800]
    return str(payload)[:800]


def _maybe_adjust_max_tokens(resp: httpx.Response, payload: dict) -> dict | None:
    if resp.status_code != 400:
        return None
    message = _extract_upstream_error_text(resp)
    if "maximum context length" not in message and "Please reduce the length of the input prompt or the number of requested output tokens" not in message:
        return None
    current = int(payload.get("max_tokens") or DEFAULT_MAX_TOKENS)
    lowered = max(2048, min(current - 2048, current // 2))
    if lowered >= current:
        return None
    new_payload = dict(payload)
    new_payload["max_tokens"] = lowered
    return new_payload


async def post_with_fallback(nvidia: httpx.AsyncClient, payload: dict) -> tuple[httpx.Response, dict, list[dict]]:
    attempts: list[dict] = []
    working_payload = dict(payload)
    for model in candidate_models(str(payload.get("model") or "")):
        model_payload = dict(working_payload)
        model_payload["model"] = model
        resp = await nvidia.post("/chat/completions", json=model_payload)
        attempts.append({"model": model, "status": resp.status_code})
        if resp.status_code < 400:
            return resp, model_payload, attempts
        if resp.status_code in {404, 410, 429} or resp.status_code >= 500:
            continue
        adjusted = _maybe_adjust_max_tokens(resp, model_payload)
        if adjusted is not None:
            retry = await nvidia.post("/chat/completions", json=adjusted)
            attempts.append({"model": model, "status": retry.status_code, "max_tokens": adjusted.get("max_tokens")})
            if retry.status_code < 400:
                return retry, adjusted, attempts
            resp = retry
        return resp, model_payload, attempts
    return resp, model_payload, attempts


def translate_request(body: dict, tool_id_map: dict[str, str]) -> dict:
    msgs: list[dict] = []
    if (sys := flatten_system(body.get("system"))):
        msgs.append({"role": "system", "content": sys})
    msgs.extend(translate_messages(body.get("messages") or [], tool_id_map))
    payload: dict = {
        "model": body["model"],
        "messages": msgs,
        "max_tokens": int(body.get("max_tokens") or DEFAULT_MAX_TOKENS),
        "stream": bool(body.get("stream", False)),
    }
    for key in ("temperature", "top_p", "top_k"):
        if (v := body.get(key)) is not None:
            payload[key] = v
    if (ss := body.get("stop_sequences")) is not None:
        payload["stop"] = ss
    if (tools := translate_tools(body.get("tools"))):
        payload["tools"] = tools
        if (tc := translate_tool_choice(body.get("tool_choice"))) is not None:
            payload["tool_choice"] = tc
    if (md := body.get("metadata")) and isinstance(md, dict) and md.get("user_id"):
        payload["user"] = str(md["user_id"])
    return payload


def extract_thinking(content: str | None, reasoning: str | None) -> tuple[str | None, str]:
    if reasoning:
        return reasoning, content or ""
    if content and "<think>" in content:
        if (m := THINK_RE.search(content)):
            return m.group(1).strip(), THINK_RE.sub("", content, count=1).lstrip()
    return None, content or ""


def translate_response(oai: dict, model: str, tool_id_map: dict[str, str]) -> dict:
    choice = (oai.get("choices") or [{}])[0]
    msg = choice.get("message") or {}
    blocks: list[dict] = []
    thinking, remaining = extract_thinking(msg.get("content"), msg.get("reasoning_content"))
    if thinking:
        blocks.append({"type": "thinking", "thinking": thinking, "signature": new_signature()})
    if remaining:
        blocks.append({"type": "text", "text": remaining})
    for tc in msg.get("tool_calls") or []:
        fn = tc.get("function") or {}
        try:
            args = json.loads(fn.get("arguments") or "{}")
        except json.JSONDecodeError:
            args = {"_raw_arguments": fn.get("arguments", "")}
        oid = tc.get("id") or new_tool_id()
        anth_id = oid if oid.startswith("toolu_") else new_tool_id()
        tool_id_map[anth_id] = oid
        blocks.append({
            "type": "tool_use",
            "id": anth_id,
            "name": fn.get("name", ""),
            "input": args,
        })
    usage = oai.get("usage") or {}
    return {
        "id": new_msg_id(),
        "type": "message",
        "role": "assistant",
        "model": model,
        "content": blocks or [{"type": "text", "text": ""}],
        "stop_reason": FINISH_TO_STOP.get(choice.get("finish_reason"), "end_turn"),
        "stop_sequence": None,
        "usage": {
            "input_tokens": usage.get("prompt_tokens", 0),
            "output_tokens": usage.get("completion_tokens", 0),
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
    }


def retokenize(s: str, max_chars: int = TEXT_DELTA_CHARS) -> list[str]:
    if len(s) <= max_chars:
        return [s]
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        end = min(i + max_chars, n)
        if end < n:
            ms = list(_SPLIT_RE.finditer(s[i:end]))
            if ms:
                end = i + ms[-1].end()
        out.append(s[i:end])
        i = end
    return out


def _safe_suffix_len(buf: str, target: str) -> int:
    for k in range(min(len(buf), len(target) - 1), 0, -1):
        if buf.endswith(target[:k]):
            return k
    return 0


class StreamTranslator:
    def __init__(self, model: str, tool_id_map: dict[str, str]):
        self.model = model
        self.tool_id_map = tool_id_map
        self.next_index = 0
        self.open_type: str | None = None
        self.open_index: int | None = None
        self.signature_sent = False
        self.in_inline_think = False
        self.text_buf = ""
        self.tools: dict[int, dict] = {}
        self.stop_reason = "end_turn"
        self.usage_in = 0
        self.usage_out = 0

    @staticmethod
    def _ev(event: str, data: dict) -> dict:
        return {"event": event, "data": data}

    def _close_open(self):
        if self.open_index is None:
            return
        if self.open_type == "thinking" and not self.signature_sent:
            yield self._ev("content_block_delta", {
                "type": "content_block_delta",
                "index": self.open_index,
                "delta": {"type": "signature_delta", "signature": new_signature()},
            })
            self.signature_sent = True
        yield self._ev("content_block_stop", {"type": "content_block_stop", "index": self.open_index})
        self.open_type = None
        self.open_index = None
        self.signature_sent = False

    def _open_text(self):
        idx = self.next_index
        self.next_index += 1
        self.open_type = "text"
        self.open_index = idx
        yield self._ev("content_block_start", {"type": "content_block_start", "index": idx, "content_block": {"type": "text", "text": ""}})

    def _open_thinking(self):
        idx = self.next_index
        self.next_index += 1
        self.open_type = "thinking"
        self.open_index = idx
        self.signature_sent = False
        yield self._ev("content_block_start", {"type": "content_block_start", "index": idx, "content_block": {"type": "thinking", "thinking": "", "signature": ""}})

    def _emit_text(self, s: str):
        if not s:
            return
        if self.open_type != "text":
            yield from self._close_open()
            yield from self._open_text()
        for piece in retokenize(s):
            yield self._ev("content_block_delta", {"type": "content_block_delta", "index": self.open_index, "delta": {"type": "text_delta", "text": piece}})

    def _emit_thinking(self, s: str):
        if not s:
            return
        if self.open_type != "thinking":
            yield from self._close_open()
            yield from self._open_thinking()
        for piece in retokenize(s):
            yield self._ev("content_block_delta", {"type": "content_block_delta", "index": self.open_index, "delta": {"type": "thinking_delta", "thinking": piece}})

    def _process_text(self, s: str):
        buf = self.text_buf + s
        self.text_buf = ""
        while buf:
            if self.in_inline_think:
                idx = buf.find(_THINK_CLOSE)
                if idx == -1:
                    suf = _safe_suffix_len(buf, _THINK_CLOSE)
                    if suf:
                        yield from self._emit_thinking(buf[:-suf])
                        self.text_buf = buf[-suf:]
                    else:
                        yield from self._emit_thinking(buf)
                    return
                yield from self._emit_thinking(buf[:idx])
                yield from self._close_open()
                self.in_inline_think = False
                buf = buf[idx + len(_THINK_CLOSE):]
            else:
                idx = buf.find(_THINK_OPEN)
                if idx == -1:
                    suf = _safe_suffix_len(buf, _THINK_OPEN)
                    if suf:
                        yield from self._emit_text(buf[:-suf])
                        self.text_buf = buf[-suf:]
                    else:
                        yield from self._emit_text(buf)
                    return
                yield from self._emit_text(buf[:idx])
                yield from self._close_open()
                yield from self._open_thinking()
                self.in_inline_think = True
                buf = buf[idx + len(_THINK_OPEN):]

    def feed(self, chunk: dict):
        if not chunk.get("choices"):
            if (u := chunk.get("usage")):
                self.usage_in = u.get("prompt_tokens", self.usage_in)
                self.usage_out = u.get("completion_tokens", self.usage_out)
            return
        choice = chunk["choices"][0]
        delta = choice.get("delta") or {}
        finish = choice.get("finish_reason")
        if (rc := delta.get("reasoning_content")):
            yield from self._emit_thinking(rc)
        if (text := delta.get("content")):
            yield from self._process_text(text)
        for tc in delta.get("tool_calls") or []:
            o_idx = tc.get("index", 0)
            buf = self.tools.setdefault(o_idx, {"oid": None, "name": None, "started": False, "anth_id": None, "anth_idx": None})
            fn = tc.get("function") or {}
            if (i := tc.get("id")):
                buf["oid"] = i
            if (n := fn.get("name")):
                buf["name"] = n
            args = fn.get("arguments")
            if not buf["started"] and buf["oid"] and buf["name"]:
                yield from self._close_open()
                anth_id = buf["oid"] if str(buf["oid"]).startswith("toolu_") else new_tool_id()
                self.tool_id_map[anth_id] = buf["oid"]
                buf["anth_id"] = anth_id
                buf["anth_idx"] = self.next_index
                self.next_index += 1
                self.open_type = "tool_use"
                self.open_index = buf["anth_idx"]
                buf["started"] = True
                yield self._ev("content_block_start", {"type": "content_block_start", "index": buf["anth_idx"], "content_block": {"type": "tool_use", "id": anth_id, "name": buf["name"], "input": {}}})
            if buf["started"] and args:
                yield self._ev("content_block_delta", {"type": "content_block_delta", "index": buf["anth_idx"], "delta": {"type": "input_json_delta", "partial_json": args}})
        if finish:
            if self.text_buf:
                tail, self.text_buf = self.text_buf, ""
                yield from (self._emit_thinking if self.in_inline_think else self._emit_text)(tail)
            yield from self._close_open()
            self.stop_reason = FINISH_TO_STOP.get(finish, "end_turn")

    def finalize(self):
        if self.text_buf:
            yield from (self._emit_thinking if self.in_inline_think else self._emit_text)(self.text_buf)
            self.text_buf = ""
        yield from self._close_open()
        yield self._ev("message_delta", {"type": "message_delta", "delta": {"stop_reason": self.stop_reason, "stop_sequence": None}, "usage": {"input_tokens": self.usage_in, "output_tokens": self.usage_out, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0}})
        yield self._ev("message_stop", {"type": "message_stop"})


def encode_sse(event: str, data: dict, event_id: str | None = None) -> bytes:
    parts: list[bytes] = []
    if event_id is not None:
        parts.append(b"id: " + event_id.encode() + b"\n")
    parts.append(b"event: " + event.encode() + b"\n")
    parts.append(b"data: " + orjson.dumps(data) + b"\n\n")
    return b"".join(parts)


def visualizer_event(seq: int, request_id: str, stage: str, payload: dict | None = None) -> dict:
    return {
        "type": "ncp_stream_event",
        "seq": seq,
        "request_id": request_id,
        "stage": stage,
        "payload": payload or {},
    }


def estimate_input_tokens(body: dict) -> int:
    def walk(o):
        if isinstance(o, dict):
            total = 0
            for k, v in o.items():
                if k == "data":
                    continue
                total += walk(v)
            return total
        if isinstance(o, list):
            return sum(walk(v) for v in o)
        if isinstance(o, str):
            return len(o)
        return 0
    return max(walk(body) // 4, 1)


def context_window_for_model(model: str) -> int:
    return MODEL_CONTEXT_WINDOWS.get(model, 131072)


def apply_budget_guardrails(body: dict, request_id: str) -> tuple[dict | None, ORJSONResponse | None]:
    model = str(body.get("model") or DEFAULT_MODEL)
    ctx = context_window_for_model(model)
    est_input = estimate_input_tokens(body)

    if est_input >= ctx:
        msg = (
            f"Input is too large for model '{model}'. Estimated input tokens: {est_input}, "
            f"context window: {ctx}. Start a fresh Claude session, use /clear, reduce codebase scope, "
            f"or choose a larger-context model."
        )
        return None, ORJSONResponse(
            {"type": "error", "error": {"type": "invalid_request_error", "message": msg}},
            status_code=400,
            headers=response_headers(request_id),
        )

    requested = body.get("max_tokens")
    if requested is None:
        requested = DEFAULT_MAX_TOKENS
    try:
        requested_int = int(requested)
    except Exception:
        requested_int = DEFAULT_MAX_TOKENS

    requested_int = max(256, min(requested_int, HARD_MAX_TOKENS))
    available = max(256, ctx - est_input - 1024)
    effective = min(requested_int, available)

    if effective < 256:
        msg = (
            f"Not enough context budget remains for model '{model}'. Estimated input tokens: {est_input}, "
            f"context window: {ctx}. Start a fresh Claude session, use /clear, reduce codebase scope, "
            f"or choose a larger-context model."
        )
        return None, ORJSONResponse(
            {"type": "error", "error": {"type": "invalid_request_error", "message": msg}},
            status_code=400,
            headers=response_headers(request_id),
        )

    new_body = dict(body)
    new_body["max_tokens"] = effective
    meta = dict(new_body.get("metadata") or {})
    meta.setdefault("ncp_budget_guardrails", {
        "estimated_input_tokens": est_input,
        "requested_max_tokens": requested_int,
        "effective_max_tokens": effective,
        "context_window": ctx,
        "hard_max_tokens": HARD_MAX_TOKENS,
    })
    new_body["metadata"] = meta
    return new_body, None


@app.get("/dashboard/stream")
async def dashboard_stream():
    return FileResponse(os.path.join(static_dir, "r2-stream.html"))


@app.websocket("/ws/stream-visualization")
async def ws_stream_visualization(websocket: WebSocket):
    await app.state.pubsub.subscribe(websocket)
    try:
        while True:
            await websocket.receive_text()
    except Exception:
        app.state.pubsub.unsubscribe(websocket)


@app.get("/healthz")
async def healthz():
    return {"status": "ok", "version": __version__, "profile": "r2", "dashboard": "/dashboard/stream", "stream_visualization": STREAM_VISUALIZATION, "message_delta_every_block": MESSAGE_DELTA_EVERY_BLOCK, "default_model": DEFAULT_MODEL, "default_max_tokens": DEFAULT_MAX_TOKENS, "hard_max_tokens": HARD_MAX_TOKENS}


@app.get("/v1/models")
async def list_models(request: Request):
    nvidia: httpx.AsyncClient = request.app.state.nvidia
    r = await nvidia.get("/models")
    return ORJSONResponse(r.json(), status_code=r.status_code)


@app.get("/v1/stream/visualization")
async def stream_visualization():
    return {
        "enabled": STREAM_VISUALIZATION,
        "event_name": "ncp_visualization",
        "event_id_header": STREAM_EVENT_ID_HEADER,
        "message_delta_every_block": MESSAGE_DELTA_EVERY_BLOCK,
        "text_delta_chars": TEXT_DELTA_CHARS,
        "default_model": DEFAULT_MODEL,
        "default_max_tokens": DEFAULT_MAX_TOKENS,
        "hard_max_tokens": HARD_MAX_TOKENS,
        "ping_interval_seconds": PING_INTERVAL,
    }


@app.post("/v1/messages/count_tokens")
async def count_tokens(request: Request):
    check_auth(request)
    request_id = new_request_id()
    body = await request.json()
    return ORJSONResponse({"input_tokens": estimate_input_tokens(body)}, headers=response_headers(request_id))


@app.post("/v1/messages")
async def messages(request: Request):
    check_auth(request)
    request_id = new_request_id()
    try:
        body = await request.json()
    except Exception as e:
        return ORJSONResponse({"type": "error", "error": {"type": "invalid_request_error", "message": f"bad JSON: {e}"}}, status_code=400, headers=response_headers(request_id))
    if "model" not in body or "messages" not in body:
        return ORJSONResponse({"type": "error", "error": {"type": "invalid_request_error", "message": "model and messages are required"}}, status_code=400, headers=response_headers(request_id))
    body, budget_error = apply_budget_guardrails(body, request_id)
    if budget_error is not None:
        return budget_error
    tool_id_map: dict[str, str] = {}
    payload = translate_request(body, tool_id_map)
    nvidia: httpx.AsyncClient = request.app.state.nvidia
    if not body.get("stream"):
        try:
            resp, final_payload, attempts = await post_with_fallback(nvidia, payload)
        except httpx.HTTPError as e:
            return ORJSONResponse({"type": "error", "error": {"type": "api_error", "message": str(e)[:500]}}, status_code=502, headers=response_headers(request_id))
        if resp.status_code >= 400:
            body_err = _extract_upstream_error_text(resp)
            message = str(body_err)[:500]
            if "maximum context length" in message or "input tokens" in message.lower():
                message = message + " | Hint: start a fresh Claude session, use /clear, reduce scope, or lower history/tool load."
            return ORJSONResponse({"type": "error", "error": {"type": map_error_type(resp.status_code), "message": message}}, status_code=resp.status_code, headers=response_headers(request_id))
        out = translate_response(resp.json(), body["model"], tool_id_map)
        out["usage"].setdefault("server_tool_use", {})
        out["usage"]["server_tool_use"]["attempts"] = attempts
        return ORJSONResponse(out, headers=response_headers(request_id))
    return StreamingResponse(
        stream_response(request, body, payload, tool_id_map, request_id),
        media_type="text/event-stream",
        headers=stream_headers(request_id),
    )


async def open_stream_with_fallback(nvidia: httpx.AsyncClient, payload: dict) -> tuple[httpx.Response | None, list[dict], str | None, dict]:
    attempts: list[dict] = []
    working_payload = dict(payload)
    last_error: str | None = None
    for model in candidate_models(str(payload.get("model") or "")):
        model_payload = dict(working_payload)
        model_payload["model"] = model
        req = nvidia.build_request("POST", "/chat/completions", json={**model_payload, "stream": True, "stream_options": {"include_usage": True}})
        resp = await nvidia.send(req, stream=True)
        attempts.append({"model": model, "status": resp.status_code})
        if resp.status_code < 400:
            return resp, attempts, None, model_payload
        last_error = _extract_upstream_error_text(resp)
        adjusted = _maybe_adjust_max_tokens(resp, model_payload)
        if adjusted is not None:
            await resp.aclose()
            req2 = nvidia.build_request("POST", "/chat/completions", json={**adjusted, "stream": True, "stream_options": {"include_usage": True}})
            resp2 = await nvidia.send(req2, stream=True)
            attempts.append({"model": model, "status": resp2.status_code, "max_tokens": adjusted.get("max_tokens")})
            if resp2.status_code < 400:
                return resp2, attempts, None, adjusted
            last_error = _extract_upstream_error_text(resp2)
            await resp2.aclose()
            return None, attempts, last_error, adjusted
        await resp.aclose()
        if resp.status_code not in {404, 410, 429} and resp.status_code < 500:
            return None, attempts, last_error, model_payload
    return None, attempts, last_error, working_payload


async def stream_response(request: Request, body: dict, payload: dict, tool_id_map: dict[str, str], request_id: str) -> AsyncIterator[bytes]:
    nvidia: httpx.AsyncClient = request.app.state.nvidia
    model = body["model"]
    msg_id = new_msg_id()
    event_seq = 1
    block_closes_since_usage = 0

    def next_event_id() -> str:
        nonlocal event_seq
        current = str(event_seq)
        event_seq += 1
        return current

    async def push_visualization(stage: str, payload: dict) -> None:
        if not STREAM_VISUALIZATION:
            return
        await request.app.state.pubsub.broadcast(visualizer_event(event_seq - 1, request_id, stage, payload))

    def emit_wire(event: str, data: dict) -> bytes:
        return encode_sse(event, data, event_id=next_event_id())

    start_payload = {"type": "message_start", "message": {"id": msg_id, "type": "message", "role": "assistant", "content": [], "model": model, "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 0, "output_tokens": 0, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0}}}
    yield emit_wire("message_start", start_payload)
    await push_visualization("message_start", {"model": model, "message_id": msg_id})
    st = StreamTranslator(model=model, tool_id_map=tool_id_map)
    queue: asyncio.Queue = asyncio.Queue(maxsize=256)
    DONE = object()
    ERROR = object()

    async def producer():
        stream_resp: httpx.Response | None = None
        try:
            stream_resp, attempts, open_error, final_payload = await open_stream_with_fallback(nvidia, payload)
            if stream_resp is None:
                raise RuntimeError(open_error or "Unable to open upstream stream")
            await request.app.state.pubsub.broadcast({"type": "ncp_stream_event", "seq": 0, "request_id": request_id, "stage": "upstream_open", "payload": {"attempts": attempts, "model": final_payload.get("model"), "max_tokens": final_payload.get("max_tokens")}})
            async for line in stream_resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data = line[5:].lstrip()
                if data == "[DONE]":
                    break
                try:
                    await queue.put(json.loads(data))
                except json.JSONDecodeError:
                    continue
        except Exception as e:
            await queue.put((ERROR, e))
        finally:
            if stream_resp is not None:
                try:
                    await stream_resp.aclose()
                except Exception:
                    pass
            await queue.put(DONE)

    prod = asyncio.create_task(producer())
    try:
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=PING_INTERVAL)
            except asyncio.TimeoutError:
                yield emit_wire("ping", {"type": "ping"})
                await push_visualization("ping", {})
                if await request.is_disconnected():
                    prod.cancel()
                    return
                continue
            if item is DONE:
                break
            if isinstance(item, tuple) and item and item[0] is ERROR:
                exc = item[1]
                status = getattr(getattr(exc, "response", None), "status_code", 500)
                err_payload = {"type": "error", "error": {"type": map_error_type(status), "message": str(exc)[:500]}}
                yield emit_wire("error", err_payload)
                await push_visualization("error", err_payload)
                break
            for ev in st.feed(item):
                yield emit_wire(ev["event"], ev["data"])
                await push_visualization(ev["event"], ev["data"])
                if MESSAGE_DELTA_EVERY_BLOCK and ev["event"] == "content_block_stop":
                    block_closes_since_usage += 1
                    usage_payload = {
                        "type": "message_delta",
                        "delta": {"stop_reason": None, "stop_sequence": None},
                        "usage": {
                            "input_tokens": st.usage_in,
                            "output_tokens": st.usage_out,
                            "cache_creation_input_tokens": 0,
                            "cache_read_input_tokens": 0,
                        },
                    }
                    yield emit_wire("message_delta", usage_payload)
                    await push_visualization("message_delta_progress", {"block_closes": block_closes_since_usage, "usage": usage_payload["usage"]})
        for ev in st.finalize():
            yield emit_wire(ev["event"], ev["data"])
            await push_visualization(ev["event"], ev["data"])
    finally:
        if not prod.done():
            prod.cancel()
            try:
                await prod
            except (asyncio.CancelledError, Exception):
                pass


def main():
    if not NVIDIA_API_KEY:
        raise SystemExit("NVIDIA_API_KEY env var is required")
    kwargs = {"host": PROXY_HOST, "port": PROXY_PORT, "log_level": LOG_LEVEL, "access_log": False}
    try:
        import uvloop  # noqa: F401
        kwargs["loop"] = "uvloop"
    except ImportError:
        pass
    try:
        import httptools  # noqa: F401
        kwargs["http"] = "httptools"
    except ImportError:
        pass
    uvicorn.run(app, **kwargs)


if __name__ == "__main__":
    main()
