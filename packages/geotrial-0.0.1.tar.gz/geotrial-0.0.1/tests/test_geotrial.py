#!/usr/bin/env python

"""Tests for `geotrial` package."""


import unittest

from geotrial import geotrial


class TestGeotrial(unittest.TestCase):
    """Tests for `geotrial` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
