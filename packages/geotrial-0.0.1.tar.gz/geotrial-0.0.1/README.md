# geotrial


[![image](https://img.shields.io/pypi/v/geotrial.svg)](https://pypi.python.org/pypi/geotrial)
[![image](https://img.shields.io/conda/vn/conda-forge/geotrial.svg)](https://anaconda.org/conda-forge/geotrial)


**Just a dummy package that created by M.R.P.**


-   Free software: MIT license
-   Documentation: https://AditPradana36.github.io/geotrial
    

## Features

-   TODO
