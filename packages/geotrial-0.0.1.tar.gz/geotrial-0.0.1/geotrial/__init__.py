"""Top-level package for geotrial."""

__author__ = """Mohammad Raditia Pradana"""
__email__ = 'radityapradana20@gmail.com'
__version__ = '0.0.1'
