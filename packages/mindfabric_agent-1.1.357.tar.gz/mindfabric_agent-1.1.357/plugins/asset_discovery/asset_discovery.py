"""
Asset Discovery Plugin

Comprehensive infrastructure asset discovery plugin that collects:
- System assets (servers, VMs, containers)
- Running services and processes
- Network interfaces and connections
- Hardware specifications
- Service dependencies and connections
"""

import asyncio
from datetime import datetime, timedelta
import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import os
import platform
import re
import socket
import struct
import sys
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

try:
    import psutil
except ImportError:
    psutil = None

from plugins.base_plugin import BasePlugin
from utils.logger import logger
from .proto import (
    Asset, Service, AssetConnection, AssetDiscoveryResult,
    NetworkInterface, HardwareSpecs
)
# Import modular components
from .modules.utils import get_local_ip, generate_asset_id
from .modules.discovery import AssetDiscoverer, ProviderDetector, DatabaseDiscovery, DockerKubernetesDiscovery, ServiceMeshDiscovery
from .modules.enumerations import (
    APIDiscovery, CertificateDiscovery, ServiceEnumerator, CloudServiceEnumerator,
    DNSEnumerator, OSINTDiscovery, IaCDiscovery, IoTDeviceDiscovery
)
from .modules.analysis import WebFingerprinter, SideChannelDetector, ProtocolAnalyzer

class AssetDiscoveryPlugin(BasePlugin):
    """
    Asset Discovery Plugin for Infrastructure Intelligence
    
    Provides comprehensive asset discovery capabilities:
    - System asset detection (local and remote)
    - Service discovery and enumeration
    - Network interface analysis
    - Hardware specification collection
    - Connection mapping between assets
    """
    VERSION = "1.0.0"

    # Known provider-managed infrastructure endpoints that can appear in network traces.
    # These are strong signals and safe to tag as provider-service/not-ours when discovered.
    PROVIDER_SERVICE_SPECIAL_IPS: Dict[str, str] = {
        # Cloud instance metadata (AWS/Azure/GCP)
        "169.254.169.254": "Cloud instance metadata service (IMDS)",
        # AWS Route 53 Resolver / AmazonProvidedDNS (link-local form)
        "169.254.169.253": "AWS Route 53 Resolver (AmazonProvidedDNS)",
        # AWS ECS task metadata endpoint (common on ECS/EKS nodes)
        "169.254.170.2": "AWS ECS task metadata endpoint",
        # AWS time synchronization (NTP)
        "169.254.169.123": "AWS time sync service (NTP)",
        # Azure platform IP (health probes/DHCP/DNS/platform services)
        "168.63.129.16": "Azure platform service IP",
    }

    # Provider-managed DNS resolvers that commonly appear in /etc/resolv.conf on cloud hosts.
    # Keep this list very small & explicit to avoid false positives.
    PROVIDER_SERVICE_DNS_RESOLVERS: Dict[str, Dict[str, str]] = {
        "DigitalOcean": {
            "67.207.67.2": "DigitalOcean DNS resolver (from /etc/resolv.conf)",
            "67.207.67.3": "DigitalOcean DNS resolver (from /etc/resolv.conf)",
        }
    }

    # Known CDN and public service IP ranges that should not be created as assets.
    # These are external services that agents connect to, not infrastructure assets.
    KNOWN_CDN_IP_RANGES: List[Tuple[str, str]] = [
        # Cloudflare CDN (common ranges)
        ("104.16.0.0/12", "Cloudflare CDN"),
        ("172.64.0.0/13", "Cloudflare CDN"),
        ("173.245.48.0/20", "Cloudflare CDN"),
        ("188.114.96.0/20", "Cloudflare CDN"),
        ("198.41.128.0/17", "Cloudflare CDN"),
        ("2400:cb00::/32", "Cloudflare CDN IPv6"),
        ("2606:4700::/32", "Cloudflare CDN IPv6"),
        ("2803:f800::/32", "Cloudflare CDN IPv6"),
        ("2a06:98c0::/29", "Cloudflare CDN IPv6"),
        ("2c0f:f248::/32", "Cloudflare CDN IPv6"),
    ]
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.local_hostname = socket.gethostname()
        self.local_ip = get_local_ip(self.local_hostname)
        self.discovered_assets = {}
        self.discovered_services = {}
        self.discovered_connections = []
        
        # Initialize modular components
        self.asset_discoverer = AssetDiscoverer(self.local_hostname, self.local_ip)
        try:
            from .modules.connections import ConnectionDiscoverer
            self.connection_discoverer = ConnectionDiscoverer()
        except ImportError:
            self.connection_discoverer = None
        
        # ProtoBuilders is not a class, it's a collection of functions
        # Import functions directly instead
        try:
            from .modules.builders import (
                dict_to_asset, dict_to_service, dict_to_connection,
                asset_to_dict, service_to_dict, connection_to_dict
            )
            self.dict_to_asset = dict_to_asset
            self.dict_to_service = dict_to_service
            self.dict_to_connection = dict_to_connection
            self.asset_to_dict = asset_to_dict
            self.service_to_dict = service_to_dict
            self.connection_to_dict = connection_to_dict
        except ImportError:
            # If builders can't be imported, set to None
            self.dict_to_asset = None
            self.dict_to_service = None
            self.dict_to_connection = None
            self.asset_to_dict = None
            self.service_to_dict = None
            self.connection_to_dict = None

    def _feature_enabled(self, env_name: str, default: str = "0") -> bool:
        try:
            return str(os.getenv(env_name, default)).strip().lower() in ("1", "true", "yes", "on")
        except Exception:
            return False

    async def _read_resolv_conf_nameservers(self) -> List[str]:
        """
        Best-effort DNS server discovery from /etc/resolv.conf.
        Used only for conservative provider-service tagging (e.g. internal resolvers).
        """
        def _read() -> List[str]:
            try:
                p = Path("/etc/resolv.conf")
                if not p.exists():
                    return []
                out: List[str] = []
                for line in p.read_text(errors="ignore").splitlines():
                    s = line.strip()
                    if not s or s.startswith("#"):
                        continue
                    if s.lower().startswith("nameserver "):
                        ip = s.split(None, 1)[1].strip()
                        if ip:
                            out.append(ip)
                # stable unique
                return list(dict.fromkeys(out))
            except Exception:
                return []

        try:
            return await asyncio.to_thread(_read)
        except Exception:
            return []

    def _provider_service_reason_for_ip(self, *, ip_str: str, local_provider: str, local_ip: Optional[str], dns_servers: List[str]) -> Optional[str]:
        try:
            reason = self.PROVIDER_SERVICE_SPECIAL_IPS.get(str(ip_str).strip())
            if reason:
                return reason
        except Exception:
            pass

        # Conservative DNS-based tagging:
        # - Explicit known provider resolvers (DigitalOcean)
        # - Cloud VPC/VNet resolver at "... .2" when it is a configured nameserver and matches local /24
        try:
            ip_norm = str(ip_str).strip()
            if ip_norm in (dns_servers or []):
                lp = str(local_provider or "").strip()

                # Known provider resolvers
                try:
                    by_provider = self.PROVIDER_SERVICE_DNS_RESOLVERS.get(lp) or {}
                    if isinstance(by_provider, dict) and ip_norm in by_provider:
                        return str(by_provider[ip_norm])
                except Exception:
                    pass

                # Generic ".2 resolver" heuristic (cloud-only, local-subnet match).
                try:
                    if lp in ("AWS", "Azure", "GCP", "DigitalOcean"):
                        ip_obj = ipaddress.ip_address(ip_norm)
                        lip_obj = ipaddress.ip_address(str(local_ip).strip()) if local_ip else None
                        if isinstance(ip_obj, ipaddress.IPv4Address) and isinstance(lip_obj, ipaddress.IPv4Address):
                            ip_parts = ip_norm.split(".")
                            lip_parts = str(lip_obj).split(".")
                            if len(ip_parts) == 4 and len(lip_parts) == 4 and ip_parts[:3] == lip_parts[:3]:
                                if int(ip_parts[-1]) == 2:
                                    return f"{lp} VPC/VNet DNS resolver (local /24 + .2, from /etc/resolv.conf)"
                except Exception:
                    pass
        except Exception:
            pass

        return None

    def _is_routable_ip(self, ip_str: str) -> bool:
        try:
            ip_obj = ipaddress.ip_address(str(ip_str).strip())
            # Allow private RFC1918 (internal DNS PTR can exist).
            # Skip loopback/link-local/multicast/unspecified.
            return not (ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_multicast or getattr(ip_obj, "is_unspecified", False))
        except Exception:
            return False

    async def _reverse_dns_ptr(self, ip_str: str) -> Optional[str]:
        """
        Best-effort reverse DNS (PTR) lookup for an IP.
        Never raises; uses tight timeouts and caches results to avoid repeated blocking calls.
        """
        ip_norm = str(ip_str or "").strip()
        if not ip_norm:
            return None
        if not self._is_routable_ip(ip_norm):
            return None

        try:
            if not hasattr(self, "_rdns_cache"):
                self._rdns_cache = {}
            # Prevent unbounded growth in long-running agent processes.
            # Reverse DNS results can be noisy (especially on large networks) and caching should remain bounded.
            if len(self._rdns_cache) > int(os.getenv("ASSET_DISCOVERY_RDNS_CACHE_MAX", "2048")):
                self._rdns_cache.clear()
            if ip_norm in self._rdns_cache:
                return self._rdns_cache[ip_norm]
        except Exception:
            pass

        import socket as _socket

        async def _do(ip: str) -> Optional[str]:
            try:
                res = await asyncio.wait_for(asyncio.to_thread(_socket.gethostbyaddr, ip), timeout=0.7)
                if isinstance(res, tuple) and res and isinstance(res[0], str):
                    hn = res[0].strip().rstrip(".")
                    if hn and hn != ip:
                        return hn
            except Exception:
                return None
            return None

        hn = await _do(ip_norm)
        try:
            self._rdns_cache[ip_norm] = hn
        except Exception:
            pass
        return hn

    def _mark_asset_as_provider_service(self, asset: Dict[str, Any], reason: str) -> None:
        try:
            tags_val = asset.get("tags")
            tags = tags_val if isinstance(tags_val, list) else []
            asset["tags"] = list(dict.fromkeys(tags + ["provider-service", "not-ours"]))
            asset["role"] = asset.get("role") or "provider-service"

            existing = asset.get("detection_reason") or ""
            suffix = f" Provider-managed node: {reason}."
            if suffix not in str(existing):
                asset["detection_reason"] = (str(existing).rstrip() + suffix).strip()
        except Exception:
            # best-effort; never fail discovery due to tagging
            return
    
    async def run(self):
        """Main entry point for asset discovery"""
        # Default to "quick" for safety/performance when invoked without explicit options
        # (e.g. via scheduler). Users can still request "full" explicitly.
        mode = self.options.get("mode", "quick")
        return await self.hook_discover(mode=mode)
    
    async def hook_discover(self, mode: str = "full", **kwargs) -> Dict[str, Any]:
        """
        Discover infrastructure assets and services.
        
        Args:
            mode (str): Discovery mode - "full", "quick", "network-only", "local-only"
            **kwargs: Additional parameters
            
        Returns:
            dict: Asset discovery results
            
        Examples:
            plugin:asset_discovery discover mode=full
            plugin:asset_discovery discover mode=quick
            plugin:asset_discovery discover mode=local-only
        """
        try:
            scanned_at = datetime.utcnow().isoformat()
            start_t = time.monotonic()
            # Backend command timeout is ~5 minutes; keep a safety margin.
            # Full mode can be heavy in real networks, so we enforce an overall budget and per-step timeouts
            # to always return partial results (so backend can persist services/assets).
            overall_budget_s = 240 if mode == "full" else 90

            def time_left() -> float:
                return max(0.0, overall_budget_s - (time.monotonic() - start_t))
            
            # Discover local asset using modular component
            local_asset = await self.asset_discoverer.discover_local_asset()
            if local_asset:
                asset_id = local_asset["id"]
                self.discovered_assets[asset_id] = local_asset
            
            # Discover services on local asset
            # NOTE: Service discovery can be heavy. Enforce a time budget so we still return output
            # (and persist partial results) within the platform/agent timeout.
            services: List[Dict[str, Any]] = []
            local_asset_id = local_asset["id"] if local_asset else None
            if local_asset_id:
                if mode == "full":
                    # Deep discovery but time-bounded
                    try:
                        services = await asyncio.wait_for(self._discover_services(local_asset_id), timeout=120)
                    except asyncio.TimeoutError:
                        services = list(self.discovered_services.values())
                    except Exception as e:
                        logger.error(f"Service discovery failed: {e}", exc_info=True)
                        services = list(self.discovered_services.values())
                elif mode in ["quick", "local-only"]:
                    # Lightweight local discovery so Services Table isn't empty.
                    try:
                        services = await asyncio.wait_for(self._discover_services_light(local_asset_id), timeout=20)
                    except Exception as e:
                        logger.debug(f"Lightweight service discovery failed: {e}")
                        services = []

                for service in services:
                    try:
                        self.discovered_services[service["id"]] = service
                    except Exception:
                        pass
            
            # Discover network connections using modular component
            if mode in ["full", "network-only"]:
                from .modules.connections import ConnectionDiscoverer
                connection_discoverer = ConnectionDiscoverer()
                try:
                    # Connection discovery can hang in containerized environments; cap it.
                    connections = await asyncio.wait_for(
                        connection_discoverer.discover_connections(self.discovered_assets),
                        timeout=min(30, max(5, int(time_left())))
                    )
                    self.discovered_connections.extend(connections)
                except asyncio.TimeoutError:
                    logger.debug("Connection discovery timed out. Continuing.")
                except Exception as e:
                    logger.debug(f"Connection discovery failed: {e}")
            
            # Scan subnet for other hosts (full and network-only modes)
            if mode in ["full", "network-only"] and local_asset:
                network_assets: List[Dict[str, Any]] = []
                try:
                    # Network scan can be expensive; cap it so we still return.
                    network_assets = await asyncio.wait_for(
                        self._discover_network_assets(local_asset),
                        timeout=min(60, max(10, int(time_left())))
                    )
                except asyncio.TimeoutError:
                    logger.debug("Network asset discovery timed out. Continuing with local-only results.")
                except Exception as e:
                    logger.debug(f"Network asset discovery failed: {e}")
                for asset in network_assets:
                    if asset["id"] not in self.discovered_assets:
                        self.discovered_assets[asset["id"]] = asset

                # Active port scan (full mode): enrich discovered hosts with more open ports.
                # This produces a richer, more informative graph even in small test environments.
                if mode == "full" and network_assets:
                    try:
                        await asyncio.wait_for(
                            self._active_port_scan_network_assets(network_assets, scanned_at=scanned_at),
                            timeout=min(60, max(10, int(time_left())))
                        )
                    except Exception as e:
                        logger.debug(f"Active port scan failed: {e}")

                # Edges from outbound services: if a process/service has remoteAddress (ip:port),
                # build dependency edges asset -> remote host.
                if mode == "full" and local_asset and services:
                    try:
                        await self._emit_edges_from_outbound_services(local_asset=local_asset, services=services, scanned_at=scanned_at)
                    except Exception as e:
                        logger.debug(f"Failed to emit edges from outbound services: {e}")

                # Internal inbound SSH edges (topology): internal client -> this asset
                if mode == "full" and local_asset and services:
                    try:
                        await self._emit_edges_from_internal_inbound_ssh(local_asset=local_asset, services=services, scanned_at=scanned_at, limit=25)
                    except Exception as e:
                        logger.debug(f"Failed to emit internal inbound SSH edges: {e}")

                # Neighbor / routing edges (ARP + default gateway). These can have no port.
                if mode == "full" and local_asset:
                    try:
                        await self._emit_arp_and_route_edges(local_asset=local_asset, scanned_at=scanned_at, limit=25)
                    except Exception as e:
                        logger.debug(f"Failed to emit ARP/route edges: {e}")

                # Config-inferred dependencies (nginx/apache upstreams, db URLs) -> edges.
                if mode == "full" and local_asset:
                    try:
                        await self._emit_config_inferred_edges(local_asset=local_asset, scanned_at=scanned_at, limit=25)
                    except Exception as e:
                        logger.debug(f"Failed to emit config-inferred edges: {e}")

                # Fallback: create basic edges from local asset -> discovered hosts based on open ports.
                # In some containerized environments, deep connection discovery can return 0 results.
                # This ensures the graph shows at least "reachability" links for discovered hosts.
                try:
                    local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
                    local_id = local_asset.get("id")
                    if local_ip and local_id:
                        seen = set()
                        for asset in network_assets:
                            remote_ip = asset.get("ip_address") or asset.get("ipAddress")
                            remote_id = asset.get("id")
                            if not remote_ip or not remote_id or remote_ip == local_ip:
                                continue
                            open_ports = asset.get("open_ports") or asset.get("openPorts") or []
                            if not isinstance(open_ports, list):
                                open_ports = []
                            for p in open_ports:
                                try:
                                    port = int(p)
                                except Exception:
                                    continue
                                proto_hint = None
                                if port in (80, 8080, 8000, 3000, 5000):
                                    proto_hint = "http"
                                elif port in (8088,):
                                    proto_hint = "http"
                                elif port in (443, 8443):
                                    proto_hint = "https"
                                elif port:
                                    proto_hint = "tcp"
                                key = (remote_ip, port, proto_hint)
                                if key in seen:
                                    continue
                                seen.add(key)
                                self.discovered_connections.append({
                                    "from_asset_id": local_id,
                                    "to_asset_id": remote_id,
                                    "from_ip": local_ip,
                                    "to_ip": remote_ip,
                                    "connection_type": "network",
                                    "port": port,
                                    "protocol": proto_hint,
                                    "discovered_at": scanned_at,
                                    "last_seen": scanned_at,
                                    "status": "active",
                                })
                except Exception as e:
                    logger.debug(f"Failed to build fallback connections from open_ports: {e}")
            
            # Enhanced discovery (full mode only)
            if mode == "full":
                # Discover certificates
                certificates = await CertificateDiscovery.discover_certificates(root_dir="/")
                # Store certificates in asset metadata (can be extended later)
                
                # Discover Kubernetes resources
                k8s_resources = await DockerKubernetesDiscovery.discover_kubernetes_resources()
                # Store K8s resources for future use
                
                # Service enumeration for discovered IPs
                discovered_ips = set()
                for asset in self.discovered_assets.values():
                    discovered_ips.add(asset.get("ip_address"))
                for conn in self.discovered_connections:
                    discovered_ips.add(conn.get("source_ip"))
                    discovered_ips.add(conn.get("target_ip"))
                
                for ip in list(discovered_ips)[:10]:  # Limit to 10 IPs
                    # SNMP enumeration
                    from .modules.builders import add_service_from_enumeration
                    snmp_result = await ServiceEnumerator.enumerate_snmp(ip)
                    if snmp_result.get("accessible"):
                        add_service_from_enumeration(self.discovered_services, snmp_result, "SNMP")
                    
                    # SMB enumeration
                    smb_result = await ServiceEnumerator.enumerate_smb(ip)
                    if smb_result.get("accessible"):
                        add_service_from_enumeration(self.discovered_services, smb_result, "SMB")
                
                # Cloud enumeration
                if local_asset:
                    from .modules.builders import extract_domain_from_hostname, add_cloud_resource
                    domain = extract_domain_from_hostname(local_asset.get("hostname", ""))
                    if domain:
                        s3_buckets = await CloudServiceEnumerator.discover_s3_buckets(domain)
                        for bucket in s3_buckets:
                            add_cloud_resource(self.discovered_services, bucket, "S3 Bucket")
                    
                    cloud_metadata = await CloudServiceEnumerator.enumerate_cloud_metadata()
                    if cloud_metadata.get("aws", {}).get("accessible") or \
                       cloud_metadata.get("azure", {}).get("accessible") or \
                       cloud_metadata.get("gcp", {}).get("accessible"):
                        local_asset["cloud_metadata"] = cloud_metadata
                
                # DNS enumeration for local hostname
                if local_asset:
                    from .modules.builders import extract_domain_from_hostname
                    hostname = local_asset.get("hostname", "")
                    domain = extract_domain_from_hostname(hostname)
                    if domain:
                        dns_records = await DNSEnumerator.enumerate_dns_records(domain)
                        local_asset["dns_records"] = dns_records
                        
                        # Subdomain enumeration (limited)
                        subdomains = await DNSEnumerator.enumerate_subdomains(domain)
                        if subdomains.get("total_found", 0) > 0:
                            local_asset["subdomains"] = subdomains
                        
                        # Certificate Transparency lookup
                        ct_results = await OSINTDiscovery.query_certificate_transparency(domain)
                        if ct_results.get("total_subdomains", 0) > 0:
                            local_asset["ct_subdomains"] = ct_results
                
                # Service Mesh discovery
                from .modules.builders import add_service_mesh_services
                istio_services = await ServiceMeshDiscovery.discover_istio_services()
                if istio_services.get("accessible"):
                    add_service_mesh_services(self.discovered_services, istio_services, "Istio")
                
                consul_services = await ServiceMeshDiscovery.discover_consul_services()
                if consul_services.get("accessible"):
                    add_service_mesh_services(self.discovered_services, consul_services, "Consul")
                
                eureka_services = await ServiceMeshDiscovery.discover_eureka_services()
                if eureka_services.get("accessible"):
                    add_service_mesh_services(self.discovered_services, eureka_services, "Eureka")
                
                # IaC discovery
                if local_asset:
                    terraform_state = await IaCDiscovery.discover_terraform_state()
                    if terraform_state.get("resources"):
                        local_asset["terraform_resources"] = terraform_state
                    
                    cloudformation_template = await IaCDiscovery.discover_cloudformation_templates()
                    if cloudformation_template.get("resources"):
                        local_asset["cloudformation_resources"] = cloudformation_template
                
                # Side-channel detection
                if local_asset:
                    discovered_ips = [local_asset.get("ip_address")]
                    discovered_ips.extend([conn.get("target_ip") for conn in self.discovered_connections[:5]])
                    timing_anomalies = await SideChannelDetector.detect_timing_anomalies(discovered_ips)
                    if timing_anomalies.get("anomalies"):
                        local_asset["timing_anomalies"] = timing_anomalies
                    
                    metadata_leaks = await SideChannelDetector.detect_metadata_leakage()
                    if metadata_leaks:
                        local_asset["metadata_leaks"] = metadata_leaks
                
                # Protocol analysis for web services
                for service in list(self.discovered_services.values()):
                    if service.get("protocol") in ["http", "https"]:
                        url = f"{service['protocol']}://localhost:{service.get('port', 80)}"
                        protocol_analysis = await ProtocolAnalyzer.detect_protocol_downgrade(url)
                        if protocol_analysis.get("vulnerabilities"):
                            service["protocol_vulnerabilities"] = protocol_analysis
                
                # IoT device discovery
                mqtt_brokers = await IoTDeviceDiscovery.discover_mqtt_brokers()
                for broker in mqtt_brokers:
                    if broker.get("accessible"):
                        add_service_from_enumeration(self.discovered_services, broker, "MQTT")
                
                bluetooth_devices = await IoTDeviceDiscovery.discover_bluetooth_devices()
                if bluetooth_devices:
                    local_asset["bluetooth_devices"] = bluetooth_devices
                
                # Web fingerprinting for web services
                for service in list(self.discovered_services.values()):
                    if service.get("protocol") in ["http", "https"]:
                        url = f"{service['protocol']}://localhost:{service.get('port', 80)}"
                        fingerprint = await WebFingerprinter.fingerprint_application(url)
                        service["web_fingerprint"] = fingerprint
                
                # Database discovery for database services
                for service in list(self.discovered_services.values()):
                    if service.get("type") in ["PostgreSQL", "MySQL", "MongoDB"]:
                        db_type = service.get("type").lower()
                        if db_type == "postgresql":
                            db_info = await DatabaseDiscovery.enumerate_postgresql(
                                "localhost", service.get("port", 5432)
                            )
                        elif db_type == "mysql":
                            db_info = await DatabaseDiscovery.enumerate_mysql(
                                "localhost", service.get("port", 3306)
                            )
                        elif db_type == "mongodb":
                            db_info = await DatabaseDiscovery.enumerate_mongodb(
                                "localhost", service.get("port", 27017)
                            )
                        else:
                            db_info = None
                        
                        if db_info and db_info.get("accessible"):
                            service["database_info"] = db_info
                
                # Database Topology Discovery (replication, federation, connection pools)
                try:
                    from .modules.connections import DatabaseTopologyDiscovery
                    db_topology_discovery = DatabaseTopologyDiscovery(self)
                    
                    # Collect database hosts from discovered services
                    db_hosts = []
                    for service in self.discovered_services.values():
                        if service.get("type") in ["PostgreSQL", "MySQL", "MongoDB", "Redis", "MSSQL"]:
                            db_type_map = {
                                "PostgreSQL": "postgresql",
                                "MySQL": "mysql",
                                "MongoDB": "mongodb",
                                "Redis": "redis",
                                "MSSQL": "mssql",
                            }
                            db_hosts.append({
                                "host": "localhost",
                                "port": service.get("port", 5432),
                                "type": db_type_map.get(service.get("type"), "postgresql"),
                            })
                    
                    if db_hosts:
                        db_topology = await db_topology_discovery.discover_all(hosts=db_hosts)
                        if db_topology:
                            local_asset["database_topology"] = db_topology
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Database topology discovery error: {e}")
                
                # API & Microservices Discovery (gateways, message queues, CDC)
                try:
                    from .modules.connections import APIMicroservicesDiscovery
                    api_discovery = APIMicroservicesDiscovery(self)
                    
                    api_topology = await api_discovery.discover_all(
                        include_k8s=True,
                        include_gateways=True,
                        include_messaging=True,
                        include_cdc=True,
                    )
                    if api_topology:
                        local_asset["api_microservices_topology"] = api_topology
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"API/Microservices discovery error: {e}")
                
                # Network Topology Discovery (VLANs, subnets, routing)
                try:
                    from .modules.connections import NetworkTopologyDiscovery
                    network_discovery = NetworkTopologyDiscovery(self)
                    network_topology = await network_discovery.discover_network_topology()
                    if network_topology:
                        local_asset["network_topology"] = network_topology
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Network topology discovery error: {e}")
                
                # Cloud Relationships Discovery (AWS, Azure, GCP relationships)
                try:
                    from .modules.connections import CloudRelationshipsDiscovery
                    cloud_discovery = CloudRelationshipsDiscovery(self)
                    cloud_relationships = await cloud_discovery.discover_cloud_relationships()
                    if cloud_relationships:
                        local_asset["cloud_relationships"] = cloud_relationships
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Cloud relationships discovery error: {e}")
                
                # Container Networking Discovery (Docker, K8s networking)
                try:
                    from .modules.connections import ContainerNetworkingDiscovery
                    container_discovery = ContainerNetworkingDiscovery(self)
                    container_networking = await container_discovery.discover_container_networking()
                    if container_networking:
                        local_asset["container_networking"] = container_networking
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Container networking discovery error: {e}")
            
            # Convert to proto format using builders
            from .modules.builders import dict_to_asset, dict_to_service, dict_to_connection
            assets = [dict_to_asset(asset) for asset in self.discovered_assets.values()]
            def _is_noisy_service_entry(svc: Dict[str, Any]) -> bool:
                """
                Avoid emitting high-volume 'service' records that are actually just process/config noise.
                Keep entries that have clear network semantics (port+protocol or remote_address).
                """
                try:
                    dm = str(svc.get("discovery_method") or svc.get("discoveryMethod") or "").strip().lower()
                    if dm not in {"process-scan", "config-analysis"}:
                        return False

                    port = svc.get("port")
                    proto = str(svc.get("protocol") or "").strip().lower()
                    direction = str(svc.get("port_direction") or svc.get("portDirection") or "").strip().lower()
                    ra = str(svc.get("remote_address") or svc.get("remoteAddress") or "").strip()

                    has_network = (port is not None and proto in {"tcp", "udp"}) or bool(ra)
                    has_direction = direction in {"inbound", "outbound"}

                    # If it lacks clear network semantics, it's noise.
                    return not (has_network and (has_direction or bool(ra)))
                except Exception:
                    return False

            # Log before filtering
            filtered_service_dicts = [
                svc for svc in self.discovered_services.values()
                if isinstance(svc, dict) and not _is_noisy_service_entry(svc)
            ]
            services = [dict_to_service(service) for service in filtered_service_dicts]
            connections = [dict_to_connection(conn) for conn in self.discovered_connections]
            
            result = AssetDiscoveryResult(
                assets=assets,
                services=services,
                connections=connections,
                scanned_at=scanned_at,
                scan_mode=mode
            )
            
            from .modules.builders import asset_to_dict, service_to_dict, connection_to_dict
            return {
                "status": "success",
                "result": "Asset discovery completed",
                "data": {
                    "assets": [asset_to_dict(asset) for asset in assets],
                    "services": [service_to_dict(service) for service in services],
                    "connections": [connection_to_dict(conn) for conn in connections],
                    "scanned_at": scanned_at,
                    "scan_mode": mode,
                    "total_assets": len(assets),
                    "total_services": len(services),
                    "total_connections": len(connections)
                }
            }
        except Exception as e:
            logger.exception(f"Error during asset discovery: {e}")
            return {
                "status": "error",
                "result": f"Asset discovery failed: {str(e)}",
                "data": {}
            }
    
    async def _discover_local_asset(self) -> Optional[Dict[str, Any]]:
        """Discover local system asset - delegates to modular AssetDiscoverer"""
        return await self.asset_discoverer.discover_local_asset()
    
    async def _detect_provider(self) -> str:
        """Detect cloud provider or on-premise - delegates to ProviderDetector"""
        return await ProviderDetector.detect_provider()
    
    def _detect_agent_type(self) -> str:
        """Detect agent type - delegates to ProviderDetector"""
        return ProviderDetector.detect_agent_type()
    
    def _detect_environment(self) -> str:
        """Detect environment - delegates to ProviderDetector"""
        return ProviderDetector.detect_environment(self.local_hostname)
    
    def _detect_system_role(self) -> Optional[str]:
        """Detect system role - delegates to ProviderDetector"""
        return ProviderDetector.detect_system_role(self.local_hostname)
    
    def _get_system_tags(self, provider: str, role: Optional[str], environment: str) -> List[str]:
        """Get system tags - delegates to ProviderDetector"""
        return ProviderDetector.get_system_tags(provider, role, environment)

    async def _infer_provider_for_discovered_host(self, *, host_ip: str, local_ip: Optional[str] = None, local_provider: Optional[str] = None) -> str:
        """
        Best-effort provider inference for discovered hosts without an installed agent.

        Variant B (default): reverse DNS / PTR + hostname pattern matching.
        Variant C (optional): ASN lookup (disabled by default; requires outbound whois and caching).

        IMPORTANT:
        - No universal truth exists for remote hosts without an agent.
        - We therefore only label cloud providers when we have a strong signal.
        - Otherwise return "Unknown" (not "On-premise") to avoid misleading UI.
        """
        cache_key = str(host_ip).strip()
        try:
            if not hasattr(self, "_provider_infer_cache"):
                self._provider_infer_cache = {}
            if cache_key in self._provider_infer_cache:
                return self._provider_infer_cache[cache_key]
        except Exception:
            pass

        try:
            ip_obj = ipaddress.ip_address(cache_key)
            if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_multicast:
                prov0 = "On-premise"
                try:
                    self._provider_infer_cache[cache_key] = prov0
                except Exception:
                    pass
                return prov0
        except Exception:
            return "Unknown"

        # Variant A (cheap heuristic):
        # Some providers (notably DigitalOcean) often don't have PTR set on droplets.
        # If the scanning host is confidently labeled as a cloud provider and the discovered host
        # is on the same /24 public subnet, inherit the provider label.
        try:
            lp = (local_provider or "").strip()
            lip = (local_ip or "").strip()
            if lp and lp != "Unknown" and lip:
                ip_local = ipaddress.ip_address(lip)
                ip_remote = ipaddress.ip_address(cache_key)
                if (not ip_local.is_private) and (not ip_remote.is_private):
                    inherit = lp == "DigitalOcean"
                    try:
                        inherit = inherit or (
                            str(os.getenv("ASSET_DISCOVERY_INFER_PROVIDER_FROM_LOCAL_SUBNET", "0")).strip().lower()
                            in ("1", "true", "yes")
                        )
                    except Exception:
                        pass
                    if inherit:
                        net = ipaddress.ip_network(f"{lip}/24", strict=False)
                        if ip_remote in net:
                            try:
                                self._provider_infer_cache[cache_key] = lp
                            except Exception:
                                pass
                            return lp
        except Exception:
            pass

        def _provider_from_ptr(ptr: str) -> Optional[str]:
            p = (ptr or "").strip().lower()
            if not p:
                return None
            # AWS: many PTRs end with amazonaws.com (incl compute.amazonaws.com)
            if "amazonaws.com" in p or p.endswith(".compute-1.amazonaws.com") or p.endswith(".compute.amazonaws.com"):
                return "AWS"
            # Azure: cloudapp.azure.com / cloudapp.net patterns
            if "cloudapp.azure.com" in p or "cloudapp.net" in p:
                return "Azure"
            # GCP: googleusercontent reverse or internal naming
            if "googleusercontent.com" in p or p.endswith(".c.internal") or "bc.googleusercontent.com" in p:
                return "GCP"
            # DigitalOcean: not always present, but some PTRs contain "digitalocean"
            if "digitalocean" in p:
                return "DigitalOcean"
            return None

        # Reuse the bounded PTR helper (cache + routability guard).
        ptr = await self._reverse_dns_ptr(str(host_ip))
        prov = _provider_from_ptr(ptr or "")
        if prov:
            try:
                self._provider_infer_cache[cache_key] = prov
            except Exception:
                pass
            return prov

        # Variant C (optional): ASN lookup for stronger inference across clouds.
        # Disabled by default; requires outbound whois and should be cached.
        try:
            enable_asn = str(os.getenv("ASSET_DISCOVERY_PROVIDER_ASN_LOOKUP", "0")).strip().lower() in ("1", "true", "yes")
        except Exception:
            enable_asn = False
        if enable_asn:
            try:
                prov = await asyncio.wait_for(self._infer_provider_via_asn(host_ip=str(host_ip)), timeout=1.0)
                if prov:
                    try:
                        self._provider_infer_cache[cache_key] = prov
                    except Exception:
                        pass
                    return prov
            except Exception:
                pass

        try:
            self._provider_infer_cache[cache_key] = "Unknown"
        except Exception:
            pass
        return "Unknown"

    async def _run_shell_stdout(self, cmd: str, *, timeout: float = 3.0) -> str:
        """Trusted static shell pipelines only (pipes/redirections). Prefer run_exec for argv."""
        try:
            from utils.async_subprocess import run_shell_stdout

            out = await run_shell_stdout(cmd, timeout=timeout, allow_unsafe_shell=True)
            return (out or "").strip()
        except Exception:
            return ""

    async def _run_ping_once(self, ip: str) -> None:
        """Single ICMP probe; ``ip`` must be a valid IP address (no shell)."""
        try:
            addr = ipaddress.ip_address(str(ip).strip())
        except Exception:
            return
        try:
            from utils.async_subprocess import run_exec

            ping_bin = shutil.which("ping") or "ping"
            await run_exec([ping_bin, "-c", "1", "-W", "1", addr.compressed], timeout=2.0)
        except Exception:
            return

    async def _ip_neigh_first_line(self, ip: str) -> str:
        """First line of ``ip neigh show <addr>`` without shell interpolation."""
        try:
            addr = ipaddress.ip_address(str(ip).strip())
        except Exception:
            return ""
        try:
            from utils.async_subprocess import run_exec

            ip_bin = shutil.which("ip") or "/sbin/ip"
            rc, out, _ = await run_exec([ip_bin, "neigh", "show", addr.compressed], timeout=2.0)
            if not out:
                return ""
            return (out.strip().splitlines() or [""])[0]
        except Exception:
            return ""

    async def _infer_provider_via_asn(self, *, host_ip: str) -> Optional[str]:
        """
        Optional Variant C: infer provider via ASN org name.
        Best-effort using Team Cymru whois (port 43). Keep timeouts tiny.
        """
        import socket as _socket
        try:
            q = f" -v {host_ip}\n"
            def _do_query() -> Optional[str]:
                try:
                    s = _socket.create_connection(("whois.cymru.com", 43), timeout=0.6)
                    with s:
                        s.sendall(q.encode("utf-8", errors="ignore"))
                        s.shutdown(_socket.SHUT_WR)
                        data = b""
                        while True:
                            chunk = s.recv(4096)
                            if not chunk:
                                break
                            data += chunk
                    return data.decode("utf-8", errors="ignore")
                except Exception:
                    return None

            out = await asyncio.to_thread(_do_query)
            if not out:
                return None
            # Parse lines, skip header, look for org name.
            lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
            if len(lines) < 2:
                return None
            # Example columns: ASN | IP | BGP Prefix | CC | Registry | Allocated | AS Name
            parts = [p.strip() for p in lines[-1].split("|")]
            if len(parts) < 7:
                return None
            as_name = parts[6].lower()
            if "amazon" in as_name or "aws" in as_name:
                return "AWS"
            if "google" in as_name:
                return "GCP"
            if "microsoft" in as_name or "azure" in as_name:
                return "Azure"
            if "digitalocean" in as_name:
                return "DigitalOcean"
            return None
        except Exception:
            return None
    
    async def _discover_network_interfaces(self) -> List[Dict[str, Any]]:
        """Discover network interfaces - delegates to NetworkInterfaceDiscoverer"""
        from .modules.discovery import NetworkInterfaceDiscoverer
        discoverer = NetworkInterfaceDiscoverer(self.local_ip)
        return await discoverer.discover_network_interfaces()
    
    async def _get_hardware_specs(self) -> Optional[Dict[str, Any]]:
        """Get hardware specifications - delegates to HardwareDiscoverer"""
        from .modules.discovery import HardwareDiscoverer
        discoverer = HardwareDiscoverer()
        return await discoverer.get_hardware_specs()
    
    async def _discover_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services - delegates to ServiceDiscoverer"""
        from .modules.services import ServiceDiscoverer
        discoverer = ServiceDiscoverer(self.local_hostname, self.local_ip)
        services = await discoverer.discover_services(asset_id)
        # Store in cache for potential fallback
        for svc in services:
            try:
                self.discovered_services[svc["id"]] = svc
            except Exception:
                pass
        return services

    async def _discover_services_light(self, asset_id: str) -> List[Dict[str, Any]]:
        """
        Fast local-only service discovery.
        Goal: provide *some* services quickly (for UI) without heavy enumeration.
        """
        services: List[Dict[str, Any]] = []
        if not asset_id or psutil is None:
            return services
        try:
            try:
                conns = psutil.net_connections(kind="inet")
            except Exception:
                conns = []
            seen = set()
            now_iso = datetime.utcnow().isoformat()
            for c in (conns or [])[:5000]:
                try:
                    laddr = getattr(c, "laddr", None)
                    if not laddr:
                        continue
                    port = getattr(laddr, "port", None) if hasattr(laddr, "port") else None
                    if port is None:
                        continue
                    proto = "tcp"
                    try:
                        # psutil uses socket.SOCK_STREAM/SOCK_DGRAM for type
                        if getattr(c, "type", None) == socket.SOCK_DGRAM:
                            proto = "udp"
                    except Exception:
                        proto = "tcp"
                    key = (int(port), proto)
                    if key in seen:
                        continue
                    seen.add(key)
                    sid = f"svc-{asset_id}-{proto}-{int(port)}"
                    services.append(
                        {
                            "id": sid,
                            "asset_id": asset_id,
                            "name": f"{proto.upper()}:{int(port)}",
                            "type": "local",
                            "status": "running",
                            "port": int(port),
                            "protocol": proto,
                            "direction": "inbound",
                            "discovery_method": "psutil",
                            "description": "Discovered from local socket listeners",
                            "last_seen": now_iso,
                        }
                    )
                except Exception:
                    continue
        except Exception:
            return services
        return services
    
    async def _discover_network_assets(self, local_asset: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Passively discover other hosts in the network through:
        - Established connections (netstat/psutil)
        - ARP cache
        - /proc/net/* files
        
        Creates 'without-agent' assets for discovered hosts.
        """
        network_assets = []
        
        try:
            from .modules.connections.connection_discovery import PassiveNetworkDiscovery
            from .modules.utils.id_generator import generate_asset_id
            
            local_ip = local_asset.get("ip_address", self.local_ip)
            local_provider = local_asset.get("provider") or "Unknown"
            enhanced_provider_service = self._feature_enabled("ASSET_DISCOVERY_PROVIDER_SERVICE_ENHANCED", "0")
            dns_servers: List[str] = []
            if enhanced_provider_service:
                try:
                    dns_servers = await self._read_resolv_conf_nameservers()
                except Exception:
                    dns_servers = []
            gw_ip = None
            try:
                line = await self._run_shell_stdout("ip route show default 2>/dev/null | head -n 1", timeout=2)
                m = re.search(r"\bvia\s+([0-9\.]+)\b", line)
                if m:
                    gw_ip = m.group(1)
            except Exception:
                gw_ip = None
            
            
            # Passively discover hosts
            discovered_hosts = await PassiveNetworkDiscovery.discover_hosts(local_ip)
            # Hard bound to prevent memory blow-ups on hosts with very large ARP/proc tables.
            try:
                max_hosts = int(os.getenv("ASSET_DISCOVERY_MAX_PASSIVE_HOSTS", "500"))
            except Exception:
                max_hosts = 500
            if max_hosts > 0 and len(discovered_hosts) > max_hosts:
                discovered_hosts = discovered_hosts[:max_hosts]
            
            now = datetime.utcnow()
            # Default ON: reverse DNS enrichment is best-effort, bounded, and improves UX significantly.
            rdns_enabled = self._feature_enabled("ASSET_DISCOVERY_REVERSE_DNS_HOSTNAMES", "1")
            rdns_candidates: List[tuple[Dict[str, Any], str]] = []
            try:
                max_rdns = int(os.getenv("ASSET_DISCOVERY_REVERSE_DNS_MAX", "200"))
            except Exception:
                max_rdns = 200
            
            for host in discovered_hosts:
                host_ip = host.get("ip")
                if not host_ip or host_ip == local_ip:
                    continue
                
                hostname = host.get("hostname") or host_ip

                # Filter noisy passive discoveries on public networks:
                # do not include Passive/ARP assets for non-RFC1918 IPv4 addresses.
                # Exception: keep the default gateway (it is useful context and often provider-managed).
                try:
                    ip_norm = str(host_ip).strip()
                    hn = str(hostname or "").strip().lower()
                    is_gw = (hn in ("_gateway", "gateway")) or (gw_ip and ip_norm == str(gw_ip).strip())
                    addr = ipaddress.ip_address(ip_norm)
                    if addr.version == 4 and not is_gw:
                        is_rfc1918 = (
                            addr in ipaddress.ip_network("10.0.0.0/8")
                            or addr in ipaddress.ip_network("172.16.0.0/12")
                            or addr in ipaddress.ip_network("192.168.0.0/16")
                        )
                        if not is_rfc1918:
                            continue
                    # Also filter known CDN IPs that might appear in passive discovery
                    if self._is_known_cdn(ip_norm):
                        continue
                except Exception:
                    # Never let filtering break discovery; worst case we keep the record.
                    pass
                asset_id = generate_asset_id(hostname, host_ip)
                
                # Determine service hints based on detected ports
                open_ports = host.get("open_ports", [])
                services_hint = []
                port_service_map = {
                    5432: "PostgreSQL",
                    6379: "Redis", 
                    3306: "MySQL",
                    27017: "MongoDB",
                    80: "HTTP",
                    8080: "HTTP",
                    8088: "HTTP API",
                    443: "HTTPS",
                    22: "SSH",
                    3000: "Web App",
                    5000: "Web App",
                    9090: "Prometheus",
                    9100: "Node Exporter"
                }
                
                for port in open_ports:
                    if port in port_service_map:
                        services_hint.append(port_service_map[port])
                
                # Remove duplicates while preserving order
                services_hint = list(dict.fromkeys(services_hint))
                
                asset = {
                    "id": asset_id,
                    "ip_address": host_ip,
                    "hostname": hostname,
                    "status": "without-agent",
                    "provider": await self._infer_provider_for_discovered_host(
                        host_ip=host_ip,
                        local_ip=str(local_ip),
                        local_provider=str(local_provider),
                    ),
                    "os": "Unknown",
                    "agent_type": None,
                    "environment": local_asset.get("environment", "Development"),
                    "services": services_hint,
                    "last_seen": now.strftime("%I:%M:%S %p"),
                    "discovered_at": now.date().isoformat(),
                    "tags": ["network-discovered"],
                    "detection_method": "Passive Discovery",
                    "detection_location": f"Network connections from {local_ip}",
                    "detection_reason": f"Host discovered passively through network connections/ARP. "
                                       f"Ports: {', '.join(map(str, open_ports)) if open_ports else 'unknown'}.",
                    "open_ports": open_ports,
                    "mac_address": host.get("mac")
                }

                # Best-effort: tag provider-managed service nodes (gateway) so they can be filtered later.
                # Persist in both tags and role (role is a DB column; tags persistence is backend-dependent).
                try:
                    hn = (hostname or "").strip().lower()
                    is_gw = (hn in ("_gateway", "gateway")) or (gw_ip and str(host_ip) == str(gw_ip))
                    if is_gw:
                        self._mark_asset_as_provider_service(asset, "Default gateway")
                except Exception:
                    pass

                # Enhanced provider-service tagging (conservative, behind flag):
                # - Special provider-managed IPs (IMDS, time sync, Azure magic IP, AWS resolver)
                # - AWS VPC resolver at VPC CIDR+2, if observed as a nameserver and local provider is AWS
                if enhanced_provider_service:
                    try:
                        tags_now = asset.get("tags") if isinstance(asset.get("tags"), list) else []
                        already_marked = "provider-service" in tags_now or "not-ours" in tags_now or str(asset.get("role") or "").strip().lower() == "provider-service"
                        if not already_marked:
                            reason = self._provider_service_reason_for_ip(
                                ip_str=str(host_ip),
                                local_provider=str(local_provider),
                                local_ip=str(local_ip) if local_ip else None,
                                dns_servers=dns_servers,
                            )
                            if reason:
                                self._mark_asset_as_provider_service(asset, reason)
                    except Exception:
                        pass

                # Best-effort: reverse DNS (PTR) -> hostname mapping, bounded & non-blocking.
                # Only overwrite hostname if it's missing or equals the IP (avoid clobbering meaningful labels).
                try:
                    if rdns_enabled:
                        hn_now = str(asset.get("hostname") or "").strip()
                        if (not hn_now) or hn_now == str(host_ip).strip():
                            # Cap during collection to avoid transient memory spikes on large host lists.
                            if max_rdns <= 0 or len(rdns_candidates) < max_rdns:
                                rdns_candidates.append((asset, str(host_ip).strip()))
                except Exception:
                    pass
                
                network_assets.append(asset)

            # Resolve PTR hostnames concurrently with conservative bounds to avoid slowing discovery.
            if rdns_candidates:
                try:
                    sem = asyncio.Semaphore(10)
                    # Hard cap to keep runtime bounded even on large networks.
                    if max_rdns > 0:
                        rdns_candidates = rdns_candidates[:max_rdns]

                    async def _resolve_one(asset: Dict[str, Any], ip_str: str) -> None:
                        async with sem:
                            ptr = await self._reverse_dns_ptr(ip_str)
                            if not ptr:
                                return
                            # Never overwrite special gateway labels.
                            cur = str(asset.get("hostname") or "").strip().lower()
                            if cur in ("_gateway", "gateway"):
                                return
                            asset["hostname"] = ptr
                            # Keep original IP visible for debugging
                            asset["dns_ptr"] = ptr
                            try:
                                existing = asset.get("detection_reason") or ""
                                suffix = f" PTR: {ptr}."
                                if suffix not in str(existing):
                                    asset["detection_reason"] = (str(existing).rstrip() + suffix).strip()
                            except Exception:
                                pass

                    await asyncio.gather(*[_resolve_one(a, ip) for a, ip in rdns_candidates], return_exceptions=True)
                except Exception:
                    pass
            
            
        except Exception as e:
            logger.error(f"Error discovering network assets: {e}")
        
        return network_assets
    
    # All service discovery methods moved to modules.services.ServiceDiscoverer
    
    async def _discover_connections(self, assets: List[Asset]) -> List[AssetConnection]:
        """Discover network connections between assets"""
        assets_dict = {asset.id: self.proto_builders._asset_to_dict(asset) for asset in assets}
        connections_list = await self.connection_discoverer.discover_connections(assets_dict)
        return [self.proto_builders._dict_to_connection(conn) for conn in connections_list]

    async def _active_port_scan_network_assets(self, network_assets: List[Dict[str, Any]], scanned_at: Optional[str] = None) -> None:
        """
        Lightweight active TCP port scan for discovered hosts.
        Updates each asset dict with a richer open_ports list and creates service records for Services Table.
        """
        ports = [
            22, 53, 80, 443,
            3000, 3002, 5000, 8000, 8080, 8088, 8443,
            5432, 3306, 6379, 27017,
            15672, 5672,
            9200, 5601,
        ]
        timeout_s = 0.35
        concurrency = 200
        sem = asyncio.Semaphore(concurrency)

        def _is_ip(s: str) -> bool:
            try:
                ipaddress.ip_address(s)
                return True
            except Exception:
                return False

        async def probe(ip: str, port: int) -> bool:
            async with sem:
                try:
                    reader, writer = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout=timeout_s)
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                    return True
                except Exception:
                    return False

        tasks = []
        idx_map = []
        for i, asset in enumerate(network_assets):
            ip = asset.get("ip_address") or asset.get("ipAddress")
            if not isinstance(ip, str) or not ip or not _is_ip(ip):
                continue
            for p in ports:
                tasks.append(probe(ip, p))
                idx_map.append((i, p))

        if not tasks:
            return

        results = await asyncio.gather(*tasks, return_exceptions=False)

        found = {}
        for (i, p), ok in zip(idx_map, results):
            if ok:
                found.setdefault(i, []).append(p)

        def _proto_for_port(port: int) -> str:
            if port in (80, 8080, 8088, 8000, 3000, 3002, 5000):
                return "http"
            if port in (443, 8443):
                return "https"
            return "tcp"

        def _service_type_for_port(port: int) -> str:
            if port in (80, 443, 8080, 8088, 8000, 3000, 3002, 5000, 8443, 5601, 15672):
                return "web"
            if port in (5432, 3306, 27017, 9200):
                return "database"
            if port in (6379,):
                return "cache"
            return "network"

        when = scanned_at or datetime.utcnow().isoformat()

        for i, ports_found in found.items():
            try:
                existing = network_assets[i].get("open_ports") or network_assets[i].get("openPorts") or []
                if not isinstance(existing, list):
                    existing = []
                merged = sorted(set([int(x) for x in existing if str(x).isdigit()] + [int(x) for x in ports_found]))
                network_assets[i]["open_ports"] = merged

                # Also emit "port-scan" services for these open ports so Services Table shows this data.
                asset = network_assets[i]
                asset_id = asset.get("id")
                asset_ip = asset.get("ip_address") or asset.get("ipAddress")
                asset_hostname = asset.get("hostname")
                if asset_id and asset_ip:
                    for port in ports_found:
                        try:
                            p = int(port)
                        except Exception:
                            continue
                        proto = _proto_for_port(p)
                        service_type = _service_type_for_port(p)
                        svc_id = f"portscan:{asset_id}:{p}:{proto}"
                        if svc_id in self.discovered_services:
                            continue
                        name = f"{proto.upper()}:{p}" if proto in ("http", "https") else f"TCP:{p}"
                        svc = {
                            "id": svc_id,
                            "name": name,
                            "asset_id": asset_id,
                            "asset_hostname": asset_hostname,
                            "asset_ip_address": asset_ip,
                            "status": "running",
                            "port": p,
                            "protocol": proto,
                            "service_type": service_type,
                            "port_direction": "inbound",
                            "discovery_method": "port-scan",
                            "detection_location": "active-port-scan (tcp connect)",
                            "detection_reason": "Open port discovered via lightweight active scan during asset_discovery(full).",
                            "description": f"Open port {p}/{proto} discovered on {asset_hostname or asset_ip} via active scan.",
                            "discovered_at": when,
                            "last_seen": when,
                        }

                        # For web ports, enrich with a lightweight HTTP probe (status/title/headers) so UI can show it.
                        try:
                            if proto in ("http", "https"):
                                http_info = await self._probe_http_remote(asset_ip, p, preferred_scheme=proto)
                                if http_info:
                                    svc["process_info"] = {"http": http_info}
                        except Exception:
                            pass

                        self.discovered_services[svc_id] = svc
            except Exception:
                pass

    async def _probe_http_remote(self, host: str, port: int, preferred_scheme: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Probe a remote HTTP/HTTPS endpoint without following redirects.
        Returns the same shape as ServiceDiscoverer._probe_http_endpoint, plus headers.
        """
        from .modules.utils.async_http import fetch
        import html as _html
        import re as _re

        def _extract_title(body_text: str) -> Optional[str]:
            try:
                m = _re.search(r"<title[^>]*>(.*?)</title>", body_text, _re.IGNORECASE | _re.DOTALL)
                if not m:
                    return None
                t = m.group(1)
                t = _re.sub(r"\s+", " ", t).strip()
                t = _html.unescape(t)
                return t[:200] if t else None
            except Exception:
                return None

        schemes: List[str] = []
        if preferred_scheme and str(preferred_scheme).lower() in ("http", "https"):
            schemes.append(str(preferred_scheme).lower())
        for s in ("http", "https"):
            if s not in schemes:
                schemes.append(s)

        for scheme in schemes:
            url = f"{scheme}://{host}:{port}"
            try:
                status_code, headers_lc, body_b = await fetch(
                    url,
                    headers={
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    },
                    timeout=2,
                    max_bytes=65536,
                )
                if not isinstance(status_code, int):
                    continue

                title = None
                try:
                    content_type = ((headers_lc or {}).get("content-type") or "").lower()
                    if status_code == 200 and ("text/html" in content_type or "application/xhtml" in content_type or not content_type):
                        body_txt = (body_b or b"").decode("utf-8", errors="ignore")
                        title = _extract_title(body_txt)
                except Exception:
                    pass

                redirect_to = (headers_lc or {}).get("location")

                safe_headers: Dict[str, str] = {}
                try:
                    for k, v in list((headers_lc or {}).items())[:40]:
                        key = str(k)
                        val = str(v)
                        lk = key.lower()
                        if lk in ("set-cookie", "cookie", "authorization", "proxy-authorization", "x-api-key"):
                            val = "***"
                        if len(val) > 240:
                            val = val[:240] + "…"
                        safe_headers[key] = val
                except Exception:
                    safe_headers = {}

                return {
                    "url": url,
                    "scheme": scheme,
                    "status_code": status_code,
                    "redirect_to": redirect_to,
                    "title": title,
                    "headers": safe_headers,
                }
            except Exception:
                continue

        return None

    def _is_known_cdn(self, ip_str: str) -> bool:
        """
        Check if an IP address is a known CDN that should not be created as an asset.
        Only filters known CDN IP ranges, not DNS servers or other infrastructure.
        
        Args:
            ip_str: IP address to check
        
        Returns:
            True if IP is a known CDN and should be excluded from asset creation
        """
        if not ip_str:
            return False
        
        # Check if it's in known CDN IP ranges
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            for cidr, description in self.KNOWN_CDN_IP_RANGES:
                try:
                    network = ipaddress.ip_network(cidr, strict=False)
                    if ip_obj in network:
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        
        return False

    def _ensure_asset_for_ip(
        self,
        ip_str: str,
        scanned_at: str,
        hostname: Optional[str] = None,
        tags: Optional[List[str]] = None,
        detection_method: Optional[str] = None,
        detection_location: Optional[str] = None,
        detection_reason: Optional[str] = None,
    ) -> Optional[str]:
        """Ensure self.discovered_assets contains an asset for ip_str. Returns asset_id."""
        try:
            from .modules.utils.id_generator import generate_asset_id
        except Exception:
            generate_asset_id = None

        if not ip_str:
            return None

        # Reuse existing
        for a in self.discovered_assets.values():
            if isinstance(a, dict) and (a.get("ip_address") or a.get("ipAddress")) == ip_str:
                return a.get("id")

        hn = hostname or ip_str
        asset_id = generate_asset_id(hn, ip_str) if generate_asset_id else f"asset_{ip_str.replace('.', '_')}"
        try:
            # Always tag known provider-managed infra endpoints, even for inferred edge-only assets.
            # (Safe, strong signal; avoids relying on passive host discovery to classify them.)
            special_reason = self.PROVIDER_SERVICE_SPECIAL_IPS.get(str(ip_str).strip())
            if special_reason:
                base_tags = tags or ["inferred"]
                tags = list(dict.fromkeys(list(base_tags) + ["provider-service", "not-ours"]))
                detection_reason = (str(detection_reason or "").rstrip() + f" Provider-managed node: {special_reason}.").strip()
        except Exception:
            pass

        self.discovered_assets[asset_id] = {
            "id": asset_id,
            "ip_address": ip_str,
            "hostname": hn,
            "status": "without-agent",
            # Keep inferred assets conservative; they are used primarily for graph edges.
            "provider": "Unknown",
            "os": "Unknown",
            "agent_type": None,
            "environment": "Development",
            "services": [],
            "last_seen": scanned_at,
            "discovered_at": scanned_at,
            "tags": tags or ["inferred"],
            "detection_method": detection_method or "Inferred",
            "detection_location": detection_location,
            "detection_reason": detection_reason,
            "role": "provider-service" if (isinstance(tags, list) and ("provider-service" in tags or "not-ours" in tags)) else None,
        }
        return asset_id

    def _build_remoteaddress_reason(self, *, local_asset: Dict[str, Any], svc: Dict[str, Any], remote: str) -> str:
        """
        Build a human-meaningful reason for Service remoteAddress assets.
        Prefer concrete evidence: process commandline, config path, container image, and the service name.
        SECURITY: Never include access keys or tokens in the reason string.
        """
        def _norm(v: Any) -> str:
            s = str(v or "").strip()
            return s

        def _short(v: Any, n: int = 220) -> str:
            s = _norm(v)
            if len(s) <= n:
                return s
            return s[:n] + "…"

        def _mask_access_key(cmd_str: str) -> str:
            """Mask access keys in command strings to prevent token exposure."""
            if not cmd_str:
                return cmd_str
            import re
            # Match --access-key agt-... patterns
            cmd_str = re.sub(r'--access-key\s+agt-[A-Za-z0-9]+', '--access-key ***MASKED***', cmd_str)
            # Match ACCESS_KEY=agt-... patterns
            cmd_str = re.sub(r'ACCESS_KEY\s*=\s*agt-[A-Za-z0-9]+', 'ACCESS_KEY=***MASKED***', cmd_str, flags=re.IGNORECASE)
            # Match access_key: agt-... patterns
            cmd_str = re.sub(r'access_key\s*[:=]\s*agt-[A-Za-z0-9]+', 'access_key=***MASKED***', cmd_str, flags=re.IGNORECASE)
            return cmd_str

        parts: List[str] = []

        # Service/process identity
        name = _norm(svc.get("name"))
        if name:
            parts.append(f"service={name}")

        # Network hint (local port/proto for outbound connections)
        proto = _norm(svc.get("protocol"))
        port = svc.get("port")
        if proto and port is not None:
            parts.append(f"local={proto}:{port}")

        # Discovery method
        dm = _norm(svc.get("discovery_method") or svc.get("discoveryMethod"))
        if dm:
            parts.append(f"via={dm}")

        # Process evidence
        pi = svc.get("process_info") or svc.get("processInfo")
        if isinstance(pi, dict):
            cmd = pi.get("command") or pi.get("cmd") or pi.get("cmdline") or pi.get("args")
            pid = pi.get("pid")
            user = pi.get("user")
            if pid:
                parts.append(f"pid={pid}")
            if user:
                parts.append(f"user={user}")
            if cmd:
                # SECURITY: Mask access keys before including in reason
                safe_cmd = _mask_access_key(_norm(cmd))
                parts.append(f"cmd={_short(safe_cmd)}")

        # Config evidence
        cfg = _norm(svc.get("config_path") or svc.get("configPath"))
        if cfg:
            parts.append(f"config={cfg}")

        # Container evidence
        ci = svc.get("container_info") or svc.get("containerInfo")
        if isinstance(ci, dict):
            image = ci.get("image")
            cid = ci.get("container_id") or ci.get("containerId")
            if image:
                parts.append(f"image={_short(image, 160)}")
            elif cid:
                parts.append(f"container={_short(cid, 80)}")

        local_hn = _norm(local_asset.get("hostname") or local_asset.get("ip_address") or local_asset.get("ipAddress"))
        left = f"Outbound connection observed from {local_hn}" if local_hn else "Outbound connection observed"
        evidence = "; ".join(parts) if parts else "source=unknown"
        return f"{left}: {evidence} -> remote={_short(remote, 240)}"

    async def _emit_edges_from_outbound_services(self, local_asset: Dict[str, Any], services: List[Dict[str, Any]], scanned_at: str) -> None:
        """
        If a service was discovered with port_direction=outbound and remote_address=host:port,
        create a dependency edge from local asset -> remote host.
        """
        local_id = local_asset.get("id")
        local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
        if not local_id or not local_ip:
            return

        seen = set()

        def _parse_remote(remote: str) -> Optional[tuple[str, Optional[int]]]:
            if not isinstance(remote, str) or not remote.strip():
                return None
            r = remote.strip()
            # Handle IPv6 in brackets: [::1]:443
            if r.startswith("[") and "]" in r:
                host = r[1:r.index("]")]
                rest = r[r.index("]") + 1 :]
                port = None
                if rest.startswith(":"):
                    try:
                        port = int(rest[1:])
                    except Exception:
                        port = None
                return host, port
            # Normal host:port
            if ":" in r:
                host, port_s = r.rsplit(":", 1)
                try:
                    return host, int(port_s)
                except Exception:
                    return host, None
            return r, None

        def _is_ip(s: str) -> bool:
            try:
                ipaddress.ip_address(s)
                return True
            except Exception:
                return False

        for svc in services:
            try:
                if svc.get("port_direction") != "outbound":
                    continue
                remote = svc.get("remote_address") or svc.get("remoteAddress")
                parsed = _parse_remote(remote)
                if not parsed:
                    continue
                host, port = parsed
                if host in ("127.0.0.1", "::1", "localhost"):
                    continue

                remote_ip = host
                remote_host = None
                if not _is_ip(host):
                    remote_host = host
                    try:
                        infos = await asyncio.wait_for(
                            asyncio.get_running_loop().getaddrinfo(host, None, family=socket.AF_INET, type=socket.SOCK_STREAM),
                            timeout=0.8,
                        )
                        remote_ip = infos[0][4][0] if infos else None
                        if not remote_ip:
                            continue
                    except Exception:
                        # Can't resolve -> skip edge (backend persistence requires IP)
                        continue

                # Skip known CDN IPs - these are external services, not infrastructure assets
                # This filters only known CDN ranges, not all external IPs (servers may communicate through external nodes)
                if self._is_known_cdn(remote_ip):
                    continue

                remote_id = self._ensure_asset_for_ip(
                    ip_str=remote_ip,
                    scanned_at=scanned_at,
                    hostname=remote_host or remote_ip,
                    tags=["remoteAddress"],
                    detection_method="Service remoteAddress",
                    detection_location=str(remote),
                    detection_reason=self._build_remoteaddress_reason(local_asset=local_asset, svc=svc, remote=str(remote)),
                )
                if not remote_id:
                    continue

                key = (remote_ip, port, svc.get("protocol") or svc.get("protocol", None))
                if key in seen:
                    continue
                seen.add(key)

                proto = svc.get("protocol")
                if not proto and isinstance(port, int):
                    if port in (80, 8080, 8088, 8000, 3000, 3002, 5000):
                        proto = "http"
                    elif port in (443, 8443):
                        proto = "https"
                    else:
                        proto = "tcp"

                self.discovered_connections.append({
                    "from_asset_id": local_id,
                    "to_asset_id": remote_id,
                    "from_ip": local_ip,
                    "to_ip": remote_ip,
                    "connection_type": "dependency",
                    "port": port,
                    "protocol": proto,
                    "discovered_at": scanned_at,
                    "last_seen": scanned_at,
                    "status": "active",
                })
            except Exception:
                continue

    async def _emit_edges_from_internal_inbound_ssh(self, local_asset: Dict[str, Any], services: List[Dict[str, Any]], scanned_at: str, limit: int = 25) -> None:
        """
        Draw INTERNAL SSH edges for topology visibility in Asset Graph.

        We intentionally exclude public inbound SSH (scanners/bots), which should be represented in Current Threat Graph.
        Source for this signal: process-scan entries that captured internal inbound peers.
        """
        local_id = local_asset.get("id")
        local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
        if not local_id or not local_ip:
            return

        def _norm_ip(v: Any) -> Optional[str]:
            s = str(v or "").strip()
            return s if s else None

        def _is_internal_ip(ip_str: str) -> bool:
            try:
                ip_obj = ipaddress.ip_address(str(ip_str).strip())
                if ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_multicast:
                    return False
                # RFC1918
                if getattr(ip_obj, "is_private", False):
                    return True
                # RFC6598 CGNAT (100.64.0.0/10)
                if isinstance(ip_obj, ipaddress.IPv4Address) and ip_obj in ipaddress.ip_network("100.64.0.0/10"):
                    return True
                # IPv6 ULA
                if isinstance(ip_obj, ipaddress.IPv6Address) and ip_obj in ipaddress.ip_network("fc00::/7"):
                    return True
            except Exception:
                return False
            return False

        # Build a quick lookup of existing discovered assets by IP
        asset_id_by_ip: Dict[str, str] = {}
        try:
            for aid, a in (self.discovered_assets or {}).items():
                ip = _norm_ip(a.get("ip_address") or a.get("ipAddress"))
                if ip:
                    asset_id_by_ip[ip] = str(aid)
        except Exception:
            asset_id_by_ip = {}

        emitted = 0
        seen: set[tuple[str, str]] = set()  # (src_ip, dst_ip)

        for svc in services:
            if emitted >= limit:
                break
            try:
                name = str(svc.get("name") or "").lower()
                dm = str(svc.get("discovery_method") or svc.get("discoveryMethod") or "").lower()
                if dm != "process-scan":
                    continue
                # Only for sshd-ish processes
                if "sshd" not in name and "ssh" not in name:
                    continue

                peers = svc.get("inbound_peers") or svc.get("inboundPeers")
                if not isinstance(peers, list) or not peers:
                    continue

                for peer in peers[:5]:
                    if emitted >= limit:
                        break
                    p = str(peer or "").strip()
                    if not p or ":" not in p:
                        continue
                    host, _port_s = p.rsplit(":", 1)
                    src_ip = _norm_ip(host)
                    if not src_ip or not _is_internal_ip(src_ip):
                        continue
                    if src_ip == local_ip:
                        continue

                    # Prefer linking to an existing discovered asset; otherwise create a conservative inferred internal node.
                    src_id = asset_id_by_ip.get(src_ip)
                    if not src_id:
                        src_id = self._ensure_asset_for_ip(
                            ip_str=src_ip,
                            scanned_at=scanned_at,
                            hostname=src_ip,
                            tags=["inferred", "internal-ssh-peer"],
                            detection_method="Internal SSH peer (process-scan)",
                            detection_location=f"sshd inbound peer {src_ip}",
                            detection_reason=f"Internal inbound SSH session observed to {local_asset.get('hostname') or local_ip} (service={svc.get('name')}; via=process-scan).",
                        )
                        if src_id:
                            asset_id_by_ip[src_ip] = src_id

                    if not src_id:
                        continue

                    key = (src_ip, str(local_ip))
                    if key in seen:
                        continue
                    seen.add(key)

                    self.discovered_connections.append({
                        "from_asset_id": src_id,
                        "to_asset_id": local_id,
                        "from_ip": src_ip,
                        "to_ip": local_ip,
                        "connection_type": "network",
                        "port": 22,
                        "protocol": "ssh",
                        "discovered_at": scanned_at,
                        "last_seen": scanned_at,
                        "status": "active",
                    })
                    emitted += 1
            except Exception:
                continue

    async def _emit_arp_and_route_edges(self, local_asset: Dict[str, Any], scanned_at: str, limit: int = 25) -> None:
        """
        Add low-cost topology edges from ARP table and default route.
        These edges may not have a port.
        """
        local_id = local_asset.get("id")
        local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
        if not local_id or not local_ip:
            return

        seen = set()

        # Warm up ARP cache (helps in docker/vuln env where ARP table is often empty until traffic happens)
        try:
            await self._warm_up_arp_cache(local_ip=local_ip, max_probes=20)
        except Exception:
            pass

        # Default gateway route edge
        gw_ip = None
        gw_mac = None
        try:
            line = await self._run_shell_stdout("ip route show default 2>/dev/null | head -n 1", timeout=3)
            # Example: default via 172.17.0.1 dev eth0
            m = re.search(r"\bvia\s+([0-9\\.]+)\b", line)
            if m:
                gw_ip = m.group(1)
                gw_id = self._ensure_asset_for_ip(
                    ip_str=gw_ip,
                    scanned_at=scanned_at,
                    hostname="_gateway",
                    tags=["gateway", "provider-service", "not-ours"],
                    detection_method="Routing table",
                    detection_location="ip route show default",
                    detection_reason="Default gateway inferred from routing table.",
                )
                if gw_id:
                    k = (gw_ip, "route")
                    if k not in seen:
                        seen.add(k)
                        self.discovered_connections.append({
                            "from_asset_id": local_id,
                            "to_asset_id": gw_id,
                            "from_ip": local_ip,
                            "to_ip": gw_ip,
                            "connection_type": "network",
                            "port": None,
                            "protocol": "route",
                            "discovered_at": scanned_at,
                            "last_seen": scanned_at,
                            "status": "active",
                        })
                # Try to learn gateway MAC for proxy-ARP filtering (DO case: many IPs share gateway lladdr)
                try:
                    l2 = await self._ip_neigh_first_line(gw_ip)
                    mm = re.search(r"\blladdr\s+([0-9a-f:]{17})\b", l2, re.IGNORECASE)
                    if mm:
                        gw_mac = mm.group(1).lower()
                except Exception:
                    gw_mac = None
        except Exception:
            pass

        # ARP neighbors (Linux)
        try:
            out = await self._run_shell_stdout("ip neigh show 2>/dev/null | head -n 400", timeout=4)
            lines = [ln.strip() for ln in (out or "").splitlines() if ln.strip()]
            if not lines and os.path.exists("/proc/net/arp"):
                # Fallback: /proc/net/arp (linux)
                try:
                    with open("/proc/net/arp", "r", encoding="utf-8", errors="ignore") as f:
                        proc_lines = f.read().splitlines()[1:]  # skip header
                    # Format: IP address HW type Flags HW address Mask Device
                    for ln in proc_lines:
                        parts = ln.split()
                        if len(parts) >= 4:
                            ip_str = parts[0].strip()
                            mac = parts[3].strip().lower()
                            if ip_str and mac and mac != "00:00:00:00:00:00":
                                lines.append(f"{ip_str} dev unknown lladdr {mac} STALE")
                except Exception:
                    pass
            count = 0
            for line in lines:
                if count >= limit:
                    break
                # Common formats:
                # - "IP dev IFACE lladdr MAC STALE"
                # - "IP dev IFACE INCOMPLETE"
                parts = line.split()
                if not parts:
                    continue
                ip_str = parts[0]
                if ip_str == local_ip or ip_str.startswith("127."):
                    continue
                try:
                    ipaddress.ip_address(ip_str)
                except Exception:
                    continue

                # Skip explicit FAILED entries; INCOMPLETE is still useful for topology.
                if "FAILED" in parts:
                    continue

                # Dynamic provider-infra filtering:
                # On DigitalOcean public networks, many IPs can appear in `ip neigh` with the same lladdr as the gateway
                # (proxy ARP / virtual fabric). These are not "your servers" and should not clutter the asset list.
                try:
                    ip_obj = ipaddress.ip_address(ip_str)
                    if gw_mac and not ip_obj.is_private:
                        mm = re.search(r"\blladdr\s+([0-9a-f:]{17})\b", line, re.IGNORECASE)
                        if mm and mm.group(1).lower() == gw_mac and ip_str != gw_ip:
                            continue
                except Exception:
                    pass

                neighbor_id = self._ensure_asset_for_ip(
                    ip_str=ip_str,
                    scanned_at=scanned_at,
                    hostname=ip_str,
                    tags=["arp"],
                    detection_method="ARP",
                    detection_location="ip neigh show",
                    detection_reason="Neighbor inferred from ARP cache.",
                )
                if not neighbor_id:
                    continue
                k = (ip_str, "arp")
                if k in seen:
                    continue
                seen.add(k)
                self.discovered_connections.append({
                    "from_asset_id": local_id,
                    "to_asset_id": neighbor_id,
                    "from_ip": local_ip,
                    "to_ip": ip_str,
                    "connection_type": "network",
                    "port": None,
                    "protocol": "arp",
                    "discovered_at": scanned_at,
                    "last_seen": scanned_at,
                    "status": "active",
                })
                count += 1
        except Exception:
            pass

    async def _warm_up_arp_cache(self, local_ip: str, max_probes: int = 20) -> None:
        """
        Generate a small amount of local traffic to populate ARP/neighbor tables.
        Keep it bounded and fast.
        """
        try:
            targets = []

            # Default gateway is the best single probe (usually reachable).
            try:
                line = await self._run_shell_stdout("ip route show default 2>/dev/null | head -n 1", timeout=2)
                m = re.search(r"\bvia\s+([0-9\\.]+)\b", line)
                if m:
                    targets.append(m.group(1))
            except Exception:
                pass

            # host.docker.internal often appears in the graph; probe it if resolvable.
            try:
                infos = await asyncio.wait_for(
                    asyncio.get_running_loop().getaddrinfo("host.docker.internal", None, family=socket.AF_INET, type=socket.SOCK_STREAM),
                    timeout=0.8,
                )
                ip = infos[0][4][0] if infos else None
                if ip:
                    targets.append(ip)
            except Exception:
                pass

            # Probe a few IPs in the local subnet.
            try:
                # IMPORTANT (real-world DO case):
                # On public cloud L2 segments (e.g. DigitalOcean public /20), ping-sweeping the subnet
                # creates a ton of proxy-ARP neighbor entries (many IPs map to the same lladdr),
                # which the UI later misinterprets as "provider-owned servers".
                #
                # Therefore: only sweep *private* networks. For public IPs, probe only the gateway.
                ip_obj = ipaddress.ip_address(local_ip)
                if ip_obj.is_private:
                    # Use the same heuristic prefix as backend grouping: 16 for 172.*, else /24.
                    prefix = 16 if local_ip.startswith("172.") else 24
                    net = ipaddress.ip_network(f"{local_ip}/{prefix}", strict=False)
                    # Take first N hosts (skip own ip)
                    for h in net.hosts():
                        s = str(h)
                        if s == local_ip or s.startswith("127."):
                            continue
                        targets.append(s)
                        if len(targets) >= max_probes:
                            break
            except Exception:
                pass

            # De-dupe while preserving order
            seen = set()
            uniq = []
            for t in targets:
                if t not in seen:
                    seen.add(t)
                    uniq.append(t)

            for t in uniq[:max_probes]:
                try:
                    await self._run_ping_once(t)
                except Exception:
                    continue
        except Exception:
            return

    async def _emit_config_inferred_edges(self, local_asset: Dict[str, Any], scanned_at: str, limit: int = 25) -> None:
        """
        Parse a few common configs for upstream/dependency endpoints and emit edges.
        Keep this light: best-effort regex, bounded results.
        """
        local_id = local_asset.get("id")
        local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
        if not local_id or not local_ip:
            return

        candidates: List[str] = []
        nginx_paths = ["/etc/nginx/nginx.conf"]
        try:
            for root, _, files in os.walk("/etc/nginx", topdown=True):
                for f in files:
                    if f.endswith(".conf"):
                        nginx_paths.append(os.path.join(root, f))
        except Exception:
            pass

        for p in nginx_paths:
            try:
                if os.path.isfile(p):
                    txt = open(p, "r", encoding="utf-8", errors="ignore").read()
                    candidates.append(txt)
            except Exception:
                continue

        # Extract endpoints from common patterns:
        # - proxy_pass http://host:port
        # - server host:port; inside upstream blocks
        endpoints: List[tuple[str, Optional[int], Optional[str], str]] = []
        for txt in candidates:
            for m in re.finditer(r"\bproxy_pass\s+(https?)://([^\\s/;]+)", txt, flags=re.IGNORECASE):
                scheme = m.group(1).lower()
                hostport = m.group(2)
                host, port = (hostport, None)
                if ":" in hostport:
                    host, port_s = hostport.rsplit(":", 1)
                    try:
                        port = int(port_s)
                    except Exception:
                        port = None
                if port is None:
                    port = 443 if scheme == "https" else 80
                endpoints.append((host, port, scheme, "nginx:proxy_pass"))

            for m in re.finditer(r"\bserver\s+([^\\s;]+);", txt, flags=re.IGNORECASE):
                hostport = m.group(1)
                # skip unix sockets etc
                if hostport.startswith("unix:"):
                    continue
                host, port = (hostport, None)
                if ":" in hostport:
                    host, port_s = hostport.rsplit(":", 1)
                    try:
                        port = int(port_s)
                    except Exception:
                        port = None
                endpoints.append((host, port, None, "nginx:upstream"))

        def _is_ip(s: str) -> bool:
            try:
                ipaddress.ip_address(s)
                return True
            except Exception:
                return False

        def _infer_proto(port: Optional[int], scheme: Optional[str]) -> Optional[str]:
            if scheme in ("http", "https"):
                return scheme
            if isinstance(port, int):
                if port in (80, 8080, 8088, 8000, 3000, 3002, 5000):
                    return "http"
                if port in (443, 8443):
                    return "https"
                if port in (5432,):
                    return "postgresql"
                if port in (3306,):
                    return "mysql"
                if port in (6379,):
                    return "redis"
                return "tcp"
            return None

        seen = set()
        emitted = 0
        for host, port, scheme, source in endpoints:
            if emitted >= limit:
                break
            if not host or host in ("127.0.0.1", "::1", "localhost"):
                continue

            remote_ip = host
            remote_host = None
            if not _is_ip(host):
                remote_host = host
                try:
                    infos = await asyncio.wait_for(
                        asyncio.get_running_loop().getaddrinfo(host, None, family=socket.AF_INET, type=socket.SOCK_STREAM),
                        timeout=0.8,
                    )
                    remote_ip = infos[0][4][0] if infos else None
                    if not remote_ip:
                        continue
                except Exception:
                    continue

            remote_id = self._ensure_asset_for_ip(
                ip_str=remote_ip,
                scanned_at=scanned_at,
                hostname=remote_host or remote_ip,
                tags=["config-inferred"],
                detection_method="Config inference",
                detection_location=source,
                detection_reason="Dependency inferred from configuration parsing (nginx/apache/upstreams).",
            )
            if not remote_id:
                continue

            proto = _infer_proto(port, scheme)
            k = (remote_ip, port, proto, source)
            if k in seen:
                continue
            seen.add(k)

            # Also create an outbound "service" marker on the local asset so the UI can show discoveryMethod
            # (we match remoteAddress in GraphView).
            try:
                local_hn = local_asset.get("hostname") or local_ip
                svc_port = port
                svc_proto = proto or ("tcp" if svc_port else None)
                if isinstance(svc_port, int):
                    svc_id = f"config_outbound:{remote_ip}:{svc_port}:{svc_proto or 'tcp'}"
                else:
                    svc_id = f"config_outbound:{remote_ip}:{svc_proto or 'tcp'}"
                if svc_id not in self.discovered_services:
                    self.discovered_services[svc_id] = {
                        "id": svc_id,
                        "name": f"Outbound dependency ({source})",
                        "asset_id": local_id,
                        "asset_hostname": local_hn,
                        "asset_ip_address": local_ip,
                        "status": "running",
                        "port": svc_port,
                        "protocol": svc_proto,
                        "port_direction": "outbound",
                        "remote_address": f"{remote_ip}:{svc_port}" if svc_port else remote_ip,
                        "service_type": "other",
                        "description": f"Dependency inferred from config: {source}",
                        "discovery_method": "config-inferred",
                        "discovered_at": scanned_at,
                        "last_seen": scanned_at,
                        "detection_location": source,
                        "detection_reason": "Config parsing found upstream/endpoint.",
                    }
            except Exception:
                pass

            self.discovered_connections.append({
                "from_asset_id": local_id,
                "to_asset_id": remote_id,
                "from_ip": local_ip,
                "to_ip": remote_ip,
                "connection_type": "dependency",
                "port": port,
                "protocol": proto,
                "discovered_at": scanned_at,
                "last_seen": scanned_at,
                "status": "active",
            })
            emitted += 1
