from .asset_discovery import AssetDiscoveryPlugin

