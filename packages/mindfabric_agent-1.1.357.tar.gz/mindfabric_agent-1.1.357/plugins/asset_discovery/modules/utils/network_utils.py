"""
Network utilities
"""
import socket
import struct


def prefix_to_netmask(prefix: int) -> str:
    """Convert CIDR prefix to dotted decimal netmask"""
    mask = (0xffffffff >> (32 - prefix)) << (32 - prefix)
    return socket.inet_ntoa(struct.pack('!I', mask))


def hex_netmask_to_dotted(hex_netmask: str) -> str:
    """Convert hex netmask (0xffffff00) to dotted decimal"""
    try:
        mask_value = int(hex_netmask, 16)
        return socket.inet_ntoa(struct.pack('!I', mask_value))
    except:
        return hex_netmask

