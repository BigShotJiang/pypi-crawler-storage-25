"""
ID generation utilities
"""
import hashlib


def generate_asset_id(hostname: str, ip_address: str) -> str:
    """Generate unique asset ID"""
    unique_string = f"{hostname}_{ip_address}"
    return hashlib.md5(unique_string.encode()).hexdigest()[:12]

