"""
Async HTTP helpers (no external deps).

We intentionally avoid the standard library's blocking HTTP client inside async code paths,
because it blocks the agent event loop. These helpers use `asyncio.open_connection` with optional TLS.
"""

from __future__ import annotations

import asyncio
import ssl
from typing import Dict, Tuple, Optional
from urllib.parse import urlparse


def _normalize_headers(headers: Optional[Dict[str, str]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not headers:
        return out
    for k, v in headers.items():
        if not k:
            continue
        out[str(k)] = str(v)
    return out


async def fetch(
    url: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 5.0,
    max_bytes: int = 65536,
) -> Tuple[Optional[int], Dict[str, str], bytes]:
    """
    Fetch a URL via HTTP/HTTPS and return (status_code, headers, body_bytes).
    Returns (None, {}, b"") on parse/connect errors.

    Notes:
    - TLS verification is disabled (like our other discovery probes).
    - Not a full HTTP client (no redirects, limited parsing).
    """
    try:
        parsed = urlparse(url)
        scheme = (parsed.scheme or "http").lower()
        host = parsed.hostname
        if not host:
            return None, {}, b""

        port = parsed.port or (443 if scheme == "https" else 80)
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"

        hdrs = _normalize_headers(headers)
        if "Host" not in hdrs and "host" not in {k.lower() for k in hdrs.keys()}:
            hdrs["Host"] = host
        if "User-Agent" not in hdrs and "user-agent" not in {k.lower() for k in hdrs.keys()}:
            hdrs["User-Agent"] = "Mozilla/5.0"
        if "Connection" not in hdrs and "connection" not in {k.lower() for k in hdrs.keys()}:
            hdrs["Connection"] = "close"

        hdr_lines = "".join([f"{k}: {v}\r\n" for k, v in hdrs.items()])
        req = f"GET {path} HTTP/1.1\r\n{hdr_lines}\r\n".encode("utf-8", errors="ignore")

        ctx = None
        if scheme == "https":
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, ssl=ctx, server_hostname=host if ctx else None),
            timeout=timeout,
        )
        try:
            writer.write(req)
            await writer.drain()
            raw = await asyncio.wait_for(reader.read(max_bytes), timeout=timeout)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

        if not raw:
            return None, {}, b""

        header_blob, _, body = raw.partition(b"\r\n\r\n")
        header_lines = header_blob.split(b"\r\n")
        status = None
        if header_lines:
            try:
                first = header_lines[0].decode("utf-8", errors="ignore")
                if "HTTP/" in first:
                    status = int(first.split()[1])
            except Exception:
                status = None

        out_headers: Dict[str, str] = {}
        for line_b in header_lines[1:]:
            try:
                line = line_b.decode("utf-8", errors="ignore")
                if ":" not in line:
                    continue
                k, v = line.split(":", 1)
                out_headers[k.strip().lower()] = v.strip()
            except Exception:
                continue

        return status, out_headers, body
    except Exception:
        return None, {}, b""

