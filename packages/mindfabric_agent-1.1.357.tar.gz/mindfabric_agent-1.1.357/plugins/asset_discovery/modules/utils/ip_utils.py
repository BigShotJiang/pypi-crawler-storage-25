"""
IP address utilities
"""
import socket
from typing import Optional


def get_local_ip(hostname: Optional[str] = None) -> Optional[str]:
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            resolver = getattr(socket, "gethostbyname", None)
            if not resolver:
                return None
            if hostname:
                return resolver(hostname)
            else:
                return resolver(socket.gethostname())
        except Exception:
            return None

