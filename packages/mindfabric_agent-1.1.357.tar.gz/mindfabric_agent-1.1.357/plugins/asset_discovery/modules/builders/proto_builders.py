"""
Builders for converting between dict and proto dataclass formats
"""
import hashlib
import re
from typing import Dict, Any, List

from ...proto import Asset, Service, AssetConnection, NetworkInterface, HardwareSpecs


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def dict_to_asset(data: Dict[str, Any]) -> Asset:
    """Convert dict to Asset dataclass"""
    network_interfaces = []
    for iface in data.get("network_interfaces", []):
        network_interfaces.append(NetworkInterface(**iface))
    
    hardware_data = data.get("hardware")
    hardware = None
    if hardware_data:
        hardware = HardwareSpecs(**hardware_data)
    
    return Asset(
        id=data["id"],
        ip_address=data["ip_address"],
        hostname=data["hostname"],
        status=data["status"],
        provider=data["provider"],
        os=data["os"],
        agent_type=data["agent_type"],
        environment=data["environment"],
        services=data.get("services", []),
        role=data.get("role"),
        last_seen=data["last_seen"],
        discovered_at=data["discovered_at"],
        network=data.get("network"),
        network_interfaces=network_interfaces,
        tags=data.get("tags", []),
        detection_method=data.get("detection_method"),
        detection_location=data.get("detection_location"),
        detection_reason=data.get("detection_reason"),
        hardware=hardware
    )


def dict_to_service(data: Dict[str, Any]) -> Service:
    """Convert dict to Service dataclass"""
    # Be defensive: discovery/enrichment stages may add extra keys (e.g. web_fingerprint, type).
    # Dataclasses will raise TypeError on unexpected kwargs, which breaks the whole scan.
    # Also handle camelCase keys (e.g. assetHostname -> asset_hostname)
    allowed = set(Service.__dataclass_fields__.keys())  # type: ignore[attr-defined]
    
    # Normalize keys: convert camelCase to snake_case and check both formats
    normalized_data = {}
    for k, v in data.items():
        # Try exact match first (snake_case)
        if k in allowed:
            normalized_data[k] = v
        else:
            # Try camelCase -> snake_case conversion
            snake_key = _camel_to_snake(k)
            if snake_key in allowed:
                normalized_data[snake_key] = v
            # Handle special alias: "type" -> "service_type"
            elif k == "type" and "service_type" in allowed:
                normalized_data["service_type"] = v
    
    # Filter to only allowed keys (should already be normalized, but double-check)
    filtered = {k: v for k, v in normalized_data.items() if k in allowed}
    
    # Check for required fields and provide defaults if missing
    required_fields = {
        'id', 'name', 'asset_id', 'asset_hostname', 'asset_ip_address',
        'status', 'service_type', 'description', 'discovery_method', 'discovered_at'
    }
    missing_fields = required_fields - set(filtered.keys())
    
    if missing_fields:
        # Try to provide sensible defaults for missing required fields
        if 'id' in missing_fields:
            filtered['id'] = filtered.get('name', 'unknown') + '_' + str(hash(str(filtered)))
        if 'name' in missing_fields:
            filtered['name'] = filtered.get('service_type', 'unknown_service')
        if 'asset_id' in missing_fields:
            filtered['asset_id'] = filtered.get('asset_hostname', 'unknown')
        if 'asset_hostname' in missing_fields:
            filtered['asset_hostname'] = filtered.get('name', 'unknown')
        if 'asset_ip_address' in missing_fields:
            filtered['asset_ip_address'] = '0.0.0.0'
        if 'status' in missing_fields:
            filtered['status'] = 'running'
        if 'service_type' in missing_fields:
            filtered['service_type'] = 'other'
        if 'description' in missing_fields:
            filtered['description'] = filtered.get('name', 'Service')
        if 'discovery_method' in missing_fields:
            filtered['discovery_method'] = 'unknown'
        if 'discovered_at' in missing_fields:
            from datetime import datetime
            filtered['discovered_at'] = datetime.utcnow().isoformat()
    
    return Service(**filtered)


def dict_to_connection(data: Dict[str, Any]) -> AssetConnection:
    """Convert dict to AssetConnection dataclass"""
    return AssetConnection(**data)


def asset_to_dict(asset: Asset) -> Dict[str, Any]:
    """Convert Asset to dict"""
    result = {
        "id": asset.id,
        "ipAddress": asset.ip_address,
        "hostname": asset.hostname,
        "status": asset.status,
        "provider": asset.provider,
        "os": asset.os,
        "agentType": asset.agent_type,
        "environment": asset.environment,
        "services": asset.services,
        "lastSeen": asset.last_seen,
        "discoveredAt": asset.discovered_at,
        "tags": asset.tags
    }
    
    if asset.role:
        result["role"] = asset.role
    if asset.network:
        result["network"] = asset.network
    if asset.network_interfaces:
        result["networkInterfaces"] = [
            {
                "ipAddress": iface.ip_address,
                "network": iface.network,
                "interface": iface.interface,
                "isPrimary": iface.is_primary,
                "macAddress": iface.mac_address,
                "netmask": iface.netmask,
                "broadcast": iface.broadcast,
                "mtu": iface.mtu,
                "status": iface.status,
                "flags": iface.flags,
                "media": iface.media,
                "linkSpeed": iface.link_speed,
                "vlan": iface.vlan,
                "ipv6": iface.ipv6
            }
            for iface in asset.network_interfaces
        ]
    if asset.detection_method:
        result["detectionMethod"] = asset.detection_method
    if asset.detection_location:
        result["detectionLocation"] = asset.detection_location
    if asset.detection_reason:
        result["detectionReason"] = asset.detection_reason
    if asset.hardware:
        result["hardware"] = {
            "cpu": asset.hardware.cpu,
            "memory": asset.hardware.memory,
            "disk": asset.hardware.disk
        }
    
    return result


def service_to_dict(service: Service) -> Dict[str, Any]:
    """Convert Service to dict"""
    return {
        "id": service.id,
        "name": service.name,
        "assetId": service.asset_id,
        "assetHostname": service.asset_hostname,
        "assetIpAddress": service.asset_ip_address,
        "status": service.status,
        "port": service.port,
        "protocol": service.protocol,
        "portDirection": service.port_direction,
        "remoteAddress": service.remote_address,
        "serviceType": service.service_type,
        "description": service.description,
        "discoveryMethod": service.discovery_method,
        "discoveredAt": service.discovered_at,
        "lastSeen": service.last_seen,
        "version": service.version,
        "processInfo": service.process_info,
        "containerInfo": service.container_info,
        "configPath": service.config_path,
        "environment": service.environment,
        "detectionLocation": service.detection_location,
        "detectionReason": service.detection_reason
    }


def connection_to_dict(conn: AssetConnection) -> Dict[str, Any]:
    """Convert AssetConnection to dict"""
    return {
        "from": conn.from_asset_id,
        "to": conn.to_asset_id,
        "fromIp": conn.from_ip,
        "toIp": conn.to_ip,
        "type": conn.connection_type,
        "port": conn.port,
        "protocol": conn.protocol,
        "discoveredAt": conn.discovered_at,
        "lastSeen": conn.last_seen,
        "status": conn.status
    }


def add_service_from_enumeration(
    discovered_services: Dict[str, Any],
    enum_result: Dict[str, Any],
    service_type: str
) -> None:
    """Add service from enumeration result"""
    try:
        service_id = f"service_{enum_result.get('ip', 'unknown')}_{enum_result.get('port', 0)}"
        
        if service_id not in discovered_services:
            service = {
                "id": service_id,
                "name": f"{service_type} Service",
                "asset_id": None,  # Will be linked later
                "type": service_type,
                "port": enum_result.get("port", 0),
                "protocol": enum_result.get("protocol", "tcp"),
                "status": "running" if enum_result.get("accessible") else "unknown",
                "discovery_method": f"{service_type.lower()}-enumeration",
                "details": enum_result
            }
            discovered_services[service_id] = service
    except Exception as e:
        from utils.logger import logger
        logger.debug(f"Error adding service from enumeration: {e}")


def add_cloud_resource(
    discovered_services: Dict[str, Any],
    resource: Dict[str, Any],
    resource_type: str
) -> None:
    """Add cloud resource as service"""
    try:
        resource_id = f"cloud_{resource_type.lower().replace(' ', '_')}_{hashlib.md5(str(resource).encode()).hexdigest()[:8]}"
        
        if resource_id not in discovered_services:
            service = {
                "id": resource_id,
                "name": f"{resource_type}: {resource.get('name', 'unknown')}",
                "asset_id": None,
                "type": resource_type,
                "port": None,
                "protocol": "cloud",
                "status": "accessible" if resource.get("accessible") else "unknown",
                "discovery_method": "cloud-enumeration",
                "details": resource
            }
            discovered_services[resource_id] = service
    except Exception as e:
        from utils.logger import logger
        logger.debug(f"Error adding cloud resource: {e}")


def add_service_mesh_services(
    discovered_services: Dict[str, Any],
    mesh_data: Dict[str, Any],
    mesh_type: str
) -> None:
    """Add service mesh services to discovered services"""
    try:
        if mesh_type == "Istio" and "services" in mesh_data:
            for service in mesh_data.get("services", [])[:20]:  # Limit
                service_id = f"mesh_istio_{hashlib.md5(str(service).encode()).hexdigest()[:8]}"
                discovered_services[service_id] = {
                    "id": service_id,
                    "name": f"Istio Service: {service}",
                    "asset_id": None,
                    "type": "Istio Service",
                    "port": None,
                    "protocol": "service-mesh",
                    "status": "running",
                    "discovery_method": "service-mesh",
                    "details": mesh_data
                }
        
        elif mesh_type == "Consul" and "services" in mesh_data:
            services_list = mesh_data.get("services", [])
            if isinstance(services_list, list):
                for service_name in services_list[:20]:
                    if isinstance(service_name, str):
                        service_id = f"mesh_consul_{hashlib.md5(service_name.encode()).hexdigest()[:8]}"
                        discovered_services[service_id] = {
                            "id": service_id,
                            "name": f"Consul Service: {service_name}",
                            "asset_id": None,
                            "type": "Consul Service",
                            "port": None,
                            "protocol": "service-mesh",
                            "status": "running",
                            "discovery_method": "service-mesh",
                            "details": mesh_data
                        }
        
        elif mesh_type == "Eureka" and "applications" in mesh_data:
            for app in mesh_data.get("applications", [])[:20]:
                app_name = app.get("name", "") if isinstance(app, dict) else str(app)
                service_id = f"mesh_eureka_{hashlib.md5(app_name.encode()).hexdigest()[:8]}"
                discovered_services[service_id] = {
                    "id": service_id,
                    "name": f"Eureka Application: {app_name}",
                    "asset_id": None,
                    "type": "Eureka Application",
                    "port": None,
                    "protocol": "service-mesh",
                    "status": "running",
                    "discovery_method": "service-mesh",
                    "details": mesh_data
                }
    except Exception as e:
        from utils.logger import logger
        logger.debug(f"Error adding service mesh services: {e}")


def extract_domain_from_hostname(hostname: str) -> str:
    """Extract domain from hostname"""
    try:
        # Remove common prefixes
        parts = hostname.split('.')
        if len(parts) >= 2:
            # Return last 2-3 parts as domain
            return '.'.join(parts[-2:]) if len(parts) >= 2 else ""
        return ""
    except Exception:
        return ""

