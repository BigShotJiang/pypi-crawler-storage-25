"""
Builders for converting between dict and dataclass formats
"""
from .proto_builders import (
    dict_to_asset,
    dict_to_service,
    dict_to_connection,
    asset_to_dict,
    service_to_dict,
    connection_to_dict,
    add_service_from_enumeration,
    add_cloud_resource,
    add_service_mesh_services,
    extract_domain_from_hostname,
)

__all__ = [
    'dict_to_asset',
    'dict_to_service',
    'dict_to_connection',
    'asset_to_dict',
    'service_to_dict',
    'connection_to_dict',
    'add_service_from_enumeration',
    'add_cloud_resource',
    'add_service_mesh_services',
    'extract_domain_from_hostname',
]

