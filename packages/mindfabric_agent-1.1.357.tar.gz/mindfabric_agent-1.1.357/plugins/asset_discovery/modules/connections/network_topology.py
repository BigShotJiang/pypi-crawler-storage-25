"""
Network Topology Discovery Module

Discovers and maps network topology including:
- Layer 2: ARP tables, VLAN, STP bridges, link aggregation
- Layer 3: Routing tables, BGP, OSPF neighbors, VRFs
- Traffic flow: NetFlow/sFlow patterns, bandwidth utilization

This module helps understand the physical and logical network structure
and how different network segments are interconnected.
"""

import os
import re
import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple


logger = logging.getLogger(__name__)

from ..utils.async_subprocess import run_exec_stdout


class NetworkLayerType(str, Enum):
    """Network layer types."""
    LAYER2 = "layer2"
    LAYER3 = "layer3"
    OVERLAY = "overlay"


class ConnectionType(str, Enum):
    """Types of network connections."""
    DIRECT = "direct"
    ROUTED = "routed"
    BRIDGED = "bridged"
    VLAN = "vlan"
    VPN = "vpn"
    OVERLAY = "overlay"


@dataclass
class ARPEntry:
    """ARP table entry."""
    ip_address: str
    mac_address: str
    interface: str
    state: str = "reachable"
    vendor: str = ""


@dataclass
class VLANInfo:
    """VLAN information."""
    vlan_id: int
    name: str = ""
    interfaces: List[str] = field(default_factory=list)
    ip_range: str = ""


@dataclass
class RouteEntry:
    """Routing table entry."""
    destination: str
    gateway: str
    interface: str
    metric: int = 0
    protocol: str = "static"  # static, connected, ospf, bgp, etc.
    flags: str = ""


@dataclass
class NetworkNeighbor:
    """Network routing neighbor (OSPF, BGP, etc.)."""
    neighbor_id: str
    neighbor_ip: str
    protocol: str  # ospf, bgp, eigrp
    state: str
    as_number: int = 0
    uptime: str = ""


@dataclass
class NetworkInterface:
    """Network interface details."""
    name: str
    mac_address: str
    ip_addresses: List[str] = field(default_factory=list)
    mtu: int = 1500
    state: str = "up"
    speed: str = ""
    duplex: str = ""
    vlan_id: Optional[int] = None
    bond_master: Optional[str] = None


@dataclass
class NetworkTopologyReport:
    """Complete network topology report."""
    interfaces: List[NetworkInterface] = field(default_factory=list)
    arp_entries: List[ARPEntry] = field(default_factory=list)
    vlans: List[VLANInfo] = field(default_factory=list)
    routes: List[RouteEntry] = field(default_factory=list)
    neighbors: List[NetworkNeighbor] = field(default_factory=list)
    bridges: List[Dict[str, Any]] = field(default_factory=list)
    bonds: List[Dict[str, Any]] = field(default_factory=list)
    connections: List[Dict[str, Any]] = field(default_factory=list)


class NetworkTopologyDiscovery:
    """Service for discovering network topology."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self._is_linux = os.name != 'nt'
    
    async def _run_command(self, cmd: List[str], timeout: int = 10) -> Optional[str]:
        """Run a command and return output (async, non-blocking)."""
        try:
            return await run_exec_stdout(cmd, timeout=float(timeout))
        except FileNotFoundError:
            return None
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Command {cmd} failed: {e}")
            return None
    
    async def discover_interfaces(self) -> List[NetworkInterface]:
        """
        Discover all network interfaces.
        
        Returns:
            List of NetworkInterface objects
        """
        interfaces = []
        
        if self._is_linux:
            # Try ip link show
            output = await self._run_command(["ip", "-j", "link", "show"])
            if output:
                try:
                    import json
                    links = json.loads(output)
                    for link in links:
                        iface = NetworkInterface(
                            name=link.get("ifname", ""),
                            mac_address=link.get("address", ""),
                            mtu=link.get("mtu", 1500),
                            state=link.get("operstate", "unknown"),
                        )
                        
                        # Check for VLAN
                        if "." in iface.name:
                            try:
                                iface.vlan_id = int(iface.name.split(".")[-1])
                            except ValueError:
                                pass
                        
                        # Check for bond
                        if link.get("master"):
                            iface.bond_master = link.get("master")
                        
                        interfaces.append(iface)
                        
                except json.JSONDecodeError:
                    pass
            
            # Get IP addresses
            ip_output = await self._run_command(["ip", "-j", "addr", "show"])
            if ip_output:
                try:
                    import json
                    addrs = json.loads(ip_output)
                    for addr_info in addrs:
                        ifname = addr_info.get("ifname", "")
                        for iface in interfaces:
                            if iface.name == ifname:
                                for addr in addr_info.get("addr_info", []):
                                    ip = f"{addr.get('local', '')}/{addr.get('prefixlen', '')}"
                                    iface.ip_addresses.append(ip)
                                break
                                
                except json.JSONDecodeError:
                    pass
        else:
            # Windows - use ipconfig
            output = await self._run_command(["ipconfig", "/all"])
            if output:
                current_iface = None
                for line in output.split('\n'):
                    if "adapter" in line.lower():
                        name = line.split("adapter")[-1].strip().rstrip(':')
                        current_iface = NetworkInterface(name=name, mac_address="")
                        interfaces.append(current_iface)
                    elif current_iface:
                        if "Physical Address" in line:
                            mac = line.split(":")[-1].strip()
                            current_iface.mac_address = mac
                        elif "IPv4 Address" in line:
                            ip = line.split(":")[-1].strip().replace("(Preferred)", "")
                            current_iface.ip_addresses.append(ip)
        
        return interfaces
    
    async def discover_arp_table(self) -> List[ARPEntry]:
        """
        Discover ARP table entries.
        
        Returns:
            List of ARPEntry objects
        """
        entries = []
        
        if self._is_linux:
            output = await self._run_command(["ip", "neigh", "show"])
            if output:
                for line in output.strip().split('\n'):
                    if not line:
                        continue
                    parts = line.split()
                    if len(parts) >= 5:
                        ip = parts[0]
                        mac = ""
                        iface = ""
                        state = ""
                        
                        for i, part in enumerate(parts):
                            if part == "dev":
                                iface = parts[i + 1] if i + 1 < len(parts) else ""
                            elif part == "lladdr":
                                mac = parts[i + 1] if i + 1 < len(parts) else ""
                        
                        state = parts[-1] if parts[-1] in ["REACHABLE", "STALE", "DELAY", "PROBE", "FAILED", "PERMANENT"] else ""
                        
                        if ip and mac:
                            entries.append(ARPEntry(
                                ip_address=ip,
                                mac_address=mac,
                                interface=iface,
                                state=state.lower(),
                            ))
        else:
            output = await self._run_command(["arp", "-a"])
            if output:
                for line in output.strip().split('\n'):
                    # Parse Windows arp -a output
                    match = re.search(r'(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F-]+)\s+(\w+)', line)
                    if match:
                        entries.append(ARPEntry(
                            ip_address=match.group(1),
                            mac_address=match.group(2).replace('-', ':'),
                            interface="",
                            state=match.group(3).lower(),
                        ))
        
        return entries
    
    async def discover_vlans(self) -> List[VLANInfo]:
        """
        Discover VLANs.
        
        Returns:
            List of VLANInfo objects
        """
        vlans = []
        
        if self._is_linux:
            # Check for VLAN interfaces
            output = await self._run_command(["ip", "-d", "link", "show"])
            if output:
                current_vlan_id = None
                current_iface = None
                
                for line in output.split('\n'):
                    # Look for interface name
                    iface_match = re.match(r'^\d+:\s+(\S+)[@:]', line)
                    if iface_match:
                        current_iface = iface_match.group(1)
                    
                    # Look for VLAN info
                    vlan_match = re.search(r'vlan protocol 802.1Q id (\d+)', line)
                    if vlan_match and current_iface:
                        vlan_id = int(vlan_match.group(1))
                        
                        # Find or create VLAN entry
                        vlan_entry = None
                        for v in vlans:
                            if v.vlan_id == vlan_id:
                                vlan_entry = v
                                break
                        
                        if not vlan_entry:
                            vlan_entry = VLANInfo(vlan_id=vlan_id)
                            vlans.append(vlan_entry)
                        
                        vlan_entry.interfaces.append(current_iface)
            
            # Try to read from /proc/net/vlan
            vlan_dir = "/proc/net/vlan"
            if os.path.exists(vlan_dir):
                try:
                    for filename in os.listdir(vlan_dir):
                        if filename != "config":
                            try:
                                vlan_id = int(filename.split(".")[-1])
                                exists = any(v.vlan_id == vlan_id for v in vlans)
                                if not exists:
                                    vlans.append(VLANInfo(
                                        vlan_id=vlan_id,
                                        interfaces=[filename],
                                    ))
                            except ValueError:
                                pass
                except Exception:
                    pass
        
        return vlans
    
    async def discover_routes(self) -> List[RouteEntry]:
        """
        Discover routing table.
        
        Returns:
            List of RouteEntry objects
        """
        routes = []
        
        if self._is_linux:
            output = await self._run_command(["ip", "-j", "route", "show"])
            if output:
                try:
                    import json
                    route_data = json.loads(output)
                    for r in route_data:
                        routes.append(RouteEntry(
                            destination=r.get("dst", "default"),
                            gateway=r.get("gateway", "direct"),
                            interface=r.get("dev", ""),
                            metric=r.get("metric", 0),
                            protocol=r.get("protocol", "static"),
                        ))
                except json.JSONDecodeError:
                    pass
            
            # Also get IPv6 routes
            output6 = await self._run_command(["ip", "-6", "-j", "route", "show"])
            if output6:
                try:
                    import json
                    route_data = json.loads(output6)
                    for r in route_data:
                        routes.append(RouteEntry(
                            destination=r.get("dst", "default"),
                            gateway=r.get("gateway", "direct"),
                            interface=r.get("dev", ""),
                            metric=r.get("metric", 0),
                            protocol=r.get("protocol", "static"),
                        ))
                except json.JSONDecodeError:
                    pass
        else:
            output = await self._run_command(["route", "print"])
            if output:
                for line in output.split('\n'):
                    parts = line.split()
                    if len(parts) >= 4 and re.match(r'\d+\.\d+\.\d+\.\d+', parts[0]):
                        routes.append(RouteEntry(
                            destination=parts[0],
                            gateway=parts[2] if len(parts) > 2 else "direct",
                            interface=parts[3] if len(parts) > 3 else "",
                            metric=int(parts[4]) if len(parts) > 4 else 0,
                        ))
        
        return routes
    
    async def discover_bridges(self) -> List[Dict[str, Any]]:
        """
        Discover network bridges.
        
        Returns:
            List of bridge information dictionaries
        """
        bridges = []
        
        if self._is_linux:
            output = await self._run_command(["bridge", "-j", "link", "show"])
            if output:
                try:
                    import json
                    bridge_data = json.loads(output)
                    
                    bridge_map = {}
                    for entry in bridge_data:
                        master = entry.get("master", "")
                        if master:
                            if master not in bridge_map:
                                bridge_map[master] = {
                                    "name": master,
                                    "interfaces": [],
                                    "stp_enabled": False,
                                }
                            bridge_map[master]["interfaces"].append(entry.get("ifname", ""))
                    
                    bridges = list(bridge_map.values())
                    
                except json.JSONDecodeError:
                    pass
            
            # Check STP status
            for bridge in bridges:
                stp_path = f"/sys/class/net/{bridge['name']}/bridge/stp_state"
                if os.path.exists(stp_path):
                    try:
                        with open(stp_path, 'r') as f:
                            bridge["stp_enabled"] = f.read().strip() != "0"
                    except Exception:
                        pass
        
        return bridges
    
    async def discover_bonds(self) -> List[Dict[str, Any]]:
        """
        Discover bonding/link aggregation.
        
        Returns:
            List of bond information dictionaries
        """
        bonds = []
        
        if self._is_linux:
            bond_dir = "/proc/net/bonding"
            if os.path.exists(bond_dir):
                try:
                    for bond_name in os.listdir(bond_dir):
                        bond_info = {
                            "name": bond_name,
                            "slaves": [],
                            "mode": "",
                            "active_slave": "",
                        }
                        
                        with open(os.path.join(bond_dir, bond_name), 'r') as f:
                            content = f.read()
                            
                            mode_match = re.search(r'Bonding Mode:\s*(.+)', content)
                            if mode_match:
                                bond_info["mode"] = mode_match.group(1).strip()
                            
                            active_match = re.search(r'Currently Active Slave:\s*(\S+)', content)
                            if active_match:
                                bond_info["active_slave"] = active_match.group(1)
                            
                            for slave_match in re.finditer(r'Slave Interface:\s*(\S+)', content):
                                bond_info["slaves"].append(slave_match.group(1))
                        
                        bonds.append(bond_info)
                        
                except Exception as e:
                    logger.debug(f"Error reading bonding info: {e}")
        
        return bonds
    
    async def discover_routing_neighbors(self) -> List[NetworkNeighbor]:
        """
        Discover routing protocol neighbors (OSPF, BGP).
        
        Returns:
            List of NetworkNeighbor objects
        """
        neighbors = []
        
        if self._is_linux:
            # Try FRR/Quagga vtysh
            for proto, cmd in [
                ("ospf", ["vtysh", "-c", "show ip ospf neighbor"]),
                ("bgp", ["vtysh", "-c", "show ip bgp summary"]),
            ]:
                output = await self._run_command(cmd)
                if output:
                    if proto == "ospf":
                        for line in output.split('\n'):
                            parts = line.split()
                            if len(parts) >= 6 and re.match(r'\d+\.\d+\.\d+\.\d+', parts[0]):
                                neighbors.append(NetworkNeighbor(
                                    neighbor_id=parts[0],
                                    neighbor_ip=parts[5] if len(parts) > 5 else parts[0],
                                    protocol="ospf",
                                    state=parts[2] if len(parts) > 2 else "",
                                ))
                    elif proto == "bgp":
                        for line in output.split('\n'):
                            parts = line.split()
                            if len(parts) >= 4 and re.match(r'\d+\.\d+\.\d+\.\d+', parts[0]):
                                neighbors.append(NetworkNeighbor(
                                    neighbor_id=parts[0],
                                    neighbor_ip=parts[0],
                                    protocol="bgp",
                                    state=parts[-1] if parts[-1].isalpha() else "established",
                                    as_number=int(parts[2]) if parts[2].isdigit() else 0,
                                ))
        
        return neighbors
    
    async def build_connection_map(
        self,
        interfaces: List[NetworkInterface],
        routes: List[RouteEntry],
        arp_entries: List[ARPEntry],
    ) -> List[Dict[str, Any]]:
        """
        Build a map of network connections.
        
        Args:
            interfaces: List of network interfaces
            routes: List of routing entries
            arp_entries: List of ARP entries
            
        Returns:
            List of connection dictionaries
        """
        connections = []
        
        # Map interfaces to their networks
        for iface in interfaces:
            for ip in iface.ip_addresses:
                if "/" in ip:
                    network = ip.rsplit('.', 1)[0] + ".0"
                    connections.append({
                        "type": "local_network",
                        "interface": iface.name,
                        "network": network,
                        "ip": ip.split('/')[0],
                    })
        
        # Map routes to gateways
        for route in routes:
            if route.gateway and route.gateway != "direct":
                connections.append({
                    "type": "route",
                    "destination": route.destination,
                    "gateway": route.gateway,
                    "interface": route.interface,
                    "protocol": route.protocol,
                })
        
        # Map ARP entries as directly reachable hosts
        for arp in arp_entries:
            connections.append({
                "type": "arp_neighbor",
                "ip": arp.ip_address,
                "mac": arp.mac_address,
                "interface": arp.interface,
                "state": arp.state,
            })
        
        return connections
    
    async def run_full_discovery(self) -> NetworkTopologyReport:
        """
        Run full network topology discovery.
        
        Returns:
            NetworkTopologyReport
        """
        interfaces = await self.discover_interfaces()
        arp_entries = await self.discover_arp_table()
        vlans = await self.discover_vlans()
        routes = await self.discover_routes()
        bridges = await self.discover_bridges()
        bonds = await self.discover_bonds()
        neighbors = await self.discover_routing_neighbors()
        
        connections = await self.build_connection_map(interfaces, routes, arp_entries)
        
        return NetworkTopologyReport(
            interfaces=interfaces,
            arp_entries=arp_entries,
            vlans=vlans,
            routes=routes,
            neighbors=neighbors,
            bridges=bridges,
            bonds=bonds,
            connections=connections,
        )

