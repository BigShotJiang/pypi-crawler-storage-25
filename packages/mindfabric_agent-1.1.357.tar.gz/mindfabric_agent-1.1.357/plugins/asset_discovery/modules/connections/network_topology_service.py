"""
Network Topology Discovery Service

Discovers network topology and relationships:
- Layer 2: ARP, VLAN, STP, Link Aggregation
- Layer 3: Routing tables, BGP, OSPF, VRF
- Traffic flow: NetFlow/sFlow patterns
- Connection mapping and visualization

This is NOT a security plugin - it's for infrastructure topology mapping.
"""

import os
import re
import asyncio
import socket
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple


logger = logging.getLogger(__name__)

from ..utils.async_subprocess import run_exec_stdout


class TopologyLayerType(str, Enum):
    """Network layer types."""
    LAYER2 = "layer2"
    LAYER3 = "layer3"
    APPLICATION = "application"


class ConnectionType(str, Enum):
    """Types of network connections."""
    DIRECT = "direct"
    ROUTED = "routed"
    PEERED = "peered"
    TUNNELED = "tunneled"
    BRIDGED = "bridged"
    NAT = "nat"


@dataclass
class ARPEntry:
    """ARP table entry."""
    ip_address: str
    mac_address: str
    interface: str
    state: str = ""
    vendor: str = ""


@dataclass
class VLANInfo:
    """VLAN information."""
    vlan_id: int
    name: str = ""
    interfaces: List[str] = field(default_factory=list)
    ip_range: str = ""
    state: str = "active"


@dataclass
class RouteEntry:
    """Routing table entry."""
    destination: str
    gateway: str
    interface: str
    metric: int = 0
    protocol: str = "static"
    flags: str = ""


@dataclass
class NetworkInterface:
    """Network interface details."""
    name: str
    mac_address: str = ""
    ip_addresses: List[str] = field(default_factory=list)
    mtu: int = 1500
    state: str = "up"
    speed: str = ""
    duplex: str = ""
    vlan_id: Optional[int] = None


@dataclass
class NetworkNode:
    """A node in the network topology."""
    node_id: str
    node_type: str  # host, router, switch, gateway
    hostname: str = ""
    ip_addresses: List[str] = field(default_factory=list)
    mac_addresses: List[str] = field(default_factory=list)
    interfaces: List[NetworkInterface] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NetworkEdge:
    """An edge (connection) between network nodes."""
    source_node: str
    target_node: str
    connection_type: ConnectionType
    layer: TopologyLayerType
    interface_source: str = ""
    interface_target: str = ""
    bandwidth: str = ""
    latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NetworkTopology:
    """Complete network topology."""
    nodes: List[NetworkNode] = field(default_factory=list)
    edges: List[NetworkEdge] = field(default_factory=list)
    vlans: List[VLANInfo] = field(default_factory=list)
    routes: List[RouteEntry] = field(default_factory=list)
    arp_table: List[ARPEntry] = field(default_factory=list)


class NetworkTopologyService:
    """Service for discovering network topology."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.topology = NetworkTopology()
        self._is_linux = os.name == 'posix' and os.path.exists('/proc')
        self._is_macos = os.name == 'posix' and os.uname().sysname == 'Darwin'
        self._is_windows = os.name == 'nt'
    
    async def _run_command(self, cmd: List[str], timeout: int = 30) -> Optional[str]:
        """Run a shell command and return output (async, non-blocking)."""
        try:
            return await run_exec_stdout(cmd, timeout=float(timeout))
        except FileNotFoundError:
            return None
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Command failed {cmd}: {e}")
            return None
    
    async def discover_arp_table(self) -> List[ARPEntry]:
        """
        Discover ARP table entries.
        
        Returns:
            List of ARP entries
        """
        entries = []
        
        if self._is_linux:
            # Linux: ip neigh or arp -a
            output = await self._run_command(["ip", "neigh", "show"])
            if output:
                for line in output.strip().split('\n'):
                    if not line:
                        continue
                    # Format: IP dev INTERFACE lladdr MAC state STATE
                    parts = line.split()
                    if len(parts) >= 4:
                        ip = parts[0]
                        interface = parts[2] if 'dev' in parts else ""
                        mac = ""
                        state = ""
                        
                        if 'lladdr' in parts:
                            idx = parts.index('lladdr')
                            if idx + 1 < len(parts):
                                mac = parts[idx + 1]
                        
                        # Get state
                        for s in ['REACHABLE', 'STALE', 'DELAY', 'PROBE', 'FAILED', 'PERMANENT']:
                            if s in parts:
                                state = s
                                break
                        
                        if mac:
                            entries.append(ARPEntry(
                                ip_address=ip,
                                mac_address=mac,
                                interface=interface,
                                state=state,
                            ))
        
        elif self._is_macos:
            output = await self._run_command(["arp", "-a"])
            if output:
                for line in output.strip().split('\n'):
                    # Format: hostname (IP) at MAC on interface
                    match = re.search(r'\(([0-9.]+)\) at ([0-9a-f:]+) on (\w+)', line)
                    if match:
                        entries.append(ARPEntry(
                            ip_address=match.group(1),
                            mac_address=match.group(2),
                            interface=match.group(3),
                        ))
        
        elif self._is_windows:
            output = await self._run_command(["arp", "-a"])
            if output:
                current_interface = ""
                for line in output.strip().split('\n'):
                    if 'Interface:' in line:
                        match = re.search(r'Interface:\s*([0-9.]+)', line)
                        if match:
                            current_interface = match.group(1)
                    elif re.match(r'\s*[0-9]+\.', line):
                        parts = line.split()
                        if len(parts) >= 2:
                            entries.append(ARPEntry(
                                ip_address=parts[0],
                                mac_address=parts[1],
                                interface=current_interface,
                                state=parts[2] if len(parts) > 2 else "",
                            ))
        
        self.topology.arp_table = entries
        return entries
    
    async def discover_vlans(self) -> List[VLANInfo]:
        """
        Discover VLAN information.
        
        Returns:
            List of VLANs
        """
        vlans = []
        
        if self._is_linux:
            # Check for VLAN interfaces
            output = await self._run_command(["ip", "-d", "link", "show"])
            if output:
                current_iface = ""
                for line in output.split('\n'):
                    # Interface name
                    match = re.match(r'\d+:\s+(\S+)[@:]', line)
                    if match:
                        current_iface = match.group(1)
                    
                    # VLAN info
                    if 'vlan' in line.lower() and 'id' in line.lower():
                        vlan_match = re.search(r'id\s+(\d+)', line)
                        if vlan_match:
                            vlans.append(VLANInfo(
                                vlan_id=int(vlan_match.group(1)),
                                interfaces=[current_iface],
                            ))
            
            # Check /proc/net/vlan if exists
            vlan_proc = "/proc/net/vlan/config"
            if os.path.exists(vlan_proc):
                try:
                    with open(vlan_proc, 'r') as f:
                        for line in f:
                            parts = line.split('|')
                            if len(parts) >= 3 and parts[0].strip() != 'VLAN Dev name':
                                vlan_id = int(parts[1].strip())
                                iface = parts[0].strip()
                                vlans.append(VLANInfo(
                                    vlan_id=vlan_id,
                                    interfaces=[iface],
                                ))
                except Exception as e:
                    logger.debug(f"Error reading VLAN config: {e}")
        
        self.topology.vlans = vlans
        return vlans
    
    async def discover_routes(self) -> List[RouteEntry]:
        """
        Discover routing table.
        
        Returns:
            List of route entries
        """
        routes = []
        
        if self._is_linux:
            output = await self._run_command(["ip", "route", "show"])
            if output:
                for line in output.strip().split('\n'):
                    if not line:
                        continue
                    
                    parts = line.split()
                    if not parts:
                        continue
                    
                    dest = parts[0]
                    gateway = ""
                    interface = ""
                    metric = 0
                    protocol = "kernel"
                    
                    if 'via' in parts:
                        idx = parts.index('via')
                        if idx + 1 < len(parts):
                            gateway = parts[idx + 1]
                    
                    if 'dev' in parts:
                        idx = parts.index('dev')
                        if idx + 1 < len(parts):
                            interface = parts[idx + 1]
                    
                    if 'metric' in parts:
                        idx = parts.index('metric')
                        if idx + 1 < len(parts):
                            try:
                                metric = int(parts[idx + 1])
                            except ValueError:
                                pass
                    
                    if 'proto' in parts:
                        idx = parts.index('proto')
                        if idx + 1 < len(parts):
                            protocol = parts[idx + 1]
                    
                    routes.append(RouteEntry(
                        destination=dest,
                        gateway=gateway,
                        interface=interface,
                        metric=metric,
                        protocol=protocol,
                    ))
        
        elif self._is_macos:
            output = await self._run_command(["netstat", "-rn"])
            if output:
                for line in output.strip().split('\n'):
                    parts = line.split()
                    if len(parts) >= 4 and not line.startswith('Routing') and not line.startswith('Destination'):
                        routes.append(RouteEntry(
                            destination=parts[0],
                            gateway=parts[1],
                            flags=parts[2],
                            interface=parts[3] if len(parts) > 3 else "",
                        ))
        
        elif self._is_windows:
            output = await self._run_command(["route", "print"])
            if output:
                in_ipv4 = False
                for line in output.strip().split('\n'):
                    if 'IPv4 Route Table' in line:
                        in_ipv4 = True
                        continue
                    if 'IPv6 Route Table' in line:
                        in_ipv4 = False
                        continue
                    
                    if in_ipv4 and re.match(r'\s*[0-9]+\.', line):
                        parts = line.split()
                        if len(parts) >= 4:
                            routes.append(RouteEntry(
                                destination=parts[0],
                                gateway=parts[2],
                                interface=parts[3] if len(parts) > 3 else "",
                                metric=int(parts[4]) if len(parts) > 4 else 0,
                            ))
        
        self.topology.routes = routes
        return routes
    
    async def discover_interfaces(self) -> List[NetworkInterface]:
        """
        Discover network interfaces.
        
        Returns:
            List of network interfaces
        """
        interfaces = []
        
        if self._is_linux:
            output = await self._run_command(["ip", "-d", "link", "show"])
            if output:
                current_iface = None
                
                for line in output.split('\n'):
                    # New interface
                    match = re.match(r'\d+:\s+(\S+)[@:]', line)
                    if match:
                        if current_iface:
                            interfaces.append(current_iface)
                        
                        name = match.group(1)
                        state = "up" if "UP" in line else "down"
                        mtu_match = re.search(r'mtu\s+(\d+)', line)
                        mtu = int(mtu_match.group(1)) if mtu_match else 1500
                        
                        current_iface = NetworkInterface(
                            name=name,
                            state=state,
                            mtu=mtu,
                        )
                    
                    # MAC address
                    if current_iface and 'link/ether' in line:
                        mac_match = re.search(r'link/ether\s+([0-9a-f:]+)', line)
                        if mac_match:
                            current_iface.mac_address = mac_match.group(1)
                
                if current_iface:
                    interfaces.append(current_iface)
            
            # Get IP addresses
            ip_output = await self._run_command(["ip", "addr", "show"])
            if ip_output:
                current_name = ""
                for line in ip_output.split('\n'):
                    match = re.match(r'\d+:\s+(\S+)[@:]', line)
                    if match:
                        current_name = match.group(1)
                    
                    if current_name and 'inet ' in line:
                        ip_match = re.search(r'inet\s+([0-9./]+)', line)
                        if ip_match:
                            for iface in interfaces:
                                if iface.name == current_name:
                                    iface.ip_addresses.append(ip_match.group(1))
        
        elif self._is_macos:
            output = await self._run_command(["ifconfig", "-a"])
            if output:
                current_iface = None
                
                for line in output.split('\n'):
                    # New interface
                    match = re.match(r'^(\w+):\s+flags=', line)
                    if match:
                        if current_iface:
                            interfaces.append(current_iface)
                        
                        name = match.group(1)
                        state = "up" if "UP" in line else "down"
                        mtu_match = re.search(r'mtu\s+(\d+)', line)
                        mtu = int(mtu_match.group(1)) if mtu_match else 1500
                        
                        current_iface = NetworkInterface(
                            name=name,
                            state=state,
                            mtu=mtu,
                        )
                    
                    if current_iface:
                        # MAC address
                        if 'ether' in line:
                            mac_match = re.search(r'ether\s+([0-9a-f:]+)', line)
                            if mac_match:
                                current_iface.mac_address = mac_match.group(1)
                        
                        # IP address
                        if 'inet ' in line:
                            ip_match = re.search(r'inet\s+([0-9.]+)', line)
                            if ip_match:
                                current_iface.ip_addresses.append(ip_match.group(1))
                
                if current_iface:
                    interfaces.append(current_iface)
        
        return interfaces
    
    async def discover_neighbors(self) -> List[NetworkNode]:
        """
        Discover network neighbors using various methods.
        
        Returns:
            List of discovered neighbor nodes
        """
        neighbors = []
        seen_macs: Set[str] = set()
        
        # Use ARP table
        arp_entries = await self.discover_arp_table()
        
        for entry in arp_entries:
            if entry.mac_address and entry.mac_address not in seen_macs:
                seen_macs.add(entry.mac_address)
                neighbors.append(NetworkNode(
                    node_id=entry.mac_address,
                    node_type="host",
                    ip_addresses=[entry.ip_address],
                    mac_addresses=[entry.mac_address],
                    metadata={
                        "discovery_method": "arp",
                        "interface": entry.interface,
                        "state": entry.state,
                    }
                ))
        
        return neighbors
    
    async def build_topology(self) -> NetworkTopology:
        """
        Build complete network topology.
        
        Returns:
            NetworkTopology
        """
        # Discover all components
        await self.discover_arp_table()
        await self.discover_vlans()
        await self.discover_routes()
        
        interfaces = await self.discover_interfaces()
        neighbors = await self.discover_neighbors()
        
        # Build local node
        hostname = socket.gethostname()
        local_ips = []
        local_macs = []
        
        for iface in interfaces:
            local_ips.extend(iface.ip_addresses)
            if iface.mac_address:
                local_macs.append(iface.mac_address)
        
        local_node = NetworkNode(
            node_id=hostname,
            node_type="host",
            hostname=hostname,
            ip_addresses=local_ips,
            mac_addresses=local_macs,
            interfaces=interfaces,
            metadata={"is_local": True},
        )
        
        self.topology.nodes = [local_node] + neighbors
        
        # Build edges from ARP table
        for entry in self.topology.arp_table:
            self.topology.edges.append(NetworkEdge(
                source_node=hostname,
                target_node=entry.mac_address,
                connection_type=ConnectionType.DIRECT,
                layer=TopologyLayerType.LAYER2,
                interface_source=entry.interface,
            ))
        
        # Build edges from routes (gateways)
        for route in self.topology.routes:
            if route.gateway and route.gateway != '0.0.0.0':
                self.topology.edges.append(NetworkEdge(
                    source_node=hostname,
                    target_node=route.gateway,
                    connection_type=ConnectionType.ROUTED,
                    layer=TopologyLayerType.LAYER3,
                    interface_source=route.interface,
                    metadata={
                        "destination": route.destination,
                        "metric": route.metric,
                    },
                ))
        
        return self.topology
    
    def get_topology_graph(self) -> Dict[str, Any]:
        """
        Get topology as graph structure for visualization.
        
        Returns:
            Dictionary with nodes and edges for graph visualization
        """
        nodes = []
        edges = []
        
        for node in self.topology.nodes:
            nodes.append({
                "id": node.node_id,
                "label": node.hostname or node.node_id,
                "type": node.type,
                "ips": node.ip_addresses,
                "macs": node.mac_addresses,
            })
        
        for edge in self.topology.edges:
            edges.append({
                "source": edge.source_node,
                "target": edge.target_node,
                "type": edge.connection_type.value,
                "layer": edge.layer.value,
            })
        
        return {
            "nodes": nodes,
            "edges": edges,
            "vlans": [{"id": v.vlan_id, "name": v.name} for v in self.topology.vlans],
        }

