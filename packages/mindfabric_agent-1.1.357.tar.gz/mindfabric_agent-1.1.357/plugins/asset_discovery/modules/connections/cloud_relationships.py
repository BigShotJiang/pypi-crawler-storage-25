"""
Cloud Relationships Discovery Module

Discovers relationships between cloud resources:
- AWS: VPC peering, Transit Gateway, PrivateLink, Direct Connect
- Azure: VNet peering, Virtual WAN, ExpressRoute, Private Endpoints
- GCP: VPC peering, Shared VPC, Cloud Interconnect, Private Service Connect
- Multi-cloud: Cross-cloud VPN, hybrid connections

This module helps understand how cloud resources are interconnected.
"""

import os
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


class CloudProvider(str, Enum):
    """Cloud provider types."""
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    MULTICLOUD = "multicloud"


class CloudConnectionType(str, Enum):
    """Types of cloud connections."""
    VPC_PEERING = "vpc_peering"
    TRANSIT_GATEWAY = "transit_gateway"
    PRIVATE_LINK = "private_link"
    VPN = "vpn"
    DIRECT_CONNECT = "direct_connect"
    SHARED_VPC = "shared_vpc"
    SERVICE_ENDPOINT = "service_endpoint"
    LOAD_BALANCER = "load_balancer"


@dataclass
class CloudVPC:
    """Cloud VPC/VNet information."""
    vpc_id: str
    name: str
    provider: CloudProvider
    cidr_blocks: List[str] = field(default_factory=list)
    region: str = ""
    account_id: str = ""
    subnets: List[Dict[str, Any]] = field(default_factory=list)
    route_tables: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class CloudPeeringConnection:
    """VPC/VNet peering connection."""
    connection_id: str
    provider: CloudProvider
    source_vpc: str
    target_vpc: str
    source_account: str = ""
    target_account: str = ""
    status: str = ""
    cross_region: bool = False
    cross_account: bool = False


@dataclass
class CloudTransitConnection:
    """Transit Gateway/Virtual WAN connection."""
    transit_id: str
    provider: CloudProvider
    name: str = ""
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    route_tables: List[Dict[str, Any]] = field(default_factory=list)
    regions: List[str] = field(default_factory=list)


@dataclass
class CloudPrivateEndpoint:
    """Private Link/Service Connect endpoint."""
    endpoint_id: str
    provider: CloudProvider
    service_name: str
    vpc_id: str
    subnet_id: str = ""
    ip_address: str = ""
    status: str = ""


@dataclass
class CloudVPNConnection:
    """VPN connection."""
    connection_id: str
    provider: CloudProvider
    type: str  # site-to-site, client
    local_gateway: str = ""
    remote_gateway: str = ""
    remote_cidr: List[str] = field(default_factory=list)
    status: str = ""
    tunnels: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class CloudRelationshipsReport:
    """Cloud relationships discovery report."""
    vpcs: List[CloudVPC] = field(default_factory=list)
    peering_connections: List[CloudPeeringConnection] = field(default_factory=list)
    transit_connections: List[CloudTransitConnection] = field(default_factory=list)
    private_endpoints: List[CloudPrivateEndpoint] = field(default_factory=list)
    vpn_connections: List[CloudVPNConnection] = field(default_factory=list)
    cross_cloud_connections: List[Dict[str, Any]] = field(default_factory=list)


class CloudRelationshipsDiscovery:
    """Service for discovering cloud resource relationships."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self._aws_client = None
        self._azure_client = None
        self._gcp_client = None
    
    def set_aws_client(self, client):
        """Set AWS boto3 client."""
        self._aws_client = client
    
    def set_azure_client(self, client):
        """Set Azure client."""
        self._azure_client = client
    
    def set_gcp_client(self, client):
        """Set GCP client."""
        self._gcp_client = client
    
    async def discover_aws_vpcs(self, ec2_client=None) -> List[CloudVPC]:
        """
        Discover AWS VPCs.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of CloudVPC objects
        """
        vpcs = []
        client = ec2_client or self._aws_client
        
        if not client:
            return vpcs
        
        try:
            response = client.describe_vpcs()
            
            for vpc in response.get("Vpcs", []):
                vpc_id = vpc.get("VpcId", "")
                
                # Get VPC name from tags
                name = ""
                for tag in vpc.get("Tags", []):
                    if tag.get("Key") == "Name":
                        name = tag.get("Value", "")
                        break
                
                # Get subnets
                subnets_response = client.describe_subnets(
                    Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
                )
                
                subnets = []
                for subnet in subnets_response.get("Subnets", []):
                    subnet_name = ""
                    for tag in subnet.get("Tags", []):
                        if tag.get("Key") == "Name":
                            subnet_name = tag.get("Value", "")
                            break
                    
                    subnets.append({
                        "subnet_id": subnet.get("SubnetId", ""),
                        "name": subnet_name,
                        "cidr": subnet.get("CidrBlock", ""),
                        "az": subnet.get("AvailabilityZone", ""),
                        "public": subnet.get("MapPublicIpOnLaunch", False),
                    })
                
                # Get route tables
                rt_response = client.describe_route_tables(
                    Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
                )
                
                route_tables = []
                for rt in rt_response.get("RouteTables", []):
                    routes = []
                    for route in rt.get("Routes", []):
                        routes.append({
                            "destination": route.get("DestinationCidrBlock", route.get("DestinationPrefixListId", "")),
                            "target": route.get("GatewayId", route.get("NatGatewayId", route.get("TransitGatewayId", route.get("VpcPeeringConnectionId", "local")))),
                            "state": route.get("State", ""),
                        })
                    
                    route_tables.append({
                        "rt_id": rt.get("RouteTableId", ""),
                        "routes": routes,
                    })
                
                vpcs.append(CloudVPC(
                    vpc_id=vpc_id,
                    name=name,
                    provider=CloudProvider.AWS,
                    cidr_blocks=[vpc.get("CidrBlock", "")],
                    account_id=vpc.get("OwnerId", ""),
                    subnets=subnets,
                    route_tables=route_tables,
                ))
                
        except Exception as e:
            logger.error(f"Error discovering AWS VPCs: {e}")
        
        return vpcs
    
    async def discover_aws_peering(self, ec2_client=None) -> List[CloudPeeringConnection]:
        """
        Discover AWS VPC peering connections.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of CloudPeeringConnection objects
        """
        connections = []
        client = ec2_client or self._aws_client
        
        if not client:
            return connections
        
        try:
            response = client.describe_vpc_peering_connections()
            
            for peering in response.get("VpcPeeringConnections", []):
                requester = peering.get("RequesterVpcInfo", {})
                accepter = peering.get("AccepterVpcInfo", {})
                
                connections.append(CloudPeeringConnection(
                    connection_id=peering.get("VpcPeeringConnectionId", ""),
                    provider=CloudProvider.AWS,
                    source_vpc=requester.get("VpcId", ""),
                    target_vpc=accepter.get("VpcId", ""),
                    source_account=requester.get("OwnerId", ""),
                    target_account=accepter.get("OwnerId", ""),
                    status=peering.get("Status", {}).get("Code", ""),
                    cross_region=requester.get("Region") != accepter.get("Region"),
                    cross_account=requester.get("OwnerId") != accepter.get("OwnerId"),
                ))
                
        except Exception as e:
            logger.error(f"Error discovering AWS VPC peering: {e}")
        
        return connections
    
    async def discover_aws_transit_gateways(self, ec2_client=None) -> List[CloudTransitConnection]:
        """
        Discover AWS Transit Gateways.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of CloudTransitConnection objects
        """
        transit_connections = []
        client = ec2_client or self._aws_client
        
        if not client:
            return transit_connections
        
        try:
            response = client.describe_transit_gateways()
            
            for tgw in response.get("TransitGateways", []):
                tgw_id = tgw.get("TransitGatewayId", "")
                
                # Get name from tags
                name = ""
                for tag in tgw.get("Tags", []):
                    if tag.get("Key") == "Name":
                        name = tag.get("Value", "")
                        break
                
                # Get attachments
                attach_response = client.describe_transit_gateway_attachments(
                    Filters=[{"Name": "transit-gateway-id", "Values": [tgw_id]}]
                )
                
                attachments = []
                for attach in attach_response.get("TransitGatewayAttachments", []):
                    attachments.append({
                        "attachment_id": attach.get("TransitGatewayAttachmentId", ""),
                        "resource_type": attach.get("ResourceType", ""),
                        "resource_id": attach.get("ResourceId", ""),
                        "state": attach.get("State", ""),
                    })
                
                transit_connections.append(CloudTransitConnection(
                    transit_id=tgw_id,
                    provider=CloudProvider.AWS,
                    name=name,
                    attachments=attachments,
                ))
                
        except Exception as e:
            logger.error(f"Error discovering AWS Transit Gateways: {e}")
        
        return transit_connections
    
    async def discover_aws_vpc_endpoints(self, ec2_client=None) -> List[CloudPrivateEndpoint]:
        """
        Discover AWS VPC Endpoints (PrivateLink).
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of CloudPrivateEndpoint objects
        """
        endpoints = []
        client = ec2_client or self._aws_client
        
        if not client:
            return endpoints
        
        try:
            response = client.describe_vpc_endpoints()
            
            for endpoint in response.get("VpcEndpoints", []):
                subnet_ids = endpoint.get("SubnetIds", [])
                
                # Get IP from network interfaces
                ip_address = ""
                for eni in endpoint.get("NetworkInterfaceIds", []):
                    try:
                        eni_response = client.describe_network_interfaces(
                            NetworkInterfaceIds=[eni]
                        )
                        for ni in eni_response.get("NetworkInterfaces", []):
                            ip_address = ni.get("PrivateIpAddress", "")
                            break
                    except Exception:
                        pass
                    break
                
                endpoints.append(CloudPrivateEndpoint(
                    endpoint_id=endpoint.get("VpcEndpointId", ""),
                    provider=CloudProvider.AWS,
                    service_name=endpoint.get("ServiceName", ""),
                    vpc_id=endpoint.get("VpcId", ""),
                    subnet_id=subnet_ids[0] if subnet_ids else "",
                    ip_address=ip_address,
                    status=endpoint.get("State", ""),
                ))
                
        except Exception as e:
            logger.error(f"Error discovering AWS VPC Endpoints: {e}")
        
        return endpoints
    
    async def discover_aws_vpn_connections(self, ec2_client=None) -> List[CloudVPNConnection]:
        """
        Discover AWS VPN connections.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of CloudVPNConnection objects
        """
        vpn_connections = []
        client = ec2_client or self._aws_client
        
        if not client:
            return vpn_connections
        
        try:
            response = client.describe_vpn_connections()
            
            for vpn in response.get("VpnConnections", []):
                tunnels = []
                for tunnel in vpn.get("VgwTelemetry", []):
                    tunnels.append({
                        "outside_ip": tunnel.get("OutsideIpAddress", ""),
                        "status": tunnel.get("Status", ""),
                        "status_message": tunnel.get("StatusMessage", ""),
                    })
                
                vpn_connections.append(CloudVPNConnection(
                    connection_id=vpn.get("VpnConnectionId", ""),
                    provider=CloudProvider.AWS,
                    type="site-to-site",
                    local_gateway=vpn.get("VpnGatewayId", vpn.get("TransitGatewayId", "")),
                    remote_gateway=vpn.get("CustomerGatewayId", ""),
                    status=vpn.get("State", ""),
                    tunnels=tunnels,
                ))
                
        except Exception as e:
            logger.error(f"Error discovering AWS VPN connections: {e}")
        
        return vpn_connections
    
    async def discover_azure_vnets(self, network_client=None) -> List[CloudVPC]:
        """
        Discover Azure VNets.
        
        Args:
            network_client: Azure NetworkManagementClient
            
        Returns:
            List of CloudVPC objects
        """
        vnets = []
        client = network_client or self._azure_client
        
        if not client:
            return vnets
        
        try:
            for vnet in client.virtual_networks.list_all():
                subnets = []
                for subnet in vnet.subnets or []:
                    subnets.append({
                        "subnet_id": subnet.id,
                        "name": subnet.name,
                        "cidr": subnet.address_prefix,
                    })
                
                cidr_blocks = []
                if vnet.address_space:
                    cidr_blocks = vnet.address_space.address_prefixes or []
                
                vnets.append(CloudVPC(
                    vpc_id=vnet.id,
                    name=vnet.name,
                    provider=CloudProvider.AZURE,
                    cidr_blocks=cidr_blocks,
                    region=vnet.location,
                    subnets=subnets,
                ))
                
        except Exception as e:
            logger.error(f"Error discovering Azure VNets: {e}")
        
        return vnets
    
    async def discover_azure_peering(self, network_client=None) -> List[CloudPeeringConnection]:
        """
        Discover Azure VNet peering connections.
        
        Args:
            network_client: Azure NetworkManagementClient
            
        Returns:
            List of CloudPeeringConnection objects
        """
        connections = []
        client = network_client or self._azure_client
        
        if not client:
            return connections
        
        try:
            for vnet in client.virtual_networks.list_all():
                for peering in vnet.virtual_network_peerings or []:
                    connections.append(CloudPeeringConnection(
                        connection_id=peering.id,
                        provider=CloudProvider.AZURE,
                        source_vpc=vnet.id,
                        target_vpc=peering.remote_virtual_network.id if peering.remote_virtual_network else "",
                        status=peering.peering_state,
                    ))
                    
        except Exception as e:
            logger.error(f"Error discovering Azure VNet peering: {e}")
        
        return connections
    
    async def run_full_discovery(
        self,
        aws_client=None,
        azure_client=None,
        gcp_client=None,
    ) -> CloudRelationshipsReport:
        """
        Run full cloud relationships discovery.
        
        Args:
            aws_client: boto3 EC2 client
            azure_client: Azure NetworkManagementClient
            gcp_client: GCP compute client
            
        Returns:
            CloudRelationshipsReport
        """
        all_vpcs = []
        all_peering = []
        all_transit = []
        all_endpoints = []
        all_vpn = []
        
        # AWS Discovery
        if aws_client:
            aws_vpcs = await self.discover_aws_vpcs(aws_client)
            all_vpcs.extend(aws_vpcs)
            
            aws_peering = await self.discover_aws_peering(aws_client)
            all_peering.extend(aws_peering)
            
            aws_transit = await self.discover_aws_transit_gateways(aws_client)
            all_transit.extend(aws_transit)
            
            aws_endpoints = await self.discover_aws_vpc_endpoints(aws_client)
            all_endpoints.extend(aws_endpoints)
            
            aws_vpn = await self.discover_aws_vpn_connections(aws_client)
            all_vpn.extend(aws_vpn)
        
        # Azure Discovery
        if azure_client:
            azure_vnets = await self.discover_azure_vnets(azure_client)
            all_vpcs.extend(azure_vnets)
            
            azure_peering = await self.discover_azure_peering(azure_client)
            all_peering.extend(azure_peering)
        
        # Build cross-cloud connections
        cross_cloud = self._detect_cross_cloud_connections(all_vpcs, all_vpn)
        
        return CloudRelationshipsReport(
            vpcs=all_vpcs,
            peering_connections=all_peering,
            transit_connections=all_transit,
            private_endpoints=all_endpoints,
            vpn_connections=all_vpn,
            cross_cloud_connections=cross_cloud,
        )
    
    def _detect_cross_cloud_connections(
        self,
        vpcs: List[CloudVPC],
        vpn_connections: List[CloudVPNConnection],
    ) -> List[Dict[str, Any]]:
        """Detect potential cross-cloud connections based on CIDR overlaps and VPN configs."""
        cross_cloud = []
        
        # Group VPCs by provider
        vpcs_by_provider = {}
        for vpc in vpcs:
            if vpc.provider not in vpcs_by_provider:
                vpcs_by_provider[vpc.provider] = []
            vpcs_by_provider[vpc.provider].append(vpc)
        
        # Check for CIDR patterns that suggest interconnection
        # This is a heuristic approach
        for vpn in vpn_connections:
            for remote_cidr in vpn.remote_cidr:
                # Check if remote CIDR matches any VPC from another provider
                for provider, provider_vpcs in vpcs_by_provider.items():
                    if provider != vpn.provider:
                        for vpc in provider_vpcs:
                            for cidr in vpc.cidr_blocks:
                                if remote_cidr == cidr or self._cidrs_overlap(remote_cidr, cidr):
                                    cross_cloud.append({
                                        "source_provider": vpn.provider.value,
                                        "target_provider": provider.value,
                                        "connection_type": "vpn",
                                        "source_vpc": vpn.connection_id,
                                        "target_vpc": vpc.vpc_id,
                                    })
        
        return cross_cloud
    
    async def discover_gcp_vpcs(self, compute_client=None) -> List[CloudVPC]:
        """
        Discover GCP VPC networks.
        
        Args:
            compute_client: GCP compute client
            
        Returns:
            List of CloudVPC objects
        """
        vpcs = []
        client = compute_client or self._gcp_client
        
        if not client:
            return vpcs
        
        try:
            # List all networks
            networks = client.networks().list(project=client.project).execute()
            
            for network in networks.get("items", []):
                network_name = network.get("name", "")
                network_id = network.get("selfLink", "")
                
                # Get subnets
                subnets = []
                for subnet_link in network.get("subnetworks", []):
                    # Parse subnet info from the link
                    # Format: https://www.googleapis.com/compute/v1/projects/{project}/regions/{region}/subnetworks/{name}
                    parts = subnet_link.split("/")
                    if len(parts) >= 4:
                        region = parts[-3]
                        subnet_name = parts[-1]
                        
                        try:
                            subnet_data = client.subnetworks().get(
                                project=client.project,
                                region=region,
                                subnetwork=subnet_name
                            ).execute()
                            
                            subnets.append({
                                "subnet_id": subnet_data.get("selfLink", ""),
                                "name": subnet_name,
                                "cidr": subnet_data.get("ipCidrRange", ""),
                                "region": region,
                                "private_google_access": subnet_data.get("privateIpGoogleAccess", False),
                            })
                        except Exception:
                            pass
                
                # Get CIDR blocks from subnets
                cidr_blocks = [s["cidr"] for s in subnets if s.get("cidr")]
                
                vpcs.append(CloudVPC(
                    vpc_id=network_id,
                    name=network_name,
                    provider=CloudProvider.GCP,
                    cidr_blocks=cidr_blocks,
                    subnets=subnets,
                ))
                
        except Exception as e:
            logger.error(f"Error discovering GCP VPCs: {e}")
        
        return vpcs
    
    async def discover_gcp_peering(self, compute_client=None) -> List[CloudPeeringConnection]:
        """
        Discover GCP VPC peering connections.
        
        Args:
            compute_client: GCP compute client
            
        Returns:
            List of CloudPeeringConnection objects
        """
        connections = []
        client = compute_client or self._gcp_client
        
        if not client:
            return connections
        
        try:
            networks = client.networks().list(project=client.project).execute()
            
            for network in networks.get("items", []):
                network_name = network.get("name", "")
                network_id = network.get("selfLink", "")
                
                for peering in network.get("peerings", []):
                    connections.append(CloudPeeringConnection(
                        connection_id=f"{network_name}-{peering.get('name', '')}",
                        provider=CloudProvider.GCP,
                        source_vpc=network_id,
                        target_vpc=peering.get("network", ""),
                        status=peering.get("state", ""),
                        cross_account=True,  # GCP peering is always cross-project capable
                    ))
                    
        except Exception as e:
            logger.error(f"Error discovering GCP VPC peering: {e}")
        
        return connections
    
    async def discover_gcp_interconnects(self, compute_client=None) -> List[Dict[str, Any]]:
        """
        Discover GCP Cloud Interconnect and VPN connections.
        
        Args:
            compute_client: GCP compute client
            
        Returns:
            List of interconnect dictionaries
        """
        interconnects = []
        client = compute_client or self._gcp_client
        
        if not client:
            return interconnects
        
        try:
            # Cloud Interconnect attachments
            attachments = client.interconnectAttachments().aggregatedList(
                project=client.project
            ).execute()
            
            for region, data in attachments.get("items", {}).items():
                for attachment in data.get("interconnectAttachments", []):
                    interconnects.append({
                        "type": "interconnect",
                        "id": attachment.get("selfLink", ""),
                        "name": attachment.get("name", ""),
                        "region": region.split("/")[-1] if "/" in region else region,
                        "bandwidth": attachment.get("bandwidth", ""),
                        "state": attachment.get("state", ""),
                        "router": attachment.get("router", ""),
                        "vlan_tag": attachment.get("vlanTag8021q"),
                    })
                    
        except Exception as e:
            logger.debug(f"Error discovering GCP interconnects: {e}")
        
        try:
            # VPN tunnels
            tunnels = client.vpnTunnels().aggregatedList(
                project=client.project
            ).execute()
            
            for region, data in tunnels.get("items", {}).items():
                for tunnel in data.get("vpnTunnels", []):
                    interconnects.append({
                        "type": "vpn_tunnel",
                        "id": tunnel.get("selfLink", ""),
                        "name": tunnel.get("name", ""),
                        "region": region.split("/")[-1] if "/" in region else region,
                        "peer_ip": tunnel.get("peerIp", ""),
                        "status": tunnel.get("status", ""),
                        "vpn_gateway": tunnel.get("vpnGateway", ""),
                        "remote_traffic_selector": tunnel.get("remoteTrafficSelector", []),
                        "local_traffic_selector": tunnel.get("localTrafficSelector", []),
                    })
                    
        except Exception as e:
            logger.debug(f"Error discovering GCP VPN tunnels: {e}")
        
        return interconnects
    
    async def discover_gcp_private_service_connect(self, compute_client=None) -> List[CloudPrivateEndpoint]:
        """
        Discover GCP Private Service Connect endpoints.
        
        Args:
            compute_client: GCP compute client
            
        Returns:
            List of CloudPrivateEndpoint objects
        """
        endpoints = []
        client = compute_client or self._gcp_client
        
        if not client:
            return endpoints
        
        try:
            # Service attachments (PSC producer side)
            attachments = client.serviceAttachments().aggregatedList(
                project=client.project
            ).execute()
            
            for region, data in attachments.get("items", {}).items():
                for attachment in data.get("serviceAttachments", []):
                    endpoints.append(CloudPrivateEndpoint(
                        endpoint_id=attachment.get("selfLink", ""),
                        provider=CloudProvider.GCP,
                        service_name=attachment.get("targetService", ""),
                        vpc_id=attachment.get("network", ""),
                        status=attachment.get("connectionPreference", ""),
                    ))
                    
        except Exception as e:
            logger.debug(f"Error discovering GCP PSC: {e}")
        
        try:
            # Forwarding rules for PSC consumers
            rules = client.forwardingRules().aggregatedList(
                project=client.project
            ).execute()
            
            for region, data in rules.get("items", {}).items():
                for rule in data.get("forwardingRules", []):
                    # Check if it's a PSC endpoint
                    if rule.get("pscConnectionId"):
                        endpoints.append(CloudPrivateEndpoint(
                            endpoint_id=rule.get("selfLink", ""),
                            provider=CloudProvider.GCP,
                            service_name=rule.get("target", ""),
                            vpc_id=rule.get("network", ""),
                            subnet_id=rule.get("subnetwork", ""),
                            ip_address=rule.get("IPAddress", ""),
                            status=rule.get("pscConnectionStatus", ""),
                        ))
                        
        except Exception as e:
            logger.debug(f"Error discovering GCP PSC forwarding rules: {e}")
        
        return endpoints
    
    async def discover_gcp_shared_vpc(self, compute_client=None) -> List[Dict[str, Any]]:
        """
        Discover GCP Shared VPC relationships.
        
        Args:
            compute_client: GCP compute client
            
        Returns:
            List of shared VPC relationship dictionaries
        """
        shared_vpcs = []
        client = compute_client or self._gcp_client
        
        if not client:
            return shared_vpcs
        
        try:
            # Check if this project is a host project
            project_info = client.projects().get(project=client.project).execute()
            
            xpn_host = project_info.get("xpnProjectStatus", {})
            
            if xpn_host.get("xpnProjectStatus") == "HOST":
                # List service projects
                service_projects = client.projects().getXpnResources(
                    project=client.project
                ).execute()
                
                for resource in service_projects.get("resources", []):
                    shared_vpcs.append({
                        "type": "shared_vpc_host",
                        "host_project": client.project,
                        "service_project": resource.get("id", ""),
                        "resource_type": resource.get("type", ""),
                    })
            
            # Check if this project is a service project
            if xpn_host.get("hostProjectId"):
                shared_vpcs.append({
                    "type": "shared_vpc_service",
                    "host_project": xpn_host.get("hostProjectId"),
                    "service_project": client.project,
                })
                
        except Exception as e:
            logger.debug(f"Error discovering GCP Shared VPC: {e}")
        
        return shared_vpcs
    
    def _cidrs_overlap(self, cidr1: str, cidr2: str) -> bool:
        """Check if two CIDRs overlap (simplified check)."""
        try:
            import ipaddress
            net1 = ipaddress.ip_network(cidr1, strict=False)
            net2 = ipaddress.ip_network(cidr2, strict=False)
            return net1.overlaps(net2)
        except Exception:
            return False

