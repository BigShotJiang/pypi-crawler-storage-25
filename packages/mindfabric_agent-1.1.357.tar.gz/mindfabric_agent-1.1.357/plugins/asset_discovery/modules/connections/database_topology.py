"""
Database Topology Discovery Module

Discovers database relationships and topology:
- Replication links: Master-slave, primary-replica, multi-master clusters
- Federation/Sharding: Database federation, shard distribution, linked servers
- Connection pools: Application connection pools, proxy connections

This module helps understand how databases are interconnected.
"""

import os
import re
import json
import logging
import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)

from ..utils.async_subprocess import run_shell


class DatabaseType(str, Enum):
    """Database types."""
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    MARIADB = "mariadb"
    MSSQL = "mssql"
    ORACLE = "oracle"
    MONGODB = "mongodb"
    REDIS = "redis"
    CASSANDRA = "cassandra"
    ELASTICSEARCH = "elasticsearch"
    COCKROACHDB = "cockroachdb"
    TIDB = "tidb"
    VITESS = "vitess"


class ReplicationType(str, Enum):
    """Types of replication."""
    MASTER_SLAVE = "master_slave"
    PRIMARY_REPLICA = "primary_replica"
    MULTI_MASTER = "multi_master"
    SYNCHRONOUS = "synchronous"
    ASYNCHRONOUS = "asynchronous"
    STREAMING = "streaming"
    LOGICAL = "logical"
    PHYSICAL = "physical"


class ConnectionPoolType(str, Enum):
    """Types of connection pools."""
    PGBOUNCER = "pgbouncer"
    PROXYSQL = "proxysql"
    HAPROXY = "haproxy"
    ODYSSEY = "odyssey"
    PGCAT = "pgcat"
    MYSQL_ROUTER = "mysql_router"
    APPLICATION = "application"


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class DatabaseNode:
    """Database node information."""
    host: str
    port: int
    db_type: DatabaseType
    role: str  # master, slave, primary, replica, arbiter
    name: str = ""
    version: str = ""
    cluster_name: str = ""
    region: str = ""
    zone: str = ""
    is_writable: bool = False
    lag_seconds: float = 0.0
    state: str = ""  # running, syncing, recovery
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "host": self.host,
            "port": self.port,
            "db_type": self.db_type.value,
            "role": self.role,
            "name": self.name,
            "version": self.version,
            "cluster_name": self.cluster_name,
            "region": self.region,
            "zone": self.zone,
            "is_writable": self.is_writable,
            "lag_seconds": self.lag_seconds,
            "state": self.state,
        }


@dataclass
class ReplicationLink:
    """Database replication link."""
    link_id: str
    source: DatabaseNode
    target: DatabaseNode
    replication_type: ReplicationType
    lag_bytes: int = 0
    lag_seconds: float = 0.0
    is_synchronous: bool = False
    slot_name: str = ""
    channel_name: str = ""
    status: str = ""  # streaming, catchup, offline
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "link_id": self.link_id,
            "source": self.source.to_dict(),
            "target": self.target.to_dict(),
            "replication_type": self.replication_type.value,
            "lag_bytes": self.lag_bytes,
            "lag_seconds": self.lag_seconds,
            "is_synchronous": self.is_synchronous,
            "slot_name": self.slot_name,
            "channel_name": self.channel_name,
            "status": self.status,
        }


@dataclass
class DatabaseShard:
    """Database shard information."""
    shard_id: str
    shard_name: str
    nodes: List[DatabaseNode] = field(default_factory=list)
    key_range: Tuple[str, str] = ("", "")
    tables: List[str] = field(default_factory=list)
    size_bytes: int = 0
    row_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "shard_id": self.shard_id,
            "shard_name": self.shard_name,
            "nodes": [n.to_dict() for n in self.nodes],
            "key_range": self.key_range,
            "tables": self.tables,
            "size_bytes": self.size_bytes,
            "row_count": self.row_count,
        }


@dataclass
class FederationLink:
    """Database federation/linked server."""
    link_id: str
    local_db: str
    remote_server: str
    remote_db: str
    link_type: str  # linked_server, foreign_data_wrapper, dblink
    provider: str = ""
    is_writable: bool = False
    authentication: str = ""  # sql_auth, integrated, mapped
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "link_id": self.link_id,
            "local_db": self.local_db,
            "remote_server": self.remote_server,
            "remote_db": self.remote_db,
            "link_type": self.link_type,
            "provider": self.provider,
            "is_writable": self.is_writable,
            "authentication": self.authentication,
        }


@dataclass
class ConnectionPool:
    """Connection pool information."""
    pool_id: str
    pool_type: ConnectionPoolType
    host: str
    port: int
    backend_servers: List[Dict[str, Any]] = field(default_factory=list)
    max_connections: int = 0
    current_connections: int = 0
    wait_queue: int = 0
    pool_mode: str = ""  # transaction, session, statement
    databases: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "pool_id": self.pool_id,
            "pool_type": self.pool_type.value,
            "host": self.host,
            "port": self.port,
            "backend_servers": self.backend_servers,
            "max_connections": self.max_connections,
            "current_connections": self.current_connections,
            "wait_queue": self.wait_queue,
            "pool_mode": self.pool_mode,
            "databases": self.databases,
        }


@dataclass
class DatabaseCluster:
    """Database cluster information."""
    cluster_id: str
    cluster_name: str
    db_type: DatabaseType
    nodes: List[DatabaseNode] = field(default_factory=list)
    replication_links: List[ReplicationLink] = field(default_factory=list)
    shards: List[DatabaseShard] = field(default_factory=list)
    connection_pools: List[ConnectionPool] = field(default_factory=list)
    federation_links: List[FederationLink] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "cluster_id": self.cluster_id,
            "cluster_name": self.cluster_name,
            "db_type": self.db_type.value,
            "nodes": [n.to_dict() for n in self.nodes],
            "replication_links": [r.to_dict() for r in self.replication_links],
            "shards": [s.to_dict() for s in self.shards],
            "connection_pools": [p.to_dict() for p in self.connection_pools],
            "federation_links": [f.to_dict() for f in self.federation_links],
        }


# =============================================================================
# Discovery Commands
# =============================================================================

POSTGRESQL_COMMANDS = {
    "replication_status": """
        SELECT 
            client_addr,
            client_port,
            state,
            sent_lsn,
            write_lsn,
            flush_lsn,
            replay_lsn,
            sync_state,
            slot_name,
            EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp())) as lag_seconds
        FROM pg_stat_replication
    """,
    "replication_slots": """
        SELECT 
            slot_name,
            plugin,
            slot_type,
            database,
            active,
            restart_lsn,
            confirmed_flush_lsn
        FROM pg_replication_slots
    """,
    "foreign_servers": """
        SELECT 
            srvname as server_name,
            srvowner::regrole as owner,
            fdwname as wrapper_name,
            srvoptions as options
        FROM pg_foreign_server fs
        JOIN pg_foreign_data_wrapper fdw ON fs.srvfdw = fdw.oid
    """,
    "dblink_connections": """
        SELECT 
            unnest(dblink_get_connections()) as connection_name
    """,
    "subscription_status": """
        SELECT 
            subname,
            subconninfo,
            subenabled,
            subslotname,
            subpublications
        FROM pg_subscription
    """,
    "publication_status": """
        SELECT 
            pubname,
            puballtables,
            pubinsert,
            pubupdate,
            pubdelete
        FROM pg_publication
    """,
}

MYSQL_COMMANDS = {
    "replication_status": """
        SHOW SLAVE STATUS
    """,
    "replica_status": """
        SHOW REPLICA STATUS
    """,
    "master_status": """
        SHOW MASTER STATUS
    """,
    "binlog_status": """
        SHOW BINARY LOGS
    """,
    "group_replication": """
        SELECT 
            MEMBER_HOST,
            MEMBER_PORT,
            MEMBER_STATE,
            MEMBER_ROLE
        FROM performance_schema.replication_group_members
    """,
    "ndb_cluster": """
        SHOW STATUS LIKE 'Ndb%'
    """,
}

MSSQL_COMMANDS = {
    "replication_status": """
        SELECT 
            DB_NAME(database_id) as database_name,
            synchronization_state_desc,
            synchronization_health_desc,
            is_primary_replica,
            is_local
        FROM sys.dm_hadr_database_replica_states
    """,
    "linked_servers": """
        SELECT 
            name as server_name,
            data_source,
            provider,
            catalog,
            is_data_access_enabled,
            is_rpc_out_enabled
        FROM sys.servers
        WHERE is_linked = 1
    """,
    "availability_groups": """
        SELECT 
            ag.name as ag_name,
            ar.replica_server_name,
            ar.availability_mode_desc,
            ar.failover_mode_desc,
            ars.role_desc,
            ars.synchronization_health_desc
        FROM sys.availability_groups ag
        JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
        JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id
    """,
    "mirroring_status": """
        SELECT 
            DB_NAME(database_id) as database_name,
            mirroring_state_desc,
            mirroring_role_desc,
            mirroring_partner_name,
            mirroring_partner_instance
        FROM sys.database_mirroring
        WHERE mirroring_guid IS NOT NULL
    """,
}

MONGODB_COMMANDS = {
    "replica_set_status": "rs.status()",
    "replica_set_config": "rs.conf()",
    "shard_status": "sh.status()",
    "shard_distribution": "db.printShardingStatus()",
    "connection_status": "db.serverStatus().connections",
    "cluster_members": "db.adminCommand({listShards: 1})",
}

REDIS_COMMANDS = {
    "replication_info": "INFO replication",
    "cluster_info": "CLUSTER INFO",
    "cluster_nodes": "CLUSTER NODES",
    "cluster_slots": "CLUSTER SLOTS",
    "sentinel_masters": "SENTINEL masters",
}

CASSANDRA_COMMANDS = {
    "ring_status": "nodetool ring",
    "status": "nodetool status",
    "describecluster": "nodetool describecluster",
    "gossipinfo": "nodetool gossipinfo",
}


# =============================================================================
# Proxy Detection Patterns
# =============================================================================

PROXY_PATTERNS = {
    ConnectionPoolType.PGBOUNCER: {
        "process": ["pgbouncer"],
        "ports": [6432],
        "config_files": ["/etc/pgbouncer/pgbouncer.ini", "/etc/pgbouncer.ini"],
        "stats_command": "SHOW POOLS; SHOW STATS; SHOW SERVERS;",
    },
    ConnectionPoolType.PROXYSQL: {
        "process": ["proxysql"],
        "ports": [6033, 6032],
        "config_files": ["/etc/proxysql.cnf", "/var/lib/proxysql/proxysql.db"],
        "stats_command": "SELECT * FROM stats_mysql_connection_pool;",
    },
    ConnectionPoolType.HAPROXY: {
        "process": ["haproxy"],
        "ports": [3307, 3308],
        "config_files": ["/etc/haproxy/haproxy.cfg"],
        "stats_url": "/stats",
    },
    ConnectionPoolType.ODYSSEY: {
        "process": ["odyssey"],
        "ports": [6432],
        "config_files": ["/etc/odyssey/odyssey.conf"],
    },
    ConnectionPoolType.PGCAT: {
        "process": ["pgcat"],
        "ports": [6432],
        "config_files": ["/etc/pgcat/pgcat.toml"],
    },
    ConnectionPoolType.MYSQL_ROUTER: {
        "process": ["mysqlrouter"],
        "ports": [6446, 6447],
        "config_files": ["/etc/mysqlrouter/mysqlrouter.conf"],
    },
}


# =============================================================================
# Main Service Class
# =============================================================================

class DatabaseTopologyDiscovery:
    """Service for discovering database topology and relationships."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.clusters: List[DatabaseCluster] = []
        self.replication_links: List[ReplicationLink] = []
        self.shards: List[DatabaseShard] = []
        self.federation_links: List[FederationLink] = []
        self.connection_pools: List[ConnectionPool] = []
        self._link_counter = 0
    
    def _generate_link_id(self, prefix: str = "link") -> str:
        """Generate unique link ID."""
        self._link_counter += 1
        return f"{prefix}_{self._link_counter}"
    
    async def _run_command(self, cmd: str) -> Tuple[str, str, int]:
        """Run shell command and return output (async, non-blocking)."""
        try:
            rc, out, err = await run_shell(cmd, timeout=30, allow_unsafe_shell=True)
            return out, err, rc
        except FileNotFoundError:
            return "", "Command not found", 1
        except asyncio.TimeoutError:
            return "", "Command timed out", 1
        except Exception as e:
            return "", str(e), 1
    
    # =========================================================================
    # PostgreSQL Discovery
    # =========================================================================
    
    async def discover_postgresql_replication(
        self,
        host: str,
        port: int = 5432,
        connection_string: str = None,
    ) -> List[ReplicationLink]:
        """Discover PostgreSQL replication topology."""
        links = []
        
        # Check if this is a primary (has replicas)
        primary_node = DatabaseNode(
            host=host,
            port=port,
            db_type=DatabaseType.POSTGRESQL,
            role="primary",
            is_writable=True,
        )
        
        # Query replication status
        query = POSTGRESQL_COMMANDS["replication_status"]
        # In real implementation, execute query via psycopg2
        logger.info(f"Discovering PostgreSQL replication on {host}:{port}")
        
        # Check streaming replication
        repl_slots_query = POSTGRESQL_COMMANDS["replication_slots"]
        
        # Check logical replication (publications/subscriptions)
        pub_query = POSTGRESQL_COMMANDS["publication_status"]
        sub_query = POSTGRESQL_COMMANDS["subscription_status"]
        
        # Simulated discovery result structure
        # Real implementation would query the database
        
        return links
    
    async def discover_postgresql_fdw(
        self,
        host: str,
        port: int = 5432,
    ) -> List[FederationLink]:
        """Discover PostgreSQL Foreign Data Wrappers."""
        federation_links = []
        
        logger.info(f"Discovering PostgreSQL FDW on {host}:{port}")
        
        # Foreign servers
        fdw_query = POSTGRESQL_COMMANDS["foreign_servers"]
        
        # dblink connections
        dblink_query = POSTGRESQL_COMMANDS["dblink_connections"]
        
        return federation_links
    
    # =========================================================================
    # MySQL/MariaDB Discovery
    # =========================================================================
    
    async def discover_mysql_replication(
        self,
        host: str,
        port: int = 3306,
    ) -> List[ReplicationLink]:
        """Discover MySQL/MariaDB replication topology."""
        links = []
        
        logger.info(f"Discovering MySQL replication on {host}:{port}")
        
        # Check slave/replica status
        slave_query = MYSQL_COMMANDS["replica_status"]
        
        # Check Group Replication
        gr_query = MYSQL_COMMANDS["group_replication"]
        
        # Check NDB Cluster
        ndb_query = MYSQL_COMMANDS["ndb_cluster"]
        
        return links
    
    # =========================================================================
    # MSSQL Discovery
    # =========================================================================
    
    async def discover_mssql_topology(
        self,
        host: str,
        port: int = 1433,
    ) -> Tuple[List[ReplicationLink], List[FederationLink]]:
        """Discover MSSQL replication and linked servers."""
        repl_links = []
        fed_links = []
        
        logger.info(f"Discovering MSSQL topology on {host}:{port}")
        
        # Always On Availability Groups
        ag_query = MSSQL_COMMANDS["availability_groups"]
        
        # Database Mirroring (legacy)
        mirror_query = MSSQL_COMMANDS["mirroring_status"]
        
        # Linked Servers
        linked_query = MSSQL_COMMANDS["linked_servers"]
        
        return repl_links, fed_links
    
    # =========================================================================
    # MongoDB Discovery
    # =========================================================================
    
    async def discover_mongodb_topology(
        self,
        host: str,
        port: int = 27017,
    ) -> Tuple[List[ReplicationLink], List[DatabaseShard]]:
        """Discover MongoDB replica set and sharding topology."""
        repl_links = []
        shards = []
        
        logger.info(f"Discovering MongoDB topology on {host}:{port}")
        
        # Replica Set Status
        rs_status = MONGODB_COMMANDS["replica_set_status"]
        
        # Sharding Status
        shard_status = MONGODB_COMMANDS["shard_status"]
        
        return repl_links, shards
    
    # =========================================================================
    # Redis Discovery
    # =========================================================================
    
    async def discover_redis_topology(
        self,
        host: str,
        port: int = 6379,
    ) -> List[ReplicationLink]:
        """Discover Redis replication and cluster topology."""
        links = []
        
        logger.info(f"Discovering Redis topology on {host}:{port}")
        
        # Replication info
        stdout, _, _ = await self._run_command(f"redis-cli -h {host} -p {port} INFO replication")
        if stdout:
            links.extend(self._parse_redis_replication(stdout, host, port))
        
        # Cluster info (if cluster mode)
        stdout, _, _ = await self._run_command(f"redis-cli -h {host} -p {port} CLUSTER INFO")
        if "cluster_state:ok" in stdout:
            # Cluster nodes
            nodes_out, _, _ = await self._run_command(f"redis-cli -h {host} -p {port} CLUSTER NODES")
            if nodes_out:
                links.extend(self._parse_redis_cluster(nodes_out))
        
        # Sentinel (if sentinel mode)
        stdout, _, _ = await self._run_command(f"redis-cli -h {host} -p 26379 SENTINEL masters")
        if stdout and "ERR" not in stdout:
            links.extend(self._parse_redis_sentinel(stdout))
        
        return links
    
    def _parse_redis_replication(
        self,
        output: str,
        host: str,
        port: int,
    ) -> List[ReplicationLink]:
        """Parse Redis INFO replication output."""
        links = []
        
        role_match = re.search(r"role:(\w+)", output)
        role = role_match.group(1) if role_match else "unknown"
        
        if role == "master":
            # Find connected slaves
            slave_pattern = r"slave(\d+):ip=([^,]+),port=(\d+),state=(\w+),offset=(\d+),lag=(\d+)"
            for match in re.finditer(slave_pattern, output):
                slave_host = match.group(2)
                slave_port = int(match.group(3))
                state = match.group(4)
                lag = int(match.group(6))
                
                master_node = DatabaseNode(
                    host=host,
                    port=port,
                    db_type=DatabaseType.REDIS,
                    role="master",
                    is_writable=True,
                )
                slave_node = DatabaseNode(
                    host=slave_host,
                    port=slave_port,
                    db_type=DatabaseType.REDIS,
                    role="slave",
                    is_writable=False,
                    lag_seconds=lag,
                )
                
                links.append(ReplicationLink(
                    link_id=self._generate_link_id("redis_repl"),
                    source=master_node,
                    target=slave_node,
                    replication_type=ReplicationType.MASTER_SLAVE,
                    lag_seconds=lag,
                    status=state,
                ))
        
        elif role == "slave":
            # Find master
            master_host_match = re.search(r"master_host:(.+)", output)
            master_port_match = re.search(r"master_port:(\d+)", output)
            link_status_match = re.search(r"master_link_status:(\w+)", output)
            
            if master_host_match and master_port_match:
                master_node = DatabaseNode(
                    host=master_host_match.group(1).strip(),
                    port=int(master_port_match.group(1)),
                    db_type=DatabaseType.REDIS,
                    role="master",
                    is_writable=True,
                )
                slave_node = DatabaseNode(
                    host=host,
                    port=port,
                    db_type=DatabaseType.REDIS,
                    role="slave",
                    is_writable=False,
                )
                
                links.append(ReplicationLink(
                    link_id=self._generate_link_id("redis_repl"),
                    source=master_node,
                    target=slave_node,
                    replication_type=ReplicationType.MASTER_SLAVE,
                    status=link_status_match.group(1) if link_status_match else "unknown",
                ))
        
        return links
    
    def _parse_redis_cluster(self, output: str) -> List[ReplicationLink]:
        """Parse Redis CLUSTER NODES output."""
        links = []
        nodes = {}
        
        for line in output.strip().split("\n"):
            parts = line.split()
            if len(parts) < 8:
                continue
            
            node_id = parts[0]
            addr = parts[1].split("@")[0]  # host:port@cport
            flags = parts[2].split(",")
            master_id = parts[3] if parts[3] != "-" else None
            
            host, port = addr.rsplit(":", 1)
            port = int(port)
            
            role = "master" if "master" in flags else "slave"
            
            node = DatabaseNode(
                host=host,
                port=port,
                db_type=DatabaseType.REDIS,
                role=role,
                is_writable=(role == "master"),
            )
            nodes[node_id] = (node, master_id)
        
        # Create replication links for slaves
        for node_id, (node, master_id) in nodes.items():
            if master_id and master_id in nodes:
                master_node, _ = nodes[master_id]
                links.append(ReplicationLink(
                    link_id=self._generate_link_id("redis_cluster"),
                    source=master_node,
                    target=node,
                    replication_type=ReplicationType.MASTER_SLAVE,
                    status="connected",
                ))
        
        return links
    
    def _parse_redis_sentinel(self, output: str) -> List[ReplicationLink]:
        """Parse Redis Sentinel masters output."""
        links = []
        # Implementation for Sentinel topology
        return links
    
    # =========================================================================
    # Cassandra Discovery
    # =========================================================================
    
    async def discover_cassandra_topology(
        self,
        host: str,
        port: int = 9042,
    ) -> List[DatabaseNode]:
        """Discover Cassandra cluster topology."""
        nodes = []
        
        logger.info(f"Discovering Cassandra topology on {host}:{port}")
        
        # nodetool status
        stdout, _, rc = await self._run_command(f"nodetool -h {host} status")
        if rc == 0:
            nodes.extend(self._parse_cassandra_status(stdout))
        
        return nodes
    
    def _parse_cassandra_status(self, output: str) -> List[DatabaseNode]:
        """Parse nodetool status output."""
        nodes = []
        
        # Pattern: UN  192.168.1.1  100.0 GB   256    ?       rack1
        pattern = r"([UD][NLJM])\s+(\d+\.\d+\.\d+\.\d+)\s+"
        
        for match in re.finditer(pattern, output):
            status = match.group(1)
            host = match.group(2)
            
            state = "running" if status[0] == "U" else "down"
            
            nodes.append(DatabaseNode(
                host=host,
                port=9042,
                db_type=DatabaseType.CASSANDRA,
                role="node",
                state=state,
                is_writable=(status[0] == "U"),
            ))
        
        return nodes
    
    # =========================================================================
    # Connection Pool Discovery
    # =========================================================================
    
    async def discover_connection_pools(self) -> List[ConnectionPool]:
        """Discover database connection pools and proxies."""
        pools = []
        
        for pool_type, patterns in PROXY_PATTERNS.items():
            # Check running processes
            for proc in patterns["process"]:
                stdout, _, rc = await self._run_command(f"pgrep -a {proc}")
                if rc == 0 and stdout.strip():
                    logger.info(f"Found {pool_type.value} process")
                    
                    # Try to get configuration
                    for config_file in patterns.get("config_files", []):
                        if os.path.exists(config_file):
                            pool = await self._parse_pool_config(pool_type, config_file)
                            if pool:
                                pools.append(pool)
            
            # Check listening ports
            for port in patterns.get("ports", []):
                stdout, _, rc = await self._run_command(f"lsof -i :{port} -sTCP:LISTEN")
                if rc == 0 and stdout.strip():
                    logger.info(f"Found {pool_type.value} on port {port}")
        
        return pools
    
    async def _parse_pool_config(
        self,
        pool_type: ConnectionPoolType,
        config_file: str,
    ) -> Optional[ConnectionPool]:
        """Parse connection pool configuration."""
        try:
            with open(config_file, "r") as f:
                content = f.read()
            
            if pool_type == ConnectionPoolType.PGBOUNCER:
                return self._parse_pgbouncer_config(content)
            elif pool_type == ConnectionPoolType.PROXYSQL:
                return self._parse_proxysql_config(content)
            elif pool_type == ConnectionPoolType.HAPROXY:
                return self._parse_haproxy_config(content)
            
        except Exception as e:
            logger.error(f"Error parsing {pool_type.value} config: {e}")
        
        return None
    
    def _parse_pgbouncer_config(self, content: str) -> Optional[ConnectionPool]:
        """Parse PgBouncer configuration."""
        pool = ConnectionPool(
            pool_id=self._generate_link_id("pgbouncer"),
            pool_type=ConnectionPoolType.PGBOUNCER,
            host="localhost",
            port=6432,
        )
        
        # Parse listen_addr and listen_port
        addr_match = re.search(r"listen_addr\s*=\s*([^\s]+)", content)
        port_match = re.search(r"listen_port\s*=\s*(\d+)", content)
        mode_match = re.search(r"pool_mode\s*=\s*(\w+)", content)
        max_match = re.search(r"max_client_conn\s*=\s*(\d+)", content)
        
        if addr_match:
            pool.host = addr_match.group(1)
        if port_match:
            pool.port = int(port_match.group(1))
        if mode_match:
            pool.pool_mode = mode_match.group(1)
        if max_match:
            pool.max_connections = int(max_match.group(1))
        
        # Parse databases section
        db_section = re.search(r"\[databases\](.*?)(?:\[|\Z)", content, re.DOTALL)
        if db_section:
            for match in re.finditer(r"(\w+)\s*=\s*host=([^\s]+)\s+port=(\d+)", db_section.group(1)):
                db_name = match.group(1)
                backend_host = match.group(2)
                backend_port = int(match.group(3))
                
                pool.databases.append(db_name)
                pool.backend_servers.append({
                    "database": db_name,
                    "host": backend_host,
                    "port": backend_port,
                })
        
        return pool
    
    def _parse_proxysql_config(self, content: str) -> Optional[ConnectionPool]:
        """Parse ProxySQL configuration."""
        pool = ConnectionPool(
            pool_id=self._generate_link_id("proxysql"),
            pool_type=ConnectionPoolType.PROXYSQL,
            host="localhost",
            port=6033,
        )
        
        # Parse mysql_servers
        servers_match = re.search(r"mysql_servers\s*=\s*\((.*?)\)", content, re.DOTALL)
        if servers_match:
            for server in re.finditer(
                r"hostname\s*=\s*\"([^\"]+)\".*?port\s*=\s*(\d+)",
                servers_match.group(1),
                re.DOTALL
            ):
                pool.backend_servers.append({
                    "host": server.group(1),
                    "port": int(server.group(2)),
                })
        
        return pool
    
    def _parse_haproxy_config(self, content: str) -> Optional[ConnectionPool]:
        """Parse HAProxy configuration for database backends."""
        pool = ConnectionPool(
            pool_id=self._generate_link_id("haproxy"),
            pool_type=ConnectionPoolType.HAPROXY,
            host="localhost",
            port=3307,
        )
        
        # Find database backends (mysql, postgres, etc.)
        backend_pattern = r"backend\s+(\w*(?:mysql|postgres|pgsql|mariadb)\w*)(.*?)(?=backend|\Z)"
        
        for match in re.finditer(backend_pattern, content, re.DOTALL | re.IGNORECASE):
            backend_name = match.group(1)
            backend_content = match.group(2)
            
            # Find servers in backend
            for server_match in re.finditer(
                r"server\s+(\w+)\s+([^:\s]+):(\d+)",
                backend_content
            ):
                pool.backend_servers.append({
                    "name": server_match.group(1),
                    "host": server_match.group(2),
                    "port": int(server_match.group(3)),
                    "backend": backend_name,
                })
        
        return pool
    
    # =========================================================================
    # Main Discovery Method
    # =========================================================================
    
    async def discover_all(
        self,
        hosts: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Discover all database topology.
        
        Args:
            hosts: List of hosts with database information
                   [{"host": "...", "port": ..., "type": "postgresql"}, ...]
        
        Returns:
            Complete topology information
        """
        results = {
            "clusters": [],
            "replication_links": [],
            "shards": [],
            "federation_links": [],
            "connection_pools": [],
        }
        
        # Discover connection pools first
        pools = await self.discover_connection_pools()
        results["connection_pools"] = [p.to_dict() for p in pools]
        
        if hosts:
            for host_info in hosts:
                host = host_info.get("host", "localhost")
                port = host_info.get("port", 5432)
                db_type = host_info.get("type", "").lower()
                
                if db_type == "postgresql":
                    repl = await self.discover_postgresql_replication(host, port)
                    results["replication_links"].extend([r.to_dict() for r in repl])
                    
                    fdw = await self.discover_postgresql_fdw(host, port)
                    results["federation_links"].extend([f.to_dict() for f in fdw])
                    
                elif db_type in ("mysql", "mariadb"):
                    repl = await self.discover_mysql_replication(host, port)
                    results["replication_links"].extend([r.to_dict() for r in repl])
                    
                elif db_type == "mssql":
                    repl, fed = await self.discover_mssql_topology(host, port)
                    results["replication_links"].extend([r.to_dict() for r in repl])
                    results["federation_links"].extend([f.to_dict() for f in fed])
                    
                elif db_type == "mongodb":
                    repl, shards = await self.discover_mongodb_topology(host, port)
                    results["replication_links"].extend([r.to_dict() for r in repl])
                    results["shards"].extend([s.to_dict() for s in shards])
                    
                elif db_type == "redis":
                    repl = await self.discover_redis_topology(host, port)
                    results["replication_links"].extend([r.to_dict() for r in repl])
                    
                elif db_type == "cassandra":
                    nodes = await self.discover_cassandra_topology(host, port)
                    # Cassandra doesn't have traditional master-slave
                    # All nodes are peers
        
        return results
    
    def get_topology_summary(self) -> Dict[str, Any]:
        """Get summary of discovered topology."""
        return {
            "total_clusters": len(self.clusters),
            "total_replication_links": len(self.replication_links),
            "total_shards": len(self.shards),
            "total_federation_links": len(self.federation_links),
            "total_connection_pools": len(self.connection_pools),
        }

