"""
API and Microservices Discovery Module

Discovers API and microservices relationships:
- Service dependencies: API call graph, dependency depth, critical paths
- API Gateway routing: Kong, Nginx, Envoy, AWS API Gateway, Azure API Management
- Event-driven connections: Message queues, event buses, webhooks, CDC streams

This module helps understand how APIs and microservices are interconnected.
"""

import os
import re
import json
import yaml
import logging
import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

from ..utils.async_subprocess import run_shell


logger = logging.getLogger(__name__)


class APIGatewayType(str, Enum):
    """API Gateway types."""
    KONG = "kong"
    NGINX = "nginx"
    ENVOY = "envoy"
    AWS_API_GATEWAY = "aws_api_gateway"
    AZURE_API_MANAGEMENT = "azure_api_management"
    GCP_API_GATEWAY = "gcp_api_gateway"
    TRAEFIK = "traefik"
    AMBASSADOR = "ambassador"
    APISIX = "apisix"
    TYKK = "tyk"


class MessageBrokerType(str, Enum):
    """Message broker types."""
    RABBITMQ = "rabbitmq"
    KAFKA = "kafka"
    AWS_SQS = "aws_sqs"
    AWS_SNS = "aws_sns"
    AWS_EVENTBRIDGE = "aws_eventbridge"
    AZURE_SERVICE_BUS = "azure_service_bus"
    AZURE_EVENT_HUBS = "azure_event_hubs"
    GCP_PUBSUB = "gcp_pubsub"
    REDIS_STREAMS = "redis_streams"
    NATS = "nats"
    PULSAR = "pulsar"
    ACTIVEMQ = "activemq"


class ServiceProtocol(str, Enum):
    """Service communication protocols."""
    HTTP = "http"
    HTTPS = "https"
    GRPC = "grpc"
    GRAPHQL = "graphql"
    WEBSOCKET = "websocket"
    AMQP = "amqp"
    MQTT = "mqtt"
    KAFKA = "kafka"
    NATS = "nats"


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class Microservice:
    """Microservice information."""
    service_id: str
    name: str
    host: str
    port: int
    protocol: ServiceProtocol = ServiceProtocol.HTTP
    version: str = ""
    namespace: str = ""
    environment: str = ""
    health_endpoint: str = ""
    is_healthy: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "service_id": self.service_id,
            "name": self.name,
            "host": self.host,
            "port": self.port,
            "protocol": self.protocol.value,
            "version": self.version,
            "namespace": self.namespace,
            "environment": self.environment,
            "health_endpoint": self.health_endpoint,
            "is_healthy": self.is_healthy,
            "metadata": self.metadata,
        }


@dataclass
class ServiceDependency:
    """Service dependency relationship."""
    dependency_id: str
    source_service: str
    target_service: str
    protocol: ServiceProtocol
    endpoint: str = ""
    method: str = ""  # GET, POST, etc.
    is_critical: bool = False
    timeout_ms: int = 0
    retry_count: int = 0
    circuit_breaker: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "dependency_id": self.dependency_id,
            "source_service": self.source_service,
            "target_service": self.target_service,
            "protocol": self.protocol.value,
            "endpoint": self.endpoint,
            "method": self.method,
            "is_critical": self.is_critical,
            "timeout_ms": self.timeout_ms,
            "retry_count": self.retry_count,
            "circuit_breaker": self.circuit_breaker,
        }


@dataclass
class APIRoute:
    """API Gateway route."""
    route_id: str
    gateway_type: APIGatewayType
    path: str
    methods: List[str] = field(default_factory=list)
    upstream_service: str = ""
    upstream_url: str = ""
    plugins: List[str] = field(default_factory=list)
    rate_limit: Dict[str, Any] = field(default_factory=dict)
    authentication: str = ""
    cors_enabled: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "route_id": self.route_id,
            "gateway_type": self.gateway_type.value,
            "path": self.path,
            "methods": self.methods,
            "upstream_service": self.upstream_service,
            "upstream_url": self.upstream_url,
            "plugins": self.plugins,
            "rate_limit": self.rate_limit,
            "authentication": self.authentication,
            "cors_enabled": self.cors_enabled,
        }


@dataclass
class MessageQueueBinding:
    """Message queue binding."""
    binding_id: str
    broker_type: MessageBrokerType
    exchange_name: str = ""
    queue_name: str = ""
    topic_name: str = ""
    routing_key: str = ""
    producer_service: str = ""
    consumer_service: str = ""
    message_type: str = ""
    is_durable: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "binding_id": self.binding_id,
            "broker_type": self.broker_type.value,
            "exchange_name": self.exchange_name,
            "queue_name": self.queue_name,
            "topic_name": self.topic_name,
            "routing_key": self.routing_key,
            "producer_service": self.producer_service,
            "consumer_service": self.consumer_service,
            "message_type": self.message_type,
            "is_durable": self.is_durable,
        }


@dataclass
class EventBusSubscription:
    """Event bus subscription."""
    subscription_id: str
    event_bus: str
    event_type: str
    source_service: str
    target_service: str
    filter_pattern: str = ""
    retry_policy: Dict[str, Any] = field(default_factory=dict)
    dead_letter_queue: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "subscription_id": self.subscription_id,
            "event_bus": self.event_bus,
            "event_type": self.event_type,
            "source_service": self.source_service,
            "target_service": self.target_service,
            "filter_pattern": self.filter_pattern,
            "retry_policy": self.retry_policy,
            "dead_letter_queue": self.dead_letter_queue,
        }


@dataclass
class WebhookRegistration:
    """Webhook registration."""
    webhook_id: str
    source_service: str
    target_url: str
    events: List[str] = field(default_factory=list)
    secret: str = ""
    is_active: bool = True
    retry_count: int = 3
    content_type: str = "application/json"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "webhook_id": self.webhook_id,
            "source_service": self.source_service,
            "target_url": self.target_url,
            "events": self.events,
            "secret": "***" if self.secret else "",
            "is_active": self.is_active,
            "retry_count": self.retry_count,
            "content_type": self.content_type,
        }


@dataclass
class CDCStream:
    """Change Data Capture stream."""
    stream_id: str
    source_database: str
    source_table: str
    target_topic: str
    connector_type: str  # debezium, maxwell, etc.
    operations: List[str] = field(default_factory=list)  # INSERT, UPDATE, DELETE
    snapshot_mode: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "stream_id": self.stream_id,
            "source_database": self.source_database,
            "source_table": self.source_table,
            "target_topic": self.target_topic,
            "connector_type": self.connector_type,
            "operations": self.operations,
            "snapshot_mode": self.snapshot_mode,
        }


@dataclass
class ServiceCallGraph:
    """Service call graph analysis."""
    root_service: str
    total_services: int
    max_depth: int
    critical_path: List[str] = field(default_factory=list)
    single_points_of_failure: List[str] = field(default_factory=list)
    circular_dependencies: List[List[str]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "root_service": self.root_service,
            "total_services": self.total_services,
            "max_depth": self.max_depth,
            "critical_path": self.critical_path,
            "single_points_of_failure": self.single_points_of_failure,
            "circular_dependencies": self.circular_dependencies,
        }


# =============================================================================
# Configuration Patterns
# =============================================================================

KONG_CONFIG_PATHS = [
    "/etc/kong/kong.yml",
    "/etc/kong/kong.conf",
    "/usr/local/kong/declarative/kong.yml",
]

NGINX_CONFIG_PATHS = [
    "/etc/nginx/nginx.conf",
    "/etc/nginx/conf.d/",
    "/usr/local/nginx/conf/nginx.conf",
]

ENVOY_CONFIG_PATHS = [
    "/etc/envoy/envoy.yaml",
    "/etc/envoy/config.yaml",
]

TRAEFIK_CONFIG_PATHS = [
    "/etc/traefik/traefik.yml",
    "/etc/traefik/traefik.toml",
    "/etc/traefik/dynamic/",
]

RABBITMQ_MANAGEMENT_API = "http://localhost:15672/api"
KAFKA_TOOLS = {
    "topics": "kafka-topics.sh --list",
    "consumer_groups": "kafka-consumer-groups.sh --list",
    "describe_group": "kafka-consumer-groups.sh --describe --group",
}


# =============================================================================
# Main Service Class
# =============================================================================

class APIMicroservicesDiscovery:
    """Service for discovering API and microservices relationships."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.services: List[Microservice] = []
        self.dependencies: List[ServiceDependency] = []
        self.routes: List[APIRoute] = []
        self.queue_bindings: List[MessageQueueBinding] = []
        self.event_subscriptions: List[EventBusSubscription] = []
        self.webhooks: List[WebhookRegistration] = []
        self.cdc_streams: List[CDCStream] = []
        self._id_counter = 0
    
    def _generate_id(self, prefix: str = "id") -> str:
        """Generate unique ID."""
        self._id_counter += 1
        return f"{prefix}_{self._id_counter}"
    
    async def _run_command(self, cmd: str) -> Tuple[str, str, int]:
        """Run shell command and return output (async, non-blocking)."""
        try:
            rc, out, err = await run_shell(cmd, timeout=30, allow_unsafe_shell=True)
            return out, err, rc
        except FileNotFoundError:
            return "", "Command not found", 1
        except asyncio.TimeoutError:
            return "", "Command timed out", 1
        except Exception as e:
            return "", str(e), 1
    
    def _load_yaml(self, path: str) -> Optional[Dict]:
        """Load YAML configuration file."""
        try:
            with open(path, "r") as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.debug(f"Could not load YAML {path}: {e}")
            return None
    
    def _load_json(self, path: str) -> Optional[Dict]:
        """Load JSON configuration file."""
        try:
            with open(path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.debug(f"Could not load JSON {path}: {e}")
            return None
    
    # =========================================================================
    # Kong Discovery
    # =========================================================================
    
    async def discover_kong_routes(self) -> List[APIRoute]:
        """Discover Kong API Gateway routes."""
        routes = []
        
        # Try declarative config
        for config_path in KONG_CONFIG_PATHS:
            if os.path.exists(config_path):
                config = self._load_yaml(config_path)
                if config:
                    routes.extend(self._parse_kong_config(config))
        
        # Try Admin API
        stdout, _, rc = await self._run_command(
            "curl -s http://localhost:8001/routes"
        )
        if rc == 0 and stdout:
            try:
                data = json.loads(stdout)
                routes.extend(self._parse_kong_api_routes(data))
            except json.JSONDecodeError:
                pass
        
        return routes
    
    def _parse_kong_config(self, config: Dict) -> List[APIRoute]:
        """Parse Kong declarative configuration."""
        routes = []
        
        for service in config.get("services", []):
            service_name = service.get("name", "")
            service_url = service.get("url", "")
            
            for route in service.get("routes", []):
                routes.append(APIRoute(
                    route_id=self._generate_id("kong_route"),
                    gateway_type=APIGatewayType.KONG,
                    path=route.get("paths", ["/"])[0] if route.get("paths") else "/",
                    methods=route.get("methods", ["GET"]),
                    upstream_service=service_name,
                    upstream_url=service_url,
                    plugins=[p.get("name") for p in service.get("plugins", [])],
                ))
        
        return routes
    
    def _parse_kong_api_routes(self, data: Dict) -> List[APIRoute]:
        """Parse Kong Admin API response."""
        routes = []
        
        for route in data.get("data", []):
            routes.append(APIRoute(
                route_id=route.get("id", self._generate_id("kong_route")),
                gateway_type=APIGatewayType.KONG,
                path=route.get("paths", ["/"])[0] if route.get("paths") else "/",
                methods=route.get("methods", []),
                upstream_service=route.get("service", {}).get("id", ""),
            ))
        
        return routes
    
    # =========================================================================
    # Nginx Discovery
    # =========================================================================
    
    async def discover_nginx_routes(self) -> List[APIRoute]:
        """Discover Nginx reverse proxy routes."""
        routes = []
        
        for config_path in NGINX_CONFIG_PATHS:
            if os.path.isfile(config_path):
                routes.extend(self._parse_nginx_config(config_path))
            elif os.path.isdir(config_path):
                for filename in os.listdir(config_path):
                    if filename.endswith(".conf"):
                        routes.extend(
                            self._parse_nginx_config(os.path.join(config_path, filename))
                        )
        
        return routes
    
    def _parse_nginx_config(self, config_path: str) -> List[APIRoute]:
        """Parse Nginx configuration for upstream/proxy routes."""
        routes = []
        
        try:
            with open(config_path, "r") as f:
                content = f.read()
            
            # Find location blocks with proxy_pass
            location_pattern = r"location\s+([^\s{]+)\s*\{([^}]+)\}"
            proxy_pattern = r"proxy_pass\s+([^;]+);"
            
            for match in re.finditer(location_pattern, content):
                path = match.group(1)
                block = match.group(2)
                
                proxy_match = re.search(proxy_pattern, block)
                if proxy_match:
                    upstream_url = proxy_match.group(1).strip()
                    
                    routes.append(APIRoute(
                        route_id=self._generate_id("nginx_route"),
                        gateway_type=APIGatewayType.NGINX,
                        path=path,
                        methods=["GET", "POST", "PUT", "DELETE"],  # Nginx doesn't restrict by default
                        upstream_url=upstream_url,
                    ))
            
            # Find upstream blocks
            upstream_pattern = r"upstream\s+(\w+)\s*\{([^}]+)\}"
            for match in re.finditer(upstream_pattern, content):
                upstream_name = match.group(1)
                upstream_block = match.group(2)
                
                # Find servers in upstream
                server_pattern = r"server\s+([^;]+);"
                servers = re.findall(server_pattern, upstream_block)
                
                for route in routes:
                    if upstream_name in route.upstream_url:
                        route.upstream_service = upstream_name
                        route.metadata = {"servers": servers}
        
        except Exception as e:
            logger.error(f"Error parsing Nginx config {config_path}: {e}")
        
        return routes
    
    # =========================================================================
    # Envoy Discovery
    # =========================================================================
    
    async def discover_envoy_routes(self) -> List[APIRoute]:
        """Discover Envoy proxy routes."""
        routes = []
        
        for config_path in ENVOY_CONFIG_PATHS:
            if os.path.exists(config_path):
                config = self._load_yaml(config_path)
                if config:
                    routes.extend(self._parse_envoy_config(config))
        
        return routes
    
    def _parse_envoy_config(self, config: Dict) -> List[APIRoute]:
        """Parse Envoy configuration."""
        routes = []
        
        static_resources = config.get("static_resources", {})
        
        # Parse listeners and routes
        for listener in static_resources.get("listeners", []):
            for filter_chain in listener.get("filter_chains", []):
                for filter_obj in filter_chain.get("filters", []):
                    if filter_obj.get("name") == "envoy.filters.network.http_connection_manager":
                        typed_config = filter_obj.get("typed_config", {})
                        route_config = typed_config.get("route_config", {})
                        
                        for vhost in route_config.get("virtual_hosts", []):
                            for route in vhost.get("routes", []):
                                match = route.get("match", {})
                                route_action = route.get("route", {})
                                
                                routes.append(APIRoute(
                                    route_id=self._generate_id("envoy_route"),
                                    gateway_type=APIGatewayType.ENVOY,
                                    path=match.get("prefix", match.get("path", "/")),
                                    upstream_service=route_action.get("cluster", ""),
                                ))
        
        return routes
    
    # =========================================================================
    # Traefik Discovery
    # =========================================================================
    
    async def discover_traefik_routes(self) -> List[APIRoute]:
        """Discover Traefik routes."""
        routes = []
        
        for config_path in TRAEFIK_CONFIG_PATHS:
            if os.path.isfile(config_path):
                if config_path.endswith(".yml") or config_path.endswith(".yaml"):
                    config = self._load_yaml(config_path)
                else:
                    # TOML parsing would need tomli library
                    continue
                
                if config:
                    routes.extend(self._parse_traefik_config(config))
            
            elif os.path.isdir(config_path):
                for filename in os.listdir(config_path):
                    if filename.endswith((".yml", ".yaml")):
                        config = self._load_yaml(os.path.join(config_path, filename))
                        if config:
                            routes.extend(self._parse_traefik_config(config))
        
        return routes
    
    def _parse_traefik_config(self, config: Dict) -> List[APIRoute]:
        """Parse Traefik configuration."""
        routes = []
        
        http = config.get("http", {})
        routers = http.get("routers", {})
        services = http.get("services", {})
        
        for router_name, router in routers.items():
            rule = router.get("rule", "")
            service = router.get("service", "")
            
            # Parse PathPrefix from rule
            path_match = re.search(r"PathPrefix\(`([^`]+)`\)", rule)
            path = path_match.group(1) if path_match else "/"
            
            # Get service URL
            service_config = services.get(service, {})
            servers = service_config.get("loadBalancer", {}).get("servers", [])
            upstream_url = servers[0].get("url", "") if servers else ""
            
            routes.append(APIRoute(
                route_id=self._generate_id("traefik_route"),
                gateway_type=APIGatewayType.TRAEFIK,
                path=path,
                upstream_service=service,
                upstream_url=upstream_url,
            ))
        
        return routes
    
    # =========================================================================
    # RabbitMQ Discovery
    # =========================================================================
    
    async def discover_rabbitmq_bindings(
        self,
        host: str = "localhost",
        port: int = 15672,
        user: str = "guest",
        password: str = "guest",
    ) -> List[MessageQueueBinding]:
        """Discover RabbitMQ exchanges and bindings."""
        bindings = []
        
        base_url = f"http://{host}:{port}/api"
        auth = f"-u {user}:{password}"
        
        # Get exchanges
        stdout, _, rc = await self._run_command(f"curl -s {auth} {base_url}/exchanges")
        if rc == 0 and stdout:
            try:
                exchanges = json.loads(stdout)
                for exchange in exchanges:
                    if exchange.get("name"):
                        bindings.append(MessageQueueBinding(
                            binding_id=self._generate_id("rabbitmq"),
                            broker_type=MessageBrokerType.RABBITMQ,
                            exchange_name=exchange.get("name"),
                            is_durable=exchange.get("durable", False),
                        ))
            except json.JSONDecodeError:
                pass
        
        # Get queues
        stdout, _, rc = await self._run_command(f"curl -s {auth} {base_url}/queues")
        if rc == 0 and stdout:
            try:
                queues = json.loads(stdout)
                for queue in queues:
                    bindings.append(MessageQueueBinding(
                        binding_id=self._generate_id("rabbitmq"),
                        broker_type=MessageBrokerType.RABBITMQ,
                        queue_name=queue.get("name"),
                        is_durable=queue.get("durable", False),
                    ))
            except json.JSONDecodeError:
                pass
        
        # Get bindings
        stdout, _, rc = await self._run_command(f"curl -s {auth} {base_url}/bindings")
        if rc == 0 and stdout:
            try:
                binding_data = json.loads(stdout)
                for binding in binding_data:
                    if binding.get("source") and binding.get("destination"):
                        bindings.append(MessageQueueBinding(
                            binding_id=self._generate_id("rabbitmq_binding"),
                            broker_type=MessageBrokerType.RABBITMQ,
                            exchange_name=binding.get("source"),
                            queue_name=binding.get("destination"),
                            routing_key=binding.get("routing_key", ""),
                        ))
            except json.JSONDecodeError:
                pass
        
        return bindings
    
    # =========================================================================
    # Kafka Discovery
    # =========================================================================
    
    async def discover_kafka_topics(
        self,
        bootstrap_servers: str = "localhost:9092",
    ) -> List[MessageQueueBinding]:
        """Discover Kafka topics and consumer groups."""
        bindings = []
        
        # List topics
        stdout, _, rc = await self._run_command(
            f"kafka-topics.sh --bootstrap-server {bootstrap_servers} --list"
        )
        if rc == 0 and stdout:
            for topic in stdout.strip().split("\n"):
                if topic and not topic.startswith("__"):  # Skip internal topics
                    bindings.append(MessageQueueBinding(
                        binding_id=self._generate_id("kafka_topic"),
                        broker_type=MessageBrokerType.KAFKA,
                        topic_name=topic.strip(),
                    ))
        
        # List consumer groups
        stdout, _, rc = await self._run_command(
            f"kafka-consumer-groups.sh --bootstrap-server {bootstrap_servers} --list"
        )
        if rc == 0 and stdout:
            for group in stdout.strip().split("\n"):
                if group:
                    # Get group details
                    detail_stdout, _, _ = await self._run_command(
                        f"kafka-consumer-groups.sh --bootstrap-server {bootstrap_servers} "
                        f"--describe --group {group}"
                    )
                    
                    # Parse topics consumed by this group
                    if detail_stdout:
                        for line in detail_stdout.split("\n"):
                            if line and not line.startswith("GROUP"):
                                parts = line.split()
                                if len(parts) >= 2:
                                    topic = parts[1]
                                    
                                    # Find matching binding and update
                                    for binding in bindings:
                                        if binding.topic_name == topic:
                                            binding.consumer_service = group
        
        return bindings
    
    # =========================================================================
    # NATS Discovery
    # =========================================================================
    
    async def discover_nats_subjects(
        self,
        nats_url: str = "nats://localhost:4222"
    ) -> List[MessageQueueBinding]:
        """Discover NATS subjects and subscribers."""
        bindings = []
        
        from ..utils.async_http import fetch
        import json
        
        try:
            # NATS monitoring API (usually on port 8222)
            monitor_url = nats_url.replace("4222", "8222").replace("nats://", "http://")
            
            # Get subscriptions
            st, _, body = await fetch(f"{monitor_url}/subsz?subs=1", timeout=5, max_bytes=1_000_000)
            if st == 200 and body:
                data = json.loads(body.decode(errors="ignore") or "{}")
                
                for sub in data.get("subscriptions", []):
                    bindings.append(MessageQueueBinding(
                        binding_id=self._generate_id("nats_sub"),
                        broker_type=MessageBrokerType.NATS,
                        topic_name=sub.get("subject", "unknown"),
                        consumer_service=sub.get("name", ""),
                        routing_key=sub.get("subject", ""),
                        metadata={
                            "queue_group": sub.get("queue", ""),
                            "pending_msgs": sub.get("pending", 0),
                            "max_pending": sub.get("max", 0),
                        }
                    ))
            
            # Get stream info (JetStream)
            try:
                st2, _, b2 = await fetch(f"{monitor_url}/jsz?streams=1", timeout=5, max_bytes=1_000_000)
                if st2 == 200 and b2:
                    js_data = json.loads(b2.decode(errors="ignore") or "{}")
                    
                    for stream in js_data.get("streams", []):
                        bindings.append(MessageQueueBinding(
                            binding_id=self._generate_id("nats_stream"),
                            broker_type=MessageBrokerType.NATS,
                            topic_name=stream.get("name", "unknown"),
                            metadata={
                                "type": "jetstream",
                                "messages": stream.get("state", {}).get("messages", 0),
                                "bytes": stream.get("state", {}).get("bytes", 0),
                                "subjects": stream.get("config", {}).get("subjects", []),
                            }
                        ))
            except Exception:
                pass
                
        except Exception:
            pass
        
        return bindings
    
    # =========================================================================
    # gRPC Service Discovery
    # =========================================================================
    
    async def discover_grpc_services(
        self,
        target: str = "localhost:50051"
    ) -> List[Dict[str, Any]]:
        """Discover gRPC services using reflection."""
        services = []
        
        # Try grpcurl for reflection
        stdout, _, rc = await self._run_command(
            f"grpcurl -plaintext {target} list"
        )
        
        if rc == 0 and stdout:
            for service_name in stdout.strip().split("\n"):
                if service_name and not service_name.startswith("grpc."):
                    # Get service methods
                    methods_stdout, _, _ = await self._run_command(
                        f"grpcurl -plaintext {target} describe {service_name}"
                    )
                    
                    methods = []
                    if methods_stdout:
                        for line in methods_stdout.split("\n"):
                            if "rpc " in line:
                                methods.append(line.strip())
                    
                    services.append({
                        "service": service_name,
                        "target": target,
                        "methods": methods,
                        "protocol": "grpc",
                        "reflection_enabled": True,
                    })
        
        return services
    
    # =========================================================================
    # WebSocket Connections Discovery
    # =========================================================================
    
    async def discover_websocket_endpoints(
        self,
        base_url: str = "http://localhost"
    ) -> List[Dict[str, Any]]:
        """Discover WebSocket endpoints."""
        endpoints = []
        
        common_ws_paths = [
            "/ws", "/websocket", "/socket", "/socket.io",
            "/ws/", "/api/ws", "/api/websocket",
            "/realtime", "/events", "/stream",
            "/chat", "/notifications", "/updates"
        ]
        
        from ..utils.async_http import fetch
        
        for path in common_ws_paths:
            for scheme in ["ws://", "wss://"]:
                ws_url = base_url.replace("http://", scheme).replace("https://", scheme) + path
                
                try:
                    # Try HTTP upgrade request
                    http_url = ws_url.replace("ws://", "http://").replace("wss://", "https://")
                    st, hdrs, _ = await fetch(
                        http_url,
                        headers={
                            "Upgrade": "websocket",
                            "Connection": "Upgrade",
                            "Sec-WebSocket-Version": "13",
                            "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
                        },
                        timeout=3,
                        max_bytes=2048,
                    )
                    if st == 101:
                        endpoints.append({
                            "url": ws_url,
                            "path": path,
                            "protocol": "websocket",
                            "secure": scheme == "wss://",
                        })
                    elif st in [426, 400]:
                        upgrade_header = (hdrs or {}).get("upgrade", "")
                        if "websocket" in str(upgrade_header).lower():
                            endpoints.append({
                                "url": ws_url,
                                "path": path,
                                "protocol": "websocket",
                                "secure": scheme == "wss://",
                            })
                except Exception:
                    pass
        
        return endpoints
    
    # =========================================================================
    # AWS EventBridge Discovery
    # =========================================================================
    
    async def discover_eventbridge_rules(self) -> List[EventBusSubscription]:
        """Discover AWS EventBridge rules and targets."""
        subscriptions = []
        
        # List event buses
        stdout, _, rc = await self._run_command(
            "aws events list-event-buses --query 'EventBuses[*].Name' --output text"
        )
        if rc != 0:
            return subscriptions
        
        event_buses = stdout.strip().split() if stdout else ["default"]
        
        for bus in event_buses:
            # List rules for each bus
            stdout, _, rc = await self._run_command(
                f"aws events list-rules --event-bus-name {bus} --output json"
            )
            if rc == 0 and stdout:
                try:
                    data = json.loads(stdout)
                    for rule in data.get("Rules", []):
                        rule_name = rule.get("Name")
                        
                        # Get targets for this rule
                        targets_stdout, _, _ = await self._run_command(
                            f"aws events list-targets-by-rule --rule {rule_name} "
                            f"--event-bus-name {bus} --output json"
                        )
                        
                        targets = []
                        if targets_stdout:
                            try:
                                targets_data = json.loads(targets_stdout)
                                targets = targets_data.get("Targets", [])
                            except json.JSONDecodeError:
                                pass
                        
                        for target in targets:
                            subscriptions.append(EventBusSubscription(
                                subscription_id=self._generate_id("eventbridge"),
                                event_bus=bus,
                                event_type=rule.get("EventPattern", ""),
                                source_service="eventbridge",
                                target_service=target.get("Arn", ""),
                                filter_pattern=rule.get("EventPattern", ""),
                            ))
                
                except json.JSONDecodeError:
                    pass
        
        return subscriptions
    
    # =========================================================================
    # CDC (Debezium) Discovery
    # =========================================================================
    
    async def discover_debezium_connectors(
        self,
        connect_url: str = "http://localhost:8083",
    ) -> List[CDCStream]:
        """Discover Debezium CDC connectors."""
        streams = []
        
        # List connectors
        stdout, _, rc = await self._run_command(f"curl -s {connect_url}/connectors")
        if rc != 0 or not stdout:
            return streams
        
        try:
            connectors = json.loads(stdout)
        except json.JSONDecodeError:
            return streams
        
        for connector_name in connectors:
            # Get connector config
            stdout, _, rc = await self._run_command(
                f"curl -s {connect_url}/connectors/{connector_name}/config"
            )
            if rc == 0 and stdout:
                try:
                    config = json.loads(stdout)
                    
                    # Check if it's a Debezium connector
                    connector_class = config.get("connector.class", "")
                    if "debezium" in connector_class.lower():
                        streams.append(CDCStream(
                            stream_id=self._generate_id("debezium"),
                            source_database=config.get("database.dbname", 
                                config.get("database.names", "")),
                            source_table=config.get("table.include.list", "*"),
                            target_topic=config.get("topic.prefix", connector_name),
                            connector_type="debezium",
                            operations=["INSERT", "UPDATE", "DELETE"],
                            snapshot_mode=config.get("snapshot.mode", "initial"),
                        ))
                
                except json.JSONDecodeError:
                    pass
        
        return streams
    
    # =========================================================================
    # Service Dependency Analysis
    # =========================================================================
    
    def analyze_call_graph(
        self,
        dependencies: List[ServiceDependency],
        root_service: str,
    ) -> ServiceCallGraph:
        """Analyze service call graph for critical paths and failures."""
        
        # Build adjacency list
        graph: Dict[str, Set[str]] = {}
        reverse_graph: Dict[str, Set[str]] = {}
        
        for dep in dependencies:
            source = dep.source_service
            target = dep.target_service
            
            if source not in graph:
                graph[source] = set()
            graph[source].add(target)
            
            if target not in reverse_graph:
                reverse_graph[target] = set()
            reverse_graph[target].add(source)
        
        # Find all reachable services
        visited: Set[str] = set()
        
        def dfs(service: str, depth: int = 0) -> int:
            if service in visited:
                return depth
            visited.add(service)
            max_depth = depth
            
            for neighbor in graph.get(service, []):
                max_depth = max(max_depth, dfs(neighbor, depth + 1))
            
            return max_depth
        
        max_depth = dfs(root_service)
        
        # Find critical path (longest path)
        def find_longest_path(service: str, path: List[str]) -> List[str]:
            path = path + [service]
            
            if service not in graph or not graph[service]:
                return path
            
            longest = path
            for neighbor in graph[service]:
                if neighbor not in path:  # Avoid cycles
                    candidate = find_longest_path(neighbor, path)
                    if len(candidate) > len(longest):
                        longest = candidate
            
            return longest
        
        critical_path = find_longest_path(root_service, [])
        
        # Find single points of failure
        # Services that, if removed, disconnect the graph
        spof = []
        for service in visited:
            dependents = reverse_graph.get(service, set())
            dependencies_out = graph.get(service, set())
            
            # If only one service depends on it and it has dependencies,
            # it could be a SPOF
            if len(dependents) == 1 and dependencies_out:
                spof.append(service)
        
        # Find circular dependencies
        circular = []
        
        def find_cycle(service: str, path: List[str]) -> Optional[List[str]]:
            if service in path:
                cycle_start = path.index(service)
                return path[cycle_start:] + [service]
            
            for neighbor in graph.get(service, []):
                cycle = find_cycle(neighbor, path + [service])
                if cycle:
                    return cycle
            
            return None
        
        for service in visited:
            cycle = find_cycle(service, [])
            if cycle and cycle not in circular:
                circular.append(cycle)
        
        return ServiceCallGraph(
            root_service=root_service,
            total_services=len(visited),
            max_depth=max_depth,
            critical_path=critical_path,
            single_points_of_failure=spof,
            circular_dependencies=circular,
        )
    
    # =========================================================================
    # Kubernetes Service Discovery
    # =========================================================================
    
    async def discover_kubernetes_services(
        self,
        namespace: str = "default",
    ) -> List[Microservice]:
        """Discover Kubernetes services."""
        services = []
        
        # Get services
        stdout, _, rc = await self._run_command(
            f"kubectl get services -n {namespace} -o json"
        )
        if rc != 0 or not stdout:
            return services
        
        try:
            data = json.loads(stdout)
            for svc in data.get("items", []):
                metadata = svc.get("metadata", {})
                spec = svc.get("spec", {})
                
                ports = spec.get("ports", [])
                port = ports[0].get("port", 80) if ports else 80
                
                services.append(Microservice(
                    service_id=metadata.get("uid", self._generate_id("k8s_svc")),
                    name=metadata.get("name", ""),
                    host=f"{metadata.get('name')}.{namespace}.svc.cluster.local",
                    port=port,
                    namespace=namespace,
                    metadata={
                        "cluster_ip": spec.get("clusterIP"),
                        "type": spec.get("type"),
                        "selector": spec.get("selector"),
                    },
                ))
        
        except json.JSONDecodeError:
            pass
        
        return services
    
    # =========================================================================
    # Main Discovery Method
    # =========================================================================
    
    async def discover_all(
        self,
        include_k8s: bool = True,
        include_gateways: bool = True,
        include_messaging: bool = True,
        include_cdc: bool = True,
    ) -> Dict[str, Any]:
        """
        Discover all API and microservices relationships.
        
        Args:
            include_k8s: Discover Kubernetes services
            include_gateways: Discover API gateways
            include_messaging: Discover message brokers
            include_cdc: Discover CDC connectors
        
        Returns:
            Complete discovery results
        """
        results = {
            "services": [],
            "dependencies": [],
            "routes": [],
            "queue_bindings": [],
            "event_subscriptions": [],
            "webhooks": [],
            "cdc_streams": [],
            "call_graph": None,
        }
        
        if include_k8s:
            services = await self.discover_kubernetes_services()
            results["services"] = [s.to_dict() for s in services]
        
        if include_gateways:
            # Kong
            kong_routes = await self.discover_kong_routes()
            results["routes"].extend([r.to_dict() for r in kong_routes])
            
            # Nginx
            nginx_routes = await self.discover_nginx_routes()
            results["routes"].extend([r.to_dict() for r in nginx_routes])
            
            # Envoy
            envoy_routes = await self.discover_envoy_routes()
            results["routes"].extend([r.to_dict() for r in envoy_routes])
            
            # Traefik
            traefik_routes = await self.discover_traefik_routes()
            results["routes"].extend([r.to_dict() for r in traefik_routes])
        
        if include_messaging:
            # RabbitMQ
            rabbitmq_bindings = await self.discover_rabbitmq_bindings()
            results["queue_bindings"].extend([b.to_dict() for b in rabbitmq_bindings])
            
            # Kafka
            kafka_bindings = await self.discover_kafka_topics()
            results["queue_bindings"].extend([b.to_dict() for b in kafka_bindings])
            
            # EventBridge
            eventbridge_subs = await self.discover_eventbridge_rules()
            results["event_subscriptions"].extend([s.to_dict() for s in eventbridge_subs])
        
        if include_cdc:
            cdc_streams = await self.discover_debezium_connectors()
            results["cdc_streams"] = [s.to_dict() for s in cdc_streams]
        
        return results
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of discovered topology."""
        return {
            "total_services": len(self.services),
            "total_dependencies": len(self.dependencies),
            "total_routes": len(self.routes),
            "total_queue_bindings": len(self.queue_bindings),
            "total_event_subscriptions": len(self.event_subscriptions),
            "total_webhooks": len(self.webhooks),
            "total_cdc_streams": len(self.cdc_streams),
        }

