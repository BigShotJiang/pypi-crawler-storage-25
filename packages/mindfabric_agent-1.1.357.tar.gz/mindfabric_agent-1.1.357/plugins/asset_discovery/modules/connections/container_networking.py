"""
Container Networking Discovery Module

Discovers container network topology:
- Kubernetes: Pod/Service/NetworkPolicy, Ingress/Egress, multi-cluster
- Service Mesh: Istio, Linkerd, Consul Connect
- Docker: networks, bridges, overlay, port mappings

This module helps understand how containers communicate.
"""

import os
import re
import json
import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)

from ..utils.async_subprocess import run_exec_stdout


class ContainerNetworkType(str, Enum):
    """Container network types."""
    KUBERNETES = "kubernetes"
    DOCKER = "docker"
    SERVICE_MESH = "service_mesh"


class ServiceMeshType(str, Enum):
    """Service mesh types."""
    ISTIO = "istio"
    LINKERD = "linkerd"
    CONSUL = "consul"
    ENVOY = "envoy"


@dataclass
class KubernetesPod:
    """Kubernetes Pod network info."""
    name: str
    namespace: str
    pod_ip: str
    host_ip: str = ""
    node_name: str = ""
    labels: Dict[str, str] = field(default_factory=dict)
    containers: List[Dict[str, Any]] = field(default_factory=list)
    network_policies: List[str] = field(default_factory=list)


@dataclass
class KubernetesService:
    """Kubernetes Service info."""
    name: str
    namespace: str
    service_type: str  # ClusterIP, NodePort, LoadBalancer, ExternalName
    cluster_ip: str = ""
    external_ips: List[str] = field(default_factory=list)
    ports: List[Dict[str, Any]] = field(default_factory=list)
    selector: Dict[str, str] = field(default_factory=dict)
    endpoints: List[str] = field(default_factory=list)


@dataclass
class KubernetesNetworkPolicy:
    """Kubernetes NetworkPolicy info."""
    name: str
    namespace: str
    pod_selector: Dict[str, str] = field(default_factory=dict)
    ingress_rules: List[Dict[str, Any]] = field(default_factory=list)
    egress_rules: List[Dict[str, Any]] = field(default_factory=list)
    policy_types: List[str] = field(default_factory=list)


@dataclass
class KubernetesIngress:
    """Kubernetes Ingress info."""
    name: str
    namespace: str
    ingress_class: str = ""
    hosts: List[str] = field(default_factory=list)
    rules: List[Dict[str, Any]] = field(default_factory=list)
    tls: List[Dict[str, Any]] = field(default_factory=list)
    load_balancer_ip: str = ""


@dataclass
class DockerNetwork:
    """Docker network info."""
    name: str
    network_id: str
    driver: str  # bridge, overlay, host, none, macvlan
    scope: str  # local, swarm, global
    subnet: str = ""
    gateway: str = ""
    containers: List[Dict[str, Any]] = field(default_factory=list)
    options: Dict[str, str] = field(default_factory=dict)


@dataclass
class DockerContainer:
    """Docker container network info."""
    container_id: str
    name: str
    networks: List[str] = field(default_factory=list)
    ip_addresses: Dict[str, str] = field(default_factory=dict)  # network -> ip
    port_mappings: List[Dict[str, Any]] = field(default_factory=list)
    links: List[str] = field(default_factory=list)


@dataclass
class ServiceMeshService:
    """Service mesh service info."""
    name: str
    namespace: str
    mesh_type: ServiceMeshType
    virtual_service: Optional[Dict[str, Any]] = None
    destination_rules: List[Dict[str, Any]] = field(default_factory=list)
    traffic_policy: Optional[Dict[str, Any]] = None
    upstream_services: List[str] = field(default_factory=list)
    downstream_services: List[str] = field(default_factory=list)


@dataclass
class ContainerNetworkReport:
    """Container networking discovery report."""
    # Kubernetes
    pods: List[KubernetesPod] = field(default_factory=list)
    services: List[KubernetesService] = field(default_factory=list)
    network_policies: List[KubernetesNetworkPolicy] = field(default_factory=list)
    ingresses: List[KubernetesIngress] = field(default_factory=list)
    
    # Docker
    docker_networks: List[DockerNetwork] = field(default_factory=list)
    docker_containers: List[DockerContainer] = field(default_factory=list)
    
    # Service Mesh
    service_mesh_services: List[ServiceMeshService] = field(default_factory=list)
    service_mesh_type: Optional[ServiceMeshType] = None
    
    # Connections
    pod_to_pod_connections: List[Dict[str, Any]] = field(default_factory=list)
    service_dependencies: List[Dict[str, Any]] = field(default_factory=list)


class ContainerNetworkingDiscovery:
    """Service for discovering container network topology."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
    
    async def _run_command(self, cmd: List[str], timeout: int = 30) -> Optional[str]:
        """Run a command and return output (async, non-blocking)."""
        try:
            return await run_exec_stdout(cmd, timeout=float(timeout))
        except FileNotFoundError:
            return None
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Command {cmd} failed: {e}")
            return None
    
    # =========================================================================
    # Kubernetes Discovery
    # =========================================================================
    
    async def discover_kubernetes_pods(self, namespace: str = None) -> List[KubernetesPod]:
        """
        Discover Kubernetes pods.
        
        Args:
            namespace: Optional namespace filter (None = all namespaces)
            
        Returns:
            List of KubernetesPod objects
        """
        pods = []
        
        cmd = ["kubectl", "get", "pods", "-o", "json"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        
        output = await self._run_command(cmd)
        if not output:
            return pods
        
        try:
            data = json.loads(output)
            
            for item in data.get("items", []):
                metadata = item.get("metadata", {})
                spec = item.get("spec", {})
                status = item.get("status", {})
                
                containers = []
                for container in spec.get("containers", []):
                    containers.append({
                        "name": container.get("name", ""),
                        "image": container.get("image", ""),
                        "ports": container.get("ports", []),
                    })
                
                pods.append(KubernetesPod(
                    name=metadata.get("name", ""),
                    namespace=metadata.get("namespace", ""),
                    pod_ip=status.get("podIP", ""),
                    host_ip=status.get("hostIP", ""),
                    node_name=spec.get("nodeName", ""),
                    labels=metadata.get("labels", {}),
                    containers=containers,
                ))
                
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing pods: {e}")
        
        return pods
    
    async def discover_kubernetes_services(self, namespace: str = None) -> List[KubernetesService]:
        """
        Discover Kubernetes services.
        
        Args:
            namespace: Optional namespace filter
            
        Returns:
            List of KubernetesService objects
        """
        services = []
        
        cmd = ["kubectl", "get", "services", "-o", "json"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        
        output = await self._run_command(cmd)
        if not output:
            return services
        
        try:
            data = json.loads(output)
            
            for item in data.get("items", []):
                metadata = item.get("metadata", {})
                spec = item.get("spec", {})
                status = item.get("status", {})
                
                # Get external IPs
                external_ips = spec.get("externalIPs", [])
                lb_ingress = status.get("loadBalancer", {}).get("ingress", [])
                for ing in lb_ingress:
                    if ing.get("ip"):
                        external_ips.append(ing["ip"])
                    if ing.get("hostname"):
                        external_ips.append(ing["hostname"])
                
                ports = []
                for port in spec.get("ports", []):
                    ports.append({
                        "name": port.get("name", ""),
                        "protocol": port.get("protocol", "TCP"),
                        "port": port.get("port"),
                        "target_port": port.get("targetPort"),
                        "node_port": port.get("nodePort"),
                    })
                
                services.append(KubernetesService(
                    name=metadata.get("name", ""),
                    namespace=metadata.get("namespace", ""),
                    service_type=spec.get("type", "ClusterIP"),
                    cluster_ip=spec.get("clusterIP", ""),
                    external_ips=external_ips,
                    ports=ports,
                    selector=spec.get("selector", {}),
                ))
                
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing services: {e}")
        
        return services
    
    async def discover_kubernetes_network_policies(self, namespace: str = None) -> List[KubernetesNetworkPolicy]:
        """
        Discover Kubernetes NetworkPolicies.
        
        Args:
            namespace: Optional namespace filter
            
        Returns:
            List of KubernetesNetworkPolicy objects
        """
        policies = []
        
        cmd = ["kubectl", "get", "networkpolicies", "-o", "json"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        
        output = await self._run_command(cmd)
        if not output:
            return policies
        
        try:
            data = json.loads(output)
            
            for item in data.get("items", []):
                metadata = item.get("metadata", {})
                spec = item.get("spec", {})
                
                policies.append(KubernetesNetworkPolicy(
                    name=metadata.get("name", ""),
                    namespace=metadata.get("namespace", ""),
                    pod_selector=spec.get("podSelector", {}).get("matchLabels", {}),
                    ingress_rules=spec.get("ingress", []),
                    egress_rules=spec.get("egress", []),
                    policy_types=spec.get("policyTypes", []),
                ))
                
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing network policies: {e}")
        
        return policies
    
    async def discover_kubernetes_ingresses(self, namespace: str = None) -> List[KubernetesIngress]:
        """
        Discover Kubernetes Ingresses.
        
        Args:
            namespace: Optional namespace filter
            
        Returns:
            List of KubernetesIngress objects
        """
        ingresses = []
        
        cmd = ["kubectl", "get", "ingresses", "-o", "json"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        
        output = await self._run_command(cmd)
        if not output:
            return ingresses
        
        try:
            data = json.loads(output)
            
            for item in data.get("items", []):
                metadata = item.get("metadata", {})
                spec = item.get("spec", {})
                status = item.get("status", {})
                
                # Get hosts from rules
                hosts = []
                for rule in spec.get("rules", []):
                    if rule.get("host"):
                        hosts.append(rule["host"])
                
                # Get load balancer IP
                lb_ip = ""
                lb_ingress = status.get("loadBalancer", {}).get("ingress", [])
                if lb_ingress:
                    lb_ip = lb_ingress[0].get("ip", lb_ingress[0].get("hostname", ""))
                
                ingresses.append(KubernetesIngress(
                    name=metadata.get("name", ""),
                    namespace=metadata.get("namespace", ""),
                    ingress_class=spec.get("ingressClassName", metadata.get("annotations", {}).get("kubernetes.io/ingress.class", "")),
                    hosts=hosts,
                    rules=spec.get("rules", []),
                    tls=spec.get("tls", []),
                    load_balancer_ip=lb_ip,
                ))
                
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing ingresses: {e}")
        
        return ingresses
    
    # =========================================================================
    # Docker Discovery
    # =========================================================================
    
    async def discover_docker_networks(self) -> List[DockerNetwork]:
        """
        Discover Docker networks.
        
        Returns:
            List of DockerNetwork objects
        """
        networks = []
        
        output = await self._run_command(["docker", "network", "ls", "--format", "{{json .}}"])
        if not output:
            return networks
        
        for line in output.strip().split('\n'):
            if not line:
                continue
            
            try:
                net_basic = json.loads(line)
                net_id = net_basic.get("ID", "")
                
                # Get detailed info
                inspect_output = await self._run_command(["docker", "network", "inspect", net_id])
                if inspect_output:
                    net_data = json.loads(inspect_output)[0]
                    
                    # Get IPAM config
                    ipam = net_data.get("IPAM", {}).get("Config", [])
                    subnet = ipam[0].get("Subnet", "") if ipam else ""
                    gateway = ipam[0].get("Gateway", "") if ipam else ""
                    
                    # Get containers
                    containers = []
                    for cid, cdata in net_data.get("Containers", {}).items():
                        containers.append({
                            "container_id": cid,
                            "name": cdata.get("Name", ""),
                            "ipv4": cdata.get("IPv4Address", ""),
                            "ipv6": cdata.get("IPv6Address", ""),
                            "mac": cdata.get("MacAddress", ""),
                        })
                    
                    networks.append(DockerNetwork(
                        name=net_data.get("Name", ""),
                        network_id=net_id,
                        driver=net_data.get("Driver", ""),
                        scope=net_data.get("Scope", ""),
                        subnet=subnet,
                        gateway=gateway,
                        containers=containers,
                        options=net_data.get("Options", {}),
                    ))
                    
            except json.JSONDecodeError:
                pass
        
        return networks
    
    async def discover_docker_containers(self) -> List[DockerContainer]:
        """
        Discover Docker containers with network info.
        
        Returns:
            List of DockerContainer objects
        """
        containers = []
        
        output = await self._run_command(["docker", "ps", "-a", "--format", "{{json .}}"])
        if not output:
            return containers
        
        for line in output.strip().split('\n'):
            if not line:
                continue
            
            try:
                c_basic = json.loads(line)
                cid = c_basic.get("ID", "")
                
                # Get detailed info
                inspect_output = await self._run_command(["docker", "inspect", cid])
                if inspect_output:
                    c_data = json.loads(inspect_output)[0]
                    
                    # Get networks
                    network_settings = c_data.get("NetworkSettings", {})
                    networks_data = network_settings.get("Networks", {})
                    
                    network_names = list(networks_data.keys())
                    ip_addresses = {}
                    for net_name, net_info in networks_data.items():
                        ip_addresses[net_name] = net_info.get("IPAddress", "")
                    
                    # Get port mappings
                    port_mappings = []
                    ports = network_settings.get("Ports", {})
                    for container_port, host_bindings in ports.items():
                        if host_bindings:
                            for binding in host_bindings:
                                port_mappings.append({
                                    "container_port": container_port,
                                    "host_ip": binding.get("HostIp", ""),
                                    "host_port": binding.get("HostPort", ""),
                                })
                    
                    # Get links
                    links = c_data.get("HostConfig", {}).get("Links", []) or []
                    
                    containers.append(DockerContainer(
                        container_id=cid,
                        name=c_data.get("Name", "").lstrip("/"),
                        networks=network_names,
                        ip_addresses=ip_addresses,
                        port_mappings=port_mappings,
                        links=links,
                    ))
                    
            except json.JSONDecodeError:
                pass
        
        return containers
    
    # =========================================================================
    # Service Mesh Discovery
    # =========================================================================
    
    async def detect_service_mesh(self) -> Optional[ServiceMeshType]:
        """
        Detect which service mesh is installed.
        
        Returns:
            ServiceMeshType or None
        """
        # Check for Istio
        istio_output = await self._run_command([
            "kubectl", "get", "pods", "-n", "istio-system",
            "-l", "app=istiod", "-o", "name"
        ])
        if istio_output and "pod/" in istio_output:
            return ServiceMeshType.ISTIO
        
        # Check for Linkerd
        linkerd_output = await self._run_command([
            "kubectl", "get", "pods", "-n", "linkerd",
            "-l", "app=controller", "-o", "name"
        ])
        if linkerd_output and "pod/" in linkerd_output:
            return ServiceMeshType.LINKERD
        
        # Check for Consul Connect
        consul_output = await self._run_command([
            "kubectl", "get", "pods", "-n", "consul",
            "-l", "app=consul", "-o", "name"
        ])
        if consul_output and "pod/" in consul_output:
            return ServiceMeshType.CONSUL
        
        return None
    
    async def discover_istio_services(self) -> List[ServiceMeshService]:
        """
        Discover Istio virtual services and destination rules.
        
        Returns:
            List of ServiceMeshService objects
        """
        services = []
        
        # Get VirtualServices
        vs_output = await self._run_command([
            "kubectl", "get", "virtualservices", "-A", "-o", "json"
        ])
        
        if vs_output:
            try:
                vs_data = json.loads(vs_output)
                
                for item in vs_data.get("items", []):
                    metadata = item.get("metadata", {})
                    spec = item.get("spec", {})
                    
                    # Extract upstream services from routes
                    upstreams = []
                    for http in spec.get("http", []):
                        for route in http.get("route", []):
                            dest = route.get("destination", {})
                            if dest.get("host"):
                                upstreams.append(dest["host"])
                    
                    services.append(ServiceMeshService(
                        name=metadata.get("name", ""),
                        namespace=metadata.get("namespace", ""),
                        mesh_type=ServiceMeshType.ISTIO,
                        virtual_service=spec,
                        upstream_services=upstreams,
                    ))
                    
            except json.JSONDecodeError:
                pass
        
        # Get DestinationRules
        dr_output = await self._run_command([
            "kubectl", "get", "destinationrules", "-A", "-o", "json"
        ])
        
        if dr_output:
            try:
                dr_data = json.loads(dr_output)
                
                for item in dr_data.get("items", []):
                    metadata = item.get("metadata", {})
                    spec = item.get("spec", {})
                    host = spec.get("host", "")
                    
                    # Find matching service and add destination rule
                    for svc in services:
                        if svc.name == metadata.get("name") or host in svc.upstream_services:
                            svc.destination_rules.append(spec)
                            svc.traffic_policy = spec.get("trafficPolicy")
                            break
                    else:
                        # Create new service entry
                        services.append(ServiceMeshService(
                            name=metadata.get("name", ""),
                            namespace=metadata.get("namespace", ""),
                            mesh_type=ServiceMeshType.ISTIO,
                            destination_rules=[spec],
                            traffic_policy=spec.get("trafficPolicy"),
                        ))
                        
            except json.JSONDecodeError:
                pass
        
        return services
    
    async def discover_linkerd_services(self) -> List[ServiceMeshService]:
        """
        Discover Linkerd service profiles.
        
        Returns:
            List of ServiceMeshService objects
        """
        services = []
        
        output = await self._run_command([
            "kubectl", "get", "serviceprofiles", "-A", "-o", "json"
        ])
        
        if output:
            try:
                data = json.loads(output)
                
                for item in data.get("items", []):
                    metadata = item.get("metadata", {})
                    spec = item.get("spec", {})
                    
                    services.append(ServiceMeshService(
                        name=metadata.get("name", ""),
                        namespace=metadata.get("namespace", ""),
                        mesh_type=ServiceMeshType.LINKERD,
                        traffic_policy={"routes": spec.get("routes", [])},
                    ))
                    
            except json.JSONDecodeError:
                pass
        
        return services
    
    async def discover_consul_services(self) -> List[ServiceMeshService]:
        """
        Discover Consul Connect intentions.
        
        Returns:
            List of ServiceMeshService objects
        """
        services = []
        
        # Get ServiceIntentions
        output = await self._run_command([
            "kubectl", "get", "serviceintentions", "-A", "-o", "json"
        ])
        
        if output:
            try:
                data = json.loads(output)
                
                for item in data.get("items", []):
                    metadata = item.get("metadata", {})
                    spec = item.get("spec", {})
                    
                    # Extract upstream/downstream from intentions
                    upstreams = []
                    downstreams = []
                    
                    for source in spec.get("sources", []):
                        if source.get("name"):
                            downstreams.append(source["name"])
                    
                    services.append(ServiceMeshService(
                        name=spec.get("destination", {}).get("name", metadata.get("name", "")),
                        namespace=spec.get("destination", {}).get("namespace", metadata.get("namespace", "")),
                        mesh_type=ServiceMeshType.CONSUL,
                        traffic_policy={"sources": spec.get("sources", [])},
                        downstream_services=downstreams,
                    ))
                    
            except json.JSONDecodeError:
                pass
        
        return services
    
    # =========================================================================
    # Connection Analysis
    # =========================================================================
    
    def build_pod_connections(
        self,
        pods: List[KubernetesPod],
        services: List[KubernetesService],
        network_policies: List[KubernetesNetworkPolicy],
    ) -> List[Dict[str, Any]]:
        """
        Build pod-to-pod connection map based on services and network policies.
        
        Returns:
            List of connection dictionaries
        """
        connections = []
        
        # Map services to pods
        for svc in services:
            selector = svc.selector
            if not selector:
                continue
            
            # Find pods matching this service
            matching_pods = []
            for pod in pods:
                if all(pod.labels.get(k) == v for k, v in selector.items()):
                    matching_pods.append(pod)
            
            # Create connections from all other pods to this service's pods
            for target_pod in matching_pods:
                connections.append({
                    "type": "service",
                    "service_name": f"{svc.namespace}/{svc.name}",
                    "target_pod": f"{target_pod.namespace}/{target_pod.name}",
                    "target_ip": target_pod.pod_ip,
                    "ports": svc.ports,
                })
        
        # Apply network policy restrictions
        for policy in network_policies:
            # Find affected pods
            affected_pods = []
            for pod in pods:
                if pod.namespace == policy.namespace:
                    selector = policy.pod_selector
                    if not selector or all(pod.labels.get(k) == v for k, v in selector.items()):
                        affected_pods.append(pod)
            
            for pod in affected_pods:
                connections.append({
                    "type": "network_policy",
                    "policy_name": f"{policy.namespace}/{policy.name}",
                    "pod": f"{pod.namespace}/{pod.name}",
                    "ingress_rules": len(policy.ingress_rules),
                    "egress_rules": len(policy.egress_rules),
                    "policy_types": policy.policy_types,
                })
        
        return connections
    
    def build_service_dependencies(
        self,
        services: List[KubernetesService],
        mesh_services: List[ServiceMeshService],
    ) -> List[Dict[str, Any]]:
        """
        Build service dependency graph.
        
        Returns:
            List of dependency dictionaries
        """
        dependencies = []
        
        # From service mesh data
        for svc in mesh_services:
            for upstream in svc.upstream_services:
                dependencies.append({
                    "source": f"{svc.namespace}/{svc.name}",
                    "target": upstream,
                    "mesh_type": svc.mesh_type.value if svc.mesh_type else None,
                    "type": "service_mesh",
                })
            
            for downstream in svc.downstream_services:
                dependencies.append({
                    "source": downstream,
                    "target": f"{svc.namespace}/{svc.name}",
                    "mesh_type": svc.mesh_type.value if svc.mesh_type else None,
                    "type": "service_mesh",
                })
        
        return dependencies
    
    async def run_full_discovery(self, namespace: str = None) -> ContainerNetworkReport:
        """
        Run full container networking discovery.
        
        Args:
            namespace: Optional namespace filter
            
        Returns:
            ContainerNetworkReport
        """
        # Kubernetes discovery
        pods = await self.discover_kubernetes_pods(namespace)
        services = await self.discover_kubernetes_services(namespace)
        network_policies = await self.discover_kubernetes_network_policies(namespace)
        ingresses = await self.discover_kubernetes_ingresses(namespace)
        
        # Docker discovery
        docker_networks = await self.discover_docker_networks()
        docker_containers = await self.discover_docker_containers()
        
        # Service mesh discovery
        mesh_type = await self.detect_service_mesh()
        mesh_services = []
        
        if mesh_type == ServiceMeshType.ISTIO:
            mesh_services = await self.discover_istio_services()
        elif mesh_type == ServiceMeshType.LINKERD:
            mesh_services = await self.discover_linkerd_services()
        elif mesh_type == ServiceMeshType.CONSUL:
            mesh_services = await self.discover_consul_services()
        
        # Build connections
        pod_connections = self.build_pod_connections(pods, services, network_policies)
        service_deps = self.build_service_dependencies(services, mesh_services)
        
        return ContainerNetworkReport(
            pods=pods,
            services=services,
            network_policies=network_policies,
            ingresses=ingresses,
            docker_networks=docker_networks,
            docker_containers=docker_containers,
            service_mesh_services=mesh_services,
            service_mesh_type=mesh_type,
            pod_to_pod_connections=pod_connections,
            service_dependencies=service_deps,
        )

