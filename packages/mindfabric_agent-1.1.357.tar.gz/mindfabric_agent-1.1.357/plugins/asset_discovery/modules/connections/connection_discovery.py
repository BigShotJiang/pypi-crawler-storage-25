"""
Network connection discovery
"""
import asyncio
import datetime
import ipaddress
import socket
from typing import Dict, List, Any, Optional
import ssl
import os

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger
from ..utils.async_subprocess import run_exec_stdout


class PassiveNetworkDiscovery:
    """
    Passively discovers network hosts through system data sources:
    - Established connections (psutil/netstat)
    - ARP cache
    - /proc/net/* files
    - DNS cache
    """
    
    @staticmethod
    async def discover_hosts(local_ip: str) -> List[Dict[str, Any]]:
        """
        Passively discover network hosts from multiple sources.
        First warms up ARP cache by probing local subnet, then reads system data.
        """
        discovered_hosts = {}  # ip -> host_info
        
        # First, warm up ARP cache by probing subnet
        await PassiveNetworkDiscovery._warm_up_arp_cache(local_ip)
        
        # Method 1: Get hosts from established connections
        conn_hosts = await PassiveNetworkDiscovery._get_hosts_from_connections(local_ip)
        for host in conn_hosts:
            ip = host["ip"]
            if ip not in discovered_hosts:
                discovered_hosts[ip] = host
            else:
                # Merge port info
                discovered_hosts[ip]["ports"].update(host.get("ports", set()))
        
        # Method 2: Get hosts from ARP cache
        arp_hosts = await PassiveNetworkDiscovery._get_hosts_from_arp()
        for host in arp_hosts:
            ip = host["ip"]
            if ip not in discovered_hosts:
                discovered_hosts[ip] = host
            else:
                # Add MAC address if available
                if host.get("mac"):
                    discovered_hosts[ip]["mac"] = host["mac"]
        
        # Method 3: Get hosts from /proc/net/tcp (Linux)
        proc_hosts = await PassiveNetworkDiscovery._get_hosts_from_proc_net(local_ip)
        for host in proc_hosts:
            ip = host["ip"]
            if ip not in discovered_hosts:
                discovered_hosts[ip] = host
            else:
                discovered_hosts[ip]["ports"].update(host.get("ports", set()))
        
        # Convert to list and (optionally) resolve hostnames.
        # IMPORTANT:
        # Reverse DNS can be expensive and can contribute to memory pressure on small instances.
        # AssetDiscoveryPlugin performs bounded PTR enrichment separately; keep this OFF by default.
        result = []
        for ip, host_info in discovered_hosts.items():
            try:
                enable_rdns = str(os.getenv("ASSET_DISCOVERY_PASSIVE_RDNS", "0")).strip().lower() in ("1", "true", "yes", "on")
            except Exception:
                enable_rdns = False
            if enable_rdns and not host_info.get("hostname"):
                host_info["hostname"] = await PassiveNetworkDiscovery._resolve_hostname(ip)
            
            # Convert ports set to list
            if isinstance(host_info.get("ports"), set):
                host_info["open_ports"] = sorted(list(host_info["ports"]))
                del host_info["ports"]
            
            result.append(host_info)
        
        logger.info(f"[PassiveNetworkDiscovery] Found {len(result)} hosts passively")
        return result
    
    @staticmethod
    async def _get_hosts_from_connections(local_ip: str) -> List[Dict[str, Any]]:
        """Get remote hosts from established TCP/UDP connections"""
        hosts = []
        
        if not psutil:
            return hosts
        
        try:
            seen_ips = set()
            
            for conn in psutil.net_connections(kind='inet'):
                if conn.raddr:
                    remote_ip = conn.raddr.ip
                    remote_port = conn.raddr.port
                    
                    # Skip localhost and self
                    if remote_ip in ['127.0.0.1', '::1', 'localhost', local_ip]:
                        continue
                    
                    # Skip external IPs (only keep private network IPs)
                    try:
                        ip_obj = ipaddress.ip_address(remote_ip)
                        if not ip_obj.is_private:
                            continue
                    except:
                        continue
                    
                    if remote_ip not in seen_ips:
                        seen_ips.add(remote_ip)
                        hosts.append({
                            "ip": remote_ip,
                            "hostname": None,
                            "ports": {remote_port},
                            "source": "connection"
                        })
                    else:
                        # Add port to existing host
                        for h in hosts:
                            if h["ip"] == remote_ip:
                                h["ports"].add(remote_port)
                                break
                                
        except Exception as e:
            logger.debug(f"Error getting hosts from connections: {e}")
        
        return hosts
    
    @staticmethod
    async def _get_hosts_from_arp() -> List[Dict[str, Any]]:
        """Get hosts from ARP cache"""
        hosts = []
        
        try:
            # Try reading /proc/net/arp (Linux)
            arp_file = "/proc/net/arp"
            try:
                with open(arp_file, 'r') as f:
                    lines = f.readlines()[1:]  # Skip header
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 4:
                            ip = parts[0]
                            mac = parts[3]
                            
                            # Skip incomplete entries
                            if mac == "00:00:00:00:00:00":
                                continue
                            
                            # Skip localhost
                            if ip.startswith("127."):
                                continue
                            
                            hosts.append({
                                "ip": ip,
                                "hostname": None,
                                "mac": mac,
                                "ports": set(),
                                "source": "arp"
                            })
            except FileNotFoundError:
                # Try arp command as fallback
                out = await run_exec_stdout(["arp", "-a"], timeout=5)
                if out:
                    for line in out.split('\n'):
                        # Parse arp -a output: hostname (ip) at mac ...
                        if '(' in line and ')' in line:
                            try:
                                ip = line.split('(')[1].split(')')[0]
                                if not ip.startswith("127."):
                                    mac_part = line.split(' at ')
                                    mac = mac_part[1].split()[0] if len(mac_part) > 1 else None
                                    hosts.append({
                                        "ip": ip,
                                        "hostname": None,
                                        "mac": mac,
                                        "ports": set(),
                                        "source": "arp"
                                    })
                            except:
                                pass
                                
        except Exception as e:
            logger.debug(f"Error getting hosts from ARP: {e}")
        
        return hosts
    
    @staticmethod
    async def _get_hosts_from_proc_net(local_ip: str) -> List[Dict[str, Any]]:
        """Get hosts from /proc/net/tcp and /proc/net/udp (Linux)"""
        hosts = []
        seen_ips = set()
        
        def hex_to_ip(hex_ip: str) -> str:
            """Convert hex IP to dotted decimal"""
            try:
                # /proc/net/tcp stores IP in little-endian hex
                ip_int = int(hex_ip, 16)
                return socket.inet_ntoa(ip_int.to_bytes(4, byteorder='little'))
            except:
                return None
        
        def hex_to_port(hex_port: str) -> int:
            """Convert hex port to int"""
            try:
                return int(hex_port, 16)
            except:
                return 0
        
        for proc_file in ["/proc/net/tcp", "/proc/net/udp"]:
            try:
                with open(proc_file, 'r') as f:
                    lines = f.readlines()[1:]  # Skip header
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 3:
                            # Remote address is in format IP:PORT (hex)
                            remote_addr = parts[2]
                            if ':' in remote_addr:
                                hex_ip, hex_port = remote_addr.split(':')
                                remote_ip = hex_to_ip(hex_ip)
                                remote_port = hex_to_port(hex_port)
                                
                                if remote_ip and remote_ip not in ['0.0.0.0', '127.0.0.1', local_ip]:
                                    # Check if private IP
                                    try:
                                        if not ipaddress.ip_address(remote_ip).is_private:
                                            continue
                                    except:
                                        continue
                                    
                                    if remote_ip not in seen_ips:
                                        seen_ips.add(remote_ip)
                                        hosts.append({
                                            "ip": remote_ip,
                                            "hostname": None,
                                            "ports": {remote_port} if remote_port else set(),
                                            "source": "proc_net"
                                        })
                                    elif remote_port:
                                        for h in hosts:
                                            if h["ip"] == remote_ip:
                                                h["ports"].add(remote_port)
                                                break
            except FileNotFoundError:
                pass
            except Exception as e:
                logger.debug(f"Error reading {proc_file}: {e}")
        
        return hosts
    
    @staticmethod
    async def _resolve_hostname(ip: str) -> Optional[str]:
        """Try to resolve IP to hostname"""
        try:
            res = await asyncio.wait_for(asyncio.to_thread(socket.gethostbyaddr, ip), timeout=0.8)
            if isinstance(res, tuple) and res and isinstance(res[0], str):
                return res[0]
            return None
        except:
            return None
    
    @staticmethod
    async def _warm_up_arp_cache(local_ip: str) -> None:
        """
        Probe local subnet to populate ARP cache.
        Uses quick TCP connect attempts to common ports.
        """
        try:
            # Calculate subnet hosts (only scan /24 for efficiency)
            parts = local_ip.split('.')
            base_network = f"{parts[0]}.{parts[1]}.{parts[2]}"
            
            logger.info(f"[PassiveNetworkDiscovery] Warming up ARP cache for {base_network}.0/24")
            
            # Common ports to probe
            probe_ports = [22, 80, 443, 5432, 6379, 3306, 8080, 8088, 3000]
            
            async def probe_host(ip: str):
                """Quick probe to populate ARP"""
                for port in probe_ports[:3]:  # Only try first 3 ports
                    try:
                        r, w = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout=0.1)
                        w.close()
                        try:
                            await w.wait_closed()
                        except Exception:
                            pass
                    except:
                        pass
            
            # Probe first 20 IPs in subnet (typical Docker range)
            tasks = []
            for i in range(1, 21):
                target_ip = f"{base_network}.{i}"
                if target_ip != local_ip:
                    tasks.append(probe_host(target_ip))
            
            await asyncio.gather(*tasks, return_exceptions=True)
            
            logger.info(f"[PassiveNetworkDiscovery] ARP cache warm-up complete")
            
        except Exception as e:
            logger.debug(f"Error warming up ARP cache: {e}")


class ConnectionDiscoverer:
    """Discovers network connections between assets"""
    
    def __init__(self, local_asset_id: str = "local"):
        self.local_asset_id = local_asset_id
    
    async def discover_connections(self, discovered_assets: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Discover network connections to other assets"""
        connections = []
        
        if not psutil:
            return connections
        
        try:
            local_asset_id = list(discovered_assets.keys())[0] if discovered_assets else self.local_asset_id
            now = datetime.datetime.utcnow().isoformat()
            
            # Get network connections
            for conn in psutil.net_connections(kind='inet'):
                try:
                    if conn.status != 'ESTABLISHED':
                        continue
                    
                    # Get remote address
                    if conn.raddr:
                        remote_ip = conn.raddr.ip
                        remote_port = conn.raddr.port
                        
                        # Skip localhost connections
                        if remote_ip in ['127.0.0.1', '::1', 'localhost']:
                            continue
                        
                        # Determine connection type
                        conn_type = "network"
                        if remote_port in [5432, 3306, 27017]:  # Database ports
                            conn_type = "dependency"
                        elif remote_port in [6443, 10250]:  # Kubernetes ports
                            conn_type = "cluster"
                        elif remote_port in [9100, 9090, 3000]:  # Monitoring ports
                            conn_type = "service"
                        
                        # Detect protocol - try HTTP headers first, fallback to port
                        protocol = await self.detect_protocol_by_connection(remote_ip, remote_port)
                        if not protocol:
                            # Fallback to port-based detection
                            if remote_port == 80 or remote_port == 443:
                                protocol = "http" if remote_port == 80 else "https"
                            elif remote_port == 5432:
                                protocol = "postgresql"
                            elif remote_port == 3306:
                                protocol = "mysql"
                            elif remote_port == 6379:
                                protocol = "redis"
                            elif remote_port == 27017:
                                protocol = "mongodb"
                        
                        # Get local IP from discovered assets
                        local_ip = None
                        if discovered_assets:
                            local_asset = list(discovered_assets.values())[0]
                            if isinstance(local_asset, dict):
                                local_ip = local_asset.get("ip_address") or local_asset.get("ipAddress")
                        
                        connection = {
                            "from_asset_id": local_asset_id,
                            "to_asset_id": f"asset_{remote_ip.replace('.', '_')}",
                            "from_ip": local_ip,
                            "to_ip": remote_ip,
                            "connection_type": conn_type,
                            "port": remote_port,
                            "protocol": protocol,
                            "discovered_at": now,
                            "last_seen": now,
                            "status": "active"
                        }
                        
                        connections.append(connection)
                except Exception as e:
                    logger.debug(f"Error processing connection: {e}")
                    continue
            
            return connections[:50]  # Limit connections
        except Exception as e:
            logger.exception(f"Error discovering connections: {e}")
            return []
    
    async def detect_protocol_by_connection(self, ip: str, port: int) -> Optional[str]:
        """Detect protocol by trying to connect and analyze headers"""
        try:
            # Only try HTTP/HTTPS for now (most common)
            if port not in [80, 443, 8080, 8443, 3000, 8000, 5000]:
                return None

            async def _http_probe(use_ssl: bool) -> bool:
                ctx = None
                if use_ssl:
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(ip, port, ssl=ctx, server_hostname=ip if ctx else None),
                    timeout=1,
                )
                try:
                    req = (
                        f"GET / HTTP/1.1\r\n"
                        f"Host: {ip}\r\n"
                        f"User-Agent: Mozilla/5.0\r\n"
                        f"Connection: close\r\n\r\n"
                    ).encode("utf-8", errors="ignore")
                    writer.write(req)
                    await writer.drain()
                    raw = await asyncio.wait_for(reader.read(256), timeout=1)
                finally:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                line = (raw or b"").split(b"\r\n", 1)[0].decode("utf-8", errors="ignore")
                # HTTP/1.1 200 OK
                if "HTTP/" in line:
                    try:
                        code = int(line.split()[1])
                        return code in (200, 301, 302, 404)
                    except Exception:
                        return True
                return False

            if port in [80, 8080, 3000, 8000, 5000]:
                try:
                    if await _http_probe(False):
                        return "http"
                except Exception:
                    pass

            if port in [443, 8443]:
                try:
                    if await _http_probe(True):
                        return "https"
                except Exception:
                    pass
        except Exception as e:
            logger.debug(f"Error detecting protocol for {ip}:{port}: {e}")
        
        return None

