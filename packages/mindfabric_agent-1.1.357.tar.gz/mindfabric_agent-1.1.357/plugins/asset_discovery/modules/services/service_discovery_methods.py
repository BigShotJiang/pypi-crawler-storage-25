"""
Service discovery methods - extracted from main plugin
This file contains all the detailed service discovery methods
"""

