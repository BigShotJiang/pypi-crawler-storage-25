"""
Service discovery - main orchestrator
"""
import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import ipaddress
import re
import socket
import html
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from asyncio.subprocess import PIPE

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger
from .service_detectors import ServiceTypeDetector, ServiceVersionDetector
from ..enumerations import APIDiscovery
from ..discovery import DockerKubernetesDiscovery
from ..utils.async_http import fetch


class ServiceDiscoverer:
    """Discovers services using multiple methods"""
    
    def __init__(self, local_hostname: str, local_ip: Optional[str] = None):
        self.local_hostname = local_hostname
        self.local_ip = local_ip or "127.0.0.1"
        self.type_detector = ServiceTypeDetector()
        self.version_detector = ServiceVersionDetector()
    
    @staticmethod
    def _mask_access_key_in_cmd(cmd_str: str) -> str:
        """SECURITY: Mask access keys in command strings to prevent token exposure."""
        if not cmd_str:
            return cmd_str
        # Match --access-key agt-... patterns
        cmd_str = re.sub(r'--access-key\s+agt-[A-Za-z0-9]+', '--access-key ***MASKED***', cmd_str)
        # Match ACCESS_KEY=agt-... patterns
        cmd_str = re.sub(r'ACCESS_KEY\s*=\s*agt-[A-Za-z0-9]+', 'ACCESS_KEY=***MASKED***', cmd_str, flags=re.IGNORECASE)
        # Match access_key: agt-... patterns
        cmd_str = re.sub(r'access_key\s*[:=]\s*agt-[A-Za-z0-9]+', 'access_key=***MASKED***', cmd_str, flags=re.IGNORECASE)
        return cmd_str

    async def _run_cmd(self, args: List[str], *, timeout: float = 5.0) -> Tuple[int, str, str]:
        """
        Async subprocess runner to avoid blocking the agent event loop.
        Returns (returncode, stdout, stderr).
        """
        proc = await asyncio.create_subprocess_exec(*args, stdout=PIPE, stderr=PIPE)
        try:
            out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            try:
                await proc.communicate()
            except Exception:
                pass
            raise
        return int(proc.returncode or 0), (out_b or b"").decode("utf-8", errors="ignore"), (err_b or b"").decode("utf-8", errors="ignore")
    
    async def discover_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Discover services using multiple methods:
        - Process scanning (running processes)
        - Systemd services (including stopped)
        - Docker containers
        - Config file analysis
        - Port scanning with HTTP header analysis
        - API discovery
        """
        from utils.logger import logger
        services = []
        service_ids = set()  # Track unique service IDs
        
        # Method 1: Process scanning
        try:
            process_services = await self._discover_services_from_processes(asset_id)
            for svc in process_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Process scanning failed: {e}")
        
        # Method 2: Systemd services (even if not running)
        try:
            systemd_services = await self._discover_systemd_services(asset_id)
            for svc in systemd_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Systemd discovery failed: {e}")
        
        # Method 3: Docker containers
        try:
            docker_services = await self._discover_docker_services(asset_id)
            for svc in docker_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Docker discovery failed: {e}")
        
        # Method 4: Config file analysis
        try:
            config_services = await self._discover_services_from_configs(asset_id)
            for svc in config_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Config analysis failed: {e}")
        
        # Method 5: Port scanning with HTTP headers
        try:
            port_services = await self._discover_services_from_ports(asset_id)
            for svc in port_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Port scanning failed: {e}")
        
        # Method 6: Analysis using ss command (more accurate port info)
        try:
            ss_services = await self._discover_services_from_ss(asset_id)
            for svc in ss_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"SS command failed: {e}")
        
        # Method 7: Autostart services (cron, systemd timers)
        try:
            autostart_services = await self._discover_autostart_services(asset_id)
            for svc in autostart_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Autostart discovery failed: {e}")
        
        # Method 8: Docker containers with detailed inspection
        try:
            docker_detailed_services = await self._discover_docker_services_detailed(asset_id)
            for svc in docker_detailed_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"Docker detailed discovery failed: {e}")
        
        # Method 9: API endpoints from specifications
        try:
            api_services = await self._discover_api_services(asset_id)
            for svc in api_services:
                if svc["id"] not in service_ids:
                    services.append(svc)
                    service_ids.add(svc["id"])
        except Exception as e:
            logger.debug(f"API discovery failed: {e}")
        
        # Filter out ephemeral ports (32768-65535) - these are client ports, not services
        filtered_services = []
        for svc in services:
            port = svc.get("port")
            # Keep services without port, or with non-ephemeral ports, or with explicit port_direction='outbound'
            if port is None:
                filtered_services.append(svc)
            elif port < 32768:
                filtered_services.append(svc)
            elif svc.get("port_direction") == "outbound" and svc.get("remote_address"):
                # Keep outbound connections to show what the service connects to
                filtered_services.append(svc)
            # else: skip ephemeral inbound ports - they're not real services
        
        # Final normalization: ensure all sshd variants are unified to "sshd"
        # This prevents duplicates like "sshd", "sshd:", "sshd: [accepted]", etc.
        normalized_services = []
        seen_sshd = set()  # Track (port, protocol) for sshd services to deduplicate
        
        for svc in filtered_services:
            service_name = svc.get("name", "")
            
            # Normalize sshd service names
            if service_name and 'sshd' in service_name.lower():
                # Extract base name before any colon or bracket
                if ':' in service_name:
                    service_name = service_name.split(':')[0].strip()
                if '[' in service_name:
                    service_name = service_name.split('[')[0].strip()
                # Final normalization: ensure it's exactly "sshd"
                if service_name.lower().startswith('sshd'):
                    service_name = 'sshd'
                    svc["name"] = 'sshd'
                
                # Deduplicate sshd services by port and protocol
                # If we already have an sshd service on the same port, skip this one
                port = svc.get("port")
                protocol = svc.get("protocol", "tcp")
                sshd_key = (port, protocol)
                
                if sshd_key in seen_sshd:
                    # Skip duplicate sshd service
                    continue
                seen_sshd.add(sshd_key)
            
            normalized_services.append(svc)
        
        return normalized_services[:250]
    
    async def _discover_services_from_processes(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services from running processes"""
        services = []
        
        if not psutil:
            return services
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'username', 'cmdline']):
                try:
                    proc_info = proc.info
                    service_name = proc_info['name']
                    
                    # Filter out child processes of multi-process services (e.g., sshd: [accepted], sshd: [net])
                    # These are child processes and should not be treated as separate services
                    if ':' in service_name and '[' in service_name:
                        # This is a child process (e.g., "sshd: [accepted]", "sshd: [net]", "sshd: root [priv]")
                        continue
                    
                    # Try to get full name from cmdline (proc.name is limited to 15 chars in Linux)
                    # Extract the actual executable name from cmdline to avoid truncation
                    cmdline = proc_info.get('cmdline', [])
                    if cmdline:
                        full_name = None
                        first_cmd = cmdline[0] if cmdline else ""
                        
                        if first_cmd:
                            # Check if first command is a Python interpreter
                            is_python = 'python' in first_cmd.lower() or first_cmd.endswith('python') or first_cmd.endswith('python3')
                            
                            if is_python:
                                # Look for the script name in remaining args
                                # Skip flags and find the first non-flag argument that looks like an executable
                                for arg in cmdline[1:]:
                                    if not arg or arg.startswith('-'):
                                        continue
                                    # Extract basename if it's a path
                                    candidate = arg.split('/')[-1] if '/' in arg else arg
                                    # Use if it's longer than truncated name (more accurate)
                                    if candidate and len(candidate) > len(service_name):
                                        full_name = candidate
                                        break
                            else:
                                # First element is the executable itself
                                if '/' in first_cmd:
                                    full_name = first_cmd.split('/')[-1]
                                else:
                                    full_name = first_cmd
                        
                        # Use full name if it's longer than truncated proc.name (more accurate)
                        if full_name and len(full_name) > len(service_name):
                            service_name = full_name
                    
                    # Normalize sshd service names: all variants (sshd, sshd:, sshd: [accepted], etc.) → "sshd"
                    # This ensures we only have one sshd service entry instead of multiple variants
                    if service_name and 'sshd' in service_name.lower():
                        # Extract base name before any colon or bracket
                        if ':' in service_name:
                            service_name = service_name.split(':')[0].strip()
                        # Also handle cases like "sshd [accepted]" (without colon)
                        if '[' in service_name:
                            service_name = service_name.split('[')[0].strip()
                        # Final normalization: ensure it's exactly "sshd"
                        if service_name.lower().startswith('sshd'):
                            service_name = 'sshd'
                    
                    # Skip system processes
                    if service_name in ['systemd', 'kernel', 'kthreadd', 'systemd-journald', 'systemd-logind']:
                        continue
                    
                    # Detect service type
                    service_type = self.type_detector.detect_service_type(service_name, proc_info.get('cmdline', []))
                    
                    # Get port information
                    port = None
                    protocol = None
                    port_direction = None  # 'inbound' (LISTEN) or 'outbound' (client connection)
                    remote_address = None
                    inbound_peers: List[str] = []

                    def _is_internal_ip(ip_str: str) -> bool:
                        """
                        Conservative internal/VPC check.
                        - RFC1918 private ranges
                        - RFC6598 CGNAT (100.64.0.0/10) can appear in some VPCs/tunnels
                        """
                        try:
                            ip = ipaddress.ip_address(str(ip_str).strip())
                            if ip.is_loopback or ip.is_link_local or ip.is_multicast:
                                return False
                            if isinstance(ip, ipaddress.IPv4Address):
                                if ip.is_private:
                                    return True
                                # RFC6598: 100.64.0.0/10
                                if ip in ipaddress.ip_network("100.64.0.0/10"):
                                    return True
                            # IPv6 private ULA (fc00::/7)
                            if isinstance(ip, ipaddress.IPv6Address):
                                if ip in ipaddress.ip_network("fc00::/7"):
                                    return True
                        except Exception:
                            return False
                        return False

                    try:
                        conns = proc.net_connections() if hasattr(proc, 'net_connections') else (proc.connections() if hasattr(proc, 'connections') else [])
                        if conns:
                            for conn in conns:
                                if conn.status == 'LISTEN' and conn.laddr:
                                    port = conn.laddr.port
                                    protocol = 'tcp' if conn.type == socket.SOCK_STREAM else 'udp'
                                    port_direction = 'inbound'
                                    remote_address = None
                                    break

                                # IMPORTANT:
                                # Do NOT treat every ESTABLISHED connection as outbound.
                                # For server processes (e.g. sshd/nginx), ESTABLISHED often means an inbound client connection.
                                # Heuristic:
                                # - outbound: local port is ephemeral (>=32768) AND remote port is non-ephemeral (<32768)
                                # - inbound: local port is non-ephemeral (<32768) AND remote port is ephemeral (>=32768)
                                # This prevents public Internet scanners from being materialized as "assets" in Asset Discovery.
                                if conn.status == 'ESTABLISHED' and conn.laddr and conn.raddr:
                                    lport = getattr(conn.laddr, "port", None)
                                    rport = getattr(conn.raddr, "port", None)
                                    if isinstance(lport, int) and isinstance(rport, int):
                                        l_ephemeral = lport >= 32768
                                        r_ephemeral = rport >= 32768

                                        protocol = 'tcp' if conn.type == socket.SOCK_STREAM else 'udp'

                                        if l_ephemeral and not r_ephemeral:
                                            # Outbound dependency from this host/process -> remote service
                                            port = rport
                                            port_direction = 'outbound'
                                            remote_address = f"{conn.raddr.ip}:{conn.raddr.port}"
                                            break

                                        if (not l_ephemeral) and r_ephemeral:
                                            # Inbound client to a local service port (keep service port; do not emit remoteAddress edge)
                                            port = lport
                                            port_direction = 'inbound'
                                            remote_address = None
                                            # For Asset Graph topology, keep ONLY internal/VPC inbound SSH peers.
                                            # External/public inbound attempts should be represented in Current Threat Graph instead.
                                            try:
                                                rip = str(getattr(conn.raddr, "ip", "") or "").strip()
                                                if rip and _is_internal_ip(rip):
                                                    inbound_peers = [f"{rip}:{int(rport)}"]
                                            except Exception:
                                                inbound_peers = []
                                            break

                                        # Ambiguous case: keep local port if it's non-ephemeral, otherwise ignore remote.
                                        if not l_ephemeral:
                                            port = lport
                                            port_direction = 'inbound'
                                            remote_address = None
                                            break
                    except (psutil.AccessDenied, psutil.NoSuchProcess):
                        pass
                    
                    # Get version
                    version = self.version_detector.get_service_version(service_name, proc_info.get('cmdline', []))
                    
                    # Get detailed process info from /proc
                    proc_details = await self._get_process_details_from_proc(proc_info['pid'])
                    
                    service_id = hashlib.md5(
                        f"process_{service_name}_{proc_info['pid']}".encode()
                    ).hexdigest()[:12]
                    
                    # SECURITY: Mask access keys in command line to prevent token exposure
                    raw_cmd = " ".join(proc_info.get('cmdline', []))[:256] if proc_info.get('cmdline') else None
                    safe_cmd = self._mask_access_key_in_cmd(raw_cmd) if raw_cmd else None
                    
                    # Get process executable path
                    executable_path = None
                    try:
                        executable_path = proc.exe()
                    except (psutil.AccessDenied, psutil.NoSuchProcess):
                        # Fallback to cmdline[0] if available
                        if cmdline and cmdline[0]:
                            executable_path = cmdline[0]
                    
                    # Get process start time
                    start_time = None
                    try:
                        create_time = proc.create_time()
                        if create_time:
                            start_time = datetime.fromtimestamp(create_time, tz=timezone.utc).isoformat()
                    except (psutil.AccessDenied, psutil.NoSuchProcess):
                        pass
                    
                    # Get username
                    username = proc_info.get('username', 'unknown')
                    
                    process_info_dict = {
                        "pid": proc_info['pid'],
                        "user": username,
                        "command": safe_cmd
                    }
                    
                    # Merge /proc details if available
                    if proc_details:
                        process_info_dict.update(proc_details)
                    
                    # Build enhanced description with user, start time, and executable path
                    description_parts = [f"{service_name} service"]
                    if username and username != 'unknown':
                        description_parts.append(f"run by user: {username}")
                    if start_time:
                        description_parts.append(f"started: {start_time}")
                    if executable_path:
                        description_parts.append(f"executable: {executable_path}")
                    
                    description = ". ".join(description_parts)
                    
                    service = {
                        "id": f"s{service_id}",
                        "name": service_name,
                        "asset_id": asset_id or "local",
                        "asset_hostname": self.local_hostname,
                        "asset_ip_address": self.local_ip or "127.0.0.1",
                        "status": "running",
                        "port": port,
                        "protocol": protocol,
                        "port_direction": port_direction,  # 'inbound' or 'outbound'
                        "remote_address": remote_address,  # For outbound connections
                        # Extra (non-persisted) evidence: internal inbound peers (used to draw internal SSH edges)
                        "inbound_peers": inbound_peers,
                        "service_type": service_type,
                        "description": description,
                        "discovery_method": "process-scan",
                        "discovered_at": datetime.utcnow().isoformat(),
                        "last_seen": datetime.utcnow().isoformat(),
                        "version": version,
                        "process_info": process_info_dict,
                        "detection_location": f"{self.local_hostname} ({self.local_ip}) - process PID {proc_info['pid']}",
                        "detection_reason": f"Service discovered through process scanning. Agent identified {service_name} process running."
                    }
                    
                    services.append(service)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                except Exception as e:
                    logger.debug(f"Error processing process: {e}")
                    continue
            
            return services
        except Exception as e:
            logger.exception(f"Error discovering services from processes: {e}")
            return []
    
    async def _discover_systemd_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover systemd services (including stopped ones)"""
        services = []
        
        try:
            # Check if systemd is available
            rc, _, _ = await self._run_cmd(["systemctl", "--version"], timeout=2)
            if rc != 0:
                return services
            
            # List all services
            rc, stdout, _ = await self._run_cmd(
                ["systemctl", "list-units", "--all", "--type=service", "--no-pager", "--no-legend"],
                timeout=5
            )
            
            if rc != 0:
                return services
            
            now = datetime.utcnow().isoformat()
            
            for line in stdout.split('\n'):
                if not line.strip():
                    continue
                
                # Parse: service_name.service  loaded active running  description
                parts = line.split()
                if len(parts) < 4:
                    continue
                
                service_name_full = parts[0]
                if not service_name_full.endswith('.service'):
                    continue
                
                service_name = service_name_full[:-8]  # Remove .service
                status = parts[2] if len(parts) > 2 else "unknown"
                description = " ".join(parts[3:]) if len(parts) > 3 else ""
                
                # Normalize sshd service names: all variants → "sshd"
                if service_name and 'sshd' in service_name.lower():
                    if service_name.lower().startswith('sshd'):
                        service_name = 'sshd'
                
                # Skip system services
                if service_name in ['systemd', 'kernel', 'dbus']:
                    continue
                
                # Determine service status
                service_status = "running" if status == "active" else "stopped"
                
                # Detect service type
                service_type = self.type_detector.detect_service_type(service_name, [service_name])
                
                # Try to get port from service
                port = None
                try:
                    # Check if service has a socket
                    rc, exec_out, _ = await self._run_cmd(
                        ["systemctl", "show", f"{service_name}.service", "-p", "ExecStart"],
                        timeout=2
                    )
                    # Parse port from command line if available
                    if rc == 0:
                        # Try to extract port from common patterns
                        port_match = re.search(r':(\d+)', exec_out)
                        if port_match:
                            port = int(port_match.group(1))
                except:
                    pass
                
                service_id = hashlib.md5(f"systemd_{service_name}".encode()).hexdigest()[:12]
                
                service = {
                    "id": f"s{service_id}",
                    "name": service_name,
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": service_status,
                    "port": port,
                    "protocol": "tcp" if port else None,
                    "service_type": service_type,
                    "description": description or f"{service_name} systemd service",
                    "discovery_method": "config-analysis",
                    "discovered_at": now,
                    "last_seen": now,
                    "config_path": f"/etc/systemd/system/{service_name}.service",
                    "detection_location": f"{self.local_hostname} - systemd unit {service_name_full}",
                    "detection_reason": f"Service discovered through systemd unit analysis. Status: {status}."
                }
                
                services.append(service)
        except FileNotFoundError:
            # systemctl not available
            pass
        except asyncio.TimeoutError:
            # systemctl call timed out
            pass
        except Exception as e:
            logger.debug(f"Error discovering systemd services: {e}")
        
        return services
    
    async def _discover_docker_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services from Docker containers"""
        services = []
        
        try:
            # Check if docker is available
            rc, _, _ = await self._run_cmd(["docker", "--version"], timeout=2)
            if rc != 0:
                return services
            
            # List all containers (including stopped)
            rc, stdout, _ = await self._run_cmd(
                ["docker", "ps", "-a", "--format", "{{.ID}}|{{.Image}}|{{.Status}}|{{.Names}}|{{.Ports}}"],
                timeout=5
            )
            
            if rc != 0:
                return services
            
            now = datetime.utcnow().isoformat()
            
            for line in stdout.split('\n'):
                if not line.strip():
                    continue
                
                parts = line.split('|')
                if len(parts) < 4:
                    continue
                
                container_id = parts[0][:12]  # Short ID
                image = parts[1]
                status = parts[2]
                name = parts[3] if len(parts) > 3 else container_id
                ports_str = parts[4] if len(parts) > 4 else ""
                
                # Determine container status
                is_running = "Up" in status
                service_status = "running" if is_running else "stopped"
                
                # Parse ports
                port = None
                protocol = None
                if ports_str:
                    # Extract port from format like "0.0.0.0:8080->80/tcp"
                    port_match = re.search(r':(\d+)->', ports_str)
                    if port_match:
                        port = int(port_match.group(1))
                        if '/tcp' in ports_str:
                            protocol = "tcp"
                        elif '/udp' in ports_str:
                            protocol = "udp"
                
                # Detect service type from image name
                service_type = self.type_detector.detect_service_type(image.lower(), [image])
                
                service_id = hashlib.md5(f"docker_{container_id}".encode()).hexdigest()[:12]
                
                service = {
                    "id": f"s{service_id}",
                    "name": name,
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": service_status,
                    "port": port,
                    "protocol": protocol,
                    "service_type": service_type,
                    "description": f"Docker container: {image}",
                    "discovery_method": "container-inspection",
                    "discovered_at": now,
                    "last_seen": now,
                    "container_info": {
                        "container_id": container_id,
                        "image": image,
                        "status": status
                    },
                    "detection_location": f"{self.local_hostname} - Docker container {name}",
                    "detection_reason": f"Service discovered through Docker container inspection. Container {name} ({image}) status: {status}."
                }
                
                services.append(service)
        except FileNotFoundError:
            # docker not available
            pass
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug(f"Error discovering Docker services: {e}")
        
        return services
    
    async def _discover_services_from_configs(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services from configuration files"""
        services = []
        config_paths = [
            ("/etc/nginx/sites-enabled/", "nginx", "web"),
            ("/etc/nginx/conf.d/", "nginx", "web"),
            ("/etc/apache2/sites-enabled/", "apache2", "web"),
            ("/etc/httpd/conf.d/", "httpd", "web"),
            ("/etc/systemd/system/", "systemd", "other"),
        ]
        
        now = datetime.utcnow().isoformat()
        
        for config_dir, service_name, service_type in config_paths:
            config_path = Path(config_dir)
            if not config_path.exists():
                continue
            
            try:
                for config_file in config_path.iterdir():
                    if not config_file.is_file():
                        continue
                    
                    try:
                        with open(config_file, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            
                            # Extract port from config
                            port = None
                            port_matches = re.findall(r'listen\s+(\d+)', content, re.IGNORECASE)
                            if port_matches:
                                port = int(port_matches[0])
                            
                            # Extract server name
                            server_match = re.search(r'server_name\s+([^;]+)', content, re.IGNORECASE)
                            server_name = server_match.group(1).strip() if server_match else service_name
                            # nginx often uses "server_name _;" as a catch-all placeholder; don't show "_" as a name.
                            if server_name in ("_", "*", "default_server"):
                                server_name = service_name
                            
                            service_id = hashlib.md5(f"config_{config_file}_{port}".encode()).hexdigest()[:12]
                            
                            # Check if service is running by checking if port is in use
                            status = "stopped"
                            if port:
                                try:
                                    r, w = await asyncio.wait_for(asyncio.open_connection('localhost', port), timeout=0.5)
                                    w.close()
                                    try:
                                        await w.wait_closed()
                                    except Exception:
                                        pass
                                    status = "running"
                                except Exception:
                                    pass
                            
                            service = {
                                "id": f"s{service_id}",
                                "name": server_name,
                                "asset_id": asset_id or "local",
                                "asset_hostname": self.local_hostname,
                                "asset_ip_address": self.local_ip or "127.0.0.1",
                                "status": status,
                                "port": port,
                                "protocol": "http" if port == 80 or port == 443 else "tcp",
                                "service_type": service_type,
                                # Avoid "on server/configured in ..." boilerplate in UI; keep concise.
                                "description": f"{service_name} service",
                                "discovery_method": "config-analysis",
                                "discovered_at": now,
                                "last_seen": now,
                                "config_path": str(config_file),
                                "detection_location": f"{self.local_hostname} - config file {config_file}",
                                "detection_reason": f"Service discovered through configuration file analysis. Found {service_name} configuration in {config_file}."
                            }
                            
                            services.append(service)
                    except (PermissionError, IOError):
                        continue
                    except Exception as e:
                        logger.debug(f"Error reading config {config_file}: {e}")
                        continue
            except PermissionError:
                continue
            except Exception as e:
                logger.debug(f"Error scanning config directory {config_dir}: {e}")
                continue
        
        return services
    
    async def _discover_services_from_ports(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services by scanning open ports and analyzing HTTP headers"""
        services = []
        
        if not psutil:
            return services
        
        try:
            # Get all listening ports
            listening_ports = set()
            for conn in psutil.net_connections(kind='inet'):
                try:
                    if conn.status == 'LISTEN' and conn.laddr:
                        listening_ports.add(conn.laddr.port)
                except (psutil.AccessDenied, AttributeError):
                    continue
            
            now = datetime.utcnow().isoformat()
            common_ports = [80, 443, 8080, 8443, 3000, 8000, 5000, 9000, 3001, 8888]
            
            for port in list(listening_ports) + common_ports:
                # Skip invalid ports
                if port > 65535 or port < 1:
                    continue
                
                # Check if port is actually open
                try:
                    try:
                        r, w = await asyncio.wait_for(asyncio.open_connection('localhost', port), timeout=0.5)
                        w.close()
                        try:
                            await w.wait_closed()
                        except Exception:
                            pass
                        is_open = True
                    except Exception:
                        is_open = False
                    if (not is_open) and port not in listening_ports:
                        continue
                except Exception:
                    continue
                
                # Try to identify service by HTTP headers
                protocol, service_name, version = await self._identify_service_by_headers(port)
                
                if not service_name:
                    # Fallback to port-based identification
                    service_name, protocol = self._identify_service_by_port(port)
                
                service_type = self.type_detector.detect_service_type(service_name, [service_name])
                
                service_id = hashlib.md5(f"port_{port}".encode()).hexdigest()[:12]
                
                service = {
                    "id": f"s{service_id}",
                    "name": service_name or f"service-on-port-{port}",
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": "running",
                    "port": port,
                    "protocol": protocol or "tcp",
                    "port_direction": "inbound",  # Port scan finds listening ports
                    "service_type": service_type,
                    "description": f"Service discovered on port {port}",
                    "discovery_method": "port-scan",
                    "discovered_at": now,
                    "last_seen": now,
                    "version": version,
                    "detection_location": f"{self.local_hostname}:{port}",
                    "detection_reason": f"Service discovered through port scanning and HTTP header analysis on port {port}."
                }

                # If this looks like a web endpoint, probe HTTP status / redirect / title.
                try:
                    if (protocol or "").lower() in ("http", "https") or port in (80, 443, 8080, 8443, 3000, 8000, 5000, 8888, 3001):
                        http_info = await self._probe_http_endpoint(port, preferred_scheme=(protocol or None))
                        if http_info:
                            service["process_info"] = {"http": http_info}
                            # Enrich detection_reason with the most useful fact (keep it short).
                            status_code = http_info.get("status_code")
                            if isinstance(status_code, int):
                                if 300 <= status_code < 400 and http_info.get("redirect_to"):
                                    service["detection_reason"] = (
                                        f"Service discovered through port scanning and HTTP header analysis on port {port}. "
                                        f"HTTP {status_code} redirect to {http_info.get('redirect_to')}."
                                    )
                                elif status_code == 200 and http_info.get("title"):
                                    service["detection_reason"] = (
                                        f"Service discovered through port scanning and HTTP header analysis on port {port}. "
                                        f"HTTP 200, title: {http_info.get('title')}."
                                    )
                                else:
                                    service["detection_reason"] = (
                                        f"Service discovered through port scanning and HTTP header analysis on port {port}. "
                                        f"HTTP {status_code}."
                                    )
                except Exception as e:
                    logger.debug(f"HTTP probe failed on port {port}: {e}")
                
                services.append(service)
        except Exception as e:
            logger.debug(f"Error discovering services from ports: {e}")
        
        return services

    async def _probe_http_endpoint(self, port: int, preferred_scheme: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Probe local HTTP endpoint without following redirects.
        Returns:
          {
            "url": "http://localhost:80",
            "scheme": "http"|"https",
            "status_code": int,
            "redirect_to": str|None,
            "title": str|None,
            "headers": {str: str}  # sanitized, capped
          }
        """
        def _extract_title(body_text: str) -> Optional[str]:
            try:
                m = re.search(r"<title[^>]*>(.*?)</title>", body_text, re.IGNORECASE | re.DOTALL)
                if not m:
                    return None
                t = m.group(1)
                t = re.sub(r"\s+", " ", t).strip()
                t = html.unescape(t)
                return t[:200] if t else None
            except Exception:
                return None

        schemes = []
        if preferred_scheme and str(preferred_scheme).lower() in ("http", "https"):
            schemes.append(str(preferred_scheme).lower())
        # Try both; some apps run HTTP on 443/8443 in dev, etc.
        for s in ("http", "https"):
            if s not in schemes:
                schemes.append(s)

        for scheme in schemes:
            url = f"{scheme}://localhost:{port}"
            try:
                status_code, headers_lc, body_b = await fetch(
                    url,
                    headers={
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    },
                    timeout=2,
                    max_bytes=65536,
                )
                if not isinstance(status_code, int):
                    continue

                title = None
                try:
                    content_type = ((headers_lc or {}).get("content-type") or "").lower()
                    if status_code == 200 and ("text/html" in content_type or "application/xhtml" in content_type or not content_type):
                        body_txt = (body_b or b"").decode("utf-8", errors="ignore")
                        title = _extract_title(body_txt)
                except Exception:
                    pass

                redirect_to = (headers_lc or {}).get("location")

                safe_headers: Dict[str, str] = {}
                try:
                    for k, v in list((headers_lc or {}).items())[:40]:
                        key = str(k)
                        val = str(v)
                        lk = key.lower()
                        if lk in ("set-cookie", "cookie", "authorization", "proxy-authorization", "x-api-key"):
                            val = "***"
                        if len(val) > 240:
                            val = val[:240] + "…"
                        safe_headers[key] = val
                except Exception:
                    safe_headers = {}

                return {
                    "url": url,
                    "scheme": scheme,
                    "status_code": status_code,
                    "redirect_to": redirect_to,
                    "title": title,
                    "headers": safe_headers,
                }
            except Exception:
                continue

        return None
    
    async def _identify_service_by_headers(self, port: int) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """Identify service by HTTP headers"""
        protocol = None
        service_name = None
        version = None
        
        try:
            # Try HTTP first
            url = f"http://localhost:{port}"
            status, headers_lc, _ = await fetch(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=2, max_bytes=1024)
            if isinstance(status, int):
                protocol = "http"
                headers = {k.title(): v for k, v in (headers_lc or {}).items()}

                # Check Server header
                if 'Server' in headers:
                    server_header = headers['Server']
                    # Extract name and version: "nginx/1.18.0"
                    match = re.match(r'([^/]+)(?:/([\d.]+))?', server_header)
                    if match:
                        service_name = match.group(1).strip().lower()
                        version = match.group(2) if match.group(2) else None

                # Check X-Powered-By header (PHP, ASP.NET)
                if not service_name and 'X-Powered-By' in headers:
                    service_name = headers['X-Powered-By'].split('/')[0].strip().lower()

                # Check X-Served-By header
                if not service_name and 'X-Served-By' in headers:
                    service_name = headers['X-Served-By'].strip().lower()

                return protocol, service_name, version
            
            # Try HTTPS
            try:
                url = f"https://localhost:{port}"
                status2, headers2_lc, _ = await fetch(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=2, max_bytes=1024)
                if isinstance(status2, int):
                    protocol = "https"
                    headers2 = {k.title(): v for k, v in (headers2_lc or {}).items()}

                    if 'Server' in headers2:
                        server_header = headers2['Server']
                        match = re.match(r'([^/]+)(?:/([\d.]+))?', server_header)
                        if match:
                            service_name = match.group(1).strip().lower()
                            version = match.group(2) if match.group(2) else None

                    return protocol, service_name, version
            except Exception:
                pass
        except Exception as e:
            logger.debug(f"Error identifying service by headers on port {port}: {e}")
        
        return protocol, service_name, version
    
    def _identify_service_by_port(self, port: int) -> Tuple[str, str]:
        """Identify service by common port"""
        port_services = {
            80: ("nginx", "http"),
            443: ("nginx", "https"),
            3306: ("mysql", "mysql"),
            5432: ("postgresql", "postgresql"),
            27017: ("mongodb", "mongodb"),
            6379: ("redis", "redis"),
            8080: ("web-server", "http"),
            8443: ("web-server", "https"),
            3000: ("node-app", "http"),
            5000: ("flask-app", "http"),
            8000: ("django-app", "http"),
            9000: ("php-fpm", "tcp"),
            9090: ("prometheus", "http"),
            9100: ("node-exporter", "http"),
        }
        
        service_name, protocol = port_services.get(port, (f"service-{port}", "tcp"))
        return service_name, protocol
    
    async def _discover_services_from_ss(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services using ss command (more accurate than psutil)"""
        services = []
        
        try:
            # Try to use ss command (modern replacement for netstat)
            rc, stdout, _ = await self._run_cmd(["ss", "-tulpn"], timeout=10)
            
            if rc != 0:
                return services
            
            now = datetime.utcnow().isoformat()
            seen_ports = set()
            
            # Parse ss output
            # Format: State   Recv-Q   Send-Q   Local Address:Port   Peer Address:Port   Process
            # Example: LISTEN  0        128      0.0.0.0:22           0.0.0.0:*           users:(("sshd",pid=1234,fd=3))
            for line in stdout.split('\n')[1:]:  # Skip header
                if not line.strip():
                    continue
                
                parts = line.split()
                if len(parts) < 5:
                    continue
                
                state = parts[0]
                local_addr = parts[3]
                
                # Parse address:port
                if ':' not in local_addr:
                    continue
                
                addr_part, port_part = local_addr.rsplit(':', 1)
                try:
                    port = int(port_part)
                except ValueError:
                    continue
                
                # Skip if already seen
                if port in seen_ports:
                    continue
                seen_ports.add(port)
                
                # Extract process info from last part
                process_info = ""
                if len(parts) > 4:
                    process_info = " ".join(parts[4:])
                
                # Extract process name and PID
                process_name = None
                pid = None
                proc_match = re.search(r'"([^"]+)"', process_info)
                pid_match = re.search(r'pid=(\d+)', process_info)
                
                if proc_match:
                    process_name = proc_match.group(1)
                if pid_match:
                    pid = int(pid_match.group(1))
                
                # Determine protocol
                protocol = "tcp" if "tcp" in line.lower() else "udp"
                
                # Identify service
                service_name, _ = self._identify_service_by_port(port)
                if process_name:
                    service_name = process_name
                
                # Normalize sshd service names: all variants → "sshd"
                if service_name and 'sshd' in service_name.lower():
                    if ':' in service_name:
                        service_name = service_name.split(':')[0].strip()
                    if '[' in service_name:
                        service_name = service_name.split('[')[0].strip()
                    if service_name.lower().startswith('sshd'):
                        service_name = 'sshd'
                
                service_type = self.type_detector.detect_service_type(service_name or "", [])
                
                service_id = hashlib.md5(f"ss_{port}_{pid or 0}".encode()).hexdigest()[:12]
                
                # Determine direction based on state
                port_direction = "inbound" if state == "LISTEN" else "outbound"
                
                service = {
                    "id": f"s{service_id}",
                    "name": service_name or f"service-on-port-{port}",
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": "running" if state == "LISTEN" else "stopped",
                    "port": port,
                    "protocol": protocol,
                    "port_direction": port_direction,
                    "service_type": service_type,
                    "description": f"Service discovered via ss on port {port}",
                    "discovery_method": "network-analysis",
                    "discovered_at": now,
                    "last_seen": now,
                    "process_info": {
                        "pid": pid,
                        "user": "unknown",
                        "command": self._mask_access_key_in_cmd(process_info[:256]) if process_info else None
                    } if pid else None,
                    "detection_location": f"{self.local_hostname}:{port} (via ss)",
                    "detection_reason": f"Service discovered through ss command. Port {port} is in {state} state."
                }
                
                services.append(service)
        except FileNotFoundError:
            # ss command not available
            pass
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug(f"Error discovering services from ss: {e}")
        
        return services
    
    async def _discover_autostart_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services from autostart (cron, systemd timers)"""
        services = []
        now = datetime.utcnow().isoformat()
        
        # Discover cron jobs
        cron_services = await self._discover_cron_services(asset_id, now)
        services.extend(cron_services)
        
        # Discover systemd timers
        timer_services = await self._discover_systemd_timers(asset_id, now)
        services.extend(timer_services)
        
        return services
    
    async def _discover_cron_services(self, asset_id: Optional[str], now: str) -> List[Dict[str, Any]]:
        """Discover services from cron jobs"""
        services = []
        
        cron_paths = [
            "/etc/crontab",
            "/etc/cron.d",
            "/var/spool/cron/crontabs",
            "/var/spool/cron"
        ]
        
        for cron_path in cron_paths:
            path = Path(cron_path)
            if not path.exists():
                continue
            
            try:
                if path.is_file():
                    # Single file
                    services.extend(await self._parse_cron_file(path, asset_id, now))
                elif path.is_dir():
                    # Directory - scan all files
                    for file_path in path.iterdir():
                        if file_path.is_file():
                            services.extend(await self._parse_cron_file(file_path, asset_id, now))
            except (PermissionError, IOError):
                continue
            except Exception as e:
                logger.debug(f"Error scanning cron path {cron_path}: {e}")
                continue
        
        return services
    
    async def _parse_cron_file(self, cron_file: Path, asset_id: Optional[str], now: str) -> List[Dict[str, Any]]:
        """Parse a single cron file"""
        services = []
        
        try:
            with open(cron_file, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    
                    # Skip comments and empty lines
                    if not line or line.startswith('#'):
                        continue
                    
                    # Skip variable definitions
                    if '=' in line and not any(char in line for char in ['*', '/', '-', ',']):
                        continue
                    
                    # Parse cron line: minute hour day month weekday command
                    # Example: 0 * * * * /usr/bin/service
                    parts = line.split()
                    if len(parts) < 6:
                        continue
                    
                    schedule = " ".join(parts[:5])
                    command = " ".join(parts[5:])
                    
                    # Extract service name from command
                    # Try to find executable name
                    cmd_parts = command.split()
                    if not cmd_parts:
                        continue
                    
                    executable = Path(cmd_parts[0]).name
                    if not executable:
                        continue
                    
                    # Skip if it's a script execution
                    if executable.endswith('.sh') or executable.endswith('.py'):
                        # Try to find service name in path or script name
                        executable = executable.replace('.sh', '').replace('.py', '')
                    
                    service_type = self.type_detector.detect_service_type(executable, cmd_parts)
                    
                    service_id = hashlib.md5(f"cron_{cron_file}_{line_num}_{executable}".encode()).hexdigest()[:12]
                    
                    service = {
                        "id": f"s{service_id}",
                        "name": executable,
                        "asset_id": asset_id or "local",
                        "asset_hostname": self.local_hostname,
                        "asset_ip_address": self.local_ip or "127.0.0.1",
                        "status": "stopped",  # Cron jobs are not always running
                        "port": None,
                        "protocol": None,
                        "service_type": service_type,
                        "description": f"Scheduled service via cron: {command[:100]}",
                        "discovery_method": "config-analysis",
                        "discovered_at": now,
                        "last_seen": now,
                        "config_path": str(cron_file),
                        "environment": {
                            "schedule": schedule,
                            "command": self._mask_access_key_in_cmd(command[:200])
                        },
                        "detection_location": f"{cron_file}:{line_num}",
                        "detection_reason": f"Service discovered through cron job analysis. Scheduled to run: {schedule}"
                    }
                    
                    services.append(service)
        except (PermissionError, IOError):
            pass
        except Exception as e:
            logger.debug(f"Error parsing cron file {cron_file}: {e}")
        
        return services
    
    async def _discover_systemd_timers(self, asset_id: Optional[str], now: str) -> List[Dict[str, Any]]:
        """Discover services from systemd timers"""
        services = []
        
        try:
            rc, stdout, _ = await self._run_cmd(
                ["systemctl", "list-timers", "--all", "--no-pager", "--no-legend"],
                timeout=5
            )
            
            if rc != 0:
                return services
            
            for line in stdout.split('\n'):
                if not line.strip():
                    continue
                
                # Parse: NEXT                         LEFT          LAST                         PASSED       UNIT                         ACTIVATES
                # Example: Mon 2025-01-20 12:00:00 UTC 2h left      Mon 2025-01-20 10:00:00 UTC 2h ago      systemd-tmpfiles-clean.timer    systemd-tmpfiles-clean.service
                parts = line.split()
                if len(parts) < 6:
                    continue
                
                unit = parts[4] if len(parts) > 4 else None
                activates = parts[5] if len(parts) > 5 else None
                
                if not unit or not activates:
                    continue
                
                # Get service details
                _, show_out, _ = await self._run_cmd(
                    ["systemctl", "show", activates, "-p", "ExecStart", "-p", "Description"],
                    timeout=2
                )
                
                exec_start = ""
                description = ""
                for line in show_out.split('\n'):
                    if line.startswith('ExecStart='):
                        exec_start = line.split('=', 1)[1]
                    elif line.startswith('Description='):
                        description = line.split('=', 1)[1]
                
                # Extract service name
                service_name = activates.replace('.service', '').replace('.timer', '')
                service_type = self.type_detector.detect_service_type(service_name, [exec_start] if exec_start else [])
                
                service_id = hashlib.md5(f"timer_{unit}".encode()).hexdigest()[:12]
                
                service = {
                    "id": f"s{service_id}",
                    "name": service_name,
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": "stopped",  # Timers trigger services, they're not always running
                    "port": None,
                    "protocol": None,
                    "service_type": service_type,
                    "description": description or f"Scheduled service via systemd timer: {unit}",
                    "discovery_method": "config-analysis",
                    "discovered_at": now,
                    "last_seen": now,
                    "config_path": f"/etc/systemd/system/{unit}",
                    "detection_location": f"systemd timer {unit}",
                    "detection_reason": f"Service discovered through systemd timer analysis. Timer {unit} activates {activates}."
                }
                
                services.append(service)
        except FileNotFoundError:
            pass
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug(f"Error discovering systemd timers: {e}")
        
        return services
    
    async def _get_process_details_from_proc(self, pid: int) -> Optional[Dict[str, Any]]:
        """Get detailed process information from /proc filesystem"""
        details = {}
        
        try:
            proc_base = Path(f"/proc/{pid}")
            if not proc_base.exists():
                return None
            
            # Read /proc/[pid]/status for memory and capabilities
            status_file = proc_base / "status"
            if status_file.exists():
                try:
                    with open(status_file, 'r') as f:
                        for line in f:
                            if line.startswith('VmRSS:'):
                                # Physical memory in KB
                                rss_kb = int(line.split()[1])
                                details["memory_mb"] = round(rss_kb / 1024, 2)
                            elif line.startswith('Threads:'):
                                details["threads"] = int(line.split()[1])
                            elif line.startswith('CapEff:'):
                                # Effective capabilities (hex)
                                cap_hex = line.split()[1]
                                details["capabilities"] = cap_hex
                except (PermissionError, IOError, ValueError):
                    pass
            
            # Read /proc/[pid]/stat for CPU time and other stats
            stat_file = proc_base / "stat"
            if stat_file.exists():
                try:
                    with open(stat_file, 'r') as f:
                        stat_data = f.read().split()
                        if len(stat_data) >= 14:
                            # utime (14), stime (15) in clock ticks
                            utime = int(stat_data[13])
                            stime = int(stat_data[14])
                            # Convert to seconds (assuming 100 Hz clock)
                            details["cpu_time_user"] = round(utime / 100.0, 2)
                            details["cpu_time_system"] = round(stime / 100.0, 2)
                            # num_threads (20)
                            if len(stat_data) >= 20:
                                details["threads_from_stat"] = int(stat_data[19])
                except (PermissionError, IOError, ValueError, IndexError):
                    pass
            
            # Read /proc/[pid]/io for I/O statistics
            io_file = proc_base / "io"
            if io_file.exists():
                try:
                    with open(io_file, 'r') as f:
                        for line in f:
                            if line.startswith('read_bytes:'):
                                read_bytes = int(line.split()[1])
                                details["io_read_bytes"] = read_bytes
                            elif line.startswith('write_bytes:'):
                                write_bytes = int(line.split()[1])
                                details["io_write_bytes"] = write_bytes
                except (PermissionError, IOError, ValueError):
                    pass
            
            # Check network namespace to detect containers
            ns_net = proc_base / "ns" / "net"
            if ns_net.exists():
                try:
                    init_ns_net = Path("/proc/1/ns/net")
                    if init_ns_net.exists():
                        # Compare inode numbers
                        if ns_net.stat().st_ino != init_ns_net.stat().st_ino:
                            details["in_container"] = True
                            details["network_namespace"] = str(ns_net.stat().st_ino)
                except (PermissionError, IOError):
                    pass
            
            # Count open file descriptors
            fd_dir = proc_base / "fd"
            if fd_dir.exists():
                try:
                    fd_count = len(list(fd_dir.iterdir()))
                    details["open_files_count"] = fd_count
                except (PermissionError, IOError, OSError):
                    # EINVAL on some kernels/containers for odd proc entries
                    pass
            
        except (PermissionError, IOError, OSError) as e:
            # Handle permission errors gracefully (e.g., /proc/1/map_files requires special permissions)
            # This is expected for system processes and containers
            logger.debug(f"Permission/IO error getting process details from /proc/{pid}: {e}")
        except Exception as e:
            logger.debug(f"Error getting process details from /proc/{pid}: {e}")
        
        return details if details else None
    
    async def _discover_docker_services_detailed(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover Docker containers with detailed information"""
        services = []
        now = datetime.utcnow().isoformat()
        
        try:
            containers = await DockerKubernetesDiscovery.discover_docker_containers_detailed()
            
            for container in containers:
                service_id = hashlib.md5(
                    f"docker_detailed_{container['container_id']}".encode()
                ).hexdigest()[:12]
                
                # Extract port from network settings
                port = None
                protocol = None
                if container.get("ports"):
                    for port_mapping in container["ports"].values():
                        if port_mapping and len(port_mapping) > 0:
                            port = int(port_mapping[0]["HostPort"])
                            protocol = "tcp"
                            break
                
                service = {
                    "id": f"s{service_id}",
                    "name": container.get("name", container.get("container_id", "unknown")),
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": container.get("status", "unknown"),
                    "port": port,
                    "protocol": protocol,
                    "service_type": "container",
                    "description": f"Docker container: {container.get('image', 'unknown')}",
                    "discovery_method": "docker-inspection",
                    "discovered_at": now,
                    "last_seen": now,
                    "version": None,
                    # IMPORTANT:
                    # - Keep the full "picture" (mounts/networks/resource_limits/health_check) for DB persistence,
                    #   but NEVER send raw env var values from the agent.
                    # - We mask env values here and let backend deduplicate services/records.
                    "container_info": {
                        "container_id": container.get("container_id"),
                        "image": container.get("image"),
                        "command": self._mask_access_key_in_cmd((container.get("command") or "")[:256]) if isinstance(container.get("command"), str) else container.get("command"),
                        "ports": container.get("ports"),
                        # Preserve details (useful for infra intelligence), but env is masked.
                        "networks": container.get("networks", {}),
                        "mounts": container.get("mounts", []),
                        "resource_limits": container.get("resource_limits", {}),
                        "health_check": container.get("health_check"),
                        "environment": self._mask_env_values(container.get("environment") or {}),
                    },
                    "detection_location": f"Docker container {container.get('container_id')}",
                    "detection_reason": f"Container discovered through detailed Docker inspection (env values masked on agent)."
                }
                
                services.append(service)
        except Exception as e:
            logger.debug(f"Error in detailed Docker discovery: {e}")
        
        return services

    def _mask_env_values(self, env: Any) -> Dict[str, Any]:
        """
        Mask environment variable values so the agent never sends plaintext secrets.
        Keeps keys, masks values with a stable shape (start/end visible) for debugging.
        """
        if not isinstance(env, dict):
            return {}

        def mask(v: Any) -> Any:
            if v is None:
                return None
            if isinstance(v, (int, float, bool)):
                # primitives can be kept as-is; they aren't secrets typically
                return v
            s = str(v)
            if not s:
                return ""
            if len(s) <= 6:
                return "*" * len(s)
            return f"{s[:2]}***{s[-2:]}"

        out: Dict[str, Any] = {}
        for k, v in env.items():
            try:
                out[str(k)] = mask(v)
            except Exception:
                out[str(k)] = "***"
        return out
    
    async def _discover_api_services(self, asset_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Discover services from API specifications"""
        services = []
        now = datetime.utcnow().isoformat()
        
        try:
            # Discover API endpoints
            api_endpoints = await APIDiscovery.discover_api_endpoints(root_dir="/", max_files=100)
            
            # Group endpoints by base URL/protocol
            grouped = {}
            for endpoint in api_endpoints:
                if endpoint.get("discovered_from") == "spec_file":
                    key = f"{endpoint.get('protocol', 'unknown')}_{endpoint.get('spec_file', 'unknown')}"
                    if key not in grouped:
                        grouped[key] = {
                            "endpoints": [],
                            "protocol": endpoint.get("protocol"),
                            "spec_file": endpoint.get("spec_file")
                        }
                    grouped[key]["endpoints"].append(endpoint)
            
            # Create service for each API specification
            for key, group in grouped.items():
                endpoints = group["endpoints"]
                if not endpoints:
                    continue
                
                service_id = hashlib.md5(f"api_{key}".encode()).hexdigest()[:12]
                
                # Determine port from first endpoint if available
                port = None
                first_endpoint = endpoints[0]
                if first_endpoint.get("full_url"):
                    url = first_endpoint["full_url"]
                    port_match = re.search(r':(\d+)', url)
                    if port_match:
                        port = int(port_match.group(1))
                
                # Determine service type
                protocol = group.get("protocol", "unknown")
                service_type = "web"
                if protocol == "gRPC":
                    service_type = "other"
                elif protocol == "GraphQL":
                    service_type = "web"
                elif protocol == "SOAP":
                    service_type = "web"
                
                service = {
                    "id": f"s{service_id}",
                    "name": f"API Service ({protocol})",
                    "asset_id": asset_id or "local",
                    "asset_hostname": self.local_hostname,
                    "asset_ip_address": self.local_ip or "127.0.0.1",
                    "status": "running",  # API spec suggests running service
                    "port": port,
                    "protocol": protocol.lower() if protocol != "gRPC" else "grpc",
                    "service_type": service_type,
                    "description": f"API service discovered from {Path(group['spec_file']).name}. {len(endpoints)} endpoints found.",
                    "discovery_method": "api-spec-analysis",
                    "discovered_at": now,
                    "last_seen": now,
                    "version": first_endpoint.get("spec_version"),
                    "process_info": {
                        "spec_file": group["spec_file"],
                        "endpoint_count": len(endpoints),
                        "endpoints": endpoints[:10],  # Limit to first 10 endpoints
                        "operations": [ep.get("operation_id") or ep.get("method") or ep.get("query") for ep in endpoints[:10]]
                    },
                    "detection_location": f"Specification file: {group['spec_file']}",
                    "detection_reason": f"API service discovered through specification file analysis. Found {len(endpoints)} API endpoints defined in the specification."
                }
                
                services.append(service)
        except Exception as e:
            logger.debug(f"Error in API discovery: {e}")
        
        return services

