"""
Service discovery modules
"""
from .service_discovery import ServiceDiscoverer
from .service_detectors import ServiceTypeDetector, ServiceVersionDetector

__all__ = [
    'ServiceDiscoverer',
    'ServiceTypeDetector',
    'ServiceVersionDetector',
]

# Import will be completed as methods are moved to separate files

