"""
Service type and version detection utilities
"""
import re
from typing import List, Optional


class ServiceTypeDetector:
    """Detects service type from service name and command line"""
    
    @staticmethod
    def detect_service_type(service_name: str, cmdline: List[str]) -> str:
        """Detect service type"""
        service_lower = service_name.lower()
        cmdline_str = " ".join(cmdline).lower() if cmdline else ""
        
        # Database services
        if any(x in service_lower for x in ['postgres', 'mysql', 'mongo', 'redis', 'elasticsearch']):
            if 'redis' in service_lower or 'memcache' in service_lower:
                return "cache"
            return "database"
        
        # Web services
        if any(x in service_lower for x in ['nginx', 'apache', 'httpd', 'caddy', 'lighttpd']):
            return "web"
        
        # Monitoring services
        if any(x in service_lower for x in ['prometheus', 'grafana', 'influx', 'datadog']):
            return "monitoring"
        
        # Container services
        if any(x in service_lower for x in ['docker', 'containerd', 'kubelet', 'podman']):
            return "container"
        
        return "other"


class ServiceVersionDetector:
    """Detects service version from command line"""
    
    @staticmethod
    def get_service_version(service_name: str, cmdline: List[str]) -> Optional[str]:
        """
        Get service version if available.

        IMPORTANT:
        Avoid subprocess calls here (this runs inside the agent asyncio loop during process scanning).
        We only do best-effort extraction from existing cmdline tokens.
        """
        try:
            if not cmdline:
                return None
            # Look for version-like tokens (e.g. 1.2.3 or 1.2)
            joined = " ".join([str(x) for x in cmdline if x is not None])
            m = re.search(r"\b(\d+\.\d+(?:\.\d+)?)\b", joined)
            if m:
                return m.group(1)
        except Exception:
            return None
        return None

