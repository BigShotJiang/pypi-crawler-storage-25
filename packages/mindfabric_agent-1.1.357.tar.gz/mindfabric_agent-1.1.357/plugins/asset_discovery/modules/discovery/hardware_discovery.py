"""
Hardware specifications discovery
"""
import platform
import asyncio
from typing import Dict, Any, Optional

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger
from ..utils.async_subprocess import run_exec


class HardwareDiscoverer:
    """Discovers hardware specifications"""
    
    async def get_hardware_specs(self) -> Optional[Dict[str, Any]]:
        """Get hardware specifications"""
        if not psutil:
            return None
        
        try:
            hardware = {}
            
            # CPU info
            try:
                cpu_count = psutil.cpu_count(logical=True)
                cpu_percent = psutil.cpu_percent(interval=1)
                
                cpu_info_str = "Unknown CPU"
                try:
                    if platform.system() == "Linux":
                        with open("/proc/cpuinfo", "r") as f:
                            for line in f:
                                if "model name" in line.lower():
                                    cpu_info_str = line.split(":")[1].strip()
                                    break
                    elif platform.system() == "Darwin":  # macOS
                        rc, out, _ = await run_exec(
                            ["sysctl", "-n", "machdep.cpu.brand_string"],
                            timeout=2,
                        )
                        if rc == 0 and out:
                            cpu_info_str = out.strip()
                except:
                    pass
                
                hardware["cpu"] = {
                    "cores": cpu_count,
                    "model": cpu_info_str,
                    "usage_percent": round(cpu_percent, 1)
                }
            except Exception as e:
                logger.debug(f"Error getting CPU info: {e}")
            
            # Memory info
            try:
                memory = psutil.virtual_memory()
                hardware["memory"] = {
                    "total_gb": round(memory.total / (1024**3), 1),
                    "used_gb": round(memory.used / (1024**3), 1),
                    "usage_percent": round(memory.percent, 1)
                }
            except Exception as e:
                logger.debug(f"Error getting memory info: {e}")
            
            # Disk info
            try:
                disk = psutil.disk_usage('/')
                hardware["disk"] = {
                    "total_gb": round(disk.total / (1024**3), 1),
                    "used_gb": round(disk.used / (1024**3), 1),
                    "usage_percent": round((disk.used / disk.total) * 100, 1)
                }
            except Exception as e:
                logger.debug(f"Error getting disk info: {e}")
            
            return hardware if hardware else None
        except Exception as e:
            logger.exception(f"Error getting hardware specs: {e}")
            return None

