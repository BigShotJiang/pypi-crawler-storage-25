"""
Docker and Kubernetes Deep Inspection Module

Provides comprehensive discovery of containerized services including:
- Docker container inspection (layers, env vars, volumes, networks)
- Kubernetes pod/service discovery
- Container network configuration
- Resource limits and health checks
"""

import json
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from utils.logger import logger
from ..utils.async_subprocess import run_exec_stdout


class DockerKubernetesDiscovery:
    """Deep inspection of Docker and Kubernetes containers"""
    
    @staticmethod
    async def discover_docker_containers_detailed() -> List[Dict[str, Any]]:
        """
        Discover Docker containers with detailed information
        
        Returns:
            List of container details including:
            - Image layers
            - Environment variables
            - Mounted volumes
            - Network configuration
            - Resource limits
            - Health checks
        """
        containers = []
        
        try:
            # Get all containers (including stopped)
            out = await run_exec_stdout(["docker", "ps", "-a", "--format", "{{.ID}}"], timeout=10)
            if not out:
                return containers

            container_ids = [line.strip() for line in out.split('\n') if line.strip()]
            
            for container_id in container_ids:
                try:
                    container_info = await DockerKubernetesDiscovery._inspect_container(container_id)
                    if container_info:
                        containers.append(container_info)
                except Exception as e:
                    logger.debug(f"Error inspecting container {container_id}: {e}")
                    continue
                    
        except FileNotFoundError:
            # Docker not available
            pass
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug(f"Error discovering Docker containers: {e}")
        
        return containers
    
    @staticmethod
    async def _inspect_container(container_id: str) -> Optional[Dict[str, Any]]:
        """Inspect a single Docker container in detail"""
        try:
            out = await run_exec_stdout(["docker", "inspect", container_id], timeout=5)
            if not out:
                return None

            inspect_data = json.loads(out)
            if not inspect_data:
                return None
            
            container = inspect_data[0]
            
            # Extract detailed information
            config = container.get("Config", {})
            host_config = container.get("HostConfig", {})
            network_settings = container.get("NetworkSettings", {})
            
            # Environment variables
            env_vars = {}
            for env in config.get("Env", []):
                if "=" in env:
                    key, value = env.split("=", 1)
                    env_vars[key] = value
            
            # Mounted volumes
            mounts = []
            for mount in container.get("Mounts", []):
                mounts.append({
                    "source": mount.get("Source"),
                    "destination": mount.get("Destination"),
                    "type": mount.get("Type"),
                    "read_only": mount.get("RW", True) == False
                })
            
            # Network configuration
            networks = {}
            for network_name, network_data in network_settings.get("Networks", {}).items():
                networks[network_name] = {
                    "ip_address": network_data.get("IPAddress"),
                    "gateway": network_data.get("Gateway"),
                    "mac_address": network_data.get("MacAddress"),
                    "network_id": network_data.get("NetworkID")
                }
            
            # Resource limits
            resources = {}
            if host_config.get("Memory"):
                resources["memory_bytes"] = host_config.get("Memory")
            if host_config.get("CpuShares"):
                resources["cpu_shares"] = host_config.get("CpuShares")
            if host_config.get("CpuQuota"):
                resources["cpu_quota"] = host_config.get("CpuQuota")
            if host_config.get("CpuPeriod"):
                resources["cpu_period"] = host_config.get("CpuPeriod")
            
            # Health check
            health_check = None
            if config.get("Healthcheck"):
                health_check = {
                    "test": config["Healthcheck"].get("Test"),
                    "interval": config["Healthcheck"].get("Interval"),
                    "timeout": config["Healthcheck"].get("Timeout"),
                    "retries": config["Healthcheck"].get("Retries")
                }
            
            # Image layers (approximate via image ID)
            image_id = container.get("Image")
            
            return {
                "container_id": container_id[:12],
                "full_id": container_id,
                "name": container.get("Name", "").lstrip("/"),
                "image": config.get("Image"),
                "image_id": image_id,
                "status": container.get("State", {}).get("Status"),
                "created": container.get("Created"),
                "command": config.get("Cmd"),
                "entrypoint": config.get("Entrypoint"),
                "working_dir": config.get("WorkingDir"),
                "user": config.get("User"),
                "environment": env_vars,
                "mounts": mounts,
                "networks": networks,
                "resource_limits": resources,
                "health_check": health_check,
                "ports": container.get("NetworkSettings", {}).get("Ports", {}),
                "labels": container.get("Config", {}).get("Labels", {})
            }
            
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            logger.debug(f"Error parsing container inspect for {container_id}: {e}")
            return None
        except Exception as e:
            logger.debug(f"Error inspecting container {container_id}: {e}")
            return None
    
    @staticmethod
    async def discover_kubernetes_resources() -> Dict[str, List[Dict[str, Any]]]:
        """
        Discover Kubernetes resources using kubectl
        
        Returns:
            Dictionary with keys: pods, services, configmaps, secrets
        """
        resources = {
            "pods": [],
            "services": [],
            "configmaps": [],
            "secrets": []
        }
        
        # Check if kubectl is available and we're in a cluster
        try:
            out = await run_exec_stdout(["kubectl", "version", "--client", "--short"], timeout=3)
            if not out:
                return resources
        except FileNotFoundError:
            return resources
        except asyncio.TimeoutError:
            return resources
        
        # Discover Pods
        try:
            out = await run_exec_stdout(["kubectl", "get", "pods", "-o", "json", "--all-namespaces"], timeout=10)
            if out:
                pods_data = json.loads(out)
                for pod in pods_data.get("items", []):
                    metadata = pod.get("metadata", {})
                    spec = pod.get("spec", {})
                    status = pod.get("status", {})
                    
                    # Extract container images
                    container_images = []
                    for container in spec.get("containers", []):
                        container_images.append({
                            "name": container.get("name"),
                            "image": container.get("image"),
                            "ports": container.get("ports", [])
                        })
                    
                    resources["pods"].append({
                        "name": metadata.get("name"),
                        "namespace": metadata.get("namespace"),
                        "status": status.get("phase"),
                        "node": spec.get("nodeName"),
                        "containers": container_images,
                        "labels": metadata.get("labels", {}),
                        "creation_timestamp": metadata.get("creationTimestamp")
                    })
        except Exception as e:
            logger.debug(f"Error discovering Kubernetes pods: {e}")
        
        # Discover Services
        try:
            out = await run_exec_stdout(["kubectl", "get", "services", "-o", "json", "--all-namespaces"], timeout=10)
            if out:
                svc_data = json.loads(out)
                for service in svc_data.get("items", []):
                    metadata = service.get("metadata", {})
                    spec = service.get("spec", {})
                    
                    resources["services"].append({
                        "name": metadata.get("name"),
                        "namespace": metadata.get("namespace"),
                        "type": spec.get("type"),
                        "cluster_ip": spec.get("clusterIP"),
                        "ports": spec.get("ports", []),
                        "selector": spec.get("selector", {}),
                        "labels": metadata.get("labels", {})
                    })
        except Exception as e:
            logger.debug(f"Error discovering Kubernetes services: {e}")
        
        # Discover ConfigMaps
        try:
            out = await run_exec_stdout(["kubectl", "get", "configmaps", "-o", "json", "--all-namespaces"], timeout=10)
            if out:
                cm_data = json.loads(out)
                for cm in cm_data.get("items", []):
                    metadata = cm.get("metadata", {})
                    data = cm.get("data", {})
                    
                    resources["configmaps"].append({
                        "name": metadata.get("name"),
                        "namespace": metadata.get("namespace"),
                        "keys": list(data.keys()),
                        "labels": metadata.get("labels", {})
                    })
        except Exception as e:
            logger.debug(f"Error discovering Kubernetes ConfigMaps: {e}")
        
        # Discover Secrets (metadata only, not values)
        try:
            out = await run_exec_stdout(["kubectl", "get", "secrets", "-o", "json", "--all-namespaces"], timeout=10)
            if out:
                secret_data = json.loads(out)
                for secret in secret_data.get("items", []):
                    metadata = secret.get("metadata", {})
                    secret_type = secret.get("type")
                    
                    resources["secrets"].append({
                        "name": metadata.get("name"),
                        "namespace": metadata.get("namespace"),
                        "type": secret_type,
                        "keys": list(secret.get("data", {}).keys()) if secret.get("data") else [],
                        "labels": metadata.get("labels", {})
                    })
        except Exception as e:
            logger.debug(f"Error discovering Kubernetes secrets: {e}")
        
        return resources
    
    @staticmethod
    async def get_container_networks(container_id: str) -> Dict[str, Any]:
        """Get detailed network information for a container"""
        try:
            out = await run_exec_stdout(["docker", "network", "inspect", container_id], timeout=5)
            if out:
                networks = json.loads(out)
                if networks:
                    network = networks[0]
                    return {
                        "name": network.get("Name"),
                        "driver": network.get("Driver"),
                        "ipam": network.get("IPAM", {}),
                        "containers": network.get("Containers", {})
                    }
        except Exception:
            pass
        
        return {}

