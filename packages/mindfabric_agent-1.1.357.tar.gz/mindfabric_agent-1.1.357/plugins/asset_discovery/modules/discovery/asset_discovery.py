"""
Local asset discovery
"""
import datetime
import platform
from typing import Dict, Any, Optional

from ..utils.id_generator import generate_asset_id
from ..utils.ip_utils import get_local_ip
from .provider_detector import ProviderDetector
from .network_discovery import NetworkInterfaceDiscoverer
from .hardware_discovery import HardwareDiscoverer
from utils.logger import logger


class AssetDiscoverer:
    """Discovers local system asset"""
    
    def __init__(self, hostname: str, local_ip: Optional[str] = None):
        self.hostname = hostname
        self.local_ip = local_ip or get_local_ip(hostname)
        self.provider_detector = ProviderDetector()
        self.network_discoverer = NetworkInterfaceDiscoverer(self.local_ip)
        self.hardware_discoverer = HardwareDiscoverer()
    
    async def discover_local_asset(self) -> Optional[Dict[str, Any]]:
        """Discover local system asset"""
        try:
            hostname = self.hostname
            ip_address = self.local_ip or "127.0.0.1"
            asset_id = generate_asset_id(hostname, ip_address)
            
            # Detect OS
            os_name = platform.system()
            os_version = platform.version()
            os_release = platform.release()
            os_full = f"{os_name} {os_release}"
            
            # Detect provider/environment
            provider = await self.provider_detector.detect_provider()
            agent_type = self.provider_detector.detect_agent_type()
            environment = self.provider_detector.detect_environment(hostname)
            
            # Get network interfaces
            network_interfaces = await self.network_discoverer.discover_network_interfaces()
            primary_network = network_interfaces[0]["network"] if network_interfaces else None
            
            # Get hardware specs
            hardware = await self.hardware_discoverer.get_hardware_specs()
            
            # Detect role
            role = self.provider_detector.detect_system_role(hostname)
            
            asset = {
                "id": asset_id,
                "ip_address": ip_address,
                "hostname": hostname,
                "status": "with-agent",
                "provider": provider,
                "os": os_full,
                "agent_type": agent_type,
                "environment": environment,
                "services": [],
                "role": role,
                "last_seen": datetime.datetime.utcnow().strftime("%I:%M:%S %p"),
                "discovered_at": datetime.date.today().isoformat(),
                "network": primary_network,
                "network_interfaces": network_interfaces,
                "tags": self.provider_detector.get_system_tags(provider, role, environment),
                "detection_method": "Agent Discovery",
                "detection_location": f"{hostname} ({ip_address}) - Local agent",
                "detection_reason": f"Asset discovered through local agent running on {os_full}. "
                                   f"Agent detected system running on {provider} infrastructure.",
                "hardware": hardware
            }
            
            return asset
        except Exception as e:
            logger.exception(f"Error discovering local asset: {e}")
            return None

