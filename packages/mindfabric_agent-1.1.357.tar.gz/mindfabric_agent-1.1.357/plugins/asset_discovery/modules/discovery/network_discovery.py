"""
Network interface discovery
"""
import asyncio
import ipaddress
import re
import socket
from typing import Dict, List, Any, Optional
from asyncio.subprocess import PIPE

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger
from ..utils.network_utils import prefix_to_netmask, hex_netmask_to_dotted


class NetworkInterfaceDiscoverer:
    """Discovers network interfaces with detailed information"""
    
    def __init__(self, local_ip: Optional[str] = None):
        self.local_ip = local_ip

    async def _run_cmd(self, args: List[str], *, timeout: float = 5.0) -> Optional[str]:
        """Async subprocess runner (avoid blocking agent event loop). Returns stdout or None."""
        try:
            proc = await asyncio.create_subprocess_exec(*args, stdout=PIPE, stderr=PIPE)
            out_b, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if proc.returncode != 0:
                return None
            return (out_b or b"").decode("utf-8", errors="ignore")
        except Exception:
            return None
    
    async def discover_network_interfaces(self) -> List[Dict[str, Any]]:
        """Discover network interfaces using psutil and ifconfig/ip commands for detailed info"""
        interfaces = []
        
        # First, get basic info from psutil
        basic_interfaces = await self._discover_network_interfaces_psutil()
        
        # Then enhance with detailed info from ifconfig/ip
        detailed_info = await self._get_interface_details_from_system()
        
        # Merge information
        for iface in basic_interfaces:
            interface_name = iface.get("interface")
            if interface_name and interface_name in detailed_info:
                # Merge detailed info
                iface.update(detailed_info[interface_name])
            interfaces.append(iface)
        
        return interfaces
    
    async def _discover_network_interfaces_psutil(self) -> List[Dict[str, Any]]:
        """Discover network interfaces using psutil"""
        interfaces = []
        
        if not psutil:
            return interfaces
        
        try:
            net_if_addrs = psutil.net_if_addrs()
            net_if_stats = psutil.net_if_stats()
            
            for interface_name, addrs in net_if_addrs.items():
                # Skip loopback
                if interface_name.startswith("lo"):
                    continue
                
                interface_data = {
                    "interface": interface_name,
                    "ip_address": None,
                    "network": None,
                    "is_primary": False,
                    "mac_address": None,
                    "netmask": None,
                    "broadcast": None,
                    "mtu": None,
                    "status": "active",
                    "flags": [],
                    "media": None,
                    "link_speed": None,
                    "ipv6": []
                }
                
                # Get interface stats
                if interface_name in net_if_stats:
                    stats = net_if_stats[interface_name]
                    interface_data["mtu"] = stats.mtu
                    interface_data["status"] = "active" if stats.isup else "inactive"
                    if stats.speed > 0:
                        interface_data["link_speed"] = f"{stats.speed}Mbps"
                
                primary_ipv4 = None
                
                # Get AF_LINK/AF_PACKET constant (different on macOS vs Linux)
                try:
                    AF_LINK = socket.AF_LINK  # macOS
                except AttributeError:
                    try:
                        AF_LINK = socket.AF_PACKET  # Linux
                    except AttributeError:
                        AF_LINK = 17  # Fallback to numeric value
                
                for addr in addrs:
                    if addr.family == socket.AF_INET:  # IPv4
                        interface_data["ip_address"] = addr.address
                        if addr.netmask:
                            interface_data["netmask"] = addr.netmask
                            # Calculate network CIDR
                            try:
                                network = ipaddress.IPv4Network(f"{addr.address}/{addr.netmask}", strict=False)
                                interface_data["network"] = str(network)
                            except:
                                pass
                        if addr.broadcast:
                            interface_data["broadcast"] = addr.broadcast
                        primary_ipv4 = addr.address
                    elif addr.family == AF_LINK:  # MAC (AF_LINK on macOS, AF_PACKET on Linux)
                        interface_data["mac_address"] = addr.address
                    elif addr.family == socket.AF_INET6:  # IPv6
                        ipv6_info = {
                            "address": addr.address,
                            "prefixlen": addr.netmask or 64
                        }
                        if "%" in addr.address:
                            parts = addr.address.split("%")
                            interface_data["ipv6"].append({
                                **ipv6_info,
                                "scopeid": parts[1] if len(parts) > 1 else None
                            })
                        else:
                            interface_data["ipv6"].append(ipv6_info)
                
                if interface_data["ip_address"]:
                    # Mark as primary if it matches local IP
                    if self.local_ip and interface_data["ip_address"] == self.local_ip:
                        interface_data["is_primary"] = True
                    
                    interfaces.append(interface_data)
        except Exception as e:
            logger.exception(f"Error discovering network interfaces: {e}")
        
        return interfaces
    
    async def _get_interface_details_from_system(self) -> Dict[str, Dict[str, Any]]:
        """Get detailed interface information from ifconfig or ip command"""
        detailed_info = {}
        
        # Try ip command first (modern, better parsing)
        stdout = await self._run_cmd(["ip", "-d", "addr", "show"], timeout=5)
        if stdout:
            detailed_info = self._parse_ip_addr_output(stdout)
        else:
            # Fallback to ifconfig
            stdout = await self._run_cmd(["ifconfig", "-a"], timeout=5)
            if stdout:
                detailed_info = self._parse_ifconfig_output(stdout)
        
        return detailed_info
    
    def _parse_ip_addr_output(self, output: str) -> Dict[str, Dict[str, Any]]:
        """Parse output from 'ip addr show' command"""
        interfaces = {}
        current_iface = None
        
        for line in output.split('\n'):
            line = line.strip()
            
            # Interface line
            if ':' in line and not line.startswith(' '):
                parts = line.split(':')
                if len(parts) >= 2:
                    current_iface = parts[1].strip().split('@')[0]  # Remove alias
                    interfaces[current_iface] = {
                        "flags": [],
                        "mtu": None,
                        "status": "inactive"
                    }
                    
                    # Parse flags
                    if '<' in line and '>' in line:
                        flags_str = line[line.find('<')+1:line.find('>')]
                        interfaces[current_iface]["flags"] = [f.strip() for f in flags_str.split(',')]
                    
                    # Parse MTU
                    mtu_match = re.search(r'mtu\s+(\d+)', line)
                    if mtu_match:
                        interfaces[current_iface]["mtu"] = int(mtu_match.group(1))
                    
                    # Parse state
                    if 'state UP' in line:
                        interfaces[current_iface]["status"] = "active"
            
            elif current_iface and line.startswith(' '):
                # IP address line
                if 'inet ' in line and 'inet6 ' not in line:
                    # IPv4
                    inet_match = re.search(r'inet\s+([\d.]+)/(\d+)', line)
                    if inet_match:
                        ip = inet_match.group(1)
                        prefix = int(inet_match.group(2))
                        # Calculate netmask
                        netmask = prefix_to_netmask(prefix)
                        interfaces[current_iface]["netmask"] = netmask
                        
                        # Broadcast
                        brd_match = re.search(r'brd\s+([\d.]+)', line)
                        if brd_match:
                            interfaces[current_iface]["broadcast"] = brd_match.group(1)
                
                # IPv6 line
                elif 'inet6 ' in line:
                    inet6_match = re.search(r'inet6\s+([a-fA-F0-9:]+)/(\d+)', line)
                    if inet6_match and "ipv6" not in interfaces[current_iface]:
                        interfaces[current_iface]["ipv6"] = []
                    
                    if inet6_match:
                        ipv6_addr = inet6_match.group(1)
                        prefixlen = int(inet6_match.group(2))
                        scope_match = re.search(r'scope\s+(\w+)', line)
                        scope = scope_match.group(1) if scope_match else None
                        
                        interfaces[current_iface].setdefault("ipv6", []).append({
                            "address": ipv6_addr,
                            "prefixlen": prefixlen,
                            "scopeid": scope
                        })
                
                # Link line
                elif 'link/ether' in line:
                    mac_match = re.search(r'link/ether\s+([a-fA-F0-9:]+)', line)
                    if mac_match:
                        interfaces[current_iface]["mac_address"] = mac_match.group(1)
        
        return interfaces
    
    def _parse_ifconfig_output(self, output: str) -> Dict[str, Dict[str, Any]]:
        """Parse output from 'ifconfig -a' command"""
        interfaces = {}
        current_iface = None
        
        for line in output.split('\n'):
            line = line.strip()
            
            # Interface line
            if not line.startswith(' ') and ':' in line:
                parts = line.split(':')
                current_iface = parts[0]
                interfaces[current_iface] = {
                    "flags": [],
                    "mtu": None,
                    "status": "inactive"
                }
                
                # Parse flags
                flags_match = re.search(r'flags=\d+<([^>]+)>', line)
                if flags_match:
                    interfaces[current_iface]["flags"] = flags_match.group(1).split(',')
                
                # Parse MTU
                mtu_match = re.search(r'mtu\s+(\d+)', line)
                if mtu_match:
                    interfaces[current_iface]["mtu"] = int(mtu_match.group(1))
                
                # Status from flags
                if 'UP' in interfaces[current_iface]["flags"]:
                    interfaces[current_iface]["status"] = "active"
            
            elif current_iface and line.startswith(('inet ', 'inet6 ', 'ether ', 'media:')):
                # IPv4
                if line.startswith('inet ') and 'inet6' not in line:
                    netmask_match = re.search(r'netmask\s+([\d.]+|0x[0-9a-fA-F]+)', line)
                    broadcast_match = re.search(r'broadcast\s+([\d.]+)', line)
                    
                    if netmask_match:
                        netmask = netmask_match.group(1)
                        if netmask.startswith('0x'):
                            # Convert hex to dotted decimal
                            netmask = hex_netmask_to_dotted(netmask)
                        interfaces[current_iface]["netmask"] = netmask
                    
                    if broadcast_match:
                        interfaces[current_iface]["broadcast"] = broadcast_match.group(1)
                
                # IPv6
                elif line.startswith('inet6 '):
                    inet6_match = re.search(r'inet6\s+([a-fA-F0-9:]+)', line)
                    prefix_match = re.search(r'prefixlen\s+(\d+)', line)
                    scope_match = re.search(r'scopeid\s+0x([0-9a-fA-F]+)', line)
                    
                    if inet6_match and prefix_match:
                        if "ipv6" not in interfaces[current_iface]:
                            interfaces[current_iface]["ipv6"] = []
                        
                        ipv6_addr = inet6_match.group(1)
                        prefixlen = int(prefix_match.group(1))
                        scopeid = scope_match.group(1) if scope_match else None
                        
                        interfaces[current_iface]["ipv6"].append({
                            "address": ipv6_addr,
                            "prefixlen": prefixlen,
                            "scopeid": scopeid
                        })
                
                # MAC
                elif line.startswith('ether '):
                    mac_match = re.search(r'ether\s+([a-fA-F0-9:]+)', line)
                    if mac_match:
                        interfaces[current_iface]["mac_address"] = mac_match.group(1)
                
                # Media
                elif line.startswith('media:'):
                    media_match = re.search(r'media:\s+([^<]+)', line)
                    if media_match:
                        interfaces[current_iface]["media"] = media_match.group(1).strip()
                    
                    # Link speed from media
                    link_match = re.search(r'(\d+baseT)', line)
                    if link_match:
                        interfaces[current_iface]["link_speed"] = link_match.group(1)
        
        return interfaces

