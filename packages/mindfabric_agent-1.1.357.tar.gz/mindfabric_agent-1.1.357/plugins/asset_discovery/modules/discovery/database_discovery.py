"""
Database Schema Discovery Module

Database enumeration and schema discovery:
- Database enumeration (PostgreSQL, MySQL, MongoDB, etc.)
- Schema enumeration
- Table/collection enumeration
- Data type discovery
"""

import asyncio
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec


class DatabaseDiscovery:
    """Database schema discovery"""
    
    @staticmethod
    async def enumerate_postgresql(ip: str, port: int = 5432, username: str = "postgres") -> Dict[str, Any]:
        """
        Enumerate PostgreSQL database
        
        Args:
            ip: Database IP
            port: Database port
            username: Username to try
            
        Returns:
            PostgreSQL enumeration results
        """
        result = {
            "type": "PostgreSQL",
            "ip": ip,
            "port": port,
            "accessible": False,
            "version": None,
            "databases": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try to get version
            version_cmd = ["psql", "-h", ip, "-p", str(port), "-U", username, "-c", "SELECT version();", "-t"]
            rc, out, _ = await run_exec(version_cmd, timeout=3, stdin="\n")
            if rc == 0 and out:
                result["accessible"] = True
                version_match = re.search(r'PostgreSQL\s+([\d.]+)', out)
                if version_match:
                    result["version"] = version_match.group(1)
                
                # List databases
                db_cmd = ["psql", "-h", ip, "-p", str(port), "-U", username, "-l", "-t"]
                rc2, out2, _ = await run_exec(db_cmd, timeout=3, stdin="\n")
                if rc2 == 0 and out2:
                    # Parse database list
                    for line in out2.split('\n'):
                        parts = line.split('|')
                        if len(parts) >= 2:
                            db_name = parts[0].strip()
                            if db_name and not db_name.startswith('-') and db_name != 'Name':
                                result["databases"].append({
                                    "name": db_name,
                                    "owner": parts[1].strip() if len(parts) > 1 else None
                                })
                                
        except FileNotFoundError:
            result["error"] = "psql not available"
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error enumerating PostgreSQL on {ip}:{port}: {e}")
        
        return result
    
    @staticmethod
    async def enumerate_mysql(ip: str, port: int = 3306, username: str = "root") -> Dict[str, Any]:
        """
        Enumerate MySQL database
        
        Args:
            ip: Database IP
            port: Database port
            username: Username to try
            
        Returns:
            MySQL enumeration results
        """
        result = {
            "type": "MySQL",
            "ip": ip,
            "port": port,
            "accessible": False,
            "version": None,
            "databases": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try to get version
            version_cmd = ["mysql", "-h", ip, "-P", str(port), "-u", username, "-e", "SELECT VERSION();"]
            rc, out, _ = await run_exec(version_cmd, timeout=3)
            if rc == 0 and out:
                result["accessible"] = True
                version_match = re.search(r'(\d+\.\d+\.\d+)', out)
                if version_match:
                    result["version"] = version_match.group(1)
                
                # List databases
                db_cmd = ["mysql", "-h", ip, "-P", str(port), "-u", username, "-e", "SHOW DATABASES;"]
                rc2, out2, _ = await run_exec(db_cmd, timeout=3)
                if rc2 == 0 and out2:
                    for line in out2.split('\n'):
                        db_name = line.strip()
                        if db_name and db_name != "Database" and not db_name.startswith('-'):
                            result["databases"].append({"name": db_name})
                            
        except FileNotFoundError:
            result["error"] = "mysql client not available"
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error enumerating MySQL on {ip}:{port}: {e}")
        
        return result
    
    @staticmethod
    async def enumerate_mongodb(ip: str, port: int = 27017) -> Dict[str, Any]:
        """
        Enumerate MongoDB
        
        Args:
            ip: Database IP
            port: Database port
            
        Returns:
            MongoDB enumeration results
        """
        result = {
            "type": "MongoDB",
            "ip": ip,
            "port": port,
            "accessible": False,
            "version": None,
            "databases": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try to get version
            version_cmd = ["mongo", f"{ip}:{port}", "--eval", "db.version()", "--quiet"]
            rc, out, _ = await run_exec(version_cmd, timeout=3)
            if rc == 0 and (out or "").strip():
                result["accessible"] = True
                version_match = re.search(r'(\d+\.\d+\.\d+)', out or "")
                if version_match:
                    result["version"] = version_match.group(1)
                
                # List databases
                db_cmd = ["mongo", f"{ip}:{port}", "--eval", "db.adminCommand('listDatabases')", "--quiet"]
                rc2, out2, _ = await run_exec(db_cmd, timeout=3)
                if rc2 == 0 and out2:
                    # Parse JSON output
                    import json
                    try:
                        data = json.loads(out2)
                        if 'databases' in data:
                            for db in data['databases']:
                                result["databases"].append({
                                    "name": db.get('name'),
                                    "size": db.get('sizeOnDisk', 0)
                                })
                    except json.JSONDecodeError:
                        pass
                        
        except FileNotFoundError:
            result["error"] = "mongo client not available"
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error enumerating MongoDB on {ip}:{port}: {e}")
        
        return result
    
    @staticmethod
    async def enumerate_schema_postgresql(ip: str, port: int, database: str, username: str = "postgres") -> Dict[str, Any]:
        """
        Enumerate PostgreSQL schema
        
        Args:
            ip: Database IP
            port: Database port
            database: Database name
            username: Username
            
        Returns:
            Schema enumeration results
        """
        result = {
            "database": database,
            "tables": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # List tables
            tables_cmd = [
                "psql", "-h", ip, "-p", str(port), "-U", username,
                "-d", database,
                "-c", "SELECT tablename FROM pg_tables WHERE schemaname='public';", "-t"
            ]
            rc, out, _ = await run_exec(tables_cmd, timeout=5, stdin="\n")
            if rc == 0 and out:
                for line in out.split('\n'):
                    table_name = line.strip()
                    if table_name:
                        # Get columns for each table
                        columns_cmd = [
                            "psql", "-h", ip, "-p", str(port), "-U", username,
                            "-d", database,
                            "-c", f"SELECT column_name, data_type FROM information_schema.columns WHERE table_name='{table_name}';", "-t"
                        ]
                        rc2, out2, _ = await run_exec(columns_cmd, timeout=3, stdin="\n")
                        
                        columns = []
                        if rc2 == 0 and out2:
                            for col_line in out2.split('\n'):
                                parts = col_line.split('|')
                                if len(parts) >= 2:
                                    columns.append({
                                        "name": parts[0].strip(),
                                        "type": parts[1].strip()
                                    })
                        
                        result["tables"].append({
                            "name": table_name,
                            "columns": columns
                        })
                        
        except Exception as e:
            logger.debug(f"Error enumerating schema for PostgreSQL {database}: {e}")
        
        return result

