"""
Service Mesh Discovery Module

Service mesh and microservices discovery:
- Istio service discovery
- Consul service discovery
- Eureka service discovery
- etcd discovery
"""

import json
from ..utils.async_http import fetch
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec_stdout


class ServiceMeshDiscovery:
    """Service mesh discovery"""

    @staticmethod
    def _is_expected_unreachable_error(e: Exception) -> bool:
        """
        Treat 'service not present / not reachable in this environment' as a normal outcome.
        We should keep scanning without spamming logs (even in --debug mode).
        """
        # Common cases: connection refused, DNS failure, timeouts.
        if isinstance(e, (ConnectionRefusedError, TimeoutError)):
            return True
        if isinstance(e, OSError) and getattr(e, "errno", None) in (61, 111):
            return True
        return False
    
    @staticmethod
    async def discover_istio_services() -> Dict[str, Any]:
        """
        Discover services through Istio service mesh
        
        Returns:
            Istio service discovery results
        """
        result = {
            "mesh_type": "Istio",
            "services": [],
            "accessible": False,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try to query Istio Pilot discovery API
            # Default: istio-pilot.istio-system.svc.cluster.local
            endpoints = [
                "http://istio-pilot.istio-system:15010",
                "http://istiod.istio-system:15010",
                "http://localhost:15010"
            ]
            
            for endpoint in endpoints:
                try:
                    status, _, body = await fetch(f"{endpoint}/v1/registration", headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=1_000_000)
                    if status == 200 and body:
                        result["accessible"] = True
                        data = json.loads(body.decode('utf-8', errors="ignore") or "[]")
                        result["services"] = data
                        result["endpoint"] = endpoint
                        break
                except Exception:
                    continue
            
            # Also try kubectl for Istio resources
            try:
                out = await run_exec_stdout(
                    ["kubectl", "get", "virtualservices", "--all-namespaces", "-o", "json"],
                    timeout=5,
                )
                if out:
                    data = json.loads(out)
                    if "items" in data:
                        result["virtual_services"] = [item.get("metadata", {}).get("name") for item in data["items"]]
            except FileNotFoundError:
                pass
            except Exception:
                pass
                
        except Exception as e:
            if not ServiceMeshDiscovery._is_expected_unreachable_error(e):
                logger.debug(f"Error discovering Istio services: {e}")
                result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def discover_consul_services(consul_url: str = "http://localhost:8500") -> Dict[str, Any]:
        """
        Discover services through Consul
        
        Args:
            consul_url: Consul API URL
            
        Returns:
            Consul service discovery results
        """
        result = {
            "mesh_type": "Consul",
            "services": [],
            "nodes": [],
            "accessible": False,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Query Consul catalog API
            catalog_url = f"{consul_url}/v1/catalog/services"
            
            status, _, body = await fetch(catalog_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=1_000_000)
            if status == 200 and body:
                result["accessible"] = True
                data = json.loads(body.decode('utf-8', errors="ignore") or "{}")
                service_names = list(data.keys()) if isinstance(data, dict) else []
                result["services"] = list(service_names)

                # Get service details
                for service_name in service_names[:20]:  # Limit
                    service_url = f"{consul_url}/v1/health/service/{service_name}"
                    try:
                        st2, _, b2 = await fetch(service_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=2, max_bytes=1_000_000)
                        if st2 == 200 and b2:
                            service_data = json.loads(b2.decode('utf-8', errors="ignore") or "[]")
                            result["services"].append({
                                "name": service_name,
                                "instances": len(service_data) if isinstance(service_data, list) else 0,
                                "details": service_data[:3] if isinstance(service_data, list) else [],
                            })
                    except Exception:
                        continue

                # Get nodes
                nodes_url = f"{consul_url}/v1/catalog/nodes"
                st3, _, b3 = await fetch(nodes_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=2, max_bytes=1_000_000)
                if st3 == 200 and b3:
                    nodes_data = json.loads(b3.decode('utf-8', errors="ignore") or "[]")
                    if isinstance(nodes_data, list):
                        result["nodes"] = [node.get("Node") for node in nodes_data if isinstance(node, dict)]
                            
        except Exception as e:
            # Consul not present is normal; don't spam logs.
            if not ServiceMeshDiscovery._is_expected_unreachable_error(e):
                logger.debug(f"Error discovering Consul services: {e}")
                result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def discover_eureka_services(eureka_url: str = "http://localhost:8761") -> Dict[str, Any]:
        """
        Discover services through Eureka
        
        Args:
            eureka_url: Eureka server URL
            
        Returns:
            Eureka service discovery results
        """
        result = {
            "mesh_type": "Eureka",
            "applications": [],
            "accessible": False,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Query Eureka REST API
            apps_url = f"{eureka_url}/eureka/apps"
            
            status, _, body = await fetch(apps_url, headers={"Accept": "application/json"}, timeout=3, max_bytes=1_000_000)
            if status == 200 and body:
                result["accessible"] = True
                data = json.loads(body.decode('utf-8', errors="ignore") or "{}")
                apps = data.get("applications", {}).get("application", [])
                if isinstance(apps, dict):
                    apps = [apps]
                if isinstance(apps, list):
                    for app in apps:
                        if not isinstance(app, dict):
                            continue
                        inst = app.get("instance", [])
                        result["applications"].append({
                            "name": app.get("name"),
                            "instance_count": len(inst) if isinstance(inst, list) else 0
                        })
                            
        except Exception as e:
            # Eureka not present is normal; don't spam logs.
            if not ServiceMeshDiscovery._is_expected_unreachable_error(e):
                logger.debug(f"Error discovering Eureka services: {e}")
                result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def discover_etcd_services(etcd_url: str = "http://localhost:2379") -> Dict[str, Any]:
        """
        Discover services through etcd
        
        Args:
            etcd_url: etcd server URL
            
        Returns:
            etcd discovery results
        """
        result = {
            "mesh_type": "etcd",
            "keys": [],
            "accessible": False,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Query etcd API v3 (requires gRPC, simplified version here)
            # For v2 API:
            v2_url = f"{etcd_url}/v2/keys/?recursive=true"
            
            status, _, body = await fetch(v2_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=1_000_000)
            if status == 200 and body:
                result["accessible"] = True
                data = json.loads(body.decode('utf-8', errors="ignore") or "{}")

                # Extract keys
                def extract_keys(node, prefix=""):
                    keys = []
                    if isinstance(node, dict) and "key" in node:
                        key = node["key"]
                        keys.append(prefix + key)
                    if isinstance(node, dict) and "nodes" in node and isinstance(node["nodes"], list):
                        for child in node["nodes"]:
                            keys.extend(extract_keys(child, prefix))
                    return keys

                result["keys"] = extract_keys(data.get("node", {}))[:100]  # Limit
                    
        except Exception as e:
            # etcd not present is normal; don't spam logs.
            if not ServiceMeshDiscovery._is_expected_unreachable_error(e):
                logger.debug(f"Error discovering etcd services: {e}")
                result["error"] = str(e)
        
        return result

