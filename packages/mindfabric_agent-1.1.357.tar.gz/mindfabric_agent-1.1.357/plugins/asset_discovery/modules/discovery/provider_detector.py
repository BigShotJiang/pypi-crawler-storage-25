"""
Provider and environment detection
"""
import os
from typing import Optional
import asyncio
import socket

from ..utils.async_http import fetch


class ProviderDetector:
    """Detects cloud provider, agent type, environment, and system role"""
    
    @staticmethod
    async def detect_provider() -> str:
        """Detect cloud provider or on-premise"""
        try:
            # DigitalOcean
            # Real-world signals:
            # - DMI sys_vendor/product_name: "DigitalOcean" / "Droplet"
            # - droplet-agent present
            # - metadata endpoint responds on /metadata/v1/id
            try:
                vendor = ""
                product = ""
                if os.path.exists("/sys/class/dmi/id/sys_vendor"):
                    with open("/sys/class/dmi/id/sys_vendor", "r") as f:
                        vendor = (f.read() or "").strip().lower()
                if os.path.exists("/sys/class/dmi/id/product_name"):
                    with open("/sys/class/dmi/id/product_name", "r") as f:
                        product = (f.read() or "").strip().lower()
                if "digitalocean" in vendor or "droplet" in product:
                    return "DigitalOcean"
                if os.path.exists("/opt/digitalocean/bin/droplet-agent") or os.path.exists("/etc/systemd/system/droplet-agent.service"):
                    return "DigitalOcean"
            except Exception:
                pass

            # GCP — check before the generic 169.254.169.254 probes below.
            # Google Cloud uses the same link-local metadata IP as other clouds; an unknown path there
            # may return a non-200 body and must NOT be mistaken for DigitalOcean.
            try:
                status, _, _ = await fetch(
                    "http://metadata.google.internal/computeMetadata/v1/instance/",
                    headers={"Metadata-Flavor": "Google"},
                    timeout=1,
                    max_bytes=1024,
                )
                if status == 200:
                    return "GCP"
            except Exception:
                pass

            # Check DigitalOcean metadata service (distinct path from AWS/Azure/GCP).
            # Require HTTP 200 — 404/HTML error pages from another cloud's metadata server must not match.
            try:
                status, _, body = await fetch("http://169.254.169.254/metadata/v1/id", timeout=1, max_bytes=1024)
                if status == 200 and body:
                    return "DigitalOcean"
            except Exception:
                pass

            # AWS
            if os.path.exists("/sys/class/dmi/id/product_version"):
                with open("/sys/class/dmi/id/product_version", "r") as f:
                    if "amazon" in f.read().lower():
                        return "AWS"
            
            # Check for AWS metadata service
            try:
                status, _, _ = await fetch("http://169.254.169.254/latest/meta-data/", timeout=1, max_bytes=1024)
                if status == 200:
                    return "AWS"
            except:
                pass
            
            # Azure
            try:
                status, _, _ = await fetch(
                    "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
                    headers={"Metadata": "true"},
                    timeout=1,
                    max_bytes=1024,
                )
                if status == 200:
                    return "Azure"
            except:
                pass
            
            # Kubernetes
            # Be strict: some container runtimes/environments may set KUBERNETES_* env vars or create
            # placeholder directories. Only consider it Kubernetes if:
            # - KUBERNETES_SERVICE_HOST is present (typical in pods)
            # - and a real serviceaccount token exists.
            svcacct_token = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            k8s_host = os.getenv("KUBERNETES_SERVICE_HOST")
            k8s_port = os.getenv("KUBERNETES_SERVICE_PORT")
            if k8s_host and os.path.exists(svcacct_token):
                try:
                    if os.path.getsize(svcacct_token) > 0:
                        # Extra guard: verify we're actually in a Kubernetes runtime (or at least the apiserver is reachable).
                        try:
                            # Common in real pods: /proc/1/cgroup includes "kubepods"
                            with open("/proc/1/cgroup", "r") as f:
                                cgroup = f.read()
                                if "kubepods" in cgroup:
                                    return "Kubernetes"
                        except Exception:
                            pass

                        # If env vars are present but apiserver is NOT reachable, treat as non-k8s.
                        try:
                            port = int(k8s_port) if k8s_port and str(k8s_port).isdigit() else 443
                            r, w = await asyncio.wait_for(asyncio.open_connection(k8s_host, port), timeout=0.2)
                            w.close()
                            try:
                                await w.wait_closed()
                            except Exception:
                                pass
                            return "Kubernetes"
                        except Exception:
                            pass
                except Exception:
                    # If we can't stat it reliably, still treat the existence as a strong indicator.
                    return "Kubernetes"
            
            return "On-premise"
        except Exception:
            return "On-premise"
    
    @staticmethod
    def detect_agent_type() -> str:
        """Detect agent type"""
        # Check if running in Docker
        if os.path.exists("/.dockerenv"):
            return "Docker"
        
        # Check for Kubernetes
        if os.path.exists("/var/run/secrets/kubernetes.io"):
            return "Kubernetes"
        
        # Avoid running external commands here (blocks agent loop). On Linux, systemd presence can be inferred from FS.
        try:
            if os.path.isdir("/run/systemd/system") or os.path.exists("/bin/systemctl") or os.path.exists("/usr/bin/systemctl"):
                return "Native"
        except Exception:
            pass

        return "Native"
    
    @staticmethod
    def detect_environment(hostname: str) -> str:
        """Detect environment"""
        hostname_lower = hostname.lower()
        
        if any(x in hostname_lower for x in ["prod", "production", "live"]):
            return "Production"
        elif any(x in hostname_lower for x in ["dev", "development"]):
            return "Development"
        elif any(x in hostname_lower for x in ["test", "testing", "qa"]):
            return "Testing"
        elif any(x in hostname_lower for x in ["stage", "staging"]):
            return "Staging"
        
        return "Development"
    
    @staticmethod
    def detect_system_role(hostname: str) -> Optional[str]:
        """Detect system role based on hostname and services"""
        hostname_lower = hostname.lower()
        
        if any(x in hostname_lower for x in ["db", "database", "postgres", "mysql", "mongo"]):
            return "Database Server"
        elif any(x in hostname_lower for x in ["web", "www", "http", "nginx", "apache"]):
            return "Web Server"
        elif any(x in hostname_lower for x in ["app", "api", "application"]):
            return "Application Server"
        elif any(x in hostname_lower for x in ["cache", "redis", "memcache"]):
            return "Cache Server"
        elif any(x in hostname_lower for x in ["monitor", "prometheus", "grafana"]):
            return "Monitoring Server"
        elif any(x in hostname_lower for x in ["k8s", "kubernetes", "master", "worker"]):
            if "master" in hostname_lower or "control" in hostname_lower:
                return "Kubernetes Master"
            else:
                return "Kubernetes Worker"
        
        return None
    
    @staticmethod
    def get_system_tags(provider: str, role: Optional[str], environment: str) -> list:
        """Get system tags"""
        tags = []
        
        if provider.lower() != "on-premise":
            tags.append("cloud")
        if role:
            role_tag = role.lower().replace(" ", "-")
            tags.append(role_tag)
        if environment:
            tags.append(environment.lower())
        
        return tags

