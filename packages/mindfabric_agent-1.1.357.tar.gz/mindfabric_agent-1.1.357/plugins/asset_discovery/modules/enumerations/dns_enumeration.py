"""
DNS Enumeration Module

Advanced DNS enumeration techniques:
- DNS Zone Transfer (AXFR)
- Subdomain brute-forcing
- DNS record enumeration (A, AAAA, MX, TXT, SRV, CNAME)
- Historical DNS records
"""

import socket
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger

try:
    import dns.resolver
    import dns.zone
    import dns.query
    DNS_AVAILABLE = True
except ImportError:
    DNS_AVAILABLE = False
    logger.debug("dnspython not available, DNS enumeration limited")


class DNSEnumerator:
    """DNS enumeration"""
    
    # Common subdomain wordlist
    COMMON_SUBDOMAINS = [
        "www", "mail", "ftp", "localhost", "webmail", "smtp", "pop", "ns1", "webdisk",
        "ns2", "cpanel", "whm", "autodiscover", "autoconfig", "m", "imap", "test",
        "ns", "blog", "pop3", "dev", "www2", "admin", "forum", "news", "vpn", "ns3",
        "mail2", "new", "mysql", "old", "lists", "support", "mobile", "mx", "static",
        "docs", "beta", "shop", "sql", "secure", "demo", "cp", "calendar", "wiki",
        "web", "media", "email", "images", "img", "www1", "intranet", "portal",
        "video", "sip", "dns2", "api", "cdn", "stats", "dns1", "ns4", "www3", "dns",
        "search", "staging", "server", "mx1", "chat", "wap", "my", "svn", "mail1",
        "sites", "proxy", "ads", "host", "crm", "cms", "backup", "mx2", "lyncdiscover",
        "info", "apps", "download", "remote", "db", "forums", "store", "relay", "files",
        "newsletter", "app", "live", "owa", "en", "start", "sms", "office", "exchange",
        "ipv4"
    ]
    
    @staticmethod
    async def attempt_zone_transfer(domain: str, nameserver: Optional[str] = None) -> Dict[str, Any]:
        """
        Attempt DNS zone transfer (AXFR)
        
        Args:
            domain: Target domain
            nameserver: Optional nameserver IP
            
        Returns:
            Zone transfer results
        """
        result = {
            "domain": domain,
            "zone_transfer_successful": False,
            "records": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if not DNS_AVAILABLE:
            result["error"] = "dnspython not available"
            return result
        
        try:
            # If nameserver not provided, find authoritative nameservers
            if not nameserver:
                ns_records = dns.resolver.resolve(domain, 'NS')
                nameservers = [str(ns) for ns in ns_records]
            else:
                nameservers = [nameserver]
            
            for ns in nameservers:
                try:
                    # Attempt zone transfer
                    zone = dns.zone.from_xfr(dns.query.xfr(ns, domain))
                    
                    # Extract all records
                    for name, node in zone.nodes.items():
                        rdatasets = node.rdatasets
                        for rdataset in rdatasets:
                            for rdata in rdataset:
                                result["records"].append({
                                    "name": str(name),
                                    "type": dns.rdatatype.to_text(rdataset.rdtype),
                                    "data": str(rdata)
                                })
                    
                    result["zone_transfer_successful"] = True
                    result["nameserver"] = ns
                    break
                except Exception as e:
                    logger.debug(f"Zone transfer failed for {ns}: {e}")
                    continue
                    
        except Exception as e:
            logger.debug(f"Error attempting zone transfer for {domain}: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def enumerate_subdomains(domain: str, wordlist: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Enumerate subdomains using brute-forcing
        
        Args:
            domain: Target domain
            wordlist: Optional wordlist, uses default if None
            
        Returns:
            Subdomain enumeration results
        """
        if wordlist is None:
            wordlist = DNSEnumerator.COMMON_SUBDOMAINS
        
        result = {
            "domain": domain,
            "subdomains": [],
            "total_tested": len(wordlist),
            "total_found": 0,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        for subdomain in wordlist[:100]:  # Limit to first 100
            full_domain = f"{subdomain}.{domain}"
            
            try:
                # Try A record
                answers = dns.resolver.resolve(full_domain, 'A', lifetime=1)
                for rdata in answers:
                    result["subdomains"].append({
                        "subdomain": full_domain,
                        "type": "A",
                        "ip": str(rdata)
                    })
                    result["total_found"] += 1
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.Timeout):
                continue
            except Exception as e:
                logger.debug(f"Error resolving {full_domain}: {e}")
                continue
        
        return result
    
    @staticmethod
    async def enumerate_dns_records(domain: str) -> Dict[str, Any]:
        """
        Enumerate various DNS records
        
        Args:
            domain: Target domain
            
        Returns:
            DNS records enumeration
        """
        result = {
            "domain": domain,
            "records": {},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        record_types = ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CNAME', 'SOA', 'SRV']
        
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(domain, record_type, lifetime=2)
                result["records"][record_type] = [str(rdata) for rdata in answers]
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                continue
            except Exception as e:
                logger.debug(f"Error resolving {record_type} for {domain}: {e}")
                continue
        
        # Extract information from TXT records
        if 'TXT' in result["records"]:
            txt_info = {}
            for txt in result["records"]["TXT"]:
                # SPF records
                if 'v=spf1' in txt:
                    txt_info["spf"] = txt
                # DKIM records
                if 'v=DKIM1' in txt:
                    txt_info["dkim"] = txt
                # Other TXT records
                if "txt_info" not in txt_info:
                    txt_info["other"] = result["records"]["TXT"]
            
            result["txt_parsed"] = txt_info
        
        return result
    
    @staticmethod
    async def enumerate_srv_records(domain: str) -> List[Dict[str, Any]]:
        """
        Enumerate SRV records for service discovery
        
        Args:
            domain: Target domain
            
        Returns:
            List of SRV records
        """
        srv_records = []
        common_services = [
            "_ldap._tcp", "_kerberos._tcp", "_kerberos._udp",
            "_ldap._tcp.dc._msdcs", "_gc._tcp", "_kerberos._tcp.dc._msdcs",
            "_sip._tcp", "_sip._udp", "_sipfederationtls._tcp",
            "_sipinternaltls._tcp", "_autodiscover._tcp", "_xmpp-server._tcp"
        ]
        
        for service in common_services:
            full_domain = f"{service}.{domain}"
            try:
                answers = dns.resolver.resolve(full_domain, 'SRV', lifetime=1)
                for rdata in answers:
                    srv_records.append({
                        "service": service,
                        "target": str(rdata.target),
                        "port": rdata.port,
                        "priority": rdata.priority,
                        "weight": rdata.weight
                    })
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.Timeout):
                continue
            except Exception as e:
                logger.debug(f"Error resolving SRV {full_domain}: {e}")
                continue
        
        return srv_records

