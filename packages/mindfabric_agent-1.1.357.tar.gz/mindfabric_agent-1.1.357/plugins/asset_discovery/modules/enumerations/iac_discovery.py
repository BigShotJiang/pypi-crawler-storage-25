"""
Infrastructure as Code (IaC) Discovery Module

IaC analysis and discovery:
- Terraform state analysis
- CloudFormation template analysis
- Ansible playbook analysis
"""

import json
try:
    import yaml
except ImportError:
    yaml = None
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger


class IaCDiscovery:
    """Infrastructure as Code discovery"""

    @staticmethod
    def _safe_glob_limited(root: Path, pattern: str, limit: int = 5) -> List[Path]:
        """Best-effort glob that tolerates disappearing /proc-like paths."""
        out: List[Path] = []
        try:
            for p in root.glob(pattern):
                out.append(p)
                if len(out) >= limit:
                    break
        except (FileNotFoundError, OSError, PermissionError, IOError):
            return []
        return out
    
    @staticmethod
    async def discover_terraform_state(state_file: Optional[Path] = None) -> Dict[str, Any]:
        """
        Discover resources from Terraform state
        
        Args:
            state_file: Path to terraform.tfstate file
            
        Returns:
            Terraform state analysis results
        """
        result = {
            "type": "Terraform",
            "resources": [],
            "outputs": {},
            "sensitive_values": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Find state file if not provided
        if state_file is None:
            possible_paths = [
                Path("terraform.tfstate"),
                Path(".terraform/terraform.tfstate"),
                IaCDiscovery._safe_glob_limited(Path.cwd(), "**/terraform.tfstate", limit=5),
            ]
            
            for path_pattern in possible_paths:
                if isinstance(path_pattern, Path) and path_pattern.exists():
                    state_file = path_pattern
                    break
                elif hasattr(path_pattern, '__iter__'):
                    for path in list(path_pattern)[:5]:  # Limit search
                        if path.exists():
                            state_file = path
                            break
        
        if not state_file or not state_file.exists():
            result["error"] = "Terraform state file not found"
            return result
        
        try:
            with open(state_file, 'r') as f:
                state_data = json.load(f)
            
            # Extract resources
            if "resources" in state_data:
                for resource in state_data["resources"]:
                    resource_info = {
                        "type": resource.get("type"),
                        "name": resource.get("name"),
                        "provider": resource.get("provider", "").split('"')[1] if '"' in str(resource.get("provider", "")) else "",
                    }
                    
                    # Extract attributes (limit to avoid too much data)
                    if "instances" in resource and resource["instances"]:
                        instance = resource["instances"][0]
                        if "attributes" in instance:
                            attrs = instance["attributes"]
                            # Look for sensitive data
                            sensitive_patterns = [
                                (r'password', 'password'),
                                (r'secret', 'secret'),
                                (r'key', 'key'),
                                (r'token', 'token'),
                                (r'credential', 'credential'),
                            ]
                            
                            for pattern, label in sensitive_patterns:
                                for key, value in attrs.items():
                                    if re.search(pattern, key, re.I) and value:
                                        result["sensitive_values"].append({
                                            "resource": f"{resource_info['type']}.{resource_info['name']}",
                                            "key": key,
                                            "type": label
                                        })
                            
                            resource_info["attributes_count"] = len(attrs)
                    
                    result["resources"].append(resource_info)
            
            # Extract outputs
            if "outputs" in state_data:
                result["outputs"] = {k: "***REDACTED***" for k in state_data["outputs"].keys()}
                result["output_count"] = len(result["outputs"])
            
            result["total_resources"] = len(result["resources"])
            
        except json.JSONDecodeError as e:
            result["error"] = f"Invalid JSON in state file: {e}"
        except Exception as e:
            logger.debug(f"Error analyzing Terraform state: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def discover_cloudformation_templates(template_file: Optional[Path] = None) -> Dict[str, Any]:
        """
        Discover resources from CloudFormation template
        
        Args:
            template_file: Path to CloudFormation template
            
        Returns:
            CloudFormation template analysis results
        """
        result = {
            "type": "CloudFormation",
            "resources": [],
            "parameters": [],
            "outputs": [],
            "misconfigurations": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Find template file
        if template_file is None:
            possible_paths = [
                Path("template.yaml"),
                Path("template.yml"),
                Path("cloudformation.yaml"),
                IaCDiscovery._safe_glob_limited(Path.cwd(), "**/*template*.yaml", limit=5),
                IaCDiscovery._safe_glob_limited(Path.cwd(), "**/*template*.yml", limit=5),
            ]
            
            for path_pattern in possible_paths:
                if isinstance(path_pattern, Path) and path_pattern.exists():
                    template_file = path_pattern
                    break
                elif hasattr(path_pattern, '__iter__'):
                    for path in list(path_pattern)[:5]:
                        if path.exists():
                            template_file = path
                            break
        
        if not template_file or not template_file.exists():
            result["error"] = "CloudFormation template not found"
            return result
        
        try:
            with open(template_file, 'r') as f:
                if yaml is None:
                    template_data = json.load(f)
                else:
                    template_data = yaml.safe_load(f) or json.load(f)
            
            # Extract resources
            if "Resources" in template_data:
                for resource_name, resource_def in template_data["Resources"].items():
                    resource_type = resource_def.get("Type", "")
                    properties = resource_def.get("Properties", {})
                    
                    resource_info = {
                        "name": resource_name,
                        "type": resource_type,
                        "properties_count": len(properties)
                    }
                    
                    # Check for common misconfigurations
                    if resource_type.startswith("AWS::EC2::SecurityGroup"):
                        # Check for overly permissive rules
                        if "SecurityGroupIngress" in properties:
                            for rule in properties["SecurityGroupIngress"]:
                                if rule.get("CidrIp") == "0.0.0.0/0":
                                    result["misconfigurations"].append({
                                        "resource": resource_name,
                                        "issue": "Overly permissive security group rule (0.0.0.0/0)",
                                        "severity": "high"
                                    })
                    
                    result["resources"].append(resource_info)
            
            # Extract parameters
            if "Parameters" in template_data:
                result["parameters"] = list(template_data["Parameters"].keys())
            
            # Extract outputs
            if "Outputs" in template_data:
                result["outputs"] = list(template_data["Outputs"].keys())
            
            result["total_resources"] = len(result["resources"])
            
        except (yaml.YAMLError if yaml else Exception) as e:
            result["error"] = f"Invalid YAML in template: {e}" if yaml else f"Error loading template: {e}"
        except json.JSONDecodeError as e:
            result["error"] = f"Invalid JSON in template: {e}"
        except Exception as e:
            logger.debug(f"Error analyzing CloudFormation template: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def discover_ansible_playbooks(playbook_dir: Optional[Path] = None) -> Dict[str, Any]:
        """
        Discover hosts and configurations from Ansible playbooks
        
        Args:
            playbook_dir: Directory containing Ansible playbooks
            
        Returns:
            Ansible playbook analysis results
        """
        result = {
            "type": "Ansible",
            "playbooks": [],
            "hosts": set(),
            "tasks": [],
            "variables": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if playbook_dir is None:
            playbook_dir = Path.cwd()
        
        try:
            # Find playbook files
            playbook_files = (
                IaCDiscovery._safe_glob_limited(playbook_dir, "**/*.yml", limit=50)
                + IaCDiscovery._safe_glob_limited(playbook_dir, "**/*.yaml", limit=50)
            )
            playbook_files = [f for f in playbook_files if "playbook" in f.name.lower() or "site.yml" == f.name][:10]
            
            for playbook_file in playbook_files:
                try:
                    with open(playbook_file, 'r') as f:
                        if yaml is None:
                            continue  # Skip YAML files if yaml module not available
                        playbook_data = yaml.safe_load(f)
                    
                    if not isinstance(playbook_data, list):
                        playbook_data = [playbook_data]
                    
                    for play in playbook_data:
                        if "hosts" in play:
                            hosts = play["hosts"]
                            if isinstance(hosts, str):
                                result["hosts"].add(hosts)
                            elif isinstance(hosts, list):
                                result["hosts"].update(hosts)
                        
                        if "tasks" in play:
                            for task in play["tasks"]:
                                task_info = {
                                    "name": task.get("name", "unnamed"),
                                    "module": list(task.keys())[0] if task else None
                                }
                                result["tasks"].append(task_info)
                        
                        if "vars" in play:
                            result["variables"].extend(list(play["vars"].keys()))
                    
                    result["playbooks"].append({
                        "file": str(playbook_file),
                        "play_count": len(playbook_data)
                    })
                except Exception as e:
                    logger.debug(f"Error parsing playbook {playbook_file}: {e}")
                    continue
            
            result["hosts"] = list(result["hosts"])
            result["total_playbooks"] = len(result["playbooks"])
            result["total_hosts"] = len(result["hosts"])
            
        except Exception as e:
            logger.debug(f"Error discovering Ansible playbooks: {e}")
            result["error"] = str(e)
        
        return result

