"""
Certificate and Key Discovery Module

Discovers SSL/TLS certificates and cryptographic keys including:
- Certificate files (.crt, .pem, .key)
- Certificate information extraction
- Expired certificate detection
- Self-signed certificate detection
- Subject Alternative Names (SAN) mapping
"""

import os
import re
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec


class CertificateDiscovery:
    """Certificate and key discovery module"""
    
    # Common certificate/key file extensions
    CERT_EXTENSIONS = ['.crt', '.pem', '.cer', '.der', '.p12', '.pfx', '.key']
    # Never descend into virtual/kernel FS — pathlib.rglob("/") hits /proc/.../task/.../net and raises OSError (EINVAL).
    _WALK_PRUNE_TOP = frozenset({"proc", "sys", "dev", "run"})
    
    # Common certificate locations
    CERT_PATHS = [
        '/etc/ssl/certs',
        '/etc/pki/tls/certs',
        '/usr/share/ca-certificates',
        '/etc/letsencrypt/live',
        '/etc/nginx/ssl',
        '/etc/apache2/ssl',
        '/var/www/*/ssl',
        '/home/*/.ssl',
        '/home/*/.certificates'
    ]
    
    @staticmethod
    async def discover_certificates(root_dir: str = "/") -> List[Dict[str, Any]]:
        """
        Discover certificates and keys in the filesystem
        
        Args:
            root_dir: Root directory to search
            
        Returns:
            List of discovered certificates with metadata
        """
        certificates = []
        
        try:
            root_path = Path(root_dir)
            if not root_path.exists():
                return certificates
            
            # Search in common paths first
            for cert_path_pattern in CertificateDiscovery.CERT_PATHS:
                if cert_path_pattern.startswith(root_dir):
                    for path in Path(root_dir).glob(cert_path_pattern.lstrip(root_dir).lstrip('/')):
                        if path.exists():
                            if path.is_file():
                                cert_info = await CertificateDiscovery._analyze_cert_file(path)
                                if cert_info:
                                    certificates.append(cert_info)
                            elif path.is_dir():
                                certificates.extend(
                                    await CertificateDiscovery._scan_directory(path)
                                )
            
            # Also search for certificate files (never use Path.rglob("/") — hits /proc/.../task/.../net → OSError EINVAL)
            for ext in CertificateDiscovery.CERT_EXTENSIONS:
                count = 0
                for cert_file in CertificateDiscovery._iter_cert_files_under_root(root_path, ext):
                    if count > 100:
                        break
                    cert_info = await CertificateDiscovery._analyze_cert_file(cert_file)
                    if cert_info:
                        certificates.append(cert_info)
                        count += 1
                        
        except Exception as e:
            logger.debug(f"Error discovering certificates: {e}")
        
        return certificates

    @staticmethod
    def _iter_cert_files_under_root(root_path: Path, ext: str):
        """Yield cert-like files under root without walking virtual filesystems."""
        root = str(root_path)
        ext_l = ext.lower()
        try:
            for dirpath, dirnames, filenames in os.walk(
                root, topdown=True, followlinks=False, onerror=None
            ):
                # Prune kernel/virtual mount points when scanning from filesystem root
                if dirpath == "/" or dirpath == os.path.sep:
                    dirnames[:] = [d for d in dirnames if d not in CertificateDiscovery._WALK_PRUNE_TOP]
                # Defense in depth: never descend into /proc (bind mounts, odd roots)
                norm = dirpath.rstrip(os.sep) or os.sep
                if norm == "/proc" or norm.startswith("/proc/"):
                    dirnames[:] = []
                    continue
                for name in filenames:
                    if name.lower().endswith(ext_l):
                        yield Path(dirpath) / name
        except (OSError, RuntimeError):
            return

    @staticmethod
    async def _scan_directory(directory: Path) -> List[Dict[str, Any]]:
        """Scan directory for certificate files"""
        certificates = []
        
        try:
            for item in directory.iterdir():
                if item.is_file() and any(item.suffix == ext for ext in CertificateDiscovery.CERT_EXTENSIONS):
                    cert_info = await CertificateDiscovery._analyze_cert_file(item)
                    if cert_info:
                        certificates.append(cert_info)
                elif item.is_dir():
                    # Avoid following symlinks into /proc, etc. (pathlib follows targets by default)
                    if item.is_symlink():
                        continue
                    # Recursively scan subdirectories (limit depth)
                    if len(item.parts) - len(directory.parts) < 3:  # Max 3 levels deep
                        certificates.extend(await CertificateDiscovery._scan_directory(item))
        except (PermissionError, IOError, OSError):
            pass
        except Exception as e:
            logger.debug(f"Error scanning directory {directory}: {e}")
        
        return certificates
    
    @staticmethod
    async def _analyze_cert_file(cert_path: Path) -> Optional[Dict[str, Any]]:
        """Analyze a certificate file and extract information"""
        try:
            if not cert_path.exists() or not cert_path.is_file():
                return None
            
            # Check if file is readable
            try:
                with open(cert_path, 'rb') as f:
                    content = f.read(4096)  # Read first 4KB
            except (PermissionError, IOError):
                return None
            
            # Check if it's a certificate or key
            is_cert = b'-----BEGIN CERTIFICATE-----' in content or b'-----BEGIN X509 CERTIFICATE-----' in content
            is_key = b'-----BEGIN' in content and (b'PRIVATE KEY' in content or b'RSA PRIVATE KEY' in content)
            
            if not (is_cert or is_key):
                return None
            
            cert_info = {
                "path": str(cert_path),
                "filename": cert_path.name,
                "size": cert_path.stat().st_size,
                "type": "certificate" if is_cert else "private_key",
                "modified": datetime.fromtimestamp(cert_path.stat().st_mtime).isoformat()
            }
            
            if is_cert:
                # Extract certificate information using openssl
                cert_details = await CertificateDiscovery._extract_cert_info(cert_path)
                if cert_details:
                    cert_info.update(cert_details)
            elif is_key:
                # Extract key information
                key_info = await CertificateDiscovery._extract_key_info(cert_path)
                if key_info:
                    cert_info.update(key_info)
            
            return cert_info
            
        except Exception as e:
            logger.debug(f"Error analyzing certificate file {cert_path}: {e}")
            return None
    
    @staticmethod
    async def _extract_cert_info(cert_path: Path) -> Optional[Dict[str, Any]]:
        """Extract detailed information from certificate using openssl"""
        try:
            # Use openssl to extract certificate information
            rc, out, _ = await run_exec(
                ["openssl", "x509", "-in", str(cert_path), "-noout", "-text", "-dates", "-subject", "-issuer"],
                timeout=5,
            )
            if rc != 0:
                # Try alternative format
                rc, out, _ = await run_exec(
                    ["openssl", "x509", "-inform", "DER", "-in", str(cert_path), "-noout", "-text", "-dates", "-subject", "-issuer"],
                    timeout=5,
                )
            if rc != 0:
                return None
            
            output = out or ""
            
            cert_info = {}
            
            # Extract subject
            subject_match = re.search(r'Subject: (.+)', output)
            if subject_match:
                cert_info["subject"] = subject_match.group(1)
                # Extract CN (Common Name)
                cn_match = re.search(r'CN\s*=\s*([^,/\n]+)', subject_match.group(1))
                if cn_match:
                    cert_info["common_name"] = cn_match.group(1).strip()
            
            # Extract issuer
            issuer_match = re.search(r'Issuer: (.+)', output)
            if issuer_match:
                cert_info["issuer"] = issuer_match.group(1)
                # Check if self-signed
                cert_info["self_signed"] = subject_match and issuer_match and \
                                          subject_match.group(1) == issuer_match.group(1)
            
            # Extract validity dates
            not_before_match = re.search(r'Not Before: (.+)', output)
            not_after_match = re.search(r'Not After\s*: (.+)', output)
            
            if not_before_match:
                cert_info["not_before"] = not_before_match.group(1).strip()
            if not_after_match:
                not_after_str = not_after_match.group(1).strip()
                cert_info["not_after"] = not_after_str
                
                # Check if expired
                try:
                    not_after_date = datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z")
                    cert_info["expired"] = datetime.now() > not_after_date
                    cert_info["days_until_expiry"] = (not_after_date - datetime.now()).days
                except ValueError:
                    pass
            
            # Extract SAN (Subject Alternative Names)
            san_section = re.search(r'X509v3 Subject Alternative Name:\s*\n\s*(.+?)(?=\n\s+[A-Z]|\Z)', output, re.DOTALL)
            if san_section:
                san_text = san_section.group(1)
                sans = []
                # Extract DNS names
                dns_matches = re.findall(r'DNS:([^\s,]+)', san_text)
                sans.extend([{"type": "DNS", "value": dns} for dns in dns_matches])
                # Extract IP addresses
                ip_matches = re.findall(r'IP Address:([^\s,]+)', san_text)
                sans.extend([{"type": "IP", "value": ip} for ip in ip_matches])
                
                if sans:
                    cert_info["subject_alternative_names"] = sans
                    cert_info["domains"] = [san["value"] for san in sans if san["type"] == "DNS"]
            
            # Extract signature algorithm
            sig_alg_match = re.search(r'Signature Algorithm: (.+)', output)
            if sig_alg_match:
                cert_info["signature_algorithm"] = sig_alg_match.group(1).strip()
            
            # Extract key size
            key_size_match = re.search(r'Public-Key:\s*\((\d+)\s+bit\)', output)
            if key_size_match:
                cert_info["key_size"] = int(key_size_match.group(1))
            
            return cert_info
            
        except FileNotFoundError:
            # openssl not available
            return None
        except Exception as e:
            logger.debug(f"Error extracting certificate info from {cert_path}: {e}")
            return None
    
    @staticmethod
    async def _extract_key_info(key_path: Path) -> Optional[Dict[str, Any]]:
        """Extract information from private key file"""
        try:
            with open(key_path, 'rb') as f:
                content = f.read()
            
            key_info = {}
            
            # Determine key type
            if b'BEGIN RSA PRIVATE KEY' in content:
                key_info["key_type"] = "RSA"
            elif b'BEGIN EC PRIVATE KEY' in content:
                key_info["key_type"] = "EC"
            elif b'BEGIN DSA PRIVATE KEY' in content:
                key_info["key_type"] = "DSA"
            elif b'BEGIN OPENSSH PRIVATE KEY' in content:
                key_info["key_type"] = "OpenSSH"
            elif b'BEGIN PRIVATE KEY' in content:
                key_info["key_type"] = "PKCS#8"
            else:
                key_info["key_type"] = "unknown"
            
            # Try to extract key size using openssl
            if key_info["key_type"] in ["RSA", "EC", "DSA"]:
                try:
                    rc, out, _ = await run_exec(
                        ["openssl", key_info["key_type"].lower(), "-in", str(key_path), "-text", "-noout"],
                        timeout=5,
                    )
                    if rc == 0 and out:
                        output = out
                        if key_info["key_type"] == "RSA":
                            size_match = re.search(r'Private-Key:\s*\((\d+)\s+bit\)', output)
                            if size_match:
                                key_info["key_size"] = int(size_match.group(1))
                except Exception:
                    pass
            
            return key_info
            
        except (PermissionError, IOError):
            return None
        except Exception as e:
            logger.debug(f"Error extracting key info from {key_path}: {e}")
            return None

