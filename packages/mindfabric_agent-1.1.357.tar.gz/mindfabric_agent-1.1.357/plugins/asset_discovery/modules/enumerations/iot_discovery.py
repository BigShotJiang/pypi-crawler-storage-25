"""
IoT and Embedded Device Discovery Module

IoT device discovery:
- MQTT broker discovery
- CoAP device discovery
- Bluetooth Low Energy discovery
- Zigbee/Z-Wave discovery
"""

import socket
import asyncio
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec


class IoTDeviceDiscovery:
    """IoT device discovery"""
    
    @staticmethod
    async def discover_mqtt_brokers() -> List[Dict[str, Any]]:
        """
        Discover MQTT brokers
        
        Returns:
            List of discovered MQTT brokers
        """
        brokers = []
        timestamp = datetime.utcnow().isoformat()
        
        # Common MQTT ports
        mqtt_ports = [1883, 8883, 8884]  # 1883 (non-TLS), 8883 (TLS), 8884 (TLS alternative)
        
        # Try to connect to localhost and common addresses
        targets = ["localhost", "127.0.0.1", "mosquitto", "mqtt"]

        async def _tcp_probe(host: str, port: int, timeout_s: float = 1.0) -> bool:
            try:
                r, w = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=timeout_s)
                w.close()
                try:
                    await w.wait_closed()
                except Exception:
                    pass
                return True
            except Exception:
                return False
        
        for target in targets:
            for port in mqtt_ports:
                try:
                    if await _tcp_probe(target, port, timeout_s=1.0):
                        brokers.append({
                            "host": target,
                            "port": port,
                            "protocol": "MQTT",
                            "tls": port in [8883, 8884],
                            "accessible": True,
                            "timestamp": timestamp
                        })
                except Exception:
                    continue
        
        # Also check for MQTT broker processes
        try:
            if psutil:
                for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                    try:
                        proc_info = proc.info
                        proc_name = proc_info.get('name', '').lower()
                        cmdline = " ".join(proc_info.get('cmdline', [])).lower()
                        
                        if 'mosquitto' in proc_name or 'mqtt' in proc_name or 'mosquitto' in cmdline:
                            brokers.append({
                                "host": "localhost",
                                "port": 1883,
                                "protocol": "MQTT",
                                "process": proc_info.get('name'),
                                "pid": proc_info['pid'],
                                "discovered_via": "process",
                                "timestamp": timestamp
                            })
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
        except Exception:
            pass
        
        return brokers
    
    @staticmethod
    async def discover_coap_devices() -> List[Dict[str, Any]]:
        """
        Discover CoAP devices
        
        Returns:
            List of discovered CoAP devices
        """
        devices = []
        timestamp = datetime.utcnow().isoformat()
        
        # CoAP uses UDP on port 5683
        coap_port = 5683
        
        try:
            # Try to discover CoAP devices via multicast
            # CoAP uses multicast address ff02::1 for link-local (IPv6)
            # or 224.0.1.187 for IPv4
            
            # Note: CoAP discovery requires CoAP library
            # This is a placeholder structure
            devices.append({
                "note": "CoAP discovery requires coap library (aiocoap, coapthon)",
                "multicast_addresses": {
                    "ipv4": "224.0.1.187",
                    "ipv6": "ff02::1"
                },
                "port": coap_port,
                "timestamp": timestamp
            })
            
        except Exception as e:
            logger.debug(f"Error discovering CoAP devices: {e}")
        
        return devices
    
    @staticmethod
    async def discover_bluetooth_devices() -> List[Dict[str, Any]]:
        """
        Discover Bluetooth Low Energy (BLE) devices
        
        Returns:
            List of discovered BLE devices
        """
        devices = []
        timestamp = datetime.utcnow().isoformat()
        
        try:
            # Use hcitool or bluetoothctl to scan for devices
            # Try hcitool first
            try:
                rc, out, _ = await run_exec(["hcitool", "scan"], timeout=10)
                if rc == 0 and out:
                    # Parse output
                    for line in out.split('\n')[1:]:  # Skip header
                        if line.strip():
                            parts = line.split('\t')
                            if len(parts) >= 2:
                                mac = parts[0].strip()
                                name = parts[1].strip()
                                
                                devices.append({
                                    "mac_address": mac,
                                    "name": name,
                                    "type": "Bluetooth",
                                    "discovery_method": "hcitool",
                                    "timestamp": timestamp
                                })
            except FileNotFoundError:
                # Try bluetoothctl
                try:
                    await run_exec(["bluetoothctl", "scan", "on"], timeout=5)
                    
                    # Note: bluetoothctl output parsing is more complex
                    # This is a placeholder
                    devices.append({
                        "note": "Bluetooth discovery requires bluetoothctl or hcitool",
                        "timestamp": timestamp
                    })
                except FileNotFoundError:
                    pass
                    
        except Exception as e:
            logger.debug(f"Error discovering Bluetooth devices: {e}")
        
        return devices
    
    @staticmethod
    async def discover_zigbee_networks() -> List[Dict[str, Any]]:
        """
        Discover Zigbee networks (requires Zigbee adapter)
        
        Returns:
            List of discovered Zigbee networks
        """
        networks = []
        timestamp = datetime.utcnow().isoformat()
        
        try:
            # Check for Zigbee adapter/devices
            # Common Zigbee adapters: CC2531, CC2538, Z-Stack
            
            # Check USB devices
            try:
                rc, out, _ = await run_exec(["lsusb"], timeout=2)
                if rc == 0 and out:
                    zigbee_keywords = ['cc2531', 'cc2538', 'zigbee', 'z-stack']
                    for line in out.split('\n'):
                        line_lower = line.lower()
                        if any(keyword in line_lower for keyword in zigbee_keywords):
                            networks.append({
                                "type": "Zigbee",
                                "adapter_found": True,
                                "usb_info": line.strip(),
                                "timestamp": timestamp
                            })
            except FileNotFoundError:
                pass
                
        except Exception as e:
            logger.debug(f"Error discovering Zigbee networks: {e}")
        
        return networks

