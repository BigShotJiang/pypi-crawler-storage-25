"""
OSINT (Open Source Intelligence) Discovery Module

Passive reconnaissance techniques:
- Certificate Transparency logs
- DNS history and passive DNS
- GitHub/GitLab dorking
- Public API enumeration
"""

import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_http import fetch


class OSINTDiscovery:
    """OSINT discovery techniques"""
    
    @staticmethod
    async def query_certificate_transparency(domain: str) -> Dict[str, Any]:
        """
        Query Certificate Transparency logs for subdomains
        
        Args:
            domain: Target domain
            
        Returns:
            Certificate Transparency results
        """
        result = {
            "domain": domain,
            "certificates": [],
            "subdomains": set(),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Query crt.sh
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            status, _, body = await fetch(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10, max_bytes=2_000_000)
            if status is None:
                result["error"] = "Failed to fetch crt.sh"
                return result
            if status != 200:
                result["error"] = f"HTTP error: {status}"
                return result

            data = json.loads((body or b"").decode("utf-8", errors="ignore") or "[]")
                
            for cert in data[:100]:  # Limit to 100
                name_value = cert.get('name_value', '')
                if name_value:
                    # Parse names (can be multiple)
                    names = re.split(r'[\n\r]+', name_value)
                    for name in names:
                        name = name.strip()
                        if name and domain in name:
                            result["subdomains"].add(name)
                            result["certificates"].append({
                                "name": name,
                                "issuer": cert.get('issuer_name', ''),
                                "not_before": cert.get('not_before', ''),
                                "not_after": cert.get('not_after', ''),
                                "id": cert.get('id')
                            })
                
            result["subdomains"] = list(result["subdomains"])
            result["total_subdomains"] = len(result["subdomains"])
            result["total_certificates"] = len(result["certificates"])
                
        except json.JSONDecodeError as e:
            result["error"] = f"Failed to parse crt.sh JSON: {e}"
        except Exception as e:
            logger.debug(f"Error querying Certificate Transparency for {domain}: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def search_github_dorking(domain: str, keywords: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Search GitHub for exposed information (dorking)
        
        Args:
            domain: Target domain
            keywords: Optional additional keywords
            
        Returns:
            GitHub search results
        """
        result = {
            "domain": domain,
            "searches": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if keywords is None:
            keywords = []
        
        # Common GitHub dork queries
        queries = [
            f"{domain} filename:config",
            f"{domain} filename:.env",
            f"{domain} password",
            f"{domain} API_KEY",
            f"{domain} SECRET",
            f"{domain} filename:docker-compose",
            f"{domain} filename:terraform.tfstate",
        ]
        
        queries.extend([f"{domain} {kw}" for kw in keywords[:5]])  # Limit
        
        # Note: GitHub API requires authentication for advanced searches
        # This is a placeholder for the logic structure
        result["note"] = "GitHub API requires authentication. Implement with GitHub API token."
        result["suggested_queries"] = queries
        
        return result
    
    @staticmethod
    async def query_passive_dns(domain: str) -> Dict[str, Any]:
        """
        Query passive DNS databases
        
        Args:
            domain: Target domain
            
        Returns:
            Passive DNS results
        """
        result = {
            "domain": domain,
            "ip_addresses": [],
            "dns_records": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Query SecurityTrails API (requires API key in production)
            # This is a placeholder structure
            result["note"] = "Passive DNS APIs require API keys (SecurityTrails, PassiveTotal, etc.)"
            result["available_services"] = [
                "SecurityTrails",
                "PassiveTotal",
                "VirusTotal",
                "Shodan"
            ]
            
        except Exception as e:
            logger.debug(f"Error querying passive DNS for {domain}: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def enumerate_shodan(domain_or_ip: str) -> Dict[str, Any]:
        """
        Query Shodan for information
        
        Args:
            domain_or_ip: Target domain or IP address
            
        Returns:
            Shodan results
        """
        result = {
            "target": domain_or_ip,
            "services": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Note: Shodan API requires API key
        result["note"] = "Shodan API requires API key. Implement with Shodan Python library."
        result["api_endpoint"] = f"https://api.shodan.io/shodan/host/{domain_or_ip}"
        
        return result

