"""
Cloud Service Enumeration Module

Enumerates cloud services and resources:
- S3 bucket discovery
- Azure storage account enumeration
- GCP bucket enumeration
- Cloud metadata API abuse
- Container registry discovery
- CI/CD pipeline discovery
"""

import json
import asyncio
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec, run_exec_stdout


class CloudServiceEnumerator:
    """Cloud service enumeration"""

    @staticmethod
    async def _http_status(host: str, path: str = "/", *, headers: Optional[Dict[str, str]] = None, timeout: float = 2.0) -> Optional[int]:
        """
        Minimal async HTTP GET to avoid blocking urllib.
        Returns status code or None.
        """
        hdrs = headers or {}
        hdr_lines = "".join([f"{k}: {v}\r\n" for k, v in hdrs.items()])
        req = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"Connection: close\r\n"
            f"{hdr_lines}\r\n"
        ).encode("utf-8", errors="ignore")
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 80), timeout=timeout)
            try:
                writer.write(req)
                await writer.drain()
                raw = await asyncio.wait_for(reader.read(128), timeout=timeout)
            finally:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            line = (raw or b"").split(b"\r\n", 1)[0].decode("utf-8", errors="ignore")
            if "HTTP/" not in line:
                return None
            try:
                return int(line.split()[1])
            except Exception:
                return None
        except Exception:
            return None

    @staticmethod
    async def _http_get_body(host: str, path: str = "/", *, headers: Optional[Dict[str, str]] = None, timeout: float = 2.0, max_bytes: int = 65536) -> Optional[bytes]:
        hdrs = headers or {}
        hdr_lines = "".join([f"{k}: {v}\r\n" for k, v in hdrs.items()])
        req = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"Connection: close\r\n"
            f"{hdr_lines}\r\n"
        ).encode("utf-8", errors="ignore")
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, 80), timeout=timeout)
            try:
                writer.write(req)
                await writer.drain()
                raw = await asyncio.wait_for(reader.read(max_bytes), timeout=timeout)
            finally:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            if not raw:
                return None
            sep = b"\r\n\r\n"
            if sep in raw:
                return raw.split(sep, 1)[1]
            return raw
        except Exception:
            return None
    
    @staticmethod
    async def discover_s3_buckets(domain: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Discover S3 buckets (public or misconfigured)
        
        Args:
            domain: Domain name to try bucket names based on
            
        Returns:
            List of discovered S3 buckets
        """
        buckets = []
        
        try:
            # Common bucket naming patterns
            bucket_names = []
            
            if domain:
                # Generate potential bucket names from domain
                domain_parts = domain.split('.')
                bucket_names.extend([
                    domain,
                    domain.replace('.', '-'),
                    f"{domain_parts[0]}-backup",
                    f"{domain_parts[0]}-dev",
                    f"{domain_parts[0]}-staging",
                    f"{domain_parts[0]}-prod",
                    f"www.{domain}",
                ])
            
            # Try to access buckets using AWS CLI or curl
            for bucket_name in bucket_names[:20]:  # Limit attempts
                try:
                    # Try AWS CLI
                    rc, out, _ = await run_exec(
                        ["aws", "s3", "ls", f"s3://{bucket_name}", "--no-sign-request"],
                        timeout=3,
                    )
                    if rc == 0 and out is not None:
                        buckets.append({
                            "name": bucket_name,
                            "provider": "AWS",
                            "accessible": True,
                            "public": True,
                            "files": (out or "").split('\n')[:10],  # First 10 files
                            "timestamp": datetime.utcnow().isoformat()
                        })
                except FileNotFoundError:
                    # Try HTTP access
                    try:
                        url = f"http://{bucket_name}.s3.amazonaws.com"
                        status = await CloudServiceEnumerator._http_status(f"{bucket_name}.s3.amazonaws.com", "/", timeout=2)
                        if status == 200:
                            buckets.append({
                                "name": bucket_name,
                                "provider": "AWS",
                                "accessible": True,
                                "public": True,
                                "url": url,
                                "timestamp": datetime.utcnow().isoformat()
                            })
                    except Exception:
                        pass
                except asyncio.TimeoutError:
                    continue
                except Exception:
                    continue
                    
        except Exception as e:
            logger.debug(f"Error discovering S3 buckets: {e}")
        
        return buckets
    
    @staticmethod
    async def enumerate_cloud_metadata() -> Dict[str, Any]:
        """
        Enumerate cloud metadata APIs (IMDS)
        
        Returns:
            Cloud metadata information
        """
        metadata = {
            "aws": {},
            "azure": {},
            "gcp": {},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # AWS Instance Metadata Service
        try:
            status = await CloudServiceEnumerator._http_status("169.254.169.254", "/latest/meta-data/", timeout=2)
            if status == 200:
                metadata["aws"]["accessible"] = True
                body = await CloudServiceEnumerator._http_get_body("169.254.169.254", "/latest/meta-data/", timeout=2, max_bytes=32768)
                if body:
                    metadata["aws"]["endpoints"] = body.decode('utf-8', errors="ignore").split('\n')
                try:
                    body2 = await CloudServiceEnumerator._http_get_body("169.254.169.254", "/latest/meta-data/instance-id", timeout=2, max_bytes=1024)
                    if body2:
                        metadata["aws"]["instance_id"] = body2.decode('utf-8', errors="ignore").strip()
                except Exception:
                    pass
        except Exception:
            pass
        
        # Azure Instance Metadata Service
        try:
            status = await CloudServiceEnumerator._http_status(
                "169.254.169.254",
                "/metadata/instance?api-version=2021-02-01",
                headers={"Metadata": "true"},
                timeout=2,
            )
            if status == 200:
                metadata["azure"]["accessible"] = True
                body = await CloudServiceEnumerator._http_get_body(
                    "169.254.169.254",
                    "/metadata/instance?api-version=2021-02-01",
                    headers={"Metadata": "true"},
                    timeout=2,
                    max_bytes=65536,
                )
                if body:
                    data = json.loads(body.decode('utf-8', errors="ignore"))
                    metadata["azure"]["data"] = data
        except Exception:
            pass
        
        # GCP Metadata Service
        try:
            status = await CloudServiceEnumerator._http_status(
                "metadata.google.internal",
                "/computeMetadata/v1/instance/",
                headers={"Metadata-Flavor": "Google"},
                timeout=2,
            )
            if status == 200:
                metadata["gcp"]["accessible"] = True
                body = await CloudServiceEnumerator._http_get_body(
                    "metadata.google.internal",
                    "/computeMetadata/v1/instance/",
                    headers={"Metadata-Flavor": "Google"},
                    timeout=2,
                    max_bytes=32768,
                )
                if body:
                    metadata["gcp"]["endpoints"] = body.decode('utf-8', errors="ignore").split('\n')
        except Exception:
            pass
        
        return metadata
    
    @staticmethod
    async def discover_container_registries() -> List[Dict[str, Any]]:
        """
        Discover container registries (Docker Hub, ECR, GCR, ACR)
        
        Returns:
            List of discovered registries
        """
        registries = []
        
        try:
            # Check Docker config for registries
            docker_config_paths = [
                Path.home() / ".docker" / "config.json",
                Path("/root/.docker/config.json"),
            ]
            
            for config_path in docker_config_paths:
                if config_path.exists():
                    try:
                        with open(config_path, 'r') as f:
                            config = json.load(f)
                            
                            # Extract auths (registries)
                            auths = config.get("auths", {})
                            for registry_url in auths.keys():
                                registries.append({
                                    "url": registry_url,
                                    "authenticated": True,
                                    "config_file": str(config_path),
                                    "timestamp": datetime.utcnow().isoformat()
                                })
                    except (json.JSONDecodeError, IOError):
                        continue
            
            # Check for ECR (AWS)
            try:
                out = await run_exec_stdout(["aws", "ecr", "describe-repositories"], timeout=5)
                if out:
                    data = json.loads(out)
                    for repo in data.get("repositories", []):
                        registries.append({
                            "url": repo.get("repositoryUri"),
                            "provider": "AWS ECR",
                            "repository_name": repo.get("repositoryName"),
                            "timestamp": datetime.utcnow().isoformat()
                        })
            except (FileNotFoundError, json.JSONDecodeError):
                pass
            except asyncio.TimeoutError:
                pass
                
        except Exception as e:
            logger.debug(f"Error discovering container registries: {e}")
        
        return registries
    
    @staticmethod
    async def discover_cicd_pipelines() -> List[Dict[str, Any]]:
        """
        Discover CI/CD pipeline configurations
        
        Returns:
            List of discovered CI/CD pipelines
        """
        pipelines = []
        
        # Common CI/CD config files (recursive under each root — not from "/" to avoid /proc etc.)
        cicd_patterns = [
            "**/.github/workflows/*.yml",
            "**/.github/workflows/*.yaml",
            "**/.gitlab-ci.yml",
            "**/.circleci/config.yml",
            "**/.travis.yml",
            "**/Jenkinsfile",
            "**/azure-pipelines.yml",
            "**/.drone.yml",
        ]
        
        # Never glob from "/" — same proc/sys pitfalls as other recursive scans.
        _cicd_roots = []
        for r in ("/home", "/root", "/opt", "/srv", "/var", "/usr/local", "/app", "/mnt"):
            try:
                rp = Path(r)
                if rp.is_dir():
                    _cicd_roots.append(rp)
            except OSError:
                continue
        try:
            for pattern in cicd_patterns:
                for root in _cicd_roots:
                    try:
                        matches = root.glob(pattern)
                    except OSError:
                        continue
                    for config_file in matches:
                        if config_file.exists() and config_file.is_file():
                            try:
                                with open(config_file, 'r', encoding='utf-8', errors='ignore') as f:
                                    content = f.read(1024)  # Read first KB
                                    
                                    # Detect CI/CD type
                                    cicd_type = "unknown"
                                    if "github" in str(config_file) or "workflow" in str(config_file):
                                        cicd_type = "GitHub Actions"
                                    elif "gitlab" in str(config_file):
                                        cicd_type = "GitLab CI"
                                    elif "circleci" in str(config_file):
                                        cicd_type = "CircleCI"
                                    elif "travis" in str(config_file):
                                        cicd_type = "Travis CI"
                                    elif "jenkins" in str(config_file).lower():
                                        cicd_type = "Jenkins"
                                    elif "azure" in str(config_file):
                                        cicd_type = "Azure Pipelines"
                                    
                                    pipelines.append({
                                        "config_file": str(config_file),
                                        "type": cicd_type,
                                        "size": config_file.stat().st_size,
                                        "modified": datetime.fromtimestamp(config_file.stat().st_mtime).isoformat(),
                                        "timestamp": datetime.utcnow().isoformat()
                                    })
                            except (PermissionError, IOError):
                                continue
        except Exception as e:
            logger.debug(f"Error discovering CI/CD pipelines: {e}")
        
        return pipelines

