"""
Service Enumeration Module

Advanced service discovery and enumeration:
- SNMP enumeration
- SMB share enumeration
- LDAP/Active Directory enumeration
- Database enumeration
- Service version detection (banner grabbing)
- Web technology detection
"""

import asyncio
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_subprocess import run_exec


class ServiceEnumerator:
    """Advanced service enumeration"""
    
    @staticmethod
    async def enumerate_snmp(ip: str, community: str = "public") -> Dict[str, Any]:
        """
        Enumerate SNMP service
        
        Args:
            ip: Target IP address
            community: SNMP community string
            
        Returns:
            SNMP enumeration results
        """
        # Normal case: no target provided -> skip silently.
        if not ip:
            return {}

        result = {
            "ip": ip,
            "port": 161,
            "protocol": "SNMP",
            "accessible": False,
            "system_info": {},
            "interfaces": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try snmpwalk for system information
            rc, out, _ = await run_exec(
                ["snmpwalk", "-v2c", "-c", community, ip, "system"],
                timeout=5,
            )
            if rc == 0 and out:
                result["accessible"] = True
                output = out
                
                # Parse system information
                sys_name_match = re.search(r'SNMPv2-MIB::sysName\.0 = STRING: (.+)', output)
                if sys_name_match:
                    result["system_info"]["sysName"] = sys_name_match.group(1).strip()
                
                sys_desc_match = re.search(r'SNMPv2-MIB::sysDescr\.0 = STRING: (.+)', output)
                if sys_desc_match:
                    result["system_info"]["sysDescr"] = sys_desc_match.group(1).strip()
                
                # Try to enumerate interfaces
                rc2, out2, _ = await run_exec(
                    ["snmpwalk", "-v2c", "-c", community, ip, "ifDescr"],
                    timeout=5,
                )
                if rc2 == 0 and out2:
                    interfaces = re.findall(r'IF-MIB::ifDescr\.(\d+) = STRING: (.+)', out2)
                    result["interfaces"] = [{"index": idx, "description": desc.strip()} for idx, desc in interfaces]
                    
        except FileNotFoundError:
            # snmpwalk not available (normal in minimal envs)
            pass
        except asyncio.TimeoutError:
            # Timeout is an expected outcome on many hosts; keep quiet.
            result["timeout"] = True
        except Exception:
            # SNMP may be absent/blocked; treat as normal and keep quiet.
            pass
        
        return result
    
    @staticmethod
    async def enumerate_smb(ip: str) -> Dict[str, Any]:
        """
        Enumerate SMB shares
        
        Args:
            ip: Target IP address
            
        Returns:
            SMB enumeration results
        """
        # Normal case: no target provided -> skip silently.
        if not ip:
            return {}

        result = {
            "ip": ip,
            "port": 445,
            "protocol": "SMB",
            "accessible": False,
            "shares": [],
            "users": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try smbclient to list shares
            rc, out, _ = await run_exec(
                ["smbclient", "-L", ip, "-N"],  # -N for no password
                timeout=5,
            )
            if rc == 0 and out:
                result["accessible"] = True
                output = out
                
                # Parse shares
                share_pattern = r'^\s+(\S+)\s+(Disk|Printer)'
                for line in output.split('\n'):
                    match = re.match(share_pattern, line)
                    if match:
                        result["shares"].append({
                            "name": match.group(1),
                            "type": match.group(2)
                        })
            
            # Try enum4linux or rpcclient for user enumeration
            try:
                rc2, out2, _ = await run_exec(
                    ["rpcclient", "-U", "", "-N", ip, "-c", "enumdomusers"],
                    timeout=5,
                )
                if rc2 == 0 and out2:
                    # Parse users
                    user_pattern = r'user:\[([^\]]+)\]'
                    users = re.findall(user_pattern, out2)
                    result["users"] = users
            except FileNotFoundError:
                pass
                
        except FileNotFoundError:
            # smbclient not available (normal in minimal envs)
            pass
        except asyncio.TimeoutError:
            # Timeout is an expected outcome on many hosts; keep quiet.
            result["timeout"] = True
        except Exception:
            # SMB may be absent/blocked; treat as normal and keep quiet.
            pass
        
        return result
    
    @staticmethod
    async def enumerate_ldap(ip: str, port: int = 389) -> Dict[str, Any]:
        """
        Enumerate LDAP/Active Directory
        
        Args:
            ip: Target IP address
            port: LDAP port (389 or 636 for LDAPS)
            
        Returns:
            LDAP enumeration results
        """
        result = {
            "ip": ip,
            "port": port,
            "protocol": "LDAP",
            "accessible": False,
            "base_dn": None,
            "domain": None,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try ldapsearch for anonymous bind
            rc, out, _ = await run_exec(
                ["ldapsearch", "-x", "-H", f"ldap://{ip}:{port}", "-b", "", "-s", "base", "namingContexts"],
                timeout=5,
            )
            if rc == 0 and out:
                result["accessible"] = True
                output = out
                
                # Parse base DN
                dn_match = re.search(r'namingContexts:\s*(.+)', output)
                if dn_match:
                    result["base_dn"] = dn_match.group(1).strip()
                    # Extract domain from DN
                    domain_parts = re.findall(r'DC=([^,]+)', result["base_dn"])
                    if domain_parts:
                        result["domain"] = ".".join(domain_parts)
                        
        except FileNotFoundError:
            # ldapsearch not available
            pass
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error enumerating LDAP on {ip}:{port}: {e}")
        
        return result
    
    @staticmethod
    async def grab_banner(ip: str, port: int, timeout: float = 2.0) -> Optional[Dict[str, Any]]:
        """
        Grab service banner for version detection
        
        Args:
            ip: Target IP address
            port: Target port
            timeout: Connection timeout
            
        Returns:
            Banner information
        """
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout=timeout)
            try:
                # Many services send a banner immediately; read a small chunk with a tight timeout.
                data = await asyncio.wait_for(reader.read(1024), timeout=timeout)
            finally:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass

            banner = (data or b"").decode('utf-8', errors='ignore').strip()
            if banner:
                return {
                    "ip": ip,
                    "port": port,
                    "banner": banner,
                    "timestamp": datetime.utcnow().isoformat()
                }

        except Exception as e:
            logger.debug(f"Error grabbing banner from {ip}:{port}: {e}")
        
        return None
    
    @staticmethod
    async def detect_web_technologies(url: str) -> Dict[str, Any]:
        """
        Detect web technologies (Wappalyzer-like)
        
        Args:
            url: Target URL
            
        Returns:
            Detected technologies
        """
        technologies = {
            "url": url,
            "server": None,
            "framework": None,
            "cms": None,
            "database": None,
            "languages": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            from urllib.parse import urlparse
            import ssl

            parsed = urlparse(url)
            scheme = (parsed.scheme or "http").lower()
            host = parsed.hostname
            if not host:
                return technologies
            port = parsed.port or (443 if scheme == "https" else 80)
            path = parsed.path or "/"
            if parsed.query:
                path = f"{path}?{parsed.query}"

            ctx = None
            if scheme == "https":
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE

            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port, ssl=ctx, server_hostname=host if ctx else None),
                timeout=3,
            )
            try:
                req = (
                    f"GET {path} HTTP/1.1\r\n"
                    f"Host: {host}\r\n"
                    f"User-Agent: Mozilla/5.0\r\n"
                    f"Connection: close\r\n\r\n"
                ).encode("utf-8", errors="ignore")
                writer.write(req)
                await writer.drain()
                raw = await asyncio.wait_for(reader.read(8192), timeout=3)
            finally:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass

            text = (raw or b"").decode("utf-8", errors="ignore")
            hdrs, _, body = text.partition("\r\n\r\n")
            headers = {}
            for line in hdrs.splitlines()[1:]:
                if ":" in line:
                    k, v = line.split(":", 1)
                    headers[k.strip().lower()] = v.strip()

            server = headers.get("server", "")
            if server:
                technologies["server"] = server
                if 'nginx' in server.lower():
                    technologies["server_type"] = "Nginx"
                elif 'apache' in server.lower():
                    technologies["server_type"] = "Apache"
                elif 'iis' in server.lower():
                    technologies["server_type"] = "IIS"

            powered_by = headers.get("x-powered-by", "")
            if powered_by:
                technologies["framework"] = powered_by

            content = (body or "")[:8192]
            if 'wp-content' in content or 'wp-includes' in content:
                technologies["cms"] = "WordPress"
            elif 'drupal' in content.lower():
                technologies["cms"] = "Drupal"
            elif 'joomla' in content.lower():
                technologies["cms"] = "Joomla"

            if 'react' in content.lower() or 'React' in content:
                technologies["languages"].append("React")
            if 'vue' in content.lower() or 'Vue' in content:
                technologies["languages"].append("Vue")
            if 'angular' in content.lower():
                technologies["languages"].append("Angular")

        except Exception as e:
            logger.debug(f"Error detecting web technologies for {url}: {e}")
        
        return technologies
    
    @staticmethod
    async def enumerate_database(ip: str, port: int, db_type: str) -> Dict[str, Any]:
        """
        Enumerate database information
        
        Args:
            ip: Target IP address
            port: Database port
            db_type: Database type (postgres, mysql, mongodb, etc.)
            
        Returns:
            Database enumeration results
        """
        result = {
            "ip": ip,
            "port": port,
            "db_type": db_type,
            "accessible": False,
            "version": None,
            "databases": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            if db_type == "postgres":
                # Try to get PostgreSQL version
                rc, out, _ = await run_exec(
                    ["psql", "-h", ip, "-p", str(port), "-U", "postgres", "-c", "SELECT version();"],
                    timeout=3,
                    stdin="\n",
                )
                if rc == 0 and out:
                    result["accessible"] = True
                    version_match = re.search(r'PostgreSQL\s+([\d.]+)', out)
                    if version_match:
                        result["version"] = version_match.group(1)
            
            elif db_type == "mysql":
                # Try to get MySQL version
                rc, out, _ = await run_exec(
                    ["mysql", "-h", ip, "-P", str(port), "-u", "root", "-e", "SELECT VERSION();"],
                    timeout=3,
                )
                if rc == 0 and out:
                    result["accessible"] = True
                    version_match = re.search(r'(\d+\.\d+\.\d+)', out)
                    if version_match:
                        result["version"] = version_match.group(1)
            
            elif db_type == "mongodb":
                # Try MongoDB connection
                rc, out, _ = await run_exec(
                    ["mongo", f"{ip}:{port}", "--eval", "db.version()"],
                    timeout=3,
                )
                if rc == 0 and out:
                    result["accessible"] = True
                    version_match = re.search(r'(\d+\.\d+\.\d+)', out)
                    if version_match:
                        result["version"] = version_match.group(1)
                        
        except FileNotFoundError:
            # Database client not available
            pass
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error enumerating {db_type} on {ip}:{port}: {e}")
        
        return result

