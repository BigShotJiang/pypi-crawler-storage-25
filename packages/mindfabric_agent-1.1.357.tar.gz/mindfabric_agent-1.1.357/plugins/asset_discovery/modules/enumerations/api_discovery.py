"""
API Endpoint Discovery Module

Discovers API endpoints through:
- OpenAPI/Swagger specifications
- GraphQL schemas
- REST API endpoints from logs
- gRPC service definitions (.proto files)
- WSDL files (SOAP)
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from utils.logger import logger

# When root_dir is "/", never run pathlib ** globs from the real FS root: that traverses
# /proc, /sys, /dev, ... and can raise OSError (Errno 22) on paths like /proc/.../task/.../net.
_DEFAULT_SPEC_SCAN_ROOTS: Tuple[str, ...] = (
    "/etc",
    "/home",
    "/root",
    "/opt",
    "/srv",
    "/usr/local",
    "/var/www",
    "/var/lib",
    "/app",
    "/mnt",
)


class APIDiscovery:
    """API endpoint discovery module"""
    
    # Common API specification file patterns
    API_PATTERNS = [
        "**/swagger.json",
        "**/swagger.yaml",
        "**/swagger.yml",
        "**/openapi.json",
        "**/openapi.yaml",
        "**/openapi.yml",
        "**/*.proto",  # gRPC
        "**/*.wsdl",  # SOAP
        "**/*.graphql",
        "**/schema.graphql"
    ]

    @staticmethod
    def _spec_search_roots(root_dir: str) -> List[Path]:
        try:
            p = Path(root_dir).resolve()
        except OSError:
            return []
        if str(p) == "/" or root_dir in ("/", ""):
            roots: List[Path] = []
            for r in _DEFAULT_SPEC_SCAN_ROOTS:
                try:
                    rp = Path(r)
                    if rp.is_dir():
                        roots.append(rp)
                except OSError:
                    continue
            return roots if roots else [p]
        return [p]
    
    @staticmethod
    async def discover_api_endpoints(root_dir: str = "/", max_files: int = 200) -> List[Dict[str, Any]]:
        """
        Discover API endpoints from various sources
        
        Args:
            root_dir: Root directory to search
            max_files: Maximum number of files to analyze
            
        Returns:
            List of discovered API endpoints
        """
        endpoints = []
        
        # Discover from specification files
        spec_endpoints = await APIDiscovery._discover_from_specs(root_dir, max_files)
        endpoints.extend(spec_endpoints)
        
        # Discover from logs (if accessible)
        log_endpoints = await APIDiscovery._discover_from_logs(root_dir)
        endpoints.extend(log_endpoints)
        
        return endpoints
    
    @staticmethod
    async def _discover_from_specs(root_dir: str, max_files: int) -> List[Dict[str, Any]]:
        """Discover API endpoints from specification files"""
        endpoints = []
        roots = APIDiscovery._spec_search_roots(root_dir)
        
        for pattern in APIDiscovery.API_PATTERNS:
            count = 0
            for root_path in roots:
                if count >= max_files:
                    break
                try:
                    spec_iter = root_path.glob(pattern)
                except OSError:
                    continue
                for spec_file in spec_iter:
                    if count >= max_files:
                        break
                    try:
                        if spec_file.is_file() and spec_file.stat().st_size < 10 * 1024 * 1024:  # Max 10MB
                            parsed = await APIDiscovery._parse_spec_file(spec_file)
                            if parsed:
                                endpoints.extend(parsed)
                                count += 1
                    except (PermissionError, IOError, OSError):
                        continue
                    except Exception as e:
                        logger.debug(f"Error processing spec file {spec_file}: {e}")
                        continue
        
        return endpoints
    
    @staticmethod
    async def _parse_spec_file(spec_file: Path) -> List[Dict[str, Any]]:
        """Parse a specification file and extract endpoints"""
        endpoints = []
        
        try:
            suffix = spec_file.suffix.lower()
            
            if suffix == '.proto':
                # gRPC service definition
                grpc_endpoints = await APIDiscovery._parse_proto_file(spec_file)
                endpoints.extend(grpc_endpoints)
            elif suffix in ['.yaml', '.yml', '.json']:
                # OpenAPI/Swagger
                openapi_endpoints = await APIDiscovery._parse_openapi_file(spec_file)
                endpoints.extend(openapi_endpoints)
            elif suffix == '.wsdl':
                # SOAP WSDL
                wsdl_endpoints = await APIDiscovery._parse_wsdl_file(spec_file)
                endpoints.extend(wsdl_endpoints)
            elif suffix == '.graphql' or 'graphql' in spec_file.name.lower():
                # GraphQL schema
                graphql_endpoints = await APIDiscovery._parse_graphql_file(spec_file)
                endpoints.extend(graphql_endpoints)
                
        except Exception as e:
            logger.debug(f"Error parsing spec file {spec_file}: {e}")
        
        return endpoints
    
    @staticmethod
    async def _parse_openapi_file(spec_file: Path) -> List[Dict[str, Any]]:
        """Parse OpenAPI/Swagger specification"""
        endpoints = []
        
        try:
            with open(spec_file, 'r', encoding='utf-8', errors='ignore') as f:
                if spec_file.suffix == '.json':
                    spec = json.load(f)
                else:
                    import yaml
                    spec = yaml.safe_load(f)
            
            if not spec:
                return endpoints
            
            # Determine version
            openapi_version = spec.get('openapi') or spec.get('swagger', '2.0')
            
            # Get base URL
            servers = spec.get('servers', [])
            if not servers and 'host' in spec:
                # Swagger 2.0
                base_url = f"{spec.get('schemes', ['http'])[0]}://{spec.get('host', '')}"
                if spec.get('basePath'):
                    base_url += spec['basePath']
            elif servers:
                base_url = servers[0].get('url', '')
            else:
                base_url = ''
            
            # Extract paths
            paths = spec.get('paths', {})
            for path, methods in paths.items():
                if not isinstance(methods, dict):
                    continue
                
                for method, operation in methods.items():
                    if method.upper() in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS']:
                        endpoint = {
                            "method": method.upper(),
                            "path": path,
                            "full_url": f"{base_url}{path}" if base_url else path,
                            "spec_file": str(spec_file),
                            "spec_type": "OpenAPI" if 'openapi' in spec else "Swagger",
                            "spec_version": openapi_version,
                            "operation_id": operation.get('operationId'),
                            "summary": operation.get('summary'),
                            "description": operation.get('description'),
                            "tags": operation.get('tags', []),
                            "parameters": operation.get('parameters', []),
                            "security": operation.get('security', []),
                            "discovered_from": "spec_file"
                        }
                        endpoints.append(endpoint)
                        
        except (json.JSONDecodeError, KeyError, IOError, PermissionError) as e:
            logger.debug(f"Error parsing OpenAPI file {spec_file}: {e}")
        except ImportError:
            # yaml module not available
            logger.debug("yaml module not available for parsing YAML files")
        
        return endpoints
    
    @staticmethod
    async def _parse_proto_file(proto_file: Path) -> List[Dict[str, Any]]:
        """Parse gRPC .proto file"""
        endpoints = []
        
        try:
            with open(proto_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract service definitions
            service_pattern = r'service\s+(\w+)\s*\{([^}]+)\}'
            service_matches = re.finditer(service_pattern, content, re.DOTALL)
            
            for service_match in service_matches:
                service_name = service_match.group(1)
                service_body = service_match.group(2)
                
                # Extract RPC methods
                rpc_pattern = r'rpc\s+(\w+)\s*\([^)]+\)\s*(?:returns\s*\([^)]+\))?\s*;'
                rpc_matches = re.finditer(rpc_pattern, service_body)
                
                for rpc_match in rpc_matches:
                    method_name = rpc_match.group(1)
                    endpoint = {
                        "service": service_name,
                        "method": method_name,
                        "protocol": "gRPC",
                        "spec_file": str(proto_file),
                        "full_path": f"/{service_name}/{method_name}",
                        "discovered_from": "proto_file"
                    }
                    endpoints.append(endpoint)
                    
        except (IOError, PermissionError) as e:
            logger.debug(f"Error parsing proto file {proto_file}: {e}")
        
        return endpoints
    
    @staticmethod
    async def _parse_wsdl_file(wsdl_file: Path) -> List[Dict[str, Any]]:
        """Parse SOAP WSDL file"""
        endpoints = []
        
        try:
            with open(wsdl_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract service definitions (simplified parsing)
            # WSDL can be complex, this is a basic extraction
            service_pattern = r'<service\s+name="([^"]+)"[^>]*>'
            services = re.findall(service_pattern, content)
            
            # Extract port definitions
            port_pattern = r'<port\s+name="([^"]+)"[^>]*>'
            ports = re.findall(port_pattern, content)
            
            # Extract binding names
            binding_pattern = r'<binding\s+name="([^"]+)"[^>]*>'
            bindings = re.findall(binding_pattern, content)
            
            # Extract operations (simplified)
            operation_pattern = r'<operation\s+name="([^"]+)"'
            operations = re.findall(operation_pattern, content)
            
            for operation in operations:
                endpoint = {
                    "operation": operation,
                    "protocol": "SOAP",
                    "services": services,
                    "ports": ports,
                    "bindings": bindings,
                    "spec_file": str(wsdl_file),
                    "discovered_from": "wsdl_file"
                }
                endpoints.append(endpoint)
                
        except (IOError, PermissionError) as e:
            logger.debug(f"Error parsing WSDL file {wsdl_file}: {e}")
        
        return endpoints
    
    @staticmethod
    async def _parse_graphql_file(graphql_file: Path) -> List[Dict[str, Any]]:
        """Parse GraphQL schema file"""
        endpoints = []
        
        try:
            with open(graphql_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract type definitions
            type_pattern = r'type\s+(\w+)\s*\{([^}]+)\}'
            types = re.findall(type_pattern, content)
            
            # Extract Query type (main GraphQL endpoint)
            query_types = [t for t in types if t[0] == 'Query' or t[0] == 'query']
            
            for query_type, query_body in query_types:
                # Extract fields (queries)
                field_pattern = r'(\w+)\s*\([^)]*\)\s*:\s*([^\s{]+)'
                fields = re.findall(field_pattern, query_body)
                
                for field_name, field_type in fields:
                    endpoint = {
                        "query": field_name,
                        "return_type": field_type,
                        "protocol": "GraphQL",
                        "spec_file": str(graphql_file),
                        "full_path": "/graphql",
                        "discovered_from": "graphql_file"
                    }
                    endpoints.append(endpoint)
            
            # Extract Mutation type
            mutation_types = [t for t in types if t[0] == 'Mutation' or t[0] == 'mutation']
            for mutation_type, mutation_body in mutation_types:
                field_pattern = r'(\w+)\s*\([^)]*\)\s*:\s*([^\s{]+)'
                fields = re.findall(field_pattern, mutation_body)
                
                for field_name, field_type in fields:
                    endpoint = {
                        "mutation": field_name,
                        "return_type": field_type,
                        "protocol": "GraphQL",
                        "spec_file": str(graphql_file),
                        "full_path": "/graphql",
                        "discovered_from": "graphql_file"
                    }
                    endpoints.append(endpoint)
                    
        except (IOError, PermissionError) as e:
            logger.debug(f"Error parsing GraphQL file {graphql_file}: {e}")
        
        return endpoints
    
    @staticmethod
    async def _discover_from_logs(root_dir: str) -> List[Dict[str, Any]]:
        """Discover API endpoints from log files"""
        endpoints = []
        
        # Common log locations
        log_paths = [
            "/var/log/nginx/access.log",
            "/var/log/apache2/access.log",
            "/var/log/httpd/access_log",
            "/var/www/*/logs/access.log"
        ]
        
        # HTTP method and path pattern
        http_pattern = re.compile(r'(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+(/[^\s?]+)')
        
        for log_path_pattern in log_paths:
            try:
                for log_file in Path(root_dir).glob(log_path_pattern.lstrip(root_dir).lstrip('/')):
                    if log_file.is_file():
                        try:
                            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                                # Read last 1000 lines to avoid processing huge files
                                lines = f.readlines()[-1000:]
                                
                                seen_endpoints = set()
                                for line in lines:
                                    matches = http_pattern.findall(line)
                                    for method, path in matches:
                                        key = f"{method}:{path}"
                                        if key not in seen_endpoints:
                                            seen_endpoints.add(key)
                                            endpoint = {
                                                "method": method,
                                                "path": path,
                                                "protocol": "HTTP",
                                                "log_file": str(log_file),
                                                "discovered_from": "log_file"
                                            }
                                            endpoints.append(endpoint)
                        except (IOError, PermissionError):
                            continue
            except Exception as e:
                logger.debug(f"Error discovering from logs {log_path_pattern}: {e}")
        
        return endpoints

