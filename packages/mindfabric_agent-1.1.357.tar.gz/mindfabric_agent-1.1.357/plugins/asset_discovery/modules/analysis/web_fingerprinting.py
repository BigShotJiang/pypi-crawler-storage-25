"""
Web Application Fingerprinting Module

Deep web application fingerprinting:
- Framework detection (headers, URL patterns, error messages)
- Version detection
- Technology stack analysis
- CMS detection
"""

import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_http import fetch


class WebFingerprinter:
    """Web application fingerprinting"""
    
    # Framework signatures
    FRAMEWORK_SIGNATURES = {
        "Django": [
            (r'csrfmiddlewaretoken', 'form'),
            (r'__jsi18n__', 'html'),
            (r'/static/admin/', 'url'),
        ],
        "Rails": [
            (r'_rails_session', 'cookie'),
            (r'/assets/application-', 'url'),
            (r'csrf-token', 'html'),
        ],
        "Laravel": [
            (r'laravel_session', 'cookie'),
            (r'XSRF-TOKEN', 'header'),
        ],
        "Symfony": [
            (r'SYMONY', 'header'),
            (r'/bundles/', 'url'),
        ],
        "Spring": [
            (r'JSESSIONID', 'cookie'),
            (r'org.springframework', 'error'),
        ],
        "Express": [
            (r'X-Powered-By: Express', 'header'),
            (r'express', 'server'),
        ],
        "Flask": [
            (r'flask', 'server'),
            (r'Werkzeug', 'server'),
        ],
    }
    
    # CMS signatures
    CMS_SIGNATURES = {
        "WordPress": [
            (r'/wp-content/', 'url'),
            (r'/wp-includes/', 'url'),
            (r'wp-json', 'url'),
            (r'wordpress', 'generator'),
        ],
        "Drupal": [
            (r'/sites/default/files/', 'url'),
            (r'Drupal', 'generator'),
            (r'/modules/', 'url'),
        ],
        "Joomla": [
            (r'/administrator/', 'url'),
            (r'/components/', 'url'),
            (r'Joomla!', 'generator'),
        ],
        "Magento": [
            (r'/skin/frontend/', 'url'),
            (r'Magento', 'generator'),
        ],
    }
    
    @staticmethod
    async def fingerprint_application(url: str, timeout: float = 5.0) -> Dict[str, Any]:
        """
        Fingerprint web application
        
        Args:
            url: Target URL
            timeout: Request timeout
            
        Returns:
            Fingerprinting results
        """
        result = {
            "url": url,
            "server": None,
            "server_version": None,
            "frameworks": [],
            "cms": None,
            "languages": [],
            "technologies": [],
            "version_hints": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            status, headers_lc, body = await fetch(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
                timeout=timeout,
                max_bytes=16384,
            )
            if status is None:
                return result

            # Rebuild header dict with title-case keys for backward-compat-ish access
            headers = {k.title(): v for k, v in (headers_lc or {}).items()}

            # Server header
            server = headers.get('Server', '')
            if server:
                result["server"] = server
                # Try to extract version
                version_match = re.search(r'(\d+\.\d+(?:\.\d+)?)', server)
                if version_match:
                    result["server_version"] = version_match.group(1)
                
                # Detect server type
                server_lower = server.lower()
                if 'nginx' in server_lower:
                    result["server_type"] = "Nginx"
                elif 'apache' in server_lower:
                    result["server_type"] = "Apache"
                    # Try to extract Apache version
                    apache_match = re.search(r'Apache/(\d+\.\d+(?:\.\d+)?)', server)
                    if apache_match:
                        result["server_version"] = apache_match.group(1)
                elif 'iis' in server_lower:
                    result["server_type"] = "IIS"
                elif 'cloudflare' in server_lower:
                    result["server_type"] = "Cloudflare"
            
            # X-Powered-By header
            powered_by = headers.get('X-Powered-By', '')
            if powered_by:
                result["technologies"].append(powered_by)
                
                # Detect framework from X-Powered-By
                if 'PHP' in powered_by:
                    result["languages"].append("PHP")
                    php_match = re.search(r'PHP/(\d+\.\d+(?:\.\d+)?)', powered_by)
                    if php_match:
                        result["version_hints"].append(f"PHP {php_match.group(1)}")
                elif 'ASP.NET' in powered_by:
                    result["languages"].append(".NET")
                elif 'Express' in powered_by:
                    result["frameworks"].append("Express.js")
            
            # X-Framework header
            framework = headers.get('X-Framework', '')
            if framework:
                result["frameworks"].append(framework)
            
            # Content
            content = (body or b"").decode('utf-8', errors='ignore')
            url_path = url

            # Framework detection
            for framework_name, patterns in WebFingerprinter.FRAMEWORK_SIGNATURES.items():
                for pattern, location in patterns:
                    if location == 'header' and pattern.lower() in str(headers).lower():
                        if framework_name not in result["frameworks"]:
                            result["frameworks"].append(framework_name)
                    elif location == 'url' and re.search(pattern, url_path, re.I):
                        if framework_name not in result["frameworks"]:
                            result["frameworks"].append(framework_name)
                    elif location in ['html', 'form', 'cookie', 'error'] and re.search(pattern, content, re.I):
                        if framework_name not in result["frameworks"]:
                            result["frameworks"].append(framework_name)
            
            # CMS detection
            for cms_name, patterns in WebFingerprinter.CMS_SIGNATURES.items():
                for pattern, location in patterns:
                    if location == 'generator' and re.search(pattern, content, re.I):
                        result["cms"] = cms_name
                        break
                    elif location == 'url' and re.search(pattern, url_path, re.I):
                        result["cms"] = cms_name
                        break
                if result["cms"]:
                    break
            
            # JavaScript framework detection
            if re.search(r'<script[^>]*src.*react', content, re.I) or 'React' in content:
                result["languages"].append("React")
            if re.search(r'<script[^>]*src.*vue', content, re.I) or 'Vue' in content:
                result["languages"].append("Vue")
            if re.search(r'<script[^>]*src.*angular', content, re.I) or 'ng-app' in content:
                result["languages"].append("Angular")
            if 'jQuery' in content:
                result["languages"].append("jQuery")
            
            # Database detection from error messages
            if 'mysql' in content.lower() or 'mysqli' in content.lower():
                result["technologies"].append("MySQL")
            if 'postgresql' in content.lower() or 'postgres' in content.lower():
                result["technologies"].append("PostgreSQL")
            if 'mongodb' in content.lower():
                result["technologies"].append("MongoDB")
            
            # Cache detection
            if headers.get('X-Cache'):
                result["technologies"].append("Caching enabled")
            if 'varnish' in headers.get('Via', '').lower():
                result["technologies"].append("Varnish")
            
            # CDN detection
            if headers.get('CF-Ray'):  # Cloudflare
                result["technologies"].append("Cloudflare CDN")
            if headers.get('X-Amz-Cf-Id'):  # AWS CloudFront
                result["technologies"].append("AWS CloudFront")
            
            # Security headers
            security_headers = []
            if headers.get('Strict-Transport-Security'):
                security_headers.append("HSTS")
            if headers.get('X-Frame-Options'):
                security_headers.append("X-Frame-Options")
            if headers.get('X-Content-Type-Options'):
                security_headers.append("X-Content-Type-Options")
            if headers.get('Content-Security-Policy'):
                security_headers.append("CSP")
            
            if security_headers:
                result["security_headers"] = security_headers
        except Exception as e:
            logger.debug(f"Error fingerprinting {url}: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def detect_version_from_error(url: str) -> Optional[str]:
        """
        Attempt to get version from error messages
        
        Args:
            url: Target URL (try to trigger error, e.g., /nonexistent)
            
        Returns:
            Version information if found
        """
        try:
            error_url = f"{url}/nonexistent-page-{datetime.utcnow().timestamp()}"
            status, _, body = await fetch(error_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=8192)
            if not status or not body:
                return None
            content = body.decode('utf-8', errors='ignore')
                
            # Look for version patterns
            version_patterns = [
                r'version\s*[:=]\s*(\d+\.\d+(?:\.\d+)?)',
                r'v(\d+\.\d+(?:\.\d+)?)',
                r'(\d+\.\d+(?:\.\d+)?)\s*\(build',
            ]
                
            for pattern in version_patterns:
                match = re.search(pattern, content, re.I)
                if match:
                    return match.group(1)
                        
        except Exception:
            pass
        
        return None

