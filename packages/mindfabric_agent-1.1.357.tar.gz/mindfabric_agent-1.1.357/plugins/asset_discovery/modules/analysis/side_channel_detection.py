"""
Side-Channel Information Disclosure Detection Module

Detection of side-channel information leakage:
- Timing attack detection
- Metadata leakage detection
- Network timing analysis
"""

import time
import socket
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger


class SideChannelDetector:
    """Side-channel detection"""
    
    @staticmethod
    async def detect_timing_anomalies(targets: List[str], iterations: int = 5) -> Dict[str, Any]:
        """
        Detect timing anomalies that might indicate information disclosure
        
        Args:
            targets: List of targets to test
            iterations: Number of iterations for timing tests
            
        Returns:
            Timing anomaly detection results
        """
        result = {
            "targets": {},
            "anomalies": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        for target in targets[:10]:  # Limit targets
            try:
                timings = []
                
                # Measure response times
                for _ in range(iterations):
                    start = time.perf_counter()
                    
                    try:
                        # Try HTTP connection
                        r, w = await asyncio.wait_for(asyncio.open_connection(target, 80), timeout=2)
                        w.close()
                        try:
                            await w.wait_closed()
                        except Exception:
                            pass
                    except Exception:
                        pass
                    
                    elapsed = time.perf_counter() - start
                    timings.append(elapsed)
                
                if timings:
                    avg_time = sum(timings) / len(timings)
                    variance = sum((t - avg_time) ** 2 for t in timings) / len(timings)
                    std_dev = variance ** 0.5
                    
                    result["targets"][target] = {
                        "avg_time": avg_time,
                        "std_dev": std_dev,
                        "variance": variance,
                        "timings": timings
                    }
                    
                    # Detect anomalies (high variance might indicate information leakage)
                    if variance > 0.01:  # Threshold
                        result["anomalies"].append({
                            "target": target,
                            "type": "timing_variance",
                            "variance": variance,
                            "description": f"High timing variance detected for {target}"
                        })
                        
            except Exception as e:
                logger.debug(f"Error detecting timing anomalies for {target}: {e}")
                continue
        
        return result
    
    @staticmethod
    async def detect_metadata_leakage() -> List[Dict[str, Any]]:
        """
        Detect metadata leakage in file system
        
        Returns:
            List of detected metadata leakage
        """
        leaks = []
        timestamp = datetime.utcnow().isoformat()
        
        try:
            # Check for files with suspicious metadata
            suspicious_paths = [
                Path("/tmp"),
                Path("/var/tmp"),
                Path("/dev/shm"),
                Path.home() / "Downloads",
            ]
            
            for path in suspicious_paths:
                if path.exists():
                    try:
                        for file_path in path.rglob("*"):
                            try:
                                is_file = file_path.is_file()
                            except (FileNotFoundError, OSError, PermissionError, IOError):
                                # Common race on procfs-like symlink targets disappearing mid-scan.
                                continue
                            if is_file:
                                try:
                                    stat = file_path.stat()
                                    
                                    # Check for unusual permissions (world-readable sensitive files)
                                    mode = stat.st_mode
                                    if mode & 0o004:  # World readable
                                        # Check if file might contain sensitive data
                                        if file_path.suffix in ['.txt', '.log', '.json', '.yml', '.yaml']:
                                            leaks.append({
                                                "type": "metadata_permission",
                                                "file": str(file_path),
                                                "permission": oct(mode)[-3:],
                                                "severity": "medium",
                                                "description": f"World-readable file: {file_path.name}",
                                                "timestamp": timestamp
                                            })
                                    
                                    # Check for unusual timestamps
                                    mtime = datetime.fromtimestamp(stat.st_mtime)
                                    if datetime.now() - mtime < datetime.now() - datetime.now().replace(hour=0):
                                        # Modified today
                                        if file_path.name.lower() in ['passwords', 'secrets', 'keys', 'config']:
                                            leaks.append({
                                                "type": "metadata_timestamp",
                                                "file": str(file_path),
                                                "modified": mtime.isoformat(),
                                                "severity": "high",
                                                "description": f"Recently modified sensitive-looking file: {file_path.name}",
                                                "timestamp": timestamp
                                            })
                                except (FileNotFoundError, OSError, PermissionError, IOError):
                                    continue
                    except (FileNotFoundError, OSError, PermissionError, IOError):
                        continue
                        
        except Exception as e:
            logger.debug(f"Error detecting metadata leakage: {e}")
        
        return leaks
    
    @staticmethod
    async def analyze_network_timing(connections: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze network timing patterns for side-channel detection
        
        Args:
            connections: List of connection records
            
        Returns:
            Network timing analysis results
        """
        result = {
            "timing_patterns": {},
            "anomalies": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Group connections by destination
        by_destination = {}
        for conn in connections:
            dest = f"{conn.get('target_ip', '')}:{conn.get('target_port', '')}"
            if dest not in by_destination:
                by_destination[dest] = []
            by_destination[dest].append(conn)
        
        # Analyze timing patterns
        for dest, conns in by_destination.items():
            if len(conns) > 3:
                # Calculate connection intervals
                timestamps = [c.get('timestamp') or c.get('discovered_at') for c in conns if c.get('timestamp') or c.get('discovered_at')]
                if timestamps:
                    try:
                        sorted_times = sorted([datetime.fromisoformat(ts.replace('Z', '+00:00')) if isinstance(ts, str) else ts for ts in timestamps])
                        intervals = [(sorted_times[i] - sorted_times[i-1]).total_seconds() for i in range(1, len(sorted_times))]
                        
                        if intervals:
                            avg_interval = sum(intervals) / len(intervals)
                            
                            # Regular intervals might indicate beaconing (side-channel)
                            variance = sum((i - avg_interval) ** 2 for i in intervals) / len(intervals)
                            
                            if variance < 1.0 and avg_interval > 0:
                                result["timing_patterns"][dest] = {
                                    "avg_interval": avg_interval,
                                    "variance": variance,
                                    "connection_count": len(conns)
                                }
                                
                                result["anomalies"].append({
                                    "destination": dest,
                                    "type": "regular_timing_pattern",
                                    "interval": avg_interval,
                                    "description": f"Regular timing pattern detected (possible side-channel)"
                                })
                    except Exception:
                        pass
        
        return result

