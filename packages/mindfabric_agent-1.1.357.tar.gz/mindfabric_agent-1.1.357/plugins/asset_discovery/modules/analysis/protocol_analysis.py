"""
Advanced Protocol Analysis Module

Protocol-level exploitation detection:
- Protocol downgrade detection
- Protocol confusion attacks
- HTTP request smuggling
"""

import re
import asyncio
import ssl
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from ..utils.async_http import fetch


class ProtocolAnalyzer:
    """Advanced protocol analysis"""
    
    @staticmethod
    async def detect_protocol_downgrade(url: str) -> Dict[str, Any]:
        """
        Detect protocol downgrade attempts
        
        Args:
            url: Target URL
            
        Returns:
            Protocol downgrade detection results
        """
        result = {
            "url": url,
            "downgrade_detected": False,
            "protocols_tested": [],
            "vulnerabilities": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Test HTTPS
            try:
                https_url = url.replace("http://", "https://")
                status, _, _ = await fetch(https_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=1024)
                result["protocols_tested"].append({
                    "protocol": "HTTPS",
                    "supported": bool(status),
                    "version": None,
                })
            except Exception:
                result["protocols_tested"].append({
                    "protocol": "HTTPS",
                    "supported": False
                })
            
            # Test HTTP
            try:
                http_url = url.replace("https://", "http://")
                status, _, _ = await fetch(http_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=3, max_bytes=1024)
                result["protocols_tested"].append({
                    "protocol": "HTTP",
                    "supported": bool(status),
                    "version": None,
                })

                # If HTTPS is supported but HTTP also works, potential downgrade
                https_supported = any(p.get("protocol") == "HTTPS" and p.get("supported") for p in result["protocols_tested"])
                if https_supported and status:
                    result["downgrade_detected"] = True
                    result["vulnerabilities"].append({
                        "type": "protocol_downgrade",
                        "severity": "medium",
                        "description": "HTTP is supported when HTTPS is available (downgrade possible)"
                    })
            except Exception:
                pass
            
            # Test TLS versions
            try:
                host = url.split("://", 1)[1].split("/", 1)[0]
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, 443, ssl=ctx, server_hostname=host),
                    timeout=3,
                )
                try:
                    ssl_obj = writer.get_extra_info("ssl_object")
                    tls_version = ssl_obj.version() if ssl_obj else None
                    if tls_version:
                        result["tls_version"] = tls_version

                        # Check for old TLS versions
                        if tls_version in ["TLSv1", "TLSv1.1"]:
                            result["vulnerabilities"].append({
                                "type": "weak_tls",
                                "severity": "high",
                                "description": f"Old TLS version: {tls_version}"
                            })
                finally:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
            except Exception:
                pass
                
        except Exception as e:
            logger.debug(f"Error detecting protocol downgrade for {url}: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def detect_http_request_smuggling(url: str) -> Dict[str, Any]:
        """
        Detect HTTP request smuggling vulnerabilities
        
        Args:
            url: Target URL
            
        Returns:
            Request smuggling detection results
        """
        result = {
            "url": url,
            "vulnerable": False,
            "techniques_tested": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # HTTP Request Smuggling techniques
        # CL.TE (Content-Length + Transfer-Encoding)
        smuggling_payloads = [
            {
                "name": "CL.TE",
                "payload": b"POST / HTTP/1.1\r\nHost: example.com\r\nContent-Length: 13\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nSMUGGLED",
                "headers": {
                    "Content-Length": "13",
                    "Transfer-Encoding": "chunked"
                }
            },
            {
                "name": "TE.CL",
                "payload": b"POST / HTTP/1.1\r\nHost: example.com\r\nTransfer-Encoding: chunked\r\nContent-Length: 3\r\n\r\n8\r\nSMUGGLED\r\n0\r\n\r\n",
                "headers": {
                    "Transfer-Encoding": "chunked",
                    "Content-Length": "3"
                }
            }
        ]
        
        # Note: Actual HTTP request smuggling testing requires careful implementation
        # This is a placeholder structure
        result["note"] = "HTTP request smuggling testing requires custom HTTP client implementation"
        result["techniques_available"] = [p["name"] for p in smuggling_payloads]
        
        return result
    
    @staticmethod
    async def analyze_http2_behavior(url: str) -> Dict[str, Any]:
        """
        Analyze HTTP/2 behavior for anomalies
        
        Args:
            url: Target URL
            
        Returns:
            HTTP/2 analysis results
        """
        result = {
            "url": url,
            "http2_supported": False,
            "multiplexing_detected": False,
            "vulnerabilities": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Try HTTP/2 connection
            import http.client
            from urllib.parse import urlparse
            
            parsed = urlparse(url)
            host = parsed.netloc
            port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            
            # Note: HTTP/2 detection requires http2 library or h2
            # This is a placeholder structure
            result["note"] = "HTTP/2 analysis requires http2 or h2 library"
            
        except Exception as e:
            logger.debug(f"Error analyzing HTTP/2 for {url}: {e}")
            result["error"] = str(e)
        
        return result

