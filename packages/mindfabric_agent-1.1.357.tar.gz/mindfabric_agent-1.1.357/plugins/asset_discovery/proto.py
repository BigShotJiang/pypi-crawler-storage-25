from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import datetime

@dataclass
class NetworkInterface:
    """Network interface information"""
    ip_address: str
    network: str  # CIDR notation
    interface: Optional[str] = None
    is_primary: Optional[bool] = None
    mac_address: Optional[str] = None
    netmask: Optional[str] = None
    broadcast: Optional[str] = None
    mtu: Optional[int] = None
    status: Optional[str] = None  # active, inactive, up, down
    flags: List[str] = field(default_factory=list)
    media: Optional[str] = None
    vlan: Optional[Dict[str, Any]] = None
    ipv6: List[Dict[str, Any]] = field(default_factory=list)
    link_speed: Optional[str] = None

@dataclass
class HardwareSpecs:
    """Hardware specifications"""
    cpu: Optional[Dict[str, Any]] = None  # cores, model, usage_percent
    memory: Optional[Dict[str, Any]] = None  # total_gb, used_gb, usage_percent
    disk: Optional[Dict[str, Any]] = None  # total_gb, used_gb, usage_percent

@dataclass
class Asset:
    """Infrastructure asset (server, VM, container, etc.)"""
    id: str
    ip_address: str
    hostname: str
    status: str  # with-agent, without-agent, excluded
    provider: str  # AWS, Azure, GCP, On-premise, Kubernetes
    os: str
    agent_type: str  # Docker, Kubernetes, Native, None
    environment: str  # Production, Development, Testing, Staging
    discovered_at: str
    services: List[str] = field(default_factory=list)
    last_seen: Optional[str] = None
    role: Optional[str] = None
    network: Optional[str] = None
    network_interfaces: List[NetworkInterface] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    detection_method: Optional[str] = None
    detection_location: Optional[str] = None
    detection_reason: Optional[str] = None
    hardware: Optional[HardwareSpecs] = None

@dataclass
class Service:
    """Service running on an asset"""
    id: str
    name: str
    asset_id: str
    asset_hostname: str
    asset_ip_address: str
    status: str  # running, stopped, failed
    service_type: str  # web, database, cache, monitoring, container, other
    description: str
    discovery_method: str
    discovered_at: str
    port: Optional[int] = None
    protocol: Optional[str] = None
    port_direction: Optional[str] = None  # inbound, outbound
    remote_address: Optional[str] = None  # For outbound connections
    last_seen: Optional[str] = None
    version: Optional[str] = None
    process_info: Optional[Dict[str, Any]] = None
    container_info: Optional[Dict[str, Any]] = None
    config_path: Optional[str] = None
    environment: Dict[str, str] = field(default_factory=dict)
    detection_location: Optional[str] = None
    detection_reason: Optional[str] = None

@dataclass
class AssetConnection:
    """Connection between assets"""
    from_asset_id: str
    to_asset_id: str
    connection_type: str  # network, dependency, service, cluster
    discovered_at: str
    port: Optional[int] = None
    protocol: Optional[str] = None
    last_seen: Optional[str] = None
    status: Optional[str] = None  # active, investigating, resolved, ignored
    from_ip: Optional[str] = None
    to_ip: Optional[str] = None

@dataclass
class AssetDiscoveryResult:
    """Complete asset discovery result"""
    assets: List[Asset]
    services: List[Service]
    connections: List[AssetConnection]
    scanned_at: str
    scan_mode: str  # full, quick, network-only, etc.

