from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import datetime

@dataclass
class MetricData:
    """Time-series metric data point"""
    timestamp: str
    cpu: float
    memory: float
    storage: float
    network_in: float
    network_out: float
    disk_read: float
    disk_write: float

@dataclass
class ServiceCall:
    """Service call/request information"""
    id: str
    from_service: str
    to_service: str
    count: int
    avg_latency: float
    p95_latency: float
    error_rate: float
    timestamp: str
    is_anomaly: bool

@dataclass
class ProcessInfo:
    """Process information for anomaly"""
    pid: int
    name: str
    command: Optional[str] = None
    user: Optional[str] = None
    cpu_percent: Optional[float] = None
    memory_percent: Optional[float] = None
    thread_count: Optional[int] = None
    status: Optional[str] = None
    # When this process snapshot was captured (ISO timestamp).
    captured_at: Optional[str] = None


@dataclass
class NetworkDetails:
    """Network anomaly details"""
    direction: str  # inbound, outbound
    protocol: Optional[str] = None
    local_address: Optional[str] = None
    local_port: Optional[int] = None
    remote_address: Optional[str] = None
    remote_port: Optional[int] = None
    bytes_sent: Optional[float] = None
    bytes_recv: Optional[float] = None


@dataclass
class DiskDetails:
    """Disk I/O anomaly details"""
    operation: str  # read, write
    path: Optional[str] = None
    speed_mbps: Optional[float] = None
    iops: Optional[int] = None


@dataclass
class CpuDetails:
    """CPU anomaly details"""
    user_percent: Optional[float] = None
    system_percent: Optional[float] = None
    idle_percent: Optional[float] = None
    iowait_percent: Optional[float] = None


@dataclass
class MemoryDetails:
    """Memory anomaly details"""
    total_gb: Optional[float] = None
    used_gb: Optional[float] = None
    available_gb: Optional[float] = None
    swap_used_gb: Optional[float] = None


@dataclass
class Anomaly:
    """Detected infrastructure anomaly"""
    id: str
    timestamp: str
    severity: str  # critical, high, medium, low
    type: str  # cpu, memory, storage, network, disk-io, service-call, behavioral
    asset: str
    metric: str
    current_value: float
    expected_value: float
    deviation: float  # percentage
    description: str
    status: str  # active, investigating, resolved, false-positive
    # When running "context" mode, we emit a lightweight record that should be merged
    # into an existing backend anomaly. This is the backend anomaly id to merge into.
    anomaly_id: Optional[str] = None
    asset_ip: Optional[str] = None
    service_calls: List[Dict[str, Any]] = field(default_factory=list)
    # Process information
    process_info: Optional[ProcessInfo] = None
    network_details: Optional[NetworkDetails] = None
    disk_details: Optional[DiskDetails] = None
    cpu_details: Optional[CpuDetails] = None
    memory_details: Optional[MemoryDetails] = None

@dataclass
class InfrastructureIntelligenceResult:
    """Complete infrastructure intelligence result"""
    anomalies: List[Anomaly]
    metric_data: List[MetricData]
    service_calls: List[ServiceCall]
    scanned_at: str
    scan_mode: str  # full, quick, anomalies-only

