"""
Infrastructure Intelligence Plugin

AI-powered infrastructure intelligence and anomaly detection plugin that:
- Collects system metrics (CPU, memory, disk, network)
- Analyzes metric patterns for anomalies
- Detects service call latency issues
- Identifies behavioral anomalies
- Provides baseline comparisons
"""

import datetime
import asyncio
import socket
from collections import deque
from typing import Dict, List, Any, Optional

from plugins.base_plugin import BasePlugin
from utils.logger import logger
from .proto import InfrastructureIntelligenceResult
from .modules.collectors import (
    SystemMetricsCollector,
    ExtendedMetricsCollector,
)
from .modules.analyzers import (
    AnomalyDetector,
    BaselineCalculator,
    MLAnomalyDetector,
    ContainerMetricsCollector,
    NetworkLatencyMeasurer,
    ProcessAnalyzer,
    KernelAnalyzer,
    AdvancedMemoryAnalyzer,
    ApplicationProfiler,
)
from .modules.utils import get_local_ip
from .modules.builders import (
    dict_to_anomaly, dict_to_metric, dict_to_service_call,
    anomaly_to_dict, metric_to_dict, service_call_to_dict
)

class InfrastructureIntelligencePlugin(BasePlugin):
    """
    Infrastructure Intelligence Plugin for Anomaly Detection
    
    Provides comprehensive anomaly detection capabilities:
    - Real-time metric collection and analysis
    - Anomaly detection using statistical methods
    - Baseline calculation and deviation detection
    - Service call latency monitoring
    - Behavioral pattern analysis
    """
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.hostname = socket.gethostname()
        self.metric_history = deque(maxlen=100)  # Store last 100 metric readings
        self.baselines = {}  # Store baseline values for metrics
        
        # Initialize modular components
        self.anomaly_detector = AnomalyDetector(self.hostname, self._get_local_ip)
        self.baseline_calculator = BaselineCalculator()
        self.extended_metrics_collector = ExtendedMetricsCollector(self)
        self.ml_anomaly_detector = MLAnomalyDetector(self)
        # ContainerMetricsCollector currently exposes async @staticmethod APIs and
        # does not accept constructor args.
        self.container_metrics = ContainerMetricsCollector()
        # NetworkLatencyMeasurer exposes async @staticmethod APIs and does not accept constructor args.
        self.network_latency = NetworkLatencyMeasurer()
        # These analyzers expose async @staticmethod APIs and do not accept constructor args.
        self.process_analyzer = ProcessAnalyzer()
        self.kernel_analyzer = KernelAnalyzer()
        self.memory_analyzer = AdvancedMemoryAnalyzer()
        self.application_profiler = ApplicationProfiler()
    
    async def run(self):
        """Main entry point for infrastructure intelligence"""
        # Options can arrive in multiple shapes depending on the backend dispatcher:
        # - top-level: {"mode": "...", "metric": "...", "anomaly_id": "..."}
        # - nested: {"options": {...}} (parsed unified command)
        # - nested: {"args": {...}} (batch dispatcher)
        # - legacy: {"args": ["mode=context", "metric=disk", "anomaly_id=..."]} (list form)
        def _collect_opts() -> Dict[str, Any]:
            out: Dict[str, Any] = {}
            if isinstance(self.options, dict):
                if isinstance(self.options.get("options"), dict):
                    out.update(self.options["options"])
                args_val = self.options.get("args")
                if isinstance(args_val, dict):
                    out.update(args_val)
                elif isinstance(args_val, (list, tuple)):
                    for item in args_val:
                        if not isinstance(item, str):
                            continue
                        s = item.strip()
                        if "=" not in s:
                            continue
                        k, v = s.split("=", 1)
                        k = k.strip()
                        v = v.strip()
                        if k:
                            out[k] = v

                # Best-effort parse from command string if dispatcher didn't pass structured args/options.
                cmd_str = self.options.get("command")
                if isinstance(cmd_str, str) and cmd_str:
                    parts = [p.strip() for p in cmd_str.split() if p and "=" in p]
                    for p in parts:
                        k, v = p.split("=", 1)
                        k = k.strip()
                        v = v.strip()
                        if k and k not in out:
                            out[k] = v
                # Top-level always wins (if present)
                for k in ("mode", "metric", "anomaly_id", "anomalyId"):
                    if k in self.options and self.options.get(k) is not None:
                        out[k] = self.options.get(k)
            return out

        collected = _collect_opts()
        mode = (collected.get("mode") or (self.options.get("mode") if isinstance(self.options, dict) else None) or "full")
        # Normalize common alias
        if "anomaly_id" not in collected and "anomalyId" in collected:
            collected["anomaly_id"] = collected.get("anomalyId")
        # Debug visibility: this command is critical for populating Process Details.
        # Keep it concise and safe even if options are malformed.
        try:
            if isinstance(self.options, dict):
                logger.info(
                    f"[infra_intel] cmd_id={self.command_id} "
                    f"keys={list(self.options.keys())} "
                    f"command={self.options.get('command')} "
                    f"args_type={type(self.options.get('args')).__name__} "
                    f"options_type={type(self.options.get('options')).__name__} "
                    f"collected_keys={list(collected.keys())} mode={mode}"
                )
        except Exception:
            pass
        # Pass through known params so hook_analyze(mode="context") can find them via kwargs as well.
        passthrough = {k: v for k, v in collected.items() if k in ("metric", "anomaly_id", "anomalyId")}
        return await self.hook_analyze(mode=mode, **passthrough)
    
    async def hook_analyze(self, mode: str = "full", **kwargs) -> Dict[str, Any]:
        """
        Analyze infrastructure for anomalies and collect metrics.
        
        Args:
            mode (str): Analysis mode - "full", "quick", "anomalies-only"
            **kwargs: Additional parameters
            
        Returns:
            dict: Infrastructure intelligence results
            
        Examples:
            plugin:infrastructure_intelligence analyze mode=full
            plugin:infrastructure_intelligence analyze mode=quick
            plugin:infrastructure_intelligence analyze mode=anomalies-only
        """
        try:
            scanned_at = datetime.datetime.utcnow().isoformat()

            # The dispatcher may call this hook with default args (mode="full") even when the
            # original command string contained `mode=context ...`. Recover intended params from
            # parsed `options` (from ws_client.parse_unified_command) and structured `args` dict.
            try:
                if isinstance(self.options, dict) and mode == "full":
                    opt = self.options.get("options") if isinstance(self.options.get("options"), dict) else {}
                    args_obj = self.options.get("args")
                    args_dict = args_obj if isinstance(args_obj, dict) else {}
                    maybe_mode = opt.get("mode") or args_dict.get("mode") or self.options.get("mode")
                    if isinstance(maybe_mode, str) and maybe_mode:
                        mode = maybe_mode
            except Exception:
                pass
            
            anomalies = []
            metric_data = []
            service_calls = []
            
            if mode in ["full", "quick"]:
                # Collect current metrics
                current_metric = await SystemMetricsCollector.collect_metrics(mode)
                if current_metric:
                    metric_data.append(current_metric)
                    self.metric_history.append(current_metric)
                
                # Update baselines
                self.baselines = self.baseline_calculator.update_baselines(list(self.metric_history))

                # Anomalies are computed on the backend from real heartbeat time-series.
                # Keep quick mode anomaly detection only if you still want agent-side signal.
                if mode != "full":
                    detected_anomalies = await asyncio.to_thread(self.anomaly_detector.detect_anomalies, current_metric, self.baselines)
                    anomalies.extend(detected_anomalies)

            if mode == "context":
                # Lightweight context snapshot for an already-detected backend anomaly.
                # This does NOT compute baselines or anomalies; it only returns process/network/disk context.
                opt = self.options.get("options") if isinstance(self.options.get("options"), dict) else {}
                args_obj = self.options.get("args")
                args_dict = args_obj if isinstance(args_obj, dict) else {}
                metric = (kwargs.get("metric") or opt.get("metric") or args_dict.get("metric") or self.options.get("metric") or "cpu")
                if isinstance(metric, str):
                    metric = metric.strip().lower()
                anomaly_id = (
                    kwargs.get("anomaly_id")
                    or kwargs.get("anomalyId")
                    or opt.get("anomaly_id")
                    or opt.get("anomalyId")
                    or args_dict.get("anomaly_id")
                    or args_dict.get("anomalyId")
                    or self.options.get("anomaly_id")
                    or self.options.get("anomalyId")
                )

                # Pick relevant process snapshot + details based on metric
                proc = None
                cpu_details = None
                mem_details = None
                net_details = None
                disk_details = None

                if metric in ("cpu", "cpu_percent"):
                    proc = self.anomaly_detector._get_top_cpu_process()
                    cpu_details = self.anomaly_detector._get_cpu_details()
                elif metric in ("memory", "mem", "ram"):
                    proc = self.anomaly_detector._get_top_memory_process()
                    mem_details = self.anomaly_detector._get_memory_details()
                elif metric in ("network", "net", "net_rx", "net_tx", "network_rx", "network_tx"):
                    net_info = self.anomaly_detector._get_top_network_process()
                    if isinstance(net_info, dict):
                        proc = net_info.get("process_info")
                        net_details = net_info.get("network_details")
                elif metric in ("disk", "disk_free", "disk_io", "disk-io"):
                    d = self.anomaly_detector._get_top_disk_io_process()
                    if isinstance(d, dict):
                        proc = d.get("process_info")
                        disk_details = d.get("disk_details")
                else:
                    proc = self.anomaly_detector._get_top_cpu_process()
                    cpu_details = self.anomaly_detector._get_cpu_details()

                if isinstance(proc, dict):
                    # Stamp when this snapshot was captured (for UI clarity).
                    proc = {**proc, "captured_at": scanned_at}

                # Return as a single "anomaly context" record so backend can merge into the existing anomaly.
                anomalies.append(
                    {
                        "id": f"context_{metric}_{scanned_at}",
                        "timestamp": scanned_at,
                        "severity": "info",
                        "type": metric if metric in ("cpu", "memory", "network", "disk") else "cpu",
                        "asset": self.hostname,
                        "asset_ip": self._get_local_ip(),
                        "metric": f"{metric}_context",
                        "status": "active",
                        "anomaly_id": anomaly_id,
                        "process_info": proc,
                        "cpu_details": cpu_details,
                        "memory_details": mem_details,
                        "network_details": net_details,
                        "disk_details": disk_details,
                        "description": f"Context snapshot for {metric} anomaly",
                    }
                )
            
            if mode == "full":
                # NOTE:
                # We intentionally do NOT generate simulated historical metrics in full mode.
                # Baselines / expected / thresholds are computed on the backend from real
                # heartbeat time-series (agent_metric_points).
                #
                # Keep full mode for "more collection" (if/when implemented with real sources),
                # but avoid synthetic data and anything that could block.
                pass
            
            # Convert to proto format
            anomaly_objects = [dict_to_anomaly(a) for a in anomalies]
            metric_objects = [dict_to_metric(m) for m in metric_data]
            service_call_objects = [dict_to_service_call(sc) for sc in service_calls]
            
            result = InfrastructureIntelligenceResult(
                anomalies=anomaly_objects,
                metric_data=metric_objects,
                service_calls=service_call_objects,
                scanned_at=scanned_at,
                scan_mode=mode
            )
            
            return {
                "status": "success",
                "result": "Infrastructure analysis completed",
                "data": {
                    "anomalies": [anomaly_to_dict(a) for a in anomaly_objects],
                    "metric_data": [metric_to_dict(m) for m in metric_objects],
                    "service_calls": [service_call_to_dict(sc) for sc in service_call_objects],
                    "scanned_at": scanned_at,
                    "scan_mode": mode,
                    "total_anomalies": len(anomalies),
                    "critical_anomalies": len([a for a in anomalies if a.get("severity") == "critical"]),
                    "active_anomalies": len([a for a in anomalies if a.get("status") == "active"])
                }
            }
        except Exception as e:
            logger.exception(f"Error during infrastructure analysis: {e}")
            return {
                "status": "error",
                "result": f"Infrastructure analysis failed: {str(e)}",
                "data": {}
            }
    
    def _get_local_ip(self) -> Optional[str]:
        """Get local IP address"""
        return get_local_ip(self.hostname)
