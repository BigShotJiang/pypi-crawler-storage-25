"""
IP address utilities
"""
import socket
from typing import Optional


def get_local_ip(hostname: str) -> Optional[str]:
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            resolver = getattr(socket, "gethostbyname", None)
            if not resolver:
                return None
            return resolver(hostname)
        except Exception:
            return None

