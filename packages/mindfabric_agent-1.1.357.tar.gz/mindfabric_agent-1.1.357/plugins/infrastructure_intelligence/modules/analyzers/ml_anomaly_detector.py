"""
ML-Based Anomaly Detection Module

Implements machine learning approaches for anomaly detection:
- Statistical methods (Z-score, IQR, MAD)
- Isolation Forest for multivariate anomalies
- Exponential smoothing for trend detection
- Seasonality detection and handling

This module provides more sophisticated anomaly detection
compared to simple threshold-based approaches.
"""

import math
import logging
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)


class AnomalyType(str, Enum):
    """Types of anomalies."""
    POINT = "point"  # Single point anomaly
    CONTEXTUAL = "contextual"  # Anomaly in context
    COLLECTIVE = "collective"  # Pattern anomaly
    SEASONAL = "seasonal"  # Deviation from seasonal pattern
    TREND = "trend"  # Trend change


class AnomalySeverity(str, Enum):
    """Anomaly severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class AnomalyResult:
    """Result of anomaly detection."""
    is_anomaly: bool
    anomaly_type: AnomalyType
    severity: AnomalySeverity
    score: float  # 0-1, higher = more anomalous
    metric_name: str
    current_value: float
    expected_value: float
    deviation: float
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BaselineStats:
    """Baseline statistics for a metric."""
    mean: float = 0.0
    std: float = 0.0
    median: float = 0.0
    mad: float = 0.0  # Median Absolute Deviation
    q1: float = 0.0
    q3: float = 0.0
    iqr: float = 0.0
    min_val: float = 0.0
    max_val: float = 0.0
    count: int = 0


@dataclass
class SeasonalPattern:
    """Seasonal pattern information."""
    period: int  # Period in data points (e.g., 24 for hourly data with daily pattern)
    pattern: List[float] = field(default_factory=list)  # Expected value at each point
    strength: float = 0.0  # 0-1, how strong is the seasonality


class MLAnomalyDetector:
    """ML-based anomaly detection service."""
    
    def __init__(
        self,
        window_size: int = 100,
        zscore_threshold: float = 3.0,
        iqr_multiplier: float = 1.5,
        mad_threshold: float = 3.5,
        smoothing_alpha: float = 0.3,
    ):
        self.window_size = window_size
        self.zscore_threshold = zscore_threshold
        self.iqr_multiplier = iqr_multiplier
        self.mad_threshold = mad_threshold
        self.smoothing_alpha = smoothing_alpha
        
        # History storage per metric
        self._history: Dict[str, deque] = {}
        self._baselines: Dict[str, BaselineStats] = {}
        self._ewma: Dict[str, float] = {}  # Exponential weighted moving average
        self._seasonal_patterns: Dict[str, SeasonalPattern] = {}
    
    def _get_history(self, metric_name: str) -> deque:
        """Get or create history for a metric."""
        if metric_name not in self._history:
            self._history[metric_name] = deque(maxlen=self.window_size)
        return self._history[metric_name]
    
    def add_data_point(self, metric_name: str, value: float) -> None:
        """
        Add a data point to the history.
        
        Args:
            metric_name: Name of the metric
            value: Metric value
        """
        history = self._get_history(metric_name)
        history.append(value)
        
        # Update EWMA
        if metric_name in self._ewma:
            self._ewma[metric_name] = (
                self.smoothing_alpha * value + 
                (1 - self.smoothing_alpha) * self._ewma[metric_name]
            )
        else:
            self._ewma[metric_name] = value
    
    def calculate_baseline(self, metric_name: str) -> BaselineStats:
        """
        Calculate baseline statistics for a metric.
        
        Args:
            metric_name: Name of the metric
            
        Returns:
            BaselineStats
        """
        history = self._get_history(metric_name)
        
        if len(history) < 10:
            return BaselineStats()
        
        values = list(history)
        n = len(values)
        
        # Sort for percentile calculations
        sorted_values = sorted(values)
        
        # Mean and std
        mean = sum(values) / n
        variance = sum((x - mean) ** 2 for x in values) / n
        std = math.sqrt(variance) if variance > 0 else 0.001
        
        # Median
        mid = n // 2
        median = sorted_values[mid] if n % 2 else (sorted_values[mid - 1] + sorted_values[mid]) / 2
        
        # MAD (Median Absolute Deviation)
        deviations = sorted([abs(x - median) for x in values])
        mad = deviations[mid] if n % 2 else (deviations[mid - 1] + deviations[mid]) / 2
        
        # Quartiles
        q1_idx = n // 4
        q3_idx = 3 * n // 4
        q1 = sorted_values[q1_idx]
        q3 = sorted_values[q3_idx]
        iqr = q3 - q1
        
        stats = BaselineStats(
            mean=mean,
            std=std,
            median=median,
            mad=mad if mad > 0 else 0.001,
            q1=q1,
            q3=q3,
            iqr=iqr if iqr > 0 else 0.001,
            min_val=min(values),
            max_val=max(values),
            count=n,
        )
        
        self._baselines[metric_name] = stats
        return stats
    
    def detect_zscore_anomaly(
        self,
        metric_name: str,
        value: float,
    ) -> Optional[AnomalyResult]:
        """
        Detect anomaly using Z-score method.
        
        Args:
            metric_name: Name of the metric
            value: Current value
            
        Returns:
            AnomalyResult if anomaly detected, None otherwise
        """
        if metric_name not in self._baselines:
            self.calculate_baseline(metric_name)
        
        baseline = self._baselines.get(metric_name)
        if not baseline or baseline.count < 10:
            return None
        
        zscore = (value - baseline.mean) / baseline.std
        
        if abs(zscore) > self.zscore_threshold:
            severity = AnomalySeverity.LOW
            if abs(zscore) > self.zscore_threshold * 2:
                severity = AnomalySeverity.HIGH
            if abs(zscore) > self.zscore_threshold * 3:
                severity = AnomalySeverity.CRITICAL
            
            return AnomalyResult(
                is_anomaly=True,
                anomaly_type=AnomalyType.POINT,
                severity=severity,
                score=min(abs(zscore) / (self.zscore_threshold * 3), 1.0),
                metric_name=metric_name,
                current_value=value,
                expected_value=baseline.mean,
                deviation=zscore,
                context={"method": "zscore", "threshold": self.zscore_threshold},
            )
        
        return None
    
    def detect_iqr_anomaly(
        self,
        metric_name: str,
        value: float,
    ) -> Optional[AnomalyResult]:
        """
        Detect anomaly using IQR (Interquartile Range) method.
        More robust to outliers than Z-score.
        
        Args:
            metric_name: Name of the metric
            value: Current value
            
        Returns:
            AnomalyResult if anomaly detected, None otherwise
        """
        if metric_name not in self._baselines:
            self.calculate_baseline(metric_name)
        
        baseline = self._baselines.get(metric_name)
        if not baseline or baseline.count < 10:
            return None
        
        lower_bound = baseline.q1 - self.iqr_multiplier * baseline.iqr
        upper_bound = baseline.q3 + self.iqr_multiplier * baseline.iqr
        
        if value < lower_bound or value > upper_bound:
            deviation = (value - baseline.median) / baseline.iqr
            
            severity = AnomalySeverity.LOW
            if abs(deviation) > 2:
                severity = AnomalySeverity.MEDIUM
            if abs(deviation) > 3:
                severity = AnomalySeverity.HIGH
            if abs(deviation) > 4:
                severity = AnomalySeverity.CRITICAL
            
            return AnomalyResult(
                is_anomaly=True,
                anomaly_type=AnomalyType.POINT,
                severity=severity,
                score=min(abs(deviation) / 4, 1.0),
                metric_name=metric_name,
                current_value=value,
                expected_value=baseline.median,
                deviation=deviation,
                context={
                    "method": "iqr",
                    "lower_bound": lower_bound,
                    "upper_bound": upper_bound,
                },
            )
        
        return None
    
    def detect_mad_anomaly(
        self,
        metric_name: str,
        value: float,
    ) -> Optional[AnomalyResult]:
        """
        Detect anomaly using MAD (Median Absolute Deviation) method.
        Very robust to outliers.
        
        Args:
            metric_name: Name of the metric
            value: Current value
            
        Returns:
            AnomalyResult if anomaly detected, None otherwise
        """
        if metric_name not in self._baselines:
            self.calculate_baseline(metric_name)
        
        baseline = self._baselines.get(metric_name)
        if not baseline or baseline.count < 10:
            return None
        
        # Modified Z-score using MAD
        # 0.6745 is the consistency constant for normal distribution
        modified_zscore = 0.6745 * (value - baseline.median) / baseline.mad
        
        if abs(modified_zscore) > self.mad_threshold:
            severity = AnomalySeverity.LOW
            if abs(modified_zscore) > self.mad_threshold * 1.5:
                severity = AnomalySeverity.MEDIUM
            if abs(modified_zscore) > self.mad_threshold * 2:
                severity = AnomalySeverity.HIGH
            if abs(modified_zscore) > self.mad_threshold * 3:
                severity = AnomalySeverity.CRITICAL
            
            return AnomalyResult(
                is_anomaly=True,
                anomaly_type=AnomalyType.POINT,
                severity=severity,
                score=min(abs(modified_zscore) / (self.mad_threshold * 3), 1.0),
                metric_name=metric_name,
                current_value=value,
                expected_value=baseline.median,
                deviation=modified_zscore,
                context={"method": "mad", "threshold": self.mad_threshold},
            )
        
        return None
    
    def detect_trend_change(
        self,
        metric_name: str,
        value: float,
    ) -> Optional[AnomalyResult]:
        """
        Detect sudden trend changes using EWMA.
        
        Args:
            metric_name: Name of the metric
            value: Current value
            
        Returns:
            AnomalyResult if trend change detected, None otherwise
        """
        if metric_name not in self._ewma:
            return None
        
        ewma = self._ewma[metric_name]
        
        if metric_name not in self._baselines:
            self.calculate_baseline(metric_name)
        
        baseline = self._baselines.get(metric_name)
        if not baseline or baseline.count < 10:
            return None
        
        # Check if current value deviates significantly from EWMA
        deviation = abs(value - ewma) / baseline.std
        
        if deviation > self.zscore_threshold:
            severity = AnomalySeverity.MEDIUM
            if deviation > self.zscore_threshold * 2:
                severity = AnomalySeverity.HIGH
            
            return AnomalyResult(
                is_anomaly=True,
                anomaly_type=AnomalyType.TREND,
                severity=severity,
                score=min(deviation / (self.zscore_threshold * 2), 1.0),
                metric_name=metric_name,
                current_value=value,
                expected_value=ewma,
                deviation=deviation,
                context={"method": "ewma", "ewma_value": ewma},
            )
        
        return None
    
    def detect_isolation_anomaly(
        self,
        metric_values: Dict[str, float],
    ) -> List[AnomalyResult]:
        """
        Detect multivariate anomalies using simplified Isolation Forest concept.
        
        This is a simplified implementation that checks for outliers
        across multiple dimensions simultaneously.
        
        Args:
            metric_values: Dictionary of metric_name -> value
            
        Returns:
            List of AnomalyResult for detected anomalies
        """
        anomalies = []
        
        # Normalize each metric to z-scores
        z_scores = {}
        for metric_name, value in metric_values.items():
            if metric_name not in self._baselines:
                self.calculate_baseline(metric_name)
            
            baseline = self._baselines.get(metric_name)
            if baseline and baseline.count >= 10:
                z_scores[metric_name] = (value - baseline.mean) / baseline.std
        
        if len(z_scores) < 2:
            return anomalies
        
        # Calculate multivariate score (simplified)
        # Use Euclidean distance in z-score space
        squared_sum = sum(z ** 2 for z in z_scores.values())
        distance = math.sqrt(squared_sum)
        
        # Threshold based on number of dimensions
        n_dims = len(z_scores)
        threshold = math.sqrt(n_dims) * self.zscore_threshold
        
        if distance > threshold:
            # Find which metrics contribute most
            sorted_metrics = sorted(z_scores.items(), key=lambda x: abs(x[1]), reverse=True)
            top_contributors = sorted_metrics[:3]
            
            severity = AnomalySeverity.MEDIUM
            if distance > threshold * 1.5:
                severity = AnomalySeverity.HIGH
            if distance > threshold * 2:
                severity = AnomalySeverity.CRITICAL
            
            anomalies.append(AnomalyResult(
                is_anomaly=True,
                anomaly_type=AnomalyType.COLLECTIVE,
                severity=severity,
                score=min(distance / (threshold * 2), 1.0),
                metric_name="multivariate",
                current_value=distance,
                expected_value=0.0,
                deviation=distance,
                context={
                    "method": "isolation",
                    "top_contributors": [
                        {"metric": m, "zscore": z} for m, z in top_contributors
                    ],
                },
            ))
        
        return anomalies
    
    def detect_all_anomalies(
        self,
        metric_name: str,
        value: float,
    ) -> List[AnomalyResult]:
        """
        Run all anomaly detection methods and return combined results.
        
        Args:
            metric_name: Name of the metric
            value: Current value
            
        Returns:
            List of AnomalyResult for all detected anomalies
        """
        anomalies = []
        
        # Add data point first
        self.add_data_point(metric_name, value)
        
        # Update baseline periodically
        if len(self._get_history(metric_name)) % 10 == 0:
            self.calculate_baseline(metric_name)
        
        # Run detectors
        zscore_result = self.detect_zscore_anomaly(metric_name, value)
        if zscore_result:
            anomalies.append(zscore_result)
        
        iqr_result = self.detect_iqr_anomaly(metric_name, value)
        if iqr_result:
            anomalies.append(iqr_result)
        
        mad_result = self.detect_mad_anomaly(metric_name, value)
        if mad_result:
            anomalies.append(mad_result)
        
        trend_result = self.detect_trend_change(metric_name, value)
        if trend_result:
            anomalies.append(trend_result)
        
        return anomalies
    
    def get_baseline(self, metric_name: str) -> Optional[BaselineStats]:
        """Get current baseline for a metric."""
        return self._baselines.get(metric_name)
    
    def get_ewma(self, metric_name: str) -> Optional[float]:
        """Get current EWMA for a metric."""
        return self._ewma.get(metric_name)
    
    def get_history(self, metric_name: str) -> List[float]:
        """Get history for a metric."""
        return list(self._get_history(metric_name))
    
    def reset_metric(self, metric_name: str) -> None:
        """Reset all data for a metric."""
        if metric_name in self._history:
            del self._history[metric_name]
        if metric_name in self._baselines:
            del self._baselines[metric_name]
        if metric_name in self._ewma:
            del self._ewma[metric_name]
        if metric_name in self._seasonal_patterns:
            del self._seasonal_patterns[metric_name]
    
    def reset_all(self) -> None:
        """Reset all stored data."""
        self._history.clear()
        self._baselines.clear()
        self._ewma.clear()
        self._seasonal_patterns.clear()

