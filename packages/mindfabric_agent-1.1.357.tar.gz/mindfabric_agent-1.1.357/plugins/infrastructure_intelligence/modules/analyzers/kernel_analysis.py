"""
Kernel-Level Analysis Module

Kernel and system internals analysis:
- Kernel module analysis
- System call monitoring
- Kernel memory analysis
"""

import re
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger

from utils.async_subprocess import run_exec


class KernelAnalyzer:
    """Kernel-level analysis"""
    
    @staticmethod
    async def analyze_kernel_modules() -> Dict[str, Any]:
        """
        Analyze loaded kernel modules
        
        Returns:
            Kernel modules analysis results
        """
        result = {
            "modules": [],
            "total_modules": 0,
            "suspicious_modules": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            modules_file = Path("/proc/modules")
            if not modules_file.exists():
                result["error"] = "/proc/modules not available"
                return result
            
            with open(modules_file, 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 6:
                        module_name = parts[0]
                        size = int(parts[1])
                        instances = int(parts[2])
                        dependencies = parts[3].split(',') if parts[3] != '-' else []
                        
                        module_info = {
                            "name": module_name,
                            "size_kb": size,
                            "instances": instances,
                            "dependencies": dependencies
                        }
                        
                        result["modules"].append(module_info)
                        
                        # Check for suspicious modules
                        suspicious_keywords = [
                            'rootkit', 'backdoor', 'stealth', 'hidden', 'test'
                        ]
                        
                        module_lower = module_name.lower()
                        for keyword in suspicious_keywords:
                            if keyword in module_lower:
                                result["suspicious_modules"].append({
                                    "module": module_name,
                                    "reason": f"Contains suspicious keyword: {keyword}"
                                })
                                break
            
            result["total_modules"] = len(result["modules"])
            
        except Exception as e:
            logger.debug(f"Error analyzing kernel modules: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def analyze_interrupts() -> Dict[str, Any]:
        """
        Analyze /proc/interrupts for hardware events
        
        Returns:
            Interrupts analysis results
        """
        result = {
            "interrupts": {},
            "cpu_count": 0,
            "high_interrupt_devices": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            interrupts_file = Path("/proc/interrupts")
            if not interrupts_file.exists():
                result["error"] = "/proc/interrupts not available"
                return result
            
            with open(interrupts_file, 'r') as f:
                lines = f.readlines()
                
                # First line contains CPU numbers
                if lines:
                    header = lines[0]
                    cpu_count = len(header.split())
                    result["cpu_count"] = cpu_count - 1  # Subtract first column (IRQ number)
                
                # Parse interrupt data
                for line in lines[1:]:
                    parts = line.split()
                    if len(parts) > cpu_count + 1:
                        irq_num = parts[0].rstrip(':')
                        device_name = parts[-1] if len(parts) > cpu_count + 1 else "unknown"
                        
                        # Sum interrupts across all CPUs
                        total_interrupts = sum(int(parts[i]) for i in range(1, cpu_count + 1) if parts[i].isdigit())
                        
                        result["interrupts"][irq_num] = {
                            "device": device_name,
                            "total": total_interrupts
                        }
                        
                        # Flag high interrupt devices
                        if total_interrupts > 10000:  # Threshold
                            result["high_interrupt_devices"].append({
                                "device": device_name,
                                "irq": irq_num,
                                "interrupts": total_interrupts
                            })
            
            # Sort high interrupt devices
            result["high_interrupt_devices"].sort(key=lambda x: x["interrupts"], reverse=True)
            
        except Exception as e:
            logger.debug(f"Error analyzing interrupts: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def analyze_io_schedulers() -> Dict[str, Any]:
        """
        Analyze I/O schedulers for block devices
        
        Returns:
            I/O scheduler analysis results
        """
        result = {
            "devices": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Check /sys/block for block devices
            block_dir = Path("/sys/block")
            if not block_dir.exists():
                result["error"] = "/sys/block not available"
                return result
            
            for device_dir in block_dir.iterdir():
                if device_dir.is_dir():
                    device_name = device_dir.name
                    
                    # Check I/O scheduler
                    queue_dir = device_dir / "queue"
                    if queue_dir.exists():
                        scheduler_file = queue_dir / "scheduler"
                        if scheduler_file.exists():
                            try:
                                with open(scheduler_file, 'r') as f:
                                    scheduler_data = f.read().strip()
                                    # Format: [noop] deadline cfq (active)
                                    active_match = re.search(r'\[([^\]]+)\]', scheduler_data)
                                    active_scheduler = active_match.group(1) if active_match else "unknown"
                                    
                                    result["devices"].append({
                                        "device": device_name,
                                        "scheduler": active_scheduler,
                                        "available": scheduler_data
                                    })
                            except (PermissionError, IOError):
                                continue
                                
        except Exception as e:
            logger.debug(f"Error analyzing I/O schedulers: {e}")
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    async def analyze_system_calls_for_process(pid: int, duration: int = 5) -> Optional[Dict[str, Any]]:
        """
        Analyze system calls for a specific process using strace
        
        Args:
            pid: Process ID
            duration: Duration to trace in seconds
            
        Returns:
            System call analysis results
        """
        result = {
            "pid": pid,
            "system_calls": {},
            "top_syscalls": [],
            "error_count": 0,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Use strace to trace system calls
            cmd = [
                "strace",
                "-c",  # Summary count
                "-p", str(pid),
                "-e", "trace=all"
            ]
            
            rc, out, err = await run_exec(cmd, timeout=duration + 2)

            if rc == 0 or err:
                output = err if err else (out or "")
                
                # Parse strace output
                # Look for % time | calls | errors | syscall pattern
                lines = output.split('\n')
                parsing_stats = False
                
                for line in lines:
                    if '%' in line and 'time' in line.lower():
                        parsing_stats = True
                        continue
                    
                    if parsing_stats and line.strip():
                        parts = line.split()
                        if len(parts) >= 4:
                            try:
                                time_percent = float(parts[0].rstrip('%'))
                                calls = int(parts[1])
                                errors = int(parts[2])
                                syscall = parts[3] if len(parts) > 3 else "unknown"
                                
                                result["system_calls"][syscall] = {
                                    "time_percent": time_percent,
                                    "calls": calls,
                                    "errors": errors
                                }
                                
                                result["error_count"] += errors
                            except (ValueError, IndexError):
                                continue
                
                # Get top system calls by time
                top_syscalls = sorted(
                    result["system_calls"].items(),
                    key=lambda x: x[1]["time_percent"],
                    reverse=True
                )[:10]
                
                result["top_syscalls"] = [
                    {"syscall": name, "time_percent": data["time_percent"], "calls": data["calls"]}
                    for name, data in top_syscalls
                ]
                
        except FileNotFoundError:
            result["error"] = "strace not available"
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error analyzing system calls for PID {pid}: {e}")
            result["error"] = str(e)
        
        return result if result.get("system_calls") else None

