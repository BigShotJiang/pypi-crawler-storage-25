"""
Anomaly detection using statistical analysis
"""
import datetime
import hashlib
import statistics
import time
from typing import Dict, List, Any, Optional

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger


class AnomalyDetector:
    """Detects anomalies in system metrics using statistical analysis"""
    
    def __init__(self, hostname: str, get_local_ip_func):
        self.hostname = hostname
        self._get_local_ip = get_local_ip_func
    
    def _get_top_cpu_process(self) -> Optional[Dict[str, Any]]:
        """Get the process with highest CPU usage"""
        if not psutil:
            return None
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'username', 'cmdline', 'num_threads', 'status']):
                try:
                    pinfo = proc.info
                    if pinfo['cpu_percent'] and pinfo['cpu_percent'] > 0:
                        processes.append({
                            "pid": pinfo['pid'],
                            "name": pinfo['name'],
                            "command": ' '.join(pinfo.get('cmdline') or [])[:200] or pinfo['name'],
                            "user": pinfo.get('username'),
                            "cpu_percent": round(pinfo['cpu_percent'], 1),
                            "memory_percent": round(pinfo.get('memory_percent') or 0, 1),
                            "thread_count": pinfo.get('num_threads'),
                            "status": pinfo.get('status')
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if processes:
                top = max(processes, key=lambda x: x['cpu_percent'])
                top["captured_at"] = datetime.datetime.utcnow().isoformat()
                return top
        except Exception as e:
            logger.debug(f"Error getting top CPU process: {e}")
        return None
    
    def _get_top_memory_process(self) -> Optional[Dict[str, Any]]:
        """Get the process with highest memory usage"""
        if not psutil:
            return None
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'memory_percent', 'cpu_percent', 'username', 'cmdline', 'num_threads', 'status']):
                try:
                    pinfo = proc.info
                    if pinfo['memory_percent'] and pinfo['memory_percent'] > 0:
                        processes.append({
                            "pid": pinfo['pid'],
                            "name": pinfo['name'],
                            "command": ' '.join(pinfo.get('cmdline') or [])[:200] or pinfo['name'],
                            "user": pinfo.get('username'),
                            "cpu_percent": round(pinfo.get('cpu_percent') or 0, 1),
                            "memory_percent": round(pinfo['memory_percent'], 1),
                            "thread_count": pinfo.get('num_threads'),
                            "status": pinfo.get('status')
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if processes:
                top = max(processes, key=lambda x: x['memory_percent'])
                top["captured_at"] = datetime.datetime.utcnow().isoformat()
                return top
        except Exception as e:
            logger.debug(f"Error getting top memory process: {e}")
        return None
    
    def _get_top_network_process(self) -> Optional[Dict[str, Any]]:
        """Get the process with most network connections"""
        if not psutil:
            return None
        try:
            process_connections = {}
            connections = psutil.net_connections(kind='inet')
            
            for conn in connections:
                if conn.pid:
                    if conn.pid not in process_connections:
                        process_connections[conn.pid] = {
                            "connections": [],
                            "total_bytes_sent": 0,
                            "total_bytes_recv": 0
                        }
                    process_connections[conn.pid]["connections"].append(conn)
            
            if not process_connections:
                return None
            
            # Get the process with most connections
            top_pid = max(process_connections.keys(), key=lambda p: len(process_connections[p]["connections"]))
            top_conns = process_connections[top_pid]["connections"]
            
            try:
                proc = psutil.Process(top_pid)
                pinfo = proc.as_dict(attrs=['pid', 'name', 'cmdline', 'username', 'cpu_percent', 'memory_percent', 'num_threads', 'status'])
                
                # Get primary connection info
                primary_conn = top_conns[0] if top_conns else None
                network_details = None
                
                if primary_conn:
                    direction = "outbound" if primary_conn.status == 'ESTABLISHED' and primary_conn.raddr else "inbound"
                    network_details = {
                        "direction": direction,
                        "protocol": "TCP" if primary_conn.type == 1 else "UDP",
                        "local_address": primary_conn.laddr.ip if primary_conn.laddr else None,
                        "local_port": primary_conn.laddr.port if primary_conn.laddr else None,
                        "remote_address": primary_conn.raddr.ip if primary_conn.raddr else None,
                        "remote_port": primary_conn.raddr.port if primary_conn.raddr else None
                    }
                
                return {
                    "process_info": {
                        "pid": pinfo['pid'],
                        "name": pinfo['name'],
                        "command": ' '.join(pinfo.get('cmdline') or [])[:200] or pinfo['name'],
                        "user": pinfo.get('username'),
                        "cpu_percent": round(pinfo.get('cpu_percent') or 0, 1),
                        "memory_percent": round(pinfo.get('memory_percent') or 0, 1),
                        "thread_count": pinfo.get('num_threads'),
                        "status": pinfo.get('status'),
                        "captured_at": datetime.datetime.utcnow().isoformat(),
                    },
                    "network_details": network_details,
                    "connection_count": len(top_conns)
                }
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        except Exception as e:
            logger.debug(f"Error getting top network process: {e}")
        return None
    
    def _get_top_disk_io_process(self) -> Optional[Dict[str, Any]]:
        """Get the process with highest disk I/O"""
        if not psutil:
            return None
        try:
            # io_counters are cumulative; estimate rate by sampling a small set of top candidates.
            candidates = []
            for proc in psutil.process_iter(['pid', 'name', 'io_counters', 'username', 'cmdline', 'cpu_percent', 'memory_percent', 'num_threads', 'status']):
                try:
                    pinfo = proc.info
                    io_counters = pinfo.get('io_counters')
                    if io_counters:
                        write_bytes = io_counters.write_bytes if hasattr(io_counters, 'write_bytes') else 0
                        read_bytes = io_counters.read_bytes if hasattr(io_counters, 'read_bytes') else 0
                        
                        if write_bytes > 0 or read_bytes > 0:
                            candidates.append({
                                "pid": pinfo['pid'],
                                "name": pinfo['name'],
                                "command": ' '.join(pinfo.get('cmdline') or [])[:200] or pinfo['name'],
                                "user": pinfo.get('username'),
                                "cpu_percent": round(pinfo.get('cpu_percent') or 0, 1),
                                "memory_percent": round(pinfo.get('memory_percent') or 0, 1),
                                "thread_count": pinfo.get('num_threads'),
                                "status": pinfo.get('status'),
                                "write_bytes": write_bytes,
                                "read_bytes": read_bytes
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            if not candidates:
                return None

            # Take top N by cumulative IO and sample rate for those.
            top_n = sorted(candidates, key=lambda x: x['write_bytes'] + x['read_bytes'], reverse=True)[:10]
            t0 = time.monotonic()
            before = {}
            for c in top_n:
                try:
                    p = psutil.Process(c["pid"])
                    io0 = p.io_counters()
                    before[c["pid"]] = (getattr(io0, "read_bytes", 0), getattr(io0, "write_bytes", 0))
                except (psutil.NoSuchProcess, psutil.AccessDenied, Exception):
                    continue

            # short sample window (avoid blocking the agent loop; this function is typically called via to_thread)
            __import__("time").sleep(0.2)
            dt = max(time.monotonic() - t0, 0.05)

            best = None
            best_rate = -1.0
            best_op = "read"
            for c in top_n:
                pid = c["pid"]
                if pid not in before:
                    continue
                try:
                    p = psutil.Process(pid)
                    io1 = p.io_counters()
                    r0, w0 = before[pid]
                    r1 = getattr(io1, "read_bytes", 0)
                    w1 = getattr(io1, "write_bytes", 0)
                    dr = max(0, r1 - r0)
                    dw = max(0, w1 - w0)
                    rate_mbps = (dr + dw) / (1024 * 1024) / dt  # MB/s
                    if rate_mbps > best_rate:
                        best_rate = rate_mbps
                        best = c
                        best_op = "write" if dw > dr else "read"
                except (psutil.NoSuchProcess, psutil.AccessDenied, Exception):
                    continue

            if not best:
                # fallback to cumulative top process, but don't pretend it's a rate
                best = top_n[0]
                best_rate = 0.0
                best_op = "write" if best['write_bytes'] > best['read_bytes'] else "read"

            return {
                "process_info": {
                    "pid": best['pid'],
                    "name": best['name'],
                    "command": best['command'],
                    "user": best['user'],
                    "cpu_percent": best['cpu_percent'],
                    "memory_percent": best['memory_percent'],
                    "thread_count": best['thread_count'],
                    "status": best['status'],
                    "captured_at": datetime.datetime.utcnow().isoformat(),
                },
                "disk_details": {
                    "operation": best_op,
                    "speed_mbps": round(best_rate, 2)
                }
            }
        except Exception as e:
            logger.debug(f"Error getting top disk I/O process: {e}")
        return None
    
    def _get_cpu_details(self) -> Optional[Dict[str, Any]]:
        """Get detailed CPU metrics"""
        if not psutil:
            return None
        try:
            cpu_times = psutil.cpu_times_percent(interval=0.1)
            return {
                "user_percent": round(cpu_times.user, 1),
                "system_percent": round(cpu_times.system, 1),
                "idle_percent": round(cpu_times.idle, 1),
                "iowait_percent": round(getattr(cpu_times, 'iowait', 0), 1)
            }
        except Exception as e:
            logger.debug(f"Error getting CPU details: {e}")
        return None
    
    def _get_memory_details(self) -> Optional[Dict[str, Any]]:
        """Get detailed memory metrics"""
        if not psutil:
            return None
        try:
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()
            return {
                "total_gb": round(mem.total / (1024**3), 2),
                "used_gb": round(mem.used / (1024**3), 2),
                "available_gb": round(mem.available / (1024**3), 2),
                "swap_used_gb": round(swap.used / (1024**3), 2)
            }
        except Exception as e:
            logger.debug(f"Error getting memory details: {e}")
        return None
    
    def detect_anomalies(
        self, 
        current_metric: Optional[Dict[str, Any]], 
        baselines: Dict[str, float]
    ) -> List[Dict[str, Any]]:
        """Detect anomalies in current metrics"""
        anomalies = []
        
        if not current_metric:
            return anomalies
        
        # Use default baselines if not enough history
        if not baselines:
            baselines = {
                "cpu": 30.0,
                "memory": 50.0,
                "storage": 45.0,
                "network_in": 100.0,
                "network_out": 150.0
            }
        
        timestamp = datetime.datetime.utcnow().isoformat()
        
        # CPU anomaly detection
        cpu_current = current_metric["cpu"]
        cpu_baseline = baselines.get("cpu", 30.0)
        cpu_deviation = ((cpu_current - cpu_baseline) / cpu_baseline * 100) if cpu_baseline > 0 else 0
        
        if abs(cpu_deviation) > 50:  # More than 50% deviation
            severity = "critical" if cpu_deviation > 100 else "high" if cpu_deviation > 70 else "medium"
            
            # Get process info for CPU anomaly
            top_cpu_proc = self._get_top_cpu_process()
            cpu_details = self._get_cpu_details()
            
            anomaly_data = {
                "id": f"anomaly_{hashlib.md5(f'cpu_{timestamp}'.encode()).hexdigest()[:8]}",
                "timestamp": timestamp,
                "severity": severity,
                "type": "cpu",
                "asset": self.hostname,
                "asset_ip": self._get_local_ip(),
                "metric": "CPU Usage",
                "current_value": round(cpu_current, 1),
                "expected_value": round(cpu_baseline, 1),
                "deviation": round(cpu_deviation, 1),
                "description": f"CPU usage {'spiked' if cpu_deviation > 0 else 'dropped'} to {cpu_current:.1f}% - unusual pattern. Expected baseline: {cpu_baseline:.1f}%",
                "status": "active"
            }
            
            if top_cpu_proc:
                anomaly_data["process_info"] = top_cpu_proc
            if cpu_details:
                anomaly_data["cpu_details"] = cpu_details
            
            anomalies.append(anomaly_data)
        
        # Memory anomaly detection
        memory_current = current_metric["memory"]
        memory_baseline = baselines.get("memory", 50.0)
        memory_deviation = ((memory_current - memory_baseline) / memory_baseline * 100) if memory_baseline > 0 else 0
        
        if abs(memory_deviation) > 30:
            severity = "critical" if memory_deviation > 80 else "high" if memory_deviation > 50 else "medium" if memory_deviation > 30 else "low"
            
            # Get process info for Memory anomaly
            top_mem_proc = self._get_top_memory_process()
            memory_details = self._get_memory_details()
            
            anomaly_data = {
                "id": f"anomaly_{hashlib.md5(f'memory_{timestamp}'.encode()).hexdigest()[:8]}",
                "timestamp": timestamp,
                "severity": severity,
                "type": "memory",
                "asset": self.hostname,
                "asset_ip": self._get_local_ip(),
                "metric": "Memory Usage",
                "current_value": round(memory_current, 1),
                "expected_value": round(memory_baseline, 1),
                "deviation": round(memory_deviation, 1),
                "description": f"Memory usage elevated to {memory_current:.1f}%, {'significantly' if memory_deviation > 50 else 'slightly'} above expected {memory_baseline:.1f}% baseline",
                "status": "active"
            }
            
            if top_mem_proc:
                anomaly_data["process_info"] = top_mem_proc
            if memory_details:
                anomaly_data["memory_details"] = memory_details
            
            anomalies.append(anomaly_data)
        
        # Storage anomaly detection
        storage_current = current_metric["storage"]
        storage_baseline = baselines.get("storage", 45.0)
        storage_deviation = ((storage_current - storage_baseline) / storage_baseline * 100) if storage_baseline > 0 else 0
        
        if storage_deviation > 50:  # Storage growth
            severity = "critical" if storage_deviation > 100 else "high" if storage_deviation > 75 else "medium"
            anomalies.append({
                "id": f"anomaly_{hashlib.md5(f'storage_{timestamp}'.encode()).hexdigest()[:8]}",
                "timestamp": timestamp,
                "severity": severity,
                "type": "storage",
                "asset": self.hostname,
                "asset_ip": self._get_local_ip(),
                "metric": "Storage Growth",
                "current_value": round(storage_current, 1),
                "expected_value": round(storage_baseline, 1),
                "deviation": round(storage_deviation, 1),
                "description": f"Storage usage growth anomaly. {storage_current:.1f}% usage growing faster than expected pattern ({storage_baseline:.1f}% baseline)",
                "status": "active"
            })
        
        # Network anomaly detection
        network_in_current = current_metric["network_in"]
        network_in_baseline = baselines.get("network_in", 100.0)
        network_in_deviation = ((network_in_current - network_in_baseline) / network_in_baseline * 100) if network_in_baseline > 0 else 0
        
        if abs(network_in_deviation) > 200:  # Significant network traffic change
            severity = "critical" if network_in_deviation > 500 else "high"
            
            # Get process info for Network anomaly
            network_proc_info = self._get_top_network_process()
            
            anomaly_data = {
                "id": f"anomaly_{hashlib.md5(f'network_{timestamp}'.encode()).hexdigest()[:8]}",
                "timestamp": timestamp,
                "severity": severity,
                "type": "network",
                "asset": self.hostname,
                "asset_ip": self._get_local_ip(),
                "metric": "Network Traffic",
                "current_value": round(network_in_current, 1),
                "expected_value": round(network_in_baseline, 1),
                "deviation": round(network_in_deviation, 1),
                # UI expects Mbps for network anomalies
                "description": f"Unusual network traffic pattern detected. {network_in_current:.1f} Mbps vs expected {network_in_baseline:.1f} Mbps baseline",
                "status": "active"
            }
            
            if network_proc_info:
                anomaly_data["process_info"] = network_proc_info.get("process_info")
                anomaly_data["network_details"] = network_proc_info.get("network_details")
            
            anomalies.append(anomaly_data)
        
        # Disk I/O anomaly detection
        disk_write_current = current_metric["disk_write"]
        if disk_write_current > 100:  # High disk write activity
            # Get process info for Disk I/O anomaly
            disk_proc_info = self._get_top_disk_io_process()
            
            anomaly_data = {
                "id": f"anomaly_{hashlib.md5(f'diskio_{timestamp}'.encode()).hexdigest()[:8]}",
                "timestamp": timestamp,
                "severity": "medium",
                "type": "disk-io",
                "asset": self.hostname,
                "asset_ip": self._get_local_ip(),
                "metric": "Disk Write I/O",
                "current_value": round(disk_write_current, 1),
                "expected_value": 50.0,
                "deviation": round(((disk_write_current - 50.0) / 50.0 * 100), 1),
                "description": f"Disk write I/O increased to {disk_write_current:.1f} MB/s, exceeding normal baseline",
                "status": "active"
            }
            
            if disk_proc_info:
                anomaly_data["process_info"] = disk_proc_info.get("process_info")
                anomaly_data["disk_details"] = disk_proc_info.get("disk_details")
            
            anomalies.append(anomaly_data)
        
        return anomalies
    
    def detect_service_call_anomalies(self) -> List[Dict[str, Any]]:
        """Detect service call latency anomalies"""
        anomalies = []
        
        # In real implementation, this would analyze actual service calls
        # For now, we simulate detection based on network connections
        
        try:
            import psutil
            if not psutil:
                return anomalies
            
            timestamp = datetime.datetime.utcnow().isoformat()
            
            # Analyze network connections for potential service call issues
            connections = psutil.net_connections(kind='inet')
            for conn in connections:
                if conn.status == 'ESTABLISHED' and conn.raddr:
                    # Simulate high latency detection
                    # In production, this would use actual APM data
                    pass
            
            # Example anomaly (simulated) - commented out
            # anomalies.append({...})
            
        except Exception as e:
            from utils.logger import logger
            logger.debug(f"Error detecting service call anomalies: {e}")
        
        return anomalies


class BaselineCalculator:
    """Calculates baseline values from historical metrics"""
    
    @staticmethod
    def update_baselines(metric_history: list) -> Dict[str, float]:
        """Update baseline values based on historical metrics"""
        baselines = {}
        
        if len(metric_history) < 10:
            # Need more data for baseline
            return baselines
        
        try:
            # Calculate baseline (median) for each metric
            cpu_values = [m["cpu"] for m in metric_history if "cpu" in m]
            memory_values = [m["memory"] for m in metric_history if "memory" in m]
            storage_values = [m["storage"] for m in metric_history if "storage" in m]
            network_in_values = [m["network_in"] for m in metric_history if "network_in" in m]
            network_out_values = [m["network_out"] for m in metric_history if "network_out" in m]
            
            if cpu_values:
                baselines["cpu"] = statistics.median(cpu_values)
            if memory_values:
                baselines["memory"] = statistics.median(memory_values)
            if storage_values:
                baselines["storage"] = statistics.median(storage_values)
            if network_in_values:
                baselines["network_in"] = statistics.median(network_in_values)
            if network_out_values:
                baselines["network_out"] = statistics.median(network_out_values)
        except Exception as e:
            from utils.logger import logger
            logger.debug(f"Error updating baselines: {e}")
        
        return baselines

