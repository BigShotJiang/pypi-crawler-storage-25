"""
Advanced Memory Analysis Module

Deep memory analysis:
- Memory leak detection
- Memory corruption detection
- Memory encryption analysis
"""

import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger

try:
    import psutil
except ImportError:
    psutil = None


class AdvancedMemoryAnalyzer:
    """Advanced memory analysis"""
    
    @staticmethod
    async def detect_memory_leaks(processes: Optional[List[int]] = None) -> Dict[str, Any]:
        """
        Detect memory leaks in processes
        
        Args:
            processes: Optional list of PIDs to check
            
        Returns:
            Memory leak detection results
        """
        result = {
            "leaks_detected": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if not psutil:
            return result
        
        try:
            pids_to_check = processes if processes else []
            
            # Get all processes if not specified
            if not pids_to_check:
                for proc in psutil.process_iter(['pid']):
                    try:
                        pids_to_check.append(proc.info['pid'])
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            
            # Monitor memory usage over time
            memory_snapshots = {}
            
            for pid in pids_to_check[:50]:  # Limit
                try:
                    proc = psutil.Process(pid)
                    mem_info = proc.memory_info()
                    
                    # Take multiple snapshots
                    if pid not in memory_snapshots:
                        memory_snapshots[pid] = []
                    
                    memory_snapshots[pid].append({
                        "rss": mem_info.rss,
                        "vms": mem_info.vms,
                        "timestamp": datetime.utcnow()
                    })
                    
                    # Simple heuristic: if memory consistently grows, potential leak
                    if len(memory_snapshots[pid]) > 3:
                        rss_values = [s["rss"] for s in memory_snapshots[pid]]
                        if all(rss_values[i] < rss_values[i+1] for i in range(len(rss_values)-1)):
                            growth_rate = (rss_values[-1] - rss_values[0]) / len(rss_values)
                            
                            if growth_rate > 1024 * 1024:  # > 1MB per snapshot
                                result["leaks_detected"].append({
                                    "pid": pid,
                                    "process_name": proc.name(),
                                    "memory_growth_mb": round(growth_rate / (1024 * 1024), 2),
                                    "severity": "medium",
                                    "description": "Consistent memory growth detected"
                                })
                                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception:
                    continue
                    
        except Exception as e:
            logger.debug(f"Error detecting memory leaks: {e}")
        
        return result
    
    @staticmethod
    async def detect_memory_corruption() -> List[Dict[str, Any]]:
        """
        Detect memory corruption indicators
        
        Returns:
            List of memory corruption indicators
        """
        corruptions = []
        timestamp = datetime.utcnow().isoformat()
        
        try:
            # Check system logs for memory corruption messages
            log_paths = [
                Path("/var/log/syslog"),
                Path("/var/log/messages"),
                Path("/var/log/kern.log"),
            ]
            
            corruption_patterns = [
                (r'kernel.*BUG', 'Kernel bug detected'),
                (r'kernel.*panic', 'Kernel panic'),
                (r'segfault', 'Segmentation fault'),
                (r'buffer overflow', 'Buffer overflow'),
                (r'use.*after.*free', 'Use after free'),
                (r'double.*free', 'Double free'),
                (r'memory.*corruption', 'Memory corruption'),
            ]
            
            for log_path in log_paths:
                if log_path.exists():
                    try:
                        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                            # Read last 1000 lines
                            lines = f.readlines()[-1000:]
                            
                            for line in lines:
                                for pattern, description in corruption_patterns:
                                    if re.search(pattern, line, re.I):
                                        corruptions.append({
                                            "type": "memory_corruption",
                                            "description": description,
                                            "log_file": str(log_path),
                                            "log_line": line.strip()[:200],
                                            "severity": "high",
                                            "timestamp": timestamp
                                        })
                                        break
                    except (PermissionError, IOError):
                        continue
                    except Exception:
                        continue
                        
        except Exception as e:
            logger.debug(f"Error detecting memory corruption: {e}")
        
        return corruptions
    
    @staticmethod
    async def analyze_memory_encryption() -> Dict[str, Any]:
        """
        Analyze memory encryption status
        
        Returns:
            Memory encryption analysis results
        """
        result = {
            "encryption_enabled": False,
            "encryption_type": None,
            "details": {},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Check for Intel TME (Total Memory Encryption)
            # Check for AMD SME (Secure Memory Encryption)
            
            # Check CPU flags
            try:
                with open("/proc/cpuinfo", 'r') as f:
                    cpuinfo = f.read()
                    
                    if 'tme' in cpuinfo.lower() or 'total memory encryption' in cpuinfo.lower():
                        result["encryption_enabled"] = True
                        result["encryption_type"] = "Intel TME"
                    
                    if 'sme' in cpuinfo.lower() or 'secure memory encryption' in cpuinfo.lower():
                        result["encryption_enabled"] = True
                        result["encryption_type"] = "AMD SME"
                        
            except (PermissionError, IOError):
                pass
            
            # Check kernel configuration
            try:
                config_paths = [
                    Path("/proc/config.gz"),
                    Path("/boot/config"),
                    Path("/boot/config-$(uname -r)"),
                ]
                
                for config_path in config_paths:
                    if config_path.exists():
                        # Note: Would need to decompress and parse config
                        result["details"]["config_file"] = str(config_path)
                        break
            except Exception:
                pass
                
        except Exception as e:
            logger.debug(f"Error analyzing memory encryption: {e}")
        
        return result
    
    @staticmethod
    async def analyze_heap_usage() -> Dict[str, Any]:
        """
        Analyze heap usage patterns
        
        Returns:
            Heap usage analysis results
        """
        result = {
            "processes": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if not psutil:
            return result
        
        try:
            # Analyze heap usage per process
            for proc in psutil.process_iter(['pid', 'name', 'memory_info', 'memory_percent']):
                try:
                    proc_info = proc.info
                    mem_info = proc_info.get('memory_info')
                    
                    if mem_info:
                        heap_size = mem_info.rss  # Simplified: RSS as heap approximation
                        
                        # Flag processes with high heap usage
                        if heap_size > 500 * 1024 * 1024:  # > 500MB
                            result["processes"].append({
                                "pid": proc_info['pid'],
                                "name": proc_info.get('name'),
                                "heap_size_mb": round(heap_size / (1024 * 1024), 2),
                                "memory_percent": proc_info.get('memory_percent', 0),
                                "severity": "high" if heap_size > 1024 * 1024 * 1024 else "medium"
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception:
                    continue
                    
        except Exception as e:
            logger.debug(f"Error analyzing heap usage: {e}")
        
        return result

