"""
Advanced Process Analysis Module

Deep process analysis:
- Process tree analysis (parent-child relationships)
- Inter-process communication (IPC) discovery
- Shared memory analysis
- System call patterns
- Resource contention detection
"""

import re
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from collections import defaultdict
from utils.logger import logger

from utils.async_subprocess import run_exec

try:
    import psutil
except ImportError:
    psutil = None


class ProcessAnalyzer:
    """Advanced process analysis"""
    
    @staticmethod
    async def analyze_process_tree() -> Dict[str, Any]:
        """
        Analyze process tree and relationships
        
        Returns:
            Process tree analysis results
        """
        tree_data = {
            "root_processes": [],
            "orphan_processes": [],
            "deep_trees": [],
            "suspicious_parents": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if not psutil:
            return tree_data
        
        try:
            all_processes = {}
            parent_map = defaultdict(list)
            
            # Build process map and parent relationships
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'username', 'create_time']):
                try:
                    proc_info = proc.info
                    pid = proc_info['pid']
                    ppid = proc_info['ppid']
                    
                    all_processes[pid] = proc_info
                    parent_map[ppid].append(pid)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Find root processes (PPID = 1 or 0)
            for pid, proc_info in all_processes.items():
                ppid = proc_info.get('ppid', 0)
                if ppid in [0, 1]:
                    tree_data["root_processes"].append({
                        "pid": pid,
                        "name": proc_info.get('name'),
                        "username": proc_info.get('username'),
                        "children_count": len(parent_map.get(pid, []))
                    })
            
            # Find orphan processes (parent doesn't exist)
            for pid, proc_info in all_processes.items():
                ppid = proc_info.get('ppid', 0)
                if ppid not in all_processes and ppid not in [0, 1]:
                    tree_data["orphan_processes"].append({
                        "pid": pid,
                        "name": proc_info.get('name'),
                        "ppid": ppid,
                        "username": proc_info.get('username')
                    })
            
            # Find deep process trees (potential chain)
            def get_tree_depth(pid, visited=None):
                if visited is None:
                    visited = set()
                if pid in visited:
                    return 0  # Cycle detected
                visited.add(pid)
                
                children = parent_map.get(pid, [])
                if not children:
                    return 1
                
                max_depth = 1 + max([get_tree_depth(child, visited.copy()) for child in children], default=0)
                return max_depth
            
            for root_pid in [p["pid"] for p in tree_data["root_processes"]]:
                depth = get_tree_depth(root_pid)
                if depth > 5:  # Deep tree
                    tree_data["deep_trees"].append({
                        "root_pid": root_pid,
                        "depth": depth,
                        "root_name": all_processes.get(root_pid, {}).get('name')
                    })
            
            # Find suspicious parent processes
            suspicious_parents = ['bash', 'sh', 'python', 'perl', 'ruby', 'node']
            for pid, proc_info in all_processes.items():
                proc_name = proc_info.get('name', '').lower()
                if proc_name in suspicious_parents:
                    children = parent_map.get(pid, [])
                    if len(children) > 3:  # Many children
                        tree_data["suspicious_parents"].append({
                            "pid": pid,
                            "name": proc_info.get('name'),
                            "children_count": len(children),
                            "children": [all_processes.get(c, {}).get('name', 'unknown') for c in children[:5]]
                        })
                        
        except Exception as e:
            logger.debug(f"Error analyzing process tree: {e}")
        
        return tree_data
    
    @staticmethod
    async def analyze_ipc() -> List[Dict[str, Any]]:
        """
        Analyze Inter-Process Communication
        
        Returns:
            IPC analysis results
        """
        ipc_connections = []
        
        if not psutil:
            return ipc_connections
        
        try:
            # Analyze shared memory
            shm_path = Path("/dev/shm")
            if shm_path.exists():
                for shm_file in shm_path.iterdir():
                    try:
                        # Check file size and access
                        stat = shm_file.stat()
                        ipc_connections.append({
                            "type": "shared_memory",
                            "path": str(shm_file),
                            "size": stat.st_size,
                            "accessed": datetime.fromtimestamp(stat.st_atime).isoformat(),
                            "timestamp": datetime.utcnow().isoformat()
                        })
                    except (PermissionError, IOError):
                        continue
            
            # Analyze named pipes (FIFOs)
            for proc in psutil.process_iter(['pid', 'open_files']):
                try:
                    proc_info = proc.info
                    open_files = proc_info.get('open_files', [])
                    
                    for file_info in open_files:
                        file_path = file_info.path if hasattr(file_info, 'path') else str(file_info)
                        if Path(file_path).is_fifo():
                            ipc_connections.append({
                                "type": "named_pipe",
                                "path": file_path,
                                "pid": proc_info['pid'],
                                "process_name": proc.name(),
                                "timestamp": datetime.utcnow().isoformat()
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception:
                    continue
                    
        except Exception as e:
            logger.debug(f"Error analyzing IPC: {e}")
        
        return ipc_connections
    
    @staticmethod
    async def detect_resource_contention() -> List[Dict[str, Any]]:
        """
        Detect resource contention between processes
        
        Returns:
            Resource contention indicators
        """
        contentions = []
        
        if not psutil:
            return contentions
        
        try:
            # Group processes by resource usage
            cpu_processes = []
            memory_processes = []
            
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    proc_info = proc.info
                    cpu_percent = proc_info.get('cpu_percent', 0)
                    memory_percent = proc_info.get('memory_percent', 0)
                    
                    if cpu_percent > 50:
                        cpu_processes.append({
                            "pid": proc_info['pid'],
                            "name": proc_info.get('name'),
                            "cpu_percent": cpu_percent
                        })
                    
                    if memory_percent > 10:
                        memory_processes.append({
                            "pid": proc_info['pid'],
                            "name": proc_info.get('name'),
                            "memory_percent": memory_percent
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Detect contention (multiple processes competing for same resource)
            if len(cpu_processes) > 3:
                contentions.append({
                    "type": "cpu_contention",
                    "competing_processes": len(cpu_processes),
                    "top_processes": sorted(cpu_processes, key=lambda x: x['cpu_percent'], reverse=True)[:5],
                    "severity": "high" if len(cpu_processes) > 5 else "medium",
                    "timestamp": datetime.utcnow().isoformat()
                })
            
            if len(memory_processes) > 5:
                contentions.append({
                    "type": "memory_contention",
                    "competing_processes": len(memory_processes),
                    "top_processes": sorted(memory_processes, key=lambda x: x['memory_percent'], reverse=True)[:5],
                    "severity": "high" if len(memory_processes) > 10 else "medium",
                    "timestamp": datetime.utcnow().isoformat()
                })
                
        except Exception as e:
            logger.debug(f"Error detecting resource contention: {e}")
        
        return contentions
    
    @staticmethod
    async def analyze_system_calls(pid: int) -> Optional[Dict[str, Any]]:
        """
        Analyze system calls for a process (requires strace)
        
        Args:
            pid: Process ID
            
        Returns:
            System call analysis
        """
        try:
            # Use strace to trace system calls
            rc, out, _ = await run_exec(["strace", "-c", "-p", str(pid)], timeout=5)
            if rc == 0 and out:
                output = out
                
                # Parse strace output
                syscalls = {}
                for line in output.split('\n'):
                    if '%' in line and 'time' in line.lower():
                        parts = line.split()
                        if len(parts) >= 4:
                            syscall_name = parts[-1]
                            time_percent = parts[0].replace('%', '')
                            try:
                                syscalls[syscall_name] = float(time_percent)
                            except ValueError:
                                pass
                
                return {
                    "pid": pid,
                    "system_calls": syscalls,
                    "top_syscalls": sorted(syscalls.items(), key=lambda x: x[1], reverse=True)[:10],
                    "timestamp": datetime.utcnow().isoformat()
                }
        except FileNotFoundError:
            # strace not available
            return None
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Error analyzing system calls for PID {pid}: {e}")
            return None

