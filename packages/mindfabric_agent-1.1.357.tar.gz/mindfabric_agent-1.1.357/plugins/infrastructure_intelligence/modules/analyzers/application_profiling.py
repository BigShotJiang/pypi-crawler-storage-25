"""
Application-Level Profiling Module

Deep application profiling:
- CPU profiling
- Memory profiling
- I/O profiling
"""

import re
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger

from utils.async_subprocess import run_exec


class ApplicationProfiler:
    """Application profiling"""
    
    @staticmethod
    async def profile_process_cpu(pid: int, duration: int = 5) -> Optional[Dict[str, Any]]:
        """
        Profile CPU usage for a process using perf
        
        Args:
            pid: Process ID
            duration: Profiling duration in seconds
            
        Returns:
            CPU profiling results
        """
        result = {
            "pid": pid,
            "duration": duration,
            "samples": {},
            "top_functions": [],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Use perf to profile CPU
            cmd = [
                "perf", "record",
                "-g",  # Call graph
                "-p", str(pid),
                "--", "sleep", str(duration)
            ]

            rc, _, _ = await run_exec(cmd, timeout=duration + 5)
            if rc == 0:
                # Parse perf report
                report_cmd = ["perf", "report", "--stdio", "--no-children"]
                rc2, out2, _ = await run_exec(report_cmd, timeout=10)
                if rc2 == 0 and out2:
                    # Parse report output
                    lines = out2.split('\n')
                    for line in lines[:50]:  # First 50 lines
                        # Look for function names and percentages
                        match = re.search(r'(\d+\.\d+)\%\s+(.+)', line)
                        if match:
                            percent = float(match.group(1))
                            function = match.group(2).strip()
                            
                            result["samples"][function] = percent
                            
                            result["top_functions"].append({
                                "function": function,
                                "percentage": percent
                            })
                    
                    # Sort by percentage
                    result["top_functions"].sort(key=lambda x: x["percentage"], reverse=True)
                    result["top_functions"] = result["top_functions"][:10]
                    
        except FileNotFoundError:
            result["error"] = "perf not available"
        except asyncio.TimeoutError:
            result["timeout"] = True
        except Exception as e:
            logger.debug(f"Error profiling CPU for PID {pid}: {e}")
            result["error"] = str(e)
        
        return result if result.get("samples") else None
    
    @staticmethod
    async def profile_process_memory(pid: int) -> Optional[Dict[str, Any]]:
        """
        Profile memory usage for a process
        
        Args:
            pid: Process ID
            
        Returns:
            Memory profiling results
        """
        result = {
            "pid": pid,
            "memory_maps": [],
            "total_memory": 0,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Read /proc/[pid]/maps
            maps_file = Path(f"/proc/{pid}/maps")
            if maps_file.exists():
                with open(maps_file, 'r') as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 5:
                            address_range = parts[0]
                            perms = parts[1]
                            offset = parts[2]
                            device = parts[3]
                            inode = parts[4]
                            pathname = parts[5] if len(parts) > 5 else ""
                            
                            # Parse address range
                            if '-' in address_range:
                                start_addr, end_addr = address_range.split('-')
                                try:
                                    start = int(start_addr, 16)
                                    end = int(end_addr, 16)
                                    size = end - start
                                    
                                    result["total_memory"] += size
                                    
                                    result["memory_maps"].append({
                                        "address_range": address_range,
                                        "size_kb": round(size / 1024, 2),
                                        "permissions": perms,
                                        "pathname": pathname[:100]  # Limit length
                                    })
                                except ValueError:
                                    continue
                
                # Sort by size
                result["memory_maps"].sort(key=lambda x: x.get("size_kb", 0), reverse=True)
                result["memory_maps"] = result["memory_maps"][:20]  # Top 20
                
                result["total_memory_mb"] = round(result["total_memory"] / (1024 * 1024), 2)
                
        except (PermissionError, IOError):
            result["error"] = "Permission denied or process not found"
        except Exception as e:
            logger.debug(f"Error profiling memory for PID {pid}: {e}")
            result["error"] = str(e)
        
        return result if result.get("memory_maps") else None
    
    @staticmethod
    async def profile_process_io(pid: int, duration: int = 5) -> Optional[Dict[str, Any]]:
        """
        Profile I/O usage for a process
        
        Args:
            pid: Process ID
            duration: Profiling duration
            
        Returns:
            I/O profiling results
        """
        result = {
            "pid": pid,
            "duration": duration,
            "io_stats": {},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            # Use iotop or read /proc/[pid]/io
            io_file = Path(f"/proc/{pid}/io")
            if io_file.exists():
                with open(io_file, 'r') as f:
                    for line in f:
                        parts = line.split(':')
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value = parts[1].strip()
                            
                            try:
                                result["io_stats"][key] = int(value)
                            except ValueError:
                                result["io_stats"][key] = value
                
                # Calculate rates if we have multiple snapshots
                # For now, just return current stats
                if "read_bytes" in result["io_stats"]:
                    result["read_mb"] = round(result["io_stats"]["read_bytes"] / (1024 * 1024), 2)
                if "write_bytes" in result["io_stats"]:
                    result["write_mb"] = round(result["io_stats"]["write_bytes"] / (1024 * 1024), 2)
                    
        except (PermissionError, IOError):
            result["error"] = "Permission denied or process not found"
        except Exception as e:
            logger.debug(f"Error profiling I/O for PID {pid}: {e}")
            result["error"] = str(e)
        
        return result if result.get("io_stats") else None
    
    @staticmethod
    async def generate_flame_graph(pid: int, output_dir: Path = Path("/tmp")) -> Optional[str]:
        """
        Generate flame graph for a process (requires FlameGraph tools)
        
        Args:
            pid: Process ID
            output_dir: Output directory for flame graph
            
        Returns:
            Path to flame graph SVG file
        """
        try:
            # This requires FlameGraph tools (https://github.com/brendangregg/FlameGraph)
            # Placeholder structure
            result = {
                "pid": pid,
                "flamegraph_available": False,
                "note": "FlameGraph tools required: https://github.com/brendangregg/FlameGraph",
                "output_dir": str(output_dir)
            }
            
            return None
            
        except Exception as e:
            logger.debug(f"Error generating flame graph for PID {pid}: {e}")
            return None

