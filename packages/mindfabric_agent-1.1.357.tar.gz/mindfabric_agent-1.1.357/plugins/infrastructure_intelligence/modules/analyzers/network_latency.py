"""
Network Latency Measurement Module

Measures network latency and packet loss:
- ICMP ping to known servers
- TCP connection timing
- Latency and jitter calculation
"""

import socket
import time
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from utils.logger import logger
from utils.async_subprocess import run_exec


class NetworkLatencyMeasurer:
    """Network latency and packet loss measurement"""
    
    # Common test targets
    DEFAULT_TARGETS = [
        "8.8.8.8",  # Google DNS
        "1.1.1.1",  # Cloudflare DNS
        "208.67.222.222",  # OpenDNS
    ]
    
    @staticmethod
    async def measure_latency(targets: Optional[List[str]] = None, count: int = 5) -> List[Dict[str, Any]]:
        """
        Measure latency to target hosts using ICMP ping
        
        Args:
            targets: List of IP addresses or hostnames to ping
            count: Number of ping packets to send
            
        Returns:
            List of latency measurements
        """
        if targets is None:
            targets = NetworkLatencyMeasurer.DEFAULT_TARGETS
        
        measurements = []
        
        for target in targets:
            try:
                measurement = await NetworkLatencyMeasurer._ping_target(target, count)
                if measurement:
                    measurements.append(measurement)
            except Exception as e:
                logger.debug(f"Error measuring latency to {target}: {e}")
                continue
        
        return measurements
    
    @staticmethod
    async def _ping_target(target: str, count: int = 5) -> Optional[Dict[str, Any]]:
        """Ping a target and collect statistics"""
        try:
            # Use ping command (works on both Linux and macOS)
            # -c: count, -W: timeout, -i: interval
            rc, out, _ = await run_exec(
                ["ping", "-c", str(count), "-W", "2", "-i", "0.2", target],
                timeout=count * 2 + 5,
            )
            if rc != 0 or not out:
                return None
            output = out
            
            # Parse ping output
            # Extract packet loss
            packet_loss = 0.0
            loss_match = __import__('re').search(r'(\d+(?:\.\d+)?)%\s+packet\s+loss', output)
            if loss_match:
                packet_loss = float(loss_match.group(1))
            
            # Extract round-trip times
            rtt_times = []
            rtt_match = __import__('re').findall(r'time=([\d.]+)\s*ms', output)
            if rtt_match:
                rtt_times = [float(t) for t in rtt_match]
            
            if not rtt_times:
                return None
            
            # Calculate statistics
            avg_latency = sum(rtt_times) / len(rtt_times)
            min_latency = min(rtt_times)
            max_latency = max(rtt_times)
            
            # Calculate jitter (standard deviation of latency)
            variance = sum((x - avg_latency) ** 2 for x in rtt_times) / len(rtt_times)
            jitter = variance ** 0.5
            
            return {
                "target": target,
                "packet_loss_percent": round(packet_loss, 2),
                "packets_sent": count,
                "packets_received": len(rtt_times),
                "avg_latency_ms": round(avg_latency, 2),
                "min_latency_ms": round(min_latency, 2),
                "max_latency_ms": round(max_latency, 2),
                "jitter_ms": round(jitter, 2),
                "timestamp": __import__('datetime').datetime.utcnow().isoformat()
            }
            
        except FileNotFoundError:
            # ping command not available
            return None
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Error pinging {target}: {e}")
            return None
    
    @staticmethod
    async def measure_tcp_handshake(target_host: str, target_port: int, timeout: float = 2.0) -> Optional[Dict[str, Any]]:
        """
        Measure TCP handshake time
        
        Args:
            target_host: Target hostname or IP
            target_port: Target port
            timeout: Connection timeout in seconds
            
        Returns:
            TCP handshake timing information
        """
        try:
            start_time = time.monotonic()
            try:
                reader, writer = await asyncio.wait_for(asyncio.open_connection(target_host, target_port), timeout=timeout)
                connect_time = (time.monotonic() - start_time) * 1000  # ms
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
                
                return {
                    "target": f"{target_host}:{target_port}",
                    "handshake_time_ms": round(connect_time, 2),
                    "success": True,
                    "timestamp": __import__('datetime').datetime.utcnow().isoformat()
                }
            except Exception as e:
                return {
                    "target": f"{target_host}:{target_port}",
                    "handshake_time_ms": None,
                    "success": False,
                    "error": str(e),
                    "timestamp": __import__('datetime').datetime.utcnow().isoformat()
                }
                
        except Exception as e:
            logger.debug(f"Error measuring TCP handshake to {target_host}:{target_port}: {e}")
            return None

