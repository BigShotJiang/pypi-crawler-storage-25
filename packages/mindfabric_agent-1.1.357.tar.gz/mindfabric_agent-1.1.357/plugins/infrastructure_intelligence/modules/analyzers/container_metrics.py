"""
Container Metrics Module for Infrastructure Intelligence

Collects detailed metrics for Docker and Kubernetes containers:
- Per-container CPU and memory usage
- Network I/O per container
- Block I/O per container
- Resource limits and utilization
"""

import json
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
from utils.logger import logger
from utils.async_subprocess import run_exec


class ContainerMetricsCollector:
    """Collects metrics for containers"""
    
    @staticmethod
    async def collect_docker_metrics() -> List[Dict[str, Any]]:
        """
        Collect metrics for all Docker containers
        
        Returns:
            List of container metrics
        """
        metrics = []
        
        try:
            # Get all running containers
            rc, out, _ = await run_exec(["docker", "ps", "--format", "{{.ID}}"], timeout=10)
            if rc != 0 or not out:
                return metrics
            container_ids = [line.strip() for line in out.split('\n') if line.strip()]
            
            for container_id in container_ids:
                try:
                    container_metric = await ContainerMetricsCollector._get_docker_stats(container_id)
                    if container_metric:
                        metrics.append(container_metric)
                except Exception as e:
                    logger.debug(f"Error getting stats for container {container_id}: {e}")
                    continue
                    
        except FileNotFoundError:
            # Docker not available
            pass
        except Exception as e:
            logger.debug(f"Error collecting Docker metrics: {e}")
        
        return metrics
    
    @staticmethod
    async def _get_docker_stats(container_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a single Docker container"""
        try:
            # Get container stats
            rc, out, _ = await run_exec(
                ["docker", "stats", "--no-stream", "--format", "json", container_id],
                timeout=5,
            )
            if rc != 0 or not out:
                return None
            stats_data = json.loads(out)
            if not stats_data:
                return None
            
            # Parse CPU percentage
            cpu_percent = 0.0
            if "%" in stats_data.get("CPUPerc", "0%"):
                cpu_str = stats_data["CPUPerc"].replace("%", "").strip()
                try:
                    cpu_percent = float(cpu_str)
                except ValueError:
                    pass
            
            # Parse memory
            mem_usage = stats_data.get("MemUsage", "0B / 0B")
            mem_parts = mem_usage.split(" / ")
            mem_used = ContainerMetricsCollector._parse_size(mem_parts[0]) if len(mem_parts) > 0 else 0
            mem_limit = ContainerMetricsCollector._parse_size(mem_parts[1]) if len(mem_parts) > 1 else 0
            mem_percent = (mem_used / mem_limit * 100) if mem_limit > 0 else 0
            
            # Parse network I/O
            net_io = stats_data.get("NetIO", "0B / 0B")
            net_parts = net_io.split(" / ")
            net_in = ContainerMetricsCollector._parse_size(net_parts[0]) if len(net_parts) > 0 else 0
            net_out = ContainerMetricsCollector._parse_size(net_parts[1]) if len(net_parts) > 1 else 0
            
            # Parse block I/O
            block_io = stats_data.get("BlockIO", "0B / 0B")
            block_parts = block_io.split(" / ")
            block_read = ContainerMetricsCollector._parse_size(block_parts[0]) if len(block_parts) > 0 else 0
            block_write = ContainerMetricsCollector._parse_size(block_parts[1]) if len(block_parts) > 1 else 0
            
            return {
                "container_id": container_id[:12],
                "name": stats_data.get("Name", "").lstrip("/"),
                "timestamp": datetime.utcnow().isoformat(),
                "cpu_percent": round(cpu_percent, 2),
                "memory_used_mb": round(mem_used / (1024 * 1024), 2),
                "memory_limit_mb": round(mem_limit / (1024 * 1024), 2),
                "memory_percent": round(mem_percent, 2),
                "network_in_mb": round(net_in / (1024 * 1024), 2),
                "network_out_mb": round(net_out / (1024 * 1024), 2),
                "block_read_mb": round(block_read / (1024 * 1024), 2),
                "block_write_mb": round(block_write / (1024 * 1024), 2),
                "pids": int(stats_data.get("PIDs", "0"))
            }
            
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.debug(f"Error parsing Docker stats for {container_id}: {e}")
            return None
        except Exception as e:
            logger.debug(f"Error getting Docker stats for {container_id}: {e}")
            return None
    
    @staticmethod
    def _parse_size(size_str: str) -> int:
        """Parse size string (e.g., '1.5MiB') to bytes"""
        try:
            size_str = size_str.strip()
            if not size_str:
                return 0
            
            # Remove unit and convert
            multipliers = {
                'B': 1,
                'KB': 1024,
                'MB': 1024 * 1024,
                'GB': 1024 * 1024 * 1024,
                'TB': 1024 * 1024 * 1024 * 1024,
                'KiB': 1024,
                'MiB': 1024 * 1024,
                'GiB': 1024 * 1024 * 1024,
                'TiB': 1024 * 1024 * 1024 * 1024
            }
            
            # Find unit
            unit = None
            number_str = size_str
            for unit_name in sorted(multipliers.keys(), key=len, reverse=True):
                if size_str.upper().endswith(unit_name.upper()):
                    unit = unit_name
                    number_str = size_str[:-len(unit_name)]
                    break
            
            # Parse number
            try:
                number = float(number_str)
            except ValueError:
                return 0
            
            multiplier = multipliers.get(unit, 1) if unit else 1
            return int(number * multiplier)
            
        except Exception:
            return 0
    
    @staticmethod
    async def collect_kubernetes_metrics() -> Dict[str, List[Dict[str, Any]]]:
        """
        Collect metrics for Kubernetes pods using kubectl top
        
        Returns:
            Dictionary with pod and node metrics
        """
        metrics = {
            "pods": [],
            "nodes": []
        }
        
        try:
            # Check if kubectl is available
            rc, _, _ = await run_exec(["kubectl", "version", "--client", "--short"], timeout=3)
            if rc != 0:
                return metrics
            
            # Get pod metrics
            try:
                rc2, out2, _ = await run_exec(["kubectl", "top", "pods", "--all-namespaces"], timeout=10)
                if rc2 == 0 and out2:
                    lines = out2.strip().split('\n')[1:]  # Skip header
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 4:
                            metrics["pods"].append({
                                "namespace": parts[0],
                                "pod_name": parts[1],
                                "cpu_millicores": parts[2],
                                "memory_mb": parts[3],
                                "timestamp": datetime.utcnow().isoformat()
                            })
            except Exception as e:
                logger.debug(f"Error getting Kubernetes pod metrics: {e}")
            
            # Get node metrics
            try:
                rc3, out3, _ = await run_exec(["kubectl", "top", "nodes"], timeout=10)
                if rc3 == 0 and out3:
                    lines = out3.strip().split('\n')[1:]  # Skip header
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 3:
                            metrics["nodes"].append({
                                "node_name": parts[0],
                                "cpu_millicores": parts[1],
                                "memory_mb": parts[2],
                                "timestamp": datetime.utcnow().isoformat()
                            })
            except Exception as e:
                logger.debug(f"Error getting Kubernetes node metrics: {e}")
                
        except FileNotFoundError:
            # kubectl not available
            pass
        except Exception as e:
            logger.debug(f"Error collecting Kubernetes metrics: {e}")
        
        return metrics

