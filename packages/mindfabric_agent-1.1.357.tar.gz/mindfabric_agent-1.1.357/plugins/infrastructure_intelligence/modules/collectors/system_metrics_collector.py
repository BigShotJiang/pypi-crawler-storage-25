"""
System metrics collection
"""
import datetime
import time
from typing import Dict, Any, Optional

try:
    import psutil
except ImportError:
    psutil = None

from utils.logger import logger
from ..analyzers import (
    ContainerMetricsCollector, NetworkLatencyMeasurer, ProcessAnalyzer,
    KernelAnalyzer, AdvancedMemoryAnalyzer, ApplicationProfiler
)
from .proc_metrics_collector import ProcMetricsCollector


class SystemMetricsCollector:
    """Collects system metrics using psutil and analyzers"""
    
    @staticmethod
    async def collect_metrics(mode: str = "full") -> Optional[Dict[str, Any]]:
        """Collect current system metrics"""
        if not psutil:
            return None
        
        try:
            timestamp = datetime.datetime.utcnow().isoformat()
            # Measure I/O rates over the same window we already use for CPU sampling.
            # psutil net/disk IO counters are cumulative since boot, so we must compute deltas.
            t0 = time.monotonic()
            net0 = psutil.net_io_counters()
            diskio0 = psutil.disk_io_counters()

            # CPU usage (blocks ~1s)
            cpu_percent = psutil.cpu_percent(interval=1)

            t1 = time.monotonic()
            net1 = psutil.net_io_counters()
            diskio1 = psutil.disk_io_counters()
            dt = max(t1 - t0, 0.001)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage("/")
            storage_percent = disk.percent
            
            # Network I/O rate (Mbps)
            # NOTE: UI expects Mbps for network anomalies.
            bytes_recv = max(0, (net1.bytes_recv - net0.bytes_recv)) if (net0 and net1) else 0
            bytes_sent = max(0, (net1.bytes_sent - net0.bytes_sent)) if (net0 and net1) else 0
            network_in = (bytes_recv * 8) / 1_000_000 / dt  # Mbps
            network_out = (bytes_sent * 8) / 1_000_000 / dt  # Mbps

            # Disk I/O rate (MB/s)
            read_bytes = 0
            write_bytes = 0
            if diskio0 and diskio1:
                read_bytes = max(0, (diskio1.read_bytes - diskio0.read_bytes))
                write_bytes = max(0, (diskio1.write_bytes - diskio0.write_bytes))
            disk_read = read_bytes / (1024 * 1024) / dt  # MB/s
            disk_write = write_bytes / (1024 * 1024) / dt  # MB/s
            
            # Enhanced metrics from /proc
            proc_metrics = await ProcMetricsCollector.collect_proc_metrics()
            
            base_metrics = {
                "timestamp": timestamp,
                "cpu": round(cpu_percent, 2),
                "memory": round(memory_percent, 2),
                "storage": round(storage_percent, 2),
                "network_in": round(network_in, 2),
                "network_out": round(network_out, 2),
                "disk_read": round(disk_read, 2),
                "disk_write": round(disk_write, 2)
            }
            
            # Merge /proc metrics
            if proc_metrics:
                base_metrics.update(proc_metrics)
            
            # Collect container metrics (if available)
            container_metrics = await ContainerMetricsCollector.collect_docker_metrics()
            if container_metrics:
                base_metrics["container_metrics"] = container_metrics
            
            # Measure network latency
            latency_measurements = await NetworkLatencyMeasurer.measure_latency(count=3)
            if latency_measurements:
                base_metrics["network_latency"] = latency_measurements
            
            # Advanced process analysis (full mode only)
            if mode == "full":
                process_tree = await ProcessAnalyzer.analyze_process_tree()
                if process_tree:
                    base_metrics["process_tree"] = process_tree
                
                ipc_analysis = await ProcessAnalyzer.analyze_ipc()
                if ipc_analysis:
                    base_metrics["ipc_connections"] = ipc_analysis
                
                resource_contention = await ProcessAnalyzer.detect_resource_contention()
                if resource_contention:
                    base_metrics["resource_contention"] = resource_contention
                
                # Kernel-level analysis
                kernel_modules = await KernelAnalyzer.analyze_kernel_modules()
                if kernel_modules:
                    base_metrics["kernel_modules"] = kernel_modules
                
                interrupts = await KernelAnalyzer.analyze_interrupts()
                if interrupts:
                    base_metrics["interrupts"] = interrupts
                
                io_schedulers = await KernelAnalyzer.analyze_io_schedulers()
                if io_schedulers:
                    base_metrics["io_schedulers"] = io_schedulers
                
                # Advanced memory analysis
                memory_leaks = await AdvancedMemoryAnalyzer.detect_memory_leaks()
                if memory_leaks.get("leaks_detected"):
                    base_metrics["memory_leaks"] = memory_leaks
                
                memory_corruption = await AdvancedMemoryAnalyzer.detect_memory_corruption()
                if memory_corruption:
                    base_metrics["memory_corruption"] = memory_corruption
                
                memory_encryption = await AdvancedMemoryAnalyzer.analyze_memory_encryption()
                if memory_encryption:
                    base_metrics["memory_encryption"] = memory_encryption
                
                # Application profiling for top processes
                if psutil:
                    try:
                        top_processes = sorted(
                            psutil.process_iter(['pid', 'cpu_percent', 'memory_percent']),
                            key=lambda x: x.info.get('cpu_percent', 0),
                            reverse=True
                        )[:5]
                        
                        for proc_info in top_processes:
                            try:
                                pid = proc_info.info['pid']
                                # CPU profiling
                                cpu_profile = await ApplicationProfiler.profile_process_cpu(pid, duration=3)
                                if cpu_profile:
                                    base_metrics.setdefault("cpu_profiles", {})[str(pid)] = cpu_profile
                                
                                # Memory profiling
                                mem_profile = await ApplicationProfiler.profile_process_memory(pid)
                                if mem_profile:
                                    base_metrics.setdefault("memory_profiles", {})[str(pid)] = mem_profile
                                    
                            except Exception:
                                continue
                    except Exception:
                        pass
            
            return base_metrics
        except Exception as e:
            logger.exception(f"Error collecting metrics: {e}")
            return None

