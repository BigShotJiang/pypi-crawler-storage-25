"""
Historical metrics collection
"""
from datetime import datetime, timedelta
import random
from collections import deque
from typing import List, Dict, Any


class HistoricalMetricsCollector:
    """Collects historical metrics for baseline calculation"""
    
    @staticmethod
    async def collect_historical_metrics(metric_history: deque) -> List[Dict[str, Any]]:
        """Collect historical metrics (simulated for now)"""
        # In real implementation, this would read from time-series database
        # For now, we generate simulated data based on current metrics
        metrics = []
        
        if not metric_history:
            return metrics
        
        # Use current metrics as baseline
        current = metric_history[-1] if metric_history else None
        if not current:
            return metrics
        
        # Generate historical data points (last 24 hours, hourly intervals)
        base_time = datetime.utcnow() - timedelta(hours=24)
        
        for i in range(24):
            timestamp = (base_time + timedelta(hours=i)).isoformat()
            
            # Generate realistic variations
            variation = random.uniform(-10, 10)
            
            metric = {
                "timestamp": timestamp,
                "cpu": max(0, min(100, current["cpu"] + variation)),
                "memory": max(0, min(100, current["memory"] + variation * 0.5)),
                "storage": max(0, min(100, current["storage"] + i * 0.1)),  # Gradual growth
                "network_in": max(0, current["network_in"] + random.uniform(-20, 20)),
                "network_out": max(0, current["network_out"] + random.uniform(-20, 20)),
                "disk_read": max(0, current["disk_read"] + random.uniform(-10, 10)),
                "disk_write": max(0, current["disk_write"] + random.uniform(-10, 10))
            }
            
            metrics.append(metric)
        
        return metrics

