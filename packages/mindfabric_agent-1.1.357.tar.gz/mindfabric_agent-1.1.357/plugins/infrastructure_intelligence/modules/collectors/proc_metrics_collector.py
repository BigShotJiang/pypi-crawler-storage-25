"""
/proc filesystem metrics collection
"""
from pathlib import Path
from typing import Dict, Any, Optional

from utils.logger import logger


class ProcMetricsCollector:
    """Collects enhanced metrics from /proc filesystem"""
    
    @staticmethod
    async def collect_proc_metrics() -> Optional[Dict[str, Any]]:
        """Collect enhanced metrics from /proc filesystem"""
        metrics = {}
        
        try:
            # Load average from /proc/loadavg
            loadavg_file = Path("/proc/loadavg")
            if loadavg_file.exists():
                try:
                    with open(loadavg_file, 'r') as f:
                        load_data = f.read().split()
                        if len(load_data) >= 3:
                            metrics["load_1min"] = float(load_data[0])
                            metrics["load_5min"] = float(load_data[1])
                            metrics["load_15min"] = float(load_data[2])
                except (IOError, ValueError):
                    pass
            
            # Detailed memory info from /proc/meminfo
            meminfo_file = Path("/proc/meminfo")
            if meminfo_file.exists():
                try:
                    with open(meminfo_file, 'r') as f:
                        mem_data = {}
                        for line in f:
                            if ':' in line:
                                key, value = line.split(':', 1)
                                value = value.strip().replace(' kB', '').replace(' kB', '')
                                try:
                                    mem_data[key.strip()] = int(value)
                                except ValueError:
                                    pass
                        
                        # Calculate additional metrics
                        if 'MemTotal' in mem_data and 'MemAvailable' in mem_data:
                            mem_available_percent = (mem_data['MemAvailable'] / mem_data['MemTotal']) * 100
                            metrics["memory_available_percent"] = round(mem_available_percent, 2)
                        
                        if 'SwapTotal' in mem_data and 'SwapFree' in mem_data:
                            swap_total = mem_data['SwapTotal']
                            if swap_total > 0:
                                swap_used = swap_total - mem_data['SwapFree']
                                swap_percent = (swap_used / swap_total) * 100
                                metrics["swap_percent"] = round(swap_percent, 2)
                        
                        if 'Dirty' in mem_data:
                            metrics["dirty_pages_kb"] = mem_data['Dirty']
                except (IOError, ValueError):
                    pass
            
            # Disk I/O stats from /proc/diskstats
            diskstats_file = Path("/proc/diskstats")
            if diskstats_file.exists():
                try:
                    with open(diskstats_file, 'r') as f:
                        total_read_ops = 0
                        total_write_ops = 0
                        total_read_time = 0
                        total_write_time = 0
                        
                        for line in f:
                            parts = line.split()
                            if len(parts) >= 14:
                                # Read operations (4), Write operations (8)
                                # Read time ms (7), Write time ms (11)
                                read_ops = int(parts[3])
                                write_ops = int(parts[7])
                                read_time = int(parts[6])
                                write_time = int(parts[10])
                                
                                total_read_ops += read_ops
                                total_write_ops += write_ops
                                total_read_time += read_time
                                total_write_time += write_time
                        
                        metrics["disk_read_operations"] = total_read_ops
                        metrics["disk_write_operations"] = total_write_ops
                        metrics["disk_read_time_ms"] = total_read_time
                        metrics["disk_write_time_ms"] = total_write_time
                except (IOError, ValueError):
                    pass
            
            # Network socket stats from /proc/net/sockstat
            sockstat_file = Path("/proc/net/sockstat")
            if sockstat_file.exists():
                try:
                    with open(sockstat_file, 'r') as f:
                        for line in f:
                            if line.startswith('TCP:'):
                                parts = line.split()
                                if 'inuse' in parts:
                                    idx = parts.index('inuse')
                                    if idx + 1 < len(parts):
                                        metrics["tcp_sockets_inuse"] = int(parts[idx + 1])
                            elif line.startswith('UDP:'):
                                parts = line.split()
                                if 'inuse' in parts:
                                    idx = parts.index('inuse')
                                    if idx + 1 < len(parts):
                                        metrics["udp_sockets_inuse"] = int(parts[idx + 1])
                except (IOError, ValueError):
                    pass
            
            # VM stats from /proc/vmstat
            vmstat_file = Path("/proc/vmstat")
            if vmstat_file.exists():
                try:
                    with open(vmstat_file, 'r') as f:
                        for line in f:
                            if ' ' in line:
                                key, value = line.split(None, 1)
                                try:
                                    if key == 'pgpgin':
                                        metrics["pages_paged_in"] = int(value)
                                    elif key == 'pgpgout':
                                        metrics["pages_paged_out"] = int(value)
                                    elif key == 'pswpin':
                                        metrics["swap_pages_in"] = int(value)
                                    elif key == 'pswpout':
                                        metrics["swap_pages_out"] = int(value)
                                    elif key == 'pgfault':
                                        metrics["page_faults_minor"] = int(value)
                                    elif key == 'pgmajfault':
                                        metrics["page_faults_major"] = int(value)
                                except ValueError:
                                    pass
                except (IOError, ValueError):
                    pass
                    
        except Exception as e:
            logger.debug(f"Error collecting /proc metrics: {e}")
        
        return metrics if metrics else None

