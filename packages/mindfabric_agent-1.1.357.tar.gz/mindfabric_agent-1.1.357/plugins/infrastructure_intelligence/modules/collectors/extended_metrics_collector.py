"""
Extended Metrics Collector Module

Collects extended system metrics for anomaly detection:
- CPU: saturation, thermal, pressure (PSI)
- Memory: pressure, leak detection, OOM prediction
- Disk: saturation, SMART health, filesystem metrics

This module provides deeper insights into system health
beyond basic CPU/memory/disk utilization.
"""

import os
import re
import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)

from utils.async_subprocess import run_exec


class MetricSeverity(str, Enum):
    """Metric severity levels."""
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"
    OK = "ok"


@dataclass
class CPUExtendedMetrics:
    """Extended CPU metrics."""
    # Saturation metrics
    run_queue_length: float = 0.0
    load_average_1m: float = 0.0
    load_average_5m: float = 0.0
    load_average_15m: float = 0.0
    
    # Per-core metrics
    per_core_utilization: Dict[int, float] = field(default_factory=dict)
    core_variance: float = 0.0
    
    # Virtualization metrics
    steal_time_percent: float = 0.0
    iowait_percent: float = 0.0
    
    # Thermal metrics
    temperatures: Dict[str, float] = field(default_factory=dict)
    thermal_throttling: bool = False
    
    # Pressure metrics (PSI - Linux 4.20+)
    cpu_pressure_some: float = 0.0
    cpu_pressure_full: float = 0.0
    
    # Context switches
    context_switches_per_sec: float = 0.0
    interrupts_per_sec: float = 0.0


@dataclass
class MemoryExtendedMetrics:
    """Extended memory metrics."""
    # Basic
    total_bytes: int = 0
    available_bytes: int = 0
    used_percent: float = 0.0
    
    # Pressure metrics
    page_faults_per_sec: float = 0.0
    major_faults_per_sec: float = 0.0
    page_scan_rate: float = 0.0
    reclaim_pressure: float = 0.0
    
    # NUMA metrics
    numa_imbalance: float = 0.0
    numa_hit_ratio: float = 0.0
    
    # Swap metrics
    swap_total_bytes: int = 0
    swap_used_bytes: int = 0
    swap_used_percent: float = 0.0
    swap_in_rate: float = 0.0
    swap_out_rate: float = 0.0
    
    # OOM metrics
    oom_score_adj: Dict[int, int] = field(default_factory=dict)  # pid -> score
    oom_kill_count: int = 0
    
    # Pressure metrics (PSI)
    memory_pressure_some: float = 0.0
    memory_pressure_full: float = 0.0
    
    # Slab metrics
    slab_reclaimable_bytes: int = 0
    slab_unreclaimable_bytes: int = 0


@dataclass
class DiskExtendedMetrics:
    """Extended disk metrics."""
    device: str = ""
    
    # Saturation
    io_utilization_percent: float = 0.0
    queue_depth: float = 0.0
    await_ms: float = 0.0
    svctm_ms: float = 0.0
    
    # Throughput
    read_bytes_per_sec: float = 0.0
    write_bytes_per_sec: float = 0.0
    read_iops: float = 0.0
    write_iops: float = 0.0
    
    # Latency percentiles
    read_latency_p50_ms: float = 0.0
    read_latency_p95_ms: float = 0.0
    read_latency_p99_ms: float = 0.0
    write_latency_p50_ms: float = 0.0
    write_latency_p95_ms: float = 0.0
    write_latency_p99_ms: float = 0.0
    
    # SMART metrics
    smart_healthy: bool = True
    smart_temperature: float = 0.0
    smart_reallocated_sectors: int = 0
    smart_pending_sectors: int = 0
    smart_power_on_hours: int = 0
    smart_write_error_rate: float = 0.0
    
    # SSD-specific
    wear_leveling_count: int = 0
    total_bytes_written: int = 0


@dataclass
class FilesystemMetrics:
    """Filesystem metrics."""
    mount_point: str = ""
    filesystem_type: str = ""
    
    # Space
    total_bytes: int = 0
    used_bytes: int = 0
    available_bytes: int = 0
    used_percent: float = 0.0
    
    # Inodes
    inodes_total: int = 0
    inodes_used: int = 0
    inodes_free: int = 0
    inodes_used_percent: float = 0.0
    
    # File descriptors
    open_files: int = 0


@dataclass
class ExtendedMetricsReport:
    """Complete extended metrics report."""
    cpu: CPUExtendedMetrics = field(default_factory=CPUExtendedMetrics)
    memory: MemoryExtendedMetrics = field(default_factory=MemoryExtendedMetrics)
    disks: List[DiskExtendedMetrics] = field(default_factory=list)
    filesystems: List[FilesystemMetrics] = field(default_factory=list)
    anomalies: List[Dict[str, Any]] = field(default_factory=list)


class ExtendedMetricsCollector:
    """Service for collecting extended system metrics."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self._is_linux = os.name != 'nt'
        self._prev_cpu_stats = None
        self._prev_disk_stats = {}
        self._prev_vmstat = None
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read a file and return contents."""
        try:
            with open(path, 'r') as f:
                return f.read()
        except Exception:
            return None
    
    async def _run_command(self, cmd: List[str], timeout: int = 10) -> Optional[str]:
        """Run a command without blocking the agent event loop and return stdout."""
        try:
            rc, out, _ = await run_exec(cmd, timeout=timeout)
            if rc == 0 and out is not None:
                return out
            return None
        except (FileNotFoundError, asyncio.TimeoutError):
            return None
        except Exception:
            return None
    
    async def collect_cpu_extended(self) -> CPUExtendedMetrics:
        """
        Collect extended CPU metrics.
        
        Returns:
            CPUExtendedMetrics
        """
        metrics = CPUExtendedMetrics()
        
        if not self._is_linux:
            return metrics
        
        # Load average
        loadavg = self._read_file("/proc/loadavg")
        if loadavg:
            parts = loadavg.split()
            if len(parts) >= 3:
                metrics.load_average_1m = float(parts[0])
                metrics.load_average_5m = float(parts[1])
                metrics.load_average_15m = float(parts[2])
            if len(parts) >= 4:
                # Run queue length (running/total)
                run_parts = parts[3].split('/')
                if len(run_parts) >= 1:
                    metrics.run_queue_length = float(run_parts[0])
        
        # Per-CPU stats from /proc/stat
        stat = self._read_file("/proc/stat")
        if stat:
            for line in stat.split('\n'):
                if line.startswith('cpu') and line[3:4].isdigit():
                    parts = line.split()
                    cpu_id = int(parts[0][3:])
                    
                    # Calculate utilization (simplified)
                    user = int(parts[1])
                    nice = int(parts[2])
                    system = int(parts[3])
                    idle = int(parts[4])
                    iowait = int(parts[5]) if len(parts) > 5 else 0
                    steal = int(parts[8]) if len(parts) > 8 else 0
                    
                    total = user + nice + system + idle + iowait + steal
                    busy = total - idle - iowait
                    
                    if total > 0:
                        metrics.per_core_utilization[cpu_id] = (busy / total) * 100
                
                elif line.startswith('cpu '):
                    parts = line.split()
                    if len(parts) > 8:
                        total = sum(int(p) for p in parts[1:])
                        iowait = int(parts[5]) if len(parts) > 5 else 0
                        steal = int(parts[8]) if len(parts) > 8 else 0
                        
                        if total > 0:
                            metrics.iowait_percent = (iowait / total) * 100
                            metrics.steal_time_percent = (steal / total) * 100
                
                elif line.startswith('ctxt'):
                    metrics.context_switches_per_sec = float(line.split()[1])
                
                elif line.startswith('intr'):
                    parts = line.split()
                    if len(parts) > 1:
                        metrics.interrupts_per_sec = float(parts[1])
        
        # Calculate core variance
        if metrics.per_core_utilization:
            values = list(metrics.per_core_utilization.values())
            mean = sum(values) / len(values)
            variance = sum((x - mean) ** 2 for x in values) / len(values)
            metrics.core_variance = variance ** 0.5  # std dev
        
        # Thermal metrics
        thermal_paths = [
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/hwmon/hwmon0/temp1_input",
            "/sys/devices/platform/coretemp.0/hwmon/hwmon*/temp*_input",
        ]
        
        for pattern in thermal_paths:
            import glob
            for path in glob.glob(pattern):
                temp = self._read_file(path)
                if temp:
                    try:
                        temp_c = float(temp.strip()) / 1000.0
                        zone_name = os.path.basename(os.path.dirname(path))
                        metrics.temperatures[zone_name] = temp_c
                        
                        if temp_c > 90:
                            metrics.thermal_throttling = True
                    except ValueError:
                        pass
        
        # PSI (Pressure Stall Information) - Linux 4.20+
        psi_cpu = self._read_file("/proc/pressure/cpu")
        if psi_cpu:
            for line in psi_cpu.split('\n'):
                if line.startswith('some'):
                    match = re.search(r'avg10=(\d+\.\d+)', line)
                    if match:
                        metrics.cpu_pressure_some = float(match.group(1))
                elif line.startswith('full'):
                    match = re.search(r'avg10=(\d+\.\d+)', line)
                    if match:
                        metrics.cpu_pressure_full = float(match.group(1))
        
        return metrics
    
    async def collect_memory_extended(self) -> MemoryExtendedMetrics:
        """
        Collect extended memory metrics.
        
        Returns:
            MemoryExtendedMetrics
        """
        metrics = MemoryExtendedMetrics()
        
        if not self._is_linux:
            return metrics
        
        # /proc/meminfo
        meminfo = self._read_file("/proc/meminfo")
        if meminfo:
            mem_dict = {}
            for line in meminfo.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    value = value.strip().replace(' kB', '')
                    try:
                        mem_dict[key.strip()] = int(value) * 1024  # Convert to bytes
                    except ValueError:
                        pass
            
            metrics.total_bytes = mem_dict.get('MemTotal', 0)
            metrics.available_bytes = mem_dict.get('MemAvailable', 0)
            
            if metrics.total_bytes > 0:
                used = metrics.total_bytes - metrics.available_bytes
                metrics.used_percent = (used / metrics.total_bytes) * 100
            
            metrics.swap_total_bytes = mem_dict.get('SwapTotal', 0)
            metrics.swap_used_bytes = metrics.swap_total_bytes - mem_dict.get('SwapFree', 0)
            
            if metrics.swap_total_bytes > 0:
                metrics.swap_used_percent = (metrics.swap_used_bytes / metrics.swap_total_bytes) * 100
            
            metrics.slab_reclaimable_bytes = mem_dict.get('SReclaimable', 0)
            metrics.slab_unreclaimable_bytes = mem_dict.get('SUnreclaim', 0)
        
        # /proc/vmstat for page faults
        vmstat = self._read_file("/proc/vmstat")
        if vmstat:
            for line in vmstat.split('\n'):
                parts = line.split()
                if len(parts) == 2:
                    key, value = parts
                    if key == 'pgfault':
                        metrics.page_faults_per_sec = float(value)
                    elif key == 'pgmajfault':
                        metrics.major_faults_per_sec = float(value)
                    elif key == 'pgsteal_direct':
                        metrics.reclaim_pressure = float(value)
                    elif key == 'pswpin':
                        metrics.swap_in_rate = float(value)
                    elif key == 'pswpout':
                        metrics.swap_out_rate = float(value)
        
        # PSI memory
        psi_mem = self._read_file("/proc/pressure/memory")
        if psi_mem:
            for line in psi_mem.split('\n'):
                if line.startswith('some'):
                    match = re.search(r'avg10=(\d+\.\d+)', line)
                    if match:
                        metrics.memory_pressure_some = float(match.group(1))
                elif line.startswith('full'):
                    match = re.search(r'avg10=(\d+\.\d+)', line)
                    if match:
                        metrics.memory_pressure_full = float(match.group(1))
        
        # NUMA stats
        numa_stat = self._read_file("/proc/vmstat")
        if numa_stat:
            numa_hit = 0
            numa_miss = 0
            for line in numa_stat.split('\n'):
                if line.startswith('numa_hit'):
                    numa_hit = int(line.split()[1])
                elif line.startswith('numa_miss'):
                    numa_miss = int(line.split()[1])
            
            total_numa = numa_hit + numa_miss
            if total_numa > 0:
                metrics.numa_hit_ratio = numa_hit / total_numa
                metrics.numa_imbalance = numa_miss / total_numa
        
        # OOM kill count from dmesg (if accessible)
        dmesg = await self._run_command(["dmesg"])
        if dmesg:
            metrics.oom_kill_count = dmesg.count("Out of memory: Kill")
        
        return metrics
    
    async def collect_disk_extended(self) -> List[DiskExtendedMetrics]:
        """
        Collect extended disk metrics.
        
        Returns:
            List of DiskExtendedMetrics
        """
        disks = []
        
        if not self._is_linux:
            return disks
        
        # /proc/diskstats
        diskstats = self._read_file("/proc/diskstats")
        if diskstats:
            for line in diskstats.split('\n'):
                parts = line.split()
                if len(parts) < 14:
                    continue
                
                device = parts[2]
                
                # Skip partitions (usually end with numbers) and loop devices
                if device.startswith('loop') or device.startswith('ram'):
                    continue
                if re.match(r'.*\d$', device) and not device.startswith('nvme'):
                    continue
                
                metrics = DiskExtendedMetrics(device=device)
                
                # Parse diskstats
                # Field 4: reads completed
                # Field 5: reads merged
                # Field 6: sectors read
                # Field 7: time reading (ms)
                # Field 8: writes completed
                # Field 9: writes merged
                # Field 10: sectors written
                # Field 11: time writing (ms)
                # Field 12: IOs in progress
                # Field 13: time doing IOs (ms)
                # Field 14: weighted time doing IOs (ms)
                
                reads = int(parts[3])
                sectors_read = int(parts[5])
                read_time = int(parts[6])
                writes = int(parts[7])
                sectors_written = int(parts[9])
                write_time = int(parts[10])
                io_in_progress = int(parts[11])
                io_time = int(parts[12])
                weighted_time = int(parts[13])
                
                metrics.read_iops = reads
                metrics.write_iops = writes
                metrics.read_bytes_per_sec = sectors_read * 512
                metrics.write_bytes_per_sec = sectors_written * 512
                metrics.queue_depth = io_in_progress
                
                # Calculate await (average wait time)
                total_ios = reads + writes
                if total_ios > 0:
                    metrics.await_ms = (read_time + write_time) / total_ios
                
                # Utilization (simplified - % of time doing I/O)
                # This is a snapshot, not a rate
                metrics.io_utilization_percent = min(io_time / 10, 100)  # Rough estimate
                
                disks.append(metrics)
        
        # SMART data
        for disk in disks:
            smart_output = await self._run_command(["smartctl", "-A", f"/dev/{disk.device}"])
            if smart_output:
                disk.smart_healthy = "PASSED" in smart_output or "OK" in smart_output
                
                for line in smart_output.split('\n'):
                    parts = line.split()
                    if len(parts) < 10:
                        continue
                    
                    attr_name = parts[1] if len(parts) > 1 else ""
                    raw_value = parts[9] if len(parts) > 9 else "0"
                    
                    try:
                        if "Temperature" in attr_name:
                            disk.smart_temperature = float(raw_value)
                        elif "Reallocated" in attr_name:
                            disk.smart_reallocated_sectors = int(raw_value)
                        elif "Pending" in attr_name:
                            disk.smart_pending_sectors = int(raw_value)
                        elif "Power_On_Hours" in attr_name:
                            disk.smart_power_on_hours = int(raw_value)
                        elif "Wear_Leveling" in attr_name:
                            disk.wear_leveling_count = int(raw_value)
                    except ValueError:
                        pass
        
        return disks
    
    async def collect_filesystem_metrics(self) -> List[FilesystemMetrics]:
        """
        Collect filesystem metrics.
        
        Returns:
            List of FilesystemMetrics
        """
        filesystems = []
        
        if not self._is_linux:
            return filesystems
        
        # df output
        df_output = await self._run_command(["df", "-B1", "-T"])
        if df_output:
            lines = df_output.strip().split('\n')[1:]  # Skip header
            for line in lines:
                parts = line.split()
                if len(parts) < 7:
                    continue
                
                device = parts[0]
                fstype = parts[1]
                total = int(parts[2])
                used = int(parts[3])
                avail = int(parts[4])
                mount = parts[6]
                
                # Skip virtual filesystems
                if fstype in ['tmpfs', 'devtmpfs', 'squashfs', 'overlay']:
                    continue
                
                metrics = FilesystemMetrics(
                    mount_point=mount,
                    filesystem_type=fstype,
                    total_bytes=total,
                    used_bytes=used,
                    available_bytes=avail,
                )
                
                if total > 0:
                    metrics.used_percent = (used / total) * 100
                
                filesystems.append(metrics)
        
        # Inode information
        df_inodes = await self._run_command(["df", "-i"])
        if df_inodes:
            lines = df_inodes.strip().split('\n')[1:]
            for line in lines:
                parts = line.split()
                if len(parts) < 6:
                    continue
                
                mount = parts[5]
                
                for fs in filesystems:
                    if fs.mount_point == mount:
                        try:
                            fs.inodes_total = int(parts[1])
                            fs.inodes_used = int(parts[2])
                            fs.inodes_free = int(parts[3])
                            
                            if fs.inodes_total > 0:
                                fs.inodes_used_percent = (fs.inodes_used / fs.inodes_total) * 100
                        except ValueError:
                            pass
                        break
        
        # Open files count
        lsof_output = await self._run_command(["lsof", "-Fn"])
        if lsof_output:
            for fs in filesystems:
                count = lsof_output.count(fs.mount_point)
                fs.open_files = count
        
        return filesystems
    
    async def detect_anomalies(
        self,
        cpu: CPUExtendedMetrics,
        memory: MemoryExtendedMetrics,
        disks: List[DiskExtendedMetrics],
        filesystems: List[FilesystemMetrics],
    ) -> List[Dict[str, Any]]:
        """
        Detect anomalies in collected metrics.
        
        Returns:
            List of anomaly dictionaries
        """
        anomalies = []
        
        # CPU anomalies
        if cpu.load_average_1m > os.cpu_count() * 2:
            anomalies.append({
                "type": "cpu_saturation",
                "severity": MetricSeverity.WARNING.value,
                "message": f"High load average: {cpu.load_average_1m:.2f}",
                "metric": "load_average_1m",
                "value": cpu.load_average_1m,
            })
        
        if cpu.steal_time_percent > 10:
            anomalies.append({
                "type": "cpu_steal",
                "severity": MetricSeverity.WARNING.value,
                "message": f"High CPU steal time: {cpu.steal_time_percent:.1f}%",
                "metric": "steal_time_percent",
                "value": cpu.steal_time_percent,
            })
        
        if cpu.thermal_throttling:
            anomalies.append({
                "type": "thermal_throttling",
                "severity": MetricSeverity.CRITICAL.value,
                "message": "CPU thermal throttling detected",
                "metric": "thermal_throttling",
                "value": True,
            })
        
        if cpu.cpu_pressure_full > 20:
            anomalies.append({
                "type": "cpu_pressure",
                "severity": MetricSeverity.WARNING.value,
                "message": f"High CPU pressure: {cpu.cpu_pressure_full:.1f}%",
                "metric": "cpu_pressure_full",
                "value": cpu.cpu_pressure_full,
            })
        
        # Memory anomalies
        if memory.used_percent > 90:
            anomalies.append({
                "type": "memory_high",
                "severity": MetricSeverity.CRITICAL.value,
                "message": f"High memory usage: {memory.used_percent:.1f}%",
                "metric": "used_percent",
                "value": memory.used_percent,
            })
        
        if memory.swap_used_percent > 50:
            anomalies.append({
                "type": "swap_high",
                "severity": MetricSeverity.WARNING.value,
                "message": f"High swap usage: {memory.swap_used_percent:.1f}%",
                "metric": "swap_used_percent",
                "value": memory.swap_used_percent,
            })
        
        if memory.memory_pressure_full > 10:
            anomalies.append({
                "type": "memory_pressure",
                "severity": MetricSeverity.WARNING.value,
                "message": f"High memory pressure: {memory.memory_pressure_full:.1f}%",
                "metric": "memory_pressure_full",
                "value": memory.memory_pressure_full,
            })
        
        if memory.oom_kill_count > 0:
            anomalies.append({
                "type": "oom_kills",
                "severity": MetricSeverity.CRITICAL.value,
                "message": f"OOM kills detected: {memory.oom_kill_count}",
                "metric": "oom_kill_count",
                "value": memory.oom_kill_count,
            })
        
        # Disk anomalies
        for disk in disks:
            if disk.io_utilization_percent > 80:
                anomalies.append({
                    "type": "disk_saturation",
                    "severity": MetricSeverity.WARNING.value,
                    "message": f"High disk I/O on {disk.device}: {disk.io_utilization_percent:.1f}%",
                    "metric": "io_utilization_percent",
                    "device": disk.device,
                    "value": disk.io_utilization_percent,
                })
            
            if disk.await_ms > 100:
                anomalies.append({
                    "type": "disk_latency",
                    "severity": MetricSeverity.WARNING.value,
                    "message": f"High disk latency on {disk.device}: {disk.await_ms:.1f}ms",
                    "metric": "await_ms",
                    "device": disk.device,
                    "value": disk.await_ms,
                })
            
            if not disk.smart_healthy:
                anomalies.append({
                    "type": "disk_unhealthy",
                    "severity": MetricSeverity.CRITICAL.value,
                    "message": f"SMART health check failed for {disk.device}",
                    "metric": "smart_healthy",
                    "device": disk.device,
                    "value": False,
                })
            
            if disk.smart_reallocated_sectors > 0:
                anomalies.append({
                    "type": "disk_reallocated",
                    "severity": MetricSeverity.WARNING.value,
                    "message": f"Reallocated sectors on {disk.device}: {disk.smart_reallocated_sectors}",
                    "metric": "smart_reallocated_sectors",
                    "device": disk.device,
                    "value": disk.smart_reallocated_sectors,
                })
        
        # Filesystem anomalies
        for fs in filesystems:
            if fs.used_percent > 90:
                anomalies.append({
                    "type": "filesystem_full",
                    "severity": MetricSeverity.CRITICAL.value,
                    "message": f"Filesystem {fs.mount_point} is {fs.used_percent:.1f}% full",
                    "metric": "used_percent",
                    "mount_point": fs.mount_point,
                    "value": fs.used_percent,
                })
            
            if fs.inodes_used_percent > 90:
                anomalies.append({
                    "type": "inodes_exhausted",
                    "severity": MetricSeverity.WARNING.value,
                    "message": f"Inodes on {fs.mount_point}: {fs.inodes_used_percent:.1f}% used",
                    "metric": "inodes_used_percent",
                    "mount_point": fs.mount_point,
                    "value": fs.inodes_used_percent,
                })
        
        return anomalies
    
    async def collect_all_metrics(self) -> ExtendedMetricsReport:
        """
        Collect all extended metrics.
        
        Returns:
            ExtendedMetricsReport
        """
        cpu = await self.collect_cpu_extended()
        memory = await self.collect_memory_extended()
        disks = await self.collect_disk_extended()
        filesystems = await self.collect_filesystem_metrics()
        
        anomalies = await self.detect_anomalies(cpu, memory, disks, filesystems)
        
        return ExtendedMetricsReport(
            cpu=cpu,
            memory=memory,
            disks=disks,
            filesystems=filesystems,
            anomalies=anomalies,
        )

