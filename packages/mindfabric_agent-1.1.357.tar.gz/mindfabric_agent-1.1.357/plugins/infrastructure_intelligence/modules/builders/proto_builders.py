"""
Builders for converting between dict and proto dataclass formats
"""
from typing import Dict, Any
from ...proto import (
    Anomaly, MetricData, ServiceCall, 
    ProcessInfo, NetworkDetails, DiskDetails, CpuDetails, MemoryDetails
)


def dict_to_process_info(data: Dict[str, Any]) -> ProcessInfo:
    """Convert dict to ProcessInfo dataclass"""
    return ProcessInfo(
        pid=data.get("pid", 0),
        name=data.get("name", "unknown"),
        command=data.get("command"),
        user=data.get("user"),
        cpu_percent=data.get("cpu_percent"),
        memory_percent=data.get("memory_percent"),
        thread_count=data.get("thread_count"),
        status=data.get("status"),
        captured_at=data.get("captured_at") or data.get("capturedAt"),
    )


def dict_to_network_details(data: Dict[str, Any]) -> NetworkDetails:
    """Convert dict to NetworkDetails dataclass"""
    return NetworkDetails(
        direction=data.get("direction", "unknown"),
        protocol=data.get("protocol"),
        local_address=data.get("local_address"),
        local_port=data.get("local_port"),
        remote_address=data.get("remote_address"),
        remote_port=data.get("remote_port"),
        bytes_sent=data.get("bytes_sent"),
        bytes_recv=data.get("bytes_recv")
    )


def dict_to_disk_details(data: Dict[str, Any]) -> DiskDetails:
    """Convert dict to DiskDetails dataclass"""
    return DiskDetails(
        operation=data.get("operation", "unknown"),
        path=data.get("path"),
        speed_mbps=data.get("speed_mbps"),
        iops=data.get("iops")
    )


def dict_to_cpu_details(data: Dict[str, Any]) -> CpuDetails:
    """Convert dict to CpuDetails dataclass"""
    return CpuDetails(
        user_percent=data.get("user_percent"),
        system_percent=data.get("system_percent"),
        idle_percent=data.get("idle_percent"),
        iowait_percent=data.get("iowait_percent")
    )


def dict_to_memory_details(data: Dict[str, Any]) -> MemoryDetails:
    """Convert dict to MemoryDetails dataclass"""
    return MemoryDetails(
        total_gb=data.get("total_gb"),
        used_gb=data.get("used_gb"),
        available_gb=data.get("available_gb"),
        swap_used_gb=data.get("swap_used_gb")
    )


def dict_to_anomaly(data: Dict[str, Any]) -> Anomaly:
    """Convert dict to Anomaly dataclass"""
    # Handle nested objects
    process_info = None
    if data.get("process_info"):
        process_info = dict_to_process_info(data["process_info"])
    
    network_details = None
    if data.get("network_details"):
        network_details = dict_to_network_details(data["network_details"])
    
    disk_details = None
    if data.get("disk_details"):
        disk_details = dict_to_disk_details(data["disk_details"])
    
    cpu_details = None
    if data.get("cpu_details"):
        cpu_details = dict_to_cpu_details(data["cpu_details"])
    
    memory_details = None
    if data.get("memory_details"):
        memory_details = dict_to_memory_details(data["memory_details"])
    
    return Anomaly(
        id=data.get("id", ""),
        timestamp=data.get("timestamp", ""),
        severity=data.get("severity", "unknown"),
        type=data.get("type", "unknown"),
        asset=data.get("asset", ""),
        metric=data.get("metric", ""),
        current_value=data.get("current_value", 0),
        expected_value=data.get("expected_value", 0),
        deviation=data.get("deviation", 0),
        description=data.get("description", ""),
        status=data.get("status", "active"),
        anomaly_id=data.get("anomaly_id") or data.get("anomalyId"),
        asset_ip=data.get("asset_ip"),
        service_calls=data.get("service_calls", []),
        process_info=process_info,
        network_details=network_details,
        disk_details=disk_details,
        cpu_details=cpu_details,
        memory_details=memory_details
    )


def dict_to_metric(data: Dict[str, Any]) -> MetricData:
    """Convert dict to MetricData dataclass"""
    # Keep only fields supported by MetricData
    supported_fields = {
        "timestamp", "cpu", "memory", "storage", 
        "network_in", "network_out", "disk_read", "disk_write"
    }
    filtered_data = {k: v for k, v in data.items() if k in supported_fields}
    return MetricData(**filtered_data)


def dict_to_service_call(data: Dict[str, Any]) -> ServiceCall:
    """Convert dict to ServiceCall dataclass"""
    return ServiceCall(**data)


def process_info_to_dict(process_info: ProcessInfo) -> Dict[str, Any]:
    """Convert ProcessInfo to dict"""
    d = {
        "pid": process_info.pid,
        "name": process_info.name,
        "command": process_info.command,
        "user": process_info.user,
        "cpuPercent": process_info.cpu_percent,
        "memoryPercent": process_info.memory_percent,
        "threadCount": process_info.thread_count,
        "status": process_info.status
    }
    if process_info.captured_at:
        d["capturedAt"] = process_info.captured_at
    return d


def network_details_to_dict(network_details: NetworkDetails) -> Dict[str, Any]:
    """Convert NetworkDetails to dict"""
    return {
        "direction": network_details.direction,
        "protocol": network_details.protocol,
        "localAddress": network_details.local_address,
        "localPort": network_details.local_port,
        "remoteAddress": network_details.remote_address,
        "remotePort": network_details.remote_port,
        "bytesSent": network_details.bytes_sent,
        "bytesRecv": network_details.bytes_recv
    }


def disk_details_to_dict(disk_details: DiskDetails) -> Dict[str, Any]:
    """Convert DiskDetails to dict"""
    return {
        "operation": disk_details.operation,
        "path": disk_details.path,
        "speedMbps": disk_details.speed_mbps,
        "iops": disk_details.iops
    }


def cpu_details_to_dict(cpu_details: CpuDetails) -> Dict[str, Any]:
    """Convert CpuDetails to dict"""
    return {
        "userPercent": cpu_details.user_percent,
        "systemPercent": cpu_details.system_percent,
        "idlePercent": cpu_details.idle_percent,
        "iowaitPercent": cpu_details.iowait_percent
    }


def memory_details_to_dict(memory_details: MemoryDetails) -> Dict[str, Any]:
    """Convert MemoryDetails to dict"""
    return {
        "totalGb": memory_details.total_gb,
        "usedGb": memory_details.used_gb,
        "availableGb": memory_details.available_gb,
        "swapUsedGb": memory_details.swap_used_gb
    }


def anomaly_to_dict(anomaly: Anomaly) -> Dict[str, Any]:
    """Convert Anomaly to dict"""
    result = {
        "id": anomaly.id,
        "timestamp": anomaly.timestamp,
        "severity": anomaly.severity,
        "type": anomaly.type,
        "asset": anomaly.asset,
        "metric": anomaly.metric,
        "currentValue": anomaly.current_value,
        "expectedValue": anomaly.expected_value,
        "deviation": anomaly.deviation,
        "description": anomaly.description,
        "status": anomaly.status
    }
    if anomaly.anomaly_id:
        result["anomalyId"] = anomaly.anomaly_id
    
    if anomaly.asset_ip:
        result["assetIp"] = anomaly.asset_ip
    if anomaly.service_calls:
        result["serviceCalls"] = anomaly.service_calls
    
    # Add process info and details
    if anomaly.process_info:
        result["processInfo"] = process_info_to_dict(anomaly.process_info)
    if anomaly.network_details:
        result["networkDetails"] = network_details_to_dict(anomaly.network_details)
    if anomaly.disk_details:
        result["diskDetails"] = disk_details_to_dict(anomaly.disk_details)
    if anomaly.cpu_details:
        result["cpuDetails"] = cpu_details_to_dict(anomaly.cpu_details)
    if anomaly.memory_details:
        result["memoryDetails"] = memory_details_to_dict(anomaly.memory_details)
    
    return result


def metric_to_dict(metric: MetricData) -> Dict[str, Any]:
    """Convert MetricData to dict"""
    return {
        "timestamp": metric.timestamp,
        "cpu": metric.cpu,
        "memory": metric.memory,
        "storage": metric.storage,
        "networkIn": metric.network_in,
        "networkOut": metric.network_out,
        "diskRead": metric.disk_read,
        "diskWrite": metric.disk_write
    }


def service_call_to_dict(service_call: ServiceCall) -> Dict[str, Any]:
    """Convert ServiceCall to dict"""
    return {
        "id": service_call.id,
        "from": service_call.from_service,
        "to": service_call.to_service,
        "count": service_call.count,
        "avgLatency": service_call.avg_latency,
        "p95Latency": service_call.p95_latency,
        "errorRate": service_call.error_rate,
        "timestamp": service_call.timestamp,
        "isAnomaly": service_call.is_anomaly
    }

