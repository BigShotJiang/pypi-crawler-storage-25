"""
Output service for IOC Scanner with reproduction steps and explicit commands.
"""

from datetime import datetime
from typing import List, Optional

from .proto import (
    IoCScanResult,
    ScanMetadata,
    ScanSummary,
    MitreSummary,
    IoCMatch,
    ScanStatus,
    ExploitationCommands,
    IoCType,
)
from plugins.reproduction import ReproStep


class OutputService:
    """Build IoCScanResult with reproduction steps and explicit commands."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _build_commands_for_match(self, match: IoCMatch) -> ExploitationCommands:
        """Build explicit detection commands based on IOC type."""
        hostname = getattr(self.plugin, "hostname", "target-host")
        ioc_type = match.indicator.type
        ioc_value = match.indicator.value
        target = match.target
        
        # File-based IOCs
        if ioc_type in [IoCType.MD5, IoCType.SHA1, IoCType.SHA256, IoCType.SHA512]:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Verify hash IOC: {ioc_value[:16]}...",
                    f"sha256sum {target}",
                    f"md5sum {target}",
                    f"# Search entire system for this hash:",
                    f"find / -type f -exec sha256sum {{}} \\; 2>/dev/null | grep '{ioc_value}'",
                    f"# Check VirusTotal:",
                    f"curl -s 'https://www.virustotal.com/vtapi/v2/file/report?apikey=YOUR_API_KEY&resource={ioc_value}'",
                    f"# Quarantine if malicious:",
                    f"mv {target} /tmp/quarantine/",
                ],
                description=f"Detect and verify hash IOC {ioc_type.value}"
            )
        
        elif ioc_type == IoCType.FILE_PATH:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Check suspicious file path IOC:",
                    f"ls -la {ioc_value}",
                    f"stat {ioc_value}",
                    f"file {ioc_value}",
                    f"sha256sum {ioc_value}",
                    f"strings {ioc_value} | head -50",
                    f"# Check file content:",
                    f"head -100 {ioc_value}",
                ],
                description=f"Analyze suspicious file at {ioc_value}"
            )
        
        elif ioc_type == IoCType.FILE_NAME:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Search for suspicious filename IOC: {ioc_value}",
                    f"find / -name '{ioc_value}' 2>/dev/null",
                    f"locate {ioc_value}",
                    f"# Check running processes using this file:",
                    f"lsof | grep '{ioc_value}'",
                ],
                description=f"Find all instances of suspicious filename"
            )
        
        # Network-based IOCs
        elif ioc_type == IoCType.IP_V4 or ioc_type == IoCType.IP_V6:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Check connections to malicious IP: {ioc_value}",
                    f"ss -tunap | grep '{ioc_value}'",
                    f"netstat -an | grep '{ioc_value}'",
                    f"# Check firewall logs:",
                    f"grep '{ioc_value}' /var/log/syslog /var/log/firewall.log 2>/dev/null",
                    f"# Block IP:",
                    f"iptables -A INPUT -s {ioc_value} -j DROP",
                    f"iptables -A OUTPUT -d {ioc_value} -j DROP",
                    f"# Check GeoIP:",
                    f"geoiplookup {ioc_value}",
                    f"# Check reputation:",
                    f"curl -s 'https://api.abuseipdb.com/api/v2/check?ipAddress={ioc_value}'",
                ],
                description=f"Detect/block malicious IP {ioc_value}"
            )
        
        elif ioc_type == IoCType.DOMAIN:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Check DNS resolution for malicious domain: {ioc_value}",
                    f"dig {ioc_value}",
                    f"nslookup {ioc_value}",
                    f"host {ioc_value}",
                    f"# Check WHOIS:",
                    f"whois {ioc_value}",
                    f"# Check if any process is connecting:",
                    f"ss -tunap | grep $(dig +short {ioc_value})",
                    f"# Search logs for domain:",
                    f"grep '{ioc_value}' /var/log/syslog /var/log/dns.log 2>/dev/null",
                    f"# Block domain via hosts:",
                    f"echo '127.0.0.1 {ioc_value}' >> /etc/hosts",
                ],
                description=f"Detect/block malicious domain {ioc_value}"
            )
        
        elif ioc_type == IoCType.URL:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Check for connections to malicious URL: {ioc_value[:50]}...",
                    f"grep -r '{ioc_value}' /var/log/ 2>/dev/null",
                    f"# Check browser history/cache:",
                    f"grep -r '{ioc_value}' ~/.mozilla ~/.config/google-chrome 2>/dev/null",
                    f"# Download for analysis (CAREFUL):",
                    f"# curl -o /tmp/malicious_download '{ioc_value}'",
                ],
                description=f"Detect access to malicious URL"
            )
        
        # Process-based IOCs
        elif ioc_type == IoCType.PROCESS_NAME:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Check for malicious process: {ioc_value}",
                    f"ps aux | grep '{ioc_value}'",
                    f"pgrep -a '{ioc_value}'",
                    f"# Get process details:",
                    f"ps -ef | grep '{ioc_value}'",
                    f"# Check process executable:",
                    f"ls -la /proc/$(pgrep {ioc_value})/exe 2>/dev/null",
                    f"# Kill if malicious:",
                    f"pkill -9 '{ioc_value}'",
                ],
                description=f"Detect/kill malicious process {ioc_value}"
            )
        
        elif ioc_type == IoCType.PROCESS_CMDLINE:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# Search for malicious command line pattern: {ioc_value[:50]}...",
                    f"ps aux | grep -E '{ioc_value}'",
                    f"# Check all command lines:",
                    f"for pid in /proc/[0-9]*; do cat $pid/cmdline 2>/dev/null | tr '\\0' ' '; echo; done | grep '{ioc_value}'",
                ],
                description=f"Detect malicious command line pattern"
            )
        
        # YARA rule match
        elif ioc_type == IoCType.YARA_RULE:
            return ExploitationCommands(
                server=hostname,
                commands=[
                    f"# YARA rule matched: {ioc_value}",
                    f"yara -r /path/to/rules/{ioc_value}.yar {target}",
                    f"# Scan entire system:",
                    f"yara -r /path/to/rules/{ioc_value}.yar /",
                    f"# Get file details:",
                    f"stat {target}",
                    f"sha256sum {target}",
                ],
                description=f"Verify YARA rule match: {ioc_value}"
            )
        
        # Default fallback
        return ExploitationCommands(
            server=hostname,
            commands=[
                f"# IOC Detection: {ioc_type.value}",
                f"# Value: {ioc_value}",
                f"# Target: {target}",
                f"grep -r '{ioc_value}' /var/log/ 2>/dev/null",
                f"find / -name '*{ioc_value}*' 2>/dev/null",
            ],
            description=f"Generic IOC detection for {ioc_type.value}"
        )

    def _build_steps_for_match(self, match: IoCMatch) -> List[ReproStep]:
        # Build commands first
        commands = self._build_commands_for_match(match)
        match.commands = commands
        
        # Build command string for payload
        command_str = "\n".join(commands.commands) if commands.commands else None
        
        return [
            ReproStep(
                title=f"IOC {match.indicator.type.value}: {match.indicator.value[:30]}...",
                preconditions=["Access to system for IOC verification"],
                target=match.target,
                action=f"Detect IOC {match.indicator.value}",
                payload=command_str,
                expected_outcome="IOC presence confirmed or blocked",
                evidence=str(match.metadata),
                tooling=["grep", "find", "yara", "ss/netstat", "iptables"],
                safety="Read-only detection unless blocking enabled",
                cleanup=None,
            )
        ]

    def _attach_reproduction_steps(self) -> List[ReproStep]:
        collected: List[ReproStep] = []
        for m in getattr(self.plugin, "all_ioc_matches", []) or []:
            if getattr(m, "reproduction_steps", None):
                collected.extend(m.reproduction_steps)
                continue
            m.reproduction_steps = self._build_steps_for_match(m)
            collected.extend(m.reproduction_steps)
        return collected

    def create_output(
        self,
        summary: ScanSummary,
        mitre_summary: MitreSummary,
    ) -> IoCScanResult:
        completed = datetime.utcnow()
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            started_at=getattr(self.plugin, "scan_start", completed),
            completed_at=completed,
            duration_seconds=self.plugin.scan_duration if hasattr(self.plugin, "scan_duration") else None,
            total_findings=len(getattr(self.plugin, "all_ioc_matches", []) or []),
            tool_version=getattr(self.plugin, "VERSION", "1.0.0"),
        )

        repro_steps = self._attach_reproduction_steps()

        return IoCScanResult(
            metadata=metadata,
            summary=summary,
            mitre_summary=mitre_summary,
            file_findings=getattr(self.plugin, "file_findings", []),
            process_findings=getattr(self.plugin, "process_findings", []),
            network_findings=getattr(self.plugin, "network_findings", []),
            memory_findings=getattr(self.plugin, "memory_findings", []),
            persistence_findings=getattr(self.plugin, "persistence_findings", []),
            log_findings=getattr(self.plugin, "log_findings", []),
            ttp_findings=getattr(self.plugin, "ttp_findings", []),
            all_ioc_matches=getattr(self.plugin, "all_ioc_matches", []),
            attack_timeline=getattr(self.plugin, "attack_timeline", None),
            ai_results=getattr(self.plugin, "ai_results", []),
            ti_enrichments=getattr(self.plugin, "ti_enrichments", []),
            overall_risk_score=getattr(self.plugin, "overall_risk_score", 0.0),
            overall_severity=getattr(self.plugin, "overall_severity", None),
            is_compromised=getattr(self.plugin, "is_compromised", False),
            remediation_steps=getattr(self.plugin, "remediation_steps", []),
            actions_taken=getattr(self.plugin, "actions_taken", []),
            status=ScanStatus.COMPLETED,
            reproduction_steps=repro_steps or None,
        )
