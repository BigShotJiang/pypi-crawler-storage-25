"""Progress and alert handling utilities."""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanMetadata, SeverityLevel


class ProgressHandler:
    """Utility class for handling progress updates and alerts."""
    
    @staticmethod
    async def handle_progress(scan_metadata: ScanMetadata, percent: int, message: str):
        """
        Handle progress updates.
        
        Args:
            scan_metadata: Scan metadata object to update
            percent: Progress percentage (0-100)
            message: Progress message
        """
        if scan_metadata:
            scan_metadata.progress_percent = percent
            scan_metadata.current_phase = message
        # Could emit via websocket here
    
    @staticmethod
    async def send_alert(plugin_instance, alert_type: str, message: str, severity: SeverityLevel):
        """
        Send alert.
        
        Args:
            plugin_instance: Plugin instance (for websocket access if needed)
            alert_type: Type of alert
            message: Alert message
            severity: Alert severity level
        """
        # Could send via websocket here
        pass

