"""IOC Scanner utility functions."""

import hashlib
import math
import os
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

import ipaddress

# Try imports with fallbacks
try:
    import magic
    HAS_MAGIC = True
except ImportError:
    HAS_MAGIC = False

try:
    import yara
    HAS_YARA = True
except ImportError:
    HAS_YARA = False

import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from ...proto import (
    IoCType,
    HashSet,
    FileMetadata,
    YaraMatch,
    LogEntry,
)


def calculate_entropy(data: bytes) -> float:
    """Calculate Shannon entropy of data."""
    if not data:
        return 0.0
    
    entropy = 0.0
    length = len(data)
    freq = defaultdict(int)
    
    for byte in data:
        freq[byte] += 1
    
    for count in freq.values():
        if count > 0:
            p = count / length
            entropy -= p * math.log2(p)
    
    return entropy


def calculate_file_hashes(filepath: str, algorithms: List[str] = None) -> HashSet:
    """Calculate multiple hashes for a file."""
    if algorithms is None:
        algorithms = ["md5", "sha1", "sha256"]
    
    hashes = {}
    hash_objects = {}
    
    for alg in algorithms:
        if alg == "md5":
            hash_objects["md5"] = hashlib.md5()
        elif alg == "sha1":
            hash_objects["sha1"] = hashlib.sha1()
        elif alg == "sha256":
            hash_objects["sha256"] = hashlib.sha256()
        elif alg == "sha512":
            hash_objects["sha512"] = hashlib.sha512()
    
    try:
        with open(filepath, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                for h in hash_objects.values():
                    h.update(chunk)
        
        for name, h in hash_objects.items():
            hashes[name] = h.hexdigest()
    except Exception:
        pass
    
    return HashSet(**hashes)


def get_file_metadata(filepath: str) -> Optional[FileMetadata]:
    """Get comprehensive file metadata."""
    try:
        path = Path(filepath)
        if not path.exists():
            return None
        
        stat = path.stat()
        
        # Determine file type
        file_type = None
        mime_type = None
        magic_str = None
        
        if HAS_MAGIC:
            try:
                magic_str = magic.from_file(filepath)
                mime_type = magic.from_file(filepath, mime=True)
            except Exception:
                pass
        
        # Check if executable
        is_executable = os.access(filepath, os.X_OK)
        
        # Check if hidden
        is_hidden = path.name.startswith(".")
        
        # Calculate entropy for small files
        entropy = None
        if stat.st_size < 10 * 1024 * 1024:  # < 10MB
            try:
                with open(filepath, "rb") as f:
                    entropy = calculate_entropy(f.read())
            except Exception:
                pass
        
        return FileMetadata(
            path=str(path.absolute()),
            name=path.name,
            size=stat.st_size,
            created=datetime.fromtimestamp(stat.st_ctime),
            modified=datetime.fromtimestamp(stat.st_mtime),
            accessed=datetime.fromtimestamp(stat.st_atime),
            owner=str(stat.st_uid),
            group=str(stat.st_gid),
            permissions=oct(stat.st_mode)[-3:],
            is_hidden=is_hidden,
            is_executable=is_executable,
            is_symlink=path.is_symlink(),
            symlink_target=str(path.resolve()) if path.is_symlink() else None,
            file_type=file_type,
            mime_type=mime_type,
            magic=magic_str,
            entropy=entropy,
        )
    except Exception:
        return None


def is_ip_address(value: str) -> bool:
    """Check if string is valid IP address."""
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def is_domain(value: str) -> bool:
    """Check if string is valid domain name."""
    domain_pattern = re.compile(
        r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    )
    return bool(domain_pattern.match(value))


def is_hash(value: str) -> Optional[IoCType]:
    """Check if string is a hash and return type."""
    value = value.lower().strip()
    
    if re.match(r'^[a-f0-9]{32}$', value):
        return IoCType.MD5
    elif re.match(r'^[a-f0-9]{40}$', value):
        return IoCType.SHA1
    elif re.match(r'^[a-f0-9]{64}$', value):
        return IoCType.SHA256
    elif re.match(r'^[a-f0-9]{128}$', value):
        return IoCType.SHA512
    
    return None


def detect_ioc_type(value: str) -> IoCType:
    """Auto-detect IOC type from value."""
    value = value.strip()
    
    # Check hash
    hash_type = is_hash(value)
    if hash_type:
        return hash_type
    
    # Check IP
    if is_ip_address(value):
        if ":" in value:
            return IoCType.IP_V6
        return IoCType.IP_V4
    
    # Check URL
    if value.startswith(("http://", "https://", "ftp://")):
        return IoCType.URL
    
    # Check email
    if "@" in value and "." in value.split("@")[-1]:
        return IoCType.EMAIL
    
    # Check domain
    if is_domain(value):
        return IoCType.DOMAIN
    
    # Check file path
    if "/" in value or "\\" in value:
        return IoCType.FILE_PATH
    
    return IoCType.CUSTOM


def match_yara_rules(filepath: str, rules_paths: List[str] = None, timeout: int = 60) -> List[YaraMatch]:
    """Match file against YARA rules."""
    if not HAS_YARA:
        return []
    
    matches = []
    
    try:
        # Compile rules
        rules = None
        if rules_paths:
            rule_files = {}
            for i, rp in enumerate(rules_paths):
                if os.path.isfile(rp):
                    rule_files[f"rule_{i}"] = rp
                elif os.path.isdir(rp):
                    for rf in Path(rp).glob("**/*.yar*"):
                        rule_files[str(rf)] = str(rf)
            
            if rule_files:
                rules = yara.compile(filepaths=rule_files)
        
        if rules:
            yara_matches = rules.match(filepath, timeout=timeout)
            for m in yara_matches:
                matches.append(YaraMatch(
                    rule_name=m.rule,
                    rule_namespace=m.namespace,
                    tags=list(m.tags),
                    meta=dict(m.meta),
                    strings=[
                        {"offset": s[0], "identifier": s[1], "data": s[2].hex() if isinstance(s[2], bytes) else s[2]}
                        for s in m.strings
                    ] if hasattr(m, 'strings') else []
                ))
    except Exception:
        pass
    
    return matches


def check_dga(domain: str) -> Tuple[bool, float]:
    """
    Check if domain looks like DGA (Domain Generation Algorithm).
    Returns (is_dga, score).
    """
    if not domain:
        return False, 0.0
    
    # Remove TLD
    parts = domain.split(".")
    if len(parts) < 2:
        return False, 0.0
    
    name = parts[0]
    
    # Scoring factors
    score = 0.0
    
    # Length check
    if len(name) > 15:
        score += 0.2
    if len(name) > 20:
        score += 0.2
    
    # Entropy of domain name
    if name:
        char_freq = defaultdict(int)
        for c in name:
            char_freq[c] += 1
        
        entropy = 0.0
        for count in char_freq.values():
            p = count / len(name)
            entropy -= p * math.log2(p)
        
        if entropy > 3.5:
            score += 0.3
    
    # Consonant/vowel ratio
    vowels = set("aeiou")
    consonants = sum(1 for c in name.lower() if c.isalpha() and c not in vowels)
    vowel_count = sum(1 for c in name.lower() if c in vowels)
    
    if vowel_count > 0:
        ratio = consonants / vowel_count
        if ratio > 4 or ratio < 0.3:
            score += 0.2
    
    # Numeric content
    digits = sum(1 for c in name if c.isdigit())
    if digits > len(name) * 0.3:
        score += 0.2
    
    # No meaningful words (simplified check)
    common_words = {"www", "mail", "ftp", "api", "dev", "test", "app", "web", "cdn", "img"}
    if not any(word in name.lower() for word in common_words):
        score += 0.1
    
    is_dga = score >= 0.5
    
    return is_dga, min(score, 1.0)


def parse_log_line(line: str, source: str = "") -> Optional[LogEntry]:
    """Parse a log line into structured format."""
    from datetime import datetime, timezone
    from calendar import month_abbr
    
    # Syslog format: "Mon DD HH:MM:SS hostname program[pid]: message"
    syslog_pattern = re.compile(
        r'^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(\S+?)(?:\[(\d+)\])?:\s+(.*)$'
    )
    
    # systemd/journald format: "2026-02-06T11:28:45.578760+00:00 hostname program[pid]: message"
    systemd_pattern = re.compile(
        r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:?\d{2})?)\s+(\S+)\s+(\S+?)(?:\[(\d+)\])?:\s+(.*)$'
    )
    
    # Apache/Nginx access log format: "IP - - [06/Feb/2026:11:28:45 +0000] "request" status size"
    access_log_pattern = re.compile(
        r'^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"([^"]+)"\s+(\d+)\s+(\d+)'
    )
    
    # Auth log format (SSH authentication logs)
    auth_pattern = re.compile(
        r'(Failed|Accepted|Invalid)\s+(password|publickey|user)\s+(?:for\s+)?(\S+)?\s+from\s+(\S+)\s+port\s+(\d+)'
    )
    
    # ISO8601 format at start of line: "2026-02-06T11:28:45Z" or "2026-02-06 11:28:45"
    iso8601_pattern = re.compile(
        r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:?\d{2})?)'
    )
    
    entry = LogEntry(
        source=source,
        message=line.strip(),
        raw_line=line
    )
    
    def _parse_timestamp(ts_str: str) -> Optional[datetime]:
        """Parse timestamp string to datetime object."""
        try:
            # Try ISO8601 format first
            if ts_str.endswith('Z'):
                ts_str = ts_str[:-1] + '+00:00'
            elif '+' in ts_str or (ts_str.count('-') >= 3 and 'T' in ts_str):
                # Already has timezone
                pass
            else:
                # Assume UTC if no timezone
                ts_str = ts_str + '+00:00'
            return datetime.fromisoformat(ts_str.replace(' ', 'T'))
        except Exception:
            try:
                # Try syslog format: "Mon DD HH:MM:SS" (need to add year)
                # Parse format like "Feb  6 11:28:45" or "Feb 06 11:28:45"
                parts = ts_str.strip().split()
                if len(parts) >= 3:
                    month_str = parts[0]
                    day = int(parts[1])
                    time_str = parts[2]
                    
                    # Get current year (syslog doesn't include year)
                    current_year = datetime.now().year
                    month_num = list(month_abbr).index(month_str)
                    
                    # Parse time
                    time_parts = time_str.split(':')
                    if len(time_parts) == 3:
                        hour = int(time_parts[0])
                        minute = int(time_parts[1])
                        second = int(time_parts[2])
                        
                        dt = datetime(current_year, month_num, day, hour, minute, second, tzinfo=timezone.utc)
                        return dt
            except Exception:
                pass
            try:
                # Try Apache/Nginx format: "06/Feb/2026:11:28:45 +0000"
                # Format: DD/Mon/YYYY:HH:MM:SS +TZ
                if ':' in ts_str and '/' in ts_str:
                    # Remove brackets if present
                    ts_str = ts_str.strip('[]')
                    # Parse "06/Feb/2026:11:28:45 +0000"
                    date_part, time_part = ts_str.split(':', 1)
                    day, month_str, year = date_part.split('/')
                    time_str, tz_str = time_part.rsplit(' ', 1)
                    
                    month_num = list(month_abbr).index(month_str)
                    hour, minute, second = map(int, time_str.split(':'))
                    
                    dt = datetime(int(year), month_num, int(day), hour, minute, second, tzinfo=timezone.utc)
                    return dt
            except Exception:
                pass
        return None
    
    # Try systemd/journald format first (most precise)
    match = systemd_pattern.match(line)
    if match:
        ts_str = match.group(1)
        entry.timestamp = _parse_timestamp(ts_str)
        entry.hostname = match.group(2)
        entry.program = match.group(3)
        entry.pid = int(match.group(4)) if match.group(4) else None
        entry.message = match.group(5)
        # Extract IPs and auth info
        ip_pattern = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
        ips = ip_pattern.findall(entry.message)
        if ips:
            entry.source_ip = ips[0]
            if len(ips) > 1:
                entry.destination_ip = ips[1]
        auth_match = auth_pattern.search(entry.message)
        if auth_match:
            entry.source_ip = auth_match.group(4)
            entry.user = auth_match.group(3) if auth_match.group(3) else None
        return entry
    
    # Try syslog format
    match = syslog_pattern.match(line)
    if match:
        ts_str = match.group(1)
        entry.timestamp = _parse_timestamp(ts_str)
        entry.hostname = match.group(2)
        entry.program = match.group(3)
        entry.pid = int(match.group(4)) if match.group(4) else None
        entry.message = match.group(5)
        # Extract IPs and auth info
        ip_pattern = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
        ips = ip_pattern.findall(entry.message)
        if ips:
            entry.source_ip = ips[0]
            if len(ips) > 1:
                entry.destination_ip = ips[1]
        auth_match = auth_pattern.search(entry.message)
        if auth_match:
            entry.source_ip = auth_match.group(4)
            entry.user = auth_match.group(3) if auth_match.group(3) else None
        return entry
    
    # Try Apache/Nginx access log format
    match = access_log_pattern.match(line)
    if match:
        ts_str = match.group(2)
        entry.timestamp = _parse_timestamp(ts_str)
        entry.source_ip = match.group(1)
        entry.message = match.group(3)
        return entry
    
    # Try ISO8601 at start of line
    match = iso8601_pattern.match(line)
    if match:
        ts_str = match.group(1)
        entry.timestamp = _parse_timestamp(ts_str)
    
    # Try auth log format directly (for non-syslog auth logs)
    auth_match = auth_pattern.search(line)
    if auth_match:
        entry.source_ip = auth_match.group(4)  # IP from auth log
        entry.user = auth_match.group(3) if auth_match.group(3) else None
    
    # Fallback: Try to extract IP addresses from any line
    ip_pattern = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
    ips = ip_pattern.findall(line)
    if ips:
        entry.source_ip = ips[0]
        if len(ips) > 1:
            entry.destination_ip = ips[1]
    
    return entry

