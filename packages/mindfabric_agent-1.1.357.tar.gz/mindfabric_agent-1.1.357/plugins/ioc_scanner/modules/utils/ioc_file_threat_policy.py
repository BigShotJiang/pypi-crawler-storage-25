"""
IOC file → threat row policy (agent-side).

Suppresses or downgrades file IOC noise in vendor/runtime trees without a corroborating
second signal. No Maven coordinate hash allowlist — paths like ~/.m2/repository and
Gradle caches are treated as dependency delivery trees (weak alone).

risk_score is computed only here for triage; backend must not invent it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

_SEVERITY_ORDER = ("info", "low", "medium", "high", "critical")

# After /opt/<segment>/ — known product/vendor roots (extend as needed).
_OPT_VENDOR_SEGMENTS = frozenset(
    {
        "google",
        "microsoft",
        "vmware",
        "splunk",
        "elastic",
        "elasticsearch",
        "kibana",
        "logstash",
        "oracle",
        "java",
        "openjdk",
        "jdk",
        "jre",
        "ibm",
        "websphere",
        "tomcat",
        "jetty",
        "apache",
        "nginx",
        "haproxy",
        "rabbitmq",
        "kafka",
        "confluent",
        "redis",
        "mongodb",
        "cassandra",
        "docker",
        "containerd",
        "cri-o",
        "cni",
        "nvidia",
        "cuda",
        "amazon",
        "aws",
        "azure",
        "jenkins",
        "gitlab-runner",
        "teamcity",
        "grafana",
        "prometheus",
        "datadog",
        "newrelic",
        "hashicorp",
        "vault",
        "consul",
        "nomad",
        "terraform",
        "ansible",
        "puppet",
        "chef",
        "mysql",
        "mariadb",
        "postgresql",
        "postgres",
        "percona",
        "couchdb",
        "etcd",
        "zookeeper",
        "apache2",
        "httpd",
        "wildfly",
        "jboss",
        "activemq",
        "artemis",
    }
)


def _norm_path(path: str) -> str:
    if not path:
        return ""
    return path.replace("\\", "/").lower().strip()


def _severity_index(sev: str) -> int:
    s = (sev or "medium").lower()
    try:
        return _SEVERITY_ORDER.index(s)
    except ValueError:
        return _SEVERITY_ORDER.index("medium")


def cap_severity(current: str, ceiling: Optional[str]) -> str:
    """Do not exceed ceiling (e.g. ceiling=medium caps critical→medium)."""
    if not ceiling:
        return current
    return _SEVERITY_ORDER[min(_severity_index(current), _severity_index(ceiling))]


def is_node_js_package_manager_cache(path_lower: str) -> bool:
    """
    Node/npm/pnpm/yarn/corepack/bun/deno toolchain delivery and cache trees.

    Executable bits on scripts under these paths are usually package managers / tooling,
    not attacker staging — suppress as threat rows unless corroborated (TI hash, YARA, etc.).
    """
    if not path_lower:
        return False
    p = path_lower.replace("\\", "/")
    # Segment markers (avoid bare substring false positives on unrelated "npm" tokens).
    markers = (
        "/.npm/",
        "/_cacache/",
        "/_prebuilds/",
        "/pnpm/",
        "/corepack/",
        "/node_modules/",
        "/node-gyp",
        "/.cache/node/",
        "/.cache/pnpm",
        "/.cache/corepack",
        "/.yarn/",
        "/.local/share/pnpm",
        "/.local/share/yarn",
        "/.pnpm-store/",
        "/pnpm-store/",
        "/.nvm/",
        "/.fnm/",
        "/.volta/",
        "/.bun/",
        "/.deno/",
        "/deno_dir/",
        "/.cache/deno",
        "/.turbo/",
        "/.vite/",
        "/.parcel-cache/",
    )
    if any(m in p for m in markers):
        return True
    # pnpm content-addressed store layout
    if "/pnpm/store/" in p and "/files/" in p:
        return True
    # npm pack / yarn classic
    if p.endswith((".tgz", ".yarn-metadata.json")) and ("/.npm/" in p or "/.yarn/" in p):
        return True
    return False


def is_maven_or_gradle_cache_jar(path_lower: str) -> bool:
    if not path_lower.endswith(".jar"):
        return False
    if ".m2/repository/" in path_lower:
        return True
    if ".gradle/caches/" in path_lower or "/gradle/caches/" in path_lower:
        return True
    return False


def is_typical_server_runtime_jar(path_lower: str) -> bool:
    """Jetty/Tomcat/app-server bundles and runtime/lib trees."""
    if not path_lower.endswith(".jar"):
        return False
    markers = (
        "/webapps/",
        "/web-inf/lib/",
        "/web-inf/classes/",
        "/tomcat/",
        "/jetty/",
        "/wildfly/",
        "/jboss/",
        "/kafka/libs/",
        "/elasticsearch/lib/",
        "/elasticsearch/modules/",
        "/logstash/vendor/",
        "/splunk/",
        "/runtime/lib/",
        "/usr/share/tomcat",
        "/usr/share/java/",
        "/usr/share/elasticsearch",
    )
    if any(m in path_lower for m in markers):
        return True
    # Only treat /opt/<known vendor>/.../lib/*.jar as delivery-like — not arbitrary /opt/custom_app/lib.
    if path_lower.startswith("/opt/") and "/lib/" in path_lower and path_lower.endswith(".jar"):
        parts = [p for p in path_lower.split("/") if p]
        if len(parts) >= 2 and parts[0] == "opt":
            seg = parts[1].split("@", 1)[0]
            if seg in _OPT_VENDOR_SEGMENTS:
                return True
    return False


def is_opt_product_lib_jar(path_lower: str) -> bool:
    """
    Typical product install: /opt/<product>/**/lib/**/*.jar
    Treat as vendor/delivery tree unless corroborated (TI hash, network, process, YARA, etc.).
    Replaced trojan JARs usually still need a second signal (e.g. hash TI, anomaly) to alert cleanly.
    """
    if not path_lower.endswith(".jar"):
        return False
    return bool(
        re.match(r"^/opt/[^/]+/(?:.*/)?lib/.*\.jar$", path_lower)
    )


def is_known_opt_vendor_tree(path_lower: str) -> bool:
    if not path_lower.startswith("/opt/"):
        return False
    parts = [p for p in path_lower.split("/") if p]
    if len(parts) < 2:
        return False
    # parts[0] == 'opt', parts[1] == product segment
    seg = parts[1].split("@", 1)[0]
    if seg in _OPT_VENDOR_SEGMENTS:
        return True
    return any(
        x in path_lower
        for x in (
            "/tomcat",
            "/jetty",
            "/jboss",
            "/wildfly",
            "/kafka",
            "/elasticsearch",
            "/cassandra",
            "/nginx",
        )
    )


_KEYSTORE_SUFFIX = (".jks", ".p12", ".pfx", ".keystore", ".truststore")


def is_structurally_expected_entropy_vendor_artifact_path(path_lower: str) -> bool:
    """
    Paths where **high entropy alone** is usually a property of shipped artifacts, not malware.

    We never rely on path-only for YARA/webshell; this gate applies only to ``high_entropy`` heuristics.
    Real compromise is still surfaced when :func:`_ioc_strong_corroboration_signals` fires
    (TI hash, YARA, non-root owner in this tree, network context, …).
    """
    if not path_lower:
        return False
    p = path_lower.replace("\\", "/")
    if "/postgresql/bitcode/" in p and (p.endswith(".bc") or ".index.bc" in p):
        return True
    if "/etc/pki/ca-trust/" in p:
        return True
    if p.endswith("/phar.phar") or p.endswith("phar.phar"):
        return True
    if "/etc/keys/ima/" in p and p.endswith(".der"):
        return True
    if "/dateutil/zoneinfo/" in p or "/dateutil/zoneinfo" in p:
        return True
    return False


def is_git_hook_sample_template_path(path_lower: str) -> bool:
    """Official ``.git/hooks/*.sample`` templates — executable-looking but not deployment hooks."""
    if not path_lower:
        return False
    p = path_lower.replace("\\", "/")
    if "/.git/hooks/" not in p:
        return False
    base = p.rsplit("/", 1)[-1]
    return base.endswith(".sample") or ".sample." in base


def _ioc_strong_corroboration_signals(seconds_meaningful: List[str]) -> bool:
    """Second-factor signals that justify emitting a threat on an otherwise weak path."""
    strong = frozenset(
        {
            "yara_rules",
            "non_root_owner_in_vendor_entropy_tree",
            "ioc_recorded_file_hashes",
            "ti_classification",
            "ti_source_attribution",
            "ti_high_confidence_indicator",
            "ioc_metadata_network_hint",
            "evidence_network_or_execution_hint",
            "related_process",
            "network_context",
            "ioc_match_context_strong",
            "finding_type:yara_match",
            "finding_type:webshell",
        }
    )
    return any(s in strong for s in seconds_meaningful)


def is_product_keystore_near_conf(path_lower: str) -> bool:
    if not any(path_lower.endswith(s) for s in _KEYSTORE_SUFFIX):
        return False
    if "/conf/" in path_lower:
        return True
    # e.g. .../apache2/conf/ssl/server.keystore
    if re.search(
        r"/(tomcat|jetty|nginx|apache2|httpd|wildfly|jboss|kafka|elasticsearch)/.*/conf/",
        path_lower,
    ):
        return True
    return False


def collect_second_signals(item: Dict[str, Any], path_lower: str) -> List[str]:
    """Corroboration beyond a weak path/filename IOC (TI, process, network, strong match types)."""
    sigs: List[str] = []
    ft = str(item.get("finding_type") or item.get("findingType") or "").lower()
    if ft in ("yara_match", "webshell"):
        sigs.append(f"finding_type:{ft}")

    ym = item.get("yara_matches") or item.get("yaraMatches")
    if isinstance(ym, list) and ym:
        sigs.append("yara_rules")

    im = item.get("ioc_match") if isinstance(item.get("ioc_match"), dict) else {}
    ind = im.get("indicator") if isinstance(im.get("indicator"), dict) else {}
    itype = str(ind.get("type") or "").strip().lower()
    meta = im.get("metadata") if isinstance(im.get("metadata"), dict) else {}

    if itype in {"file_hash", "sha256", "sha1", "md5", "hash", "imphash", "ssdeep"}:
        sigs.append(f"ioc:{itype}")
    elif itype and itype not in {"file_name", "filename", "file_path", "path", "string"}:
        sigs.append(f"ioc_type:{itype}")

    # Threat intel attribution (feed / actor / family) — hash+source still counts as TI-backed
    if (ind.get("source") or "").strip() or (ind.get("source_url") or "").strip():
        sigs.append("ti_source_attribution")
    if (ind.get("threat_actor") or "").strip() or (ind.get("malware_family") or "").strip() or (ind.get("campaign") or "").strip():
        sigs.append("ti_classification")
    try:
        if float(ind.get("confidence") or 0) >= 0.85:
            sigs.append("ti_high_confidence_indicator")
    except (TypeError, ValueError):
        pass

    mt = im.get("mitre_techniques")
    if isinstance(mt, list) and mt:
        sigs.append("ioc_match_mitre")

    fh = im.get("hashes")
    if isinstance(fh, dict) and any(fh.get(x) for x in ("sha256", "sha1", "md5", "sha512")):
        sigs.append("ioc_recorded_file_hashes")

    mt_keys = {k.lower() for k in meta.keys()}
    if mt_keys & {
        "related_ip",
        "related_ips",
        "dst_ip",
        "c2",
        "c2_ip",
        "beacon",
        "connections",
        "dst_port",
        "remote_ip",
    }:
        sigs.append("ioc_metadata_network_hint")

    mctx = str(im.get("match_context") or im.get("matchContext") or "").lower()
    if any(x in mctx for x in ("c2", "beacon", "malware", "trojan", "exploit", "payload")):
        sigs.append("ioc_match_context_strong")

    if str(im.get("match_type") or im.get("matchType") or "").lower() in ("exact", "yara", "sigma"):
        sigs.append(f"ioc_match_type:{str(im.get('match_type') or im.get('matchType')).lower()}")

    for pref in ("/tmp/", "/var/tmp/", "/dev/shm/", "/home/", "/root/"):
        if path_lower.startswith(pref):
            sigs.append("writable_or_user_tree")
            break

    # Process/network context sometimes embedded by scanners
    if item.get("related_process") or item.get("relatedProcess"):
        sigs.append("related_process")
    if item.get("related_connections") or item.get("network_matches"):
        sigs.append("network_context")

    ev = item.get("evidence")
    if isinstance(ev, list) and ev:
        blob = " ".join(str(x).lower() for x in ev[:40])
        if any(
            k in blob
            for k in (
                "listening",
                "established",
                "tcp ",
                "udp ",
                "connect",
                "curl ",
                "wget ",
                "malware",
                "c2",
                "beacon",
            )
        ):
            sigs.append("evidence_network_or_execution_hint")

    fmeta = _meta_dict(item)
    mod = _parse_iso_dt(fmeta.get("modified") or fmeta.get("mtime"))
    if mod:
        age = datetime.now(timezone.utc) - mod
        if age <= timedelta(hours=48):
            sigs.append("modified_within_48h")
    owner = str(fmeta.get("owner") or "").strip().lower()
    if owner and owner not in {"0", "root", ""}:
        if is_structurally_expected_entropy_vendor_artifact_path(path_lower):
            sigs.append("non_root_owner_in_vendor_entropy_tree")

    return sigs


@dataclass
class IocFileThreatDecision:
    emit: bool
    severity_ceiling: Optional[str] = None  # cap item severity (e.g. medium)
    risk_score: Optional[int] = None  # 0–100 for triage; None if suppressed
    policy: Dict[str, Any] = field(default_factory=dict)


def _parse_iso_dt(val: Any) -> Optional[datetime]:
    if val is None:
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    if not isinstance(val, str) or not val.strip():
        return None
    s = val.strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(s)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _meta_dict(item: Dict[str, Any]) -> Dict[str, Any]:
    m = item.get("file_metadata") or item.get("fileMetadata")
    return m if isinstance(m, dict) else {}


def build_ioc_file_posture_profile(
    item: Dict[str, Any],
    *,
    baseline_path_prefixes: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Multi-factor posture for analysts (does not replace classify_ioc_file_for_threat emit/suppress).

    Strong finding types (yara / webshell) stay high-signal; we only add context and small risk deltas.
    """
    path = item.get("file_path") or item.get("filePath") or ""
    path_lower = _norm_path(str(path))
    ft = str(item.get("finding_type") or item.get("findingType") or "").strip().lower()
    meta = _meta_dict(item)
    factors: List[str] = []
    risk_delta = 0

    if ft in ("yara_match", "webshell"):
        factors.append("strong_finding_type")
        return {
            "posture_tier": "high",
            "posture_factors": factors,
            "risk_score_delta": 0,
            "path_class_hint": "strong_type",
        }

    # --- Entropy vs location ---
    ent: Optional[float] = None
    try:
        ent = float(meta.get("entropy")) if meta.get("entropy") is not None else None
    except (TypeError, ValueError):
        ent = None
    staging = any(
        path_lower.startswith(p)
        for p in ("/tmp/", "/var/tmp/", "/dev/shm/", "/home/", "/root/")
    )
    if ent is not None:
        factors.append(f"entropy={ent:.2f}")
        if ent >= 7.8 and staging:
            risk_delta += 12
            factors.append("high_entropy_user_staging")
        elif ent >= 7.5 and staging:
            risk_delta += 8
            factors.append("elevated_entropy_staging")
        elif ent >= 7.2 and not staging:
            risk_delta += 4
            factors.append("elevated_entropy_system_tree")

    # --- Owner / identity drift (hostile replace of system binaries is rare but high impact) ---
    owner = str(meta.get("owner") or "").strip().lower()
    if owner and owner not in {"0", "root", ""}:
        if path_lower.startswith(("/bin/", "/sbin/", "/usr/bin/", "/usr/sbin/", "/lib/", "/lib64/")):
            risk_delta += 14
            factors.append("non_root_owner_system_binary_tree")
        elif path_lower.startswith("/etc/") and not path_lower.startswith("/etc/pki/"):
            risk_delta += 8
            factors.append("non_root_owner_etc_path")

    # --- Recency (recent drop-in) ---
    mod = _parse_iso_dt(meta.get("modified") or meta.get("mtime"))
    if mod:
        age = datetime.now(timezone.utc) - mod
        if age <= timedelta(hours=48):
            risk_delta += 6
            factors.append("modified_within_48h")
        elif age <= timedelta(days=7):
            risk_delta += 3
            factors.append("modified_within_7d")

    # --- Optional golden / fleet baseline: paths outside declared prefixes are more interesting ---
    prefs = [p.strip().lower().replace("\\", "/") for p in (baseline_path_prefixes or []) if isinstance(p, str) and p.strip()]
    if prefs and path_lower:
        if not any(path_lower.startswith(p) for p in prefs):
            risk_delta += 5
            factors.append("outside_ioc_baseline_prefixes")

    # --- Executable bit in non-standard lib (often loaders) ---
    if meta.get("is_executable") and ("/lib/" in path_lower or "/lib64/" in path_lower) and not path_lower.endswith(".so"):
        risk_delta += 5
        factors.append("executable_under_lib")

    # Soft dampening only when clearly vendor-ish AND weak type (never pull yara down here)
    if ft == "high_entropy" and ("/site-packages/" in path_lower or "/dist-packages/" in path_lower):
        risk_delta -= 6
        factors.append("python_vendor_tree_entropy_common")

    tier: str
    if risk_delta >= 10:
        tier = "elevated"
    elif risk_delta <= -4:
        tier = "low_noise"
    else:
        tier = "standard"

    return {
        "posture_tier": tier,
        "posture_factors": factors,
        "risk_score_delta": max(-12, min(18, risk_delta)),
        "path_class_hint": "analyzed",
    }


def apply_posture_to_risk_score(base: int, posture: Dict[str, Any], *, strong_type: bool) -> Tuple[int, Dict[str, Any]]:
    """Clamp 0–100; strong types only allow non-negative deltas."""
    delta = int(posture.get("risk_score_delta") or 0)
    if strong_type:
        delta = max(0, delta)
    out = max(0, min(100, int(base) + delta))
    posture = dict(posture)
    posture["risk_score_after_posture"] = out
    return out, posture


def classify_ioc_file_for_threat(item: Dict[str, Any]) -> IocFileThreatDecision:
    path = item.get("file_path") or item.get("filePath") or ""
    path_lower = _norm_path(str(path))
    ft = str(item.get("finding_type") or item.get("findingType") or "").strip().lower()

    seconds = collect_second_signals(item, path_lower)
    # "writable_or_user_tree" is too weak to count as corroboration for JS package caches
    # (almost everything under /home is flagged — would block toolchain suppressions).
    seconds_meaningful = [s for s in seconds if s != "writable_or_user_tree"]
    policy: Dict[str, Any] = {
        "second_signals": seconds,
        "second_signals_meaningful": seconds_meaningful,
        "path_lower": path_lower,
        "finding_type": ft,
    }

    if ft in ("yara_match", "webshell"):
        policy["decision"] = "strong_finding_type"
        rs = 90 if ft == "webshell" else 78
        return IocFileThreatDecision(True, None, rs, policy)

    # Node/npm/pnpm/corepack caches: path heuristics alone are expected; require real corroboration.
    if is_node_js_package_manager_cache(path_lower) and ft in ("suspicious_location", "high_entropy"):
        if not seconds_meaningful:
            policy["decision"] = "suppress_node_toolchain_cache_without_corroboration"
            return IocFileThreatDecision(False, None, None, policy)

    # Shipped blobs (PG bitcode, CA bundles, IMA keys, PHP phar, tzdata): entropy-only is not a threat
    # unless TI/YARA/owner drift / network context corroborates.
    if ft == "high_entropy" and is_structurally_expected_entropy_vendor_artifact_path(path_lower):
        if not _ioc_strong_corroboration_signals(seconds_meaningful):
            policy["decision"] = "suppress_expected_vendor_entropy_without_corroboration"
            policy["path_class"] = "expected_vendor_high_entropy_blob"
            return IocFileThreatDecision(False, None, None, policy)
        policy["path_class"] = "expected_vendor_high_entropy_blob_with_corroboration"
        rs = min(78, 40 + len(seconds_meaningful) * 12)
        return IocFileThreatDecision(True, "medium", rs, policy)

    if ft in ("high_entropy", "suspicious_location") and is_git_hook_sample_template_path(path_lower):
        if not _ioc_strong_corroboration_signals(seconds_meaningful):
            policy["decision"] = "suppress_git_hook_sample_template_without_corroboration"
            policy["path_class"] = "git_upstream_hook_template"
            return IocFileThreatDecision(False, None, None, policy)

    vendorish = (
        is_known_opt_vendor_tree(path_lower)
        or is_typical_server_runtime_jar(path_lower)
        or is_maven_or_gradle_cache_jar(path_lower)
        or is_opt_product_lib_jar(path_lower)
    )
    if vendorish:
        policy["path_class"] = "vendor_or_dependency_delivery"

    keystore_adj = is_product_keystore_near_conf(path_lower)
    if keystore_adj:
        policy["path_class"] = policy.get("path_class") or "product_keystore"
        if not seconds:
            policy["decision"] = "suppress_keystore_without_second_signal"
            return IocFileThreatDecision(False, None, None, policy)

    if vendorish and not seconds:
        policy["decision"] = "suppress_vendor_tree_without_second_signal"
        return IocFileThreatDecision(False, None, None, policy)

    if vendorish and seconds:
        policy["decision"] = "vendor_tree_with_corroboration"
        rs = min(80, 45 + len(seconds) * 11)
        return IocFileThreatDecision(True, "medium", rs, policy)

    policy["decision"] = "default_emit"
    rs = {"ioc_match": 64, "high_entropy": 50, "suspicious_location": 58}.get(ft, 56)
    return IocFileThreatDecision(True, None, rs, policy)
