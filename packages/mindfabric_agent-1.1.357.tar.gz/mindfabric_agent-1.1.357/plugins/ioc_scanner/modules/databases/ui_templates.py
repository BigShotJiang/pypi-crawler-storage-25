"""
IOC Scanner UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse / what it indicates)
- recommendations (what to do next)
"""

from __future__ import annotations

import re
import shlex
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional, Set


def get_ioc_guidance(kind: str) -> Tuple[str, List[Dict[str, str]]]:
    k = (kind or "").strip().lower()

    if k in ("process", "process_finding", "injection"):
        return (
            "Suspicious process behavior can indicate malware execution, credential theft, or process injection. Attackers often use living-off-the-land binaries and injected code to evade detection.",
            [
                {
                    "title": "Triage the process tree on-host",
                    "description": "Capture parent PID chain, user context, binary path, and open files/sockets; dump command line and verify image signature before killing.",
                    "priority": "high",
                },
                {
                    "title": "Enumerate persistence and credentials",
                    "description": "After confirming malicious behavior, scan systemd/cron/tasks, shell profiles, and SSH authorized_keys for follow-on access.",
                    "priority": "medium",
                },
            ],
        )

    if k in ("network", "beaconing", "c2"):
        return (
            "Suspicious network connections and beaconing patterns can indicate command-and-control (C2) activity. Attackers use C2 to execute commands, exfiltrate data, and move laterally.",
            [
                {
                    "title": "Contain egress and map the session",
                    "description": "Identify owning PID/process, block or sinkhole the destination at the firewall/proxy, and retain PCAP or flow logs for the connection window.",
                    "priority": "high",
                },
                {
                    "title": "Validate accounts and secrets",
                    "description": "If data left the host or shells were interactive, assume credential exposure; rotate session tokens and review auth logs for new logons.",
                    "priority": "medium",
                },
            ],
        )

    if k in ("file", "webshell", "malware"):
        return (
            "Suspicious or modified binaries/webshells can indicate persistence or post-exploitation tooling. Attackers often modify common paths and drop implants in writable locations.",
            [
                {
                    "title": "Capture integrity evidence per path",
                    "description": "Record owner, mtime, permissions, and hashes; compare to package manager inventory (dpkg/rpm) or golden image for paths under /usr, /bin, or language runtimes.",
                    "priority": "high",
                },
                {
                    "title": "Correlate in EDR/SIEM and asset inventory",
                    "description": "Search for the same path, hash, or signing anomaly across hosts; review alerts and logins on systems that share the artifact.",
                    "priority": "medium",
                },
            ],
        )

    if k in ("persistence",):
        return (
            "Persistence artifacts indicate an attacker may regain access after reboot or credential rotation. This increases dwell time and complicates eradication.",
            [
                {"title": "Remove persistence", "description": "Disable or remove identified persistence mechanisms; verify no alternate methods exist.", "priority": "high"},
                {"title": "Rebuild if needed", "description": "For high-confidence compromise, consider rebuild/re-image to ensure eradication.", "priority": "medium"},
            ],
        )

    if k in ("memory", "memory_finding"):
        return (
            "Memory-resident anomalies often accompany injection, unpacked shellcode, or credential scraping from other processes. "
            "Attackers use in-RAM techniques to evade file-centric AV while still executing and exfiltrating.",
            [
                {
                    "title": "Correlate with disk and parent process",
                    "description": "Map suspicious regions to on-disk modules, parent PID, and user; capture a targeted dump only under policy.",
                    "priority": "high",
                },
                {
                    "title": "Contain if confirmed",
                    "description": "Isolate the host; terminate only after evidence preservation; rebuild if kernel-critical services are suspect.",
                    "priority": "medium",
                },
            ],
        )

    if k in ("log", "log_finding"):
        return (
            "Log-derived signals (auth failures, exploit patterns, policy violations) describe attacker behavior without a binary IoC. "
            "High-volume or patterned lines often precede successful access or web exploitation.",
            [
                {
                    "title": "Pivot from log to session",
                    "description": "Extract source IP, user, and time window; check for successful logons or web shells in the same period.",
                    "priority": "high",
                },
                {
                    "title": "Tune and retain",
                    "description": "Ensure shipping to SIEM with retention that covers dwell time; add detections for the observed pattern.",
                    "priority": "medium",
                },
            ],
        )

    if k in ("ssh_bruteforce", "ssh brute force", "invalid ssh user"):
        return (
            "SSH brute force attacks attempt to gain unauthorized access by systematically trying username/password combinations. High-volume attacks indicate automated botnets targeting exposed SSH services. If successful, attackers gain shell access and can install backdoors, exfiltrate data, or pivot to other systems.",
            [
                {"title": "Block attacking IPs", "description": "Immediately block identified source IPs using firewall rules (iptables/ufw) or fail2ban. Consider blocking entire IP ranges if attacks originate from known malicious networks.", "priority": "high"},
                {"title": "Harden SSH configuration", "description": "Disable password authentication, use SSH keys only. Change default SSH port, enable rate limiting, and restrict access to specific IPs if possible.", "priority": "high"},
                {"title": "Check for successful logins", "description": "Review /var/log/auth.log for 'Accepted' entries from suspicious IPs. Check for new user accounts, suspicious cron jobs, or unauthorized SSH keys.", "priority": "high"},
                {"title": "Monitor and alert", "description": "Set up automated alerts for SSH brute force attempts. Consider using fail2ban or similar tools for automatic blocking.", "priority": "medium"},
            ],
        )

    if k in ("oom killer", "out of memory"):
        return (
            "Out of Memory (OOM) killer events indicate severe memory pressure that forced the kernel to terminate processes. While not directly a security threat, OOM events can indicate resource exhaustion attacks (DoS), memory leaks in applications, or insufficient system resources. Attackers may intentionally trigger OOM to crash security tools or cause service disruptions.",
            [
                {"title": "Identify root cause", "description": "Review system memory usage (free -h, top, ps aux --sort=-%mem). Check if specific processes are consuming excessive memory or if system is undersized for workload.", "priority": "high"},
                {"title": "Check for memory leaks", "description": "Review application logs and system logs for patterns. Monitor memory usage over time to identify processes with growing memory consumption.", "priority": "medium"},
                {"title": "Review killed processes", "description": "Identify which processes were killed and why. Check if critical security tools or services were affected.", "priority": "high"},
                {"title": "Optimize or scale resources", "description": "If legitimate workload, consider increasing system memory or optimizing application memory usage. If attack, implement rate limiting and resource quotas.", "priority": "medium"},
            ],
        )

    return (
        "Unclassified host indicator: use it as a thread to pull—real intrusions usually leave correlated signals (auth, process, "
        "file, network) in the same timeframe. Downgrade only after change-management or vendor baseline explains the observation.",
        [
            {
                "title": "Time-boxed correlation",
                "description": "Within ±hours of detection, search EDR/SIEM for matching hashes, IPs, users, and parent/child processes; open an incident if two or more independent signals align.",
                "priority": "high",
            },
            {
                "title": "Rule out benign drift",
                "description": "Compare to golden image, package inventory, and recent deploys; document owners before closing.",
                "priority": "medium",
            },
        ],
    )


def get_ioc_process_audience_lead() -> str:
    return (
        "This process matched an IOC or heuristic: it may be malware, a hijacked legitimate binary, or LOLBin abuse. "
        "Operators often run payloads under familiar names (e.g., `java`, `powershell`) with unusual argv, cwd, or network peers—"
        "that gap between “trusted name” and behavior is what attackers exploit for execution and evasion."
    )


def get_ioc_network_audience_lead() -> str:
    return (
        "This network indicator points at a destination or flow that resembles C2, scanning, or data exfil. "
        "Even a single beacon can mean an implant is alive; staged downloads often precede hands-on-keyboard activity. "
        "Map the socket to owning PID and user before blocking so you do not blind a critical updater."
    )


def get_ioc_memory_audience_lead() -> str:
    return (
        "Memory telemetry suggests code or data in a process image that should not be there—injection, reflective loaders, or "
        "scraped secrets in heap regions. Attackers favor RAM to skip on-disk scanners while still running capabilities. "
        "Treat as high priority when paired with suspicious network or auth activity."
    )


def get_ioc_persistence_audience_lead(item: Dict[str, Any]) -> str:
    ptype = str(item.get("persistence_type") or item.get("persistenceType") or item.get("type") or "").strip()
    loc = str(item.get("location") or item.get("file_path") or item.get("filePath") or item.get("path") or "").strip()
    loc_bit = f" Entry surface: `{loc[:160]}{'…' if len(loc) > 160 else ''}`." if loc else ""
    type_bit = f" Mechanism: {ptype}." if ptype else ""
    return (
        "Persistence lets an adversary survive reboots, password rotations, and simple malware cleanup—cron, systemd, WMI, Run keys, "
        "and hijacked startup scripts are common primitives."
        + type_bit
        + loc_bit
        + " Removing only the payload without deleting the trigger often yields a quick reinfection."
    )


def get_ioc_log_audience_lead(item: Dict[str, Any]) -> str:
    src = str(item.get("log_source") or item.get("logSource") or "").strip()
    pat = str(item.get("matched_pattern") or item.get("matchedPattern") or "").strip()
    bits = []
    if src:
        bits.append(f"source `{src[:120]}`")
    if pat:
        bits.append(f"pattern `{pat[:120]}{'…' if len(pat) > 120 else ''}`")
    ctx = f" ({', '.join(bits)})" if bits else ""
    return (
        f"Log lines matched suspicious content{ctx}. That usually means repeated failed auth, exploit-style requests, or policy "
        "violations—early warning before a confirmed compromise. Correlate timestamps with firewall, WAF, and EDR to see whether "
        "the same actor graduated to success elsewhere."
    )


def _ioc_item_file_path(item: Dict[str, Any]) -> str:
    for key in ("file_path", "filePath", "path", "location"):
        v = item.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _ioc_item_mitre_ids(item: Dict[str, Any]) -> List[str]:
    raw = item.get("mitre_techniques") or item.get("mitreTechniques") or []
    out: List[str] = []
    if isinstance(raw, list):
        for x in raw:
            if isinstance(x, str) and x.strip():
                out.append(x.strip().upper())
            elif isinstance(x, dict):
                tid = str(x.get("technique_id") or x.get("id") or "").strip().upper()
                if tid:
                    out.append(tid)
    return out


def build_ioc_file_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Per-file IOC rows: recommendations name the path, hashes, and MITRE context when present.
    """
    path = _ioc_item_file_path(item)
    path_disp = path if len(path) <= 200 else path[:197] + "…"
    base = Path(path.replace("\\", "/")).name.lower() if path else ""

    im = item.get("ioc_match") if isinstance(item.get("ioc_match"), dict) else {}
    ind = im.get("indicator") if isinstance(im.get("indicator"), dict) else {}
    ind_type = str(ind.get("type") or "").strip().lower()
    ind_val = ind.get("value") or ind.get("pattern")
    ind_hint = ""
    if ind_type in {"file_hash", "sha256", "sha1", "md5", "hash", "imphash", "ssdeep"} and isinstance(ind_val, str) and ind_val.strip():
        iv = ind_val.strip()
        ind_hint = f" Indicator match type `{ind_type}` ({iv[:48]}{'…' if len(iv) > 48 else ''})."

    hash_bits: List[str] = []
    for hk, label in (("sha256", "SHA-256"), ("sha1", "SHA-1"), ("md5", "MD5")):
        v = item.get(hk) or item.get(hk.upper())
        if isinstance(v, str) and v.strip():
            hash_bits.append(f"{label} {v.strip()[:16]}…" if len(v.strip()) > 20 else f"{label} {v.strip()}")

    path_ref = f"`{path_disp}`" if path_disp else "this file path"
    recs: List[Dict[str, str]] = [
        {
            "title": "Verify the file on-host",
            "description": (
                f"Run read-only checks on {path_ref}: `ls -la`, `stat`, and `sha256sum` (or `shasum -a 256`). "
                f"If the path lives under `/usr` or a language runtime tree, confirm ownership with the distro package manager "
                f"(e.g. `dpkg -S` / `rpm -qf`).{ind_hint}"
            ),
            "priority": "high",
        },
    ]

    if hash_bits:
        recs.append(
            {
                "title": "Hunt the same hash across the fleet",
                "description": (
                    "Use EDR, file integrity, or SIEM inventory to find other hosts with "
                    + "; ".join(hash_bits)
                    + "; treat matches as related incidents."
                ),
                "priority": "medium",
            }
        )

    mitre = _ioc_item_mitre_ids(item)
    if "T1027" in mitre:
        recs.append(
            {
                "title": "Rule out obfuscation and supply-chain drift",
                "description": (
                    f"T1027 (obfuscated files or information) was tagged for {path_ref}. "
                    "Compare the binary to vendor packages, check for UPX/packed sections or unexpected ELF/PE sections, "
                    "and review recent package or image updates that could explain the change."
                ),
                "priority": "high",
            }
        )

    if base == "phar.phar" or "/php" in path.replace("\\", "/").lower():
        recs.append(
            {
                "title": "Validate PHP Phar stub integrity",
                "description": (
                    f"{path_ref} is commonly installed with PHP as the `phar` CLI stub. "
                    "If it was not expected on this host, compare hash and size to the same package version on a clean peer; "
                    "review PHP packages (`php-cli` / `php-common`) for unauthorized downgrades or replacements."
                ),
                "priority": "medium",
            }
        )

    if not hash_bits and "T1027" not in mitre and base != "phar.phar":
        recs.append(
            {
                "title": "Contain if tampering is confirmed",
                "description": (
                    f"If {path_ref} differs from baseline or shows unexpected permissions/owner, snapshot it to secure storage, "
                    "prevent execution where safe, and isolate the host pending deeper forensics."
                ),
                "priority": "medium",
            }
        )

    return recs


def build_ioc_ttp_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    tech = item.get("technique") if isinstance(item.get("technique"), dict) else {}
    tid = str(
        tech.get("technique_id")
        or item.get("technique_id")
        or item.get("mitre_technique")
        or ""
    ).strip().upper()
    tname = str(tech.get("technique_name") or item.get("technique_name") or "").strip()
    label = f"{tid} — {tname}" if tid and tname else (tid or tname or "reported MITRE technique")

    recs: List[Dict[str, str]] = [
        {
            "title": f"Confirm {label} with primary evidence",
            "description": (
                "Pull process, file, auth, and network telemetry for the detection window; map the technique to concrete artifacts "
                "(binary path, registry key, service name, firewall rule, or log line) before remediation."
            ),
            "priority": "high",
        },
        {
            "title": "Apply mitigations mapped to this TTP",
            "description": (
                f"Use MITRE mitigations for {tid or 'the technique'} and prioritize controls that break the observed stage "
                "(execution, persistence, credential access, or command and control)."
            ),
            "priority": "medium",
        },
    ]

    if tid == "T1027":
        recs.insert(
            0,
            {
                "title": "Inspect payloads for packing or staging",
                "description": "Look for decode/decompress steps, dropped second stages, and retrieval via curl/wget/mshta; compare suspicious files to known-good baselines.",
                "priority": "high",
            },
        )

    return recs


def build_ioc_process_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    proc = item.get("process") if isinstance(item.get("process"), dict) else {}
    exe = str(proc.get("exe") or "").strip()
    pid = proc.get("pid")
    name = str(proc.get("name") or "").strip()
    ctx_parts = [p for p in (name, exe if exe else None, f"PID {pid}" if pid is not None else None) if p]
    ctx = ", ".join(ctx_parts) if ctx_parts else "the flagged process"

    return [
        {
            "title": "Capture live process context",
            "description": (
                f"For {ctx}: record parent PID, user, open files/sockets, and loaded modules; dump `/proc/<pid>/cmdline` (Linux) "
                "or Process Explorer-equivalent data before termination."
            ),
            "priority": "high",
        },
        {
            "title": "Search for persistence tied to this executable",
            "description": "Enumerate systemd units, cron, shell profiles, and scheduled tasks referencing the same path or hash.",
            "priority": "medium",
        },
    ]


def build_ioc_network_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    rip = str(item.get("remote_ip") or item.get("ip") or item.get("destination_ip") or "").strip()
    rdom = str(item.get("remote_domain") or item.get("domain") or "").strip()
    rport = item.get("remote_port") or item.get("port")
    proc = str(item.get("process_name") or "").strip()
    pid = item.get("process_pid")

    host = rip or rdom
    if host and rport is not None and str(rport).strip():
        endpoint = f"{host}:{rport}"
    elif host:
        endpoint = host
    elif rport is not None and str(rport).strip():
        endpoint = f"destination port {rport}"
    else:
        endpoint = "the remote endpoint"

    owner = ""
    if proc or pid is not None:
        owner = f" Owning process: {proc or 'unknown'}" + (f" (PID {pid})" if pid is not None else "") + "."

    return [
        {
            "title": f"Investigate traffic to {endpoint}",
            "description": (
                f"Identify the local process and user responsible, retain DNS/proxy/firewall logs for the session, and block or sinkhole "
                f"{endpoint} if policy allows.{owner}"
            ),
            "priority": "high",
        },
        {
            "title": "Hunt the same indicator elsewhere",
            "description": (
                "Search SIEM/EDR for the same IP, domain, JA3/SNI, or URI pattern across hosts and time windows to find lateral movement or shared C2."
            ),
            "priority": "medium",
        },
    ]


def build_ioc_memory_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    pid = item.get("pid") or item.get("process_pid")
    proc = str(item.get("process_name") or item.get("name") or "").strip()
    mr = item.get("memory_region") or item.get("memoryRegion")
    region = ""
    if isinstance(mr, dict):
        region = str(mr.get("name") or mr.get("base") or mr.get("start") or "").strip()
    elif mr is not None:
        region = str(mr).strip()
    if not region:
        region = str(item.get("region") or "").strip()
    ctx = ", ".join([p for p in (proc, f"PID {pid}" if pid is not None else None, region) if p]) or "the affected memory region"

    return [
        {
            "title": "Correlate memory signal with on-disk and network IOCs",
            "description": (
                f"For {ctx}: capture a targeted memory dump if policy permits, map suspicious regions to modules on disk, "
                "and check for matching C2 or file IoCs in the same timeframe."
            ),
            "priority": "high",
        },
        {
            "title": "Plan containment if injection is confirmed",
            "description": "Isolate the host, terminate only after evidence collection, and rebuild if kernel or critical services are impacted.",
            "priority": "medium",
        },
    ]


def get_ioc_file_audience_lead(item: Dict[str, Any]) -> str:
    """
    Opening narrative for per-file IOC threat descriptions (not the generic single sentence).
    """
    ft = str(item.get("finding_type") or item.get("findingType") or "").strip().lower()
    path = _ioc_item_file_path(item)
    path_disp = path if len(path) <= 200 else path[:197] + "…"
    path_ref = f"`{path_disp}`" if path_disp else "this path"

    if ft == "high_entropy":
        return (
            f"High-entropy data at {path_ref} often indicates packed or encrypted payloads, embedded secrets, or compressed blobs—"
            "patterns attackers hide in web roots and product lib trees. Legitimate vendor JARs, installers, and PDFs can still "
            "trip entropy heuristics, so confirm against package inventory, build artifacts, and signing before you clear the alert."
        )
    if ft in ("yara_match", "webshell"):
        return (
            f"A YARA or webshell rule matched {path_ref}. Signatures encode byte-level patterns tied to malware and post-exploitation tooling—"
            "stronger than path alone. Validate with EDR/AV, hash reputation, and the owning service; if confirmed, assume active or prior compromise."
        )
    if ft == "suspicious_location":
        return (
            f"The file lives in a location commonly abused for staging or execution ({path_ref}). "
            "Attackers drop webshells and loaders where the HTTP or app user can read/execute them. "
            "Verify the path against your deploy pipeline, container image layers, and change tickets."
        )
    if ft == "ioc_match":
        im = item.get("ioc_match") if isinstance(item.get("ioc_match"), dict) else {}
        ind = im.get("indicator") if isinstance(im.get("indicator"), dict) else {}
        itype = str(ind.get("type") or "").strip().lower() or "indicator"
        return (
            f"Threat-intel matched {path_ref} via a `{itype}` IoC. That ties the object to a feed or campaign—not just local heuristics. "
            "Correlate with auth, process, and network telemetry in the same window; rotate credentials if the file sits beside secrets or SSH material."
        )

    return (
        f"File IoC on {path_ref}: treat as suspicious until reconciled with your golden image, package manager, or CI artifacts. "
        "Attackers routinely plant payloads alongside legitimate apps; unexpected mtimes, owners, or hashes warrant deeper triage."
    )


def get_ioc_ttp_audience_lead(item: Dict[str, Any]) -> str:
    """Context-specific MITRE TTP narrative for descriptions and threat impact."""
    tech = item.get("technique") if isinstance(item.get("technique"), dict) else {}
    tid = str(tech.get("technique_id") or item.get("technique_id") or "").strip().upper()
    tname = str(tech.get("technique_name") or item.get("technique_name") or "").strip()
    label = f"{tid} — {tname}" if tid and tname else (tid or tname or "MITRE ATT&CK technique")

    base = tid.split(".")[0] if tid else ""
    narratives: Dict[str, str] = {
        "T1110": (
            "Credential access via guessing, spraying, or brute force against exposed services. "
            "Winning attempts yield the same rights as the broken account—often SSH/RDP or SaaS admin—then lateral movement and persistence follow quickly."
        ),
        "T1078": (
            "Use of legitimate credentials: attackers reuse stolen passwords, tokens, or sessions instead of exploiting a CVE. "
            "Correlate with impossible travel, new device fingerprints, and privilege changes."
        ),
        "T1059": (
            "Command and scripting interpreter abuse—PowerShell, bash, Python, etc.—is how operators run payloads after access. "
            "Benign automation uses the same primitives; judge by parent process, user context, and outbound connections."
        ),
        "T1190": (
            "Exploitation of public-facing applications: Internet-exposed bugs become initial access. "
            "Patch urgently, review WAF/proxy logs, and assume downstream credential theft if the app touched identity stores."
        ),
        "T1021": (
            "Remote services abuse for lateral movement—RDP, SSH, WinRM, SMB. "
            "Often follows credential theft; hunt for new sessions from unusual sources and interactive logons to tier-zero assets."
        ),
    }
    body = narratives.get(base, (
        "ATT&CK labels real adversary tradecraft. A lone signal may be noise; combined with authentication anomalies, new binaries, "
        "or data exfiltration it describes where to hunt next in logs and EDR."
    ))
    return f"This activity maps to {label}. {body}"


def build_ioc_persistence_item_recommendations(item: Dict[str, Any]) -> List[Dict[str, str]]:
    loc = str(
        item.get("location")
        or item.get("file_path")
        or item.get("filePath")
        or item.get("path")
        or ""
    ).strip()
    ptype = str(item.get("persistence_type") or item.get("persistenceType") or item.get("type") or "").strip()
    loc_ref = f"`{loc}`" if loc else "the persistence entry"

    return [
        {
            "title": f"Remove or disable {ptype or 'persistence'} safely",
            "description": (
                f"Document {loc_ref}, disable the mechanism (service unit, cron, WMI, Run key, etc.), and verify it does not respawn after reboot."
            ),
            "priority": "high",
        },
        {
            "title": "Hunt parallel persistence",
            "description": "After removal, scan for duplicate entries, shadow copies, or other users' profiles referencing the same payload path.",
            "priority": "medium",
        },
    ]


def build_ioc_bucket_description(kind: str, count: int, preview: Optional[List[str]] = None) -> str:
    """
    Human-friendly bucket descriptions (avoid the generic 'Detected N ...').
    """
    k = (kind or "").strip().lower()
    p = preview or []
    if k == "persistence":
        example = p[0] if p else None
        suffix = f" Example: {example}" if example else ""
        return (
            f"Detected {count} persistence indicator(s). Persistence is a post-exploitation technique: "
            f"it allows an attacker to regain access after reboot or credential rotation by re-launching malware or backdoors. "
            f"This significantly increases the attacker's dwell time and makes eradication more difficult. "
            f"Immediately investigate and remove identified persistence mechanisms."
            f"{suffix}"
        )
    if k == "process":
        return (
            f"Detected {count} suspicious process indicator(s). Suspicious process behavior can indicate malware execution, "
            f"process injection, credential theft, or living-off-the-land (LOLBin) attacks. "
            f"Attackers often use legitimate system binaries to evade detection. "
            f"Validate processes, check parent processes, verify executable origins, and review command-line arguments for anomalies."
        )
    if k == "network":
        return (
            f"Detected {count} suspicious network indicator(s). Suspicious network connections can indicate command-and-control (C2) "
            f"activity, data exfiltration, or lateral movement. Attackers use C2 channels to execute commands, steal data, and "
            f"maintain persistent access. Correlate destinations with process owners, review DNS/proxy logs, and block suspicious "
            f"IPs/domains immediately."
        )
    if k == "file":
        return (
            f"Detected {count} suspicious file indicator(s). Suspicious files can indicate dropped malware payloads, modified "
            f"system binaries, webshells, or other post-exploitation tooling. Attackers often place files in writable locations "
            f"like /tmp, /var/tmp, or user directories. Validate file signatures, compare hashes against known-good baselines, "
            f"and check file modification times for anomalies."
        )
    if k == "memory":
        return (
            f"Detected {count} suspicious memory finding(s). Memory-based indicators can reveal process injection, shellcode "
            f"execution, or credential theft. Attackers often inject malicious code into legitimate processes to evade detection. "
            f"Review memory dumps, check for suspicious process memory regions, and correlate with process findings."
        )
    if k == "ttp":
        return (
            f"Detected {count} MITRE ATT&CK TTP(s). Tactics, Techniques, and Procedures (TTPs) represent specific attack methods "
            f"used by adversaries. Multiple TTPs may indicate an advanced persistent threat (APT) or sophisticated attack campaign. "
            f"Review each TTP finding for specific attack techniques and recommended mitigations."
        )
    if k == "log":
        return (
            f"Detected {count} suspicious log indicator(s). Log analysis reveals attack patterns, authentication failures, "
            f"and system anomalies. Review log findings for specific attack vectors, source IPs, and recommended actions."
        )
    return (
        f"Detected {count} {k} indicator(s). Indicators of compromise (IOCs) are signals of potential malicious activity. "
        f"Review individual findings for specific threats and recommended remediation steps."
    )


def get_ioc_finding_type_legend(finding_type: str) -> str:
    """
    Short, user-facing explanation of IOC file finding_type codes (shown in Threat UI).
    """
    ft = (finding_type or "").strip().lower()
    legends: Dict[str, str] = {
        "high_entropy": (
            "Shannon entropy of the file body is high (often ~7–8 bits/byte): the bytes look random. "
            "That usually means compression, encryption, packing, embedded secrets, or dense binary formats—not automatically malware. "
            "Examples: packed ELF/PE, encrypted configs, JAR/ZIP contents, PDF streams; many vendor JARs also score high. "
            "Confirm with package ownership (dpkg/rpm), expected hash, and change tickets."
        ),
        "yara_match": (
            "A YARA rule matched byte patterns in this file—stronger than entropy alone. "
            "Validate with AV/EDR, hash reputation, and whether the path belongs to a known package."
        ),
        "webshell": (
            "Heuristics or signatures suggest web-shell traits (eval/base64/obfuscation patterns). "
            "Correlate with web logs, deploy artifacts, and whether the file is in a web root you expect."
        ),
        "suspicious_location": (
            "The path is in a directory commonly abused for web uploads or execution (e.g. under document roots or /tmp). "
            "Legitimate apps sometimes land here—verify against your deploy pipeline and image."
        ),
        "ioc_match": (
            "A threat-intel indicator (hash/domain/…) matched this object. "
            "Correlate with timeline and other telemetry before treating as active compromise."
        ),
        "suspicious_hash": (
            "File hash appears on a blocklist or internal deny list. "
            "Re-check false positives from shared installers; rotate secrets if the file touched sensitive areas."
        ),
    }
    return legends.get(ft, "")


def build_ioc_evidence_preview(kind: str, items_preview: List[str], items_count: int) -> Dict[str, Any]:
    """
    Compact evidence so UI shows something useful (strings), instead of `[object]`.
    """
    k = (kind or "").strip().lower()
    return {
        "source": f"ioc_scanner.{k}",
        "items_count": int(items_count),
        "items_preview": items_preview[:12],
    }


def _ioc_preview_line_to_fs_path(raw: str) -> str:
    """
    Map preview lines like 'path=/opt/foo/bar | type=high_entropy' to a real filesystem path for shell quoting.
    """
    s = str(raw).strip().split("\n", 1)[0].strip()
    if not s or s.startswith("#"):
        return ""
    if s.startswith("path="):
        rest = s[5:].strip()
        if " | " in rest:
            rest = rest.split(" | ", 1)[0].strip()
        return rest.strip()
    if s.startswith("/"):
        if " | " in s:
            return s.split(" | ", 1)[0].strip()
        return s.strip()
    return ""


def get_ioc_bucket_exploitation_commands(kind: str, items_preview: Optional[List[str]] = None) -> List[str]:
    """
    Read-only verification commands per bucket.
    Keep these safe; do not include destructive actions.
    """
    k = (kind or "").strip().lower()
    p = items_preview or []

    if k in ("summary", "ioc", "ioc_summary"):
        return [
            "# IOC quick triage (Linux) — high-signal starting points",
            "date; hostname; whoami; uname -a",
            "uptime; w; last -n 20 2>/dev/null || true",
            "ps auxww --sort=-%mem | head -n 25",
            "ps auxww --sort=-%cpu | head -n 25",
            "ss -tulpn 2>/dev/null | head -n 200",
            "ss -tpn state established 2>/dev/null | head -n 200",
            "journalctl -p warning..alert -n 200 --no-pager 2>/dev/null || true",
            "sudo journalctl -u ssh -n 200 --no-pager 2>/dev/null || true",
        ]

    if k == "process":
        _pid_in_preview = re.compile(r"\bpid=(\d+)\b", re.I)
        pids_ordered: List[str] = []
        seen_pid: Set[str] = set()
        for raw in p:
            s = str(raw).strip() if raw is not None else ""
            if not s:
                continue
            for m in _pid_in_preview.finditer(s):
                g = m.group(1)
                if g not in seen_pid:
                    seen_pid.add(g)
                    pids_ordered.append(g)
            first_tok = s.split(None, 1)[0] if s else ""
            if first_tok.isdigit() and first_tok not in seen_pid:
                seen_pid.add(first_tok)
                pids_ordered.append(first_tok)
        pids_ordered = pids_ordered[:12]

        cmds = [
            "# Process triage — inspect suspicious processes and parents",
            "ps auxwwf | head -n 200",
            "pstree -ap 2>/dev/null | head -n 200 || true",
            "ps -eo pid,ppid,user,%cpu,%mem,etime,cmd --sort=-%mem | head -n 35",
            "# For a specific PID: ls -l /proc/<PID>/exe ; tr '\\0' ' ' </proc/<PID>/cmdline ; lsof -p <PID> | head",
        ]
        for pid in pids_ordered[:8]:
            cmds.extend(
                [
                    f"# IOC PID from scan: {pid}",
                    f"ps -p {pid} -o pid,ppid,user,etime,cmd 2>/dev/null || true",
                    f"tr '\\0' ' ' </proc/{pid}/cmdline 2>/dev/null; echo",
                    f"readlink /proc/{pid}/exe 2>/dev/null || true",
                    f"command -v lsof >/dev/null && lsof -p {pid} 2>/dev/null | head -n 40 || true",
                ]
            )
        return cmds

    if k == "network":
        cmds = [
            "# Network triage — map connections to owning processes",
            "ss -tpn state established 2>/dev/null | head -n 200",
            "ss -tpn state connected 2>/dev/null | head -n 200",
            "lsof -nP -iTCP -sTCP:ESTABLISHED 2>/dev/null | head -n 200 || true",
            "ip route 2>/dev/null | head -n 200 || true",
            "cat /etc/resolv.conf 2>/dev/null || true",
        ]
        for raw in p[:8]:
            hint = str(raw).strip()
            if not hint or "occurrences" in hint.lower():
                continue
            if ":" in hint or hint.replace(".", "").isdigit():
                cmds.append(f"# Hint: filter for endpoint substring\nss -tpn 2>/dev/null | grep -F {shlex.quote(hint[:64])} | head -n 50 || true")
        return cmds

    if k == "file":
        cmds = [
            "# File triage — validate suspicious paths, hashes, permissions, and provenance",
            "ls -la /tmp /var/tmp /dev/shm 2>/dev/null | head -n 200 || true",
            "find /tmp /var/tmp /dev/shm -maxdepth 2 -type f -ls 2>/dev/null | head -n 120 || true",
            "# For a specific file: ls -la <PATH>; stat <PATH>; sha256sum <PATH>; file <PATH>; strings -n 6 <PATH> | head",
        ]
        for raw in p[:10]:
            raw_s = str(raw).strip().split("\n", 1)[0].strip()
            if not raw_s or raw_s.startswith("#"):
                continue
            path = _ioc_preview_line_to_fs_path(raw_s) or raw_s
            if not path.startswith("/") and not path.startswith("./"):
                continue
            qp = shlex.quote(path)
            cmds.extend(
                [
                    f"# IOC path from scan: {path}",
                    f"ls -la {qp} 2>/dev/null || true",
                    f"stat {qp} 2>/dev/null || true",
                    f"sha256sum {qp} 2>/dev/null || shasum -a 256 {qp} 2>/dev/null || true",
                    f"file {qp} 2>/dev/null || true",
                ]
            )
        return cmds

    if k == "log":
        # Show high-signal grep suggestions; actual vectors depend on distro/log paths.
        cmds: List[str] = [
            "# Log triage — confirm patterns and look for successful access",
            "sudo tail -n 200 /var/log/auth.log 2>/dev/null || true",
            "sudo tail -n 200 /var/log/syslog 2>/dev/null || true",
            "sudo grep -Ei \"Failed password|Invalid user|Accepted publickey|session opened for user root|POSSIBLE BREAK-IN\" /var/log/auth.log 2>/dev/null | tail -n 200 || true",
            "sudo grep -Ei \"Out of memory|Killed process\" /var/log/syslog 2>/dev/null | tail -n 200 || true",
        ]
        # If we have preview strings, add a hint to search for the top one.
        if p:
            hint = str(p[0]).split("occurrences", 1)[0].strip()
            if hint:
                cmds.append(f"# Hint: search for vector text\nsudo grep -F \"{hint}\" /var/log/auth.log /var/log/syslog 2>/dev/null | tail -n 200 || true")
        return cmds

    if k in ("ssh_bruteforce", "ssh brute force", "invalid ssh user"):
        cmds: List[str] = [
            "# SSH brute force investigation — identify attackers and check for successful access",
            "# Check recent failed login attempts",
            "sudo grep -Ei \"Failed password|Invalid user\" /var/log/auth.log 2>/dev/null | tail -n 500 || true",
            "# Check for successful logins from suspicious IPs",
            "sudo grep -Ei \"Accepted\" /var/log/auth.log 2>/dev/null | tail -n 200 || true",
            "# Count unique attacking IPs",
            "sudo grep -oE 'from [0-9.]+' /var/log/auth.log 2>/dev/null | sort | uniq -c | sort -rn | head -n 20 || true",
            "# Check for new user accounts",
            "cut -d: -f1 /etc/passwd | sort",
            "# Check authorized_keys for suspicious entries",
            "sudo find /home /root -name authorized_keys -exec ls -la {} \\; 2>/dev/null || true",
            "# Check current SSH connections",
            "ss -tnp | grep :22 || netstat -tnp | grep :22 || true",
            "# Block specific IP (example: replace 1.2.3.4 with actual IP)",
            "# sudo iptables -A INPUT -s 1.2.3.4 -j DROP",
            "# sudo ufw deny from 1.2.3.4",
        ]
        return cmds

    if k in ("oom killer", "out of memory"):
        cmds: List[str] = [
            "# OOM killer investigation — identify processes and memory usage",
            "# Check OOM killer events",
            "sudo grep -Ei \"Out of memory|Killed process|oom-killer\" /var/log/syslog /var/log/kern.log 2>/dev/null | tail -n 200 || true",
            "# Check current memory usage",
            "free -h",
            "cat /proc/meminfo | grep -E 'MemTotal|MemFree|MemAvailable|SwapTotal|SwapFree'",
            "# Top memory consumers",
            "ps aux --sort=-%mem | head -n 20",
            "ps aux --sort=-%cpu | head -n 20",
            "# Check system load",
            "uptime",
            "cat /proc/loadavg",
            "# Check for memory leaks (monitor over time)",
            "# watch -n 5 'ps aux --sort=-%mem | head -n 10'",
            "# Check dmesg for OOM messages",
            "dmesg | grep -i oom | tail -n 50 || true",
        ]
        return cmds

    if k == "persistence":
        cmds: List[str] = [
            "# Persistence verification (Linux) — enumerate common autorun mechanisms",
            "systemctl list-unit-files --type=service --no-pager 2>/dev/null | head -n 200",
            "systemctl list-timers --all --no-pager 2>/dev/null | head -n 200",
            "crontab -l 2>/dev/null || true",
            "ls -la /etc/cron.* /etc/crontab 2>/dev/null || true",
            "find /etc/systemd/system /lib/systemd/system -maxdepth 2 -type f -name '*.service' 2>/dev/null | head -n 120",
            "ls -la /etc/rc.local /etc/init.d 2>/dev/null || true",
            "find /etc -maxdepth 3 -type f \\( -name '*.profile' -o -name '*.bashrc' -o -name '*.bash_profile' \\) 2>/dev/null | head -n 120",
        ]
        return [c for c in cmds if isinstance(c, str) and c.strip()]

    if k == "memory":
        cmds: List[str] = [
            "# Memory analysis — check for process injection and suspicious memory regions",
            "# Check current memory usage",
            "free -h",
            "cat /proc/meminfo | grep -E 'MemTotal|MemFree|MemAvailable|SwapTotal|SwapFree'",
            "# Top memory consumers",
            "ps aux --sort=-%mem | head -n 20",
            "ps aux --sort=-%cpu | head -n 20",
            "# Check for suspicious processes with high memory usage",
            "ps aux --sort=-%mem | awk '$6 > 1000000 {print}' | head -n 20",
            "# Check /proc for process memory maps (example for PID)",
            "# cat /proc/<PID>/maps | head -n 50",
            "# Check for memory leaks",
            "# watch -n 5 'ps aux --sort=-%mem | head -n 10'",
        ]
        return cmds

    if k == "ttp":
        _ttp_id_re = re.compile(r"\b(T\d{4,5}(?:\.\d{3})?)\b", re.I)
        _pid_ev_re = re.compile(r"\bPID\s+(\d+)\b", re.I)
        pids_ordered: List[str] = []
        seen_pid: Set[str] = set()
        technique_ids: List[str] = []
        seen_tid: Set[str] = set()
        for raw in p:
            s = str(raw).strip() if raw is not None else ""
            if not s:
                continue
            for m in _ttp_id_re.finditer(s):
                tid = m.group(1).upper()
                if tid not in seen_tid:
                    seen_tid.add(tid)
                    technique_ids.append(tid)
            for m in _pid_ev_re.finditer(s):
                g = m.group(1)
                if g not in seen_pid:
                    seen_pid.add(g)
                    pids_ordered.append(g)

        cmds: List[str] = [
            "# TTP investigation — analyze detected MITRE ATT&CK techniques",
            "# Review system logs for TTP-related activity",
            "sudo journalctl -p warning..alert -n 500 --no-pager 2>/dev/null || true",
            "# Check for suspicious process trees",
            "pstree -ap 2>/dev/null | head -n 200 || true",
            "# Review network connections for C2 indicators",
            "ss -tpn state established 2>/dev/null | head -n 200",
            "ss -tulpn 2>/dev/null | head -n 200",
            "# Check for file modifications in suspicious locations",
            "find /tmp /var/tmp /dev/shm -type f -mtime -1 -ls 2>/dev/null | head -n 100 || true",
            "# Review authentication logs",
            "sudo tail -n 500 /var/log/auth.log 2>/dev/null || true",
            "# Check for persistence mechanisms",
            "systemctl list-unit-files --type=service --no-pager 2>/dev/null | grep -E 'enabled|disabled' | head -n 100",
            "crontab -l 2>/dev/null || true",
        ]
        if any(t == "T1190" for t in technique_ids) or any("T1190" in str(x) for x in p):
            cmds.extend(
                [
                    "# T1190 — public-facing app abuse: map listeners, parent/child shells, Java/web tier",
                    "ps auxwwf | grep -E '[j]ava|[n]ginx|[h]ttpd|[a]pache|[t]omcat|[c]atalina' | head -n 60 || true",
                    "# Inspect a suspicious PID (cmdline, exe, maps)",
                    "# tr '\\0' ' ' </proc/<PID>/cmdline; readlink /proc/<PID>/exe; head -n 40 /proc/<PID>/maps",
                ]
            )
        for tid in technique_ids[:4]:
            if "." in tid:
                main, sub = tid.split(".", 1)
                u = f"https://attack.mitre.org/techniques/{main}/{sub}/"
            else:
                u = f"https://attack.mitre.org/techniques/{tid}/"
            cmds.append(f"# MITRE reference: {tid}")
            cmds.append(f"# xdg-open '{u}' 2>/dev/null || true  # or open in browser")
        for pid in pids_ordered[:8]:
            cmds.extend(
                [
                    f"# Evidence PID from TTP rollup: {pid}",
                    f"ps -p {pid} -o pid,ppid,user,etime,cmd 2>/dev/null || true",
                    f"tr '\\0' ' ' </proc/{pid}/cmdline 2>/dev/null; echo",
                    f"readlink /proc/{pid}/exe 2>/dev/null || true",
                    f"command -v lsof >/dev/null && lsof -p {pid} 2>/dev/null | head -n 40 || true",
                ]
            )
        return cmds

    return get_ioc_bucket_exploitation_commands("summary", p)

