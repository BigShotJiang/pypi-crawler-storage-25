"""IOC Scanner databases and constants."""

from typing import Any, Dict, List, Set
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from ...proto import (
    IoCType, SeverityLevel, ConfidenceLevel, ThreatCategory, FeedFormat,
    FeedSource, ProcessInjectionType, PersistenceType, NetworkProtocol,
    MitreTactic, ScanStatus, ActionTaken,
)

# MITRE ATT&CK Techniques Database
MITRE_TECHNIQUES: Dict[str, Dict[str, Any]] = {
    # Initial Access
    "T1190": {
        "name": "Exploit Public-Facing Application",
        "tactic": MitreTactic.INITIAL_ACCESS,
        "description": "Adversaries may exploit vulnerabilities in internet-facing applications",
        "data_sources": ["Application Log", "Network Traffic"],
        "url": "https://attack.mitre.org/techniques/T1190/",
        "platforms": ["Linux", "Windows", "macOS", "Containers"],
        "detection": (
            "Look for unexpected child processes (shells, interpreters) spawned by web or app runtimes; "
            "correlate with WAF/reverse-proxy and application logs for exploit-like requests."
        ),
        "mitigation": (
            "Patch and harden public-facing services; restrict egress; use WAF/RASP where appropriate; "
            "avoid running app servers as root; disable debug endpoints (e.g. JDWP) in production."
        ),
    },
    "T1133": {
        "name": "External Remote Services",
        "tactic": MitreTactic.INITIAL_ACCESS,
        "description": "Adversaries may leverage external-facing remote services to initially access a network",
        "data_sources": ["Authentication Logs", "Network Traffic"],
    },
    "T1566": {
        "name": "Phishing",
        "tactic": MitreTactic.INITIAL_ACCESS,
        "description": "Adversaries may send phishing messages to gain access to victim systems",
        "data_sources": ["Email Gateway", "Network Traffic"],
    },
    
    # Execution
    "T1059": {
        "name": "Command and Scripting Interpreter",
        "tactic": MitreTactic.EXECUTION,
        "description": "Adversaries may abuse command and script interpreters to execute commands",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
        "sub_techniques": {
            "001": "PowerShell",
            "003": "Windows Command Shell",
            "004": "Unix Shell",
            "005": "Visual Basic",
            "006": "Python",
            "007": "JavaScript",
        }
    },
    "T1053": {
        "name": "Scheduled Task/Job",
        "tactic": MitreTactic.EXECUTION,
        "description": "Adversaries may abuse task scheduling functionality",
        "data_sources": ["Process Monitoring", "File Monitoring"],
        "sub_techniques": {
            "003": "Cron",
            "005": "Scheduled Task",
        }
    },
    "T1204": {
        "name": "User Execution",
        "tactic": MitreTactic.EXECUTION,
        "description": "Adversary relies on user to execute malicious payload",
        "data_sources": ["Process Monitoring", "File Monitoring"],
    },
    
    # Persistence
    "T1547": {
        "name": "Boot or Logon Autostart Execution",
        "tactic": MitreTactic.PERSISTENCE,
        "description": "Adversaries may configure system settings to automatically execute a program during boot/logon",
        "data_sources": ["Registry", "File Monitoring"],
        "sub_techniques": {
            "001": "Registry Run Keys / Startup Folder",
            "004": "Winlogon Helper DLL",
            "006": "Kernel Modules and Extensions",
        }
    },
    "T1543": {
        "name": "Create or Modify System Process",
        "tactic": MitreTactic.PERSISTENCE,
        "description": "Adversaries may create or modify system-level processes",
        "data_sources": ["Process Monitoring", "Service Monitoring"],
        "sub_techniques": {
            "001": "Launch Agent",
            "002": "Systemd Service",
            "003": "Windows Service",
        }
    },
    "T1136": {
        "name": "Create Account",
        "tactic": MitreTactic.PERSISTENCE,
        "description": "Adversaries may create accounts to maintain access",
        "data_sources": ["Authentication Logs", "Process Monitoring"],
    },
    "T1505": {
        "name": "Server Software Component",
        "tactic": MitreTactic.PERSISTENCE,
        "description": "Adversaries may abuse legitimate extensible development features",
        "data_sources": ["File Monitoring", "Process Monitoring"],
        "sub_techniques": {
            "003": "Web Shell",
        }
    },
    
    # Privilege Escalation
    "T1548": {
        "name": "Abuse Elevation Control Mechanism",
        "tactic": MitreTactic.PRIVILEGE_ESCALATION,
        "description": "Adversaries may circumvent mechanisms designed to control elevated privileges",
        "data_sources": ["Process Monitoring", "File Monitoring"],
        "sub_techniques": {
            "001": "Setuid and Setgid",
            "002": "Bypass User Account Control",
            "003": "Sudo and Sudo Caching",
        }
    },
    "T1068": {
        "name": "Exploitation for Privilege Escalation",
        "tactic": MitreTactic.PRIVILEGE_ESCALATION,
        "description": "Adversaries may exploit software vulnerabilities to elevate privileges",
        "data_sources": ["Process Monitoring", "Application Logs"],
    },
    
    # Defense Evasion
    "T1070": {
        "name": "Indicator Removal",
        "tactic": MitreTactic.DEFENSE_EVASION,
        "description": "Adversaries may delete or modify artifacts generated on a host system",
        "data_sources": ["File Monitoring", "Process Monitoring"],
        "sub_techniques": {
            "001": "Clear Windows Event Logs",
            "002": "Clear Linux or Mac System Logs",
            "003": "Clear Command History",
            "004": "File Deletion",
        }
    },
    "T1055": {
        "name": "Process Injection",
        "tactic": MitreTactic.DEFENSE_EVASION,
        "description": "Adversaries may inject code into processes to evade detection",
        "data_sources": ["Process Monitoring", "DLL Monitoring"],
        "sub_techniques": {
            "001": "Dynamic-link Library Injection",
            "002": "Portable Executable Injection",
            "003": "Thread Execution Hijacking",
            "004": "Asynchronous Procedure Call",
            "012": "Process Hollowing",
        }
    },
    "T1036": {
        "name": "Masquerading",
        "tactic": MitreTactic.DEFENSE_EVASION,
        "description": "Adversaries may attempt to manipulate features to make their malicious behavior appear legitimate",
        "data_sources": ["File Monitoring", "Process Monitoring"],
        "sub_techniques": {
            "003": "Rename System Utilities",
            "004": "Masquerade Task or Service",
            "005": "Match Legitimate Name or Location",
        }
    },
    "T1027": {
        "name": "Obfuscated Files or Information",
        "tactic": MitreTactic.DEFENSE_EVASION,
        "description": "Adversaries may obfuscate files or information to make detection difficult",
        "data_sources": ["File Monitoring", "Process Monitoring"],
    },
    "T1014": {
        "name": "Rootkit",
        "tactic": MitreTactic.DEFENSE_EVASION,
        "description": "Adversaries may use rootkits to hide the presence of programs, files, network connections",
        "data_sources": ["BIOS", "MBR", "System calls"],
    },
    
    # Credential Access
    "T1003": {
        "name": "OS Credential Dumping",
        "tactic": MitreTactic.CREDENTIAL_ACCESS,
        "description": "Adversaries may attempt to dump credentials from OS",
        "data_sources": ["Process Monitoring", "PowerShell Logs"],
        "sub_techniques": {
            "001": "LSASS Memory",
            "002": "Security Account Manager",
            "003": "/etc/passwd and /etc/shadow",
            "006": "DCSync",
            "007": "Proc Filesystem",
            "008": "/etc/passwd and /etc/shadow",
        }
    },
    "T1552": {
        "name": "Unsecured Credentials",
        "tactic": MitreTactic.CREDENTIAL_ACCESS,
        "description": "Adversaries may search for unsecured credentials",
        "data_sources": ["File Monitoring", "Process Monitoring"],
        "sub_techniques": {
            "001": "Credentials In Files",
            "004": "Private Keys",
        }
    },
    "T1110": {
        "name": "Brute Force",
        "tactic": MitreTactic.CREDENTIAL_ACCESS,
        "description": "Adversaries may use brute force techniques to gain access",
        "data_sources": ["Authentication Logs", "Network Traffic"],
    },
    
    # Discovery
    "T1083": {
        "name": "File and Directory Discovery",
        "tactic": MitreTactic.DISCOVERY,
        "description": "Adversaries may enumerate files and directories",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
    },
    "T1057": {
        "name": "Process Discovery",
        "tactic": MitreTactic.DISCOVERY,
        "description": "Adversaries may attempt to get information about running processes",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
    },
    "T1049": {
        "name": "System Network Connections Discovery",
        "tactic": MitreTactic.DISCOVERY,
        "description": "Adversaries may attempt to get a listing of network connections",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
    },
    "T1082": {
        "name": "System Information Discovery",
        "tactic": MitreTactic.DISCOVERY,
        "description": "Adversaries may attempt to get detailed information about the OS and hardware",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
    },
    "T1016": {
        "name": "System Network Configuration Discovery",
        "tactic": MitreTactic.DISCOVERY,
        "description": "Adversaries may look for details about network configuration",
        "data_sources": ["Process Monitoring", "Command-line Logging"],
    },
    
    # Lateral Movement
    "T1021": {
        "name": "Remote Services",
        "tactic": MitreTactic.LATERAL_MOVEMENT,
        "description": "Adversaries may use remote services to move laterally",
        "data_sources": ["Authentication Logs", "Network Traffic"],
        "sub_techniques": {
            "001": "Remote Desktop Protocol",
            "002": "SMB/Windows Admin Shares",
            "004": "SSH",
        }
    },
    "T1570": {
        "name": "Lateral Tool Transfer",
        "tactic": MitreTactic.LATERAL_MOVEMENT,
        "description": "Adversaries may transfer tools or files between systems",
        "data_sources": ["File Monitoring", "Network Traffic"],
    },
    
    # Collection
    "T1560": {
        "name": "Archive Collected Data",
        "tactic": MitreTactic.COLLECTION,
        "description": "Adversary may compress/encrypt data before exfiltration",
        "data_sources": ["File Monitoring", "Process Monitoring"],
    },
    "T1005": {
        "name": "Data from Local System",
        "tactic": MitreTactic.COLLECTION,
        "description": "Adversaries may search local system sources for data of interest",
        "data_sources": ["File Monitoring", "Process Monitoring"],
    },
    "T1039": {
        "name": "Data from Network Shared Drive",
        "tactic": MitreTactic.COLLECTION,
        "description": "Adversaries may search network shares for files of interest",
        "data_sources": ["File Monitoring", "Network Traffic"],
    },
    
    # Command and Control
    "T1071": {
        "name": "Application Layer Protocol",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may communicate using application layer protocols",
        "data_sources": ["Network Traffic", "Process Monitoring"],
        "sub_techniques": {
            "001": "Web Protocols",
            "002": "File Transfer Protocols",
            "003": "Mail Protocols",
            "004": "DNS",
        }
    },
    "T1095": {
        "name": "Non-Application Layer Protocol",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may use non-application layer protocols for C2",
        "data_sources": ["Network Traffic"],
    },
    "T1573": {
        "name": "Encrypted Channel",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may employ encryption to conceal C2 traffic",
        "data_sources": ["Network Traffic", "SSL/TLS Inspection"],
    },
    "T1105": {
        "name": "Ingress Tool Transfer",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may transfer tools from external systems",
        "data_sources": ["Network Traffic", "File Monitoring"],
    },
    "T1571": {
        "name": "Non-Standard Port",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may communicate using non-standard ports",
        "data_sources": ["Network Traffic"],
    },
    "T1572": {
        "name": "Protocol Tunneling",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may tunnel network communications to avoid detection",
        "data_sources": ["Network Traffic"],
    },
    "T1090": {
        "name": "Proxy",
        "tactic": MitreTactic.COMMAND_AND_CONTROL,
        "description": "Adversaries may use proxy to direct network traffic",
        "data_sources": ["Network Traffic"],
    },
    
    # Exfiltration
    "T1041": {
        "name": "Exfiltration Over C2 Channel",
        "tactic": MitreTactic.EXFILTRATION,
        "description": "Adversaries may steal data by exfiltrating over C2 channel",
        "data_sources": ["Network Traffic"],
    },
    "T1048": {
        "name": "Exfiltration Over Alternative Protocol",
        "tactic": MitreTactic.EXFILTRATION,
        "description": "Adversaries may steal data by exfiltrating over a different protocol",
        "data_sources": ["Network Traffic"],
        "sub_techniques": {
            "001": "Exfiltration Over Symmetric Encrypted Non-C2 Protocol",
            "002": "Exfiltration Over Asymmetric Encrypted Non-C2 Protocol",
            "003": "Exfiltration Over Unencrypted Non-C2 Protocol",
        }
    },
    "T1567": {
        "name": "Exfiltration Over Web Service",
        "tactic": MitreTactic.EXFILTRATION,
        "description": "Adversaries may use existing web services to exfiltrate data",
        "data_sources": ["Network Traffic"],
    },
    
    # Impact
    "T1486": {
        "name": "Data Encrypted for Impact",
        "tactic": MitreTactic.IMPACT,
        "description": "Adversaries may encrypt data on target systems (ransomware)",
        "data_sources": ["File Monitoring", "Process Monitoring"],
    },
    "T1489": {
        "name": "Service Stop",
        "tactic": MitreTactic.IMPACT,
        "description": "Adversaries may stop or disable services on a system",
        "data_sources": ["Process Monitoring", "Windows Event Logs"],
    },
    "T1485": {
        "name": "Data Destruction",
        "tactic": MitreTactic.IMPACT,
        "description": "Adversaries may destroy data and files on specific systems",
        "data_sources": ["File Monitoring", "Process Monitoring"],
    },
    "T1496": {
        "name": "Resource Hijacking",
        "tactic": MitreTactic.IMPACT,
        "description": "Adversaries may leverage system resources for cryptomining",
        "data_sources": ["Process Monitoring", "Network Traffic"],
    },
}

# Suspicious file locations
SUSPICIOUS_LOCATIONS: Dict[str, Dict[str, Any]] = {
    # Temp directories
    "/tmp": {"severity": SeverityLevel.LOW, "reason": "World-writable temp directory"},
    "/var/tmp": {"severity": SeverityLevel.LOW, "reason": "Persistent temp directory"},
    "/dev/shm": {"severity": SeverityLevel.MEDIUM, "reason": "RAM-based filesystem, often used by malware"},
    
    # Hidden directories
    "/root/.": {"severity": SeverityLevel.MEDIUM, "reason": "Hidden file in root home"},
    "/home/*/.": {"severity": SeverityLevel.LOW, "reason": "Hidden file in user home"},
    
    # System directories (unexpected executables)
    "/usr/share": {"severity": SeverityLevel.MEDIUM, "reason": "Executables in data directory"},
    "/var/www": {"severity": SeverityLevel.HIGH, "reason": "Potential webshell location"},
    "/var/lib": {"severity": SeverityLevel.MEDIUM, "reason": "Executables in state directory"},
    
    # Cron directories
    "/etc/cron.d": {"severity": SeverityLevel.HIGH, "reason": "Cron job directory - persistence"},
    "/etc/cron.daily": {"severity": SeverityLevel.HIGH, "reason": "Daily cron directory"},
    "/etc/cron.hourly": {"severity": SeverityLevel.HIGH, "reason": "Hourly cron directory"},
    "/var/spool/cron": {"severity": SeverityLevel.HIGH, "reason": "User crontabs"},
    
    # Init/systemd
    "/etc/init.d": {"severity": SeverityLevel.HIGH, "reason": "Init script directory"},
    "/etc/systemd/system": {"severity": SeverityLevel.HIGH, "reason": "Systemd service directory"},
    "/lib/systemd/system": {"severity": SeverityLevel.HIGH, "reason": "Systemd library services"},
    
    # Profile/RC files
    "/etc/profile.d": {"severity": SeverityLevel.HIGH, "reason": "Profile script directory"},
    "/etc/bash.bashrc": {"severity": SeverityLevel.HIGH, "reason": "Global bashrc"},
    "/etc/environment": {"severity": SeverityLevel.HIGH, "reason": "Environment variables"},
    
    # Kernel modules
    "/lib/modules": {"severity": SeverityLevel.CRITICAL, "reason": "Kernel modules directory"},
    
    # SSH
    "/root/.ssh": {"severity": SeverityLevel.HIGH, "reason": "Root SSH directory"},
    "/home/*/.ssh": {"severity": SeverityLevel.MEDIUM, "reason": "User SSH directory"},
}

# Known malicious process patterns
SUSPICIOUS_PROCESS_PATTERNS: List[Dict[str, Any]] = [
    # Reverse shells
    {"pattern": r"nc\s+.*-e\s+/bin/(ba)?sh", "name": "Netcat reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059.004"},
    {"pattern": r"bash\s+-i\s+>&\s+/dev/tcp/", "name": "Bash reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059.004"},
    {"pattern": r"python.*socket.*connect.*exec", "name": "Python reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059.006"},
    {"pattern": r"perl.*socket.*exec", "name": "Perl reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059"},
    {"pattern": r"ruby.*TCPSocket.*exec", "name": "Ruby reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059"},
    {"pattern": r"php.*fsockopen.*exec", "name": "PHP reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059"},
    {"pattern": r"socat\s+.*exec:", "name": "Socat reverse shell", "severity": SeverityLevel.CRITICAL, "ttp": "T1059.004"},
    
    # Data exfiltration
    {"pattern": r"curl.*-d\s+@", "name": "Curl data exfiltration", "severity": SeverityLevel.HIGH, "ttp": "T1048"},
    {"pattern": r"wget.*--post-file", "name": "Wget data exfiltration", "severity": SeverityLevel.HIGH, "ttp": "T1048"},
    {"pattern": r"base64.*\|\s*(curl|wget|nc)", "name": "Encoded data exfiltration", "severity": SeverityLevel.HIGH, "ttp": "T1048"},
    
    # Credential access
    {"pattern": r"cat.*/etc/shadow", "name": "Shadow file access", "severity": SeverityLevel.CRITICAL, "ttp": "T1003.008"},
    {"pattern": r"cat.*/etc/passwd", "name": "Passwd file access", "severity": SeverityLevel.MEDIUM, "ttp": "T1003.008"},
    {"pattern": r"mimikatz", "name": "Mimikatz", "severity": SeverityLevel.CRITICAL, "ttp": "T1003.001"},
    {"pattern": r"secretsdump", "name": "Secretsdump", "severity": SeverityLevel.CRITICAL, "ttp": "T1003"},
    {"pattern": r"LaZagne", "name": "LaZagne credential stealer", "severity": SeverityLevel.CRITICAL, "ttp": "T1552"},
    
    # Discovery
    {"pattern": r"nmap\s+", "name": "Nmap scanning", "severity": SeverityLevel.MEDIUM, "ttp": "T1046"},
    {"pattern": r"masscan\s+", "name": "Masscan scanning", "severity": SeverityLevel.MEDIUM, "ttp": "T1046"},
    {"pattern": r"enum4linux", "name": "Enum4linux", "severity": SeverityLevel.MEDIUM, "ttp": "T1087"},
    {"pattern": r"bloodhound", "name": "BloodHound", "severity": SeverityLevel.HIGH, "ttp": "T1087.002"},
    
    # Lateral movement tools
    {"pattern": r"psexec", "name": "PsExec", "severity": SeverityLevel.HIGH, "ttp": "T1570"},
    {"pattern": r"wmiexec", "name": "WMIExec", "severity": SeverityLevel.HIGH, "ttp": "T1047"},
    {"pattern": r"smbexec", "name": "SMBExec", "severity": SeverityLevel.HIGH, "ttp": "T1021.002"},
    {"pattern": r"crackmapexec|cme", "name": "CrackMapExec", "severity": SeverityLevel.HIGH, "ttp": "T1021.002"},
    
    # Cryptominers
    {"pattern": r"xmrig|minerd|cgminer|bfgminer", "name": "Cryptominer", "severity": SeverityLevel.HIGH, "ttp": "T1496"},
    {"pattern": r"stratum\+tcp://", "name": "Mining pool connection", "severity": SeverityLevel.HIGH, "ttp": "T1496"},
    {"pattern": r"--donate-level|--coin=", "name": "Cryptominer arguments", "severity": SeverityLevel.HIGH, "ttp": "T1496"},
    
    # Persistence
    # Often benign (admins listing/editing crontab). Keep as low signal unless correlated with other IOCs.
    {"pattern": r"\bcrontab\s+-(?:e|l)\b", "name": "Crontab modification", "severity": SeverityLevel.LOW, "ttp": "T1053.003"},
    {"pattern": r"systemctl\s+(enable|start)", "name": "Systemd service manipulation", "severity": SeverityLevel.MEDIUM, "ttp": "T1543.002"},
    {"pattern": r"chkconfig\s+--add", "name": "Init script manipulation", "severity": SeverityLevel.MEDIUM, "ttp": "T1037"},
    
    # Defense evasion
    {"pattern": r"history\s+-c|unset\s+HISTFILE", "name": "History clearing", "severity": SeverityLevel.HIGH, "ttp": "T1070.003"},
    {"pattern": r"rm\s+.*\.bash_history", "name": "History file deletion", "severity": SeverityLevel.HIGH, "ttp": "T1070.003"},
    {"pattern": r"shred\s+|srm\s+", "name": "Secure file deletion", "severity": SeverityLevel.HIGH, "ttp": "T1070.004"},
    {"pattern": r"\biptables\s+-(?:F|X)\b", "name": "Firewall rules clearing", "severity": SeverityLevel.HIGH, "ttp": "T1562.004"},
    
    # Encoding/obfuscation
    {"pattern": r"base64\s+-d.*\|\s*(bash|sh|python|perl)", "name": "Base64 decode and execute", "severity": SeverityLevel.CRITICAL, "ttp": "T1027"},
    {"pattern": r"eval.*\$\(.*base64", "name": "Eval with base64", "severity": SeverityLevel.CRITICAL, "ttp": "T1027"},
    {"pattern": r"python.*-c.*exec.*decode", "name": "Python encoded execution", "severity": SeverityLevel.HIGH, "ttp": "T1027"},
]

# Known malicious domains patterns (DGA, C2, etc.)
SUSPICIOUS_DOMAIN_PATTERNS: List[Dict[str, Any]] = [
    {"pattern": r"^[a-z0-9]{20,}\.(?:com|net|org|info|biz)$", "name": "DGA-like domain", "severity": SeverityLevel.HIGH},
    {"pattern": r"\.onion$", "name": "Tor hidden service", "severity": SeverityLevel.HIGH},
    {"pattern": r"\.i2p$", "name": "I2P domain", "severity": SeverityLevel.HIGH},
    {"pattern": r"^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\.xip\.io$", "name": "XIP.io dynamic DNS", "severity": SeverityLevel.MEDIUM},
    {"pattern": r"\.duckdns\.org$", "name": "DuckDNS dynamic", "severity": SeverityLevel.MEDIUM},
    {"pattern": r"\.no-ip\.", "name": "No-IP dynamic DNS", "severity": SeverityLevel.MEDIUM},
    {"pattern": r"\.ngrok\.io$", "name": "Ngrok tunnel", "severity": SeverityLevel.MEDIUM},
    {"pattern": r"pastebin\.com/raw/", "name": "Pastebin raw content", "severity": SeverityLevel.MEDIUM},
]

# Persistence locations to check
PERSISTENCE_CHECKS: Dict[str, Dict[str, Any]] = {
    # Linux cron
    "cron_system": {
        "paths": ["/etc/crontab", "/etc/cron.d/*", "/etc/cron.daily/*", "/etc/cron.hourly/*", "/etc/cron.weekly/*", "/etc/cron.monthly/*"],
        "type": PersistenceType.CRON,
        "ttp": "T1053.003",
    },
    "cron_user": {
        "paths": ["/var/spool/cron/crontabs/*"],
        "type": PersistenceType.CRON,
        "ttp": "T1053.003",
    },
    
    # Systemd
    "systemd_system": {
        "paths": ["/etc/systemd/system/*.service", "/lib/systemd/system/*.service", "/usr/lib/systemd/system/*.service"],
        "type": PersistenceType.SYSTEMD,
        "ttp": "T1543.002",
    },
    "systemd_user": {
        "paths": ["~/.config/systemd/user/*.service"],
        "type": PersistenceType.SYSTEMD,
        "ttp": "T1543.002",
    },
    
    # Init scripts
    "init_scripts": {
        "paths": ["/etc/init.d/*", "/etc/rc.local"],
        "type": PersistenceType.INIT_SCRIPT,
        "ttp": "T1037.004",
    },
    
    # Shell RC files
    "bashrc": {
        "paths": ["/etc/bash.bashrc", "/etc/bashrc", "~/.bashrc", "~/.bash_profile", "~/.profile"],
        "type": PersistenceType.BASHRC,
        "ttp": "T1546.004",
    },
    "profile": {
        "paths": ["/etc/profile", "/etc/profile.d/*"],
        "type": PersistenceType.PROFILE,
        "ttp": "T1546.004",
    },
    
    # SSH keys
    "ssh_authorized_keys": {
        "paths": ["/root/.ssh/authorized_keys", "/home/*/.ssh/authorized_keys"],
        "type": PersistenceType.SSH_AUTHORIZED_KEYS,
        "ttp": "T1098.004",
    },
    
    # LD_PRELOAD
    "ld_preload": {
        "paths": ["/etc/ld.so.preload"],
        "type": PersistenceType.LD_PRELOAD,
        "ttp": "T1574.006",
    },
    
    # Kernel modules
    "kernel_modules": {
        "paths": ["/etc/modules", "/etc/modules-load.d/*", "/lib/modules/*/"],
        "type": PersistenceType.KERNEL_MODULE,
        "ttp": "T1547.006",
    },
}

# Known C2 ports
KNOWN_C2_PORTS: Set[int] = {
    # Common C2 ports
    443, 80, 8080, 8443, 4444, 5555, 6666, 7777, 8888, 9999,
    # Metasploit defaults
    4443, 4445,
    # Cobalt Strike
    50050,
    # Empire
    8081,
    # Other
    1234, 31337, 12345,
}

# High entropy threshold for packed/encrypted files
ENTROPY_THRESHOLD = 7.0

# Known webshell signatures
WEBSHELL_SIGNATURES: List[Dict[str, Any]] = [
    {"pattern": r"eval\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)", "name": "PHP eval injection", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"assert\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP assert injection", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"base64_decode\s*\(\s*\$_(GET|POST)", "name": "PHP base64 decode", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"system\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP system call", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"passthru\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP passthru", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"shell_exec\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP shell_exec", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"exec\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP exec", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"popen\s*\(\s*\$_(GET|POST|REQUEST)", "name": "PHP popen", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"proc_open\s*\(.*\$_(GET|POST|REQUEST)", "name": "PHP proc_open", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"<%.*Runtime\.getRuntime\(\)\.exec", "name": "JSP command execution", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"ProcessBuilder.*start\(\)", "name": "Java ProcessBuilder", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"os\.system\s*\(.*request\.", "name": "Python os.system", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"subprocess\.(call|Popen|run).*request\.", "name": "Python subprocess", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"c99shell|r57shell|b374k|WSO\s+shell", "name": "Known webshell name", "severity": SeverityLevel.CRITICAL},
    {"pattern": r"FilesMan|Alfa\s+Shell|China\s+Chopper", "name": "Known webshell", "severity": SeverityLevel.CRITICAL},
]

# TI Feed URLs (free/open sources)
DEFAULT_TI_FEEDS: List[Dict[str, Any]] = [
    {
        "name": "abuse.ch URLhaus",
        "url": "https://urlhaus.abuse.ch/downloads/csv_recent/",
        "format": FeedFormat.CSV,
        "source": FeedSource.URLHAUS,
        "ioc_types": [IoCType.URL, IoCType.DOMAIN],
    },
    {
        "name": "abuse.ch Feodo Tracker",
        "url": "https://feodotracker.abuse.ch/downloads/ipblocklist.csv",
        "format": FeedFormat.CSV,
        "source": FeedSource.FEODO_TRACKER,
        "ioc_types": [IoCType.IP_V4],
    },
    {
        "name": "abuse.ch SSL Blacklist",
        "url": "https://sslbl.abuse.ch/blacklist/sslipblacklist.csv",
        "format": FeedFormat.CSV,
        "source": FeedSource.SSLBL,
        "ioc_types": [IoCType.IP_V4],
    },
    {
        "name": "abuse.ch ThreatFox IOCs",
        "url": "https://threatfox.abuse.ch/export/json/recent/",
        "format": FeedFormat.JSON,
        "source": FeedSource.THREATFOX,
        "ioc_types": [IoCType.IP_V4, IoCType.DOMAIN, IoCType.URL, IoCType.SHA256],
    },
    {
        "name": "Emerging Threats Compromised IPs",
        "url": "https://rules.emergingthreats.net/blockrules/compromised-ips.txt",
        "format": FeedFormat.TXT,
        "source": FeedSource.EMERGING_THREATS,
        "ioc_types": [IoCType.IP_V4],
    },
]


# =============================================================================
# Container IOC Patterns
# =============================================================================

CONTAINER_IOC_PATTERNS: Dict[str, Dict[str, Any]] = {
    # Malicious Container Images
    "malicious_images": {
        "description": "Known malicious container image patterns",
        "severity": SeverityLevel.CRITICAL,
        "patterns": [
            # Cryptominers
            r"xmrig",
            r"cryptominer",
            r"monero",
            r"coinhive",
            r"minergate",
            r"nicehash",
            r".*miner.*:latest",
            # Backdoored images
            r"backdoor",
            r"rootkit",
            r"c2-",
            r".*malware.*",
            # Typosquatting
            r"ngnix",  # nginx typo
            r"ubunti",  # ubuntu typo
            r"alphine",  # alpine typo
            r"debain",  # debian typo
            # Known malicious registries
            r".*\.onion/",
            r"malicious-registry\..*",
        ],
        "mitre_technique": "T1610",  # Deploy Container
    },
    
    # Container Escape Indicators
    "escape_indicators": {
        "description": "Indicators of container escape attempts",
        "severity": SeverityLevel.CRITICAL,
        "patterns": [
            # Host filesystem access
            r"/host/",
            r"/hostfs/",
            r"/proc/1/root",
            # Docker socket abuse
            r"/var/run/docker\.sock",
            r"/run/containerd/containerd\.sock",
            r"/run/crio/crio\.sock",
            # Privileged operations
            r"nsenter.*-t\s*1",
            r"chroot\s+/host",
            r"--privileged",
            # Kernel exploits
            r"dirty_pipe",
            r"dirtycow",
            r"cve-202[0-5]-",
        ],
        "mitre_technique": "T1611",  # Escape to Host
    },
    
    # Kubernetes Attack Patterns
    "kubernetes_attacks": {
        "description": "Kubernetes-specific attack indicators",
        "severity": SeverityLevel.HIGH,
        "patterns": [
            # Service account token theft
            r"/var/run/secrets/kubernetes\.io/serviceaccount",
            r"kubectl.*--token",
            # RBAC abuse
            r"clusterrole.*admin",
            r"clusterrolebinding.*cluster-admin",
            # Secrets enumeration
            r"kubectl\s+get\s+secrets?\s+-A",
            r"kubectl\s+get\s+secrets?\s+--all-namespaces",
            # Pod creation for persistence
            r"kubectl\s+create.*daemonset",
            r"kubectl\s+apply.*privileged.*true",
            # Node shell
            r"kubectl.*debug.*node",
            r"kubectl.*node-shell",
        ],
        "mitre_technique": "T1609",  # Container Administration Command
    },
    
    # Container Process Anomalies
    "process_anomalies": {
        "description": "Anomalous processes in containers",
        "severity": SeverityLevel.MEDIUM,
        "patterns": [
            # Reverse shells
            r"bash\s+-i\s+>&\s*/dev/tcp",
            r"nc\s+-e\s*/bin/(ba)?sh",
            r"python.*socket.*connect",
            r"perl.*socket.*INET",
            r"ruby.*TCPSocket",
            # Miners
            r"xmrig",
            r"stratum\+tcp://",
            r"pool\..*:\d{4}",
            # Post-exploitation
            r"curl\s+.*\|\s*(ba)?sh",
            r"wget\s+.*-O-\s*\|\s*(ba)?sh",
            # Credential access
            r"cat.*/etc/shadow",
            r"mimikatz",
            r"secretsdump",
        ],
        "mitre_technique": "T1059",  # Command and Scripting Interpreter
    },
    
    # Container Network Anomalies
    "network_anomalies": {
        "description": "Suspicious container network activity",
        "severity": SeverityLevel.HIGH,
        "patterns": [
            # C2 Communication
            r"169\.254\.(169|170)\.\d+",  # IMDS
            r"metadata\.google\.internal",
            r"metadata\.azure\.com",
            # Unusual ports from containers
            r"ESTABLISHED.*:4444\s",  # Metasploit default
            r"ESTABLISHED.*:5555\s",  # Meterpreter
            r"ESTABLISHED.*:6666\s",
            r"ESTABLISHED.*:7777\s",
            r"ESTABLISHED.*:1337\s",
            # Tor/I2P
            r"\.onion\b",
            r"\.i2p\b",
            # IRC (C2)
            r":6667\s",
            r":6697\s",
        ],
        "mitre_technique": "T1071",  # Application Layer Protocol
    },
    
    # Docker Daemon Abuse
    "docker_abuse": {
        "description": "Docker daemon abuse indicators",
        "severity": SeverityLevel.CRITICAL,
        "patterns": [
            # Remote API abuse
            r"docker\s+-H\s+tcp://",
            r":2375/",  # Unencrypted Docker API
            r":2376/",  # Docker API with TLS
            # Privileged container creation
            r"docker\s+run.*--privileged",
            r"docker\s+run.*--cap-add\s+ALL",
            r"docker\s+run.*--pid=host",
            r"docker\s+run.*--network=host",
            r"docker\s+run.*-v\s+/:/",
            # Image manipulation
            r"docker\s+save.*\|.*nc",
            r"docker\s+export.*\|.*nc",
            # Buildkit abuse
            r"docker\s+build.*--ssh",
            r"DOCKER_BUILDKIT.*secret",
        ],
        "mitre_technique": "T1610",  # Deploy Container
    },
    
    # Container Registry Attacks
    "registry_attacks": {
        "description": "Container registry attack indicators",
        "severity": SeverityLevel.HIGH,
        "patterns": [
            # Registry enumeration
            r"_catalog",
            r"/v2/.*/manifests/",
            r"/v2/.*/blobs/",
            # Registry credentials
            r"\.docker/config\.json",
            r"dockerconfigjson",
            r"registry\..*\.io.*password",
            # Malicious push
            r"docker\s+push.*:latest",
            r"docker\s+tag.*:latest",
        ],
        "mitre_technique": "T1195.002",  # Supply Chain Compromise: Compromise Software Supply Chain
    },
}


# Kubernetes Audit Event IOCs
K8S_AUDIT_IOCS: Dict[str, Dict[str, Any]] = {
    "secrets_enumeration": {
        "description": "Kubernetes secrets enumeration",
        "verb": ["list", "get"],
        "resource": "secrets",
        "severity": SeverityLevel.MEDIUM,
        "mitre_technique": "T1552.007",
    },
    "configmap_access": {
        "description": "Sensitive ConfigMap access",
        "verb": ["get", "list"],
        "resource": "configmaps",
        "severity": SeverityLevel.LOW,
        "mitre_technique": "T1552",
    },
    "pod_exec": {
        "description": "Pod exec command execution",
        "verb": ["create"],
        "resource": "pods/exec",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1609",
    },
    "privileged_pod": {
        "description": "Privileged pod creation",
        "verb": ["create", "update"],
        "resource": "pods",
        "pattern": r"privileged.*true",
        "severity": SeverityLevel.CRITICAL,
        "mitre_technique": "T1611",
    },
    "hostpath_mount": {
        "description": "HostPath volume mount",
        "verb": ["create", "update"],
        "resource": "pods",
        "pattern": r"hostPath",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1611",
    },
    "service_account_token": {
        "description": "Service account token creation",
        "verb": ["create"],
        "resource": "serviceaccounts/token",
        "severity": SeverityLevel.MEDIUM,
        "mitre_technique": "T1078.004",
    },
    "cluster_admin_binding": {
        "description": "Cluster admin role binding",
        "verb": ["create", "update"],
        "resource": "clusterrolebindings",
        "pattern": r"cluster-admin",
        "severity": SeverityLevel.CRITICAL,
        "mitre_technique": "T1098.003",
    },
    "admission_webhook": {
        "description": "Admission webhook modification",
        "verb": ["create", "update", "patch"],
        "resource": ["validatingwebhookconfigurations", "mutatingwebhookconfigurations"],
        "severity": SeverityLevel.CRITICAL,
        "mitre_technique": "T1546",
    },
    "daemonset_creation": {
        "description": "DaemonSet creation for persistence",
        "verb": ["create"],
        "resource": "daemonsets",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1053.007",
    },
    "cronjob_creation": {
        "description": "CronJob creation for persistence",
        "verb": ["create"],
        "resource": "cronjobs",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1053.007",
    },
}


# Known Malicious Container Hashes
MALICIOUS_CONTAINER_HASHES: Dict[str, Dict[str, Any]] = {
    # Example format - would be populated with actual known malicious image digests
    # "sha256:abc123...": {
    #     "name": "xmrig-miner-alpine",
    #     "description": "Cryptominer disguised as alpine image",
    #     "threat_type": "cryptominer",
    #     "severity": SeverityLevel.CRITICAL,
    # },
}


# Container File System IOCs
CONTAINER_FS_IOCS: List[Dict[str, Any]] = [
    {
        "path": "/etc/crontab",
        "description": "Crontab modification in container (unusual)",
        "severity": SeverityLevel.MEDIUM,
        "mitre_technique": "T1053.003",
    },
    {
        "path": "/root/.ssh/authorized_keys",
        "description": "SSH key addition in container",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1098.004",
    },
    {
        "path": "/tmp/.*\.sh",
        "pattern": True,
        "description": "Shell script in /tmp (potential dropper)",
        "severity": SeverityLevel.MEDIUM,
        "mitre_technique": "T1059.004",
    },
    {
        "path": "/dev/shm/.*",
        "pattern": True,
        "description": "Files in /dev/shm (fileless execution)",
        "severity": SeverityLevel.HIGH,
        "mitre_technique": "T1027.011",
    },
    {
        "path": "/proc/self/exe.*deleted",
        "pattern": True,
        "description": "Deleted executable running (fileless malware)",
        "severity": SeverityLevel.CRITICAL,
        "mitre_technique": "T1027.011",
    },
    {
        "path": "/.dockerenv",
        "description": "Docker environment marker (container detection)",
        "severity": SeverityLevel.INFO,
        "mitre_technique": "T1082",
    },
    {
        "path": "/run/secrets/kubernetes.io",
        "description": "Kubernetes secrets mount",
        "severity": SeverityLevel.INFO,
        "mitre_technique": "T1552.007",
    },
]


# =============================================================================
# Cloud IOCs (AWS, Azure, GCP)
# =============================================================================

CLOUD_IOCS: Dict[str, Dict[str, Any]] = {
    # AWS CloudTrail IOCs
    "aws": {
        "cloudtrail_iocs": [
            {
                "event_name": "ConsoleLogin",
                "condition": "responseElements.ConsoleLogin == 'Failure'",
                "description": "Failed console login attempt",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1110",
                "threshold": {"count": 5, "timeframe_minutes": 10},
            },
            {
                "event_name": "GetSecretValue",
                "condition": "unusual_source_ip",
                "description": "Secrets Manager access from unusual IP",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1552.004",
            },
            {
                "event_name": "StopLogging",
                "description": "CloudTrail logging disabled",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1562.008",
            },
            {
                "event_name": "DeleteTrail",
                "description": "CloudTrail deleted",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1562.008",
            },
            {
                "event_name": "PutBucketPolicy",
                "condition": "public_access",
                "description": "S3 bucket made public",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1530",
            },
            {
                "event_name": "CreateAccessKey",
                "description": "New access key created",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1098.001",
            },
            {
                "event_name": "AttachUserPolicy",
                "condition": "policy == 'AdministratorAccess'",
                "description": "Admin policy attached to user",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1098.003",
            },
            {
                "event_name": "RunInstances",
                "condition": "unusual_region",
                "description": "EC2 instance launched in unusual region",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1578.002",
            },
            {
                "event_name": "UpdateAssumeRolePolicy",
                "description": "IAM role trust policy modified",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1098.003",
            },
            {
                "event_name": "CreateUser",
                "condition": "unusual_time",
                "description": "IAM user created at unusual time",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1136.003",
            },
            {
                "event_name": "ModifyDBInstance",
                "condition": "publicly_accessible",
                "description": "RDS instance made publicly accessible",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1530",
            },
            {
                "event_name": "AuthorizeSecurityGroupIngress",
                "condition": "0.0.0.0/0",
                "description": "Security group opened to world",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1562.007",
            },
            {
                "event_name": "AssumeRole",
                "condition": "cross_account && unusual_principal",
                "description": "Cross-account role assumption from unusual principal",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1550.001",
            },
            {
                "event_name": "GetCallerIdentity",
                "description": "Identity enumeration (reconnaissance)",
                "severity": SeverityLevel.LOW,
                "mitre_technique": "T1087.004",
            },
            {
                "event_name": "DescribeInstances",
                "condition": "high_frequency",
                "description": "High-frequency EC2 enumeration",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1580",
            },
            {
                "event_name": "CreateKeyPair",
                "description": "New EC2 key pair created",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1098.001",
            },
            {
                "event_name": "InvokeModel",
                "condition": "bedrock && unusual_model",
                "description": "Unusual Bedrock model invocation",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1059",
            },
        ],
        "guardduty_findings": [
            {
                "type": "UnauthorizedAccess:IAMUser/InstanceCredentialExfiltration",
                "severity": SeverityLevel.CRITICAL,
                "description": "Instance credentials used from external IP",
                "mitre_technique": "T1552.005",
            },
            {
                "type": "Recon:IAMUser/MaliciousIPCaller",
                "severity": SeverityLevel.HIGH,
                "description": "API call from known malicious IP",
                "mitre_technique": "T1595",
            },
            {
                "type": "CryptoCurrency:EC2/BitcoinTool.B",
                "severity": SeverityLevel.HIGH,
                "description": "EC2 communicating with Bitcoin-related network",
                "mitre_technique": "T1496",
            },
            {
                "type": "Backdoor:EC2/C&CActivity.B",
                "severity": SeverityLevel.CRITICAL,
                "description": "C2 communication detected",
                "mitre_technique": "T1071",
            },
            {
                "type": "PrivilegeEscalation:IAMUser/AdministrativePermissions",
                "severity": SeverityLevel.HIGH,
                "description": "Privilege escalation attempt",
                "mitre_technique": "T1078",
            },
        ],
    },
    "azure": {
        "activity_log_iocs": [
            {
                "operation": "Microsoft.Authorization/roleAssignments/write",
                "condition": "Owner or Contributor role",
                "description": "High-privilege role assignment",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1098.003",
            },
            {
                "operation": "Microsoft.Compute/virtualMachines/write",
                "condition": "unusual_location",
                "description": "VM created in unusual location",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1578.002",
            },
            {
                "operation": "Microsoft.KeyVault/vaults/secrets/read",
                "condition": "unusual_principal",
                "description": "Key Vault secret accessed by unusual principal",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1552.004",
            },
            {
                "operation": "Microsoft.Network/networkSecurityGroups/write",
                "condition": "AllowAll rule",
                "description": "NSG rule allowing all traffic",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1562.007",
            },
            {
                "operation": "Microsoft.Storage/storageAccounts/write",
                "condition": "public_access",
                "description": "Storage account made public",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1530",
            },
            {
                "operation": "Microsoft.AAD/domainServices/write",
                "description": "Azure AD Domain Services modification",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1484",
            },
        ],
        "sentinel_alerts": [
            {
                "alert_type": "Suspicious Azure AD sign-in",
                "description": "Sign-in from unusual location or impossible travel",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1078.004",
            },
            {
                "alert_type": "Azure AD Identity Protection risk",
                "description": "High-risk user or sign-in detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1078",
            },
            {
                "alert_type": "Malicious PowerShell command",
                "description": "Suspicious PowerShell execution detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1059.001",
            },
        ],
    },
    "gcp": {
        "audit_log_iocs": [
            {
                "method": "google.iam.admin.v1.CreateServiceAccountKey",
                "description": "Service account key created",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1098.001",
            },
            {
                "method": "google.iam.admin.v1.SetIamPolicy",
                "condition": "allUsers or allAuthenticatedUsers",
                "description": "Public IAM policy set",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1530",
            },
            {
                "method": "google.cloud.secretmanager.v1.SecretManagerService.AccessSecretVersion",
                "condition": "unusual_accessor",
                "description": "Secret accessed by unusual principal",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1552.004",
            },
            {
                "method": "google.logging.v2.ConfigServiceV2.DeleteSink",
                "description": "Log sink deleted",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1562.008",
            },
            {
                "method": "google.compute.instances.insert",
                "condition": "unusual_zone",
                "description": "VM created in unusual zone",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1578.002",
            },
            {
                "method": "google.compute.firewalls.insert",
                "condition": "0.0.0.0/0 allowed",
                "description": "Firewall rule allowing all traffic",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1562.007",
            },
            {
                "method": "google.cloud.bigquery.v2.TableService.InsertAllTableData",
                "condition": "exfiltration_pattern",
                "description": "Large data export from BigQuery",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1567.002",
            },
        ],
        "security_command_center": [
            {
                "finding": "PUBLIC_IP_ADDRESS",
                "description": "Resource with public IP address",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1562.007",
            },
            {
                "finding": "OPEN_FIREWALL",
                "description": "Firewall allows all traffic",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1562.007",
            },
            {
                "finding": "CRYPTOMINING_MALWARE",
                "description": "Cryptomining malware detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1496",
            },
        ],
    },
}


# =============================================================================
# Behavioral IOCs
# =============================================================================

BEHAVIORAL_IOCS: Dict[str, Dict[str, Any]] = {
    "process_behavior": {
        "suspicious_parent_child": [
            {
                "parent": "explorer.exe",
                "child": "powershell.exe",
                "args_pattern": "-enc|-e|-encodedcommand|-ep bypass",
                "description": "Explorer spawning encoded PowerShell",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1059.001",
            },
            {
                "parent": "winword.exe",
                "child": "cmd.exe|powershell.exe",
                "description": "Office application spawning shell",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1204.002",
            },
            {
                "parent": "outlook.exe",
                "child": "cmd.exe|powershell.exe|mshta.exe",
                "description": "Outlook spawning suspicious process",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1566.001",
            },
            {
                "parent": "wmiprvse.exe",
                "child": "powershell.exe|cmd.exe",
                "description": "WMI spawning shell (lateral movement)",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1047",
            },
            {
                "parent": "services.exe",
                "child": "cmd.exe",
                "args_pattern": "net user|net group|whoami",
                "description": "Service executing reconnaissance commands",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1543.003",
            },
            {
                "parent": "svchost.exe",
                "child": "cmd.exe|powershell.exe",
                "condition": "unusual_svchost_service",
                "description": "Suspicious svchost child process",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1055",
            },
            {
                "parent": "python.exe|python3",
                "child": "sh|bash|cmd.exe",
                "description": "Python spawning shell (potential RCE)",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1059.006",
            },
            {
                "parent": "java.exe|java",
                "child": "sh|bash|cmd.exe|powershell.exe",
                "description": "Java spawning shell (potential RCE/Log4j)",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1190",
            },
        ],
        "rare_lolbins_usage": [
            {
                "process": "certutil.exe",
                "args_pattern": "-urlcache|-decode|-encode",
                "description": "Certutil used for download/decode",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1140",
            },
            {
                "process": "mshta.exe",
                "args_pattern": "http|javascript|vbscript",
                "description": "MSHTA executing remote/script content",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1218.005",
            },
            {
                "process": "regsvr32.exe",
                "args_pattern": "/s /n /u /i:http",
                "description": "Regsvr32 script execution (squiblydoo)",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1218.010",
            },
            {
                "process": "msiexec.exe",
                "args_pattern": "/q.*http",
                "description": "MSIExec loading remote package",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1218.007",
            },
            {
                "process": "bitsadmin.exe",
                "args_pattern": "/transfer",
                "description": "BitsAdmin file transfer",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1197",
            },
            {
                "process": "rundll32.exe",
                "args_pattern": "javascript:|shell32.dll,ShellExec_RunDLL",
                "description": "Rundll32 script/command execution",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1218.011",
            },
        ],
        "defense_evasion": [
            {
                "behavior": "process_hollowing",
                "indicators": ["NtUnmapViewOfSection", "WriteProcessMemory", "SetThreadContext"],
                "description": "Process hollowing technique detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1055.012",
            },
            {
                "behavior": "timestomping",
                "indicators": ["SetFileTime", "timestamp_mismatch"],
                "description": "File timestamp modification",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1070.006",
            },
            {
                "behavior": "log_clearing",
                "indicators": ["wevtutil cl", "Clear-EventLog", "/var/log deletion"],
                "description": "Event log/audit log clearing",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1070.001",
            },
            {
                "behavior": "amsi_bypass",
                "indicators": ["AmsiScanBuffer patch", "amsi.dll unhook"],
                "description": "AMSI bypass detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1562.001",
            },
            {
                "behavior": "etw_bypass",
                "indicators": ["EtwEventWrite patch", "ntdll!NtTraceEvent hook"],
                "description": "ETW bypass detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1562.006",
            },
        ],
    },
    "network_behavior": {
        "c2_patterns": [
            {
                "pattern": "dns_tunneling",
                "indicators": [
                    "high_frequency_dns_queries",
                    "long_subdomain_names",
                    "txt_record_queries",
                    "unusual_dns_server",
                ],
                "description": "DNS tunneling detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1071.004",
            },
            {
                "pattern": "http_beaconing",
                "indicators": [
                    "regular_interval_requests",
                    "consistent_packet_size",
                    "base64_in_uri",
                    "user_agent_anomaly",
                ],
                "description": "HTTP beaconing pattern detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1071.001",
            },
            {
                "pattern": "icmp_tunneling",
                "indicators": [
                    "large_icmp_packets",
                    "high_frequency_icmp",
                    "icmp_data_anomaly",
                ],
                "description": "ICMP tunneling detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1095",
            },
            {
                "pattern": "websocket_c2",
                "indicators": [
                    "persistent_websocket",
                    "unusual_websocket_data",
                    "websocket_to_uncommon_port",
                ],
                "description": "WebSocket C2 communication",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1071.001",
            },
            {
                "pattern": "encrypted_channel_anomaly",
                "indicators": [
                    "self_signed_cert",
                    "unusual_tls_fingerprint",
                    "certificate_mismatch",
                    "expired_certificate",
                ],
                "description": "Suspicious encrypted channel",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1573.002",
            },
        ],
        "data_exfiltration": [
            {
                "pattern": "large_upload",
                "indicators": ["upload_bytes > 100MB", "unusual_destination"],
                "description": "Large data upload detected",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1048",
            },
            {
                "pattern": "cloud_storage_upload",
                "indicators": ["S3 bucket", "Azure Blob", "GCS bucket", "unusual_bucket_name"],
                "description": "Upload to cloud storage",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1567.002",
            },
            {
                "pattern": "email_exfiltration",
                "indicators": ["smtp_attachment_large", "unusual_recipient_domain"],
                "description": "Data exfiltration via email",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1048.003",
            },
            {
                "pattern": "code_repository_upload",
                "indicators": ["github.com", "gitlab.com", "unusual_repo_push"],
                "description": "Data upload to code repository",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1567.001",
            },
        ],
        "lateral_movement": [
            {
                "pattern": "internal_scanning",
                "indicators": [
                    "port_sweep",
                    "ping_sweep",
                    "smb_enumeration",
                    "rdp_attempts",
                ],
                "description": "Internal network scanning",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1046",
            },
            {
                "pattern": "credential_relay",
                "indicators": [
                    "ntlm_relay_pattern",
                    "kerberos_ap_req_to_multiple_hosts",
                    "pass_the_hash_pattern",
                ],
                "description": "Credential relay attack",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1550",
            },
            {
                "pattern": "remote_execution",
                "indicators": [
                    "psexec_pattern",
                    "wmi_remote_exec",
                    "winrm_remote_exec",
                    "ssh_multiple_hosts",
                ],
                "description": "Remote execution pattern",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1021",
            },
        ],
    },
    "file_behavior": {
        "ransomware_indicators": [
            {
                "pattern": "mass_file_encryption",
                "indicators": [
                    "file_extension_change",
                    "high_write_rate",
                    "entropy_increase",
                    "ransom_note_creation",
                ],
                "description": "Ransomware behavior detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1486",
            },
            {
                "pattern": "shadow_copy_deletion",
                "indicators": [
                    "vssadmin delete shadows",
                    "wmic shadowcopy delete",
                    "bcdedit /set {default} recoveryenabled No",
                ],
                "description": "Backup deletion (ransomware)",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1490",
            },
        ],
        "data_staging": [
            {
                "pattern": "archive_creation",
                "indicators": [
                    "rar.exe",
                    "7z.exe",
                    "zip creation",
                    "archive in temp folder",
                ],
                "description": "Data archiving for exfiltration",
                "severity": SeverityLevel.MEDIUM,
                "mitre_technique": "T1560.001",
            },
            {
                "pattern": "staging_directory",
                "indicators": [
                    "unusual_folder_with_many_files",
                    "files copied from multiple locations",
                ],
                "description": "Data staged for exfiltration",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1074.001",
            },
        ],
    },
    "authentication_behavior": {
        "credential_theft": [
            {
                "pattern": "lsass_access",
                "indicators": [
                    "OpenProcess on lsass.exe",
                    "MiniDumpWriteDump",
                    "comsvcs.dll MiniDump",
                ],
                "description": "LSASS memory access (credential theft)",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1003.001",
            },
            {
                "pattern": "sam_access",
                "indicators": [
                    "reg save HKLM\\SAM",
                    "reg save HKLM\\SYSTEM",
                    "impacket secretsdump",
                ],
                "description": "SAM database access",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1003.002",
            },
            {
                "pattern": "ntds_access",
                "indicators": [
                    "ntdsutil",
                    "vssadmin create shadow",
                    "NTDS.dit copy",
                ],
                "description": "Active Directory database theft",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1003.003",
            },
            {
                "pattern": "kerberos_attack",
                "indicators": [
                    "AS-REP roasting",
                    "Kerberoasting",
                    "Golden ticket",
                    "Silver ticket",
                ],
                "description": "Kerberos attack detected",
                "severity": SeverityLevel.CRITICAL,
                "mitre_technique": "T1558",
            },
        ],
        "brute_force": [
            {
                "pattern": "password_spray",
                "indicators": [
                    "same_password_multiple_users",
                    "low_rate_distributed",
                ],
                "description": "Password spray attack",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1110.003",
            },
            {
                "pattern": "credential_stuffing",
                "indicators": [
                    "known_breach_credentials",
                    "multiple_failed_logins",
                    "unusual_user_agent",
                ],
                "description": "Credential stuffing attack",
                "severity": SeverityLevel.HIGH,
                "mitre_technique": "T1110.004",
            },
        ],
    },
}


# =============================================================================
# Threat Intelligence Feed Sources
# =============================================================================

THREAT_INTEL_FEEDS: Dict[str, Dict[str, Any]] = {
    "abuse_ch": {
        "name": "abuse.ch",
        "feeds": [
            {
                "name": "URLhaus",
                "url": "https://urlhaus.abuse.ch/downloads/csv/",
                "type": IoCType.URL,
                "format": FeedFormat.CSV,
                "update_frequency_hours": 1,
            },
            {
                "name": "MalwareBazaar",
                "url": "https://bazaar.abuse.ch/export/csv/full/",
                "type": IoCType.FILE_HASH,
                "format": FeedFormat.CSV,
                "update_frequency_hours": 24,
            },
            {
                "name": "ThreatFox",
                "url": "https://threatfox.abuse.ch/export/csv/recent/",
                "type": IoCType.DOMAIN,
                "format": FeedFormat.CSV,
                "update_frequency_hours": 1,
            },
            {
                "name": "Feodo Tracker",
                "url": "https://feodotracker.abuse.ch/downloads/ipblocklist.csv",
                "type": IoCType.IP_ADDRESS,
                "format": FeedFormat.CSV,
                "update_frequency_hours": 6,
            },
        ],
    },
    "alienvault_otx": {
        "name": "AlienVault OTX",
        "url": "https://otx.alienvault.com/api/v1/pulses/subscribed",
        "format": FeedFormat.JSON,
        "requires_api_key": True,
        "types": [IoCType.IP_ADDRESS, IoCType.DOMAIN, IoCType.FILE_HASH, IoCType.URL],
        "update_frequency_hours": 1,
    },
    "misp": {
        "name": "MISP Threat Sharing",
        "format": FeedFormat.JSON,
        "requires_api_key": True,
        "types": [IoCType.IP_ADDRESS, IoCType.DOMAIN, IoCType.FILE_HASH, IoCType.URL, IoCType.EMAIL],
    },
    "virustotal": {
        "name": "VirusTotal",
        "url": "https://www.virustotal.com/api/v3/",
        "format": FeedFormat.JSON,
        "requires_api_key": True,
        "types": [IoCType.FILE_HASH, IoCType.URL, IoCType.DOMAIN, IoCType.IP_ADDRESS],
    },
    "emergingthreats": {
        "name": "Emerging Threats",
        "feeds": [
            {
                "name": "Compromised IPs",
                "url": "https://rules.emergingthreats.net/blockrules/compromised-ips.txt",
                "type": IoCType.IP_ADDRESS,
                "format": FeedFormat.PLAIN_TEXT,
                "update_frequency_hours": 24,
            },
        ],
    },
    "blocklist_de": {
        "name": "Blocklist.de",
        "url": "https://lists.blocklist.de/lists/all.txt",
        "type": IoCType.IP_ADDRESS,
        "format": FeedFormat.PLAIN_TEXT,
        "update_frequency_hours": 24,
    },
}

