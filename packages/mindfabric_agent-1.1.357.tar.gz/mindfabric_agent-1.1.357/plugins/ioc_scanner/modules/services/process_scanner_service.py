"""Process IOC scanning service."""

import os
import re
from datetime import datetime
from typing import Dict, List, Any, Set

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    ProcessFinding,
    ProcessInfo,
    ProcessTreeNode,
    InjectionEvidence,
    ProcessInjectionType,
    ScanOptions,
    SeverityLevel,
    ConfidenceLevel,
)
from ..utils import calculate_file_hashes
from ..databases import SUSPICIOUS_PROCESS_PATTERNS
from ..detection import InjectionDetector


def _build_process_info(proc: Any, pinfo: Dict[str, Any]) -> ProcessInfo:
    """Build ProcessInfo from psutil snapshot plus best-effort enrichment (may fail under permissions)."""
    pid = int(pinfo["pid"])
    ppid = pinfo.get("ppid")
    cmdline_list = pinfo.get("cmdline") or []
    cmdline = " ".join(cmdline_list) if cmdline_list else ""
    mem = pinfo.get("memory_info")
    rss = int(mem.rss) if mem and getattr(mem, "rss", None) is not None else None
    vms = int(mem.vms) if mem and getattr(mem, "vms", None) is not None else None

    cwd = None
    uid = None
    gid = None
    num_fds = None
    cpu_time = None
    environ_subset: Dict[str, str] = {}
    open_files: List[str] = []

    try:
        cwd = proc.cwd()
    except Exception:
        pass

    try:
        u = proc.uids()
        uid = int(u.real)
    except Exception:
        pass

    try:
        g = proc.gids()
        gid = int(g.real)
    except Exception:
        pass

    try:
        nf = proc.num_fds()
        if nf is not None:
            num_fds = int(nf)
    except Exception:
        pass

    try:
        ct = proc.cpu_times()
        if ct:
            cpu_time = float(ct.user + ct.system)
    except Exception:
        pass

    try:
        mfull = proc.memory_full_info()
        if rss is None and getattr(mfull, "rss", None) is not None:
            rss = int(mfull.rss)
        if vms is None and getattr(mfull, "vms", None) is not None:
            vms = int(mfull.vms)
    except Exception:
        pass

    try:
        raw_env = proc.environ()
        max_keys = 48
        max_val = 240
        for i, (ek, ev) in enumerate(sorted(raw_env.items())):
            if i >= max_keys:
                break
            if ev is None:
                continue
            sv = str(ev)
            if len(sv) > max_val:
                sv = sv[: max_val - 1] + "…"
            environ_subset[str(ek)] = sv
    except Exception:
        pass

    try:
        for of in proc.open_files()[:24]:
            pth = getattr(of, "path", None)
            if pth:
                open_files.append(str(pth))
    except Exception:
        pass

    exe_path = pinfo.get("exe")
    exe_hash = None
    if exe_path and isinstance(exe_path, str) and os.path.isfile(exe_path):
        try:
            st = os.stat(exe_path)
            if st.st_size <= 12 * 1024 * 1024:
                hs = calculate_file_hashes(exe_path, ["sha256"])
                if hs.sha256:
                    exe_hash = hs
        except OSError:
            pass

    return ProcessInfo(
        pid=pid,
        ppid=ppid,
        name=pinfo.get("name", "") or "",
        exe=exe_path,
        cmdline=cmdline,
        cwd=cwd,
        username=pinfo.get("username"),
        uid=uid,
        gid=gid,
        create_time=datetime.fromtimestamp(pinfo.get("create_time", 0)) if pinfo.get("create_time") else None,
        cpu_time=cpu_time,
        memory_rss=rss,
        memory_vms=vms,
        num_threads=pinfo.get("num_threads"),
        num_fds=num_fds,
        open_files=open_files,
        environ=environ_subset,
        exe_hash=exe_hash,
        status=pinfo.get("status"),
        is_running=True,
    )


class ProcessScannerService:
    """Service for process IOC scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize process scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
        self.injection_detector = InjectionDetector()
    
    async def check_suspicious_process_trees(
        self,
        processes: Dict[int, ProcessInfo],
        tree: Dict[int, List[int]]
    ) -> List[ProcessFinding]:
        """Check for suspicious parent-child process relationships."""
        findings = []
        
        # Known suspicious parent-child combinations
        suspicious_relationships = [
            # Office apps spawning shells
            ("word", "cmd.exe", "T1204.002"),
            ("excel", "cmd.exe", "T1204.002"),
            ("word", "powershell", "T1204.002"),
            ("excel", "powershell", "T1204.002"),
            ("outlook", "cmd.exe", "T1204.002"),
            
            # Web servers spawning shells
            ("httpd", "sh", "T1190"),
            ("apache", "sh", "T1190"),
            ("nginx", "sh", "T1190"),
            ("tomcat", "sh", "T1190"),
            ("java", "sh", "T1190"),
            
            # Script interpreters spawning network tools
            ("python", "nc", "T1059.006"),
            ("python", "ncat", "T1059.006"),
            ("python", "curl", "T1105"),
            ("perl", "nc", "T1059"),
            ("php", "sh", "T1059"),
            
            # System processes spawning unexpected children
            ("cron", "sh", "T1053.003"),
            ("at", "sh", "T1053.002"),
        ]
        
        for ppid, children in tree.items():
            if ppid not in processes:
                continue
            
            parent = processes[ppid]
            parent_name = parent.name.lower() if parent.name else ""
            
            for child_pid in children:
                if child_pid not in processes:
                    continue
                
                child = processes[child_pid]
                child_name = child.name.lower() if child.name else ""
                
                for parent_pattern, child_pattern, ttp in suspicious_relationships:
                    if parent_pattern in parent_name and child_pattern in child_name:
                        findings.append(ProcessFinding(
                            finding_type="suspicious_tree",
                            severity=SeverityLevel.HIGH,
                            confidence=ConfidenceLevel.MEDIUM,
                            process=child,
                            parent_process=parent,
                            suspicious_behaviors=[f"Suspicious parent-child: {parent_name} -> {child_name}"],
                            description=f"Suspicious process tree: {parent_name} spawned {child_name}",
                            reason=f"Parent: {parent_name}, Child: {child_name}",
                            mitre_techniques=[ttp]
                        ))
        
        return findings
    
    async def scan_processes(
        self,
        ioc: Dict[str, Any] = None,
        options: ScanOptions = None,
    ) -> List[ProcessFinding]:
        """
        Comprehensive process IOC scanning.
        
        Args:
            ioc: Dictionary with process IOCs (names, hashes, patterns)
            options: Scan configuration
        
        Returns:
            List of ProcessFinding
        """
        if not HAS_PSUTIL:
            return []
        
        if options is None:
            options = ScanOptions()
        
        results: List[ProcessFinding] = []
        
        # Parse IOC dict
        ioc_names: Set[str] = set()
        ioc_cmdline_patterns = []
        ioc_hashes_proc: Set[str] = set()
        
        if ioc:
            if "names" in ioc:
                ioc_names = set(n.lower() for n in ioc["names"])
            if "patterns" in ioc:
                ioc_cmdline_patterns = ioc["patterns"]
            if "hashes" in ioc:
                ioc_hashes_proc = set(h.lower() for h in ioc["hashes"])
        
        try:
            # Build process tree
            processes: Dict[int, ProcessInfo] = {}
            process_tree: Dict[int, List[int]] = {}
            
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'exe', 'cmdline', 'username', 'create_time', 'status', 'memory_info', 'num_threads']):
                try:
                    pinfo = proc.info
                    pid = pinfo['pid']
                    ppid = pinfo['ppid']

                    processes[pid] = _build_process_info(proc, pinfo)
                    
                    # Build tree
                    if ppid not in process_tree:
                        process_tree[ppid] = []
                    process_tree[ppid].append(pid)
                    
                    # Check 1: Process name IOC match
                    if ioc_names and pinfo.get('name', '').lower() in ioc_names:
                        results.append(ProcessFinding(
                            finding_type="ioc_match",
                            severity=SeverityLevel.HIGH,
                            confidence=ConfidenceLevel.HIGH,
                            process=processes[pid],
                            description=f"Process name matches IOC: {pinfo['name']}",
                            reason="IOC name match",
                            mitre_techniques=["T1059"]
                        ))
                    
                    # Check 2: Cmdline IOC patterns
                    for pattern_info in ioc_cmdline_patterns:
                        pattern = pattern_info if isinstance(pattern_info, str) else pattern_info.get("pattern", "")
                        if re.search(pattern, cmdline, re.IGNORECASE):
                            results.append(ProcessFinding(
                                finding_type="ioc_match",
                                severity=SeverityLevel.HIGH,
                                confidence=ConfidenceLevel.HIGH,
                                process=processes[pid],
                                description=f"Command line matches IOC pattern",
                                reason=f"Pattern: {pattern}",
                                mitre_techniques=["T1059"]
                            ))
                    
                    # Check 3: Suspicious command patterns
                    for pattern_info in SUSPICIOUS_PROCESS_PATTERNS:
                        if re.search(pattern_info["pattern"], cmdline, re.IGNORECASE):
                            results.append(ProcessFinding(
                                finding_type="suspicious_cmdline",
                                severity=pattern_info["severity"],
                                confidence=ConfidenceLevel.HIGH,
                                process=processes[pid],
                                suspicious_behaviors=[pattern_info["name"]],
                                description=f"Suspicious command detected: {pattern_info['name']}",
                                reason=pattern_info["name"],
                                mitre_techniques=[pattern_info.get("ttp", "T1059")]
                            ))
                    
                    # Check 4: Executable hash (if available)
                    exe_path = pinfo.get('exe')
                    if exe_path and ioc_hashes_proc and os.path.exists(exe_path):
                        hashes = calculate_file_hashes(exe_path, ["sha256"])
                        if hashes.sha256 and hashes.sha256.lower() in ioc_hashes_proc:
                            results.append(ProcessFinding(
                                finding_type="ioc_match",
                                severity=SeverityLevel.CRITICAL,
                                confidence=ConfidenceLevel.CONFIRMED,
                                process=processes[pid],
                                description=f"Process executable hash matches IOC",
                                reason=f"Hash: {hashes.sha256}",
                                mitre_techniques=["T1059"]
                            ))
                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Check 5: Suspicious parent-child relationships
            suspicious_trees = await self.check_suspicious_process_trees(processes, process_tree)
            results.extend(suspicious_trees)
            
            # Check 6: Process injection indicators
            if options.scope.scan_process_memory:
                injection_findings = await self.injection_detector.detect(processes)
                results.extend(injection_findings)
        
        except Exception as e:
            await self.plugin._send_alert("ioc_process_error", str(e), SeverityLevel.HIGH)
        
        return results

