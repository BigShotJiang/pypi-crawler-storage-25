"""Scan orchestration service for coordinating full/quick/targeted scans."""

import uuid
import time
import asyncio
from datetime import datetime
from typing import List, Dict, Any

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, ScanMetadata, ScanStatus, IoCScanResult
from ..utils.progress_handler import ProgressHandler
from utils.logger import logger


class ScanOrchestratorService:
    """Service for orchestrating different types of IOC scans."""
    
    def __init__(self, plugin_instance):
        """
        Initialize scan orchestrator service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
        self.progress_handler = ProgressHandler()
    
    async def full_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run comprehensive IOC scan.
        
        Executes all scan phases:
        1. Feed sync
        2. File system scan
        3. Process scan
        4. Network scan
        5. Log scan
        6. Persistence scan
        7. TTP detection
        8. AI analysis
        
        Returns:
            IoCScanResult dictionary
        """
        if options is None:
            options = ScanOptions()
        
        self.plugin.scan_metadata = ScanMetadata(
            scan_id=str(uuid.uuid4()),
            scan_type="full",
            started_at=datetime.utcnow(),
            status=ScanStatus.RUNNING
        )
        
        start_time = time.time()
        timeout_seconds = options.timeout_seconds if options and hasattr(options, 'timeout_seconds') else 1200  # 20 min default (reduced from 30 min)
        logger.info(f"[ioc_scanner] Starting full_scan with timeout: {timeout_seconds}s")
        
        try:
            # Define phases with their time budgets (as percentage of total timeout)
            phases = []
            
            # Phase 8: AI analysis helper (defined before phases list)
            async def _run_ai_analysis():
                """Helper to run AI analysis."""
                all_findings = []
                for findings in self.plugin.findings.values():
                    all_findings.extend([f.model_dump() if hasattr(f, 'model_dump') else f for f in findings])
                return await self.plugin.hook_ai_ioc_label(findings=all_findings)
            
            # Phase 1: Sync feeds (5% of time)
            if options.use_feeds:
                async def phase_feed_sync():
                    return await self.plugin.hook_feed_sync(feed_urls=options.feed_urls)
                phases.append(("feed_sync", 0.05, phase_feed_sync))
            
            # Phase 2: File system scan (35% of time - increased from 20% to allow complete scanning)
            # File system scanning is the most time-consuming phase and needs more time
            if options.scope.scan_file_system:
                async def phase_file_system():
                    return await self.plugin.hook_ioc_file_system(
                        paths=options.scope.file_paths,
                        options=options
                    )
                phases.append(("file_system", 0.35, phase_file_system))
            
            # Phase 3: Process scan (10% of time - reduced from 15% to give more time to file_system)
            if options.scope.scan_processes:
                async def phase_process():
                    return await self.plugin.hook_ioc_processes(options=options)
                phases.append(("process", 0.10, phase_process))
            
            # Phase 4: Network scan (8% of time - reduced from 10%)
            if options.scope.scan_network:
                async def phase_network():
                    result = await self.plugin.hook_ioc_network(options=options)
                    # Also run DNS analysis as part of network scan
                    await self.plugin.hook_dns_analysis(options=options)
                    return result
                phases.append(("network", 0.08, phase_network))
            
            # Phase 4.5: Drive-by Compromise Detection (5% of time)
            if options.scope.scan_file_system:  # Only if file system scanning is enabled
                async def phase_drive_by():
                    return await self.plugin.hook_drive_by_detection(options=options)
                phases.append(("drive_by", 0.05, phase_drive_by))
            
            # Phase 5: Log scan (12% of time - reduced from 15%)
            if options.scope.scan_logs:
                async def phase_logs():
                    return await self.plugin.hook_ioc_logs(
                        log_paths=options.scope.log_paths,
                        options=options
                    )
                phases.append(("logs", 0.12, phase_logs))
            
            # Phase 6: Persistence scan (8% of time - reduced from 10%)
            if options.scope.scan_persistence:
                async def phase_persistence():
                    return await self.plugin.hook_persistence_scan(options=options)
                phases.append(("persistence", 0.08, phase_persistence))
            
            # Phase 7: TTP detection (8% of time - reduced from 10%)
            async def phase_ttp():
                return await self.plugin.hook_ttp_detect(options=options)
            phases.append(("ttp", 0.08, phase_ttp))
            
            # Phase 8: AI analysis (5% of time, but can be skipped if time is running out)
            if options.use_ai:
                phases.append(("ai", 0.05, _run_ai_analysis))
            
            # Execute phases with timeout protection
            progress_values = [5, 15, 35, 50, 55, 65, 80, 90, 95]
            phase_names = ["Syncing feeds", "Scanning file system", "Scanning processes", 
                          "Scanning network", "Drive-by detection", "Scanning logs", 
                          "Scanning persistence", "Detecting TTPs", "Running AI analysis"]
            
            phase_idx = 0
            for phase_name, time_budget_ratio, phase_func in phases:
                elapsed = time.time() - start_time
                remaining = timeout_seconds - elapsed
                
                # Stop if less than 1 minute remaining
                if remaining <= 60:
                    logger.warning(f"[ioc_scanner] Stopping early - only {remaining:.1f}s remaining")
                    break
                
                # Calculate phase timeout
                phase_timeout = min(remaining * time_budget_ratio, remaining - 60)  # Reserve 1 minute for finalization
                if phase_timeout < 10:
                    phase_timeout = 10  # Minimum 10 seconds per phase
                
                logger.info(f"[ioc_scanner] Starting phase '{phase_name}' with timeout: {phase_timeout:.1f}s (remaining: {remaining:.1f}s)")
                
                # Update progress
                if phase_idx < len(progress_values):
                    await self.progress_handler.handle_progress(
                        self.plugin.scan_metadata, progress_values[phase_idx], phase_names[phase_idx]
                    )
                
                try:
                    # Execute phase with timeout
                    await asyncio.wait_for(phase_func(), timeout=phase_timeout)
                    logger.info(f"[ioc_scanner] Phase '{phase_name}' completed successfully")
                except asyncio.TimeoutError:
                    logger.warning(f"[ioc_scanner] Phase '{phase_name}' timed out after {phase_timeout:.1f}s, continuing with next phase")
                    self.plugin.scan_metadata.warnings.append(f"Phase '{phase_name}' timed out after {phase_timeout:.1f}s")
                except Exception as e:
                    logger.error(f"[ioc_scanner] Phase '{phase_name}' failed: {e}", exc_info=True)
                    self.plugin.scan_metadata.errors.append(f"Phase '{phase_name}': {str(e)}")
                    # Continue with next phase instead of failing completely
                
                phase_idx += 1
            
            # Finalize results
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 100, "Finalizing results"
            )
            result = self.plugin._finalize_scan_result(options)
            
            self.plugin.scan_metadata.status = ScanStatus.COMPLETED
            self.plugin.scan_metadata.completed_at = datetime.utcnow()
            self.plugin.scan_metadata.duration_seconds = (
                self.plugin.scan_metadata.completed_at - self.plugin.scan_metadata.started_at
            ).total_seconds()
            
            return result.model_dump()
        
        except Exception as e:
            self.plugin.scan_metadata.status = ScanStatus.FAILED
            self.plugin.scan_metadata.errors.append(str(e))
            raise
    
    async def quick_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Quick IOC scan - fast assessment.
        
        Focuses on:
        - Running processes
        - Active network connections
        - Key persistence locations
        - Critical system files
        
        Returns:
            Simplified IoCScanResult
        """
        if options is None:
            options = ScanOptions()

        # Quick scan settings (always enforced).
        # Users who want logs/filesystem should run full_scan instead.
        options.scope.scan_file_system = False
        options.scope.scan_logs = False
        options.scope.scan_memory = False
        
        self.plugin.scan_metadata = ScanMetadata(
            scan_id=str(uuid.uuid4()),
            scan_type="quick",
            started_at=datetime.utcnow(),
            status=ScanStatus.RUNNING
        )
        
        try:
            # Process scan
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 20, "Quick scan: processes"
            )
            await self.plugin.hook_ioc_processes(options=options)
            
            # Network scan
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 50, "Quick scan: network"
            )
            await self.plugin.hook_ioc_network(options=options)
            
            # Key persistence only
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 80, "Quick scan: persistence"
            )
            await self.plugin.hook_persistence_scan(options=options)
            
            # Finalize
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 100, "Quick scan: complete"
            )
            result = self.plugin._finalize_scan_result(options)
            
            self.plugin.scan_metadata.status = ScanStatus.COMPLETED
            self.plugin.scan_metadata.completed_at = datetime.utcnow()
            
            return result.model_dump()
        
        except Exception as e:
            self.plugin.scan_metadata.status = ScanStatus.FAILED
            self.plugin.scan_metadata.errors.append(str(e))
            raise
    
    async def targeted_scan(
        self,
        targets: Dict[str, Any],
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Targeted IOC scan for specific indicators.
        
        Args:
            targets: Dictionary with specific targets:
                - hashes: List of file hashes to find
                - ips: List of IPs to check
                - domains: List of domains to check
                - processes: List of process names
                - files: List of file paths
        
        Returns:
            IoCScanResult focused on targets
        """
        if options is None:
            options = ScanOptions()
        
        self.plugin.scan_metadata = ScanMetadata(
            scan_id=str(uuid.uuid4()),
            scan_type="targeted",
            started_at=datetime.utcnow(),
            status=ScanStatus.RUNNING
        )
        
        try:
            # Hash/file targets
            if targets.get("hashes") or targets.get("files"):
                await self.progress_handler.handle_progress(
                    self.plugin.scan_metadata, 25, "Targeted: file/hash scan"
                )
                await self.plugin.hook_ioc_file_system(
                    ioc_list=targets.get("hashes", []) + targets.get("files", []),
                    options=options
                )
            
            # Process targets
            if targets.get("processes"):
                await self.progress_handler.handle_progress(
                    self.plugin.scan_metadata, 50, "Targeted: process scan"
                )
                await self.plugin.hook_ioc_processes(
                    ioc={"names": targets["processes"]},
                    options=options
                )
            
            # Network targets
            if targets.get("ips") or targets.get("domains"):
                await self.progress_handler.handle_progress(
                    self.plugin.scan_metadata, 75, "Targeted: network scan"
                )
                await self.plugin.hook_ioc_network(
                    ioc_ips=targets.get("ips"),
                    ioc_domains=targets.get("domains"),
                    options=options
                )
            
            # TTP detection
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 90, "Targeted: TTP analysis"
            )
            await self.plugin.hook_ttp_detect(options=options)
            
            # Finalize
            await self.progress_handler.handle_progress(
                self.plugin.scan_metadata, 100, "Complete"
            )
            result = self.plugin._finalize_scan_result(options)
            
            self.plugin.scan_metadata.status = ScanStatus.COMPLETED
            self.plugin.scan_metadata.completed_at = datetime.utcnow()
            
            return result.model_dump()
        
        except Exception as e:
            self.plugin.scan_metadata.status = ScanStatus.FAILED
            raise

