"""Statistics service."""

from typing import Dict, Any

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))


class StatisticsService:
    """Service for generating scan statistics."""
    
    def __init__(self, plugin_instance):
        """
        Initialize statistics service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get scan statistics."""
        stats = {
            "ioc_databases": {
                "hashes": len(self.plugin.ioc_hashes),
                "ips": len(self.plugin.ioc_ips),
                "domains": len(self.plugin.ioc_domains),
                "urls": len(self.plugin.ioc_urls),
            },
            "yara_rules": {
                "loaded": self.plugin.yara_rules is not None,
                "rule_paths": len(self.plugin.yara_rules_paths)
            },
            "findings": {
                "file": len(self.plugin.findings.get("file", [])),
                "process": len(self.plugin.findings.get("process", [])),
                "network": len(self.plugin.findings.get("network", [])),
                "log": len(self.plugin.findings.get("log", [])),
                "persistence": len(self.plugin.findings.get("persistence", [])),
                "memory": len(self.plugin.findings.get("memory", [])),
                "ttp": len(self.plugin.findings.get("ttp", [])),
            },
            "scan_metadata": self.plugin.scan_metadata.model_dump() if self.plugin.scan_metadata else None
        }
        
        return stats

