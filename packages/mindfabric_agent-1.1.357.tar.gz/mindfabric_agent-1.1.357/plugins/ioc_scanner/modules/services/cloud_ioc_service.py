"""
Cloud IOC Detection Service

Detects Indicators of Compromise in cloud audit logs:
- AWS CloudTrail IOCs
- Azure Activity Logs IOCs
- GCP Audit Logs IOCs
- Cloud-specific attack patterns
- Security service findings

MITRE ATT&CK:
- T1078: Valid Accounts
- T1098: Account Manipulation
- T1530: Data from Cloud Storage Object
- T1537: Transfer Data to Cloud Account
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from utils.logger import logger


class CloudIOCSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class CloudIOCType(str, Enum):
    """Types of cloud IOCs."""
    IAM_ABUSE = "iam_abuse"
    DATA_EXFILTRATION = "data_exfiltration"
    DEFENSE_EVASION = "defense_evasion"
    PERSISTENCE = "persistence"
    CREDENTIAL_ACCESS = "credential_access"
    RECONNAISSANCE = "reconnaissance"
    INITIAL_ACCESS = "initial_access"


# =============================================================================
# AWS CloudTrail IOC Patterns
# =============================================================================

AWS_CLOUDTRAIL_IOCS = {
    # IAM Abuse
    "iam_user_creation": {
        "name": "IAM User Created",
        "event_name": "CreateUser",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1136.003",
    },
    "iam_access_key_creation": {
        "name": "IAM Access Key Created",
        "event_name": "CreateAccessKey",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1098.001",
    },
    "iam_policy_attachment": {
        "name": "Policy Attached to User/Role",
        "event_names": ["AttachUserPolicy", "AttachRolePolicy", "PutUserPolicy", "PutRolePolicy"],
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1098",
    },
    "iam_assume_role": {
        "name": "Assume Role",
        "event_name": "AssumeRole",
        "severity": CloudIOCSeverity.LOW,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1550.001",
    },
    "iam_console_login": {
        "name": "Console Login",
        "event_name": "ConsoleLogin",
        "severity": CloudIOCSeverity.LOW,
        "ioc_type": CloudIOCType.INITIAL_ACCESS,
        "mitre": "T1078.004",
    },
    "iam_console_login_failure": {
        "name": "Console Login Failure",
        "event_name": "ConsoleLogin",
        "error_code": "Failed",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.INITIAL_ACCESS,
        "mitre": "T1110",
    },
    "iam_mfa_disabled": {
        "name": "MFA Disabled",
        "event_name": "DeactivateMFADevice",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1556",
    },
    
    # Defense Evasion
    "cloudtrail_stopped": {
        "name": "CloudTrail Stopped",
        "event_name": "StopLogging",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
    "cloudtrail_deleted": {
        "name": "CloudTrail Deleted",
        "event_name": "DeleteTrail",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
    "guardduty_disabled": {
        "name": "GuardDuty Disabled",
        "event_names": ["DeleteDetector", "UpdateDetector"],
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.001",
    },
    "config_disabled": {
        "name": "AWS Config Disabled",
        "event_name": "StopConfigurationRecorder",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.001",
    },
    "log_group_deleted": {
        "name": "CloudWatch Log Group Deleted",
        "event_name": "DeleteLogGroup",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1070.004",
    },
    
    # Data Exfiltration
    "s3_public_access": {
        "name": "S3 Bucket Made Public",
        "event_names": ["PutBucketAcl", "PutBucketPolicy", "PutPublicAccessBlock"],
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
    "s3_replication_enabled": {
        "name": "S3 Replication Enabled",
        "event_name": "PutBucketReplication",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
    "rds_snapshot_public": {
        "name": "RDS Snapshot Made Public",
        "event_name": "ModifyDBSnapshotAttribute",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1530",
    },
    "ec2_snapshot_shared": {
        "name": "EC2 Snapshot Shared",
        "event_name": "ModifySnapshotAttribute",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
    
    # Secrets Access
    "secrets_manager_access": {
        "name": "Secrets Manager Secret Accessed",
        "event_name": "GetSecretValue",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1552.004",
    },
    "ssm_parameter_access": {
        "name": "SSM Parameter Accessed",
        "event_name": "GetParameter",
        "severity": CloudIOCSeverity.LOW,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1552.001",
    },
    
    # Reconnaissance
    "iam_enumeration": {
        "name": "IAM Enumeration",
        "event_names": ["ListUsers", "ListRoles", "ListGroups", "GetAccountAuthorizationDetails"],
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.RECONNAISSANCE,
        "mitre": "T1087.004",
    },
    "s3_enumeration": {
        "name": "S3 Bucket Enumeration",
        "event_names": ["ListBuckets", "ListObjects", "GetBucketLocation"],
        "severity": CloudIOCSeverity.LOW,
        "ioc_type": CloudIOCType.RECONNAISSANCE,
        "mitre": "T1580",
    },
    
    # Network Changes
    "security_group_modified": {
        "name": "Security Group Modified",
        "event_names": ["AuthorizeSecurityGroupIngress", "AuthorizeSecurityGroupEgress"],
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1562.007",
    },
    "vpc_flow_logs_disabled": {
        "name": "VPC Flow Logs Disabled",
        "event_name": "DeleteFlowLogs",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
}


# =============================================================================
# Azure Activity Log IOC Patterns
# =============================================================================

AZURE_ACTIVITY_LOG_IOCS = {
    # Identity Abuse
    "azure_ad_user_created": {
        "name": "Azure AD User Created",
        "operation": "Add user",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1136.003",
    },
    "azure_ad_app_credential": {
        "name": "App Registration Credential Added",
        "operations": ["Add service principal credentials", "Update application – Certificates and secrets management"],
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1098.001",
    },
    "azure_role_assignment": {
        "name": "Role Assignment Created",
        "operation": "Create role assignment",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1098",
    },
    "azure_ad_mfa_disabled": {
        "name": "MFA Disabled",
        "operation": "Disable Strong Authentication",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1556",
    },
    "azure_conditional_access_modified": {
        "name": "Conditional Access Policy Modified",
        "operations": ["Update conditional access policy", "Delete conditional access policy"],
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.001",
    },
    
    # Defense Evasion
    "azure_diagnostic_settings_deleted": {
        "name": "Diagnostic Settings Deleted",
        "operation": "Delete diagnostic setting",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
    "azure_log_profile_deleted": {
        "name": "Log Profile Deleted",
        "operation": "Delete log profile",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
    "azure_security_center_disabled": {
        "name": "Security Center Disabled",
        "operation": "Security policies update",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.001",
    },
    
    # Data Exfiltration
    "azure_storage_public": {
        "name": "Storage Made Public",
        "operation": "Update Storage Account",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
    "azure_key_vault_access": {
        "name": "Key Vault Secret Accessed",
        "operation": "SecretGet",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1552.004",
    },
    
    # Network
    "azure_nsg_rule_created": {
        "name": "NSG Rule Created",
        "operation": "Create or Update Security Rule",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1562.007",
    },
    "azure_firewall_rule_deleted": {
        "name": "Firewall Rule Deleted",
        "operation": "Delete Firewall Rule",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.007",
    },
}


# =============================================================================
# GCP Audit Log IOC Patterns
# =============================================================================

GCP_AUDIT_LOG_IOCS = {
    # IAM Abuse
    "gcp_iam_policy_changed": {
        "name": "IAM Policy Changed",
        "methods": ["SetIamPolicy", "UpdateIamPolicy"],
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1098",
    },
    "gcp_service_account_key_created": {
        "name": "Service Account Key Created",
        "method": "CreateServiceAccountKey",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1098.001",
    },
    "gcp_service_account_created": {
        "name": "Service Account Created",
        "method": "CreateServiceAccount",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1136.003",
    },
    
    # Defense Evasion
    "gcp_logging_sink_deleted": {
        "name": "Logging Sink Deleted",
        "method": "DeleteSink",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.008",
    },
    "gcp_log_bucket_deleted": {
        "name": "Log Bucket Deleted",
        "method": "DeleteBucket",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1070.004",
    },
    "gcp_security_command_center_disabled": {
        "name": "Security Command Center Disabled",
        "method": "UpdateOrganizationSettings",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.001",
    },
    
    # Data Exfiltration
    "gcp_bucket_iam_public": {
        "name": "GCS Bucket Made Public",
        "method": "storage.buckets.setIamPolicy",
        "severity": CloudIOCSeverity.CRITICAL,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
    "gcp_secret_accessed": {
        "name": "Secret Manager Secret Accessed",
        "method": "AccessSecretVersion",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.CREDENTIAL_ACCESS,
        "mitre": "T1552.004",
    },
    
    # Network
    "gcp_firewall_rule_created": {
        "name": "Firewall Rule Created",
        "method": "compute.firewalls.insert",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1562.007",
    },
    "gcp_firewall_rule_deleted": {
        "name": "Firewall Rule Deleted",
        "method": "compute.firewalls.delete",
        "severity": CloudIOCSeverity.MEDIUM,
        "ioc_type": CloudIOCType.DEFENSE_EVASION,
        "mitre": "T1562.007",
    },
    
    # Compute
    "gcp_instance_created": {
        "name": "Compute Instance Created",
        "method": "compute.instances.insert",
        "severity": CloudIOCSeverity.LOW,
        "ioc_type": CloudIOCType.PERSISTENCE,
        "mitre": "T1610",
    },
    "gcp_snapshot_exported": {
        "name": "Snapshot Exported",
        "method": "compute.images.export",
        "severity": CloudIOCSeverity.HIGH,
        "ioc_type": CloudIOCType.DATA_EXFILTRATION,
        "mitre": "T1537",
    },
}


# =============================================================================
# Suspicious Patterns (Cross-Cloud)
# =============================================================================

SUSPICIOUS_PATTERNS = {
    "off_hours_activity": {
        "name": "Off-Hours Activity",
        "description": "Administrative activity during unusual hours",
        "severity": CloudIOCSeverity.MEDIUM,
        "hours": [0, 1, 2, 3, 4, 5, 22, 23],  # Late night
    },
    "geographic_anomaly": {
        "name": "Geographic Anomaly",
        "description": "Activity from unusual geographic location",
        "severity": CloudIOCSeverity.HIGH,
    },
    "impossible_travel": {
        "name": "Impossible Travel",
        "description": "Activity from distant locations in short time",
        "severity": CloudIOCSeverity.HIGH,
        "mitre": "T1078",
    },
    "multiple_failures": {
        "name": "Multiple Authentication Failures",
        "description": "Multiple failed authentication attempts",
        "severity": CloudIOCSeverity.MEDIUM,
        "threshold": 5,
        "mitre": "T1110",
    },
    "privilege_escalation_pattern": {
        "name": "Privilege Escalation Pattern",
        "description": "Sequence of actions indicating privilege escalation",
        "severity": CloudIOCSeverity.HIGH,
        "mitre": "T1098",
    },
}


@dataclass
class CloudIOCFinding:
    """A cloud IOC finding."""
    ioc_type: CloudIOCType
    severity: CloudIOCSeverity
    cloud_provider: str
    name: str
    description: str
    event_data: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    timestamp: str = ""
    user_identity: str = ""
    source_ip: str = ""


@dataclass
class CloudIOCReport:
    """Cloud IOC detection report."""
    findings: List[CloudIOCFinding] = field(default_factory=list)
    aws_iocs: int = 0
    azure_iocs: int = 0
    gcp_iocs: int = 0
    critical_findings: int = 0
    risk_score: float = 0.0


class CloudIOCService:
    """Service for detecting cloud IOCs."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[CloudIOCFinding] = []
    
    async def analyze_cloudtrail_event(
        self,
        event: Dict[str, Any],
    ) -> List[CloudIOCFinding]:
        """
        Analyze a CloudTrail event for IOCs.
        
        Args:
            event: CloudTrail event dictionary
            
        Returns:
            List of findings
        """
        findings = []
        
        event_name = event.get("eventName", "")
        event_time = event.get("eventTime", "")
        user_identity = event.get("userIdentity", {})
        source_ip = event.get("sourceIPAddress", "")
        error_code = event.get("errorCode", "")
        
        user_name = user_identity.get("userName", user_identity.get("arn", "unknown"))
        
        for ioc_key, ioc_config in AWS_CLOUDTRAIL_IOCS.items():
            matched = False
            
            # Check single event name
            if "event_name" in ioc_config and event_name == ioc_config["event_name"]:
                matched = True
            
            # Check multiple event names
            if "event_names" in ioc_config and event_name in ioc_config["event_names"]:
                matched = True
            
            # Check error code for failed logins
            if "error_code" in ioc_config:
                if ioc_config["error_code"] == "Failed" and error_code:
                    matched = matched and True
                else:
                    matched = False
            
            if matched:
                findings.append(CloudIOCFinding(
                    ioc_type=ioc_config["ioc_type"],
                    severity=ioc_config["severity"],
                    cloud_provider="aws",
                    name=ioc_config["name"],
                    description=f"CloudTrail event: {event_name}",
                    event_data={
                        "event_name": event_name,
                        "event_id": event.get("eventID", ""),
                        "aws_region": event.get("awsRegion", ""),
                    },
                    mitre_technique=ioc_config.get("mitre", ""),
                    timestamp=event_time,
                    user_identity=user_name,
                    source_ip=source_ip,
                ))
        
        return findings
    
    async def analyze_azure_activity(
        self,
        activity: Dict[str, Any],
    ) -> List[CloudIOCFinding]:
        """
        Analyze an Azure Activity Log event for IOCs.
        
        Args:
            activity: Azure Activity Log event
            
        Returns:
            List of findings
        """
        findings = []
        
        operation = activity.get("operationName", {}).get("localizedValue", "")
        event_time = activity.get("eventTimestamp", "")
        caller = activity.get("caller", "unknown")
        
        for ioc_key, ioc_config in AZURE_ACTIVITY_LOG_IOCS.items():
            matched = False
            
            if "operation" in ioc_config and operation == ioc_config["operation"]:
                matched = True
            
            if "operations" in ioc_config and operation in ioc_config["operations"]:
                matched = True
            
            if matched:
                findings.append(CloudIOCFinding(
                    ioc_type=ioc_config["ioc_type"],
                    severity=ioc_config["severity"],
                    cloud_provider="azure",
                    name=ioc_config["name"],
                    description=f"Azure Activity: {operation}",
                    event_data={
                        "operation": operation,
                        "resource_id": activity.get("resourceId", ""),
                    },
                    mitre_technique=ioc_config.get("mitre", ""),
                    timestamp=event_time,
                    user_identity=caller,
                ))
        
        return findings
    
    async def analyze_gcp_audit_log(
        self,
        log_entry: Dict[str, Any],
    ) -> List[CloudIOCFinding]:
        """
        Analyze a GCP Audit Log entry for IOCs.
        
        Args:
            log_entry: GCP Audit Log entry
            
        Returns:
            List of findings
        """
        findings = []
        
        proto_payload = log_entry.get("protoPayload", {})
        method_name = proto_payload.get("methodName", "")
        timestamp = log_entry.get("timestamp", "")
        principal_email = proto_payload.get("authenticationInfo", {}).get("principalEmail", "unknown")
        caller_ip = proto_payload.get("requestMetadata", {}).get("callerIp", "")
        
        for ioc_key, ioc_config in GCP_AUDIT_LOG_IOCS.items():
            matched = False
            
            if "method" in ioc_config and method_name == ioc_config["method"]:
                matched = True
            
            if "methods" in ioc_config and method_name in ioc_config["methods"]:
                matched = True
            
            if matched:
                findings.append(CloudIOCFinding(
                    ioc_type=ioc_config["ioc_type"],
                    severity=ioc_config["severity"],
                    cloud_provider="gcp",
                    name=ioc_config["name"],
                    description=f"GCP Audit Log: {method_name}",
                    event_data={
                        "method_name": method_name,
                        "resource_name": proto_payload.get("resourceName", ""),
                    },
                    mitre_technique=ioc_config.get("mitre", ""),
                    timestamp=timestamp,
                    user_identity=principal_email,
                    source_ip=caller_ip,
                ))
        
        return findings
    
    async def analyze_events_batch(
        self,
        events: List[Dict[str, Any]],
        cloud_provider: str,
    ) -> CloudIOCReport:
        """
        Analyze a batch of cloud events.
        
        Args:
            events: List of cloud events
            cloud_provider: Cloud provider name (aws, azure, gcp)
            
        Returns:
            CloudIOCReport
        """
        all_findings = []
        
        for event in events:
            if cloud_provider == "aws":
                findings = await self.analyze_cloudtrail_event(event)
            elif cloud_provider == "azure":
                findings = await self.analyze_azure_activity(event)
            elif cloud_provider == "gcp":
                findings = await self.analyze_gcp_audit_log(event)
            else:
                continue
            
            all_findings.extend(findings)
        
        # Count by provider
        aws_count = sum(1 for f in all_findings if f.cloud_provider == "aws")
        azure_count = sum(1 for f in all_findings if f.cloud_provider == "azure")
        gcp_count = sum(1 for f in all_findings if f.cloud_provider == "gcp")
        
        # Count critical
        critical_count = sum(1 for f in all_findings if f.severity == CloudIOCSeverity.CRITICAL)
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return CloudIOCReport(
            findings=all_findings,
            aws_iocs=aws_count,
            azure_iocs=azure_count,
            gcp_iocs=gcp_count,
            critical_findings=critical_count,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[CloudIOCFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            CloudIOCSeverity.CRITICAL: 10,
            CloudIOCSeverity.HIGH: 7,
            CloudIOCSeverity.MEDIUM: 4,
            CloudIOCSeverity.LOW: 1,
            CloudIOCSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[CloudIOCFinding]:
        """Get all findings."""
        return self.findings
    
    def get_ioc_patterns(self) -> Dict[str, Any]:
        """Get all IOC pattern databases."""
        return {
            "aws_cloudtrail": AWS_CLOUDTRAIL_IOCS,
            "azure_activity": AZURE_ACTIVITY_LOG_IOCS,
            "gcp_audit": GCP_AUDIT_LOG_IOCS,
            "suspicious_patterns": SUSPICIOUS_PATTERNS,
        }

