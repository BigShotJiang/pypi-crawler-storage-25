"""Network IOC scanning service."""

import socket
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Set

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    NetworkFinding,
    NetworkConnection,
    IoCIndicator,
    IoCMatch,
    BeaconingPattern,
    ScanOptions,
    NetworkProtocol,
    IoCType,
    SeverityLevel,
    ConfidenceLevel,
)
from ..databases import KNOWN_C2_PORTS, SUSPICIOUS_DOMAIN_PATTERNS
import re
from ..detection import BeaconingDetector


class NetworkScannerService:
    """Service for network IOC scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize network scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
        self.beaconing_detector = BeaconingDetector()
    
    async def scan_network(
        self,
        ioc_ips: List[str] = None,
        ioc_domains: List[str] = None,
        options: ScanOptions = None,
    ) -> List[NetworkFinding]:
        """
        Comprehensive network IOC scanning.
        
        Args:
            ioc_ips: List of malicious IPs
            ioc_domains: List of malicious domains
            options: Scan configuration
        
        Returns:
            List of NetworkFinding
        """
        if not HAS_PSUTIL:
            return []
        
        if options is None:
            options = ScanOptions()
        
        results: List[NetworkFinding] = []
        
        # Build IOC sets
        bad_ips: Set[str] = set(ioc_ips or [])
        bad_ips.update(self.plugin.ioc_ips.keys())
        
        bad_domains: Set[str] = set(d.lower() for d in (ioc_domains or []))
        bad_domains.update(self.plugin.ioc_domains.keys())
        
        # Track connections for beaconing analysis
        connection_history: Dict[str, List[datetime]] = defaultdict(list)
        
        try:
            # Get all connections
            connections = psutil.net_connections(kind='inet')
            
            for conn in connections:
                try:
                    # Skip if no remote address
                    if not conn.raddr:
                        continue
                    
                    remote_ip = conn.raddr.ip
                    remote_port = conn.raddr.port
                    local_port = conn.laddr.port if conn.laddr else 0
                    
                    # Get process info
                    proc_name = None
                    proc_pid = conn.pid
                    if proc_pid:
                        try:
                            proc_name = psutil.Process(proc_pid).name()
                        except Exception:
                            pass
                    
                    net_conn = NetworkConnection(
                        local_address=conn.laddr.ip if conn.laddr else "",
                        local_port=local_port,
                        remote_address=remote_ip,
                        remote_port=remote_port,
                        protocol=NetworkProtocol.TCP if conn.type == socket.SOCK_STREAM else NetworkProtocol.UDP,
                        status=conn.status,
                        pid=proc_pid,
                        process_name=proc_name
                    )
                    
                    # Check 1: IP IOC match
                    if remote_ip in bad_ips:
                        indicator = self.plugin.ioc_ips.get(remote_ip, IoCIndicator(
                            value=remote_ip,
                            type=IoCType.IP_V4,
                            severity=SeverityLevel.HIGH
                        ))
                        results.append(NetworkFinding(
                            finding_type="ioc_match",
                            severity=indicator.severity,
                            confidence=ConfidenceLevel.CONFIRMED,
                            connection=net_conn,
                            remote_ip=remote_ip,
                            remote_port=remote_port,
                            process_pid=proc_pid,
                            process_name=proc_name,
                            ioc_match=IoCMatch(
                                indicator=indicator,
                                target=remote_ip,
                                target_type="network",
                                match_type="exact",
                                severity=indicator.severity,
                                confidence=ConfidenceLevel.CONFIRMED
                            ),
                            threat_category=indicator.threat_category,
                            description=f"Connection to known malicious IP: {remote_ip}",
                            reason="IP IOC match",
                            mitre_techniques=["T1071"]
                        ))
                    
                    # Check 2: Known C2 port
                    if remote_port in KNOWN_C2_PORTS:
                        results.append(NetworkFinding(
                            finding_type="suspicious_port",
                            severity=SeverityLevel.MEDIUM,
                            confidence=ConfidenceLevel.LOW,
                            connection=net_conn,
                            remote_ip=remote_ip,
                            remote_port=remote_port,
                            process_pid=proc_pid,
                            process_name=proc_name,
                            description=f"Connection to known C2 port: {remote_port}",
                            reason=f"C2 port: {remote_port}",
                            mitre_techniques=["T1571"]
                        ))
                    
                    # Check 3: Suspicious domain pattern (via reverse DNS)
                    domain_finding = self._check_suspicious_domain(remote_ip, net_conn, proc_pid, proc_name)
                    if domain_finding:
                        results.append(domain_finding)
                    
                    # Track for beaconing analysis
                    dest_key = f"{remote_ip}:{remote_port}"
                    connection_history[dest_key].append(datetime.utcnow())
                
                except Exception:
                    continue
            
            # Check 4: Beaconing detection
            if options.scope.check_c2_beaconing:
                beaconing = await self.beaconing_detector.detect(connection_history)
                results.extend(beaconing)
        
        except Exception as e:
            await self.plugin._send_alert("ioc_network_error", str(e), SeverityLevel.HIGH)
        
        return results
    
    def _check_suspicious_domain(
        self,
        ip_address: str,
        connection: NetworkConnection,
        proc_pid: int,
        proc_name: str
    ) -> NetworkFinding:
        """Check if IP resolves to suspicious domain pattern."""
        try:
            # Attempt reverse DNS lookup
            hostname, _, _ = socket.gethostbyaddr(ip_address)
            hostname = hostname.lower()
            
            # Check against suspicious domain patterns
            for pattern_info in SUSPICIOUS_DOMAIN_PATTERNS:
                if not isinstance(pattern_info, dict):
                    continue
                
                pattern = pattern_info.get("pattern", "")
                if pattern and re.match(pattern, hostname, re.IGNORECASE):
                    return NetworkFinding(
                        finding_type="suspicious_domain",
                        severity=pattern_info.get("severity", SeverityLevel.MEDIUM),
                        confidence=ConfidenceLevel.MEDIUM,
                        connection=connection,
                        remote_ip=ip_address,
                        remote_port=connection.remote_port,
                        process_pid=proc_pid,
                        process_name=proc_name,
                        description=f"Connection to suspicious domain: {hostname} ({pattern_info.get('name', 'Unknown pattern')})",
                        reason=f"Domain matches suspicious pattern: {pattern_info.get('name', 'Unknown')}",
                        mitre_techniques=["T1071.001"]
                    )
        except (socket.herror, socket.gaierror):
            # Reverse DNS lookup failed - not suspicious on its own
            pass
        except Exception:
            pass
        
        return None
    
    def check_domain_against_patterns(self, domain: str) -> List[Dict]:
        """Check a domain against all suspicious patterns.
        
        Useful for checking domains from DNS logs or other sources.
        """
        matches = []
        domain = domain.lower()
        
        for pattern_info in SUSPICIOUS_DOMAIN_PATTERNS:
            if not isinstance(pattern_info, dict):
                continue
            
            pattern = pattern_info.get("pattern", "")
            if pattern and re.match(pattern, domain, re.IGNORECASE):
                matches.append({
                    "domain": domain,
                    "pattern_name": pattern_info.get("name", "Unknown"),
                    "pattern": pattern,
                    "severity": pattern_info.get("severity", SeverityLevel.MEDIUM),
                })
        
        return matches

