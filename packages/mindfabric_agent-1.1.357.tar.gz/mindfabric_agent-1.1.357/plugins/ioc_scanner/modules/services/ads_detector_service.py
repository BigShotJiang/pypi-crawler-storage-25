"""
Alternate Data Streams (ADS) Detector Service

Detects NTFS Alternate Data Streams (T1564.004) - hidden data in ADS.
"""

import os
import logging
import uuid
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any

from ...proto import (
    FileSystemFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

logger = logging.getLogger(__name__)


class ADSDetectorService:
    """Service for detecting Alternate Data Streams."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[FileSystemFinding] = []
        self._is_windows = os.name == 'nt'
    
    async def detect_ads(
        self,
        directory_paths: List[str],
        recursive: bool = True,
    ) -> List[FileSystemFinding]:
        """
        Detect Alternate Data Streams in directories.
        
        Args:
            directory_paths: List of directory paths to scan
            recursive: Whether to scan recursively
            
        Returns:
            List of ADS findings
        """
        findings = []
        
        if not self._is_windows:
            # ADS is Windows-specific
            logger.debug("ADS detection is only available on Windows")
            return findings
        
        for dir_path in directory_paths:
            try:
                dir_findings = await self._scan_directory_for_ads(dir_path, recursive)
                findings.extend(dir_findings)
            except Exception as e:
                logger.debug(f"Error scanning {dir_path} for ADS: {e}")
                continue
        
        self.findings.extend(findings)
        return findings
    
    async def _scan_directory_for_ads(
        self,
        directory_path: str,
        recursive: bool = True,
    ) -> List[FileSystemFinding]:
        """Scan directory for Alternate Data Streams."""
        findings = []
        
        try:
            # Use PowerShell to enumerate ADS
            if recursive:
                cmd = [
                    "powershell", "-Command",
                    f"Get-ChildItem -Path '{directory_path}' -Recurse -File | "
                    f"ForEach-Object {{ $file = $_.FullName; "
                    f"Get-Item -Path $file -Stream * | "
                    f"Where-Object {{ $_.Stream -ne ':$DATA' }} | "
                    f"ForEach-Object {{ [PSCustomObject]@{{ "
                    f"File = $file; "
                    f"Stream = $_.Stream; "
                    f"Length = $_.Length "
                    f"}} }} }} | ConvertTo-Json"
                ]
            else:
                cmd = [
                    "powershell", "-Command",
                    f"Get-ChildItem -Path '{directory_path}' -File | "
                    f"ForEach-Object {{ $file = $_.FullName; "
                    f"Get-Item -Path $file -Stream * | "
                    f"Where-Object {{ $_.Stream -ne ':$DATA' }} | "
                    f"ForEach-Object {{ [PSCustomObject]@{{ "
                    f"File = $file; "
                    f"Stream = $_.Stream; "
                    f"Length = $_.Length "
                    f"}} }} }} | ConvertTo-Json"
                ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minutes max
            )
            
            if result.returncode == 0 and result.stdout.strip():
                import json
                try:
                    streams = json.loads(result.stdout)
                    if isinstance(streams, dict):
                        streams = [streams]
                    
                    for stream in streams:
                        file_path = stream.get("File", "")
                        stream_name = stream.get("Stream", "")
                        stream_length = stream.get("Length", 0)
                        
                        # Check for suspicious ADS
                        if self._is_suspicious_ads(stream_name, stream_length):
                            findings.append(self._create_finding(
                                file_path,
                                stream_name,
                                f"Alternate Data Stream detected: {stream_name} ({stream_length} bytes)",
                                SeverityLevel.HIGH if stream_length > 1024 else SeverityLevel.MEDIUM,
                                ConfidenceLevel.HIGH,
                                {
                                    "stream_name": stream_name,
                                    "stream_length": stream_length,
                                },
                            ))
                except json.JSONDecodeError:
                    logger.debug(f"Error parsing ADS output: {result.stdout[:200]}")
        
        except Exception as e:
            logger.debug(f"Error scanning directory for ADS: {e}")
        
        return findings
    
    def _is_suspicious_ads(self, stream_name: str, stream_length: int) -> bool:
        """Check if ADS is suspicious."""
        # Remove :$DATA suffix if present
        stream_name_clean = stream_name.replace(":$DATA", "")
        
        # Suspicious patterns
        suspicious_patterns = [
            "Zone.Identifier",  # Download marker (usually OK, but can be abused)
            "encrypted",
            "hidden",
            "malware",
            "payload",
            "backdoor",
        ]
        
        # Large ADS (> 1MB) is suspicious
        if stream_length > 1024 * 1024:
            return True
        
        # ADS with suspicious name
        if any(pattern in stream_name_clean.lower() for pattern in suspicious_patterns):
            return True
        
        # ADS in system directories
        # This would be checked by caller based on file_path
        
        return False
    
    def _create_finding(
        self,
        file_path: str,
        stream_name: str,
        description: str,
        severity: SeverityLevel,
        confidence: ConfidenceLevel,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> FileSystemFinding:
        """Create an ADS finding."""
        
        evidence = [description]
        if stream_info:
            evidence.append(f"Stream info: {stream_info}")
        
        return FileSystemFinding(
            finding_type="alternate_data_stream",
            severity=severity,
            confidence=confidence,
            file_path=file_path,
            threat_category=ThreatCategory.DEFENSE_EVASION,
            description=description,
            evidence=evidence,
            mitre_techniques=["T1564.004"],
            remediation=f"Inspect Alternate Data Stream '{stream_name}' in file '{file_path}'. Use 'Get-Item -Path '{file_path}' -Stream *' to list all streams.",
        )
