"""AI/ML analysis service."""

import re
from typing import List, Dict, Any

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import AIAnalysisResult, AIClassification


class AIService:
    """Service for AI/ML analysis of IOC findings."""
    
    def __init__(self, plugin_instance):
        """
        Initialize AI service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def analyze(
        self,
        lines: str = None,
        findings: List[Dict] = None,
    ) -> Dict[str, Any]:
        """
        AI/ML analysis of IOC findings.
        
        Args:
            lines: Raw text to analyze
            findings: Existing findings to enrich
        
        Returns:
            AIAnalysisResult dictionary
        """
        result = AIAnalysisResult(
            analysis_type="classification"
        )
        
        # Extract entities from text
        if lines:
            # IP extraction
            ip_pattern = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
            ips = ip_pattern.findall(lines)
            for ip in set(ips):
                result.entities.append({"type": "ip", "value": ip})
            
            # Domain extraction
            domain_pattern = re.compile(r'\b([a-zA-Z0-9][-a-zA-Z0-9]*\.)+[a-zA-Z]{2,}\b')
            domains = domain_pattern.findall(lines)
            for domain in set(domains):
                result.entities.append({"type": "domain", "value": domain})
            
            # Hash extraction
            hash_pattern = re.compile(r'\b[a-fA-F0-9]{32,64}\b')
            hashes = hash_pattern.findall(lines)
            for h in set(hashes):
                result.entities.append({"type": "hash", "value": h})
            
            # Keywords
            threat_keywords = [
                "malware", "ransomware", "trojan", "backdoor", "exploit",
                "vulnerability", "attack", "compromise", "breach", "phishing"
            ]
            found_keywords = [kw for kw in threat_keywords if kw in lines.lower()]
            result.keywords = found_keywords
        
        # Simple classification (placeholder for real ML)
        if findings:
            critical_count = sum(1 for f in findings if f.get("severity") == "critical")
            high_count = sum(1 for f in findings if f.get("severity") == "high")
            
            if critical_count > 0:
                label = "critical_threat"
                confidence = 0.9
            elif high_count > 3:
                label = "high_threat"
                confidence = 0.8
            elif high_count > 0:
                label = "medium_threat"
                confidence = 0.7
            else:
                label = "low_threat"
                confidence = 0.6
            
            result.classification = AIClassification(
                model_name="rule_based_v1",
                label=label,
                confidence=confidence,
                probabilities={
                    "critical_threat": 0.1 if critical_count == 0 else 0.9,
                    "high_threat": 0.3 if high_count == 0 else 0.7,
                    "medium_threat": 0.4,
                    "low_threat": 0.2
                }
            )
        
        # Generate recommendations
        result.recommendations = [
            "Review all critical and high severity findings immediately",
            "Isolate affected systems if active compromise detected",
            "Collect forensic evidence before remediation",
            "Update IOC feeds and rerun scan after remediation",
            "Review logs for additional indicators"
        ]
        
        return result.model_dump()

