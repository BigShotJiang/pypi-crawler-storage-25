"""
PowerShell AST Analyzer Service

Analyzes PowerShell scripts using AST (Abstract Syntax Tree) parsing for deobfuscation and detection.
"""

import os
import logging
import uuid
import re
import base64
from typing import List, Optional, Dict, Any

from ...proto import (
    LogFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

logger = logging.getLogger(__name__)


class PowerShellAnalyzerService:
    """Service for analyzing PowerShell scripts using AST parsing."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[LogFinding] = []
        self._has_powershell_ast = False
        
        # Try to import PowerShell AST parser
        try:
            # PowerShell AST is available through System.Management.Automation
            # This requires PowerShell to be installed
            self._has_powershell_ast = self._check_powershell_available()
        except Exception:
            pass
    
    def _check_powershell_available(self) -> bool:
        """Check if PowerShell is available for AST parsing."""
        try:
            import subprocess
            result = subprocess.run(
                ["powershell", "-Command", "$PSVersionTable.PSVersion"],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False
    
    async def analyze_powershell(
        self,
        script_content: str,
        source: Optional[str] = None,
    ) -> List[LogFinding]:
        """
        Analyze PowerShell script using AST parsing.
        
        Args:
            script_content: PowerShell script content
            source: Source of the script (file path, log entry, etc.)
            
        Returns:
            List of PowerShell analysis findings
        """
        findings = []
        
        if not script_content:
            return findings
        
        # Method 1: AST-based analysis (if available)
        if self._has_powershell_ast:
            ast_findings = await self._analyze_with_ast(script_content, source)
            findings.extend(ast_findings)
        
        # Method 2: Pattern-based analysis (fallback)
        pattern_findings = await self._analyze_with_patterns(script_content, source)
        findings.extend(pattern_findings)
        
        # Method 3: Deobfuscation
        deobfuscated = await self._deobfuscate_powershell(script_content)
        if deobfuscated and deobfuscated != script_content:
            # Re-analyze deobfuscated version
            deob_findings = await self._analyze_with_patterns(deobfuscated, source or "deobfuscated")
            findings.extend(deob_findings)
        
        self.findings.extend(findings)
        return findings
    
    async def _analyze_with_ast(
        self,
        script_content: str,
        source: Optional[str],
    ) -> List[LogFinding]:
        """Analyze PowerShell using AST parsing."""
        findings = []
        
        try:
            import subprocess
            import json
            import tempfile
            
            # Create temporary script file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False) as f:
                f.write(script_content)
                temp_file = f.name
            
            try:
                # Use PowerShell to parse AST
                ps_script = f"""
$script = Get-Content '{temp_file}' -Raw
$ast = [System.Management.Automation.Language.Parser]::ParseInput($script, [ref]$null, [ref]$null)
$findings = @()

# Check for obfuscation patterns
if ($ast.FindAll({{$args[0] -is [System.Management.Automation.Language.StringConstantExpressionAst]}}, $true) | 
    Where-Object {{$_.Value.Length -gt 100}}) {{
    $findings += @{{Type='LongString'; Severity='Medium'}}
}}

# Check for Invoke-Expression
if ($ast.FindAll({{$args[0] -is [System.Management.Automation.Language.CommandAst]}}, $true) | 
    Where-Object {{$_.CommandElements[0].Value -eq 'Invoke-Expression' -or $_.CommandElements[0].Value -eq 'IEX'}}) {{
    $findings += @{{Type='InvokeExpression'; Severity='High'}}
}}

# Check for DownloadString
if ($ast.FindAll({{$args[0] -is [System.Management.Automation.Language.MemberExpressionAst]}}, $true) | 
    Where-Object {{$_.Member.Value -eq 'DownloadString'}}) {{
    $findings += @{{Type='DownloadString'; Severity='High'}}
}}

$findings | ConvertTo-Json
"""
                
                result = subprocess.run(
                    ["powershell", "-Command", ps_script],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                
                if result.returncode == 0 and result.stdout.strip():
                    ast_findings = json.loads(result.stdout)
                    if isinstance(ast_findings, dict):
                        ast_findings = [ast_findings]
                    
                    for finding in ast_findings:
                        findings.append(self._create_finding(
                            source or "powershell_script",
                            finding.get("Type", "AST_Anomaly"),
                            f"PowerShell AST analysis detected: {finding.get('Type', 'Unknown')}",
                            SeverityLevel.HIGH if finding.get("Severity") == "High" else SeverityLevel.MEDIUM,
                            ConfidenceLevel.HIGH,
                        ))
            
            finally:
                os.unlink(temp_file)
        
        except Exception as e:
            logger.debug(f"Error in AST analysis: {e}")
        
        return findings
    
    async def _analyze_with_patterns(
        self,
        script_content: str,
        source: Optional[str],
    ) -> List[LogFinding]:
        """Analyze PowerShell using pattern matching."""
        findings = []
        
        # Pattern 1: Encoded commands
        encoded_patterns = [
            (r'-enc(odedcommand)?\s+([A-Za-z0-9+/=]{20,})', "Encoded command detected"),
            (r'FromBase64String\s*\(', "Base64 decoding detected"),
        ]
        
        for pattern, description in encoded_patterns:
            if re.search(pattern, script_content, re.IGNORECASE):
                findings.append(self._create_finding(
                    source or "powershell_script",
                    "encoded_command",
                    description,
                    SeverityLevel.HIGH,
                    ConfidenceLevel.HIGH,
                ))
        
        # Pattern 2: Download cradles
        download_patterns = [
            (r'DownloadString\s*\(', "Download cradle detected"),
            (r'DownloadFile\s*\(', "File download detected"),
            (r'Invoke-WebRequest', "Web request detected"),
            (r'IEX\s*\(', "Invoke-Expression detected"),
        ]
        
        for pattern, description in download_patterns:
            if re.search(pattern, script_content, re.IGNORECASE):
                findings.append(self._create_finding(
                    source or "powershell_script",
                    "download_cradle",
                    description,
                    SeverityLevel.HIGH,
                    ConfidenceLevel.MEDIUM,
                ))
        
        # Pattern 3: Obfuscation techniques
        obfuscation_patterns = [
            (r'\$[a-z]+\s*\+\s*\$[a-z]+', "String concatenation obfuscation"),
            (r'\[char\]\d+', "Character code obfuscation"),
            (r'-join\s*\(', "Join operator obfuscation"),
        ]
        
        for pattern, description in obfuscation_patterns:
            matches = re.findall(pattern, script_content, re.IGNORECASE)
            if len(matches) > 3:  # Multiple obfuscation patterns
                findings.append(self._create_finding(
                    source or "powershell_script",
                    "obfuscation",
                    f"Obfuscation detected: {description}",
                    SeverityLevel.MEDIUM,
                    ConfidenceLevel.MEDIUM,
                ))
        
        return findings
    
    async def _deobfuscate_powershell(self, script_content: str) -> Optional[str]:
        """Attempt to deobfuscate PowerShell script."""
        deobfuscated = script_content
        
        # Try to decode base64 encoded commands
        base64_pattern = r'-enc(odedcommand)?\s+([A-Za-z0-9+/=]{20,})'
        match = re.search(base64_pattern, script_content, re.IGNORECASE)
        
        if match:
            try:
                encoded = match.group(2)
                decoded = base64.b64decode(encoded).decode('utf-16le', errors='ignore')
                deobfuscated = deobfuscated.replace(match.group(0), f"# Decoded: {decoded}")
            except Exception:
                pass
        
        return deobfuscated if deobfuscated != script_content else None
    
    def _create_finding(
        self,
        source: str,
        finding_type: str,
        description: str,
        severity: SeverityLevel,
        confidence: ConfidenceLevel,
    ) -> LogFinding:
        """Create a PowerShell analysis finding."""
        
        return LogFinding(
            finding_type=finding_type,
            severity=severity,
            confidence=confidence,
            source=source,
            threat_category=ThreatCategory.EXECUTION,
            description=description,
            evidence=[description],
            mitre_techniques=["T1059.001"],
            remediation="Review PowerShell script for malicious activity. Check command line arguments and script content.",
        )
