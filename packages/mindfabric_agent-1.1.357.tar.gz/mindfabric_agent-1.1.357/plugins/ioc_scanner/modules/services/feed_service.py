"""Threat Intelligence feed service."""

import json
from datetime import datetime
from typing import List, Dict, Any

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    TIResult,
    IoCIndicator,
    ThreatCategory,
    IoCType,
)
from ..databases import DEFAULT_TI_FEEDS
from ..utils import detect_ioc_type


class FeedService:
    """Service for Threat Intelligence feed synchronization."""
    
    def __init__(self, plugin_instance):
        """
        Initialize feed service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    def parse_feed_content(self, content: str, url: str) -> List[IoCIndicator]:
        """Parse feed content into IOC indicators."""
        iocs = []
        
        # Detect format
        if url.endswith(".json") or content.strip().startswith("{"):
            try:
                data = json.loads(content)
                # Handle various JSON structures
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, str):
                            ioc_type = detect_ioc_type(item)
                            iocs.append(IoCIndicator(value=item, type=ioc_type))
                        elif isinstance(item, dict):
                            value = item.get("ioc") or item.get("indicator") or item.get("value")
                            if value:
                                ioc_type = detect_ioc_type(value)
                                iocs.append(IoCIndicator(
                                    value=value,
                                    type=ioc_type,
                                    threat_category=ThreatCategory(item.get("threat_type", "unknown")) if item.get("threat_type") else None,
                                    malware_family=item.get("malware"),
                                    tags=item.get("tags", [])
                                ))
            except json.JSONDecodeError:
                pass
        
        elif url.endswith(".csv"):
            # CSV format - assume first column is IOC
            for line in content.strip().split("\n"):
                if line.startswith("#") or "," not in line:
                    continue
                parts = line.split(",")
                value = parts[0].strip().strip('"')
                if value:
                    ioc_type = detect_ioc_type(value)
                    iocs.append(IoCIndicator(value=value, type=ioc_type))
        
        else:
            # Plain text - one IOC per line
            for line in content.strip().split("\n"):
                line = line.strip()
                if line and not line.startswith("#"):
                    ioc_type = detect_ioc_type(line)
                    iocs.append(IoCIndicator(value=line, type=ioc_type))
        
        return iocs
    
    async def sync_feeds(
        self,
        feed_url: str = None,
        feed_urls: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Sync Threat Intelligence feeds.
        
        Args:
            feed_url: Single feed URL
            feed_urls: Multiple feed URLs
        
        Returns:
            TIResult dictionary
        """
        if not HAS_HTTPX:
            return TIResult(
                operation="sync",
                status="failed",
                errors=["httpx not available"]
            ).model_dump()
        
        urls = []
        if feed_url:
            urls.append(feed_url)
        if feed_urls:
            urls.extend(feed_urls)
        
        # Add default feeds if no URLs provided
        if not urls:
            urls = [f["url"] for f in DEFAULT_TI_FEEDS]
        
        result = TIResult(
            operation="sync",
            status="running",
            started_at=datetime.utcnow()
        )
        
        async with httpx.AsyncClient(timeout=30) as client:
            for url in urls:
                try:
                    response = await client.get(url)
                    if response.status_code == 200:
                        # Parse based on content type
                        content = response.text
                        iocs = self.parse_feed_content(content, url)
                        
                        result.indicators_loaded += len(iocs)
                        result.feeds_processed.append(url)
                        
                        # Add to internal databases
                        for ioc in iocs:
                            if ioc.type in [IoCType.MD5, IoCType.SHA1, IoCType.SHA256]:
                                self.plugin.ioc_hashes[ioc.value.lower()] = ioc
                            elif ioc.type in [IoCType.IP_V4, IoCType.IP_V6]:
                                self.plugin.ioc_ips[ioc.value] = ioc
                            elif ioc.type == IoCType.DOMAIN:
                                self.plugin.ioc_domains[ioc.value.lower()] = ioc
                            elif ioc.type == IoCType.URL:
                                self.plugin.ioc_urls[ioc.value] = ioc
                    else:
                        result.feeds_failed.append(url)
                        result.errors.append(f"HTTP {response.status_code} for {url}")
                
                except Exception as e:
                    result.feeds_failed.append(url)
                    result.errors.append(f"Error fetching {url}: {str(e)}")
        
        result.status = "success" if result.feeds_processed else "failed"
        result.completed_at = datetime.utcnow()
        result.duration_seconds = (result.completed_at - result.started_at).total_seconds()
        
        return result.model_dump()

