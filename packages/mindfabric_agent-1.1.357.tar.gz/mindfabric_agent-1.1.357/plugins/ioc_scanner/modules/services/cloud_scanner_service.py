"""
Cloud IOC Scanner Service

Scans cloud environments for indicators of compromise:
- AWS CloudTrail anomalies
- Azure Activity Log suspicious events
- GCP Audit Log suspicious events
- Behavioral IOCs
"""

import os
import json
from typing import List, Dict, Any, Optional
from datetime import datetime
from uuid import uuid4

from ..databases import (
    CLOUD_IOCS,
    BEHAVIORAL_IOCS,
    THREAT_INTEL_FEEDS,
)


class CloudScannerService:
    """Scans cloud environments for IOCs."""
    
    def __init__(self, plugin_instance=None):
        """Initialize cloud scanner."""
        self.plugin = plugin_instance
        self.findings = []
    
    async def scan_aws_cloudtrail(
        self,
        cloudtrail_events: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Scan AWS CloudTrail events for IOCs.
        
        Args:
            cloudtrail_events: List of CloudTrail event records
            
        Returns:
            List of IOC findings
        """
        findings = []
        aws_iocs = CLOUD_IOCS.get("aws", {})
        
        for event in cloudtrail_events:
            event_name = event.get("eventName", "")
            event_source = event.get("eventSource", "")
            user_identity = event.get("userIdentity", {})
            
            # Check against AWS IOC patterns
            for ioc_name, ioc_data in aws_iocs.items():
                if not isinstance(ioc_data, dict):
                    continue
                
                # Check event names
                event_patterns = ioc_data.get("event_names", [])
                if event_patterns and event_name in event_patterns:
                    findings.append(self._create_finding(
                        "aws_cloudtrail_ioc",
                        ioc_name,
                        ioc_data,
                        event,
                    ))
                    continue
                
                # Check event source patterns
                source_patterns = ioc_data.get("event_sources", [])
                if source_patterns and event_source in source_patterns:
                    findings.append(self._create_finding(
                        "aws_cloudtrail_ioc",
                        ioc_name,
                        ioc_data,
                        event,
                    ))
                    continue
                
                # Check for user agent patterns
                user_agent = event.get("userAgent", "")
                ua_patterns = ioc_data.get("user_agent_patterns", [])
                for pattern in ua_patterns:
                    if pattern.lower() in user_agent.lower():
                        findings.append(self._create_finding(
                            "aws_cloudtrail_ioc",
                            ioc_name,
                            ioc_data,
                            event,
                        ))
                        break
        
        return findings
    
    async def scan_azure_activity_log(
        self,
        activity_events: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Scan Azure Activity Log events for IOCs.
        
        Args:
            activity_events: List of Azure Activity Log events
            
        Returns:
            List of IOC findings
        """
        findings = []
        azure_iocs = CLOUD_IOCS.get("azure", {})
        
        for event in activity_events:
            operation_name = event.get("operationName", {})
            if isinstance(operation_name, dict):
                operation_name = operation_name.get("value", "")
            
            # Check against Azure IOC patterns
            for ioc_name, ioc_data in azure_iocs.items():
                if not isinstance(ioc_data, dict):
                    continue
                
                operations = ioc_data.get("operations", [])
                if operations and operation_name in operations:
                    findings.append(self._create_finding(
                        "azure_activity_ioc",
                        ioc_name,
                        ioc_data,
                        event,
                    ))
        
        return findings
    
    async def scan_gcp_audit_log(
        self,
        audit_events: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Scan GCP Audit Log events for IOCs.
        
        Args:
            audit_events: List of GCP Audit Log events
            
        Returns:
            List of IOC findings
        """
        findings = []
        gcp_iocs = CLOUD_IOCS.get("gcp", {})
        
        for event in audit_events:
            method_name = event.get("protoPayload", {}).get("methodName", "")
            
            # Check against GCP IOC patterns
            for ioc_name, ioc_data in gcp_iocs.items():
                if not isinstance(ioc_data, dict):
                    continue
                
                methods = ioc_data.get("methods", [])
                if methods and method_name in methods:
                    findings.append(self._create_finding(
                        "gcp_audit_ioc",
                        ioc_name,
                        ioc_data,
                        event,
                    ))
        
        return findings
    
    async def detect_behavioral_iocs(
        self,
        events: List[Dict[str, Any]],
        time_window_minutes: int = 60,
    ) -> List[Dict[str, Any]]:
        """
        Detect behavioral IOCs across cloud events.
        
        Args:
            events: List of cloud events
            time_window_minutes: Time window for analysis
            
        Returns:
            List of behavioral IOC findings
        """
        findings = []
        
        # Group events by source IP/user
        grouped_events: Dict[str, List[Dict]] = {}
        for event in events:
            source_ip = event.get("sourceIPAddress") or event.get("callerIpAddress") or "unknown"
            if source_ip not in grouped_events:
                grouped_events[source_ip] = []
            grouped_events[source_ip].append(event)
        
        # Check behavioral patterns
        for source, source_events in grouped_events.items():
            for behavior_name, behavior_data in BEHAVIORAL_IOCS.items():
                if not isinstance(behavior_data, dict):
                    continue
                
                threshold = behavior_data.get("threshold", 10)
                event_types = behavior_data.get("event_types", [])
                
                # Count matching events
                matching_count = 0
                for event in source_events:
                    event_name = event.get("eventName") or event.get("operationName") or ""
                    if any(et in event_name for et in event_types):
                        matching_count += 1
                
                if matching_count >= threshold:
                    findings.append({
                        "id": str(uuid4()),
                        "type": "behavioral_ioc",
                        "name": behavior_name,
                        "source": source,
                        "event_count": matching_count,
                        "threshold": threshold,
                        "description": behavior_data.get("description", ""),
                        "severity": behavior_data.get("severity", "high"),
                        "timestamp": datetime.utcnow().isoformat(),
                        "mitre_techniques": behavior_data.get("mitre_techniques", []),
                    })
        
        return findings
    
    def get_threat_intel_feeds(self) -> List[Dict[str, Any]]:
        """
        Get configured threat intelligence feeds.
        
        Returns:
            List of threat intel feed configurations
        """
        feeds = []
        
        for feed_name, feed_data in THREAT_INTEL_FEEDS.items():
            if isinstance(feed_data, dict):
                feeds.append({
                    "name": feed_name,
                    "url": feed_data.get("url", ""),
                    "type": feed_data.get("type", ""),
                    "format": feed_data.get("format", ""),
                    "refresh_interval": feed_data.get("refresh_interval", 3600),
                })
        
        return feeds
    
    async def scan_all(
        self,
        aws_events: List[Dict[str, Any]] = None,
        azure_events: List[Dict[str, Any]] = None,
        gcp_events: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Run all cloud IOC scans.
        
        Args:
            aws_events: AWS CloudTrail events
            azure_events: Azure Activity Log events
            gcp_events: GCP Audit Log events
            
        Returns:
            Combined scan results
        """
        aws_findings = []
        azure_findings = []
        gcp_findings = []
        behavioral_findings = []
        
        all_events = []
        
        if aws_events:
            aws_findings = await self.scan_aws_cloudtrail(aws_events)
            all_events.extend(aws_events)
        
        if azure_events:
            azure_findings = await self.scan_azure_activity_log(azure_events)
            all_events.extend(azure_events)
        
        if gcp_events:
            gcp_findings = await self.scan_gcp_audit_log(gcp_events)
            all_events.extend(gcp_events)
        
        if all_events:
            behavioral_findings = await self.detect_behavioral_iocs(all_events)
        
        all_findings = aws_findings + azure_findings + gcp_findings + behavioral_findings
        
        return {
            "total_findings": len(all_findings),
            "aws_findings": aws_findings,
            "azure_findings": azure_findings,
            "gcp_findings": gcp_findings,
            "behavioral_findings": behavioral_findings,
            "all_findings": all_findings,
            "threat_intel_feeds": self.get_threat_intel_feeds(),
            "timestamp": datetime.utcnow().isoformat(),
        }
    
    def _create_finding(
        self,
        finding_type: str,
        name: str,
        ioc_data: Dict,
        event: Dict,
    ) -> Dict[str, Any]:
        """Create a standardized finding."""
        return {
            "id": str(uuid4()),
            "type": finding_type,
            "name": name,
            "description": ioc_data.get("description", ""),
            "severity": ioc_data.get("severity", "high"),
            "event": event,
            "timestamp": datetime.utcnow().isoformat(),
            "mitre_techniques": ioc_data.get("mitre_techniques", []),
        }

