"""
Certificate Analyzer Service

Analyzes certificate chains in files (not network certificates - those are covered by other plugins).
Detects certificate pinning bypass, fake CA certificates, and suspicious certificate chains.
"""

import os
import logging
import uuid
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any

from ...proto import (
    FileSystemFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

logger = logging.getLogger(__name__)


class CertificateAnalyzerService:
    """Service for analyzing certificate chains in files."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[FileSystemFinding] = []
        self._is_windows = os.name == 'nt'
    
    async def analyze_certificates(
        self,
        file_paths: List[str],
        check_trust_stores: bool = True,
    ) -> List[FileSystemFinding]:
        """
        Analyze certificates in files.
        
        Args:
            file_paths: List of file paths to check
            check_trust_stores: Whether to check trust stores for fake CA certificates
            
        Returns:
            List of certificate analysis findings
        """
        findings = []
        
        # Check trust stores for fake CA certificates
        if check_trust_stores:
            trust_store_findings = await self._check_trust_stores()
            findings.extend(trust_store_findings)
        
        # Analyze certificates in files
        for file_path in file_paths:
            try:
                file_path_obj = Path(file_path)
                
                # Check if file contains certificates
                if file_path_obj.suffix.lower() in ['.pem', '.crt', '.cer', '.p12', '.pfx']:
                    cert_findings = await self._analyze_certificate_file(file_path)
                    findings.extend(cert_findings)
                
                # Check if file is a trust store
                if self._is_trust_store_file(file_path):
                    trust_findings = await self._analyze_trust_store_file(file_path)
                    findings.extend(trust_findings)
                
            except Exception as e:
                logger.debug(f"Error analyzing certificate in {file_path}: {e}")
                continue
        
        self.findings.extend(findings)
        return findings
    
    async def _check_trust_stores(self) -> List[FileSystemFinding]:
        """Check system trust stores for fake CA certificates."""
        findings = []
        
        if self._is_windows:
            # Windows: Check Certificate Store
            try:
                result = subprocess.run(
                    ["powershell", "-Command",
                     "Get-ChildItem -Path Cert:\\LocalMachine\\Root | Select-Object Subject, Thumbprint, NotAfter | ConvertTo-Json"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                
                if result.returncode == 0:
                    import json
                    certs = json.loads(result.stdout) if result.stdout.strip() else []
                    if isinstance(certs, dict):
                        certs = [certs]
                    
                    for cert in certs:
                        # Check for suspicious certificates
                        subject = cert.get("Subject", "")
                        if self._is_suspicious_ca_certificate(subject):
                            findings.append(self._create_finding(
                                "Certificate Store",
                                "suspicious_ca_certificate",
                                f"Suspicious CA certificate in trust store: {subject}",
                                SeverityLevel.HIGH,
                                ConfidenceLevel.MEDIUM,
                                {"certificate": cert},
                            ))
            except Exception as e:
                logger.debug(f"Error checking Windows trust store: {e}")
        else:
            # Linux: Check /etc/ssl/certs or /etc/pki
            trust_store_paths = [
                "/etc/ssl/certs",
                "/etc/pki/tls/certs",
                "/usr/local/share/ca-certificates",
            ]
            
            for trust_path in trust_store_paths:
                if os.path.exists(trust_path):
                    for cert_file in Path(trust_path).glob("*.crt"):
                        try:
                            cert_info = await self._get_certificate_info(str(cert_file))
                            if cert_info and self._is_suspicious_ca_certificate(cert_info.get("subject", "")):
                                findings.append(self._create_finding(
                                    str(cert_file),
                                    "suspicious_ca_certificate",
                                    f"Suspicious CA certificate: {cert_info.get('subject', '')}",
                                    SeverityLevel.HIGH,
                                    ConfidenceLevel.MEDIUM,
                                    cert_info,
                                ))
                        except Exception:
                            continue
        
        return findings
    
    async def _analyze_certificate_file(self, file_path: str) -> List[FileSystemFinding]:
        """Analyze a certificate file."""
        findings = []
        
        try:
            cert_info = await self._get_certificate_info(file_path)
            if not cert_info:
                return findings
            
            # Check 1: Self-signed certificate
            if cert_info.get("is_self_signed"):
                findings.append(self._create_finding(
                    file_path,
                    "self_signed_certificate",
                    f"Self-signed certificate detected: {cert_info.get('subject', '')}",
                    SeverityLevel.MEDIUM,
                    ConfidenceLevel.HIGH,
                    cert_info,
                ))
            
            # Check 2: Expired certificate
            if cert_info.get("is_expired"):
                findings.append(self._create_finding(
                    file_path,
                    "expired_certificate",
                    f"Expired certificate: valid until {cert_info.get('not_after', '')}",
                    SeverityLevel.LOW,
                    ConfidenceLevel.HIGH,
                    cert_info,
                ))
            
            # Check 3: Revoked certificate (would need CRL/OCSP check)
            # This is complex and requires network access, skip for now
            
            # Check 4: Suspicious certificate data
            if self._is_suspicious_certificate_data(cert_info):
                findings.append(self._create_finding(
                    file_path,
                    "suspicious_certificate_data",
                    f"Suspicious certificate data detected: {cert_info.get('subject', '')}",
                    SeverityLevel.HIGH,
                    ConfidenceLevel.MEDIUM,
                    cert_info,
                ))
            
        except Exception as e:
            logger.debug(f"Error analyzing certificate file {file_path}: {e}")
        
        return findings
    
    async def _analyze_trust_store_file(self, file_path: str) -> List[FileSystemFinding]:
        """Analyze a trust store file."""
        findings = []
        
        # Check for modifications to trust store
        # This would require baseline comparison
        # For now, just check if file exists and is readable
        
        return findings
    
    async def _get_certificate_info(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Get certificate information using openssl."""
        try:
            result = subprocess.run(
                ["openssl", "x509", "-in", file_path, "-noout", "-text", "-dates", "-subject", "-issuer"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            
            if result.returncode == 0:
                output = result.stdout
                
                # Parse certificate info
                subject = self._extract_field(output, "Subject:")
                issuer = self._extract_field(output, "Issuer:")
                not_before = self._extract_field(output, "Not Before:")
                not_after = self._extract_field(output, "Not After:")
                
                from datetime import datetime
                is_expired = False
                if not_after:
                    try:
                        # Parse date (format: "Jan  1 00:00:00 2025 GMT")
                        exp_date = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                        if exp_date < datetime.now():
                            is_expired = True
                    except Exception:
                        pass
                
                return {
                    "subject": subject,
                    "issuer": issuer,
                    "not_before": not_before,
                    "not_after": not_after,
                    "is_self_signed": subject == issuer,
                    "is_expired": is_expired,
                }
        except Exception as e:
            logger.debug(f"Error getting certificate info: {e}")
        
        return None
    
    def _extract_field(self, text: str, field_name: str) -> Optional[str]:
        """Extract field value from openssl output."""
        lines = text.split("\n")
        for line in lines:
            if line.strip().startswith(field_name):
                return line.split(field_name, 1)[1].strip()
        return None
    
    def _is_suspicious_ca_certificate(self, subject: str) -> bool:
        """Check if CA certificate is suspicious."""
        if not subject:
            return False
        
        subject_lower = subject.lower()
        
        # Suspicious patterns
        suspicious_patterns = [
            "test",
            "fake",
            "malware",
            "virus",
            "hack",
            "evil",
        ]
        
        return any(pattern in subject_lower for pattern in suspicious_patterns)
    
    def _is_suspicious_certificate_data(self, cert_info: Dict[str, Any]) -> bool:
        """Check if certificate data is suspicious."""
        subject = cert_info.get("subject", "")
        
        # Check for suspicious patterns
        if self._is_suspicious_ca_certificate(subject):
            return True
        
        # Check for very short validity period (could indicate test certificate)
        not_before = cert_info.get("not_before")
        not_after = cert_info.get("not_after")
        
        # Additional checks can be added here
        
        return False
    
    def _is_trust_store_file(self, file_path: str) -> bool:
        """Check if file is a trust store file."""
        trust_store_names = [
            "ca-bundle.crt",
            "ca-certificates.crt",
            "cacert.pem",
            "cert.pem",
        ]
        
        file_name = Path(file_path).name.lower()
        return file_name in trust_store_names
    
    def _create_finding(
        self,
        file_path: str,
        finding_type: str,
        description: str,
        severity: SeverityLevel,
        confidence: ConfidenceLevel,
        cert_info: Optional[Dict[str, Any]] = None,
    ) -> FileSystemFinding:
        """Create a certificate analysis finding."""
        
        evidence = [description]
        if cert_info:
            evidence.append(f"Certificate info: {cert_info}")
        
        return FileSystemFinding(
            finding_type=finding_type,
            severity=severity,
            confidence=confidence,
            file_path=file_path,
            threat_category=ThreatCategory.DEFENSE_EVASION,
            description=description,
            evidence=evidence,
            mitre_techniques=["T1557", "T1573"],
            remediation="Verify certificate legitimacy. Check certificate chain. Remove suspicious certificates from trust store.",
        )
