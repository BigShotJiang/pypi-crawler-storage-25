"""TTP (MITRE ATT&CK) detection service."""

from collections import defaultdict
from typing import Dict, List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    TTPFinding,
    MitreAttackTechnique,
    ScanOptions,
    SeverityLevel,
    ConfidenceLevel,
    MitreTactic,
    FileSystemFinding,
    ProcessFinding,
    NetworkFinding,
    LogFinding,
    PersistenceFinding,
)
from ..databases import MITRE_TECHNIQUES


def _mitre_attack_url(technique_id: str) -> Optional[str]:
    """Canonical MITRE ATT&CK technique page URL (T1059 / T1059.001)."""
    if not technique_id or not isinstance(technique_id, str):
        return None
    tid = technique_id.strip().upper()
    if not tid.startswith("T"):
        return None
    rest = tid[1:]
    parts = rest.split(".", 1)
    main = parts[0]
    if not main.isdigit():
        return None
    if len(parts) == 1:
        return f"https://attack.mitre.org/techniques/T{main}/"
    sub = parts[1]
    if sub.isdigit():
        return f"https://attack.mitre.org/techniques/T{main}/{sub}/"
    return f"https://attack.mitre.org/techniques/T{main}/"


class TTPDetectorService:
    """Service for MITRE ATT&CK TTP detection."""
    
    def __init__(self, plugin_instance):
        """
        Initialize TTP detector service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def detect_ttps(
        self,
        ttp_patterns: Dict[str, str] = None,
        options: ScanOptions = None,
    ) -> List[TTPFinding]:
        """
        MITRE ATT&CK TTP detection.
        
        Args:
            ttp_patterns: Custom TTP detection patterns
            options: Scan configuration
        
        Returns:
            List of TTPFinding
        """
        if options is None:
            options = ScanOptions()
        
        results: List[TTPFinding] = []
        
        # Collect all TTPs from findings
        ttp_evidence: Dict[str, List[Dict[str, str]]] = defaultdict(list)
        
        # From file findings
        for finding in self.plugin.findings.get("file", []):
            if isinstance(finding, FileSystemFinding):
                for ttp in finding.mitre_techniques:
                    ttp_evidence[ttp].append({
                        "type": "file",
                        "source": finding.file_path,
                        "details": finding.description
                    })
        
        # From process findings
        for finding in self.plugin.findings.get("process", []):
            if isinstance(finding, ProcessFinding):
                for ttp in finding.mitre_techniques:
                    ttp_evidence[ttp].append({
                        "type": "process",
                        "source": f"PID {finding.process.pid}: {finding.process.name}",
                        "details": finding.description
                    })
        
        # From network findings
        for finding in self.plugin.findings.get("network", []):
            if isinstance(finding, NetworkFinding):
                for ttp in finding.mitre_techniques:
                    ttp_evidence[ttp].append({
                        "type": "network",
                        "source": f"{finding.remote_ip}:{finding.remote_port}",
                        "details": finding.description
                    })
        
        # From log findings
        for finding in self.plugin.findings.get("log", []):
            if isinstance(finding, LogFinding):
                for ttp in finding.mitre_techniques:
                    ttp_evidence[ttp].append({
                        "type": "log",
                        "source": finding.log_source,
                        "details": finding.description
                    })
        
        # From persistence findings
        for finding in self.plugin.findings.get("persistence", []):
            if isinstance(finding, PersistenceFinding):
                ttp_evidence[finding.mitre_technique].append({
                    "type": "persistence",
                    "source": finding.location,
                    "details": finding.description
                })
        
        # Create TTP findings
        for ttp_id, evidence_list in ttp_evidence.items():
            if ttp_id in MITRE_TECHNIQUES:
                tech_info = MITRE_TECHNIQUES[ttp_id]
                
                # Calculate confidence based on evidence count
                confidence = ConfidenceLevel.LOW
                if len(evidence_list) >= 3:
                    confidence = ConfidenceLevel.HIGH
                elif len(evidence_list) >= 2:
                    confidence = ConfidenceLevel.MEDIUM
                
                # Determine severity
                severity = SeverityLevel.MEDIUM
                tactic = tech_info.get("tactic")
                if tactic in [MitreTactic.EXECUTION, MitreTactic.PERSISTENCE, MitreTactic.PRIVILEGE_ESCALATION]:
                    severity = SeverityLevel.HIGH
                if tactic in [MitreTactic.EXFILTRATION, MitreTactic.IMPACT]:
                    severity = SeverityLevel.CRITICAL
                
                related_file: List[str] = []
                related_process: List[str] = []
                related_network: List[str] = []
                for e in evidence_list:
                    line = f"{e.get('source', '')} — {e.get('details', '')}".strip(" —")
                    if not line:
                        continue
                    et = e.get("type")
                    if et == "file":
                        related_file.append(line[:500])
                    elif et == "process":
                        related_process.append(line[:500])
                    elif et == "network":
                        related_network.append(line[:500])

                mitre_url: Optional[str] = tech_info.get("url")
                if not mitre_url:
                    mitre_url = _mitre_attack_url(ttp_id) or None
                platforms = tech_info.get("platforms")
                if not isinstance(platforms, list):
                    platforms = []

                results.append(TTPFinding(
                    technique=MitreAttackTechnique(
                        technique_id=ttp_id,
                        technique_name=tech_info["name"],
                        tactic=tactic,
                        sub_technique=tech_info.get("sub_technique"),
                        description=tech_info.get("description"),
                        detection=tech_info.get("detection"),
                        mitigation=tech_info.get("mitigation"),
                        data_sources=tech_info.get("data_sources", []),
                        platforms=platforms,
                        url=mitre_url,
                    ),
                    severity=severity,
                    confidence=confidence,
                    evidence_type=evidence_list[0]["type"],
                    evidence_source=evidence_list[0]["source"],
                    evidence_details=[e["details"] for e in evidence_list],
                    related_file_findings=related_file[:25],
                    related_process_findings=related_process[:25],
                    related_network_findings=related_network[:25],
                    remediation=tech_info.get("mitigation"),
                    description=f"{tech_info['name']}: {len(evidence_list)} evidence items"
                ))
        
        return results

