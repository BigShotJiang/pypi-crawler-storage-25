"""
Container IOC Scanner Service

Scans container environments for indicators of compromise:
- Container filesystem IOCs
- Kubernetes audit log IOCs
- Malicious container image hashes
- Container-specific attack patterns
"""

import os
import json
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime
from uuid import uuid4

from utils.async_subprocess import run_exec_stdout

from ..databases import (
    CONTAINER_FS_IOCS,
    CONTAINER_IOC_PATTERNS,
    K8S_AUDIT_IOCS,
    MALICIOUS_CONTAINER_HASHES,
)


class ContainerScannerService:
    """Scans container environments for IOCs."""
    
    def __init__(self, plugin_instance=None):
        """Initialize container scanner."""
        self.plugin = plugin_instance
        self.findings = []
    
    async def scan_container_filesystem(
        self,
        container_root: str = "/",
        container_id: str = None,
    ) -> List[Dict[str, Any]]:
        """
        Scan container filesystem for IOCs.
        
        Args:
            container_root: Root path of container filesystem
            container_id: Optional container ID
            
        Returns:
            List of IOC findings
        """
        return await asyncio.to_thread(self._scan_container_filesystem_sync, container_root, container_id)

    def _scan_container_filesystem_sync(self, container_root: str, container_id: Optional[str]) -> List[Dict[str, Any]]:
        """Sync implementation to avoid blocking the event loop."""
        findings: List[Dict[str, Any]] = []

        # Check for suspicious files and directories
        for ioc_name, ioc_data in CONTAINER_FS_IOCS.items():
            if not isinstance(ioc_data, dict):
                continue

            paths = ioc_data.get("paths", [])
            description = ioc_data.get("description", "")
            severity = ioc_data.get("severity", "medium")

            for path_pattern in paths:
                full_path = os.path.join(container_root, path_pattern.lstrip("/"))

                if os.path.exists(full_path):
                    findings.append({
                        "id": str(uuid4()),
                        "type": "container_fs_ioc",
                        "name": ioc_name,
                        "path": full_path,
                        "description": description,
                        "severity": severity,
                        "container_id": container_id,
                        "timestamp": datetime.utcnow().isoformat(),
                        "mitre_techniques": ioc_data.get("mitre_techniques", []),
                    })

        return findings
    
    async def scan_container_processes(
        self,
        container_id: str = None,
    ) -> List[Dict[str, Any]]:
        """
        Scan container processes for suspicious patterns.
        
        Args:
            container_id: Optional container ID
            
        Returns:
            List of IOC findings
        """
        findings = []
        
        # Get process list
        try:
            if container_id:
                # Use docker exec to get processes inside container
                process_output = await run_exec_stdout(
                    ["docker", "exec", container_id, "ps", "aux"],
                    timeout=30,
                ) or ""
            else:
                # Check local processes
                process_output = await run_exec_stdout(
                    ["ps", "aux"],
                    timeout=30,
                ) or ""
            
            # Check against container IOC patterns
            for pattern_name, pattern_data in CONTAINER_IOC_PATTERNS.items():
                if not isinstance(pattern_data, dict):
                    continue
                
                patterns = pattern_data.get("patterns", [])
                for pattern in patterns:
                    if pattern.lower() in process_output.lower():
                        findings.append({
                            "id": str(uuid4()),
                            "type": "container_process_ioc",
                            "name": pattern_name,
                            "pattern": pattern,
                            "description": pattern_data.get("description", ""),
                            "severity": pattern_data.get("severity", "high"),
                            "container_id": container_id,
                            "timestamp": datetime.utcnow().isoformat(),
                            "mitre_techniques": pattern_data.get("mitre_techniques", []),
                        })
        
        except Exception:
            pass
        
        return findings
    
    async def scan_k8s_audit_logs(
        self,
        audit_log_path: str = "/var/log/kubernetes/audit/audit.log",
    ) -> List[Dict[str, Any]]:
        """
        Scan Kubernetes audit logs for suspicious activity.
        
        Args:
            audit_log_path: Path to Kubernetes audit log
            
        Returns:
            List of IOC findings
        """
        return await asyncio.to_thread(self._scan_k8s_audit_logs_sync, audit_log_path)

    def _scan_k8s_audit_logs_sync(self, audit_log_path: str) -> List[Dict[str, Any]]:
        """Sync implementation to avoid blocking the event loop."""
        findings: List[Dict[str, Any]] = []

        if not os.path.exists(audit_log_path):
            return findings

        try:
            with open(audit_log_path, 'r') as f:
                for line in f:
                    try:
                        log_entry = json.loads(line.strip())
                    except json.JSONDecodeError:
                        continue

                    # Check against K8s audit IOCs
                    for ioc_name, ioc_data in K8S_AUDIT_IOCS.items():
                        if not isinstance(ioc_data, dict):
                            continue

                        if self._matches_k8s_ioc(log_entry, ioc_data):
                            findings.append({
                                "id": str(uuid4()),
                                "type": "k8s_audit_ioc",
                                "name": ioc_name,
                                "description": ioc_data.get("description", ""),
                                "severity": ioc_data.get("severity", "high"),
                                "log_entry": log_entry,
                                "timestamp": datetime.utcnow().isoformat(),
                                "mitre_techniques": ioc_data.get("mitre_techniques", []),
                            })

        except Exception:
            pass

        return findings
    
    async def check_container_image_hash(
        self,
        image_hash: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Check if container image hash is known malicious.
        
        Args:
            image_hash: Container image digest/hash
            
        Returns:
            Finding if malicious, None otherwise
        """
        if not image_hash:
            return None
        
        # Normalize hash
        hash_lower = image_hash.lower()
        if hash_lower.startswith("sha256:"):
            hash_lower = hash_lower[7:]
        
        for malware_name, malware_data in MALICIOUS_CONTAINER_HASHES.items():
            if not isinstance(malware_data, dict):
                continue
            
            hashes = malware_data.get("hashes", [])
            for known_hash in hashes:
                if known_hash.lower() == hash_lower:
                    return {
                        "id": str(uuid4()),
                        "type": "malicious_container_image",
                        "name": malware_name,
                        "image_hash": image_hash,
                        "description": malware_data.get("description", "Known malicious container image"),
                        "severity": "critical",
                        "timestamp": datetime.utcnow().isoformat(),
                        "mitre_techniques": malware_data.get("mitre_techniques", ["T1610"]),
                    }
        
        return None
    
    async def scan_all(
        self,
        container_root: str = "/",
        container_id: str = None,
        k8s_audit_log: str = "/var/log/kubernetes/audit/audit.log",
        image_hashes: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Run all container IOC scans.
        
        Args:
            container_root: Container filesystem root
            container_id: Container ID
            k8s_audit_log: Path to K8s audit log
            image_hashes: List of image hashes to check
            
        Returns:
            Combined scan results
        """
        fs_findings = await self.scan_container_filesystem(container_root, container_id)
        process_findings = await self.scan_container_processes(container_id)
        k8s_findings = await self.scan_k8s_audit_logs(k8s_audit_log)
        
        image_findings = []
        if image_hashes:
            for image_hash in image_hashes:
                finding = await self.check_container_image_hash(image_hash)
                if finding:
                    image_findings.append(finding)
        
        all_findings = fs_findings + process_findings + k8s_findings + image_findings
        
        return {
            "total_findings": len(all_findings),
            "fs_findings": fs_findings,
            "process_findings": process_findings,
            "k8s_findings": k8s_findings,
            "image_findings": image_findings,
            "all_findings": all_findings,
            "timestamp": datetime.utcnow().isoformat(),
        }
    
    def _matches_k8s_ioc(self, log_entry: Dict, ioc_data: Dict) -> bool:
        """Check if K8s audit log entry matches IOC pattern."""
        # Check verb
        if "verb" in ioc_data:
            if log_entry.get("verb") != ioc_data["verb"]:
                return False
        
        # Check resource
        if "resource" in ioc_data:
            obj_ref = log_entry.get("objectRef", {})
            if obj_ref.get("resource") != ioc_data["resource"]:
                return False
        
        # Check namespace patterns
        if "namespace_pattern" in ioc_data:
            obj_ref = log_entry.get("objectRef", {})
            namespace = obj_ref.get("namespace", "")
            if ioc_data["namespace_pattern"].lower() not in namespace.lower():
                return False
        
        # Check request object patterns
        if "request_patterns" in ioc_data:
            request_obj = str(log_entry.get("requestObject", {})).lower()
            for pattern in ioc_data["request_patterns"]:
                if pattern.lower() in request_obj:
                    return True
            return False
        
        return True

