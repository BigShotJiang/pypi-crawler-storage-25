"""
SQLite-backed artifact storage for IOC Scanner (log vectors).

Goal:
- Store detailed investigation data on disk (not in RAM)
- Deduplicate detail rows
- Provide rich aggregations (vector counts, per-IP counts) for incident response
"""

from __future__ import annotations

import os
import json
import sqlite3
import time
import hashlib
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any, Dict


def _utc_iso() -> str:
    # Prefer timezone-aware now() for forward compatibility (datetime.utcnow is deprecated).
    return datetime.now(timezone.utc).replace(tzinfo=None).isoformat() + "Z"


@dataclass
class LogHit:
    vector: str
    log_source: str
    timestamp: Optional[str]
    source_ip: Optional[str]
    username: Optional[str]
    line_number: Optional[int]
    message: Optional[str]


class IocArtifactSqliteStore:
    def __init__(self, command_id: str, *, db_path: Optional[str] = None, max_db_bytes: int = 25 * 1024 * 1024):
        self.command_id = command_id
        self._conn: Optional[sqlite3.Connection] = None
        self._disabled_details = False

        preferred_root = os.getenv("IOC_ARTIFACT_DIR") or os.getenv("MINDFABRIC_AGENT_DATA_DIR") or "/var/lib/mindfabric-agent"
        preferred_dir = str(Path(preferred_root) / "ioc_scanner")
        chosen_dir = preferred_dir
        try:
            Path(chosen_dir).mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(chosen_dir, 0o700)
            except Exception:
                pass
        except Exception:
            chosen_dir = "/tmp/mindfabric-agent/ioc_scanner"
            Path(chosen_dir).mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(chosen_dir, 0o700)
            except Exception:
                pass

        self.db_path = db_path or str(Path(chosen_dir) / f"ioc_artifact_{command_id}.sqlite")
        
        # Calculate max_db_bytes dynamically based on available disk space
        # Default: use provided max_db_bytes, but can use up to 10% of available space (min 25MB, max 500MB)
        try:
            total, used, free = shutil.disk_usage(chosen_dir)
            # Use 10% of free space, but clamp between 25MB and 500MB
            dynamic_max = min(500 * 1024 * 1024, max(25 * 1024 * 1024, int(free * 0.1)))
            # Use the larger of: user-provided max_db_bytes or dynamic calculation
            provided_max = max(5 * 1024 * 1024, int(max_db_bytes or 0))
            self.max_db_bytes = max(dynamic_max, provided_max)
        except Exception:
            # Fallback to provided or default value
            self.max_db_bytes = max(5 * 1024 * 1024, int(max_db_bytes or 0))

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, timeout=30.0)
            self._conn.row_factory = sqlite3.Row
            cur = self._conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA synchronous=NORMAL;")
            cur.execute("PRAGMA temp_store=FILE;")
            cur.execute("PRAGMA cache_size=-2000;")  # ~2MB
            self._init_schema()
            try:
                os.chmod(self.db_path, 0o600)
            except Exception:
                pass
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            finally:
                self._conn = None

    def _init_schema(self) -> None:
        conn = self.connect()
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS meta (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL
            );
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS vector_summary (
              vector TEXT NOT NULL,
              log_source TEXT NOT NULL,
              count_total INTEGER NOT NULL DEFAULT 0,
              first_seen TEXT,
              last_seen TEXT,
              PRIMARY KEY (vector, log_source)
            );
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS vector_ip (
              vector TEXT NOT NULL,
              log_source TEXT NOT NULL,
              source_ip TEXT NOT NULL,
              count INTEGER NOT NULL DEFAULT 0,
              first_seen TEXT,
              last_seen TEXT,
              PRIMARY KEY (vector, log_source, source_ip)
            );
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS vector_sample (
              vector TEXT NOT NULL,
              log_source TEXT NOT NULL,
              line_hash TEXT NOT NULL,
              timestamp TEXT,
              source_ip TEXT,
              username TEXT,
              line_number INTEGER,
              message TEXT,
              PRIMARY KEY (vector, log_source, line_hash)
            );
            """
        )
        conn.commit()

    def _maybe_rotate_old_samples(self) -> None:
        """
        Rotate old vector_sample entries if database exceeds size limit.
        Instead of disabling details completely, we remove oldest samples
        while keeping aggregation data (vector_summary, vector_ip).
        """
        if self._disabled_details:
            return
        try:
            sz = int(os.path.getsize(self.db_path))
            if sz < self.max_db_bytes:
                return  # No need to rotate
            
            conn = self.connect()
            cur = conn.cursor()
            
            # Count current samples
            cur.execute("SELECT COUNT(*) FROM vector_sample")
            sample_count = cur.fetchone()[0]
            
            if sample_count < 100:
                # Too few samples to rotate, but mark as disabled to prevent further growth
                self._disabled_details = True
                return
            
            # Remove oldest 20% of samples (but keep at least 1000 samples)
            to_keep = max(1000, int(sample_count * 0.8))
            to_remove = sample_count - to_keep
            
            if to_remove > 0:
                # Delete oldest samples (by timestamp, or by rowid if timestamp is NULL)
                cur.execute("""
                    DELETE FROM vector_sample
                    WHERE rowid IN (
                        SELECT rowid FROM vector_sample
                        ORDER BY 
                            CASE WHEN timestamp IS NULL THEN 1 ELSE 0 END,
                            timestamp ASC,
                            rowid ASC
                        LIMIT ?
                    )
                """, (to_remove,))
                conn.commit()
                
                # Vacuum to reclaim space (best-effort, may take time)
                try:
                    cur.execute("VACUUM")
                    conn.commit()
                except Exception:
                    pass  # Vacuum is optional
        except Exception:
            # On any error, disable details to prevent further issues
            self._disabled_details = True

    def record_log_hit(self, hit: LogHit, *, store_sample: bool = True) -> None:
        """
        Record one log-vector hit.
        - Always updates vector_summary (+1)
        - Updates per-IP counter if source_ip present
        - Stores a deduped sample row (bounded by db size cap) when store_sample=True
        """
        conn = self.connect()
        cur = conn.cursor()

        ts = hit.timestamp or _utc_iso()
        now = _utc_iso()

        # summary increment
        cur.execute(
            """
            INSERT INTO vector_summary(vector, log_source, count_total, first_seen, last_seen)
            VALUES(?, ?, 1, ?, ?)
            ON CONFLICT(vector, log_source) DO UPDATE SET
              count_total = count_total + 1,
              last_seen = excluded.last_seen
            """,
            (hit.vector, hit.log_source, ts, ts),
        )

        # per-ip increment
        if hit.source_ip:
            cur.execute(
                """
                INSERT INTO vector_ip(vector, log_source, source_ip, count, first_seen, last_seen)
                VALUES(?, ?, ?, 1, ?, ?)
                ON CONFLICT(vector, log_source, source_ip) DO UPDATE SET
                  count = count + 1,
                  last_seen = excluded.last_seen
                """,
                (hit.vector, hit.log_source, hit.source_ip, ts, ts),
            )

        # Rotate old samples if DB is too large (instead of disabling completely)
        # Only relevant if we intend to write sample rows.
        if store_sample:
            self._maybe_rotate_old_samples()

        if store_sample and not self._disabled_details:
            msg = (hit.message or "").strip()
            if len(msg) > 1000:
                msg = msg[:1000]
            # stable dedupe key per unique message line
            h = hashlib.sha1(msg.encode("utf-8", errors="ignore")).hexdigest()
            cur.execute(
                """
                INSERT OR IGNORE INTO vector_sample(vector, log_source, line_hash, timestamp, source_ip, username, line_number, message)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (hit.vector, hit.log_source, h, ts, hit.source_ip, hit.username, hit.line_number, msg),
            )

        # Caller controls commit cadence; do not commit every row.

    def commit(self) -> None:
        conn = self.connect()
        conn.commit()

    def get_meta(self, key: str) -> Optional[str]:
        conn = self.connect()
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
        if not row:
            return None
        try:
            return str(row[0])
        except Exception:
            return None

    def set_meta(self, key: str, value: str) -> None:
        conn = self.connect()
        conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        conn.commit()

    def _checkpoint_key(self, log_source: str) -> str:
        # Keep keys short and stable even for long paths.
        h = hashlib.sha1((log_source or "").encode("utf-8", errors="ignore")).hexdigest()
        return f"checkpoint:{h}"

    def get_checkpoint(self, log_source: str) -> Optional[Dict[str, Any]]:
        raw = self.get_meta(self._checkpoint_key(log_source))
        if not raw:
            return None
        try:
            v = json.loads(raw)
            if not isinstance(v, dict):
                return None
            return v
        except Exception:
            return None

    def set_checkpoint(
        self,
        *,
        log_source: str,
        inode: Optional[int],
        offset: int,
        file_size: Optional[int],
        mtime: Optional[float],
        reason: str,
        commit: bool = True,
    ) -> None:
        payload = {
            "log_source": log_source,
            "inode": inode,
            "offset": int(max(0, offset)),
            "file_size": file_size,
            "mtime": mtime,
            "reason": reason,
            "updated_at": _utc_iso(),
        }
        key = self._checkpoint_key(log_source)
        conn = self.connect()
        conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(payload, separators=(",", ":"))),
        )
        if commit:
            conn.commit()
