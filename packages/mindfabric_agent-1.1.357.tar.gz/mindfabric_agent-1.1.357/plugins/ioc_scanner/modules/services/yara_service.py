"""YARA scanning service."""

from typing import List, Dict, Any

try:
    import yara
    HAS_YARA = True
except ImportError:
    HAS_YARA = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import FileSystemFinding, SeverityLevel, ConfidenceLevel
from ..utils import match_yara_rules


class YaraService:
    """Service for YARA rule scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize YARA service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def scan_with_yara(
        self,
        paths: List[str] = None,
        rules_paths: List[str] = None,
        file_paths: List[str] = None,
        yara_rules_paths: List[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Scan files with YARA rules.
        
        Args:
            paths: Paths to scan (files or directories)
            rules_paths: YARA rule files/directories
            file_paths: Alternative parameter name for paths
            yara_rules_paths: Alternative parameter name for rules_paths
        
        Returns:
            List of YARA match dictionaries
        """
        if not HAS_YARA:
            return [{"error": "yara-python not available"}]
        
        # Handle both parameter names
        scan_paths = paths or file_paths or []
        rule_paths = rules_paths or yara_rules_paths or self.plugin.yara_rules_paths
        
        if not scan_paths:
            return []
        
        results = []
        
        for scan_path in scan_paths:
            from pathlib import Path
            scan_path = Path(scan_path)
            if not scan_path.exists():
                continue
            
            if scan_path.is_file():
                files = [scan_path]
            else:
                files = scan_path.rglob("*")
            
            for filepath in files:
                if not filepath.is_file():
                    continue
                
                try:
                    matches = match_yara_rules(str(filepath), rule_paths)
                    if matches:
                        results.append({
                            "file": str(filepath),
                            "matches": [m.model_dump() if hasattr(m, 'model_dump') else m for m in matches]
                        })
                except Exception:
                    continue
        
        return results

