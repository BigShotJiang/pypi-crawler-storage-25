"""Export service for scan results."""

import json
import csv
import uuid as uuid_module
from datetime import datetime
from typing import Dict, Any

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import IoCScanResult
from ..databases import MITRE_TECHNIQUES


class ExportService:
    """Service for exporting scan results."""
    
    def __init__(self, plugin_instance):
        """
        Initialize export service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    def export_to_json(self, result: IoCScanResult, filepath: str = None) -> str:
        """Export scan results to JSON."""
        data = result.model_dump() if hasattr(result, 'model_dump') else result
        json_str = json.dumps(data, indent=2, default=str)
        
        if filepath:
            with open(filepath, 'w') as f:
                f.write(json_str)
        
        return json_str
    
    def export_to_csv(self, result: IoCScanResult, filepath: str) -> str:
        """Export scan results to CSV."""
        rows = []
        
        # File findings
        for f in result.file_findings:
            finding = f if isinstance(f, dict) else f.model_dump()
            rows.append({
                "type": "file",
                "severity": finding.get("severity", ""),
                "path": finding.get("file_path", ""),
                "description": finding.get("description", ""),
                "mitre": ",".join(finding.get("mitre_techniques", []))
            })
        
        # Process findings
        for p in result.process_findings:
            finding = p if isinstance(p, dict) else p.model_dump()
            proc = finding.get("process", {})
            rows.append({
                "type": "process",
                "severity": finding.get("severity", ""),
                "path": f"PID:{proc.get('pid')} {proc.get('name', '')}",
                "description": finding.get("description", ""),
                "mitre": ",".join(finding.get("mitre_techniques", []))
            })
        
        # Network findings
        for n in result.network_findings:
            finding = n if isinstance(n, dict) else n.model_dump()
            rows.append({
                "type": "network",
                "severity": finding.get("severity", ""),
                "path": f"{finding.get('remote_ip')}:{finding.get('remote_port')}",
                "description": finding.get("description", ""),
                "mitre": ",".join(finding.get("mitre_techniques", []))
            })
        
        if rows:
            with open(filepath, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=["type", "severity", "path", "description", "mitre"])
                writer.writeheader()
                writer.writerows(rows)
        
        return filepath
    
    def export_to_stix(self, result: IoCScanResult) -> Dict[str, Any]:
        """Export scan results to STIX 2.1 format."""
        stix_bundle = {
            "type": "bundle",
            "id": f"bundle--{uuid_module.uuid4()}",
            "objects": []
        }
        
        # Add indicators for IOC matches
        for finding in result.file_findings:
            if isinstance(finding, dict):
                ioc_match = finding.get("ioc_match")
            else:
                ioc_match = finding.ioc_match
            
            if ioc_match:
                indicator = ioc_match if isinstance(ioc_match, dict) else ioc_match.model_dump()
                ind_value = indicator.get("indicator", {})
                
                stix_indicator = {
                    "type": "indicator",
                    "spec_version": "2.1",
                    "id": f"indicator--{uuid_module.uuid4()}",
                    "created": datetime.utcnow().isoformat() + "Z",
                    "modified": datetime.utcnow().isoformat() + "Z",
                    "name": f"IOC: {ind_value.get('value', '')}",
                    "pattern": f"[file:hashes.SHA256 = '{ind_value.get('value', '')}']",
                    "pattern_type": "stix",
                    "valid_from": datetime.utcnow().isoformat() + "Z"
                }
                stix_bundle["objects"].append(stix_indicator)
        
        return stix_bundle
    
    def generate_report(self, result: IoCScanResult) -> str:
        """Generate human-readable report."""
        lines = []
        lines.append("=" * 80)
        lines.append("IOC SCAN REPORT")
        lines.append("=" * 80)
        lines.append("")
        
        # Summary
        summary = result.summary if hasattr(result, 'summary') else result.get('summary', {})
        if isinstance(summary, dict):
            lines.append(f"Total Findings: {summary.get('total_findings', 0)}")
            lines.append(f"  Critical: {summary.get('critical_findings', 0)}")
            lines.append(f"  High: {summary.get('high_findings', 0)}")
            lines.append(f"  Medium: {summary.get('medium_findings', 0)}")
            lines.append(f"  Low: {summary.get('low_findings', 0)}")
        
        lines.append("")
        lines.append(f"Risk Score: {result.overall_risk_score if hasattr(result, 'overall_risk_score') else result.get('overall_risk_score', 0):.1f}/10")
        lines.append(f"Compromised: {'YES' if (result.is_compromised if hasattr(result, 'is_compromised') else result.get('is_compromised')) else 'No'}")
        
        # MITRE Coverage
        lines.append("")
        lines.append("-" * 40)
        lines.append("MITRE ATT&CK Coverage")
        lines.append("-" * 40)
        mitre = result.mitre_summary if hasattr(result, 'mitre_summary') else result.get('mitre_summary', {})
        if isinstance(mitre, dict):
            techniques = mitre.get('techniques_detected', [])
            lines.append(f"Techniques Detected: {len(techniques)}")
            for tech in techniques[:10]:
                if tech in MITRE_TECHNIQUES:
                    lines.append(f"  - {tech}: {MITRE_TECHNIQUES[tech]['name']}")
        
        # Top Findings
        lines.append("")
        lines.append("-" * 40)
        lines.append("Top Findings")
        lines.append("-" * 40)
        
        all_findings = []
        for f in (result.file_findings if hasattr(result, 'file_findings') else result.get('file_findings', [])):
            finding = f if isinstance(f, dict) else f.model_dump()
            all_findings.append(finding)
        for f in (result.process_findings if hasattr(result, 'process_findings') else result.get('process_findings', [])):
            finding = f if isinstance(f, dict) else f.model_dump()
            all_findings.append(finding)
        
        # Sort by severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        all_findings.sort(key=lambda x: severity_order.get(str(x.get('severity', '')).lower(), 5))
        
        for finding in all_findings[:10]:
            sev = finding.get('severity', 'unknown')
            desc = finding.get('description', 'No description')[:60]
            lines.append(f"  [{sev.upper()}] {desc}")
        
        # Remediation
        lines.append("")
        lines.append("-" * 40)
        lines.append("Recommended Actions")
        lines.append("-" * 40)
        remediation = result.remediation_steps if hasattr(result, 'remediation_steps') else result.get('remediation_steps', [])
        for i, step in enumerate(remediation[:5], 1):
            lines.append(f"  {i}. {step}")
        
        lines.append("")
        lines.append("=" * 80)
        
        return "\n".join(lines)

