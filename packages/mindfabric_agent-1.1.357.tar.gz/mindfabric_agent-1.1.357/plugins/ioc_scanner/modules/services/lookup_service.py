"""IOC lookup service."""

from typing import List, Dict, Any

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import IoCType


class LookupService:
    """Service for IOC lookups."""
    
    def __init__(self, plugin_instance):
        """
        Initialize lookup service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def lookup_hashes(self, hashes: List[str]) -> List[Dict[str, Any]]:
        """
        Look up hashes against loaded IOC database.
        
        Args:
            hashes: List of hashes to check
        
        Returns:
            List of matches with threat info
        """
        results = []
        
        for h in hashes:
            h_lower = h.lower().strip()
            
            if h_lower in self.plugin.ioc_hashes:
                indicator = self.plugin.ioc_hashes[h_lower]
                results.append({
                    "hash": h,
                    "found": True,
                    "indicator": indicator.model_dump(),
                    "threat_category": indicator.threat_category.value if indicator.threat_category else None,
                    "malware_family": indicator.malware_family,
                    "severity": indicator.severity.value
                })
            else:
                results.append({
                    "hash": h,
                    "found": False
                })
        
        return results
    
    async def lookup_ips(self, ips: List[str]) -> List[Dict[str, Any]]:
        """
        Look up IPs against loaded IOC database.
        
        Args:
            ips: List of IPs to check
        
        Returns:
            List of matches with threat info
        """
        from ..utils import check_dga, is_domain
        
        results = []
        
        for ip in ips:
            ip = ip.strip()
            
            if ip in self.plugin.ioc_ips:
                indicator = self.plugin.ioc_ips[ip]
                results.append({
                    "ip": ip,
                    "found": True,
                    "indicator": indicator.model_dump(),
                    "threat_category": indicator.threat_category.value if indicator.threat_category else None,
                    "severity": indicator.severity.value
                })
            else:
                # Check DGA (if it's actually a domain)
                is_dga, dga_score = check_dga(ip) if is_domain(ip) else (False, 0)
                results.append({
                    "ip": ip,
                    "found": False,
                    "dga_check": is_dga,
                    "dga_score": dga_score
                })
        
        return results
    
    async def lookup_domains(self, domains: List[str]) -> List[Dict[str, Any]]:
        """
        Look up domains against loaded IOC database.
        
        Args:
            domains: List of domains to check
        
        Returns:
            List of matches with threat info
        """
        from ..utils import check_dga
        
        results = []
        
        for domain in domains:
            domain_lower = domain.lower().strip()
            
            found = False
            indicator = None
            
            # Direct match
            if domain_lower in self.plugin.ioc_domains:
                found = True
                indicator = self.plugin.ioc_domains[domain_lower]
            
            # Subdomain match
            if not found:
                parts = domain_lower.split('.')
                for i in range(len(parts)):
                    check = '.'.join(parts[i:])
                    if check in self.plugin.ioc_domains:
                        found = True
                        indicator = self.plugin.ioc_domains[check]
                        break
            
            if found and indicator:
                results.append({
                    "domain": domain,
                    "found": True,
                    "indicator": indicator.model_dump(),
                    "threat_category": indicator.threat_category.value if indicator.threat_category else None,
                    "severity": indicator.severity.value
                })
            else:
                # Check DGA
                is_dga, dga_score = check_dga(domain)
                results.append({
                    "domain": domain,
                    "found": False,
                    "dga_check": is_dga,
                    "dga_score": dga_score
                })
        
        return results

