"""
File Signature Verifier Service

Verifies digital signatures of files (PE, DMG, APP) to detect masquerading and compromised binaries.
"""

import os
import logging
import uuid
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any

from ...proto import (
    FileSystemFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

logger = logging.getLogger(__name__)


class SignatureVerifierService:
    """Service for verifying digital signatures of files."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[FileSystemFinding] = []
        self._is_windows = os.name == 'nt'
        self._is_macos = os.uname().sysname == 'Darwin' if hasattr(os, 'uname') else False
    
    async def verify_signatures(
        self,
        file_paths: List[str],
        system_directories: Optional[List[str]] = None,
    ) -> List[FileSystemFinding]:
        """
        Verify digital signatures of files.
        
        Args:
            file_paths: List of file paths to check
            system_directories: List of system directories where signatures are required
            
        Returns:
            List of signature verification findings
        """
        findings = []
        
        if system_directories is None:
            system_directories = self._get_default_system_directories()
        
        for file_path in file_paths:
            try:
                file_path_obj = Path(file_path)
                
                # Check if file is in system directory
                is_system_file = any(
                    str(file_path_obj).startswith(sys_dir) for sys_dir in system_directories
                )
                
                if self._is_windows:
                    result = await self._verify_pe_signature(file_path)
                elif self._is_macos:
                    result = await self._verify_macos_signature(file_path)
                else:
                    # Linux: Check for GPG signatures or package signatures
                    result = await self._verify_linux_signature(file_path)
                
                if result:
                    if result.get("has_signature"):
                        # Check signature validity
                        if not result.get("is_valid"):
                            findings.append(self._create_finding(
                                file_path,
                                "invalid_signature",
                                f"File has invalid digital signature: {result.get('error', 'Unknown error')}",
                                SeverityLevel.HIGH if is_system_file else SeverityLevel.MEDIUM,
                                ConfidenceLevel.HIGH,
                                result,
                            ))
                        
                        # Check for suspicious certificates
                        if result.get("is_suspicious"):
                            findings.append(self._create_finding(
                                file_path,
                                "suspicious_certificate",
                                f"File has suspicious certificate: {result.get('certificate_info', {})}",
                                SeverityLevel.HIGH,
                                ConfidenceLevel.MEDIUM,
                                result,
                            ))
                    else:
                        # No signature
                        if is_system_file:
                            findings.append(self._create_finding(
                                file_path,
                                "unsigned_system_file",
                                f"System file lacks digital signature: {file_path}",
                                SeverityLevel.HIGH,
                                ConfidenceLevel.HIGH,
                                result,
                            ))
                
            except Exception as e:
                logger.debug(f"Error verifying signature for {file_path}: {e}")
                continue
        
        self.findings.extend(findings)
        return findings
    
    async def _verify_pe_signature(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Verify PE file signature on Windows."""
        try:
            # Use signtool or PowerShell Get-AuthenticodeSignature
            result = subprocess.run(
                ["powershell", "-Command", 
                 f"Get-AuthenticodeSignature -FilePath '{file_path}' | ConvertTo-Json"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            
            if result.returncode == 0:
                import json
                sig_info = json.loads(result.stdout)
                
                status = sig_info.get("Status", "Unknown")
                
                return {
                    "has_signature": status != "NotSigned",
                    "is_valid": status == "Valid",
                    "status": status,
                    "signer": sig_info.get("SignerCertificate", {}).get("Subject", ""),
                    "timestamp": sig_info.get("TimeStamperCertificate", {}).get("Subject", ""),
                    "error": sig_info.get("StatusMessage", ""),
                    "is_suspicious": self._is_suspicious_certificate(sig_info),
                    "certificate_info": sig_info.get("SignerCertificate", {}),
                }
        except Exception as e:
            logger.debug(f"Error verifying PE signature: {e}")
        
        return None
    
    async def _verify_macos_signature(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Verify macOS code signature."""
        try:
            result = subprocess.run(
                ["codesign", "-dv", "--verbose=4", file_path],
                capture_output=True,
                text=True,
                timeout=10,
            )
            
            if result.returncode == 0:
                # Parse codesign output
                output = result.stdout + result.stderr
                
                has_signature = "code object is not signed" not in output.lower()
                is_valid = "valid on disk" in output.lower() and "satisfies its Designated Requirement" in output.lower()
                
                return {
                    "has_signature": has_signature,
                    "is_valid": is_valid,
                    "output": output,
                }
        except Exception as e:
            logger.debug(f"Error verifying macOS signature: {e}")
        
        return None
    
    async def _verify_linux_signature(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Verify Linux file signature (GPG or package signature)."""
        try:
            # Check if file is from a package
            result = subprocess.run(
                ["dpkg", "-S", file_path],
                capture_output=True,
                text=True,
                timeout=5,
            )
            
            if result.returncode == 0:
                # File is from a package, check package signature
                package = result.stdout.split(":")[0]
                pkg_result = subprocess.run(
                    ["dpkg", "-s", package],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                
                if "Status: install ok installed" in pkg_result.stdout:
                    return {
                        "has_signature": True,
                        "is_valid": True,
                        "package": package,
                        "type": "package",
                    }
        except Exception:
            pass
        
        # Check for GPG signature file
        sig_file = Path(file_path + ".sig")
        if sig_file.exists():
            return {
                "has_signature": True,
                "is_valid": None,  # Would need to verify with GPG
                "type": "gpg",
            }
        
        return {
            "has_signature": False,
            "is_valid": False,
        }
    
    def _is_suspicious_certificate(self, sig_info: Dict[str, Any]) -> bool:
        """Check if certificate is suspicious."""
        cert = sig_info.get("SignerCertificate", {})
        subject = cert.get("Subject", "")
        
        # Check for self-signed certificates in system files
        if "CN=" in subject:
            # Extract CN
            cn = subject.split("CN=")[1].split(",")[0] if "CN=" in subject else ""
            
            # Suspicious patterns
            suspicious_patterns = [
                "test",
                "temp",
                "fake",
                "malware",
                "virus",
            ]
            
            if any(pattern in cn.lower() for pattern in suspicious_patterns):
                return True
        
        return False
    
    def _get_default_system_directories(self) -> List[str]:
        """Get default system directories."""
        if self._is_windows:
            return [
                "C:\\Windows\\System32",
                "C:\\Windows\\SysWOW64",
                "C:\\Program Files",
                "C:\\Program Files (x86)",
            ]
        elif self._is_macos:
            return [
                "/usr/bin",
                "/usr/sbin",
                "/System/Library",
                "/Applications",
            ]
        else:
            return [
                "/bin",
                "/sbin",
                "/usr/bin",
                "/usr/sbin",
                "/lib",
                "/lib64",
            ]
    
    def _create_finding(
        self,
        file_path: str,
        finding_type: str,
        description: str,
        severity: SeverityLevel,
        confidence: ConfidenceLevel,
        signature_info: Optional[Dict[str, Any]] = None,
    ) -> FileSystemFinding:
        """Create a signature verification finding."""
        
        evidence = [description]
        if signature_info:
            evidence.append(f"Signature info: {signature_info}")
        
        return FileSystemFinding(
            finding_type=finding_type,
            severity=severity,
            confidence=confidence,
            file_path=file_path,
            threat_category=ThreatCategory.DEFENSE_EVASION,
            description=description,
            evidence=evidence,
            mitre_techniques=["T1554", "T1036"],
            remediation="Verify file integrity. Check if file was modified or replaced. Compare with known good hash.",
        )
