"""
DNS Analysis Service

Enhanced DNS analysis for:
- DNS exfiltration detection (T1048)
- DNS anomalies detection
- DNS C2 communication detection (T1071.004)
- DGA domain detection
"""

import re
import asyncio
from collections import defaultdict
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Set
from urllib.parse import urlparse

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from utils.logger import logger
from ...proto import (
    NetworkFinding,
    DNSQuery,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
    IoCType,
    NetworkProtocol,
)

# DNS exfiltration patterns
DNS_EXFIL_PATTERNS = [
    r"[a-zA-Z0-9]{32,}",  # Long base64-like strings
    r"[0-9a-f]{32,}",      # Long hex strings
    r"[\w\-]{50,}",        # Very long subdomains
]

# Suspicious DNS record types for exfiltration
SUSPICIOUS_DNS_TYPES = ["TXT", "NULL", "CNAME"]

# Known DGA patterns
DGA_PATTERNS = [
    r"[a-z]{10,}\d{4,}\.[a-z]{2,}",  # Random chars + numbers
    r"[a-z]{15,}\.[a-z]{2,}",        # Very long random domains
    r"\d{8,}\.[a-z]{2,}",            # Numbers + TLD
]

# Entropy threshold for suspicious subdomains
ENTROPY_THRESHOLD = 4.5


class DNSAnalysisService:
    """Service for advanced DNS analysis."""
    
    def __init__(self, plugin_instance):
        """
        Initialize DNS analysis service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin
        """
        self.plugin = plugin_instance
        self.dns_query_history: Dict[str, List[datetime]] = defaultdict(list)
        self.dns_query_counts: Dict[str, int] = defaultdict(int)
    
    async def analyze_dns_queries(
        self,
        dns_queries: Optional[List[DNSQuery]] = None,
        analyze_exfiltration: bool = True,
        analyze_anomalies: bool = True,
        analyze_c2: bool = True,
    ) -> List[NetworkFinding]:
        """
        Analyze DNS queries for exfiltration, anomalies, and C2 communication.
        
        Args:
            dns_queries: List of DNS queries to analyze
            analyze_exfiltration: Detect DNS exfiltration
            analyze_anomalies: Detect DNS anomalies
            analyze_c2: Detect DNS C2 communication
            
        Returns:
            List of NetworkFinding related to DNS
        """
        findings = []
        
        try:
            # If no queries provided, try to collect from system
            if dns_queries is None:
                dns_queries = await self._collect_dns_queries()
            
            # Analyze each query
            for query in dns_queries:
                # Track query history
                self.dns_query_history[query.domain].append(query.timestamp)
                self.dns_query_counts[query.domain] += 1
                
                # DNS exfiltration detection
                if analyze_exfiltration:
                    exfil_findings = await self._detect_dns_exfiltration(query)
                    findings.extend(exfil_findings)
                
                # DNS anomalies detection
                if analyze_anomalies:
                    anomaly_findings = await self._detect_dns_anomalies(query)
                    findings.extend(anomaly_findings)
                
                # DNS C2 detection
                if analyze_c2:
                    c2_findings = await self._detect_dns_c2(query)
                    findings.extend(c2_findings)
            
            # Analyze query patterns
            pattern_findings = await self._analyze_query_patterns()
            findings.extend(pattern_findings)
            
            logger.info(f"[dns_analysis] Analyzed {len(dns_queries)} DNS queries, found {len(findings)} findings")
            
        except Exception as e:
            logger.error(f"[dns_analysis] Error analyzing DNS queries: {e}")
            self.plugin.errors.append(f"DNS analysis failed: {e}")
        
        return findings
    
    async def _collect_dns_queries(self) -> List[DNSQuery]:
        """Collect DNS queries from system logs and network monitoring."""
        queries = []
        
        # Common DNS log locations
        dns_log_paths = [
            "/var/log/syslog",
            "/var/log/messages",
            "/var/log/dnsmasq.log",
            "/var/log/bind9/query.log",
        ]
        
        # DNS query regex pattern
        dns_query_pattern = re.compile(
            r'(?:query|dns):\s+([A-Z]+)\s+([\w\.\-]+)',
            re.IGNORECASE
        )
        
        for log_path in dns_log_paths:
            try:
                from pathlib import Path
                if not Path(log_path).exists():
                    continue
                
                with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                    # Read last 1000 lines
                    lines = f.readlines()[-1000:]
                    
                    for line in lines:
                        match = dns_query_pattern.search(line)
                        if match:
                            query_type = match.group(1)
                            domain = match.group(2)
                            
                            queries.append(DNSQuery(
                                domain=domain,
                                query_type=query_type,
                                timestamp=datetime.utcnow(),  # Would parse from log
                                source_ip="",  # Would parse from log
                            ))
            except Exception as e:
                logger.debug(f"Error reading DNS log {log_path}: {e}")
                continue
        
        return queries
    
    async def _detect_dns_exfiltration(self, query: DNSQuery) -> List[NetworkFinding]:
        """Detect DNS exfiltration patterns."""
        findings = []
        
        domain = query.domain.lower()
        
        # Check for suspicious subdomain patterns
        if "." in domain:
            subdomain = domain.split(".")[0]
            
            # Check length (exfiltration often uses long subdomains)
            if len(subdomain) > 50:
                findings.append(NetworkFinding(
                    finding_type="dns_exfiltration",
                    severity=SeverityLevel.HIGH,
                    confidence=ConfidenceLevel.MEDIUM,
                    dns_query=query,
                    remote_domain=domain,
                    threat_category=ThreatCategory.DATA_EXFILTRATION,
                    mitre_techniques=["T1048"],
                    description=f"DNS query with unusually long subdomain: {len(subdomain)} chars",
                    evidence=[
                        f"Subdomain length: {len(subdomain)}",
                        f"Subdomain: {subdomain[:50]}...",
                    ],
                    remediation="Investigate DNS query source. Monitor for data exfiltration. Block suspicious domains.",
                    detected_at=datetime.utcnow(),
                ))
            
            # Check for base64/hex patterns
            for pattern in DNS_EXFIL_PATTERNS:
                if re.search(pattern, subdomain):
                    findings.append(NetworkFinding(
                        finding_type="dns_exfiltration",
                        severity=SeverityLevel.HIGH,
                        confidence=ConfidenceLevel.MEDIUM,
                        dns_query=query,
                        remote_domain=domain,
                        threat_category=ThreatCategory.DATA_EXFILTRATION,
                        mitre_techniques=["T1048"],
                        description=f"DNS query with encoded data pattern in subdomain",
                        evidence=[f"Pattern match: {pattern}"],
                        remediation="Investigate DNS query source. Monitor for data exfiltration.",
                        detected_at=datetime.utcnow(),
                    ))
                    break
            
            # Check entropy (high entropy = possible encryption/encoding)
            entropy = self._calculate_entropy(subdomain)
            if entropy > ENTROPY_THRESHOLD:
                findings.append(NetworkFinding(
                    finding_type="dns_exfiltration",
                    severity=SeverityLevel.MEDIUM,
                    confidence=ConfidenceLevel.LOW,
                    dns_query=query,
                    remote_domain=domain,
                    threat_category=ThreatCategory.DATA_EXFILTRATION,
                    mitre_techniques=["T1048"],
                    description=f"DNS query with high entropy subdomain (possible encoded data)",
                    evidence=[f"Entropy: {entropy:.2f}"],
                    remediation="Investigate DNS query source. Monitor for data exfiltration.",
                    detected_at=datetime.utcnow(),
                ))
        
        # Check for suspicious DNS record types
        if query.query_type in SUSPICIOUS_DNS_TYPES:
            findings.append(NetworkFinding(
                finding_type="dns_exfiltration",
                severity=SeverityLevel.MEDIUM,
                confidence=ConfidenceLevel.MEDIUM,
                dns_query=query,
                remote_domain=domain,
                threat_category=ThreatCategory.DATA_EXFILTRATION,
                mitre_techniques=["T1048"],
                description=f"DNS query with suspicious record type: {query.query_type}",
                evidence=[f"Record type: {query.query_type}"],
                remediation="Investigate DNS query source. Monitor for data exfiltration.",
                detected_at=datetime.utcnow(),
            ))
        
        return findings
    
    async def _detect_dns_anomalies(self, query: DNSQuery) -> List[NetworkFinding]:
        """Detect DNS anomalies."""
        findings = []
        
        domain = query.domain.lower()
        
        # Check for DGA patterns
        for pattern in DGA_PATTERNS:
            if re.search(pattern, domain):
                findings.append(NetworkFinding(
                    finding_type="dns_anomaly",
                    severity=SeverityLevel.HIGH,
                    confidence=ConfidenceLevel.MEDIUM,
                    dns_query=query,
                    remote_domain=domain,
                    threat_category=ThreatCategory.C2,
                    mitre_techniques=["T1071.004"],
                    description=f"DNS query to possible DGA domain",
                    evidence=[f"DGA pattern match: {pattern}"],
                    remediation="Block DGA domain. Investigate source process. Monitor for C2 communication.",
                    detected_at=datetime.utcnow(),
                ))
                break
        
        # Check query frequency (high frequency = possible C2)
        query_count = self.dns_query_counts.get(domain, 0)
        if query_count > 100:
            findings.append(NetworkFinding(
                finding_type="dns_anomaly",
                severity=SeverityLevel.MEDIUM,
                confidence=ConfidenceLevel.MEDIUM,
                dns_query=query,
                remote_domain=domain,
                threat_category=ThreatCategory.C2,
                mitre_techniques=["T1071.004"],
                description=f"High frequency DNS queries to domain: {query_count} queries",
                evidence=[f"Query count: {query_count}"],
                remediation="Investigate high-frequency DNS queries. Monitor for C2 communication.",
                detected_at=datetime.utcnow(),
            ))
        
        return findings
    
    async def _detect_dns_c2(self, query: DNSQuery) -> List[NetworkFinding]:
        """Detect DNS-based C2 communication."""
        findings = []
        
        domain = query.domain.lower()
        
        # Check if domain is in IOC database
        if domain in self.plugin.ioc_domains:
            indicator = self.plugin.ioc_domains[domain]
            findings.append(NetworkFinding(
                finding_type="ioc_match",
                severity=indicator.severity,
                confidence=ConfidenceLevel.CONFIRMED,
                dns_query=query,
                remote_domain=domain,
                threat_category=ThreatCategory.C2,
                mitre_techniques=["T1071.004"],
                description=f"DNS query to known C2 domain: {domain}",
                evidence=[f"IOC match: {indicator.value}"],
                remediation="Block C2 domain. Isolate affected system. Investigate compromise.",
                detected_at=datetime.utcnow(),
            ))
        
        # Check for beaconing pattern (regular intervals)
        query_times = self.dns_query_history.get(domain, [])
        if len(query_times) >= 5:
            intervals = []
            for i in range(1, len(query_times)):
                interval = (query_times[i] - query_times[i-1]).total_seconds()
                intervals.append(interval)
            
            # Check if intervals are regular (beaconing)
            if len(intervals) >= 3:
                avg_interval = sum(intervals) / len(intervals)
                variance = sum((i - avg_interval) ** 2 for i in intervals) / len(intervals)
                
                # Low variance = regular intervals = possible beaconing
                if variance < avg_interval * 0.2:  # 20% variance threshold
                    findings.append(NetworkFinding(
                        finding_type="c2_beacon",
                        severity=SeverityLevel.HIGH,
                        confidence=ConfidenceLevel.MEDIUM,
                        dns_query=query,
                        remote_domain=domain,
                        threat_category=ThreatCategory.C2,
                        mitre_techniques=["T1071.004"],
                        description=f"DNS beaconing pattern detected: regular intervals (~{avg_interval:.1f}s)",
                        evidence=[
                            f"Average interval: {avg_interval:.1f}s",
                            f"Variance: {variance:.1f}",
                        ],
                        remediation="Block C2 domain. Investigate source process. Isolate affected system.",
                        detected_at=datetime.utcnow(),
                    ))
        
        return findings
    
    async def _analyze_query_patterns(self) -> List[NetworkFinding]:
        """Analyze DNS query patterns across all queries."""
        findings = []
        
        # Find domains with very high query frequency
        for domain, count in self.dns_query_counts.items():
            if count > 500:
                findings.append(NetworkFinding(
                    finding_type="dns_anomaly",
                    severity=SeverityLevel.MEDIUM,
                    confidence=ConfidenceLevel.LOW,
                    remote_domain=domain,
                    threat_category=ThreatCategory.C2,
                    mitre_techniques=["T1071.004"],
                    description=f"Extremely high DNS query frequency: {count} queries",
                    evidence=[f"Query count: {count}"],
                    remediation="Investigate high-frequency DNS queries. Monitor for C2 or exfiltration.",
                    detected_at=datetime.utcnow(),
                ))
        
        return findings
    
    def _calculate_entropy(self, text: str) -> float:
        """Calculate Shannon entropy of a string."""
        if not text:
            return 0.0
        
        import math
        from collections import Counter
        
        counter = Counter(text.lower())
        length = len(text)
        entropy = 0.0
        
        for count in counter.values():
            probability = count / length
            if probability > 0:
                entropy -= probability * math.log2(probability)
        
        return entropy
