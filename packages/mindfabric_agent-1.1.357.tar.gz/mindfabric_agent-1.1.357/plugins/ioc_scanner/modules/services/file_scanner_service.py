"""File system IOC scanning service."""

import os
import re
import asyncio
import time
from pathlib import Path
from typing import List, Dict, Any, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from utils.logger import logger
from ...proto import (
    FileSystemFinding,
    IoCIndicator,
    IoCMatch,
    ScanOptions,
    ScanScope,
    IoCType,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)
from ..utils import (
    calculate_file_hashes,
    get_file_metadata,
    detect_ioc_type,
    match_yara_rules,
)
from ..databases import (
    SUSPICIOUS_LOCATIONS,
    ENTROPY_THRESHOLD,
)
from ..detection import WebshellDetector
from ..utils.ioc_file_threat_policy import is_node_js_package_manager_cache


class FileScannerService:
    """Service for file system IOC scanning."""

    @staticmethod
    def _dedupe_file_findings(results: List[Any]) -> List[Any]:
        """
        One row per (finding_type, normalized path, IOC indicator) per scan.
        Preserves distinct YARA rule hits / hashes on the same path.
        """
        seen: set = set()
        out: List[Any] = []
        for f in results:
            try:
                if hasattr(f, "model_dump"):
                    d = f.model_dump()
                elif isinstance(f, dict):
                    d = dict(f)
                else:
                    d = {}
                fp = d.get("file_path") or d.get("filePath") or ""
                try:
                    fp_norm = os.path.normpath(str(fp)).lower() if fp else ""
                except Exception:
                    fp_norm = str(fp).lower() if fp else ""
                ft = str(d.get("finding_type") or d.get("findingType") or "").lower()
                ind = ""
                im = d.get("ioc_match")
                if isinstance(im, dict):
                    ind_obj = im.get("indicator")
                    if isinstance(ind_obj, dict):
                        ind = str(ind_obj.get("value") or "")
                yara = ""
                ym = d.get("yara_matches") or d.get("yaraMatches")
                if isinstance(ym, list) and ym:
                    yara = ",".join(sorted({str(getattr(x, "rule_name", None) or x) for x in ym[:20]}))
                key = (ft, fp_norm, ind, yara)
                if key in seen:
                    continue
                seen.add(key)
                out.append(f)
            except Exception:
                out.append(f)
        return out
    
    def __init__(self, plugin_instance):
        """
        Initialize file scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
        self.webshell_detector = WebshellDetector()

    @staticmethod
    def _safe_stderr_write(msg: str) -> None:
        """
        Best-effort debug write for subprocess mode.
        Avoid surfacing BrokenPipeError as a scan failure when stderr pipe closes.
        """
        try:
            import sys

            sys.stderr.write(msg)
            sys.stderr.flush()
        except BrokenPipeError:
            return
        except OSError:
            return
        except Exception:
            return
    
    def iter_files(self, path: Path, scope: ScanScope):
        """Iterate regular files under path while *pruning* excluded directories.

        Important: avoid Path.rglob() here. It can't prune subtrees, so we'd still walk huge pseudo-filesystems
        like /proc and /sys. That can block the event loop long enough that phase timeouts don't fire, leading
        to agent-level command timeouts on the first run.
        """
        import stat
        import sys

        # Known slow/pseudo directories to prune immediately (performance optimization)
        skip_prefixes = {
            "/proc",
            "/sys",
            "/dev",
            "/run",
            "/tmp",
            "/var/lib/docker",
            "/var/lib/containers",
            "/snap",
            "/boot/efi",
            "/lost+found",
            "/var/cache",
            "/var/tmp",
        }

        def _norm(p: str) -> str:
            p2 = (p or "").strip()
            if not p2:
                return ""
            # Keep root "/" as-is, otherwise strip trailing slashes for stable prefix checks.
            return p2 if p2 == "/" else p2.rstrip("/")

        exclude_prefixes = [_norm(p) for p in (scope.exclude_paths or []) if _norm(p)]
        for p in skip_prefixes:
            pn = _norm(p)
            if pn and pn not in exclude_prefixes:
                exclude_prefixes.append(pn)

        def _is_excluded(full_path: str) -> bool:
            fp = _norm(full_path)
            if not fp:
                return False
            for ex in exclude_prefixes:
                if fp == ex or fp.startswith(ex + os.sep):
                    return True
            return False

        try:
            msg = f"[ioc_scanner] iter_files: Starting iteration for path={path}, scope.scan_hidden={scope.scan_hidden}\n"
            self._safe_stderr_write(msg)
            logger.info(msg.strip())

            if path.is_file():
                msg = f"[ioc_scanner] iter_files: Path is a file, yielding: {path}\n"
                self._safe_stderr_write(msg)
                logger.info(msg.strip())
                yield path
                return

            root = str(path)
            if _is_excluded(root):
                logger.info(f"[ioc_scanner] iter_files: Root path excluded, skipping: {root}")
                return

            items_seen = 0
            first_logged = False

            # Prunable directory walk.
            for dirpath, dirnames, filenames in os.walk(
                root,
                topdown=True,
                followlinks=bool(scope.follow_symlinks),
            ):
                # Prune excluded/hidden dirs *in-place* so we don't descend.
                if dirnames:
                    keep: List[str] = []
                    for d in dirnames:
                        if not scope.scan_hidden and d.startswith("."):
                            continue
                        full_d = os.path.join(dirpath, d)
                        if _is_excluded(full_d):
                            continue
                        keep.append(d)
                    dirnames[:] = keep

                if not filenames:
                    continue

                for name in filenames:
                    items_seen += 1

                    if not first_logged:
                        msg = f"[ioc_scanner] iter_files: First item found: {os.path.join(dirpath, name)}\n"
                        self._safe_stderr_write(msg)
                        logger.info(msg.strip())
                        first_logged = True
                    elif items_seen % 1000 == 0:
                        msg = f"[ioc_scanner] iter_files: Processed {items_seen} items so far\n"
                        self._safe_stderr_write(msg)
                        logger.info(msg.strip())

                    if not scope.scan_hidden and name.startswith("."):
                        continue

                    full_path = os.path.join(dirpath, name)
                    if _is_excluded(full_path):
                        continue

                    # Skip symlinks if not following (fast path before stat)
                    if not scope.follow_symlinks:
                        try:
                            if os.path.islink(full_path):
                                continue
                        except (OSError, PermissionError):
                            continue

                    try:
                        st = os.stat(full_path, follow_symlinks=bool(scope.follow_symlinks))
                        if not stat.S_ISREG(st.st_mode):
                            continue
                        if st.st_size > scope.max_file_size:
                            continue
                    except (OSError, PermissionError):
                        continue
                    except Exception:
                        continue

                    yield Path(full_path)

        except PermissionError as e:
            msg = f"[ioc_scanner] iter_files: PermissionError for path={path}: {e}\n"
            self._safe_stderr_write(msg)
            logger.warning(msg.strip())
        except Exception as e:
            msg = f"[ioc_scanner] iter_files: Exception for path={path}: {e}\n"
            self._safe_stderr_write(msg)
            logger.warning(msg.strip())
    
    def check_suspicious_location(self, filepath: str) -> Optional[FileSystemFinding]:
        """Check if file is in suspicious location."""
        try:
            path_lower = str(filepath).replace("\\", "/").lower()
        except Exception:
            path_lower = ""
        # Toolchain/package-manager trees: executable scripts here are usually not incident-worthy alone.
        if path_lower and is_node_js_package_manager_cache(path_lower):
            return None
        for location, info in SUSPICIOUS_LOCATIONS.items():
            if "*" in location:
                pattern = location.replace("*", ".*")
                if re.match(pattern, filepath):
                    # Additional check: is it executable in non-standard location?
                    if os.access(filepath, os.X_OK):
                        return FileSystemFinding(
                            finding_type="suspicious_location",
                            severity=info["severity"],
                            confidence=ConfidenceLevel.MEDIUM,
                            file_path=filepath,
                            file_metadata=get_file_metadata(filepath),
                            description=f"Executable in suspicious location: {info['reason']}",
                            mitre_techniques=["T1036.005"]
                        )
            elif filepath.startswith(location):
                if os.access(filepath, os.X_OK):
                    return FileSystemFinding(
                        finding_type="suspicious_location",
                        severity=info["severity"],
                        confidence=ConfidenceLevel.MEDIUM,
                        file_path=filepath,
                        file_metadata=get_file_metadata(filepath),
                        description=f"Executable in suspicious location: {info['reason']}",
                        mitre_techniques=["T1036.005"]
                    )
        
        return None
    
    async def scan_files(
        self,
        ioc_list: List[str] = None,
        paths: List[str] = None,
        options: ScanOptions = None,
    ) -> List[Dict[str, Any]]:
        """
        Comprehensive file system IOC scanning.
        
        Args:
            ioc_list: List of IOC values (hashes, filenames, paths)
            paths: Directories to scan
            options: Scan configuration options
        
        Returns:
            List of FileSystemFinding dictionaries
        """
        if options is None:
            options = ScanOptions()
        
        if paths is None:
            paths = options.scope.file_paths or ["/"]
        
        results: List[FileSystemFinding] = []
        scanned_count = 0
        start_time = time.time()
        
        # Get timeout from options (default 30 minutes for file system phase)
        timeout_seconds = getattr(options, 'timeout_seconds', None) or 1800
        deadline_ts = start_time + timeout_seconds
        
        # Parse IOC list
        hash_iocs: Dict[str, IoCIndicator] = {}
        name_iocs: List[str] = []
        path_iocs: List[str] = []
        
        if ioc_list:
            for ioc in ioc_list:
                ioc_type = detect_ioc_type(ioc)
                if ioc_type in [IoCType.MD5, IoCType.SHA1, IoCType.SHA256]:
                    hash_iocs[ioc.lower()] = IoCIndicator(
                        value=ioc.lower(),
                        type=ioc_type,
                        confidence=0.9,
                        severity=SeverityLevel.HIGH
                    )
                elif "/" in ioc or "\\" in ioc:
                    path_iocs.append(ioc)
                else:
                    name_iocs.append(ioc.lower())
        
        # Add loaded IOCs
        hash_iocs.update(self.plugin.ioc_hashes)
        
        logger.info(f"[ioc_scanner] Starting file system scan with timeout: {timeout_seconds}s, paths={paths}")
        
        try:
            for scan_path in paths:
                scan_path = Path(scan_path)
                if not scan_path.exists():
                    logger.warning(f"[ioc_scanner] Scan path does not exist: {scan_path}")
                    continue
                
                files_iterated = 0
                # Iterate files with timeout checks
                for filepath in self.iter_files(scan_path, options.scope):
                    files_iterated += 1
                    # Check timeout before processing each file
                    elapsed = time.time() - start_time
                    remaining = timeout_seconds - elapsed
                    
                    if remaining <= 10:  # Stop if less than 10 seconds remaining
                        logger.warning(f"[ioc_scanner] File system scan stopping early - only {remaining:.1f}s remaining")
                        break
                    
                    # Yield control to event loop periodically to allow timeout to work
                    if scanned_count % 100 == 0:
                        await asyncio.sleep(0)
                    
                    try:
                        scanned_count += 1
                        
                        # Progress logging and callback
                        # Log every 1000 files
                        if scanned_count % 1000 == 0:
                            logger.info(f"[ioc_scanner] Scanned {scanned_count} files, found {len(results)} findings so far (elapsed: {elapsed:.1f}s, remaining: {remaining:.1f}s)")
                            await self.plugin._handle_progress(
                                scanned_count,
                                f"Scanned {scanned_count} files"
                            )
                        
                        str_path = str(filepath)
                        filename = filepath.name.lower()
                        
                        # Check 1: Filename match
                        if name_iocs:
                            for name_ioc in name_iocs:
                                if name_ioc in filename:
                                    # Use asyncio.to_thread with timeout for blocking I/O
                                    try:
                                        metadata = await asyncio.wait_for(
                                            asyncio.to_thread(get_file_metadata, str_path),
                                            timeout=options.scope.file_timeout_seconds or 30
                                        )
                                    except asyncio.TimeoutError:
                                        logger.warning(f"[ioc_scanner] get_file_metadata timeout for {str_path}")
                                        continue
                                    results.append(FileSystemFinding(
                                        finding_type="ioc_match",
                                        severity=SeverityLevel.HIGH,
                                        confidence=ConfidenceLevel.HIGH,
                                        file_path=str_path,
                                        file_metadata=metadata,
                                        ioc_match=IoCMatch(
                                            indicator=IoCIndicator(
                                                value=name_ioc,
                                                type=IoCType.FILE_NAME,
                                                severity=SeverityLevel.HIGH
                                            ),
                                            target=str_path,
                                            target_type="file",
                                            match_type="partial",
                                            severity=SeverityLevel.HIGH,
                                            confidence=ConfidenceLevel.HIGH
                                        ),
                                        description=f"Filename matches IOC pattern: {name_ioc}",
                                        mitre_techniques=["T1036"]
                                    ))
                        
                        # Check 2: Path match
                        if path_iocs:
                            for path_ioc in path_iocs:
                                if path_ioc in str_path:
                                    # Use asyncio.to_thread with timeout for blocking I/O
                                    try:
                                        metadata = await asyncio.wait_for(
                                            asyncio.to_thread(get_file_metadata, str_path),
                                            timeout=options.scope.file_timeout_seconds or 30
                                        )
                                    except asyncio.TimeoutError:
                                        logger.warning(f"[ioc_scanner] get_file_metadata timeout for {str_path}")
                                        continue
                                    results.append(FileSystemFinding(
                                        finding_type="ioc_match",
                                        severity=SeverityLevel.HIGH,
                                        confidence=ConfidenceLevel.HIGH,
                                        file_path=str_path,
                                        file_metadata=metadata,
                                        description=f"File path matches IOC: {path_ioc}",
                                        mitre_techniques=["T1036"]
                                    ))
                        
                        # Check 3: Hash match (for reasonable file sizes)
                        # Use asyncio.to_thread with timeout for blocking stat()
                        try:
                            file_size = await asyncio.wait_for(
                                asyncio.to_thread(lambda: filepath.stat().st_size),
                                timeout=options.scope.file_timeout_seconds or 30
                            )
                        except Exception:
                            file_size = 0
                        
                        if hash_iocs and file_size < options.scope.max_file_size:
                            # Use asyncio.to_thread with timeout for blocking hash calculation
                            try:
                                hashes = await asyncio.wait_for(
                                    asyncio.to_thread(calculate_file_hashes, str_path, ["md5", "sha1", "sha256"]),
                                    timeout=options.scope.file_timeout_seconds or 30
                                )
                            except asyncio.TimeoutError:
                                logger.warning(f"[ioc_scanner] calculate_file_hashes timeout for {str_path}")
                                continue
                            
                            for hash_val in [hashes.md5, hashes.sha1, hashes.sha256]:
                                if hash_val and hash_val.lower() in hash_iocs:
                                    indicator = hash_iocs[hash_val.lower()]
                                    # Use asyncio.to_thread with timeout for blocking I/O
                                    try:
                                        metadata = await asyncio.wait_for(
                                            asyncio.to_thread(get_file_metadata, str_path),
                                            timeout=options.scope.file_timeout_seconds or 30
                                        )
                                    except asyncio.TimeoutError:
                                        logger.warning(f"[ioc_scanner] get_file_metadata timeout for {str_path}")
                                        continue
                                    if metadata:
                                        metadata.hashes = hashes
                                    
                                    results.append(FileSystemFinding(
                                        finding_type="ioc_match",
                                        severity=indicator.severity,
                                        confidence=ConfidenceLevel.CONFIRMED,
                                        file_path=str_path,
                                        file_metadata=metadata,
                                        ioc_match=IoCMatch(
                                            indicator=indicator,
                                            target=str_path,
                                            target_type="file",
                                            match_type="exact",
                                            severity=indicator.severity,
                                            confidence=ConfidenceLevel.CONFIRMED,
                                            hashes=hashes
                                        ),
                                        threat_category=indicator.threat_category,
                                        malware_family=indicator.malware_family,
                                        description=f"File hash matches known IOC: {indicator.value}",
                                        mitre_techniques=indicator.ttps or []
                                    ))
                        
                        # Check 4: YARA rules
                        if options.use_yara and self.plugin.yara_rules_paths:
                            # Use asyncio.to_thread with timeout for blocking YARA matching
                            try:
                                yara_matches = await asyncio.wait_for(
                                    asyncio.to_thread(
                                        match_yara_rules,
                                        str_path,
                                        self.plugin.yara_rules_paths,
                                        options.yara_timeout
                                    ),
                                    timeout=(options.yara_timeout or 60) + 10  # Add 10s buffer
                                )
                            except asyncio.TimeoutError:
                                logger.warning(f"[ioc_scanner] match_yara_rules timeout for {str_path}")
                                continue
                            if yara_matches:
                                # Use asyncio.to_thread with timeout for blocking I/O
                                try:
                                    metadata = await asyncio.wait_for(
                                        asyncio.to_thread(get_file_metadata, str_path),
                                        timeout=options.scope.file_timeout_seconds or 30
                                    )
                                except asyncio.TimeoutError:
                                    logger.warning(f"[ioc_scanner] get_file_metadata timeout for {str_path}")
                                    continue
                                results.append(FileSystemFinding(
                                    finding_type="yara_match",
                                    severity=SeverityLevel.HIGH,
                                    confidence=ConfidenceLevel.HIGH,
                                    file_path=str_path,
                                    file_metadata=metadata,
                                    yara_matches=yara_matches,
                                    description=f"YARA rules matched: {[m.rule_name for m in yara_matches]}",
                                    mitre_techniques=["T1027"]
                                ))
                        
                        # Check 5: Suspicious location
                        finding = self.check_suspicious_location(str_path)
                        if finding:
                            results.append(finding)
                        
                        # Check 6: Webshell detection
                        if self.webshell_detector.is_web_file(str_path):
                            webshell = await self.webshell_detector.detect(str_path)
                            if webshell:
                                results.append(webshell)
                        
                        # Check 7: High entropy (packed/encrypted)
                        if options.scope.scan_hidden:
                            # Use asyncio.to_thread with timeout for blocking I/O
                            try:
                                metadata = await asyncio.wait_for(
                                    asyncio.to_thread(get_file_metadata, str_path),
                                    timeout=options.scope.file_timeout_seconds or 30
                                )
                            except asyncio.TimeoutError:
                                logger.warning(f"[ioc_scanner] get_file_metadata timeout for {str_path}")
                                continue
                            if metadata and metadata.entropy and metadata.entropy > ENTROPY_THRESHOLD:
                                results.append(FileSystemFinding(
                                    finding_type="high_entropy",
                                    severity=SeverityLevel.MEDIUM,
                                    confidence=ConfidenceLevel.MEDIUM,
                                    file_path=str_path,
                                    file_metadata=metadata,
                                    description=f"High entropy file ({metadata.entropy:.2f}) - possibly packed/encrypted",
                                    mitre_techniques=["T1027"]
                                ))
                    
                    except PermissionError:
                        continue
                    except Exception as e:
                        # Log every 100 errors to avoid spam
                        if scanned_count % 100 == 0:
                            logger.warning(f"[ioc_scanner] Error scanning file {filepath}: {e} (total scanned: {scanned_count})")
                        continue
        
        except Exception as e:
            logger.error(f"[ioc_scanner] File system scan error: {e}", exc_info=True)
            await self.plugin._send_alert("ioc_fs_error", str(e), SeverityLevel.HIGH)
        finally:
            elapsed_total = time.time() - start_time
            logger.info(f"[ioc_scanner] File system scan completed: scanned={scanned_count}, findings={len(results)}, elapsed={elapsed_total:.1f}s")
        return self._dedupe_file_findings(results)

