"""Persistence mechanism scanning service."""

import os
import re
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    PersistenceFinding,
    PersistenceType,
    ScanOptions,
    SeverityLevel,
    ConfidenceLevel,
)
from ..databases import PERSISTENCE_CHECKS
from ..detection import PersistenceDetector
from ..utils import calculate_entropy


class PersistenceScannerService:
    """Service for persistence mechanism scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize persistence scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
        self.detector = PersistenceDetector()
    
    async def scan_persistence(
        self,
        options: ScanOptions = None,
    ) -> List[PersistenceFinding]:
        """
        Scan for persistence mechanisms.
        
        Args:
            options: Scan configuration
        
        Returns:
            List of PersistenceFinding
        """
        if options is None:
            options = ScanOptions()
        
        results: List[PersistenceFinding] = []
        
        try:
            for check_name, check_info in PERSISTENCE_CHECKS.items():
                for path_pattern in check_info["paths"]:
                    # Expand patterns
                    paths = []
                    if "*" in path_pattern:
                        try:
                            paths = list(Path("/").glob(path_pattern.lstrip("/")))
                        except OSError:
                            paths = []
                    elif path_pattern.startswith("~"):
                        # Expand for all users
                        for user_home in Path("/home").iterdir():
                            expanded = path_pattern.replace("~", str(user_home))
                            if Path(expanded).exists():
                                paths.append(Path(expanded))
                        # Also check root
                        root_path = path_pattern.replace("~", "/root")
                        if Path(root_path).exists():
                            paths.append(Path(root_path))
                    else:
                        paths = [Path(path_pattern)] if Path(path_pattern).exists() else []
                    
                    for path in paths:
                        try:
                            # Skip if not file
                            if not path.is_file():
                                continue
                            
                            # Check for suspicious content
                            suspicious = await self.detector.analyze_file(
                                str(path),
                                check_info["type"]
                            )
                            
                            if suspicious:
                                results.append(PersistenceFinding(
                                    persistence_type=check_info["type"],
                                    severity=suspicious.get("severity", SeverityLevel.MEDIUM),
                                    confidence=suspicious.get("confidence", ConfidenceLevel.MEDIUM),
                                    location=str(path),
                                    value=suspicious.get("content"),
                                    file_path=str(path),
                                    description=suspicious.get("description", f"Suspicious persistence in {path}"),
                                    is_legitimate=False,
                                    evidence=suspicious.get("evidence", []),
                                    mitre_technique=check_info["ttp"],
                                    remediation=f"Review and remove if unauthorized: {path}"
                                ))
                        
                        except PermissionError:
                            continue
        
        except Exception as e:
            await self.plugin._send_alert("persistence_error", str(e), SeverityLevel.HIGH)
        
        return results

