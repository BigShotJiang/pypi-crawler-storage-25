"""
Drive-by Compromise Detection Service

Detects drive-by compromise attacks (T1189) by analyzing:
- Browser artifacts (history, downloads, cache)
- Exploit kit indicators
- Malicious website visits
- Office macro execution
"""

import os
import re
import json
import sqlite3
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from collections import defaultdict

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from utils.logger import logger
from ...proto import (
    FileSystemFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

# Known exploit kit indicators
EXPLOIT_KIT_PATTERNS = [
    r"angler",
    r"nuclear",
    r"magnitude",
    r"rig",
    r"sundown",
    r"neutrino",
    r"fiesta",
    r"redkit",
    r"blackhole",
    r"crimepack",
]

# Suspicious URL patterns
SUSPICIOUS_URL_PATTERNS = [
    r"bit\.ly",
    r"tinyurl\.com",
    r"goo\.gl",
    r"t\.co",
    r"ow\.ly",
    r"is\.gd",
    r"short\.link",
]

# Browser history database paths
BROWSER_PATHS = {
    "chrome": {
        "linux": "~/.config/google-chrome/Default/History",
        "darwin": "~/Library/Application Support/Google/Chrome/Default/History",
        "windows": "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\History",
    },
    "firefox": {
        "linux": "~/.mozilla/firefox/*/places.sqlite",
        "darwin": "~/Library/Application Support/Firefox/Profiles/*/places.sqlite",
        "windows": "%APPDATA%\\Mozilla\\Firefox\\Profiles\\*\\places.sqlite",
    },
    "edge": {
        "linux": "~/.config/microsoft-edge/Default/History",
        "darwin": "~/Library/Application Support/Microsoft Edge/Default/History",
        "windows": "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Default\\History",
    },
}


class DriveByDetectorService:
    """Service for detecting drive-by compromise attacks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize drive-by detector service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin
        """
        self.plugin = plugin_instance
        # Initialize nested services (defined in same file)
        self.browser_artifacts_service = BrowserArtifactsService(plugin_instance)
        self.exploit_kit_detector = ExploitKitDetectorService(plugin_instance)
    
    async def detect_drive_by_compromise(
        self,
        scan_browser_history: bool = True,
        scan_downloads: bool = True,
        scan_cache: bool = True,
        scan_office_macros: bool = True,
    ) -> List[FileSystemFinding]:
        """
        Detect drive-by compromise attacks.
        
        Args:
            scan_browser_history: Scan browser history
            scan_downloads: Scan browser downloads
            scan_cache: Scan browser cache
            scan_office_macros: Scan Office documents for macros
            
        Returns:
            List of findings related to drive-by compromise
        """
        findings = []
        
        try:
            # Browser artifacts analysis
            if scan_browser_history or scan_downloads or scan_cache:
                browser_findings = await self.browser_artifacts_service.analyze_browser_artifacts(
                    scan_history=scan_browser_history,
                    scan_downloads=scan_downloads,
                    scan_cache=scan_cache,
                )
                findings.extend(browser_findings)
            
            # Exploit kit detection
            exploit_kit_findings = await self.exploit_kit_detector.detect_exploit_kits()
            findings.extend(exploit_kit_findings)
            
            # Office macro detection
            if scan_office_macros:
                macro_findings = await self._detect_office_macros()
                findings.extend(macro_findings)
            
            logger.info(f"[drive_by_detector] Detected {len(findings)} drive-by compromise indicators")
            
        except Exception as e:
            logger.error(f"[drive_by_detector] Error detecting drive-by compromise: {e}")
            self.plugin.errors.append(f"Drive-by detection failed: {e}")
        
        return findings
    
    async def _detect_office_macros(self) -> List[FileSystemFinding]:
        """Detect Office documents with malicious macros."""
        findings = []
        
        # Common Office document extensions
        office_extensions = [".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"]
        
        # Suspicious macro patterns
        macro_patterns = [
            r"WScript\.Shell",
            r"Shell\.Execute",
            r"CreateObject\(",
            r"GetObject\(",
            r"Application\.Run",
            r"AutoOpen",
            r"AutoExec",
            r"Document_Open",
            r"Workbook_Open",
            r"PowerShell",
            r"cmd\.exe",
            r"powershell\.exe",
            r"DownloadString",
            r"DownloadFile",
        ]
        
        # Common user directories to scan
        user_dirs = [
            Path.home() / "Downloads",
            Path.home() / "Documents",
            Path.home() / "Desktop",
        ]
        
        for user_dir in user_dirs:
            if not user_dir.exists():
                continue
            
            try:
                for file_path in user_dir.rglob("*"):
                    if file_path.suffix.lower() not in office_extensions:
                        continue
                    
                    # Check file content for macro patterns
                    try:
                        with open(file_path, "rb") as f:
                            content = f.read(1024 * 1024)  # Read first 1MB
                            content_str = content.decode("utf-8", errors="ignore")
                            
                            for pattern in macro_patterns:
                                if re.search(pattern, content_str, re.IGNORECASE):
                                    findings.append(FileSystemFinding(
                                        finding_type="suspicious_macro",
                                        severity=SeverityLevel.HIGH,
                                        confidence=ConfidenceLevel.MEDIUM,
                                        file_path=str(file_path),
                                        threat_category=ThreatCategory.EXPLOIT,
                                        mitre_techniques=["T1189"],
                                        description=f"Office document with suspicious macro pattern detected: {pattern}",
                                        evidence=[f"Pattern match: {pattern}"],
                                        remediation="Do not open this document. Scan with antivirus. Review macro content if necessary.",
                                        detected_at=datetime.utcnow(),
                                    ))
                                    break
                    except Exception as e:
                        logger.debug(f"Error reading file {file_path}: {e}")
                        continue
                        
            except Exception as e:
                logger.warning(f"Error scanning {user_dir}: {e}")
                continue
        
        return findings


class BrowserArtifactsService:
    """Service for analyzing browser artifacts."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def analyze_browser_artifacts(
        self,
        scan_history: bool = True,
        scan_downloads: bool = True,
        scan_cache: bool = True,
    ) -> List[FileSystemFinding]:
        """
        Analyze browser artifacts for drive-by compromise indicators.
        
        Args:
            scan_history: Scan browser history
            scan_downloads: Scan browser downloads
            scan_cache: Scan browser cache
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            if scan_history:
                history_findings = await self._analyze_browser_history()
                findings.extend(history_findings)
            
            if scan_downloads:
                download_findings = await self._analyze_downloads()
                findings.extend(download_findings)
            
            if scan_cache:
                cache_findings = await self._analyze_cache()
                findings.extend(cache_findings)
            
        except Exception as e:
            logger.error(f"[browser_artifacts] Error analyzing browser artifacts: {e}")
        
        return findings
    
    async def _analyze_browser_history(self) -> List[FileSystemFinding]:
        """Analyze browser history for suspicious visits."""
        findings = []
        
        # Get platform
        platform = "linux" if os.name == "posix" else ("darwin" if sys.platform == "darwin" else "windows")
        
        for browser_name, paths in BROWSER_PATHS.items():
            if platform not in paths:
                continue
            
            history_path = Path(paths[platform]).expanduser()
            
            # Handle glob patterns
            if "*" in str(history_path):
                import glob
                history_paths = glob.glob(str(history_path))
            else:
                history_paths = [history_path]
            
            for hist_path in history_paths:
                if not hist_path or not Path(hist_path).exists():
                    continue
                
                try:
                    # Copy database to temp location (browsers lock the DB)
                    import tempfile
                    import shutil
                    
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".db") as tmp:
                        tmp_path = tmp.name
                    
                    shutil.copy2(hist_path, tmp_path)
                    
                    # Query history
                    conn = sqlite3.connect(tmp_path)
                    cursor = conn.cursor()
                    
                    # Get recent visits (last 30 days)
                    thirty_days_ago = (datetime.now() - timedelta(days=30)).timestamp() * 1000000
                    
                    cursor.execute("""
                        SELECT urls.url, urls.visit_count, urls.last_visit_time, urls.title
                        FROM urls
                        WHERE urls.last_visit_time > ?
                        ORDER BY urls.last_visit_time DESC
                        LIMIT 1000
                    """, (thirty_days_ago,))
                    
                    for row in cursor.fetchall():
                        url, visit_count, last_visit, title = row
                        
                        # Check for suspicious patterns
                        suspicious = False
                        evidence = []
                        
                        # Check for suspicious URL patterns
                        for pattern in SUSPICIOUS_URL_PATTERNS:
                            if re.search(pattern, url, re.IGNORECASE):
                                suspicious = True
                                evidence.append(f"Suspicious URL shortener: {pattern}")
                        
                        # Check for exploit kit indicators
                        for ek_pattern in EXPLOIT_KIT_PATTERNS:
                            if re.search(ek_pattern, url, re.IGNORECASE):
                                suspicious = True
                                evidence.append(f"Exploit kit indicator: {ek_pattern}")
                        
                        # Check for high visit count (possible watering hole)
                        if visit_count > 100:
                            suspicious = True
                            evidence.append(f"High visit count: {visit_count}")
                        
                        if suspicious:
                            findings.append(FileSystemFinding(
                                finding_type="suspicious_browser_history",
                                severity=SeverityLevel.MEDIUM,
                                confidence=ConfidenceLevel.MEDIUM,
                                file_path=str(hist_path),
                                threat_category=ThreatCategory.EXPLOIT,
                                mitre_techniques=["T1189"],
                                description=f"Suspicious browser history entry: {url}",
                                evidence=evidence,
                                remediation="Review browser history. Clear cache and cookies. Scan system for malware.",
                                detected_at=datetime.utcnow(),
                            ))
                    
                    conn.close()
                    os.unlink(tmp_path)
                    
                except Exception as e:
                    logger.debug(f"Error analyzing {browser_name} history: {e}")
                    continue
        
        return findings
    
    async def _analyze_downloads(self) -> List[FileSystemFinding]:
        """Analyze browser downloads."""
        findings = []
        
        # Common download locations
        download_dirs = [
            Path.home() / "Downloads",
            Path.home() / "Desktop",
        ]
        
        # Suspicious file extensions
        suspicious_extensions = [".exe", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar"]
        
        for download_dir in download_dirs:
            if not download_dir.exists():
                continue
            
            try:
                # Get files modified in last 7 days
                seven_days_ago = datetime.now() - timedelta(days=7)
                
                for file_path in download_dir.iterdir():
                    if not file_path.is_file():
                        continue
                    
                    # Check modification time
                    mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                    if mtime < seven_days_ago:
                        continue
                    
                    # Check extension
                    if file_path.suffix.lower() in suspicious_extensions:
                        findings.append(FileSystemFinding(
                            finding_type="suspicious_download",
                            severity=SeverityLevel.MEDIUM,
                            confidence=ConfidenceLevel.LOW,
                            file_path=str(file_path),
                            threat_category=ThreatCategory.MALWARE,
                            mitre_techniques=["T1189"],
                            description=f"Recently downloaded suspicious file: {file_path.name}",
                            evidence=[f"Extension: {file_path.suffix}", f"Downloaded: {mtime}"],
                            remediation="Scan file with antivirus. Review file source. Delete if not needed.",
                            detected_at=datetime.utcnow(),
                        ))
                        
            except Exception as e:
                logger.debug(f"Error analyzing downloads in {download_dir}: {e}")
                continue
        
        return findings
    
    async def _analyze_cache(self) -> List[FileSystemFinding]:
        """Analyze browser cache for malicious content."""
        findings = []
        
        # Browser cache locations
        cache_paths = {
            "chrome": {
                "linux": "~/.cache/google-chrome",
                "darwin": "~/Library/Caches/Google/Chrome",
            },
            "firefox": {
                "linux": "~/.cache/mozilla/firefox",
                "darwin": "~/Library/Caches/Firefox",
            },
        }
        
        platform = "linux" if os.name == "posix" else ("darwin" if sys.platform == "darwin" else "windows")
        
        for browser_name, paths in cache_paths.items():
            if platform not in paths:
                continue
            
            cache_path = Path(paths[platform]).expanduser()
            if not cache_path.exists():
                continue
            
            try:
                # Look for JavaScript files in cache
                for js_file in cache_path.rglob("*.js"):
                    try:
                        with open(js_file, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read(10240)  # Read first 10KB
                            
                            # Check for suspicious patterns
                            suspicious_patterns = [
                                r"eval\(",
                                r"unescape\(",
                                r"String\.fromCharCode",
                                r"document\.write",
                                r"document\.createElement",
                                r"XMLHttpRequest",
                                r"ActiveXObject",
                            ]
                            
                            for pattern in suspicious_patterns:
                                if re.search(pattern, content, re.IGNORECASE):
                                    findings.append(FileSystemFinding(
                                        finding_type="suspicious_cache_content",
                                        severity=SeverityLevel.MEDIUM,
                                        confidence=ConfidenceLevel.LOW,
                                        file_path=str(js_file),
                                        threat_category=ThreatCategory.EXPLOIT,
                                        mitre_techniques=["T1189"],
                                        description=f"Suspicious JavaScript found in browser cache: {pattern}",
                                        evidence=[f"Pattern: {pattern}"],
                                        remediation="Clear browser cache. Review browser history for suspicious sites.",
                                        detected_at=datetime.utcnow(),
                                    ))
                                    break
                    except Exception as e:
                        logger.debug(f"Error reading cache file {js_file}: {e}")
                        continue
                        
            except Exception as e:
                logger.debug(f"Error analyzing {browser_name} cache: {e}")
                continue
        
        return findings


class ExploitKitDetectorService:
    """Service for detecting exploit kit indicators."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def detect_exploit_kits(self) -> List[FileSystemFinding]:
        """Detect exploit kit indicators."""
        findings = []
        
        # This would typically analyze network traffic, logs, or browser artifacts
        # For now, we'll focus on log analysis and file system indicators
        
        try:
            # Check for exploit kit artifacts in common locations
            artifact_paths = [
                Path("/tmp"),
                Path.home() / "Downloads",
                Path("/var/tmp"),
            ]
            
            for artifact_path in artifact_paths:
                if not artifact_path.exists():
                    continue
                
                try:
                    for file_path in artifact_path.rglob("*"):
                        if not file_path.is_file():
                            continue
                        
                        file_name = file_path.name.lower()
                        
                        # Check for exploit kit indicators in filename
                        for ek_pattern in EXPLOIT_KIT_PATTERNS:
                            if re.search(ek_pattern, file_name, re.IGNORECASE):
                                findings.append(FileSystemFinding(
                                    finding_type="exploit_kit_artifact",
                                    severity=SeverityLevel.HIGH,
                                    confidence=ConfidenceLevel.MEDIUM,
                                    file_path=str(file_path),
                                    threat_category=ThreatCategory.EXPLOIT,
                                    mitre_techniques=["T1189"],
                                    description=f"Possible exploit kit artifact detected: {file_name}",
                                    evidence=[f"Pattern match: {ek_pattern}"],
                                    remediation="Isolate file. Do not execute. Scan with antivirus. Review system for compromise.",
                                    detected_at=datetime.utcnow(),
                                ))
                                break
                                
                except Exception as e:
                    logger.debug(f"Error scanning {artifact_path}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"[exploit_kit_detector] Error detecting exploit kits: {e}")
        
        return findings
