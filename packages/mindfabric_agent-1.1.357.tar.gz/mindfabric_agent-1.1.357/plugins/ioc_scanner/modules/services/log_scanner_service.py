"""Log file IOC scanning service."""

import os
import re
import glob
import socket
import ipaddress
import time
import psutil
from collections import defaultdict
from datetime import datetime
from typing import List, Dict, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    LogFinding,
    LogEntry,
    ScanOptions,
    SeverityLevel,
    ConfidenceLevel,
)
from ..utils import parse_log_line
from .ioc_artifact_sqlite_store import LogHit
from utils.logger import logger


def _get_real_server_ip() -> Optional[str]:
    """
    Get the real (non-loopback) IP address of the server.
    Prefers public IPs, then private IPs, but never returns loopback.
    """
    try:
        # Strategy 1: Get IP from network interfaces (prefer non-loopback, non-link-local)
        candidate_ips = []
        for _if, addrs in (psutil.net_if_addrs() or {}).items():
            for addr in addrs or []:
                if getattr(addr, "family", None) != socket.AF_INET:
                    continue
                ip_str = getattr(addr, "address", "") or ""
                if not ip_str:
                    continue
                try:
                    ip_obj = ipaddress.ip_address(ip_str)
                    if ip_obj.is_loopback:
                        continue  # Skip loopback
                    if ip_obj.is_link_local:
                        continue  # Skip link-local (169.254.x.x)
                    if ip_obj.is_unspecified:
                        continue
                    # Prioritize: public IPs (priority 2) > private IPs (priority 1)
                    priority = 2 if not ip_obj.is_private else 1
                    candidate_ips.append((ip_str, priority))
                except (ValueError, AttributeError):
                    continue
        
        if candidate_ips:
            # Sort by priority (public first) and return the first one
            candidate_ips.sort(key=lambda x: x[1], reverse=True)
            return candidate_ips[0][0]
        
        # Strategy 2: Fallback to socket method (but filter loopback)
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_str = s.getsockname()[0]
            s.close()
            if ip_str:
                ip_obj = ipaddress.ip_address(ip_str)
                if not ip_obj.is_loopback:
                    return ip_str
        except Exception:
            pass
        
        # Strategy 3: Last resort - try hostname but filter loopback
        try:
            hostname = socket.gethostname()
            ip_str = socket.gethostbyname(hostname)
            if ip_str:
                ip_obj = ipaddress.ip_address(ip_str)
                if not ip_obj.is_loopback:
                    return ip_str
        except Exception:
            pass
        
        return None
    except Exception as e:
        logger.warning(f"[log_scanner] Failed to get real server IP: {e}")
        return None


class LogScannerService:
    """Service for log file IOC scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize log scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def scan_logs(
        self,
        ioc_strings: List[str] = None,
        log_paths: List[str] = None,
        use_ai: bool = False,
        options: ScanOptions = None,
    ) -> List[LogFinding]:
        """
        Log file IOC scanning.
        
        Args:
            ioc_strings: Strings to search in logs
            log_paths: Log files to scan
            use_ai: Enable AI analysis
            options: Scan configuration
        
        Returns:
            List of LogFinding
        """
        if options is None:
            options = ScanOptions()
        
        if log_paths is None:
            log_paths = [
                "/var/log/auth.log",
                "/var/log/syslog",
                "/var/log/messages",
                "/var/log/secure",
                "/var/log/apache2/access.log",
                "/var/log/apache2/error.log",
                "/var/log/nginx/access.log",
                "/var/log/nginx/error.log",
            ]
        
        results: List[LogFinding] = []
        
        # Attack patterns to detect in logs
        # Support both classic syslog and systemd/journald formats
        attack_patterns = [
            # Classic syslog format
            {"pattern": r"Failed password for .* from (\d+\.\d+\.\d+\.\d+)", "name": "SSH brute force", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"Invalid user .* from (\d+\.\d+\.\d+\.\d+)", "name": "Invalid SSH user", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"Accepted publickey for .* from (\d+\.\d+\.\d+\.\d+)", "name": "SSH key login", "ttp": "T1078.004", "severity": SeverityLevel.INFO},
            # systemd/journald format (with rhost=IP)
            {"pattern": r"authentication failure.*rhost=(\d+\.\d+\.\d+\.\d+)", "name": "SSH brute force", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"pam_unix\(sshd:auth\):.*authentication failure.*rhost=(\d+\.\d+\.\d+\.\d+)", "name": "SSH brute force", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"user unknown.*rhost=(\d+\.\d+\.\d+\.\d+)", "name": "Invalid SSH user", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"check pass.*user unknown", "name": "Invalid SSH user", "ttp": "T1110", "severity": SeverityLevel.MEDIUM},
            # Other patterns
            {"pattern": r"POSSIBLE BREAK-IN ATTEMPT", "name": "Break-in attempt", "ttp": "T1133", "severity": SeverityLevel.HIGH},
            {"pattern": r"sudo:.*COMMAND=", "name": "Sudo command execution", "ttp": "T1548.003", "severity": SeverityLevel.LOW},
            {"pattern": r"sudo:.*authentication failure", "name": "Sudo auth failure", "ttp": "T1548.003", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"su\[.*\]:\s+FAILED", "name": "Su failure", "ttp": "T1548.003", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"session opened for user root", "name": "Root session", "ttp": "T1078", "severity": SeverityLevel.LOW},
            {"pattern": r"reverse mapping checking .* POSSIBLE BREAK", "name": "DNS mismatch", "ttp": "T1557", "severity": SeverityLevel.MEDIUM},
            {"pattern": r"segfault at", "name": "Segmentation fault", "ttp": "T1068", "severity": SeverityLevel.MEDIUM},
        ]
        
        # Add custom IOC strings
        if ioc_strings:
            for ioc in ioc_strings:
                attack_patterns.append({
                    "pattern": re.escape(ioc),
                    "name": f"IOC: {ioc[:30]}",
                    "ttp": "T1027",
                    "severity": SeverityLevel.HIGH
                })

        # Compile patterns once (big CPU win on large logs).
        compiled_patterns = []
        for p in attack_patterns:
            try:
                compiled_patterns.append((re.compile(p["pattern"], re.IGNORECASE), p))
            except Exception:
                continue
        
        try:
            # Expand directories to actual log files
            expanded_log_paths = []
            for log_path in log_paths:
                if not os.path.exists(log_path):
                    logger.debug(f"[ioc_scanner] Log path does not exist: {log_path}")
                    continue
                
                if os.path.isdir(log_path):
                    # If it's a directory, find log files in it
                    logger.info(f"[ioc_scanner] Expanding log directory: {log_path}")
                    # Common log file patterns
                    patterns = [
                        os.path.join(log_path, "*.log"),
                        os.path.join(log_path, "auth.log"),
                        os.path.join(log_path, "syslog"),
                        os.path.join(log_path, "messages"),
                        os.path.join(log_path, "secure"),
                    ]
                    for pattern in patterns:
                        for file_path in glob.glob(pattern):
                            if os.path.isfile(file_path):
                                expanded_log_paths.append(file_path)
                                logger.debug(f"[ioc_scanner] Found log file: {file_path}")
                elif os.path.isfile(log_path):
                    expanded_log_paths.append(log_path)
                    logger.debug(f"[ioc_scanner] Using log file: {log_path}")
            
            # Use expanded paths or fallback to default if empty
            if not expanded_log_paths:
                logger.info(f"[ioc_scanner] No log files found, using default paths")
                expanded_log_paths = [
                    "/var/log/auth.log",
                    "/var/log/syslog",
                    "/var/log/messages",
                    "/var/log/secure",
                ]
            
            logger.info(f"[ioc_scanner] Scanning {len(expanded_log_paths)} log file(s): {expanded_log_paths[:5]}...")
            
            files_processed = 0
            files_skipped = 0
            for log_path in expanded_log_paths:
                if not os.path.exists(log_path) or not os.path.isfile(log_path):
                    logger.debug(f"[ioc_scanner] Skipping log path (not found or not file): {log_path}")
                    files_skipped += 1
                    continue
                
                try:
                    # Check file age
                    mtime = datetime.fromtimestamp(os.path.getmtime(log_path))
                    age_days = (datetime.now() - mtime).days
                    if age_days > options.scope.log_max_age_days:
                        logger.debug(f"[ioc_scanner] Skipping old log file: {log_path} (age: {age_days} days, max: {options.scope.log_max_age_days} days)")
                        files_skipped += 1
                        continue
                    
                    # Important:
                    # - If artifact_store (SQLite) is enabled, we do NOT keep any matched log entries in RAM.
                    #   Detailed hits are streamed to SQLite and bounded by the artifact DB size cap.
                    # - If artifact_store is NOT enabled, we keep a small sample to avoid OOM on small hosts.
                    store = getattr(self.plugin, "artifact_store", None)
                    max_sample_entries: int = 0 if store is not None else 10

                    # Performance controls for log scanning.
                    scope = getattr(options, "scope", None)
                    checkpoint_enabled = bool(getattr(scope, "log_checkpoint_enabled", True))
                    try:
                        initial_tail_bytes = int(getattr(scope, "log_initial_tail_bytes", 5 * 1024 * 1024))
                    except Exception:
                        initial_tail_bytes = 5 * 1024 * 1024
                    try:
                        max_lines_per_file = int(getattr(scope, "log_max_lines_per_file", 200_000))
                    except Exception:
                        max_lines_per_file = 200_000
                    try:
                        max_seconds_per_file = float(getattr(scope, "log_max_seconds_per_file", 15.0))
                    except Exception:
                        max_seconds_per_file = 15.0
                    try:
                        max_samples_total = int(getattr(scope, "log_max_samples_total_per_file", 5_000))
                    except Exception:
                        max_samples_total = 5_000
                    try:
                        max_samples_per_vector = int(getattr(scope, "log_max_samples_per_vector_per_file", 1_000))
                    except Exception:
                        max_samples_per_vector = 1_000

                    logger.info(f"[ioc_scanner] Opening log file: {log_path}")
                    files_processed += 1
                    line_count = 0
                    matched_counts: Dict[str, int] = defaultdict(int)
                    matched_samples: Dict[str, List[LogEntry]] = defaultdict(list)
                    matched_source_ips: Dict[str, set] = defaultdict(set)  # Collect unique source IPs per pattern
                    matched_usernames: Dict[str, set] = defaultdict(set)  # Collect unique usernames per pattern
                    matched_oom_processes: Dict[str, set] = defaultdict(set)  # Collect OOM killer process names
                    hits_since_commit = 0
                    # Limit sample rows written to vector_sample (even if summary counters grow).
                    sample_total_written = 0
                    sample_written_per_vector: Dict[str, int] = defaultdict(int)
                    
                    # Get destination IP (server IP where agent is running)
                    # Use real IP, never loopback (127.0.0.1, 127.0.1.1, etc.)
                    destination_ip = _get_real_server_ip()
                    if not destination_ip:
                        logger.warning("[log_scanner] Could not determine real server IP, destination_ip will be None")

                    # Determine file checkpoint and start offset (to avoid scanning huge historical logs on first run).
                    start_offset = 0
                    inode = None
                    st_size = None
                    st_mtime = None
                    checkpoint = None
                    try:
                        st = os.stat(log_path)
                        inode = getattr(st, "st_ino", None)
                        st_size = int(getattr(st, "st_size", 0))
                        st_mtime = float(getattr(st, "st_mtime", 0.0))
                    except Exception:
                        st_size = None

                    if checkpoint_enabled:
                        # Prefer SQLite meta checkpoints when artifact_store is enabled and persistent.
                        if store is not None and hasattr(store, "get_checkpoint"):
                            try:
                                checkpoint = store.get_checkpoint(log_path)  # type: ignore[attr-defined]
                            except Exception:
                                checkpoint = None

                    # Resume from previous offset if possible, otherwise tail the file on first sight.
                    if checkpoint and isinstance(checkpoint, dict):
                        try:
                            cp_inode = checkpoint.get("inode")
                            cp_offset = checkpoint.get("offset")
                            if cp_inode is not None and inode is not None and int(cp_inode) == int(inode) and isinstance(cp_offset, int):
                                if st_size is not None and 0 <= int(cp_offset) <= int(st_size):
                                    start_offset = int(cp_offset)
                        except Exception:
                            start_offset = 0

                    if start_offset == 0 and st_size is not None and initial_tail_bytes > 0 and st_size > initial_tail_bytes:
                        start_offset = max(0, int(st_size) - int(initial_tail_bytes))

                    file_started_at = time.monotonic()
                    last_offset = start_offset
                    current_line_num = 0
                    with open(log_path, "rb") as f:
                        try:
                            f.seek(start_offset)
                            if start_offset > 0:
                                # Avoid partial first line when resuming mid-file.
                                f.readline()
                        except Exception:
                            pass

                        while True:
                            if max_seconds_per_file > 0 and (time.monotonic() - file_started_at) > max_seconds_per_file:
                                logger.warning(f"[ioc_scanner] Log scan time budget exceeded for {log_path}, stopping early (checkpoint enabled={checkpoint_enabled})")
                                break
                            if max_lines_per_file > 0 and line_count >= max_lines_per_file:
                                logger.warning(f"[ioc_scanner] Log scan line budget exceeded for {log_path}, stopping early (lines={line_count})")
                                break

                            b = f.readline()
                            if not b:
                                break
                            last_offset = f.tell()
                            line_count += 1
                            current_line_num += 1
                            if line_count % 10000 == 0:
                                total_matches = sum(matched_counts.values())
                                logger.debug(f"[ioc_scanner] Processed {line_count} lines from {log_path}, found {total_matches} matches so far")

                            try:
                                line = b.decode("utf-8", errors="ignore")
                            except Exception:
                                continue

                            entry: Optional[LogEntry] = None

                            for cre, pattern_info in compiled_patterns:
                                try:
                                    match = cre.search(line)
                                except Exception:
                                    continue
                                if not match:
                                    continue

                                pattern_name = pattern_info["name"]
                                matched_counts[pattern_name] += 1
                                if matched_counts[pattern_name] <= 3:
                                    logger.debug(f"[ioc_scanner] Match found: pattern='{pattern_name}', line={current_line_num}, preview={line[:100]}")

                                # Collect source IP cheaply (many regexes capture it as group(1)).
                                source_ip = None
                                try:
                                    if match.lastindex and match.lastindex >= 1:
                                        source_ip = match.group(1)
                                except Exception:
                                    source_ip = None

                                # Parse line only when needed (sample and/or sqlite store).
                                if (store is not None or max_sample_entries > 0) and entry is None:
                                    entry = parse_log_line(line, log_path)
                                    if entry:
                                        entry.line_number = current_line_num

                                # Prefer parsed fields, fall back to regex group(1) for IP.
                                if entry and getattr(entry, "source_ip", None):
                                    source_ip = getattr(entry, "source_ip", None)
                                if source_ip:
                                    matched_source_ips[pattern_name].add(str(source_ip))

                                # Collect usernames for SSH-ish patterns.
                                if entry and getattr(entry, "user", None) and ("ssh" in pattern_name.lower() or "brute" in pattern_name.lower() or "invalid" in pattern_name.lower()):
                                    matched_usernames[pattern_name].add(str(entry.user))

                                # For OOM killer, extract process name from log line
                                if "oom killer" in pattern_name.lower():
                                    oom_process_match = re.search(r"Killed process (\\d+) \\((.+?)\\)", line, re.IGNORECASE)
                                    if oom_process_match:
                                        matched_oom_processes[pattern_name].add(oom_process_match.group(2))

                                # Keep a small sample only when SQLite artifacts are not enabled
                                if max_sample_entries > 0 and entry and len(matched_samples[pattern_name]) < max_sample_entries:
                                    matched_samples[pattern_name].append(entry)

                                # Persist forensic hit on disk (sqlite). Always update counters, but cap sample rows.
                                if store is not None:
                                    try:
                                        msg = getattr(entry, "raw_line", None) if entry else None
                                        if not msg:
                                            msg = line

                                        # Decide whether we are still allowed to write sample rows for this run.
                                        allow_sample = True
                                        if max_samples_total > 0 and sample_total_written >= max_samples_total:
                                            allow_sample = False
                                        if max_samples_per_vector > 0 and sample_written_per_vector[pattern_name] >= max_samples_per_vector:
                                            allow_sample = False

                                        hit = LogHit(
                                            vector=pattern_name,
                                            log_source=log_path,
                                            timestamp=getattr(entry, "timestamp", None) if entry else None,
                                            source_ip=source_ip,
                                            username=(getattr(entry, "user", None) or getattr(entry, "username", None)) if entry else None,
                                            line_number=current_line_num,
                                            message=msg,
                                        )
                                        store.record_log_hit(hit, store_sample=allow_sample)
                                        hits_since_commit += 1
                                        if allow_sample:
                                            sample_total_written += 1
                                            sample_written_per_vector[pattern_name] += 1
                                        if hits_since_commit >= 200:
                                            store.commit()
                                            hits_since_commit = 0
                                    except Exception:
                                        pass  # Don't fail if store write fails

                        # Save checkpoint for next run (best-effort).
                        if checkpoint_enabled:
                            try:
                                reason = "eof"
                                if max_seconds_per_file > 0 and (time.monotonic() - file_started_at) > max_seconds_per_file:
                                    reason = "budget_time"
                                elif max_lines_per_file > 0 and line_count >= max_lines_per_file:
                                    reason = "budget_lines"
                                # Primary: SQLite meta checkpoint (persistent when using single artifact DB).
                                if store is not None and hasattr(store, "set_checkpoint"):
                                    try:
                                        store.set_checkpoint(  # type: ignore[attr-defined]
                                            log_source=log_path,
                                            inode=inode,
                                            offset=int(last_offset),
                                            file_size=st_size,
                                            mtime=st_mtime,
                                            reason=reason,
                                            commit=False,
                                        )
                                    except Exception:
                                        pass
                            except Exception:
                                pass

                        # Final commit for this log file
                        try:
                            if store is not None:
                                store.commit()
                        except Exception:
                            pass

                        # Log summary for this file
                        total_matches = sum(matched_counts.values())
                        if total_matches > 0:
                            logger.info(f"[ioc_scanner] Log scan {log_path}: processed {line_count} lines, found {total_matches} matches across {len(matched_counts)} patterns")
                        
                        # Create findings
                        for pattern_name, findings_count in matched_counts.items():
                            pattern_info = next(
                                (p for p in attack_patterns if p["name"] == pattern_name),
                                {"ttp": "T1027", "severity": SeverityLevel.MEDIUM}
                            )
                            
                            severity = pattern_info["severity"]
                            
                            # Avoid noisy severities for internet-exposed hosts.
                            # Escalate only for extreme volume or explicit break-in signals.
                            pname = (pattern_name or "").lower()
                            if "break-in attempt" in pname:
                                severity = SeverityLevel.HIGH
                            elif "ssh brute force" in pname:
                                if findings_count > 2000:
                                    severity = SeverityLevel.CRITICAL
                                elif findings_count > 200:
                                    severity = SeverityLevel.HIGH
                            elif "invalid ssh user" in pname:
                                if findings_count > 5000:
                                    severity = SeverityLevel.CRITICAL
                                elif findings_count > 500:
                                    severity = SeverityLevel.HIGH
                            elif findings_count > 5000:
                                severity = SeverityLevel.CRITICAL
                            
                            # Include unique source IPs, usernames, and other metadata in evidence
                            # This allows backend to extract source IPs for threat graph edges
                            evidence_list = [f"Found {findings_count} matches"]
                            source_ips = matched_source_ips.get(pattern_name, set())
                            if source_ips:
                                evidence_list.append(f"Source IPs: {', '.join(sorted(source_ips))}")
                            
                            # Add destination IP (server IP where attack is targeting)
                            if destination_ip:
                                evidence_list.append(f"Destination IP: {destination_ip}")
                            
                            # Add usernames for SSH brute force
                            usernames = matched_usernames.get(pattern_name, set())
                            if usernames:
                                evidence_list.append(f"Targeted Usernames: {', '.join(sorted(usernames))}")
                            
                            # Add OOM killer process information
                            oom_processes = matched_oom_processes.get(pattern_name, set())
                            if oom_processes:
                                evidence_list.append(f"Killed Processes: {', '.join(sorted(oom_processes))}")
                            
                            # Even when SQLite store is enabled, include a small sample of log_entries
                            # with source_ip to help backend extract IPs for threat graph edges
                            # Limit to 10 entries to avoid large payloads
                            sample_entries = matched_samples.get(pattern_name, [])
                            # If SQLite store is enabled and we have source IPs, create minimal sample entries
                            if store is not None and source_ips and not sample_entries:
                                # Create minimal sample entries with just source_ip for backend processing
                                from ...proto import LogEntry
                                sample_entries = []
                                for src_ip in sorted(source_ips)[:10]:  # Limit to 10 IPs
                                    sample_entries.append(LogEntry(
                                        source=log_path,
                                        message=f"Sample entry for {pattern_name}",
                                        raw_line=f"Sample: {pattern_name} from {src_ip}",
                                        source_ip=src_ip
                                    ))
                            
                            # Build enhanced description with context
                            description_parts = [f"{pattern_name}: {findings_count} occurrences in {log_path}"]
                            if source_ips:
                                description_parts.append(f"from {len(source_ips)} unique source IP(s)")
                            if usernames and ("ssh" in pattern_name.lower() or "brute" in pattern_name.lower()):
                                description_parts.append(f"targeting {len(usernames)} username(s)")
                            if oom_processes:
                                description_parts.append(f"affecting {len(oom_processes)} process(es)")
                            
                            enhanced_description = ". ".join(description_parts)
                            
                            results.append(LogFinding(
                                finding_type="pattern_match",
                                severity=severity,
                                confidence=ConfidenceLevel.HIGH,
                                log_source=log_path,
                                # Include sample entries even when SQLite store is enabled
                                # to help backend extract source IPs for threat graph edges
                                log_entries=sample_entries,
                                matched_pattern=pattern_name,
                                description=enhanced_description,
                                evidence=evidence_list,
                                mitre_techniques=[pattern_info["ttp"]]
                            ))
                
                except PermissionError as e:
                    logger.warning(f"[ioc_scanner] Permission denied for log file: {log_path}: {e}")
                    files_skipped += 1
                    continue
                except Exception as e:
                    logger.error(f"[ioc_scanner] Error processing log file {log_path}: {e}", exc_info=True)
                    files_skipped += 1
                    continue
            
            # Log summary
            logger.info(f"[ioc_scanner] Log scan summary: {files_processed} files processed, {files_skipped} files skipped, {len(results)} findings created")
        
        except Exception as e:
            logger.error(f"[ioc_scanner] Log scan error: {e}", exc_info=True)
            # Send alert via plugin's alert handler
            if hasattr(self.plugin, '_send_alert'):
                await self.plugin._send_alert("ioc_log_error", str(e), SeverityLevel.HIGH)
        
        logger.info(f"[ioc_scanner] Log scan completed: found {len(results)} finding(s)")
        return results

