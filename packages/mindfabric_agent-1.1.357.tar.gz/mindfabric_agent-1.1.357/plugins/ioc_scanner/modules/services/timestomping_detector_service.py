"""
Timestomping Detector Service

Detects timestomping (T1070.006) - modification of file timestamps to hide activity.
"""

import os
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any
from collections import defaultdict

from ...proto import (
    FileSystemFinding,
    SeverityLevel,
    ConfidenceLevel,
    ThreatCategory,
)

logger = logging.getLogger(__name__)


class TimestompingDetectorService:
    """Service for detecting timestomping attacks."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[FileSystemFinding] = []
    
    async def detect_timestomping(
        self,
        file_paths: List[str],
        system_install_date: Optional[datetime] = None,
    ) -> List[FileSystemFinding]:
        """
        Detect timestomping in files.
        
        Args:
            file_paths: List of file paths to check
            system_install_date: System installation date (for comparison)
            
        Returns:
            List of timestomping findings
        """
        findings = []
        
        if not system_install_date:
            # Try to get system install date
            system_install_date = await self._get_system_install_date()
        
        # Group files by timestamp to detect mass timestomping
        timestamp_groups = defaultdict(list)
        
        for file_path in file_paths:
            try:
                file_stat = os.stat(file_path)
                
                mtime = datetime.fromtimestamp(file_stat.st_mtime, tz=timezone.utc)
                ctime = datetime.fromtimestamp(file_stat.st_ctime, tz=timezone.utc)
                atime = datetime.fromtimestamp(file_stat.st_atime, tz=timezone.utc)
                
                # Check 1: Future timestamps
                now = datetime.now(timezone.utc)
                if mtime > now or ctime > now or atime > now:
                    findings.append(self._create_finding(
                        file_path,
                        "future_timestamp",
                        f"File has timestamp in the future: mtime={mtime}, ctime={ctime}",
                        SeverityLevel.HIGH,
                        ConfidenceLevel.HIGH,
                    ))
                
                # Check 2: Timestamps before system installation
                if system_install_date and mtime < system_install_date:
                    findings.append(self._create_finding(
                        file_path,
                        "pre_install_timestamp",
                        f"File timestamp ({mtime}) predates system installation ({system_install_date})",
                        SeverityLevel.MEDIUM,
                        ConfidenceLevel.MEDIUM,
                    ))
                
                # Check 3: Timestamp mismatch (mtime != ctime when file is modified)
                # If mtime is older than ctime by more than a few seconds, it's suspicious
                if abs((mtime - ctime).total_seconds()) > 60:
                    # This could indicate timestomping
                    if mtime < ctime:
                        findings.append(self._create_finding(
                            file_path,
                            "timestamp_mismatch",
                            f"Modified time ({mtime}) is significantly different from creation time ({ctime})",
                            SeverityLevel.MEDIUM,
                            ConfidenceLevel.MEDIUM,
                        ))
                
                # Check 4: Very old timestamps (before 2000)
                old_threshold = datetime(2000, 1, 1, tzinfo=timezone.utc)
                if mtime < old_threshold:
                    findings.append(self._create_finding(
                        file_path,
                        "very_old_timestamp",
                        f"File has very old timestamp: {mtime}",
                        SeverityLevel.LOW,
                        ConfidenceLevel.LOW,
                    ))
                
                # Group by exact timestamp for mass timestomping detection
                timestamp_key = (mtime.isoformat(), ctime.isoformat())
                timestamp_groups[timestamp_key].append(file_path)
                
            except (OSError, ValueError) as e:
                logger.debug(f"Error checking {file_path}: {e}")
                continue
        
        # Check 5: Mass timestomping (many files with same timestamps)
        for timestamp_key, files in timestamp_groups.items():
            if len(files) > 10:  # Threshold for mass timestomping
                findings.append(self._create_finding(
                    files[0],  # Use first file as example
                    "mass_timestomping",
                    f"Mass timestomping detected: {len(files)} files share identical timestamps",
                    SeverityLevel.HIGH,
                    ConfidenceLevel.HIGH,
                    additional_files=files[1:10],  # Include up to 10 files
                ))
        
        self.findings.extend(findings)
        return findings
    
    async def _get_system_install_date(self) -> Optional[datetime]:
        """Get system installation date."""
        try:
            # Linux: /etc/lsb-release or /proc/stat
            if os.path.exists("/proc/stat"):
                stat = os.stat("/proc/stat")
                return datetime.fromtimestamp(stat.st_birthtime if hasattr(stat, 'st_birthtime') else stat.st_ctime, tz=timezone.utc)
            
            # Windows: Registry or system files
            # For now, return None and let caller handle it
            return None
        except Exception:
            return None
    
    def _create_finding(
        self,
        file_path: str,
        finding_type: str,
        description: str,
        severity: SeverityLevel,
        confidence: ConfidenceLevel,
        additional_files: Optional[List[str]] = None,
    ) -> FileSystemFinding:
        """Create a timestomping finding."""
        
        evidence = {
            "type": finding_type,
            "file": file_path,
            "description": description,
        }
        
        if additional_files:
            evidence["additional_files"] = additional_files[:10]  # Limit to 10
        
        return FileSystemFinding(
            finding_type="timestomping",
            severity=severity,
            confidence=confidence,
            file_path=file_path,
            threat_category=ThreatCategory.DEFENSE_EVASION,
            description=description,
            evidence=[description],
            mitre_techniques=["T1070.006"],
            remediation="Investigate file modification history. Check if timestamps were manually modified.",
        )
