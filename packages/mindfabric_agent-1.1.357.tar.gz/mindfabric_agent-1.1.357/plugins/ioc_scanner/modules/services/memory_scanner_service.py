"""Memory scanning service."""

import os
from typing import List, Dict, Any

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    MemoryFinding,
    MemoryRegion,
    ScanOptions,
    SeverityLevel,
    ConfidenceLevel,
)


class MemoryScannerService:
    """Service for memory IOC scanning."""
    
    def __init__(self, plugin_instance):
        """
        Initialize memory scanner service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def scan_memory(
        self,
        pids: List[int] = None,
        yara_rules: List[str] = None,
        patterns: List[str] = None,
        options: ScanOptions = None,
    ) -> List[MemoryFinding]:
        """
        Memory scanning for IOCs.
        
        Args:
            pids: Process IDs to scan (None = all accessible)
            yara_rules: YARA rule paths
            patterns: Hex patterns to search
            options: Scan configuration
        
        Returns:
            List of MemoryFinding
        """
        if not HAS_PSUTIL:
            return []
        
        if options is None:
            options = ScanOptions()
        
        results: List[MemoryFinding] = []
        
        # Suspicious patterns (shellcode signatures, etc.)
        shellcode_patterns = [
            (b"\x31\xc0\x50\x68", "Linux shellcode prologue"),
            (b"\x31\xc9\xf7\xe1", "x86 shellcode"),
            (b"\x48\x31\xc0", "x64 shellcode prologue"),
            (b"\xfc\xe8\x82\x00\x00\x00", "Metasploit shellcode"),
            (b"\x55\x89\xe5\x83\xec", "Standard function prologue"),
            (b"\x6a\x0b\x58\x99\x52", "execve shellcode"),
        ]
        
        # Suspicious strings
        suspicious_strings = [
            b"/bin/sh",
            b"/bin/bash",
            b"nc -e",
            b"bash -i",
            b"/dev/tcp/",
            b"python -c",
            b"perl -e",
            b"rm -rf",
            b"wget http",
            b"curl http",
            b"base64 -d",
            b"chmod 777",
            b"id_rsa",
            b"shadow",
            b"passwd",
        ]
        
        try:
            target_pids = pids or []
            
            # If no specific PIDs, get all accessible
            if not target_pids:
                for proc in psutil.process_iter(['pid']):
                    target_pids.append(proc.info['pid'])
            
            for pid in target_pids:
                try:
                    proc = psutil.Process(pid)
                    proc_name = proc.name()
                    
                    # Read memory maps
                    try:
                        maps_file = f"/proc/{pid}/maps"
                        mem_file = f"/proc/{pid}/mem"
                        
                        if not os.path.exists(maps_file):
                            continue
                        
                        with open(maps_file, 'r') as f:
                            maps = f.readlines()
                        
                        for map_line in maps:
                            parts = map_line.split()
                            if len(parts) < 5:
                                continue
                            
                            addr_range = parts[0]
                            perms = parts[1]
                            
                            # Focus on executable anonymous regions (potential injection)
                            if 'x' in perms and len(parts) == 5:
                                start, end = addr_range.split('-')
                                start = int(start, 16)
                                end = int(end, 16)
                                size = end - start
                                
                                # Limit read size
                                if size > 10 * 1024 * 1024:  # 10MB limit
                                    continue
                                
                                try:
                                    with open(mem_file, 'rb') as mem:
                                        mem.seek(start)
                                        data = mem.read(min(size, 1024 * 1024))  # 1MB max
                                    
                                    # Check for shellcode patterns
                                    for pattern, name in shellcode_patterns:
                                        offset = data.find(pattern)
                                        if offset != -1:
                                            results.append(MemoryFinding(
                                                finding_type="shellcode",
                                                severity=SeverityLevel.CRITICAL,
                                                confidence=ConfidenceLevel.HIGH,
                                                pid=pid,
                                                process_name=proc_name,
                                                memory_region=MemoryRegion(
                                                    address_start=hex(start),
                                                    address_end=hex(end),
                                                    size=size,
                                                    permissions=perms,
                                                    is_executable='x' in perms,
                                                    is_writable='w' in perms,
                                                    is_anonymous=len(parts) == 5
                                                ),
                                                offset=start + offset,
                                                matched_content=data[offset:offset+32].hex(),
                                                description=f"Shellcode pattern detected: {name}",
                                                evidence=[f"Pattern: {pattern.hex()}", f"Offset: {hex(start + offset)}"],
                                                mitre_techniques=["T1055"]
                                            ))
                                    
                                    # Check for suspicious strings
                                    for sus_str in suspicious_strings:
                                        offset = data.find(sus_str)
                                        if offset != -1:
                                            results.append(MemoryFinding(
                                                finding_type="suspicious_string",
                                                severity=SeverityLevel.MEDIUM,
                                                confidence=ConfidenceLevel.MEDIUM,
                                                pid=pid,
                                                process_name=proc_name,
                                                memory_region=MemoryRegion(
                                                    address_start=hex(start),
                                                    address_end=hex(end),
                                                    size=size,
                                                    permissions=perms
                                                ),
                                                matched_strings=[sus_str.decode('utf-8', errors='ignore')],
                                                description=f"Suspicious string in memory: {sus_str.decode('utf-8', errors='ignore')}",
                                                mitre_techniques=["T1059"]
                                            ))
                                
                                except (PermissionError, OSError):
                                    continue
                    
                    except (PermissionError, FileNotFoundError):
                        continue
                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        
        except Exception as e:
            await self.plugin._send_alert("memory_scan_error", str(e), SeverityLevel.HIGH)
        
        return results

