"""Legacy compatibility service for backward compatibility wrappers."""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import LegacyIoCMatch, LegacyProcessFinding, LegacyNetworkFinding


class LegacyCompatibilityService:
    """Service for legacy API compatibility wrappers."""
    
    def __init__(self, plugin_instance):
        """
        Initialize legacy compatibility service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to plugin methods
        """
        self.plugin = plugin_instance
    
    async def hook_ioc_file_system_legacy(self, ioc_list=None, paths=None, **kwargs):
        """Legacy compatibility wrapper for file system scanning."""
        results = await self.plugin.hook_ioc_file_system(ioc_list=ioc_list, paths=paths)
        return [LegacyIoCMatch(
            target=r.get("file_path", ""),
            ioc_type=r.get("finding_type", "file"),
            indicator=r.get("description", ""),
            confidence=r.get("confidence", 0.5)
        ).model_dump() for r in results]
    
    async def hook_ioc_processes_legacy(self, ioc=None, **kwargs):
        """Legacy compatibility wrapper for process scanning."""
        results = await self.plugin.hook_ioc_processes(ioc=ioc)
        return [LegacyProcessFinding(
            pid=r.get("process", {}).get("pid", 0),
            name=r.get("process", {}).get("name", ""),
            cmdline=r.get("process", {}).get("cmdline"),
            suspicious=r.get("severity") in ["critical", "high"],
            reason=r.get("reason")
        ).model_dump() for r in results]
    
    async def hook_ioc_network_legacy(self, ioc_domains=None, ioc_ips=None, **kwargs):
        """Legacy compatibility wrapper for network scanning."""
        results = await self.plugin.hook_ioc_network(ioc_ips=ioc_ips, ioc_domains=ioc_domains)
        return [LegacyNetworkFinding(
            ip=r.get("remote_ip", ""),
            port=r.get("remote_port", 0),
            protocol=r.get("connection", {}).get("protocol", "tcp"),
            bad=r.get("severity") in ["critical", "high"],
            reason=r.get("reason")
        ).model_dump() for r in results]

