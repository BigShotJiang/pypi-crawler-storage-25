"""Hook router service for consolidating all hook method delegations."""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import List, Dict, Any
from ...proto import ScanOptions, IoCScanResult


class HookRouterService:
    """Service for routing all hook method calls to appropriate services."""
    
    def __init__(self, plugin_instance):
        """
        Initialize hook router service.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to all services
        """
        self.plugin = plugin_instance
    
    async def route_file_system_scan(
        self,
        ioc_list: List[str] = None,
        paths: List[str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route file system scan to FileScannerService."""
        results = await self.plugin.file_scanner.scan_files(
            ioc_list=ioc_list,
            paths=paths,
            options=options
        )
        self.plugin.findings["file"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    async def route_process_scan(
        self,
        ioc: Dict[str, Any] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route process scan to ProcessScannerService."""
        results = await self.plugin.process_scanner.scan_processes(
            ioc=ioc,
            options=options
        )
        self.plugin.findings["process"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    async def route_network_scan(
        self,
        ioc_ips: List[str] = None,
        ioc_domains: List[str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route network scan to NetworkScannerService."""
        results = await self.plugin.network_scanner.scan_network(
            ioc_ips=ioc_ips,
            ioc_domains=ioc_domains,
            options=options
        )
        self.plugin.findings["network"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    async def route_log_scan(
        self,
        ioc_strings: List[str] = None,
        log_paths: List[str] = None,
        use_ai: bool = False,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route log scan to LogScannerService."""
        results = await self.plugin.log_scanner.scan_logs(
            ioc_strings=ioc_strings,
            log_paths=log_paths,
            use_ai=use_ai,
            options=options
        )
        self.plugin.findings["log"] = results
        return [r.model_dump() for r in results]
    
    async def route_persistence_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route persistence scan to PersistenceScannerService."""
        results = await self.plugin.persistence_scanner.scan_persistence(
            options=options
        )
        self.plugin.findings["persistence"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    async def route_ttp_detect(
        self,
        ttp_patterns: Dict[str, str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route TTP detection to TTPDetectorService."""
        results = await self.plugin.ttp_detector.detect_ttps(
            ttp_patterns=ttp_patterns,
            options=options
        )
        self.plugin.findings["ttp"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    async def route_memory_scan(
        self,
        pids: List[int] = None,
        yara_rules: List[str] = None,
        patterns: List[str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Route memory scan to MemoryScannerService."""
        results = await self.plugin.memory_scanner.scan_memory(
            pids=pids,
            yara_rules=yara_rules,
            patterns=patterns,
            options=options
        )
        self.plugin.findings["memory"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    def route_finalize_scan_result(self, options: ScanOptions) -> IoCScanResult:
        """Route finalize to ResultProcessor."""
        return self.plugin.result_processor.finalize_scan_result(options)

