"""Webshell detection module."""

import os
import re
from pathlib import Path
from typing import Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    FileSystemFinding,
    ConfidenceLevel,
    ThreatCategory,
)
from ..utils import get_file_metadata
from ..databases import WEBSHELL_SIGNATURES


class WebshellDetector:
    """Detector for webshell files."""
    
    def is_web_file(self, filepath: str) -> bool:
        """Check if file is a web file."""
        web_extensions = {".php", ".jsp", ".asp", ".aspx", ".cgi", ".py", ".pl", ".rb"}
        return Path(filepath).suffix.lower() in web_extensions
    
    async def detect(self, filepath: str) -> Optional[FileSystemFinding]:
        """Detect webshell in file."""
        try:
            with open(filepath, "r", errors="ignore") as f:
                content = f.read(100000)  # First 100KB
            
            for sig in WEBSHELL_SIGNATURES:
                if re.search(sig["pattern"], content, re.IGNORECASE):
                    return FileSystemFinding(
                        finding_type="webshell",
                        severity=sig["severity"],
                        confidence=ConfidenceLevel.HIGH,
                        file_path=filepath,
                        file_metadata=get_file_metadata(filepath),
                        threat_category=ThreatCategory.WEBSHELL,
                        description=f"Webshell detected: {sig['name']}",
                        evidence=[f"Pattern matched: {sig['pattern']}"],
                        mitre_techniques=["T1505.003"],
                        remediation="Remove the webshell and investigate access logs"
                    )
        except Exception:
            pass
        
        return None

