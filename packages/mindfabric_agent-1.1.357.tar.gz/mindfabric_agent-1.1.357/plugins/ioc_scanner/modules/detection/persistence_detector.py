"""Persistence mechanism detection module."""

import os
import re
import time
from pathlib import Path
from typing import Dict, Any, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    PersistenceType,
    PersistenceFinding,
    SeverityLevel,
    ConfidenceLevel,
)
from ..databases import PERSISTENCE_CHECKS
from ..utils import calculate_entropy


class PersistenceDetector:
    """Detector for persistence mechanisms."""

    # Known legitimate persistence-like artifacts (vendor agents / default system files)
    _ALLOWLIST_PATH_PATTERNS = [
        r"^/etc/cron\.(hourly|daily|weekly|monthly)/droplet-agent$",
        r"^/opt/digitalocean/droplet-agent/",
        r"^/var/log/droplet-agent\.",
        r"^/root/\.ssh/authorized_keys$",
        r"^/root/\.bashrc$",
        r"^/root/\.profile$",
        r"^/etc/init\.d/rsync$",
    ]

    _ALLOWLIST_CONTENT_PATTERNS = [
        r"DigitalOcean Droplet Agent",
        r"code name:\s*DOTTY",
    ]

    _AUTHORIZED_KEYS_SUSPICIOUS_OPTION_PATTERNS = [
        r"(^|,)\s*command=",
        r"(^|,)\s*environment=",
        r"(^|,)\s*permitopen=",
        r"(^|,)\s*tunnel=",
        r"(^|,)\s*principals=",
        r"(^|,)\s*cert-authority\b",
    ]
    
    async def analyze_file(
        self,
        filepath: str,
        persistence_type: PersistenceType
    ) -> Optional[Dict[str, Any]]:
        """Analyze a persistence file for suspicious content."""
        try:
            if persistence_type == PersistenceType.SSH_AUTHORIZED_KEYS:
                return self._analyze_authorized_keys(filepath)

            # Hard allowlist for known legit artifacts to reduce noise.
            for pat in self._ALLOWLIST_PATH_PATTERNS:
                if re.search(pat, filepath):
                    return None

            with open(filepath, "r", errors="ignore") as f:
                content = f.read()

            for pat in self._ALLOWLIST_CONTENT_PATTERNS:
                if re.search(pat, content, re.IGNORECASE):
                    return None
            
            suspicious_indicators = []
            severity = SeverityLevel.LOW
            
            # Common suspicious patterns
            suspicious_patterns = [
                (r"curl\s+.*\|\s*(ba)?sh", "Curl pipe to shell"),
                (r"wget\s+.*\|\s*(ba)?sh", "Wget pipe to shell"),
                (r"base64\s+-d", "Base64 decode"),
                (r"/dev/tcp/", "Bash TCP redirect"),
                (r"nc\s+.*-e", "Netcat with execute"),
                (r"python.*-c.*socket", "Python socket"),
                (r"perl.*socket", "Perl socket"),
                (r"xmrig|minerd|cgminer", "Cryptominer"),
                (r"0\.0\.0\.0|/0\s", "Suspicious network"),
            ]
            
            for pattern, name in suspicious_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    suspicious_indicators.append(name)
                    severity = SeverityLevel.HIGH
            
            # Check for encoded content
            if len(content) > 100:
                # High entropy might indicate encoding
                entropy = calculate_entropy(content.encode())
                if entropy > 5.5:
                    suspicious_indicators.append("High entropy content")
            
            # "Recently modified" alone is too noisy (package upgrades, cloud agents, config management).
            # We only use mtime as an amplifier when there is already a suspicious signal.
            stat = os.stat(filepath)
            if suspicious_indicators and stat.st_mtime > time.time() - 86400:  # Modified in last day
                suspicious_indicators.append("Recently modified")
                if severity == SeverityLevel.LOW:
                    severity = SeverityLevel.MEDIUM
            
            if suspicious_indicators:
                return {
                    "severity": severity,
                    "confidence": ConfidenceLevel.MEDIUM,
                    "content": content[:500],
                    "description": f"Suspicious content in {filepath}",
                    "evidence": suspicious_indicators
                }
        
        except Exception:
            pass
        
        return None

    def _analyze_authorized_keys(self, filepath: str) -> Optional[Dict[str, Any]]:
        suspicious_indicators = []
        severity = SeverityLevel.LOW

        try:
            p = Path(filepath)
            st = os.lstat(filepath)
            if not p.is_file():
                return None

            if p.is_symlink():
                suspicious_indicators.append("authorized_keys is a symlink")
                severity = SeverityLevel.HIGH

            if st.st_mode & 0o022:
                suspicious_indicators.append("authorized_keys is writable by group/others")
                severity = SeverityLevel.HIGH

            expected_uid = None
            try:
                if str(p).startswith("/home/") and len(p.parts) >= 3:
                    expected_uid = os.stat(str(Path("/home") / p.parts[2])).st_uid
                elif str(p).startswith("/root/"):
                    expected_uid = os.stat("/root").st_uid
            except Exception:
                expected_uid = None

            if expected_uid is not None and st.st_uid not in (expected_uid, 0):
                suspicious_indicators.append("authorized_keys owner differs from home directory owner")
                severity = SeverityLevel.HIGH

            with open(filepath, "r", errors="ignore") as f:
                lines = [line.strip() for line in f.readlines()]

            key_lines = [
                line for line in lines
                if line and not line.startswith("#")
            ]
            if not key_lines:
                return None

            for line in key_lines:
                line_lower = line.lower()
                if any(re.search(pattern, line_lower) for pattern in self._AUTHORIZED_KEYS_SUSPICIOUS_OPTION_PATTERNS):
                    suspicious_indicators.append("authorized_keys uses forced-command or restrictive key options")
                    severity = SeverityLevel.HIGH
                    break

            # A normal authorized_keys file with stable ownership and plain keys is inventory,
            # not a persistence threat by itself.
            if not suspicious_indicators:
                return None

            if st.st_mtime > time.time() - 86400:
                suspicious_indicators.append("Recently modified")
                if severity == SeverityLevel.LOW:
                    severity = SeverityLevel.MEDIUM

            return {
                "severity": severity,
                "confidence": ConfidenceLevel.MEDIUM,
                "content": "\n".join(key_lines[:5])[:500],
                "description": f"Suspicious SSH authorized_keys configuration in {filepath}",
                "evidence": suspicious_indicators,
            }
        except Exception:
            return None
    
    def get_persistence_checks(self) -> Dict[str, Dict[str, Any]]:
        """Get all persistence checks."""
        return PERSISTENCE_CHECKS

