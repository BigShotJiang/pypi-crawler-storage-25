"""Process injection detection module."""

from typing import Dict, List

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    ProcessInfo,
    ProcessFinding,
    InjectionEvidence,
    ProcessInjectionType,
    SeverityLevel,
    ConfidenceLevel,
)


class InjectionDetector:
    """Detector for process injection."""
    
    async def detect(self, processes: Dict[int, ProcessInfo]) -> List[ProcessFinding]:
        """Detect potential process injection."""
        findings = []
        
        if not HAS_PSUTIL:
            return findings
        
        for pid, proc_info in processes.items():
            try:
                proc = psutil.Process(pid)
                
                # Check memory maps for suspicious regions
                try:
                    maps = proc.memory_maps()
                    for mmap in maps:
                        # Anonymous executable memory (potential injection)
                        if mmap.path == '' and 'x' in mmap.perms:
                            findings.append(ProcessFinding(
                                finding_type="potential_injection",
                                severity=SeverityLevel.HIGH,
                                confidence=ConfidenceLevel.MEDIUM,
                                process=proc_info,
                                injection_evidence=InjectionEvidence(
                                    injection_type=ProcessInjectionType.SHELLCODE_INJECTION,
                                    target_pid=pid,
                                    target_process=proc_info.name,
                                    memory_region=f"{mmap.path}",
                                    evidence=["Anonymous executable memory region detected"]
                                ),
                                description="Anonymous executable memory detected (potential injection)",
                                mitre_techniques=["T1055"]
                            ))
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass
            
            except Exception:
                continue
        
        return findings

