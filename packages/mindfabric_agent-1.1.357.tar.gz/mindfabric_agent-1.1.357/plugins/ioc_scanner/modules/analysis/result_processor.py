"""Result processing and finalization module."""

from typing import Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))
from ...proto import (
    IoCScanResult,
    ScanSummary,
    MitreSummary,
    ScanOptions,
    SeverityLevel,
    FileSystemFinding,
    ProcessFinding,
    NetworkFinding,
    MemoryFinding,
    PersistenceFinding,
    LogFinding,
    TTPFinding,
)


class ResultProcessor:
    """Processor for finalizing scan results."""
    
    def __init__(self, plugin_instance):
        """
        Initialize result processor.
        
        Args:
            plugin_instance: Instance of IocScannerPlugin for access to findings
        """
        self.plugin = plugin_instance
    
    def finalize_scan_result(self, options: ScanOptions) -> IoCScanResult:
        """Finalize scan results."""
        # Build summary
        summary = ScanSummary()
        mitre_summary = MitreSummary()
        
        all_ttps = set()
        all_tactics = set()
        
        # Count findings
        for finding_type, findings in self.plugin.findings.items():
            for finding in findings:
                summary.total_findings += 1
                
                # Get severity
                severity = None
                if hasattr(finding, 'severity'):
                    severity = finding.severity
                elif isinstance(finding, dict):
                    severity = finding.get('severity')
                
                if severity:
                    if severity == SeverityLevel.CRITICAL or severity == "critical":
                        summary.critical_findings += 1
                    elif severity == SeverityLevel.HIGH or severity == "high":
                        summary.high_findings += 1
                    elif severity == SeverityLevel.MEDIUM or severity == "medium":
                        summary.medium_findings += 1
                    elif severity == SeverityLevel.LOW or severity == "low":
                        summary.low_findings += 1
                    else:
                        summary.info_findings += 1
                
                # Count by type
                if finding_type == "file":
                    summary.file_findings += 1
                elif finding_type == "process":
                    summary.process_findings += 1
                elif finding_type == "network":
                    summary.network_findings += 1
                elif finding_type == "memory":
                    summary.memory_findings += 1
                elif finding_type == "persistence":
                    summary.persistence_findings += 1
                elif finding_type == "log":
                    summary.log_findings += 1
                elif finding_type == "ttp":
                    summary.ttp_findings += 1
                
                # Collect TTPs
                if hasattr(finding, 'mitre_techniques'):
                    all_ttps.update(finding.mitre_techniques)
                elif hasattr(finding, 'technique'):
                    all_ttps.add(finding.technique.technique_id)
                    all_tactics.add(finding.technique.tactic)
        
        mitre_summary.techniques_detected = list(all_ttps)
        mitre_summary.tactics_detected = list(all_tactics)
        mitre_summary.technique_count = len(all_ttps)
        mitre_summary.tactic_count = len(all_tactics)
        
        # Calculate risk
        risk_score = 0.0
        if summary.critical_findings > 0:
            risk_score = min(10.0, 8.0 + summary.critical_findings * 0.5)
        elif summary.high_findings > 0:
            risk_score = min(8.0, 5.0 + summary.high_findings * 0.3)
        elif summary.medium_findings > 0:
            risk_score = min(5.0, 2.0 + summary.medium_findings * 0.2)
        else:
            risk_score = summary.low_findings * 0.1
        
        overall_severity = SeverityLevel.INFO
        if risk_score >= 8:
            overall_severity = SeverityLevel.CRITICAL
        elif risk_score >= 5:
            overall_severity = SeverityLevel.HIGH
        elif risk_score >= 2:
            overall_severity = SeverityLevel.MEDIUM
        elif risk_score > 0:
            overall_severity = SeverityLevel.LOW
        
        # Generate remediation
        remediation = []
        if summary.critical_findings > 0:
            remediation.append("IMMEDIATE: Isolate affected systems from network")
            remediation.append("Collect forensic evidence before any changes")
        if summary.persistence_findings > 0:
            remediation.append("Remove identified persistence mechanisms")
        if self.plugin.findings.get("process"):
            remediation.append("Terminate malicious processes identified")
        if self.plugin.findings.get("network"):
            remediation.append("Block malicious IPs/domains at firewall")
        remediation.append("Update all security software and signatures")
        remediation.append("Review and rotate compromised credentials")
        remediation.append("Conduct full system reimage if deeply compromised")
        
        return IoCScanResult(
            metadata=self.plugin.scan_metadata,
            summary=summary,
            mitre_summary=mitre_summary,
            file_findings=[f if isinstance(f, FileSystemFinding) else f for f in self.plugin.findings.get("file", [])],
            process_findings=[f if isinstance(f, ProcessFinding) else f for f in self.plugin.findings.get("process", [])],
            network_findings=[f if isinstance(f, NetworkFinding) else f for f in self.plugin.findings.get("network", [])],
            memory_findings=[f if isinstance(f, MemoryFinding) else f for f in self.plugin.findings.get("memory", [])],
            persistence_findings=[f if isinstance(f, PersistenceFinding) else f for f in self.plugin.findings.get("persistence", [])],
            log_findings=[f if isinstance(f, LogFinding) else f for f in self.plugin.findings.get("log", [])],
            ttp_findings=[f if isinstance(f, TTPFinding) else f for f in self.plugin.findings.get("ttp", [])],
            overall_risk_score=risk_score,
            overall_severity=overall_severity,
            is_compromised=summary.critical_findings > 0 or summary.high_findings > 3,
            remediation_steps=remediation
        )

