#!/usr/bin/env python3
"""Remove duplicate constants from ioc_scanner.py"""

file_path = "/Users/grigory/My Projects/MindFabric/claude_opus/infrastructure_agent/agent/plugins/ioc_scanner2/ioc_scanner.py"

with open(file_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Find where to start removing (after "# PHASE 1: FILE SYSTEM SCANNING")
start_idx = None
for i, line in enumerate(lines):
    if i >= 212 and '# PHASE 1: FILE SYSTEM SCANNING' in line:
        start_idx = i + 2  # Skip the separator and start removing from next line
        break

# Find where duplicate constants end (before the actual hook_ioc_file_system method)
end_idx = None
for i in range(start_idx if start_idx else 0, len(lines)):
    # Look for the actual method definition with proper indentation
    if 'async def hook_ioc_file_system(' in lines[i] and '        self,' in lines[i+1] if i+1 < len(lines) else False:
        end_idx = i
        break
    # Also check for class definition (duplicate class)
    if i >= 820 and 'class IocScannerPlugin:' in lines[i]:
        end_idx = i
        break

if start_idx and end_idx:
    print(f"Removing lines {start_idx+1} to {end_idx}")
    print(f"First line to remove: {lines[start_idx].strip()[:50]}...")
    print(f"Last line to remove: {lines[end_idx-1].strip()[:50]}...")
    print(f"First line after removal: {lines[end_idx].strip()[:50]}...")
    
    # Keep everything before start_idx and from end_idx onwards
    new_lines = lines[:start_idx] + lines[end_idx:]
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    
    print(f"Successfully removed {end_idx - start_idx} lines")
    print(f"New file has {len(new_lines)} lines (was {len(lines)})")
else:
    print(f"Could not find boundaries: start={start_idx}, end={end_idx}")

