"""
IOC Scanner Plugin - Complete Edition

Comprehensive IOC detection covering:
- 15+ IOC types (hashes, IPs, domains, URLs, files, etc.)
- 50+ MITRE ATT&CK techniques
- YARA rules scanning
- Memory analysis
- Process injection detection
- Network C2 beaconing detection
- Persistence mechanism detection
- Threat Intelligence feed integration
- AI/ML classification
"""

import asyncio
import hashlib
import json
import os
import re
import socket
import struct
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional, Set, Tuple, Union
from collections import defaultdict
import ipaddress

# Try imports with fallbacks
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import yara
    HAS_YARA = True
except ImportError:
    HAS_YARA = False

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

try:
    import magic
    HAS_MAGIC = True
except ImportError:
    HAS_MAGIC = False

try:
    import ssdeep
    HAS_SSDEEP = True
except ImportError:
    HAS_SSDEEP = False

from .proto import (
    # Enums
    IoCType, SeverityLevel, ConfidenceLevel, ThreatCategory, FeedFormat,
    FeedSource, ProcessInjectionType, PersistenceType, NetworkProtocol,
    MitreTactic, ScanStatus, ActionTaken,
    # Models
    HashSet, FileMetadata, PEInfo, ELFInfo, YaraMatch, GeoIPInfo,
    DNSRecord, TLSInfo, MitreAttackTechnique, ThreatActor, MalwareFamily,
    IoCIndicator, IoCMatch, SuspiciousFileLocation, HiddenFile,
    ModifiedBinary, FileSystemFinding, ProcessInfo, ProcessTreeNode,
    InjectionEvidence, ProcessFinding, NetworkConnection, DNSQuery,
    BeaconingPattern, NetworkFinding, MemoryRegion, MemoryFinding,
    PersistenceFinding, LogEntry, LogFinding, TTPFinding, KillChainPhase,
    AttackTimeline, TIFeed, TIEnrichment, TIResult, AIClassification,
    AnomalyScore, AIAnalysisResult, ScanScope, ScanOptions, ScanSummary,
    MitreSummary, ScanMetadata, IoCScanResult,
    # Legacy
    LegacyIoCMatch, LegacyProcessFinding, LegacyNetworkFinding,
    LegacyTTPFinding, LegacyTIResult, LegacyAiIocLabel
)

# Import modules
from .modules.services import (
    DriveByDetectorService,
    DNSAnalysisService,
    FileScannerService,
    ProcessScannerService,
    NetworkScannerService,
    LogScannerService,
    PersistenceScannerService,
    TTPDetectorService,
    FeedService,
    ExportService,
    MemoryScannerService,
    LookupService,
    YaraService,
    AIService,
    StatisticsService,
    ScanOrchestratorService,
    LegacyCompatibilityService,
    ContainerScannerService,
    CloudScannerService,
    CloudIOCService,
    TimestompingDetectorService,
    SignatureVerifierService,
    CertificateAnalyzerService,
    ADSDetectorService,
    PowerShellAnalyzerService,
    IocArtifactSqliteStore,
    LogHit,
)
from .modules.analysis import ResultProcessor
from .modules.utils import ProgressHandler
from .modules.utils.ioc_file_threat_policy import (
    apply_posture_to_risk_score,
    build_ioc_file_posture_profile,
    cap_severity,
    classify_ioc_file_for_threat,
    is_node_js_package_manager_cache,
)

# =============================================================================
# CONSTANTS & DATABASES
# =============================================================================
# Note: All constants and databases moved to modules/databases/ioc_databases.py
# Import them from there if needed
from .modules.databases import (
    MITRE_TECHNIQUES,
    SUSPICIOUS_LOCATIONS,
    SUSPICIOUS_PROCESS_PATTERNS,
    SUSPICIOUS_DOMAIN_PATTERNS,
    PERSISTENCE_CHECKS,
    KNOWN_C2_PORTS,
    ENTROPY_THRESHOLD,
    WEBSHELL_SIGNATURES,
    DEFAULT_TI_FEEDS,
)
from .modules.databases.ui_templates import (
    get_ioc_guidance,
    build_ioc_bucket_description,
    build_ioc_evidence_preview,
    get_ioc_bucket_exploitation_commands,
    get_ioc_finding_type_legend,
    build_ioc_file_item_recommendations,
    build_ioc_ttp_item_recommendations,
    build_ioc_process_item_recommendations,
    build_ioc_network_item_recommendations,
    build_ioc_memory_item_recommendations,
    build_ioc_persistence_item_recommendations,
    get_ioc_file_audience_lead,
    get_ioc_ttp_audience_lead,
    get_ioc_process_audience_lead,
    get_ioc_network_audience_lead,
    get_ioc_memory_audience_lead,
    get_ioc_persistence_audience_lead,
    get_ioc_log_audience_lead,
)

# =============================================================================
# Removed - moved to modules/databases/ioc_databases.py:
# - MITRE_TECHNIQUES
# - SUSPICIOUS_LOCATIONS
# - SUSPICIOUS_PROCESS_PATTERNS
# - SUSPICIOUS_DOMAIN_PATTERNS
# - PERSISTENCE_CHECKS
# - KNOWN_C2_PORTS
# - ENTROPY_THRESHOLD
# - WEBSHELL_SIGNATURES
# - DEFAULT_TI_FEEDS
# Import utility functions from modules/utils
from .modules.utils import (
    calculate_entropy,
    calculate_file_hashes,
    get_file_metadata,
    is_ip_address,
    is_domain,
    is_hash,
    detect_ioc_type,
    match_yara_rules,
    check_dga,
    parse_log_line,
)


def _ioc_triage_hints_for_finding(kind: str, item: Dict[str, Any]) -> Dict[str, Any]:
    """Structured context for SOC triage (host, MITRE id, paths) — reduces opaque one-off rows."""
    k = (kind or "").strip().lower()
    out: Dict[str, Any] = {
        "host": socket.gethostname(),
        "ioc_bucket": k,
    }
    if k == "ttp":
        tech = item.get("technique") if isinstance(item.get("technique"), dict) else {}
        tid = tech.get("technique_id") or tech.get("id")
        tname = tech.get("technique_name") or tech.get("name")
        if tid:
            out["mitre_technique_id"] = str(tid)[:80]
        if tname:
            out["mitre_technique_name"] = str(tname)[:240]
        ev = item.get("evidence_source")
        if isinstance(ev, str) and ev.strip():
            out["evidence_source"] = ev.strip()[:500]
        out["triage_note"] = (
            "Confirm with process lineage, file path, and network peers — standalone TTP string matches are often benign."
        )
    elif k == "persistence":
        for key in ("path", "file_path", "filePath", "location", "registry_key", "target"):
            v = item.get(key)
            if isinstance(v, str) and v.strip():
                out["artifact_path"] = v.strip()[:1200]
                break
        pt = item.get("persistence_type") or item.get("type")
        if pt is not None:
            out["persistence_kind"] = str(pt)[:200]
        out["triage_note"] = (
            "Validate against golden images and change records — containers/dev boxes often show persistence-like paths."
        )
    elif k == "network":
        for kk, label in (
            ("remote_ip", "remote_ip"),
            ("destination_ip", "destination_ip"),
            ("local_ip", "local_ip"),
            ("source_ip", "source_ip"),
        ):
            v = item.get(kk)
            if isinstance(v, str) and v.strip():
                out[label] = v.strip()[:80]
    elif k == "memory":
        r = item.get("region") or item.get("address_range") or item.get("base_address")
        if r is not None:
            out["memory_region_hint"] = str(r)[:200]
        out["triage_note"] = "Memory IOC requires volatile dump analysis to confirm; host scan alone is a lead."
    return {a: b for a, b in out.items() if b is not None}


# =============================================================================
# MAIN PLUGIN CLASS
# =============================================================================

from plugins.base_plugin import BasePlugin

class IocScannerPlugin(BasePlugin):
    VERSION = "1.0.0"
    """
    Comprehensive IOC Scanner Plugin.
    
    Capabilities:
    - File system IOC scanning (hash, YARA, patterns)
    - Process analysis (injection, suspicious behavior)
    - Network connection analysis (C2, beaconing, IOC)
    - Memory scanning
    - Log analysis
    - Persistence detection
    - MITRE ATT&CK TTP detection
    - Threat Intelligence feed integration
    - AI/ML classification
    """
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        
        # IOC databases (loaded from feeds)
        self.ioc_hashes: Dict[str, IoCIndicator] = {}  # hash -> indicator
        self.ioc_ips: Dict[str, IoCIndicator] = {}  # ip -> indicator
        self.ioc_domains: Dict[str, IoCIndicator] = {}  # domain -> indicator
        self.ioc_urls: Dict[str, IoCIndicator] = {}  # url -> indicator
        
        # YARA rules
        self.yara_rules = None
        self.yara_rules_paths: List[str] = []
        
        # Findings storage
        self.findings: Dict[str, List] = {
            "file": [],
            "process": [],
            "network": [],
            "log": [],
            "persistence": [],
            "memory": [],
            "ttp": [],
        }
        
        # Scan metadata
        self.scan_metadata: Optional[ScanMetadata] = None
        
        # Initialize modules
        self.file_scanner = FileScannerService(self)
        self.process_scanner = ProcessScannerService(self)
        self.network_scanner = NetworkScannerService(self)
        self.log_scanner = LogScannerService(self)
        self.persistence_scanner = PersistenceScannerService(self)
        self.ttp_detector = TTPDetectorService(self)
        self.feed_service = FeedService(self)
        self.export_service = ExportService(self)
        self.memory_scanner = MemoryScannerService(self)
        self.lookup_service = LookupService(self)
        self.yara_service = YaraService(self)
        self.ai_service = AIService(self)
        self.statistics_service = StatisticsService(self)
        self.result_processor = ResultProcessor(self)
        self.scan_orchestrator = ScanOrchestratorService(self)
        self.legacy_service = LegacyCompatibilityService(self)
        self.progress_handler = ProgressHandler()
        self.container_scanner = ContainerScannerService(self)
        self.cloud_scanner = CloudScannerService(self)
        self.cloud_ioc_service = CloudIOCService(self)
        self.drive_by_detector = DriveByDetectorService(self)
        self.dns_analysis = DNSAnalysisService(self)
        
        # New detection services
        self.timestomping_detector = TimestompingDetectorService(self)
        self.signature_verifier = SignatureVerifierService(self)
        self.certificate_analyzer = CertificateAnalyzerService(self)
        self.ads_detector = ADSDetectorService(self)
        self.powershell_analyzer = PowerShellAnalyzerService(self)

        # Artifact storage (log vectors): on-disk sqlite to avoid RAM usage.
        # Enable by default, but can be disabled via IOC_ARTIFACTS_ENABLED=0.
        enabled = str(os.getenv("IOC_ARTIFACTS_ENABLED", "1")).strip().lower() not in ("0", "false", "no")
        try:
            max_mb = int(os.getenv("IOC_ARTIFACTS_MAX_MB", "25"))
        except Exception:
            max_mb = 25
        if max_mb < 5:
            max_mb = 5
        self.artifact_store = IocArtifactSqliteStore(command_id, max_db_bytes=max_mb * 1024 * 1024) if enabled else None
        self._artifact_hits_buffer = 0
    
    async def run(self):
        """Main entry point."""
        import asyncio
        from utils.logger import logger
        
        from .proto import ScanOptions
        options = ScanOptions()
        # Use full_scan by default for comprehensive IOC detection
        # Users can still trigger quick_scan via explicit hook call if needed
        # Add timeout protection: 20 minutes max to prevent agent timeout
        # This is a safety net - individual phases should have their own time budgets
        try:
            result = await asyncio.wait_for(
                self.hook_full_scan(options),
                timeout=20 * 60  # 20 minutes max (reduced from 30 minutes)
            )
        except asyncio.TimeoutError:
            logger.warning("ioc_scanner.run() exceeded timeout (20 minutes)")
            # Return partial results with timeout finding
            result = {
                'findings': getattr(self, 'findings', {}),
                'scan_metadata': {
                    'status': 'partial',
                    'errors': ['Scan exceeded maximum execution time (20 minutes)'],
                    'warnings': ['Some scan phases may not have completed']
                }
            }
        
        # Process results with timeout protection
        try:
            canonical_result = await asyncio.wait_for(
                asyncio.to_thread(self._with_canonical_findings, result),
                timeout=5 * 60  # 5 minutes max for result processing
            )
        except asyncio.TimeoutError:
            logger.error("[ioc_scanner] _with_canonical_findings exceeded timeout (5 minutes), using partial results")
            canonical_result = {
                'findings': [],
                'error': 'Result processing exceeded maximum time (5 minutes)',
                'scan_metadata': result.get('scan_metadata', {})
            }
        except Exception as e:
            logger.error(f"[ioc_scanner] Error in _with_canonical_findings: {e}", exc_info=True)
            canonical_result = {
                'findings': [],
                'error': f'Result processing error: {str(e)}',
                'scan_metadata': result.get('scan_metadata', {})
            }
        
        logger.info("[ioc_scanner] Starting serialization (to_security_scan_v1)")
        try:
            out = await asyncio.wait_for(
                asyncio.to_thread(self.to_security_scan_v1, canonical_result),
                timeout=2 * 60  # 2 minutes max for serialization
            )
        except asyncio.TimeoutError:
            logger.error("[ioc_scanner] to_security_scan_v1 exceeded timeout (2 minutes), using minimal result")
            out = self.to_security_scan_v1({
                'findings': [],
                'error': 'Serialization exceeded maximum time (2 minutes)',
                'scanned_at': datetime.utcnow().isoformat()
            })
        except Exception as e:
            logger.error(f"[ioc_scanner] Error in to_security_scan_v1: {e}", exc_info=True)
            out = self.to_security_scan_v1({
                'findings': [],
                'error': f'Serialization error: {str(e)}',
                'scanned_at': datetime.utcnow().isoformat()
            })

        # Optional: upload artifact sqlite to backend (opt-in)
        upload = str(os.getenv("IOC_ARTIFACTS_UPLOAD", "0")).strip().lower() in ("1", "true", "yes")
        if upload and self.artifact_store and self.ws and hasattr(self.ws, "upload_artifact_file"):
            try:
                # IMPORTANT: do not block the plugin result on artifact upload.
                # Large uploads can transiently drop the WS and delay/lose scan progress reporting.
                # We schedule upload in the background with a short delay so the command result
                # can be delivered first.
                async def _deferred_upload():
                    import asyncio
                    try:
                        delay_s = float(os.getenv("IOC_ARTIFACTS_UPLOAD_DELAY_SECONDS", "10"))
                    except Exception:
                        delay_s = 10.0
                    if delay_s < 0:
                        delay_s = 0.0
                    await asyncio.sleep(delay_s)

                    # If command results are pending resend, prefer stability over artifacts.
                    try:
                        pending = getattr(self.ws, "pending_results", None)
                        if isinstance(pending, list) and len(pending) > 0:
                            return
                    except Exception:
                        pass

                    try:
                        await self.ws.upload_artifact_file(
                            command_id=self.command_id,
                            file_path=self.artifact_store.db_path,
                            filename=f"ioc_scanner_{self.command_id}.sqlite",
                            content_type="application/x-sqlite3",
                            upload_id=f"ioc_scanner_{self.command_id}",
                        )
                    except Exception:
                        pass

                import asyncio
                asyncio.create_task(_deferred_upload())
            except Exception:
                pass

        try:
            if self.artifact_store:
                self.artifact_store.close()
        except Exception:
            pass
        return out

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Produce security_scan v1 `findings` with impact/recommendations from IoCScanResult shape.
        Keeps plugin-specific logic in plugin code (not in security_contract).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        # If plugin already produced canonical findings, just ensure recs/impact exist.
        findings_existing = out.get("findings")
        if isinstance(findings_existing, list) and findings_existing:
            for f in findings_existing:
                if not isinstance(f, dict):
                    continue
                if not f.get("impact") or not f.get("recommendations"):
                    impact, recs = get_ioc_guidance(str(f.get("threat_type") or "ioc"))
                    f.setdefault("impact", impact)
                    f.setdefault("recommendations", recs)
            return out

        # Build canonical findings from IoCScanResult fields.
        file_findings = out.get("file_findings") or out.get("fileFindings") or []
        process_findings = out.get("process_findings") or out.get("processFindings") or []
        network_findings = out.get("network_findings") or out.get("networkFindings") or []
        memory_findings = out.get("memory_findings") or out.get("memoryFindings") or []
        persistence_findings = out.get("persistence_findings") or out.get("persistenceFindings") or []
        log_findings = out.get("log_findings") or out.get("logFindings") or []
        ttp_findings = out.get("ttp_findings") or out.get("ttpFindings") or []

        overall_sev = out.get("overall_severity") or out.get("overallSeverity") or "info"
        if hasattr(overall_sev, "value"):
            overall_sev = overall_sev.value

        findings: List[Dict[str, Any]] = []

        # Aggregate "IOC scan summary" is not emitted as a threat (THREAT_QUALITY_ANALYSIS §9):
        # counts without per-item context inflated severity; use per-bucket / per-item findings only.

        def _item_as_dict(item: Any) -> Dict[str, Any]:
            if isinstance(item, dict):
                return item
            if hasattr(item, "model_dump"):
                try:
                    return item.model_dump()
                except Exception:
                    return {}
            if hasattr(item, "dict"):
                try:
                    return item.dict()
                except Exception:
                    return {}
            return {}

        def _is_likely_benign_os_path(path_lower: str) -> bool:
            if not path_lower:
                return False
            p = path_lower.replace("\\", "/")
            prefixes = (
                "/usr/share/", "/usr/lib/", "/usr/lib64/", "/usr/bin/", "/usr/sbin/",
                "/bin/", "/sbin/", "/lib/", "/lib64/", "/var/lib/", "/var/cache/",
                "/snap/", "/proc/", "/sys/", "/run/", "/etc/alternatives/",
                "/opt/homebrew/", "/library/apple/", "/system/library/",
                "c:/windows/winsxs/", "c:/windows/system32/", "c:/windows/syswow64/",
                "c:/program files/", "c:/program files (x86)/",
            )
            return any(p.startswith(pref) for pref in prefixes)

        def _is_package_manager_artifact(path_lower: str) -> bool:
            if not path_lower:
                return False
            if is_node_js_package_manager_cache(path_lower):
                return True
            p = path_lower.replace("\\", "/")
            prefixes = (
                "/var/lib/dpkg/info/",
                "/var/lib/rpm/",
                "/var/lib/pacman/local/",
                "/var/db/pkg/",
                "/var/cache/apt/",
            )
            return any(p.startswith(pref) for pref in prefixes)

        def _is_likely_benign_archive_or_log(path_lower: str) -> bool:
            if not path_lower:
                return False
            p = path_lower.replace("\\", "/")
            if p.startswith(("/var/log/", "/run/log/", "/var/lib/systemd/")):
                return True
            suffixes = (
                ".gz", ".xz", ".bz2", ".zip", ".7z", ".rar", ".tgz", ".tar",
                ".jar", ".war", ".ear", ".whl",
            )
            return p.endswith(suffixes)

        def _is_ioc_noise_runtime_path(path_lower: str) -> bool:
            """
            Hard FP suppression for IOC file indicators in OS/runtime/package trees.
            """
            if not path_lower:
                return False
            p = path_lower.replace("\\", "/")
            noisy_prefixes = (
                "/etc/apt/trusted.gpg.d/",
                "/etc/cron.daily/",
                "/etc/init.d/",
                "/usr/local/openjdk-",
                "/usr/local/lib/python",
                "/usr/lib/python",
                "/site-packages/",
                "/dist-packages/",
                "/root/.cache/pip/",
            )
            if any(p.startswith(pref) for pref in noisy_prefixes):
                return True
            if is_node_js_package_manager_cache(p):
                return True
            # Demo/sample/vendor assets are a common IOC filename-match false positive source.
            if "/examples/" in p or "/example/" in p:
                return True
            if p.endswith(
                (
                    ".png",
                    ".jpg",
                    ".jpeg",
                    ".gif",
                    ".svg",
                    ".ico",
                    ".css",
                    ".woff",
                    ".woff2",
                    ".ttf",
                    ".eot",
                )
            ):
                return True
            if "/plugins/" in p and any(
                x in p
                for x in (
                    "/ioc_scanner/",
                    "/web_application_scanner/",
                    "/message_queue_security_scanner/",
                    "/persistence_detection/",
                    "/misconfigurations_detector/",
                )
            ):
                return True
            return False

        def _is_user_writable_or_execution_staging_path(path_lower: str) -> bool:
            if not path_lower:
                return False
            p = path_lower.replace("\\", "/")
            prefixes = (
                "/tmp/", "/var/tmp/", "/dev/shm/", "/home/", "/root/",
                "/opt/", "/usr/local/", "c:/users/", "c:/programdata/",
            )
            return any(p.startswith(pref) for pref in prefixes)

        def _should_emit_suspicious_location(item: Dict[str, Any], path_lower: str) -> bool:
            if not path_lower:
                return False
            if _is_package_manager_artifact(path_lower):
                return False
            if _is_likely_benign_archive_or_log(path_lower) and not _is_user_writable_or_execution_staging_path(path_lower):
                return False
            if _is_user_writable_or_execution_staging_path(path_lower):
                return True
            return not _is_likely_benign_os_path(path_lower)

        def _should_emit_high_entropy(item: Dict[str, Any], path_lower: str) -> bool:
            if not path_lower:
                return False
            if _is_package_manager_artifact(path_lower):
                return False
            if _is_likely_benign_archive_or_log(path_lower) and not _is_user_writable_or_execution_staging_path(path_lower):
                return False
            metadata = item.get("file_metadata") if isinstance(item.get("file_metadata"), dict) else {}
            entropy = metadata.get("entropy")
            try:
                entropy_f = float(entropy)
            except Exception:
                entropy_f = None
            if _is_user_writable_or_execution_staging_path(path_lower):
                return entropy_f is None or entropy_f >= 7.2
            return not _is_likely_benign_os_path(path_lower)

        def _should_emit_ttp_finding(item: Dict[str, Any]) -> bool:
            technique = item.get("technique") if isinstance(item.get("technique"), dict) else {}
            technique_id = str(technique.get("technique_id") or "").strip().upper()
            technique_name = str(technique.get("technique_name") or "").strip().lower()
            evidence_details = item.get("evidence_details") or item.get("evidenceDetails") or []
            joined = " ".join(str(x).lower() for x in evidence_details[:80] if x)
            desc_l = str(item.get("description") or "").lower()

            def _has_strong_ttp_context() -> bool:
                strong_markers = (
                    "base64",
                    "decode",
                    "encodedcommand",
                    "powershell -enc",
                    "download_execute",
                    "reverse_shell",
                    "webshell",
                    "eval(",
                    "fromcharcode",
                    "certutil -decode",
                    "openssl enc",
                    "cmdline",
                    "process tree",
                    "yara",
                    "injection",
                    "credential",
                    "registry",
                    "scheduled task",
                    "persistence",
                    "lateral",
                    "syscall",
                    "memfd",
                    "ptrace",
                    "http://",
                    "https://",
                    "cve-",
                    "exploit",
                    "deserialization",
                    "jndi",
                    "log4j",
                    "sqli",
                    "sql injection",
                    "prototype pollution",
                    "ssrf",
                    "lfi",
                    "rfi",
                )
                return any(marker in joined or marker in desc_l for marker in strong_markers)

            weak_without_context_ids = frozenset({"T1036", "T1055", "T1071", "T1498", "T1190"})
            if technique_id in weak_without_context_ids:
                return _has_strong_ttp_context()
            if any(
                t in technique_name
                for t in ("masquerading", "process injection", "application layer protocol", "network denial")
            ):
                return _has_strong_ttp_context()
            if "exploit public-facing" in technique_name or "public-facing application" in technique_name:
                return _has_strong_ttp_context()

            if technique_id == "T1027" or technique_name == "obfuscated files or information":
                strong_markers = (
                    "base64",
                    "decode",
                    "encodedcommand",
                    "powershell -enc",
                    "download_execute",
                    "reverse_shell",
                    "webshell",
                    "eval(",
                    "fromcharcode",
                    "certutil -decode",
                    "openssl enc",
                )
                return any(marker in joined for marker in strong_markers)
            return True

        def _file_finding_for_threat_list(item: Any) -> bool:
            """Drop low-signal file rows (e.g. entropy heuristics under OS trees) from threat output."""
            d = _item_as_dict(item)
            ft = str(d.get("finding_type") or d.get("findingType") or "").strip().lower()
            path = d.get("file_path") or d.get("filePath") or ""
            path_s = path.strip().lower() if isinstance(path, str) else ""
            if _is_ioc_noise_runtime_path(path_s):
                return False

            if ft in ("ioc_match", "yara_match", "webshell"):
                if ft == "ioc_match":
                    ioc_match = d.get("ioc_match") if isinstance(d.get("ioc_match"), dict) else {}
                    indicator = ioc_match.get("indicator") if isinstance(ioc_match.get("indicator"), dict) else {}
                    indicator_type = str(indicator.get("type") or "").strip().lower()
                    # Filename/path partial matches in known noisy trees are weak by themselves.
                    if indicator_type in {"file_name", "filename", "file_path", "path"} and _is_ioc_noise_runtime_path(path_s):
                        return False
                return True
            if ft == "suspicious_location":
                return _should_emit_suspicious_location(d, path_s)
            if ft == "high_entropy":
                return _should_emit_high_entropy(d, path_s)
            return False

        def _dedupe_file_items_for_threats(items: Any) -> Any:
            """Same-file duplicate rows (multiple IOC hooks) -> one canonical row per scan."""
            if not isinstance(items, list) or not items:
                return items
            import os

            seen: set = set()
            out: List[Any] = []
            for raw in items:
                d = _item_as_dict(raw)
                fp = d.get("file_path") or d.get("filePath") or ""
                try:
                    fp_n = os.path.normpath(str(fp)).lower() if fp else ""
                except Exception:
                    fp_n = str(fp).lower() if fp else ""
                ft = str(d.get("finding_type") or d.get("findingType") or "").lower()
                ind = ""
                im = d.get("ioc_match")
                if isinstance(im, dict):
                    ind = str((im.get("indicator") or {}).get("value") or "")
                yara = ""
                ym = d.get("yara_matches") or d.get("yaraMatches")
                if isinstance(ym, list) and ym:
                    yara = ",".join(sorted({str(getattr(x, "rule_name", None) or x) for x in ym[:20]}))
                key = (ft, fp_n, ind, yara)
                if key in seen:
                    continue
                seen.add(key)
                out.append(raw)
            return out

        file_findings_for_threats = _dedupe_file_items_for_threats(
            [f for f in file_findings if _file_finding_for_threat_list(f)]
        )

        # Per-category findings only when non-empty (kept bounded).
        _IOC_AUDIENCE_LEADS_DEFAULT = (
            "Host indicator without a dedicated category label: treat as one signal in a timeline—pair with auth, process, file, "
            "and network evidence in the same window, and rule out change management before closing."
        )

        def _ioc_technical_preview(kind: str, item: Any) -> str:
            """
            Short, pipe-separated facts for titles, bucket examples, and evidence previews.
            """
            k = (kind or "").strip().lower()
            if not isinstance(item, dict):
                return str(item)[:220]

            if k == "process":
                proc = item.get("process") if isinstance(item.get("process"), dict) else None
                if proc:
                    pid = proc.get("pid")
                    name = proc.get("name")
                    user = proc.get("username") or proc.get("user")
                    exe = proc.get("exe")
                    cmd = proc.get("cmdline")
                    bits: List[str] = []
                    if pid is not None:
                        bits.append(f"pid={pid}")
                    if isinstance(name, str) and name.strip():
                        bits.append(name.strip())
                    if isinstance(user, str) and user.strip():
                        bits.append(f"user={user.strip()}")
                    if isinstance(exe, str) and exe.strip():
                        bits.append(f"exe={exe.strip()}")
                    if isinstance(cmd, str) and cmd.strip():
                        c = cmd.strip()
                        if len(c) > 140:
                            c = c[:140] + "…"
                        bits.append(f"cmd={c}")
                    if bits:
                        return " | ".join(bits)[:240]
                return (item.get("description") or item.get("reason") or "process indicator")[:240]

            if k == "log":
                pat = item.get("matched_pattern") or item.get("matchedPattern")
                src = item.get("log_source") or item.get("logSource")
                desc = item.get("description")
                parts: List[str] = []
                if isinstance(pat, str) and pat.strip():
                    parts.append(pat.strip())
                if isinstance(src, str) and src.strip():
                    parts.append(src.strip())
                if isinstance(desc, str) and desc.strip():
                    parts.append(desc.strip())
                if parts:
                    return " | ".join(parts)[:240]
                return "log indicator"

            if k == "persistence":
                ptype = item.get("persistence_type") or item.get("persistenceType") or item.get("type")
                if hasattr(ptype, "value"):
                    ptype = ptype.value
                loc = item.get("location") or item.get("file_path") or item.get("filePath") or item.get("path")
                val = item.get("value")
                parts: List[str] = []
                if ptype:
                    parts.append(str(ptype))
                if loc:
                    parts.append(str(loc))
                if val:
                    parts.append(str(val))
                if parts:
                    return " | ".join(parts)[:220]
                return "persistence indicator"

            if k == "file":
                ft = str(item.get("finding_type") or item.get("findingType") or "").strip()
                path = ""
                for key in ("file_path", "filePath", "path", "location"):
                    v = item.get(key)
                    if isinstance(v, str) and v.strip():
                        path = v.strip()
                        break
                bits: List[str] = []
                if path:
                    disp = path if len(path) <= 130 else path[:127] + "…"
                    bits.append(f"path={disp}")
                if ft:
                    bits.append(f"type={ft}")
                ym = item.get("yara_matches") or item.get("yaraMatches")
                if isinstance(ym, list) and ym:
                    rule = getattr(ym[0], "rule_name", None) or ym[0]
                    bits.append(f"yara={str(rule)[:72]}")
                im = item.get("ioc_match") if isinstance(item.get("ioc_match"), dict) else {}
                ind = im.get("indicator") if isinstance(im.get("indicator"), dict) else {}
                if isinstance(ind.get("value"), str) and ind["value"].strip():
                    iv = ind["value"].strip()
                    bits.append(f"indicator={iv[:96]}")
                if bits:
                    return " | ".join(bits)[:240]
                return (item.get("description") or item.get("reason") or "file indicator")[:240]

            if k == "network":
                rip = str(item.get("remote_ip") or item.get("ip") or item.get("destination_ip") or "").strip()
                rdom = str(item.get("remote_domain") or item.get("domain") or "").strip()
                rport = item.get("remote_port") or item.get("port")
                proc = str(item.get("process_name") or item.get("name") or "").strip()
                pid = item.get("process_pid") or item.get("pid")
                bits: List[str] = []
                if rip:
                    bits.append(f"ip={rip}")
                if rdom:
                    bits.append(f"host={rdom}")
                if rport is not None and str(rport).strip():
                    bits.append(f"port={rport}")
                if proc:
                    bits.append(proc[:100])
                if pid is not None:
                    bits.append(f"pid={pid}")
                if bits:
                    return " | ".join(bits)[:240]
                for key in ("url", "uri", "indicator"):
                    v = item.get(key)
                    if isinstance(v, str) and v.strip():
                        return v.strip()[:240]
                return (item.get("description") or item.get("reason") or "network indicator")[:240]

            if k == "memory":
                pid = item.get("pid") or item.get("process_pid")
                proc = str(item.get("process_name") or item.get("name") or "").strip()
                mr = item.get("memory_region") or item.get("memoryRegion")
                region = ""
                if isinstance(mr, dict):
                    region = str(mr.get("name") or mr.get("base") or mr.get("start") or "").strip()
                elif mr is not None:
                    region = str(mr).strip()
                if not region:
                    region = str(item.get("region") or "").strip()
                bits: List[str] = []
                if proc:
                    bits.append(proc[:100])
                if pid is not None:
                    bits.append(f"pid={pid}")
                if region:
                    bits.append(f"region={region[:100]}")
                if bits:
                    return " | ".join(bits)[:240]
                return (item.get("description") or item.get("reason") or "memory indicator")[:240]

            if k == "ttp":
                tech = item.get("technique") if isinstance(item.get("technique"), dict) else {}
                tid = str(
                    tech.get("technique_id")
                    or item.get("technique_id")
                    or item.get("mitre_technique")
                    or ""
                ).strip().upper()
                tname = str(tech.get("technique_name") or item.get("technique_name") or "").strip()
                if tid and tname:
                    return f"{tid} — {tname}"[:240]
                if tid:
                    return tid
                if tname:
                    return tname[:240]
                return (item.get("description") or item.get("reason") or "TTP indicator")[:240]

            for key in ("location", "file_path", "path", "process_name", "processName", "domain", "ip", "url", "indicator"):
                v = item.get(key)
                if isinstance(v, str) and v.strip():
                    return v.strip()[:220]
            return (item.get("description") or item.get("reason") or "indicator")[:220]

        def _ioc_audience_description(kind: str, item: Any) -> str:
            """Plain-language explanation plus technical preview for threat `description` fields."""
            k = (kind or "").strip().lower()
            idict = item if isinstance(item, dict) else {}
            if k == "file":
                lead = get_ioc_file_audience_lead(idict)
            elif k == "ttp":
                lead = get_ioc_ttp_audience_lead(idict)
            elif k == "process":
                lead = get_ioc_process_audience_lead()
            elif k == "network":
                lead = get_ioc_network_audience_lead()
            elif k == "memory":
                lead = get_ioc_memory_audience_lead()
            elif k == "persistence":
                lead = get_ioc_persistence_audience_lead(idict)
            elif k == "log":
                lead = get_ioc_log_audience_lead(idict)
            else:
                lead = _IOC_AUDIENCE_LEADS_DEFAULT
            tech = _ioc_technical_preview(kind, item)
            if tech and tech not in lead:
                return f"{lead} Technical detail: {tech}"[:900]
            return lead[:900]

        def _summarize_item(kind: str, item: Any) -> str:
            """Backward-compatible alias: technical preview only (used in bucket previews)."""
            return _ioc_technical_preview(kind, item)

        def _bucket_affected_resources(kind: str, items: List[Dict[str, Any]], preview: List[str]) -> List[Dict[str, Any]]:
            """
            Structured scope: host + indicator surface (paths stay tied to scanned host).
            """
            k = (kind or "").strip().lower()
            out_res: List[Dict[str, Any]] = []
            try:
                hn = socket.gethostname()
            except Exception:
                hn = ""

            if k == "file":
                for it in items[:25]:
                    if not isinstance(it, dict):
                        continue
                    for key in ("file_path", "filePath", "path", "location"):
                        v = it.get(key)
                        if isinstance(v, str) and v.strip():
                            row: Dict[str, Any] = {
                                "type": "ioc_host_filesystem",
                                "path": v.strip()[:2000],
                            }
                            if hn:
                                row["hostname"] = hn
                            out_res.append(row)
                            break
                    if len(out_res) >= 12:
                        break
            elif k == "persistence":
                for it in items[:25]:
                    if not isinstance(it, dict):
                        continue
                    v = it.get("location") or it.get("file_path") or it.get("filePath") or it.get("path")
                    if isinstance(v, str) and v.strip():
                        row = {"type": "persistence_artifact", "path": v.strip()[:2000]}
                        if hn:
                            row["hostname"] = hn
                        out_res.append(row)
                    if len(out_res) >= 12:
                        break
            elif k == "process":
                for it in items[:25]:
                    if not isinstance(it, dict):
                        continue
                    proc = it.get("process") if isinstance(it.get("process"), dict) else None
                    if proc:
                        pid = proc.get("pid")
                        name = proc.get("name")
                        row = {"type": "ioc_process"}
                        if isinstance(name, str) and name.strip():
                            row["name"] = name.strip()[:260]
                        if pid is not None:
                            try:
                                row["pid"] = int(pid)
                            except (TypeError, ValueError):
                                pass
                        if hn:
                            row["hostname"] = hn
                        if len(row) > 1:
                            out_res.append(row)
                    if len(out_res) >= 12:
                        break
            elif k == "log":
                for it in items[:25]:
                    if not isinstance(it, dict):
                        continue
                    src = it.get("log_source") or it.get("logSource")
                    pat = it.get("matched_pattern") or it.get("matchedPattern")
                    if isinstance(src, str) and src.strip():
                        row = {"type": "log_ingestion_surface", "source": src.strip()[:500]}
                        if isinstance(pat, str) and pat.strip():
                            row["pattern"] = pat.strip()[:500]
                        if hn:
                            row["hostname"] = hn
                        out_res.append(row)
                    if len(out_res) >= 12:
                        break

            # Dedupe by repr
            seen = set()
            deduped: List[Dict[str, Any]] = []
            for r in out_res:
                key = repr(sorted(r.items()))
                if key in seen:
                    continue
                seen.add(key)
                deduped.append(r)
            if not deduped and hn:
                return [{"type": "ioc_scan_scope", "hostname": hn}]
            return deduped

        def _item_severity(item: Any) -> str:
            d = _item_as_dict(item)
            sev = d.get("severity") or overall_sev
            if hasattr(sev, "value"):
                sev = sev.value
            return str(sev or "medium").lower()

        def _item_title(kind: str, item: Any) -> str:
            d = _item_as_dict(item)
            summary = _summarize_item(kind, d)
            prefixes = {
                "file": "IOC file indicator",
                "process": "IOC process indicator",
                "network": "IOC network indicator",
                "memory": "IOC memory indicator",
                "persistence": "IOC persistence indicator",
                "ttp": "IOC TTP indicator",
            }
            prefix = prefixes.get((kind or "").strip().lower(), "IOC indicator")
            return f"{prefix}: {summary}" if summary else prefix

        def _is_benign_ioc_process_item(item: Dict[str, Any]) -> bool:
            proc = item.get("process") if isinstance(item.get("process"), dict) else {}
            cmd = str(proc.get("cmdline") or item.get("description") or "").lower()
            name = str(proc.get("name") or "").lower()
            exe = str(proc.get("exe") or "").lower().replace("\\", "/")
            user_l = str(proc.get("user") or proc.get("username") or "").lower()
            parent = str(proc.get("parent_name") or proc.get("ppname") or proc.get("parent") or "").lower()
            # Common cron housekeeping shells are noisy in IOC mode.
            if "run-parts --report /etc/cron.hourly" in cmd and name in {"sh", "dash", "bash"}:
                return True
            # Package managers and known service daemons under vendor paths
            if name in {"apt-get", "apt", "dpkg", "yum", "dnf", "rpm", "pip", "pip3"}:
                return True
            if exe.startswith("/usr/lib/") and name in {"packagekitd", "fwupd"}:
                return True
            if name == "java" and ("-jar" in cmd) and ("/opt/" in cmd or "/usr/share/" in cmd):
                return True
            # Root shells from JVM app servers or init are usually operational noise.
            if name in {"sh", "bash", "dash"} and user_l in {"root", "0"}:
                if parent in {"java", "jsvc"} or "java" in parent:
                    return True
                if parent.startswith("systemd") or parent == "cron" or "(sd-pam)" in parent:
                    return True
                if "/lib/systemd/" in exe or exe.endswith("/systemd"):
                    return True
            return False

        def _add_individual_item_findings(kind: str, items: Any, threat_type: str, limit: int = 50):
            if not isinstance(items, list) or not items:
                return
            impact_k, recs_default = get_ioc_guidance(kind)
            for raw in items[:limit]:
                item = _item_as_dict(raw)
                if not item:
                    continue
                if (kind or "").strip().lower() == "ttp" and not _should_emit_ttp_finding(item):
                    continue
                if (kind or "").strip().lower() == "process" and _is_benign_ioc_process_item(item):
                    continue
                summary = _ioc_technical_preview(kind, item)
                audience_desc = _ioc_audience_description(kind, item)
                sev = _item_severity(item)
                risk_score: Optional[int] = None
                evidence_out: Dict[str, Any] = dict(item)
                if (kind or "").strip().lower() == "file" and threat_type == "ioc_file_finding":
                    dec = classify_ioc_file_for_threat(item)
                    if not dec.emit:
                        continue
                    if dec.severity_ceiling:
                        sev = cap_severity(sev, dec.severity_ceiling)
                    risk_score = dec.risk_score
                    evidence_out["ioc_file_threat_policy"] = dec.policy
                    # Multi-factor posture (entropy, owner, mtime, optional baseline prefixes) — never suppresses strong types here.
                    try:
                        raw_prefs = None
                        if isinstance(self.options, dict):
                            raw_prefs = self.options.get("ioc_baseline_path_prefixes")
                        baseline_prefs: Optional[List[str]] = None
                        if isinstance(raw_prefs, list):
                            baseline_prefs = [str(x) for x in raw_prefs if str(x).strip()]
                        elif isinstance(raw_prefs, str) and raw_prefs.strip():
                            baseline_prefs = [p.strip() for p in raw_prefs.split(",") if p.strip()]
                        posture = build_ioc_file_posture_profile(item, baseline_path_prefixes=baseline_prefs)
                        strong_ft = str(
                            item.get("finding_type") or item.get("findingType") or ""
                        ).strip().lower() in ("yara_match", "webshell")
                        if risk_score is not None:
                            risk_score, posture = apply_posture_to_risk_score(
                                int(risk_score), posture, strong_type=strong_ft
                            )
                        evidence_out["ioc_posture_profile"] = posture
                    except Exception:
                        pass
                k_item = (kind or "").strip().lower()
                recs_row = recs_default
                if k_item == "file":
                    recs_row = build_ioc_file_item_recommendations(item)
                elif k_item == "ttp":
                    recs_row = build_ioc_ttp_item_recommendations(item)
                elif k_item == "process":
                    recs_row = build_ioc_process_item_recommendations(item)
                elif k_item == "network":
                    recs_row = build_ioc_network_item_recommendations(item)
                elif k_item == "memory":
                    recs_row = build_ioc_memory_item_recommendations(item)
                elif k_item == "persistence":
                    recs_row = build_ioc_persistence_item_recommendations(item)
                preview_for_cmds: List[str] = []
                if k_item == "process":
                    proc_d = item.get("process") if isinstance(item.get("process"), dict) else {}
                    par_d = item.get("parent_process") if isinstance(item.get("parent_process"), dict) else {}
                    for d in (proc_d, par_d):
                        raw_pid = d.get("pid") if isinstance(d, dict) else None
                        if raw_pid is None:
                            continue
                        try:
                            preview_for_cmds.append(str(int(raw_pid)))
                        except (TypeError, ValueError):
                            preview_for_cmds.append(str(raw_pid))
                elif k_item == "ttp":
                    tech_d = item.get("technique") if isinstance(item.get("technique"), dict) else {}
                    tid = str(tech_d.get("technique_id") or "").strip()
                    if tid:
                        preview_for_cmds.append(tid)
                    ev_src = item.get("evidence_source")
                    if isinstance(ev_src, str) and ev_src.strip():
                        preview_for_cmds.append(ev_src.strip())
                    for ed in item.get("evidence_details") or []:
                        if isinstance(ed, str) and ed.strip():
                            preview_for_cmds.append(ed.strip()[:240])
                        if len(preview_for_cmds) >= 14:
                            break
                elif k_item == "file":
                    for key in ("file_path", "filePath", "path", "location"):
                        v = item.get(key)
                        if isinstance(v, str) and v.strip():
                            preview_for_cmds.append(v.strip())
                            break
                if summary:
                    if k_item == "file" and preview_for_cmds:
                        pass
                    else:
                        preview_for_cmds.append(summary)
                exp_cmds = get_ioc_bucket_exploitation_commands(str(kind).lower(), preview_for_cmds)
                impact_row = impact_k
                if k_item == "file":
                    impact_row = get_ioc_file_audience_lead(item)
                elif k_item == "ttp":
                    impact_row = get_ioc_ttp_audience_lead(item)
                elif k_item == "process":
                    impact_row = get_ioc_process_audience_lead()
                elif k_item == "network":
                    impact_row = get_ioc_network_audience_lead()
                elif k_item == "memory":
                    impact_row = get_ioc_memory_audience_lead()
                elif k_item == "persistence":
                    impact_row = get_ioc_persistence_audience_lead(item)
                elif k_item == "log":
                    impact_row = get_ioc_log_audience_lead(item)
                row: Dict[str, Any] = {
                    "title": _item_title(kind, item),
                    "description": audience_desc or f"Concrete {kind} IOC detected.",
                    "severity": sev,
                    "category": "IOC Scanner",
                    "threat_type": threat_type,
                    "type": threat_type,
                    "finding_type": threat_type,
                    "impact": impact_row,
                    "recommendations": recs_row,
                    "evidence": evidence_out,
                    "exploitation_commands": exp_cmds,
                    "affected_resources": _bucket_affected_resources(kind, [item], [summary] if summary else []),
                }
                thi = _ioc_triage_hints_for_finding(k_item, item)
                if thi:
                    row["triage_hints"] = thi
                if k_item == "file":
                    ft_leg = str(item.get("finding_type") or item.get("findingType") or "").strip().lower()
                    legend = get_ioc_finding_type_legend(ft_leg)
                    if legend:
                        row["finding_type_legend"] = legend
                    evidence_out["data_collection"] = (
                        "On-host file read: metadata (stat), optional type detection, entropy over file bytes where enabled."
                    )
                if risk_score is None:
                    k = (kind or "").strip().lower()
                    if k == "process":
                        risk_score = { "critical": 78, "high": 68, "medium": 58, "low": 46, "info": 36 }.get(sev, 56)
                    elif k == "ttp":
                        risk_score = 63
                    elif k in ("network", "memory", "persistence"):
                        risk_score = { "critical": 76, "high": 65, "medium": 54, "low": 44, "info": 34 }.get(sev, 54)
                if risk_score is not None:
                    row["risk_score"] = risk_score
                findings.append(row)

        def _add_bucket(kind: str, items: Any, title: str, threat_type: str):
            if not isinstance(items, list) or not items:
                return
            impact_k, recs_k = get_ioc_guidance(kind)
            preview = [_summarize_item(kind, it) for it in items[:25]]
            preview = [p for p in preview if isinstance(p, str) and p.strip()]

            exp_cmds = get_ioc_bucket_exploitation_commands(str(kind).lower(), preview)
            affected = _bucket_affected_resources(kind, items, preview)

            findings.append(
                {
                    "title": title,
                    "description": build_ioc_bucket_description(kind, len(items), preview[:3]),
                    "severity": str(overall_sev).lower(),
                    "category": "IOC Scanner",
                    "threat_type": threat_type,
                    "type": threat_type,
                    "finding_type": threat_type,
                    "impact": impact_k,
                    "recommendations": recs_k,
                    "evidence": build_ioc_evidence_preview(kind, preview, len(items)),
                    "exploitation_commands": exp_cmds,
                    "affected_resources": affected,
                }
            )

        _add_individual_item_findings("file", file_findings_for_threats, "ioc_file_finding")
        _add_individual_item_findings("process", process_findings, "ioc_process_finding")
        _add_individual_item_findings("network", network_findings, "ioc_network_finding")
        _add_individual_item_findings("memory", memory_findings, "ioc_memory_finding")
        _add_individual_item_findings("persistence", persistence_findings, "ioc_persistence_finding")
        
        # Special handling for log findings: create individual findings for each log finding
        # This allows backend to extract IP addresses and create proper threat graph edges
        if log_findings:
            # LogScannerService emits separate LogFinding rows per regex *name* (e.g. "SSH brute force"
            # vs "Invalid SSH user"). Those buckets hold disjoint IP sets for the same auth.log.
            # Pre-merge attacker IPs per log file so consolidated ssh_bruteforce evidence lists all sources.
            _ssh_ip_union: Dict[str, Set[str]] = defaultdict(set)
            _ssh_user_union: Dict[str, Set[str]] = defaultdict(set)
            _ssh_occ_union: Dict[str, int] = defaultdict(int)
            # Merge raw log lines across SSH-related regex buckets for the same file (UI / ThreatFinding evidence).
            _ssh_log_line_samples: Dict[str, List[str]] = defaultdict(list)

            def _log_finding_as_dict(lf: Any) -> Optional[Dict[str, Any]]:
                if isinstance(lf, dict):
                    return lf
                if hasattr(lf, "model_dump"):
                    return lf.model_dump()
                if hasattr(lf, "dict"):
                    return lf.dict()
                return None

            for _lf in log_findings:
                d = _log_finding_as_dict(_lf)
                if not d:
                    continue
                mp = (d.get("matched_pattern") or "").lower()
                if "oom killer" in mp or "out of memory" in mp:
                    continue
                if not ("ssh" in mp and ("brute" in mp or "invalid" in mp)):
                    continue
                log_src = d.get("log_source") or d.get("logSource") or "unknown"
                for ev_item in d.get("evidence") or []:
                    if not isinstance(ev_item, str):
                        continue
                    if ev_item.startswith("Source IPs:"):
                        ip_list_str = ev_item.replace("Source IPs:", "").strip()
                        if ip_list_str:
                            for ip in ip_list_str.split(","):
                                ip = ip.strip()
                                if ip:
                                    _ssh_ip_union[log_src].add(ip)
                    elif ev_item.startswith("Targeted Usernames:"):
                        u_str = ev_item.replace("Targeted Usernames:", "").strip()
                        if u_str:
                            for u in u_str.split(","):
                                u = u.strip()
                                if u:
                                    _ssh_user_union[log_src].add(u)
                    elif ev_item.startswith("Found ") and "matches" in ev_item:
                        try:
                            _ssh_occ_union[log_src] += int(ev_item.split()[1])
                        except Exception:
                            pass
                for entry in d.get("log_entries") or []:
                    if isinstance(entry, dict):
                        sip = entry.get("source_ip")
                        if sip:
                            _ssh_ip_union[log_src].add(str(sip))
                        rl = (entry.get("raw_line") or entry.get("message") or "").strip()
                        if rl and len(_ssh_log_line_samples[log_src]) < 72:
                            _ssh_log_line_samples[log_src].append(rl[:1800])
                    elif hasattr(entry, "source_ip") and entry.source_ip:
                        _ssh_ip_union[log_src].add(str(entry.source_ip))
                        if hasattr(entry, "raw_line") and entry.raw_line:
                            rl = str(entry.raw_line).strip()
                            if rl and len(_ssh_log_line_samples[log_src]) < 72:
                                _ssh_log_line_samples[log_src].append(rl[:1800])

            _ssh_bruteforce_emitted: Set[str] = set()
            processed_count = 0
            for log_finding in log_findings:
                processed_count += 1
                if not isinstance(log_finding, dict):
                    # Try to convert to dict if it's a Pydantic model
                    if hasattr(log_finding, "model_dump"):
                        log_finding = log_finding.model_dump()
                    elif hasattr(log_finding, "dict"):
                        log_finding = log_finding.dict()
                    else:
                        continue
                
                # Extract key information
                log_source = log_finding.get("log_source") or log_finding.get("logSource") or "unknown"
                matched_pattern = log_finding.get("matched_pattern") or log_finding.get("matchedPattern") or ""
                description = log_finding.get("description") or ""
                evidence_list = log_finding.get("evidence") or []
                
                # Extract metadata from evidence
                source_ips = []
                destination_ip = None
                usernames = []
                oom_processes = []
                findings_count = 0
                
                for ev_item in evidence_list:
                    if isinstance(ev_item, str):
                        if ev_item.startswith("Source IPs:"):
                            ip_list_str = ev_item.replace("Source IPs:", "").strip()
                            if ip_list_str:
                                source_ips.extend([ip.strip() for ip in ip_list_str.split(",")])
                        elif ev_item.startswith("Destination IP:"):
                            destination_ip = ev_item.replace("Destination IP:", "").strip()
                        elif ev_item.startswith("Targeted Usernames:"):
                            username_list_str = ev_item.replace("Targeted Usernames:", "").strip()
                            if username_list_str:
                                usernames.extend([u.strip() for u in username_list_str.split(",")])
                        elif ev_item.startswith("Killed Processes:"):
                            process_list_str = ev_item.replace("Killed Processes:", "").strip()
                            if process_list_str:
                                oom_processes.extend([p.strip() for p in process_list_str.split(",")])
                        elif ev_item.startswith("Found ") and "matches" in ev_item:
                            try:
                                findings_count = int(ev_item.split()[1])
                            except Exception:
                                pass
                
                # Also try to extract from log_entries
                log_entries = log_finding.get("log_entries") or []
                log_timestamps = []  # Collect timestamps from log entries
                for entry in log_entries:
                    if isinstance(entry, dict):
                        src_ip = entry.get("source_ip")
                        if src_ip and src_ip not in source_ips:
                            source_ips.append(src_ip)
                        if not destination_ip:
                            destination_ip = entry.get("destination_ip")
                        # Extract timestamp from log entry
                        entry_ts = entry.get("timestamp")
                        if entry_ts:
                            log_timestamps.append(entry_ts)
                    elif hasattr(entry, "source_ip") and entry.source_ip:
                        if entry.source_ip not in source_ips:
                            source_ips.append(entry.source_ip)
                        if not destination_ip and hasattr(entry, "destination_ip"):
                            destination_ip = entry.destination_ip
                        # Extract timestamp from log entry
                        if hasattr(entry, "timestamp") and entry.timestamp:
                            log_timestamps.append(entry.timestamp)
                
                # Get earliest and latest log timestamps (time when logs were written in system)
                log_timestamp_earliest = None
                log_timestamp_latest = None
                if log_timestamps:
                    # Filter out None values and convert to datetime if needed
                    valid_timestamps = []
                    for ts in log_timestamps:
                        if ts:
                            if isinstance(ts, str):
                                try:
                                    ts = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                                except Exception:
                                    continue
                            valid_timestamps.append(ts)
                    if valid_timestamps:
                        log_timestamp_earliest = min(valid_timestamps)
                        log_timestamp_latest = max(valid_timestamps)
                
                # Get detection time (when plugin found the issue)
                detected_at = log_finding.get("detected_at")
                if detected_at:
                    if isinstance(detected_at, str):
                        try:
                            detected_at = datetime.fromisoformat(detected_at.replace('Z', '+00:00'))
                        except Exception:
                            detected_at = datetime.utcnow()
                    elif not isinstance(detected_at, datetime):
                        detected_at = datetime.utcnow()
                else:
                    detected_at = datetime.utcnow()
                
                # Determine severity
                severity_value = log_finding.get("severity")
                if hasattr(severity_value, "value"):
                    severity = severity_value.value
                else:
                    severity = str(severity_value or "medium").lower()
                
                # Determine threat type and guidance key
                pattern_lower = matched_pattern.lower()
                if "oom killer" in pattern_lower or "out of memory" in pattern_lower:
                    continue
                if "ssh" in pattern_lower and ("brute" in pattern_lower or "invalid" in pattern_lower):
                    threat_type = "ssh_bruteforce"
                    guidance_key = "ssh_bruteforce"
                else:
                    threat_type = "log_attack"
                    guidance_key = "log"
                
                # Get impact and recommendations
                impact_k, recs_k = get_ioc_guidance(guidance_key)
                exp_cmds = get_ioc_bucket_exploitation_commands(guidance_key, [matched_pattern])
                
                # For large volume attacks (e.g., > 1000 occurrences), create summary + top 10 findings
                if findings_count > 1000 and source_ips and len(source_ips) > 10:
                    # Create summary finding first
                    summary_title = f"{matched_pattern}: {findings_count} total occurrences from {len(source_ips)} unique source IPs"
                    summary_description = (
                        "Your log files show a large number of suspicious events that often mean an automated attack "
                        "(for example password guessing or vulnerability scanning) against this system. "
                        f"Pattern matched: {matched_pattern}. "
                        f"Scale: {findings_count} events from {len(source_ips)} different source IP addresses; log source: {log_source}. "
                    )
                    if usernames:
                        summary_description += f"Attackers targeted {len(usernames)} username(s): {', '.join(sorted(usernames)[:10])}. "
                    summary_description += f"Top 10 attacking IPs: {', '.join(sorted(source_ips)[:10])}. "
                    if "ssh" in pattern_lower:
                        summary_description += "This indicates automated brute force attempts. Review logs for successful logins and immediately block attacking IPs."
                    
                    # Prepare evidence with timestamps
                    evidence_dict = {
                        "log_source": log_source,
                        "matched_pattern": matched_pattern,
                        "source_ip": sorted(source_ips)[0] if source_ips else None,  # First IP for edge extraction
                        "destination_ip": destination_ip,
                        "total_occurrences": findings_count,
                        "unique_source_ips_count": len(source_ips),
                        "targeted_usernames": usernames[:20],  # Limit to 20
                        "oom_processes": oom_processes[:20] if oom_processes else [],
                        "all_source_ips": sorted(source_ips)[:100],  # Top 100 for reference
                        "log_entries_count": len(log_entries),
                        "mitre_techniques": log_finding.get("mitre_techniques", []),
                    }
                    # Add timestamps: log_timestamp (time when log was written) and detected_at (time when plugin found it)
                    if log_timestamp_earliest:
                        evidence_dict["log_timestamp"] = log_timestamp_earliest.isoformat() if hasattr(log_timestamp_earliest, "isoformat") else str(log_timestamp_earliest)
                        if log_timestamp_latest and log_timestamp_latest != log_timestamp_earliest:
                            evidence_dict["log_timestamp_latest"] = log_timestamp_latest.isoformat() if hasattr(log_timestamp_latest, "isoformat") else str(log_timestamp_latest)
                    evidence_dict["detected_at"] = detected_at.isoformat() if hasattr(detected_at, "isoformat") else str(detected_at)
                    
                    findings.append({
                        "title": summary_title,
                        "description": summary_description,
                        "severity": severity,
                        "category": "Log IOC",
                        "threat_type": threat_type,
                        "type": threat_type,
                        "finding_type": threat_type,
                        "impact": impact_k,
                        "recommendations": recs_k,
                        "exploitation_commands": exp_cmds,
                        "evidence": evidence_dict,
                        "detection_method": "IOC Scanner",
                        "detection_location": log_source,
                        "risk_score": 68,
                    })
                    
                    # Per-IP rows multiply noise; keep only for non-SSH log patterns.
                    if threat_type != "ssh_bruteforce":
                        for src_ip in sorted(source_ips)[:10]:
                            threat_title = f"{matched_pattern} from {src_ip}"
                            individual_description = (
                                "Log analysis tied repeated suspicious activity to a single Internet address. "
                                f"Pattern: {matched_pattern}. Source IP: {src_ip}. Log source: {log_source}. "
                            )
                            if usernames:
                                individual_description += f"Usernames seen in attempts: {', '.join(sorted(usernames)[:5])}. "
                            individual_description += (
                                "This is likely part of a broader campaign. Block or rate-limit that address and verify "
                                "no unexpected successful sign-ins occurred."
                            )
                            
                            evidence_dict_ip = {
                                "log_source": log_source,
                                "matched_pattern": matched_pattern,
                                "source_ip": src_ip,
                                "destination_ip": destination_ip,
                                "targeted_usernames": usernames[:10],
                                "log_entries_count": len(log_entries),
                                "mitre_techniques": log_finding.get("mitre_techniques", []),
                            }
                            if log_timestamp_earliest:
                                evidence_dict_ip["log_timestamp"] = log_timestamp_earliest.isoformat() if hasattr(log_timestamp_earliest, "isoformat") else str(log_timestamp_earliest)
                            evidence_dict_ip["detected_at"] = detected_at.isoformat() if hasattr(detected_at, "isoformat") else str(detected_at)
                            
                            findings.append({
                                "title": threat_title,
                                "description": individual_description,
                                "severity": severity,
                                "category": "Log IOC",
                                "threat_type": threat_type,
                                "type": threat_type,
                                "finding_type": threat_type,
                                "impact": impact_k,
                                "recommendations": recs_k,
                                "exploitation_commands": exp_cmds,
                                "evidence": evidence_dict_ip,
                                "detection_method": "IOC Scanner",
                                "detection_location": log_source,
                            })
                elif threat_type == "ssh_bruteforce":
                    # One consolidated threat per log file (not per regex bucket). Merge IPs from all
                    # SSH-related patterns on this path (e.g. "Failed password" + "Invalid user").
                    if log_source in _ssh_bruteforce_emitted:
                        continue
                    merged_ips = sorted(set(source_ips) | _ssh_ip_union.get(log_source, set()))
                    if not merged_ips:
                        continue
                    _ssh_bruteforce_emitted.add(log_source)
                    uniq_ips = merged_ips
                    occ_total = _ssh_occ_union.get(log_source) or findings_count
                    cons_title = (
                        f"SSH brute force from {len(uniq_ips)} source(s) → {log_source}"
                    )
                    cons_desc = (
                        f"One or more Internet hosts ({len(uniq_ips)} distinct source IP(s)) are actively guessing SSH "
                        f"credentials against this machine; evidence is in {log_source}. "
                        f"This maps to MITRE T1110 (Brute Force): each failed attempt is an attack try, not yet proof of access. "
                        "If an attacker finds a valid password or key, they get a shell as that user—read/modify files, "
                        "install malware, pivot internally, or exfiltrate data. "
                        "Next: confirm whether any 'Accepted password' / 'Accepted publickey' lines appear for the same IP(s) "
                        "around the same time; if none, the account may still be safe, but the SSH surface is being abused."
                    )
                    merged_users = sorted(set(usernames) | _ssh_user_union.get(log_source, set()))
                    if merged_users:
                        cons_desc += f" Sample usernames: {', '.join(merged_users[:8])}."
                    evidence_dict = {
                        "log_source": log_source,
                        "matched_pattern": matched_pattern,
                        "source_ip": uniq_ips[0],
                        "destination_ip": destination_ip,
                        "unique_source_ips_count": len(uniq_ips),
                        "all_source_ips": uniq_ips[:200],
                        "targeted_usernames": merged_users[:30] if merged_users else [],
                        "log_entries_count": len(log_entries),
                        "mitre_techniques": log_finding.get("mitre_techniques", []),
                        "deduplication": "host_log_pattern",
                        "ssh_ip_merge": "merged_invalid_user_and_brute_force_buckets",
                    }
                    line_samples = _ssh_log_line_samples.get(log_source) or []
                    if not line_samples and log_entries:
                        for entry in log_entries:
                            if isinstance(entry, dict):
                                rl = (entry.get("raw_line") or entry.get("message") or "").strip()
                                if rl:
                                    line_samples.append(rl[:1800])
                            elif hasattr(entry, "raw_line") and entry.raw_line:
                                line_samples.append(str(entry.raw_line).strip()[:1800])
                            if len(line_samples) >= 45:
                                break
                    if line_samples:
                        evidence_dict["log_line_samples"] = line_samples[:45]
                    if occ_total:
                        evidence_dict["total_occurrences"] = occ_total
                    if log_timestamp_earliest:
                        evidence_dict["log_timestamp"] = log_timestamp_earliest.isoformat() if hasattr(log_timestamp_earliest, "isoformat") else str(log_timestamp_earliest)
                        if log_timestamp_latest and log_timestamp_latest != log_timestamp_earliest:
                            evidence_dict["log_timestamp_latest"] = log_timestamp_latest.isoformat() if hasattr(log_timestamp_latest, "isoformat") else str(log_timestamp_latest)
                    evidence_dict["detected_at"] = detected_at.isoformat() if hasattr(detected_at, "isoformat") else str(detected_at)
                    findings.append({
                        "title": cons_title,
                        "description": cons_desc,
                        "severity": severity,
                        "category": "Log IOC",
                        "threat_type": threat_type,
                        "type": threat_type,
                        "finding_type": threat_type,
                        "impact": impact_k,
                        "recommendations": recs_k,
                        "exploitation_commands": exp_cmds,
                        "evidence": evidence_dict,
                        "detection_method": "IOC Scanner",
                        "detection_location": log_source,
                        "risk_score": 70,
                    })
                elif source_ips:
                    # Non-SSH log indicators: keep a small cap of per-IP rows for graph hints.
                    for src_ip in source_ips[:12]:
                        threat_title = f"{matched_pattern} from {src_ip}" if matched_pattern else f"Log attack from {src_ip}"
                        individual_description = description or (
                            "Logs contained activity matching a known suspicious pattern. "
                            f"Pattern: {matched_pattern or 'unspecified'}. Log source: {log_source}. Source IP: {src_ip}. "
                        )
                        if not description:
                            individual_description += (
                                "Review whether this traffic is expected; if not, treat it as possible probing or intrusion."
                            )
                        if usernames:
                            individual_description += f" Usernames referenced: {', '.join(sorted(usernames)[:5])}."
                        if oom_processes:
                            individual_description += f" Related processes (if any): {', '.join(sorted(oom_processes)[:5])}."
                        
                        evidence_dict = {
                            "log_source": log_source,
                            "matched_pattern": matched_pattern,
                            "source_ip": src_ip,
                            "destination_ip": destination_ip,
                            "targeted_usernames": usernames[:10] if usernames else [],
                            "oom_processes": oom_processes[:10] if oom_processes else [],
                            "log_entries_count": len(log_entries),
                            "mitre_techniques": log_finding.get("mitre_techniques", []),
                        }
                        if log_timestamp_earliest:
                            evidence_dict["log_timestamp"] = log_timestamp_earliest.isoformat() if hasattr(log_timestamp_earliest, "isoformat") else str(log_timestamp_earliest)
                        evidence_dict["detected_at"] = detected_at.isoformat() if hasattr(detected_at, "isoformat") else str(detected_at)
                        
                        findings.append({
                            "title": threat_title,
                            "description": individual_description,
                            "severity": severity,
                            "category": "Log IOC",
                            "threat_type": threat_type,
                            "type": threat_type,
                            "finding_type": threat_type,
                            "impact": impact_k,
                            "recommendations": recs_k,
                            "exploitation_commands": exp_cmds,
                            "evidence": evidence_dict,
                            "detection_method": "IOC Scanner",
                            "detection_location": log_source,
                            "risk_score": 55,
                        })
                else:
                    # No IPs found - create aggregated finding
                    threat_type = "log_attack"
                    if "ssh" in matched_pattern.lower() and "brute" in matched_pattern.lower():
                        threat_type = "ssh_bruteforce"
                        guidance_key = "ssh_bruteforce"
                    else:
                        guidance_key = "log"
                    
                    impact_k, recs_k = get_ioc_guidance(guidance_key)
                    exp_cmds = get_ioc_bucket_exploitation_commands(guidance_key, [matched_pattern])
                    
                    enhanced_description = description or (
                        "Automated scanning found suspicious lines in your logs that do not point to a single source IP in the extracted data. "
                        f"Pattern: {matched_pattern or 'unspecified'}. Log source: {log_source}. "
                        "An operator should read the surrounding log lines to see what happened and whether any login or action succeeded."
                    )
                    pattern_lower = matched_pattern.lower()
                    if "ssh" in pattern_lower and not description:
                        enhanced_description += (
                            " For SSH, repeated failures often mean someone is guessing passwords; confirm no unexpected successful logins "
                            "and consider blocking repeat offenders."
                        )
                    
                    # Prepare evidence with timestamps
                    evidence_dict = {
                        "log_source": log_source,
                        "matched_pattern": matched_pattern,
                        "destination_ip": destination_ip,
                        "targeted_usernames": usernames[:20] if usernames else [],
                        "oom_processes": oom_processes[:20] if oom_processes else [],
                        "log_entries_count": len(log_entries),
                        "mitre_techniques": log_finding.get("mitre_techniques", []),
                    }
                    # Add timestamps: log_timestamp (time when log was written) and detected_at (time when plugin found it)
                    if log_timestamp_earliest:
                        evidence_dict["log_timestamp"] = log_timestamp_earliest.isoformat() if hasattr(log_timestamp_earliest, "isoformat") else str(log_timestamp_earliest)
                    evidence_dict["detected_at"] = detected_at.isoformat() if hasattr(detected_at, "isoformat") else str(detected_at)
                    
                    findings.append({
                        "title": f"IOC scan: {matched_pattern}" if matched_pattern else "IOC scan: suspicious log indicators",
                        "description": enhanced_description,
                        "severity": severity,
                        "category": "Log IOC",
                        "threat_type": threat_type,
                        "type": threat_type,
                        "finding_type": threat_type,
                        "impact": impact_k,
                        "recommendations": recs_k,
                        "exploitation_commands": exp_cmds,
                        "evidence": evidence_dict,
                        "detection_method": "IOC Scanner",
                        "detection_location": log_source,
                    })
        else:
            # Fallback: create bucket if no individual findings were created
            _add_bucket("log", log_findings, "IOC scan: suspicious log indicators", "ioc_log_findings")
        
        # Preserve original log_findings in output for backend processing
        # This allows plugin_processor.py to process them separately and create individual threats per source IP
        # Serialize Pydantic models to dict to ensure proper JSON serialization
        serialized_log_findings = []
        for lf in log_findings:
            if hasattr(lf, "model_dump"):
                serialized_log_findings.append(lf.model_dump())
            elif hasattr(lf, "dict"):
                serialized_log_findings.append(lf.dict())
            elif isinstance(lf, dict):
                serialized_log_findings.append(lf)
            else:
                # Fallback: try to convert to dict
                try:
                    serialized_log_findings.append(dict(lf))
                except Exception:
                    pass
        out["log_findings"] = serialized_log_findings
        
        _add_individual_item_findings("ttp", ttp_findings, "ioc_ttp_finding", limit=25)

        out["findings"] = findings
        return out
    
    # =============================================================================
    # PHASE 1: FILE SYSTEM SCANNING
    # =============================================================================
    
    async def hook_ioc_file_system(
        self,
        ioc_list: List[str] = None,
        paths: List[str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Comprehensive file system IOC scanning.
        
        Features:
        - Hash-based detection (MD5, SHA1, SHA256, SSDEEP)
        - YARA rules scanning
        - File attribute analysis
        - Entropy analysis (packed/encrypted detection)
        - Suspicious location detection
        - Webshell detection
        - Hidden file detection
        - Modified binary detection
        
        Args:
            ioc_list: List of IOC values (hashes, filenames, paths)
            paths: Directories to scan
            options: Scan configuration options
        
        Returns:
            List of FileSystemFinding dictionaries
        """
        # Delegate to file scanner service
        results = await self.file_scanner.scan_files(
            ioc_list=ioc_list,
            paths=paths,
            options=options
        )
        
        self.findings["file"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # Methods moved to modules:
    # - _iter_files, _check_suspicious_location, _is_web_file, _detect_webshell -> FileScannerService
    # - _check_suspicious_process_trees, _detect_process_injection -> ProcessScannerService
    # - _detect_beaconing -> NetworkScannerService / BeaconingDetector
    
    # =============================================================================
    # PHASE 2: PROCESS SCANNING
    # =============================================================================
    
    async def hook_ioc_processes(
        self,
        ioc: Dict[str, Any] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Comprehensive process IOC scanning.
        
        Features:
        - Process name/cmdline IOC matching
        - Suspicious command pattern detection
        - Process injection detection
        - Suspicious parent-child relationships
        - Hidden process detection
        - Cryptominer detection
        - Reverse shell detection
        
        Args:
            ioc: Dictionary with process IOCs (names, hashes, patterns)
            options: Scan configuration
        
        Returns:
            List of ProcessFinding dictionaries
        """
        # Delegate to process scanner service
        results = await self.process_scanner.scan_processes(
            ioc=ioc,
            options=options
        )
        
        self.findings["process"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =============================================================================
    # PHASE 3: NETWORK SCANNING
    # =============================================================================
    
    async def hook_ioc_network(
        self,
        ioc_strings: List[str] = None,
        log_paths: List[str] = None,
        use_ai: bool = False,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Log file IOC scanning.
        
        Features:
        - Pattern/string matching
        - Authentication failure detection
        - Privilege escalation detection
        - Command injection detection
        - Brute force detection
        
        Args:
            ioc_strings: Strings to search in logs
            log_paths: Log files to scan
            use_ai: Enable AI analysis
            options: Scan configuration
        
        Returns:
            List of LogFinding dictionaries
        """
        # Delegate to log scanner service
        results = await self.log_scanner.scan_logs(
            ioc_strings=ioc_strings,
            log_paths=log_paths,
            use_ai=use_ai,
            options=options
        )
        
        self.findings["log"] = results
        return [r.model_dump() for r in results]
    
    async def hook_ioc_logs(
        self,
        ioc_strings: List[str] = None,
        log_paths: List[str] = None,
        use_ai: bool = False,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Log file IOC scanning (alias for hook_ioc_network for log scanning).
        
        Features:
        - Pattern/string matching
        - Authentication failure detection
        - Privilege escalation detection
        - Command injection detection
        - Brute force detection
        
        Args:
            ioc_strings: Strings to search in logs
            log_paths: Log files to scan
            use_ai: Enable AI analysis
            options: Scan configuration
        
        Returns:
            List of LogFinding dictionaries
        """
        # Delegate to log scanner service (same as hook_ioc_network for logs)
        return await self.hook_ioc_network(
            ioc_strings=ioc_strings,
            log_paths=log_paths,
            use_ai=use_ai,
            options=options,
            **kwargs
        )
    
    # =========================================================================
    # PHASE 5: PERSISTENCE DETECTION
    # =========================================================================
    
    async def hook_persistence_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Scan for persistence mechanisms.
        
        Features:
        - Cron job analysis
        - Systemd service analysis
        - Init script analysis
        - SSH authorized keys analysis
        - Shell RC file analysis
        - LD_PRELOAD detection
        - Kernel module analysis
        
        Returns:
            List of PersistenceFinding dictionaries
        """
        # Delegate to persistence scanner service
        results = await self.persistence_scanner.scan_persistence(
            options=options
        )
        
        self.findings["persistence"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =========================================================================
    # PHASE 6: TTP DETECTION
    # =========================================================================
    
    async def hook_ttp_detect(
        self,
        ttp_patterns: Dict[str, str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        MITRE ATT&CK TTP detection.
        
        Analyzes all findings and maps to MITRE techniques.
        
        Args:
            ttp_patterns: Custom TTP detection patterns
            options: Scan configuration
        
        Returns:
            List of TTPFinding dictionaries
        """
        # Delegate to TTP detector service
        results = await self.ttp_detector.detect_ttps(
            ttp_patterns=ttp_patterns,
            options=options
        )
        
        self.findings["ttp"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =========================================================================
    # PHASE 7: THREAT INTELLIGENCE
    # =========================================================================
    
    async def hook_feed_sync(
        self,
        feed_url: str = None,
        feed_urls: List[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Sync Threat Intelligence feeds.
        
        Args:
            feed_url: Single feed URL
            feed_urls: Multiple feed URLs
        
        Returns:
            TIResult dictionary
        """
        # Delegate to feed service
        return await self.feed_service.sync_feeds(
            feed_url=feed_url,
            feed_urls=feed_urls
        )
    
    # =========================================================================
    # PHASE 8: AI ANALYSIS
    # =========================================================================
    
    async def hook_ai_ioc_label(
        self,
        lines: str = None,
        findings: List[Dict] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """AI/ML analysis of IOC findings."""
        return await self.ai_service.analyze(
            lines=lines,
            findings=findings
        )
    
    # =========================================================================
    # MAIN SCAN ORCHESTRATION
    # =========================================================================
    
    async def hook_full_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run comprehensive IOC scan.
        
        Executes all scan phases:
        1. Feed sync
        2. File system scan
        3. Process scan
        4. Network scan
        5. Log scan
        6. Persistence scan
        7. TTP detection
        8. AI analysis
        
        Returns:
            IoCScanResult dictionary
        """
        # Delegate to scan orchestrator service
        return await self.scan_orchestrator.full_scan(options=options, **kwargs)
    
    def _finalize_scan_result(self, options: ScanOptions) -> IoCScanResult:
        """Finalize scan results."""
        # Delegate to result processor
        return self.result_processor.finalize_scan_result(options)
    
    # =========================================================================
    # HELPERS
    # =========================================================================
    
    async def _handle_progress(self, percent: int, message: str):
        """Handle progress updates."""
        await self.progress_handler.handle_progress(self.scan_metadata, percent, message)
    
    async def _send_alert(self, alert_type: str, message: str, severity: SeverityLevel):
        """Send alert."""
        await self.progress_handler.send_alert(self, alert_type, message, severity)
    
    # =========================================================================
    # LEGACY COMPATIBILITY
    # =========================================================================
    
    async def hook_ioc_file_system_legacy(self, ioc_list=None, paths=None, **kwargs):
        """Legacy compatibility wrapper."""
        return await self.legacy_service.hook_ioc_file_system_legacy(
            ioc_list=ioc_list, paths=paths, **kwargs
        )
    
    async def hook_ioc_processes_legacy(self, ioc=None, **kwargs):
        """Legacy compatibility wrapper."""
        return await self.legacy_service.hook_ioc_processes_legacy(ioc=ioc, **kwargs)
    
    async def hook_ioc_network_legacy(self, ioc_domains=None, ioc_ips=None, **kwargs):
        """Legacy compatibility wrapper."""
        return await self.legacy_service.hook_ioc_network_legacy(
            ioc_domains=ioc_domains, ioc_ips=ioc_ips, **kwargs
        )
    
    # =========================================================================
    # DRIVE-BY COMPROMISE DETECTION
    # =========================================================================
    
    async def hook_drive_by_detection(
        self,
        scan_browser_history: bool = True,
        scan_downloads: bool = True,
        scan_cache: bool = True,
        scan_office_macros: bool = True,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Detect drive-by compromise attacks (T1189).
        
        Features:
        - Browser artifacts analysis (history, downloads, cache)
        - Exploit kit detection
        - Malicious website visits
        - Office macro execution
        
        Args:
            scan_browser_history: Scan browser history
            scan_downloads: Scan browser downloads
            scan_cache: Scan browser cache
            scan_office_macros: Scan Office documents for macros
            options: Scan configuration
            
        Returns:
            List of FileSystemFinding dictionaries
        """
        results = await self.drive_by_detector.detect_drive_by_compromise(
            scan_browser_history=scan_browser_history,
            scan_downloads=scan_downloads,
            scan_cache=scan_cache,
            scan_office_macros=scan_office_macros,
        )
        
        # Add to file findings
        self.findings["file"].extend(results)
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =========================================================================
    # NEW DETECTION SERVICES
    # =========================================================================
    
    async def hook_timestomping_detection(
        self,
        file_paths: Optional[List[str]] = None,
        system_install_date: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Detect timestomping in files.
        
        Args:
            file_paths: List of file paths to check (if None, scans common locations)
            system_install_date: System installation date (ISO format)
            **kwargs: Additional options
            
        Returns:
            Dict with timestomping findings
        """
        from datetime import datetime
        
        if file_paths is None:
            # Default scan locations
            file_paths = []
            if os.name == 'nt':
                file_paths.extend([
                    "C:\\Windows\\System32",
                    "C:\\Windows\\SysWOW64",
                ])
            else:
                file_paths.extend([
                    "/bin",
                    "/sbin",
                    "/usr/bin",
                    "/usr/sbin",
                ])
        
        install_date = None
        if system_install_date:
            try:
                install_date = datetime.fromisoformat(system_install_date.replace('Z', '+00:00'))
            except Exception:
                pass
        
        findings = await self.timestomping_detector.detect_timestomping(
            file_paths,
            install_date,
        )
        
        self.findings["file"].extend(findings)
        return {
            "findings": [f.model_dump() if hasattr(f, 'model_dump') else f.__dict__ for f in findings],
            "count": len(findings),
        }
    
    async def hook_signature_verification(
        self,
        file_paths: Optional[List[str]] = None,
        system_directories: Optional[List[str]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Verify digital signatures of files.
        
        Args:
            file_paths: List of file paths to check
            system_directories: List of system directories where signatures are required
            **kwargs: Additional options
            
        Returns:
            Dict with signature verification findings
        """
        if file_paths is None:
            file_paths = []
        
        findings = await self.signature_verifier.verify_signatures(
            file_paths,
            system_directories,
        )
        
        self.findings["file"].extend(findings)
        return {
            "findings": [f.model_dump() if hasattr(f, 'model_dump') else f.__dict__ for f in findings],
            "count": len(findings),
        }
    
    async def hook_certificate_analysis(
        self,
        file_paths: Optional[List[str]] = None,
        check_trust_stores: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analyze certificates in files and trust stores.
        
        Args:
            file_paths: List of file paths to check
            check_trust_stores: Whether to check trust stores for fake CA certificates
            **kwargs: Additional options
            
        Returns:
            Dict with certificate analysis findings
        """
        if file_paths is None:
            file_paths = []
        
        findings = await self.certificate_analyzer.analyze_certificates(
            file_paths,
            check_trust_stores,
        )
        
        self.findings["file"].extend(findings)
        return {
            "findings": [f.model_dump() if hasattr(f, 'model_dump') else f.__dict__ for f in findings],
            "count": len(findings),
        }
    
    async def hook_ads_detection(
        self,
        directory_paths: Optional[List[str]] = None,
        recursive: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Detect Alternate Data Streams (NTFS).
        
        Args:
            directory_paths: List of directory paths to scan
            recursive: Whether to scan recursively
            **kwargs: Additional options
            
        Returns:
            Dict with ADS findings
        """
        if directory_paths is None:
            if os.name == 'nt':
                directory_paths = [
                    "C:\\Windows\\System32",
                    "C:\\Windows\\SysWOW64",
                    "C:\\Program Files",
                ]
            else:
                return {"findings": [], "count": 0, "message": "ADS detection is Windows-only"}
        
        findings = await self.ads_detector.detect_ads(
            directory_paths,
            recursive,
        )
        
        self.findings["file"].extend(findings)
        return {
            "findings": [f.model_dump() if hasattr(f, 'model_dump') else f.__dict__ for f in findings],
            "count": len(findings),
        }
    
    async def hook_powershell_analysis(
        self,
        script_content: Optional[str] = None,
        file_path: Optional[str] = None,
        source: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analyze PowerShell script using AST parsing.
        
        Args:
            script_content: PowerShell script content
            file_path: Path to PowerShell script file
            source: Source identifier (log entry, etc.)
            **kwargs: Additional options
            
        Returns:
            Dict with PowerShell analysis findings
        """
        if script_content is None and file_path:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    script_content = f.read()
            except Exception as e:
                return {"error": f"Failed to read file: {e}"}
        
        if not script_content:
            return {"error": "No script content provided"}
        
        findings = await self.powershell_analyzer.analyze_powershell(
            script_content,
            source or file_path,
        )
        
        self.findings["log"].extend(findings)
        return {
            "findings": [f.model_dump() if hasattr(f, 'model_dump') else f.__dict__ for f in findings],
            "count": len(findings),
        }
    
    # =========================================================================
    # DNS ANALYSIS
    # =========================================================================
    
    async def hook_dns_analysis(
        self,
        dns_queries: List[Any] = None,
        analyze_exfiltration: bool = True,
        analyze_anomalies: bool = True,
        analyze_c2: bool = True,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Advanced DNS analysis for exfiltration, anomalies, and C2 detection.
        
        Features:
        - DNS exfiltration detection (T1048)
        - DNS anomalies detection
        - DNS C2 communication detection (T1071.004)
        - DGA domain detection
        
        Args:
            dns_queries: List of DNS queries to analyze
            analyze_exfiltration: Detect DNS exfiltration
            analyze_anomalies: Detect DNS anomalies
            analyze_c2: Detect DNS C2 communication
            options: Scan configuration
            
        Returns:
            List of NetworkFinding dictionaries
        """
        results = await self.dns_analysis.analyze_dns_queries(
            dns_queries=dns_queries,
            analyze_exfiltration=analyze_exfiltration,
            analyze_anomalies=analyze_anomalies,
            analyze_c2=analyze_c2,
        )
        
        # Add to network findings
        self.findings["network"].extend(results)
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =========================================================================
    # PHASE 9: MEMORY SCANNING
    # =========================================================================
    
    async def hook_memory_scan(
        self,
        pids: List[int] = None,
        yara_rules: List[str] = None,
        patterns: List[str] = None,
        options: ScanOptions = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Memory scanning for IOCs.
        
        Args:
            pids: Process IDs to scan (None = all accessible)
            yara_rules: YARA rule paths
            patterns: Hex patterns to search
            options: Scan configuration
        
        Returns:
            List of MemoryFinding dictionaries
        """
        # Delegate to memory scanner service
        results = await self.memory_scanner.scan_memory(
            pids=pids,
            yara_rules=yara_rules,
            patterns=patterns,
            options=options
        )
        
        self.findings["memory"] = results
        return [r.model_dump() if hasattr(r, 'model_dump') else r for r in results]
    
    # =========================================================================
    # PHASE 10: QUICK SCAN MODE
    # =========================================================================
    
    async def hook_quick_scan(
        self,
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Quick IOC scan - fast assessment.
        
        Focuses on:
        - Running processes
        - Active network connections
        - Key persistence locations
        - Critical system files
        
        Returns:
            Simplified IoCScanResult
        """
        # Delegate to scan orchestrator service
        return await self.scan_orchestrator.quick_scan(options=options, **kwargs)
    
    # =========================================================================
    # PHASE 11: TARGETED SCAN
    # =========================================================================
    
    async def hook_targeted_scan(
        self,
        targets: Dict[str, Any],
        options: ScanOptions = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Targeted IOC scan for specific indicators.
        
        Args:
            targets: Dictionary with specific targets:
                - hashes: List of file hashes to find
                - ips: List of IPs to check
                - domains: List of domains to check
                - processes: List of process names
                - files: List of file paths
        
        Returns:
            IoCScanResult focused on targets
        """
        # Delegate to scan orchestrator service
        return await self.scan_orchestrator.targeted_scan(
            targets=targets, options=options, **kwargs
        )
    
    # =========================================================================
    # EXPORT & REPORTING
    # =========================================================================
    
    def export_to_json(self, result: IoCScanResult, filepath: str = None) -> str:
        """Export scan results to JSON."""
        return self.export_service.export_to_json(result, filepath)
    
    def export_to_csv(self, result: IoCScanResult, filepath: str) -> str:
        """Export scan results to CSV."""
        return self.export_service.export_to_csv(result, filepath)
    
    def export_to_stix(self, result: IoCScanResult) -> Dict[str, Any]:
        """Export scan results to STIX 2.1 format."""
        return self.export_service.export_to_stix(result)
    
    def generate_report(self, result: IoCScanResult) -> str:
        """Generate human-readable report."""
        return self.export_service.generate_report(result)
    
    # =========================================================================
    # UTILITY METHODS
    # =========================================================================
    
    async def hook_hash_lookup(
        self,
        hashes: List[str],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Look up hashes against loaded IOC database."""
        return await self.lookup_service.lookup_hashes(hashes)
    
    async def hook_ip_lookup(
        self,
        ips: List[str],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Look up IPs against loaded IOC database."""
        return await self.lookup_service.lookup_ips(ips)
    
    async def hook_domain_lookup(
        self,
        domains: List[str],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """Look up domains against loaded IOC database."""
        return await self.lookup_service.lookup_domains(domains)
    
    async def hook_yara_scan(
        self,
        paths: List[str] = None,
        rules_paths: List[str] = None,
        file_paths: List[str] = None,
        yara_rules_paths: List[str] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """YARA rules scanning."""
        return await self.yara_service.scan_with_yara(
            paths=paths,
            rules_paths=rules_paths,
            file_paths=file_paths,
            yara_rules_paths=yara_rules_paths
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get current IOC database statistics."""
        return self.statistics_service.get_statistics()
