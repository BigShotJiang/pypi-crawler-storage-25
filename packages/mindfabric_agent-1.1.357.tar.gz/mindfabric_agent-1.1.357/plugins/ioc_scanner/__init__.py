"""IOC Scanner Plugin"""

from .ioc_scanner import IocScannerPlugin

__all__ = ['IocScannerPlugin']

