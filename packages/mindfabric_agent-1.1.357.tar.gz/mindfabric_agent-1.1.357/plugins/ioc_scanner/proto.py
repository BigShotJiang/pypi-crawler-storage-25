"""
IOC Scanner Plugin - Protocol Models (Complete Edition)

Comprehensive data models for IOC detection covering:
- 15+ IOC types (hashes, IPs, domains, URLs, files, registry, etc.)
- 50+ MITRE ATT&CK techniques
- Memory, process, network, filesystem analysis
- Threat Intelligence feed integration
- YARA rules support
- AI/ML classification
"""

from enum import Enum
from typing import List, Optional, Dict, Any, Set, Union
from pydantic import BaseModel, Field
from datetime import datetime
from plugins.reproduction import ReproStep


# =============================================================================
# ENUMS
# =============================================================================

class IoCType(str, Enum):
    """Types of Indicators of Compromise."""
    # File-based
    MD5 = "md5"
    SHA1 = "sha1"
    SHA256 = "sha256"
    SHA512 = "sha512"
    SSDEEP = "ssdeep"
    IMPHASH = "imphash"
    PEHASH = "pehash"
    TLSH = "tlsh"
    FILE_NAME = "file_name"
    FILE_PATH = "file_path"
    FILE_SIZE = "file_size"
    # Generic aliases used by some databases/modules
    FILE_HASH = "file_hash"
    
    # Network-based
    IP_ADDRESS = "ip_address"
    IP_V4 = "ipv4"
    IP_V6 = "ipv6"
    DOMAIN = "domain"
    URL = "url"
    EMAIL = "email"
    USER_AGENT = "user_agent"
    JA3 = "ja3"
    JA3S = "ja3s"
    JARM = "jarm"
    
    # Process-based
    PROCESS_NAME = "process_name"
    PROCESS_CMDLINE = "process_cmdline"
    PROCESS_HASH = "process_hash"
    MUTEX = "mutex"
    NAMED_PIPE = "named_pipe"
    
    # Registry (Windows)
    REGISTRY_KEY = "registry_key"
    REGISTRY_VALUE = "registry_value"
    
    # Memory
    MEMORY_PATTERN = "memory_pattern"
    YARA_RULE = "yara_rule"
    SIGMA_RULE = "sigma_rule"
    
    # Behavior
    TTP = "ttp"
    ATTACK_PATTERN = "attack_pattern"
    
    # Certificate
    CERT_SERIAL = "cert_serial"
    CERT_THUMBPRINT = "cert_thumbprint"
    CERT_ISSUER = "cert_issuer"
    CERT_SUBJECT = "cert_subject"
    
    # Other
    CVE = "cve"
    ASN = "asn"
    CIDR = "cidr"
    BITCOIN_ADDRESS = "bitcoin_address"
    CUSTOM = "custom"


class SeverityLevel(str, Enum):
    """Severity levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ConfidenceLevel(str, Enum):
    """Confidence levels for detections."""
    CONFIRMED = "confirmed"      # 100% match
    HIGH = "high"                # 90%+ match
    MEDIUM = "medium"            # 70-90% match
    LOW = "low"                  # 50-70% match
    SUSPICIOUS = "suspicious"    # < 50% match


class ThreatCategory(str, Enum):
    """Categories of threats."""
    MALWARE = "malware"
    RANSOMWARE = "ransomware"
    TROJAN = "trojan"
    BACKDOOR = "backdoor"
    RAT = "rat"
    ROOTKIT = "rootkit"
    BOTNET = "botnet"
    CRYPTOMINER = "cryptominer"
    SPYWARE = "spyware"
    ADWARE = "adware"
    WORM = "worm"
    DROPPER = "dropper"
    LOADER = "loader"
    WEBSHELL = "webshell"
    APT = "apt"
    PHISHING = "phishing"
    EXPLOIT = "exploit"
    C2 = "c2"
    LATERAL_MOVEMENT = "lateral_movement"
    DATA_EXFILTRATION = "data_exfiltration"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DEFENSE_EVASION = "defense_evasion"
    CREDENTIAL_ACCESS = "credential_access"
    DISCOVERY = "discovery"
    UNKNOWN = "unknown"


class FeedFormat(str, Enum):
    """Threat Intelligence feed formats."""
    STIX_1 = "stix_1"
    STIX_2 = "stix_2"
    TAXII = "taxii"
    OPENIOC = "openioc"
    CSV = "csv"
    JSON = "json"
    TXT = "txt"
    PLAIN_TEXT = "plain_text"
    MISP = "misp"
    YARA = "yara"
    SIGMA = "sigma"
    SNORT = "snort"
    SURICATA = "suricata"
    CUSTOM = "custom"


class FeedSource(str, Enum):
    """Known Threat Intelligence feed sources."""
    ALIENTVAULT_OTX = "alienvault_otx"
    ABUSE_CH = "abuse_ch"
    MALWARE_BAZAAR = "malware_bazaar"
    URLHAUS = "urlhaus"
    FEODO_TRACKER = "feodo_tracker"
    SSLBL = "sslbl"
    THREATFOX = "threatfox"
    VIRUSTOTAL = "virustotal"
    MISP = "misp"
    OPENCTI = "opencti"
    CIRCL = "circl"
    EMERGING_THREATS = "emerging_threats"
    SPAMHAUS = "spamhaus"
    TALOS = "talos"
    CUSTOM = "custom"


class ProcessInjectionType(str, Enum):
    """Types of process injection."""
    DLL_INJECTION = "dll_injection"
    PROCESS_HOLLOWING = "process_hollowing"
    THREAD_HIJACKING = "thread_hijacking"
    APC_INJECTION = "apc_injection"
    ATOM_BOMBING = "atom_bombing"
    PROCESS_DOPPELGANGING = "process_doppelganging"
    TRANSACTED_HOLLOWING = "transacted_hollowing"
    PE_INJECTION = "pe_injection"
    SHELLCODE_INJECTION = "shellcode_injection"
    REFLECTIVE_DLL = "reflective_dll"
    HOOK_INJECTION = "hook_injection"
    EXTRA_WINDOW_MEMORY = "extra_window_memory"


class PersistenceType(str, Enum):
    """Types of persistence mechanisms."""
    # Linux
    CRON = "cron"
    SYSTEMD = "systemd"
    INIT_SCRIPT = "init_script"
    RC_LOCAL = "rc_local"
    BASHRC = "bashrc"
    PROFILE = "profile"
    LD_PRELOAD = "ld_preload"
    SSH_AUTHORIZED_KEYS = "ssh_authorized_keys"
    KERNEL_MODULE = "kernel_module"
    
    # Windows
    RUN_KEY = "run_key"
    RUNONCE_KEY = "runonce_key"
    STARTUP_FOLDER = "startup_folder"
    SCHEDULED_TASK = "scheduled_task"
    SERVICE = "service"
    WMI_SUBSCRIPTION = "wmi_subscription"
    OFFICE_ADDIN = "office_addin"
    BROWSER_EXTENSION = "browser_extension"
    DLL_SEARCH_ORDER = "dll_search_order"
    COM_HIJACKING = "com_hijacking"
    BOOTKIT = "bootkit"
    
    # Cross-platform
    WEBSHELL = "webshell"
    IMPLANT = "implant"


class NetworkProtocol(str, Enum):
    """Network protocols."""
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    HTTP = "http"
    HTTPS = "https"
    DNS = "dns"
    SSH = "ssh"
    RDP = "rdp"
    SMB = "smb"
    FTP = "ftp"
    SMTP = "smtp"
    IMAP = "imap"
    POP3 = "pop3"
    LDAP = "ldap"
    KERBEROS = "kerberos"
    IRC = "irc"
    TOR = "tor"
    I2P = "i2p"
    CUSTOM = "custom"


class MitreTactic(str, Enum):
    """MITRE ATT&CK Tactics."""
    RECONNAISSANCE = "reconnaissance"
    RESOURCE_DEVELOPMENT = "resource_development"
    INITIAL_ACCESS = "initial_access"
    EXECUTION = "execution"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DEFENSE_EVASION = "defense_evasion"
    CREDENTIAL_ACCESS = "credential_access"
    DISCOVERY = "discovery"
    LATERAL_MOVEMENT = "lateral_movement"
    COLLECTION = "collection"
    COMMAND_AND_CONTROL = "command_and_control"
    EXFILTRATION = "exfiltration"
    IMPACT = "impact"


class ScanStatus(str, Enum):
    """Scan status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PARTIAL = "partial"


class ActionTaken(str, Enum):
    """Actions taken on findings."""
    NONE = "none"
    LOGGED = "logged"
    ALERTED = "alerted"
    QUARANTINED = "quarantined"
    KILLED = "killed"
    BLOCKED = "blocked"
    DELETED = "deleted"
    RESTORED = "restored"


# =============================================================================
# SUPPORTING MODELS
# =============================================================================

class ExploitationCommands(BaseModel):
    """Explicit detection/verification commands for UI display."""
    server: Optional[str] = Field(None, description="Target server")
    ip: Optional[str] = Field(None, description="Target IP")
    commands: List[str] = Field(default_factory=list, description="Shell commands to detect/verify IOC")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class HashSet(BaseModel):
    """Collection of file hashes."""
    md5: Optional[str] = None
    sha1: Optional[str] = None
    sha256: Optional[str] = None
    sha512: Optional[str] = None
    ssdeep: Optional[str] = None
    imphash: Optional[str] = None
    tlsh: Optional[str] = None


class FileMetadata(BaseModel):
    """File metadata for analysis."""
    path: str
    name: str
    size: int = 0
    created: Optional[datetime] = None
    modified: Optional[datetime] = None
    accessed: Optional[datetime] = None
    owner: Optional[str] = None
    group: Optional[str] = None
    permissions: Optional[str] = None
    is_hidden: bool = False
    is_system: bool = False
    is_executable: bool = False
    is_symlink: bool = False
    symlink_target: Optional[str] = None
    file_type: Optional[str] = None
    mime_type: Optional[str] = None
    magic: Optional[str] = None
    entropy: Optional[float] = None
    hashes: Optional[HashSet] = None


class PEInfo(BaseModel):
    """PE (Windows executable) analysis info."""
    is_pe: bool = False
    is_dll: bool = False
    is_driver: bool = False
    is_64bit: bool = False
    machine_type: Optional[str] = None
    compile_time: Optional[datetime] = None
    entry_point: Optional[str] = None
    image_base: Optional[str] = None
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    imports: List[str] = Field(default_factory=list)
    exports: List[str] = Field(default_factory=list)
    resources: List[Dict[str, Any]] = Field(default_factory=list)
    version_info: Optional[Dict[str, str]] = None
    is_packed: bool = False
    packer_name: Optional[str] = None
    is_signed: bool = False
    signature_valid: bool = False
    signer: Optional[str] = None
    imphash: Optional[str] = None
    rich_header_hash: Optional[str] = None
    suspicious_imports: List[str] = Field(default_factory=list)
    suspicious_sections: List[str] = Field(default_factory=list)


class ELFInfo(BaseModel):
    """ELF (Linux executable) analysis info."""
    is_elf: bool = False
    is_shared_object: bool = False
    is_64bit: bool = False
    machine_type: Optional[str] = None
    entry_point: Optional[str] = None
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    symbols: List[str] = Field(default_factory=list)
    libraries: List[str] = Field(default_factory=list)
    is_stripped: bool = False
    is_static: bool = False
    has_debug_info: bool = False
    interpreter: Optional[str] = None


class YaraMatch(BaseModel):
    """YARA rule match."""
    rule_name: str
    rule_namespace: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    meta: Dict[str, Any] = Field(default_factory=dict)
    strings: List[Dict[str, Any]] = Field(default_factory=list)
    match_offset: Optional[int] = None
    match_length: Optional[int] = None


class GeoIPInfo(BaseModel):
    """GeoIP information."""
    country: Optional[str] = None
    country_code: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    postal_code: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    timezone: Optional[str] = None
    isp: Optional[str] = None
    org: Optional[str] = None
    asn: Optional[int] = None
    asn_org: Optional[str] = None


class DNSRecord(BaseModel):
    """DNS record information."""
    query: str
    record_type: str  # A, AAAA, MX, TXT, CNAME, NS, etc.
    answer: str
    ttl: Optional[int] = None
    timestamp: Optional[datetime] = None


class TLSInfo(BaseModel):
    """TLS/SSL certificate information."""
    version: Optional[str] = None
    cipher_suite: Optional[str] = None
    serial_number: Optional[str] = None
    thumbprint: Optional[str] = None
    issuer: Optional[str] = None
    subject: Optional[str] = None
    not_before: Optional[datetime] = None
    not_after: Optional[datetime] = None
    is_expired: bool = False
    is_self_signed: bool = False
    san: List[str] = Field(default_factory=list)
    ja3: Optional[str] = None
    ja3s: Optional[str] = None
    jarm: Optional[str] = None


class MitreAttackTechnique(BaseModel):
    """MITRE ATT&CK technique reference."""
    technique_id: str  # e.g., T1059.001
    technique_name: str
    tactic: MitreTactic
    sub_technique: Optional[str] = None
    description: Optional[str] = None
    detection: Optional[str] = None
    mitigation: Optional[str] = None
    data_sources: List[str] = Field(default_factory=list)
    platforms: List[str] = Field(default_factory=list)
    url: Optional[str] = None


class ThreatActor(BaseModel):
    """Threat actor information."""
    name: str
    aliases: List[str] = Field(default_factory=list)
    description: Optional[str] = None
    motivation: Optional[str] = None
    sophistication: Optional[str] = None
    resource_level: Optional[str] = None
    primary_motivation: Optional[str] = None
    secondary_motivations: List[str] = Field(default_factory=list)
    associated_groups: List[str] = Field(default_factory=list)
    associated_campaigns: List[str] = Field(default_factory=list)
    ttps: List[str] = Field(default_factory=list)
    target_sectors: List[str] = Field(default_factory=list)
    target_countries: List[str] = Field(default_factory=list)


class MalwareFamily(BaseModel):
    """Malware family information."""
    name: str
    aliases: List[str] = Field(default_factory=list)
    category: ThreatCategory = ThreatCategory.MALWARE
    description: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    ttps: List[str] = Field(default_factory=list)
    associated_actors: List[str] = Field(default_factory=list)
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    references: List[str] = Field(default_factory=list)


# =============================================================================
# IOC MODELS
# =============================================================================

class IoCIndicator(BaseModel):
    """Individual IOC indicator."""
    value: str
    type: IoCType
    confidence: float = 0.5  # 0.0 - 1.0
    severity: SeverityLevel = SeverityLevel.MEDIUM
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    malware_family: Optional[str] = None
    threat_actor: Optional[str] = None
    campaign: Optional[str] = None
    
    # Metadata
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    ttps: List[str] = Field(default_factory=list)
    
    # Source
    source: Optional[str] = None
    source_url: Optional[str] = None
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    
    # Expiration
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    is_active: bool = True
    
    # Related
    related_indicators: List[str] = Field(default_factory=list)


class IoCMatch(BaseModel):
    """IOC match result."""
    # What was found
    indicator: IoCIndicator
    target: str  # Path, IP, process name, etc.
    target_type: str  # file, process, network, registry, memory
    
    # Match details
    match_type: str = "exact"  # exact, partial, fuzzy, yara, sigma
    match_confidence: float = 1.0
    match_context: Optional[str] = None
    match_offset: Optional[int] = None
    match_length: Optional[int] = None
    
    # Severity assessment
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.HIGH
    
    # Additional context
    metadata: Dict[str, Any] = Field(default_factory=dict)
    hashes: Optional[HashSet] = None
    file_info: Optional[FileMetadata] = None
    yara_matches: List[YaraMatch] = Field(default_factory=list)
    
    # MITRE mapping
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to verify/detect this IOC"
    )
    
    # Timestamps
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Actions
    action_taken: ActionTaken = ActionTaken.LOGGED
    action_details: Optional[str] = None


# =============================================================================
# FILE SYSTEM MODELS
# =============================================================================

class SuspiciousFileLocation(BaseModel):
    """Suspicious file location finding."""
    path: str
    reason: str
    severity: SeverityLevel = SeverityLevel.MEDIUM
    expected_content: Optional[str] = None
    found_content: Optional[str] = None
    mitre_technique: Optional[str] = None


class HiddenFile(BaseModel):
    """Hidden file finding."""
    path: str
    hide_method: str  # dot_prefix, attribute, alternate_stream, rootkit
    is_malicious: bool = False
    metadata: Optional[FileMetadata] = None


class ModifiedBinary(BaseModel):
    """Modified system binary finding."""
    path: str
    original_hash: Optional[str] = None
    current_hash: str
    package_name: Optional[str] = None
    is_tampered: bool = True
    severity: SeverityLevel = SeverityLevel.HIGH


class FileSystemFinding(BaseModel):
    """Comprehensive file system finding."""
    finding_type: str  # ioc_match, suspicious_location, hidden_file, modified_binary, yara_match
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # File info
    file_path: str
    file_metadata: Optional[FileMetadata] = None
    pe_info: Optional[PEInfo] = None
    elf_info: Optional[ELFInfo] = None
    
    # Match info
    ioc_match: Optional[IoCMatch] = None
    yara_matches: List[YaraMatch] = Field(default_factory=list)
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    malware_family: Optional[str] = None
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to detect/analyze this file IOC"
    )
    
    # Details
    description: str = ""
    evidence: List[str] = Field(default_factory=list)
    remediation: Optional[str] = None
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# PROCESS MODELS
# =============================================================================

class ProcessInfo(BaseModel):
    """Detailed process information."""
    pid: int
    ppid: Optional[int] = None
    name: str
    exe: Optional[str] = None
    cmdline: Optional[str] = None
    cwd: Optional[str] = None
    username: Optional[str] = None
    uid: Optional[int] = None
    gid: Optional[int] = None
    
    # Timing
    create_time: Optional[datetime] = None
    cpu_time: Optional[float] = None
    
    # Resources
    memory_rss: Optional[int] = None
    memory_vms: Optional[int] = None
    num_threads: Optional[int] = None
    num_fds: Optional[int] = None
    
    # Network
    connections: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Files
    open_files: List[str] = Field(default_factory=list)
    
    # Environment
    environ: Dict[str, str] = Field(default_factory=dict)
    
    # Hashes
    exe_hash: Optional[HashSet] = None
    
    # Status
    status: Optional[str] = None
    is_running: bool = True


class ProcessTreeNode(BaseModel):
    """Process tree node."""
    process: ProcessInfo
    children: List["ProcessTreeNode"] = Field(default_factory=list)
    depth: int = 0


class InjectionEvidence(BaseModel):
    """Evidence of code injection."""
    injection_type: ProcessInjectionType
    target_pid: int
    target_process: str
    source_pid: Optional[int] = None
    source_process: Optional[str] = None
    injected_code: Optional[str] = None  # hex or base64
    memory_region: Optional[str] = None
    evidence: List[str] = Field(default_factory=list)
    confidence: float = 0.5


class ProcessFinding(BaseModel):
    """Comprehensive process finding."""
    finding_type: str  # ioc_match, injection, suspicious_behavior, anomaly
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Process info
    process: ProcessInfo
    parent_process: Optional[ProcessInfo] = None
    child_processes: List[ProcessInfo] = Field(default_factory=list)
    
    # Match info
    ioc_match: Optional[IoCMatch] = None
    injection_evidence: Optional[InjectionEvidence] = None
    
    # Behavior
    suspicious_behaviors: List[str] = Field(default_factory=list)
    anomalies: List[str] = Field(default_factory=list)
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to detect/analyze this process IOC"
    )
    
    # Details
    description: str = ""
    reason: str = ""
    evidence: List[str] = Field(default_factory=list)
    remediation: Optional[str] = None
    
    # Actions
    action_taken: ActionTaken = ActionTaken.LOGGED
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# NETWORK MODELS
# =============================================================================

class NetworkConnection(BaseModel):
    """Network connection information."""
    local_address: str
    local_port: int
    remote_address: Optional[str] = None
    remote_port: Optional[int] = None
    protocol: NetworkProtocol = NetworkProtocol.TCP
    status: Optional[str] = None  # ESTABLISHED, LISTEN, etc.
    pid: Optional[int] = None
    process_name: Optional[str] = None
    
    # Remote info
    remote_hostname: Optional[str] = None
    remote_geoip: Optional[GeoIPInfo] = None
    
    # TLS info
    tls_info: Optional[TLSInfo] = None
    
    # Timing
    established_at: Optional[datetime] = None
    bytes_sent: Optional[int] = None
    bytes_received: Optional[int] = None


class DNSQuery(BaseModel):
    """DNS query information."""
    query_name: str
    query_type: str
    answers: List[DNSRecord] = Field(default_factory=list)
    timestamp: Optional[datetime] = None
    source_ip: Optional[str] = None
    source_port: Optional[int] = None
    is_dga: bool = False
    dga_score: Optional[float] = None
    is_tunneling: bool = False


class BeaconingPattern(BaseModel):
    """C2 beaconing pattern detection."""
    destination: str  # IP or domain
    destination_port: int
    interval_mean: float  # seconds
    interval_std: float
    jitter: float
    beacon_count: int
    first_seen: datetime
    last_seen: datetime
    confidence: float = 0.5
    is_c2: bool = False


class NetworkFinding(BaseModel):
    """Comprehensive network finding."""
    finding_type: str  # ioc_match, c2_beacon, data_exfil, lateral_movement, anomaly
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Connection info
    connection: Optional[NetworkConnection] = None
    dns_query: Optional[DNSQuery] = None
    beaconing: Optional[BeaconingPattern] = None
    
    # Match info
    ioc_match: Optional[IoCMatch] = None
    
    # Remote endpoint
    remote_ip: Optional[str] = None
    remote_port: Optional[int] = None
    remote_domain: Optional[str] = None
    remote_geoip: Optional[GeoIPInfo] = None
    
    # Associated process
    process_pid: Optional[int] = None
    process_name: Optional[str] = None
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to detect/block this network IOC"
    )
    
    # Details
    description: str = ""
    reason: str = ""
    evidence: List[str] = Field(default_factory=list)
    remediation: Optional[str] = None
    
    # Actions
    action_taken: ActionTaken = ActionTaken.LOGGED
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# MEMORY MODELS
# =============================================================================

class MemoryRegion(BaseModel):
    """Memory region information."""
    address_start: str
    address_end: str
    size: int
    permissions: str  # rwxp
    path: Optional[str] = None
    is_executable: bool = False
    is_writable: bool = False
    is_private: bool = False
    is_anonymous: bool = False


class MemoryFinding(BaseModel):
    """Memory analysis finding."""
    finding_type: str  # injected_code, suspicious_string, shellcode, hook
    severity: SeverityLevel = SeverityLevel.HIGH
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Location
    pid: int
    process_name: str
    memory_region: Optional[MemoryRegion] = None
    offset: Optional[int] = None
    
    # Content
    matched_content: Optional[str] = None  # hex or base64
    matched_strings: List[str] = Field(default_factory=list)
    yara_matches: List[YaraMatch] = Field(default_factory=list)
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to analyze/dump memory for this IOC"
    )
    
    # Details
    description: str = ""
    evidence: List[str] = Field(default_factory=list)
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# PERSISTENCE MODELS
# =============================================================================

class PersistenceFinding(BaseModel):
    """Persistence mechanism finding."""
    persistence_type: PersistenceType
    severity: SeverityLevel = SeverityLevel.HIGH
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Location
    location: str  # Path, registry key, etc.
    value: Optional[str] = None
    
    # Associated file/process
    file_path: Optional[str] = None
    file_hash: Optional[str] = None
    process_pid: Optional[int] = None
    
    # IOC match
    ioc_match: Optional[IoCMatch] = None
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    
    # MITRE
    mitre_technique: str = ""  # e.g., T1053.003 for cron
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to detect/remove this persistence IOC"
    )
    
    # Details
    description: str = ""
    is_legitimate: bool = False
    evidence: List[str] = Field(default_factory=list)
    remediation: Optional[str] = None
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# LOG MODELS
# =============================================================================

class LogEntry(BaseModel):
    """Parsed log entry."""
    source: str  # Log file path or name
    timestamp: Optional[datetime] = None
    level: Optional[str] = None  # INFO, WARNING, ERROR, etc.
    message: str
    raw_line: str
    line_number: Optional[int] = None
    
    # Parsed fields
    fields: Dict[str, Any] = Field(default_factory=dict)
    
    # Source info
    hostname: Optional[str] = None
    program: Optional[str] = None
    pid: Optional[int] = None
    user: Optional[str] = None
    
    # Network (if applicable)
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None


class LogFinding(BaseModel):
    """Log analysis finding."""
    finding_type: str  # ioc_match, attack_pattern, anomaly, correlation
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Log info
    log_source: str
    log_entries: List[LogEntry] = Field(default_factory=list)
    
    # Match info
    ioc_match: Optional[IoCMatch] = None
    matched_pattern: Optional[str] = None
    
    # Classification
    threat_category: Optional[ThreatCategory] = None
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to search logs for this IOC"
    )
    
    # Details
    description: str = ""
    evidence: List[str] = Field(default_factory=list)
    
    # Correlation
    correlated_events: List[str] = Field(default_factory=list)
    correlation_id: Optional[str] = None
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# TTP MODELS
# =============================================================================

class TTPFinding(BaseModel):
    """MITRE ATT&CK TTP finding."""
    # Technique info
    technique: MitreAttackTechnique
    
    # Assessment
    severity: SeverityLevel = SeverityLevel.MEDIUM
    confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM
    
    # Evidence
    evidence_type: str  # file, process, network, log, memory
    evidence_source: str
    evidence_details: List[str] = Field(default_factory=list)
    
    # Related findings
    related_file_findings: List[str] = Field(default_factory=list)
    related_process_findings: List[str] = Field(default_factory=list)
    related_network_findings: List[str] = Field(default_factory=list)
    
    # Context
    threat_actor: Optional[str] = None
    campaign: Optional[str] = None
    malware_family: Optional[str] = None
    
    # 🔴 EXPLICIT DETECTION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to detect this TTP"
    )
    
    # Details
    description: str = ""
    remediation: Optional[str] = None
    
    detected_at: datetime = Field(default_factory=datetime.utcnow)


class KillChainPhase(BaseModel):
    """Cyber Kill Chain phase."""
    phase: str  # reconnaissance, weaponization, delivery, exploitation, installation, c2, actions
    findings: List[TTPFinding] = Field(default_factory=list)
    confidence: float = 0.0


class AttackTimeline(BaseModel):
    """Attack timeline reconstruction."""
    events: List[Dict[str, Any]] = Field(default_factory=list)
    first_activity: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    kill_chain_phases: List[KillChainPhase] = Field(default_factory=list)


# =============================================================================
# THREAT INTELLIGENCE MODELS
# =============================================================================

class TIFeed(BaseModel):
    """Threat Intelligence feed configuration."""
    name: str
    source: FeedSource
    format: FeedFormat
    url: Optional[str] = None
    api_key: Optional[str] = None
    
    # Update settings
    update_interval: int = 3600  # seconds
    last_updated: Optional[datetime] = None
    last_status: Optional[str] = None
    
    # Content
    ioc_count: int = 0
    ioc_types: List[IoCType] = Field(default_factory=list)
    
    # Quality
    reliability: float = 0.5  # 0.0 - 1.0
    is_active: bool = True


class TIEnrichment(BaseModel):
    """Threat Intelligence enrichment result."""
    indicator: str
    indicator_type: IoCType
    
    # Scores
    reputation_score: Optional[float] = None  # -100 to 100
    risk_score: Optional[float] = None  # 0 to 100
    
    # Classification
    is_malicious: bool = False
    threat_categories: List[ThreatCategory] = Field(default_factory=list)
    malware_families: List[str] = Field(default_factory=list)
    threat_actors: List[str] = Field(default_factory=list)
    campaigns: List[str] = Field(default_factory=list)
    
    # Context
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    sightings_count: int = 0
    
    # Related
    related_indicators: List[str] = Field(default_factory=list)
    ttps: List[str] = Field(default_factory=list)
    
    # Sources
    sources: List[str] = Field(default_factory=list)
    references: List[str] = Field(default_factory=list)
    
    # GeoIP (for IPs)
    geoip: Optional[GeoIPInfo] = None
    
    # WHOIS (for domains)
    whois: Optional[Dict[str, Any]] = None
    
    enriched_at: datetime = Field(default_factory=datetime.utcnow)


class TIResult(BaseModel):
    """Threat Intelligence operation result."""
    operation: str  # sync, enrich, search
    status: str  # success, partial, failed
    
    # Feed info
    feeds_processed: List[str] = Field(default_factory=list)
    feeds_failed: List[str] = Field(default_factory=list)
    
    # Stats
    indicators_loaded: int = 0
    indicators_new: int = 0
    indicators_updated: int = 0
    indicators_expired: int = 0
    
    # Enrichment results
    enrichments: List[TIEnrichment] = Field(default_factory=list)
    
    # Errors
    errors: List[str] = Field(default_factory=list)
    
    # Timing
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None


# =============================================================================
# AI/ML MODELS
# =============================================================================

class AIClassification(BaseModel):
    """AI classification result."""
    model_name: str
    model_version: Optional[str] = None
    
    # Classification
    label: str
    confidence: float = 0.0
    probabilities: Dict[str, float] = Field(default_factory=dict)
    
    # Features
    features_used: List[str] = Field(default_factory=list)
    feature_importance: Dict[str, float] = Field(default_factory=dict)
    
    # Explanation
    explanation: Optional[str] = None
    
    classified_at: datetime = Field(default_factory=datetime.utcnow)


class AnomalyScore(BaseModel):
    """Anomaly detection score."""
    model_name: str
    anomaly_score: float  # 0.0 - 1.0
    is_anomaly: bool = False
    threshold: float = 0.5
    
    # Contributing factors
    factors: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Baseline comparison
    baseline_mean: Optional[float] = None
    baseline_std: Optional[float] = None
    deviation: Optional[float] = None


class AIAnalysisResult(BaseModel):
    """AI/ML analysis result."""
    analysis_type: str  # classification, anomaly_detection, clustering, nlp
    
    # Results
    classification: Optional[AIClassification] = None
    anomaly_score: Optional[AnomalyScore] = None
    
    # NLP results (for log analysis)
    entities: List[Dict[str, Any]] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)
    summary: Optional[str] = None
    sentiment: Optional[str] = None
    
    # Recommendations
    recommendations: List[str] = Field(default_factory=list)
    
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# CONFIGURATION MODELS
# =============================================================================

# Default paths to exclude during file system scanning (performance optimization)
DEFAULT_EXCLUDE_PATHS = [
    "/proc", "/sys", "/dev", "/run", "/tmp",
    "/var/lib/docker", "/var/lib/containers",
    "/snap", "/boot/efi", "/lost+found",
    "/var/cache", "/var/tmp"
]

class ScanScope(BaseModel):
    """Scan scope configuration."""
    # File system
    scan_file_system: bool = True
    file_paths: List[str] = Field(default_factory=lambda: ["/"])
    exclude_paths: List[str] = Field(default_factory=lambda: DEFAULT_EXCLUDE_PATHS.copy())
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    follow_symlinks: bool = False
    scan_hidden: bool = True
    
    # Processes
    scan_processes: bool = True
    process_names: Optional[List[str]] = None  # None = all
    exclude_processes: List[str] = Field(default_factory=list)
    scan_process_memory: bool = False
    
    # Network
    scan_network: bool = True
    check_dns: bool = True
    check_c2_beaconing: bool = False
    
    # Logs
    scan_logs: bool = True
    log_paths: List[str] = Field(default_factory=lambda: ["/var/log"])
    log_max_age_days: int = 7
    # Log scanning performance controls (prevents first run from timing out on huge auth.log).
    # These defaults are conservative for small hosts and internet-exposed servers.
    log_checkpoint_enabled: bool = True
    log_initial_tail_bytes: int = 5 * 1024 * 1024  # On first sight, scan only last N bytes of a log file
    log_max_lines_per_file: int = 200_000          # Per file per run
    log_max_seconds_per_file: float = 15.0         # Per file per run
    log_max_samples_total_per_file: int = 5_000    # Cap vector_sample growth per file per run
    log_max_samples_per_vector_per_file: int = 1_000
    
    # Memory
    scan_memory: bool = False
    memory_scan_all: bool = False
    
    # Persistence
    scan_persistence: bool = True
    
    # IOC types to check
    ioc_types: Optional[List[IoCType]] = None  # None = all
    
    # Severity threshold
    min_severity: SeverityLevel = SeverityLevel.LOW
    
    # Timeouts
    timeout_seconds: int = 1200  # Reduced from 3600 (1 hour) to 1200 (20 minutes) to prevent agent timeout
    file_timeout_seconds: int = 30
    
    # Performance
    max_concurrent: int = 10
    batch_size: int = 1000


class ScanOptions(BaseModel):
    """Scan options."""
    scope: ScanScope = Field(default_factory=ScanScope)
    
    # IOC sources
    use_builtin_iocs: bool = True
    use_feeds: bool = True
    feed_urls: List[str] = Field(default_factory=list)
    custom_iocs: List[IoCIndicator] = Field(default_factory=list)
    
    # YARA
    use_yara: bool = True
    yara_rules_paths: List[str] = Field(default_factory=list)
    yara_timeout: int = 60
    
    # Hashing
    calculate_hashes: bool = True
    hash_algorithms: List[str] = Field(default_factory=lambda: ["md5", "sha256"])
    
    # AI/ML
    use_ai: bool = False
    ai_classification: bool = False
    ai_anomaly_detection: bool = False
    
    # TI enrichment
    enrich_findings: bool = False
    enrichment_sources: List[str] = Field(default_factory=list)
    
    # Output
    output_format: str = "json"  # json, csv, stix
    output_file: Optional[str] = None
    verbose: bool = False
    
    # Actions
    quarantine_on_critical: bool = False
    kill_malicious_processes: bool = False
    block_malicious_ips: bool = False
    
    # Reporting
    generate_report: bool = True
    include_remediation: bool = True
    include_mitre_mapping: bool = True


# =============================================================================
# RESULT MODELS
# =============================================================================

class ScanSummary(BaseModel):
    """Scan summary statistics."""
    # Counts
    total_files_scanned: int = 0
    total_processes_scanned: int = 0
    total_connections_scanned: int = 0
    total_log_entries_scanned: int = 0
    
    # Findings
    total_findings: int = 0
    critical_findings: int = 0
    high_findings: int = 0
    medium_findings: int = 0
    low_findings: int = 0
    info_findings: int = 0
    
    # By type
    file_findings: int = 0
    process_findings: int = 0
    network_findings: int = 0
    memory_findings: int = 0
    persistence_findings: int = 0
    log_findings: int = 0
    ttp_findings: int = 0
    
    # IOC matches
    ioc_matches: int = 0
    yara_matches: int = 0
    
    # Unique threats
    unique_malware_families: List[str] = Field(default_factory=list)
    unique_threat_actors: List[str] = Field(default_factory=list)
    unique_ttps: List[str] = Field(default_factory=list)


class MitreSummary(BaseModel):
    """MITRE ATT&CK coverage summary."""
    techniques_detected: List[str] = Field(default_factory=list)
    tactics_detected: List[MitreTactic] = Field(default_factory=list)
    technique_count: int = 0
    tactic_count: int = 0
    
    # By tactic
    by_tactic: Dict[str, List[str]] = Field(default_factory=dict)
    
    # Kill chain
    kill_chain_coverage: Dict[str, int] = Field(default_factory=dict)


class ScanMetadata(BaseModel):
    """Scan metadata."""
    scan_id: str
    scan_type: str = "full"  # full, quick, targeted
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    status: ScanStatus = ScanStatus.PENDING
    
    # Target
    target_host: Optional[str] = None
    target_os: Optional[str] = None
    
    # Configuration
    options_hash: Optional[str] = None
    
    # Progress
    progress_percent: int = 0
    current_phase: Optional[str] = None
    
    # Errors
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class IoCScanResult(BaseModel):
    """Complete IOC scan result."""
    # Metadata
    metadata: ScanMetadata
    
    # Summary
    summary: ScanSummary = Field(default_factory=ScanSummary)
    mitre_summary: MitreSummary = Field(default_factory=MitreSummary)
    
    # Findings
    file_findings: List[FileSystemFinding] = Field(default_factory=list)
    process_findings: List[ProcessFinding] = Field(default_factory=list)
    network_findings: List[NetworkFinding] = Field(default_factory=list)
    memory_findings: List[MemoryFinding] = Field(default_factory=list)
    persistence_findings: List[PersistenceFinding] = Field(default_factory=list)
    log_findings: List[LogFinding] = Field(default_factory=list)
    ttp_findings: List[TTPFinding] = Field(default_factory=list)
    
    # IOC matches
    all_ioc_matches: List[IoCMatch] = Field(default_factory=list)
    
    # Attack timeline
    attack_timeline: Optional[AttackTimeline] = None
    
    # AI analysis
    ai_results: List[AIAnalysisResult] = Field(default_factory=list)
    
    # TI enrichment
    ti_enrichments: List[TIEnrichment] = Field(default_factory=list)
    
    # Risk assessment
    overall_risk_score: float = 0.0
    overall_severity: SeverityLevel = SeverityLevel.INFO
    is_compromised: bool = False
    
    # Recommendations
    remediation_steps: List[str] = Field(default_factory=list)
    
    # Actions taken
    actions_taken: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )


# =============================================================================
# LEGACY COMPATIBILITY
# =============================================================================

class LegacyIoCMatch(BaseModel):
    """Legacy IOC match format for backward compatibility."""
    target: str
    ioc_type: str
    indicator: str
    meta: Dict[str, Any] = Field(default_factory=dict)
    confidence: Optional[float] = None
    
    @classmethod
    def from_new(cls, match: IoCMatch) -> "LegacyIoCMatch":
        return cls(
            target=match.target,
            ioc_type=match.indicator.type.value,
            indicator=match.indicator.value,
            meta=match.metadata,
            confidence=match.match_confidence
        )


class LegacyProcessFinding(BaseModel):
    """Legacy process finding format."""
    pid: int
    name: str
    cmdline: Optional[str] = None
    suspicious: bool = False
    reason: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class LegacyNetworkFinding(BaseModel):
    """Legacy network finding format."""
    ip: str
    port: int
    protocol: str
    bad: bool = False
    reason: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class LegacyTTPFinding(BaseModel):
    """Legacy TTP finding format."""
    ttp_id: str
    description: str
    confidence: float
    relation: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


class LegacyTIResult(BaseModel):
    """Legacy TI result format."""
    feed: str
    hits: List[LegacyIoCMatch] = Field(default_factory=list)
    feed_time: Optional[str] = None
    update_status: Optional[str] = None
    alerts: List[str] = Field(default_factory=list)


class LegacyAiIocLabel(BaseModel):
    """Legacy AI IOC label format."""
    scope: str
    tags: List[str] = Field(default_factory=list)
    score: float = 0.0
    context: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)


# Update forward references
ProcessTreeNode.model_rebuild()
