"""
Kubernetes Escape Plugin

Plugin for detecting and demonstrating Kubernetes pod escape techniques.
"""

import shlex
import socket
from typing import List
from plugins.base_plugin import BasePlugin
from .proto import EscapeAttemptResult, KubernetesEscapeOutput
from .output_service import OutputService
from .modules.database import (
    KUBERNETES_ESCAPE_DEFAULT_RECOMMENDATIONS,
    KUBERNETES_ESCAPE_NOT_IN_K8S_COMMANDS,
    KUBERNETES_ESCAPE_NOT_IN_K8S_RECOMMENDATIONS,
    KUBERNETES_ESCAPE_NO_ACTION_RECOMMENDATIONS,
)

# Import modules (lazy import to avoid blocking plugin loading)
try:
    from .modules.detection import KubernetesDetector
    from .modules.collectors import (
        BasicEscapeCollector,
        AdvancedEscapeCollector,
        CVEExploitCollector,
        SpecificScenarioCollector,
        AdditionalScenarioCollector
    )
except ImportError as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.warning(f"Some modules failed to load for kubernetes_escape: {e}")
    KubernetesDetector = None
    BasicEscapeCollector = None
    AdvancedEscapeCollector = None
    CVEExploitCollector = None
    SpecificScenarioCollector = None
    AdditionalScenarioCollector = None


class KubernetesEscapePlugin(BasePlugin):
    """
    Plugin for detecting and demonstrating Kubernetes pod escape techniques.
    """
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        
        # Initialize detection module (with error handling)
        self.kubernetes_detector = KubernetesDetector(self) if KubernetesDetector else None
        
        # Initialize collectors
        self.basic_collector = BasicEscapeCollector(self) if BasicEscapeCollector else None
        self.advanced_collector = AdvancedEscapeCollector(self) if AdvancedEscapeCollector else None
        self.cve_collector = CVEExploitCollector(self) if CVEExploitCollector else None
        self.specific_collector = SpecificScenarioCollector(self) if SpecificScenarioCollector else None
        self.additional_collector = AdditionalScenarioCollector(self) if AdditionalScenarioCollector else None
    
    async def run(self):
        """Main entry point."""
        result = await self.hook_escape()

        # Plugin-owned canonical findings generation (avoid hardcodes in security_contract).
        try:
            if hasattr(result, "model_dump"):
                out = result.model_dump()
            elif hasattr(result, "dict"):
                out = result.dict()
            elif isinstance(result, dict):
                out = dict(result)
            else:
                out = {}
        except Exception:
            out = {}

        findings_existing = out.get("findings") or []
        if not (isinstance(findings_existing, list) and len(findings_existing) > 0):
            findings = []
            inside = bool(out.get("inside_kubernetes"))
            methods = out.get("methods") or []
            # Important: do not emit "environment mismatch" or "no actionable findings" as threats.
            # Confirmed breakouts are high severity; vulnerable / partial / exploitable are still real
            # risk signals (misconfiguration or attack surface), not noise — keep them at medium.
            if inside and isinstance(methods, list):
                for m in methods:
                    if not isinstance(m, dict):
                        continue
                    method = m.get("method") or "unknown"
                    status = (m.get("status") or "").lower()
                    msg = m.get("message") or ""

                    if status in ("exploited", "success", "succeeded"):
                        sev = "high"
                        exploit_posture = "confirmed_or_successful"
                    elif status in ("exploitable",):
                        sev = "high"
                        exploit_posture = "exploitable_vector"
                    elif status in ("vulnerable", "partial"):
                        sev = "medium"
                        exploit_posture = "risk_posture_or_partial_exposure"
                    else:
                        continue

                    cmd_list: list[str] = []
                    cmd_obj = m.get("commands") or {}
                    if isinstance(cmd_obj, dict) and isinstance(cmd_obj.get("commands"), list):
                        cmd_list = [str(x) for x in cmd_obj.get("commands") if isinstance(x, (str, int, float)) and str(x).strip()]

                    if not cmd_list:
                        ap = m.get("artifact_path") or m.get("artifactPath")
                        cmd_list = [
                            f"# Read-only triage for technique: {method} (status={status})",
                            "kubectl version --client 2>/dev/null || true",
                            "kubectl auth can-i --list 2>/dev/null | head -n 40 || true",
                            "mount 2>/dev/null | head -n 40 || true",
                            "cat /proc/self/cgroup 2>/dev/null | head -n 20 || true",
                        ]
                        if isinstance(ap, str) and ap.strip():
                            qa = shlex.quote(ap.strip())
                            cmd_list.append(f"ls -la {qa} 2>/dev/null || true")

                    human = (
                        "This pod or container may be able to break out to the underlying node or wider cluster. "
                        "In plain terms: a workload that should stay isolated could gain powers similar to the host server, "
                        "which puts the whole Kubernetes environment at risk."
                    )
                    tail = (msg or "").strip()
                    if tail:
                        human += f" Technical detail: {tail}"
                    else:
                        human += (
                            f' The check reported technique "{method}" with status "{status or "unknown"}". '
                            "Have a platform engineer review node isolation, RBAC, and whether this workload should be privileged."
                        )
                    findings.append({
                        "title": f"Kubernetes escape attempt: {method}",
                        "description": human,
                        "severity": sev,
                        "category": "Kubernetes Escape",
                        "threat_type": "k8s_escape_attempt",
                        "triage_hints": {
                            "host": socket.gethostname(),
                            "technique": str(method)[:200],
                            "status": status,
                            "exploit_confirmation_tier": exploit_posture,
                            "triage_note": (
                                "High-severity rows are confirmed/successful checks or exploitable vectors; "
                                "medium-severity rows are still incidents/risk (vulnerable posture or partial exposure) "
                                "— prioritize by tier, not only by confirmed breakout."
                            ),
                        },
                        "affected_resources": [
                            {
                                "type": "kubernetes_workload",
                                "detail": "Pod/container boundary — risk to node and cluster if escape succeeds",
                                "hostname": socket.gethostname(),
                                "technique": str(method)[:200],
                            }
                        ],
                        "evidence": {
                            "source": "kubernetes_escape.methods",
                            "method": method,
                            "status": status,
                            "exploit_confirmation_tier": exploit_posture,
                            "artifact_path": m.get("artifact_path") or m.get("artifactPath"),
                        },
                        "recommendations": KUBERNETES_ESCAPE_DEFAULT_RECOMMENDATIONS,
                        "exploitation_commands": cmd_list,
                        "remediation_steps": [],
                        "reproduction_steps": m.get("reproduction_steps") or m.get("reproductionSteps"),
                    })

            out["findings"] = findings

        return self.to_security_scan_v1(out)
    
    async def hook_escape(self, **kwargs) -> KubernetesEscapeOutput:
        """
        Real exploitation for all techniques Kubernetes pod escape.
        Returns log for each attempt: status, message, artifact (+ errors).
        """
        methods: List[EscapeAttemptResult] = []
        if self.kubernetes_detector:
            inside = self.kubernetes_detector.is_inside_kubernetes()
        else:
            inside = False
        if not inside:
            return KubernetesEscapeOutput(
                inside_kubernetes=False,
                methods=[EscapeAttemptResult(
                    method='not_in_k8s',
                    status='skipped',
                    message='Agent not running inside Kubernetes.'
                )]
            )

        # Scheduler/default execution should be fast (TTL <= 5 min).
        # In practice, advanced/CVE/specific collectors can take a long time (many subprocess/network attempts).
        # When no explicit options are provided, run only the basic technique checks.
        if not kwargs:
            if self.basic_collector:
                methods.extend(await self.basic_collector.check_all_techniques())
            output_service = OutputService(self)
            return output_service.create_output(methods=methods, inside_kubernetes=True)
        
        # Basic techniques
        if self.basic_collector:
            methods.extend(await self.basic_collector.check_all_techniques())
        
        # Advanced techniques
        if self.advanced_collector:
            methods.extend(await self.advanced_collector.check_all_techniques())
        
        # CVE exploits
        if self.cve_collector:
            methods.extend(await self.cve_collector.check_all_cve_exploits())
        
        # Specific scenarios
        if self.specific_collector:
            methods.extend(await self.specific_collector.check_all_scenarios())
        
        # Additional scenarios
        if self.additional_collector:
            methods.extend(await self.additional_collector.check_all_additional_scenarios())
        
        output_service = OutputService(self)
        return output_service.create_output(methods=methods, inside_kubernetes=True)

