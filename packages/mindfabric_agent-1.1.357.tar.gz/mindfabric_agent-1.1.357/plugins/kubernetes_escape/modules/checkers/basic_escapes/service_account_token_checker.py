"""
Service Account Token Checker

Attempts to use service account token to interact with Kubernetes API.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class ServiceAccountTokenChecker:
    """Checks service account token access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Attempting to use service account token to interact with API."""
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if not os.path.exists(token_path):
            return EscapeAttemptResult(
                method='service_account_token',
                status='not_found',
                message='Service account token not found.'
            )
        
        try:
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            # Attempting to get information using token
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            namespace_path = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"
            
            namespace = (await asyncio.to_thread(lambda: open(namespace_path, "r").read())).strip()
            
            # Checking API access with curl, to evaluate permissions
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            try:
                rc, out, _ = await run_exec(curl_cmd, timeout=5)
                if rc == 0 and "items" in out:
                    pods_data = json.loads(out)
                    pods_count = len(pods_data.get("items", []))
                    
                    # Checking access to secrets (additional permission check)
                    curl_secrets = [
                        'curl', '-s',
                        f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/secrets',
                        '--header', f'Authorization: Bearer {token}',
                        '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                    ]
                    secrets_rc, secrets_out, _ = await run_exec(curl_secrets, timeout=5)
                    has_secrets_access = "items" in secrets_out and secrets_rc == 0
                    
                    status = "exploited" if has_secrets_access else "limited_access"
                    message = f"Access to Kubernetes API: visible {pods_count} pods"
                    if has_secrets_access:
                        message += " and namespace secrets!"
                        demo_next = "Got permissions to read secrets, can extract sensitive data or create new resources."
                        return EscapeAttemptResult(
                            method='service_account_token',
                            status=status,
                            message=message,
                            artifact_content=token[:20] + "...",
                            demo_next_steps=demo_next
                        )
                    else:
                        return EscapeAttemptResult(
                            method='service_account_token',
                            status=status,
                            message=message,
                            artifact_content=token[:20] + "..."
                        )
                else:
                    return EscapeAttemptResult(
                        method='service_account_token',
                        status='restricted',
                        message='Token has limited permissions: no access to API pods.'
                    )
            except Exception as e:
                return EscapeAttemptResult(
                    method='service_account_token',
                    status='error',
                    message=f'Error accessing API: {str(e)}'
                )
        except Exception as e:
            return EscapeAttemptResult(method='service_account_token', status='error', message=str(e))

