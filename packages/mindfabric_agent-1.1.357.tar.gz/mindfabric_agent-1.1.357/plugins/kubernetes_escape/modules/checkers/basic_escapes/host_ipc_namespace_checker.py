"""
Host IPC Namespace Checker

Checks usage of host IPC namespace.
"""

import os
from ....proto import EscapeAttemptResult


class HostIPCNamespaceChecker:
    """Checks host IPC namespace access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check(self) -> EscapeAttemptResult:
        """Checking usage IPC namespace host."""
        try:
            # Checking access to host IPC objects via /proc/sysvipc
            ipc_paths = ['/proc/sysvipc/shm', '/proc/sysvipc/sem', '/proc/sysvipc/msg']
            
            ipc_content = []
            for path in ipc_paths:
                if os.path.exists(path):
                    try:
                        with open(path, 'r') as f:
                            content = f.read()
                            if content.strip() and len(content.splitlines()) > 1:
                                ipc_content.append(f"{path}: {len(content.splitlines())} objects")
                    except Exception:
                        pass
            
            if ipc_content:
                # Trying to create shared memory for checking
                try:
                    import sysv_ipc
                    # Creating shared memory
                    memory = sysv_ipc.SharedMemory(
                        sysv_ipc.IPC_PRIVATE,
                        sysv_ipc.IPC_CREX,
                        size=1024
                    )
                    memory.detach()
                    memory.remove()
                    
                    demo_next = "Access to host IPC allows read memory of other processes, interact with them via IPC mechanisms."
                    return EscapeAttemptResult(
                        method='host_ipc_namespace',
                        status='exploited',
                        message='Pod running with hostIPC=true, has access to host IPC objects!',
                        artifact_content="\n".join(ipc_content),
                        demo_next_steps=demo_next
                    )
                except ImportError:
                    return EscapeAttemptResult(
                        method='host_ipc_namespace',
                        status='suspicious',
                        message='Detected potential host IPC objects (for full checking need sysv_ipc module).',
                        artifact_content="\n".join(ipc_content)
                    )
                except Exception as e:
                    return EscapeAttemptResult(
                        method='host_ipc_namespace',
                        status='suspicious',
                        message=f'Detected IPC objects, but test object creation failed: {str(e)}',
                        artifact_content="\n".join(ipc_content)
                    )
            
            return EscapeAttemptResult(
                method='host_ipc_namespace',
                status='isolated',
                message='Pod uses isolated IPC namespace.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='host_ipc_namespace', status='error', message=str(e))

