"""
Host Network Namespace Checker

Checks usage of host network namespace.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class HostNetworkNamespaceChecker:
    """Checks host network namespace access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking usage of host network namespace."""
        try:
            # Checking via presence of all network interfaces
            interfaces = os.listdir('/sys/class/net/')
            
            # Typical host interfaces
            host_interfaces = ['eth0', 'ens', 'enp', 'eno', 'wlan', 'bond', 'wlp', 'docker0', 'cni', 'flannel', 'calico']
            
            # Checking for presence of typical host interfaces
            host_like = []
            for interface in interfaces:
                for pattern in host_interfaces:
                    if interface.startswith(pattern) and interface != 'eth0':  # eth0 can be in container too
                        host_like.append(interface)
                        break
            
            # Checking if we see lo (loopback interface)
            has_loopback = 'lo' in interfaces
            
            # If suspicious interfaces found or more than 3 interfaces
            if host_like or (len(interfaces) > 3 and has_loopback):
                # Getting information about network interfaces
                try:
                    _, ip_output, _ = await run_exec(['ip', 'addr'], timeout=5)
                    
                    if host_like:
                        demo_next = "Access to host network namespace allows intercept traffic, create network bridges and interfaces."
                        return EscapeAttemptResult(
                            method='host_network_namespace',
                            status='exploited',
                            message=f'Pod running with hostNetwork=true, host interfaces detected: {", ".join(host_like)}',
                            artifact_content=ip_output[:500],
                            demo_next_steps=demo_next
                        )
                    else:
                        return EscapeAttemptResult(
                            method='host_network_namespace',
                            status='suspicious',
                            message=f'Detected unusual number of network interfaces ({len(interfaces)}), possibly hostNetwork=true.',
                            artifact_content=ip_output[:500]
                        )
                except Exception:
                    return EscapeAttemptResult(
                        method='host_network_namespace',
                        status='suspicious',
                        message=f'Detected host interfaces: {", ".join(host_like)}'
                    )
            
            # Checking via ports (if port 22 is open, probably this is hostNetwork)
            try:
                rc, netstat_out, _ = await run_exec(['netstat', '-tulpn'], timeout=5)
                if rc == 0 and ':22 ' in netstat_out:
                    demo_next = "Detected SSH port, can intercept and modify host network traffic."
                    return EscapeAttemptResult(
                        method='host_network_namespace',
                        status='exploited',
                        message='Pod has access to host ports (SSH port 22 detected).',
                        artifact_content=netstat_out[:500],
                        demo_next_steps=demo_next
                    )
            except Exception:
                pass
                
            return EscapeAttemptResult(
                method='host_network_namespace',
                status='isolated',
                message='Pod uses isolated network namespace.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='host_network_namespace', status='error', message=str(e))

