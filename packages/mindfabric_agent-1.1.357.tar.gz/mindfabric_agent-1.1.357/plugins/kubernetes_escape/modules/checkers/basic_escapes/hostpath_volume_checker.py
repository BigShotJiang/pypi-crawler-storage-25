"""
HostPath Volume Checker

Checks for presence of mounted hostPath volumes.
"""

import os
from ....proto import EscapeAttemptResult


class HostPathVolumeChecker:
    """Checks hostPath volume mounts"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check(self) -> EscapeAttemptResult:
        """Checking for presence of mounted hostPath volumes."""
        # Skip if we're in isolated testing mode without host access
        try:
            from utils.host_isolation_check import should_skip_host_checks
            if should_skip_host_checks():
                return EscapeAttemptResult(
                    method='hostpath_volume',
                    status='not_vulnerable',
                    message='Running in isolated mode - host filesystem not accessible'
                )
        except ImportError:
            pass  # Continue if module not available
        
        mount_paths = ['/host', '/hostroot', '/rootfs', '/mnt/host', '/node_host']
        host_mounts = []
        
        # First checking obvious mounts
        for path in mount_paths:
            if os.path.isdir(path) and os.path.exists(f"{path}/etc/passwd"):
                try:
                    with open(f"{path}/etc/passwd", 'r') as f:
                        passwd_content = f.read()
                    
                    demo_next = "Can read and modify host files via hostPath, add users, SSH keys etc."
                    return EscapeAttemptResult(
                        method='hostpath_volume',
                        status='exploited',
                        message=f'detected mounted hostPath volume on {path}.',
                        artifact_path=f"{path}/etc/passwd",
                        artifact_content=passwd_content[:500],
                        demo_next_steps=demo_next
                    )
                except Exception as e:
                    host_mounts.append(f"{path} (read error: {str(e)})")
        
        # Checking via /proc/self/mounts
        try:
            with open('/proc/self/mounts', 'r') as f:
                mounts = f.read()
                
            for line in mounts.splitlines():
                if not line:
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    mount_path = parts[1]
                    for suspicious in ['/', '/var', '/etc', '/root', '/home']:
                        # Excluding typical container mounts
                        if mount_path.startswith(suspicious) and not any(
                            item in mount_path for item in ['/var/run', '/proc', '/sys', '/dev']
                        ):
                            if os.path.isdir(mount_path) and os.access(mount_path, os.R_OK):
                                host_mounts.append(mount_path)
            
            if host_mounts:
                # Trying to read /etc/passwd on any found mount
                for mount in host_mounts:
                    passwd_path = os.path.join(mount, 'etc/passwd')
                    if os.path.exists(passwd_path):
                        try:
                            with open(passwd_path, 'r') as f:
                                passwd_content = f.read()
                            
                            demo_next = "Can read and modify host files via hostPath, add users, SSH keys etc."
                            return EscapeAttemptResult(
                                method='hostpath_volume',
                                status='exploited',
                                message=f'Detected hostPath volume with access to {mount}.',
                                artifact_path=passwd_path,
                                artifact_content=passwd_content[:500],
                                demo_next_steps=demo_next
                            )
                        except Exception:
                            pass
                
                return EscapeAttemptResult(
                    method='hostpath_volume',
                    status='suspicious',
                    message=f'Detected suspicious mount points: {", ".join(host_mounts)}'
                )
            
            return EscapeAttemptResult(
                method='hostpath_volume',
                status='not_found',
                message='No suspicious hostPath volumes detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='hostpath_volume', status='error', message=str(e))

