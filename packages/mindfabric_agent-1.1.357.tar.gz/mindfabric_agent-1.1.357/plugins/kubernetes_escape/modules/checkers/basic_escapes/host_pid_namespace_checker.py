"""
Host PID Namespace Checker

Checks access to host PID namespace.
"""

import os
from ....proto import EscapeAttemptResult


class HostPIDNamespaceChecker:
    """Checks host PID namespace access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check(self) -> EscapeAttemptResult:
        """Checking access to host PID namespace."""
        try:
            # Checking for presence of host processes in /proc
            init_cmdline_path = '/proc/1/cmdline'
            if os.path.exists(init_cmdline_path):
                with open(init_cmdline_path, 'rb') as f:
                    init_cmdline = f.read().replace(b'\x00', b' ').decode('utf-8', errors='ignore').strip()
                
                # Checking if PID 1 typical container process
                container_processes = [
                    'runc', 'containerd', 'docker', 'entrypoint', 'python', 'node', 'java', 'bash', 'sh', 'tini'
                ]
                
                if not any(proc in init_cmdline.lower() for proc in container_processes):
                    # Probably seeing system init
                    host_pids = False
                    high_pids = []
                    
                    # Additional check for presence of system processes
                    for pid_dir in os.listdir('/proc'):
                        if pid_dir.isdigit() and int(pid_dir) > 1000:
                            try:
                                pid_path = f'/proc/{pid_dir}/cmdline'
                                if os.path.exists(pid_path):
                                    with open(pid_path, 'rb') as f:
                                        cmd = f.read().replace(b'\x00', b' ').decode('utf-8', errors='ignore').strip()
                                    if cmd and any(sys_proc in cmd.lower() for sys_proc in [
                                        'systemd', 'udev', 'network', 'daemon', 'cron', 'ssh', 'audit'
                                    ]):
                                        high_pids.append(f"{pid_dir}: {cmd[:30]}")
                                        host_pids = True
                                        if len(high_pids) >= 3:  # Limitation of output
                                            break
                            except Exception:
                                continue
                    
                    if host_pids:
                        demo_next = "Access to host PID namespace allows see all processes, interact with them, can be used for obtaining data/modification."
                        return EscapeAttemptResult(
                            method='host_pid_namespace',
                            status='exploited',
                            message='Pod running with hostPID=true, host PID namespace visible!',
                            artifact_content=f"PID 1: {init_cmdline}\nSystem processes:\n" + "\n".join(high_pids),
                            demo_next_steps=demo_next
                        )
            
            # Checking for presence of large number of processes (indirect sign of host PID)
            proc_count = len([d for d in os.listdir('/proc') if d.isdigit()])
            if proc_count > 100:  # In normal container rarely more than 100 processes
                demo_next = "Number of processes indicates hostPID=true, can see and influence all host processes."
                return EscapeAttemptResult(
                    method='host_pid_namespace',
                    status='exploited',
                    message=f'Detected anomalous number of processes ({proc_count}), probably hostPID=true.',
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='host_pid_namespace',
                status='isolated',
                message='Pod uses isolated PID namespace.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='host_pid_namespace', status='error', message=str(e))

