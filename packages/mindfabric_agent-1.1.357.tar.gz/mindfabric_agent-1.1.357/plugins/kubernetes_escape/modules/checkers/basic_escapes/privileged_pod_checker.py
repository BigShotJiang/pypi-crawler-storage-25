"""
Privileged Pod Checker

Checks if pod is running in privileged mode.
"""

import os
from ....proto import EscapeAttemptResult


class PrivilegedPodChecker:
    """Checks privileged pod access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check(self) -> EscapeAttemptResult:
        """Checking if running in privileged mode."""
        try:
            # 1. Checking access to host devices
            device_cgroup_path = "/sys/fs/cgroup/devices/devices.list"
            if os.path.exists(device_cgroup_path):
                with open(device_cgroup_path, 'r') as f:
                    content = f.read()
                    if "a" in content:  # Access granted to all devices
                        demo_next = "Possible to create and use special devices, mounting any host devices."
                        return EscapeAttemptResult(
                            method='privileged_pod',
                            status='exploited',
                            message='Pod running in privileged mode (all devices accessible).',
                            artifact_content=content,
                            demo_next_steps=demo_next
                        )
            
            # 2. Checking capabilities
            try:
                with open('/proc/self/status', 'r') as f:
                    for line in f:
                        if line.startswith('CapEff:'):
                            cap_eff = int(line.split()[1], 16)
                            # Checking all capabilities (0xffffffffffffffff)
                            if cap_eff == 0xffffffffffffffff:
                                demo_next = "Full access to all capabilities, including CAP_SYS_ADMIN - can mount host filesystems."
                                return EscapeAttemptResult(
                                    method='privileged_pod',
                                    status='exploited',
                                    message='Pod running with full capabilities (privileged).',
                                    artifact_content=f"CapEff: {hex(cap_eff)}",
                                    demo_next_steps=demo_next
                                )
            except Exception:
                pass
            
            # 3. Checking access to /dev
            if os.path.exists('/dev/mem') and os.access('/dev/mem', os.R_OK):
                demo_next = "Access to /dev/mem allows read physical memory of host and change data in memory."
                return EscapeAttemptResult(
                    method='privileged_pod',
                    status='exploited',
                    message='Privileged access: /dev/mem accessible!',
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='privileged_pod',
                status='not_privileged',
                message='Pod does not have privileged mode.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='privileged_pod', status='error', message=str(e))

