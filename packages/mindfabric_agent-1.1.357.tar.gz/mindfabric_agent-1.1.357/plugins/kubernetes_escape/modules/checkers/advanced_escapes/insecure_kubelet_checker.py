"""
Insecure Kubelet Checker

Checks access to unprotected kubelet API.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class InsecureKubeletChecker:
    """Checks insecure kubelet API access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking access to unprotected kubelet API."""
        try:
            # Getting cluster nodes for checking kubelet
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='insecure_kubelet',
                    status='not_found',
                    message='service account token not found for obtaining nodes.'
                )
                
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
                
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Trying to get list of nodes
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/api/v1/nodes',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            node_rc, node_out, _ = await run_exec(curl_cmd, timeout=5)
            
            node_ips = []
            if node_rc == 0 and "items" in node_out:
                try:
                    nodes_data = json.loads(node_out)
                    for node in nodes_data.get("items", []):
                        addresses = node.get("status", {}).get("addresses", [])
                        for addr in addresses:
                            if addr.get("type") in ["InternalIP", "ExternalIP"]:
                                node_ips.append(addr.get("address"))
                except Exception:
                    pass
            
            # If failed to get node IPs, will try standard paths
            if not node_ips:
                # Trying local network, gateway by default etc..
                try:
                    route_rc, route_out, _ = await run_exec(['ip', 'route'], timeout=3)
                    if route_rc == 0:
                        routes = route_out.splitlines()
                        for route in routes:
                            if "default via" in route:
                                parts = route.split()
                                gateway_index = parts.index("via") + 1
                                if gateway_index < len(parts):
                                    node_ips.append(parts[gateway_index])
                except Exception:
                    pass
                    
                # Adding localhost and kubernetes service
                node_ips.extend(["127.0.0.1", "localhost", api_server])
            
            # Checking each node on unprotected kubelet API
            for ip in node_ips:
                kubelet_ports = [10250, 10255]
                
                for port in kubelet_ports:
                    # Checking access to API kubelet without authentication
                    curl_cmd = [
                        'curl', '-s', '-k',
                        f'https://{ip}:{port}/pods'
                    ]
                    
                    try:
                        rc, out, _ = await run_exec(curl_cmd, timeout=3)
                        
                        if rc == 0 and (
                            "pods" in out or
                            "apiVersion" in out or
                            "kind" in out
                        ):
                            demo_next = "Access to unprotected kubelet API allows seeing and executing commands in any pod on node."
                            return EscapeAttemptResult(
                                method='insecure_kubelet',
                                status='exploited',
                                message=f'detected unprotected kubelet API on {ip}:{port}!',
                                artifact_content=out[:300],
                                demo_next_steps=demo_next
                            )
                    except Exception:
                        continue
                    
                    # Checking read-only API kubelet
                    curl_cmd = [
                        'curl', '-s',
                        f'http://{ip}:{port}/pods'
                    ]
                    
                    try:
                        rc, out, _ = await run_exec(curl_cmd, timeout=3)
                        
                        if rc == 0 and (
                            "pods" in out or
                            "apiVersion" in out or
                            "kind" in out
                        ):
                            demo_next = "Access to read-only kubelet API allows getting information about node pods."
                            return EscapeAttemptResult(
                                method='insecure_kubelet',
                                status='exploited',
                                message=f'detected read-only kubelet API on {ip}:{port}.',
                                artifact_content=out[:300],
                                demo_next_steps=demo_next
                            )
                    except Exception:
                        continue
                        
            return EscapeAttemptResult(
                method='insecure_kubelet',
                status='not_found',
                message='Unprotected kubelet API not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='insecure_kubelet', status='error', message=str(e))

