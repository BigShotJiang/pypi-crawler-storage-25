"""
Container Escape Checker

Checks possibilities of escape from container via containerization vulnerabilities.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class ContainerEscapeChecker:
    """Checks container escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities of escape from container via containerization vulnerabilities."""
        try:
            # Checking for dangerous capabilities
            dangerous_caps = []
            
            try:
                status_content = await asyncio.to_thread(lambda: open("/proc/self/status", "r").read())
                for line in status_content.splitlines():
                    if line.startswith('CapEff:'):
                        cap_eff = int(line.split()[1], 16)
                            
                        # Checking dangerous capabilities
                        cap_sys_admin = (cap_eff >> 21) & 1  # CAP_SYS_ADMIN (21)
                        cap_sys_ptrace = (cap_eff >> 19) & 1  # CAP_SYS_PTRACE (19)
                        cap_sys_module = (cap_eff >> 16) & 1  # CAP_SYS_MODULE (16)
                        cap_sys_rawio = (cap_eff >> 17) & 1   # CAP_SYS_RAWIO (17)
                            
                        if cap_sys_admin:
                            dangerous_caps.append("CAP_SYS_ADMIN (possibility of mounting file systems)")
                        if cap_sys_ptrace:
                            dangerous_caps.append("CAP_SYS_PTRACE (debugging processes)")
                        if cap_sys_module:
                            dangerous_caps.append("CAP_SYS_MODULE (loading kernel modules)")
                        if cap_sys_rawio:
                            dangerous_caps.append("CAP_SYS_RAWIO (direct access to devices)")
            except Exception:
                pass
            
            # Checking mounting capability cgroup for container escape
            if os.path.exists('/proc/mounts') and any(cap for cap in dangerous_caps if "SYS_ADMIN" in cap):
                try:
                    # Checking possibility creation directory for mounting
                    if not os.path.exists('/tmp/cgroup_exploit'):
                        os.makedirs('/tmp/cgroup_exploit')
                        
                    # Trying to mount cgroup in container
                    mount_rc, _, _ = await run_exec(['mount', '-t', 'cgroup', 'cgroup', '/tmp/cgroup_exploit'], timeout=5)
                    
                    if mount_rc == 0:
                        demo_next = "Possible to create malicious cgroup, execute command as root on host via notify_on_release handler."
                        return EscapeAttemptResult(
                            method='container_escape',
                            status='exploited',
                            message='detected possibility of escape via mounting cgroup.',
                            artifact_content=dangerous_caps[0],
                            demo_next_steps=demo_next
                        )
                except Exception:
                    pass
            
            # Checking for FUSE for possible container escape
            if os.path.exists('/dev/fuse') and os.access('/dev/fuse', os.R_OK):
                demo_next = "Possible to use FUSE for creating file system with special handler, allowing to escape from pod container."
                return EscapeAttemptResult(
                    method='container_escape',
                    status='exploited',
                    message='detected access to /dev/fuse - potential path for container escape.',
                    demo_next_steps=demo_next
                )
            
            # Checking RunC CVEs (generally)
            if os.path.exists('/proc/self/environ'):
                environ = await asyncio.to_thread(lambda: open("/proc/self/environ", "rb").read())
                if b'runc' in environ:
                    return EscapeAttemptResult(
                        method='container_escape',
                        status='suspicious',
                        message='detected signs usage RunC, recommended check version on presence of vulnerabilities.'
                    )
            
            if dangerous_caps:
                return EscapeAttemptResult(
                    method='container_escape',
                    status='suspicious',
                    message=f'detected dangerous capabilities: {", ".join(dangerous_caps)}.'
                )
                
            return EscapeAttemptResult(
                method='container_escape',
                status='no_issues',
                message='Not detected possibility for container escape.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='container_escape', status='error', message=str(e))

