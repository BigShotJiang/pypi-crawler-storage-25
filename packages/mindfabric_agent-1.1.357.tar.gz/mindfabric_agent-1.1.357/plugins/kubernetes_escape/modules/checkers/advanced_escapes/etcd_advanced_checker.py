"""
Advanced etcd Security Checker

Extended etcd security checks:
- Direct etcd access via gRPC/HTTP
- etcd authentication bypass
- etcd encryption at rest verification
- etcd backup abuse
- etcd cluster discovery
- Secret extraction from etcd
- etcd certificate access

MITRE ATT&CK: T1552.007 (Container API), T1530 (Data from Cloud Storage)
"""

import os
import socket
import asyncio
import base64
import json
from typing import Dict, List, Any, Optional, Tuple
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


# etcd Attack Techniques Database
ETCD_ATTACK_TECHNIQUES = {
    "direct_access": {
        "description": "Direct access to etcd without authentication",
        "severity": "critical",
        "ports": [2379, 2380, 4001],
        "endpoints": [
            "/v2/keys/",
            "/v3/kv/range",
            "/v3/auth/authenticate",
            "/version",
            "/health",
            "/metrics",
            "/v2/stats/self",
            "/v2/stats/store",
            "/v2/stats/leader",
        ],
        "mitre": "T1552.007",
    },
    "authentication_bypass": {
        "description": "Bypass etcd authentication",
        "severity": "critical",
        "techniques": [
            "No authentication required",
            "Default credentials",
            "Certificate authentication bypass",
            "Token brute force",
        ],
    },
    "encryption_at_rest": {
        "description": "Check if etcd data is encrypted at rest",
        "severity": "high",
        "check_paths": [
            "/var/lib/etcd",
            "/etc/kubernetes/pki/etcd",
            "/etc/etcd/pki",
        ],
    },
    "backup_abuse": {
        "description": "Access etcd backups for secret extraction",
        "severity": "critical",
        "backup_locations": [
            "/var/lib/etcd-backup",
            "/backup/etcd",
            "/tmp/etcd-backup",
        ],
    },
    "cluster_discovery": {
        "description": "Discover etcd cluster members",
        "severity": "medium",
        "endpoints": [
            "/v2/members",
            "/v3/cluster/member/list",
        ],
    },
    "secret_extraction": {
        "description": "Extract Kubernetes secrets from etcd",
        "severity": "critical",
        "key_prefixes": [
            "/registry/secrets/",
            "/registry/serviceaccounts/",
            "/registry/pods/",
            "/registry/configmaps/",
        ],
    },
    "certificate_access": {
        "description": "Access etcd certificates for persistent access",
        "severity": "critical",
        "cert_paths": [
            "/etc/kubernetes/pki/etcd/ca.crt",
            "/etc/kubernetes/pki/etcd/server.crt",
            "/etc/kubernetes/pki/etcd/server.key",
            "/etc/kubernetes/pki/etcd/peer.crt",
            "/etc/kubernetes/pki/etcd/peer.key",
            "/etc/etcd/pki/ca.crt",
            "/etc/etcd/pki/server.crt",
            "/etc/etcd/pki/server.key",
        ],
    },
    "snapshot_extraction": {
        "description": "Create or access etcd snapshots",
        "severity": "critical",
        "commands": [
            "etcdctl snapshot save",
            "etcdctl snapshot status",
            "etcdctl snapshot restore",
        ],
    },
}


class EtcdAdvancedChecker:
    """Advanced etcd security checker."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings = []
    
    async def check(self) -> EscapeAttemptResult:
        """
        Run all advanced etcd security checks.
        
        Returns:
            EscapeAttemptResult with findings
        """
        results = []
        
        # Check direct etcd access
        direct_result = await self._check_direct_access()
        if direct_result:
            results.append(direct_result)
        
        # Check etcd authentication
        auth_result = await asyncio.to_thread(self._check_authentication)
        if auth_result:
            results.append(auth_result)
        
        # Check encryption at rest
        encryption_result = await asyncio.to_thread(self._check_encryption_at_rest)
        if encryption_result:
            results.append(encryption_result)
        
        # Check backup access
        backup_result = await asyncio.to_thread(self._check_backup_access)
        if backup_result:
            results.append(backup_result)
        
        # Check cluster discovery
        cluster_result = await asyncio.to_thread(self._check_cluster_discovery)
        if cluster_result:
            results.append(cluster_result)
        
        # Check secret extraction possibility
        secrets_result = await self._check_secret_extraction()
        if secrets_result:
            results.append(secrets_result)
        
        # Check certificate access
        cert_result = await asyncio.to_thread(self._check_certificate_access)
        if cert_result:
            results.append(cert_result)
        
        # Check etcdctl availability
        etcdctl_result = await self._check_etcdctl()
        if etcdctl_result:
            results.append(etcdctl_result)
        
        # Aggregate results
        if not results:
            return EscapeAttemptResult(
                method='etcd_advanced',
                status='not_found',
                message='No etcd security issues detected.'
            )
        
        # Find most critical result
        critical = [r for r in results if r.status == 'exploited']
        suspicious = [r for r in results if r.status == 'suspicious']
        
        if critical:
            combined_messages = "\n".join([r.message for r in critical])
            combined_artifacts = "\n---\n".join([r.artifact_content or "" for r in critical if r.artifact_content])
            
            demo_steps = """
etcd Exploitation Steps:
1. Direct Access: Use etcdctl or curl to query keys
2. Secret Extraction: etcdctl get /registry/secrets --prefix
3. Service Account Tokens: etcdctl get /registry/serviceaccounts --prefix
4. Cluster Takeover: Create new admin service account in etcd
5. Persistence: Extract etcd certificates for persistent access
"""
            
            return EscapeAttemptResult(
                method='etcd_advanced',
                status='exploited',
                message=f'Critical etcd vulnerabilities found:\n{combined_messages}',
                artifact_content=combined_artifacts[:2000] if combined_artifacts else None,
                demo_next_steps=demo_steps
            )
        
        if suspicious:
            combined_messages = "\n".join([r.message for r in suspicious])
            return EscapeAttemptResult(
                method='etcd_advanced',
                status='suspicious',
                message=f'Suspicious etcd configurations:\n{combined_messages}'
            )
        
        return EscapeAttemptResult(
            method='etcd_advanced',
            status='limited_access',
            message='Limited etcd exposure detected.'
        )
    
    async def _check_direct_access(self) -> Optional[EscapeAttemptResult]:
        """Check for direct etcd access."""
        etcd_ports = ETCD_ATTACK_TECHNIQUES["direct_access"]["ports"]
        etcd_hosts = [
            "etcd",
            "etcd.kube-system",
            "etcd.kube-system.svc",
            "etcd.kube-system.svc.cluster.local",
            "localhost",
            "127.0.0.1",
            os.environ.get("ETCD_HOST", ""),
            os.environ.get("KUBERNETES_SERVICE_HOST", ""),
        ]
        etcd_hosts = [h for h in etcd_hosts if h]
        
        for host in etcd_hosts:
            for port in etcd_ports:
                try:
                    try:
                        reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=2.0)
                        writer.close()
                        try:
                            await writer.wait_closed()
                        except Exception:
                            pass
                        port_open = True
                    except Exception:
                        port_open = False

                    if port_open:
                        # Port is open, try to access etcd API
                        for endpoint in ETCD_ATTACK_TECHNIQUES["direct_access"]["endpoints"]:
                            try:
                                curl_cmd = ['curl', '-s', '-m', '3', f'http://{host}:{port}{endpoint}']
                                rc, out, _ = await run_exec(curl_cmd, timeout=5)
                                
                                if rc == 0 and len(out) > 5:
                                    if any(indicator in out.lower() for indicator in 
                                           ["key", "value", "node", "etcdserver", "version", "health"]):
                                        return EscapeAttemptResult(
                                            method='etcd_direct_access',
                                            status='exploited',
                                            message=f'Direct etcd access on {host}:{port}{endpoint}',
                                            artifact_content=out[:500]
                                        )
                            except Exception:
                                continue
                except Exception:
                    continue
        
        return None
    
    def _check_authentication(self) -> Optional[EscapeAttemptResult]:
        """Check etcd authentication configuration."""
        # Check for etcd config files
        config_paths = [
            "/etc/etcd/etcd.conf",
            "/etc/etcd/etcd.conf.yaml",
            "/etc/kubernetes/manifests/etcd.yaml",
        ]
        
        for path in config_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        content = f.read()
                    
                    # Check for insecure configurations
                    insecure_indicators = [
                        "client-cert-auth: false",
                        "client-cert-auth=false",
                        "--client-cert-auth=false",
                        "peer-client-cert-auth: false",
                        "ETCD_CLIENT_CERT_AUTH=false",
                    ]
                    
                    for indicator in insecure_indicators:
                        if indicator.lower() in content.lower():
                            return EscapeAttemptResult(
                                method='etcd_auth_bypass',
                                status='exploited',
                                message=f'etcd authentication disabled in {path}',
                                artifact_content=f"Found: {indicator}"
                            )
                except Exception:
                    continue
        
        return None
    
    def _check_encryption_at_rest(self) -> Optional[EscapeAttemptResult]:
        """Check etcd encryption at rest."""
        encryption_config_paths = [
            "/etc/kubernetes/pki/encryption-config.yaml",
            "/etc/kubernetes/encryption-config.yaml",
        ]
        
        # Check if encryption config exists
        for path in encryption_config_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        content = f.read()
                    
                    # Check encryption provider
                    if "identity" in content and "aescbc" not in content and "aesgcm" not in content:
                        return EscapeAttemptResult(
                            method='etcd_no_encryption',
                            status='suspicious',
                            message='etcd secrets not encrypted at rest (identity provider)',
                            artifact_content=content[:500]
                        )
                except Exception:
                    pass
        
        # Check if kube-apiserver has encryption config
        apiserver_manifest = "/etc/kubernetes/manifests/kube-apiserver.yaml"
        if os.path.exists(apiserver_manifest):
            try:
                with open(apiserver_manifest, 'r') as f:
                    content = f.read()
                
                if "--encryption-provider-config" not in content:
                    return EscapeAttemptResult(
                        method='etcd_no_encryption',
                        status='suspicious',
                        message='kube-apiserver not configured with encryption provider'
                    )
            except Exception:
                pass
        
        return None
    
    def _check_backup_access(self) -> Optional[EscapeAttemptResult]:
        """Check access to etcd backups."""
        backup_locations = ETCD_ATTACK_TECHNIQUES["backup_abuse"]["backup_locations"]
        
        for location in backup_locations:
            if os.path.exists(location):
                try:
                    files = os.listdir(location)
                    backup_files = [f for f in files if f.endswith(('.db', '.snap', '.tar', '.tar.gz'))]
                    
                    if backup_files:
                        return EscapeAttemptResult(
                            method='etcd_backup_access',
                            status='exploited',
                            message=f'etcd backup files found at {location}',
                            artifact_content=str(backup_files)
                        )
                except Exception:
                    continue
        
        return None
    
    def _check_cluster_discovery(self) -> Optional[EscapeAttemptResult]:
        """Discover etcd cluster members."""
        # Try environment variables first
        etcd_endpoints = os.environ.get("ETCD_ENDPOINTS", "")
        etcd_advertise = os.environ.get("ETCD_ADVERTISE_CLIENT_URLS", "")
        
        if etcd_endpoints or etcd_advertise:
            return EscapeAttemptResult(
                method='etcd_cluster_discovery',
                status='suspicious',
                message='etcd cluster endpoints found in environment',
                artifact_content=f"ETCD_ENDPOINTS={etcd_endpoints}\nETCD_ADVERTISE_CLIENT_URLS={etcd_advertise}"
            )
        
        return None
    
    async def _check_secret_extraction(self) -> Optional[EscapeAttemptResult]:
        """Check possibility of secret extraction from etcd."""
        # Check if etcdctl is available
        try:
            rc, _, _ = await run_exec(['which', 'etcdctl'], timeout=5)
            if rc == 0:
                # etcdctl is available, try to list keys
                etcdctl_cmd = ['etcdctl', 'get', '/registry/secrets/', '--prefix', '--keys-only', '--limit=5']
                
                # Try with different endpoint configurations
                endpoints = [
                    "http://127.0.0.1:2379",
                    "http://etcd:2379",
                    "https://127.0.0.1:2379",
                ]
                
                for endpoint in endpoints:
                    try:
                        env = os.environ.copy()
                        env['ETCDCTL_ENDPOINTS'] = endpoint
                        env['ETCDCTL_API'] = '3'
                        
                        proc_rc, proc_out, _ = await run_exec(etcdctl_cmd, timeout=5, env=env)
                        
                        if proc_rc == 0 and "/registry/secrets/" in proc_out:
                            return EscapeAttemptResult(
                                method='etcd_secret_extraction',
                                status='exploited',
                                message='Can extract secrets from etcd via etcdctl',
                                artifact_content=proc_out[:1000]
                            )
                    except Exception:
                        continue
        except Exception:
            pass
        
        return None
    
    def _check_certificate_access(self) -> Optional[EscapeAttemptResult]:
        """Check access to etcd certificates."""
        cert_paths = ETCD_ATTACK_TECHNIQUES["certificate_access"]["cert_paths"]
        accessible_certs = []
        
        for cert_path in cert_paths:
            if os.path.exists(cert_path):
                try:
                    # Check if we can read the certificate
                    with open(cert_path, 'r') as f:
                        content = f.read()
                    
                    if "BEGIN CERTIFICATE" in content or "BEGIN" in content:
                        accessible_certs.append(cert_path)
                except Exception:
                    continue
        
        if accessible_certs:
            severity = 'exploited' if any('.key' in c for c in accessible_certs) else 'suspicious'
            return EscapeAttemptResult(
                method='etcd_cert_access',
                status=severity,
                message=f'Accessible etcd certificates: {", ".join(accessible_certs)}',
                artifact_content=f"Found {len(accessible_certs)} accessible certificates"
            )
        
        return None
    
    async def _check_etcdctl(self) -> Optional[EscapeAttemptResult]:
        """Check if etcdctl is available and configured."""
        try:
            rc, out, _ = await run_exec(['which', 'etcdctl'], timeout=5)
            if rc == 0:
                etcdctl_path = out.strip()
                
                # Check version
                v_rc, v_out, _ = await run_exec(['etcdctl', 'version'], timeout=5)
                if v_rc == 0:
                    return EscapeAttemptResult(
                        method='etcdctl_available',
                        status='suspicious',
                        message=f'etcdctl available at {etcdctl_path}',
                        artifact_content=v_out[:300]
                    )
        except Exception:
            pass
        
        return None
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get etcd attack techniques database."""
        return ETCD_ATTACK_TECHNIQUES

