"""
Kubernetes API Server Attacks Checker

Extended API server security checks:
- API server authentication bypass
- Authorization bypass techniques
- Aggregated API server abuse
- Anonymous authentication check
- API server audit bypass
- Token impersonation
- Privilege escalation via API

MITRE ATT&CK: T1078.004 (Cloud Accounts), T1552.007 (Container API)
"""

import os
import json
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


# K8s API Server Attack Techniques Database
K8S_API_ATTACK_TECHNIQUES = {
    "anonymous_auth": {
        "description": "Check if anonymous authentication is enabled",
        "severity": "critical",
        "endpoints": [
            "/api/v1",
            "/healthz",
            "/version",
            "/api/v1/namespaces",
        ],
        "mitre": "T1078.004",
    },
    "authentication_bypass": {
        "description": "Bypass API server authentication",
        "severity": "critical",
        "techniques": [
            "Anonymous access",
            "Stolen service account tokens",
            "Certificate-based bypass",
            "OIDC token abuse",
            "Webhook token bypass",
        ],
    },
    "authorization_bypass": {
        "description": "Bypass API server authorization (RBAC)",
        "severity": "critical",
        "techniques": [
            "Impersonation headers abuse",
            "Group membership escalation",
            "Aggregated API bypass",
            "Node authorization bypass",
            "ABAC bypass (if enabled)",
        ],
    },
    "impersonation_abuse": {
        "description": "Abuse impersonation headers for privilege escalation",
        "severity": "critical",
        "headers": [
            "Impersonate-User",
            "Impersonate-Group",
            "Impersonate-Uid",
        ],
        "high_value_targets": [
            "system:admin",
            "cluster-admin",
            "system:masters",
            "system:kube-controller-manager",
            "system:kube-scheduler",
        ],
    },
    "aggregated_api": {
        "description": "Abuse aggregated API servers",
        "severity": "high",
        "endpoints": [
            "/apis/apiregistration.k8s.io/v1/apiservices",
            "/apis/metrics.k8s.io/v1beta1",
            "/apis/custom.metrics.k8s.io",
        ],
    },
    "node_authorization": {
        "description": "Abuse Node authorization mode",
        "severity": "high",
        "techniques": [
            "Node credential theft",
            "Node-specific secret access",
            "Node proxy abuse",
        ],
    },
    "audit_bypass": {
        "description": "Bypass or evade API audit logging",
        "severity": "medium",
        "techniques": [
            "Metadata-only audit level",
            "Audit webhook DoS",
            "High-volume request flooding",
        ],
    },
    "api_server_exploitation": {
        "description": "Direct API server exploitation",
        "severity": "critical",
        "cves": [
            "CVE-2018-1002105",  # Kubernetes API server privilege escalation
            "CVE-2019-1002100",  # Patch/JSON merge
            "CVE-2019-11253",    # YAML parsing DoS
            "CVE-2020-8559",     # Redirect vulnerability
        ],
    },
    "admission_webhook_bypass": {
        "description": "Bypass admission webhooks",
        "severity": "high",
        "techniques": [
            "Direct API server access",
            "Webhook failure policy exploit",
            "Timing race conditions",
        ],
    },
}


class K8sAPIServerAttacksChecker:
    """Kubernetes API server attacks checker."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings = []
    
    async def check(self) -> EscapeAttemptResult:
        """
        Run all K8s API server attack checks.
        
        Returns:
            EscapeAttemptResult with findings
        """
        results = []
        
        # Check anonymous authentication
        anon_result = await self._check_anonymous_auth()
        if anon_result:
            results.append(anon_result)
        
        # Check impersonation capabilities
        impersonation_result = await self._check_impersonation()
        if impersonation_result:
            results.append(impersonation_result)
        
        # Check aggregated API servers
        aggregated_result = await self._check_aggregated_apis()
        if aggregated_result:
            results.append(aggregated_result)
        
        # Check node authorization abuse
        node_auth_result = await self._check_node_authorization()
        if node_auth_result:
            results.append(node_auth_result)
        
        # Check audit configuration
        audit_result = await self._check_audit_bypass()
        if audit_result:
            results.append(audit_result)
        
        # Check API server configuration
        config_result = await self._check_api_server_config()
        if config_result:
            results.append(config_result)
        
        # Check privileged API access
        priv_api_result = await self._check_privileged_api_access()
        if priv_api_result:
            results.append(priv_api_result)
        
        # Check admission webhook bypass
        webhook_result = await self._check_admission_webhook_bypass()
        if webhook_result:
            results.append(webhook_result)
        
        # Aggregate results
        if not results:
            return EscapeAttemptResult(
                method='k8s_api_server_attacks',
                status='not_found',
                message='No API server attack vectors detected.'
            )
        
        critical = [r for r in results if r.status == 'exploited']
        suspicious = [r for r in results if r.status == 'suspicious']
        
        if critical:
            combined_messages = "\n".join([r.message for r in critical])
            combined_artifacts = "\n---\n".join([r.artifact_content or "" for r in critical if r.artifact_content])
            
            demo_steps = """
K8s API Server Exploitation Steps:
1. Authentication Bypass: Use anonymous auth or stolen tokens
2. Impersonation: Use headers to impersonate cluster-admin
3. RBAC Escalation: Create ClusterRoleBinding for admin access
4. Secret Extraction: Access all secrets across namespaces
5. Persistence: Create backdoor service accounts
6. Cluster Takeover: Deploy privileged pods for node access
"""
            
            return EscapeAttemptResult(
                method='k8s_api_server_attacks',
                status='exploited',
                message=f'Critical API server vulnerabilities:\n{combined_messages}',
                artifact_content=combined_artifacts[:2000] if combined_artifacts else None,
                demo_next_steps=demo_steps
            )
        
        if suspicious:
            combined_messages = "\n".join([r.message for r in suspicious])
            return EscapeAttemptResult(
                method='k8s_api_server_attacks',
                status='suspicious',
                message=f'Suspicious API server configurations:\n{combined_messages}'
            )
        
        return EscapeAttemptResult(
            method='k8s_api_server_attacks',
            status='limited_access',
            message='Limited API server attack surface detected.'
        )
    
    async def _check_anonymous_auth(self) -> Optional[EscapeAttemptResult]:
        """Check if anonymous authentication is enabled."""
        api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
        api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
        
        # Try to access API without any authentication
        endpoints = K8S_API_ATTACK_TECHNIQUES["anonymous_auth"]["endpoints"]
        
        for endpoint in endpoints:
            try:
                # Try without token
                curl_cmd = [
                    'curl', '-s', '-k', '-m', '5',
                    f'https://{api_server}:{api_port}{endpoint}'
                ]
                
                rc, response, _ = await run_exec(curl_cmd, timeout=10)
                if rc == 0:
                    
                    # Check if we got actual data (not Unauthorized)
                    if "Unauthorized" not in response and "Forbidden" not in response:
                        if len(response) > 20 and ("apiVersion" in response or "serverAddressByClientCIDRs" in response or "etcdServer" in response):
                            return EscapeAttemptResult(
                                method='anonymous_auth',
                                status='exploited',
                                message=f'Anonymous authentication enabled! Accessible: {endpoint}',
                                artifact_content=response[:500]
                            )
            except Exception:
                continue
        
        return None
    
    async def _check_impersonation(self) -> Optional[EscapeAttemptResult]:
        """Check impersonation capabilities."""
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if not os.path.exists(token_path):
            return None
        
        try:
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Check if we can impersonate users
            impersonate_check_cmd = [
                'curl', '-s', '-k', '-m', '5',
                f'https://{api_server}:{api_port}/apis/authorization.k8s.io/v1/selfsubjectaccessreviews',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '-X', 'POST',
                '--data', json.dumps({
                    "apiVersion": "authorization.k8s.io/v1",
                    "kind": "SelfSubjectAccessReview",
                    "spec": {
                        "resourceAttributes": {
                            "verb": "impersonate",
                            "resource": "users",
                            "group": ""
                        }
                    }
                })
            ]
            
            rc, out, _ = await run_exec(impersonate_check_cmd, timeout=10)
            if rc == 0 and '"allowed":true' in out.lower():
                return EscapeAttemptResult(
                    method='impersonation_abuse',
                    status='exploited',
                    message='Service account can impersonate users - privilege escalation possible!',
                    artifact_content=out[:500]
                )
            
            # Check impersonate groups
            impersonate_groups_cmd = impersonate_check_cmd.copy()
            impersonate_groups_cmd[-1] = json.dumps({
                "apiVersion": "authorization.k8s.io/v1",
                "kind": "SelfSubjectAccessReview",
                "spec": {
                    "resourceAttributes": {
                        "verb": "impersonate",
                        "resource": "groups",
                        "group": ""
                    }
                }
            })
            
            rc, out, _ = await run_exec(impersonate_groups_cmd, timeout=10)
            if rc == 0 and '"allowed":true' in out.lower():
                return EscapeAttemptResult(
                    method='impersonation_abuse',
                    status='exploited',
                    message='Service account can impersonate groups - can escalate to system:masters!',
                    artifact_content=out[:500]
                )
        except Exception:
            pass
        
        return None
    
    async def _check_aggregated_apis(self) -> Optional[EscapeAttemptResult]:
        """Check access to aggregated API servers."""
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if not os.path.exists(token_path):
            return None
        
        try:
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Check APIService access
            curl_cmd = [
                'curl', '-s', '-k', '-m', '5',
                f'https://{api_server}:{api_port}/apis/apiregistration.k8s.io/v1/apiservices',
                '--header', f'Authorization: Bearer {token}'
            ]
            
            rc, out, _ = await run_exec(curl_cmd, timeout=10)
            if rc == 0 and "items" in out and "Forbidden" not in out:
                # Check if we can create/modify APIServices
                access_check = [
                    'curl', '-s', '-k', '-m', '5',
                    f'https://{api_server}:{api_port}/apis/authorization.k8s.io/v1/selfsubjectaccessreviews',
                    '--header', f'Authorization: Bearer {token}',
                    '--header', 'Content-Type: application/json',
                    '-X', 'POST',
                    '--data', json.dumps({
                        "apiVersion": "authorization.k8s.io/v1",
                        "kind": "SelfSubjectAccessReview",
                        "spec": {
                            "resourceAttributes": {
                                "verb": "create",
                                "resource": "apiservices",
                                "group": "apiregistration.k8s.io"
                            }
                        }
                    })
                ]
                
                access_rc, access_out, _ = await run_exec(access_check, timeout=10)
                if access_rc == 0 and '"allowed":true' in access_out.lower():
                    return EscapeAttemptResult(
                        method='aggregated_api_abuse',
                        status='exploited',
                        message='Can create aggregated API services - potential for API hijacking!',
                        artifact_content=access_out[:500]
                    )
                
                return EscapeAttemptResult(
                    method='aggregated_api_abuse',
                    status='suspicious',
                    message='Can list aggregated API services',
                    artifact_content=out[:500]
                )
        except Exception:
            pass
        
        return None
    
    async def _check_node_authorization(self) -> Optional[EscapeAttemptResult]:
        """Check Node authorization mode abuse."""
        # Check if running on a node (has kubelet config)
        kubelet_configs = [
            "/var/lib/kubelet/config.yaml",
            "/etc/kubernetes/kubelet.conf",
            "/var/lib/kubelet/kubeconfig",
        ]
        
        for config in kubelet_configs:
            if os.path.exists(config):
                try:
                    content = await asyncio.to_thread(lambda p=config: open(p, "r").read())
                    
                    # Check for node credentials
                    if "client-certificate" in content or "client-key" in content:
                        return EscapeAttemptResult(
                            method='node_auth_abuse',
                            status='suspicious',
                            message=f'Node credentials accessible at {config}',
                            artifact_content=content[:500]
                        )
                except Exception:
                    continue
        
        return None
    
    async def _check_audit_bypass(self) -> Optional[EscapeAttemptResult]:
        """Check API audit configuration for bypass opportunities."""
        audit_configs = [
            "/etc/kubernetes/audit-policy.yaml",
            "/etc/kubernetes/manifests/kube-apiserver.yaml",
        ]
        
        for config in audit_configs:
            if os.path.exists(config):
                try:
                    content = await asyncio.to_thread(lambda p=config: open(p, "r").read())
                    
                    # Check for weak audit settings
                    if "level: None" in content or "level: Metadata" in content:
                        return EscapeAttemptResult(
                            method='audit_bypass',
                            status='suspicious',
                            message='Weak audit logging configuration detected',
                            artifact_content=f"Config: {config}"
                        )
                except Exception:
                    continue
        
        return None
    
    async def _check_api_server_config(self) -> Optional[EscapeAttemptResult]:
        """Check API server configuration for vulnerabilities."""
        manifest_path = "/etc/kubernetes/manifests/kube-apiserver.yaml"
        
        if os.path.exists(manifest_path):
            try:
                content = await asyncio.to_thread(lambda: open(manifest_path, "r").read())
                
                insecure_configs = []
                
                # Check for insecure configurations
                if "--anonymous-auth=true" in content or "anonymous-auth: true" in content:
                    insecure_configs.append("Anonymous auth enabled")
                
                if "--insecure-port" in content:
                    insecure_configs.append("Insecure port configured")
                
                if "--insecure-bind-address" in content:
                    insecure_configs.append("Insecure bind address")
                
                if "--authorization-mode=AlwaysAllow" in content:
                    insecure_configs.append("Authorization mode AlwaysAllow")
                
                if "--enable-admission-plugins" not in content:
                    insecure_configs.append("No admission plugins configured")
                
                if insecure_configs:
                    severity = 'exploited' if len(insecure_configs) > 2 else 'suspicious'
                    return EscapeAttemptResult(
                        method='api_server_misconfig',
                        status=severity,
                        message=f'API server misconfigurations: {", ".join(insecure_configs)}',
                        artifact_content=content[:1000]
                    )
            except Exception:
                pass
        
        return None
    
    async def _check_privileged_api_access(self) -> Optional[EscapeAttemptResult]:
        """Check for privileged API access."""
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if not os.path.exists(token_path):
            return None
        
        try:
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Check access to highly privileged resources
            privileged_apis = [
                ("/api/v1/secrets", "All secrets"),
                ("/api/v1/nodes", "Nodes"),
                ("/apis/rbac.authorization.k8s.io/v1/clusterroles", "ClusterRoles"),
                ("/apis/rbac.authorization.k8s.io/v1/clusterrolebindings", "ClusterRoleBindings"),
                ("/api/v1/namespaces/kube-system/secrets", "kube-system secrets"),
            ]
            
            accessible = []
            for api, desc in privileged_apis:
                try:
                    curl_cmd = [
                        'curl', '-s', '-k', '-m', '5',
                        f'https://{api_server}:{api_port}{api}',
                        '--header', f'Authorization: Bearer {token}'
                    ]
                    
                    rc, out, _ = await run_exec(curl_cmd, timeout=10)
                    if rc == 0 and "items" in out and "Forbidden" not in out:
                        accessible.append(desc)
                except Exception:
                    continue
            
            if accessible:
                severity = 'exploited' if "All secrets" in accessible or "kube-system secrets" in accessible else 'suspicious'
                return EscapeAttemptResult(
                    method='privileged_api_access',
                    status=severity,
                    message=f'Privileged API access: {", ".join(accessible)}'
                )
        except Exception:
            pass
        
        return None
    
    async def _check_admission_webhook_bypass(self) -> Optional[EscapeAttemptResult]:
        """Check for admission webhook bypass opportunities."""
        token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if not os.path.exists(token_path):
            return None
        
        try:
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # List mutating and validating webhook configurations
            webhook_apis = [
                "/apis/admissionregistration.k8s.io/v1/mutatingwebhookconfigurations",
                "/apis/admissionregistration.k8s.io/v1/validatingwebhookconfigurations",
            ]
            
            bypass_opportunities = []
            
            for api in webhook_apis:
                try:
                    curl_cmd = [
                        'curl', '-s', '-k', '-m', '5',
                        f'https://{api_server}:{api_port}{api}',
                        '--header', f'Authorization: Bearer {token}'
                    ]
                    
                    rc, out, _ = await run_exec(curl_cmd, timeout=10)
                    if rc == 0 and "items" in out and "Forbidden" not in out:
                        # Parse response to find failurePolicy: Ignore
                        if '"failurePolicy":"Ignore"' in out or "'failurePolicy': 'Ignore'" in out:
                            bypass_opportunities.append(f"Webhook with failurePolicy=Ignore found")
                except Exception:
                    continue
            
            if bypass_opportunities:
                return EscapeAttemptResult(
                    method='webhook_bypass',
                    status='suspicious',
                    message=f'Admission webhook bypass opportunities: {", ".join(bypass_opportunities)}'
                )
        except Exception:
            pass
        
        return None
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get K8s API attack techniques database."""
        return K8S_API_ATTACK_TECHNIQUES

