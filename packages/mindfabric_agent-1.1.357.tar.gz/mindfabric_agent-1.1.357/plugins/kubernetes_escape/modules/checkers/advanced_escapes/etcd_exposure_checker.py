"""
etcd Exposure Checker

Checks access to etcd and possibilities of extracting secrets.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class EtcdExposureChecker:
    """Checks etcd exposure"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking access to etcd and possibilities of extracting secrets."""
        try:
            # Checking direct access to etcd via standard ports
            etcd_ports = [2379, 4001]
            etcd_hosts = [
                "etcd",
                "etcd.kube-system",
                "etcd.kube-system.svc",
                "localhost",
                os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            ]
            
            for host in etcd_hosts:
                for port in etcd_ports:
                    try:
                        # Checking etcd accessibility (async connect)
                        try:
                            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=1.0)
                            writer.close()
                            try:
                                await writer.wait_closed()
                            except Exception:
                                pass
                            port_open = True
                        except Exception:
                            port_open = False

                        if port_open:  # Port is open
                            # Trying to get keys via curl
                            curl_cmd = [
                                'curl', '-s', f'http://{host}:{port}/v2/keys/'
                            ]
                            
                            rc, out, _ = await run_exec(curl_cmd, timeout=3)
                            
                            if rc == 0 and (
                                "key" in out or
                                "value" in out or
                                "node" in out
                            ):
                                demo_next = "Access to etcd allows will getall secrets cluster, including tokens, passwords and SSL-certificates."
                                return EscapeAttemptResult(
                                    method='etcd_exposure',
                                    status='exploited',
                                    message=f'detected direct Access to etcd on {host}:{port}!',
                                    artifact_content=out[:500],
                                    demo_next_steps=demo_next
                                )
                            
                            # Trying to get access to other etcd API endpoints
                            for endpoint in ["/version", "/health", "/v2/stats/self"]:
                                curl_cmd = ['curl', '-s', f'http://{host}:{port}{endpoint}']
                                rc, out, _ = await run_exec(curl_cmd, timeout=2)
                                
                                if rc == 0 and len(out) > 10:
                                    return EscapeAttemptResult(
                                        method='etcd_exposure',
                                        status='suspicious',
                                        message=f'detected response from etcd on {host}:{port}{endpoint}.',
                                        artifact_content=out[:300]
                                    )
                    except Exception:
                        continue
            
            # Checking via environment variables
            etcd_env_vars = [var for var in os.environ if "ETCD" in var]
            if etcd_env_vars:
                etcd_config = {var: os.environ[var] for var in etcd_env_vars}
                return EscapeAttemptResult(
                    method='etcd_exposure',
                    status='suspicious',
                    message='Detected environment variables etcd.',
                    artifact_content=str(etcd_config)
                )
                
            return EscapeAttemptResult(
                method='etcd_exposure',
                status='not_found',
                message='Access to etcd not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='etcd_exposure', status='error', message=str(e))

