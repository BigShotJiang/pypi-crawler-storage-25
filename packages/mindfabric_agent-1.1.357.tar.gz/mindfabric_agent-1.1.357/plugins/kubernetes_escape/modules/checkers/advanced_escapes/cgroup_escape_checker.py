"""
Cgroup Escape Checker

Checks possibilities escape from container via cgroup.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class CgroupEscapeChecker:
    """Checks cgroup escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities escape from container via cgroup."""
        try:
            # Checking for necessary capabilities and access to file system
            if not os.path.exists('/proc/self/status'):
                return EscapeAttemptResult(
                    method='cgroup_escape',
                    status='not_applicable',
                    message='no access to /proc/self/status for Checking capabilities.'
                )
                
            # Checking SYS_ADMIN capability
            status_content = await asyncio.to_thread(lambda: open("/proc/self/status", "r").read())
            cap_lines = [line for line in status_content.splitlines() if line.startswith('Cap')]
            
            if not any('CapEff' in line for line in cap_lines):
                return EscapeAttemptResult(
                    method='cgroup_escape',
                    status='not_applicable',
                    message='Information about capabilities not accessible.'
                )
                
            sys_admin_enabled = False
            for line in cap_lines:
                if line.startswith('CapEff:'):
                    cap_eff = int(line.split()[1], 16)
                    sys_admin_enabled = (cap_eff >> 21) & 1  # CAP_SYS_ADMIN (21)
                    break
            
            if not sys_admin_enabled:
                return EscapeAttemptResult(
                    method='cgroup_escape',
                    status='not_applicable',
                    message='CAP_SYS_ADMIN missing, required for escape via cgroup.'
                )
            
            # Checking mounting capability cgroup filesystem
            cgroup_test_dir = '/tmp/cgroup_test'
            os.makedirs(cgroup_test_dir, exist_ok=True)
            
            rc, _, _ = await run_exec(['mount', '-t', 'cgroup', 'none', cgroup_test_dir], timeout=5)
            if rc != 0:
                return EscapeAttemptResult(
                    method='cgroup_escape',
                    status='not_vulnerable',
                    message='Mounting cgroup failed.'
                )
            
            # If successfully mounted cgroup, Checking possibility to create subgroup and enable notify_on_release
            try:
                test_cgroup = os.path.join(cgroup_test_dir, 'test_cgroup')
                os.makedirs(test_cgroup, exist_ok=True)
                
                # Checking file notify_on_release
                notify_file = os.path.join(test_cgroup, 'notify_on_release')
                if os.path.exists(notify_file):
                    with open(notify_file, 'w') as f:
                        f.write('1')
                    
                    # Checking file release_agent
                    release_agent_file = os.path.join(cgroup_test_dir, 'release_agent')
                    if os.path.exists(release_agent_file):
                        demo_next = "Using access to cgroup, I can configure release_agent for executing arbitrary commands on behalf of root on host. For this will create own cgroup, write command to release_agent and initiate its execution. Can add SSH key, create backdoor or install persistent rootkit on host machine, and then get root access to node and all containers on it."
                        return EscapeAttemptResult(
                            method='cgroup_escape',
                            status='exploited',
                            message='Detected possibility escape from container via cgroup release_agent!',
                            artifact_content=f"CAP_SYS_ADMIN: has\nCgroup: {cgroup_test_dir}\nNotify: {notify_file}\nRelease Agent: {release_agent_file}",
                            demo_next_steps=demo_next
                        )
            except Exception:
                pass
            finally:
                # Unmounting cgroup in any case
                try:
                    await run_exec(['umount', cgroup_test_dir], timeout=5)
                except Exception:
                    pass
            
            # Checking for other signs of cgroup vulnerabilities
            device_cgroup = '/sys/fs/cgroup/devices'
            if os.path.exists(device_cgroup) and os.access(device_cgroup, os.W_OK):
                demo_next = "Having rights for writing in /sys/fs/cgroup/devices, can manipulate device rules, create new subsystems, and use cgroup v1 features for executing commands on behalf of root on host. Main vector - modifying release_agent and creating triggers for executing arbitrary code."
                return EscapeAttemptResult(
                    method='cgroup_escape',
                    status='suspicious',
                    message='detected access for writing in cgroup/devices - potential attack vector.',
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='cgroup_escape',
                status='not_vulnerable',
                message='No possibility of escape detected via cgroup.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='cgroup_escape', status='error', message=str(e))

