"""
Kubernetes API Access Checker

Checks access to Kubernetes API with elevated permissions.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class KubeAPIAccessChecker:
    """Checks Kubernetes API access permissions"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking access to Kubernetes API with elevated permissions."""
        try:
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='kube_api_access',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
                
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking administrative resources
            critical_apis = [
                # Secrets (potentially contain sensitive data)
                ("/api/v1/secrets", "Access to secrets of all cluster!"),
                
                # Access to all pods (potentially can create privileged pod)
                ("/api/v1/pods", "Access to list pods of entire cluster"),
                
                # Access to cluster nodes
                ("/api/v1/nodes", "Access to list/manage cluster nodes"),
                
                # Access to cluster roles (gives high permissions for RBAC management)
                ("/apis/rbac.authorization.k8s.io/v1/clusterroles", "Access to ClusterRoles"),
                
                # API for creating pods
                ("/api/v1/namespaces/default/pods", "Access to create pods in default namespace"),
                
                # API for creating jobs
                ("/apis/batch/v1/jobs", "Access to create Jobs")
            ]
            
            critical_access = []
            for api_path, description in critical_apis:
                curl_cmd = [
                    'curl', '-s',
                    f'https://{api_server}:{api_port}{api_path}',
                    '--header', f'Authorization: Bearer {token}',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                ]
                
                try:
                    rc, out, _ = await run_exec(curl_cmd, timeout=5)
                    if rc == 0 and "items" in out and "Forbidden" not in out:
                        critical_access.append(description)
                except Exception:
                    continue
            
            # If access available to critical APIs
            if critical_access:
                demo_next = "Detected API permissions allow get access to sensitive data and cluster management."
                return EscapeAttemptResult(
                    method='kube_api_access',
                    status='exploited',
                    message=f'Detected access to privileged APIs: {", ".join(critical_access)}.',
                    demo_next_steps=demo_next
                )
            
            # Checking permissions on create/patch resources
            try:
                # Attempt to create ConfigMap to test write permissions
                create_cm_cmd = [
                    'curl', '-s', '-X', 'POST',
                    f'https://{api_server}:{api_port}/api/v1/namespaces/default/configmaps',
                    '--header', f'Authorization: Bearer {token}',
                    '--header', 'Content-Type: application/json',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                    '--data', json.dumps({
                        "apiVersion": "v1",
                        "kind": "ConfigMap",
                        "metadata": {
                            "name": "test-permission-map"
                        },
                        "data": {
                            "test": "value"
                        }
                    })
                ]
                
                rc, out, _ = await run_exec(create_cm_cmd, timeout=5)
                if rc == 0 and "Forbidden" not in out:
                    demo_next = "permissions for creating resources allow creating privileged pods for further escalation."
                    return EscapeAttemptResult(
                        method='kube_api_access',
                        status='exploited',
                        message='detected possibility of creating resources - potential path for privilege escalation.',
                        demo_next_steps=demo_next
                    )
            except Exception:
                pass
                
            return EscapeAttemptResult(
                method='kube_api_access',
                status='limited_access',
                message='Limited access to Kubernetes API without critical rights.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='kube_api_access', status='error', message=str(e))

