"""
BPF Escape Checker

Checks possibilities of using eBPF for privilege escalation.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class BPFEscapeChecker:
    """Checks eBPF escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities of using eBPF for privilege escalation."""
        try:
            # Checking for capability CAP_BPF
            try:
                rc, out, _ = await run_exec(['capsh', '--print'], timeout=5)
                has_cap_bpf = rc == 0 and 'cap_bpf' in (out or "").lower()
            except Exception:
                has_cap_bpf = False
            
            # Checking access to BPF syscalls
            bpf_access = False
            try:
                # Trying to create simple BPF program
                from bcc import BPF
                bpf_test = """
                int kprobe__sys_clone(void *ctx) {
                    return 0;
                }
                """
                BPF(text=bpf_test)
                bpf_access = True
            except:
                # Checking access to /sys/fs/bpf
                if os.path.exists('/sys/fs/bpf') and os.access('/sys/fs/bpf', os.R_OK | os.W_OK):
                    bpf_access = True
            
            if has_cap_bpf or bpf_access:
                demo_next = "detected access to eBPF - this is real jackpot! Immediately using BPF for intercepting syscalls. First will write eBPF program, that intercepts sys_execve and replaces arguments when executing certain commands, for example substituting path to config files of kubernetes. Then will install kprobe on security functions in kernel for bypassing cgroup isolation and AppArmor/SELinux. Especially interesting is tracing functions of input-output and network calls — via them will intercept credentials and sensitive data of other containers. also will inject XDP program for intercepting all host network traffic bypassing container network interface. Using eBPF can get practically invisible rootkit: it works in kernel space, difficult to detect and can modify any kernel data structures. Additionally will configure persistence via bpffs, that will allow malicious code to survive even with reboots and reinstallation of system components."
                return EscapeAttemptResult(
                    method='bpf_escape',
                    status='exploited',
                    message='detected Access to eBPF functionality. CAP_BPF: ' + ('yes' if has_cap_bpf else 'no'),
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='bpf_escape',
                status='not_vulnerable',
                message='Access to eBPF functionality not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='bpf_escape', status='error', message=str(e))

