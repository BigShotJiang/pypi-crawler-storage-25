"""
CNI Plugin Security Bypass Checker

Checks for Container Network Interface (CNI) plugin security bypasses:
- Calico network policy bypass
- Flannel security bypass
- Cilium security bypass
- Weave Net bypass
- Network policy bypass techniques

MITRE ATT&CK: T1611 (Escape to Host), T1557 (Adversary-in-the-Middle)
"""

import os
import socket
import json
import asyncio
from typing import Any, Dict, List, Optional
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_shell


# CNI Plugin Bypass Techniques Database
CNI_BYPASS_TECHNIQUES = {
    "calico": {
        "description": "Calico network policy bypass techniques",
        "checks": [
            {
                "name": "GlobalNetworkPolicy bypass",
                "description": "Bypass GlobalNetworkPolicy via namespace selection",
                "technique": "Create workload in namespace without policy enforcement",
                "detection": "Check for namespaces without Calico NetworkPolicy",
            },
            {
                "name": "HostEndpoint bypass",
                "description": "Bypass by targeting host endpoints directly",
                "technique": "Access host network via privileged containers or hostNetwork",
                "detection": "Check for HostEndpoint policy coverage",
            },
            {
                "name": "Felix agent bypass",
                "description": "Bypass Calico by disabling Felix agent",
                "technique": "Target nodes where Felix is not running or misconfigured",
                "detection": "Check Felix pod status: kubectl get pods -n kube-system -l k8s-app=calico-node",
            },
            {
                "name": "IPPool egress bypass",
                "description": "Bypass egress controls via IPPool manipulation",
                "technique": "Use IP ranges outside Calico managed pools",
                "detection": "Check IPPool configuration: calicoctl get ippool -o yaml",
            },
            {
                "name": "BGP peer manipulation",
                "description": "Manipulate BGP peering for traffic interception",
                "technique": "Inject malicious BGP routes if BGP peering is exposed",
                "detection": "Check BGP configuration: calicoctl node status",
            },
        ],
        "config_paths": [
            "/etc/calico/calicoctl.cfg",
            "/etc/cni/net.d/10-calico.conflist",
            "/var/run/calico/",
        ],
    },
    "flannel": {
        "description": "Flannel network bypass techniques",
        "checks": [
            {
                "name": "No network policy support",
                "description": "Flannel doesn't support NetworkPolicy natively",
                "technique": "All pods can communicate freely in flannel-only clusters",
                "detection": "Check if only flannel is installed without additional CNI",
            },
            {
                "name": "flanneld access",
                "description": "Access flanneld configuration for network mapping",
                "technique": "Read flannel subnet configuration to map network topology",
                "detection": "Check /run/flannel/subnet.env",
            },
            {
                "name": "VXLAN interception",
                "description": "Intercept VXLAN traffic on flannel networks",
                "technique": "Capture VXLAN traffic on port 8472 (default)",
                "detection": "Check for VXLAN interface and traffic",
            },
            {
                "name": "Etcd backend exploitation",
                "description": "Exploit flannel etcd backend for network control",
                "technique": "Modify flannel configuration in etcd",
                "detection": "Check flannel backend type: etcd vs kubernetes",
            },
        ],
        "config_paths": [
            "/run/flannel/subnet.env",
            "/etc/cni/net.d/10-flannel.conflist",
            "/etc/kube-flannel/",
        ],
    },
    "cilium": {
        "description": "Cilium security bypass techniques",
        "checks": [
            {
                "name": "eBPF bypass",
                "description": "Bypass Cilium eBPF enforcement",
                "technique": "Exploit kernel vulnerabilities affecting eBPF",
                "detection": "Check kernel version and eBPF CVEs",
            },
            {
                "name": "Hubble API access",
                "description": "Access Hubble observability for network intelligence",
                "technique": "Query Hubble API for network flow data",
                "detection": "Check Hubble status: hubble status",
            },
            {
                "name": "Cilium API access",
                "description": "Direct access to Cilium API for policy manipulation",
                "technique": "Modify policies via cilium CLI if accessible",
                "detection": "Check cilium CLI access: cilium status",
            },
            {
                "name": "CiliumClusterwideNetworkPolicy bypass",
                "description": "Bypass cluster-wide policies via namespace isolation",
                "technique": "Exploit gaps in ClusterwideNetworkPolicy coverage",
                "detection": "Check CiliumClusterwideNetworkPolicy resources",
            },
            {
                "name": "Identity spoofing",
                "description": "Spoof Cilium security identities",
                "technique": "Manipulate pod labels to assume different identity",
                "detection": "Check identity allocation: cilium identity list",
            },
        ],
        "config_paths": [
            "/etc/cni/net.d/05-cilium.conf",
            "/var/run/cilium/",
            "/sys/fs/bpf/",
        ],
    },
    "weave": {
        "description": "Weave Net bypass techniques",
        "checks": [
            {
                "name": "Weave NPC bypass",
                "description": "Bypass Weave Network Policy Controller",
                "technique": "Target pods before NPC rules are applied",
                "detection": "Check weave-npc pod status",
            },
            {
                "name": "Weave encryption bypass",
                "description": "Bypass Weave dataplane encryption",
                "technique": "Intercept traffic before/after encryption",
                "detection": "Check if Weave encryption is enabled",
            },
            {
                "name": "Weave peer discovery",
                "description": "Exploit Weave peer discovery for node mapping",
                "technique": "Query Weave for peer information",
                "detection": "weave status peers",
            },
        ],
        "config_paths": [
            "/etc/cni/net.d/10-weave.conflist",
            "/var/run/weave/",
        ],
    },
    "generic_bypass": {
        "description": "Generic CNI/network policy bypass techniques",
        "checks": [
            {
                "name": "Direct pod IP access",
                "description": "Bypass network policies via direct pod IP access",
                "technique": "Access pods directly by IP, bypassing service-based policies",
                "detection": "Check if policies are service-based only",
            },
            {
                "name": "DNS exfiltration",
                "description": "Exfiltrate data via DNS queries",
                "technique": "Encode data in DNS queries to bypass egress policies",
                "detection": "Monitor DNS query patterns",
            },
            {
                "name": "ICMP tunneling",
                "description": "Tunnel data via ICMP if not blocked",
                "technique": "Use ICMP echo for data exfiltration",
                "detection": "Check if ICMP is allowed in policies",
            },
            {
                "name": "Service account token abuse",
                "description": "Use service account to query API for network info",
                "technique": "List pods, services, endpoints for network mapping",
                "detection": "Check service account RBAC permissions",
            },
            {
                "name": "NodePort bypass",
                "description": "Access services via NodePort from host network",
                "technique": "Bypass ClusterIP restrictions via NodePort",
                "detection": "Check for NodePort services",
            },
        ],
    },
}


class CNIBypassChecker:
    """Checks for CNI plugin security bypasses"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Check for CNI plugin security bypass opportunities."""
        findings = []
        critical_findings = []
        
        try:
            # Detect which CNI is installed
            cni_type = await self._detect_cni()
            
            # Check generic bypass techniques
            generic_findings = await self._check_generic_bypass()
            findings.extend(generic_findings)
            
            # Check CNI-specific bypasses
            if cni_type:
                cni_findings = self._check_cni_specific(cni_type)
                findings.extend(cni_findings)
                critical_findings.extend([f for f in cni_findings if f.get("severity") == "critical"])
            
            # Check for network policy gaps
            policy_findings = await self._check_network_policy_gaps()
            findings.extend(policy_findings)
            
            # Check for direct network access
            network_findings = self._check_network_access()
            findings.extend(network_findings)
            
            if findings:
                return EscapeAttemptResult(
                    method="CNI_BYPASS",
                    success=len(critical_findings) > 0,
                    vulnerable=True,
                    description=f"Found {len(findings)} CNI security bypass vectors",
                    details={
                        "cni_type": cni_type or "unknown",
                        "findings": findings,
                        "critical_count": len(critical_findings),
                    },
                    reproduction_steps=self._generate_reproduction_steps(findings),
                    mitre_technique="T1611, T1557"
                )
            else:
                return EscapeAttemptResult(
                    method="CNI_BYPASS",
                    success=False,
                    vulnerable=False,
                    description="No CNI bypass vulnerabilities found",
                    details={"cni_type": cni_type or "unknown"},
                    mitre_technique="T1611"
                )
        
        except Exception as e:
            return EscapeAttemptResult(
                method="CNI_BYPASS",
                success=False,
                vulnerable=False,
                description=f"Error during CNI bypass check: {str(e)}",
                mitre_technique="T1611"
            )
    
    async def _detect_cni(self) -> Optional[str]:
        """Detect which CNI plugin is installed."""
        cni_dir = "/etc/cni/net.d/"
        
        if os.path.exists(cni_dir):
            try:
                files = os.listdir(cni_dir)
                for f in files:
                    f_lower = f.lower()
                    if "calico" in f_lower:
                        return "calico"
                    elif "flannel" in f_lower:
                        return "flannel"
                    elif "cilium" in f_lower:
                        return "cilium"
                    elif "weave" in f_lower:
                        return "weave"
                    elif "canal" in f_lower:
                        return "canal"  # Calico + Flannel
            except Exception:
                pass
        
        # Check for running CNI pods
        try:
            cmd = "kubectl get pods -n kube-system -o name 2>/dev/null | head -20"
            rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
            if rc == 0:
                output = (out or "").lower()
                if "calico" in output:
                    return "calico"
                elif "flannel" in output:
                    return "flannel"
                elif "cilium" in output:
                    return "cilium"
                elif "weave" in output:
                    return "weave"
        except Exception:
            pass
        
        return None
    
    async def _check_generic_bypass(self) -> List[Dict[str, Any]]:
        """Check generic network bypass techniques."""
        findings = []
        
        for check in CNI_BYPASS_TECHNIQUES["generic_bypass"]["checks"]:
            finding = {
                "type": "generic_bypass",
                "name": check["name"],
                "description": check["description"],
                "technique": check["technique"],
                "severity": "medium",
            }
            
            # Check if ICMP is accessible
            if check["name"] == "ICMP tunneling":
                try:
                    cmd = "ping -c 1 -W 1 8.8.8.8 2>/dev/null"
                    rc, _, _ = await run_shell(cmd, timeout=5, allow_unsafe_shell=True)
                    if rc == 0:
                        finding["exploitable"] = True
                        finding["severity"] = "high"
                        findings.append(finding)
                except Exception:
                    pass
            
            # Check DNS access
            elif check["name"] == "DNS exfiltration":
                try:
                    await asyncio.get_running_loop().getaddrinfo(
                        "google.com",
                        443,
                        family=socket.AF_INET,
                        type=socket.SOCK_STREAM,
                    )
                    finding["exploitable"] = True
                    finding["severity"] = "medium"
                    findings.append(finding)
                except Exception:
                    pass
        
        return findings
    
    def _check_cni_specific(self, cni_type: str) -> List[Dict[str, Any]]:
        """Check CNI-specific bypass techniques."""
        findings = []
        
        if cni_type not in CNI_BYPASS_TECHNIQUES:
            return findings
        
        cni_config = CNI_BYPASS_TECHNIQUES[cni_type]
        
        # Check config file access
        for config_path in cni_config.get("config_paths", []):
            if os.path.exists(config_path):
                readable = os.access(config_path, os.R_OK)
                writable = os.access(config_path, os.W_OK)
                
                if writable:
                    findings.append({
                        "type": f"{cni_type}_config_writable",
                        "name": f"{cni_type.capitalize()} config writable",
                        "description": f"CNI configuration at {config_path} is writable",
                        "path": config_path,
                        "severity": "critical",
                        "exploitable": True,
                    })
                elif readable:
                    findings.append({
                        "type": f"{cni_type}_config_readable",
                        "name": f"{cni_type.capitalize()} config readable",
                        "description": f"CNI configuration at {config_path} is readable",
                        "path": config_path,
                        "severity": "medium",
                        "exploitable": True,
                    })
        
        # Add CNI-specific checks as informational
        for check in cni_config["checks"]:
            findings.append({
                "type": f"{cni_type}_technique",
                "name": check["name"],
                "description": check["description"],
                "technique": check["technique"],
                "detection": check["detection"],
                "severity": "info",
            })
        
        return findings
    
    async def _check_network_policy_gaps(self) -> List[Dict[str, Any]]:
        """Check for network policy gaps."""
        findings = []
        
        try:
            # Check if NetworkPolicy is defined
            cmd = "kubectl get networkpolicy -A 2>/dev/null | wc -l"
            rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
            if rc == 0:
                count = int((out or "").strip() or "0") - 1  # Subtract header
                if count == 0:
                    findings.append({
                        "type": "no_network_policies",
                        "name": "No NetworkPolicy defined",
                        "description": "Cluster has no NetworkPolicy resources - all pod communication is allowed",
                        "severity": "high",
                        "exploitable": True,
                    })
        except Exception:
            pass
        
        return findings
    
    def _check_network_access(self) -> List[Dict[str, Any]]:
        """Check for network access capabilities."""
        findings = []
        
        # Check for host network access
        try:
            with open("/proc/self/ns/net", "r") as f:
                pass
            with open("/proc/1/ns/net", "r") as f:
                pass
            
            # Compare network namespaces
            my_ns = os.readlink("/proc/self/ns/net")
            host_ns = os.readlink("/proc/1/ns/net")
            
            if my_ns == host_ns:
                findings.append({
                    "type": "host_network",
                    "name": "Host network namespace",
                    "description": "Pod has access to host network namespace",
                    "severity": "critical",
                    "exploitable": True,
                })
        except Exception:
            pass
        
        return findings
    
    def _generate_reproduction_steps(self, findings: List[Dict[str, Any]]) -> List[str]:
        """Generate reproduction steps for findings."""
        steps = ["# CNI Security Bypass Techniques"]
        
        for finding in findings:
            if finding.get("exploitable"):
                if finding["type"] == "host_network":
                    steps.extend([
                        "",
                        "## Host Network Access",
                        "1. Pod has host network - can see all host interfaces",
                        "2. Run: ip addr show",
                        "3. Capture traffic: tcpdump -i any",
                        "4. Access services on 127.0.0.1",
                    ])
                elif "config_writable" in finding["type"]:
                    steps.extend([
                        "",
                        f"## Modify {finding['path']}",
                        f"1. Backup: cp {finding['path']} /tmp/cni-backup",
                        "2. Modify configuration to disable policies",
                        "3. Restart CNI pods or wait for reconciliation",
                    ])
                elif finding["type"] == "no_network_policies":
                    steps.extend([
                        "",
                        "## No Network Policies",
                        "1. All pods can communicate freely",
                        "2. Enumerate cluster: kubectl get pods -A -o wide",
                        "3. Connect to any pod: curl <pod-ip>:<port>",
                    ])
        
        return steps


def get_cni_bypass_techniques() -> Dict[str, Any]:
    """Get all CNI bypass techniques."""
    return CNI_BYPASS_TECHNIQUES

