"""
Containerd Socket Checker

Checks access to containerd socket for creating privileged containers.
"""

import os
from ....proto import EscapeAttemptResult


class ContainerdSockChecker:
    """Checks containerd socket access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check(self) -> EscapeAttemptResult:
        """Checking access to containerd socket for creating privileged containers."""
        try:
            containerd_sockets = [
                "/run/containerd/containerd.sock",
                "/var/run/containerd/containerd.sock",
                "/run/docker/containerd/containerd.sock"
            ]
            
            cri_sockets = [
                "/run/cri-dockerd.sock",
                "/var/run/cri-dockerd.sock",
                "/run/crio/crio.sock",
                "/var/run/crio/crio.sock"
            ]
            
            accessible_sockets = []
            
            for sock in containerd_sockets + cri_sockets:
                if os.path.exists(sock) and os.access(sock, os.R_OK):
                    accessible_sockets.append(sock)
                    
            if accessible_sockets:
                demo_next = "detected access to container runtime sockets! this is a goldmine for cracking cluster. for containerd.sock first will run `crictl pull alpine:latest`, then will create privileged container via crictl with flags privileged=true and hostPID=true. Will mount immediately several critical host directories: root filesystem in /host (to read/write any files), /dev (for access to host devices), and /proc (to see all processes and do ptrace attach to needed ones). Further will install persistent rootkit via hooks in host systemd. for crio.sock using pod sandbox with privileges and custom seccomp profile, which allows all syscalls. After getting full access to host will steal admin kubeconfig from /etc/Kubernetes and will use it for attack on etcd, management components and other nodes. Even if developers removed docker.sock, they often forget about containerd and cri-o sockets, that gives direct access to OCI runtime and allows fully compromising cluster."
                return EscapeAttemptResult(
                    method='containerd_sock_access',
                    status='exploited',
                    message=f'detected access to sockets container runtime: {", ".join(accessible_sockets)}',
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='containerd_sock_access',
                status='not_vulnerable',
                message='Access to sockets container runtime not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='containerd_sock_access', status='error', message=str(e))

