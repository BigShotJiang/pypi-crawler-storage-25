"""
Kubernetes Operator Security Checker

Checks for security issues in Kubernetes Operators:
- Malicious operator deployment
- Operator privilege escalation
- Operator RBAC abuse
- Controller abuse
- CRD manipulation
- Webhook exploitation

MITRE ATT&CK:
- T1610: Deploy Container
- T1078.004: Valid Accounts: Cloud Accounts
- T1611: Escape to Host
"""

import json
import yaml
import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec_stdout


class OperatorRiskLevel(str, Enum):
    """Risk levels for operator security issues."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


# =============================================================================
# Dangerous Operators Database
# =============================================================================

DANGEROUS_OPERATORS = {
    "argo-cd": {
        "name": "Argo CD Operator",
        "risk_areas": ["GitOps access", "Cluster-wide secrets", "Application deployment"],
        "abuse_potential": "HIGH",
        "common_vulnerabilities": ["CVE-2022-24348", "CVE-2022-29165", "CVE-2023-22482"],
    },
    "cert-manager": {
        "name": "Cert Manager",
        "risk_areas": ["Certificate issuance", "CA key access", "DNS validation"],
        "abuse_potential": "MEDIUM",
    },
    "prometheus-operator": {
        "name": "Prometheus Operator",
        "risk_areas": ["Service discovery", "Metric scraping", "Config access"],
        "abuse_potential": "MEDIUM",
    },
    "vault-operator": {
        "name": "Vault Operator",
        "risk_areas": ["Secret management", "Encryption keys", "Authentication"],
        "abuse_potential": "HIGH",
    },
    "external-secrets": {
        "name": "External Secrets Operator",
        "risk_areas": ["Cloud credentials", "Secret sync", "Provider access"],
        "abuse_potential": "HIGH",
    },
    "crossplane": {
        "name": "Crossplane",
        "risk_areas": ["Cloud resource provisioning", "Multi-cloud access", "Provider credentials"],
        "abuse_potential": "CRITICAL",
    },
    "kyverno": {
        "name": "Kyverno",
        "risk_areas": ["Policy enforcement", "Mutation webhooks", "Cluster-wide rules"],
        "abuse_potential": "HIGH",
    },
    "flux": {
        "name": "Flux CD",
        "risk_areas": ["GitOps access", "Image automation", "Helm releases"],
        "abuse_potential": "HIGH",
    },
}


# =============================================================================
# Operator Privilege Escalation Techniques
# =============================================================================

OPERATOR_PRIVESC_TECHNIQUES = {
    "controller_rbac_abuse": {
        "name": "Controller RBAC Abuse",
        "description": "Abuse operator's RBAC permissions for privilege escalation",
        "severity": OperatorRiskLevel.CRITICAL,
        "techniques": [
            "Create pods with operator's service account",
            "Escalate to cluster-admin via operator's roles",
            "Access secrets via operator's permissions",
        ],
        "mitre": "T1078.004",
    },
    "crd_manipulation": {
        "name": "CRD Manipulation",
        "description": "Manipulate Custom Resource Definitions for exploitation",
        "severity": OperatorRiskLevel.HIGH,
        "techniques": [
            "Inject malicious specs in CRDs",
            "Exploit conversion webhooks",
            "Abuse defaulting webhooks",
        ],
        "mitre": "T1610",
    },
    "webhook_hijacking": {
        "name": "Webhook Hijacking",
        "description": "Hijack operator's mutating/validating webhooks",
        "severity": OperatorRiskLevel.CRITICAL,
        "techniques": [
            "Redirect webhook traffic",
            "Modify webhook CA bundle",
            "Inject malicious mutations",
        ],
        "mitre": "T1610",
    },
    "operator_secret_theft": {
        "name": "Operator Secret Theft",
        "description": "Steal secrets used by operators",
        "severity": OperatorRiskLevel.HIGH,
        "techniques": [
            "Access operator's mounted secrets",
            "Steal cloud provider credentials",
            "Extract CA certificates",
        ],
        "mitre": "T1552",
    },
    "controller_code_injection": {
        "name": "Controller Code Injection",
        "description": "Inject malicious code into controller reconciliation",
        "severity": OperatorRiskLevel.CRITICAL,
        "techniques": [
            "Craft malicious custom resources",
            "Exploit template injection in specs",
            "Abuse shell execution in controllers",
        ],
        "mitre": "T1610",
    },
}


# =============================================================================
# Common Operator Vulnerabilities
# =============================================================================

OPERATOR_VULNERABILITIES = {
    "overprivileged_rbac": {
        "name": "Overprivileged RBAC",
        "description": "Operator has more permissions than necessary",
        "severity": OperatorRiskLevel.HIGH,
        "indicators": [
            "cluster-admin binding",
            "Wildcard permissions (*)",
            "secrets access without need",
        ],
        "check": "Review operator's ClusterRole/Role",
    },
    "privileged_pods": {
        "name": "Privileged Operator Pods",
        "description": "Operator runs as privileged container",
        "severity": OperatorRiskLevel.CRITICAL,
        "indicators": [
            "privileged: true",
            "hostPID: true",
            "hostNetwork: true",
        ],
    },
    "no_network_policy": {
        "name": "Missing Network Policy",
        "description": "Operator pods have unrestricted network access",
        "severity": OperatorRiskLevel.MEDIUM,
        "check": "Verify NetworkPolicy exists for operator namespace",
    },
    "insecure_webhooks": {
        "name": "Insecure Webhooks",
        "description": "Operator webhooks lack proper security",
        "severity": OperatorRiskLevel.HIGH,
        "indicators": [
            "Self-signed certificates",
            "No mTLS",
            "Permissive failurePolicy",
        ],
    },
    "exposed_metrics": {
        "name": "Exposed Metrics Endpoint",
        "description": "Operator metrics endpoint leaks sensitive info",
        "severity": OperatorRiskLevel.MEDIUM,
        "indicators": [
            "Metrics accessible without auth",
            "Sensitive labels exposed",
        ],
    },
}


@dataclass
class OperatorSecurityFinding:
    """Finding from operator security check."""
    operator_name: str
    finding_type: str
    severity: OperatorRiskLevel
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    exploitation: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""


class OperatorSecurityChecker:
    """Checks for Kubernetes Operator security issues."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[OperatorSecurityFinding] = []

    async def check(self) -> EscapeAttemptResult:
        """
        Entry point used by the kubernetes_escape orchestrator.
        Converts structured operator findings into a compact EscapeAttemptResult.
        """
        try:
            findings = await self.check_operator_security()
            critical = [f for f in findings if getattr(f, "severity", None) == OperatorRiskLevel.CRITICAL]
            high = [f for f in findings if getattr(f, "severity", None) == OperatorRiskLevel.HIGH]

            if critical:
                return EscapeAttemptResult(
                    method="operator_security",
                    status="exploited",
                    message=f"Found {len(critical)} critical and {len(high)} high risk operator security issues",
                )
            if high:
                return EscapeAttemptResult(
                    method="operator_security",
                    status="suspicious",
                    message=f"Found {len(high)} high risk operator security issues",
                )
            if findings:
                return EscapeAttemptResult(
                    method="operator_security",
                    status="info",
                    message=f"Found {len(findings)} operator security findings",
                )
            return EscapeAttemptResult(
                method="operator_security",
                status="not_vulnerable",
                message="No operator security issues detected",
            )
        except Exception as e:
            return EscapeAttemptResult(method="operator_security", status="error", message=str(e))
    
    async def check_operator_security(self) -> List[OperatorSecurityFinding]:
        """
        Check all operator security issues.
        
        Returns:
            List of operator security findings
        """
        findings = []
        
        # Find installed operators
        operators = await self._find_installed_operators()
        
        for operator in operators:
            # Check RBAC
            rbac_findings = await self._check_operator_rbac(operator)
            findings.extend(rbac_findings)
            
            # Check pod security
            pod_findings = await self._check_operator_pod_security(operator)
            findings.extend(pod_findings)
            
            # Check webhooks
            webhook_findings = await self._check_operator_webhooks(operator)
            findings.extend(webhook_findings)
            
            # Check for known dangerous operators
            danger_findings = self._check_dangerous_operators(operator)
            findings.extend(danger_findings)
        
        # Check for malicious operator indicators
        malicious_findings = await self._check_malicious_operators()
        findings.extend(malicious_findings)
        
        self.findings = findings
        return findings
    
    async def _find_installed_operators(self) -> List[Dict[str, Any]]:
        """Find installed Kubernetes operators."""
        operators = []
        
        try:
            # Find operators by common patterns
            # 1. Check for OLM (Operator Lifecycle Manager)
            olm_out = await run_exec_stdout(["kubectl", "get", "clusterserviceversions", "-A", "-o", "json"], timeout=30)
            if olm_out:
                try:
                    data = json.loads(olm_out)
                    for item in data.get("items", []):
                        operators.append({
                            "name": item.get("metadata", {}).get("name", ""),
                            "namespace": item.get("metadata", {}).get("namespace", ""),
                            "type": "olm",
                            "spec": item.get("spec", {}),
                        })
                except json.JSONDecodeError:
                    pass
            
            # 2. Check for deployments with "-operator" or "-controller" suffix
            deploy_out = await run_exec_stdout(["kubectl", "get", "deployments", "-A", "-o", "json"], timeout=30)
            if deploy_out:
                try:
                    data = json.loads(deploy_out)
                    for item in data.get("items", []):
                        name = item.get("metadata", {}).get("name", "")
                        if "operator" in name.lower() or "controller" in name.lower():
                            operators.append({
                                "name": name,
                                "namespace": item.get("metadata", {}).get("namespace", ""),
                                "type": "deployment",
                                "spec": item.get("spec", {}),
                            })
                except json.JSONDecodeError:
                    pass
                    
        except Exception as e:
            if self.plugin:
                self.plugin.logger.error(f"Error finding operators: {e}")
        
        return operators
    
    async def _check_operator_rbac(
        self,
        operator: Dict[str, Any],
    ) -> List[OperatorSecurityFinding]:
        """Check operator RBAC permissions."""
        findings = []
        operator_name = operator.get("name", "unknown")
        namespace = operator.get("namespace", "default")
        
        try:
            # Find service accounts used by operator
            sa_name = operator_name  # Simplified - actual implementation would parse deployment
            
            # Check ClusterRoleBindings
            crb_out = await run_exec_stdout(["kubectl", "get", "clusterrolebindings", "-o", "json"], timeout=30)
            if crb_out:
                data = json.loads(crb_out)
                for crb in data.get("items", []):
                    subjects = crb.get("subjects", [])
                    role_ref = crb.get("roleRef", {})
                    
                    for subject in subjects:
                        if subject.get("name", "").startswith(operator_name.split("-")[0]):
                            # Check if it's cluster-admin
                            if role_ref.get("name") == "cluster-admin":
                                findings.append(OperatorSecurityFinding(
                                    operator_name=operator_name,
                                    finding_type="overprivileged_rbac",
                                    severity=OperatorRiskLevel.CRITICAL,
                                    description=f"Operator '{operator_name}' has cluster-admin binding",
                                    evidence={
                                        "clusterrolebinding": crb.get("metadata", {}).get("name"),
                                        "role": "cluster-admin",
                                    },
                                    exploitation=OPERATOR_PRIVESC_TECHNIQUES["controller_rbac_abuse"],
                                    mitre_technique="T1078.004",
                                    recommendation="Use least-privilege RBAC for operators",
                                ))
            
            # Check ClusterRoles for dangerous permissions
            cr_out = await run_exec_stdout(["kubectl", "get", "clusterroles", "-o", "json"], timeout=30)
            if cr_out:
                data = json.loads(cr_out)
                for cr in data.get("items", []):
                    cr_name = cr.get("metadata", {}).get("name", "")
                    
                    # Skip if not related to operator
                    if operator_name.split("-")[0].lower() not in cr_name.lower():
                        continue
                    
                    rules = cr.get("rules", [])
                    dangerous_permissions = self._check_dangerous_rbac_rules(rules)
                    
                    if dangerous_permissions:
                        findings.append(OperatorSecurityFinding(
                            operator_name=operator_name,
                            finding_type="dangerous_permissions",
                            severity=OperatorRiskLevel.HIGH,
                            description=f"Operator '{operator_name}' has dangerous RBAC permissions",
                            evidence={
                                "clusterrole": cr_name,
                                "dangerous_permissions": dangerous_permissions,
                            },
                            mitre_technique="T1078.004",
                            recommendation="Review and restrict operator permissions",
                        ))
                        
        except Exception as e:
            if self.plugin:
                self.plugin.logger.error(f"Error checking RBAC for {operator_name}: {e}")
        
        return findings
    
    def _check_dangerous_rbac_rules(
        self,
        rules: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Check RBAC rules for dangerous permissions."""
        dangerous = []
        
        dangerous_patterns = [
            {"verbs": ["*"], "resources": ["*"]},  # Wildcard
            {"verbs": ["create"], "resources": ["pods"]},  # Pod creation
            {"verbs": ["get", "list"], "resources": ["secrets"]},  # Secrets access
            {"verbs": ["create", "update"], "resources": ["clusterroles", "clusterrolebindings"]},  # RBAC escalation
            {"verbs": ["escalate"]},  # Escalate verb
            {"verbs": ["bind"]},  # Bind verb
            {"verbs": ["impersonate"]},  # Impersonation
        ]
        
        for rule in rules:
            verbs = rule.get("verbs", [])
            resources = rule.get("resources", [])
            
            for pattern in dangerous_patterns:
                pattern_verbs = pattern.get("verbs", [])
                pattern_resources = pattern.get("resources", [])
                
                verbs_match = "*" in verbs or any(v in verbs for v in pattern_verbs)
                resources_match = "*" in resources or not pattern_resources or any(r in resources for r in pattern_resources)
                
                if verbs_match and resources_match:
                    dangerous.append({
                        "verbs": verbs,
                        "resources": resources,
                        "reason": f"Matches dangerous pattern: {pattern}",
                    })
                    break
        
        return dangerous
    
    async def _check_operator_pod_security(
        self,
        operator: Dict[str, Any],
    ) -> List[OperatorSecurityFinding]:
        """Check operator pod security settings."""
        findings = []
        operator_name = operator.get("name", "unknown")
        namespace = operator.get("namespace", "default")
        
        try:
            # Get operator pods
            pods_out = await run_exec_stdout(
                ["kubectl", "get", "pods", "-n", namespace, "-l", f"app={operator_name}", "-o", "json"],
                timeout=30,
            )
            if pods_out:
                data = json.loads(pods_out)
                
                for pod in data.get("items", []):
                    pod_name = pod.get("metadata", {}).get("name", "")
                    spec = pod.get("spec", {})
                    
                    # Check hostPID
                    if spec.get("hostPID"):
                        findings.append(OperatorSecurityFinding(
                            operator_name=operator_name,
                            finding_type="privileged_pods",
                            severity=OperatorRiskLevel.CRITICAL,
                            description=f"Operator pod '{pod_name}' has hostPID enabled",
                            evidence={"pod": pod_name, "hostPID": True},
                            mitre_technique="T1611",
                            recommendation="Remove hostPID unless absolutely necessary",
                        ))
                    
                    # Check hostNetwork
                    if spec.get("hostNetwork"):
                        findings.append(OperatorSecurityFinding(
                            operator_name=operator_name,
                            finding_type="privileged_pods",
                            severity=OperatorRiskLevel.HIGH,
                            description=f"Operator pod '{pod_name}' has hostNetwork enabled",
                            evidence={"pod": pod_name, "hostNetwork": True},
                            mitre_technique="T1611",
                            recommendation="Remove hostNetwork unless absolutely necessary",
                        ))
                    
                    # Check containers for privileged mode
                    for container in spec.get("containers", []):
                        security_context = container.get("securityContext", {})
                        
                        if security_context.get("privileged"):
                            findings.append(OperatorSecurityFinding(
                                operator_name=operator_name,
                                finding_type="privileged_pods",
                                severity=OperatorRiskLevel.CRITICAL,
                                description=f"Operator container '{container.get('name')}' runs privileged",
                                evidence={
                                    "pod": pod_name,
                                    "container": container.get("name"),
                                    "privileged": True,
                                },
                                mitre_technique="T1611",
                                recommendation="Remove privileged mode; use specific capabilities instead",
                            ))
                            
        except Exception as e:
            if self.plugin:
                self.plugin.logger.error(f"Error checking pod security for {operator_name}: {e}")
        
        return findings
    
    async def _check_operator_webhooks(
        self,
        operator: Dict[str, Any],
    ) -> List[OperatorSecurityFinding]:
        """Check operator webhooks security."""
        findings = []
        operator_name = operator.get("name", "unknown")
        
        try:
            # Check MutatingWebhookConfigurations
            mwh_out = await run_exec_stdout(["kubectl", "get", "mutatingwebhookconfigurations", "-o", "json"], timeout=30)
            if mwh_out:
                data = json.loads(mwh_out)
                
                for webhook in data.get("items", []):
                    webhook_name = webhook.get("metadata", {}).get("name", "")
                    
                    # Check if related to operator
                    if operator_name.split("-")[0].lower() not in webhook_name.lower():
                        continue
                    
                    for wh in webhook.get("webhooks", []):
                        # Check failurePolicy
                        if wh.get("failurePolicy") == "Ignore":
                            findings.append(OperatorSecurityFinding(
                                operator_name=operator_name,
                                finding_type="insecure_webhooks",
                                severity=OperatorRiskLevel.HIGH,
                                description=f"Webhook '{wh.get('name')}' has failurePolicy=Ignore",
                                evidence={
                                    "webhook": webhook_name,
                                    "failurePolicy": "Ignore",
                                },
                                exploitation=OPERATOR_PRIVESC_TECHNIQUES["webhook_hijacking"],
                                mitre_technique="T1610",
                                recommendation="Use failurePolicy=Fail for security-critical webhooks",
                            ))
                        
                        # Check if webhook has no namespace selector
                        if not wh.get("namespaceSelector"):
                            findings.append(OperatorSecurityFinding(
                                operator_name=operator_name,
                                finding_type="insecure_webhooks",
                                severity=OperatorRiskLevel.MEDIUM,
                                description=f"Webhook '{wh.get('name')}' has no namespace selector",
                                evidence={
                                    "webhook": webhook_name,
                                },
                                mitre_technique="T1610",
                                recommendation="Use namespaceSelector to limit webhook scope",
                            ))
                            
        except Exception as e:
            if self.plugin:
                self.plugin.logger.error(f"Error checking webhooks for {operator_name}: {e}")
        
        return findings
    
    def _check_dangerous_operators(
        self,
        operator: Dict[str, Any],
    ) -> List[OperatorSecurityFinding]:
        """Check if operator is in dangerous operators list."""
        findings = []
        operator_name = operator.get("name", "").lower()
        
        for dangerous_key, dangerous_info in DANGEROUS_OPERATORS.items():
            if dangerous_key in operator_name:
                findings.append(OperatorSecurityFinding(
                    operator_name=operator.get("name", ""),
                    finding_type="dangerous_operator",
                    severity=OperatorRiskLevel.HIGH if dangerous_info["abuse_potential"] == "HIGH" else OperatorRiskLevel.CRITICAL if dangerous_info["abuse_potential"] == "CRITICAL" else OperatorRiskLevel.MEDIUM,
                    description=f"Operator '{dangerous_info['name']}' is installed - has sensitive capabilities",
                    evidence={
                        "risk_areas": dangerous_info["risk_areas"],
                        "abuse_potential": dangerous_info["abuse_potential"],
                        "known_cves": dangerous_info.get("common_vulnerabilities", []),
                    },
                    recommendation=f"Review {dangerous_info['name']} security configuration",
                ))
        
        return findings
    
    async def _check_malicious_operators(self) -> List[OperatorSecurityFinding]:
        """Check for indicators of malicious operators."""
        findings = []
        
        try:
            # Check for recently created operators
            deploy_out = await run_exec_stdout(["kubectl", "get", "deployments", "-A", "-o", "json"], timeout=30)
            if deploy_out:
                data = json.loads(deploy_out)
                
                for item in data.get("items", []):
                    name = item.get("metadata", {}).get("name", "")
                    namespace = item.get("metadata", {}).get("namespace", "")
                    
                    # Check for suspicious patterns
                    suspicious_patterns = [
                        "miner",
                        "cryptojacker",
                        "backdoor",
                        "reverse",
                        "shell",
                    ]
                    
                    for pattern in suspicious_patterns:
                        if pattern in name.lower():
                            findings.append(OperatorSecurityFinding(
                                operator_name=name,
                                finding_type="malicious_operator",
                                severity=OperatorRiskLevel.CRITICAL,
                                description=f"Potentially malicious operator detected: {name}",
                                evidence={
                                    "namespace": namespace,
                                    "suspicious_pattern": pattern,
                                },
                                mitre_technique="T1610",
                                recommendation="Investigate and remove if unauthorized",
                            ))
                            
        except Exception as e:
            if self.plugin:
                self.plugin.logger.error(f"Error checking malicious operators: {e}")
        
        return findings
    
    def get_exploitation_techniques(self) -> Dict[str, Any]:
        """Get operator exploitation techniques."""
        return OPERATOR_PRIVESC_TECHNIQUES
    
    def get_findings(self) -> List[OperatorSecurityFinding]:
        """Get all findings."""
        return self.findings

