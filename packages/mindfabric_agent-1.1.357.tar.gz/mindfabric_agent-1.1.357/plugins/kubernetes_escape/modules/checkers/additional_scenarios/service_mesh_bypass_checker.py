"""
Service Mesh Security Bypass Checker

Checks for service mesh security bypasses:
- Istio mTLS bypass
- Linkerd security bypass
- Consul Connect bypass
- Envoy proxy bypass
- Sidecar injection bypass

MITRE ATT&CK: T1557 (Adversary-in-the-Middle), T1562 (Impair Defenses)
"""

import os
import socket
import json
import asyncio
from typing import Any, Dict, List, Optional
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_shell


# Service Mesh Bypass Techniques Database
SERVICE_MESH_BYPASS = {
    "istio": {
        "description": "Istio service mesh bypass techniques",
        "checks": [
            {
                "name": "mTLS permissive mode",
                "description": "Istio in PERMISSIVE mode accepts both mTLS and plaintext",
                "severity": "high",
                "technique": "Send plaintext requests to services in permissive mode",
                "detection": "kubectl get peerauthentication -A -o yaml | grep mtls",
                "bypass_command": "curl -v http://<pod-ip>:<port> (skip mTLS)",
            },
            {
                "name": "Direct pod IP access",
                "description": "Bypass Istio by accessing pods directly by IP",
                "severity": "high",
                "technique": "Skip service mesh by targeting pod IP directly",
                "detection": "Check if AuthorizationPolicy blocks direct pod access",
                "bypass_command": "curl http://<pod-ip>:8080 (bypass sidecar)",
            },
            {
                "name": "Init container bypass",
                "description": "Bypass istio-init iptables rules",
                "severity": "critical",
                "technique": "Exploit race condition before init container completes",
                "detection": "Check pod init container status",
                "bypass_command": "Access pod during initialization phase",
            },
            {
                "name": "Envoy admin interface",
                "description": "Access Envoy admin interface for config/stats",
                "severity": "high",
                "technique": "Access localhost:15000 from within pod",
                "detection": "curl localhost:15000/stats",
                "bypass_command": "curl localhost:15000/config_dump",
            },
            {
                "name": "Pilot discovery service",
                "description": "Access Istio pilot for service discovery",
                "severity": "medium",
                "technique": "Query pilot for cluster topology",
                "detection": "Check istiod/pilot pod accessibility",
                "bypass_command": "curl istiod.istio-system:15010/debug/",
            },
            {
                "name": "AuthorizationPolicy bypass",
                "description": "Bypass Istio AuthorizationPolicy",
                "severity": "high",
                "technique": "Exploit ALLOW rules or missing policies",
                "detection": "kubectl get authorizationpolicy -A",
                "bypass_methods": [
                    "Target namespaces without AuthorizationPolicy",
                    "Exploit wildcards in source/destination",
                    "Use allowed paths to access sensitive endpoints",
                    "Spoof source principal/namespace",
                ],
            },
            {
                "name": "Sidecar skip ports",
                "description": "Exploit excludeInboundPorts/excludeOutboundPorts",
                "severity": "high",
                "technique": "Use excluded ports to bypass sidecar",
                "detection": "Check traffic.sidecar.istio.io/* annotations",
                "bypass_command": "Connect to excluded port directly",
            },
            {
                "name": "JWT bypass",
                "description": "Bypass RequestAuthentication JWT validation",
                "severity": "high",
                "technique": "Exploit weak JWT validation or missing policies",
                "detection": "kubectl get requestauthentication -A",
                "bypass_methods": [
                    "Send request without JWT to endpoints without policy",
                    "Exploit forwardOriginalToken for token reuse",
                    "Algorithm confusion attacks",
                ],
            },
        ],
        "ports": {
            "envoy_admin": 15000,
            "envoy_outbound": 15001,
            "envoy_inbound": 15006,
            "pilot_grpc": 15010,
            "pilot_https": 15012,
            "citadel": 8060,
            "dns_proxy": 15053,
        },
        "config_paths": [
            "/etc/istio/proxy/",
            "/var/run/secrets/istio/",
            "/etc/certs/",
        ],
    },
    "linkerd": {
        "description": "Linkerd service mesh bypass techniques",
        "checks": [
            {
                "name": "Skip-ports annotation",
                "description": "Exploit config.linkerd.io/skip-*-ports annotations",
                "severity": "high",
                "technique": "Use skipped ports to bypass proxy",
                "detection": "Check pod annotations for skip-ports",
                "bypass_command": "Connect to skipped port directly",
            },
            {
                "name": "Identity injection bypass",
                "description": "Bypass Linkerd identity/mTLS",
                "severity": "high",
                "technique": "Target pods without linkerd-proxy sidecar",
                "detection": "Check for pods without linkerd.io/proxy-version annotation",
                "bypass_command": "curl non-meshed-pod:port",
            },
            {
                "name": "Linkerd admin port",
                "description": "Access Linkerd proxy admin interface",
                "severity": "medium",
                "technique": "Access localhost:4191 for metrics and debug",
                "detection": "curl localhost:4191/metrics",
                "bypass_command": "curl localhost:4191/ready",
            },
            {
                "name": "Server authorization bypass",
                "description": "Bypass Linkerd Server/ServerAuthorization",
                "severity": "high",
                "technique": "Exploit gaps in ServerAuthorization policies",
                "detection": "kubectl get server,serverauthorization -A",
                "bypass_methods": [
                    "Target servers without ServerAuthorization",
                    "Exploit unauthenticated client patterns",
                ],
            },
            {
                "name": "Opaque ports bypass",
                "description": "Exploit opaque port configuration",
                "severity": "medium",
                "technique": "Use opaque ports for non-HTTP traffic",
                "detection": "Check config.linkerd.io/opaque-ports annotation",
            },
        ],
        "ports": {
            "proxy_admin": 4191,
            "proxy_outbound": 4140,
            "proxy_inbound": 4143,
            "control": 8086,
            "destination": 8089,
        },
        "config_paths": [
            "/var/run/linkerd/",
            "/run/linkerd/",
        ],
    },
    "consul_connect": {
        "description": "Consul Connect (Consul Service Mesh) bypass techniques",
        "checks": [
            {
                "name": "Intention bypass",
                "description": "Bypass Consul Connect intentions",
                "severity": "high",
                "technique": "Exploit permissive or missing intentions",
                "detection": "consul intention list",
                "bypass_methods": [
                    "Target services without deny intentions",
                    "Exploit wildcard (*) intentions",
                    "Use allowed source service identity",
                ],
            },
            {
                "name": "Native app mode bypass",
                "description": "Bypass via native app integration without sidecar",
                "severity": "high",
                "technique": "Access native apps directly without mesh",
                "detection": "Check for connect-native services",
            },
            {
                "name": "Transparent proxy bypass",
                "description": "Bypass transparent proxy iptables rules",
                "severity": "medium",
                "technique": "Use excluded ports/CIDRs from traffic interception",
                "detection": "Check connect-inject annotations",
            },
            {
                "name": "Local agent access",
                "description": "Access local Consul agent for service info",
                "severity": "medium",
                "technique": "Query localhost:8500 for service catalog",
                "detection": "curl localhost:8500/v1/catalog/services",
            },
            {
                "name": "ACL token abuse",
                "description": "Abuse Consul ACL tokens for privilege escalation",
                "severity": "critical",
                "technique": "Find and use ACL tokens for unauthorized access",
                "detection": "Check for CONSUL_HTTP_TOKEN or ACL tokens in env/files",
            },
        ],
        "ports": {
            "http_api": 8500,
            "grpc": 8502,
            "dns": 8600,
            "serf_lan": 8301,
            "serf_wan": 8302,
        },
        "config_paths": [
            "/consul/",
            "/etc/consul.d/",
        ],
    },
    "generic": {
        "description": "Generic service mesh bypass techniques",
        "checks": [
            {
                "name": "Sidecar not injected",
                "description": "Pods without sidecar injection",
                "severity": "high",
                "technique": "Access pods that don't have sidecar proxy",
                "detection": "Check for pods without mesh annotations/labels",
            },
            {
                "name": "Pre-sidecar race",
                "description": "Race condition before sidecar initializes",
                "severity": "critical",
                "technique": "Access pod during startup before iptables rules",
                "detection": "Monitor pod initialization timing",
            },
            {
                "name": "Localhost bypass",
                "description": "Access localhost services bypassing mesh",
                "severity": "medium",
                "technique": "Services on 127.0.0.1 often bypass sidecar",
                "detection": "Check for localhost-bound services",
            },
            {
                "name": "UDP traffic bypass",
                "description": "UDP traffic may not be intercepted by sidecar",
                "severity": "medium",
                "technique": "Use UDP protocols for communication",
                "detection": "Check if mesh handles UDP traffic",
            },
            {
                "name": "Certificate theft",
                "description": "Steal mTLS certificates from sidecar",
                "severity": "critical",
                "technique": "Read certificates from proxy config or memory",
                "detection": "Check /etc/certs, /var/run/secrets/",
            },
        ],
    },
}


class ServiceMeshBypassChecker:
    """Checks for service mesh security bypasses"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Check for service mesh security bypass opportunities."""
        findings = []
        critical_findings = []
        
        try:
            # Detect which service mesh is installed
            mesh_type = await self._detect_service_mesh()
            
            # Check for common bypass techniques
            generic_findings = self._check_generic_bypass()
            findings.extend(generic_findings)
            
            # Check mesh-specific bypasses
            if mesh_type:
                mesh_findings = self._check_mesh_specific(mesh_type)
                findings.extend(mesh_findings)
                critical_findings.extend([f for f in mesh_findings if f.get("severity") == "critical"])
            
            # Check for sidecar injection status
            sidecar_findings = await self._check_sidecar_status()
            findings.extend(sidecar_findings)
            
            # Check for accessible admin interfaces
            admin_findings = self._check_admin_interfaces(mesh_type)
            findings.extend(admin_findings)
            critical_findings.extend([f for f in admin_findings if f.get("severity") == "critical"])
            
            if findings:
                return EscapeAttemptResult(
                    method="SERVICE_MESH_BYPASS",
                    success=len(critical_findings) > 0,
                    vulnerable=True,
                    description=f"Found {len(findings)} service mesh bypass vectors",
                    details={
                        "mesh_type": mesh_type or "unknown/none",
                        "findings": findings,
                        "critical_count": len(critical_findings),
                    },
                    reproduction_steps=self._generate_reproduction_steps(findings, mesh_type),
                    mitre_technique="T1557, T1562"
                )
            else:
                return EscapeAttemptResult(
                    method="SERVICE_MESH_BYPASS",
                    success=False,
                    vulnerable=False,
                    description="No service mesh bypass vulnerabilities found",
                    details={"mesh_type": mesh_type or "unknown/none"},
                    mitre_technique="T1557"
                )
        
        except Exception as e:
            return EscapeAttemptResult(
                method="SERVICE_MESH_BYPASS",
                success=False,
                vulnerable=False,
                description=f"Error during service mesh bypass check: {str(e)}",
                mitre_technique="T1557"
            )
    
    async def _detect_service_mesh(self) -> Optional[str]:
        """Detect which service mesh is installed."""
        # Check for Istio sidecar
        if os.path.exists("/etc/istio") or os.path.exists("/var/run/secrets/istio"):
            return "istio"
        
        # Check for Linkerd sidecar
        if os.path.exists("/var/run/linkerd") or os.path.exists("/run/linkerd"):
            return "linkerd"
        
        # Check for Consul Connect
        if os.path.exists("/consul") or os.path.exists("/etc/consul.d"):
            return "consul_connect"
        
        # Check environment variables
        if os.environ.get("ISTIO_META_CLUSTER_ID"):
            return "istio"
        if os.environ.get("LINKERD2_PROXY_LOG"):
            return "linkerd"
        if os.environ.get("CONSUL_HTTP_ADDR"):
            return "consul_connect"
        
        # Check for running processes
        try:
            cmd = "ps aux 2>/dev/null | grep -E 'envoy|linkerd|consul' | head -5"
            rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
            if rc == 0:
                output = (out or "").lower()
                if "pilot-agent" in output or "istio" in output or "/usr/local/bin/envoy" in output:
                    return "istio"
                elif "linkerd" in output:
                    return "linkerd"
                elif "consul" in output and "connect" in output:
                    return "consul_connect"
        except Exception:
            pass
        
        return None
    
    def _check_generic_bypass(self) -> List[Dict[str, Any]]:
        """Check generic service mesh bypass techniques."""
        findings = []
        
        for check in SERVICE_MESH_BYPASS["generic"]["checks"]:
            # Check localhost services
            if check["name"] == "Localhost bypass":
                try:
                    # Check common localhost ports
                    localhost_ports = [8080, 8000, 3000, 5000, 9090]
                    for port in localhost_ports:
                        try:
                            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            s.settimeout(0.5)
                            result = s.connect_ex(("127.0.0.1", port))
                            s.close()
                            if result == 0:
                                findings.append({
                                    "type": "localhost_service",
                                    "name": f"Localhost service on port {port}",
                                    "description": check["description"],
                                    "port": port,
                                    "severity": "medium",
                                    "exploitable": True,
                                })
                        except Exception:
                            pass
                except Exception:
                    pass
            
            # Check certificate locations
            elif check["name"] == "Certificate theft":
                cert_paths = [
                    "/etc/certs/",
                    "/var/run/secrets/istio/",
                    "/var/run/linkerd/identity/",
                    "/var/run/secrets/kubernetes.io/serviceaccount/",
                ]
                for path in cert_paths:
                    if os.path.exists(path):
                        findings.append({
                            "type": "certificate_access",
                            "name": f"Certificate access: {path}",
                            "description": check["description"],
                            "path": path,
                            "severity": "high",
                            "exploitable": os.access(path, os.R_OK),
                        })
        
        return findings
    
    def _check_mesh_specific(self, mesh_type: str) -> List[Dict[str, Any]]:
        """Check mesh-specific bypass techniques."""
        findings = []
        
        if mesh_type not in SERVICE_MESH_BYPASS:
            return findings
        
        mesh_config = SERVICE_MESH_BYPASS[mesh_type]
        
        # Check config file access
        for config_path in mesh_config.get("config_paths", []):
            if os.path.exists(config_path):
                readable = os.access(config_path, os.R_OK)
                if readable:
                    findings.append({
                        "type": f"{mesh_type}_config_access",
                        "name": f"{mesh_type.capitalize()} config accessible",
                        "description": f"Mesh configuration at {config_path} is readable",
                        "path": config_path,
                        "severity": "high",
                        "exploitable": True,
                    })
        
        # Add mesh-specific technique info
        for check in mesh_config["checks"]:
            findings.append({
                "type": f"{mesh_type}_technique",
                "name": check["name"],
                "description": check["description"],
                "technique": check.get("technique", ""),
                "severity": check.get("severity", "info"),
                "detection": check.get("detection", ""),
            })
        
        return findings
    
    async def _check_sidecar_status(self) -> List[Dict[str, Any]]:
        """Check sidecar injection status."""
        findings = []
        
        # Check if running in a pod with sidecar
        envoy_running = False
        linkerd_running = False
        
        try:
            cmd = "ps aux 2>/dev/null | grep -c envoy"
            rc, out, _ = await run_shell(cmd, timeout=5, allow_unsafe_shell=True)
            envoy_running = rc == 0 and int((out or "").strip() or "0") > 1  # More than grep itself
        except Exception:
            pass
        
        try:
            cmd = "ps aux 2>/dev/null | grep -c linkerd-proxy"
            rc, out, _ = await run_shell(cmd, timeout=5, allow_unsafe_shell=True)
            linkerd_running = rc == 0 and int((out or "").strip() or "0") > 1
        except Exception:
            pass
        
        if not envoy_running and not linkerd_running:
            findings.append({
                "type": "no_sidecar",
                "name": "No sidecar proxy detected",
                "description": "Pod may not have service mesh sidecar injection",
                "severity": "high",
                "exploitable": True,
            })
        
        return findings
    
    def _check_admin_interfaces(self, mesh_type: Optional[str]) -> List[Dict[str, Any]]:
        """Check for accessible admin interfaces."""
        findings = []
        
        admin_ports = []
        
        if mesh_type == "istio":
            admin_ports = [
                (15000, "Envoy Admin"),
                (15020, "Merged Prometheus metrics"),
                (15021, "Health checks"),
            ]
        elif mesh_type == "linkerd":
            admin_ports = [
                (4191, "Linkerd Proxy Admin"),
            ]
        elif mesh_type == "consul_connect":
            admin_ports = [
                (8500, "Consul HTTP API"),
            ]
        else:
            # Check all common admin ports
            admin_ports = [
                (15000, "Envoy Admin"),
                (4191, "Linkerd Admin"),
                (8500, "Consul API"),
            ]
        
        for port, name in admin_ports:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1)
                result = s.connect_ex(("127.0.0.1", port))
                s.close()
                
                if result == 0:
                    findings.append({
                        "type": "admin_interface",
                        "name": f"{name} accessible",
                        "description": f"Admin interface {name} is accessible on localhost:{port}",
                        "port": port,
                        "severity": "high",
                        "exploitable": True,
                    })
            except Exception:
                pass
        
        return findings
    
    def _generate_reproduction_steps(self, findings: List[Dict[str, Any]], mesh_type: Optional[str]) -> List[str]:
        """Generate reproduction steps for findings."""
        steps = ["# Service Mesh Bypass Techniques"]
        
        for finding in findings:
            if finding.get("exploitable"):
                if finding["type"] == "admin_interface":
                    port = finding.get("port")
                    if port == 15000:
                        steps.extend([
                            "",
                            "## Envoy Admin Interface",
                            f"1. Access admin: curl localhost:{port}/",
                            f"2. Dump config: curl localhost:{port}/config_dump",
                            f"3. Get stats: curl localhost:{port}/stats",
                            f"4. Modify logging: curl -X POST localhost:{port}/logging?level=debug",
                        ])
                    elif port == 4191:
                        steps.extend([
                            "",
                            "## Linkerd Admin Interface",
                            f"1. Get metrics: curl localhost:{port}/metrics",
                            f"2. Ready check: curl localhost:{port}/ready",
                        ])
                    elif port == 8500:
                        steps.extend([
                            "",
                            "## Consul API Access",
                            f"1. List services: curl localhost:{port}/v1/catalog/services",
                            f"2. List nodes: curl localhost:{port}/v1/catalog/nodes",
                        ])
                
                elif finding["type"] == "no_sidecar":
                    steps.extend([
                        "",
                        "## No Sidecar - Direct Access",
                        "1. Pod is not in service mesh - no mTLS required",
                        "2. Access other pods directly by IP",
                        "3. No AuthorizationPolicy/Intention enforcement",
                    ])
                
                elif "certificate" in finding["type"]:
                    steps.extend([
                        "",
                        f"## Certificate Access: {finding.get('path', '')}",
                        f"1. List certs: ls -la {finding.get('path', '')}",
                        "2. Read cert: cat <path>/cert-chain.pem",
                        "3. Read key: cat <path>/key.pem",
                        "4. Use certs to impersonate service",
                    ])
        
        return steps


def get_service_mesh_bypass_techniques() -> Dict[str, Any]:
    """Get all service mesh bypass techniques."""
    return SERVICE_MESH_BYPASS

