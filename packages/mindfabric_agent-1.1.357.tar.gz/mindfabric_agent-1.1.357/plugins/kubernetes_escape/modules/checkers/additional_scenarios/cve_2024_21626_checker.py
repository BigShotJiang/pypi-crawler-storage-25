"""
CVE-2024-21626 Checker

Checks vulnerabilities containerd runc overlay-FS race (CVE-2024-21626).
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class CVE202421626Checker:
    """Checks CVE-2024-21626 vulnerability"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking vulnerabilities containerd runc overlay-FS race (CVE-2024-21626)."""
        try:
            # Checking version containerd
            containerd_version = ""
            try:
                rc, out, _ = await run_exec(['containerd', '--version'], timeout=5)
                if rc == 0:
                    containerd_version = (out or "").strip()
            except:
                pass
            
            # Checking version runc
            runc_version = ""
            try:
                rc, out, _ = await run_exec(['runc', '--version'], timeout=5)
                if rc == 0:
                    runc_version = (out or "").strip()
            except:
                pass
            
            # Checking for overlayfs
            overlay_used = False
            try:
                with open('/proc/self/mountinfo', 'r') as f:
                    mount_info = f.read()
                    if 'overlay' in mount_info:
                        overlay_used = True
            except:
                pass
            
            # Checking vulnerable versions
            is_vulnerable = False
            
            if overlay_used:
                # vulnerable containerd < 1.6.28, < 1.7.14, and < 2.0.0-rc.1
                if containerd_version:
                    if ('v1.6.' in containerd_version and not any(f'v1.6.{i}' in containerd_version for i in range(28, 100))) or \
                       ('v1.7.' in containerd_version and not any(f'v1.7.{i}' in containerd_version for i in range(14, 100))):
                        is_vulnerable = True
                
                # Vulnerable runc < 1.1.12
                if runc_version and 'runc version 1.1.' in runc_version:
                    minor = int(runc_version.split('runc version 1.1.')[1].split()[0])
                    if minor < 12:
                        is_vulnerable = True
            
            if is_vulnerable:
                demo_next = "Excellent, discovered vulnerability CVE-2024-21626 in containerd/runc! This race condition in overlayFS allows bypassing all limitations for writing in host filesystem. Here is my attack plan: will create two files in container - main and auxiliary. Then will manipulate access rights and swap between files at moment of mounting overlay, using precise race between operations. This will allow getting write-access to any host-system files. First will write SSH key to /root/.ssh/authorized_keys, will create root-user in /etc/passwd and /etc/shadow. Since can modify any executable files, will add backdoor to commonly used utilities like ps or ls - they will forward to my C2 server information about system and execute hidden commands. Also modifying system libraries for persistent RCE, which will survive even with recreated pods. After getting root-access can disable security mechanisms, including SELinux and seccomp, opening full access to all cluster resources."
                return EscapeAttemptResult(
                    method='cve_2024_21626',
                    status='exploited',
                    message='Detected vulnerability containerd runc overlay-FS race (CVE-2024-21626).',
                    artifact_content=f"Containerd version: {containerd_version}\nRunc version: {runc_version}\nOverlayFS: {'used' if overlay_used else 'not used'}",
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='cve_2024_21626',
                status='not_vulnerable',
                message='vulnerability containerd runc overlay-FS race (CVE-2024-21626) not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='cve_2024_21626', status='error', message=str(e))

