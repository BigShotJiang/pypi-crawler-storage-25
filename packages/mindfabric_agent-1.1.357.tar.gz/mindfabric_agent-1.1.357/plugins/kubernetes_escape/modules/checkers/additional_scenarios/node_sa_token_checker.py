"""
Node SA Token Checker

Checks access to tokens serviceAccount node.
"""

import os
import asyncio
from ....proto import EscapeAttemptResult
from utils.async_subprocess import run_exec


class NodeSATokenChecker:
    """Checks node service account token access"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self) -> EscapeAttemptResult:
        """Checking access to tokens serviceAccount node."""
        try:
            # Checking for permissions to read files in /var/lib/kubelet and /etc/Kubernetes
            node_token_paths = [
                "/var/lib/kubelet/pki/kubelet-client-current.pem",
                "/var/lib/kubelet/config.yaml",
                "/etc/kubernetes/kubelet.conf",
                "/var/lib/kubelet/kubeconfig",
                "/var/run/secrets/kubernetes.io/serviceaccount/token"
            ]
            
            accessible_paths = []
            
            for path in node_token_paths:
                if os.path.exists(path) and os.access(path, os.R_OK):
                    accessible_paths.append(path)
                    
            # Checking access to /var/lib/kubelet via directory
            if os.path.exists("/var/lib/kubelet") and os.access("/var/lib/kubelet", os.R_OK):
                _, out, _ = await run_exec(
                    ['find', '/var/lib/kubelet', '-name', '*.pem', '-o', '-name', '*.crt', '-o', '-name', '*.key', '-o', '-name', 'token', '-o', '-name', '*.conf'],
                    timeout=10,
                )
                kubelet_files = (out or "").strip()
                if kubelet_files:
                    for file in kubelet_files.split('\n'):
                        accessible_paths.append(file)
                        
            # Checking, do we have access to /proc with hostPID
            host_proc_access = False
            try:
                proc_1_root = "/proc/1/root"
                if os.path.exists(proc_1_root) and os.access(proc_1_root, os.R_OK):
                    host_proc_access = True
                    # Checking files in /proc/1/root/var/lib/kubelet
                    kubelet_dir = os.path.join(proc_1_root, "var/lib/kubelet")
                    if os.path.exists(kubelet_dir) and os.access(kubelet_dir, os.R_OK):
                        for root, dirs, files in os.walk(kubelet_dir):
                            for file in files:
                                if file.endswith(('.pem', '.crt', '.key', 'token', '.conf')):
                                    accessible_paths.append(os.path.join(root, file))
            except Exception:
                pass
                    
            if accessible_paths or host_proc_access:
                demo_next = "Found goldmine - node cluster tokens and certificates! First will extract kubeconfig and kubelet certificates from /var/lib/kubelet and /etc/Kubernetes. In kubelet.conf contains token with node rights — and this means, that I can register new nodes, manipulate pod binding and get sensitive data about all pods on node. If administrator rights enabled for kubelets (node Authorizer often configured incorrectly), can create privileged pods on any node and read secrets from all namespaces. Especially interesting, that I can create DaemonSets, which will automatically deploy on all nodes of cluster — in this way I will get full control over entire infrastructure. Also will try to inject myself into cluster-admin role via RBAC-manipulation, create direct access to etcd and get all cluster secrets. With node rights can also remotely execute commands via kubelet API, install privileged containers and bypass network policies."
                return EscapeAttemptResult(
                    method='node_sa_token', 
                    status='exploited', 
                    message=f'detected Access to tokens/node certificates cluster. Host proc access: {"yes" if host_proc_access else "no"}',
                    artifact=f"Accessible paths: {', '.join(accessible_paths[:5])}{'...' if len(accessible_paths) > 5 else ''}",
                    demo_next_steps=demo_next
                )
                
            return EscapeAttemptResult(
                method='node_sa_token', 
                status='not_vulnerable', 
                message='Access to tokens/node certificates not detected.'
            )
        except Exception as e:
            return EscapeAttemptResult(method='node_sa_token', status='error', message=str(e))

