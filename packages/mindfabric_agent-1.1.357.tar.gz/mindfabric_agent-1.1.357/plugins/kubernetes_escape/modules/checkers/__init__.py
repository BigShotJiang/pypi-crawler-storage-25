"""
Kubernetes Escape Plugin - Checkers Module

Contains various checkers for detecting Kubernetes escape scenarios.
"""
