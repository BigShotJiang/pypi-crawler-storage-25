"""
Kubernetes Escape Plugin - Modules

Contains checkers, collectors, detection, and database modules.
"""
