"""
Plugin demonstrating and exploiting Kubernetes pod escape and privilege escalation.
"""
from .kubernetes_escape import KubernetesEscapePlugin

__all__ = ['KubernetesEscapePlugin']