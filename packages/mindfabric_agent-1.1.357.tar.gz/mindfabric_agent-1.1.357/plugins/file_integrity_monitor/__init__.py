"""
File Integrity Monitor Plugin

Comprehensive file integrity monitoring covering:
- Baseline creation and comparison
- Change detection (create, modify, delete, rename)
- Hash verification (MD5, SHA1, SHA256, SHA512)
- Attribute monitoring (permissions, ownership, timestamps)
- Compliance mapping (PCI-DSS, HIPAA, SOX, NIST)
- Real-time and scheduled monitoring
- Critical system file monitoring
- MITRE ATT&CK mapping
"""

from .file_integrity_monitor import (
    FileIntegrityMonitorPlugin,
    create_baseline,
    compare_to_baseline,
    get_critical_files,
    get_default_rules,
    calculate_file_hash,
    get_change_types,
    get_compliance_frameworks,
)

# Import services
from .modules.services import (
    FileScanner,
    BaselineManager,
    CriticalFileChecker,
)

# Import utilities
from .modules.utils import (
    calculate_risk_score,
    get_mitre_reference,
    detect_os,
    get_file_type,
    calculate_hash,
    get_file_metadata,
)

# Import databases
from .modules.databases.fim_databases import (
    CRITICAL_FILES_LINUX,
    CRITICAL_FILES_WINDOWS,
    DEFAULT_RULES_LINUX,
    DEFAULT_RULES_WINDOWS,
)
from .proto import (
    # Enums
    SeverityLevel,
    ConfidenceLevel,
    FindingStatus,
    OperatingSystem,
    ChangeType,
    FileType,
    HashAlgorithm,
    MonitoringMode,
    ComplianceFramework,
    ComplianceRequirement,
    AlertLevel,
    MitreTactic,
    MitreTechnique,
    # MITRE
    MitreAttackReference,
    # File Models
    FilePermissions,
    FileOwnership,
    FileHashes,
    FileTimestamps,
    FileMetadata,
    # Change Models
    AttributeChange,
    FileChange,
    # Rule Models
    MonitoringRule,
    CriticalFileDefinition,
    # Baseline Models
    BaselineEntry,
    Baseline,
    # Finding
    FIMFinding,
    # Config
    ScanTarget,
    ScanOptions,
    # Output
    SeveritySummary,
    ChangeTypeSummary,
    ComplianceSummary,
    PathSummary,
    RuleSummary,
    ScanMetadata,
    FIMScanOutput,
)

__all__ = [
    # Main classes
    "FileIntegrityMonitorPlugin",
    "create_baseline",
    "compare_to_baseline",
    "get_critical_files",
    "get_default_rules",
    "calculate_file_hash",
    "get_change_types",
    "get_compliance_frameworks",
    # Components
    "FileScanner",
    "BaselineManager",
    "CriticalFileChecker",
    # Utility functions
    "calculate_risk_score",
    "get_mitre_reference",
    "detect_os",
    "get_file_type",
    "calculate_hash",
    "get_file_metadata",
    # Databases
    "CRITICAL_FILES_LINUX",
    "CRITICAL_FILES_WINDOWS",
    "DEFAULT_RULES_LINUX",
    "DEFAULT_RULES_WINDOWS",
    # Enums
    "SeverityLevel",
    "ConfidenceLevel",
    "FindingStatus",
    "OperatingSystem",
    "ChangeType",
    "FileType",
    "HashAlgorithm",
    "MonitoringMode",
    "ComplianceFramework",
    "ComplianceRequirement",
    "AlertLevel",
    "MitreTactic",
    "MitreTechnique",
    # MITRE
    "MitreAttackReference",
    # File Models
    "FilePermissions",
    "FileOwnership",
    "FileHashes",
    "FileTimestamps",
    "FileMetadata",
    # Change Models
    "AttributeChange",
    "FileChange",
    # Rule Models
    "MonitoringRule",
    "CriticalFileDefinition",
    # Baseline Models
    "BaselineEntry",
    "Baseline",
    # Finding
    "FIMFinding",
    # Config
    "ScanTarget",
    "ScanOptions",
    # Output
    "SeveritySummary",
    "ChangeTypeSummary",
    "ComplianceSummary",
    "PathSummary",
    "RuleSummary",
    "ScanMetadata",
    "FIMScanOutput",
]

__version__ = "1.0.0"
