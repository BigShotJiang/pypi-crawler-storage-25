"""
File Integrity Monitor Databases

Contains static data: critical files, monitoring rules, MITRE mappings.
"""

from typing import Dict, List, Tuple

from ...proto import (
    ChangeType,
    ComplianceRequirement,
    CriticalFileDefinition,
    MitreTechnique,
    MitreTactic,
    MonitoringRule,
    OperatingSystem,
    SeverityLevel,
)

CRITICAL_FILES_WINDOWS: List[CriticalFileDefinition] = [
    # System files
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\config\\SAM",
        description="Security Account Manager database",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1003,
    ),
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\config\\SYSTEM",
        description="System registry hive",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1003,
    ),
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\config\\SECURITY",
        description="Security registry hive",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1003,
    ),
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\drivers\\etc\\hosts",
        description="DNS hosts file",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1565,
    ),
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\cmd.exe",
        description="Command interpreter",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        description="PowerShell interpreter",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    # Startup locations
    CriticalFileDefinition(
        path="C:\\Windows\\System32\\Tasks",
        description="Scheduled tasks directory",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1053,
    ),
]

CRITICAL_FILES_LINUX: List[CriticalFileDefinition] = [
    # Authentication
    CriticalFileDefinition(
        path="/etc/passwd",
        description="User account information",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5, ComplianceRequirement.NIST_SI_7],
        mitre=MitreTechnique.T1136,
    ),
    CriticalFileDefinition(
        path="/etc/shadow",
        description="Encrypted password file",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5, ComplianceRequirement.NIST_SI_7],
        mitre=MitreTechnique.T1003,
    ),
    CriticalFileDefinition(
        path="/etc/group",
        description="Group account information",
        severity=SeverityLevel.HIGH,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1136,
    ),
    CriticalFileDefinition(
        path="/etc/sudoers",
        description="Sudo configuration",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1548,
    ),
    CriticalFileDefinition(
        path="/etc/sudoers.d",
        description="Sudo configuration directory",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1548,
    ),
    # SSH
    CriticalFileDefinition(
        path="/etc/ssh/sshd_config",
        description="SSH server configuration",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1546,
    ),
    CriticalFileDefinition(
        path="/root/.ssh/authorized_keys",
        description="Root SSH authorized keys",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1547,
    ),
    # System configuration
    CriticalFileDefinition(
        path="/etc/hosts",
        description="DNS hosts file",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1565,
    ),
    CriticalFileDefinition(
        path="/etc/resolv.conf",
        description="DNS resolver configuration",
        severity=SeverityLevel.MEDIUM,
        mitre=MitreTechnique.T1565,
    ),
    CriticalFileDefinition(
        path="/etc/fstab",
        description="Filesystem mount configuration",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1547,
    ),
    # Startup
    CriticalFileDefinition(
        path="/etc/crontab",
        description="System cron configuration",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1053,
    ),
    CriticalFileDefinition(
        path="/etc/cron.d",
        description="Cron jobs directory",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1053,
    ),
    CriticalFileDefinition(
        path="/etc/rc.local",
        description="Startup script",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1037,
    ),
    CriticalFileDefinition(
        path="/etc/init.d",
        description="Init scripts directory",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
    CriticalFileDefinition(
        path="/etc/systemd/system",
        description="Systemd unit files",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
    # Security
    CriticalFileDefinition(
        path="/etc/pam.d",
        description="PAM configuration",
        severity=SeverityLevel.CRITICAL,
        compliance=[ComplianceRequirement.PCI_DSS_11_5],
        mitre=MitreTechnique.T1547,
    ),
    CriticalFileDefinition(
        path="/etc/security",
        description="Security limits and access",
        severity=SeverityLevel.HIGH,
    ),
    # Binaries
    CriticalFileDefinition(
        path="/bin",
        description="Essential binaries",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="/sbin",
        description="System binaries",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="/usr/bin",
        description="User binaries",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="/usr/sbin",
        description="System administration binaries",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1574,
    ),
    # Kernel
    CriticalFileDefinition(
        path="/boot",
        description="Boot files and kernel",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1547,
    ),
    # Shared libraries
    CriticalFileDefinition(
        path="/lib",
        description="Essential shared libraries",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="/lib64",
        description="64-bit shared libraries",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
]


# =============================================================================

# Default Monitoring Rules
# =============================================================================

DEFAULT_RULES_LINUX: List[MonitoringRule] = [
    MonitoringRule(
        id="linux-auth-files",
        name="Linux Authentication Files",
        description="Monitor critical authentication files",
        paths=["/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow"],
        recursive=False,
        severity=SeverityLevel.CRITICAL,
        compliance_tags=[
            ComplianceRequirement.PCI_DSS_11_5,
            ComplianceRequirement.NIST_SI_7,
        ],
        mitre_technique=MitreTechnique.T1136,
    ),
    MonitoringRule(
        id="linux-ssh-config",
        name="SSH Configuration",
        description="Monitor SSH configuration and keys",
        paths=["/etc/ssh", "/root/.ssh"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        compliance_tags=[ComplianceRequirement.PCI_DSS_11_5],
        mitre_technique=MitreTechnique.T1546,
    ),
    MonitoringRule(
        id="linux-sudo-config",
        name="Sudo Configuration",
        description="Monitor sudo configuration",
        paths=["/etc/sudoers", "/etc/sudoers.d"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1548,
    ),
    MonitoringRule(
        id="linux-cron",
        name="Cron Jobs",
        description="Monitor cron configurations",
        paths=[
            "/etc/crontab",
            "/etc/cron.d",
            "/etc/cron.daily",
            "/etc/cron.hourly",
            "/etc/cron.weekly",
            "/etc/cron.monthly",
            "/var/spool/cron",
        ],
        recursive=True,
        severity=SeverityLevel.HIGH,
        compliance_tags=[ComplianceRequirement.PCI_DSS_11_5],
        mitre_technique=MitreTechnique.T1053,
    ),
    MonitoringRule(
        id="linux-systemd",
        name="Systemd Services",
        description="Monitor systemd unit files",
        paths=["/etc/systemd/system", "/lib/systemd/system"],
        recursive=True,
        exclude_patterns=["*.wants"],
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1543,
    ),
    MonitoringRule(
        id="linux-pam",
        name="PAM Configuration",
        description="Monitor PAM modules",
        paths=["/etc/pam.d", "/etc/security"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1547,
    ),
    MonitoringRule(
        id="linux-network",
        name="Network Configuration",
        description="Monitor network configuration files",
        paths=["/etc/hosts", "/etc/resolv.conf", "/etc/networks"],
        recursive=False,
        severity=SeverityLevel.MEDIUM,
        mitre_technique=MitreTechnique.T1565,
    ),
    MonitoringRule(
        id="linux-binaries",
        name="System Binaries",
        description="Monitor critical system binaries",
        paths=["/bin", "/sbin", "/usr/bin", "/usr/sbin"],
        recursive=True,
        monitor_content=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1574,
    ),
    MonitoringRule(
        id="linux-libraries",
        name="Shared Libraries",
        description="Monitor shared libraries",
        paths=["/lib", "/lib64", "/usr/lib", "/usr/lib64"],
        recursive=True,
        exclude_patterns=["*.pyc", "*.pyo", "__pycache__"],
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1574,
    ),
    MonitoringRule(
        id="linux-logs",
        name="Log Files",
        description="Monitor log file integrity",
        paths=["/var/log"],
        recursive=True,
        monitor_content=False,  # Don't hash logs
        monitor_permissions=True,
        alert_on=[ChangeType.DELETED, ChangeType.PERMISSIONS_CHANGED],
        severity=SeverityLevel.MEDIUM,
        compliance_tags=[ComplianceRequirement.PCI_DSS_10_5],
        mitre_technique=MitreTechnique.T1070,
    ),
]

DEFAULT_RULES_WINDOWS: List[MonitoringRule] = [
    MonitoringRule(
        id="windows-system32",
        name="Windows System32",
        description="Monitor System32 executables",
        paths=["C:\\Windows\\System32"],
        recursive=False,
        exclude_extensions=[".log", ".tmp", ".etl"],
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1574,
    ),
    MonitoringRule(
        id="windows-registry-hives",
        name="Registry Hives",
        description="Monitor registry hive files",
        paths=[
            "C:\\Windows\\System32\\config\\SAM",
            "C:\\Windows\\System32\\config\\SYSTEM",
            "C:\\Windows\\System32\\config\\SECURITY",
            "C:\\Windows\\System32\\config\\SOFTWARE",
        ],
        recursive=False,
        severity=SeverityLevel.CRITICAL,
        compliance_tags=[ComplianceRequirement.PCI_DSS_11_5],
        mitre_technique=MitreTechnique.T1003,
    ),
    MonitoringRule(
        id="windows-drivers",
        name="Windows Drivers",
        description="Monitor driver files",
        paths=["C:\\Windows\\System32\\drivers"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1547,
    ),
    MonitoringRule(
        id="windows-tasks",
        name="Scheduled Tasks",
        description="Monitor scheduled tasks",
        paths=["C:\\Windows\\System32\\Tasks"],
        recursive=True,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1053,
    ),
    MonitoringRule(
        id="windows-hosts",
        name="Hosts File",
        description="Monitor hosts file",
        paths=["C:\\Windows\\System32\\drivers\\etc\\hosts"],
        recursive=False,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1565,
    ),
    MonitoringRule(
        id="windows-startup",
        name="Startup Folders",
        description="Monitor startup locations",
        paths=[
            "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup",
        ],
        recursive=True,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1547,
    ),
]


# =============================================================================
# Container Critical Files
# =============================================================================

CRITICAL_FILES_CONTAINER: List[CriticalFileDefinition] = [
    # Docker
    CriticalFileDefinition(
        path="/var/run/docker.sock",
        description="Docker socket - container escape vector",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1574,
    ),
    CriticalFileDefinition(
        path="/etc/docker/daemon.json",
        description="Docker daemon configuration",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
    # Kubernetes
    CriticalFileDefinition(
        path="/var/run/secrets/kubernetes.io/serviceaccount/token",
        description="Kubernetes service account token",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="/var/run/secrets/kubernetes.io/serviceaccount/ca.crt",
        description="Kubernetes CA certificate",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="/etc/kubernetes/admin.conf",
        description="Kubernetes admin configuration",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="/etc/kubernetes/kubelet.conf",
        description="Kubelet configuration",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
    CriticalFileDefinition(
        path="/etc/kubernetes/pki",
        description="Kubernetes PKI certificates",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    # Container runtime
    CriticalFileDefinition(
        path="/etc/containerd/config.toml",
        description="containerd configuration",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
    CriticalFileDefinition(
        path="/etc/crio/crio.conf",
        description="CRI-O configuration",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1543,
    ),
]


# =============================================================================
# Container Monitoring Rules
# =============================================================================

DEFAULT_RULES_CONTAINER: List[MonitoringRule] = [
    MonitoringRule(
        id="container-docker-config",
        name="Docker Configuration",
        description="Monitor Docker daemon and client configuration",
        paths=[
            "/etc/docker",
            "/var/lib/docker/containers",
            "/root/.docker",
        ],
        recursive=True,
        exclude_patterns=["*.log", "*.tmp"],
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1543,
    ),
    MonitoringRule(
        id="container-k8s-secrets",
        name="Kubernetes Secrets",
        description="Monitor Kubernetes mounted secrets",
        paths=[
            "/var/run/secrets/kubernetes.io",
            "/etc/kubernetes",
        ],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        compliance_tags=[ComplianceRequirement.PCI_DSS_11_5],
        mitre_technique=MitreTechnique.T1552,
    ),
    MonitoringRule(
        id="container-runtime-config",
        name="Container Runtime Configuration",
        description="Monitor container runtime configurations",
        paths=[
            "/etc/containerd",
            "/etc/crio",
            "/run/containerd",
        ],
        recursive=True,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1543,
    ),
    MonitoringRule(
        id="container-cni",
        name="Container Network Interface",
        description="Monitor CNI plugin configuration",
        paths=[
            "/etc/cni/net.d",
            "/opt/cni/bin",
        ],
        recursive=True,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1565,
    ),
]


# =============================================================================
# Git Repository Monitoring Rules
# =============================================================================

DEFAULT_RULES_GIT: List[MonitoringRule] = [
    MonitoringRule(
        id="git-hooks",
        name="Git Hooks",
        description="Monitor Git hooks for malicious modifications",
        paths=[".git/hooks"],
        recursive=False,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1546,
    ),
    MonitoringRule(
        id="git-config",
        name="Git Configuration",
        description="Monitor Git configuration files",
        paths=[".git/config", ".gitconfig", ".gitmodules"],
        recursive=False,
        severity=SeverityLevel.MEDIUM,
        mitre_technique=MitreTechnique.T1565,
    ),
    MonitoringRule(
        id="git-submodules",
        name="Git Submodules",
        description="Monitor Git submodule configuration for supply chain attacks",
        paths=[".gitmodules"],
        recursive=False,
        severity=SeverityLevel.HIGH,
        mitre_technique=MitreTechnique.T1574,
    ),
]


# =============================================================================
# Cloud Configuration Files
# =============================================================================

CRITICAL_FILES_CLOUD: List[CriticalFileDefinition] = [
    # AWS
    CriticalFileDefinition(
        path="~/.aws/credentials",
        description="AWS credentials file",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="~/.aws/config",
        description="AWS configuration file",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1552,
    ),
    # GCP
    CriticalFileDefinition(
        path="~/.config/gcloud/credentials.db",
        description="GCP credentials database",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="~/.config/gcloud/application_default_credentials.json",
        description="GCP application default credentials",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    # Azure
    CriticalFileDefinition(
        path="~/.azure/accessTokens.json",
        description="Azure access tokens",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path="~/.azure/azureProfile.json",
        description="Azure profile",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1552,
    ),
    # Terraform
    CriticalFileDefinition(
        path="terraform.tfstate",
        description="Terraform state file (may contain secrets)",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
    CriticalFileDefinition(
        path=".terraform",
        description="Terraform configuration directory",
        severity=SeverityLevel.HIGH,
        mitre=MitreTechnique.T1565,
    ),
    # Ansible
    CriticalFileDefinition(
        path="~/.ansible/vault_password_file",
        description="Ansible vault password file",
        severity=SeverityLevel.CRITICAL,
        mitre=MitreTechnique.T1552,
    ),
]


DEFAULT_RULES_CLOUD: List[MonitoringRule] = [
    MonitoringRule(
        id="cloud-aws-config",
        name="AWS Configuration",
        description="Monitor AWS CLI configuration and credentials",
        paths=["~/.aws"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        compliance_tags=[ComplianceRequirement.PCI_DSS_11_5],
        mitre_technique=MitreTechnique.T1552,
    ),
    MonitoringRule(
        id="cloud-gcp-config",
        name="GCP Configuration",
        description="Monitor GCP CLI configuration and credentials",
        paths=["~/.config/gcloud"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1552,
    ),
    MonitoringRule(
        id="cloud-azure-config",
        name="Azure Configuration",
        description="Monitor Azure CLI configuration and credentials",
        paths=["~/.azure"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1552,
    ),
    MonitoringRule(
        id="cloud-terraform-state",
        name="Terraform State",
        description="Monitor Terraform state files for secret exposure",
        paths=["terraform.tfstate", "*.tfstate", ".terraform"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1552,
    ),
    MonitoringRule(
        id="cloud-kubeconfig",
        name="Kubeconfig Files",
        description="Monitor Kubernetes configuration files",
        paths=["~/.kube/config", "/etc/kubernetes"],
        recursive=True,
        severity=SeverityLevel.CRITICAL,
        mitre_technique=MitreTechnique.T1552,
    ),
]


# =============================================================================
# Binary Signature Verification
# =============================================================================

SIGNED_BINARY_PATHS: Dict[str, List[str]] = {
    "linux": [
        "/bin",
        "/sbin",
        "/usr/bin",
        "/usr/sbin",
        "/usr/local/bin",
    ],
    "windows": [
        "C:\\Windows\\System32",
        "C:\\Windows\\SysWOW64",
        "C:\\Program Files",
        "C:\\Program Files (x86)",
    ],
    "macos": [
        "/usr/bin",
        "/usr/sbin",
        "/usr/local/bin",
        "/Applications",
    ],
}


# Known good binary hashes (example structure)
KNOWN_GOOD_HASHES: Dict[str, Dict[str, str]] = {
    # Format: "binary_name": {"sha256": "hash", "version": "1.0.0"}
    # This would be populated from a trusted source
}


# =============================================================================
# Container Image Integrity
# =============================================================================

CONTAINER_IMAGE_INTEGRITY: Dict[str, Dict[str, any]] = {
    "docker": {
        "description": "Docker container image integrity checks",
        "image_config_paths": [
            "/var/lib/docker/image",
            "/var/lib/docker/overlay2",
            "/var/lib/docker/containers",
        ],
        "integrity_checks": {
            "layer_verification": "Verify layer digests match manifest",
            "config_integrity": "Check image config against signed manifest",
            "rootfs_integrity": "Verify rootfs checksum",
        },
        "suspicious_indicators": [
            "modified base layer",
            "unsigned image",
            "missing manifest",
            "tampered entrypoint",
        ],
        "mitre": "T1525",
    },
    "containerd": {
        "description": "containerd image integrity checks",
        "image_config_paths": [
            "/var/lib/containerd/io.containerd.content.v1.content",
            "/var/lib/containerd/io.containerd.snapshotter.v1.overlayfs",
        ],
        "integrity_checks": {
            "content_store": "Verify content store integrity",
            "snapshot_integrity": "Check snapshot metadata",
        },
        "mitre": "T1525",
    },
    "podman": {
        "description": "Podman container image integrity checks",
        "image_config_paths": [
            "~/.local/share/containers/storage",
            "/var/lib/containers/storage",
        ],
        "integrity_checks": {
            "sigstore_verification": "Verify sigstore signatures",
            "gpg_signature": "Verify GPG signatures",
        },
        "mitre": "T1525",
    },
    "kubernetes": {
        "description": "Kubernetes image integrity checks",
        "paths": [
            "/etc/kubernetes/manifests",
            "/var/lib/kubelet/pods",
        ],
        "integrity_checks": {
            "pod_manifest": "Verify pod manifest integrity",
            "image_pull_secrets": "Monitor image pull secret changes",
            "admission_policies": "Check image admission policies",
        },
        "mitre": "T1610",
    },
}


# =============================================================================
# Real-time Monitoring Configuration
# =============================================================================

REALTIME_MONITORING_CONFIG: Dict[str, any] = {
    "inotify_linux": {
        "description": "Linux inotify-based real-time monitoring",
        "events": [
            "IN_CREATE",
            "IN_DELETE",
            "IN_MODIFY",
            "IN_ATTRIB",
            "IN_MOVE",
            "IN_CLOSE_WRITE",
        ],
        "max_watches": 65536,
        "critical_paths": [
            "/etc/passwd",
            "/etc/shadow",
            "/etc/sudoers",
            "/etc/ssh/sshd_config",
            "/root/.ssh/authorized_keys",
        ],
    },
    "fsevents_macos": {
        "description": "macOS FSEvents-based real-time monitoring",
        "events": [
            "kFSEventStreamEventFlagItemCreated",
            "kFSEventStreamEventFlagItemRemoved",
            "kFSEventStreamEventFlagItemModified",
            "kFSEventStreamEventFlagItemRenamed",
            "kFSEventStreamEventFlagItemXattrMod",
        ],
        "critical_paths": [
            "/etc/passwd",
            "/etc/sudoers",
            "/private/var/db/dslocal",
            "~/Library/LaunchAgents",
        ],
    },
    "usn_journal_windows": {
        "description": "Windows USN Journal-based real-time monitoring",
        "events": [
            "USN_REASON_FILE_CREATE",
            "USN_REASON_FILE_DELETE",
            "USN_REASON_DATA_OVERWRITE",
            "USN_REASON_SECURITY_CHANGE",
            "USN_REASON_RENAME_NEW_NAME",
        ],
        "critical_paths": [
            "C:\\Windows\\System32\\config\\SAM",
            "C:\\Windows\\System32\\config\\SYSTEM",
            "C:\\Windows\\System32\\drivers\\etc\\hosts",
        ],
    },
    "alert_thresholds": {
        "rapid_changes": {
            "description": "Alert on rapid file changes (potential ransomware)",
            "threshold": 100,
            "window_seconds": 60,
            "severity": SeverityLevel.CRITICAL,
            "mitre": "T1486",
        },
        "sensitive_file_access": {
            "description": "Alert on sensitive file access",
            "severity": SeverityLevel.HIGH,
            "mitre": "T1005",
        },
        "permission_escalation": {
            "description": "Alert on permission escalation",
            "severity": SeverityLevel.CRITICAL,
            "mitre": "T1548",
        },
    },
}


# =============================================================================
# Configuration File Templates
# =============================================================================

CRITICAL_CONFIG_FILES: Dict[str, List[Dict[str, any]]] = {
    "web_servers": [
        {
            "path": "/etc/nginx/nginx.conf",
            "description": "Nginx main configuration",
            "severity": SeverityLevel.HIGH,
            "check_patterns": ["listen", "server_name", "ssl_certificate"],
        },
        {
            "path": "/etc/apache2/apache2.conf",
            "description": "Apache main configuration",
            "severity": SeverityLevel.HIGH,
            "check_patterns": ["Listen", "ServerName", "DocumentRoot"],
        },
    ],
    "databases": [
        {
            "path": "/etc/mysql/my.cnf",
            "description": "MySQL configuration",
            "severity": SeverityLevel.HIGH,
            "check_patterns": ["bind-address", "port", "skip-grant-tables"],
        },
        {
            "path": "/etc/postgresql/*/postgresql.conf",
            "description": "PostgreSQL configuration",
            "severity": SeverityLevel.HIGH,
            "check_patterns": ["listen_addresses", "port", "ssl"],
        },
    ],
    "authentication": [
        {
            "path": "/etc/pam.d/*",
            "description": "PAM configuration",
            "severity": SeverityLevel.CRITICAL,
            "check_patterns": ["auth", "account", "password", "session"],
        },
        {
            "path": "/etc/nsswitch.conf",
            "description": "Name Service Switch configuration",
            "severity": SeverityLevel.HIGH,
            "check_patterns": ["passwd", "shadow", "group"],
        },
    ],
}


# =============================================================================
# MITRE Mappings
# =============================================================================

CHANGE_TYPE_MITRE: Dict[ChangeType, Tuple[MitreTactic, MitreTechnique]] = {
    ChangeType.DELETED: (MitreTactic.DEFENSE_EVASION, MitreTechnique.T1070_004),
    ChangeType.PERMISSIONS_CHANGED: (MitreTactic.DEFENSE_EVASION, MitreTechnique.T1222),
    ChangeType.CONTENT_CHANGED: (MitreTactic.IMPACT, MitreTechnique.T1565),
}


# =============================================================================
