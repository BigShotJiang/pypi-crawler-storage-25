"""
File Integrity Monitor UI templates.

Centralizes analyst-oriented text for:
- impact (why file changes matter)
- fallback recommendations (when missing)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple


def get_fim_guidance(
    *,
    change_type: Optional[str],
    file_path: Optional[str] = None,
) -> Tuple[str, List[Dict[str, str]]]:
    ct = (change_type or "").strip().lower()
    fp = (file_path or "").strip()

    impact = "Unexpected changes to critical files can indicate persistence, privilege escalation, or defense evasion. Attackers often modify configs, cron/systemd, auth modules, and binaries."
    path_hint = f" (`{fp}`)" if fp else ""
    recs: List[Dict[str, str]] = [
        {
            "title": "Validate the change",
            "description": f"Confirm whether the change is expected (deploy/patch/config management){path_hint}; identify change ticket, package version, or admin session.",
            "priority": "high",
        },
        {
            "title": "Contain if suspicious",
            "description": f"If unauthorized, isolate the host, snapshot disk{path_hint}, and hunt for related persistence or credential access.",
            "priority": "high",
        },
    ]

    if ct in ("modified", "modify", "changed"):
        recs.append(
            {
                "title": "Compare to baseline",
                "description": f"Diff against golden image or backup{path_hint}; verify package signatures (`rpm -V` / `debsums`) and timeline vs patch windows.",
                "priority": "medium",
            }
        )
    if ct in ("deleted", "delete", "removed"):
        recs.append(
            {
                "title": "Restore and investigate",
                "description": f"Restore from trusted media{path_hint}; review auditd/OS logs for unlink/rename and parent process.",
                "priority": "medium",
            }
        )
    if ct in ("created", "create", "new"):
        recs.append(
            {
                "title": "Inspect new file",
                "description": f"Review content, hash, owner, mode, and mount context{path_hint}; check systemd/cron/rc for references.",
                "priority": "medium",
            }
        )

    return impact, recs


def should_upgrade_fim_description(description: Optional[str]) -> bool:
    if not isinstance(description, str):
        return True
    s = description.strip()
    if not s:
        return True
    if len(s) < 70:
        return True
    return False


def build_fim_description(*, change_type: str, file_path: str) -> str:
    ct = (change_type or "").strip().lower()
    fp = (file_path or "unknown path").strip()

    if ct in ("modified", "modify", "changed"):
        return (
            f"The file '{fp}' was modified. Unexpected changes to system or application files can indicate persistence, defense evasion, or backdooring. "
            "Attackers often modify configs and startup mechanisms to regain access after reboot."
        )
    if ct in ("deleted", "delete", "removed"):
        return (
            f"The file '{fp}' was deleted. Deletions of important files can be used to break monitoring, remove evidence, or force misconfiguration. "
            "Attackers may delete logs, binaries, or configs to hide activity."
        )
    if ct in ("created", "create", "new"):
        return (
            f"A new file '{fp}' was created. New files in sensitive directories can indicate tool staging or persistence. "
            "Attackers commonly drop scripts/binaries in writable paths and hook them into startup or scheduled tasks."
        )
    return (
        f"A file integrity change was detected at '{fp}'. Unexpected file changes can indicate compromise or unauthorized admin activity."
    )

