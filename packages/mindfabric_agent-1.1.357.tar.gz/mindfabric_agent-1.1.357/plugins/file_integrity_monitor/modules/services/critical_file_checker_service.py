"""
Critical File Checker Service

Checks critical system files including cloud, container, and git paths.
"""

import os
from typing import Dict, List, Optional, Any

from ...proto import (
    CriticalFileDefinition,
    OperatingSystem,
)

from ..databases import (
    CRITICAL_FILES_LINUX,
    CRITICAL_FILES_WINDOWS,
    CRITICAL_FILES_CLOUD,
    CRITICAL_FILES_CONTAINER,
    DEFAULT_RULES_CLOUD,
    DEFAULT_RULES_CONTAINER,
    DEFAULT_RULES_GIT,
    KNOWN_GOOD_HASHES,
    SIGNED_BINARY_PATHS,
    CONTAINER_IMAGE_INTEGRITY,
    REALTIME_MONITORING_CONFIG,
    CRITICAL_CONFIG_FILES,
)


class CriticalFileChecker:
    """Check critical system files including cloud and container."""
    
    def __init__(self, os_type: OperatingSystem, environment: str = "standard"):
        self.os_type = os_type
        self.environment = environment
        self.critical_files: List[CriticalFileDefinition] = []
        self.known_hashes: Dict[str, str] = KNOWN_GOOD_HASHES
        self.signed_paths: List[str] = SIGNED_BINARY_PATHS
        
        # Load base OS critical files
        if os_type == OperatingSystem.WINDOWS:
            self.critical_files = CRITICAL_FILES_WINDOWS
        elif os_type == OperatingSystem.LINUX:
            self.critical_files = CRITICAL_FILES_LINUX
        
        # Add cloud-specific critical files if in cloud environment
        if environment in ["aws", "azure", "gcp", "cloud"]:
            self._add_cloud_critical_files()
        
        # Add container-specific critical files
        if environment in ["container", "docker", "kubernetes", "k8s"]:
            self._add_container_critical_files()
    
    def _add_cloud_critical_files(self) -> None:
        """Add cloud-specific critical file paths."""
        for provider, files in CRITICAL_FILES_CLOUD.items():
            if isinstance(files, list):
                self.critical_files.extend(files)
    
    def _add_container_critical_files(self) -> None:
        """Add container-specific critical file paths."""
        for runtime, files in CRITICAL_FILES_CONTAINER.items():
            if isinstance(files, list):
                self.critical_files.extend(files)
    
    def is_critical(self, path: str) -> Optional[CriticalFileDefinition]:
        """Check if path is a critical file."""
        for critical in self.critical_files:
            if path == critical.path or path.startswith(critical.path + os.sep):
                return critical
        return None
    
    def get_critical_paths(self) -> List[str]:
        """Get list of critical file paths."""
        return [c.path for c in self.critical_files]
    
    def is_known_good_hash(self, file_hash: str) -> bool:
        """Check if file hash is known good."""
        return file_hash in self.known_hashes
    
    def get_known_good_hash(self, path: str) -> Optional[str]:
        """Get known good hash for a path."""
        return self.known_hashes.get(path)
    
    def is_signed_binary_path(self, path: str) -> bool:
        """Check if path should contain signed binaries."""
        return any(path.startswith(signed_path) for signed_path in self.signed_paths)
    
    def get_monitoring_rules(self, scope: str = "all") -> Dict[str, Any]:
        """Get monitoring rules for specific scope."""
        rules = {}
        
        if scope in ["all", "linux"] and self.os_type == OperatingSystem.LINUX:
            rules.update({"linux": DEFAULT_RULES_LINUX if DEFAULT_RULES_LINUX else {}})
        
        if scope in ["all", "windows"] and self.os_type == OperatingSystem.WINDOWS:
            rules.update({"windows": DEFAULT_RULES_WINDOWS if DEFAULT_RULES_WINDOWS else {}})
        
        if scope in ["all", "cloud"]:
            rules.update({"cloud": DEFAULT_RULES_CLOUD if DEFAULT_RULES_CLOUD else {}})
        
        if scope in ["all", "container"]:
            rules.update({"container": DEFAULT_RULES_CONTAINER if DEFAULT_RULES_CONTAINER else {}})
        
        if scope in ["all", "git"]:
            rules.update({"git": DEFAULT_RULES_GIT if DEFAULT_RULES_GIT else {}})
        
        return rules
    
    def get_container_image_integrity_config(self, runtime: str = "docker") -> Dict[str, Any]:
        """Get container image integrity checking configuration."""
        return CONTAINER_IMAGE_INTEGRITY.get(runtime, {})
    
    def get_all_container_image_paths(self) -> List[str]:
        """Get all paths to check for container image integrity."""
        paths = []
        for runtime, config in CONTAINER_IMAGE_INTEGRITY.items():
            if isinstance(config, dict):
                runtime_paths = config.get("image_config_paths", [])
                if isinstance(runtime_paths, list):
                    paths.extend(runtime_paths)
                # Also check 'paths' key for kubernetes
                k8s_paths = config.get("paths", [])
                if isinstance(k8s_paths, list):
                    paths.extend(k8s_paths)
        return paths
    
    def get_realtime_monitoring_config(self, platform: str = "linux") -> Dict[str, Any]:
        """Get real-time monitoring configuration for platform."""
        platform_map = {
            "linux": "inotify_linux",
            "macos": "fsevents_macos",
            "windows": "usn_journal_windows",
        }
        config_key = platform_map.get(platform.lower())
        if config_key:
            return REALTIME_MONITORING_CONFIG.get(config_key, {})
        return {}
    
    def get_alert_thresholds(self) -> Dict[str, Any]:
        """Get alert threshold configuration."""
        return REALTIME_MONITORING_CONFIG.get("alert_thresholds", {})
    
    def get_critical_config_files(self, category: str = "all") -> List[Dict[str, Any]]:
        """Get critical configuration files for a category."""
        if category == "all":
            all_files = []
            for cat_files in CRITICAL_CONFIG_FILES.values():
                if isinstance(cat_files, list):
                    all_files.extend(cat_files)
            return all_files
        return CRITICAL_CONFIG_FILES.get(category, [])


# =============================================================================
# Main Plugin Class
# =============================================================================
