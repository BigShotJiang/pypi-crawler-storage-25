"""
Output Service

Constructs the final FIMScanOutput object.
"""

import platform
from datetime import datetime
from typing import Dict, List, Optional

from ...proto import (
    Baseline,
    ChangeType,
    ChangeTypeSummary,
    FIMScanOutput,
    FileChange,
    FileMetadata,
    PathSummary,
    ScanMetadata,
    ScanOptions,
    SeverityLevel,
    SeveritySummary,
    ExploitationCommands,
    FIMFinding,
)
from plugins.reproduction import ReproStep

class OutputService:
    """Handle output creation."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _generate_commands_for_change(self, change: FileChange) -> ExploitationCommands:
        """Generate investigation/remediation commands for a file change."""
        target_host = platform.node()
        commands_list = []
        description = ""
        
        if change.change_type == ChangeType.DELETED:
            commands_list = [
                f"# Verify file was deleted",
                f"ls -la {change.path} 2>/dev/null || echo 'File not found (deleted)'",
                f"# Check backup/restore options",
                f"find /backup -name '{change.path.split('/')[-1]}' 2>/dev/null",
            ]
            description = f"Verify deletion and backup options for {change.path}"
        elif change.change_type == ChangeType.CREATED:
            commands_list = [
                f"# Inspect newly created file",
                f"ls -la {change.path}",
                f"file {change.path}",
                f"sha256sum {change.path}",
                f"# Check file contents (if text)",
                f"head -50 {change.path} 2>/dev/null || xxd {change.path} | head -50",
            ]
            description = f"Investigate newly created file {change.path}"
        elif change.change_type in [ChangeType.MODIFIED, ChangeType.CONTENT_CHANGED]:
            commands_list = [
                f"# Check current file state",
                f"ls -la {change.path}",
                f"sha256sum {change.path}",
                f"# Compare with backup if available",
                f"diff {change.path} {change.path}.bak 2>/dev/null || echo 'No backup available'",
            ]
            if change.old_hashes and change.new_hashes:
                commands_list.append(f"# Old SHA256: {change.old_hashes.sha256}")
                commands_list.append(f"# New SHA256: {change.new_hashes.sha256}")
            description = f"Investigate content modification of {change.path}"
        elif change.change_type == ChangeType.PERMISSIONS_CHANGED:
            commands_list = [
                f"# Check current permissions",
                f"ls -la {change.path}",
                f"stat {change.path}",
            ]
            if change.old_permissions and change.new_permissions:
                commands_list.append(f"# Old mode: {change.old_permissions.mode}")
                commands_list.append(f"# New mode: {change.new_permissions.mode}")
                commands_list.append(f"# Restore original permissions if needed:")
                commands_list.append(f"# chmod {change.old_permissions.mode} {change.path}")
            description = f"Verify permission changes on {change.path}"
        elif change.change_type == ChangeType.OWNERSHIP_CHANGED:
            commands_list = [
                f"# Check current ownership",
                f"ls -la {change.path}",
                f"stat {change.path}",
            ]
            if change.old_ownership and change.new_ownership:
                commands_list.append(f"# Old owner: {change.old_ownership.user}:{change.old_ownership.group}")
                commands_list.append(f"# New owner: {change.new_ownership.user}:{change.new_ownership.group}")
                commands_list.append(f"# Restore original ownership if needed:")
                commands_list.append(f"# chown {change.old_ownership.user}:{change.old_ownership.group} {change.path}")
            description = f"Verify ownership changes on {change.path}"
        elif change.change_type == ChangeType.RENAMED:
            commands_list = [
                f"# Verify rename",
                f"ls -la {change.old_path} 2>/dev/null || echo 'Old path does not exist'",
                f"ls -la {change.new_path}",
            ]
            description = f"Verify file rename from {change.old_path} to {change.new_path}"
        else:
            commands_list = [
                f"# General inspection",
                f"ls -la {change.path}",
                f"stat {change.path}",
                f"sha256sum {change.path} 2>/dev/null",
            ]
            description = f"Investigate change to {change.path}"
        
        return ExploitationCommands(
            server=target_host,
            commands=commands_list,
            description=description
        )

    def _build_reproduction_steps_for_change(self, change: FileChange, finding: Optional[FIMFinding] = None) -> ReproStep:
        # Generate commands for this change
        commands_data = self._generate_commands_for_change(change)
        
        # Build command string for action
        command_str = "\n".join(commands_data.commands)
        if commands_data.description:
            command_str = f"# {commands_data.description}\n{command_str}"
        if commands_data.server:
            command_str = f"# Target: {commands_data.server}\n{command_str}"
        
        action = command_str

        # Build evidence from attribute changes or change type
        evidence_parts = []
        for attr_change in (change.attribute_changes or []):
            evidence_parts.append(f"{attr_change.attribute}: {attr_change.old_value} -> {attr_change.new_value}")
        evidence = "; ".join(evidence_parts) if evidence_parts else change.change_type.value

        # If we have a finding, attach commands to it
        if finding and not finding.commands:
            finding.commands = commands_data

        return ReproStep(
            title=f"{change.change_type.value} {change.path}",
            preconditions=[f"Read access to {change.path}"] if change.change_type != ChangeType.DELETED else None,
            target=change.path,
            action=action,
            payload=None,
            expected_outcome=change.change_type.value,
            evidence=str(evidence) if evidence else None,
            tooling=["ls", "stat", "sha256sum", "diff", "file"],
            safety="Read-only verification; do not modify files without authorization",
        )

    def _attach_reproduction_steps(self) -> list:
        collected = []
        for finding in getattr(self.plugin, "findings", []) or []:
            if getattr(finding, "reproduction_steps", None):
                collected.extend(finding.reproduction_steps)
                continue
            step = self._build_reproduction_steps_for_change(finding.change, finding)
            finding.reproduction_steps = [step]
            collected.append(step)
        return collected

    def create_output(
        self,
        options: ScanOptions,
        current_files: Dict[str, FileMetadata],
        baseline_created: Optional[Baseline],
        baseline_used: Optional[str],
        new_files: List[str],
        missing_files: List[str],
        modified_files: List[str],
        recommendations: List[str],
        immediate_actions: List[str],
    ) -> FIMScanOutput:
        """Create the final output."""
        completed = datetime.utcnow()
        duration = (completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0
        
        # Build summaries
        severity_summary = SeveritySummary(
            critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
            high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            medium=len([f for f in self.plugin.findings if f.severity == SeverityLevel.MEDIUM]),
            low=len([f for f in self.plugin.findings if f.severity == SeverityLevel.LOW]),
            info=len([f for f in self.plugin.findings if f.severity == SeverityLevel.INFO]),
            total=len(self.plugin.findings),
        )
        
        change_type_summary = ChangeTypeSummary(
            created=len([c for c in self.plugin.changes if c.change_type == ChangeType.CREATED]),
            modified=len([c for c in self.plugin.changes if c.change_type in [ChangeType.MODIFIED, ChangeType.CONTENT_CHANGED]]),
            deleted=len([c for c in self.plugin.changes if c.change_type == ChangeType.DELETED]),
            permissions_changed=len([c for c in self.plugin.changes if c.change_type == ChangeType.PERMISSIONS_CHANGED]),
            ownership_changed=len([c for c in self.plugin.changes if c.change_type == ChangeType.OWNERSHIP_CHANGED]),
            total=len(self.plugin.changes),
        )
        
        # Path summaries
        path_summaries = []
        for path in options.target.paths:
            path_files = [p for p in current_files.keys() if p.startswith(path)]
            path_changes = [c for c in self.plugin.changes if c.path.startswith(path)]
            path_summaries.append(PathSummary(
                path=path,
                files_monitored=len(path_files),
                changes_detected=len(path_changes),
                critical_changes=len([c for c in path_changes if c.severity == SeverityLevel.CRITICAL]),
            ))
        
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            mode=options.mode,
            hostname=platform.node(),
            operating_system=self.plugin.os_type,
            paths_monitored=options.target.paths,
            started_at=self.plugin.scan_start or completed,
            completed_at=completed,
            duration_seconds=duration,
            files_scanned=self.plugin.scanner.files_scanned if self.plugin.scanner else 0,
            directories_scanned=self.plugin.scanner.dirs_scanned if self.plugin.scanner else 0,
            total_size_scanned=self.plugin.scanner.total_size if self.plugin.scanner else 0,
            baseline_id=baseline_used,
            baseline_files=baseline_created.total_files if baseline_created else 0,
            total_changes=len(self.plugin.changes),
            total_findings=len(self.plugin.findings),
        )
        
        critical_changes = [c for c in self.plugin.changes if c.severity == SeverityLevel.CRITICAL]
        critical_findings = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]

        repro_steps = self._attach_reproduction_steps()
        
        return FIMScanOutput(
            metadata=metadata,
            severity_summary=severity_summary,
            change_type_summary=change_type_summary,
            path_summaries=path_summaries,
            changes=self.plugin.changes,
            critical_changes=critical_changes,
            findings=self.plugin.findings,
            critical_findings=critical_findings,
            baseline_created=baseline_created,
            baseline_used=baseline_used,
            new_files=new_files,
            missing_files=missing_files,
            modified_files=modified_files,
            recommendations=recommendations,
            immediate_actions=immediate_actions,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            reproduction_steps=repro_steps or None,
        )
