"""
Baseline Manager Service

Manages file integrity baselines.
"""

import json
import os
import platform
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ...proto import (
    AlertLevel,
    AttributeChange,
    Baseline,
    BaselineEntry,
    ChangeType,
    FileChange,
    FileHashes,
    FileMetadata,
    FileOwnership,
    FilePermissions,
    FileTimestamps,
    FileType,
    OperatingSystem,
    SeverityLevel,
)

from ..utils.fim_utils import get_mitre_reference

BASELINE_DIR = "/tmp/fim_baselines"
MAX_BASELINE_JSON_BYTES = int(os.getenv("FIM_MAX_BASELINE_JSON_BYTES", str(5 * 1024 * 1024)))  # 5MB default

class BaselineManager:
    """Manage file integrity baselines."""
    
    def __init__(self):
        self.baselines: Dict[str, Baseline] = {}
        self._ensure_baseline_dir()
        self._load_baselines()
    
    def _ensure_baseline_dir(self):
        """Ensure baseline directory exists."""
        Path(BASELINE_DIR).mkdir(parents=True, exist_ok=True)
    
    def _load_baselines(self):
        """Load baselines from disk."""
        try:
            for file in Path(BASELINE_DIR).glob("*.json"):
                try:
                    # Guard: large baseline JSON can OOM small hosts when loaded into memory.
                    # We skip loading oversized baselines to keep the agent alive; a new, smaller
                    # baseline will be created (scan max_files is enforced at the plugin level).
                    if file.stat().st_size > MAX_BASELINE_JSON_BYTES:
                        continue
                    with open(file, 'r') as f:
                        data = json.load(f)
                    baseline = self._deserialize_baseline(data)
                    if baseline:
                        self.baselines[baseline.id] = baseline
                except Exception:
                    pass
        except Exception:
            pass
    
    def _serialize_baseline(self, baseline: Baseline) -> dict:
        """Serialize baseline to JSON-compatible dict."""
        entries = {}
        for path, entry in baseline.entries.items():
            meta = entry.metadata
            entries[path] = {
                "path": path,
                "metadata": {
                    "path": meta.path,
                    "name": meta.name,
                    "file_type": meta.file_type.value if hasattr(meta.file_type, 'value') else str(meta.file_type),
                    "size": meta.size,
                    "hashes": {
                        "md5": meta.hashes.md5,
                        "sha1": meta.hashes.sha1,
                        "sha256": meta.hashes.sha256,
                        "sha512": meta.hashes.sha512,
                    },
                    "permissions": {
                        "mode": meta.permissions.mode,
                        "mode_octal": meta.permissions.mode_octal,
                    },
                    "ownership": {
                        "uid": meta.ownership.uid,
                        "gid": meta.ownership.gid,
                        "user": meta.ownership.user,
                        "group": meta.ownership.group,
                    },
                    "timestamps": {
                        "created": meta.timestamps.created.isoformat() if meta.timestamps.created else None,
                        "modified": meta.timestamps.modified.isoformat() if meta.timestamps.modified else None,
                        "accessed": meta.timestamps.accessed.isoformat() if meta.timestamps.accessed else None,
                    }
                }
            }
        return {
            "id": baseline.id,
            "name": baseline.name,
            "description": baseline.description,
            "hostname": baseline.hostname,
            "operating_system": baseline.operating_system.value if hasattr(baseline.operating_system, 'value') else str(baseline.operating_system),
            "created_at": baseline.created_at.isoformat() if baseline.created_at else None,
            "total_files": baseline.total_files,
            "total_size": baseline.total_size,
            "rules": baseline.rules,
            "entries": entries,
        }
    
    def _deserialize_baseline(self, data: dict) -> Optional[Baseline]:
        """Deserialize baseline from dict."""
        try:
            entries = {}
            for path, entry_data in data.get("entries", {}).items():
                meta_data = entry_data.get("metadata", {})
                hashes = FileHashes(
                    md5=meta_data.get("hashes", {}).get("md5"),
                    sha1=meta_data.get("hashes", {}).get("sha1"),
                    sha256=meta_data.get("hashes", {}).get("sha256"),
                    sha512=meta_data.get("hashes", {}).get("sha512"),
                )
                permissions = FilePermissions(
                    mode=meta_data.get("permissions", {}).get("mode", ""),
                    mode_octal=meta_data.get("permissions", {}).get("mode_octal", ""),
                )
                ownership = FileOwnership(
                    uid=meta_data.get("ownership", {}).get("uid", 0),
                    gid=meta_data.get("ownership", {}).get("gid", 0),
                    user=meta_data.get("ownership", {}).get("user", ""),
                    group=meta_data.get("ownership", {}).get("group", ""),
                )
                ts_data = meta_data.get("timestamps", {})
                timestamps = FileTimestamps(
                    created=datetime.fromisoformat(ts_data["created"]) if ts_data.get("created") else None,
                    modified=datetime.fromisoformat(ts_data["modified"]) if ts_data.get("modified") else None,
                    accessed=datetime.fromisoformat(ts_data["accessed"]) if ts_data.get("accessed") else None,
                )
                file_type_str = meta_data.get("file_type", "file")
                try:
                    file_type = FileType(file_type_str)
                except:
                    file_type = FileType.FILE
                
                # Extract name from path
                name = meta_data.get("name") or os.path.basename(path)
                
                metadata = FileMetadata(
                    path=path,
                    name=name,
                    file_type=file_type,
                    size=meta_data.get("size", 0),
                    hashes=hashes,
                    permissions=permissions,
                    ownership=ownership,
                    timestamps=timestamps,
                )
                entries[path] = BaselineEntry(path=path, metadata=metadata)
            
            os_str = data.get("operating_system", "auto")
            try:
                os_type = OperatingSystem(os_str)
            except:
                os_type = OperatingSystem.AUTO
            
            return Baseline(
                id=data.get("id", str(uuid.uuid4())),
                name=data.get("name", "Unknown"),
                description=data.get("description"),
                hostname=data.get("hostname"),
                operating_system=os_type,
                created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.utcnow(),
                total_files=data.get("total_files", len(entries)),
                total_size=data.get("total_size", 0),
                rules=data.get("rules", []),
                entries=entries,
            )
        except Exception:
            return None
    
    def _save_baseline(self, baseline: Baseline):
        """Save baseline to disk."""
        try:
            filepath = Path(BASELINE_DIR) / f"{baseline.id}.json"
            with open(filepath, 'w') as f:
                json.dump(self._serialize_baseline(baseline), f)
        except Exception:
            pass
    
    def create_baseline(
        self,
        name: str,
        files: Dict[str, FileMetadata],
        rules: Optional[List[str]] = None,
        description: Optional[str] = None,
        hostname: Optional[str] = None,
        os_type: OperatingSystem = OperatingSystem.AUTO,
    ) -> Baseline:
        """Create a new baseline."""
        baseline_id = str(uuid.uuid4())
        
        entries = {}
        total_size = 0
        
        for path, metadata in files.items():
            entries[path] = BaselineEntry(
                path=path,
                metadata=metadata,
            )
            total_size += metadata.size
        
        baseline = Baseline(
            id=baseline_id,
            name=name,
            description=description,
            hostname=hostname or platform.node(),
            operating_system=os_type,
            entries=entries,
            total_files=len(entries),
            total_size=total_size,
            rules=rules or [],
        )
        
        self.baselines[baseline_id] = baseline
        self._save_baseline(baseline)
        return baseline
    
    def compare_to_baseline(
        self,
        baseline: Baseline,
        current_files: Dict[str, FileMetadata],
        check_hashes: bool = True,
        check_permissions: bool = True,
        check_ownership: bool = True,
        check_timestamps: bool = True,
    ) -> Tuple[List[FileChange], List[str], List[str], List[str]]:
        """Compare current state to baseline."""
        changes: List[FileChange] = []
        new_files: List[str] = []
        missing_files: List[str] = []
        modified_files: List[str] = []
        
        baseline_paths = set(baseline.entries.keys())
        current_paths = set(current_files.keys())
        
        # Find new files
        for path in current_paths - baseline_paths:
            new_files.append(path)
            metadata = current_files[path]
            
            change = FileChange(
                id=str(uuid.uuid4()),
                path=path,
                file_type=metadata.file_type,
                change_type=ChangeType.CREATED,
                new_hashes=metadata.hashes,
                new_size=metadata.size,
                new_permissions=metadata.permissions,
                new_ownership=metadata.ownership,
                new_timestamps=metadata.timestamps,
                severity=SeverityLevel.MEDIUM,
                alert_level=AlertLevel.MEDIUM_ALERT,
            )
            changes.append(change)
        
        # Find missing files
        for path in baseline_paths - current_paths:
            missing_files.append(path)
            baseline_entry = baseline.entries[path]
            
            change = FileChange(
                id=str(uuid.uuid4()),
                path=path,
                file_type=baseline_entry.metadata.file_type,
                change_type=ChangeType.DELETED,
                old_hashes=baseline_entry.metadata.hashes,
                old_size=baseline_entry.metadata.size,
                old_permissions=baseline_entry.metadata.permissions,
                old_ownership=baseline_entry.metadata.ownership,
                old_timestamps=baseline_entry.metadata.timestamps,
                severity=SeverityLevel.HIGH,
                alert_level=AlertLevel.HIGH_ALERT,
                mitre=get_mitre_reference(change_type=ChangeType.DELETED),
            )
            changes.append(change)
        
        # Check modified files
        for path in baseline_paths & current_paths:
            baseline_entry = baseline.entries[path]
            current = current_files[path]
            baseline_meta = baseline_entry.metadata
            
            attribute_changes = []
            change_type = None
            
            # Check content (hashes)
            if check_hashes:
                if current.hashes.sha256 != baseline_meta.hashes.sha256:
                    attribute_changes.append(AttributeChange(
                        attribute="sha256",
                        old_value=baseline_meta.hashes.sha256,
                        new_value=current.hashes.sha256,
                    ))
                    change_type = ChangeType.CONTENT_CHANGED
            
            # Check size
            if current.size != baseline_meta.size:
                attribute_changes.append(AttributeChange(
                    attribute="size",
                    old_value=baseline_meta.size,
                    new_value=current.size,
                ))
                if not change_type:
                    change_type = ChangeType.MODIFIED
            
            # Check permissions
            if check_permissions:
                if current.permissions.mode_octal != baseline_meta.permissions.mode_octal:
                    attribute_changes.append(AttributeChange(
                        attribute="permissions",
                        old_value=baseline_meta.permissions.mode,
                        new_value=current.permissions.mode,
                    ))
                    if not change_type:
                        change_type = ChangeType.PERMISSIONS_CHANGED
            
            # Check ownership
            if check_ownership:
                if (current.ownership.uid != baseline_meta.ownership.uid or
                    current.ownership.gid != baseline_meta.ownership.gid):
                    attribute_changes.append(AttributeChange(
                        attribute="ownership",
                        old_value=f"{baseline_meta.ownership.user}:{baseline_meta.ownership.group}",
                        new_value=f"{current.ownership.user}:{current.ownership.group}",
                    ))
                    if not change_type:
                        change_type = ChangeType.OWNERSHIP_CHANGED
            
            # Check timestamps
            if check_timestamps:
                if current.timestamps.modified != baseline_meta.timestamps.modified:
                    attribute_changes.append(AttributeChange(
                        attribute="modified_time",
                        old_value=str(baseline_meta.timestamps.modified),
                        new_value=str(current.timestamps.modified),
                    ))
                    if not change_type:
                        change_type = ChangeType.METADATA_CHANGED
            
            if attribute_changes:
                modified_files.append(path)
                
                severity = SeverityLevel.MEDIUM
                if change_type == ChangeType.CONTENT_CHANGED:
                    severity = SeverityLevel.HIGH
                elif change_type == ChangeType.PERMISSIONS_CHANGED:
                    severity = SeverityLevel.HIGH
                
                change = FileChange(
                    id=str(uuid.uuid4()),
                    path=path,
                    file_type=current.file_type,
                    change_type=change_type or ChangeType.MODIFIED,
                    attribute_changes=attribute_changes,
                    old_hashes=baseline_meta.hashes,
                    new_hashes=current.hashes,
                    old_size=baseline_meta.size,
                    new_size=current.size,
                    old_permissions=baseline_meta.permissions,
                    new_permissions=current.permissions,
                    old_ownership=baseline_meta.ownership,
                    new_ownership=current.ownership,
                    old_timestamps=baseline_meta.timestamps,
                    new_timestamps=current.timestamps,
                    severity=severity,
                    alert_level=AlertLevel.HIGH_ALERT if severity in [SeverityLevel.HIGH, SeverityLevel.CRITICAL] else AlertLevel.MEDIUM_ALERT,
                    mitre=get_mitre_reference(change_type=change_type),
                )
                changes.append(change)
        
        return changes, new_files, missing_files, modified_files

