"""
SQLite-backed baseline storage for File Integrity Monitor (FIM).

Goals:
- Avoid holding huge baseline/current snapshots in RAM on small hosts.
- Enable streaming compare (read baseline row-by-row, record seen paths).

This store is intentionally self-contained and uses only stdlib `sqlite3`.
"""

from __future__ import annotations

import os
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional, Iterable, Iterator, Tuple


def _utc_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _sqlite_retry_write(fn, *, retries: int = 12, base_delay: float = 0.05) -> None:
    """Retry on SQLITE_BUSY / database is locked (concurrent FIM scans or WAL checkpoint)."""
    delay = base_delay
    last: Optional[Exception] = None
    for attempt in range(retries):
        try:
            fn()
            return
        except sqlite3.OperationalError as e:
            last = e
            msg = str(e).lower()
            if "locked" not in msg and "busy" not in msg:
                raise
            if attempt >= retries - 1:
                raise
            time.sleep(delay)
            delay = min(delay * 2, 2.0)
    if last:
        raise last


@dataclass(frozen=True)
class BaselineRow:
    path: str
    size: int
    mtime_ns: int
    mode_octal: Optional[int]
    uid: Optional[int]
    gid: Optional[int]
    sha256: Optional[str]


class BaselineSqliteStore:
    def __init__(self, db_path: Optional[str] = None):
        # Prefer a persistent MindFabric-owned directory.
        # Can be overridden via FIM_BASELINE_DIR. If the default is not writable, fallback to /tmp.
        preferred_root = os.getenv("FIM_BASELINE_DIR") or os.getenv("MINDFABRIC_AGENT_DATA_DIR") or "/var/lib/mindfabric-agent"
        preferred_dir = str(Path(preferred_root) / "fim")
        chosen_dir = preferred_dir
        try:
            Path(chosen_dir).mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(chosen_dir, 0o700)
            except Exception:
                pass
        except Exception:
            chosen_dir = "/tmp/mindfabric-agent/fim"
            Path(chosen_dir).mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(chosen_dir, 0o700)
            except Exception:
                pass
        self.db_path = db_path or str(Path(chosen_dir) / "fim_baseline.sqlite")
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, timeout=120.0)
            self._conn.row_factory = sqlite3.Row
            cur = self._conn.cursor()
            # Pragmas tuned for small instances (WAL helps concurrent reads during writes)
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA synchronous=NORMAL;")
            cur.execute("PRAGMA temp_store=FILE;")
            cur.execute("PRAGMA cache_size=-2000;")  # ~2MB
            # Milliseconds — works with timeout= above for concurrent plugin runs
            cur.execute("PRAGMA busy_timeout=60000;")
            self._init_schema()
            # Best-effort hardening: restrict file permissions (password is not a SQLite concept).
            try:
                p = Path(self.db_path)
                if p.exists():
                    os.chmod(str(p), 0o600)
            except Exception:
                pass
        return self._conn

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            finally:
                self._conn = None

    def _init_schema(self) -> None:
        conn = self.connect()
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS meta (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL
            );
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS baseline (
              path TEXT PRIMARY KEY,
              size INTEGER NOT NULL,
              mtime_ns INTEGER NOT NULL,
              mode_octal INTEGER,
              uid INTEGER,
              gid INTEGER,
              sha256 TEXT
            );
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_baseline_sha256 ON baseline(sha256);")

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS seen (
              path TEXT PRIMARY KEY
            );
            """
        )
        conn.commit()

    # ---- baseline lifecycle -------------------------------------------------

    def reset_seen(self) -> None:
        def _do() -> None:
            conn = self.connect()
            conn.execute("DELETE FROM seen;")
            conn.commit()

        _sqlite_retry_write(_do)

    def set_meta(self, key: str, value: str) -> None:
        conn = self.connect()
        conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        conn.commit()

    def get_meta(self, key: str) -> Optional[str]:
        conn = self.connect()
        row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return str(row["value"]) if row else None

    def clear_baseline(self) -> None:
        def _do() -> None:
            conn = self.connect()
            conn.execute("DELETE FROM baseline;")
            conn.commit()

        _sqlite_retry_write(_do)
        self.set_meta("baseline_updated_at", _utc_iso())

    def baseline_count(self) -> int:
        conn = self.connect()
        row = conn.execute("SELECT COUNT(1) AS c FROM baseline").fetchone()
        return int(row["c"]) if row else 0

    def has_baseline(self) -> bool:
        return self.baseline_count() > 0

    def upsert_baseline_row(self, row: BaselineRow) -> None:
        conn = self.connect()
        conn.execute(
            """
            INSERT INTO baseline(path,size,mtime_ns,mode_octal,uid,gid,sha256)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(path) DO UPDATE SET
              size=excluded.size,
              mtime_ns=excluded.mtime_ns,
              mode_octal=excluded.mode_octal,
              uid=excluded.uid,
              gid=excluded.gid,
              sha256=excluded.sha256
            """,
            (row.path, row.size, row.mtime_ns, row.mode_octal, row.uid, row.gid, row.sha256),
        )

    def commit(self) -> None:
        def _do() -> None:
            conn = self.connect()
            conn.commit()

        _sqlite_retry_write(_do)

    # ---- compare helpers ----------------------------------------------------

    def mark_seen(self, path: str) -> None:
        conn = self.connect()
        conn.execute("INSERT OR IGNORE INTO seen(path) VALUES(?)", (path,))

    def get_baseline_row(self, path: str) -> Optional[BaselineRow]:
        conn = self.connect()
        r = conn.execute(
            "SELECT path,size,mtime_ns,mode_octal,uid,gid,sha256 FROM baseline WHERE path=?",
            (path,),
        ).fetchone()
        if not r:
            return None
        return BaselineRow(
            path=str(r["path"]),
            size=int(r["size"]),
            mtime_ns=int(r["mtime_ns"]),
            mode_octal=int(r["mode_octal"]) if r["mode_octal"] is not None else None,
            uid=int(r["uid"]) if r["uid"] is not None else None,
            gid=int(r["gid"]) if r["gid"] is not None else None,
            sha256=str(r["sha256"]) if r["sha256"] is not None else None,
        )

    def iter_deleted_paths(self, batch_size: int = 500) -> Iterator[str]:
        """
        Yield baseline paths that were NOT seen in the current scan, in batches,
        without loading full sets into memory.
        """
        conn = self.connect()
        offset = 0
        while True:
            rows = conn.execute(
                """
                SELECT b.path AS path
                FROM baseline b
                LEFT JOIN seen s ON s.path = b.path
                WHERE s.path IS NULL
                ORDER BY b.path
                LIMIT ? OFFSET ?
                """,
                (batch_size, offset),
            ).fetchall()
            if not rows:
                break
            for r in rows:
                yield str(r["path"])
            offset += batch_size

