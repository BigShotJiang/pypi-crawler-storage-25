"""
Recommendations Service

Generates prioritized recommendations and immediate actions.
"""

from typing import List

from ...proto import (
    ChangeType,
    SeverityLevel,
)

class RecommendationsService:
    """Handle recommendations generation."""

    def __init__(self, plugin):
        self.plugin = plugin

    def generate_recommendations(self) -> List[str]:
        """Generate prioritized recommendations."""
        recommendations = []
        
        critical = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]
        if critical:
            recommendations.append(f"URGENT: {len(critical)} critical file changes require immediate investigation")
        
        # Check for specific patterns
        auth_changes = [f for f in self.plugin.findings if '/etc/passwd' in f.file_path or '/etc/shadow' in f.file_path]
        if auth_changes:
            recommendations.append("Authentication files modified - verify no unauthorized accounts added")
        
        deleted = [f for f in self.plugin.findings if f.change_type == ChangeType.DELETED]
        if deleted:
            recommendations.append(f"{len(deleted)} files deleted - verify deletions were authorized")
        
        perm_changes = [f for f in self.plugin.findings if f.change_type == ChangeType.PERMISSIONS_CHANGED]
        if perm_changes:
            recommendations.append("Review permission changes for security weakening")
        
        recommendations.extend([
            "Establish regular baseline updates after authorized changes",
            "Enable real-time file monitoring for critical paths",
            "Review and update monitoring rules periodically",
            "Integrate with SIEM for automated alerting",
        ])
        
        return recommendations[:10]
    
    def get_immediate_actions(self) -> List[str]:
        """Get immediate actions for critical findings."""
        actions = []
        
        for finding in self.plugin.findings:
            if finding.severity == SeverityLevel.CRITICAL:
                if finding.change_type == ChangeType.DELETED:
                    actions.append(f"IMMEDIATE: Critical file deleted - {finding.file_path}")
                elif '/etc/shadow' in finding.file_path or 'SAM' in finding.file_path:
                    actions.append(f"IMMEDIATE: Credential store modified - {finding.file_path}")
                elif finding.change_type == ChangeType.CONTENT_CHANGED:
                    actions.append(f"IMMEDIATE: Critical file modified - {finding.file_path}")
        
        return list(set(actions))[:5]
