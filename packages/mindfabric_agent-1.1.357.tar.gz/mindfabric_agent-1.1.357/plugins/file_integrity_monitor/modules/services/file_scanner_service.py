"""
File Scanner Service

Scans files and collects metadata.
"""

from pathlib import Path
from typing import Dict, List, Optional, Iterator, Tuple

from ...proto import (
    FileMetadata,
    HashAlgorithm,
)

from ..utils.fim_utils import (
    get_file_metadata,
    should_exclude,
)

class FileScanner:
    """Scan files and collect metadata."""
    
    def __init__(
        self,
        hash_algorithms: List[HashAlgorithm] = None,
        check_hashes: bool = True,
        max_file_size: int = 100 * 1024 * 1024,
    ):
        if hash_algorithms is None:
            hash_algorithms = [HashAlgorithm.SHA256]
        
        self.hash_algorithms = hash_algorithms
        self.check_hashes = check_hashes
        self.max_file_size = max_file_size
        self.files_scanned = 0
        self.dirs_scanned = 0
        self.total_size = 0
        self.errors: List[str] = []
    
    def scan_path(
        self,
        path: str,
        recursive: bool = True,
        max_depth: Optional[int] = None,
        max_files: Optional[int] = None,
        exclude_paths: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        exclude_extensions: Optional[List[str]] = None,
        follow_symlinks: bool = False,
    ) -> Dict[str, FileMetadata]:
        """Scan a path and return file metadata."""
        results: Dict[str, FileMetadata] = {}
        for p, m in self.iter_path(
            path=path,
            recursive=recursive,
            max_depth=max_depth,
            max_files=max_files,
            exclude_paths=exclude_paths,
            exclude_patterns=exclude_patterns,
            exclude_extensions=exclude_extensions,
            follow_symlinks=follow_symlinks,
        ):
            results[p] = m
        return results

    def iter_path(
        self,
        path: str,
        recursive: bool = True,
        max_depth: Optional[int] = None,
        max_files: Optional[int] = None,
        exclude_paths: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        exclude_extensions: Optional[List[str]] = None,
        follow_symlinks: bool = False,
    ) -> Iterator[Tuple[str, FileMetadata]]:
        """
        Stream file metadata entries. This avoids building huge dicts in memory.
        Yields (path_str, FileMetadata) for each file/symlink encountered.
        """
        
        filepath = Path(path)
        
        if not filepath.exists():
            self.errors.append(f"Path does not exist: {path}")
            return
        
        if filepath.is_file():
            # Single file
            metadata = get_file_metadata(
                filepath,
                self.hash_algorithms,
                self.check_hashes,
                self.max_file_size,
            )
            if metadata:
                self.files_scanned += 1
                self.total_size += metadata.size
                yield (str(filepath), metadata)
            return
        
        # Directory
        def scan_dir(dir_path: Path, current_depth: int = 0):
            if max_depth is not None and current_depth > max_depth:
                return
            if max_files is not None and self.files_scanned >= max_files:
                return
            
            try:
                for entry in dir_path.iterdir():
                    if max_files is not None and self.files_scanned >= max_files:
                        return
                    # Check exclusions
                    if should_exclude(entry, exclude_paths, exclude_patterns, exclude_extensions):
                        continue
                    
                    # Handle symlinks
                    if entry.is_symlink() and not follow_symlinks:
                        # Still record symlink metadata but don't follow
                        metadata = get_file_metadata(
                            entry, [], False, self.max_file_size
                        )
                        if metadata:
                            yield (str(entry), metadata)
                        continue
                    
                    if entry.is_file():
                        metadata = get_file_metadata(
                            entry,
                            self.hash_algorithms,
                            self.check_hashes,
                            self.max_file_size,
                        )
                        if metadata:
                            self.files_scanned += 1
                            self.total_size += metadata.size
                            yield (str(entry), metadata)
                    
                    elif entry.is_dir() and recursive:
                        self.dirs_scanned += 1
                        yield from scan_dir(entry, current_depth + 1)
            
            except PermissionError:
                self.errors.append(f"Permission denied: {dir_path}")
            except Exception as e:
                self.errors.append(f"Error scanning {dir_path}: {e}")
        
        self.dirs_scanned += 1
        yield from scan_dir(filepath)

