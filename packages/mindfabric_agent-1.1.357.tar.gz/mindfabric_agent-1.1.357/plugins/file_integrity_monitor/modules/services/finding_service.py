"""
Finding Service

Creates findings from file changes.
"""

import uuid
from typing import List

from ...proto import (
    ChangeType,
    ConfidenceLevel,
    FIMFinding,
    FileChange,
    ScanOptions,
    SeverityLevel,
)

from ..utils.fim_utils import calculate_risk_score

class FindingService:
    """Handle finding creation."""

    def __init__(self, plugin):
        self.plugin = plugin

    def create_findings(self, options: ScanOptions):
        """Create findings from changes."""
        for change in self.plugin.changes:
            # Get compliance requirements
            compliance = []
            critical = self.plugin.critical_checker.is_critical(change.path) if self.plugin.critical_checker else None
            if critical and critical.compliance:
                compliance = critical.compliance
            
            finding = FIMFinding(
                id=str(uuid.uuid4()),
                severity=change.severity,
                confidence=ConfidenceLevel.CONFIRMED,
                alert_level=change.alert_level,
                mitre=change.mitre,
                compliance=compliance if compliance else None,
                title=f"File {change.change_type.value}: {change.path}",
                description=self.get_change_description(change),
                file_path=change.path,
                file_type=change.file_type,
                change_type=change.change_type,
                change=change,
                risk_score=calculate_risk_score(
                    change.severity,
                    ConfidenceLevel.CONFIRMED,
                    change.is_critical_file,
                    change.change_type,
                ),
                recommendation=self.get_recommendation(change),
                remediation_steps=self.get_remediation_steps(change),
            )
            self.plugin.findings.append(finding)
    
    def get_change_description(self, change: FileChange) -> str:
        """Generate description for change."""
        if change.change_type == ChangeType.CREATED:
            return f"New file detected: {change.path}"
        elif change.change_type == ChangeType.DELETED:
            return f"File deleted: {change.path}"
        elif change.change_type == ChangeType.CONTENT_CHANGED:
            return f"File content modified: {change.path}. Hash changed from {change.old_hashes.sha256[:16]}... to {change.new_hashes.sha256[:16]}..."
        elif change.change_type == ChangeType.PERMISSIONS_CHANGED:
            return f"Permissions changed on {change.path}: {change.old_permissions.mode} -> {change.new_permissions.mode}"
        elif change.change_type == ChangeType.OWNERSHIP_CHANGED:
            return f"Ownership changed on {change.path}"
        else:
            return f"File modified: {change.path}"
    
    def get_recommendation(self, change: FileChange) -> str:
        """Get recommendation for change."""
        if change.is_critical_file:
            return f"CRITICAL: Investigate immediately. This is a critical system file."
        elif change.change_type == ChangeType.DELETED:
            return "Verify if file deletion was authorized. Check for backup."
        elif change.change_type == ChangeType.CONTENT_CHANGED:
            return "Verify file content change was authorized. Compare to known good version."
        elif change.change_type == ChangeType.PERMISSIONS_CHANGED:
            return "Review permission change. Verify it doesn't weaken security."
        else:
            return "Review change and verify it was authorized."
    
    def get_remediation_steps(self, change: FileChange) -> List[str]:
        """Get remediation steps for change."""
        steps = []
        
        if change.change_type == ChangeType.DELETED:
            steps = [
                "Verify deletion was authorized",
                "Check audit logs for deletion source",
                "Restore from backup if unauthorized",
                "Investigate potential data destruction",
            ]
        elif change.change_type == ChangeType.CONTENT_CHANGED:
            steps = [
                "Compare file to known good version",
                "Check file signature if applicable",
                "Review change in version control",
                "Scan file for malware",
            ]
        elif change.change_type == ChangeType.PERMISSIONS_CHANGED:
            steps = [
                "Review new permissions",
                "Verify change was authorized",
                "Revert if permissions are too permissive",
                "Check for world-writable files",
            ]
        elif change.change_type == ChangeType.CREATED:
            steps = [
                "Verify file creation was authorized",
                "Scan file for malware",
                "Check file source and creator",
                "Review if file matches expected content",
            ]
        
        return steps
