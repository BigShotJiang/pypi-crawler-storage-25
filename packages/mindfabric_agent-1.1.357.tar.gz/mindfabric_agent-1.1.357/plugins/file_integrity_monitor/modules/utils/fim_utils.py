"""
File Integrity Monitor Utilities

Contains utility functions for file integrity monitoring.
"""

import hashlib
import logging
import os
import platform
import re
import stat
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ...proto import (
    ChangeType,
    ConfidenceLevel,
    FileHashes,
    FileMetadata,
    FileOwnership,
    FilePermissions,
    FileTimestamps,
    FileType,
    HashAlgorithm,
    MitreAttackReference,
    MitreTactic,
    MitreTechnique,
    OperatingSystem,
    SeverityLevel,
)

from ..databases.fim_databases import CHANGE_TYPE_MITRE

logger = logging.getLogger(__name__)

# =============================================================================

def calculate_risk_score(
    severity: SeverityLevel,
    confidence: ConfidenceLevel,
    is_critical_file: bool = False,
    change_type: Optional[ChangeType] = None,
) -> float:
    """Calculate risk score 0-10."""
    severity_weights = {
        SeverityLevel.CRITICAL: 9.5,
        SeverityLevel.HIGH: 7.5,
        SeverityLevel.MEDIUM: 5.0,
        SeverityLevel.LOW: 3.0,
        SeverityLevel.INFO: 1.0,
    }
    
    confidence_multiplier = {
        ConfidenceLevel.CONFIRMED: 1.0,
        ConfidenceLevel.HIGH: 0.9,
        ConfidenceLevel.MEDIUM: 0.7,
        ConfidenceLevel.LOW: 0.5,
        ConfidenceLevel.TENTATIVE: 0.3,
    }
    
    base = severity_weights.get(severity, 5.0)
    conf = confidence_multiplier.get(confidence, 0.7)
    
    score = base * conf
    
    if is_critical_file:
        score += 0.5
    
    # Certain change types are more concerning
    if change_type in [ChangeType.DELETED, ChangeType.PERMISSIONS_CHANGED]:
        score += 0.3
    
    return min(10.0, round(score, 1))


def get_mitre_reference(
    change_type: Optional[ChangeType] = None,
    technique: Optional[MitreTechnique] = None,
) -> Optional[MitreAttackReference]:
    """Get MITRE reference for change type or technique."""
    if technique:
        # Map technique to tactic
        tactic_map = {
            MitreTechnique.T1037: MitreTactic.PERSISTENCE,
            MitreTechnique.T1053: MitreTactic.PERSISTENCE,
            MitreTechnique.T1136: MitreTactic.PERSISTENCE,
            MitreTechnique.T1543: MitreTactic.PERSISTENCE,
            MitreTechnique.T1546: MitreTactic.PERSISTENCE,
            MitreTechnique.T1547: MitreTactic.PERSISTENCE,
            MitreTechnique.T1574: MitreTactic.PERSISTENCE,
            MitreTechnique.T1070: MitreTactic.DEFENSE_EVASION,
            MitreTechnique.T1070_004: MitreTactic.DEFENSE_EVASION,
            MitreTechnique.T1222: MitreTactic.DEFENSE_EVASION,
            MitreTechnique.T1564: MitreTactic.DEFENSE_EVASION,
            MitreTechnique.T1003: MitreTactic.CREDENTIAL_ACCESS,
            MitreTechnique.T1552: MitreTactic.CREDENTIAL_ACCESS,
            MitreTechnique.T1548: MitreTactic.PRIVILEGE_ESCALATION,
            MitreTechnique.T1005: MitreTactic.COLLECTION,
            MitreTechnique.T1039: MitreTactic.COLLECTION,
            MitreTechnique.T1485: MitreTactic.IMPACT,
            MitreTechnique.T1486: MitreTactic.IMPACT,
            MitreTechnique.T1491: MitreTactic.IMPACT,
            MitreTechnique.T1565: MitreTactic.IMPACT,
        }
        tactic = tactic_map.get(technique, MitreTactic.IMPACT)
        tech_id = technique.value.split()[0]
        return MitreAttackReference(
            tactic=tactic,
            technique=technique,
            url=f"https://attack.mitre.org/techniques/{tech_id}/",
        )
    
    if change_type and change_type in CHANGE_TYPE_MITRE:
        tactic, technique = CHANGE_TYPE_MITRE[change_type]
        tech_id = technique.value.split()[0]
        return MitreAttackReference(
            tactic=tactic,
            technique=technique,
            url=f"https://attack.mitre.org/techniques/{tech_id}/",
        )
    
    return None


def detect_os() -> OperatingSystem:
    """Detect current operating system."""
    system = platform.system().lower()
    if system == "windows":
        return OperatingSystem.WINDOWS
    elif system == "linux":
        return OperatingSystem.LINUX
    elif system == "darwin":
        return OperatingSystem.MACOS
    return OperatingSystem.LINUX  # Default


def get_file_type(path: Path) -> FileType:
    """Determine file type."""
    try:
        if path.is_symlink():
            return FileType.SYMLINK
        elif path.is_dir():
            return FileType.DIRECTORY
        elif path.is_file():
            return FileType.REGULAR_FILE
        elif path.is_socket():
            return FileType.SOCKET
        elif path.is_fifo():
            return FileType.PIPE
        elif path.is_block_device() or path.is_char_device():
            return FileType.DEVICE
        return FileType.UNKNOWN
    except Exception:
        return FileType.UNKNOWN


def calculate_hash(filepath: Path, algorithm: HashAlgorithm) -> Optional[str]:
    """Calculate file hash."""
    try:
        if algorithm == HashAlgorithm.MD5:
            hasher = hashlib.md5()
        elif algorithm == HashAlgorithm.SHA1:
            hasher = hashlib.sha1()
        elif algorithm == HashAlgorithm.SHA256:
            hasher = hashlib.sha256()
        elif algorithm == HashAlgorithm.SHA512:
            hasher = hashlib.sha512()
        else:
            return None
        
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                hasher.update(chunk)
        
        return hasher.hexdigest()
    except Exception as e:
        logger.debug(f"Failed to hash {filepath}: {e}")
        return None


def get_file_permissions(filepath: Path) -> FilePermissions:
    """Get file permissions."""
    try:
        st = filepath.stat()
        mode = st.st_mode
        
        return FilePermissions(
            mode=oct(mode)[-4:],
            mode_octal=mode & 0o7777,
            owner_read=bool(mode & stat.S_IRUSR),
            owner_write=bool(mode & stat.S_IWUSR),
            owner_execute=bool(mode & stat.S_IXUSR),
            group_read=bool(mode & stat.S_IRGRP),
            group_write=bool(mode & stat.S_IWGRP),
            group_execute=bool(mode & stat.S_IXGRP),
            other_read=bool(mode & stat.S_IROTH),
            other_write=bool(mode & stat.S_IWOTH),
            other_execute=bool(mode & stat.S_IXOTH),
            setuid=bool(mode & stat.S_ISUID),
            setgid=bool(mode & stat.S_ISGID),
            sticky=bool(mode & stat.S_ISVTX),
        )
    except Exception:
        return FilePermissions()


def get_file_ownership(filepath: Path) -> FileOwnership:
    """Get file ownership."""
    try:
        st = filepath.stat()
        
        # Try to get user/group names
        try:
            import pwd
            import grp
            user = pwd.getpwuid(st.st_uid).pw_name
            group = grp.getgrgid(st.st_gid).gr_name
        except (ImportError, KeyError):
            user = str(st.st_uid)
            group = str(st.st_gid)
        
        return FileOwnership(
            uid=st.st_uid,
            gid=st.st_gid,
            user=user,
            group=group,
        )
    except Exception:
        return FileOwnership()


def get_file_timestamps(filepath: Path) -> FileTimestamps:
    """Get file timestamps."""
    try:
        st = filepath.stat()
        
        return FileTimestamps(
            modified=datetime.fromtimestamp(st.st_mtime),
            accessed=datetime.fromtimestamp(st.st_atime),
            changed=datetime.fromtimestamp(st.st_ctime),
        )
    except Exception:
        return FileTimestamps()


def get_file_metadata(
    filepath: Path,
    hash_algorithms: List[HashAlgorithm] = None,
    check_hashes: bool = True,
    max_file_size: int = 100 * 1024 * 1024,
) -> Optional[FileMetadata]:
    """Get complete file metadata."""
    if hash_algorithms is None:
        hash_algorithms = [HashAlgorithm.SHA256]
    
    try:
        st = filepath.stat()
        file_type = get_file_type(filepath)
        
        # Calculate hashes for regular files
        hashes = FileHashes()
        if check_hashes and file_type == FileType.REGULAR_FILE and st.st_size <= max_file_size:
            for algo in hash_algorithms:
                hash_value = calculate_hash(filepath, algo)
                if algo == HashAlgorithm.MD5:
                    hashes.md5 = hash_value
                elif algo == HashAlgorithm.SHA1:
                    hashes.sha1 = hash_value
                elif algo == HashAlgorithm.SHA256:
                    hashes.sha256 = hash_value
                elif algo == HashAlgorithm.SHA512:
                    hashes.sha512 = hash_value
        
        # Get symlink target
        symlink_target = None
        if file_type == FileType.SYMLINK:
            try:
                symlink_target = str(filepath.resolve())
            except Exception:
                pass
        
        return FileMetadata(
            path=str(filepath),
            name=filepath.name,
            file_type=file_type,
            size=st.st_size if file_type == FileType.REGULAR_FILE else 0,
            hashes=hashes,
            permissions=get_file_permissions(filepath),
            ownership=get_file_ownership(filepath),
            timestamps=get_file_timestamps(filepath),
            inode=st.st_ino,
            link_count=st.st_nlink,
            symlink_target=symlink_target,
        )
    except Exception as e:
        logger.debug(f"Failed to get metadata for {filepath}: {e}")
        return None


def should_exclude(
    filepath: Path,
    exclude_paths: Optional[List[str]] = None,
    exclude_patterns: Optional[List[str]] = None,
    exclude_extensions: Optional[List[str]] = None,
) -> bool:
    """Check if file should be excluded."""
    path_str = str(filepath)
    
    # Check path exclusions
    if exclude_paths:
        for excl in exclude_paths:
            if path_str.startswith(excl) or excl in path_str:
                return True
    
    # Check pattern exclusions
    if exclude_patterns:
        for pattern in exclude_patterns:
            if re.search(pattern, path_str):
                return True
    
    # Check extension exclusions
    if exclude_extensions and filepath.suffix:
        if filepath.suffix.lower() in [e.lower() for e in exclude_extensions]:
            return True
    
    return False


# =============================================================================
