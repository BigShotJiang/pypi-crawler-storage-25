"""
File Integrity Monitor Plugin Modules

Modular components for file integrity monitoring.
"""

