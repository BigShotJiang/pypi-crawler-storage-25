"""
File Integrity Monitor Plugin

Comprehensive file integrity monitoring covering:
- Baseline creation and comparison
- Change detection (create, modify, delete, rename)
- Hash verification (MD5, SHA1, SHA256, SHA512)
- Attribute monitoring (permissions, ownership, timestamps)
- Compliance mapping (PCI-DSS, HIPAA, SOX, NIST)
- Critical system file monitoring
- MITRE ATT&CK mapping
"""

import logging
import os
import platform
import socket
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from plugins.base_plugin import BasePlugin

from .proto import (
    Baseline,
    ChangeType,
    CriticalFileDefinition,
    FileChange,
    FileMetadata,
    FIMFinding,
    FIMScanOutput,
    HashAlgorithm,
    MonitoringMode,
    MonitoringRule,
    OperatingSystem,
    ScanMetadata,
    ScanOptions,
    SeverityLevel,
)

# Import services and utilities
from .modules.services import (
    BaselineManager,
    BaselineSqliteStore,
    BaselineRow,
    CriticalFileChecker,
    FileScanner,
    FindingService,
    OutputService,
    RecommendationsService,
)
from .modules.databases.fim_databases import (
    CRITICAL_FILES_LINUX,
    CRITICAL_FILES_WINDOWS,
    DEFAULT_RULES_LINUX,
    DEFAULT_RULES_WINDOWS,
)
from .modules.utils.fim_utils import (
    detect_os,
    get_mitre_reference,
)
from .modules.databases.ui_templates import (
    build_fim_description,
    get_fim_guidance,
    should_upgrade_fim_description,
)

logger = logging.getLogger(__name__)

class FileIntegrityMonitorPlugin(BasePlugin):
    """
    File Integrity Monitor Plugin.
    
    Comprehensive file integrity monitoring.
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.os_type: OperatingSystem = OperatingSystem.AUTO
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
        # Components
        self.scanner: Optional[FileScanner] = None
        # NOTE: BaselineManager (JSON) is kept only for backward compatibility, but is not used in streaming mode.
        # We avoid loading JSON baselines eagerly because it can blow up RAM on small hosts.
        self.baseline_manager = None
        self.critical_checker: Optional[CriticalFileChecker] = None
        
        # Services
        self.finding_service = FindingService(self)
        self.recommendations_service = RecommendationsService(self)
        self.output_service = OutputService(self)
        
        # Results
        self.findings: List[FIMFinding] = []
        self.changes: List[FileChange] = []
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket using common helper."""
        from plugins.plugin_helpers import handle_partial
        await handle_partial(
            command_id=self.command_id,
            progress=percent,
            ws_client=self.ws,
            output={"message": message}
        )

    async def _send_partial_changes(self, changes_payload: Dict[str, Any], progress: Optional[int] = None):
        """
        Send a partial_result with a small batch of changes.
        This is designed for streaming UI updates without waiting for full completion.
        """
        try:
            if self.ws and hasattr(self.ws, "send_command_partial_result"):
                out = {"data": changes_payload}
                meta = {}
                if progress is not None:
                    meta["progress"] = progress
                await self.ws.send_command_partial_result(self.command_id, output=out, metadata=meta)
        except Exception:
            # best-effort; do not break scan
            return
    
    async def run(self):
        """Main entry point."""
        try:
            # Check if a specific command was requested
            command = self.options.get('command', 'run')
            # Determine whether a baseline exists (sqlite-backed, streaming-safe)
            try:
                store = BaselineSqliteStore()
                baseline_exists = store.has_baseline()
                store.close()
            except Exception:
                baseline_exists = False
            
            if command == 'baseline':
                # Create baseline mode
                options = ScanOptions(mode=MonitoringMode.BASELINE)
                return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_fim_scan(options)))
            elif command in ['compare', 'scan']:
                # Compare to baseline mode
                options = ScanOptions(mode=MonitoringMode.COMPARE)
                return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_fim_scan(options)))
            elif command in ['monitor', 'fim_scan', 'run']:
                # Auto mode: create baseline if none exists, otherwise compare
                if baseline_exists:
                    logger.info("Found existing sqlite baseline, running comparison")
                    options = ScanOptions(mode=MonitoringMode.COMPARE)
                else:
                    logger.info("No sqlite baseline found, creating one first")
                    options = ScanOptions(mode=MonitoringMode.BASELINE)
                return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_fim_scan(options)))
            else:
                # Unknown command, use default behavior
                logger.warning(f"Unknown command '{command}', using default FIM scan")
                options = ScanOptions(mode=MonitoringMode.COMPARE)
                return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_fim_scan(options)))
        except Exception as e:
            logger.exception(f"Error in file_integrity_monitor.run(): {e}")
            return self.to_security_scan_v1(
                FIMScanOutput(
                    metadata=ScanMetadata(
                        scan_id=str(uuid.uuid4()),
                        mode=MonitoringMode.COMPARE,
                        operating_system=self.os_type,
                        started_at=datetime.utcnow(),
                        completed_at=datetime.utcnow(),
                        duration_seconds=0.0,
                    ),
                    errors=[str(e)],
                )
            )

    def _with_canonical_findings(self, output: Any) -> Any:
        """
        Ensure findings include analyst-friendly `impact` and structured `recommendations`.
        Keep plugin-specific enrichment inside the plugin (not in security_contract).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                return output
        except Exception:
            return output

        findings = out.get("findings") or []
        if isinstance(findings, list):
            for f in findings:
                if not isinstance(f, dict):
                    continue
                if should_upgrade_fim_description(f.get("description")):
                    f["description"] = build_fim_description(
                        change_type=str(f.get("change_type") or f.get("changeType") or ""),
                        file_path=str(f.get("file_path") or f.get("filePath") or "unknown"),
                    )
                if not f.get("impact"):
                    impact, _ = get_fim_guidance(
                        change_type=str(f.get("change_type") or f.get("changeType") or ""),
                        file_path=str(f.get("file_path") or f.get("filePath") or "") if (f.get("file_path") or f.get("filePath")) else None,
                    )
                    f["impact"] = impact

                if not f.get("recommendations"):
                    rec_str = f.get("recommendation")
                    if isinstance(rec_str, str) and rec_str.strip():
                        f["recommendations"] = [
                            {"title": "Recommendation", "description": rec_str.strip(), "priority": "medium"}
                        ]
                    else:
                        _, fallback_recs = get_fim_guidance(
                            change_type=str(f.get("change_type") or f.get("changeType") or ""),
                            file_path=str(f.get("file_path") or f.get("filePath") or "") if (f.get("file_path") or f.get("filePath")) else None,
                        )
                        f["recommendations"] = fallback_recs

                if not f.get("affected_resources"):
                    fp = f.get("file_path") or f.get("filePath")
                    ar_fim: List[Dict[str, Any]] = []
                    if isinstance(fp, str) and fp.strip():
                        ar_fim.append({"type": "fim_protected_path", "path": fp.strip()[:2000]})
                    try:
                        ar_fim.append({"type": "scanned_host", "hostname": socket.gethostname()})
                    except Exception:
                        pass
                    if ar_fim:
                        f["affected_resources"] = ar_fim

        out["findings"] = findings
        return out
    
    async def hook_fim_scan(
        self,
        options: Optional[ScanOptions] = None,
    ) -> FIMScanOutput:
        """
        Main entry point for FIM scanning.
        
        Args:
            options: Scan configuration (if None, uses default)
            
        Returns:
            FIMScanOutput
        """
        if options is None:
            options = ScanOptions()
        
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.utcnow()
        self.errors = []
        self.warnings = []
        self.findings = []
        self.changes = []
        
        # Detect OS
        if options.operating_system == OperatingSystem.AUTO:
            self.os_type = detect_os()
        else:
            self.os_type = options.operating_system
        
        # Initialize components
        self.scanner = FileScanner(
            hash_algorithms=options.hash_algorithms,
            check_hashes=options.check_hashes,
            max_file_size=options.target.max_file_size,
        )
        self.critical_checker = CriticalFileChecker(self.os_type)
        
        await self._handle_progress(0, "Starting FIM scan")

        # Heuristic: cap max_files on low-memory hosts to prevent OOM.
        # Still allow full scans on larger hosts.
        effective_max_files = options.max_files
        try:
            import psutil  # type: ignore
            total_mb = int(psutil.virtual_memory().total // (1024 * 1024))
            if total_mb <= 768:
                effective_max_files = min(effective_max_files, 3000)
            elif total_mb <= 1536:
                effective_max_files = min(effective_max_files, 10000)
        except Exception:
            pass
        
        # Get paths to scan
        paths = options.target.paths
        if not paths and options.use_default_rules:
            # Use default rules for OS
            if self.os_type == OperatingSystem.LINUX:
                paths = [r.paths[0] for r in DEFAULT_RULES_LINUX if r.paths]
            elif self.os_type == OperatingSystem.WINDOWS:
                paths = [r.paths[0] for r in DEFAULT_RULES_WINDOWS if r.paths]
        
        # Streaming baseline/compare using SQLite to avoid storing huge snapshots in RAM.
        store = BaselineSqliteStore()
        store.connect()
        store.reset_seen()

        await self._handle_progress(10, f"Scanning {len(paths)} paths")
        scanned = 0
        # streaming counters + bounded sample for final summary
        counts = {"created": 0, "deleted": 0, "content_changed": 0, "permissions_changed": 0, "ownership_changed": 0, "modified": 0}
        sample: List[Dict[str, Any]] = []
        sample_max = int(os.getenv("FIM_FINAL_SAMPLE_MAX", "200"))
        batch: List[Dict[str, Any]] = []
        batch_size = int(getattr(options, "stream_batch_size", 50) or 50)

        def meta_to_row(p: str, m: FileMetadata) -> BaselineRow:
            # FileMetadata is pydantic; keep only minimal columns for baseline compare.
            mode_o = None
            uid = None
            gid = None
            sha256 = None
            try:
                if getattr(m, "permissions", None) and getattr(m.permissions, "mode_octal", None) is not None:
                    mode_o = int(m.permissions.mode_octal)
            except Exception:
                mode_o = None
            try:
                if getattr(m, "ownership", None):
                    uid = int(getattr(m.ownership, "uid", 0))
                    gid = int(getattr(m.ownership, "gid", 0))
            except Exception:
                uid = None
                gid = None
            try:
                if getattr(m, "hashes", None):
                    sha256 = getattr(m.hashes, "sha256", None)
            except Exception:
                sha256 = None

            mtime_ns = 0
            try:
                if getattr(m, "timestamps", None) and getattr(m.timestamps, "modified", None):
                    # Pydantic datetime -> ns
                    mtime_ns = int(m.timestamps.modified.timestamp() * 1e9)
            except Exception:
                mtime_ns = 0

            return BaselineRow(
                path=p,
                size=int(getattr(m, "size", 0) or 0),
                mtime_ns=mtime_ns,
                mode_octal=mode_o,
                uid=uid,
                gid=gid,
                sha256=str(sha256) if sha256 else None,
            )

        def emit_change(change_type: str, path: str, details: Dict[str, Any]) -> None:
            counts[change_type] = int(counts.get(change_type, 0)) + 1
            item = {"change_type": change_type, "path": path, **details}
            batch.append(item)
            if len(sample) < sample_max:
                sample.append(item)

        try:
            # Mode: baseline creation
            if options.mode == MonitoringMode.BASELINE or options.create_baseline:
                store.clear_baseline()
            else:
                # Compare mode: if baseline is empty, switch to baseline creation to avoid
                # streaming a massive "everything is created" set.
                if not store.has_baseline():
                    self.warnings.append("No baseline found; creating baseline first (streaming mode).")
                    options = options.model_copy(update={"mode": MonitoringMode.BASELINE, "create_baseline": True}) if hasattr(options, "model_copy") else options
                    store.clear_baseline()

            for root_path in paths:
                for p, meta in self.scanner.iter_path(
                    root_path,
                    recursive=options.target.recursive,
                    max_depth=options.target.max_depth,
                    max_files=effective_max_files,
                    exclude_paths=options.target.exclude_paths,
                    exclude_patterns=options.target.exclude_patterns,
                    exclude_extensions=options.target.exclude_extensions,
                    follow_symlinks=options.target.follow_symlinks,
                ):
                    scanned += 1

                    row = meta_to_row(p, meta)
                    if options.mode == MonitoringMode.BASELINE or options.create_baseline:
                        store.upsert_baseline_row(row)
                    else:
                        # compare
                        base = store.get_baseline_row(p)
                        store.mark_seen(p)
                        if base is None:
                            emit_change("created", p, {"size": row.size})
                        else:
                            # lightweight diff (hash first, then perms/ownership/mtime/size)
                            if options.check_hashes and base.sha256 and row.sha256 and base.sha256 != row.sha256:
                                emit_change("content_changed", p, {"old_sha256": base.sha256, "new_sha256": row.sha256})
                            elif options.check_permissions and base.mode_octal is not None and row.mode_octal is not None and base.mode_octal != row.mode_octal:
                                emit_change("permissions_changed", p, {"old_mode": base.mode_octal, "new_mode": row.mode_octal})
                            elif options.check_ownership and base.uid is not None and row.uid is not None and (base.uid != row.uid or base.gid != row.gid):
                                emit_change("ownership_changed", p, {"old_uid": base.uid, "old_gid": base.gid, "new_uid": row.uid, "new_gid": row.gid})
                            elif base.size != row.size:
                                emit_change("modified", p, {"old_size": base.size, "new_size": row.size})

                    # Flush baseline writes in chunks
                    if (options.mode == MonitoringMode.BASELINE or options.create_baseline) and scanned % 500 == 0:
                        store.commit()

                    # Stream changes batch (partial_result) as they appear
                    if batch and len(batch) >= batch_size:
                        pct = min(95, int((scanned / max(1, effective_max_files)) * 70)) if effective_max_files else None
                        await self._send_partial_changes(
                            {"plugin": "file_integrity_monitor", "changes": batch, "scanned": scanned},
                            progress=pct,
                        )
                        batch = []

                    if scanned >= effective_max_files:
                        self.warnings.append(
                            f"FIM scan truncated at {effective_max_files} files to prevent OOM. "
                            f"Reduce scope (paths/excludes) or run on a larger machine for full coverage."
                        )
                        break
                if scanned >= effective_max_files:
                    break

            self.errors.extend(self.scanner.errors)

            await self._handle_progress(50, f"Scanned {scanned} files")

            baseline_created = None
            baseline_used = None

            if options.mode == MonitoringMode.BASELINE or options.create_baseline:
                store.commit()
                store.set_meta("baseline_updated_at", datetime.utcnow().isoformat() + "Z")
                await self._handle_progress(100, "Baseline created")
                # Final output: minimal (avoid shipping massive baseline)
                return self.output_service.create_output(
                    options,
                    current_files={},  # not used for baseline-only output beyond summaries
                    baseline_created=None,
                    baseline_used=None,
                    new_files=[],
                    missing_files=[],
                    modified_files=[],
                    recommendations=self.recommendations_service.generate_recommendations(),
                    immediate_actions=self.recommendations_service.get_immediate_actions(),
                )

            # Compare mode: stream deletions (baseline paths not seen)
            await self._handle_progress(60, "Checking for deleted files")
            deleted_batch: List[Dict[str, Any]] = []
            for dp in store.iter_deleted_paths(batch_size=250):
                counts["deleted"] += 1
                deleted_batch.append({"change_type": "deleted", "path": dp})
                if len(deleted_batch) >= batch_size:
                    await self._send_partial_changes(
                        {"plugin": "file_integrity_monitor", "changes": deleted_batch, "scanned": scanned, "phase": "deleted_check"},
                        progress=90,
                    )
                    deleted_batch = []
            if deleted_batch:
                await self._send_partial_changes(
                    {"plugin": "file_integrity_monitor", "changes": deleted_batch, "scanned": scanned, "phase": "deleted_check"},
                    progress=90,
                )

            # We still build a small in-memory list for the final report (bounded)
            self.changes = []
            # NOTE: Full canonical findings require full change objects; streaming UI will have details already.
            self.warnings.append(
                "Streaming mode enabled: full per-file change list is streamed during execution; final report is summarized."
            )

        finally:
            try:
                store.close()
            except Exception:
                pass

        await self._handle_progress(92, "Generating recommendations")
        recommendations = self.recommendations_service.generate_recommendations()
        immediate_actions = self.recommendations_service.get_immediate_actions()

        await self._handle_progress(100, "Scan complete")
        # Final output: summarized (keeps compatibility)
        # Send one last partial snapshot with summary + sample (so backend/UI can render without full list).
        await self._send_partial_changes(
            {
                "plugin": "file_integrity_monitor",
                "summary": counts,
                "sample": sample,
                "scanned": scanned,
                "phase": "final_summary",
            },
            progress=100,
        )
        return self.output_service.create_output(
            options,
            current_files={},
            baseline_created=None,
            baseline_used=None,
            new_files=[],
            missing_files=[],
            modified_files=[],
            recommendations=recommendations,
            immediate_actions=immediate_actions,
        )
        
        # Handle different modes
        baseline_created = None
        baseline_used = None
        new_files: List[str] = []
        missing_files: List[str] = []
        modified_files: List[str] = []
        
        if options.mode == MonitoringMode.BASELINE or options.create_baseline:
            # Create baseline
            await self._handle_progress(60, "Creating baseline")
            baseline_created = self.baseline_manager.create_baseline(
                name=options.baseline_name or f"Baseline_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
                files=current_files,
                os_type=self.os_type,
            )
        
        elif options.mode == MonitoringMode.COMPARE:
            # Compare to baseline
            await self._handle_progress(60, "Comparing to baseline")
            
            baseline = options.baseline
            if not baseline and options.baseline_id:
                baseline = self.baseline_manager.baselines.get(options.baseline_id)
            
            # Auto-select latest baseline if none specified
            if not baseline and self.baseline_manager.baselines:
                # Get the most recent baseline by created_at
                baselines_list = list(self.baseline_manager.baselines.values())
                baselines_list.sort(key=lambda b: b.created_at or datetime.min, reverse=True)
                baseline = baselines_list[0]
                logger.info(f"Auto-selected latest baseline: {baseline.name} ({baseline.id})")
            
            if baseline:
                baseline_used = baseline.id
                self.changes, new_files, missing_files, modified_files = \
                    self.baseline_manager.compare_to_baseline(
                        baseline,
                        current_files,
                        check_hashes=options.check_hashes,
                        check_permissions=options.check_permissions,
                        check_ownership=options.check_ownership,
                        check_timestamps=options.check_timestamps,
                    )
            else:
                self.warnings.append("No baseline available - create one first with 'baseline' command")
        
        # Mark critical files
        await self._handle_progress(75, "Analyzing changes")
        severity_order = {
            SeverityLevel.CRITICAL: 4,
            SeverityLevel.HIGH: 3,
            SeverityLevel.MEDIUM: 2,
            SeverityLevel.LOW: 1,
            SeverityLevel.INFO: 0,
        }
        for change in self.changes:
            critical = self.critical_checker.is_critical(change.path)
            if critical:
                change.is_critical_file = True
                # Compare severities and use the higher one
                current_severity_level = severity_order.get(change.severity, 0)
                critical_severity_level = severity_order.get(critical.severity, 0)
                if critical_severity_level > current_severity_level:
                    change.severity = critical.severity
                if critical.mitre:
                    change.mitre = get_mitre_reference(technique=critical.mitre)
        
        # Create findings
        await self._handle_progress(85, "Creating findings")
        self.finding_service.create_findings(options)
        
        # Generate recommendations
        await self._handle_progress(92, "Generating recommendations")
        recommendations = self.recommendations_service.generate_recommendations()
        immediate_actions = self.recommendations_service.get_immediate_actions()
        
        await self._handle_progress(100, "Scan complete")
        
        return self.output_service.create_output(
            options,
            current_files,
            baseline_created,
            baseline_used,
            new_files,
            missing_files,
            modified_files,
            recommendations,
            immediate_actions,
        )
    
# Utility Functions
# =============================================================================

async def create_baseline(
    paths: List[str],
    name: Optional[str] = None,
    hash_algorithms: List[HashAlgorithm] = None,
) -> FIMScanOutput:
    """
    Convenience function to create a baseline.
    
    Args:
        paths: Paths to include in baseline
        name: Baseline name
        hash_algorithms: Hash algorithms to use
        
    Returns:
        FIMScanOutput with baseline_created
    """
    if hash_algorithms is None:
        hash_algorithms = [HashAlgorithm.SHA256]
    
    target = ScanTarget(paths=paths)
    options = ScanOptions(
        target=target,
        mode=MonitoringMode.BASELINE,
        create_baseline=True,
        baseline_name=name,
        hash_algorithms=hash_algorithms,
    )
    
    plugin = FileIntegrityMonitorPlugin()
    return await plugin.hook_fim_scan(options)


async def compare_to_baseline(
    paths: List[str],
    baseline: Baseline,
) -> FIMScanOutput:
    """
    Compare current state to baseline.
    
    Args:
        paths: Paths to scan
        baseline: Baseline to compare against
        
    Returns:
        FIMScanOutput with changes
    """
    target = ScanTarget(paths=paths)
    options = ScanOptions(
        target=target,
        mode=MonitoringMode.COMPARE,
        baseline=baseline,
    )
    
    plugin = FileIntegrityMonitorPlugin()
    return await plugin.hook_fim_scan(options)


def get_critical_files(os_type: OperatingSystem = OperatingSystem.AUTO) -> List[CriticalFileDefinition]:
    """Get list of critical files for OS."""
    if os_type == OperatingSystem.AUTO:
        os_type = detect_os()
    
    if os_type == OperatingSystem.WINDOWS:
        return CRITICAL_FILES_WINDOWS
    elif os_type == OperatingSystem.LINUX:
        return CRITICAL_FILES_LINUX
    return []


def get_default_rules(os_type: OperatingSystem = OperatingSystem.AUTO) -> List[MonitoringRule]:
    """Get default monitoring rules for OS."""
    if os_type == OperatingSystem.AUTO:
        os_type = detect_os()
    
    if os_type == OperatingSystem.WINDOWS:
        return DEFAULT_RULES_WINDOWS
    elif os_type == OperatingSystem.LINUX:
        return DEFAULT_RULES_LINUX
    return []


def calculate_file_hash(filepath: str, algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> Optional[str]:
    """Calculate hash for a single file."""
    from pathlib import Path
    from .modules.utils.fim_utils import calculate_hash
    return calculate_hash(Path(filepath), algorithm)


def get_change_types() -> List[str]:
    """Get list of change types."""
    return [c.value for c in ChangeType]


def get_compliance_frameworks() -> List[str]:
    """Get list of compliance frameworks."""
    return [c.value for c in ComplianceFramework]
