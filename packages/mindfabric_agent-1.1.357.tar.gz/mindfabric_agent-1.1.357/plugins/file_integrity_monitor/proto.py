"""
File Integrity Monitor Plugin - Pydantic Models

Comprehensive file integrity monitoring covering:
- Baseline creation and comparison
- Change detection (create, modify, delete, rename)
- Hash verification (MD5, SHA1, SHA256, SHA512)
- Attribute monitoring (permissions, ownership, timestamps)
- Compliance mapping (PCI-DSS, HIPAA, SOX, NIST)
- Real-time and scheduled monitoring
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional, Union, Set
from pydantic import BaseModel, Field
from plugins.reproduction import ReproStep


# =============================================================================
# Enumerations
# =============================================================================

class SeverityLevel(str, Enum):
    """Severity classification for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ConfidenceLevel(str, Enum):
    """Confidence level for detections."""
    CONFIRMED = "confirmed"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    TENTATIVE = "tentative"


class FindingStatus(str, Enum):
    """Status of a finding."""
    OPEN = "open"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    FIXED = "fixed"
    ACCEPTED_RISK = "accepted_risk"


class OperatingSystem(str, Enum):
    """Operating system types."""
    WINDOWS = "windows"
    LINUX = "linux"
    MACOS = "macos"
    AUTO = "auto"


class ChangeType(str, Enum):
    """Type of file change."""
    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    RENAMED = "renamed"
    PERMISSIONS_CHANGED = "permissions_changed"
    OWNERSHIP_CHANGED = "ownership_changed"
    ATTRIBUTES_CHANGED = "attributes_changed"
    CONTENT_CHANGED = "content_changed"
    METADATA_CHANGED = "metadata_changed"


class FileType(str, Enum):
    """Type of file."""
    REGULAR_FILE = "regular_file"
    DIRECTORY = "directory"
    SYMLINK = "symlink"
    HARDLINK = "hardlink"
    DEVICE = "device"
    SOCKET = "socket"
    PIPE = "pipe"
    UNKNOWN = "unknown"


class HashAlgorithm(str, Enum):
    """Hash algorithms."""
    MD5 = "md5"
    SHA1 = "sha1"
    SHA256 = "sha256"
    SHA512 = "sha512"


class MonitoringMode(str, Enum):
    """Monitoring mode."""
    BASELINE = "baseline"
    COMPARE = "compare"
    REALTIME = "realtime"
    SCHEDULED = "scheduled"


class ComplianceFramework(str, Enum):
    """Compliance frameworks."""
    PCI_DSS = "PCI-DSS"
    HIPAA = "HIPAA"
    SOX = "SOX"
    NIST_800_53 = "NIST 800-53"
    CIS = "CIS"
    ISO_27001 = "ISO 27001"
    GDPR = "GDPR"
    SOC2 = "SOC 2"


class ComplianceRequirement(str, Enum):
    """Specific compliance requirements."""
    # PCI-DSS
    PCI_DSS_10_5 = "PCI-DSS 10.5 - Secure audit trails"
    PCI_DSS_11_5 = "PCI-DSS 11.5 - File integrity monitoring"
    
    # HIPAA
    HIPAA_164_312_B = "HIPAA 164.312(b) - Audit controls"
    HIPAA_164_312_C_1 = "HIPAA 164.312(c)(1) - Integrity controls"
    
    # SOX
    SOX_302 = "SOX Section 302 - Corporate responsibility"
    SOX_404 = "SOX Section 404 - Internal controls"
    
    # NIST
    NIST_SI_7 = "NIST SI-7 - Software, firmware, and information integrity"
    NIST_AU_9 = "NIST AU-9 - Protection of audit information"
    
    # CIS
    CIS_CONTROL_3 = "CIS Control 3 - Data Protection"
    CIS_CONTROL_8 = "CIS Control 8 - Audit Log Management"


class AlertLevel(str, Enum):
    """Alert level for changes."""
    CRITICAL_ALERT = "critical_alert"
    HIGH_ALERT = "high_alert"
    MEDIUM_ALERT = "medium_alert"
    LOW_ALERT = "low_alert"
    INFORMATIONAL = "informational"


class MitreTactic(str, Enum):
    """MITRE ATT&CK Tactics."""
    PERSISTENCE = "TA0003 Persistence"
    PRIVILEGE_ESCALATION = "TA0004 Privilege Escalation"
    DEFENSE_EVASION = "TA0005 Defense Evasion"
    CREDENTIAL_ACCESS = "TA0006 Credential Access"
    COLLECTION = "TA0009 Collection"
    IMPACT = "TA0040 Impact"


class MitreTechnique(str, Enum):
    """MITRE ATT&CK Techniques."""
    # Persistence
    T1037 = "T1037 Boot or Logon Initialization Scripts"
    T1053 = "T1053 Scheduled Task/Job"
    T1136 = "T1136 Create Account"
    T1543 = "T1543 Create or Modify System Process"
    T1546 = "T1546 Event Triggered Execution"
    T1547 = "T1547 Boot or Logon Autostart Execution"
    T1574 = "T1574 Hijack Execution Flow"
    
    # Defense Evasion
    T1070 = "T1070 Indicator Removal"
    T1070_004 = "T1070.004 File Deletion"
    T1222 = "T1222 File and Directory Permissions Modification"
    T1564 = "T1564 Hide Artifacts"
    
    # Credential Access
    T1003 = "T1003 OS Credential Dumping"
    T1552 = "T1552 Unsecured Credentials"
    
    # Privilege Escalation
    T1548 = "T1548 Abuse Elevation Control Mechanism"
    
    # Collection
    T1005 = "T1005 Data from Local System"
    T1039 = "T1039 Data from Network Shared Drive"
    
    # Impact
    T1485 = "T1485 Data Destruction"
    T1486 = "T1486 Data Encrypted for Impact"
    T1491 = "T1491 Defacement"
    T1565 = "T1565 Data Manipulation"


# =============================================================================
# Exploitation Commands Model
# =============================================================================

class ExploitationCommands(BaseModel):
    """Explicit commands for FIM verification, investigation, or remediation."""
    server: Optional[str] = Field(None, description="Target server/host")
    ip: Optional[str] = Field(None, description="Target IP address")
    commands: List[str] = Field(default_factory=list, description="List of shell commands")
    description: Optional[str] = Field(None, description="Description of the commands")


# =============================================================================
# MITRE Reference Model
# =============================================================================

class MitreAttackReference(BaseModel):
    """MITRE ATT&CK reference."""
    tactic: MitreTactic = Field(..., description="MITRE tactic")
    technique: MitreTechnique = Field(..., description="MITRE technique")
    url: Optional[str] = Field(None, description="Reference URL")


# =============================================================================
# File Models
# =============================================================================

class FilePermissions(BaseModel):
    """File permissions."""
    # Unix-style permissions
    mode: Optional[str] = Field(None, description="Permission mode (e.g., 0755)")
    mode_octal: Optional[int] = Field(None, description="Octal mode")
    
    # Readable format
    owner_read: bool = Field(True)
    owner_write: bool = Field(True)
    owner_execute: bool = Field(False)
    group_read: bool = Field(True)
    group_write: bool = Field(False)
    group_execute: bool = Field(False)
    other_read: bool = Field(True)
    other_write: bool = Field(False)
    other_execute: bool = Field(False)
    
    # Special bits
    setuid: bool = Field(False)
    setgid: bool = Field(False)
    sticky: bool = Field(False)
    
    # Windows-specific
    readonly: Optional[bool] = Field(None)
    hidden: Optional[bool] = Field(None)
    system: Optional[bool] = Field(None)
    archive: Optional[bool] = Field(None)


class FileOwnership(BaseModel):
    """File ownership information."""
    # Unix
    uid: Optional[int] = Field(None, description="User ID")
    gid: Optional[int] = Field(None, description="Group ID")
    user: Optional[str] = Field(None, description="User name")
    group: Optional[str] = Field(None, description="Group name")
    
    # Windows
    owner_sid: Optional[str] = Field(None, description="Owner SID")
    owner_name: Optional[str] = Field(None, description="Owner name")


class FileHashes(BaseModel):
    """File hash values."""
    md5: Optional[str] = Field(None)
    sha1: Optional[str] = Field(None)
    sha256: Optional[str] = Field(None)
    sha512: Optional[str] = Field(None)


class FileTimestamps(BaseModel):
    """File timestamps."""
    created: Optional[datetime] = Field(None, description="Creation time")
    modified: Optional[datetime] = Field(None, description="Modification time")
    accessed: Optional[datetime] = Field(None, description="Access time")
    changed: Optional[datetime] = Field(None, description="Metadata change time (ctime)")


class FileMetadata(BaseModel):
    """Complete file metadata."""
    path: str = Field(..., description="Full file path")
    name: str = Field(..., description="File name")
    
    # Type and size
    file_type: FileType = Field(FileType.REGULAR_FILE)
    size: int = Field(0, description="File size in bytes")
    
    # Hashes
    hashes: FileHashes = Field(default_factory=FileHashes)
    
    # Permissions and ownership
    permissions: FilePermissions = Field(default_factory=FilePermissions)
    ownership: FileOwnership = Field(default_factory=FileOwnership)
    
    # Timestamps
    timestamps: FileTimestamps = Field(default_factory=FileTimestamps)
    
    # Links
    inode: Optional[int] = Field(None, description="Inode number")
    link_count: Optional[int] = Field(None, description="Hard link count")
    symlink_target: Optional[str] = Field(None, description="Symlink target")
    
    # Extended attributes
    extended_attributes: Optional[Dict[str, str]] = Field(None)
    
    # Windows-specific
    alternate_data_streams: Optional[List[str]] = Field(None)
    
    # Analysis flags
    is_critical: bool = Field(False)
    is_system: bool = Field(False)
    is_config: bool = Field(False)


# =============================================================================
# Change Models
# =============================================================================

class AttributeChange(BaseModel):
    """Change in a specific attribute."""
    attribute: str = Field(..., description="Attribute name")
    old_value: Optional[Any] = Field(None)
    new_value: Optional[Any] = Field(None)


class FileChange(BaseModel):
    """Detected file change."""
    id: str = Field(..., description="Change ID")
    
    # File info
    path: str = Field(..., description="File path")
    file_type: FileType = Field(FileType.REGULAR_FILE)
    
    # Change type
    change_type: ChangeType = Field(...)
    
    # For renames
    old_path: Optional[str] = Field(None)
    new_path: Optional[str] = Field(None)
    
    # Attribute changes
    attribute_changes: List[AttributeChange] = Field(default_factory=list)
    
    # Hash changes
    old_hashes: Optional[FileHashes] = Field(None)
    new_hashes: Optional[FileHashes] = Field(None)
    
    # Size change
    old_size: Optional[int] = Field(None)
    new_size: Optional[int] = Field(None)
    
    # Permission changes
    old_permissions: Optional[FilePermissions] = Field(None)
    new_permissions: Optional[FilePermissions] = Field(None)
    
    # Ownership changes
    old_ownership: Optional[FileOwnership] = Field(None)
    new_ownership: Optional[FileOwnership] = Field(None)
    
    # Timestamp changes
    old_timestamps: Optional[FileTimestamps] = Field(None)
    new_timestamps: Optional[FileTimestamps] = Field(None)
    
    # Detection
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Classification
    severity: SeverityLevel = Field(SeverityLevel.MEDIUM)
    alert_level: AlertLevel = Field(AlertLevel.MEDIUM_ALERT)
    
    # MITRE mapping
    mitre: Optional[MitreAttackReference] = Field(None)
    
    # Context
    is_critical_file: bool = Field(False)
    is_system_file: bool = Field(False)
    matched_rule: Optional[str] = Field(None)


# =============================================================================
# Rule Models
# =============================================================================

class MonitoringRule(BaseModel):
    """File monitoring rule."""
    id: str = Field(..., description="Rule ID")
    name: str = Field(..., description="Rule name")
    description: Optional[str] = Field(None)
    
    # Enabled
    enabled: bool = Field(True)
    
    # Paths
    paths: List[str] = Field(..., description="Paths to monitor")
    recursive: bool = Field(True, description="Monitor subdirectories")
    
    # Exclusions
    exclude_paths: Optional[List[str]] = Field(None)
    exclude_patterns: Optional[List[str]] = Field(None)
    exclude_extensions: Optional[List[str]] = Field(None)
    
    # What to monitor
    monitor_content: bool = Field(True, description="Monitor file content (hash)")
    monitor_permissions: bool = Field(True)
    monitor_ownership: bool = Field(True)
    monitor_timestamps: bool = Field(True)
    monitor_attributes: bool = Field(True)
    
    # Hash algorithms
    hash_algorithms: List[HashAlgorithm] = Field(
        default_factory=lambda: [HashAlgorithm.SHA256]
    )
    
    # Change types to alert on
    alert_on: List[ChangeType] = Field(
        default_factory=lambda: list(ChangeType)
    )
    
    # Classification
    severity: SeverityLevel = Field(SeverityLevel.MEDIUM)
    
    # Compliance
    compliance_tags: Optional[List[ComplianceRequirement]] = Field(None)
    
    # MITRE mapping
    mitre_technique: Optional[MitreTechnique] = Field(None)


class CriticalFileDefinition(BaseModel):
    """Definition of a critical file."""
    path: str = Field(...)
    description: str = Field(...)
    severity: SeverityLevel = Field(SeverityLevel.CRITICAL)
    compliance: Optional[List[ComplianceRequirement]] = Field(None)
    mitre: Optional[MitreTechnique] = Field(None)


# =============================================================================
# Baseline Models
# =============================================================================

class BaselineEntry(BaseModel):
    """Single baseline entry."""
    path: str = Field(...)
    metadata: FileMetadata = Field(...)
    captured_at: datetime = Field(default_factory=datetime.utcnow)
    rule_id: Optional[str] = Field(None)


class Baseline(BaseModel):
    """File integrity baseline."""
    id: str = Field(..., description="Baseline ID")
    name: str = Field(..., description="Baseline name")
    description: Optional[str] = Field(None)
    
    # Baseline info
    created_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: Optional[str] = Field(None)
    
    # Target
    hostname: Optional[str] = Field(None)
    operating_system: OperatingSystem = Field(OperatingSystem.AUTO)
    
    # Entries
    entries: Dict[str, BaselineEntry] = Field(default_factory=dict)
    total_files: int = Field(0)
    total_size: int = Field(0)
    
    # Rules used
    rules: List[str] = Field(default_factory=list)
    
    # Version
    version: int = Field(1)


# =============================================================================
# Finding Model
# =============================================================================

class FIMFinding(BaseModel):
    """File integrity monitoring finding."""
    id: str = Field(..., description="Finding ID")
    
    # Classification
    severity: SeverityLevel = Field(...)
    confidence: ConfidenceLevel = Field(...)
    alert_level: AlertLevel = Field(...)
    
    # MITRE
    mitre: Optional[MitreAttackReference] = Field(None)
    
    # Compliance
    compliance: Optional[List[ComplianceRequirement]] = Field(None)
    
    # Details
    title: str = Field(...)
    description: str = Field(...)
    
    # File context
    file_path: str = Field(...)
    file_type: FileType = Field(FileType.REGULAR_FILE)
    change_type: ChangeType = Field(...)
    
    # Change details
    change: FileChange = Field(...)
    
    # Rule context
    rule_id: Optional[str] = Field(None)
    rule_name: Optional[str] = Field(None)
    
    # Risk
    risk_score: float = Field(0.0, ge=0.0, le=10.0)
    
    # Remediation
    recommendation: str = Field(...)
    remediation_steps: Optional[List[str]] = Field(None)
    
    # Status
    status: FindingStatus = Field(FindingStatus.OPEN)
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Exploitation/Investigation commands
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to investigate or remediate this file change"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this finding"
    )


# =============================================================================
# Scan Configuration
# =============================================================================

class ScanTarget(BaseModel):
    """Scan target configuration."""
    # Paths
    paths: List[str] = Field(default_factory=list)
    recursive: bool = Field(True)
    
    # Exclusions
    exclude_paths: Optional[List[str]] = Field(None)
    exclude_patterns: Optional[List[str]] = Field(None)
    exclude_extensions: Optional[List[str]] = Field(None)
    
    # Follow symlinks
    follow_symlinks: bool = Field(False)
    
    # Max depth
    max_depth: Optional[int] = Field(None)
    
    # Max file size for hashing
    max_file_size: int = Field(100 * 1024 * 1024)  # 100MB default


class ScanOptions(BaseModel):
    """Scan configuration options."""
    target: ScanTarget = Field(default_factory=ScanTarget)
    
    # Mode
    mode: MonitoringMode = Field(MonitoringMode.COMPARE)
    
    # Baseline
    baseline_id: Optional[str] = Field(None)
    baseline: Optional[Baseline] = Field(None)
    create_baseline: bool = Field(False)
    baseline_name: Optional[str] = Field(None)
    
    # Rules
    rules: Optional[List[MonitoringRule]] = Field(None)
    use_default_rules: bool = Field(True)
    
    # OS detection
    operating_system: OperatingSystem = Field(OperatingSystem.AUTO)
    
    # What to check
    check_hashes: bool = Field(True)
    check_permissions: bool = Field(True)
    check_ownership: bool = Field(True)
    check_timestamps: bool = Field(True)
    check_attributes: bool = Field(True)
    check_extended_attrs: bool = Field(False)
    check_ads: bool = Field(False)  # Alternate Data Streams
    
    # Hash algorithms
    hash_algorithms: List[HashAlgorithm] = Field(
        default_factory=lambda: [HashAlgorithm.SHA256]
    )
    
    # Alert thresholds
    min_severity: SeverityLevel = Field(SeverityLevel.LOW)
    
    # Compliance
    compliance_mode: bool = Field(False)
    compliance_frameworks: Optional[List[ComplianceFramework]] = Field(None)
    
    # Performance
    max_files: int = Field(100000)
    timeout_seconds: int = Field(3600)
    parallel_workers: int = Field(4)


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary by severity."""
    critical: int = Field(0)
    high: int = Field(0)
    medium: int = Field(0)
    low: int = Field(0)
    info: int = Field(0)
    total: int = Field(0)


class ChangeTypeSummary(BaseModel):
    """Summary by change type."""
    created: int = Field(0)
    modified: int = Field(0)
    deleted: int = Field(0)
    renamed: int = Field(0)
    permissions_changed: int = Field(0)
    ownership_changed: int = Field(0)
    total: int = Field(0)


class ComplianceSummary(BaseModel):
    """Compliance summary."""
    framework: ComplianceFramework = Field(...)
    total_requirements: int = Field(0)
    findings_count: int = Field(0)
    critical_findings: int = Field(0)
    requirements_affected: List[str] = Field(default_factory=list)


class PathSummary(BaseModel):
    """Summary by monitored path."""
    path: str = Field(...)
    files_monitored: int = Field(0)
    changes_detected: int = Field(0)
    critical_changes: int = Field(0)


class RuleSummary(BaseModel):
    """Summary by rule."""
    rule_id: str = Field(...)
    rule_name: str = Field(...)
    files_matched: int = Field(0)
    changes_detected: int = Field(0)
    severity: SeverityLevel = Field(SeverityLevel.MEDIUM)


class ScanMetadata(BaseModel):
    """Scan metadata."""
    scan_id: str = Field(...)
    scan_type: str = Field("file_integrity")
    mode: MonitoringMode = Field(...)
    
    # Target
    hostname: Optional[str] = Field(None)
    operating_system: OperatingSystem = Field(...)
    paths_monitored: List[str] = Field(default_factory=list)
    
    # Timing
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(None)
    duration_seconds: Optional[float] = Field(None)
    
    # Coverage
    files_scanned: int = Field(0)
    directories_scanned: int = Field(0)
    total_size_scanned: int = Field(0)
    
    # Baseline
    baseline_id: Optional[str] = Field(None)
    baseline_files: int = Field(0)
    
    # Results
    total_changes: int = Field(0)
    total_findings: int = Field(0)
    
    # Tool info
    tool_version: str = Field("2.0.0")


class FIMScanOutput(BaseModel):
    """Complete output from FIM scan."""
    # Metadata
    metadata: ScanMetadata = Field(...)
    
    # Summaries
    severity_summary: SeveritySummary = Field(default_factory=SeveritySummary)
    change_type_summary: ChangeTypeSummary = Field(default_factory=ChangeTypeSummary)
    path_summaries: List[PathSummary] = Field(default_factory=list)
    rule_summaries: List[RuleSummary] = Field(default_factory=list)
    compliance_summaries: List[ComplianceSummary] = Field(default_factory=list)
    
    # Changes
    changes: List[FileChange] = Field(default_factory=list)
    critical_changes: List[FileChange] = Field(default_factory=list)
    
    # Findings
    findings: List[FIMFinding] = Field(default_factory=list)
    critical_findings: List[FIMFinding] = Field(default_factory=list)
    
    # Baseline
    baseline_created: Optional[Baseline] = Field(None)
    baseline_used: Optional[str] = Field(None)
    
    # New/Missing files
    new_files: List[str] = Field(default_factory=list)
    missing_files: List[str] = Field(default_factory=list)
    modified_files: List[str] = Field(default_factory=list)
    
    # Recommendations
    recommendations: List[str] = Field(default_factory=list)
    immediate_actions: List[str] = Field(default_factory=list)
    
    # Errors
    errors: Optional[List[str]] = Field(None)
    warnings: Optional[List[str]] = Field(None)
    skipped_files: Optional[List[str]] = Field(None)
    
    # Exploitation/Investigation commands
    commands: Optional[ExploitationCommands] = Field(
        None, description="Overall commands related to FIM scan"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )
