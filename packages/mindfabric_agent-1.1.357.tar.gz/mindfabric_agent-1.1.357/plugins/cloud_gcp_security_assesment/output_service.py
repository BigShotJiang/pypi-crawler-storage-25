"""
Output service for GCP Security Assessment with reproduction steps.
"""

import copy
from datetime import datetime
from typing import List, Optional, Dict

from .proto import (
    GCPSecurityOutput,
    ScanOptions,
    ScanMetadata,
    SeveritySummary,
    CategorySummary,
    ResourceTypeSummary,
    ProjectSummary,
    SecurityFinding,
    SeverityLevel,
    ExploitationCommands,
    SecuritySubCategory,
)
from plugins.reproduction import ReproStep


# 🔴 GCP EXPLOITATION COMMANDS by finding sub-category
GCP_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    # Storage Issues
    "public_bucket": {
        "commands": [
            "$ gsutil iam get gs://{bucket_name}",
            "$ gsutil ls gs://{bucket_name}/",
            "$ curl https://storage.googleapis.com/{bucket_name}/"
        ],
        "description": "Enumerate public GCS bucket and list contents"
    },
    "bucket_logging_disabled": {
        "commands": [
            "$ gsutil logging get gs://{bucket_name}"
        ],
        "description": "Check bucket logging status"
    },
    
    # IAM Issues
    "primitive_role_binding": {
        "commands": [
            "$ gcloud projects get-iam-policy {project_id} --format=json | jq '.bindings[] | select(.role | contains(\"roles/owner\") or contains(\"roles/editor\"))'",
            "$ gcloud iam service-accounts list --project={project_id}"
        ],
        "description": "Enumerate primitive IAM role bindings"
    },
    "service_account_key_old": {
        "commands": [
            "$ gcloud iam service-accounts keys list --iam-account={service_account_email}",
            "$ gcloud iam service-accounts describe {service_account_email}"
        ],
        "description": "Check service account key age"
    },
    "public_iam_binding": {
        "commands": [
            "$ gcloud projects get-iam-policy {project_id} --format=json | jq '.bindings[] | select(.members[] | contains(\"allUsers\") or contains(\"allAuthenticatedUsers\"))'",
        ],
        "description": "Find public IAM bindings"
    },
    
    # Compute Issues
    "firewall_rule_open": {
        "commands": [
            "$ gcloud compute firewall-rules describe {firewall_rule} --project={project_id}",
            "$ nmap -sV -p {port} {external_ip}"
        ],
        "description": "Check open firewall rules and scan exposed ports"
    },
    "instance_external_ip": {
        "commands": [
            "$ gcloud compute instances describe {instance_name} --zone={zone} --format='value(networkInterfaces[0].accessConfigs[0].natIP)'",
            "$ nmap -sV {external_ip}"
        ],
        "description": "Check instance external IP and scan services"
    },
    "os_login_disabled": {
        "commands": [
            "$ gcloud compute project-info describe --format='value(commonInstanceMetadata.items.filter(key:enable-oslogin).extract(value))'",
            "$ gcloud compute instances describe {instance_name} --zone={zone} --format='value(metadata.items)'"
        ],
        "description": "Verify OS Login status"
    },
    
    # Logging Issues
    "audit_logging_disabled": {
        "commands": [
            "$ gcloud projects get-iam-policy {project_id} --format=json | jq '.auditConfigs'",
            "$ gcloud logging sinks list --project={project_id}"
        ],
        "description": "Check GCP audit logging configuration"
    },
    "vpc_flow_logs_disabled": {
        "commands": [
            "$ gcloud compute networks subnets describe {subnet_name} --region={region} --format='value(enableFlowLogs)'"
        ],
        "description": "Check VPC flow logs status"
    },
    
    # GKE Issues
    "gke_legacy_auth": {
        "commands": [
            "$ gcloud container clusters describe {cluster_name} --zone={zone} --format='value(masterAuth)'",
            "$ gcloud container clusters describe {cluster_name} --zone={zone} --format='value(legacyAbac)'"
        ],
        "description": "Check GKE legacy authentication settings"
    },
    "gke_public_endpoint": {
        "commands": [
            "$ gcloud container clusters describe {cluster_name} --zone={zone} --format='value(endpoint)'",
            "$ kubectl cluster-info"
        ],
        "description": "Check GKE public endpoint exposure"
    },
    
    # Cloud Functions
    "function_public": {
        "commands": [
            "$ gcloud functions describe {function_name} --region={region} --format='value(httpsTrigger.url)'",
            "$ curl {function_url}"
        ],
        "description": "Check public Cloud Function access"
    },
    
    # Default
    "default": {
        "commands": [
            "$ gcloud projects describe {project_id} --format='yaml(projectId,name,lifecycleState)'",
            "$ gcloud services list --enabled --project={project_id} --format='table(name)' --limit=30",
            "$ gcloud compute instances list --project={project_id} --format='table(name,zone,status)' --limit=20 2>/dev/null || true"
        ],
        "description": "Project context: describe project, enabled APIs, and compute instances (if API enabled)"
    }
}

_GCP_SUBCAT_TEMPLATE_SOURCE: Dict[str, str] = {
    "open_firewall": "firewall_rule_open",
    "public_vm": "instance_external_ip",
    "audit_logs_disabled": "audit_logging_disabled",
    "missing_vpc_flow_logs": "vpc_flow_logs_disabled",
    "legacy_abac": "gke_legacy_auth",
    "public_endpoint": "gke_public_endpoint",
    "public_function": "function_public",
    "overly_permissive_iam": "primitive_role_binding",
    "public_access": "public_iam_binding",
    "service_account_abuse": "service_account_key_old",
    "key_management": "service_account_key_old",
    "privilege_escalation_path": "primitive_role_binding",
    "cross_project_access": "primitive_role_binding",
    "external_identity": "public_iam_binding",
    "metadata_exposure": "instance_external_ip",
    "startup_script_secrets": "function_public",
    "default_service_account": "service_account_key_old",
    "unencrypted_disk": "instance_external_ip",
    "shielded_vm_disabled": "instance_external_ip",
    "weak_ssl_policy": "firewall_rule_open",
    "no_private_access": "firewall_rule_open",
    "vpc_sc_missing": "firewall_rule_open",
    "no_versioning": "bucket_logging_disabled",
    "public_database": "instance_external_ip",
    "ssl_not_enforced": "public_bucket",
    "weak_authentication": "public_iam_binding",
    "no_backup": "instance_external_ip",
    "basic_auth": "gke_legacy_auth",
    "privileged_pod": "gke_public_endpoint",
    "workload_identity_disabled": "gke_legacy_auth",
    "function_secrets_exposed": "function_public",
    "no_vpc_connector": "function_public",
    "data_access_logs_disabled": "audit_logging_disabled",
    "short_retention": "audit_logging_disabled",
    "no_alerting": "audit_logging_disabled",
    "hardcoded_credentials": "service_account_key_old",
    "unrotated_keys": "service_account_key_old",
    "api_key_unrestricted": "public_iam_binding",
    "build_secrets_exposed": "function_public",
    "untrusted_image": "default",
    "no_vulnerability_scan": "default",
    "scheduled_persistence": "function_public",
    "function_persistence": "function_public",
    "build_trigger_persistence": "primitive_role_binding",
    "data_transfer_risk": "public_bucket",
    "cross_project_export": "primitive_role_binding",
}


def _expand_gcp_exploitation_commands() -> None:
    for member in SecuritySubCategory:
        key = member.value
        if key in GCP_EXPLOITATION_COMMANDS:
            continue
        src = _GCP_SUBCAT_TEMPLATE_SOURCE.get(key, "default")
        if src not in GCP_EXPLOITATION_COMMANDS:
            src = "default"
        GCP_EXPLOITATION_COMMANDS[key] = copy.deepcopy(GCP_EXPLOITATION_COMMANDS[src])


_expand_gcp_exploitation_commands()


class OutputService:
    """Build GCPSecurityOutput and reproduction steps."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _build_commands_for_finding(self, f: SecurityFinding) -> Optional[ExploitationCommands]:
        """Generate exploitation commands based on finding type."""
        sub_cat = f.sub_category.value if hasattr(f.sub_category, 'value') else str(f.sub_category)
        cmd_template = GCP_EXPLOITATION_COMMANDS.get(sub_cat, GCP_EXPLOITATION_COMMANDS["default"])
        
        # Get resource info
        resource_name = getattr(f.resource, "name", "") or ""
        project_id = getattr(f.resource, "project_id", "") or ""
        location = getattr(f.resource, "location", "us-central1") or "us-central1"
        full_resource_name = getattr(f.resource, "full_resource_name", "") or ""
        
        # Extract specific identifiers from evidence
        bucket_name = ""
        service_account_email = ""
        instance_name = ""
        cluster_name = ""
        function_name = ""
        firewall_rule = ""
        subnet_name = ""
        external_ip = ""
        zone = ""
        region = ""
        port = "22"
        
        if f.evidence:
            bucket_name = f.evidence.get("bucket_name", "")
            service_account_email = f.evidence.get("service_account_email", "")
            instance_name = f.evidence.get("instance_name", "")
            cluster_name = f.evidence.get("cluster_name", "")
            function_name = f.evidence.get("function_name", "")
            firewall_rule = f.evidence.get("firewall_rule", "")
            subnet_name = f.evidence.get("subnet_name", "")
            external_ip = f.evidence.get("external_ip", "x.x.x.x")
            zone = f.evidence.get("zone", "us-central1-a")
            region = f.evidence.get("region", "us-central1")
            port = str(f.evidence.get("port", 22))
        
        # Build commands with replacements
        commands = []
        for cmd in cmd_template.get("commands", []):
            cmd_replaced = cmd.replace("{bucket_name}", bucket_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{project_id}", project_id)
            cmd_replaced = cmd_replaced.replace("{service_account_email}", service_account_email)
            cmd_replaced = cmd_replaced.replace("{instance_name}", instance_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{cluster_name}", cluster_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{function_name}", function_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{firewall_rule}", firewall_rule or resource_name)
            cmd_replaced = cmd_replaced.replace("{subnet_name}", subnet_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{external_ip}", external_ip)
            cmd_replaced = cmd_replaced.replace("{zone}", zone)
            cmd_replaced = cmd_replaced.replace("{region}", region)
            cmd_replaced = cmd_replaced.replace("{port}", port)
            cmd_replaced = cmd_replaced.replace("{resource_name}", resource_name)
            cmd_replaced = cmd_replaced.replace("{service}", "compute")  # Default
            cmd_replaced = cmd_replaced.replace("{function_url}", f.evidence.get("function_url", "") if f.evidence else "")
            commands.append(cmd_replaced)
        
        return ExploitationCommands(
            server=resource_name or full_resource_name,
            ip=f"GCP:{location}",
            commands=commands,
            description=cmd_template.get("description", f"Verify/exploit {f.name}")
        )

    def _build_steps_for_finding(self, f: SecurityFinding) -> List[ReproStep]:
        target = getattr(f.resource, "resource_id", None) or getattr(f.resource, "name", None)
        action = f"Verify misconfig/vuln on {target}" if target else f"Verify finding {f.id}"
        evidence = f.evidence or f.resource_config
        preconditions = ["GCP credentials with read access"]
        return [
            ReproStep(
                title=f.name,
                preconditions=preconditions,
                target=target or f.name,
                action=action,
                payload=None,
                expected_outcome=f.description,
                evidence=str(evidence) if evidence else None,
                tooling=["gcloud", "console"],
                safety="Read-only verification; if changing resources, do so in lab",
                cleanup="No cleanup for read-only; revert if any change was made",
            )
        ]

    def _attach_reproduction_steps(self) -> List[ReproStep]:
        collected: List[ReproStep] = []
        for f in getattr(self.plugin, "findings", []) or []:
            # 🔴 Attach commands if not present
            if not getattr(f, "commands", None):
                f.commands = self._build_commands_for_finding(f)
            
            if getattr(f, "reproduction_steps", None):
                collected.extend(f.reproduction_steps)
                continue
            f.reproduction_steps = self._build_steps_for_finding(f)
            collected.extend(f.reproduction_steps)
        return collected

    def create_output(
        self,
        options: ScanOptions,
        recommendations: List[str],
        quick_wins: List[str],
    ) -> GCPSecurityOutput:
        completed = datetime.utcnow()
        duration = (completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0

        severity_summary = SeveritySummary(
            critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
            high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            medium=len([f for f in self.plugin.findings if f.severity == SeverityLevel.MEDIUM]),
            low=len([f for f in self.plugin.findings if f.severity == SeverityLevel.LOW]),
            info=len([f for f in self.plugin.findings if f.severity == SeverityLevel.INFO]),
            total=len(self.plugin.findings),
        )

        category_summaries = []
        for cat in getattr(self.plugin, "categories", []) or []:
            cat_findings = [f for f in self.plugin.findings if f.category == cat]
            if cat_findings:
                category_summaries.append(
                    CategorySummary(
                        category=cat,
                        findings_count=len(cat_findings),
                        critical=len([f for f in cat_findings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in cat_findings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        resource_summaries = []
        for rtype in getattr(self.plugin, "resource_types", []) or []:
            rfindings = [f for f in self.plugin.findings if f.resource and f.resource.resource_type == rtype]
            if rfindings:
                resource_summaries.append(
                    ResourceTypeSummary(
                        resource_type=rtype,
                        findings_count=len(rfindings),
                        critical=len([f for f in rfindings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in rfindings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        project_summaries = [
            ProjectSummary(
                project_id=getattr(self.plugin, "project_id", "unknown"),
                findings_count=len(self.plugin.findings),
                critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
                high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            )
        ]

        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            started_at=self.plugin.scan_start or completed,
            completed_at=completed,
            duration_seconds=duration,
            total_findings=len(self.plugin.findings),
        )

        repro_steps = self._attach_reproduction_steps()

        return GCPSecurityOutput(
            metadata=metadata,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            resource_type_summaries=resource_summaries,
            project_summaries=project_summaries,
            findings=self.plugin.findings,
            critical_findings=[f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL],
            recommendations=recommendations,
            quick_wins=quick_wins,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            reproduction_steps=repro_steps or None,
        )
