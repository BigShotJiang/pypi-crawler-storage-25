"""
GCP Security Assessment Plugin - Pydantic Models

This module defines all data structures used by the GCP Security Assessment Plugin
for detecting and reporting security misconfigurations in Google Cloud Platform.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional, Set
from pydantic import BaseModel, Field
from plugins.reproduction import ReproStep


# =============================================================================
# Enumerations
# =============================================================================

class SeverityLevel(str, Enum):
    """Severity classification for security findings."""
    CRITICAL = "critical"  # Public data exposure, privilege escalation, active threats
    HIGH = "high"          # Missing encryption, broad access, disabled logging
    MEDIUM = "medium"      # Missing best practices, potential risks
    LOW = "low"            # Informational, optimization opportunities
    INFO = "info"          # Non-security findings, baseline information


class GCPResourceType(str, Enum):
    """GCP resource types covered by assessment."""
    # Organization & Projects
    ORGANIZATION = "organization"
    FOLDER = "folder"
    PROJECT = "project"
    BILLING_ACCOUNT = "billing_account"
    
    # IAM
    IAM_POLICY = "iam_policy"
    IAM_ROLE = "iam_role"
    IAM_CUSTOM_ROLE = "iam_custom_role"
    SERVICE_ACCOUNT = "service_account"
    SERVICE_ACCOUNT_KEY = "service_account_key"
    WORKLOAD_IDENTITY_POOL = "workload_identity_pool"
    
    # Compute
    COMPUTE_INSTANCE = "compute_instance"
    COMPUTE_DISK = "compute_disk"
    COMPUTE_IMAGE = "compute_image"
    COMPUTE_SNAPSHOT = "compute_snapshot"
    INSTANCE_TEMPLATE = "instance_template"
    INSTANCE_GROUP = "instance_group"
    
    # Networking
    VPC_NETWORK = "vpc_network"
    SUBNETWORK = "subnetwork"
    FIREWALL_RULE = "firewall_rule"
    FIREWALL_POLICY = "firewall_policy"
    LOAD_BALANCER = "load_balancer"
    VPN_GATEWAY = "vpn_gateway"
    CLOUD_NAT = "cloud_nat"
    CLOUD_ROUTER = "cloud_router"
    VPC_SERVICE_CONTROLS = "vpc_service_controls"
    
    # Storage
    STORAGE_BUCKET = "storage_bucket"
    STORAGE_OBJECT = "storage_object"
    
    # Databases
    CLOUD_SQL_INSTANCE = "cloud_sql_instance"
    CLOUD_SPANNER_INSTANCE = "cloud_spanner_instance"
    FIRESTORE_DATABASE = "firestore_database"
    BIGTABLE_INSTANCE = "bigtable_instance"
    MEMORYSTORE_INSTANCE = "memorystore_instance"
    
    # BigQuery
    BIGQUERY_DATASET = "bigquery_dataset"
    BIGQUERY_TABLE = "bigquery_table"
    
    # Kubernetes
    GKE_CLUSTER = "gke_cluster"
    GKE_NODE_POOL = "gke_node_pool"
    K8S_NAMESPACE = "k8s_namespace"
    K8S_POD = "k8s_pod"
    K8S_SERVICE_ACCOUNT = "k8s_service_account"
    K8S_RBAC_ROLE = "k8s_rbac_role"
    K8S_RBAC_BINDING = "k8s_rbac_binding"
    
    # Serverless
    CLOUD_FUNCTION = "cloud_function"
    CLOUD_RUN_SERVICE = "cloud_run_service"
    APP_ENGINE_SERVICE = "app_engine_service"
    
    # CI/CD
    CLOUD_BUILD_TRIGGER = "cloud_build_trigger"
    ARTIFACT_REGISTRY = "artifact_registry"
    CONTAINER_IMAGE = "container_image"
    
    # Messaging
    PUBSUB_TOPIC = "pubsub_topic"
    PUBSUB_SUBSCRIPTION = "pubsub_subscription"
    CLOUD_SCHEDULER_JOB = "cloud_scheduler_job"
    CLOUD_TASKS_QUEUE = "cloud_tasks_queue"
    
    # Security & Secrets
    KMS_KEY_RING = "kms_key_ring"
    KMS_CRYPTO_KEY = "kms_crypto_key"
    SECRET_MANAGER_SECRET = "secret_manager_secret"
    API_KEY = "api_key"
    
    # Logging & Monitoring
    LOG_SINK = "log_sink"
    LOG_METRIC = "log_metric"
    ALERTING_POLICY = "alerting_policy"
    
    # Other
    ORGANIZATION_POLICY = "organization_policy"
    ESSENTIAL_CONTACTS = "essential_contacts"
    UNKNOWN = "unknown"


class SecurityCategory(str, Enum):
    """
    Security assessment categories aligned with MITRE ATT&CK Cloud Matrix.
    """
    # MITRE ATT&CK Tactics
    INITIAL_ACCESS = "initial_access"           # T1190, T1199
    EXECUTION = "execution"                     # T1059, T1648
    PERSISTENCE = "persistence"                 # T1098, T1525
    PRIVILEGE_ESCALATION = "privilege_escalation"  # T1078, T1548
    DEFENSE_EVASION = "defense_evasion"         # T1562, T1578
    CREDENTIAL_ACCESS = "credential_access"     # T1528, T1552
    DISCOVERY = "discovery"                     # T1580, T1526
    LATERAL_MOVEMENT = "lateral_movement"       # T1550, T1563
    COLLECTION = "collection"                   # T1530, T1119
    EXFILTRATION = "exfiltration"               # T1537, T1567
    IMPACT = "impact"                           # T1485, T1486
    
    # GCP-Specific Categories
    IAM_MISCONFIGURATION = "iam_misconfiguration"
    NETWORK_EXPOSURE = "network_exposure"
    DATA_EXPOSURE = "data_exposure"
    ENCRYPTION_WEAKNESS = "encryption_weakness"
    LOGGING_GAP = "logging_gap"
    COMPLIANCE_VIOLATION = "compliance_violation"
    CONFIGURATION_DRIFT = "configuration_drift"
    RESOURCE_EXPOSURE = "resource_exposure"


class SecuritySubCategory(str, Enum):
    """Specific security issue sub-categories."""
    # IAM Issues
    OVERLY_PERMISSIVE_IAM = "overly_permissive_iam"
    PUBLIC_ACCESS = "public_access"
    SERVICE_ACCOUNT_ABUSE = "service_account_abuse"
    KEY_MANAGEMENT = "key_management"
    PRIVILEGE_ESCALATION_PATH = "privilege_escalation_path"
    CROSS_PROJECT_ACCESS = "cross_project_access"
    EXTERNAL_IDENTITY = "external_identity"
    
    # Compute Issues
    PUBLIC_VM = "public_vm"
    METADATA_EXPOSURE = "metadata_exposure"
    STARTUP_SCRIPT_SECRETS = "startup_script_secrets"
    DEFAULT_SERVICE_ACCOUNT = "default_service_account"
    UNENCRYPTED_DISK = "unencrypted_disk"
    OS_LOGIN_DISABLED = "os_login_disabled"
    SHIELDED_VM_DISABLED = "shielded_vm_disabled"
    
    # Network Issues
    OPEN_FIREWALL = "open_firewall"
    MISSING_VPC_FLOW_LOGS = "missing_vpc_flow_logs"
    WEAK_SSL_POLICY = "weak_ssl_policy"
    NO_PRIVATE_ACCESS = "no_private_access"
    VPC_SC_MISSING = "vpc_sc_missing"
    
    # Storage Issues
    PUBLIC_BUCKET = "public_bucket"
    BUCKET_LOGGING_DISABLED = "bucket_logging_disabled"
    NO_VERSIONING = "no_versioning"
    
    # Database Issues
    PUBLIC_DATABASE = "public_database"
    SSL_NOT_ENFORCED = "ssl_not_enforced"
    WEAK_AUTHENTICATION = "weak_authentication"
    NO_BACKUP = "no_backup"
    
    # GKE Issues
    LEGACY_ABAC = "legacy_abac"
    BASIC_AUTH = "basic_auth"
    PUBLIC_ENDPOINT = "public_endpoint"
    PRIVILEGED_POD = "privileged_pod"
    WORKLOAD_IDENTITY_DISABLED = "workload_identity_disabled"
    
    # Serverless Issues
    PUBLIC_FUNCTION = "public_function"
    FUNCTION_SECRETS_EXPOSED = "function_secrets_exposed"
    NO_VPC_CONNECTOR = "no_vpc_connector"
    
    # Logging Issues
    AUDIT_LOGS_DISABLED = "audit_logs_disabled"
    DATA_ACCESS_LOGS_DISABLED = "data_access_logs_disabled"
    SHORT_RETENTION = "short_retention"
    NO_ALERTING = "no_alerting"
    
    # Secrets Issues
    HARDCODED_CREDENTIALS = "hardcoded_credentials"
    UNROTATED_KEYS = "unrotated_keys"
    API_KEY_UNRESTRICTED = "api_key_unrestricted"
    
    # CI/CD Issues
    BUILD_SECRETS_EXPOSED = "build_secrets_exposed"
    UNTRUSTED_IMAGE = "untrusted_image"
    NO_VULNERABILITY_SCAN = "no_vulnerability_scan"
    
    # Persistence
    SCHEDULED_PERSISTENCE = "scheduled_persistence"
    FUNCTION_PERSISTENCE = "function_persistence"
    BUILD_TRIGGER_PERSISTENCE = "build_trigger_persistence"
    
    # Exfiltration
    DATA_TRANSFER_RISK = "data_transfer_risk"
    CROSS_PROJECT_EXPORT = "cross_project_export"


class FindingStatus(str, Enum):
    """Status of security finding."""
    ACTIVE = "active"             # Issue exists and is exploitable
    SUPPRESSED = "suppressed"     # Acknowledged but not fixed
    REMEDIATED = "remediated"     # Issue has been fixed
    FALSE_POSITIVE = "false_positive"  # Not a real issue
    EXCEPTION = "exception"       # Accepted risk with justification


class ComplianceFramework(str, Enum):
    """Compliance frameworks for mapping findings."""
    CIS_GCP = "cis_gcp"
    NIST_800_53 = "nist_800_53"
    NIST_CSF = "nist_csf"
    SOC2 = "soc2"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    GDPR = "gdpr"
    ISO_27001 = "iso_27001"
    FedRAMP = "fedramp"


# =============================================================================
# Supporting Models
# =============================================================================

class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute.
    """
    server: Optional[str] = Field(None, description="Target server/hostname/resource")
    ip: Optional[str] = Field(None, description="Target IP address or GCP endpoint")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class MitreAttackReference(BaseModel):
    """MITRE ATT&CK Cloud Matrix reference."""
    tactic: str = Field(..., description="ATT&CK tactic (e.g., 'Persistence')")
    technique_id: str = Field(..., description="Technique ID (e.g., 'T1078')")
    technique_name: str = Field(..., description="Technique name")
    sub_technique_id: Optional[str] = Field(None, description="Sub-technique ID")
    sub_technique_name: Optional[str] = Field(None, description="Sub-technique name")
    url: Optional[str] = Field(None, description="Link to ATT&CK page")


class ComplianceMapping(BaseModel):
    """Compliance framework mapping for a finding."""
    framework: ComplianceFramework = Field(..., description="Compliance framework")
    control_id: str = Field(..., description="Control ID (e.g., 'CIS 1.1')")
    control_name: str = Field(..., description="Control name/description")
    requirement: Optional[str] = Field(None, description="Specific requirement")


class GCPResourceIdentifier(BaseModel):
    """Unique identifier for a GCP resource."""
    resource_type: GCPResourceType = Field(..., description="Resource type")
    project_id: Optional[str] = Field(None, description="GCP project ID")
    name: str = Field(..., description="Resource name")
    location: Optional[str] = Field(None, description="Resource location/region/zone")
    full_resource_name: Optional[str] = Field(None, description="Full GCP resource name")
    self_link: Optional[str] = Field(None, description="Resource self link URL")
    
    # Parent resources
    organization_id: Optional[str] = Field(None, description="Organization ID")
    folder_id: Optional[str] = Field(None, description="Folder ID")
    
    # Additional identifiers
    labels: Optional[Dict[str, str]] = Field(None, description="Resource labels")
    creation_time: Optional[datetime] = Field(None, description="Resource creation time")


class IAMBinding(BaseModel):
    """IAM policy binding details."""
    role: str = Field(..., description="IAM role (e.g., 'roles/owner')")
    members: List[str] = Field(default_factory=list, description="Bound members")
    condition: Optional[Dict[str, Any]] = Field(None, description="IAM condition")
    
    # Analysis
    is_primitive_role: bool = Field(False, description="Whether this is a primitive role")
    has_public_access: bool = Field(False, description="Whether allUsers/allAuthenticatedUsers")
    external_members: Optional[List[str]] = Field(None, description="External domain members")
    service_accounts: Optional[List[str]] = Field(None, description="Service account members")


class ServiceAccountInfo(BaseModel):
    """Service account details for analysis."""
    email: str = Field(..., description="Service account email")
    project_id: str = Field(..., description="Project containing the SA")
    display_name: Optional[str] = Field(None, description="Display name")
    description: Optional[str] = Field(None, description="Description")
    disabled: bool = Field(False, description="Whether SA is disabled")
    
    # Key information
    key_count: int = Field(0, description="Number of active keys")
    user_managed_keys: int = Field(0, description="User-managed keys count")
    oldest_key_age_days: Optional[int] = Field(None, description="Age of oldest key in days")
    
    # IAM analysis
    iam_roles: Optional[List[str]] = Field(None, description="Roles granted to this SA")
    impersonators: Optional[List[str]] = Field(None, description="Who can impersonate this SA")
    has_domain_wide_delegation: bool = Field(False, description="G Workspace delegation enabled")
    
    # Activity
    last_authenticated: Optional[datetime] = Field(None, description="Last authentication time")
    last_key_used: Optional[datetime] = Field(None, description="Last key usage time")
    is_default_compute_sa: bool = Field(False, description="Is default compute service account")


class NetworkConfiguration(BaseModel):
    """Network configuration details."""
    network_name: str = Field(..., description="VPC network name")
    subnetwork: Optional[str] = Field(None, description="Subnetwork")
    has_external_ip: bool = Field(False, description="Has external IP")
    external_ip: Optional[str] = Field(None, description="External IP address")
    internal_ip: Optional[str] = Field(None, description="Internal IP address")
    
    # Firewall
    open_ports: Optional[List[int]] = Field(None, description="Open ports from 0.0.0.0/0")
    firewall_rules_applied: Optional[List[str]] = Field(None, description="Applied firewall rules")
    
    # Features
    flow_logs_enabled: bool = Field(False, description="VPC flow logs enabled")
    private_google_access: bool = Field(False, description="Private Google Access enabled")


class EncryptionInfo(BaseModel):
    """Encryption configuration details."""
    encryption_type: str = Field(..., description="none, google-managed, customer-managed")
    kms_key_name: Optional[str] = Field(None, description="KMS key if customer-managed")
    key_version: Optional[str] = Field(None, description="Key version")
    is_hsm_backed: bool = Field(False, description="Whether key is HSM-backed")
    rotation_period_days: Optional[int] = Field(None, description="Key rotation period")
    last_rotated: Optional[datetime] = Field(None, description="Last rotation time")


class PrivilegeEscalationPath(BaseModel):
    """Detected privilege escalation path."""
    source_identity: str = Field(..., description="Starting identity")
    target_identity: str = Field(..., description="Target identity to escalate to")
    escalation_method: str = Field(..., description="Method of escalation")
    required_permissions: List[str] = Field(default_factory=list, description="Permissions needed")
    steps: List[str] = Field(default_factory=list, description="Step-by-step path")
    impact: str = Field(..., description="Impact if exploited")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence score")


class ExfiltrationPath(BaseModel):
    """Detected data exfiltration path."""
    source_resource: str = Field(..., description="Source resource with data")
    destination: str = Field(..., description="Potential destination")
    method: str = Field(..., description="Exfiltration method")
    data_type: Optional[str] = Field(None, description="Type of data at risk")
    permissions_required: List[str] = Field(default_factory=list, description="Permissions needed")
    mitigations: Optional[List[str]] = Field(None, description="Recommended mitigations")


class PersistenceMechanism(BaseModel):
    """Detected or potential persistence mechanism."""
    mechanism_type: str = Field(..., description="Type of persistence")
    resource: str = Field(..., description="Resource used for persistence")
    execution_trigger: str = Field(..., description="What triggers execution")
    execution_identity: Optional[str] = Field(None, description="Identity used for execution")
    detected_payload: Optional[str] = Field(None, description="Suspicious payload if found")
    is_suspicious: bool = Field(False, description="Whether appears malicious")
    legitimate_use_case: Optional[str] = Field(None, description="Potential legitimate use")


class IoC(BaseModel):
    """Indicator of Compromise extracted from finding."""
    ioc_type: str = Field(..., description="Type: ip, domain, url, email, hash, key_id")
    value: str = Field(..., description="IoC value")
    context: Optional[str] = Field(None, description="Context where found")
    first_seen: Optional[datetime] = Field(None, description="First observed")
    last_seen: Optional[datetime] = Field(None, description="Last observed")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence 0-1")


# =============================================================================
# Core Finding Models
# =============================================================================

class SecurityFinding(BaseModel):
    """
    Detailed information about a detected security issue.
    This is the primary finding object returned by security checks.
    """
    # Identification
    id: str = Field(..., description="Unique finding ID (UUID)")
    name: str = Field(..., description="Human-readable name")
    description: str = Field(..., description="Detailed description")
    
    # Classification
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific sub-category")
    severity: SeverityLevel = Field(..., description="Severity level")
    status: FindingStatus = Field(FindingStatus.ACTIVE, description="Finding status")
    
    # Resource
    resource: GCPResourceIdentifier = Field(..., description="Affected resource")
    resource_config: Optional[Dict[str, Any]] = Field(None, description="Relevant config excerpt")
    
    # Framework mappings
    mitre_attack: Optional[MitreAttackReference] = Field(None, description="MITRE ATT&CK reference")
    compliance_mappings: Optional[List[ComplianceMapping]] = Field(None, description="Compliance mappings")
    
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Explicit gcloud commands for exploitation/verification"
    )
    
    # Evidence
    evidence: Optional[Dict[str, Any]] = Field(None, description="Evidence supporting finding")
    affected_bindings: Optional[List[IAMBinding]] = Field(None, description="Affected IAM bindings")
    affected_service_accounts: Optional[List[ServiceAccountInfo]] = Field(None, description="Affected SAs")
    network_config: Optional[NetworkConfiguration] = Field(None, description="Network configuration")
    encryption_info: Optional[EncryptionInfo] = Field(None, description="Encryption details")
    
    # Attack paths
    privilege_escalation_paths: Optional[List[PrivilegeEscalationPath]] = Field(None, description="Privesc paths")
    exfiltration_paths: Optional[List[ExfiltrationPath]] = Field(None, description="Exfil paths")
    persistence_mechanisms: Optional[List[PersistenceMechanism]] = Field(None, description="Persistence")
    
    # IoCs
    iocs: Optional[List[IoC]] = Field(None, description="Extracted IoCs")
    
    # Analysis
    risk_score: float = Field(0.0, ge=0.0, le=10.0, description="Risk score 0-10")
    exploitability: Optional[str] = Field(None, description="Exploitability: easy/medium/hard")
    impact_scope: Optional[str] = Field(None, description="Scope: resource/project/org")
    false_positive_likelihood: Optional[str] = Field(None, description="FP likelihood: low/medium/high")
    
    # Remediation
    recommendation: str = Field(..., description="What should be done")
    remediation_steps: Optional[List[str]] = Field(None, description="Step-by-step remediation")
    remediation_commands: Optional[List[str]] = Field(None, description="gcloud/terraform commands")
    remediation_effort: Optional[str] = Field(None, description="Effort: low/medium/high")
    requires_downtime: bool = Field(False, description="Whether fix requires downtime")
    
    # Metadata
    detected_at: datetime = Field(default_factory=datetime.utcnow, description="Detection time")
    detection_method: Optional[str] = Field(None, description="How this was detected")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Detection confidence 0-1")
    
    # Suppression
    is_suppressed: bool = Field(False, description="Whether suppressed")
    suppression_reason: Optional[str] = Field(None, description="Reason for suppression")
    exception_until: Optional[datetime] = Field(None, description="Exception expiry date")
    
    # Additional context
    tags: Optional[List[str]] = Field(None, description="Finding tags")
    related_findings: Optional[List[str]] = Field(None, description="Related finding IDs")
    references: Optional[List[str]] = Field(None, description="External references")
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this finding"
    )
    raw_data: Optional[Dict[str, Any]] = Field(None, description="Raw API response data")


class CheckResult(BaseModel):
    """Result of a security check."""
    check_id: str = Field(..., description="Check identifier")
    check_name: str = Field(..., description="Human-readable check name")
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific type")
    
    # Status
    passed: bool = Field(..., description="Whether check passed (no issues)")
    findings_count: int = Field(0, description="Number of findings")
    
    # Results
    findings: List[SecurityFinding] = Field(default_factory=list, description="Findings from this check")
    
    # Scope
    resources_checked: int = Field(0, description="Number of resources checked")
    resources_with_issues: int = Field(0, description="Resources with issues")
    
    # Performance
    duration_ms: Optional[float] = Field(None, description="Check duration in ms")
    
    # Errors
    error: Optional[str] = Field(None, description="Error message if check failed")
    error_details: Optional[str] = Field(None, description="Detailed error info")
    skipped: bool = Field(False, description="Whether check was skipped")
    skipped_reason: Optional[str] = Field(None, description="Skip reason")


# =============================================================================
# Scan Configuration
# =============================================================================

class ScanScope(BaseModel):
    """Scope of the security assessment."""
    # Organization scope
    organization_id: Optional[str] = Field(None, description="Organization ID to scan")
    
    # Folder scope
    folder_ids: Optional[List[str]] = Field(None, description="Folder IDs to scan")
    
    # Project scope
    project_ids: Optional[List[str]] = Field(None, description="Project IDs to scan")
    exclude_project_ids: Optional[List[str]] = Field(None, description="Projects to exclude")
    
    # Resource scope
    resource_types: Optional[List[GCPResourceType]] = Field(None, description="Resource types to scan")
    exclude_resource_types: Optional[List[GCPResourceType]] = Field(None, description="Types to exclude")
    
    # Location scope
    regions: Optional[List[str]] = Field(None, description="Regions to scan (None = all)")
    zones: Optional[List[str]] = Field(None, description="Zones to scan (None = all)")


class ScanOptions(BaseModel):
    """Configuration options for security scan."""
    # Scope
    scope: ScanScope = Field(default_factory=ScanScope, description="Scan scope")
    
    # Category selection
    categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to scan")
    exclude_categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to exclude")
    
    # Severity filtering
    min_severity: SeverityLevel = Field(SeverityLevel.INFO, description="Minimum severity")
    
    # Scan depth
    deep_scan: bool = Field(False, description="Enable deep/thorough scanning")
    quick_scan: bool = Field(False, description="Quick scan (critical only)")
    
    # Analysis features
    analyze_iam_policies: bool = Field(True, description="Analyze IAM policies")
    analyze_privilege_escalation: bool = Field(True, description="Find privesc paths")
    analyze_exfiltration_paths: bool = Field(True, description="Find exfil paths")
    analyze_persistence: bool = Field(True, description="Find persistence mechanisms")
    analyze_compliance: bool = Field(True, description="Map to compliance frameworks")
    
    # Compliance frameworks
    compliance_frameworks: Optional[List[ComplianceFramework]] = Field(
        None, description="Frameworks to map findings to"
    )
    
    # Performance
    max_workers: int = Field(10, description="Maximum parallel workers")
    timeout_per_check: int = Field(60, description="Timeout per check in seconds")
    max_findings: int = Field(5000, description="Maximum findings to return")
    
    # Output options
    include_raw_data: bool = Field(False, description="Include raw API responses")
    include_passing_checks: bool = Field(False, description="Include checks with no findings")
    
    # Baseline comparison
    baseline_path: Optional[str] = Field(None, description="Path to baseline for comparison")
    suppress_baseline_findings: bool = Field(False, description="Suppress known findings")


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary counts by severity level."""
    critical: int = Field(0, description="Critical severity count")
    high: int = Field(0, description="High severity count")
    medium: int = Field(0, description="Medium severity count")
    low: int = Field(0, description="Low severity count")
    info: int = Field(0, description="Info count")
    total: int = Field(0, description="Total findings")


class CategorySummary(BaseModel):
    """Summary counts by category."""
    category: SecurityCategory = Field(..., description="Category")
    category_name: str = Field(..., description="Category display name")
    total_count: int = Field(0, description="Total findings in category")
    critical_count: int = Field(0, description="Critical findings")
    high_count: int = Field(0, description="High findings")
    top_issues: Optional[List[str]] = Field(None, description="Top issue types")


class ResourceTypeSummary(BaseModel):
    """Summary by resource type."""
    resource_type: GCPResourceType = Field(..., description="Resource type")
    total_resources: int = Field(0, description="Total resources scanned")
    resources_with_issues: int = Field(0, description="Resources with findings")
    total_findings: int = Field(0, description="Total findings")
    critical_findings: int = Field(0, description="Critical findings")


class ProjectSummary(BaseModel):
    """Summary per project."""
    project_id: str = Field(..., description="Project ID")
    project_name: Optional[str] = Field(None, description="Project name")
    total_findings: int = Field(0, description="Total findings")
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Severity breakdown"
    )
    top_categories: Optional[List[str]] = Field(None, description="Top issue categories")
    risk_score: float = Field(0.0, description="Overall project risk score")


class ScanMetadata(BaseModel):
    """Metadata about the scan execution."""
    scan_id: str = Field(..., description="Unique scan ID")
    scan_type: str = Field("full", description="Scan type: full/quick/targeted")
    started_at: datetime = Field(default_factory=datetime.utcnow, description="Start time")
    completed_at: Optional[datetime] = Field(None, description="Completion time")
    duration_seconds: Optional[float] = Field(None, description="Total duration")
    
    # Authentication
    authenticated_identity: Optional[str] = Field(None, description="Identity used for scan")
    permissions_available: Optional[List[str]] = Field(None, description="Permissions available")
    
    # Coverage
    organizations_scanned: int = Field(0, description="Organizations scanned")
    projects_scanned: int = Field(0, description="Projects scanned")
    resources_scanned: int = Field(0, description="Total resources scanned")
    
    # Checks
    total_checks: int = Field(0, description="Total checks performed")
    passed_checks: int = Field(0, description="Checks with no findings")
    failed_checks: int = Field(0, description="Checks with findings")
    skipped_checks: int = Field(0, description="Checks skipped")
    error_checks: int = Field(0, description="Checks with errors")


class GCPSecurityOutput(BaseModel):
    """
    Complete output from GCP security assessment.
    This is the main return type from hook_gcp_security_scan().
    """
    # Metadata
    metadata: ScanMetadata = Field(..., description="Scan metadata")
    
    # Configuration used
    scan_options: Optional[ScanOptions] = Field(None, description="Options used")
    
    # Check results
    check_results: List[CheckResult] = Field(
        default_factory=list, description="Results from each check"
    )
    
    # All findings
    findings: List[SecurityFinding] = Field(
        default_factory=list, description="All security findings"
    )
    
    # Summaries
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Summary by severity"
    )
    category_summaries: List[CategorySummary] = Field(
        default_factory=list, description="Summary by category"
    )
    resource_type_summaries: List[ResourceTypeSummary] = Field(
        default_factory=list, description="Summary by resource type"
    )
    project_summaries: List[ProjectSummary] = Field(
        default_factory=list, description="Summary per project"
    )
    
    # Attack analysis
    privilege_escalation_paths: List[PrivilegeEscalationPath] = Field(
        default_factory=list, description="All detected privesc paths"
    )
    exfiltration_paths: List[ExfiltrationPath] = Field(
        default_factory=list, description="All detected exfil paths"
    )
    persistence_mechanisms: List[PersistenceMechanism] = Field(
        default_factory=list, description="All detected persistence"
    )
    
    # Aggregated IoCs
    all_iocs: Optional[List[IoC]] = Field(None, description="All extracted IoCs")
    
    # Top findings
    critical_findings: Optional[List[SecurityFinding]] = Field(
        None, description="Critical severity findings"
    )
    top_risk_resources: Optional[List[GCPResourceIdentifier]] = Field(
        None, description="Highest risk resources"
    )
    
    # Compliance
    compliance_summary: Optional[Dict[str, Dict[str, int]]] = Field(
        None, description="Compliance status per framework"
    )
    
    # Errors and warnings
    errors: Optional[List[str]] = Field(None, description="Errors encountered")
    warnings: Optional[List[str]] = Field(None, description="Warnings from scan")
    
    # Recommendations
    prioritized_recommendations: Optional[List[str]] = Field(
        None, description="Prioritized action items"
    )
    
    # Baseline comparison
    baseline_comparison: Optional[Dict[str, Any]] = Field(
        None, description="Comparison with baseline"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )


# =============================================================================
# Baseline Models
# =============================================================================

class BaselineFinding(BaseModel):
    """Single finding in baseline."""
    finding_id: str = Field(..., description="Finding ID for matching")
    resource_name: str = Field(..., description="Resource identifier")
    category: SecurityCategory = Field(..., description="Category")
    sub_category: SecuritySubCategory = Field(..., description="Sub-category")
    severity: SeverityLevel = Field(..., description="Severity")
    first_seen: datetime = Field(default_factory=datetime.utcnow, description="First detection")
    status: str = Field("acknowledged", description="Baseline status")
    notes: Optional[str] = Field(None, description="Notes about this finding")
    accepted_by: Optional[str] = Field(None, description="Who accepted the risk")
    accepted_until: Optional[datetime] = Field(None, description="Acceptance expiry")


class Baseline(BaseModel):
    """Security baseline for comparison."""
    baseline_id: str = Field(..., description="Unique baseline ID")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update")
    organization_id: Optional[str] = Field(None, description="Organization ID")
    project_ids: Optional[List[str]] = Field(None, description="Projects in baseline")
    findings: List[BaselineFinding] = Field(default_factory=list, description="Baseline findings")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class BaselineComparison(BaseModel):
    """Result of comparing current state to baseline."""
    new_findings: List[SecurityFinding] = Field(
        default_factory=list, description="Findings not in baseline"
    )
    resolved_findings: List[BaselineFinding] = Field(
        default_factory=list, description="Baseline findings now resolved"
    )
    unchanged_findings: int = Field(0, description="Findings unchanged from baseline")
    severity_changes: Optional[Dict[str, int]] = Field(
        None, description="Changes in severity counts"
    )
    comparison_timestamp: datetime = Field(
        default_factory=datetime.utcnow, description="Comparison time"
    )
