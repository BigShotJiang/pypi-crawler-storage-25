"""
GCP Security Assessment Plugin

Comprehensive security assessment for Google Cloud Platform environments.
Detects IAM misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.
"""

from .gcp_security_assessment import GCPSecurityPlugin, scan_gcp_security
from .proto import (
    SeverityLevel,
    GCPResourceType,
    SecurityCategory,
    SecuritySubCategory,
    FindingStatus,
    ComplianceFramework,
    ScanScope,
    ScanOptions,
    SecurityFinding,
    CheckResult,
    GCPSecurityOutput,
    GCPResourceIdentifier,
    IAMBinding,
    ServiceAccountInfo,
    NetworkConfiguration,
    EncryptionInfo,
    PrivilegeEscalationPath,
    ExfiltrationPath,
    PersistenceMechanism,
    MitreAttackReference,
    ComplianceMapping,
)

__all__ = [
    "GCPSecurityPlugin",
    "scan_gcp_security",
    "SeverityLevel",
    "GCPResourceType",
    "SecurityCategory",
    "SecuritySubCategory",
    "FindingStatus",
    "ComplianceFramework",
    "ScanScope",
    "ScanOptions",
    "SecurityFinding",
    "CheckResult",
    "GCPSecurityOutput",
    "GCPResourceIdentifier",
    "IAMBinding",
    "ServiceAccountInfo",
    "NetworkConfiguration",
    "EncryptionInfo",
    "PrivilegeEscalationPath",
    "ExfiltrationPath",
    "PersistenceMechanism",
    "MitreAttackReference",
    "ComplianceMapping",
]

__version__ = "1.0.0"
