"""
GCP Security Assessment Plugin

Comprehensive security assessment for Google Cloud Platform environments.
Detects IAM misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.

Covers 200+ security vectors across 15 categories mapped to MITRE ATT&CK Cloud Matrix.
"""

import asyncio
import logging
import subprocess
import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .modules.databases import (
    MITRE_MAPPING,
    CIS_GCP_MAPPING,
    GCP_CHECKS,
    DANGEROUS_PERMISSIONS,
    SECRET_PATTERNS,
)
from .modules.utils import (
    run_gcloud_command,
    run_gsutil_command,
    analyze_iam_binding,
    check_content_for_secrets,
    calculate_risk_score,
)
from .modules.databases.ui_templates import get_gcp_guidance
from plugins.base_plugin import BasePlugin

from .modules.services import (
    CheckFilterService,
    ProjectScopeService,
    CheckExecutorService,
    FindingFactoryService,
    AttackPathAnalyzerService,
    ResultProcessorService,
    AdditionalGCPServicesCheckService,
)
from .proto import (
    Baseline,
    BaselineComparison,
    BaselineFinding,
    CategorySummary,
    CheckResult,
    ComplianceFramework,
    ComplianceMapping,
    EncryptionInfo,
    ExfiltrationPath,
    ExploitationCommands,
    FindingStatus,
    GCPResourceIdentifier,
    GCPResourceType,
    GCPResourceType,
    GCPSecurityOutput,
    IAMBinding,
    IoC,
    MitreAttackReference,
    NetworkConfiguration,
    PersistenceMechanism,
    PrivilegeEscalationPath,
    ProjectSummary,
    ResourceTypeSummary,
    ScanMetadata,
    ScanOptions,
    ScanScope,
    SecurityCategory,
    SecurityFinding,
    SecuritySubCategory,
    ServiceAccountInfo,
    SeverityLevel,
    SeveritySummary,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Main Plugin Class
# =============================================================================

class GCPSecurityPlugin(BasePlugin):
    """
    GCP Security Assessment Plugin.
    
    Comprehensive security assessment for Google Cloud Platform environments.
    Detects 200+ security vectors across 15 categories.
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.findings: List[SecurityFinding] = []
        self.check_results: List[CheckResult] = []
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.projects_scanned: Set[str] = set()
        self.resources_scanned: int = 0
        
        # Analysis results
        self.privilege_escalation_paths: List[PrivilegeEscalationPath] = []
        self.exfiltration_paths: List[ExfiltrationPath] = []
        self.persistence_mechanisms: List[PersistenceMechanism] = []
        
        # Cache for API responses
        self._cache: Dict[str, Any] = {}
        
        # MindFabric integration
        self.command_id: Optional[str] = None
        self.ws: Optional[Any] = None
        
        # Initialize services
        self.project_scope_service = ProjectScopeService(self)
        self.check_filter_service = CheckFilterService(self)
        self.check_executor_service = CheckExecutorService(self)
        self.finding_factory_service = FindingFactoryService(self)
        self.attack_path_analyzer_service = AttackPathAnalyzerService(self)
        self.result_processor_service = ResultProcessorService(self)
        self.additional_services_check_service = AdditionalGCPServicesCheckService(self)
    
    async def run(self):
        """Main entry point."""
        from .proto import ScanOptions
        options = ScanOptions()
        return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_gcp_security_scan(options)))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Ensure findings include analyst-friendly `impact` and structured `recommendations`.
        Keep plugin-specific enrichment inside the plugin (not in security_contract).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        findings = out.get("findings") or []
        if isinstance(findings, list):
            for f in findings:
                if not isinstance(f, dict):
                    continue
                cat = f.get("category")
                if hasattr(cat, "value"):
                    cat = cat.value
                sub = f.get("sub_category") or f.get("subCategory")
                if hasattr(sub, "value"):
                    sub = sub.value

                impact, fallback_recs = get_gcp_guidance(
                    category=str(cat) if cat else None,
                    sub_category=str(sub) if sub else None,
                    title=str(f.get("name") or f.get("title") or "") if (f.get("name") or f.get("title")) else None,
                )
                if not f.get("impact") and impact:
                    f["impact"] = impact

                if not f.get("recommendations"):
                    rec_str = f.get("recommendation")
                    if isinstance(rec_str, str) and rec_str.strip():
                        f["recommendations"] = [
                            {"title": "Recommendation", "description": rec_str.strip(), "priority": "medium"}
                        ]
                    elif fallback_recs:
                        f["recommendations"] = fallback_recs

                if not f.get("affected_resources"):
                    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}

                    def _gcp_pick(*keys: str) -> Optional[str]:
                        for k in keys:
                            v = f.get(k) or ev.get(k)
                            if isinstance(v, str) and v.strip():
                                return v.strip()
                        return None

                    pid = _gcp_pick("project_id", "projectId")
                    rid = _gcp_pick("resource_id", "resourceId")
                    rarn = _gcp_pick("resource_arn", "arn", "resourceArn")
                    reg = _gcp_pick("region")
                    rname = _gcp_pick("resource_name", "resourceName")
                    if pid or rid or rarn or reg or rname:
                        row_g: Dict[str, Any] = {"type": "cloud_resource"}
                        if pid:
                            row_g["project_id"] = pid[:260]
                        if rid:
                            row_g["resource_id"] = rid[:500]
                        if rarn:
                            row_g["arn"] = rarn[:500]
                        if reg:
                            row_g["region"] = reg[:80]
                        if rname:
                            row_g["resource"] = rname[:500]
                        f["affected_resources"] = [row_g]

        out["findings"] = findings
        return out
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket."""
        if self.ws:
            try:
                await self.ws.send_json({
                    "type": "progress",
                    "command_id": self.command_id,
                    "percent": percent,
                    "message": message
                })
            except Exception:
                pass
        logger.debug(f"Progress: {percent}% - {message}")
    
    async def hook_gcp_security_scan(
        self,
        options: Optional[ScanOptions] = None
    ) -> GCPSecurityOutput:
        """
        Main entry point for GCP security scanning.
        
        Args:
            options: Scan configuration options
            
        Returns:
            GCPSecurityOutput with all findings
        """
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.utcnow()
        self.findings = []
        self.check_results = []
        self.errors = []
        self.warnings = []
        self.projects_scanned = set()
        self.resources_scanned = 0
        self.privilege_escalation_paths = []
        self.exfiltration_paths = []
        self.persistence_mechanisms = []
        self._cache = {}
        
        # Default options
        if options is None:
            options = ScanOptions()
        
        await self._handle_progress(0, "Starting GCP security scan")
        
        # Determine scope
        await self._handle_progress(5, "Determining scan scope")
        projects = await self.project_scope_service.get_projects_to_scan(options.scope)
        
        if not projects:
            self.errors.append("No projects found to scan")
            # Important: missing gcloud/credentials is a coverage issue (not a security finding).
            # Do NOT emit a finding/threat for this case; return only errors/warnings.
            self.warnings.append("GCP scan skipped: credentials/tooling not available (no projects enumerated)")
            return self.result_processor_service.create_output(options)
        
        self.projects_scanned = set(projects)
        
        # Filter checks
        checks = self.check_filter_service.filter_checks(GCP_CHECKS, options)
        
        await self._handle_progress(10, f"Scanning {len(projects)} projects with {len(checks)} checks")
        
        # Execute checks per project
        total_work = len(projects) * len(checks)
        work_done = 0
        
        for project_id in projects:
            await self._handle_progress(
                10 + int((work_done / total_work) * 70),
                f"Scanning project: {project_id}"
            )
            
            for check in checks:
                try:
                    result = await self.check_executor_service.execute_check(check, project_id, options)
                    self.check_results.append(result)
                    self.findings.extend(result.findings)
                except Exception as e:
                    error_msg = f"Check '{check['name']}' failed for {project_id}: {str(e)}"
                    self.errors.append(error_msg)
                    logger.error(error_msg)
                
                work_done += 1
        
        # Run attack path analysis
        if options.analyze_privilege_escalation:
            await self._handle_progress(80, "Analyzing privilege escalation paths")
            await self.attack_path_analyzer_service.analyze_privilege_escalation_paths(projects, options)
            self.privilege_escalation_paths = self.attack_path_analyzer_service.privilege_escalation_paths
        
        if options.analyze_exfiltration_paths:
            await self._handle_progress(85, "Analyzing exfiltration paths")
            await self.attack_path_analyzer_service.analyze_exfiltration_paths(projects, options)
            self.exfiltration_paths = self.attack_path_analyzer_service.exfiltration_paths
        
        if options.analyze_persistence:
            await self._handle_progress(88, "Analyzing persistence mechanisms")
            await self.attack_path_analyzer_service.analyze_persistence(projects, options)
            self.persistence_mechanisms = self.attack_path_analyzer_service.persistence_mechanisms
        
        # Additional GCP services security checks
        await self._handle_progress(90, "Scanning additional GCP services")
        for project_id in projects:
            try:
                additional_findings = await self.additional_services_check_service.run_all_checks(project_id, options)
                self.findings.extend(additional_findings)
            except Exception as e:
                self.errors.append(f"Additional services check in {project_id} failed: {str(e)}")
        
        await self._handle_progress(95, "Generating summary")
        
        return self.result_processor_service.create_output(options)


# Legacy compatibility
async def scan_gcp_security(options: Optional[ScanOptions] = None) -> GCPSecurityOutput:
    """Legacy function for backward compatibility."""
    plugin = GCPSecurityPlugin()
    return await plugin.hook_gcp_security_scan(options)
