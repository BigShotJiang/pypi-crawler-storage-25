"""
GCP Security Assessment Modules
"""

