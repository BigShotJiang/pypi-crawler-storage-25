"""
Check Executor Service

Service for executing security checks by delegating to category-specific services.
"""

import time
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import CheckResult, ScanOptions
from .iam_check_service import IAMCheckService
from .compute_check_service import ComputeCheckService
from .storage_check_service import StorageCheckService
from .network_check_service import NetworkCheckService
from .database_check_service import DatabaseCheckService
from .gke_check_service import GKECheckService
from .serverless_check_service import ServerlessCheckService


class CheckExecutorService:
    """Service for executing security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize check executor service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to all services
        """
        self.plugin = plugin_instance
        # Initialize category-specific check services
        self.iam_service = IAMCheckService(plugin_instance)
        self.compute_service = ComputeCheckService(plugin_instance)
        self.storage_service = StorageCheckService(plugin_instance)
        self.network_service = NetworkCheckService(plugin_instance)
        self.database_service = DatabaseCheckService(plugin_instance)
        self.gke_service = GKECheckService(plugin_instance)
        self.serverless_service = ServerlessCheckService(plugin_instance)
    
    async def execute_check(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> CheckResult:
        """Execute a single security check."""
        start_time = time.time()
        findings = []
        resources_checked = 0
        error = None
        skipped = False
        
        try:
            check_fn = check.get("check_fn", "")
            
            # Route to appropriate category service based on check function name
            if check_fn.startswith("check_primitive_roles") or \
               check_fn.startswith("check_public_iam") or \
               check_fn.startswith("check_owner_role") or \
               check_fn.startswith("check_default_compute_sa") or \
               check_fn.startswith("check_sa_") or \
               check_fn.startswith("check_domain_wide_delegation"):
                findings = await self.iam_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_vm_") or \
                 check_fn.startswith("check_serial_port") or \
                 check_fn.startswith("check_startup_script") or \
                 check_fn.startswith("check_disk_encryption") or \
                 check_fn.startswith("check_shielded_vm") or \
                 check_fn.startswith("check_os_login"):
                findings = await self.compute_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_public_bucket") or \
                 check_fn.startswith("check_bucket_"):
                findings = await self.storage_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_open_") or \
                 check_fn.startswith("check_vpc_flow_logs"):
                findings = await self.network_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_sql_") or \
                 check_fn.startswith("check_bq_"):
                findings = await self.database_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_gke_"):
                findings = await self.gke_service.execute_check_method(check, project_id, options)
                
            elif check_fn.startswith("check_public_function") or \
                 check_fn.startswith("check_function_") or \
                 check_fn.startswith("check_scheduler_") or \
                 check_fn.startswith("check_build_trigger_") or \
                 check_fn.startswith("check_api_key_") or \
                 check_fn.startswith("check_kms_") or \
                 check_fn.startswith("check_audit_") or \
                 check_fn.startswith("check_data_access_") or \
                 check_fn.startswith("check_domain_restricted_"):
                findings = await self.serverless_service.execute_check_method(check, project_id, options)
            else:
                # Fallback to plugin's method if not in any service
                method_name = f"_{check_fn}"
                if hasattr(self.plugin, method_name):
                    method = getattr(self.plugin, method_name)
                    findings = await method(project_id, check, options)
                else:
                    error = f"Check method {check_fn} not found"
            
            self.plugin.resources_scanned += len(findings) if findings else 0
            
            resources_checked = len(findings) if findings else 0
            
        except Exception as e:
            error = str(e)
            self.plugin.errors.append(f"Check '{check['name']}' failed: {error}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CheckResult(
            check_id=check["id"],
            check_name=check["name"],
            category=check["category"],
            sub_category=check["sub_category"],
            passed=len(findings) == 0,
            findings_count=len(findings),
            findings=findings,
            resources_checked=resources_checked,
            resources_with_issues=len(findings),
            duration_ms=duration_ms,
            error=error,
            skipped=skipped,
        )

