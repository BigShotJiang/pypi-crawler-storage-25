"""
Attack Path Analyzer Service

Service for analyzing privilege escalation paths, exfiltration paths, and persistence mechanisms.
"""

from typing import List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, PrivilegeEscalationPath, ExfiltrationPath, PersistenceMechanism
from ..utils import run_gcloud_command
from ..databases import DANGEROUS_PERMISSIONS


class AttackPathAnalyzerService:
    """Service for analyzing attack paths."""
    
    def __init__(self, plugin_instance):
        """
        Initialize attack path analyzer service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def analyze_privilege_escalation_paths(
        self, projects: List[str], options: ScanOptions
    ) -> None:
        """Analyze potential privilege escalation paths."""
        for project_id in projects:
            policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
            if not policy:
                continue
            
            bindings = policy.get("bindings", [])
            
            # Find users with dangerous permissions
            for binding in bindings:
                role = binding.get("role", "")
                members = binding.get("members", [])
                
                # Check for privilege escalation enabling permissions
                for perm, info in DANGEROUS_PERMISSIONS.items():
                    if perm in role or role in [
                        "roles/cloudfunctions.admin",
                        "roles/compute.admin",
                        "roles/iam.serviceAccountAdmin",
                        "roles/deploymentmanager.editor"
                    ]:
                        for member in members:
                            if not member.startswith("serviceAccount:"):
                                self.plugin.privilege_escalation_paths.append(PrivilegeEscalationPath(
                                    source_identity=member,
                                    target_identity="Elevated service account",
                                    escalation_method=info["description"],
                                    required_permissions=[perm],
                                    steps=[
                                        f"1. {member} has {role}",
                                        f"2. This grants ability to: {info['escalation_method']}",
                                        "3. Can execute code as privileged service account"
                                    ],
                                    impact="Privilege escalation to higher-privileged identity",
                                    confidence=0.8
                                ))
    
    async def analyze_exfiltration_paths(
        self, projects: List[str], options: ScanOptions
    ) -> None:
        """Analyze potential data exfiltration paths."""
        for project_id in projects:
            # Check for storage transfer capabilities
            policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
            if not policy:
                continue
            
            bindings = policy.get("bindings", [])
            
            for binding in bindings:
                role = binding.get("role", "")
                
                if any(r in role for r in ["storage", "bigquery"]):
                    if "admin" in role.lower() or "editor" in role.lower():
                        self.plugin.exfiltration_paths.append(ExfiltrationPath(
                            source_resource=f"projects/{project_id}/*",
                            destination="External bucket or local download",
                            method=f"Via {role} permissions",
                            data_type="Storage/BigQuery data",
                            data_sensitivity="Unknown - requires classification",
                            mitigations=[
                                "Enable VPC Service Controls",
                                "Restrict IAM permissions",
                                "Enable Data Loss Prevention",
                            ],
                            confidence=0.7
                        ))
    
    async def analyze_persistence(
        self, projects: List[str], options: ScanOptions
    ) -> None:
        """Analyze persistence mechanisms."""
        for project_id in projects:
            # Cloud Scheduler
            jobs = await run_gcloud_command(["scheduler", "jobs", "list", "--location=-"], project_id)
            if isinstance(jobs, list):
                for job in jobs:
                    http_target = job.get("httpTarget", {})
                    uri = http_target.get("uri", "")
                    
                    if uri and "googleapis.com" not in uri:
                        self.plugin.persistence_mechanisms.append(PersistenceMechanism(
                            mechanism_type="cloud_scheduler",
                            resource=job.get("name", ""),
                            configuration={"uri": uri, "schedule": job.get("schedule")},
                            execution_context="Cloud Scheduler",
                            persistence_level="project",
                            detection_method="Scheduled job targeting external URL",
                            removal_steps=[
                                f"gcloud scheduler jobs delete {job.get('name', '').split('/')[-1]} --project={project_id}"
                            ],
                            confidence=0.75
                        ))

