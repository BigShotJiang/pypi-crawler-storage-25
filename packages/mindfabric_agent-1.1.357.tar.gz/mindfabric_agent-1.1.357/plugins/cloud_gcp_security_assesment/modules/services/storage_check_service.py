"""
Storage Check Service

Service for executing Cloud Storage-related security checks.
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
)
from ..utils import run_gsutil_command


class StorageCheckService:
    """Service for executing Storage security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize Storage check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Storage check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_public_bucket": self.check_public_bucket,
            "check_bucket_logging": self.check_bucket_logging,
            "check_bucket_versioning": self.check_bucket_versioning,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_public_bucket(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for publicly accessible storage buckets."""
        findings = []
        
        # List buckets
        buckets_output = run_gsutil_command(["ls", "-p", project_id])
        if not buckets_output:
            return findings
        
        bucket_names = [b.strip().replace("gs://", "").rstrip("/") 
                       for b in buckets_output.strip().split("\n") if b.strip()]
        
        for bucket_name in bucket_names:
            # Get bucket IAM
            iam_output = run_gsutil_command(["iam", "get", f"gs://{bucket_name}"])
            
            if "allUsers" in iam_output or "allAuthenticatedUsers" in iam_output:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=bucket_name,
                    resource_type=GCPResourceType.STORAGE_BUCKET,
                    description=f"Storage bucket is publicly accessible",
                    recommendation="Remove allUsers and allAuthenticatedUsers bindings and enable public access prevention",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"bucket": bucket_name, "public_access": True},
                    remediation_commands=[
                        f"gsutil iam ch -d allUsers gs://{bucket_name}",
                        f"gsutil iam ch -d allAuthenticatedUsers gs://{bucket_name}",
                        f"gcloud storage buckets update gs://{bucket_name} --public-access-prevention"
                    ],
                ))
        
        return findings
    
    async def check_bucket_logging(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if bucket access logging is enabled."""
        findings = []
        
        buckets_output = run_gsutil_command(["ls", "-p", project_id])
        if not buckets_output:
            return findings
        
        bucket_names = [b.strip().replace("gs://", "").rstrip("/") 
                       for b in buckets_output.strip().split("\n") if b.strip()]
        
        for bucket_name in bucket_names:
            # Get bucket details
            bucket_info = run_gsutil_command(["ls", "-L", "-b", f"gs://{bucket_name}"])
            
            if "Logging configuration:" not in bucket_info or "None" in bucket_info.split("Logging configuration:")[1].split("\n")[0]:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=bucket_name,
                    resource_type=GCPResourceType.STORAGE_BUCKET,
                    description="Bucket access logging is not enabled",
                    recommendation="Enable access logging for audit trail",
                    severity=SeverityLevel.MEDIUM,
                    evidence={"bucket": bucket_name},
                ))
        
        return findings
    
    async def check_bucket_versioning(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if bucket versioning is enabled."""
        findings = []
        
        buckets_output = run_gsutil_command(["ls", "-p", project_id])
        if not buckets_output:
            return findings
        
        bucket_names = [b.strip().replace("gs://", "").rstrip("/") 
                       for b in buckets_output.strip().split("\n") if b.strip()]
        
        for bucket_name in bucket_names:
            versioning = run_gsutil_command(["versioning", "get", f"gs://{bucket_name}"])
            
            if "Suspended" in versioning:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=bucket_name,
                    resource_type=GCPResourceType.STORAGE_BUCKET,
                    description="Bucket versioning is not enabled",
                    recommendation="Enable versioning for data protection and recovery",
                    severity=SeverityLevel.LOW,
                    evidence={"bucket": bucket_name},
                ))
        
        return findings
