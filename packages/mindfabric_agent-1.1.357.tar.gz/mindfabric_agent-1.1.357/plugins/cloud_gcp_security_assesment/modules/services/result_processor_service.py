"""
Result Processor Service

Service for processing scan results and generating summaries.
"""

from typing import Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    GCPSecurityOutput,
    ScanMetadata,
    SeveritySummary,
    CategorySummary,
    ProjectSummary,
    SecurityCategory,
    SeverityLevel,
)


class ResultProcessorService:
    """Service for processing scan results and generating summaries."""
    
    def __init__(self, plugin_instance):
        """
        Initialize result processor service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to findings
        """
        self.plugin = plugin_instance
    
    def create_output(self, options: ScanOptions) -> GCPSecurityOutput:
        """Create the final output object."""
        from datetime import datetime
        
        scan_completed = datetime.utcnow()
        duration = (scan_completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0
        
        # Create metadata
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            scan_type="deep" if options.deep_scan else ("quick" if options.quick_scan else "full"),
            started_at=self.plugin.scan_start or scan_completed,
            completed_at=scan_completed,
            duration_seconds=duration,
            projects_scanned=len(self.plugin.projects_scanned),
            resources_scanned=self.plugin.resources_scanned,
            total_checks=len(self.plugin.check_results),
            passed_checks=len([c for c in self.plugin.check_results if c.passed]),
            failed_checks=len([c for c in self.plugin.check_results if not c.passed]),
            error_checks=len([c for c in self.plugin.check_results if c.error]),
        )
        
        # Create severity summary
        severity_summary = self._create_severity_summary()
        
        # Create category summaries
        category_summaries = self._create_category_summaries()
        
        # Create project summaries
        project_summaries = self._create_project_summaries()
        
        # Get critical findings
        critical_findings = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]
        
        # Generate recommendations
        recommendations = self._generate_recommendations()
        
        return GCPSecurityOutput(
            metadata=metadata,
            scan_options=options,
            check_results=self.plugin.check_results,
            findings=self.plugin.findings,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            project_summaries=project_summaries,
            privilege_escalation_paths=self.plugin.privilege_escalation_paths,
            exfiltration_paths=self.plugin.exfiltration_paths,
            persistence_mechanisms=self.plugin.persistence_mechanisms,
            critical_findings=critical_findings if critical_findings else None,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            prioritized_recommendations=recommendations if recommendations else None,
        )
    
    def _create_severity_summary(self) -> SeveritySummary:
        """Create severity summary from findings."""
        summary = SeveritySummary()
        for finding in self.plugin.findings:
            if finding.severity == SeverityLevel.CRITICAL:
                summary.critical += 1
            elif finding.severity == SeverityLevel.HIGH:
                summary.high += 1
            elif finding.severity == SeverityLevel.MEDIUM:
                summary.medium += 1
            elif finding.severity == SeverityLevel.LOW:
                summary.low += 1
            else:
                summary.info += 1
        summary.total = len(self.plugin.findings)
        return summary
    
    def _create_category_summaries(self) -> List[CategorySummary]:
        """Create category summaries from findings."""
        category_counts: Dict[SecurityCategory, Dict[str, int]] = {}
        for finding in self.plugin.findings:
            if finding.category not in category_counts:
                category_counts[finding.category] = {"total": 0, "critical": 0, "high": 0}
            category_counts[finding.category]["total"] += 1
            if finding.severity == SeverityLevel.CRITICAL:
                category_counts[finding.category]["critical"] += 1
            elif finding.severity == SeverityLevel.HIGH:
                category_counts[finding.category]["high"] += 1
        
        return [
            CategorySummary(
                category=cat,
                category_name=cat.value.replace("_", " ").title(),
                total_count=counts["total"],
                critical_count=counts["critical"],
                high_count=counts["high"],
            )
            for cat, counts in category_counts.items()
        ]
    
    def _create_project_summaries(self) -> List[ProjectSummary]:
        """Create project summaries from findings."""
        project_summaries = []
        for project_id in self.plugin.projects_scanned:
            project_findings = [f for f in self.plugin.findings if f.resource.project_id == project_id]
            
            proj_severity = SeveritySummary()
            for f in project_findings:
                if f.severity == SeverityLevel.CRITICAL:
                    proj_severity.critical += 1
                elif f.severity == SeverityLevel.HIGH:
                    proj_severity.high += 1
                elif f.severity == SeverityLevel.MEDIUM:
                    proj_severity.medium += 1
                elif f.severity == SeverityLevel.LOW:
                    proj_severity.low += 1
                else:
                    proj_severity.info += 1
            proj_severity.total = len(project_findings)
            
            risk_score = proj_severity.critical * 10 + proj_severity.high * 5 + proj_severity.medium * 2
            
            project_summaries.append(ProjectSummary(
                project_id=project_id,
                total_findings=len(project_findings),
                severity_summary=proj_severity,
                risk_score=min(100.0, risk_score),
            ))
        
        return project_summaries
    
    def _generate_recommendations(self) -> List[str]:
        """Generate prioritized recommendations."""
        recommendations = []
        
        severity_summary = self._create_severity_summary()
        
        if severity_summary.critical > 0:
            recommendations.append(
                f"URGENT: Address {severity_summary.critical} critical findings immediately"
            )
        
        # Check for specific high-priority issues
        categories_found = set(f.category for f in self.plugin.findings)
        
        if SecurityCategory.DATA_EXPOSURE in categories_found:
            recommendations.append(
                "Enumerate GCS/BigQuery/Cloud SQL instances with allUsers/allAuthenticatedUsers or coarse IAM; remove public bindings, enforce org policies, and re-scan to verify."
            )
        
        if SecurityCategory.IAM_MISCONFIGURATION in categories_found:
            recommendations.append(
                "Implement least privilege access by replacing primitive roles with predefined roles"
            )
        
        if SecurityCategory.NETWORK_EXPOSURE in categories_found:
            recommendations.append(
                "Review firewall rules and restrict access from 0.0.0.0/0 to specific IP ranges"
            )
        
        if self.plugin.privilege_escalation_paths:
            recommendations.append(
                f"Review {len(self.plugin.privilege_escalation_paths)} privilege escalation paths and restrict permissions"
            )
        
        if self.plugin.persistence_mechanisms:
            recommendations.append(
                f"Audit {len(self.plugin.persistence_mechanisms)} potential persistence mechanisms"
            )
        
        # General recommendations
        recommendations.extend([
            "Enable VPC Service Controls for sensitive projects",
            "Implement organization policies to enforce security guardrails",
            "Set up Security Command Center for continuous monitoring",
        ])
        
        return recommendations

