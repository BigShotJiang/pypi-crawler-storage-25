"""
Finding Factory Service

Service for creating security findings.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    SecurityFinding,
    GCPResourceType,
    GCPResourceIdentifier,
    IAMBinding,
    ServiceAccountInfo,
    NetworkConfiguration,
    EncryptionInfo,
    FindingStatus,
    SeverityLevel,
)
from ..utils import get_mitre_reference, get_compliance_mappings, calculate_risk_score


class FindingFactoryService:
    """Service for creating security findings."""
    
    def __init__(self, plugin_instance):
        """
        Initialize finding factory service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    def create_finding(
        self,
        check: Dict[str, Any],
        project_id: str,
        resource_name: str,
        resource_type: GCPResourceType,
        description: str,
        recommendation: str,
        severity: Optional[SeverityLevel] = None,
        location: Optional[str] = None,
        affected_bindings: Optional[List[IAMBinding]] = None,
        affected_service_accounts: Optional[List[ServiceAccountInfo]] = None,
        network_config: Optional[NetworkConfiguration] = None,
        encryption_info: Optional[EncryptionInfo] = None,
        evidence: Optional[Dict[str, Any]] = None,
        remediation_commands: Optional[List[str]] = None,
    ) -> SecurityFinding:
        """Create a security finding."""
        
        finding_severity = severity or check["severity"]
        
        # Calculate risk score
        risk_score = calculate_risk_score(
            finding_severity,
            "easy" if finding_severity in [SeverityLevel.CRITICAL, SeverityLevel.HIGH] else "medium",
            "project"
        )
        
        # Get framework mappings
        mitre_ref = get_mitre_reference(check["sub_category"])
        compliance_mappings = get_compliance_mappings(check["sub_category"])
        
        return SecurityFinding(
            id=str(uuid.uuid4()),
            name=f"{check['name']} - {resource_name}",
            description=description,
            category=check["category"],
            sub_category=check["sub_category"],
            severity=finding_severity,
            status=FindingStatus.ACTIVE,
            resource=GCPResourceIdentifier(
                resource_type=resource_type,
                project_id=project_id,
                name=resource_name,
                location=location,
                full_resource_name=f"//cloudresourcemanager.googleapis.com/projects/{project_id}",
            ),
            mitre_attack=mitre_ref,
            compliance_mappings=compliance_mappings if compliance_mappings else None,
            affected_bindings=affected_bindings,
            affected_service_accounts=affected_service_accounts,
            network_config=network_config,
            encryption_info=encryption_info,
            evidence=evidence,
            risk_score=risk_score,
            exploitability="easy" if finding_severity == SeverityLevel.CRITICAL else "medium",
            impact_scope="project",
            recommendation=recommendation,
            remediation_commands=remediation_commands,
            detected_at=datetime.utcnow(),
            detection_method="api_check",
            confidence=0.95,
        )

