"""
Compute Check Service

Service for executing Compute Engine-related security checks.
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
    NetworkConfiguration,
    EncryptionInfo,
)
from ..utils import run_gcloud_command, check_content_for_secrets


class ComputeCheckService:
    """Service for executing Compute Engine security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize Compute check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Compute check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_vm_external_ip": self.check_vm_external_ip,
            "check_vm_default_sa": self.check_vm_default_sa,
            "check_vm_full_api_scope": self.check_vm_full_api_scope,
            "check_shielded_vm": self.check_shielded_vm,
            "check_os_login": self.check_os_login,
            "check_serial_port": self.check_serial_port,
            "check_startup_script_secrets": self.check_startup_script_secrets,
            "check_disk_encryption": self.check_disk_encryption,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_vm_external_ip(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs with external IPs."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            network_interfaces = instance.get("networkInterfaces", [])
            for nic in network_interfaces:
                access_configs = nic.get("accessConfigs", [])
                for ac in access_configs:
                    external_ip = ac.get("natIP")
                    if external_ip:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check,
                            project_id=project_id,
                            resource_name=name,
                            resource_type=GCPResourceType.COMPUTE_INSTANCE,
                            location=zone,
                            description=f"VM instance has external IP: {external_ip}",
                            recommendation="Remove external IP and use Cloud NAT or IAP for access",
                            severity=SeverityLevel.MEDIUM,
                            network_config=NetworkConfiguration(
                                network_name=nic.get("network", "").split("/")[-1],
                                has_external_ip=True,
                                external_ip=external_ip,
                                internal_ip=nic.get("networkIP"),
                            ),
                            evidence={"external_ip": external_ip, "zone": zone},
                        ))
        
        return findings
    
    async def check_vm_default_sa(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs using default service account."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            service_accounts = instance.get("serviceAccounts", [])
            for sa in service_accounts:
                email = sa.get("email", "")
                if "-compute@developer.gserviceaccount.com" in email:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.COMPUTE_INSTANCE,
                        location=zone,
                        description="VM uses default compute service account",
                        recommendation="Create and use a dedicated service account with minimal permissions",
                        severity=SeverityLevel.HIGH,
                        evidence={"service_account": email, "zone": zone},
                    ))
        
        return findings
    
    async def check_vm_full_api_scope(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs with full API access scope."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            service_accounts = instance.get("serviceAccounts", [])
            for sa in service_accounts:
                scopes = sa.get("scopes", [])
                if "https://www.googleapis.com/auth/cloud-platform" in scopes:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.COMPUTE_INSTANCE,
                        location=zone,
                        description="VM has full cloud-platform API access scope",
                        recommendation="Use minimal necessary scopes instead of cloud-platform",
                        severity=SeverityLevel.HIGH,
                        evidence={"scopes": scopes, "zone": zone},
                    ))
        
        return findings
    
    async def check_shielded_vm(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs without Shielded VM features."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            shielded_config = instance.get("shieldedInstanceConfig", {})
            secure_boot = shielded_config.get("enableSecureBoot", False)
            vtpm = shielded_config.get("enableVtpm", False)
            integrity = shielded_config.get("enableIntegrityMonitoring", False)
            
            if not all([secure_boot, vtpm, integrity]):
                missing = []
                if not secure_boot:
                    missing.append("Secure Boot")
                if not vtpm:
                    missing.append("vTPM")
                if not integrity:
                    missing.append("Integrity Monitoring")
                
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.COMPUTE_INSTANCE,
                    location=zone,
                    description=f"Shielded VM features disabled: {', '.join(missing)}",
                    recommendation="Enable all Shielded VM features for boot integrity protection",
                    severity=SeverityLevel.MEDIUM,
                    evidence={"missing_features": missing, "zone": zone},
                ))
        
        return findings
    
    async def check_os_login(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if OS Login is enabled."""
        findings = []
        
        project_info = await run_gcloud_command(["compute", "project-info", "describe"], project_id)
        if not project_info:
            return findings
        
        metadata = project_info.get("commonInstanceMetadata", {})
        items = metadata.get("items", [])
        
        os_login_enabled = False
        for item in items:
            if item.get("key") == "enable-oslogin" and item.get("value", "").lower() == "true":
                os_login_enabled = True
                break
        
        if not os_login_enabled:
            findings.append(self.plugin.finding_factory_service.create_finding(
                check=check,
                project_id=project_id,
                resource_name=project_id,
                resource_type=GCPResourceType.PROJECT,
                description="OS Login is not enabled at project level",
                recommendation="Enable OS Login for centralized SSH key management via IAM",
                severity=SeverityLevel.MEDIUM,
                evidence={"os_login_enabled": False},
            ))
        
        return findings
    
    async def check_serial_port(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs with serial port enabled."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            metadata = instance.get("metadata", {})
            items = metadata.get("items", [])
            
            for item in items:
                if item.get("key") == "serial-port-enable" and item.get("value", "").lower() == "true":
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.COMPUTE_INSTANCE,
                        location=zone,
                        description="Serial port access is enabled on VM",
                        recommendation="Disable serial port unless required for debugging",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"serial_port_enabled": True, "zone": zone},
                    ))
        
        return findings
    
    async def check_startup_script_secrets(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for secrets in startup scripts."""
        findings = []
        
        instances = await run_gcloud_command(["compute", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            zone = instance.get("zone", "").split("/")[-1]
            
            metadata = instance.get("metadata", {})
            items = metadata.get("items", [])
            
            for item in items:
                key = item.get("key", "")
                value = item.get("value", "")
                
                if key in ["startup-script", "shutdown-script"] and value:
                    secrets_found = check_content_for_secrets(value)
                    
                    if secrets_found:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check,
                            project_id=project_id,
                            resource_name=name,
                            resource_type=GCPResourceType.COMPUTE_INSTANCE,
                            location=zone,
                            description=f"Potential secrets found in {key}: {', '.join([s[1] for s in secrets_found])}",
                            recommendation="Use Secret Manager instead of embedding secrets in metadata",
                            severity=SeverityLevel.CRITICAL,
                            evidence={"script_type": key, "secret_types": [s[1] for s in secrets_found]},
                        ))
        
        return findings
    
    async def check_disk_encryption(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check disk encryption configuration."""
        findings = []
        
        disks = await run_gcloud_command(["compute", "disks", "list"], project_id)
        if not isinstance(disks, list):
            return findings
        
        for disk in disks:
            name = disk.get("name", "")
            zone = disk.get("zone", "").split("/")[-1]
            
            encryption = disk.get("diskEncryptionKey", {})
            kms_key = encryption.get("kmsKeyName")
            
            # All GCP disks are encrypted by default, but we check for CMEK
            if not kms_key and options.deep_scan:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.COMPUTE_DISK,
                    location=zone,
                    description="Disk uses Google-managed encryption, not customer-managed keys",
                    recommendation="Consider using customer-managed encryption keys (CMEK) for sensitive data",
                    severity=SeverityLevel.LOW,
                    encryption_info=EncryptionInfo(
                        encryption_type="google-managed",
                        kms_key_name=None
                    ),
                    evidence={"zone": zone},
                ))
        
        return findings
