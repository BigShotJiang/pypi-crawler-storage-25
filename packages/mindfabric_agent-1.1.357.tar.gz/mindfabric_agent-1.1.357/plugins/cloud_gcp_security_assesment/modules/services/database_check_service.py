"""
Database Check Service

Service for executing Database-related security checks (Cloud SQL, BigQuery).
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
)
from ..utils import run_gcloud_command


class DatabaseCheckService:
    """Service for executing Database security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize Database check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Database check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_sql_public_ip": self.check_sql_public_ip,
            "check_sql_ssl": self.check_sql_ssl,
            "check_sql_backup": self.check_sql_backup,
            "check_bq_public_dataset": self.check_bq_public_dataset,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_sql_public_ip(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Cloud SQL instances with public IP."""
        findings = []
        
        instances = await run_gcloud_command(["sql", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            
            ip_addresses = instance.get("ipAddresses", [])
            for ip in ip_addresses:
                if ip.get("type") == "PRIMARY":
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.CLOUD_SQL_INSTANCE,
                        description=f"Cloud SQL instance has public IP: {ip.get('ipAddress')}",
                        recommendation="Use private IP only with Private Service Connect or VPC peering",
                        severity=SeverityLevel.HIGH,
                        evidence={"public_ip": ip.get("ipAddress")},
                    ))
        
        return findings
    
    async def check_sql_ssl(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if SSL is enforced for Cloud SQL."""
        findings = []
        
        instances = await run_gcloud_command(["sql", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            settings = instance.get("settings", {})
            ip_config = settings.get("ipConfiguration", {})
            
            require_ssl = ip_config.get("requireSsl", False)
            
            if not require_ssl:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.CLOUD_SQL_INSTANCE,
                    description="SSL is not enforced for Cloud SQL connections",
                    recommendation="Enable requireSsl to enforce encrypted connections",
                    severity=SeverityLevel.HIGH,
                    evidence={"require_ssl": False},
                ))
        
        return findings
    
    async def check_sql_backup(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if backups are enabled for Cloud SQL."""
        findings = []
        
        instances = await run_gcloud_command(["sql", "instances", "list"], project_id)
        if not isinstance(instances, list):
            return findings
        
        for instance in instances:
            name = instance.get("name", "")
            settings = instance.get("settings", {})
            backup_config = settings.get("backupConfiguration", {})
            
            enabled = backup_config.get("enabled", False)
            
            if not enabled:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.CLOUD_SQL_INSTANCE,
                    description="Automated backups are not enabled",
                    recommendation="Enable automated backups for disaster recovery",
                    severity=SeverityLevel.MEDIUM,
                    evidence={"backups_enabled": False},
                ))
        
        return findings
    
    async def check_bq_public_dataset(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public BigQuery datasets."""
        findings = []
        
        # BigQuery listing requires different handling - placeholder
        datasets = await run_gcloud_command(["bq", "ls", "--format=json"], project_id)
        # TODO: Implement proper BigQuery dataset access checking
        return findings
