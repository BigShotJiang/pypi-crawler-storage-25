"""
GKE Check Service

Service for executing GKE-related security checks.
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
)
from ..utils import run_gcloud_command


class GKECheckService:
    """Service for executing GKE security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize GKE check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute GKE check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_gke_legacy_abac": self.check_gke_legacy_abac,
            "check_gke_basic_auth": self.check_gke_basic_auth,
            "check_gke_public_endpoint": self.check_gke_public_endpoint,
            "check_gke_workload_identity": self.check_gke_workload_identity,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_gke_legacy_abac(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for GKE clusters with legacy ABAC enabled."""
        findings = []
        
        clusters = await run_gcloud_command(["container", "clusters", "list"], project_id)
        if not isinstance(clusters, list):
            return findings
        
        for cluster in clusters:
            name = cluster.get("name", "")
            location = cluster.get("location", "")
            
            legacy_abac = cluster.get("legacyAbac", {})
            enabled = legacy_abac.get("enabled", False)
            
            if enabled:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.GKE_CLUSTER,
                    location=location,
                    description="Legacy ABAC authorization is enabled",
                    recommendation="Disable legacy ABAC and use RBAC for access control",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"legacy_abac": True, "location": location},
                ))
        
        return findings
    
    async def check_gke_basic_auth(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for GKE clusters with basic auth enabled."""
        findings = []
        
        clusters = await run_gcloud_command(["container", "clusters", "list"], project_id)
        if not isinstance(clusters, list):
            return findings
        
        for cluster in clusters:
            name = cluster.get("name", "")
            location = cluster.get("location", "")
            
            master_auth = cluster.get("masterAuth", {})
            username = master_auth.get("username", "")
            
            if username:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.GKE_CLUSTER,
                    location=location,
                    description="Basic authentication is enabled for GKE cluster",
                    recommendation="Disable basic auth and use IAM for authentication",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"basic_auth_enabled": True, "location": location},
                ))
        
        return findings
    
    async def check_gke_public_endpoint(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for GKE clusters with public endpoint."""
        findings = []
        
        clusters = await run_gcloud_command(["container", "clusters", "list"], project_id)
        if not isinstance(clusters, list):
            return findings
        
        for cluster in clusters:
            name = cluster.get("name", "")
            location = cluster.get("location", "")
            
            private_config = cluster.get("privateClusterConfig", {})
            enable_private_endpoint = private_config.get("enablePrivateEndpoint", False)
            
            if not enable_private_endpoint:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.GKE_CLUSTER,
                    location=location,
                    description="GKE cluster has public endpoint",
                    recommendation="Enable private endpoint for cluster master",
                    severity=SeverityLevel.HIGH,
                    evidence={"public_endpoint": True, "location": location},
                ))
        
        return findings
    
    async def check_gke_workload_identity(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if Workload Identity is enabled."""
        findings = []
        
        clusters = await run_gcloud_command(["container", "clusters", "list"], project_id)
        if not isinstance(clusters, list):
            return findings
        
        for cluster in clusters:
            name = cluster.get("name", "")
            location = cluster.get("location", "")
            
            workload_identity = cluster.get("workloadIdentityConfig", {})
            workload_pool = workload_identity.get("workloadPool", "")
            
            if not workload_pool:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.GKE_CLUSTER,
                    location=location,
                    description="Workload Identity is not enabled",
                    recommendation="Enable Workload Identity for secure pod-level IAM",
                    severity=SeverityLevel.HIGH,
                    evidence={"workload_identity_enabled": False, "location": location},
                ))
        
        return findings
