"""
Serverless Check Service

Service for executing Serverless-related security checks (Functions, Scheduler, etc.).
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
)
from ..utils import run_gcloud_command


class ServerlessCheckService:
    """Service for executing Serverless security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize Serverless check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Serverless check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_public_function": self.check_public_function,
            "check_function_default_sa": self.check_function_default_sa,
            "check_function_env_secrets": self.check_function_env_secrets,
            "check_audit_logging": self.check_audit_logging,
            "check_data_access_logs": self.check_data_access_logs,
            "check_api_key_restrictions": self.check_api_key_restrictions,
            "check_kms_rotation": self.check_kms_rotation,
            "check_scheduler_persistence": self.check_scheduler_persistence,
            "check_build_trigger_persistence": self.check_build_trigger_persistence,
            "check_domain_restricted_sharing": self.check_domain_restricted_sharing,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_public_function(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for publicly invokable Cloud Functions."""
        findings = []
        
        functions = await run_gcloud_command(["functions", "list"], project_id)
        if not isinstance(functions, list):
            return findings
        
        for func in functions:
            name = func.get("name", "").split("/")[-1]
            
            # Check function IAM
            func_iam = await run_gcloud_command([
                "functions", "get-iam-policy", name, "--gen2"
            ], project_id)
            
            if isinstance(func_iam, dict):
                bindings = func_iam.get("bindings", [])
                for binding in bindings:
                    members = binding.get("members", [])
                    if "allUsers" in members or "allAuthenticatedUsers" in members:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check,
                            project_id=project_id,
                            resource_name=name,
                            resource_type=GCPResourceType.CLOUD_FUNCTION,
                            description="Cloud Function is publicly invokable",
                            recommendation="Remove public invoker access and use authentication",
                            severity=SeverityLevel.HIGH,
                            evidence={"public_access": True},
                        ))
        
        return findings
    
    async def check_function_default_sa(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for functions using default service account."""
        findings = []
        # TODO: Implement function default SA check
        return findings
    
    async def check_function_env_secrets(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for secrets in function environment variables."""
        findings = []
        # TODO: Implement function env secrets check
        return findings
    
    async def check_audit_logging(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check audit logging configuration."""
        findings = []
        # TODO: Implement audit logging check
        return findings
    
    async def check_data_access_logs(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check data access logging."""
        findings = []
        # TODO: Implement data access logs check
        return findings
    
    async def check_api_key_restrictions(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for unrestricted API keys."""
        findings = []
        # TODO: Implement API key restrictions check
        return findings
    
    async def check_kms_rotation(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check KMS key rotation."""
        findings = []
        # TODO: Implement KMS rotation check
        return findings
    
    async def check_scheduler_persistence(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Cloud Scheduler persistence."""
        findings = []
        
        jobs = await run_gcloud_command(["scheduler", "jobs", "list", "--location=-"], project_id)
        if not isinstance(jobs, list):
            return findings
        
        for job in jobs:
            name = job.get("name", "").split("/")[-1]
            http_target = job.get("httpTarget", {})
            uri = http_target.get("uri", "")
            
            # Check for external targets
            if uri and not "googleapis.com" in uri:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.CLOUD_SCHEDULER_JOB,
                    description=f"Cloud Scheduler job targets external URL: {uri}",
                    recommendation="Review scheduled job for potential persistence mechanism",
                    severity=SeverityLevel.HIGH,
                    evidence={"target_uri": uri},
                ))
        
        return findings
    
    async def check_build_trigger_persistence(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Cloud Build trigger persistence."""
        findings = []
        # TODO: Implement build trigger persistence check
        return findings
    
    async def check_domain_restricted_sharing(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check organization policy for domain restricted sharing."""
        findings = []
        # TODO: Implement domain restricted sharing check
        return findings
