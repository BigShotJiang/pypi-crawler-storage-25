"""
Network Check Service

Service for executing Network-related security checks.
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
    NetworkConfiguration,
)
from ..utils import run_gcloud_command


class NetworkCheckService:
    """Service for executing Network security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize Network check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Network check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_open_ssh": self.check_open_ssh,
            "check_open_rdp": self.check_open_rdp,
            "check_open_all_ports": self.check_open_all_ports,
            "check_vpc_flow_logs": self.check_vpc_flow_logs,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_open_ssh(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for firewall rules allowing SSH from anywhere."""
        findings = []
        
        rules = await run_gcloud_command([
            "compute", "firewall-rules", "list",
            "--filter=direction=INGRESS"
        ], project_id)
        
        if not isinstance(rules, list):
            return findings
        
        for rule in rules:
            name = rule.get("name", "")
            source_ranges = rule.get("sourceRanges", [])
            
            if "0.0.0.0/0" not in source_ranges:
                continue
            
            allowed = rule.get("allowed", [])
            for allow in allowed:
                ports = allow.get("ports", [])
                protocol = allow.get("IPProtocol", "")
                
                if protocol == "tcp" and ("22" in ports or not ports):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.FIREWALL_RULE,
                        description="Firewall rule allows SSH (port 22) from 0.0.0.0/0",
                        recommendation="Restrict SSH access to specific IP ranges or use IAP",
                        severity=SeverityLevel.HIGH,
                        network_config=NetworkConfiguration(
                            network_name=rule.get("network", "").split("/")[-1],
                            open_ports=[22],
                        ),
                        evidence={"rule": name, "source_ranges": source_ranges},
                        remediation_commands=[
                            f"gcloud compute firewall-rules update {name} --source-ranges=YOUR_IP/32"
                        ],
                    ))
        
        return findings
    
    async def check_open_rdp(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for firewall rules allowing RDP from anywhere."""
        findings = []
        
        rules = await run_gcloud_command([
            "compute", "firewall-rules", "list",
            "--filter=direction=INGRESS"
        ], project_id)
        
        if not isinstance(rules, list):
            return findings
        
        for rule in rules:
            name = rule.get("name", "")
            source_ranges = rule.get("sourceRanges", [])
            
            if "0.0.0.0/0" not in source_ranges:
                continue
            
            allowed = rule.get("allowed", [])
            for allow in allowed:
                ports = allow.get("ports", [])
                protocol = allow.get("IPProtocol", "")
                
                if protocol == "tcp" and ("3389" in ports or not ports):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.FIREWALL_RULE,
                        description="Firewall rule allows RDP (port 3389) from 0.0.0.0/0",
                        recommendation="Restrict RDP access to specific IP ranges or use IAP",
                        severity=SeverityLevel.HIGH,
                        network_config=NetworkConfiguration(
                            network_name=rule.get("network", "").split("/")[-1],
                            open_ports=[3389],
                        ),
                        evidence={"rule": name, "source_ranges": source_ranges},
                    ))
        
        return findings
    
    async def check_open_all_ports(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for firewall rules allowing all ports from anywhere."""
        findings = []
        
        rules = await run_gcloud_command([
            "compute", "firewall-rules", "list",
            "--filter=direction=INGRESS"
        ], project_id)
        
        if not isinstance(rules, list):
            return findings
        
        for rule in rules:
            name = rule.get("name", "")
            source_ranges = rule.get("sourceRanges", [])
            
            if "0.0.0.0/0" not in source_ranges:
                continue
            
            allowed = rule.get("allowed", [])
            for allow in allowed:
                ports = allow.get("ports", [])
                protocol = allow.get("IPProtocol", "")
                
                # Check for all ports allowed
                if protocol == "all" or (protocol == "tcp" and not ports):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name=name,
                        resource_type=GCPResourceType.FIREWALL_RULE,
                        description=f"Firewall rule allows all {protocol} traffic from 0.0.0.0/0",
                        recommendation="Restrict to specific ports and source ranges",
                        severity=SeverityLevel.CRITICAL,
                        evidence={"rule": name, "protocol": protocol, "source_ranges": source_ranges},
                    ))
        
        return findings
    
    async def check_vpc_flow_logs(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for subnets without VPC flow logs."""
        findings = []
        
        subnets = await run_gcloud_command(["compute", "networks", "subnets", "list"], project_id)
        if not isinstance(subnets, list):
            return findings
        
        for subnet in subnets:
            name = subnet.get("name", "")
            region = subnet.get("region", "").split("/")[-1]
            
            enable_flow_logs = subnet.get("enableFlowLogs", False)
            
            if not enable_flow_logs:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=name,
                    resource_type=GCPResourceType.SUBNETWORK,
                    location=region,
                    description="VPC flow logs are not enabled for subnet",
                    recommendation="Enable VPC flow logs for network monitoring and forensics",
                    severity=SeverityLevel.MEDIUM,
                    evidence={"subnet": name, "region": region},
                ))
        
        return findings
