"""
Check Filter Service

Service for filtering checks based on scan options.
"""

from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, SecurityCategory, SecuritySubCategory, SeverityLevel
from ..databases import GCP_CHECKS


class CheckFilterService:
    """Service for filtering persistence checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize check filter service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    def filter_checks(self, checks: List[Dict], options: ScanOptions) -> List[Dict]:
        """Filter checks based on options."""
        filtered = checks
        
        # Filter by categories
        if options.scan_categories:
            filtered = [c for c in filtered if c["category"] in options.scan_categories]
        
        if options.exclude_categories:
            filtered = [c for c in filtered if c["category"] not in options.exclude_categories]
        
        # Filter by subcategories
        if options.scan_subcategories:
            filtered = [c for c in filtered if c["sub_category"] in options.scan_subcategories]
        
        # Quick scan - only high/critical severity
        if options.quick_scan:
            filtered = [c for c in filtered if c["severity"] in [SeverityLevel.HIGH, SeverityLevel.CRITICAL]]
        
        return filtered

