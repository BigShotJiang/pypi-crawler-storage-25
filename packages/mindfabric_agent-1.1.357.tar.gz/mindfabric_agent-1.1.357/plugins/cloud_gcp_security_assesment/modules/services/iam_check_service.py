"""
IAM Check Service

Service for executing IAM-related security checks.
"""

from datetime import datetime
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ScanOptions,
    SecurityFinding,
    GCPResourceType,
    SeverityLevel,
)
from ..utils import run_gcloud_command, analyze_iam_binding


class IAMCheckService:
    """Service for executing IAM security checks."""
    
    def __init__(self, plugin_instance):
        """
        Initialize IAM check service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to finding factory
        """
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        project_id: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute IAM check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_primitive_roles": self.check_primitive_roles,
            "check_public_iam_access": self.check_public_iam_access,
            "check_owner_role": self.check_owner_role,
            "check_default_compute_sa": self.check_default_compute_sa,
            "check_sa_key_rotation": self.check_sa_key_rotation,
            "check_domain_wide_delegation": self.check_domain_wide_delegation,
            "check_sa_impersonation": self.check_sa_impersonation,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(project_id, check, options)
        
        return []
    
    async def check_primitive_roles(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for usage of primitive roles."""
        findings = []
        
        policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
        if not policy:
            return findings
        
        bindings = policy.get("bindings", [])
        
        for binding in bindings:
            role = binding.get("role", "")
            if role in ["roles/owner", "roles/editor"]:
                iam_binding = analyze_iam_binding(binding)
                
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=f"project-iam-{role.split('/')[-1]}",
                    resource_type=GCPResourceType.IAM_POLICY,
                    description=f"Primitive role '{role}' is assigned to {len(binding.get('members', []))} members",
                    recommendation=f"Replace primitive role '{role}' with more granular predefined or custom roles",
                    severity=SeverityLevel.CRITICAL if role == "roles/owner" else SeverityLevel.HIGH,
                    affected_bindings=[iam_binding],
                    evidence={"role": role, "members": binding.get("members", [])},
                ))
        
        return findings
    
    async def check_public_iam_access(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public IAM access."""
        findings = []
        
        policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
        if not policy:
            return findings
        
        bindings = policy.get("bindings", [])
        
        for binding in bindings:
            members = binding.get("members", [])
            public_members = [m for m in members if m in ["allUsers", "allAuthenticatedUsers"]]
            
            if public_members:
                iam_binding = analyze_iam_binding(binding)
                
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name="project-iam-policy",
                    resource_type=GCPResourceType.IAM_POLICY,
                    description=f"Public access ({', '.join(public_members)}) granted for role {binding.get('role')}",
                    recommendation="Remove allUsers and allAuthenticatedUsers from IAM bindings",
                    severity=SeverityLevel.CRITICAL,
                    affected_bindings=[iam_binding],
                    evidence={"public_members": public_members, "role": binding.get("role")},
                ))
        
        return findings
    
    async def check_owner_role(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Owner role assignments."""
        findings = []
        
        policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
        if not policy:
            return findings
        
        bindings = policy.get("bindings", [])
        
        for binding in bindings:
            role = binding.get("role", "")
            members = binding.get("members", [])
            
            if role == "roles/owner":
                # Check for service accounts with Owner
                sa_owners = [m for m in members if m.startswith("serviceAccount:")]
                
                if sa_owners:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check,
                        project_id=project_id,
                        resource_name="project-owner-role",
                        resource_type=GCPResourceType.IAM_POLICY,
                        description=f"Service account(s) have Owner role: {', '.join(sa_owners)}",
                        recommendation="Remove Owner role from service accounts and use minimal necessary permissions",
                        severity=SeverityLevel.CRITICAL,
                        evidence={"service_accounts_with_owner": sa_owners},
                    ))
        
        return findings
    
    async def check_default_compute_sa(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for default compute service account usage."""
        findings = []
        
        policy = await run_gcloud_command(["projects", "get-iam-policy", project_id])
        if not policy:
            return findings
        
        bindings = policy.get("bindings", [])
        
        for binding in bindings:
            members = binding.get("members", [])
            role = binding.get("role", "")
            
            # Check if default compute SA has elevated roles
            for member in members:
                if "-compute@developer.gserviceaccount.com" in member:
                    if role in ["roles/owner", "roles/editor"]:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check,
                            project_id=project_id,
                            resource_name=member.replace("serviceAccount:", ""),
                            resource_type=GCPResourceType.SERVICE_ACCOUNT,
                            description=f"Default compute service account has elevated role: {role}",
                            recommendation="Create dedicated service accounts with minimal permissions instead of using defaults",
                            severity=SeverityLevel.HIGH,
                            evidence={"service_account": member, "role": role},
                        ))
        
        return findings
    
    async def check_sa_key_rotation(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for old service account keys."""
        findings = []
        
        # List service accounts
        sas = await run_gcloud_command(["iam", "service-accounts", "list"], project_id)
        if not isinstance(sas, list):
            return findings
        
        for sa in sas:
            sa_email = sa.get("email", "")
            
            # List keys for this SA
            keys = await run_gcloud_command([
                "iam", "service-accounts", "keys", "list",
                f"--iam-account={sa_email}"
            ], project_id)
            
            if not isinstance(keys, list):
                continue
            
            for key in keys:
                if key.get("keyType") != "USER_MANAGED":
                    continue
                
                # Check key age
                valid_after = key.get("validAfterTime", "")
                if valid_after:
                    try:
                        key_date = datetime.fromisoformat(valid_after.replace("Z", "+00:00"))
                        age_days = (datetime.now(key_date.tzinfo) - key_date).days
                        
                        if age_days > 90:
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check,
                                project_id=project_id,
                                resource_name=sa_email,
                                resource_type=GCPResourceType.SERVICE_ACCOUNT_KEY,
                                description=f"Service account key is {age_days} days old (>90 days)",
                                recommendation="Rotate service account keys every 90 days or use GCP-managed keys",
                                severity=SeverityLevel.HIGH if age_days > 180 else SeverityLevel.MEDIUM,
                                evidence={"key_age_days": age_days, "key_name": key.get("name")},
                            ))
                    except Exception:
                        pass
        
        return findings
    
    async def check_domain_wide_delegation(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for service accounts with domain-wide delegation."""
        findings = []
        
        sas = await run_gcloud_command(["iam", "service-accounts", "list"], project_id)
        if not isinstance(sas, list):
            return findings
        
        for sa in sas:
            sa_email = sa.get("email", "")
            description = sa.get("description", "").lower()
            display_name = sa.get("displayName", "").lower()
            
            # Check for indicators of domain-wide delegation
            if any(keyword in description or keyword in display_name 
                   for keyword in ["domain-wide", "workspace", "gsuite", "delegation"]):
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check,
                    project_id=project_id,
                    resource_name=sa_email,
                    resource_type=GCPResourceType.SERVICE_ACCOUNT,
                    description=f"Service account may have domain-wide delegation enabled",
                    recommendation="Audit G Workspace Admin console to verify delegation scope and necessity",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"description": sa.get("description"), "display_name": sa.get("displayName")},
                ))
        
        return findings
    
    async def check_sa_impersonation(
        self, project_id: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check who can impersonate service accounts."""
        findings = []
        
        sas = await run_gcloud_command(["iam", "service-accounts", "list"], project_id)
        if not isinstance(sas, list):
            return findings
        
        for sa in sas:
            sa_email = sa.get("email", "")
            
            # Get SA IAM policy
            sa_policy = await run_gcloud_command([
                "iam", "service-accounts", "get-iam-policy", sa_email
            ], project_id)
            
            if not sa_policy:
                continue
            
            bindings = sa_policy.get("bindings", [])
            
            for binding in bindings:
                role = binding.get("role", "")
                members = binding.get("members", [])
                
                if role in ["roles/iam.serviceAccountTokenCreator", "roles/iam.serviceAccountUser"]:
                    # Check for broad impersonation rights
                    non_sa_members = [m for m in members if not m.startswith("serviceAccount:")]
                    
                    if non_sa_members:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check,
                            project_id=project_id,
                            resource_name=sa_email,
                            resource_type=GCPResourceType.SERVICE_ACCOUNT,
                            description=f"Users can impersonate SA via {role}: {', '.join(non_sa_members)}",
                            recommendation="Review impersonation permissions and restrict to necessary users only",
                            severity=SeverityLevel.HIGH,
                            evidence={"role": role, "impersonators": non_sa_members},
                        ))
        
        return findings
