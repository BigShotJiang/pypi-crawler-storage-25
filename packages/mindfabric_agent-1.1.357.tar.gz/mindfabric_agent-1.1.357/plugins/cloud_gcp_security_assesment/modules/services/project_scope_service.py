"""
Project Scope Service

Service for determining which projects to scan.
"""

from typing import List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanScope
from ..utils import run_gcloud_command


class ProjectScopeService:
    """Service for determining scan scope."""
    
    def __init__(self, plugin_instance):
        """
        Initialize project scope service.
        
        Args:
            plugin_instance: Instance of GCPSecurityPlugin for access to plugin state
        """
        self.plugin = plugin_instance
    
    async def get_projects_to_scan(self, scope: ScanScope) -> List[str]:
        """Determine which projects to scan based on scope."""
        projects = []
        
        if scope.project_ids:
            projects = scope.project_ids
        elif scope.organization_id:
            # Get all projects in organization
            result = await run_gcloud_command([
                "projects", "list",
                f"--filter=parent.id={scope.organization_id}"
            ])
            if isinstance(result, list):
                projects = [p.get("projectId") for p in result if p.get("projectId")]
        elif scope.folder_ids:
            # Get projects in folders
            for folder_id in scope.folder_ids:
                result = await run_gcloud_command([
                    "projects", "list",
                    f"--filter=parent.id={folder_id}"
                ])
                if isinstance(result, list):
                    folder_projects = [p.get("projectId") for p in result if p.get("projectId")]
                    projects.extend(folder_projects)
        else:
            # Default: list all accessible projects
            result = await run_gcloud_command(["projects", "list"])
            if isinstance(result, list):
                projects = [p.get("projectId") for p in result if p.get("projectId")]
        
        return list(set(projects))  # Remove duplicates

