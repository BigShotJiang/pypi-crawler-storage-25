"""
Additional GCP Services Security Check Service

Covers additional GCP services security assessments:
- Cloud Build (secrets, artifact registry, triggers)
- Cloud KMS (key rotation, access control)
- Cloud Pub/Sub (topic permissions, subscriptions)
- Cloud Scheduler (job permissions, targets)
- Artifact Registry (image scanning, access control)
- Cloud Workflows (workflow security)
- Cloud Tasks (task security)
- Cloud Endpoints (API security)
- Cloud Armor (WAF security)
- Cloud CDN (CDN security)
- Cloud Load Balancing (LB security)
- Cloud DNS (DNS security)
- Cloud Identity (identity security)

MITRE ATT&CK: T1190, T1552, T1098, T1078
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
import re
from typing import Any, Dict, List, Optional

from ...proto import GCPResourceType, ScanOptions, SecurityFinding, SeverityLevel
from ..utils import run_gcloud_command

logger = logging.getLogger(__name__)


# Secret patterns for detection
SECRET_PATTERNS = {
    "api_key": re.compile(r'(?i)(api[_-]?key|apikey)\s*[=:]\s*["\']?([a-zA-Z0-9_-]{20,})["\']?'),
    "password": re.compile(r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']?([^\s"\']{8,})["\']?'),
    "token": re.compile(r'(?i)(token|bearer)\s*[=:]\s*["\']?([a-zA-Z0-9_-]{20,})["\']?'),
    "secret": re.compile(r'(?i)(secret|private)\s*[=:]\s*["\']?([a-zA-Z0-9_-]{16,})["\']?'),
}


class AdditionalGCPServicesCheckService:
    """Service for executing additional GCP services security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize additional GCP services check service."""
        self.plugin = plugin_instance
    
    # =========================================================================
    # Cloud Build Security Checks
    # =========================================================================
    
    async def check_cloud_build_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Build security.
        
        Checks:
        - Build-time secrets exposure
        - Artifact registry security
        - Build triggers security
        - Build service account security
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # Check build triggers
            triggers = await run_gcloud_command(["builds", "triggers", "list"], project_id)
            if isinstance(triggers, list):
                for trigger in triggers:
                    trigger_name = trigger.get("name", "unknown")
                    trigger_id = trigger.get("id", "")
                    
                    # Check for public repository triggers
                    github_trigger = trigger.get("github", {})
                    if github_trigger:
                        owner = github_trigger.get("owner", "")
                        repo = github_trigger.get("name", "")
                        
                        # Check if trigger has no branch filter (triggers on all branches)
                        push_config = github_trigger.get("push", {})
                        if not push_config.get("branch"):
                            findings.append(self._create_finding(
                                check_id="cloudbuild_trigger_no_branch_filter",
                                resource_id=trigger_id,
                                resource_name=trigger_name,
                                severity="medium",
                                title="Cloud Build trigger has no branch filter",
                                description=f"Build trigger '{trigger_name}' triggers on all branches",
                                recommendation="Configure branch filter to limit trigger scope",
                                project_id=project_id,
                            ))
                    
                    # Check build config for secrets in plaintext
                    build_config = trigger.get("build", {})
                    if build_config:
                        steps = build_config.get("steps", [])
                        for step in steps:
                            env_vars = step.get("env", [])
                            for env in env_vars:
                                for pattern_name, pattern in SECRET_PATTERNS.items():
                                    if pattern.search(env):
                                        findings.append(self._create_finding(
                                            check_id="cloudbuild_secrets_in_config",
                                            resource_id=trigger_id,
                                            resource_name=trigger_name,
                                            severity="critical",
                                            title="Potential secrets in Cloud Build config",
                                            description=f"Build trigger '{trigger_name}' may contain {pattern_name} in environment variables",
                                            recommendation="Use Secret Manager instead of plaintext secrets",
                                            project_id=project_id,
                                        ))
                    
                    # Check service account
                    service_account = trigger.get("serviceAccount", "")
                    if not service_account or "compute@developer" in service_account:
                        findings.append(self._create_finding(
                            check_id="cloudbuild_default_sa",
                            resource_id=trigger_id,
                            resource_name=trigger_name,
                            severity="medium",
                            title="Cloud Build trigger uses default service account",
                            description=f"Build trigger '{trigger_name}' uses default Compute Engine service account",
                            recommendation="Create a dedicated service account with minimal permissions",
                            project_id=project_id,
                        ))
            
            # Check recent builds for leaked secrets
            builds = await run_gcloud_command(["builds", "list", "--limit=10"], project_id)
            if isinstance(builds, list):
                for build in builds:
                    build_id = build.get("id", "")
                    build_logs_uri = build.get("logUrl", "")
                    
                    # Check build substitutions for secrets
                    substitutions = build.get("substitutions", {})
                    for key, value in substitutions.items():
                        for pattern_name, pattern in SECRET_PATTERNS.items():
                            if pattern.search(f"{key}={value}"):
                                findings.append(self._create_finding(
                                    check_id="cloudbuild_secrets_in_substitutions",
                                    resource_id=build_id,
                                    resource_name=f"build-{build_id[:8]}",
                                    severity="high",
                                    title="Potential secrets in build substitutions",
                                    description=f"Build {build_id[:8]} may contain {pattern_name} in substitutions",
                                    recommendation="Use Secret Manager for sensitive values",
                                    project_id=project_id,
                                ))
        except Exception as e:
            logger.debug(f"Cloud Build check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud KMS Security Checks
    # =========================================================================
    
    async def check_cloud_kms_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud KMS security.
        
        Checks:
        - Key rotation configuration
        - Access control policies
        - Key ring security
        - Crypto key security
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List key rings
            key_rings = await run_gcloud_command(["kms", "keyrings", "list", "--location=global"], project_id)
            if not isinstance(key_rings, list):
                key_rings = []
            
            # Also check regional key rings
            regions = ["us-central1", "us-east1", "europe-west1", "asia-east1"]
            for region in regions:
                regional_rings = await run_gcloud_command(["kms", "keyrings", "list", f"--location={region}"], project_id)
                if isinstance(regional_rings, list):
                    key_rings.extend(regional_rings)
            
            for key_ring in key_rings:
                ring_name = key_ring.get("name", "").split("/")[-1]
                location = key_ring.get("name", "").split("/")[3] if "/" in key_ring.get("name", "") else "global"
                
                # Check keys in the ring
                keys = await run_gcloud_command([
                    "kms", "keys", "list",
                    f"--keyring={ring_name}",
                    f"--location={location}"
                ], project_id)
                
                if isinstance(keys, list):
                    for key in keys:
                        key_name = key.get("name", "").split("/")[-1]
                        key_purpose = key.get("purpose", "")
                        
                        # Check rotation period
                        rotation_period = key.get("rotationPeriod", "")
                        next_rotation = key.get("nextRotationTime", "")
                        
                        if not rotation_period or not next_rotation:
                            findings.append(self._create_finding(
                                check_id="kms_no_rotation",
                                resource_id=key.get("name", ""),
                                resource_name=key_name,
                                severity="medium",
                                title="KMS key has no automatic rotation",
                                description=f"Key '{key_name}' in keyring '{ring_name}' has no rotation configured",
                                recommendation="Enable automatic key rotation with a 90-day or shorter period",
                                project_id=project_id,
                            ))
                        elif rotation_period:
                            # Parse rotation period (e.g., "7776000s" for 90 days)
                            try:
                                seconds = int(rotation_period.rstrip("s"))
                                days = seconds / 86400
                                if days > 365:
                                    findings.append(self._create_finding(
                                        check_id="kms_long_rotation",
                                        resource_id=key.get("name", ""),
                                        resource_name=key_name,
                                        severity="low",
                                        title="KMS key has long rotation period",
                                        description=f"Key '{key_name}' rotation period is {int(days)} days",
                                        recommendation="Consider reducing rotation period to 90 days or less",
                                        project_id=project_id,
                                    ))
                            except ValueError:
                                pass
                        
                        # Check key IAM policy
                        key_iam = await run_gcloud_command([
                            "kms", "keys", "get-iam-policy", key_name,
                            f"--keyring={ring_name}",
                            f"--location={location}"
                        ], project_id)
                        
                        if isinstance(key_iam, dict):
                            bindings = key_iam.get("bindings", [])
                            for binding in bindings:
                                role = binding.get("role", "")
                                members = binding.get("members", [])
                                
                                # Check for overly permissive access
                                if "allUsers" in members or "allAuthenticatedUsers" in members:
                                    findings.append(self._create_finding(
                                        check_id="kms_public_access",
                                        resource_id=key.get("name", ""),
                                        resource_name=key_name,
                                        severity="critical",
                                        title="KMS key is publicly accessible",
                                        description=f"Key '{key_name}' has public access configured",
                                        recommendation="Remove public access from KMS keys",
                                        project_id=project_id,
                                    ))
                                
                                # Check for primitive roles
                                if role in ["roles/owner", "roles/editor"]:
                                    findings.append(self._create_finding(
                                        check_id="kms_primitive_role",
                                        resource_id=key.get("name", ""),
                                        resource_name=key_name,
                                        severity="medium",
                                        title="KMS key uses primitive IAM role",
                                        description=f"Key '{key_name}' uses primitive role '{role}'",
                                        recommendation="Use granular KMS roles instead of primitive roles",
                                        project_id=project_id,
                                    ))
        except Exception as e:
            logger.debug(f"Cloud KMS check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Pub/Sub Security Checks
    # =========================================================================
    
    async def check_pubsub_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Pub/Sub security.
        
        Checks:
        - Topic permissions
        - Subscription security
        - Message encryption
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # Check topics
            topics = await run_gcloud_command(["pubsub", "topics", "list"], project_id)
            if isinstance(topics, list):
                for topic in topics:
                    topic_name = topic.get("name", "").split("/")[-1]
                    
                    # Check topic IAM
                    topic_iam = await run_gcloud_command([
                        "pubsub", "topics", "get-iam-policy", topic_name
                    ], project_id)
                    
                    if isinstance(topic_iam, dict):
                        bindings = topic_iam.get("bindings", [])
                        for binding in bindings:
                            members = binding.get("members", [])
                            role = binding.get("role", "")
                            
                            if "allUsers" in members or "allAuthenticatedUsers" in members:
                                findings.append(self._create_finding(
                                    check_id="pubsub_topic_public",
                                    resource_id=topic.get("name", ""),
                                    resource_name=topic_name,
                                    severity="high",
                                    title="Pub/Sub topic is publicly accessible",
                                    description=f"Topic '{topic_name}' allows public access",
                                    recommendation="Remove public access and use specific service accounts",
                                    project_id=project_id,
                                ))
                    
                    # Check encryption
                    kms_key = topic.get("kmsKeyName", "")
                    if not kms_key:
                        findings.append(self._create_finding(
                            check_id="pubsub_no_cmek",
                            resource_id=topic.get("name", ""),
                            resource_name=topic_name,
                            severity="low",
                            title="Pub/Sub topic uses Google-managed encryption",
                            description=f"Topic '{topic_name}' does not use customer-managed encryption key",
                            recommendation="Configure CMEK for sensitive data topics",
                            project_id=project_id,
                        ))
            
            # Check subscriptions
            subscriptions = await run_gcloud_command(["pubsub", "subscriptions", "list"], project_id)
            if isinstance(subscriptions, list):
                for sub in subscriptions:
                    sub_name = sub.get("name", "").split("/")[-1]
                    
                    # Check message retention
                    retention = sub.get("messageRetentionDuration", "")
                    if retention:
                        try:
                            seconds = int(retention.rstrip("s"))
                            if seconds > 604800:  # > 7 days
                                findings.append(self._create_finding(
                                    check_id="pubsub_long_retention",
                                    resource_id=sub.get("name", ""),
                                    resource_name=sub_name,
                                    severity="low",
                                    title="Pub/Sub subscription has long message retention",
                                    description=f"Subscription '{sub_name}' retains messages for {seconds//86400} days",
                                    recommendation="Review retention period for compliance requirements",
                                    project_id=project_id,
                                ))
                        except ValueError:
                            pass
                    
                    # Check dead letter policy
                    dead_letter = sub.get("deadLetterPolicy", {})
                    if not dead_letter:
                        findings.append(self._create_finding(
                            check_id="pubsub_no_dead_letter",
                            resource_id=sub.get("name", ""),
                            resource_name=sub_name,
                            severity="low",
                            title="Pub/Sub subscription has no dead letter topic",
                            description=f"Subscription '{sub_name}' has no dead letter policy",
                            recommendation="Configure dead letter topic for failed message handling",
                            project_id=project_id,
                        ))
                    
                    # Check push endpoint security
                    push_config = sub.get("pushConfig", {})
                    push_endpoint = push_config.get("pushEndpoint", "")
                    if push_endpoint:
                        # Check for HTTP (not HTTPS)
                        if push_endpoint.startswith("http://"):
                            findings.append(self._create_finding(
                                check_id="pubsub_insecure_push",
                                resource_id=sub.get("name", ""),
                                resource_name=sub_name,
                                severity="high",
                                title="Pub/Sub subscription uses insecure push endpoint",
                                description=f"Subscription '{sub_name}' pushes to HTTP endpoint",
                                recommendation="Use HTTPS endpoint for push subscriptions",
                                project_id=project_id,
                            ))
        except Exception as e:
            logger.debug(f"Pub/Sub check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Artifact Registry Security Checks
    # =========================================================================
    
    async def check_artifact_registry_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Artifact Registry security.
        
        Checks:
        - Image scanning configuration
        - Access control policies
        - Repository policies
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List repositories
            repos = await run_gcloud_command([
                "artifacts", "repositories", "list",
                "--location=-"
            ], project_id)
            
            if isinstance(repos, list):
                for repo in repos:
                    repo_name = repo.get("name", "").split("/")[-1]
                    repo_format = repo.get("format", "")
                    location = repo.get("name", "").split("/")[3] if "/" in repo.get("name", "") else ""
                    
                    # Check repository IAM
                    repo_iam = await run_gcloud_command([
                        "artifacts", "repositories", "get-iam-policy", repo_name,
                        f"--location={location}"
                    ], project_id)
                    
                    if isinstance(repo_iam, dict):
                        bindings = repo_iam.get("bindings", [])
                        for binding in bindings:
                            members = binding.get("members", [])
                            role = binding.get("role", "")
                            
                            if "allUsers" in members or "allAuthenticatedUsers" in members:
                                findings.append(self._create_finding(
                                    check_id="artifact_registry_public",
                                    resource_id=repo.get("name", ""),
                                    resource_name=repo_name,
                                    severity="high" if "writer" in role.lower() else "medium",
                                    title="Artifact Registry repository is publicly accessible",
                                    description=f"Repository '{repo_name}' has public access with role '{role}'",
                                    recommendation="Remove public access and use specific service accounts",
                                    project_id=project_id,
                                ))
                    
                    # Check for Docker repositories - they should have vulnerability scanning
                    if repo_format == "DOCKER":
                        # Check if Container Analysis is enabled
                        # This is project-level but we report per-repo for visibility
                        findings.append(self._create_finding(
                            check_id="artifact_registry_scan_recommendation",
                            resource_id=repo.get("name", ""),
                            resource_name=repo_name,
                            severity="info",
                            title="Docker repository should have vulnerability scanning",
                            description=f"Repository '{repo_name}' is a Docker repository - ensure vulnerability scanning is enabled",
                            recommendation="Enable Container Analysis API and vulnerability scanning",
                            project_id=project_id,
                        ))
                    
                    # Check cleanup policies
                    cleanup_policies = repo.get("cleanupPolicies", {})
                    if not cleanup_policies:
                        findings.append(self._create_finding(
                            check_id="artifact_registry_no_cleanup",
                            resource_id=repo.get("name", ""),
                            resource_name=repo_name,
                            severity="low",
                            title="Artifact Registry repository has no cleanup policy",
                            description=f"Repository '{repo_name}' has no automatic cleanup configured",
                            recommendation="Configure cleanup policies to remove old/unused artifacts",
                            project_id=project_id,
                        ))
        except Exception as e:
            logger.debug(f"Artifact Registry check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Workflows Security Checks
    # =========================================================================
    
    async def check_cloud_workflows_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Workflows security.
        
        Checks:
        - Workflow service account permissions
        - External call targets
        - Secret usage
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List workflows
            workflows = await run_gcloud_command([
                "workflows", "list",
                "--location=-"
            ], project_id)
            
            if isinstance(workflows, list):
                for workflow in workflows:
                    workflow_name = workflow.get("name", "").split("/")[-1]
                    service_account = workflow.get("serviceAccount", "")
                    
                    # Check service account
                    if not service_account or "compute@developer" in service_account:
                        findings.append(self._create_finding(
                            check_id="workflow_default_sa",
                            resource_id=workflow.get("name", ""),
                            resource_name=workflow_name,
                            severity="medium",
                            title="Cloud Workflow uses default service account",
                            description=f"Workflow '{workflow_name}' uses default Compute Engine service account",
                            recommendation="Create a dedicated service account with minimal permissions",
                            project_id=project_id,
                        ))
                    
                    # Check workflow source for potential issues
                    source = workflow.get("sourceContents", "")
                    if source:
                        # Check for hardcoded secrets
                        for pattern_name, pattern in SECRET_PATTERNS.items():
                            if pattern.search(source):
                                findings.append(self._create_finding(
                                    check_id="workflow_hardcoded_secrets",
                                    resource_id=workflow.get("name", ""),
                                    resource_name=workflow_name,
                                    severity="critical",
                                    title="Potential secrets in workflow definition",
                                    description=f"Workflow '{workflow_name}' may contain hardcoded {pattern_name}",
                                    recommendation="Use Secret Manager connector instead of hardcoded secrets",
                                    project_id=project_id,
                                ))
                        
                        # Check for HTTP calls to non-Google APIs
                        if "http.get" in source.lower() or "http.post" in source.lower():
                            if "googleapis.com" not in source:
                                findings.append(self._create_finding(
                                    check_id="workflow_external_calls",
                                    resource_id=workflow.get("name", ""),
                                    resource_name=workflow_name,
                                    severity="info",
                                    title="Workflow makes external HTTP calls",
                                    description=f"Workflow '{workflow_name}' contains HTTP calls to external services",
                                    recommendation="Review external service calls for security implications",
                                    project_id=project_id,
                                ))
        except Exception as e:
            logger.debug(f"Cloud Workflows check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Tasks Security Checks
    # =========================================================================
    
    async def check_cloud_tasks_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Tasks security.
        
        Checks:
        - Queue permissions
        - Task targets
        - Rate limiting
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List task queues
            queues = await run_gcloud_command([
                "tasks", "queues", "list",
                "--location=-"
            ], project_id)
            
            if isinstance(queues, list):
                for queue in queues:
                    queue_name = queue.get("name", "").split("/")[-1]
                    location = queue.get("name", "").split("/")[3] if "/" in queue.get("name", "") else ""
                    
                    # Check rate limits
                    rate_limits = queue.get("rateLimits", {})
                    max_dispatches = rate_limits.get("maxDispatchesPerSecond", 0)
                    max_concurrent = rate_limits.get("maxConcurrentDispatches", 0)
                    
                    if max_dispatches > 1000 or max_concurrent > 1000:
                        findings.append(self._create_finding(
                            check_id="tasks_high_rate_limit",
                            resource_id=queue.get("name", ""),
                            resource_name=queue_name,
                            severity="info",
                            title="Cloud Tasks queue has high rate limits",
                            description=f"Queue '{queue_name}' allows {max_dispatches} dispatches/sec",
                            recommendation="Review rate limits to prevent resource exhaustion",
                            project_id=project_id,
                        ))
                    
                    # Check queue IAM
                    queue_iam = await run_gcloud_command([
                        "tasks", "queues", "get-iam-policy", queue_name,
                        f"--location={location}"
                    ], project_id)
                    
                    if isinstance(queue_iam, dict):
                        bindings = queue_iam.get("bindings", [])
                        for binding in bindings:
                            members = binding.get("members", [])
                            
                            if "allUsers" in members or "allAuthenticatedUsers" in members:
                                findings.append(self._create_finding(
                                    check_id="tasks_queue_public",
                                    resource_id=queue.get("name", ""),
                                    resource_name=queue_name,
                                    severity="high",
                                    title="Cloud Tasks queue is publicly accessible",
                                    description=f"Queue '{queue_name}' has public access",
                                    recommendation="Remove public access and use specific service accounts",
                                    project_id=project_id,
                                ))
        except Exception as e:
            logger.debug(f"Cloud Tasks check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Armor Security Checks
    # =========================================================================
    
    async def check_cloud_armor_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Armor security.
        
        Checks:
        - Security policy configuration
        - WAF rules
        - Rate limiting rules
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List security policies
            policies = await run_gcloud_command([
                "compute", "security-policies", "list"
            ], project_id)
            
            if isinstance(policies, list):
                for policy in policies:
                    policy_name = policy.get("name", "")
                    
                    # Get policy details
                    policy_detail = await run_gcloud_command([
                        "compute", "security-policies", "describe", policy_name
                    ], project_id)
                    
                    if isinstance(policy_detail, dict):
                        rules = policy_detail.get("rules", [])
                        
                        has_rate_limiting = False
                        has_waf_rules = False
                        has_default_deny = False
                        
                        for rule in rules:
                            action = rule.get("action", "")
                            priority = rule.get("priority", 0)
                            
                            # Check for rate limiting
                            rate_limit = rule.get("rateLimitOptions", {})
                            if rate_limit:
                                has_rate_limiting = True
                            
                            # Check for WAF rules (preconfigured)
                            match = rule.get("match", {})
                            expr = match.get("expr", {})
                            expression = expr.get("expression", "")
                            if "evaluatePreconfiguredWaf" in expression:
                                has_waf_rules = True
                            
                            # Check default rule
                            if priority == 2147483647:  # Default rule
                                if action == "deny(403)":
                                    has_default_deny = True
                        
                        if not has_rate_limiting:
                            findings.append(self._create_finding(
                                check_id="armor_no_rate_limiting",
                                resource_id=policy.get("selfLink", ""),
                                resource_name=policy_name,
                                severity="medium",
                                title="Cloud Armor policy has no rate limiting",
                                description=f"Security policy '{policy_name}' does not have rate limiting rules",
                                recommendation="Configure rate limiting rules to prevent DoS attacks",
                                project_id=project_id,
                            ))
                        
                        if not has_waf_rules:
                            findings.append(self._create_finding(
                                check_id="armor_no_waf_rules",
                                resource_id=policy.get("selfLink", ""),
                                resource_name=policy_name,
                                severity="medium",
                                title="Cloud Armor policy has no WAF rules",
                                description=f"Security policy '{policy_name}' does not use preconfigured WAF rules",
                                recommendation="Enable OWASP Top 10 and other WAF rules",
                                project_id=project_id,
                            ))
                        
                        if not has_default_deny:
                            findings.append(self._create_finding(
                                check_id="armor_no_default_deny",
                                resource_id=policy.get("selfLink", ""),
                                resource_name=policy_name,
                                severity="low",
                                title="Cloud Armor policy has allow-by-default",
                                description=f"Security policy '{policy_name}' allows traffic by default",
                                recommendation="Consider deny-by-default policy for stricter security",
                                project_id=project_id,
                            ))
            else:
                # No Cloud Armor policies
                findings.append(self._create_finding(
                    check_id="armor_not_configured",
                    resource_id=f"projects/{project_id}",
                    resource_name=project_id,
                    severity="info",
                    title="Cloud Armor is not configured",
                    description=f"Project '{project_id}' has no Cloud Armor security policies",
                    recommendation="Consider using Cloud Armor for web application firewall protection",
                    project_id=project_id,
                ))
        except Exception as e:
            logger.debug(f"Cloud Armor check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Load Balancing Security Checks
    # =========================================================================
    
    async def check_load_balancer_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud Load Balancing security.
        
        Checks:
        - SSL/TLS configuration
        - Security policy attachment
        - Backend service security
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # Check HTTPS target proxies
            https_proxies = await run_gcloud_command([
                "compute", "target-https-proxies", "list"
            ], project_id)
            
            if isinstance(https_proxies, list):
                for proxy in https_proxies:
                    proxy_name = proxy.get("name", "")
                    ssl_policy = proxy.get("sslPolicy", "")
                    
                    if not ssl_policy:
                        findings.append(self._create_finding(
                            check_id="lb_no_ssl_policy",
                            resource_id=proxy.get("selfLink", ""),
                            resource_name=proxy_name,
                            severity="medium",
                            title="Load balancer has no custom SSL policy",
                            description=f"HTTPS proxy '{proxy_name}' uses default SSL policy",
                            recommendation="Configure custom SSL policy with modern TLS settings",
                            project_id=project_id,
                        ))
                    else:
                        # Check SSL policy details
                        policy_name = ssl_policy.split("/")[-1]
                        ssl_policy_detail = await run_gcloud_command([
                            "compute", "ssl-policies", "describe", policy_name
                        ], project_id)
                        
                        if isinstance(ssl_policy_detail, dict):
                            min_tls = ssl_policy_detail.get("minTlsVersion", "")
                            profile = ssl_policy_detail.get("profile", "")
                            
                            if min_tls in ["TLS_1_0", "TLS_1_1"]:
                                findings.append(self._create_finding(
                                    check_id="lb_weak_tls",
                                    resource_id=proxy.get("selfLink", ""),
                                    resource_name=proxy_name,
                                    severity="high",
                                    title="Load balancer allows weak TLS versions",
                                    description=f"HTTPS proxy '{proxy_name}' allows {min_tls}",
                                    recommendation="Configure minimum TLS 1.2 or higher",
                                    project_id=project_id,
                                ))
            
            # Check backend services for security policy
            backends = await run_gcloud_command([
                "compute", "backend-services", "list"
            ], project_id)
            
            if isinstance(backends, list):
                for backend in backends:
                    backend_name = backend.get("name", "")
                    security_policy = backend.get("securityPolicy", "")
                    
                    if not security_policy:
                        findings.append(self._create_finding(
                            check_id="lb_backend_no_armor",
                            resource_id=backend.get("selfLink", ""),
                            resource_name=backend_name,
                            severity="medium",
                            title="Backend service has no Cloud Armor policy",
                            description=f"Backend service '{backend_name}' has no security policy attached",
                            recommendation="Attach Cloud Armor security policy for WAF protection",
                            project_id=project_id,
                        ))
                    
                    # Check for logging
                    log_config = backend.get("logConfig", {})
                    if not log_config.get("enable", False):
                        findings.append(self._create_finding(
                            check_id="lb_backend_no_logging",
                            resource_id=backend.get("selfLink", ""),
                            resource_name=backend_name,
                            severity="low",
                            title="Backend service logging is disabled",
                            description=f"Backend service '{backend_name}' does not have logging enabled",
                            recommendation="Enable logging for security monitoring",
                            project_id=project_id,
                        ))
        except Exception as e:
            logger.debug(f"Load balancer check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud DNS Security Checks
    # =========================================================================
    
    async def check_cloud_dns_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Cloud DNS security.
        
        Checks:
        - DNSSEC configuration
        - Zone permissions
        - DNS logging
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List managed zones
            zones = await run_gcloud_command(["dns", "managed-zones", "list"], project_id)
            
            if isinstance(zones, list):
                for zone in zones:
                    zone_name = zone.get("name", "")
                    dns_name = zone.get("dnsName", "")
                    visibility = zone.get("visibility", "")
                    
                    # Check DNSSEC for public zones
                    if visibility == "public":
                        dnssec_config = zone.get("dnssecConfig", {})
                        dnssec_state = dnssec_config.get("state", "")
                        
                        if dnssec_state != "on":
                            findings.append(self._create_finding(
                                check_id="dns_no_dnssec",
                                resource_id=zone.get("id", ""),
                                resource_name=zone_name,
                                severity="medium",
                                title="Public DNS zone has DNSSEC disabled",
                                description=f"DNS zone '{zone_name}' ({dns_name}) does not have DNSSEC enabled",
                                recommendation="Enable DNSSEC for public DNS zones to prevent DNS spoofing",
                                project_id=project_id,
                            ))
                    
                    # Check zone IAM
                    zone_iam = await run_gcloud_command([
                        "dns", "managed-zones", "get-iam-policy", zone_name
                    ], project_id)
                    
                    if isinstance(zone_iam, dict):
                        bindings = zone_iam.get("bindings", [])
                        for binding in bindings:
                            members = binding.get("members", [])
                            role = binding.get("role", "")
                            
                            if "allUsers" in members or "allAuthenticatedUsers" in members:
                                severity = "critical" if "admin" in role.lower() or "writer" in role.lower() else "high"
                                findings.append(self._create_finding(
                                    check_id="dns_zone_public_access",
                                    resource_id=zone.get("id", ""),
                                    resource_name=zone_name,
                                    severity=severity,
                                    title="DNS zone has public IAM access",
                                    description=f"DNS zone '{zone_name}' has public access with role '{role}'",
                                    recommendation="Remove public access from DNS zones",
                                    project_id=project_id,
                                ))
            
            # Check DNS policies for logging
            policies = await run_gcloud_command(["dns", "policies", "list"], project_id)
            if not isinstance(policies, list) or len(policies) == 0:
                findings.append(self._create_finding(
                    check_id="dns_no_policy",
                    resource_id=f"projects/{project_id}",
                    resource_name=project_id,
                    severity="low",
                    title="No DNS policies configured",
                    description=f"Project '{project_id}' has no DNS policies for logging/forwarding",
                    recommendation="Consider configuring DNS policies for logging and security",
                    project_id=project_id,
                ))
            else:
                for policy in policies:
                    policy_name = policy.get("name", "")
                    enable_logging = policy.get("enableLogging", False)
                    
                    if not enable_logging:
                        findings.append(self._create_finding(
                            check_id="dns_policy_no_logging",
                            resource_id=policy.get("id", ""),
                            resource_name=policy_name,
                            severity="low",
                            title="DNS policy logging is disabled",
                            description=f"DNS policy '{policy_name}' does not have logging enabled",
                            recommendation="Enable DNS logging for security monitoring",
                            project_id=project_id,
                        ))
        except Exception as e:
            logger.debug(f"Cloud DNS check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud Storage Extended Security Checks
    # =========================================================================
    
    async def check_storage_extended_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check extended Cloud Storage security.
        
        Checks:
        - CORS configuration
        - Lifecycle rules
        - Versioning
        - Logging
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # List buckets
            buckets = await run_gcloud_command(["storage", "buckets", "list"], project_id)
            
            if isinstance(buckets, list):
                for bucket in buckets:
                    bucket_name = bucket.get("name", "")
                    
                    # Get bucket details
                    bucket_detail = await run_gcloud_command([
                        "storage", "buckets", "describe", f"gs://{bucket_name}"
                    ], project_id)
                    
                    if isinstance(bucket_detail, dict):
                        # Check CORS
                        cors = bucket_detail.get("cors", [])
                        for cors_rule in cors:
                            origins = cors_rule.get("origin", [])
                            if "*" in origins:
                                findings.append(self._create_finding(
                                    check_id="storage_cors_wildcard",
                                    resource_id=f"gs://{bucket_name}",
                                    resource_name=bucket_name,
                                    severity="medium",
                                    title="Storage bucket has wildcard CORS",
                                    description=f"Bucket '{bucket_name}' allows CORS from any origin",
                                    recommendation="Restrict CORS to specific trusted origins",
                                    project_id=project_id,
                                ))
                        
                        # Check versioning
                        versioning = bucket_detail.get("versioning", {})
                        if not versioning.get("enabled", False):
                            findings.append(self._create_finding(
                                check_id="storage_no_versioning",
                                resource_id=f"gs://{bucket_name}",
                                resource_name=bucket_name,
                                severity="low",
                                title="Storage bucket versioning is disabled",
                                description=f"Bucket '{bucket_name}' does not have versioning enabled",
                                recommendation="Enable versioning for data recovery and compliance",
                                project_id=project_id,
                            ))
                        
                        # Check lifecycle rules
                        lifecycle = bucket_detail.get("lifecycle", {})
                        if not lifecycle.get("rule", []):
                            findings.append(self._create_finding(
                                check_id="storage_no_lifecycle",
                                resource_id=f"gs://{bucket_name}",
                                resource_name=bucket_name,
                                severity="info",
                                title="Storage bucket has no lifecycle rules",
                                description=f"Bucket '{bucket_name}' has no lifecycle management configured",
                                recommendation="Configure lifecycle rules for cost optimization and data retention",
                                project_id=project_id,
                            ))
                        
                        # Check logging
                        logging_config = bucket_detail.get("logging", {})
                        if not logging_config.get("logBucket"):
                            findings.append(self._create_finding(
                                check_id="storage_no_logging",
                                resource_id=f"gs://{bucket_name}",
                                resource_name=bucket_name,
                                severity="low",
                                title="Storage bucket access logging is disabled",
                                description=f"Bucket '{bucket_name}' does not have access logging enabled",
                                recommendation="Enable access logging for audit and compliance",
                                project_id=project_id,
                            ))
                        
                        # Check retention policy
                        retention = bucket_detail.get("retentionPolicy", {})
                        if not retention:
                            # Only flag for sensitive data buckets (heuristic based on name)
                            sensitive_keywords = ["sensitive", "pii", "confidential", "secure", "backup", "archive"]
                            if any(kw in bucket_name.lower() for kw in sensitive_keywords):
                                findings.append(self._create_finding(
                                    check_id="storage_no_retention",
                                    resource_id=f"gs://{bucket_name}",
                                    resource_name=bucket_name,
                                    severity="medium",
                                    title="Sensitive bucket has no retention policy",
                                    description=f"Bucket '{bucket_name}' appears to contain sensitive data but has no retention policy",
                                    recommendation="Configure retention policy for compliance",
                                    project_id=project_id,
                                ))
        except Exception as e:
            logger.debug(f"Storage extended check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud SQL Extended Security Checks
    # =========================================================================
    
    async def check_sql_extended_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check extended Cloud SQL security.
        
        Checks:
        - Database flags security
        - Backup security
        - Maintenance window
        - Insights configuration
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Insecure database flags
        INSECURE_FLAGS = {
            "log_min_messages": {"insecure": ["debug5", "debug4", "debug3", "debug2", "debug1"], "secure": ["warning", "error", "fatal"]},
            "log_connections": {"insecure": ["off"], "secure": ["on"]},
            "log_disconnections": {"insecure": ["off"], "secure": ["on"]},
            "log_checkpoints": {"insecure": ["off"], "secure": ["on"]},
            "log_lock_waits": {"insecure": ["off"], "secure": ["on"]},
            "local_infile": {"insecure": ["on"], "secure": ["off"]},  # MySQL
            "skip_show_database": {"insecure": ["off"], "secure": ["on"]},  # MySQL
        }
        
        try:
            # List SQL instances
            instances = await run_gcloud_command(["sql", "instances", "list"], project_id)
            
            if isinstance(instances, list):
                for instance in instances:
                    instance_name = instance.get("name", "")
                    database_version = instance.get("databaseVersion", "")
                    
                    # Get instance details
                    instance_detail = await run_gcloud_command([
                        "sql", "instances", "describe", instance_name
                    ], project_id)
                    
                    if isinstance(instance_detail, dict):
                        settings = instance_detail.get("settings", {})
                        
                        # Check database flags
                        database_flags = settings.get("databaseFlags", [])
                        flag_dict = {f.get("name"): f.get("value") for f in database_flags}
                        
                        for flag_name, config in INSECURE_FLAGS.items():
                            flag_value = flag_dict.get(flag_name, "").lower()
                            if flag_value in config["insecure"]:
                                findings.append(self._create_finding(
                                    check_id=f"sql_insecure_flag_{flag_name}",
                                    resource_id=instance.get("selfLink", ""),
                                    resource_name=instance_name,
                                    severity="medium",
                                    title=f"Cloud SQL has insecure database flag",
                                    description=f"Instance '{instance_name}' has insecure flag '{flag_name}={flag_value}'",
                                    recommendation=f"Set {flag_name} to one of: {config['secure']}",
                                    project_id=project_id,
                                ))
                        
                        # Check backup configuration
                        backup_config = settings.get("backupConfiguration", {})
                        if not backup_config.get("enabled", False):
                            findings.append(self._create_finding(
                                check_id="sql_no_backup",
                                resource_id=instance.get("selfLink", ""),
                                resource_name=instance_name,
                                severity="high",
                                title="Cloud SQL instance has no automated backups",
                                description=f"Instance '{instance_name}' does not have automated backups enabled",
                                recommendation="Enable automated backups for disaster recovery",
                                project_id=project_id,
                            ))
                        
                        if not backup_config.get("pointInTimeRecoveryEnabled", False):
                            findings.append(self._create_finding(
                                check_id="sql_no_pitr",
                                resource_id=instance.get("selfLink", ""),
                                resource_name=instance_name,
                                severity="medium",
                                title="Cloud SQL instance has no point-in-time recovery",
                                description=f"Instance '{instance_name}' does not have PITR enabled",
                                recommendation="Enable point-in-time recovery for better data protection",
                                project_id=project_id,
                            ))
                        
                        # Check maintenance window
                        maintenance = settings.get("maintenanceWindow", {})
                        if not maintenance:
                            findings.append(self._create_finding(
                                check_id="sql_no_maintenance_window",
                                resource_id=instance.get("selfLink", ""),
                                resource_name=instance_name,
                                severity="low",
                                title="Cloud SQL instance has no maintenance window",
                                description=f"Instance '{instance_name}' uses default maintenance window",
                                recommendation="Configure maintenance window to minimize disruption",
                                project_id=project_id,
                            ))
                        
                        # Check insights
                        insights_config = settings.get("insightsConfig", {})
                        if not insights_config.get("queryInsightsEnabled", False):
                            findings.append(self._create_finding(
                                check_id="sql_no_query_insights",
                                resource_id=instance.get("selfLink", ""),
                                resource_name=instance_name,
                                severity="info",
                                title="Cloud SQL Query Insights is disabled",
                                description=f"Instance '{instance_name}' does not have Query Insights enabled",
                                recommendation="Enable Query Insights for performance monitoring",
                                project_id=project_id,
                            ))
        except Exception as e:
            logger.debug(f"SQL extended check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Cloud IAM Extended Security Checks
    # =========================================================================
    
    async def check_iam_extended_security(
        self,
        project_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check extended Cloud IAM security.
        
        Checks:
        - Organization policies
        - Workload identity federation
        - Resource hierarchy security
        
        Args:
            project_id: GCP project ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # Check organization policies
            org_policies = await run_gcloud_command([
                "resource-manager", "org-policies", "list",
                f"--project={project_id}"
            ], project_id)
            
            # Important org policies to check
            IMPORTANT_POLICIES = {
                "constraints/iam.disableServiceAccountKeyCreation": "Disable SA key creation",
                "constraints/iam.disableServiceAccountCreation": "Disable SA creation",
                "constraints/compute.requireOsLogin": "Require OS Login",
                "constraints/compute.disableSerialPortAccess": "Disable serial port",
                "constraints/storage.uniformBucketLevelAccess": "Uniform bucket access",
            }
            
            if isinstance(org_policies, list):
                policy_names = [p.get("constraint", "") for p in org_policies]
                
                for constraint, description in IMPORTANT_POLICIES.items():
                    if constraint not in policy_names:
                        findings.append(self._create_finding(
                            check_id=f"iam_missing_policy_{constraint.split('/')[-1]}",
                            resource_id=f"projects/{project_id}",
                            resource_name=project_id,
                            severity="info",
                            title=f"Organization policy not configured: {description}",
                            description=f"Project '{project_id}' does not have '{constraint}' configured",
                            recommendation=f"Consider enabling organization policy '{constraint}'",
                            project_id=project_id,
                        ))
            
            # Check workload identity pools
            try:
                pools = await run_gcloud_command([
                    "iam", "workload-identity-pools", "list",
                    "--location=global"
                ], project_id)
                
                if isinstance(pools, list):
                    for pool in pools:
                        pool_name = pool.get("name", "").split("/")[-1]
                        
                        # Check pool providers
                        providers = await run_gcloud_command([
                            "iam", "workload-identity-pools", "providers", "list",
                            f"--workload-identity-pool={pool_name}",
                            "--location=global"
                        ], project_id)
                        
                        if isinstance(providers, list):
                            for provider in providers:
                                provider_name = provider.get("name", "").split("/")[-1]
                                
                                # Check attribute condition
                                attribute_condition = provider.get("attributeCondition", "")
                                if not attribute_condition:
                                    findings.append(self._create_finding(
                                        check_id="iam_wif_no_condition",
                                        resource_id=provider.get("name", ""),
                                        resource_name=provider_name,
                                        severity="high",
                                        title="Workload identity provider has no attribute condition",
                                        description=f"Provider '{provider_name}' in pool '{pool_name}' has no attribute condition",
                                        recommendation="Add attribute condition to restrict which identities can authenticate",
                                        project_id=project_id,
                                    ))
            except Exception:
                pass  # Workload identity might not be available
        except Exception as e:
            logger.debug(f"IAM extended check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _create_finding(
        self,
        check_id: str,
        resource_id: str,
        resource_name: str,
        severity: str,
        title: str,
        description: str,
        recommendation: str,
        project_id: str,
    ) -> Dict[str, Any]:
        """Create a finding dictionary."""
        return {
            "check_id": check_id,
            "resource_id": resource_id,
            "resource_name": resource_name,
            "severity": severity,
            "title": title,
            "description": description,
            "recommendation": recommendation,
            "project_id": project_id,
        }
    
    async def run_all_checks(
        self,
        project_id: str,
        options: ScanOptions
    ) -> List[Dict[str, Any]]:
        """
        Run all additional GCP service checks.
        
        Args:
            project_id: GCP project ID
            options: Scan options
            
        Returns:
            Aggregated list of all findings
        """
        all_findings = []
        check = {}  # Empty check dict for compatibility
        
        # Cloud Build
        findings = await self.check_cloud_build_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Cloud KMS
        findings = await self.check_cloud_kms_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Pub/Sub
        findings = await self.check_pubsub_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Artifact Registry
        findings = await self.check_artifact_registry_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Cloud Workflows
        findings = await self.check_cloud_workflows_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Cloud Tasks
        findings = await self.check_cloud_tasks_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Cloud Armor
        findings = await self.check_cloud_armor_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Load Balancer
        findings = await self.check_load_balancer_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Cloud DNS
        findings = await self.check_cloud_dns_security(project_id, check, options)
        all_findings.extend(findings)
        
        # Storage Extended
        findings = await self.check_storage_extended_security(project_id, check, options)
        all_findings.extend(findings)
        
        # SQL Extended
        findings = await self.check_sql_extended_security(project_id, check, options)
        all_findings.extend(findings)
        
        # IAM Extended
        findings = await self.check_iam_extended_security(project_id, check, options)
        all_findings.extend(findings)
        
        return all_findings

