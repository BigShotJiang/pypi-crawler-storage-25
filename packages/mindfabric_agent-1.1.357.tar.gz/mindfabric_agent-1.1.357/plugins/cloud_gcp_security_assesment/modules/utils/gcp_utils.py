"""
GCP Security Assessment Utilities

Helper functions for GCP API calls, IAM analysis, secret detection, etc.
"""

import json
import logging
import re
import asyncio
from typing import Any, Dict, List, Optional, Tuple

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from utils.async_subprocess import run_exec_stdout

from ...proto import (
    SecuritySubCategory,
    SeverityLevel,
    MitreAttackReference,
    ComplianceMapping,
    ComplianceFramework,
    IAMBinding,
)
from ..databases import MITRE_MAPPING, CIS_GCP_MAPPING, SECRET_PATTERNS

logger = logging.getLogger(__name__)


async def run_gcloud_command(args: List[str], project_id: Optional[str] = None) -> Any:
    """Execute a gcloud command and return JSON output."""
    cmd = ["gcloud"] + args + ["--format=json"]
    if project_id:
        cmd.extend(["--project", project_id])
    
    try:
        out = await run_exec_stdout(cmd, timeout=60)
        if not out or not out.strip():
            return {}
        try:
            return json.loads(out)
        except json.JSONDecodeError:
            logger.error("Failed to parse gcloud output as JSON")
            return {}
    except asyncio.TimeoutError:
        logger.error(f"gcloud command timed out: {' '.join(cmd)}")
        return {}
    except Exception as e:
        logger.error(f"gcloud command error: {e}")
        return {}


async def run_gsutil_command(args: List[str]) -> str:
    """Execute a gsutil command and return output."""
    cmd = ["gsutil"] + args
    try:
        return (await run_exec_stdout(cmd, timeout=60)) or ""
    except Exception as e:
        logger.error(f"gsutil command error: {e}")
        return ""


def get_mitre_reference(sub_category: SecuritySubCategory) -> Optional[MitreAttackReference]:
    """Get MITRE ATT&CK reference for subcategory."""
    mapping = MITRE_MAPPING.get(sub_category)
    if not mapping:
        return None
    
    url = f"https://attack.mitre.org/techniques/{mapping['technique_id']}"
    if mapping.get("sub_technique_id"):
        url = f"https://attack.mitre.org/techniques/{mapping['technique_id']}/{mapping['sub_technique_id'].split('.')[1]}"
    
    return MitreAttackReference(
        tactic=mapping["tactic"],
        technique_id=mapping["technique_id"],
        technique_name=mapping["technique_name"],
        sub_technique_id=mapping.get("sub_technique_id"),
        sub_technique_name=mapping.get("sub_technique_name"),
        url=url
    )


def get_compliance_mappings(sub_category: SecuritySubCategory) -> List[ComplianceMapping]:
    """Get compliance framework mappings for subcategory."""
    mappings = []
    
    cis_mapping = CIS_GCP_MAPPING.get(sub_category)
    if cis_mapping:
        mappings.append(ComplianceMapping(
            framework=ComplianceFramework.CIS_GCP,
            control_id=cis_mapping["control_id"],
            control_name=cis_mapping["control_name"]
        ))
    
    return mappings


def analyze_iam_binding(binding: Dict[str, Any]) -> IAMBinding:
    """Analyze an IAM binding for security issues."""
    role = binding.get("role", "")
    members = binding.get("members", [])
    condition = binding.get("condition")
    
    # Check for primitive roles
    is_primitive = role in ["roles/owner", "roles/editor", "roles/viewer"]
    
    # Check for public access
    has_public = any(m in ["allUsers", "allAuthenticatedUsers"] for m in members)
    
    # Extract external members
    external_members = []
    service_accounts = []
    
    for member in members:
        if member.startswith("serviceAccount:"):
            service_accounts.append(member)
        elif "@" in member and not member.endswith(".gserviceaccount.com"):
            external_members.append(member)
    
    return IAMBinding(
        role=role,
        members=members,
        condition=condition,
        is_primitive_role=is_primitive,
        has_public_access=has_public,
        external_members=external_members if external_members else None,
        service_accounts=service_accounts if service_accounts else None
    )


def check_content_for_secrets(content: str) -> List[Tuple[str, str]]:
    """Check content for potential secrets."""
    findings = []
    for pattern, secret_type in SECRET_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
            findings.append((pattern, secret_type))
    return findings


def calculate_risk_score(severity: SeverityLevel, exploitability: str, impact_scope: str) -> float:
    """Calculate risk score based on multiple factors."""
    severity_weights = {
        SeverityLevel.CRITICAL: 9.0,
        SeverityLevel.HIGH: 7.0,
        SeverityLevel.MEDIUM: 5.0,
        SeverityLevel.LOW: 3.0,
        SeverityLevel.INFO: 1.0,
    }
    
    exploitability_multiplier = {
        "easy": 1.0,
        "medium": 0.8,
        "hard": 0.6,
    }
    
    scope_multiplier = {
        "organization": 1.2,
        "project": 1.0,
        "resource": 0.8,
    }
    
    base_score = severity_weights.get(severity, 5.0)
    exp_mult = exploitability_multiplier.get(exploitability, 0.8)
    scope_mult = scope_multiplier.get(impact_scope, 1.0)
    
    return min(10.0, base_score * exp_mult * scope_mult)

