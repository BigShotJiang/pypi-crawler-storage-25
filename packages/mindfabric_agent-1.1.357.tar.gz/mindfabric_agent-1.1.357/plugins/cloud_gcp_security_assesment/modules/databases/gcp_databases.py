"""
GCP Security Assessment Databases

Stores all static data: MITRE mappings, compliance mappings, check definitions,
dangerous permissions, and secret patterns.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Any, Dict, List, Tuple
from ...proto import (
    SecuritySubCategory,
    SecurityCategory,
    GCPResourceType,
    SeverityLevel,
)

# MITRE_MAPPING is imported from the main file to avoid duplication
# We'll copy it here during refactoring

MITRE_MAPPING: Dict[SecuritySubCategory, Dict[str, Any]] = {
    # IAM Issues
    SecuritySubCategory.OVERLY_PERMISSIVE_IAM: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
        "sub_technique_id": "T1078.004",
        "sub_technique_name": "Cloud Accounts",
    },
    SecuritySubCategory.PUBLIC_ACCESS: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.SERVICE_ACCOUNT_ABUSE: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
        "sub_technique_id": "T1078.004",
        "sub_technique_name": "Cloud Accounts",
    },
    SecuritySubCategory.KEY_MANAGEMENT: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
        "sub_technique_id": "T1552.005",
        "sub_technique_name": "Cloud Instance Metadata API",
    },
    SecuritySubCategory.PRIVILEGE_ESCALATION_PATH: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1548",
        "technique_name": "Abuse Elevation Control Mechanism",
    },
    # Compute Issues
    SecuritySubCategory.PUBLIC_VM: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.METADATA_EXPOSURE: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
        "sub_technique_id": "T1552.005",
        "sub_technique_name": "Cloud Instance Metadata API",
    },
    SecuritySubCategory.STARTUP_SCRIPT_SECRETS: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
    },
    # Network Issues
    SecuritySubCategory.OPEN_FIREWALL: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    # Storage Issues
    SecuritySubCategory.PUBLIC_BUCKET: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # Database Issues
    SecuritySubCategory.PUBLIC_DATABASE: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # GKE Issues
    SecuritySubCategory.LEGACY_ABAC: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
    },
    SecuritySubCategory.PRIVILEGED_POD: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1611",
        "technique_name": "Escape to Host",
    },
    # Logging Issues
    SecuritySubCategory.AUDIT_LOGS_DISABLED: {
        "tactic": "Defense Evasion",
        "technique_id": "T1562",
        "technique_name": "Impair Defenses",
        "sub_technique_id": "T1562.008",
        "sub_technique_name": "Disable Cloud Logs",
    },
    # Secrets Issues
    SecuritySubCategory.HARDCODED_CREDENTIALS: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
        "sub_technique_id": "T1552.001",
        "sub_technique_name": "Credentials In Files",
    },
    # Persistence
    SecuritySubCategory.SCHEDULED_PERSISTENCE: {
        "tactic": "Persistence",
        "technique_id": "T1053",
        "technique_name": "Scheduled Task/Job",
    },
    SecuritySubCategory.FUNCTION_PERSISTENCE: {
        "tactic": "Persistence",
        "technique_id": "T1525",
        "technique_name": "Implant Internal Image",
    },
    # Exfiltration
    SecuritySubCategory.DATA_TRANSFER_RISK: {
        "tactic": "Exfiltration",
        "technique_id": "T1537",
        "technique_name": "Transfer Data to Cloud Account",
    },
}

CIS_GCP_MAPPING: Dict[SecuritySubCategory, Dict[str, str]] = {
    SecuritySubCategory.PUBLIC_BUCKET: {
        "control_id": "5.1",
        "control_name": "Ensure Cloud Storage bucket is not publicly accessible",
    },
    SecuritySubCategory.OVERLY_PERMISSIVE_IAM: {
        "control_id": "1.4",
        "control_name": "Ensure no root service account is used",
    },
    SecuritySubCategory.AUDIT_LOGS_DISABLED: {
        "control_id": "2.1",
        "control_name": "Ensure Cloud Audit Logging is configured properly",
    },
    SecuritySubCategory.KEY_MANAGEMENT: {
        "control_id": "1.7",
        "control_name": "Ensure service account keys are rotated within 90 days",
    },
    SecuritySubCategory.OPEN_FIREWALL: {
        "control_id": "3.6",
        "control_name": "Ensure SSH access is restricted from the internet",
    },
    SecuritySubCategory.PUBLIC_DATABASE: {
        "control_id": "6.5",
        "control_name": "Ensure Cloud SQL database instance does not have public IP",
    },
    SecuritySubCategory.LEGACY_ABAC: {
        "control_id": "7.3",
        "control_name": "Ensure Legacy Authorization is disabled on GKE clusters",
    },
    SecuritySubCategory.SHIELDED_VM_DISABLED: {
        "control_id": "4.8",
        "control_name": "Ensure Shielded GKE nodes are enabled",
    },
}

GCP_CHECKS: List[Dict[str, Any]] = [
    # IAM Checks
    {
        "id": "iam_primitive_roles",
        "name": "Primitive Roles Usage",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OVERLY_PERMISSIVE_IAM,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.IAM_POLICY],
        "check_fn": "check_primitive_roles",
    },
    {
        "id": "iam_public_access",
        "name": "Public IAM Access",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.PUBLIC_ACCESS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.IAM_POLICY],
        "check_fn": "check_public_iam_access",
    },
    {
        "id": "iam_owner_role",
        "name": "Owner Role Assignment",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OVERLY_PERMISSIVE_IAM,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.IAM_POLICY],
        "check_fn": "check_owner_role",
    },
    {
        "id": "sa_default_compute",
        "name": "Default Compute Service Account",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.DEFAULT_SERVICE_ACCOUNT,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.SERVICE_ACCOUNT],
        "check_fn": "check_default_compute_sa",
    },
    {
        "id": "sa_key_rotation",
        "name": "Service Account Key Rotation",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.KEY_MANAGEMENT,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.SERVICE_ACCOUNT_KEY],
        "check_fn": "check_sa_key_rotation",
    },
    {
        "id": "sa_domain_wide_delegation",
        "name": "Domain-Wide Delegation",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.SERVICE_ACCOUNT_ABUSE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.SERVICE_ACCOUNT],
        "check_fn": "check_domain_wide_delegation",
    },
    {
        "id": "sa_impersonation",
        "name": "Service Account Impersonation",
        "category": SecurityCategory.PRIVILEGE_ESCALATION,
        "sub_category": SecuritySubCategory.PRIVILEGE_ESCALATION_PATH,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.SERVICE_ACCOUNT],
        "check_fn": "check_sa_impersonation",
    },
    # Compute Checks
    {
        "id": "vm_external_ip",
        "name": "VM External IP",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_VM,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_vm_external_ip",
    },
    {
        "id": "vm_default_sa",
        "name": "VM Default Service Account",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.DEFAULT_SERVICE_ACCOUNT,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_vm_default_sa",
    },
    {
        "id": "vm_full_api_scope",
        "name": "VM Full API Access Scope",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OVERLY_PERMISSIVE_IAM,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_vm_full_api_scope",
    },
    {
        "id": "vm_shielded_disabled",
        "name": "Shielded VM Disabled",
        "category": SecurityCategory.CONFIGURATION_DRIFT,
        "sub_category": SecuritySubCategory.SHIELDED_VM_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_shielded_vm",
    },
    {
        "id": "vm_os_login_disabled",
        "name": "OS Login Disabled",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OS_LOGIN_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.PROJECT],
        "check_fn": "check_os_login",
    },
    {
        "id": "vm_serial_port_enabled",
        "name": "Serial Port Enabled",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.METADATA_EXPOSURE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_serial_port",
    },
    {
        "id": "vm_startup_script_secrets",
        "name": "Secrets in Startup Script",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.STARTUP_SCRIPT_SECRETS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.COMPUTE_INSTANCE],
        "check_fn": "check_startup_script_secrets",
    },
    {
        "id": "disk_encryption",
        "name": "Disk Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.UNENCRYPTED_DISK,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.COMPUTE_DISK],
        "check_fn": "check_disk_encryption",
    },
    # Storage Checks
    {
        "id": "bucket_public_access",
        "name": "Public Storage Bucket",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_BUCKET,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.STORAGE_BUCKET],
        "check_fn": "check_public_bucket",
    },
    {
        "id": "bucket_logging",
        "name": "Bucket Access Logging",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.BUCKET_LOGGING_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.STORAGE_BUCKET],
        "check_fn": "check_bucket_logging",
    },
    {
        "id": "bucket_versioning",
        "name": "Bucket Versioning",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.NO_VERSIONING,
        "severity": SeverityLevel.LOW,
        "resource_types": [GCPResourceType.STORAGE_BUCKET],
        "check_fn": "check_bucket_versioning",
    },
    # Networking Checks
    {
        "id": "firewall_open_ssh",
        "name": "Open SSH Firewall Rule",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.OPEN_FIREWALL,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.FIREWALL_RULE],
        "check_fn": "check_open_ssh",
    },
    {
        "id": "firewall_open_rdp",
        "name": "Open RDP Firewall Rule",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.OPEN_FIREWALL,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.FIREWALL_RULE],
        "check_fn": "check_open_rdp",
    },
    {
        "id": "firewall_open_all",
        "name": "Open All Ports Firewall",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.OPEN_FIREWALL,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.FIREWALL_RULE],
        "check_fn": "check_open_all_ports",
    },
    {
        "id": "vpc_flow_logs",
        "name": "VPC Flow Logs Disabled",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.MISSING_VPC_FLOW_LOGS,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.SUBNETWORK],
        "check_fn": "check_vpc_flow_logs",
    },
    # Database Checks
    {
        "id": "sql_public_ip",
        "name": "Cloud SQL Public IP",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_DATABASE,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.CLOUD_SQL_INSTANCE],
        "check_fn": "check_sql_public_ip",
    },
    {
        "id": "sql_ssl_enforcement",
        "name": "Cloud SQL SSL Not Enforced",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.SSL_NOT_ENFORCED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.CLOUD_SQL_INSTANCE],
        "check_fn": "check_sql_ssl",
    },
    {
        "id": "sql_backup",
        "name": "Cloud SQL Backups Disabled",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.NO_BACKUP,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.CLOUD_SQL_INSTANCE],
        "check_fn": "check_sql_backup",
    },
    # BigQuery Checks
    {
        "id": "bq_public_dataset",
        "name": "Public BigQuery Dataset",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_ACCESS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.BIGQUERY_DATASET],
        "check_fn": "check_bq_public_dataset",
    },
    # GKE Checks
    {
        "id": "gke_legacy_abac",
        "name": "GKE Legacy ABAC Enabled",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.LEGACY_ABAC,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.GKE_CLUSTER],
        "check_fn": "check_gke_legacy_abac",
    },
    {
        "id": "gke_basic_auth",
        "name": "GKE Basic Auth Enabled",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.BASIC_AUTH,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.GKE_CLUSTER],
        "check_fn": "check_gke_basic_auth",
    },
    {
        "id": "gke_public_endpoint",
        "name": "GKE Public Endpoint",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_ENDPOINT,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.GKE_CLUSTER],
        "check_fn": "check_gke_public_endpoint",
    },
    {
        "id": "gke_workload_identity",
        "name": "Workload Identity Disabled",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.WORKLOAD_IDENTITY_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.GKE_CLUSTER],
        "check_fn": "check_gke_workload_identity",
    },
    # Serverless Checks
    {
        "id": "function_public",
        "name": "Public Cloud Function",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_FUNCTION,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.CLOUD_FUNCTION],
        "check_fn": "check_public_function",
    },
    {
        "id": "function_default_sa",
        "name": "Function Default Service Account",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.DEFAULT_SERVICE_ACCOUNT,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.CLOUD_FUNCTION],
        "check_fn": "check_function_default_sa",
    },
    {
        "id": "function_env_secrets",
        "name": "Secrets in Function Environment",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.FUNCTION_SECRETS_EXPOSED,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [GCPResourceType.CLOUD_FUNCTION],
        "check_fn": "check_function_env_secrets",
    },
    # Logging Checks
    {
        "id": "audit_logging",
        "name": "Audit Logging Configuration",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.AUDIT_LOGS_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.PROJECT],
        "check_fn": "check_audit_logging",
    },
    {
        "id": "data_access_logs",
        "name": "Data Access Logging",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.DATA_ACCESS_LOGS_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.PROJECT],
        "check_fn": "check_data_access_logs",
    },
    # Secrets Checks
    {
        "id": "api_key_unrestricted",
        "name": "Unrestricted API Key",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.API_KEY_UNRESTRICTED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.API_KEY],
        "check_fn": "check_api_key_restrictions",
    },
    {
        "id": "kms_key_rotation",
        "name": "KMS Key Rotation",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.UNROTATED_KEYS,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.KMS_CRYPTO_KEY],
        "check_fn": "check_kms_rotation",
    },
    # Persistence Checks
    {
        "id": "scheduler_persistence",
        "name": "Cloud Scheduler Persistence",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.SCHEDULED_PERSISTENCE,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.CLOUD_SCHEDULER_JOB],
        "check_fn": "check_scheduler_persistence",
    },
    {
        "id": "build_trigger_persistence",
        "name": "Cloud Build Trigger Persistence",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.BUILD_TRIGGER_PERSISTENCE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [GCPResourceType.CLOUD_BUILD_TRIGGER],
        "check_fn": "check_build_trigger_persistence",
    },
    # Organization Checks
    {
        "id": "org_policy_domain_restricted",
        "name": "Domain Restricted Sharing Policy",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.EXTERNAL_IDENTITY,
        "severity": SeverityLevel.HIGH,
        "resource_types": [GCPResourceType.ORGANIZATION_POLICY],
        "check_fn": "check_domain_restricted_sharing",
    },
]

DANGEROUS_PERMISSIONS: Dict[str, Dict[str, Any]] = {
    "iam.serviceAccountKeys.create": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can create service account keys for credential theft",
        "escalation_method": "Create SA key and authenticate as SA",
    },
    "iam.serviceAccountTokenCreator": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can generate access tokens for service accounts",
        "escalation_method": "Generate OAuth token for SA",
    },
    "iam.serviceAccounts.actAs": {
        "severity": SeverityLevel.HIGH,
        "description": "Can impersonate service accounts when deploying resources",
        "escalation_method": "Deploy resource as SA",
    },
    "compute.instances.setServiceAccount": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can change VM service account",
        "escalation_method": "Change VM to privileged SA and access metadata",
    },
    "cloudfunctions.functions.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can deploy Cloud Functions (with actAs can escalate)",
        "escalation_method": "Deploy function as privileged SA",
    },
    "deploymentmanager.deployments.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can deploy Deployment Manager configs as SA",
        "escalation_method": "Deploy DM config as privileged SA",
    },
    "cloudbuild.builds.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create Cloud Builds running as SA",
        "escalation_method": "Submit build as Cloud Build SA",
    },
    "run.services.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can deploy Cloud Run services as SA",
        "escalation_method": "Deploy Cloud Run service as privileged SA",
    },
    "composer.environments.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create Composer environments with SA",
        "escalation_method": "Create Airflow environment with privileged SA",
    },
    "dataflow.jobs.create": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create Dataflow jobs running as SA",
        "escalation_method": "Create Dataflow job as privileged SA",
    },
}

SECRET_PATTERNS: List[Tuple[str, str]] = [
    (r"AKIA[0-9A-Z]{16}", "AWS Access Key"),
    (r"(?i)api[_-]?key['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "API Key"),
    (r"(?i)password['\"]?\s*[:=]\s*['\"]?([^\s'\"]{8,})", "Password"),
    (r"(?i)secret[_-]?key['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "Secret Key"),
    (r"(?i)private[_-]?key", "Private Key Reference"),
    (r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "Private Key"),
    (r"(?i)bearer\s+[a-zA-Z0-9\-_\.]+", "Bearer Token"),
    (r"ya29\.[0-9A-Za-z_-]+", "Google OAuth Token"),
    (r"AIza[0-9A-Za-z_-]{35}", "Google API Key"),
    (r"(?i)database[_-]?url.*://", "Database Connection String"),
    (r"(?i)redis://[^\s]+", "Redis Connection String"),
    (r"(?i)mongodb(\+srv)?://[^\s]+", "MongoDB Connection String"),
]

