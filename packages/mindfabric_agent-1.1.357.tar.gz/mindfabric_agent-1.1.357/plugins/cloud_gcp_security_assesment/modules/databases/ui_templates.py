"""
GCP Security Assessment UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse it)
- fallback recommendations (when plugin check did not supply one)
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple


def get_gcp_guidance(
    *,
    category: Optional[str],
    sub_category: Optional[str],
    title: Optional[str] = None,
) -> Tuple[Optional[str], List[Dict[str, str]]]:
    c = (category or "").strip().lower()
    sc = (sub_category or "").strip().lower()

    if "iam" in c or "credential" in c or "auth" in c:
        impact = "Overly broad IAM bindings can allow privilege escalation (service account abuse, impersonation) and broad access to projects and data."
        recs = [
            {"title": "Apply least privilege", "description": "Remove owner/editor where possible; scope roles to resource level; limit SA impersonation.", "priority": "high"},
            {"title": "Prefer short-lived credentials", "description": "Use workload identity and avoid long-lived service account keys.", "priority": "medium"},
        ]
        return impact, recs

    if "network" in c or "exposure" in c:
        impact = "Exposed services enable scanning and direct exploitation. Weak ingress controls can provide an attacker initial access to workloads."
        recs = [
            {"title": "Restrict ingress", "description": "Use private services/VPC-SC where possible; tighten firewall rules and load balancer exposure.", "priority": "high"},
            {"title": "Add monitoring", "description": "Enable VPC Flow Logs and alert on unusual ingress and scanning patterns.", "priority": "medium"},
        ]
        return impact, recs

    if "storage" in c or "data" in c:
        impact = "Public or overly-permissive storage access can lead to data exfiltration at scale (buckets, datasets, snapshots)."
        recs = [
            {"title": "Remove public access", "description": "Eliminate allUsers/allAuthenticatedUsers where not required; enforce org policy constraints.", "priority": "high"},
            {"title": "Encrypt and log access", "description": "Use CMEK where required; enable audit logs and monitor large reads/downloads.", "priority": "medium"},
        ]
        return impact, recs

    if "logging" in c or "audit" in c:
        impact = "Without audit logs, suspicious access and IAM changes can go undetected, extending attacker dwell time."
        recs = [
            {"title": "Enable and centralize audit logs", "description": "Enable Admin Activity/Data Access logs where needed and sink them to a secure project.", "priority": "high"},
            {"title": "Alert on high-risk actions", "description": "Detect IAM binding changes, key creation, and suspicious service account usage.", "priority": "high"},
        ]
        return impact, recs

    t = (title or "").strip()
    if t:
        return (
            f"GCP risk tied to \"{t}\". Impact depends on IAM bindings, service account keys, VPC exposure, and whether the resource stores or fronts sensitive data.",
            [
                {
                    "title": "Map IAM and network path",
                    "description": f"For `{t}`, list principals (users/SAs/groups) with access, inherited org/folder roles, and any allUsers bindings.",
                    "priority": "high",
                },
                {
                    "title": "Fix and audit siblings",
                    "description": "Apply least privilege and org policies; search other projects for the same anti-pattern via Asset Inventory or policy checks.",
                    "priority": "medium",
                },
            ],
        )

    return (
        "GCP misconfigurations can enable privilege escalation, data access, or persistence depending on the affected service and permission scope.",
        [
            {
                "title": "Triage by sensitivity",
                "description": "Identify data class and production impact; escalate findings that combine broad IAM with external reachability.",
                "priority": "high",
            },
            {
                "title": "Remediate with audit logging",
                "description": "Correct config drift, ensure Admin Activity logs cover the change, and add detection for reintroduction.",
                "priority": "medium",
            },
        ],
    )


def build_gcp_project_enumeration_failure_description(*, error: str) -> str:
    """
    Used when the scanner cannot enumerate projects (missing credentials/tooling/permissions).
    Provide a cloud-context explanation, not a generic 'No projects found'.
    """
    err = (error or "").strip()
    return (
        "GCP Security Assessment could not enumerate projects to scan. "
        "This usually means the agent is missing usable GCP credentials, the `gcloud`/SDK tooling is unavailable, "
        "or the identity does not have permission to list projects (e.g., `resourcemanager.projects.list`). "
        f"Observed error: {err}"
    )


def build_gcp_project_enumeration_failure_impact() -> str:
    return (
        "Without project enumeration, the platform cannot audit IAM, network exposure, storage permissions, and logging posture across GCP. "
        "This is a visibility gap: misconfigurations that enable privilege escalation or data exposure may remain undetected."
    )


def build_gcp_project_enumeration_failure_recommendations() -> List[Dict[str, str]]:
    return [
        {
            "title": "Provide GCP credentials to the agent",
            "description": "Use Application Default Credentials (`gcloud auth application-default login`) or mount a service account JSON via `GOOGLE_APPLICATION_CREDENTIALS`. Prefer workload identity in production.",
            "priority": "high",
        },
        {
            "title": "Grant least-privilege project enumeration",
            "description": "Ensure the identity can list/inspect target scope (org/folder/project). At minimum, allow project enumeration and the specific read permissions required by enabled checks.",
            "priority": "high",
        },
        {
            "title": "Configure explicit scope",
            "description": "If you want to scan a known set of projects, configure the plugin scope to avoid relying on org-wide enumeration.",
            "priority": "medium",
        },
    ]


def build_gcp_project_enumeration_failure_evidence(*, error: str) -> Dict[str, Any]:
    # Keep evidence minimal and structured.
    return {"source": "project_enumeration", "error": (error or "")[:500]}

