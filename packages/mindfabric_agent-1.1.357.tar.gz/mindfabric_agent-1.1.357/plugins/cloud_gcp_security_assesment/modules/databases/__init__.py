"""
GCP Security Assessment Databases Module
"""

from .gcp_databases import (
    MITRE_MAPPING,
    CIS_GCP_MAPPING,
    GCP_CHECKS,
    DANGEROUS_PERMISSIONS,
    SECRET_PATTERNS,
)

__all__ = [
    "MITRE_MAPPING",
    "CIS_GCP_MAPPING",
    "GCP_CHECKS",
    "DANGEROUS_PERMISSIONS",
    "SECRET_PATTERNS",
]

