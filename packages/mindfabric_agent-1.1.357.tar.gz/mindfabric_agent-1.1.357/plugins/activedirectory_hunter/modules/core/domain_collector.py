"""
Domain Information Collector Module

Collects general domain information from Active Directory, FreeIPA, etc.
"""

import os
import re
import base64
from typing import Optional
try:
    import psutil
except ImportError:
    psutil = None

from ...proto import DirectoryType, ScanOptions, DomainInfo
from utils.async_subprocess import run_exec


class DomainCollector:
    """Collects domain information"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def gather_info(self, scan_options: ScanOptions, directory_type: DirectoryType) -> DomainInfo:
        """
        Collects general domain information
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            DomainInfo: Domain information
        """
        # Do not emit placeholder "unknown" strings into outputs; prefer empty/None and let UI templates explain.
        domain_name = (scan_options.domain_name or "").strip()
        forest_name: Optional[str] = None
        domain_controllers = []
        domain_sid = None
        domain_functional_level = None
        password_policy = None
        kerberos_policy = None
        
        # Try to detect domain from local files even without LDAP connection
        try:
            # Check /etc/krb5.conf for domain info
            if os.path.exists('/etc/krb5.conf'):
                with open('/etc/krb5.conf', 'r') as f:
                    krb5_content = f.read()
                    if 'default_realm' in krb5_content:
                        realm_match = re.search(r'default_realm\s*=\s*([^\s\n]+)', krb5_content)
                        if realm_match:
                            domain_name = realm_match.group(1).strip()
            
            # Check /etc/samba/smb.conf for domain info
            if os.path.exists('/etc/samba/smb.conf'):
                with open('/etc/samba/smb.conf', 'r') as f:
                    smb_content = f.read()
                    if 'workgroup' in smb_content or 'realm' in smb_content:
                        workgroup_match = re.search(r'workgroup\s*=\s*([^\s\n]+)', smb_content, re.IGNORECASE)
                        realm_match = re.search(r'realm\s*=\s*([^\s\n]+)', smb_content, re.IGNORECASE)
                        if realm_match:
                            domain_name = realm_match.group(1).strip()
                        elif workgroup_match:
                            domain_name = workgroup_match.group(1).strip() + ".LOCAL"
                        
                        # Detect domain controller role
                        if 'server role' in smb_content.lower() and 'domain controller' in smb_content.lower():
                            domain_controllers.append("localhost")
                            directory_type = DirectoryType.ACTIVE_DIRECTORY
            
            # Check for AD-related processes
            try:
                if psutil:
                    for proc in psutil.process_iter(['name', 'cmdline']):
                        proc_name = proc.info.get('name', '').lower()
                        if any(ad_proc in proc_name for ad_proc in ['smbd', 'nmbd', 'winbindd', 'samba', 'ldap']):
                            # Do not hardcode a fake domain for "prod-like" runs.
                            # If we can't infer a domain, keep it as "unknown".
                            if not domain_controllers:
                                domain_controllers.append("localhost")
                            directory_type = DirectoryType.ACTIVE_DIRECTORY
                            break
            except (ImportError, Exception):
                pass
        except Exception:
            pass
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            # For Active Directory using ldapsearch or available parameters
            ldap_server = scan_options.ldap_server
            
            if ldap_server is None and scan_options.use_domain_discovery:
                # Trying to detect domain controller
                try:
                    rc, out, _ = await run_exec(
                        ["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"],
                        timeout=5,
                    )
                    
                    if rc == 0 and (out or "").strip():
                        # Extracting hosts from SRV records
                        for line in (out or "").strip().splitlines():
                            try:
                                parts = line.strip().split()
                                host = parts[-1][:-1]  # Removing trailing dot
                                domain_controllers.append(host)
                            except Exception:
                                pass
                except Exception:
                    pass
            
            # If we have credentials, trying to get more information
            if scan_options.username and (scan_options.password or scan_options.ntlm_hash) and domain_controllers:
                try:
                    # Collecting domain information using ldapsearch
                    base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                    
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', domain_controllers[0],
                        '-b', base_dn, 
                        '(objectClass=domain)', '*'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=10)
                    
                    if rc == 0:
                        # Extracting SID domain
                        sid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', out or "")
                        if sid_match:
                            # Decoding SID from base64
                            sid_base64 = sid_match.group(1)
                            try:
                                sid_binary = base64.b64decode(sid_base64)
                                # Converting binary SID to string
                                domain_sid = f"S-1-5-{sid_binary[6]}-{sid_binary[7]}-{sid_binary[8]}"
                            except Exception:
                                pass
                        
                        # Extracting domain functional level
                        fl_match = re.search(r'msDS-Behavior-Version:\s*(\d+)', out or "")
                        if fl_match:
                            fl_value = int(fl_match.group(1))
                            # Converting numeric value to string
                            fl_map = {
                                0: "Windows2000Domain",
                                1: "Windows2003Domain",
                                2: "Windows2008Domain",
                                3: "Windows2008R2Domain",
                                4: "Windows2012Domain",
                                5: "Windows2012R2Domain",
                                6: "Windows2016Domain",
                                7: "Windows2019Domain",
                                8: "Windows2022Domain"
                            }
                            domain_functional_level = fl_map.get(fl_value, f"Unknown ({fl_value})")
                    
                    # Getting password policy information
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', domain_controllers[0],
                        '-b', base_dn, 
                        '(objectClass=domainDNS)', 'pwdProperties', 'pwdHistoryLength', 'lockoutThreshold', 'minPwdLength'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc2, out2, _ = await run_exec(ldapsearch_cmd, timeout=10)
                    
                    if rc2 == 0:
                        password_policy = {}
                        
                        # Extracting minimum length password
                        pwd_len_match = re.search(r'minPwdLength:\s*(\d+)', out2 or "")
                        if pwd_len_match:
                            password_policy["minimum_password_length"] = int(pwd_len_match.group(1))
                        
                        # Extracting number of stored passwords
                        pwd_hist_match = re.search(r'pwdHistoryLength:\s*(\d+)', out2 or "")
                        if pwd_hist_match:
                            password_policy["password_history_count"] = int(pwd_hist_match.group(1))
                        
                        # Extracting lockout threshold
                        lockout_match = re.search(r'lockoutThreshold:\s*(\d+)', out2 or "")
                        if lockout_match:
                            password_policy["lockout_threshold"] = int(lockout_match.group(1))
                except Exception:
                    pass
        
        elif directory_type == DirectoryType.FREEIPA:
            # For FreeIPA using corresponding commands
            if scan_options.username and scan_options.password:
                try:
                    # Collecting information using IPA CLI
                    # First getting Kerberos ticket
                    await run_exec(
                        ["kinit", scan_options.username],
                        stdin=f"{scan_options.password}\n",
                        timeout=10,
                    )
                    
                    # Getting domain information
                    rc, out, _ = await run_exec(["ipa", "env"], timeout=10)
                    
                    if rc == 0:
                        # Extracting domain information and forest
                        domain_match = re.search(r'domain:\s*([A-Za-z0-9.-]+)', out or "")
                        if domain_match:
                            domain_name = domain_match.group(1)
                        
                        forest_match = re.search(r'basedn:\s*([A-Za-z0-9=,.-]+)', out or "")
                        if forest_match:
                            forest_name = domain_name
                    
                    # Getting list of IPA servers
                    rc2, out2, _ = await run_exec(["ipa", "server-find"], timeout=15)
                    
                    if rc2 == 0:
                        # Extracting servers
                        server_matches = re.findall(r'Server name:\s*([A-Za-z0-9.-]+)', out2 or "")
                        domain_controllers = server_matches
                    
                    # Getting password policy information
                    rc3, out3, _ = await run_exec(["ipa", "pwpolicy-show"], timeout=15)
                    
                    if rc3 == 0:
                        password_policy = {}
                        
                        # Extracting minimum length password
                        pwd_len_match = re.search(r'Min password length:\s*(\d+)', out3 or "")
                        if pwd_len_match:
                            password_policy["minimum_password_length"] = int(pwd_len_match.group(1))
                        
                        # Extracting number of stored passwords
                        pwd_hist_match = re.search(r'Password history size:\s*(\d+)', out3 or "")
                        if pwd_hist_match:
                            password_policy["password_history_count"] = int(pwd_hist_match.group(1))
                        
                        # Extracting lockout threshold
                        lockout_match = re.search(r'Failed login attempts before lockout:\s*(\d+)', out3 or "")
                        if lockout_match:
                            password_policy["lockout_threshold"] = int(lockout_match.group(1))
                except Exception:
                    pass
        
        # Forming domain information
        return DomainInfo(
            domain_name=domain_name,
            forest_name=forest_name or (domain_name if domain_name else None),
            directory_type=directory_type,
            domain_functional_level=domain_functional_level,
            domain_controllers=domain_controllers,
            domain_sid=domain_sid,
            password_policy=password_policy,
            kerberos_policy=kerberos_policy
        )

