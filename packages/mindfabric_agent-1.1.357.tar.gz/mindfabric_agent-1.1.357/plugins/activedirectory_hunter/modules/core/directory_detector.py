"""
Directory Type Detector Module

Determines directory type (Active Directory, FreeIPA, Azure AD, etc.)
"""

import os
import re
import shutil
from typing import Optional
from ...proto import DirectoryType, ScanOptions
from utils.async_subprocess import run_exec


class DirectoryDetector:
    """Detects directory type from scan options"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def determine_type(self, scan_options: ScanOptions) -> DirectoryType:
        """
        Determines directory type (Active Directory, FreeIPA, Azure AD etc.)
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            DirectoryType: Directory type
        """
        # If domain_name isn't provided, try to infer it from local configuration
        # (prod-safe: avoids hardcoded test domains).
        if scan_options.domain_name is None and getattr(scan_options, "use_domain_discovery", False):
            inferred = self._infer_domain_name_from_local_config()
            if inferred:
                try:
                    scan_options.domain_name = inferred
                except Exception:
                    # Best-effort: if ScanOptions is immutable for any reason, continue without domain.
                    pass

        if scan_options.domain_name is None:
            return DirectoryType.UNKNOWN
        
        if scan_options.ldap_server is None and scan_options.use_domain_discovery:
            # Trying to automatically detect domain controllers
            try:
                # Checking for presence of tools for detection
                if not shutil.which("dig"):
                    raise RuntimeError("dig not found")
                
                # For Active Directory trying to find SRV entry
                rc, out, _ = await run_exec(
                    ["dig", "+short", f"_ldap._tcp.{scan_options.domain_name}", "SRV"],
                    timeout=5,
                )
                
                if rc == 0 and (out or "").strip():
                    return DirectoryType.ACTIVE_DIRECTORY
                
                # For FreeIPA trying to find SRV entry
                rc, out, _ = await run_exec(
                    ["dig", "+short", f"_kerberos._tcp.{scan_options.domain_name}", "SRV"],
                    timeout=5,
                )
                
                if rc == 0 and (out or "").strip():
                    # Checking if this is FreeIPA, and not just Kerberos
                    rc2, out2, _ = await run_exec(
                        ["dig", "+short", f"_ldap._tcp.{scan_options.domain_name}", "SRV"],
                        timeout=5,
                    )
                    
                    if rc2 == 0 and (out2 or "").strip():
                        # Trying to execute basic LDAP query to server
                        server = (out2 or "").strip().split()[-1][:-1]  # Extracting host from SRV entry
                        
                        ldapsearch_cmd = [
                            'ldapsearch', '-x', '-h', server,
                            '-b', f"dc={',dc='.join(scan_options.domain_name.split('.'))}", 
                            '(objectClass=*)', 'namingContexts'
                        ]
                        
                        try:
                            rc3, out3, _ = await run_exec(ldapsearch_cmd, timeout=5)
                            
                            if "ipa" in (out3 or "").lower():
                                return DirectoryType.FREEIPA
                            else:
                                return DirectoryType.ACTIVE_DIRECTORY
                        except Exception:
                            # In case of error assume Active Directory
                            return DirectoryType.ACTIVE_DIRECTORY
                    
                    return DirectoryType.ACTIVE_DIRECTORY
                
                # Checking for Azure AD
                if "microsoft" in scan_options.domain_name.lower() or "azure" in scan_options.domain_name.lower():
                    # Attempt determine Azure AD
                    return DirectoryType.AZURE_AD
            except Exception:
                pass
            
            # If failed determine, assume Active Directory
            return DirectoryType.ACTIVE_DIRECTORY
        elif scan_options.ldap_server is not None:
            # If LDAP server specified, trying to determine type by it
            try:
                # Basic LDAP query to determine type
                ldapsearch_cmd = [
                    'ldapsearch', '-x', '-h', scan_options.ldap_server,
                    '-b', f"dc={',dc='.join(scan_options.domain_name.split('.'))}", 
                    '(objectClass=*)', 'namingContexts'
                ]
                
                if scan_options.username and scan_options.password:
                    ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                
                rc, out, _ = await run_exec(ldapsearch_cmd, timeout=5)
                
                if rc == 0:
                    if "ipa" in (out or "").lower():
                        return DirectoryType.FREEIPA
                    elif "microsoft" in (out or "").lower() or "azure" in (out or "").lower():
                        return DirectoryType.AZURE_AD
                    else:
                        return DirectoryType.ACTIVE_DIRECTORY
            except Exception:
                pass
            
            # If failed determine, assume Active Directory
            return DirectoryType.ACTIVE_DIRECTORY
        else:
            # By default assume Active Directory
            return DirectoryType.ACTIVE_DIRECTORY

    def _infer_domain_name_from_local_config(self) -> Optional[str]:
        """
        Infer a realm/domain from local configuration files.

        Sources (in priority order):
        - /etc/krb5.conf: default_realm
        - /etc/samba/smb.conf: realm/workgroup
        - /etc/resolv.conf: search/domain
        """
        # /etc/krb5.conf
        try:
            if os.path.exists("/etc/krb5.conf"):
                with open("/etc/krb5.conf", "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                m = re.search(r"(?im)^\s*default_realm\s*=\s*([A-Z0-9._-]+)\s*$", content)
                if m:
                    return m.group(1).strip()
        except Exception:
            pass

        # /etc/samba/smb.conf
        try:
            if os.path.exists("/etc/samba/smb.conf"):
                with open("/etc/samba/smb.conf", "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                m = re.search(r"(?im)^\s*realm\s*=\s*([A-Z0-9._-]+)\s*$", content)
                if m:
                    return m.group(1).strip()
                m = re.search(r"(?im)^\s*workgroup\s*=\s*([A-Z0-9._-]+)\s*$", content)
                if m:
                    return f"{m.group(1).strip()}.LOCAL"
        except Exception:
            pass

        # /etc/resolv.conf
        try:
            if os.path.exists("/etc/resolv.conf"):
                with open("/etc/resolv.conf", "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        if line.startswith("search "):
                            parts = line.split()
                            if len(parts) >= 2 and "." in parts[1]:
                                return parts[1].strip()
                        if line.startswith("domain "):
                            parts = line.split()
                            if len(parts) >= 2 and "." in parts[1]:
                                return parts[1].strip()
        except Exception:
            pass

        return None
