"""
BloodHound Data Exporter Module

Exports collected data in format compatible with BloodHound
"""

import json
import zipfile
import os
import random
from datetime import datetime
from typing import List
from ...proto import ScanOptions, DomainInfo, User, Group, Computer, TrustRelationship, GPO


class BloodHoundExporter:
    """Exports data in BloodHound format"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def export(self, scan_options: ScanOptions, domain_info: DomainInfo,
               users: List[User], groups: List[Group], computers: List[Computer],
               trusts: List[TrustRelationship], gpos: List[GPO], output_file: str):
        """
        Exports collected data in format compatible with BloodHound
        
        Args:
            scan_options: Scan parameters
            domain_info: Information about domain
            users: User list
            groups: Group list
            computers: Computer list
            trusts: Trust relationship list
            gpos: Group Policy Object list
            output_file: Path to output file
        """
        try:
            bloodhound_data = {
                "users": [],
                "groups": [],
                "computers": [],
                "domains": [],
                "gpos": [],
                "ous": []
            }
            
            domain_sid = domain_info.domain_sid or "S-1-5-21-0-0-0"
            domain_data = {
                "ObjectIdentifier": domain_sid,
                "Properties": {
                    "name": domain_info.domain_name.upper(),
                    "domain": domain_info.domain_name.lower(),
                    "functionallevel": domain_info.domain_functional_level or "Unknown",
                    "highvalue": True
                },
                "Trusts": [],
                "ChildOus": [],
                "Contains": []
            }
            
            for trust in trusts:
                trust_data = {
                    "TargetDomainName": trust.target_domain.upper(),
                    "TargetDomainSid": "S-1-5-21-0-0-0",
                    "TrustDirection": trust.trust_direction,
                    "TrustType": trust.trust_type,
                    "SidFilteringEnabled": "Non-Transitive" in trust.trust_attributes,
                    "IsTransitive": trust.is_transitive
                }
                
                domain_data["Trusts"].append(trust_data)
            
            bloodhound_data["domains"].append(domain_data)
            
            for user in users:
                user_data = {
                    "ObjectIdentifier": user.sid or f"{domain_sid}-{random.randint(10000, 99999)}",
                    "Properties": {
                        "name": user.sam_account_name or user.username,
                        "domain": domain_info.domain_name.lower(),
                        "domainsid": domain_sid,
                        "distinguishedname": user.distinguished_name,
                        "description": "",
                        "admincount": user.admin_count or False,
                        "enabled": user.enabled,
                        "serviceprincipalnames": user.service_principal_names or [],
                        "lastlogon": 0,
                        "lastlogontimestamp": 0,
                        "pwdlastset": 0,
                        "highvalue": user.admin_count or False,
                        "samaccountname": user.sam_account_name,
                        "email": user.email
                    },
                    "MemberOf": [],
                    "HasSIDHistory": []
                }
                
                for group_dn in user.groups:
                    for group in groups:
                        if group.distinguished_name == group_dn:
                            user_data["MemberOf"].append(group.sid or f"{domain_sid}-{group.sam_account_name}")
                
                bloodhound_data["users"].append(user_data)
            
            for group in groups:
                group_data = {
                    "ObjectIdentifier": group.sid or f"{domain_sid}-{group.sam_account_name}",
                    "Properties": {
                        "name": group.name,
                        "domain": domain_info.domain_name.lower(),
                        "domainsid": domain_sid,
                        "distinguishedname": group.distinguished_name,
                        "description": group.description or "",
                        "admincount": group.is_privileged or False,
                        "highvalue": group.is_privileged or False
                    },
                    "Members": [],
                    "MemberOf": []
                }
                
                for member_dn in group.members:
                    for user in users:
                        if user.distinguished_name == member_dn:
                            group_data["Members"].append(user.sid or f"{domain_sid}-{user.sam_account_name}")
                    
                    for other_group in groups:
                        if other_group.distinguished_name == member_dn:
                            group_data["Members"].append(other_group.sid or f"{domain_sid}-{other_group.sam_account_name}")
                
                for parent_dn in group.member_of:
                    for parent_group in groups:
                        if parent_group.distinguished_name == parent_dn:
                            group_data["MemberOf"].append(parent_group.sid or f"{domain_sid}-{parent_group.sam_account_name}")
                
                bloodhound_data["groups"].append(group_data)
            
            for computer in computers:
                computer_data = {
                    "ObjectIdentifier": computer.sid or f"{domain_sid}-{computer.sam_account_name}",
                    "Properties": {
                        "name": computer.name,
                        "domain": domain_info.domain_name.lower(),
                        "domainsid": domain_sid,
                        "distinguishedname": computer.distinguished_name,
                        "operatingsystem": computer.os or "Unknown",
                        "serviceprincipalnames": computer.service_principal_names or [],
                        "enabled": True,
                        "unconstraineddelegation": computer.delegation_permitted and not computer.delegation_services,
                        "allowedtodelegate": computer.delegation_services,
                        "lastlogon": int(computer.last_logon.timestamp()) if computer.last_logon else 0,
                        "lastlogontimestamp": int(computer.last_logon.timestamp()) if computer.last_logon else 0,
                        "pwdlastset": int(computer.password_last_set.timestamp()) if computer.password_last_set else 0,
                        "highvalue": computer.is_domain_controller or False,
                        "samaccountname": computer.sam_account_name,
                        "haslaps": False
                    },
                    "MemberOf": [],
                    "AllowedToDelegate": computer.delegation_services or []
                }
                
                bloodhound_data["computers"].append(computer_data)
            
            for gpo in gpos:
                gpo_data = {
                    "ObjectIdentifier": f"GPO_{gpo.name}",
                    "Properties": {
                        "name": gpo.display_name or gpo.name,
                        "domain": domain_info.domain_name.lower(),
                        "domainsid": domain_sid,
                        "distinguishedname": gpo.distinguished_name,
                        "highvalue": False
                    },
                    "Links": [],
                    "GPOAdmins": []
                }
                
                for linked_object in gpo.linked_objects:
                    gpo_data["Links"].append({
                        "GUID": linked_object,
                        "IsEnforced": False
                    })
                
                bloodhound_data["gpos"].append(gpo_data)
            
            temp_dir = "/tmp/bloodhound_tmp"
            os.makedirs(temp_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            
            files_to_compress = []
            
            for data_type, data_list in bloodhound_data.items():
                if data_list:
                    file_path = os.path.join(temp_dir, f"{data_type}_{timestamp}.json")
                    with open(file_path, 'w') as f:
                        json.dump(data_list, f)
                    files_to_compress.append(file_path)
            
            with zipfile.ZipFile(output_file, 'w') as zipf:
                for file_path in files_to_compress:
                    zipf.write(file_path, os.path.basename(file_path))
            
            for file_path in files_to_compress:
                try:
                    os.remove(file_path)
                except Exception:
                    pass
            
            try:
                os.rmdir(temp_dir)
            except Exception:
                pass
        
        except Exception as e:
            raise Exception(f"Error during data export in BloodHound format: {str(e)}")

