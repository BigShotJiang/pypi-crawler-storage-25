"""
Password Policy Analyzer Module

Analyzes password policies in domain
"""

import re
import time
from typing import Dict, Any
from ...proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


class PasswordPolicyAnalyzer:
    """Analyzes password policies"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Analyzes password policies in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Analysis results
        """
        result = {
            "success": False,
            "policy": {},
            "vulnerabilities": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        try:
            if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                if scan_options.ldap_server:
                    base_dn = f"dc={',dc='.join(scan_options.domain_name.split('.'))}"
                    
                    # Query Default Domain Policy for password settings
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', scan_options.ldap_server,
                        '-b', f"CN=Default Domain Policy,CN=System,{base_dn}",
                        '(objectClass=*)',
                        'minPwdLength', 'maxPwdAge', 'minPwdAge', 'pwdHistoryLength',
                        'pwdProperties', 'lockoutThreshold', 'lockoutDuration', 'lockoutObservationWindow'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        policy = {}
                        vulnerabilities = []
                        
                        # Parse password policy attributes
                        min_length_match = re.search(r'minPwdLength:\s*(\d+)', out or "")
                        if min_length_match:
                            min_length = int(min_length_match.group(1))
                            policy["min_password_length"] = min_length
                            if min_length < 8:
                                vulnerabilities.append({
                                    "type": "weak_password_policy",
                                    "description": f"Minimum password length is only {min_length}",
                                    "risk": "high"
                                })
                        
                        # Add more policy parsing as needed
                        
                        result["policy"] = policy
                        result["vulnerabilities"] = vulnerabilities
                        result["success"] = True
            
            elif directory_type == DirectoryType.FREEIPA:
                try:
                    if scan_options.username and scan_options.password:
                        await run_exec(
                            ["kinit", scan_options.username],
                            stdin=f"{scan_options.password}\n",
                            timeout=10,
                        )
                        
                        rc, out, _ = await run_exec(["ipa", "pwpolicy-show"], timeout=30)
                        
                        if rc == 0:
                            result["policy_details"] = out or ""
                            result["success"] = True
                except Exception:
                    pass
        
        except Exception as e:
            result["errors"].append(f"Error during password policy analysis: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

