"""
ADCS (Active Directory Certificate Services) Analyzer Module

Analyzes ADCS for vulnerabilities and misconfigurations including:
- ESC1: Misconfigured Certificate Templates - Enrollee Supplies Subject
- ESC2: Misconfigured Certificate Templates - Any Purpose EKU
- ESC3: Misconfigured Enrollment Agent Templates
- ESC4: Vulnerable Certificate Template Access Control
- ESC5: Vulnerable PKI Object Access Control
- ESC6: EDITF_ATTRIBUTESUBJECTALTNAME2 Flag
- ESC7: Vulnerable Certificate Authority Access Control
- ESC8: NTLM Relay to AD CS HTTP Endpoints
- ESC9: No Security Extension
- ESC10: Weak Certificate Mappings
- ESC11: PKCS11 Certificate Abuse
- ESC13: Issuance Policy Misconfiguration
- ESC14: Weak CA Certificate Mappings
"""

import re
import time
from typing import Dict, Any, List, Optional
from ...proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


# ADCS Vulnerability Definitions
ESC_VULNERABILITIES = {
    "ESC1": {
        "name": "Misconfigured Certificate Templates - Enrollee Supplies Subject",
        "description": "Certificate template allows enrollee to specify Subject Alternative Name (SAN). Attacker can request certificate for any user including Domain Admin.",
        "risk": "critical",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Remove CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT flag (msPKI-Certificate-Name-Flag)",
            "Require manager approval for certificate enrollment",
            "Restrict enrollment permissions to specific security groups"
        ]
    },
    "ESC2": {
        "name": "Misconfigured Certificate Templates - Any Purpose EKU",
        "description": "Certificate template has Any Purpose EKU or no EKUs defined. Certificate can be used for client authentication, enabling impersonation.",
        "risk": "high",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Define specific EKUs for each certificate template",
            "Remove Any Purpose (2.5.29.37.0) EKU",
            "Restrict enrollment permissions"
        ]
    },
    "ESC3": {
        "name": "Misconfigured Enrollment Agent Templates",
        "description": "Enrollment Agent template can be used by low-privileged users to request certificates on behalf of other users.",
        "risk": "high",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Restrict Enrollment Agent template enrollment to specific users",
            "Remove Certificate Request Agent EKU from general-purpose templates",
            "Implement manager approval for enrollment agent certificates"
        ]
    },
    "ESC4": {
        "name": "Vulnerable Certificate Template Access Control",
        "description": "Low-privileged users have write access to certificate template objects, allowing modification of template properties.",
        "risk": "critical",
        "mitre": ["T1649", "T1222.001"],
        "remediation": [
            "Remove write permissions for non-privileged users on certificate templates",
            "Audit DACL on certificate template objects",
            "Implement least privilege for PKI management"
        ]
    },
    "ESC5": {
        "name": "Vulnerable PKI Object Access Control",
        "description": "Low-privileged users have dangerous permissions on PKI AD objects (CA server, NTAuthCertificates, etc.).",
        "risk": "critical",
        "mitre": ["T1649", "T1222.001"],
        "remediation": [
            "Review and restrict permissions on PKI objects in AD",
            "Remove GenericAll, GenericWrite, WriteDacl, WriteOwner from non-admin groups",
            "Audit NTAuthCertificates container access"
        ]
    },
    "ESC6": {
        "name": "EDITF_ATTRIBUTESUBJECTALTNAME2 Flag Enabled",
        "description": "CA has EDITF_ATTRIBUTESUBJECTALTNAME2 flag enabled, allowing any requester to specify SAN in the request.",
        "risk": "critical",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Disable EDITF_ATTRIBUTESUBJECTALTNAME2 flag on CA",
            "Run: certutil -setreg policy\\EditFlags -EDITF_ATTRIBUTESUBJECTALTNAME2",
            "Restart CA service after change"
        ]
    },
    "ESC7": {
        "name": "Vulnerable Certificate Authority Access Control",
        "description": "Low-privileged users have ManageCA or ManageCertificates rights on the CA, allowing certificate management operations.",
        "risk": "critical",
        "mitre": ["T1649", "T1222.001"],
        "remediation": [
            "Remove ManageCA/ManageCertificates rights from non-admin users",
            "Review CA security permissions",
            "Implement role-based access control for CA management"
        ]
    },
    "ESC8": {
        "name": "NTLM Relay to AD CS HTTP Endpoints",
        "description": "AD CS web enrollment endpoints are vulnerable to NTLM relay attacks. Attacker can relay NTLM authentication to obtain certificates.",
        "risk": "critical",
        "mitre": ["T1649", "T1557.001"],
        "remediation": [
            "Disable HTTP enrollment endpoints if not required",
            "Enable EPA (Extended Protection for Authentication) on IIS",
            "Enable Require SSL on certificate enrollment websites",
            "Disable NTLM authentication on enrollment endpoints"
        ]
    },
    "ESC9": {
        "name": "No Security Extension - StrongCertificateBindingEnforcement",
        "description": "Weak certificate mapping allows certificates without strong mapping to authenticate. CT_FLAG_NO_SECURITY_EXTENSION vulnerability.",
        "risk": "high",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Enable StrongCertificateBindingEnforcement (KB5014754)",
            "Set registry HKLM\\SYSTEM\\CurrentControlSet\\Services\\Kdc StrongCertificateBindingEnforcement = 2",
            "Review and update certificate mapping policies"
        ]
    },
    "ESC10": {
        "name": "Weak Certificate Mappings",
        "description": "Weak or missing certificate mapping allows certificate abuse. Default certificate mapping uses only Subject field.",
        "risk": "high",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Enable strong certificate binding",
            "Configure explicit certificate mapping",
            "Require certificate with SID extension for authentication"
        ]
    },
    "ESC11": {
        "name": "IF_ENFORCEENCRYPTICERTREQUEST Not Enforced",
        "description": "CA does not enforce encryption on certificate requests, allowing interception of requests.",
        "risk": "medium",
        "mitre": ["T1649", "T1040"],
        "remediation": [
            "Enable IF_ENFORCEENCRYPTICERTREQUEST flag on CA",
            "Require encrypted RPC connections to CA"
        ]
    },
    "ESC13": {
        "name": "Issuance Policy Misconfiguration",
        "description": "OID group link allows privilege escalation through issuance policy abuse.",
        "risk": "high",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Review issuance policies and OID group links",
            "Remove unnecessary OID group links",
            "Audit msPKI-Certificate-Policy mappings"
        ]
    },
    "ESC14": {
        "name": "Weak CA Certificate Mappings",
        "description": "Weak explicit mappings on user accounts allow certificate abuse.",
        "risk": "medium",
        "mitre": ["T1649", "T1556.001"],
        "remediation": [
            "Review altSecurityIdentities attribute on user accounts",
            "Remove unnecessary certificate mappings",
            "Use strong certificate mapping policies"
        ]
    },
}

# Certificate Template Flags
CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT = 0x00000001
CT_FLAG_ADD_EMAIL = 0x00000002
CT_FLAG_ADD_OBJ_GUID = 0x00000004
CT_FLAG_PUBLISH_TO_DS = 0x00000008
CT_FLAG_OLD_CERT_SUPPLIES_SUBJECT_AND_ALT_NAME = 0x00000008
CT_FLAG_ALLOW_AUTOENROLL = 0x00000020
CT_FLAG_MACHINE_TYPE = 0x00000040
CT_FLAG_IS_CA = 0x00000080
CT_FLAG_ADD_DIRECTORY_PATH = 0x00000100
CT_FLAG_NO_SECURITY_EXTENSION = 0x80000

# Extended Key Usage OIDs
EKU_CLIENT_AUTH = "1.3.6.1.5.5.7.3.2"
EKU_SMART_CARD_LOGON = "1.3.6.1.4.1.311.20.2.2"
EKU_ANY_PURPOSE = "2.5.29.37.0"
EKU_CERTIFICATE_REQUEST_AGENT = "1.3.6.1.4.1.311.20.2.1"
EKU_PKINIT = "1.3.6.1.5.2.3.4"


class ADCSAnalyzer:
    """Analyzes ADCS for vulnerabilities including ESC1-ESC14"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Analyzes ADCS for vulnerabilities
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Analysis results
        """
        result = {
            "success": False,
            "certificate_authorities": [],
            "certificate_templates": [],
            "vulnerabilities": [],
            "esc_findings": [],
            "web_enrollment_endpoints": [],
            "errors": [],
            "statistics": {
                "execution_time": 0,
                "templates_scanned": 0,
                "cas_found": 0,
                "vulnerabilities_found": 0
            }
        }
        
        start_time = time.time()
        
        if directory_type != DirectoryType.ACTIVE_DIRECTORY:
            result["errors"].append("ADCS analysis supported only for Active Directory")
            return result
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not scan_options.ldap_server:
            result["errors"].append("LDAP server not specified")
            return result
        
        try:
            base_dn = f"dc={',dc='.join(scan_options.domain_name.split('.'))}"
            config_dn = f"CN=Configuration,{base_dn}"
            
            # Enumerate Certificate Authorities
            cas = await self._enumerate_cas(scan_options, config_dn)
            result["certificate_authorities"] = cas
            result["statistics"]["cas_found"] = len(cas)
            
            # Enumerate Certificate Templates with detailed properties
            templates = await self._enumerate_templates(scan_options, config_dn)
            result["certificate_templates"] = templates
            result["statistics"]["templates_scanned"] = len(templates)
            
            # Check for ESC vulnerabilities
            esc_findings = []
            
            # ESC1: Check for ENROLLEE_SUPPLIES_SUBJECT
            esc1_findings = self._check_esc1(templates)
            esc_findings.extend(esc1_findings)
            
            # ESC2: Check for Any Purpose EKU
            esc2_findings = self._check_esc2(templates)
            esc_findings.extend(esc2_findings)
            
            # ESC3: Check for Enrollment Agent Templates
            esc3_findings = self._check_esc3(templates)
            esc_findings.extend(esc3_findings)
            
            # ESC4: Check Template Access Control (requires ACL data)
            esc4_findings = self._check_esc4(templates)
            esc_findings.extend(esc4_findings)
            
            # ESC6: Check EDITF_ATTRIBUTESUBJECTALTNAME2
            esc6_findings = await self._check_esc6(cas, scan_options)
            esc_findings.extend(esc6_findings)
            
            # ESC8: Check for Web Enrollment Endpoints
            esc8_findings = await self._check_esc8(cas, scan_options)
            esc_findings.extend(esc8_findings)
            
            # ESC9: Check for NO_SECURITY_EXTENSION
            esc9_findings = self._check_esc9(templates)
            esc_findings.extend(esc9_findings)
            
            result["esc_findings"] = esc_findings
            result["vulnerabilities"] = [f for f in esc_findings if f.get("vulnerable", False)]
            result["statistics"]["vulnerabilities_found"] = len(result["vulnerabilities"])
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during ADCS analysis: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result
    
    async def _enumerate_cas(self, scan_options: ScanOptions, config_dn: str) -> List[Dict[str, Any]]:
        """Enumerate Certificate Authorities"""
        cas = []
        
        try:
            ca_cmd = [
                'ldapsearch', '-x', '-h', scan_options.ldap_server,
                '-b', f"CN=Enrollment Services,CN=Public Key Services,CN=Services,{config_dn}",
                '(objectClass=pKIEnrollmentService)',
                'cn', 'dNSHostName', 'certificateTemplates', 'cACertificateDN', 'msPKI-Enrollment-Servers'
            ]
            
            if scan_options.username and scan_options.password:
                ca_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(ca_cmd, timeout=30)
            
            if rc == 0:
                for entry in (out or "").split('\n\n'):
                    cn_match = re.search(r'cn:\s*(.*?)$', entry, re.MULTILINE)
                    dns_match = re.search(r'dNSHostName:\s*(.*?)$', entry, re.MULTILINE)
                    enrollment_servers = re.findall(r'msPKI-Enrollment-Servers:\s*(.*?)$', entry, re.MULTILINE)
                    
                    if cn_match:
                        ca_info = {
                            "name": cn_match.group(1).strip(),
                            "dns_hostname": dns_match.group(1).strip() if dns_match else None,
                            "enrollment_servers": enrollment_servers,
                            "web_enrollment_enabled": bool(enrollment_servers)
                        }
                        cas.append(ca_info)
        
        except Exception:
            pass
        
        return cas
    
    async def _enumerate_templates(self, scan_options: ScanOptions, config_dn: str) -> List[Dict[str, Any]]:
        """Enumerate Certificate Templates with detailed properties"""
        templates = []
        
        try:
            template_cmd = [
                'ldapsearch', '-x', '-h', scan_options.ldap_server,
                '-b', f"CN=Certificate Templates,CN=Public Key Services,CN=Services,{config_dn}",
                '(objectClass=pKICertificateTemplate)',
                'cn', 'displayName', 'msPKI-Certificate-Name-Flag', 'msPKI-Enrollment-Flag',
                'pKIExtendedKeyUsage', 'msPKI-RA-Signature', 'msPKI-Certificate-Application-Policy',
                'msPKI-RA-Application-Policies', 'nTSecurityDescriptor'
            ]
            
            if scan_options.username and scan_options.password:
                template_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(template_cmd, timeout=60)
            
            if rc == 0:
                for entry in (out or "").split('\n\n'):
                    cn_match = re.search(r'cn:\s*(.*?)$', entry, re.MULTILINE)
                    name_flag_match = re.search(r'msPKI-Certificate-Name-Flag:\s*(\d+)', entry)
                    enrollment_flag_match = re.search(r'msPKI-Enrollment-Flag:\s*(\d+)', entry)
                    eku_matches = re.findall(r'pKIExtendedKeyUsage:\s*([\d.]+)', entry)
                    ra_signature_match = re.search(r'msPKI-RA-Signature:\s*(\d+)', entry)
                    app_policy_matches = re.findall(r'msPKI-Certificate-Application-Policy:\s*([\d.]+)', entry)
                    
                    if cn_match:
                        template_info = {
                            "name": cn_match.group(1).strip(),
                            "msPKI_Certificate_Name_Flag": int(name_flag_match.group(1)) if name_flag_match else 0,
                            "msPKI_Enrollment_Flag": int(enrollment_flag_match.group(1)) if enrollment_flag_match else 0,
                            "pKIExtendedKeyUsage": eku_matches,
                            "msPKI_RA_Signature": int(ra_signature_match.group(1)) if ra_signature_match else 0,
                            "msPKI_Certificate_Application_Policy": app_policy_matches,
                            "enrollee_supplies_subject": bool(int(name_flag_match.group(1)) & CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT) if name_flag_match else False,
                            "no_security_extension": bool(int(name_flag_match.group(1)) & CT_FLAG_NO_SECURITY_EXTENSION) if name_flag_match else False,
                            "requires_manager_approval": bool(int(enrollment_flag_match.group(1)) & 0x02) if enrollment_flag_match else False,
                            "autoenrollment_enabled": bool(int(enrollment_flag_match.group(1)) & 0x20) if enrollment_flag_match else False,
                        }
                        templates.append(template_info)
        
        except Exception:
            pass
        
        return templates
    
    def _check_esc1(self, templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Check ESC1: ENROLLEE_SUPPLIES_SUBJECT with Client Authentication EKU"""
        findings = []
        
        for template in templates:
            # ESC1: Template allows enrollee to supply subject AND has client auth EKU
            if template.get("enrollee_supplies_subject"):
                ekus = template.get("pKIExtendedKeyUsage", [])
                app_policies = template.get("msPKI_Certificate_Application_Policy", [])
                
                has_client_auth = (
                    EKU_CLIENT_AUTH in ekus or
                    EKU_SMART_CARD_LOGON in ekus or
                    EKU_PKINIT in ekus or
                    EKU_ANY_PURPOSE in ekus or
                    len(ekus) == 0 or  # No EKU means any purpose
                    EKU_CLIENT_AUTH in app_policies
                )
                
                if has_client_auth:
                    findings.append({
                        "esc_type": "ESC1",
                        "vulnerable": True,
                        "template_name": template["name"],
                        "details": ESC_VULNERABILITIES["ESC1"],
                        "evidence": {
                            "enrollee_supplies_subject": True,
                            "has_client_auth_eku": True,
                            "ekus": ekus,
                            "requires_manager_approval": template.get("requires_manager_approval", False)
                        }
                    })
        
        return findings
    
    def _check_esc2(self, templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Check ESC2: Any Purpose EKU or SubCA"""
        findings = []
        
        for template in templates:
            ekus = template.get("pKIExtendedKeyUsage", [])
            
            # Any Purpose EKU or no EKUs defined
            if EKU_ANY_PURPOSE in ekus or len(ekus) == 0:
                findings.append({
                    "esc_type": "ESC2",
                    "vulnerable": True,
                    "template_name": template["name"],
                    "details": ESC_VULNERABILITIES["ESC2"],
                    "evidence": {
                        "any_purpose_eku": EKU_ANY_PURPOSE in ekus,
                        "no_ekus_defined": len(ekus) == 0,
                        "ekus": ekus
                    }
                })
        
        return findings
    
    def _check_esc3(self, templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Check ESC3: Enrollment Agent Templates"""
        findings = []
        
        for template in templates:
            ekus = template.get("pKIExtendedKeyUsage", [])
            app_policies = template.get("msPKI_Certificate_Application_Policy", [])
            
            # Certificate Request Agent EKU
            if EKU_CERTIFICATE_REQUEST_AGENT in ekus or EKU_CERTIFICATE_REQUEST_AGENT in app_policies:
                findings.append({
                    "esc_type": "ESC3",
                    "vulnerable": True,
                    "template_name": template["name"],
                    "details": ESC_VULNERABILITIES["ESC3"],
                    "evidence": {
                        "has_enrollment_agent_eku": True,
                        "ekus": ekus
                    }
                })
        
        return findings
    
    def _check_esc4(self, templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Check ESC4: Vulnerable Template Access Control (requires ACL data)"""
        findings = []
        
        # Note: Full ESC4 checking requires parsing DACL from nTSecurityDescriptor
        # This is a placeholder for ACL-based vulnerability checking
        for template in templates:
            # Check if template ACL data is available
            # Full implementation would parse ntSecurityDescriptor
            pass
        
        return findings
    
    async def _check_esc6(self, cas: List[Dict[str, Any]], scan_options: ScanOptions) -> List[Dict[str, Any]]:
        """Check ESC6: EDITF_ATTRIBUTESUBJECTALTNAME2 Flag"""
        findings = []
        
        for ca in cas:
            ca_hostname = ca.get("dns_hostname")
            if not ca_hostname:
                continue
            
            # Check CA flags using certutil (if available)
            try:
                # This would require RPC access to CA
                # Placeholder for flag checking
                findings.append({
                    "esc_type": "ESC6",
                    "vulnerable": False,  # Need to verify
                    "ca_name": ca["name"],
                    "details": ESC_VULNERABILITIES["ESC6"],
                    "evidence": {
                        "ca_hostname": ca_hostname,
                        "note": "Manual verification required - check EDITF_ATTRIBUTESUBJECTALTNAME2 flag"
                    }
                })
            except Exception:
                pass
        
        return findings
    
    async def _check_esc8(self, cas: List[Dict[str, Any]], scan_options: ScanOptions) -> List[Dict[str, Any]]:
        """Check ESC8: NTLM Relay to AD CS HTTP Endpoints"""
        findings = []
        
        # Common web enrollment paths
        web_paths = [
            "/certsrv/",
            "/certenroll/",
            "/CertSrv/mscep/mscep.dll",
            "/ADPolicyProvider_CEP_Kerberos/service.svc",
            "/ADPolicyProvider_CEP_UsernamePassword/service.svc",
        ]
        
        for ca in cas:
            ca_hostname = ca.get("dns_hostname")
            if not ca_hostname:
                continue
            
            # Check for web enrollment endpoints
            if ca.get("web_enrollment_enabled"):
                findings.append({
                    "esc_type": "ESC8",
                    "vulnerable": True,
                    "ca_name": ca["name"],
                    "details": ESC_VULNERABILITIES["ESC8"],
                    "evidence": {
                        "ca_hostname": ca_hostname,
                        "web_enrollment_enabled": True,
                        "potential_endpoints": [f"http://{ca_hostname}{path}" for path in web_paths]
                    }
                })
        
        return findings
    
    def _check_esc9(self, templates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Check ESC9: No Security Extension"""
        findings = []
        
        for template in templates:
            if template.get("no_security_extension"):
                findings.append({
                    "esc_type": "ESC9",
                    "vulnerable": True,
                    "template_name": template["name"],
                    "details": ESC_VULNERABILITIES["ESC9"],
                    "evidence": {
                        "no_security_extension_flag": True,
                        "msPKI_Certificate_Name_Flag": template.get("msPKI_Certificate_Name_Flag", 0)
                    }
                })
        
        return findings
    
    def get_esc_info(self, esc_type: str) -> Optional[Dict[str, Any]]:
        """Get information about specific ESC vulnerability type"""
        return ESC_VULNERABILITIES.get(esc_type)
    
    def get_all_esc_types(self) -> List[str]:
        """Get list of all supported ESC vulnerability types"""
        return list(ESC_VULNERABILITIES.keys())
