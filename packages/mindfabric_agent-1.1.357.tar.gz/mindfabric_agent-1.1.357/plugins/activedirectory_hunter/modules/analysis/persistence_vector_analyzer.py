"""
Persistence Vector Analyzer Module

Searches for potential persistence vectors in domain structure
"""

from typing import List
from ...proto import (
    DirectoryType, ScanOptions, PersistenceMethod, PersistenceVector,
    User, Group, Computer, TrustRelationship, GPO
)


class PersistenceVectorAnalyzer:
    """Analyzes domain structure for potential persistence vectors"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType,
                users: List[User], groups: List[Group], computers: List[Computer],
                trusts: List[TrustRelationship], gpos: List[GPO]) -> List[PersistenceVector]:
        """
        Searches for potential persistence vectors in domain structure
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            users: User list
            groups: Group list
            computers: Computer list
            trusts: Trust relationship list
            gpos: Group Policy Object list
            
        Returns:
            List[PersistenceVector]: List of potential persistence vectors
        """
        persistence_vectors = []
        
        persistence_methods = scan_options.persistence_methods or list(PersistenceMethod)
        
        for method in persistence_methods:
            try:
                if method == PersistenceMethod.GOLDEN_TICKET:
                    krbtgt_account = None
                    for user in users:
                        if user.sam_account_name.lower() == 'krbtgt':
                            krbtgt_account = user
                            break
                    
                    if krbtgt_account:
                        details = {
                            "description": "Golden Ticket can be created, having access to krbtgt hash",
                            "command": f"kerberos::golden /domain:{scan_options.domain_name} /sid:<domain_sid> /krbtgt:<hash> /user:Administrator /ptt"
                        }
                        
                        persistence = PersistenceVector(
                            method=PersistenceMethod.GOLDEN_TICKET,
                            status="applicable",
                            details=details,
                            affected_objects=[krbtgt_account.distinguished_name],
                            cleanup_instructions="Need to reset password of krbtgt account entry twice and reboot all domain controllers"
                        )
                        
                        persistence_vectors.append(persistence)
                    else:
                        persistence = PersistenceVector(
                            method=PersistenceMethod.GOLDEN_TICKET,
                            status="not_applicable",
                            details={"description": "krbtgt account not found or not accessible"},
                            affected_objects=[],
                            cleanup_instructions=None
                        )
                        
                        persistence_vectors.append(persistence)
                
                elif method == PersistenceMethod.DCSHADOW:
                    if scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                            user_dn = None
                            for user in users:
                                if user.sam_account_name.lower() == scan_options.username.lower() or user.username.lower() == scan_options.username.lower():
                                    user_dn = user.distinguished_name
                                    break
                            
                            if user_dn:
                                admin_groups = ["Domain Admins", "Enterprise Admins", "Administrators"]
                                
                                is_admin = False
                                for user in users:
                                    if user.distinguished_name == user_dn:
                                        for group_dn in user.groups:
                                            for group in groups:
                                                if group.distinguished_name == group_dn:
                                                    if any(admin_group.lower() in group.name.lower() for admin_group in admin_groups):
                                                        is_admin = True
                                                        break
                                            if is_admin:
                                                break
                                        break
                                
                                if is_admin:
                                    details = {
                                        "description": "Current user has permissions to use DCShadow for injecting changes into directory",
                                        "command": "mimikatz # lsadump::dcshadow ..."
                                    }
                                    
                                    persistence = PersistenceVector(
                                        method=PersistenceMethod.DCSHADOW,
                                        status="applicable",
                                        details=details,
                                        affected_objects=[user_dn],
                                        cleanup_instructions="Monitor changes in directory using audit tools"
                                    )
                                    
                                    persistence_vectors.append(persistence)
                                else:
                                    persistence = PersistenceVector(
                                        method=PersistenceMethod.DCSHADOW,
                                        status="not_applicable",
                                        details={"description": "Current user does not have permissions on usage DCShadow"},
                                        affected_objects=[],
                                        cleanup_instructions=None
                                    )
                                    
                                    persistence_vectors.append(persistence)
                
                elif method == PersistenceMethod.COMPUTER_ACCOUNT:
                    if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                        details = {
                            "description": "creation computeraccounts can be used for domain persistence",
                            "command": f"PowerShell New-ADComputer -Name \"BackdoorComputer\" -SamAccountName \"BackdoorComputer$\" -Path \"CN=Computers,DC={',DC='.join(scan_options.domain_name.split('.'))}\" -Enabled $true"
                        }
                        
                        if scan_options.domain_name:
                            domain_parts = scan_options.domain_name.split('.')
                            domain_path = f"CN=Computers,DC={',DC='.join(domain_parts)}"
                            details["command"] = f"PowerShell New-ADComputer -Name \"BackdoorComputer\" -SamAccountName \"BackdoorComputer$\" -Path \"{domain_path}\" -Enabled $true"
                        
                        persistence = PersistenceVector(
                            method=PersistenceMethod.COMPUTER_ACCOUNT,
                            status="potentially_applicable",
                            details=details,
                            affected_objects=[],
                            cleanup_instructions="Regularly check for presence of unused or suspicious computer accounts in domain. Install restrictions on creation of computer accounts by regular users."
                        )
                        
                        persistence_vectors.append(persistence)
                
                elif method == PersistenceMethod.SHADOW_ADMINS:
                    if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                        if scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                            user_dn = None
                            for user in users:
                                if user.sam_account_name.lower() == scan_options.username.lower() or user.username.lower() == scan_options.username.lower():
                                    user_dn = user.distinguished_name
                                    break
                            
                            if user_dn:
                                admin_groups = ["Domain Admins", "Enterprise Admins", "Administrators"]
                                
                                is_admin = False
                                for user in users:
                                    if user.distinguished_name == user_dn:
                                        for group_dn in user.groups:
                                            for group in groups:
                                                if group.distinguished_name == group_dn:
                                                    if any(admin_group.lower() in group.name.lower() for admin_group in admin_groups):
                                                        is_admin = True
                                                        break
                                            if is_admin:
                                                break
                                        break
                                
                                if is_admin:
                                    details = {
                                        "description": "Current user has permissions on creation Shadow Admin by assigning specific permissions",
                                        "command": f"PowerShell Add-DomainObjectAcl -TargetIdentity \"DC={',DC='.join(scan_options.domain_name.split('.'))}\" -PrincipalIdentity \"HackerAccount\" -Rights DCSync"
                                    }
                                    
                                    if scan_options.domain_name:
                                        domain_parts = scan_options.domain_name.split('.')
                                        domain_path = f"DC={',DC='.join(domain_parts)}"
                                        details["command"] = f"PowerShell Add-DomainObjectAcl -TargetIdentity \"{domain_path}\" -PrincipalIdentity \"HackerAccount\" -Rights DCSync"
                                    
                                    persistence = PersistenceVector(
                                        method=PersistenceMethod.SHADOW_ADMINS,
                                        status="applicable",
                                        details=details,
                                        affected_objects=[user_dn],
                                        cleanup_instructions="Regularly check extended permissions on objects domain. Use tools type BloodHound for detection unusual paths to privileged objects."
                                    )
                                    
                                    persistence_vectors.append(persistence)
                                else:
                                    persistence = PersistenceVector(
                                        method=PersistenceMethod.SHADOW_ADMINS,
                                        status="not_applicable",
                                        details={"description": "Current user does not have permissions on creation Shadow Admin"},
                                        affected_objects=[],
                                        cleanup_instructions=None
                                    )
                                    
                                    persistence_vectors.append(persistence)
                
            except Exception as e:
                persistence = PersistenceVector(
                    method=method,
                    status="error",
                    details={"description": f"Error during analysis: {str(e)}"},
                    affected_objects=[],
                    cleanup_instructions=None
                )
                
                persistence_vectors.append(persistence)
        
        return persistence_vectors

