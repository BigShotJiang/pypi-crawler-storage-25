"""
Shadow Admin Finder Module

Finds shadow administrators with excessive permissions through ACL analysis.
Shadow admins are non-admin users who have been granted elevated privileges
through ACLs, group membership, or delegated permissions.
"""

import re
import time
import base64
from typing import Dict, Any, List, Set, Optional
from ...proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


# =============================================================================
# Dangerous Rights GUIDs (for ACL analysis)
# =============================================================================

DANGEROUS_RIGHTS = {
    # Extended Rights
    "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2": "DS-Replication-Get-Changes (DCSync)",
    "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2": "DS-Replication-Get-Changes-All (DCSync)",
    "89e95b76-444d-4c62-991a-0facbeda640c": "DS-Replication-Get-Changes-In-Filtered-Set",
    "00299570-246d-11d0-a768-00aa006e0529": "User-Force-Change-Password",
    "ab721a54-1e2f-11d0-9819-00aa0040529b": "User-Send-As",
    "ab721a56-1e2f-11d0-9819-00aa0040529b": "User-Receive-As",
    "00000000-0000-0000-0000-000000000000": "All Extended Rights",
    
    # Property Access Rights
    "bf967a68-0de6-11d0-a285-00aa003049e2": "Write-Property (all)",
    "bf967950-0de6-11d0-a285-00aa003049e2": "Write-Member",
    "bf9679c0-0de6-11d0-a285-00aa003049e2": "Write-msDS-AllowedToDelegateTo",
    "3f78c3e5-f79a-46bd-a0b8-9d18116ddc79": "Write-msDS-AllowedToActOnBehalfOfOtherIdentity",
    "f30e3bbf-9ff0-11d0-b603-0000f80367c1": "Write-GPLink",
    
    # Control Rights
    "bf967aba-0de6-11d0-a285-00aa003049e2": "Write-SPN",
    "72e39547-7b18-11d1-adef-00c04fd8d5cd": "Validated-Write-SPN",
}

# Dangerous ACL permissions
DANGEROUS_PERMISSIONS = [
    "GenericAll",
    "GenericWrite", 
    "WriteDacl",
    "WriteOwner",
    "AllExtendedRights",
    "ForceChangePassword",
    "Self",  # Validated writes
]

# High-value target groups
HIGH_VALUE_GROUPS = [
    "Domain Admins",
    "Enterprise Admins",
    "Schema Admins",
    "Account Operators",
    "Backup Operators",
    "Server Operators",
    "Print Operators",
    "DnsAdmins",
    "Group Policy Creator Owners",
    "Cert Publishers",
    "Key Admins",
    "Enterprise Key Admins",
    "Administrators",
]

# AdminSDHolder protected groups
ADMINSDHOLDER_GROUPS = [
    "Domain Admins",
    "Enterprise Admins",
    "Schema Admins",
    "Account Operators",
    "Backup Operators",
    "Server Operators",
    "Print Operators",
    "Administrators",
    "Replicator",
    "Domain Controllers",
    "Read-only Domain Controllers",
]


class ShadowAdminFinder:
    """Finds shadow administrators through ACL and delegation analysis"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def find(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Finds shadow administrators with excessive permissions.
        
        Shadow admins are users who can:
        - Perform DCSync attacks
        - Modify privileged groups
        - Reset passwords of admins
        - Modify GPOs linked to privileged OUs
        - Write to AdminSDHolder
        - Own or have WriteDACL on privileged objects
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Findings including shadow admins and their paths
        """
        result = {
            "success": False,
            "shadow_admins": [],
            "dcsync_principals": [],
            "group_modifiers": [],
            "password_resetters": [],
            "gpo_modifiers": [],
            "adminsdholder_modifiers": [],
            "ownership_abusers": [],
            "delegation_abusers": [],
            "errors": [],
            "statistics": {
                "users_analyzed": 0,
                "groups_analyzed": 0,
                "acls_analyzed": 0,
                "shadow_admins_found": 0,
                "execution_time": 0
            },
            "recommendations": []
        }
        
        start_time = time.time()
        
        if directory_type != DirectoryType.ACTIVE_DIRECTORY:
            result["errors"].append("Shadow admin detection supported only for Active Directory")
            return result
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        ldap_server = scan_options.ldap_server
        if not ldap_server:
            # Try to discover
            if scan_options.use_domain_discovery:
                ldap_server = await self._discover_ldap_server(scan_options.domain_name)
            if not ldap_server:
                result["errors"].append("LDAP server not specified and discovery failed")
                return result
        
        try:
            base_dn = f"DC={',DC='.join(scan_options.domain_name.split('.'))}"
            
            # 1. Find principals with DCSync rights
            dcsync_principals = await self._find_dcsync_principals(
                scan_options, ldap_server, base_dn
            )
            result["dcsync_principals"] = dcsync_principals
            
            # 2. Find principals who can modify privileged groups
            group_modifiers = await self._find_group_modifiers(
                scan_options, ldap_server, base_dn
            )
            result["group_modifiers"] = group_modifiers
            
            # 3. Find principals who can reset admin passwords
            password_resetters = await self._find_password_resetters(
                scan_options, ldap_server, base_dn
            )
            result["password_resetters"] = password_resetters
            
            # 4. Find GPO modifiers
            gpo_modifiers = await self._find_gpo_modifiers(
                scan_options, ldap_server, base_dn
            )
            result["gpo_modifiers"] = gpo_modifiers
            
            # 5. Find AdminSDHolder modifiers
            adminsdholder_modifiers = await self._find_adminsdholder_modifiers(
                scan_options, ldap_server, base_dn
            )
            result["adminsdholder_modifiers"] = adminsdholder_modifiers
            
            # 6. Find ownership abusers
            ownership_abusers = await self._find_ownership_abusers(
                scan_options, ldap_server, base_dn
            )
            result["ownership_abusers"] = ownership_abusers
            
            # 7. Find delegation abusers
            delegation_abusers = await self._find_delegation_abusers(
                scan_options, ldap_server, base_dn
            )
            result["delegation_abusers"] = delegation_abusers
            
            # Consolidate all shadow admins
            all_shadow_admins: Set[str] = set()
            
            for item in dcsync_principals:
                all_shadow_admins.add(item.get("principal", ""))
            for item in group_modifiers:
                all_shadow_admins.add(item.get("principal", ""))
            for item in password_resetters:
                all_shadow_admins.add(item.get("principal", ""))
            for item in gpo_modifiers:
                all_shadow_admins.add(item.get("principal", ""))
            for item in adminsdholder_modifiers:
                all_shadow_admins.add(item.get("principal", ""))
            for item in ownership_abusers:
                all_shadow_admins.add(item.get("principal", ""))
            for item in delegation_abusers:
                all_shadow_admins.add(item.get("principal", ""))
            
            # Remove known admin groups
            known_admins = {"Domain Admins", "Enterprise Admins", "SYSTEM", "Administrators"}
            all_shadow_admins = {sa for sa in all_shadow_admins if sa and sa not in known_admins}
            
            # Build final shadow admin list with details
            for principal in all_shadow_admins:
                shadow_admin = {
                    "principal": principal,
                    "attack_paths": [],
                    "severity": "high",
                }
                
                # Add attack paths
                for item in dcsync_principals:
                    if item.get("principal") == principal:
                        shadow_admin["attack_paths"].append({
                            "type": "DCSync",
                            "target": "Domain",
                            "description": "Can perform DCSync to extract all password hashes",
                        })
                        shadow_admin["severity"] = "critical"
                
                for item in group_modifiers:
                    if item.get("principal") == principal:
                        shadow_admin["attack_paths"].append({
                            "type": "Group Modification",
                            "target": item.get("group", ""),
                            "description": f"Can add members to {item.get('group', '')}",
                        })
                
                for item in password_resetters:
                    if item.get("principal") == principal:
                        shadow_admin["attack_paths"].append({
                            "type": "Password Reset",
                            "target": item.get("target_user", ""),
                            "description": f"Can reset password of {item.get('target_user', '')}",
                        })
                
                for item in gpo_modifiers:
                    if item.get("principal") == principal:
                        shadow_admin["attack_paths"].append({
                            "type": "GPO Modification",
                            "target": item.get("gpo", ""),
                            "description": f"Can modify GPO {item.get('gpo', '')} linked to privileged OU",
                        })
                
                for item in adminsdholder_modifiers:
                    if item.get("principal") == principal:
                        shadow_admin["attack_paths"].append({
                            "type": "AdminSDHolder",
                            "target": "AdminSDHolder",
                            "description": "Can modify AdminSDHolder to gain persistent admin access",
                        })
                        shadow_admin["severity"] = "critical"
                
                result["shadow_admins"].append(shadow_admin)
            
            # Generate recommendations
            result["recommendations"] = self._generate_recommendations(result)
            
            # Update statistics
            result["statistics"]["shadow_admins_found"] = len(result["shadow_admins"])
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during shadow admin detection: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result
    
    async def _discover_ldap_server(self, domain_name: str) -> Optional[str]:
        """Discover LDAP server via DNS."""
        try:
            rc, out, _ = await run_exec(
                ["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"],
                timeout=10,
            )
            
            if rc == 0 and (out or "").strip():
                line = (out or "").strip().splitlines()[0]
                parts = line.strip().split()
                return parts[-1].rstrip('.')
        except Exception:
            pass
        return None
    
    async def _find_dcsync_principals(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find principals with DCSync rights (DS-Replication-Get-Changes)."""
        principals = []
        
        try:
            # Query the domain root for nTSecurityDescriptor
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '-s', 'base',
                '(objectClass=domain)',
                'nTSecurityDescriptor'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                # Parse ACL for replication rights
                # Look for GUIDs: 1131f6aa-9c07-11d1-f79f-00c04fc2dcd2 and 1131f6ad-9c07-11d1-f79f-00c04fc2dcd2
                output = out or ""
                
                # This is simplified - real implementation would parse the binary SD
                if "Replication" in output or "1131f6a" in output:
                    # Found potential DCSync rights - need to identify principal
                    principals.append({
                        "principal": "Potential DCSync holder detected",
                        "right": "DS-Replication-Get-Changes-All",
                        "target": base_dn,
                        "note": "Full ACL parsing required for exact principal"
                    })
        except Exception as e:
            pass
        
        return principals
    
    async def _find_group_modifiers(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find principals who can modify privileged groups."""
        modifiers = []
        
        for group_name in HIGH_VALUE_GROUPS:
            try:
                cmd = [
                    'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                    '-b', base_dn,
                    f'(&(objectClass=group)(cn={group_name}))',
                    'distinguishedName', 'nTSecurityDescriptor'
                ]
                
                if scan_options.username and scan_options.password:
                    cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                
                rc, out, _ = await run_exec(cmd, timeout=30)
                
                if rc == 0:
                    # Check for WriteMember, GenericWrite, or GenericAll
                    output = out or ""
                    
                    if any(perm in output for perm in DANGEROUS_PERMISSIONS):
                        modifiers.append({
                            "principal": "Non-admin principal with write access",
                            "group": group_name,
                            "permission": "WriteMember/GenericWrite",
                            "note": "Detailed ACL parsing needed"
                        })
            except Exception:
                pass
        
        return modifiers
    
    async def _find_password_resetters(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find principals who can reset admin passwords."""
        resetters = []
        
        try:
            # Find admin users
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '(&(objectClass=user)(adminCount=1))',
                'distinguishedName', 'sAMAccountName'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                # Parse admin users and check their ACLs
                entries = (out or "").split('\n\n')
                
                for entry in entries:
                    sam_match = re.search(r'sAMAccountName:\s*(\S+)', entry)
                    if sam_match:
                        admin_user = sam_match.group(1)
                        
                        # Check for User-Force-Change-Password extended right
                        # This would require additional ACL query
                        resetters.append({
                            "principal": "Check for password reset rights",
                            "target_user": admin_user,
                            "note": "Review User-Force-Change-Password ACE"
                        })
        except Exception:
            pass
        
        return resetters[:5]  # Limit output
    
    async def _find_gpo_modifiers(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find principals who can modify GPOs linked to privileged OUs."""
        modifiers = []
        
        try:
            # Find GPOs
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', f'CN=Policies,CN=System,{base_dn}',
                '(objectClass=groupPolicyContainer)',
                'displayName', 'gPCFileSysPath', 'distinguishedName'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                # Parse GPOs
                entries = (out or "").split('\n\n')
                
                for entry in entries:
                    name_match = re.search(r'displayName:\s*(.+)$', entry, re.M)
                    if name_match:
                        gpo_name = name_match.group(1).strip()
                        
                        # Check if GPO is linked to Domain Controllers or similar OU
                        if "Default Domain" in gpo_name or "Controller" in gpo_name:
                            modifiers.append({
                                "principal": "Check GPO ACL",
                                "gpo": gpo_name,
                                "note": "Review GPC and GPT ACLs for non-admin writers"
                            })
        except Exception:
            pass
        
        return modifiers
    
    async def _find_adminsdholder_modifiers(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find principals who can modify AdminSDHolder."""
        modifiers = []
        
        try:
            # Query AdminSDHolder
            admin_sd_dn = f"CN=AdminSDHolder,CN=System,{base_dn}"
            
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', admin_sd_dn,
                '-s', 'base',
                '(objectClass=*)',
                'nTSecurityDescriptor'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                # Check for non-admin principals with write access
                output = out or ""
                
                if any(perm in output for perm in ["GenericAll", "WriteDacl", "WriteOwner"]):
                    modifiers.append({
                        "principal": "Non-admin with AdminSDHolder access",
                        "target": "AdminSDHolder",
                        "permission": "WriteDacl/GenericAll",
                        "impact": "Can gain persistent admin access on all protected accounts"
                    })
        except Exception:
            pass
        
        return modifiers
    
    async def _find_ownership_abusers(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find non-admin principals who own privileged objects."""
        abusers = []
        
        try:
            # Find objects owned by non-admin users
            # This is simplified - real implementation needs to compare owner SIDs
            
            for group in HIGH_VALUE_GROUPS[:3]:
                cmd = [
                    'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                    '-b', base_dn,
                    f'(&(objectClass=group)(cn={group}))',
                    'nTSecurityDescriptor'
                ]
                
                if scan_options.username and scan_options.password:
                    cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                
                rc, _, _ = await run_exec(cmd, timeout=30)
                
                if rc == 0:
                    # Would parse SD to get owner SID
                    # Check if owner is not Domain Admins/Enterprise Admins
                    pass
        except Exception:
            pass
        
        return abusers
    
    async def _find_delegation_abusers(
        self,
        scan_options: ScanOptions,
        ldap_server: str,
        base_dn: str,
    ) -> List[Dict[str, Any]]:
        """Find accounts with dangerous delegation settings."""
        abusers = []
        
        try:
            # Find accounts with unconstrained delegation
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '(&(objectClass=computer)(userAccountControl:1.2.840.113556.1.4.803:=524288))',
                'sAMAccountName', 'dNSHostName'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                entries = (out or "").split('\n\n')
                
                for entry in entries:
                    sam_match = re.search(r'sAMAccountName:\s*(\S+)', entry)
                    if sam_match and 'DC' not in sam_match.group(1).upper():
                        abusers.append({
                            "principal": sam_match.group(1),
                            "delegation_type": "Unconstrained",
                            "risk": "Can capture TGTs from any connecting user"
                        })
            
            # Find accounts with constrained delegation to sensitive services
            cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '(msDS-AllowedToDelegateTo=*)',
                'sAMAccountName', 'msDS-AllowedToDelegateTo'
            ]
            
            if scan_options.username and scan_options.password:
                cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, _ = await run_exec(cmd, timeout=30)
            
            if rc == 0:
                entries = (out or "").split('\n\n')
                
                for entry in entries:
                    sam_match = re.search(r'sAMAccountName:\s*(\S+)', entry)
                    delegate_match = re.findall(r'msDS-AllowedToDelegateTo:\s*(\S+)', entry)
                    
                    if sam_match and delegate_match:
                        # Check if delegating to sensitive services
                        sensitive_services = ['ldap', 'cifs', 'http', 'wsman', 'mssql']
                        
                        for target in delegate_match:
                            if any(svc in target.lower() for svc in sensitive_services):
                                abusers.append({
                                    "principal": sam_match.group(1),
                                    "delegation_type": "Constrained",
                                    "target_service": target,
                                    "risk": f"Can impersonate users to {target}"
                                })
        except Exception:
            pass
        
        return abusers
    
    def _generate_recommendations(self, result: Dict[str, Any]) -> List[str]:
        """Generate remediation recommendations."""
        recommendations = []
        
        if result.get("dcsync_principals"):
            recommendations.append(
                "Remove DCSync rights from non-admin principals immediately. "
                "Only Domain Controllers and authorized backup solutions should have replication rights."
            )
        
        if result.get("group_modifiers"):
            recommendations.append(
                "Review and restrict write access to privileged groups. "
                "Use AdminSDHolder to protect admin groups from unauthorized modifications."
            )
        
        if result.get("adminsdholder_modifiers"):
            recommendations.append(
                "CRITICAL: Unauthorized access to AdminSDHolder detected. "
                "This allows persistent admin access. Remove non-admin access immediately."
            )
        
        if result.get("delegation_abusers"):
            recommendations.append(
                "Review unconstrained delegation settings. "
                "Replace with constrained or resource-based constrained delegation where possible. "
                "Add sensitive accounts to 'Protected Users' group."
            )
        
        if result.get("shadow_admins"):
            recommendations.extend([
                "Audit all identified shadow admins and remove unnecessary privileges",
                "Implement tiered administration model",
                "Enable Advanced Audit Policy for AD object access",
                "Consider using Privileged Access Workstations (PAWs)",
                "Review group membership regularly using automated tools"
            ])
        
        return recommendations

