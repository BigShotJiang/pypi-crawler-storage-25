"""
ACL Analyzer Module

Analyzes Access Control Lists (ACLs) for vulnerabilities
"""

import re
import time
from typing import Dict, Any, List
from ...proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


class ACLAnalyzer:
    """Analyzes ACLs for vulnerabilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType,
                     target_object: str = None) -> Dict[str, Any]:
        """
        Analyzes ACLs for vulnerabilities
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            target_object: Target object DN (default: domain root)
            
        Returns:
            Dict[str, Any]: Analysis results
        """
        result = {
            "success": False,
            "vulnerabilities": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if directory_type != DirectoryType.ACTIVE_DIRECTORY:
            result["errors"].append("ACL analysis supported only for Active Directory")
            return result
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not scan_options.ldap_server:
            result["errors"].append("LDAP server not specified")
            return result
        
        try:
            if not target_object:
                domain_parts = scan_options.domain_name.split('.')
                target_object = f"dc={',dc='.join(domain_parts)}"
            
            # Query ACLs using ldapsearch
            ldapsearch_cmd = [
                'ldapsearch', '-x', '-h', scan_options.ldap_server,
                '-b', target_object,
                '-o', 'ldif-wrap=no',
                '(objectClass=*)',
                'nTSecurityDescriptor'
            ]
            
            if scan_options.username and scan_options.password:
                ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, err = await run_exec(ldapsearch_cmd, timeout=60)
            
            if rc == 0:
                vulnerabilities = []
                
                # Parse security descriptor (simplified)
                # Full parsing would require decoding binary security descriptor
                if 'nTSecurityDescriptor' in (out or ""):
                    vulnerabilities.append({
                        "type": "acl_found",
                        "description": "ACL found on object",
                        "target": target_object,
                        "risk": "medium",
                        "recommendation": "Review ACL for excessive permissions"
                    })
                
                result["vulnerabilities"] = vulnerabilities
                result["success"] = True
            else:
                result["errors"].append(f"Failed to query ACLs: {err}")
        
        except Exception as e:
            result["errors"].append(f"Error during ACL analysis: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

