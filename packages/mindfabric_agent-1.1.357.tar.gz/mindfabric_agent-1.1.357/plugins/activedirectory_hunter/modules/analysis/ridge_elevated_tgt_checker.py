"""
Ridge Elevated TGT Checker Module

Checks for presence and possibility of exploiting TGT tickets with non-standard flags (Ridge-elevated TGT)
"""

import os
import re
import asyncio
import tempfile
import time
import shutil
from typing import Dict, Any
from ...proto import ScanOptions, DirectoryType
from ..core.directory_detector import DirectoryDetector
from utils.async_subprocess import run_exec


class RidgeElevatedTGTChecker:
    """Checks for Ridge-elevated TGT tickets"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.directory_detector = DirectoryDetector(plugin_instance)
    
    async def check(self, scan_options: ScanOptions, target_service: str = None) -> Dict[str, Any]:
        """
        Checks for presence and possibility of exploiting TGT tickets with non-standard flags
        
        Args:
            scan_options: Scan parameters
            target_service: Target service for checking exploitation (optional)
            
        Returns:
            Dict[str, Any]: Results checking Ridge-elevated TGT
        """
        result = {
            "success": False,
            "vulnerable": False,
            "ridge_elevated_tickets": [],
            "exploitation_test": None,
            "statistics": {
                "total_tickets_checked": 0,
                "vulnerable_tickets": 0,
                "execution_time": 0
            },
            "errors": [],
            "mitigation": []
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            directory_type = await self.directory_detector.determine_type(scan_options)
            
            if directory_type != DirectoryType.ACTIVE_DIRECTORY:
                result["errors"].append("Checking Ridge-elevated TGT supported only for Active directory")
                return result
            
            # Step 1: Getting current Kerberos TGT
            try:
                temp_dir = tempfile.mkdtemp()
                import random
                temp_ccache = os.path.join(temp_dir, f"krb5cc_{random.randint(1000, 9999)}")
                env = {**os.environ, "KRB5CCNAME": temp_ccache}
                
                realm = scan_options.domain_name.upper()
                kerberos_principal = f"{scan_options.username}@{realm}"
                
                # Using kinit for obtaining TGT
                if scan_options.password:
                    kinit_cmd = ['kinit', kerberos_principal]
                    rc, _, err = await run_exec(kinit_cmd, stdin=f"{scan_options.password}\n", env=env, timeout=30)
                else:
                    result["errors"].append("Direct TGT obtaining via NTLM-Hash not supported by kinit, use password or impacket for testing")
                    return result
                
                if rc != 0:
                    result["errors"].append(f"Error obtaining TGT: {err}")
                    return result
                
                # Step 2: Checking obtained tickets using klist
                klist_cmd = ['klist', '-f', '-v']
                klist_rc, klist_out, klist_err = await run_exec(klist_cmd, env=env, timeout=30)
                
                if klist_rc != 0:
                    result["errors"].append(f"Error checking Kerberos tickets: {klist_err}")
                    return result
                
                # Analyzing klist output for presence of non-standard flags and RC4 encryption
                tickets_analyzed = 0
                tickets_with_ridge_flags = []
                klist_output = klist_out or ""
                
                # Searching for TGT tickets with flags 0x60 and RC4 encryption
                tgt_entries = re.finditer(
                    r'(?:Ticket\s+(\d+)|Principal:\s+(.*?)\n.*?)Flags:\s+0x([0-9a-f]+).*?Encryption\s+type:\s+(.*?)\n',
                    klist_output, re.DOTALL
                )
                
                for entry in tgt_entries:
                    tickets_analyzed += 1
                    ticket_number = entry.group(1) or "N/A"
                    principal = entry.group(2) or "Unknown"
                    flags_hex = entry.group(3) or "0"
                    encryption_type = entry.group(4) or "Unknown"
                    
                    flags = int(flags_hex, 16)
                    
                    # Checking for Ridge-elevated TGT (Flags 0x60 and RC4 encryption)
                    if (flags & 0x60) == 0x60 and ("rc4" in encryption_type.lower() or "arcfour" in encryption_type.lower()):
                        ticket_info = {
                            "ticket_number": ticket_number,
                            "principal": principal.strip(),
                            "flags": f"0x{flags:x}",
                            "encryption_type": encryption_type.strip(),
                            "ridge_elevated": True
                        }
                        tickets_with_ridge_flags.append(ticket_info)
                
                result["statistics"]["total_tickets_checked"] = tickets_analyzed
                result["statistics"]["vulnerable_tickets"] = len(tickets_with_ridge_flags)
                result["ridge_elevated_tickets"] = tickets_with_ridge_flags
                
                if len(tickets_with_ridge_flags) > 0:
                    result["vulnerable"] = True
                    
                    result["mitigation"] = [
                        "Update domain controllers to latest versions",
                        "Enable AES encryption for Kerberos authentication",
                        "Disable RC4 support in group policies where possible",
                        "Monitor security events for unusual tickets with long lifetime"
                    ]
                    
                    # Step 3: Attempt exploitation, if vulnerable tickets found
                    if target_service:
                        try:
                            # Checking via SMB
                            if target_service.lower().startswith("smb://"):
                                target_server = target_service[6:]
                                smbclient_cmd = ['smbclient', '-k', f'//{target_server}/IPC$', '-c', 'ls']
                                smb_rc, smb_out, smb_err = await run_exec(smbclient_cmd, env=env, timeout=30)
                                
                                exploitation_succeeded = smb_rc == 0
                                
                                result["exploitation_test"] = {
                                    "service_type": "SMB",
                                    "target": target_server,
                                    "succeeded": exploitation_succeeded,
                                    "output": smb_out if exploitation_succeeded else smb_err
                                }
                            
                            # Checking via HTTP
                            elif target_service.lower().startswith(("http://", "https://")):
                                try:
                                    import requests_kerberos
                                    
                                    kerberos_auth = requests_kerberos.HTTPKerberosAuth()
                                    rq = __import__("requests")
                                    response = await asyncio.to_thread(rq.get, target_service, auth=kerberos_auth)
                                    
                                    exploitation_succeeded = response.status_code < 400
                                    
                                    result["exploitation_test"] = {
                                        "service_type": "HTTP",
                                        "target": target_service,
                                        "succeeded": exploitation_succeeded,
                                        "status_code": response.status_code,
                                        "response_size": len(response.content)
                                    }
                                except ImportError:
                                    result["exploitation_test"] = {
                                        "service_type": "HTTP",
                                        "target": target_service,
                                        "succeeded": False,
                                        "error": "requests and requests_kerberos libraries required"
                                    }
                            else:
                                result["exploitation_test"] = {
                                    "service_type": "Unknown",
                                    "target": target_service,
                                    "succeeded": False,
                                    "error": "Unsupported service type. Supported smb:// and http(s)://"
                                }
                        
                        except Exception as e:
                            result["exploitation_test"] = {
                                "service_type": "Error",
                                "target": target_service,
                                "succeeded": False,
                                "error": str(e)
                            }
                
                # Cleanup temporary tickets
                try:
                    await run_exec(['kdestroy'], env=env, timeout=10)
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass
                    
            except Exception as e:
                result["errors"].append(f"Error while checking TGT: {str(e)}")
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

