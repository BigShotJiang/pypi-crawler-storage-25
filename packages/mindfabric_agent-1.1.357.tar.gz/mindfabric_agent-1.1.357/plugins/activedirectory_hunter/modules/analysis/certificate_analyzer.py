"""
Certificate Analyzer Module

Analyzes certificates in Active Directory environment
"""

import time
from typing import Dict, Any, List
from ...proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


class CertificateAnalyzer:
    """Analyzes certificates"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def analyze(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Analyzes certificates in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Analysis results
        """
        result = {
            "success": False,
            "certificates": [],
            "vulnerabilities": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        try:
            if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                # Search for Certificate Templates and Certificate Authorities
                details = {
                    "description": "Certificate analysis requires ADCS (Active Directory Certificate Services)",
                    "method": "Query CN=Certificate Templates,CN=Public Key Services,CN=Services,CN=Configuration",
                    "note": "Look for misconfigured certificate templates"
                }
                result["details"] = details
            
            elif directory_type == DirectoryType.FREEIPA:
                # FreeIPA has built-in PKI
                try:
                    if scan_options.username and scan_options.password:
                        await run_exec(
                            ["kinit", scan_options.username],
                            stdin=f"{scan_options.password}\n",
                            timeout=10,
                        )
                        
                        rc, out, _ = await run_exec(["ipa", "cert-find", "--all"], timeout=30)
                        
                        if rc == 0:
                            result["certificates_found"] = True
                            result["details"] = out or ""
                except Exception:
                    pass
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during certificate analysis: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

