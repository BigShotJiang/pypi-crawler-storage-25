"""
Computer Enumerator Module

Enumerates computers in Active Directory or FreeIPA domains
"""

import os
import re
import base64
from datetime import datetime
from typing import List
from ...proto import DirectoryType, ScanOptions, Computer
from utils.async_subprocess import run_exec


class ComputerEnumerator:
    """Enumerates computers in domain"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions, directory_type: DirectoryType) -> List[Computer]:
        """
        Enumerates computers in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            List[Computer]: Computer list
        """
        computers = []
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            ldap_server = scan_options.ldap_server
            domain_name = scan_options.domain_name
            
            if ldap_server is None and scan_options.use_domain_discovery:
                try:
                    rc, out, _ = await run_exec(["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"], timeout=5)
                    
                    if rc == 0 and (out or "").strip():
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]
                except Exception:
                    return computers
            
            if ldap_server and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                
                try:
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', ldap_server,
                        '-b', base_dn, 
                        '(objectClass=computer)', 
                        'sAMAccountName', 'distinguishedName', 'dNSHostName', 'operatingSystem',
                        'operatingSystemVersion', 'servicePrincipalName', 'userAccountControl',
                        'lastLogonTimestamp', 'pwdLastSet', 'objectSid', 'isCriticalSystemObject'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        computer_entries = (out or "").split('\n\n')
                        
                        for entry in computer_entries:
                            if not entry.strip():
                                continue
                            
                            try:
                                dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                                sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                                dns_match = re.search(r'dNSHostName:\s*(.*?)$', entry, re.MULTILINE)
                                
                                if dn_match and sam_match:
                                    distinguished_name = dn_match.group(1).strip()
                                    sam_account_name = sam_match.group(1).strip()
                                    dns_hostname = dns_match.group(1).strip() if dns_match else None
                                    
                                    os_match = re.search(r'operatingSystem:\s*(.*?)$', entry, re.MULTILINE)
                                    os_version_match = re.search(r'operatingSystemVersion:\s*(.*?)$', entry, re.MULTILINE)
                                    
                                    os = os_match.group(1).strip() if os_match else None
                                    os_version = os_version_match.group(1).strip() if os_version_match else None
                                    
                                    spns = []
                                    spn_matches = re.findall(r'servicePrincipalName:\s*(.*?)$', entry, re.MULTILINE)
                                    spns.extend([s.strip() for s in spn_matches])
                                    
                                    uac_match = re.search(r'userAccountControl:\s*(\d+)', entry)
                                    enabled = True
                                    is_domain_controller = False
                                    delegation_permitted = False
                                    
                                    if uac_match:
                                        uac = int(uac_match.group(1))
                                        enabled = (uac & 2) == 0
                                        is_domain_controller = (uac & 0x2000) != 0
                                        delegation_permitted = (uac & 0x80000) == 0
                                    
                                    is_sensitive = False
                                    critical_match = re.search(r'isCriticalSystemObject:\s*(.*?)$', entry, re.MULTILINE)
                                    if critical_match and critical_match.group(1).lower() == 'true':
                                        is_sensitive = True
                                    
                                    sid = None
                                    sid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', entry)
                                    if sid_match:
                                        try:
                                            sid_base64 = sid_match.group(1)
                                            sid_binary = base64.b64decode(sid_base64)
                                            sid = f"S-1-5-21-{sid_binary[-12:-8].hex()}-{sid_binary[-8:-4].hex()}-{sid_binary[-4:].hex()}"
                                        except Exception:
                                            pass
                                    
                                    last_logon = None
                                    last_logon_match = re.search(r'lastLogonTimestamp:\s*(\d+)', entry)
                                    if last_logon_match:
                                        try:
                                            filetime = int(last_logon_match.group(1))
                                            unix_time = (filetime / 10000000) - 11644473600
                                            last_logon = datetime.fromtimestamp(unix_time)
                                        except Exception:
                                            pass
                                    
                                    password_last_set = None
                                    pwd_last_set_match = re.search(r'pwdLastSet:\s*(\d+)', entry)
                                    if pwd_last_set_match:
                                        try:
                                            filetime = int(pwd_last_set_match.group(1))
                                            unix_time = (filetime / 10000000) - 11644473600
                                            password_last_set = datetime.fromtimestamp(unix_time)
                                        except Exception:
                                            pass
                                    
                                    computer = Computer(
                                        distinguished_name=distinguished_name,
                                        object_class=["top", "computer"],
                                        attributes={},
                                        domain=domain_name,
                                        name=sam_account_name.replace('$', ''),
                                        dns_hostname=dns_hostname,
                                        sam_account_name=sam_account_name,
                                        os=os,
                                        os_version=os_version,
                                        service_principal_names=spns,
                                        delegation_permitted=delegation_permitted,
                                        is_domain_controller=is_domain_controller,
                                        last_logon=last_logon,
                                        password_last_set=password_last_set,
                                        sid=sid,
                                        is_sensitive=is_sensitive
                                    )
                                    
                                    computers.append(computer)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        elif directory_type == DirectoryType.FREEIPA:
            if scan_options.username and scan_options.password:
                try:
                    await run_exec(
                        ["kinit", scan_options.username],
                        stdin=f"{scan_options.password}\n",
                        timeout=10,
                    )
                    
                    rc, out, _ = await run_exec(["ipa", "host-find", "--all"], timeout=30)
                    
                    if rc == 0:
                        host_entries = (out or "").split('Host name: ')
                        
                        for entry in host_entries[1:]:
                            try:
                                lines = entry.splitlines()
                                if not lines:
                                    continue
                                
                                hostname = lines[0].strip()
                                
                                dn = None
                                os = None
                                os_version = None
                                
                                for line in lines:
                                    if line.startswith('  LDAP DN: '):
                                        dn = line.replace('  LDAP DN: ', '').strip()
                                    elif line.startswith('  Operating system: '):
                                        os = line.replace('  Operating system: ', '').strip()
                                    elif line.startswith('  Operating system version: '):
                                        os_version = line.replace('  Operating system version: ', '').strip()
                                
                                computer = Computer(
                                    distinguished_name=dn or f"fqdn={hostname},cn=computers,cn=accounts,dc={',dc='.join(scan_options.domain_name.split('.'))}",
                                    object_class=["ipaHost", "ipaObject"],
                                    attributes={},
                                    domain=scan_options.domain_name,
                                    name=hostname.split('.')[0],
                                    dns_hostname=hostname,
                                    os=os,
                                    os_version=os_version
                                )
                                
                                computers.append(computer)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        return computers

