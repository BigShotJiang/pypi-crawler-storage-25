"""
Trust Relationship Enumerator Module

Enumerates trust relationships in Active Directory or FreeIPA domains
"""

import re
from datetime import datetime
from typing import List
from ...proto import DirectoryType, ScanOptions, TrustRelationship
from utils.async_subprocess import run_exec


class TrustEnumerator:
    """Enumerates trust relationships in domain"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions, directory_type: DirectoryType) -> List[TrustRelationship]:
        """
        Enumerates trust relationships in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            List[TrustRelationship]: Trust relationship list
        """
        trusts = []
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            ldap_server = scan_options.ldap_server
            domain_name = scan_options.domain_name
            
            if ldap_server is None and scan_options.use_domain_discovery:
                try:
                    rc, out, _ = await run_exec(["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"], timeout=5)
                    
                    if rc == 0 and (out or "").strip():
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]
                except Exception:
                    return trusts
            
            if ldap_server and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                
                try:
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', ldap_server,
                        '-b', base_dn, 
                        '(objectClass=trustedDomain)', 
                        'cn', 'trustDirection', 'trustType', 'trustAttributes', 'whenCreated'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        trust_entries = (out or "").split('\n\n')
                        
                        for entry in trust_entries:
                            if not entry.strip():
                                continue
                            
                            try:
                                cn_match = re.search(r'cn:\s*(.*?)$', entry, re.MULTILINE)
                                
                                if cn_match:
                                    target_domain = cn_match.group(1).strip()
                                    
                                    trust_direction = "Unknown"
                                    direction_match = re.search(r'trustDirection:\s*(\d+)', entry)
                                    if direction_match:
                                        direction_value = int(direction_match.group(1))
                                        if direction_value == 1:
                                            trust_direction = "Inbound"
                                        elif direction_value == 2:
                                            trust_direction = "Outbound"
                                        elif direction_value == 3:
                                            trust_direction = "Bidirectional"
                                    
                                    trust_type = "Unknown"
                                    type_match = re.search(r'trustType:\s*(\d+)', entry)
                                    if type_match:
                                        type_value = int(type_match.group(1))
                                        if type_value == 1:
                                            trust_type = "Windows NT"
                                        elif type_value == 2:
                                            trust_type = "Active Directory"
                                        elif type_value == 3:
                                            trust_type = "Kerberos Realm"
                                    
                                    trust_attributes = []
                                    attributes_match = re.search(r'trustAttributes:\s*(\d+)', entry)
                                    if attributes_match:
                                        attributes_value = int(attributes_match.group(1))
                                        if attributes_value & 0x1:
                                            trust_attributes.append("Non-Transitive")
                                        if attributes_value & 0x2:
                                            trust_attributes.append("Uplevel Only")
                                        if attributes_value & 0x4:
                                            trust_attributes.append("Quarantined")
                                        if attributes_value & 0x8:
                                            trust_attributes.append("Forest Transitive")
                                        if attributes_value & 0x10:
                                            trust_attributes.append("Cross-Organization")
                                        if attributes_value & 0x20:
                                            trust_attributes.append("Within Forest")
                                        if attributes_value & 0x40:
                                            trust_attributes.append("Treat as External")
                                        if attributes_value & 0x80:
                                            trust_attributes.append("Uses RC4 Encryption")
                                    
                                    created = None
                                    created_match = re.search(r'whenCreated:\s*(.*?)$', entry, re.MULTILINE)
                                    if created_match:
                                        created_str = created_match.group(1).strip()
                                        try:
                                            created = datetime.strptime(created_str, '%Y%m%d%H%M%S.0Z')
                                        except Exception:
                                            pass
                                    
                                    is_transitive = "Non-Transitive" not in trust_attributes
                                    
                                    trust = TrustRelationship(
                                        source_domain=domain_name,
                                        target_domain=target_domain,
                                        trust_type=trust_type,
                                        trust_direction=trust_direction,
                                        trust_attributes=trust_attributes,
                                        created=created,
                                        is_transitive=is_transitive
                                    )
                                    
                                    trusts.append(trust)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        elif directory_type == DirectoryType.FREEIPA:
            if scan_options.username and scan_options.password:
                try:
                    await run_exec(
                        ["kinit", scan_options.username],
                        stdin=f"{scan_options.password}\n",
                        timeout=10,
                    )
                    
                    rc, out, _ = await run_exec(["ipa", "trust-find", "--all"], timeout=30)
                    
                    if rc == 0:
                        trust_entries = (out or "").split('Trust name: ')
                        
                        for entry in trust_entries[1:]:
                            try:
                                lines = entry.splitlines()
                                if not lines:
                                    continue
                                
                                target_domain = lines[0].strip()
                                
                                trust_type = "Active Directory"
                                trust_direction = "Bidirectional"
                                trust_attributes = []
                                
                                for line in lines:
                                    if line.startswith('  Trust type: '):
                                        trust_type_str = line.replace('  Trust type: ', '').strip()
                                        trust_type = trust_type_str
                                    elif line.startswith('  Trust direction: '):
                                        direction_str = line.replace('  Trust direction: ', '').strip()
                                        trust_direction = direction_str
                                
                                trust = TrustRelationship(
                                    source_domain=scan_options.domain_name,
                                    target_domain=target_domain,
                                    trust_type=trust_type,
                                    trust_direction=trust_direction,
                                    trust_attributes=trust_attributes,
                                    is_transitive=True
                                )
                                
                                trusts.append(trust)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        return trusts

