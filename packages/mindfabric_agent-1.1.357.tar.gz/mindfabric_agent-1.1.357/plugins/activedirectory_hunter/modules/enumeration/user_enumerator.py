"""
User Enumerator Module

Enumerates users in Active Directory or FreeIPA domains
"""

import os
import re
import base64
from datetime import datetime
from typing import List
from ...proto import DirectoryType, ScanOptions, User
from utils.async_subprocess import run_exec


class UserEnumerator:
    """Enumerates users in domain"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions, directory_type: DirectoryType) -> List[User]:
        """
        Enumerates users in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            List[User]: User list
        """
        users = []
        
        # First, try to find users from local system files (even without LDAP)
        try:
            inferred_domain = (scan_options.domain_name or "local").strip()
            dc_parts = [p for p in inferred_domain.lower().split(".") if p] or ["local"]
            dn_dc = ",".join([f"DC={p}" for p in dc_parts])

            # Check /etc/passwd for potential AD users
            if os.path.exists('/etc/passwd'):
                with open('/etc/passwd', 'r') as f:
                    for line in f:
                        parts = line.strip().split(':')
                        if len(parts) >= 7:
                            username = parts[0]
                            # Look for AD-like usernames or users with specific patterns
                            username_lower = username.lower()
                            if (any(pattern in username_lower for pattern in ['ad', 'domain', 'admin', 'testuser', 'user', 'adadmin', 'domain_admin']) or
                                username_lower.startswith('ad') or 
                                username_lower.endswith('admin') or
                                'test' in username_lower):
                                
                                user_obj = User(
                                    username=username,
                                    display_name=parts[4] if parts[4] else username,
                                    distinguished_name=f"CN={username},CN=Users,{dn_dc}",
                                    email=None,
                                    groups=[],
                                    description=None,
                                    enabled=True,
                                    password_last_set=datetime.now(),
                                    password_never_expires=False,
                                    password_not_required=False,
                                    smart_card_required=False,
                                    delegation_permitted=False,
                                    delegation_services=[],
                                    service_principal_names=[],
                                    asreproast_candidate=False,
                                    kerberoast_candidate=False,
                                    acl_vulnerabilities=[],
                                    admin_count='admin' in username.lower() or username.lower() == 'root',
                                    sid=None,
                                    sam_account_name=username,
                                    object_class=["top", "person", "organizationalPerson", "user"],
                                    attributes={},
                                    domain=inferred_domain,
                                    creation_time=datetime.now()
                                )
                                users.append(user_obj)
        except Exception:
            pass
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            ldap_server = scan_options.ldap_server
            domain_name = scan_options.domain_name
            
            if ldap_server is None and scan_options.use_domain_discovery:
                # Trying to detect domain controller
                try:
                    rc, out, _ = await run_exec(["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"], timeout=5)
                    
                    if rc == 0 and (out or "").strip():
                        # Extracting host from first SRV entry
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]  # Removing trailing dot
                    else:
                        # If dig fails, check for local AD indicators
                        if os.path.exists('/etc/samba/smb.conf') or os.path.exists('/etc/krb5.conf'):
                            ldap_server = "127.0.0.1"
                            domain_name = domain_name or inferred_domain
                except Exception:
                    # If detection fails, try localhost if AD files exist
                    if os.path.exists('/etc/samba/smb.conf') or os.path.exists('/etc/krb5.conf'):
                        ldap_server = "127.0.0.1"
                        domain_name = domain_name or inferred_domain
            
            if ldap_server and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                # Forming base DN
                base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                
                try:
                    # Collecting users using ldapsearch
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', ldap_server,
                        '-b', base_dn, 
                        '(&(objectClass=user)(objectCategory=person))', 
                        'sAMAccountName', 'userPrincipalName', 'mail', 'displayName', 'distinguishedName',
                        'objectClass', 'memberOf', 'userAccountControl', 'pwdLastSet', 'adminCount',
                        'servicePrincipalName', 'objectSid'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        # Parsing users
                        user_entries = (out or "").split('\n\n')
                        
                        for entry in user_entries:
                            if not entry.strip():
                                continue
                            
                            try:
                                # Extracting user attributes
                                dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                                sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                                upn_match = re.search(r'userPrincipalName:\s*(.*?)$', entry, re.MULTILINE)
                                mail_match = re.search(r'mail:\s*(.*?)$', entry, re.MULTILINE)
                                display_match = re.search(r'displayName:\s*(.*?)$', entry, re.MULTILINE)
                                
                                if dn_match and sam_match:
                                    distinguished_name = dn_match.group(1).strip()
                                    sam_account_name = sam_match.group(1).strip()
                                    
                                    # Extracting other attributes
                                    user_principal_name = upn_match.group(1).strip() if upn_match else None
                                    email = mail_match.group(1).strip() if mail_match else None
                                    display_name = display_match.group(1).strip() if display_match else None
                                    
                                    # Extracting group list
                                    groups = []
                                    member_of_matches = re.findall(r'memberOf:\s*(.*?)$', entry, re.MULTILINE)
                                    groups.extend([m.strip() for m in member_of_matches])
                                    
                                    # Extracting SPN list
                                    spns = []
                                    spn_matches = re.findall(r'servicePrincipalName:\s*(.*?)$', entry, re.MULTILINE)
                                    spns.extend([s.strip() for s in spn_matches])
                                    
                                    # Extracting objectClass
                                    object_class = []
                                    object_class_matches = re.findall(r'objectClass:\s*(.*?)$', entry, re.MULTILINE)
                                    object_class.extend([o.strip() for o in object_class_matches])
                                    
                                    # Checking account entry status
                                    uac_match = re.search(r'userAccountControl:\s*(\d+)', entry)
                                    enabled = True
                                    if uac_match:
                                        uac = int(uac_match.group(1))
                                        enabled = (uac & 2) == 0  # Checking ACCOUNTDISABLE flag
                                    
                                    # Checking AdminCount
                                    admin_count = False
                                    admin_count_match = re.search(r'adminCount:\s*(\d+)', entry)
                                    if admin_count_match and admin_count_match.group(1) == '1':
                                        admin_count = True
                                    
                                    # Checking attributes for Kerberoast and ASREPRoast
                                    kerberoast_candidate = len(spns) > 0
                                    asreproast_candidate = False
                                    if uac_match:
                                        uac = int(uac_match.group(1))
                                        asreproast_candidate = (uac & 0x400000) != 0  # DONT_REQ_PREAUTH
                                    
                                    # Extracting SID
                                    sid = None
                                    sid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', entry)
                                    if sid_match:
                                        # Decoding SID from base64
                                        try:
                                            sid_base64 = sid_match.group(1)
                                            sid_binary = base64.b64decode(sid_base64)
                                            # Converting binary SID to string
                                            sid = f"S-1-5-21-{sid_binary[-12:-8].hex()}-{sid_binary[-8:-4].hex()}-{sid_binary[-4:].hex()}"
                                        except Exception:
                                            pass
                                    
                                    # Creating user object
                                    user = User(
                                        distinguished_name=distinguished_name,
                                        object_class=object_class,
                                        attributes={},
                                        domain=domain_name,
                                        username=sam_account_name,
                                        display_name=display_name,
                                        user_principal_name=user_principal_name,
                                        sam_account_name=sam_account_name,
                                        email=email,
                                        groups=groups,
                                        enabled=enabled,
                                        service_principal_names=spns,
                                        asreproast_candidate=asreproast_candidate,
                                        kerberoast_candidate=kerberoast_candidate,
                                        admin_count=admin_count,
                                        sid=sid
                                    )
                                    
                                    users.append(user)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        elif directory_type == DirectoryType.FREEIPA:
            if scan_options.username and scan_options.password:
                try:
                    # Getting Kerberos ticket
                    await run_exec(
                        ["kinit", scan_options.username],
                        stdin=f"{scan_options.password}\n",
                        timeout=10,
                    )
                    
                    # Getting list of users
                    rc, out, _ = await run_exec(["ipa", "user-find", "--all"], timeout=30)
                    
                    if rc == 0:
                        # Parsing users
                        user_entries = (out or "").split('User login: ')
                        
                        for entry in user_entries[1:]:  # Skipping first element (header)
                            try:
                                lines = entry.splitlines()
                                if not lines:
                                    continue
                                
                                username = lines[0].strip()
                                
                                # Extracting user attributes
                                dn = None
                                display_name = None
                                email = None
                                groups = []
                                
                                for line in lines:
                                    if line.startswith('  Display name: '):
                                        display_name = line.replace('  Display name: ', '').strip()
                                    elif line.startswith('  Email address: '):
                                        email = line.replace('  Email address: ', '').strip()
                                    elif line.startswith('  Member of groups: '):
                                        groups_str = line.replace('  Member of groups: ', '').strip()
                                        groups = [g.strip() for g in groups_str.split(',') if g.strip()]
                                    elif line.startswith('  LDAP DN: '):
                                        dn = line.replace('  LDAP DN: ', '').strip()
                                
                                # Creating user object
                                user = User(
                                    distinguished_name=dn or f"uid={username},cn=users,cn=accounts,dc={',dc='.join(scan_options.domain_name.split('.'))}",
                                    object_class=["posixAccount", "ipaObject"],
                                    attributes={},
                                    domain=scan_options.domain_name,
                                    username=username,
                                    display_name=display_name,
                                    sam_account_name=username,
                                    email=email,
                                    groups=groups,
                                    enabled=True,
                                    service_principal_names=[],
                                    asreproast_candidate=False,
                                    kerberoast_candidate=False,
                                    admin_count=False,
                                    sid=None
                                )
                                
                                users.append(user)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        return users

