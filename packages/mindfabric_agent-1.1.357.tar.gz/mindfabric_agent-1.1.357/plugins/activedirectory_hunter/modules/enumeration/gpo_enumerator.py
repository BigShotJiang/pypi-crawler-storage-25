"""
Group Policy Object Enumerator Module

Enumerates Group Policy Objects in Active Directory domains
"""

import re
from typing import List
from ...proto import DirectoryType, ScanOptions, GPO
from utils.async_subprocess import run_exec


class GPOEnumerator:
    """Enumerates Group Policy Objects in domain"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions, directory_type: DirectoryType) -> List[GPO]:
        """
        Enumerates group policy objects in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            List[GPO]: Group Policy Object list
        """
        gpos = []
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            ldap_server = scan_options.ldap_server
            domain_name = scan_options.domain_name
            
            if ldap_server is None and scan_options.use_domain_discovery:
                try:
                    rc, out, _ = await run_exec(["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"], timeout=5)
                    
                    if rc == 0 and (out or "").strip():
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]
                except Exception:
                    return gpos
            
            if ldap_server and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                
                try:
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', ldap_server,
                        '-b', f"CN=Policies,CN=System,{base_dn}", 
                        '(objectClass=groupPolicyContainer)', 
                        'cn', 'displayName', 'gPCFunctionalityVersion', 'whenCreated', 'whenChanged', 'gPCFileSysPath'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        gpo_entries = (out or "").split('\n\n')
                        
                        for entry in gpo_entries:
                            if not entry.strip():
                                continue
                            
                            try:
                                dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                                cn_match = re.search(r'cn:\s*(.*?)$', entry, re.MULTILINE)
                                
                                if dn_match and cn_match:
                                    distinguished_name = dn_match.group(1).strip()
                                    name = cn_match.group(1).strip()
                                    
                                    display_name = None
                                    display_match = re.search(r'displayName:\s*(.*?)$', entry, re.MULTILINE)
                                    if display_match:
                                        display_name = display_match.group(1).strip()
                                    
                                    version = None
                                    version_match = re.search(r'gPCFunctionalityVersion:\s*(\d+)', entry)
                                    if version_match:
                                        version = version_match.group(1)
                                    
                                    gpo_path = None
                                    path_match = re.search(r'gPCFileSysPath:\s*(.*?)$', entry, re.MULTILINE)
                                    if path_match:
                                        gpo_path = path_match.group(1).strip()
                                    
                                    gpo = GPO(
                                        distinguished_name=distinguished_name,
                                        object_class=["top", "groupPolicyContainer"],
                                        attributes={
                                            "gPCFileSysPath": gpo_path
                                        },
                                        domain=domain_name,
                                        name=name,
                                        display_name=display_name,
                                        version=version
                                    )
                                    
                                    try:
                                        guid_match = re.search(r'CN=\{([A-Fa-f0-9-]+)\}', distinguished_name)
                                        if guid_match:
                                            guid = guid_match.group(1)
                                            
                                            ldapsearch_cmd = [
                                                'ldapsearch', '-x', '-h', ldap_server,
                                                '-b', base_dn, 
                                                f'(gPLink=*{guid}*)', 
                                                'distinguishedName'
                                            ]
                                            
                                            if scan_options.username and scan_options.password:
                                                ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                                            
                                            rc2, out2, _ = await run_exec(ldapsearch_cmd, timeout=30)
                                            
                                            if rc2 == 0:
                                                linked_entries = (out2 or "").split('\n\n')
                                                
                                                for linked_entry in linked_entries:
                                                    if not linked_entry.strip():
                                                        continue
                                                    
                                                    dn_match = re.search(r'dn:\s*(.*?)$', linked_entry, re.MULTILINE)
                                                    if dn_match:
                                                        gpo.linked_objects.append(dn_match.group(1).strip())
                                    except Exception:
                                        pass
                                    
                                    gpos.append(gpo)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        return gpos

