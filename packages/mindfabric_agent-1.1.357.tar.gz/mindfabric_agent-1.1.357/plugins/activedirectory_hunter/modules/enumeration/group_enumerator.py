"""
Group Enumerator Module

Enumerates groups in Active Directory or FreeIPA domains
"""

import os
import re
import base64
from typing import List
from ...proto import DirectoryType, ScanOptions, Group
from utils.async_subprocess import run_exec


class GroupEnumerator:
    """Enumerates groups in domain"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions, directory_type: DirectoryType) -> List[Group]:
        """
        Enumerates groups in domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            List[Group]: Group list
        """
        groups = []
        
        if directory_type == DirectoryType.ACTIVE_DIRECTORY:
            ldap_server = scan_options.ldap_server
            domain_name = scan_options.domain_name
            
            if ldap_server is None and scan_options.use_domain_discovery:
                # Trying to detect domain controller
                try:
                    rc, out, _ = await run_exec(["dig", "+short", f"_ldap._tcp.{domain_name}", "SRV"], timeout=5)
                    
                    if rc == 0 and (out or "").strip():
                        # Extracting host from first SRV entry
                        line = (out or "").strip().splitlines()[0]
                        parts = line.strip().split()
                        ldap_server = parts[-1][:-1]  # Removing trailing dot
                except Exception:
                    return groups
            
            if ldap_server and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                # Forming base DN
                base_dn = f"dc={',dc='.join(domain_name.split('.'))}"
                
                try:
                    # Collecting groups using ldapsearch
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', ldap_server,
                        '-b', base_dn, 
                        '(objectClass=group)', 
                        'sAMAccountName', 'distinguishedName', 'description', 'member', 'memberOf',
                        'groupType', 'objectSid', 'adminCount'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        # Parsing groups
                        group_entries = (out or "").split('\n\n')
                        
                        for entry in group_entries:
                            if not entry.strip():
                                continue
                            
                            try:
                                # Extracting group attributes
                                dn_match = re.search(r'dn:\s*(.*?)$', entry, re.MULTILINE)
                                sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                                
                                if dn_match and sam_match:
                                    distinguished_name = dn_match.group(1).strip()
                                    sam_account_name = sam_match.group(1).strip()
                                    
                                    # Extracting description
                                    desc_match = re.search(r'description:\s*(.*?)$', entry, re.MULTILINE)
                                    description = desc_match.group(1).strip() if desc_match else None
                                    
                                    # Extracting member list
                                    members = []
                                    member_matches = re.findall(r'member:\s*(.*?)$', entry, re.MULTILINE)
                                    members.extend([m.strip() for m in member_matches])
                                    
                                    # Extracting group list that this group is member of
                                    member_of = []
                                    member_of_matches = re.findall(r'memberOf:\s*(.*?)$', entry, re.MULTILINE)
                                    member_of.extend([m.strip() for m in member_of_matches])
                                    
                                    # Extracting group type
                                    group_type = "Unknown"
                                    group_type_match = re.search(r'groupType:\s*(\d+)', entry)
                                    if group_type_match:
                                        group_type_value = int(group_type_match.group(1))
                                        # Determining group type based on value
                                        if group_type_value & 0x00000002:
                                            group_type = "Global"
                                        elif group_type_value & 0x00000004:
                                            group_type = "Domain Local"
                                        elif group_type_value & 0x00000008:
                                            group_type = "Universal"
                                    
                                    # Checking AdminCount
                                    is_privileged = False
                                    admin_count_match = re.search(r'adminCount:\s*(\d+)', entry)
                                    if admin_count_match and admin_count_match.group(1) == '1':
                                        is_privileged = True
                                    
                                    # Extracting SID
                                    sid = None
                                    sid_match = re.search(r'objectSid::\s*([A-Za-z0-9+/=]+)', entry)
                                    if sid_match:
                                        # Decoding SID from base64
                                        try:
                                            sid_base64 = sid_match.group(1)
                                            sid_binary = base64.b64decode(sid_base64)
                                            # Converting binary SID to string
                                            sid = f"S-1-5-21-{sid_binary[-12:-8].hex()}-{sid_binary[-8:-4].hex()}-{sid_binary[-4:].hex()}"
                                        except Exception:
                                            pass
                                    
                                    # Creating group object
                                    group = Group(
                                        distinguished_name=distinguished_name,
                                        object_class=["top", "group"],
                                        attributes={},
                                        domain=domain_name,
                                        name=sam_account_name,
                                        display_name=sam_account_name,
                                        group_type=group_type,
                                        sam_account_name=sam_account_name,
                                        members=members,
                                        member_of=member_of,
                                        description=description,
                                        is_privileged=is_privileged,
                                        sid=sid
                                    )
                                    
                                    groups.append(group)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        elif directory_type == DirectoryType.FREEIPA:
            if scan_options.username and scan_options.password:
                try:
                    # Getting Kerberos ticket
                    await run_exec(
                        ["kinit", scan_options.username],
                        stdin=f"{scan_options.password}\n",
                        timeout=10,
                    )
                    
                    # Getting group list
                    rc, out, _ = await run_exec(["ipa", "group-find", "--all"], timeout=30)
                    
                    if rc == 0:
                        # Parsing groups
                        group_entries = (out or "").split('Group name: ')
                        
                        for entry in group_entries[1:]:  # Skipping first element (header)
                            try:
                                lines = entry.splitlines()
                                if not lines:
                                    continue
                                
                                group_name = lines[0].strip()
                                
                                # Extracting group attributes
                                dn = None
                                description = None
                                members = []
                                
                                for line in lines:
                                    if line.startswith('  Description: '):
                                        description = line.replace('  Description: ', '').strip()
                                    elif line.startswith('  Member users: '):
                                        members_str = line.replace('  Member users: ', '').strip()
                                        members.extend([f"uid={m.strip()},cn=users,cn=accounts,dc={',dc='.join(scan_options.domain_name.split('.'))}" for m in members_str.split(',') if m.strip()])
                                    elif line.startswith('  LDAP DN: '):
                                        dn = line.replace('  LDAP DN: ', '').strip()
                                
                                # Creating group object
                                group = Group(
                                    distinguished_name=dn or f"cn={group_name},cn=groups,cn=accounts,dc={',dc='.join(scan_options.domain_name.split('.'))}",
                                    object_class=["posixGroup", "ipaObject"],
                                    attributes={},
                                    domain=scan_options.domain_name,
                                    name=group_name,
                                    display_name=group_name,
                                    members=members,
                                    description=description
                                )
                                
                                groups.append(group)
                            except Exception:
                                pass
                except Exception:
                    pass
        
        return groups

