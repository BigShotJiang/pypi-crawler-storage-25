"""All modules for Active Directory Hunter"""

# Core modules
from .core import DirectoryDetector, DomainCollector

# Enumeration modules
from .enumeration import UserEnumerator, GroupEnumerator, ComputerEnumerator, TrustEnumerator, GPOEnumerator

# Attack modules
from .attacks.credential_theft import KerberoastAttack, ASREPRoastAttack, DCSyncAttack, PasswordSprayAttack, LAPSPasswordDumper, CredentialExtractor, PasswordAuditor, ReplicationAttacks
from .attacks.lateral_movement import PassTheHashAttack, NTLMRelayAttack, SMBPermissionsChecker, TrustExploiter
from .attacks.persistence import GoldenTicketCreator, ShadowAdminCreator, SilverTicketCreator
from .attacks.reconnaissance import LDAPSweep
from .attacks.vulnerability_exploitation import ZeroLogonExploiter
from .attacks.federation import TokenReplayAttacks

# Analysis modules
from .analysis import (
    AttackVectorAnalyzer, PersistenceVectorAnalyzer,
    ACLAnalyzer, ShadowAdminFinder, CertificateAnalyzer,
    PasswordPolicyAnalyzer, ADCSAnalyzer, ADCSExtendedAnalyzer,
    RidgeElevatedTGTChecker, RBCDChecker, TrustAbuseChecker, SIDHistoryAbuseChecker
)

# Export modules
from .export import BloodHoundExporter

# Platform-specific modules
from .platforms import FreeIPAAnalyzer, AzureADAnalyzer, FreeIPAKeytabEnumerator

# Utility modules
from .utils import decode_sid

__all__ = [
    # Core
    'DirectoryDetector', 'DomainCollector',
    # Enumeration
    'UserEnumerator', 'GroupEnumerator', 'ComputerEnumerator', 'TrustEnumerator', 'GPOEnumerator',
    # Attacks - Credential Theft
    'KerberoastAttack', 'ASREPRoastAttack', 'DCSyncAttack', 'PasswordSprayAttack', 'LAPSPasswordDumper', 'CredentialExtractor', 'PasswordAuditor', 'ReplicationAttacks',
    # Attacks - Lateral Movement
    'PassTheHashAttack', 'NTLMRelayAttack', 'SMBPermissionsChecker', 'TrustExploiter',
    # Attacks - Persistence
    'GoldenTicketCreator', 'ShadowAdminCreator', 'SilverTicketCreator',
    # Attacks - Reconnaissance
    'LDAPSweep',
    # Attacks - Vulnerability Exploitation
    'ZeroLogonExploiter',
    # Attacks - Federation
    'TokenReplayAttacks',
    # Analysis
    'AttackVectorAnalyzer', 'PersistenceVectorAnalyzer',
    'ACLAnalyzer', 'ShadowAdminFinder', 'CertificateAnalyzer',
    'PasswordPolicyAnalyzer', 'ADCSAnalyzer', 'ADCSExtendedAnalyzer',
    'RidgeElevatedTGTChecker', 'RBCDChecker', 'TrustAbuseChecker', 'SIDHistoryAbuseChecker',
    # Export
    'BloodHoundExporter',
    # Platforms
    'FreeIPAAnalyzer', 'AzureADAnalyzer', 'FreeIPAKeytabEnumerator',
    # Utils
    'decode_sid'
]

