"""
Azure AD Hybrid Identity Attack Module

Attack techniques for hybrid environments:
- On-prem to cloud lateral movement
- Azure AD Connect abuse
- Password Hash Sync (PHS) abuse
- Pass-Through Authentication (PTA) abuse
- Seamless SSO abuse
- Directory synchronization abuse

MITRE ATT&CK: T1078.004 (Valid Accounts: Cloud Accounts)
"""

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from utils.async_subprocess import run_shell


class HybridAttackType(str, Enum):
    """Types of hybrid identity attacks."""
    AZURE_AD_CONNECT_ABUSE = "azure_ad_connect_abuse"
    PASSWORD_HASH_SYNC_ABUSE = "password_hash_sync_abuse"
    PASS_THROUGH_AUTH_ABUSE = "pass_through_auth_abuse"
    SEAMLESS_SSO_ABUSE = "seamless_sso_abuse"
    CLOUD_TO_ONPREM = "cloud_to_onprem"
    ONPREM_TO_CLOUD = "onprem_to_cloud"
    SYNC_SERVICE_ABUSE = "sync_service_abuse"
    HYBRID_ADMIN_ABUSE = "hybrid_admin_abuse"


class RiskLevel(str, Enum):
    """Risk levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class HybridAttackFinding:
    """A hybrid identity security finding."""
    attack_type: HybridAttackType
    title: str
    description: str
    risk: RiskLevel
    evidence: str = ""
    technique: str = ""
    remediation: str = ""
    mitre_technique: str = "T1078.004"


# Azure AD Hybrid Attack Techniques Database
HYBRID_ATTACK_TECHNIQUES = {
    "azure_ad_connect": {
        "description": "Azure AD Connect server compromise for hybrid identity abuse",
        "severity": "critical",
        "service_accounts": [
            {
                "name": "MSOL_ account",
                "description": "Azure AD Connect service account with DCSync rights",
                "permissions": ["Replicate Directory Changes", "Replicate Directory Changes All"],
                "abuse": "DCSync to extract all password hashes",
            },
            {
                "name": "ADSync account",
                "description": "Local service account for sync operations",
                "location": "LocalDB or remote SQL",
                "abuse": "Extract credentials from ADSync database",
            },
        ],
        "attack_paths": [
            {
                "name": "MSOL account password extraction",
                "description": "Extract MSOL_ account password from AADConnect",
                "tool": "AADInternals (Get-AADIntSyncCredentials)",
                "impact": "DCSync rights - extract all domain hashes",
            },
            {
                "name": "ADSync database extraction",
                "description": "Extract credentials from ADSync LocalDB/SQL",
                "tool": "AADInternals (Get-AADIntLocalConfigurationCredentials)",
                "impact": "Access to sync configuration and credentials",
            },
            {
                "name": "Azure AD Connect server compromise",
                "description": "Compromise server running Azure AD Connect",
                "impact": "Full control of hybrid identity",
            },
        ],
        "detection": [
            "Monitor access to ADSync database",
            "Alert on MSOL_ account usage",
            "Monitor DCSync events from AADConnect server",
        ],
    },
    "password_hash_sync": {
        "description": "Password Hash Synchronization abuse",
        "severity": "critical",
        "mechanism": "Syncs password hashes from on-prem AD to Azure AD",
        "attack_techniques": [
            {
                "name": "Cloud-only admin password spray",
                "description": "Spray passwords against cloud-synced accounts",
                "tool": "AADInternals, MSOLSpray",
            },
            {
                "name": "Hash extraction via AADConnect",
                "description": "Extract synced hashes from Azure AD Connect",
                "requirement": "AADConnect server access",
            },
            {
                "name": "Sync rule manipulation",
                "description": "Modify sync rules to elevate privileges",
            },
        ],
        "high_value_targets": [
            "Global Administrator accounts",
            "Privileged role members",
            "Service accounts with cloud access",
        ],
    },
    "pass_through_authentication": {
        "description": "Pass-Through Authentication agent abuse",
        "severity": "high",
        "mechanism": "PTA agents authenticate users against on-prem AD",
        "attack_techniques": [
            {
                "name": "PTA agent compromise",
                "description": "Compromise server running PTA agent",
                "impact": "Intercept/manipulate authentication",
            },
            {
                "name": "Authentication bypass",
                "description": "Abuse PTA to bypass MFA for on-prem accounts",
            },
            {
                "name": "Credential capture",
                "description": "Capture credentials passing through PTA agent",
            },
        ],
        "detection": [
            "Monitor PTA agent server security",
            "Alert on PTA agent installation",
        ],
    },
    "seamless_sso": {
        "description": "Seamless Single Sign-On abuse",
        "severity": "high",
        "mechanism": "Kerberos-based SSO using AZUREADSSOACC computer account",
        "attack_techniques": [
            {
                "name": "AZUREADSSOACC password extraction",
                "description": "Extract AZUREADSSOACC$ computer account password",
                "tool": "DCSync, mimikatz",
                "impact": "Forge Kerberos tickets for any Azure AD user",
            },
            {
                "name": "Silver ticket for Azure AD",
                "description": "Create silver ticket targeting Azure AD",
                "requirement": "AZUREADSSOACC$ hash",
            },
            {
                "name": "Kerberos ticket manipulation",
                "description": "Manipulate Kerberos tickets for cloud access",
            },
        ],
        "detection": [
            "Monitor AZUREADSSOACC$ account activity",
            "Alert on DCSync for computer accounts",
            "Monitor Kerberos TGS requests for AZUREADSSOACC",
        ],
    },
    "onprem_to_cloud": {
        "description": "Lateral movement from on-premises to Azure AD",
        "severity": "critical",
        "attack_paths": [
            {
                "name": "Via Global Admin sync",
                "description": "Compromise synced Global Admin account on-prem",
                "steps": [
                    "Identify synced privileged accounts",
                    "Compromise on-prem account",
                    "Access Azure AD with synced credentials",
                ],
            },
            {
                "name": "Via Azure AD Connect",
                "description": "Abuse AADConnect for cloud access",
                "steps": [
                    "Compromise AADConnect server",
                    "Extract MSOL credentials",
                    "Sync malicious changes to cloud",
                ],
            },
            {
                "name": "Via ADFS Golden SAML",
                "description": "Use ADFS to forge tokens for cloud access",
            },
            {
                "name": "Via Seamless SSO",
                "description": "Abuse Seamless SSO for cloud access",
            },
        ],
    },
    "cloud_to_onprem": {
        "description": "Lateral movement from Azure AD to on-premises",
        "severity": "high",
        "attack_paths": [
            {
                "name": "Via Intune MDM",
                "description": "Use Intune to deploy payloads to hybrid-joined devices",
            },
            {
                "name": "Via Azure AD joined devices",
                "description": "Abuse PRT on AAD-joined device for on-prem access",
            },
            {
                "name": "Via password sync",
                "description": "Reset password in cloud, sync to on-prem",
                "requirement": "Password writeback enabled",
            },
        ],
    },
    "sync_service_abuse": {
        "description": "Directory synchronization service abuse",
        "severity": "high",
        "techniques": [
            {
                "name": "Sync rule injection",
                "description": "Inject malicious sync rules",
                "impact": "Elevate on-prem user to cloud Global Admin",
            },
            {
                "name": "Attribute manipulation",
                "description": "Manipulate synced attributes",
                "impact": "Modify user properties, group memberships",
            },
            {
                "name": "Hard-match takeover",
                "description": "Take over cloud account by matching on-prem object",
            },
        ],
    },
}


class AzureADHybridAttacks:
    """Azure AD hybrid identity attack techniques."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[HybridAttackFinding] = []
    
    async def scan_hybrid_vulnerabilities(self) -> Dict[str, Any]:
        """
        Scan for hybrid identity vulnerabilities.
        
        Returns:
            Dict with findings and attack paths.
        """
        result = {
            "success": False,
            "hybrid_detected": False,
            "findings": [],
            "attack_paths": [],
            "recommendations": [],
        }
        
        try:
            # Detect hybrid identity configuration
            hybrid_info = await self._detect_hybrid_config()
            if hybrid_info:
                result["hybrid_detected"] = True
                result["hybrid_info"] = hybrid_info
                
                # Check for Azure AD Connect
                if hybrid_info.get("aadconnect_detected"):
                    aadconnect_findings = self._check_aadconnect_security()
                    self.findings.extend(aadconnect_findings)
                
                # Check for PHS
                if hybrid_info.get("phs_enabled"):
                    phs_findings = self._check_phs_security()
                    self.findings.extend(phs_findings)
                
                # Check for Seamless SSO
                if hybrid_info.get("seamless_sso_enabled"):
                    sso_findings = self._check_seamless_sso_security()
                    self.findings.extend(sso_findings)
                
                # Enumerate attack paths
                result["attack_paths"] = self._enumerate_attack_paths(hybrid_info)
            
            # Convert findings
            result["findings"] = [
                {
                    "attack_type": f.attack_type.value,
                    "title": f.title,
                    "description": f.description,
                    "risk": f.risk.value,
                    "evidence": f.evidence,
                    "technique": f.technique,
                    "remediation": f.remediation,
                    "mitre_technique": f.mitre_technique,
                }
                for f in self.findings
            ]
            
            result["recommendations"] = self._generate_recommendations()
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    async def _detect_hybrid_config(self) -> Optional[Dict[str, Any]]:
        """Detect hybrid identity configuration."""
        config = {}
        
        # Check for Azure AD Connect via LDAP
        try:
            # Look for MSOL_ accounts
            cmd = 'ldapsearch -x "(sAMAccountName=MSOL_*)" sAMAccountName 2>/dev/null | grep sAMAccountName'
            rc, out, _ = await run_shell(cmd, timeout=30, allow_unsafe_shell=True)
            if rc == 0 and "MSOL_" in (out or ""):
                config["aadconnect_detected"] = True
                config["msol_account"] = (out or "").strip()
        except Exception:
            pass
        
        # Check for AZUREADSSOACC (Seamless SSO)
        try:
            cmd = 'ldapsearch -x "(sAMAccountName=AZUREADSSOACC$)" sAMAccountName 2>/dev/null'
            rc, out, _ = await run_shell(cmd, timeout=30, allow_unsafe_shell=True)
            if rc == 0 and "AZUREADSSOACC" in (out or ""):
                config["seamless_sso_enabled"] = True
        except Exception:
            pass
        
        # Check DNS for Azure AD Connect
        try:
            domain = os.environ.get("USERDNSDOMAIN", "")
            if domain:
                cmd = f"dig +short _ldap._tcp.{domain} SRV 2>/dev/null"
                rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
                if rc == 0 and (out or "").strip():
                    config["domain"] = domain
        except Exception:
            pass
        
        return config if config else None
    
    def _check_aadconnect_security(self) -> List[HybridAttackFinding]:
        """Check Azure AD Connect security."""
        findings = []
        
        findings.append(HybridAttackFinding(
            attack_type=HybridAttackType.AZURE_AD_CONNECT_ABUSE,
            title="Azure AD Connect Server Detected",
            description="AADConnect server can be target for credential extraction",
            risk=RiskLevel.CRITICAL,
            technique="Extract MSOL_ account credentials via AADInternals",
            remediation="Tier 0 protection for AADConnect server; restrict admin access",
            mitre_technique="T1003",
        ))
        
        findings.append(HybridAttackFinding(
            attack_type=HybridAttackType.SYNC_SERVICE_ABUSE,
            title="MSOL Account Has DCSync Rights",
            description="MSOL_ service account has Replicate Directory Changes permissions",
            risk=RiskLevel.CRITICAL,
            technique="DCSync using MSOL_ credentials to extract all password hashes",
            remediation="Monitor MSOL_ account usage; implement DCSync detection",
            mitre_technique="T1003.006",
        ))
        
        return findings
    
    def _check_phs_security(self) -> List[HybridAttackFinding]:
        """Check Password Hash Sync security."""
        findings = []
        
        findings.append(HybridAttackFinding(
            attack_type=HybridAttackType.PASSWORD_HASH_SYNC_ABUSE,
            title="Password Hash Synchronization Enabled",
            description="Password hashes are synced to Azure AD",
            risk=RiskLevel.HIGH,
            technique="Cloud password spray or hash extraction via AADConnect",
            remediation="Enable Password Protection; implement smart lockout",
            mitre_technique="T1110.003",
        ))
        
        return findings
    
    def _check_seamless_sso_security(self) -> List[HybridAttackFinding]:
        """Check Seamless SSO security."""
        findings = []
        
        findings.append(HybridAttackFinding(
            attack_type=HybridAttackType.SEAMLESS_SSO_ABUSE,
            title="Seamless SSO Configured",
            description="AZUREADSSOACC$ account can be used for silver ticket attacks",
            risk=RiskLevel.HIGH,
            technique="Extract AZUREADSSOACC$ hash via DCSync for Azure AD access",
            remediation="Rotate AZUREADSSOACC$ password regularly; monitor DCSync for this account",
            mitre_technique="T1558.002",
        ))
        
        return findings
    
    def _enumerate_attack_paths(self, hybrid_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Enumerate hybrid identity attack paths."""
        paths = []
        
        if hybrid_info.get("aadconnect_detected"):
            paths.append({
                "name": "On-Prem to Cloud via AADConnect",
                "steps": [
                    "1. Compromise AADConnect server",
                    "2. Extract MSOL_ credentials (AADInternals)",
                    "3. DCSync to get all password hashes",
                    "4. Password spray against cloud accounts",
                    "5. Access Azure AD as Global Admin",
                ],
                "impact": "Full Azure AD compromise",
                "mitre": ["T1003", "T1078.004"],
            })
        
        if hybrid_info.get("seamless_sso_enabled"):
            paths.append({
                "name": "On-Prem to Cloud via Seamless SSO",
                "steps": [
                    "1. DCSync for AZUREADSSOACC$ hash",
                    "2. Create silver ticket for any user",
                    "3. Access Azure AD services as that user",
                ],
                "impact": "Impersonate any synced user in Azure AD",
                "mitre": ["T1558.002", "T1078.004"],
            })
        
        return paths
    
    def _generate_recommendations(self) -> List[str]:
        """Generate hybrid security recommendations."""
        return [
            "Treat AADConnect server as Tier 0 asset",
            "Use dedicated admin accounts for AADConnect",
            "Enable AADConnect Health for monitoring",
            "Implement conditional access for privileged users",
            "Rotate AZUREADSSOACC$ password every 30 days",
            "Monitor DCSync events for MSOL and AZUREADSSOACC accounts",
            "Enable Azure AD Identity Protection",
            "Consider disabling legacy authentication",
            "Implement PIM for privileged roles",
        ]
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get all hybrid attack techniques."""
        return HYBRID_ATTACK_TECHNIQUES


def get_hybrid_attack_database() -> Dict[str, Any]:
    """Get hybrid identity attack techniques database."""
    return HYBRID_ATTACK_TECHNIQUES

