"""
SMB Permissions Check Module

Checks accessible SMB permissions on specified server
"""

import time
from typing import Dict, Any, List
from ....proto import ScanOptions
import asyncio
from utils.async_subprocess import run_shell


class SMBPermissionsChecker:
    """Checks SMB permissions"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check(self, scan_options: ScanOptions, target_host: str) -> Dict[str, Any]:
        """
        Checks accessible SMB permissions on specified server
        
        Args:
            scan_options: Scan parameters
            target_host: Target SMB server
            
        Returns:
            Dict[str, Any]: Permissions check results
        """
        result = {
            "success": False,
            "shares": [],
            "accessible_shares": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not target_host:
            result["errors"].append("Target host not specified")
            return result
        
        try:
            # List SMB shares
            auth_params = ""
            if scan_options.username and scan_options.password:
                auth_params = f"-U {scan_options.username}%{scan_options.password}"
            elif scan_options.username and scan_options.ntlm_hash:
                auth_params = f"-U {scan_options.username} --pw-nt-hash {scan_options.ntlm_hash}"
            
            list_cmd = f"smbclient -L {target_host} {auth_params} -N"
            rc, out, err = await run_shell(list_cmd, timeout=30, allow_unsafe_shell=True)
            
            if rc == 0:
                shares = []
                for line in (out or "").split('\n'):
                    if 'Disk' in line or 'IPC' in line or 'Printer' in line:
                        share_name = line.split()[0].strip()
                        share_type = line.split()[1].strip() if len(line.split()) > 1 else "Unknown"
                        shares.append({
                            "name": share_name,
                            "type": share_type
                        })
                
                result["shares"] = shares
                
                # Try to access each share
                accessible = []
                sem = asyncio.Semaphore(6)
                
                async def _probe(share: Dict[str, Any]):
                    async with sem:
                        try:
                            access_cmd = f"smbclient //{target_host}/{share['name']} {auth_params} -N -c 'ls'"
                            rc, _, _ = await run_shell(access_cmd, timeout=10, allow_unsafe_shell=True)
                            return share if rc == 0 else None
                        except Exception:
                            return None
                
                probed = await asyncio.gather(*(_probe(s) for s in shares), return_exceptions=True)
                for item in probed:
                    if isinstance(item, Exception) or not item:
                        continue
                    accessible.append(item)
                
                result["accessible_shares"] = accessible
                result["success"] = True
            else:
                result["errors"].append(f"Failed to list shares: {err}")
        
        except Exception as e:
            result["errors"].append(f"Error during SMB permissions check: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

