"""
NTLM Coercion Attacks Module

Implements various NTLM authentication coercion techniques:
- PetitPotam (MS-EFSRPC)
- PrinterBug / SpoolSample (MS-RPRN)
- DFSCoerce (MS-DFSNM)
- ShadowCoerce (MS-FSRVP)

These attacks force a target to authenticate to an attacker-controlled server,
enabling NTLM relay attacks for privilege escalation.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent.parent))

from typing import Any, List, Dict, Optional
from dataclasses import dataclass, field
from enum import Enum
import re

from ....proto import AttackMethod


class CoercionMethod(str, Enum):
    """NTLM coercion methods."""
    PETITPOTAM = "petitpotam"
    PRINTERBUG = "printerbug"
    DFSPIPE = "dfspipe"
    SHADOWCOERCE = "shadowcoerce"


@dataclass
class CoercionTarget:
    """Target for coercion attack."""
    hostname: str
    ip_address: Optional[str] = None
    domain: Optional[str] = None
    is_dc: bool = False
    has_efs_service: bool = False
    has_spooler_service: bool = False
    has_dfs_service: bool = False
    has_vss_service: bool = False


@dataclass
class CoercionResult:
    """Result of coercion attack attempt."""
    method: CoercionMethod
    target: str
    listener: str
    success: bool
    auth_received: bool = False
    ntlm_hash: Optional[str] = None
    relay_target: Optional[str] = None
    error_message: Optional[str] = None
    raw_output: Optional[str] = None


# PetitPotam Named Pipes and RPC interfaces
PETITPOTAM_PIPES = [
    r"\pipe\efsrpc",
    r"\pipe\lsarpc",
    r"\pipe\samr",
    r"\pipe\lsass",
    r"\pipe\netlogon",
]

PETITPOTAM_FUNCTIONS = [
    "EfsRpcOpenFileRaw",
    "EfsRpcEncryptFileSrv",
    "EfsRpcDecryptFileSrv",
    "EfsRpcQueryUsersOnFile",
    "EfsRpcQueryRecoveryAgents",
    "EfsRpcRemoveUsersFromFile",
    "EfsRpcAddUsersToFile",
    "EfsRpcFileKeyInfo",
    "EfsRpcDuplicateEncryptionInfoFile",
    "EfsRpcAddUsersToFileEx",
    "EfsRpcFileKeyInfoEx",
    "EfsRpcGetEncryptedFileMetadata",
    "EfsRpcSetEncryptedFileMetadata",
    "EfsRpcEncryptFileExSrv",
]

# PrinterBug Named Pipes
PRINTERBUG_PIPES = [
    r"\pipe\spoolss",
]

PRINTERBUG_FUNCTIONS = [
    "RpcRemoteFindFirstPrinterChangeNotification",
    "RpcRemoteFindFirstPrinterChangeNotificationEx",
]

# DFSCoerce Named Pipes
DFSPIPE_PIPES = [
    r"\pipe\netdfs",
]

DFSPIPE_FUNCTIONS = [
    "NetrDfsAddStdRoot",
    "NetrDfsRemoveStdRoot",
]

# ShadowCoerce Named Pipes (VSS)
SHADOWCOERCE_PIPES = [
    r"\pipe\FssagentRpc",
]

SHADOWCOERCE_FUNCTIONS = [
    "IsPathShadowCopied",
    "IsPathSupported",
]


class CoercionAttacks:
    """NTLM coercion attack implementations."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
        self.results: List[CoercionResult] = []
    
    def check_efs_vulnerability(self, target: str) -> Dict[str, Any]:
        """
        Check if target is vulnerable to PetitPotam.
        
        PetitPotam exploits MS-EFSRPC (Encrypting File System Remote Protocol).
        CVE-2021-36942 - affects unpatched DCs.
        """
        result = {
            "target": target,
            "vulnerable": False,
            "pipes_accessible": [],
            "methods_available": [],
            "mitigations_detected": [],
        }
        
        # Check for EFS RPC pipe accessibility
        for pipe in PETITPOTAM_PIPES:
            # In real implementation, would test pipe connectivity
            # pipe_check = self._check_pipe_access(target, pipe)
            pass
        
        # Check for KB5005413 (August 2021 patch)
        # Check for "Require Encryption" EFS Group Policy
        # Check for Extended Protection for Authentication
        
        return result
    
    def check_spooler_vulnerability(self, target: str) -> Dict[str, Any]:
        """
        Check if target is vulnerable to PrinterBug (SpoolSample).
        
        Exploits MS-RPRN (Print System Remote Protocol).
        Requires Print Spooler service running on target.
        """
        result = {
            "target": target,
            "vulnerable": False,
            "spooler_running": False,
            "pipes_accessible": [],
            "mitigations_detected": [],
        }
        
        # Check for Print Spooler service
        # Check for pipe accessibility
        
        return result
    
    def check_dfs_vulnerability(self, target: str) -> Dict[str, Any]:
        """
        Check if target is vulnerable to DFSCoerce.
        
        Exploits MS-DFSNM (Distributed File System Namespace Management).
        """
        result = {
            "target": target,
            "vulnerable": False,
            "dfs_enabled": False,
            "pipes_accessible": [],
            "mitigations_detected": [],
        }
        
        return result
    
    def check_vss_vulnerability(self, target: str) -> Dict[str, Any]:
        """
        Check if target is vulnerable to ShadowCoerce.
        
        Exploits MS-FSRVP (File Server Remote VSS Protocol).
        """
        result = {
            "target": target,
            "vulnerable": False,
            "vss_enabled": False,
            "pipes_accessible": [],
            "mitigations_detected": [],
        }
        
        return result
    
    def execute_petitpotam(
        self,
        target: str,
        listener: str,
        method: str = "EfsRpcOpenFileRaw",
    ) -> CoercionResult:
        """
        Execute PetitPotam coercion attack.
        
        Args:
            target: Target DC/server to coerce
            listener: Attacker listener address (for NTLM relay)
            method: EFS RPC method to use
        
        Returns:
            CoercionResult with attack outcome
        """
        result = CoercionResult(
            method=CoercionMethod.PETITPOTAM,
            target=target,
            listener=listener,
            success=False,
        )
        
        # Implementation would:
        # 1. Connect to target via MS-EFSRPC
        # 2. Call EfsRpcOpenFileRaw with UNC path to listener
        # 3. Wait for authentication callback
        # 4. Relay authentication to target (e.g., LDAP, HTTP)
        
        return result
    
    def execute_printerbug(
        self,
        target: str,
        listener: str,
    ) -> CoercionResult:
        """
        Execute PrinterBug (SpoolSample) coercion attack.
        
        Args:
            target: Target server with Print Spooler
            listener: Attacker listener address
        
        Returns:
            CoercionResult with attack outcome
        """
        result = CoercionResult(
            method=CoercionMethod.PRINTERBUG,
            target=target,
            listener=listener,
            success=False,
        )
        
        # Implementation would:
        # 1. Connect to target's spoolss pipe
        # 2. Call RpcRemoteFindFirstPrinterChangeNotificationEx
        # 3. Specify attacker's UNC path for notification
        # 4. Wait for authentication callback
        
        return result
    
    def execute_dfscoerce(
        self,
        target: str,
        listener: str,
    ) -> CoercionResult:
        """
        Execute DFSCoerce attack.
        
        Args:
            target: Target server with DFS
            listener: Attacker listener address
        
        Returns:
            CoercionResult with attack outcome
        """
        result = CoercionResult(
            method=CoercionMethod.DFSPIPE,
            target=target,
            listener=listener,
            success=False,
        )
        
        return result
    
    def execute_shadowcoerce(
        self,
        target: str,
        listener: str,
    ) -> CoercionResult:
        """
        Execute ShadowCoerce attack.
        
        Args:
            target: Target server with File Server VSS
            listener: Attacker listener address
        
        Returns:
            CoercionResult with attack outcome
        """
        result = CoercionResult(
            method=CoercionMethod.SHADOWCOERCE,
            target=target,
            listener=listener,
            success=False,
        )
        
        return result
    
    def scan_coercion_vectors(
        self,
        targets: List[str],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Scan multiple targets for all coercion vulnerabilities.
        
        Args:
            targets: List of target hostnames/IPs
        
        Returns:
            Dictionary of target -> vulnerability info
        """
        results = {}
        
        for target in targets:
            results[target] = {
                "petitpotam": self.check_efs_vulnerability(target),
                "printerbug": self.check_spooler_vulnerability(target),
                "dfscoerce": self.check_dfs_vulnerability(target),
                "shadowcoerce": self.check_vss_vulnerability(target),
            }
        
        return results
    
    def get_relay_targets(
        self,
        domain_controllers: List[str],
        adcs_servers: List[str],
    ) -> List[Dict[str, Any]]:
        """
        Get potential relay targets for coerced authentication.
        
        Args:
            domain_controllers: List of DCs
            adcs_servers: List of AD CS servers
        
        Returns:
            List of relay target recommendations
        """
        relay_targets = []
        
        # LDAP/LDAPS to DCs (for RBCD, Shadow Credentials)
        for dc in domain_controllers:
            relay_targets.append({
                "target": dc,
                "protocol": "ldap",
                "port": 389,
                "attack": "Resource-Based Constrained Delegation (RBCD)",
                "requires": "Write access to msDS-AllowedToActOnBehalfOfOtherIdentity",
            })
            relay_targets.append({
                "target": dc,
                "protocol": "ldaps",
                "port": 636,
                "attack": "Shadow Credentials (msDS-KeyCredentialLink)",
                "requires": "Write access to msDS-KeyCredentialLink",
            })
        
        # HTTP to AD CS (ESC8)
        for adcs in adcs_servers:
            relay_targets.append({
                "target": adcs,
                "protocol": "http",
                "port": 80,
                "attack": "ESC8 - NTLM Relay to AD CS Web Enrollment",
                "requires": "AD CS Web Enrollment enabled, NTLM authentication allowed",
            })
            relay_targets.append({
                "target": adcs,
                "protocol": "https",
                "port": 443,
                "attack": "ESC8 - NTLM Relay to AD CS Web Enrollment (HTTPS)",
                "requires": "AD CS Web Enrollment enabled, NTLM authentication allowed",
            })
        
        return relay_targets
    
    def get_mitigations(self) -> List[Dict[str, str]]:
        """Get recommended mitigations for coercion attacks."""
        return [
            {
                "attack": "PetitPotam",
                "mitigation": "Install KB5005413 (August 2021 update)",
                "additional": "Enable EPA (Extended Protection for Authentication) on all services",
            },
            {
                "attack": "PetitPotam",
                "mitigation": "Block EFS RPC via GPO",
                "registry": r"HKLM\SYSTEM\CurrentControlSet\Services\EFS\Configuration\EfsDisabled=1",
            },
            {
                "attack": "PrinterBug",
                "mitigation": "Disable Print Spooler service on DCs and servers not requiring printing",
                "command": "Stop-Service Spooler; Set-Service Spooler -StartupType Disabled",
            },
            {
                "attack": "All Coercion",
                "mitigation": "Enable SMB Signing (required, not just enabled)",
                "gpo": "Computer Configuration > Policies > Windows Settings > Security Settings > Local Policies > Security Options",
            },
            {
                "attack": "All Coercion",
                "mitigation": "Enable LDAP Signing and Channel Binding",
                "details": "Domain controller: LDAP server signing requirements = Require signing",
            },
            {
                "attack": "ESC8 (Relay to ADCS)",
                "mitigation": "Enable EPA on AD CS web enrollment",
                "additional": "Disable NTLM authentication on AD CS if possible",
            },
            {
                "attack": "All Coercion",
                "mitigation": "Segment network and restrict inbound SMB/RPC connections",
                "firewall": "Block SMB (445) and RPC (135, 49152-65535) from workstations to DCs where not needed",
            },
        ]
    
    def get_attack_summary(self) -> Dict[str, Any]:
        """Get summary of coercion attack capabilities."""
        return {
            "petitpotam": {
                "protocol": "MS-EFSRPC",
                "cve": "CVE-2021-36942",
                "named_pipes": PETITPOTAM_PIPES,
                "functions": PETITPOTAM_FUNCTIONS[:5],  # Top 5
                "requirements": "Domain user account (or anonymous if misconfigured)",
                "impact": "Force DC to authenticate, relay to LDAP/ADCS for domain compromise",
            },
            "printerbug": {
                "protocol": "MS-RPRN",
                "cve": None,
                "named_pipes": PRINTERBUG_PIPES,
                "functions": PRINTERBUG_FUNCTIONS,
                "requirements": "Print Spooler service running, domain user account",
                "impact": "Force server to authenticate, relay for lateral movement",
            },
            "dfscoerce": {
                "protocol": "MS-DFSNM",
                "cve": None,
                "named_pipes": DFSPIPE_PIPES,
                "functions": DFSPIPE_FUNCTIONS,
                "requirements": "DFS enabled, domain user account",
                "impact": "Force server to authenticate, relay for lateral movement",
            },
            "shadowcoerce": {
                "protocol": "MS-FSRVP",
                "cve": None,
                "named_pipes": SHADOWCOERCE_PIPES,
                "functions": SHADOWCOERCE_FUNCTIONS,
                "requirements": "File Server VSS Agent service running",
                "impact": "Force server to authenticate, relay for lateral movement",
            },
        }

