"""Lateral Movement Attack Modules"""

from .pass_the_hash import PassTheHashAttack
from .ntlm_relay import NTLMRelayAttack
from .smb_permissions import SMBPermissionsChecker
from .trust_exploiter import TrustExploiter
from .coercion_attacks import CoercionAttacks, CoercionMethod, CoercionTarget, CoercionResult

__all__ = [
    'PassTheHashAttack',
    'NTLMRelayAttack',
    'SMBPermissionsChecker',
    'TrustExploiter',
    'CoercionAttacks',
    'CoercionMethod',
    'CoercionTarget',
    'CoercionResult',
]

