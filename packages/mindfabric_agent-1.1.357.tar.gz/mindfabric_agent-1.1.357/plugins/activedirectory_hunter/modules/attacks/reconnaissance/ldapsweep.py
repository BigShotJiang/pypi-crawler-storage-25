"""
LDAP Sweep Module

Performs LDAP sweep for information gathering
"""

import time
from typing import Dict, Any, List
from ....proto import ScanOptions
from utils.async_subprocess import run_exec


class LDAPSweep:
    """Performs LDAP sweep"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def sweep(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """
        Performs LDAP sweep for information gathering
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict[str, Any]: Sweep results
        """
        result = {
            "success": False,
            "findings": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not scan_options.ldap_server:
            result["errors"].append("LDAP server not specified")
            return result
        
        try:
            base_dn = f"dc={',dc='.join(scan_options.domain_name.split('.'))}"
            
            # Common LDAP queries for information gathering
            queries = [
                ("users", "(objectClass=user)"),
                ("groups", "(objectClass=group)"),
                ("computers", "(objectClass=computer)"),
                ("organizationalUnits", "(objectClass=organizationalUnit)"),
                ("domainControllers", "(objectClass=computer)(userAccountControl:1.2.840.113556.1.4.803:=8192)"),
            ]
            
            findings = []
            
            for query_name, query_filter in queries:
                try:
                    ldapsearch_cmd = [
                        'ldapsearch', '-x', '-h', scan_options.ldap_server,
                        '-b', base_dn,
                        query_filter,
                        'dn'
                    ]
                    
                    if scan_options.username and scan_options.password:
                        ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
                    
                    rc, out, _ = await run_exec(ldapsearch_cmd, timeout=30)
                    
                    if rc == 0:
                        count = (out or "").count('dn:')
                        findings.append({
                            "type": query_name,
                            "count": count,
                            "description": f"Found {count} {query_name}"
                        })
                
                except Exception as e:
                    result["errors"].append(f"Error during {query_name} query: {str(e)}")
            
            result["findings"] = findings
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"General error during LDAP sweep: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

