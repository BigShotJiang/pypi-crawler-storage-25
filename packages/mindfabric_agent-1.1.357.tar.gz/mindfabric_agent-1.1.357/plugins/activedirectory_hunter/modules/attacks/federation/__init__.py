"""Federation attack modules."""

from .adfs_attacks import ADFSAttacks, ADFSFinding, ADFSAttackType, ADFS_ATTACK_TECHNIQUES
from .token_replay_attacks import TokenReplayAttacks, TokenReplayFinding, TokenType, TOKEN_REPLAY_TECHNIQUES

__all__ = [
    "ADFSAttacks",
    "ADFSFinding",
    "ADFSAttackType",
    "ADFS_ATTACK_TECHNIQUES",
    "TokenReplayAttacks",
    "TokenReplayFinding",
    "TokenType",
    "TOKEN_REPLAY_TECHNIQUES",
]

