"""
ADFS Attack Module

Active Directory Federation Services attack techniques:
- Token signing key theft
- SAML token manipulation
- ADFS proxy abuse
- Federation trust abuse
- Golden SAML attack

MITRE ATT&CK: T1606.002 (Forge Web Credentials: SAML Tokens)
"""

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from utils.async_subprocess import run_shell


class ADFSAttackType(str, Enum):
    """Types of ADFS attacks."""
    TOKEN_SIGNING_KEY_THEFT = "token_signing_key_theft"
    GOLDEN_SAML = "golden_saml"
    SAML_TOKEN_MANIPULATION = "saml_token_manipulation"
    FEDERATION_TRUST_ABUSE = "federation_trust_abuse"
    ADFS_PROXY_ABUSE = "adfs_proxy_abuse"
    TOKEN_REPLAY = "token_replay"
    RELYING_PARTY_TRUST = "relying_party_trust"


class RiskLevel(str, Enum):
    """Risk levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ADFSFinding:
    """An ADFS security finding."""
    attack_type: ADFSAttackType
    title: str
    description: str
    risk: RiskLevel
    evidence: str = ""
    technique: str = ""
    remediation: str = ""
    mitre_technique: str = "T1606.002"


# ADFS Attack Techniques Database
ADFS_ATTACK_TECHNIQUES = {
    "token_signing_key_theft": {
        "description": "Steal ADFS token signing certificate for Golden SAML",
        "severity": "critical",
        "requirements": [
            "Domain Admin or ADFS server access",
            "ADFS service account compromise",
        ],
        "techniques": [
            {
                "name": "Export from ADFS database",
                "command": "Get-AdfsProperties | Select-Object -ExpandProperty SigningCertificate",
                "description": "Export signing certificate from ADFS configuration",
            },
            {
                "name": "DKM key extraction",
                "description": "Extract Distributed Key Manager (DKM) master key from AD",
                "ldap_path": "CN=ADFS,CN=Microsoft,CN=Program Data,DC=domain,DC=com",
            },
            {
                "name": "Certificate store extraction",
                "command": "mimikatz crypto::certificates /export",
                "description": "Export certificates from ADFS server certificate store",
            },
            {
                "name": "AD replication (DCSync)",
                "description": "Replicate ADFS DKM key container from AD",
                "tool": "secretsdump.py or mimikatz",
            },
        ],
        "impact": "Full access to all federated applications",
        "persistence": "Create unlimited SAML tokens for any user",
    },
    "golden_saml": {
        "description": "Forge SAML tokens using stolen signing certificate",
        "severity": "critical",
        "requirements": [
            "Token signing certificate",
            "Target user information",
            "Relying party trust details",
        ],
        "techniques": [
            {
                "name": "ADFSDump extraction",
                "tool": "ADFSDump",
                "description": "Extract ADFS configuration and certificates",
            },
            {
                "name": "AADInternals token forgery",
                "tool": "AADInternals (PowerShell)",
                "command": "New-AADIntSAMLToken -SigningCertificate $cert -Issuer $issuer",
            },
            {
                "name": "Manual SAML token crafting",
                "description": "Craft SAML assertion with valid signature",
            },
        ],
        "target_applications": [
            "Microsoft 365 / Azure AD",
            "AWS Console (SAML SSO)",
            "GCP (SAML SSO)",
            "Salesforce",
            "ServiceNow",
            "Custom SAML applications",
        ],
        "impact": "Impersonate any user to any federated application",
    },
    "saml_token_manipulation": {
        "description": "Manipulate SAML tokens for privilege escalation",
        "severity": "high",
        "techniques": [
            {
                "name": "Claim manipulation",
                "description": "Modify claims in SAML assertion (roles, groups)",
            },
            {
                "name": "Assertion replay",
                "description": "Replay valid SAML assertion before expiration",
            },
            {
                "name": "Signature stripping",
                "description": "Remove or modify signature for unsigned assertion",
            },
            {
                "name": "Comment injection",
                "description": "Use XML comments to bypass claim validation",
            },
        ],
    },
    "federation_trust_abuse": {
        "description": "Abuse federation trusts for cross-domain access",
        "severity": "high",
        "techniques": [
            {
                "name": "Trust chain exploitation",
                "description": "Traverse federation trust chain to access other domains",
            },
            {
                "name": "Claim transformation bypass",
                "description": "Bypass claim transformation rules",
            },
            {
                "name": "Trust modification",
                "description": "Modify federation trust to add malicious claims",
            },
        ],
    },
    "adfs_proxy_abuse": {
        "description": "Abuse ADFS proxy for credential theft or bypass",
        "severity": "medium",
        "techniques": [
            {
                "name": "Web Application Proxy compromise",
                "description": "Compromise WAP server for credential interception",
            },
            {
                "name": "Proxy authentication bypass",
                "description": "Bypass pre-authentication at proxy level",
            },
            {
                "name": "Certificate impersonation",
                "description": "Use compromised proxy certificate for MITM",
            },
        ],
    },
    "relying_party_trust": {
        "description": "Exploit relying party trust configurations",
        "severity": "medium",
        "techniques": [
            {
                "name": "Weak RP configuration",
                "description": "Exploit weak relying party configurations",
            },
            {
                "name": "RP endpoint enumeration",
                "description": "Enumerate relying party endpoints and configurations",
            },
            {
                "name": "RP trust injection",
                "description": "Add malicious relying party trust",
            },
        ],
    },
}


class ADFSAttacks:
    """ADFS attack techniques and detection."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[ADFSFinding] = []
    
    async def scan_adfs_vulnerabilities(self) -> Dict[str, Any]:
        """
        Scan for ADFS vulnerabilities and misconfigurations.
        
        Returns:
            Dict with findings and recommendations.
        """
        result = {
            "success": False,
            "adfs_detected": False,
            "findings": [],
            "attack_paths": [],
            "recommendations": [],
        }
        
        try:
            # Detect ADFS infrastructure
            adfs_info = await self._detect_adfs()
            if adfs_info:
                result["adfs_detected"] = True
                result["adfs_info"] = adfs_info
                
                # Check for vulnerabilities
                vuln_findings = self._check_vulnerabilities(adfs_info)
                self.findings.extend(vuln_findings)
                
                # Check for misconfigurations
                misconfig_findings = self._check_misconfigurations(adfs_info)
                self.findings.extend(misconfig_findings)
                
                # Enumerate attack paths
                attack_paths = self._enumerate_attack_paths(adfs_info)
                result["attack_paths"] = attack_paths
            
            # Convert findings to dict
            result["findings"] = [
                {
                    "attack_type": f.attack_type.value,
                    "title": f.title,
                    "description": f.description,
                    "risk": f.risk.value,
                    "evidence": f.evidence,
                    "technique": f.technique,
                    "remediation": f.remediation,
                    "mitre_technique": f.mitre_technique,
                }
                for f in self.findings
            ]
            
            # Generate recommendations
            result["recommendations"] = self._generate_recommendations()
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    async def _detect_adfs(self) -> Optional[Dict[str, Any]]:
        """Detect ADFS infrastructure."""
        adfs_info = {}
        
        # Check for ADFS service via DNS
        try:
            domain = os.environ.get("USERDNSDOMAIN", "")
            if domain:
                cmd = f"dig +short fs.{domain} A 2>/dev/null || nslookup fs.{domain} 2>/dev/null | grep Address"
                rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
                if rc == 0 and (out or "").strip():
                    adfs_info["federation_service"] = f"fs.{domain}"
        except Exception:
            pass
        
        # Check for ADFS via common endpoints
        adfs_endpoints = [
            "/adfs/ls",
            "/adfs/services/trust/mex",
            "/adfs/oauth2/token",
            "/federationmetadata/2007-06/federationmetadata.xml",
        ]
        adfs_info["endpoints_detected"] = adfs_endpoints
        
        # Check for WAP (Web Application Proxy)
        try:
            cmd = "netstat -an 2>/dev/null | grep ':443\\|:80' | head -5"
            rc, out, _ = await run_shell(cmd, timeout=10, allow_unsafe_shell=True)
            if rc == 0 and "443" in (out or ""):
                adfs_info["wap_possible"] = True
        except Exception:
            pass
        
        return adfs_info if adfs_info else None
    
    def _check_vulnerabilities(self, adfs_info: Dict[str, Any]) -> List[ADFSFinding]:
        """Check for ADFS vulnerabilities."""
        findings = []
        
        # Check for token signing key exposure
        findings.append(ADFSFinding(
            attack_type=ADFSAttackType.TOKEN_SIGNING_KEY_THEFT,
            title="ADFS Token Signing Key Theft Risk",
            description="ADFS token signing certificates can be extracted if domain admin access is achieved",
            risk=RiskLevel.CRITICAL,
            technique="DCSync or ADFS server access can extract DKM master key",
            remediation="Implement tiered admin model; monitor ADFS certificate access; use HSM for key storage",
            mitre_technique="T1606.002",
        ))
        
        # Golden SAML attack potential
        findings.append(ADFSFinding(
            attack_type=ADFSAttackType.GOLDEN_SAML,
            title="Golden SAML Attack Potential",
            description="Stolen signing certificates enable forging SAML tokens for any user",
            risk=RiskLevel.CRITICAL,
            technique="With signing certificate, attacker can create valid tokens for any federated app",
            remediation="Implement certificate monitoring; use HSM; regular certificate rotation",
            mitre_technique="T1606.002",
        ))
        
        return findings
    
    def _check_misconfigurations(self, adfs_info: Dict[str, Any]) -> List[ADFSFinding]:
        """Check for ADFS misconfigurations."""
        findings = []
        
        # Check for weak federation metadata exposure
        findings.append(ADFSFinding(
            attack_type=ADFSAttackType.RELYING_PARTY_TRUST,
            title="Federation Metadata Exposure",
            description="Federation metadata XML is publicly accessible",
            risk=RiskLevel.MEDIUM,
            evidence="Endpoint: /federationmetadata/2007-06/federationmetadata.xml",
            technique="Enumerate ADFS configuration via metadata",
            remediation="Restrict metadata access if not required; monitor access",
        ))
        
        return findings
    
    def _enumerate_attack_paths(self, adfs_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Enumerate potential attack paths."""
        attack_paths = [
            {
                "name": "Golden SAML via Domain Admin",
                "steps": [
                    "1. Achieve Domain Admin access",
                    "2. DCSync to obtain ADFS DKM key",
                    "3. Extract token signing certificate",
                    "4. Forge SAML tokens for any user",
                    "5. Access federated applications (M365, AWS, etc.)",
                ],
                "requirements": ["Domain Admin", "Network access to ADFS"],
                "impact": "Full access to all federated applications",
            },
            {
                "name": "ADFS Server Compromise",
                "steps": [
                    "1. Compromise ADFS server",
                    "2. Export certificates from certificate store",
                    "3. Export ADFS configuration database",
                    "4. Forge SAML tokens",
                ],
                "requirements": ["ADFS server admin access"],
                "impact": "Full access to all federated applications",
            },
        ]
        
        return attack_paths
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations."""
        return [
            "Store ADFS token signing certificates in HSM",
            "Implement certificate access monitoring and alerting",
            "Use Credential Guard on ADFS servers",
            "Implement tiered admin model for ADFS",
            "Regular rotation of token signing certificates",
            "Monitor for DCSync attempts targeting ADFS DKM container",
            "Enable ADFS auditing and log to SIEM",
            "Implement Conditional Access policies",
            "Use certificate-based authentication where possible",
        ]
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get all ADFS attack techniques."""
        return ADFS_ATTACK_TECHNIQUES


def get_adfs_attack_database() -> Dict[str, Any]:
    """Get ADFS attack techniques database."""
    return ADFS_ATTACK_TECHNIQUES

