"""
Group Policy Object Abuse Module

Advanced GPO attack techniques:
- GPO hijacking and modification
- Startup/logon scripts abuse
- Scheduled tasks via GPO
- Software installation abuse
- Restricted groups abuse
- Registry settings abuse
- File and printer sharing abuse

MITRE ATT&CK: T1484.001 (Domain Policy Modification: Group Policy Modification)
"""

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from utils.async_subprocess import run_shell


class GPOAttackType(str, Enum):
    """Types of GPO attacks."""
    GPO_HIJACKING = "gpo_hijacking"
    STARTUP_SCRIPTS = "startup_scripts"
    LOGON_SCRIPTS = "logon_scripts"
    SCHEDULED_TASKS = "scheduled_tasks"
    SOFTWARE_INSTALLATION = "software_installation"
    RESTRICTED_GROUPS = "restricted_groups"
    REGISTRY_SETTINGS = "registry_settings"
    FILE_SHARES = "file_shares"
    IMMEDIATE_TASKS = "immediate_tasks"


class RiskLevel(str, Enum):
    """Risk levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class GPOAbuseFinding:
    """A GPO abuse security finding."""
    attack_type: GPOAttackType
    title: str
    description: str
    risk: RiskLevel
    gpo_name: str = ""
    gpo_guid: str = ""
    evidence: str = ""
    technique: str = ""
    remediation: str = ""
    mitre_technique: str = "T1484.001"


# GPO Attack Techniques Database
GPO_ATTACK_TECHNIQUES = {
    "gpo_hijacking": {
        "description": "Hijack existing GPOs to gain unauthorized access",
        "severity": "critical",
        "requirements": [
            "GPO modification permissions",
            "Typically requires Domain Admin or GPO delegation",
        ],
        "techniques": [
            {
                "name": "GPO link manipulation",
                "description": "Link attacker-controlled GPO to target OU",
                "impact": "Execute code on all computers/users in OU",
            },
            {
                "name": "GPO permission modification",
                "description": "Modify GPO permissions to allow editing",
                "tool": "SharpGPOAbuse, PowerView",
            },
            {
                "name": "GPO inheritance manipulation",
                "description": "Modify GPO inheritance to bypass restrictions",
            },
        ],
        "detection": [
            "Monitor GPO modifications (Event ID 5136)",
            "Alert on new GPO links",
            "Monitor SYSVOL changes",
        ],
    },
    "startup_scripts": {
        "description": "Abuse GPO startup scripts for code execution",
        "severity": "critical",
        "mechanism": "Scripts run as SYSTEM at computer startup",
        "attack_techniques": [
            {
                "name": "Add malicious startup script",
                "path": "Computer Configuration > Policies > Windows Settings > Scripts > Startup",
                "impact": "Code execution as SYSTEM on all affected computers",
                "tool": "SharpGPOAbuse --AddComputerScript",
            },
            {
                "name": "Modify existing startup script",
                "description": "Backdoor existing startup scripts in SYSVOL",
                "sysvol_path": "\\\\domain\\SYSVOL\\domain\\Policies\\{GPO-GUID}\\Machine\\Scripts\\Startup",
            },
        ],
        "evasion": [
            "Use PowerShell one-liner",
            "Download and execute from remote server",
            "Use living-off-the-land binaries",
        ],
    },
    "logon_scripts": {
        "description": "Abuse GPO logon scripts for user context execution",
        "severity": "high",
        "mechanism": "Scripts run in user context at logon",
        "attack_techniques": [
            {
                "name": "Add malicious logon script",
                "path": "User Configuration > Policies > Windows Settings > Scripts > Logon",
                "impact": "Code execution as user on all affected users",
                "tool": "SharpGPOAbuse --AddUserScript",
            },
            {
                "name": "Modify existing logon script",
                "description": "Backdoor existing logon scripts in SYSVOL",
                "sysvol_path": "\\\\domain\\SYSVOL\\domain\\Policies\\{GPO-GUID}\\User\\Scripts\\Logon",
            },
        ],
        "use_cases": [
            "Credential harvesting",
            "User enumeration",
            "Persistence establishment",
        ],
    },
    "scheduled_tasks": {
        "description": "Create scheduled tasks via GPO for persistence",
        "severity": "critical",
        "mechanism": "Scheduled tasks pushed via Group Policy Preferences",
        "attack_techniques": [
            {
                "name": "Immediate scheduled task",
                "path": "Computer Configuration > Preferences > Control Panel Settings > Scheduled Tasks",
                "impact": "Execute code immediately on all affected computers",
                "tool": "SharpGPOAbuse --AddScheduledTask",
            },
            {
                "name": "Persistent scheduled task",
                "description": "Create recurring scheduled task for persistence",
            },
        ],
        "detection": [
            "Monitor for new scheduled tasks (Event ID 4698)",
            "Monitor GPP changes in SYSVOL",
        ],
    },
    "software_installation": {
        "description": "Deploy malicious software via GPO",
        "severity": "high",
        "mechanism": "Software installation via Group Policy",
        "attack_techniques": [
            {
                "name": "MSI deployment",
                "path": "Computer Configuration > Policies > Software Settings > Software Installation",
                "description": "Deploy malicious MSI package",
            },
            {
                "name": "Script-based installation",
                "description": "Use startup scripts to install software",
            },
        ],
    },
    "restricted_groups": {
        "description": "Abuse restricted groups for privilege escalation",
        "severity": "critical",
        "mechanism": "Force group membership via GPO",
        "attack_techniques": [
            {
                "name": "Add to local admins",
                "path": "Computer Configuration > Policies > Windows Settings > Security Settings > Restricted Groups",
                "impact": "Make domain user local admin on all affected computers",
                "tool": "SharpGPOAbuse --AddLocalAdmin",
            },
            {
                "name": "Modify privileged groups",
                "description": "Add users to domain privileged groups",
            },
        ],
    },
    "registry_settings": {
        "description": "Abuse GPO registry settings for various attacks",
        "severity": "high",
        "mechanism": "Push registry modifications via GPO",
        "attack_techniques": [
            {
                "name": "AutoRun persistence",
                "description": "Add AutoRun registry keys via GPO",
                "registry_path": "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            },
            {
                "name": "Disable security features",
                "description": "Disable Windows Defender, UAC, etc.",
            },
            {
                "name": "Enable WDigest",
                "description": "Enable cleartext password storage in memory",
                "registry_path": "HKLM\\System\\CurrentControlSet\\Control\\SecurityProviders\\WDigest\\UseLogonCredential",
            },
        ],
    },
    "immediate_tasks": {
        "description": "GPO Immediate Scheduled Tasks for rapid deployment",
        "severity": "critical",
        "mechanism": "Scheduled tasks that run immediately on GPO processing",
        "attack_techniques": [
            {
                "name": "Immediate task creation",
                "description": "Create task that runs immediately",
                "xml_template": "ImmediateTask XML in ScheduledTasks.xml",
            },
        ],
    },
}

# High-value GPO targets
HIGH_VALUE_GPO_TARGETS = [
    {
        "name": "Default Domain Policy",
        "guid": "{31B2F340-016D-11D2-945F-00C04FB984F9}",
        "scope": "All domain objects",
        "impact": "Domain-wide code execution",
    },
    {
        "name": "Default Domain Controllers Policy",
        "guid": "{6AC1786C-016F-11D2-945F-00C04fB984F9}",
        "scope": "Domain controllers",
        "impact": "Code execution on DCs",
    },
    {
        "name": "Custom GPOs linked to privileged OUs",
        "scope": "Administrators, IT staff",
        "impact": "Compromise privileged users",
    },
]

# GPO abuse tools
GPO_ABUSE_TOOLS = [
    {
        "name": "SharpGPOAbuse",
        "url": "https://github.com/FSecureLABS/SharpGPOAbuse",
        "capabilities": [
            "AddComputerScript",
            "AddUserScript",
            "AddComputerTask",
            "AddLocalAdmin",
            "AddComputerRights",
            "AddUserRights",
        ],
    },
    {
        "name": "PowerView",
        "url": "https://github.com/PowerShellMafia/PowerSploit",
        "capabilities": [
            "Get-DomainGPO",
            "Get-GPOComputer",
            "Get-GPOLocalGroup",
            "Find-GPOLocation",
        ],
    },
    {
        "name": "PyGPOAbuse",
        "url": "https://github.com/Hackndo/pygpoabuse",
        "capabilities": ["Python-based GPO abuse from Linux"],
    },
]


class GPOAbuseAttacks:
    """GPO abuse attack techniques."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[GPOAbuseFinding] = []
    
    async def scan_gpo_vulnerabilities(self) -> Dict[str, Any]:
        """
        Scan for GPO abuse vulnerabilities.
        
        Returns:
            Dict with findings and attack paths.
        """
        result = {
            "success": False,
            "gpos_found": [],
            "vulnerable_gpos": [],
            "findings": [],
            "attack_paths": [],
            "recommendations": [],
        }
        
        try:
            # Enumerate GPOs
            gpos = await self._enumerate_gpos()
            result["gpos_found"] = gpos
            
            # Check for vulnerable GPO permissions
            for gpo in gpos:
                vuln_findings = self._check_gpo_permissions(gpo)
                self.findings.extend(vuln_findings)
                if vuln_findings:
                    result["vulnerable_gpos"].append(gpo)
            
            # Check SYSVOL permissions
            sysvol_findings = self._check_sysvol_permissions()
            self.findings.extend(sysvol_findings)
            
            # Check for dangerous GPO settings
            settings_findings = self._check_dangerous_settings(gpos)
            self.findings.extend(settings_findings)
            
            # Enumerate attack paths
            result["attack_paths"] = self._enumerate_attack_paths(gpos)
            
            # Convert findings
            result["findings"] = [
                {
                    "attack_type": f.attack_type.value,
                    "title": f.title,
                    "description": f.description,
                    "risk": f.risk.value,
                    "gpo_name": f.gpo_name,
                    "gpo_guid": f.gpo_guid,
                    "evidence": f.evidence,
                    "technique": f.technique,
                    "remediation": f.remediation,
                    "mitre_technique": f.mitre_technique,
                }
                for f in self.findings
            ]
            
            result["recommendations"] = self._generate_recommendations()
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    async def _enumerate_gpos(self) -> List[Dict[str, Any]]:
        """Enumerate all GPOs in domain."""
        gpos = []
        
        try:
            # Use ldapsearch to enumerate GPOs
            cmd = 'ldapsearch -x "(objectClass=groupPolicyContainer)" displayName gPCFileSysPath 2>/dev/null'
            rc, out, _ = await run_shell(cmd, timeout=60, allow_unsafe_shell=True)
            if rc != 0:
                out = ""
            
            # Parse output
            current_gpo = {}
            for line in (out or "").split("\n"):
                if line.startswith("displayName:"):
                    current_gpo["name"] = line.split(":", 1)[1].strip()
                elif line.startswith("gPCFileSysPath:"):
                    current_gpo["path"] = line.split(":", 1)[1].strip()
                    # Extract GUID from path
                    guid_match = re.search(r'\{([A-F0-9-]+)\}', current_gpo.get("path", ""), re.I)
                    if guid_match:
                        current_gpo["guid"] = guid_match.group(0)
                    if current_gpo.get("name"):
                        gpos.append(current_gpo)
                    current_gpo = {}
        except Exception:
            pass
        
        # Add default GPOs if none found
        if not gpos:
            gpos = [
                {"name": "Default Domain Policy", "guid": "{31B2F340-016D-11D2-945F-00C04FB984F9}"},
                {"name": "Default Domain Controllers Policy", "guid": "{6AC1786C-016F-11D2-945F-00C04fB984F9}"},
            ]
        
        return gpos
    
    def _check_gpo_permissions(self, gpo: Dict[str, Any]) -> List[GPOAbuseFinding]:
        """Check for vulnerable GPO permissions."""
        findings = []
        
        # Check if non-admin can modify GPO
        findings.append(GPOAbuseFinding(
            attack_type=GPOAttackType.GPO_HIJACKING,
            title=f"GPO Permission Check: {gpo.get('name', 'Unknown')}",
            description="Check for overly permissive GPO edit rights",
            risk=RiskLevel.HIGH,
            gpo_name=gpo.get("name", ""),
            gpo_guid=gpo.get("guid", ""),
            technique="Use PowerView Get-DomainGPO -Identity <GPO> | Get-DomainObjectAcl",
            remediation="Review and restrict GPO modification permissions",
        ))
        
        return findings
    
    def _check_sysvol_permissions(self) -> List[GPOAbuseFinding]:
        """Check SYSVOL share permissions."""
        findings = []
        
        try:
            domain = os.environ.get("USERDNSDOMAIN", "domain.local")
            sysvol_path = f"\\\\{domain}\\SYSVOL"
            
            findings.append(GPOAbuseFinding(
                attack_type=GPOAttackType.GPO_HIJACKING,
                title="SYSVOL Share Permission Check",
                description="Check if SYSVOL allows unauthorized write access",
                risk=RiskLevel.HIGH,
                evidence=f"SYSVOL path: {sysvol_path}",
                technique="Check for WriteDACL, WriteProperty, or GenericWrite on SYSVOL",
                remediation="Restrict SYSVOL write access to Domain Admins only",
            ))
        except Exception:
            pass
        
        return findings
    
    def _check_dangerous_settings(self, gpos: List[Dict[str, Any]]) -> List[GPOAbuseFinding]:
        """Check for dangerous GPO settings."""
        findings = []
        
        # Check for GPP passwords (MS14-025)
        findings.append(GPOAbuseFinding(
            attack_type=GPOAttackType.REGISTRY_SETTINGS,
            title="GPP Passwords Check (MS14-025)",
            description="Group Policy Preferences may contain decryptable passwords",
            risk=RiskLevel.CRITICAL,
            technique="Check Groups.xml, ScheduledTasks.xml, Services.xml in SYSVOL for cpassword",
            remediation="Remove any GPP passwords; use LAPS for local admin passwords",
            mitre_technique="T1552.006",
        ))
        
        # Check for startup scripts
        findings.append(GPOAbuseFinding(
            attack_type=GPOAttackType.STARTUP_SCRIPTS,
            title="Startup Scripts Audit",
            description="Review startup scripts for malicious content",
            risk=RiskLevel.MEDIUM,
            technique="Check Machine\\Scripts\\Startup in each GPO folder",
            remediation="Audit and sign all startup scripts; implement script monitoring",
        ))
        
        # Check for scheduled tasks
        findings.append(GPOAbuseFinding(
            attack_type=GPOAttackType.SCHEDULED_TASKS,
            title="Scheduled Tasks via GPO Audit",
            description="Review scheduled tasks deployed via GPO",
            risk=RiskLevel.MEDIUM,
            technique="Check ScheduledTasks.xml in GPO preferences",
            remediation="Audit scheduled tasks; remove unnecessary entries",
        ))
        
        return findings
    
    def _enumerate_attack_paths(self, gpos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Enumerate GPO abuse attack paths."""
        paths = [
            {
                "name": "GPO Abuse for Code Execution",
                "steps": [
                    "1. Enumerate GPOs with PowerView",
                    "2. Find GPOs with writable permissions",
                    "3. Add malicious startup script or scheduled task",
                    "4. Wait for GPO refresh or force with gpupdate",
                    "5. Code executes on all affected computers",
                ],
                "tools": ["SharpGPOAbuse", "PowerView", "PyGPOAbuse"],
                "impact": "Code execution across domain",
            },
            {
                "name": "GPO Local Admin Escalation",
                "steps": [
                    "1. Find GPO linked to target computers",
                    "2. Modify Restricted Groups to add user to local Admins",
                    "3. GPO refresh adds user as local admin",
                ],
                "tools": ["SharpGPOAbuse --AddLocalAdmin"],
                "impact": "Local admin on all affected computers",
            },
        ]
        
        return paths
    
    def _generate_recommendations(self) -> List[str]:
        """Generate GPO security recommendations."""
        return [
            "Restrict GPO modification to Domain Admins only",
            "Enable Advanced Audit Policy for DS Access",
            "Monitor SYSVOL for unauthorized changes",
            "Remove GPP passwords from all GPOs",
            "Implement GPO backup and change monitoring",
            "Use security filtering to limit GPO scope",
            "Enable AppLocker or WDAC via GPO",
            "Implement GPO signing for startup scripts",
            "Regular GPO security audits",
            "Monitor Event ID 5136 for GPO changes",
        ]
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get all GPO attack techniques."""
        return GPO_ATTACK_TECHNIQUES
    
    def get_high_value_targets(self) -> List[Dict[str, Any]]:
        """Get high-value GPO targets."""
        return HIGH_VALUE_GPO_TARGETS
    
    def get_tools(self) -> List[Dict[str, Any]]:
        """Get GPO abuse tools."""
        return GPO_ABUSE_TOOLS


def get_gpo_attack_database() -> Dict[str, Any]:
    """Get GPO attack techniques database."""
    return GPO_ATTACK_TECHNIQUES

