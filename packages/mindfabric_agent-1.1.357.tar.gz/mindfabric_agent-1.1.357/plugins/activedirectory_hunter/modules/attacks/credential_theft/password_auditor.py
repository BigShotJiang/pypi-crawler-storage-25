"""
Password Auditor Module

Audits passwords for weak credentials and policy violations
"""

import time
from typing import Dict, Any, List
from ....proto import ScanOptions, DirectoryType
from ...enumeration.user_enumerator import UserEnumerator


class PasswordAuditor:
    """Audits passwords"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.user_enumerator = UserEnumerator(plugin_instance)
    
    async def audit(self, scan_options: ScanOptions, directory_type: DirectoryType,
                   password_list: List[str] = None) -> Dict[str, Any]:
        """
        Audits passwords for weak credentials and policy violations
        
        Args:
            scan_options: Scan parameters
            directory_type: Directory type
            password_list: Optional list of common passwords to test
            
        Returns:
            Dict[str, Any]: Audit results
        """
        result = {
            "success": False,
            "weak_passwords": [],
            "policy_violations": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        try:
            # Get users
            users = self.user_enumerator.enumerate(scan_options, directory_type)
            
            # Check for policy violations
            policy_violations = []
            for user in users:
                violations = []
                
                if user.password_never_expires:
                    violations.append("Password never expires")
                
                if user.password_not_required:
                    violations.append("Password not required")
                
                if violations:
                    policy_violations.append({
                        "username": user.sam_account_name,
                        "violations": violations
                    })
            
            result["policy_violations"] = policy_violations
            
            # If password list provided, test them
            if password_list:
                # Use password spraying module
                from .password_spray import PasswordSprayAttack
                spray_attack = PasswordSprayAttack(self.plugin)
                spray_result = await spray_attack.execute(scan_options, directory_type, password_list)
                
                if spray_result.get("success"):
                    result["weak_passwords"] = spray_result.get("valid_credentials", [])
            
            result["success"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during password audit: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

