"""Credential Theft Attack Modules"""

from .kerberoast import KerberoastAttack
from .asreproast import ASREPRoastAttack
from .dcsync import DCSyncAttack
from .password_spray import PasswordSprayAttack
from .laps_dump import LAPSPasswordDumper
from .credential_extractor import CredentialExtractor
from .password_auditor import PasswordAuditor
from .replication_attacks import ReplicationAttacks

__all__ = [
    'KerberoastAttack', 'ASREPRoastAttack', 'DCSyncAttack',
    'PasswordSprayAttack', 'LAPSPasswordDumper', 'CredentialExtractor',
    'PasswordAuditor', 'ReplicationAttacks'
]

