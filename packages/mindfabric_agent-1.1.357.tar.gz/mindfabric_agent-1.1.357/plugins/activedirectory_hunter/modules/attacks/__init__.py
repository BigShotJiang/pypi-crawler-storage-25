"""Attack Modules for Active Directory Hunter"""

from .credential_theft import KerberoastAttack, ASREPRoastAttack, DCSyncAttack
from .lateral_movement import PassTheHashAttack
from .persistence import GoldenTicketCreator, ShadowAdminCreator
from .federation import ADFSAttacks, ADFSFinding, ADFSAttackType, ADFS_ATTACK_TECHNIQUES
from .hybrid_identity import (
    AzureADHybridAttacks,
    HybridAttackFinding,
    HybridAttackType,
    HYBRID_ATTACK_TECHNIQUES,
)
from .gpo_abuse import (
    GPOAbuseAttacks,
    GPOAbuseFinding,
    GPOAttackType,
    GPO_ATTACK_TECHNIQUES,
    HIGH_VALUE_GPO_TARGETS,
    GPO_ABUSE_TOOLS,
)

__all__ = [
    # Credential Theft
    'KerberoastAttack', 'ASREPRoastAttack', 'DCSyncAttack',
    # Lateral Movement
    'PassTheHashAttack',
    # Persistence
    'GoldenTicketCreator', 'ShadowAdminCreator',
    # Federation (ADFS) Attacks
    'ADFSAttacks', 'ADFSFinding', 'ADFSAttackType', 'ADFS_ATTACK_TECHNIQUES',
    # Hybrid Identity Attacks
    'AzureADHybridAttacks', 'HybridAttackFinding', 'HybridAttackType', 'HYBRID_ATTACK_TECHNIQUES',
    # GPO Abuse Attacks
    'GPOAbuseAttacks', 'GPOAbuseFinding', 'GPOAttackType',
    'GPO_ATTACK_TECHNIQUES', 'HIGH_VALUE_GPO_TARGETS', 'GPO_ABUSE_TOOLS',
]

