"""
Active Directory Hunter UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse it)
- recommendations (what to fix / verify next)
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional, Tuple


def get_ad_guidance(kind: str) -> Tuple[str, List[Dict[str, str]]]:
    k = (kind or "").strip().lower()

    if k in ("shadow_admin", "shadow_admins"):
        return (
            "Shadow admins are non-obvious principals that can perform privileged AD actions (DCSync, group membership changes, password resets, GPO changes). Attackers can abuse these rights to become Domain Admin without exploiting a vulnerability.",
            [
                {"title": "Remove/limit delegated rights", "description": "Review and remove unexpected WriteDACL/GenericAll/Owner/Replicating Directory Changes rights on domain/OU/GPO/AdminSDHolder objects.", "priority": "high"},
                {"title": "Monitor privileged ACL changes", "description": "Alert on changes to ACLs of domain root, AdminSDHolder, privileged groups, and GPOs; investigate anomalies.", "priority": "medium"},
                {"title": "Reduce blast radius", "description": "Use tiering (PAW), least privilege, and dedicated admin accounts; avoid granting broad rights to service accounts.", "priority": "medium"},
            ],
        )

    if k in ("sid_history", "sid_history_abuse"):
        return (
            "SIDHistory can grant access equivalent to privileged groups if an attacker can inject/modify it. This can enable stealthy privilege escalation and persistence.",
            [
                {"title": "Restrict who can modify SIDHistory", "description": "Audit and restrict permissions that allow writing SIDHistory (including AD migration tools/accounts).", "priority": "high"},
                {"title": "Audit and clean suspicious SIDHistory", "description": "Investigate objects with SIDHistory referencing admin SIDs; remove invalid/suspicious entries.", "priority": "high"},
                {"title": "Enable detection", "description": "Alert on SIDHistory attribute changes and replication of related objects.", "priority": "medium"},
            ],
        )

    if k in ("kerberos_roast", "kerberoast"):
        return (
            "Kerberoasting and AS-REP roasting extract service account hashes from Kerberos. Weak passwords on SPN accounts are commonly cracked offline and reused for lateral movement and data access.",
            [
                {"title": "Harden SPN accounts", "description": "Use long random passwords or gMSAs; remove stale SPNs; avoid user accounts with SPNs where possible.", "priority": "high"},
                {"title": "Detect roasting activity", "description": "Alert on unusual TGS-REQ volume, odd source hosts, and AS-REP without pre-auth for sensitive accounts.", "priority": "medium"},
            ],
        )

    if k in ("domain_sync", "dcsync"):
        return (
            "DCSync-style replication abuse and critical DC flaws (e.g. ZeroLogon class) can yield domain-wide credential material. Attackers achieve persistent Domain Admin–level control.",
            [
                {"title": "Restrict replication rights", "description": "Audit Replicating Directory Changes* and DC computer account rights; remove unnecessary delegation.", "priority": "high"},
                {"title": "Patch DCs and monitor replication", "description": "Apply security updates promptly; alert on abnormal replication clients and DRS RPC patterns.", "priority": "high"},
            ],
        )

    if k in ("credential_relay", "pth", "ntlm"):
        return (
            "Pass-the-hash and NTLM relay abuse reuse captured hashes or challenge/response without cracking. Attackers pivot to SMB/RDP/WinRM and expand compromise across the estate.",
            [
                {"title": "Reduce NTLM and lateral paths", "description": "Prefer Kerberos; enable SMB signing; restrict WinRM/RDP exposure; use tiered admin accounts.", "priority": "high"},
                {"title": "Instrument auth telemetry", "description": "Correlate 4624/4768 with source workstation; hunt for odd NTLM usage from servers or service accounts.", "priority": "medium"},
            ],
        )

    if k in ("credential_spray_audit", "ldap", "spray"):
        return (
            "LDAP exposure and password guessing (spray/audit) can yield valid domain credentials. Valid accounts are the main pivot into Kerberos abuse and lateral movement.",
            [
                {"title": "Lock out abuse and watch auth", "description": "Smart lockout, CAP on VPN, and alerts on burst failures from single sources; review accounts targeted in spray patterns.", "priority": "high"},
                {"title": "Require MFA on exposed entry points", "description": "Enforce MFA for VPN, OWA, and cloud IdP; avoid password-only remote access to domain resources.", "priority": "medium"},
            ],
        )

    if k in ("adcs", "certificate", "pkinit"):
        return (
            "AD CS misconfiguration enables certificate-based authentication abuse (ESC*), shadow credentials, and PKINIT attacks—often equivalent to stealthy domain persistence.",
            [
                {"title": "Harden enrollment and templates", "description": "Disable weak templates, enforce manager approval, restrict enrollment agents, and audit published templates.", "priority": "high"},
                {"title": "Monitor certificate lifecycle", "description": "Alert on new certificates for privileged principals and unusual enrollment patterns.", "priority": "medium"},
            ],
        )

    if k in ("gpo_abuse",):
        return (
            "GPO and SYSVOL abuse lets attackers push scripts, scheduled tasks, or security policy changes to many hosts—silent mass execution across the domain.",
            [
                {"title": "Protect GPO/SYSVOL ACLs", "description": "Audit who can edit GPOs and write to NETLOGON/SYSVOL; remove unexpected edit rights.", "priority": "high"},
                {"title": "Detect GPO drift", "description": "Version and backup GPOs; alert on changes tied to non-change windows or non-admin actors.", "priority": "medium"},
            ],
        )

    if k in ("trust_abuse", "rbcd", "trust"):
        return (
            "Forest/domain trust and RBCD abuse can grant cross-domain access or constrained delegation attacks, expanding blast radius beyond a single domain.",
            [
                {"title": "Inventory and minimize trusts", "description": "Document bidirectional trusts and SID filtering; remove unused trusts; review RBCD attributes.", "priority": "high"},
                {"title": "Monitor cross-domain auth", "description": "Correlate TGT/TGS across trust boundaries; investigate unusual resource access from foreign principals.", "priority": "medium"},
            ],
        )

    if k in ("persistence_vector", "persistence"):
        return (
            "AD persistence (golden/silver tickets, shadow admins, SIDHistory, malicious delegation) lets attackers return after incident response if not fully eradicated.",
            [
                {"title": "Eradicate known persistence", "description": "Invalidate forged tickets (KRBTGT rotation when appropriate), remove rogue ACLs/delegation, and clean SIDHistory.", "priority": "high"},
                {"title": "Re-audit privileged objects", "description": "Compare AdminSDHolder, protected groups, and service principals to baseline after cleanup.", "priority": "high"},
            ],
        )

    if k in ("insecure_account", "risky_account"):
        return (
            "Accounts with password-not-required, never-expires, or risky delegation flags are common staging points for credential stuffing and privilege abuse.",
            [
                {"title": "Apply secure baseline", "description": "Clear dangerous userAccountControl flags; enforce password policy and MFA for interactive use.", "priority": "high"},
                {"title": "Privileged group review", "description": "If the account is in admin groups, treat as incident scope: rotate creds and review recent logons.", "priority": "medium"},
            ],
        )

    return (
        "Active Directory misconfigurations are frequently chained into domain-wide compromise: credential theft, lateral movement, and silent persistence.",
        [
            {
                "title": "Map the finding to MITRE and blast radius",
                "description": "Identify affected principals, OUs, and trust paths; document how an attacker would move from this signal to Domain Admin or data access.",
                "priority": "high",
            },
            {
                "title": "Remediate with least privilege",
                "description": "Remove excessive ACLs, fix auth policies, patch DCs/member servers, and validate with a second enumeration pass.",
                "priority": "medium",
            },
        ],
    )


def _coerce_ad_recommendation_items(recs: Any) -> List[Dict[str, str]]:
    if not recs:
        return []
    out: List[Dict[str, str]] = []
    for x in recs:
        if isinstance(x, str) and x.strip():
            out.append({"title": "Mitigation", "description": x.strip(), "priority": "high"})
        elif isinstance(x, dict):
            out.append(dict(x))
    return out


def _infer_ad_guidance_kind(*, title: str, threat_type: str) -> str:
    t = (title or "").strip().lower()
    tt = (threat_type or "").strip().lower()
    if "visibility gap" in t or "context not detected" in t:
        return "_skip"
    if "persistence vector" in t or (tt == "persistence" and "persistence" in t):
        return "persistence_vector"
    if "insecure ad account" in t or "risky flags" in t:
        return "insecure_account"
    method = ""
    if "ad attack vector:" in t:
        method = t.split("ad attack vector:", 1)[-1].strip()
    if "shadow" in method or "shadow" in t:
        return "shadow_admin"
    if "sid" in method and "history" in method:
        return "sid_history"
    if any(x in method for x in ("kerberoast", "asreproast", "asrep")):
        return "kerberos_roast"
    if any(x in method for x in ("dcsync", "zerologon", "dcshadow", "replication")):
        return "domain_sync"
    if any(x in method for x in ("pass_the_hash", "pth", "ntlm_relay", "smb_permissions")):
        return "credential_relay"
    if any(x in method for x in ("ldap", "password_spray", "password_audit", "ldapsweep")):
        return "credential_spray_audit"
    if "adcs" in method or "certificate" in method:
        return "adcs"
    if "gpo" in method:
        return "gpo_abuse"
    if "trust" in method or "rbcd" in method:
        return "trust_abuse"
    return "ad_generic"


def enrich_ad_hunt_findings(findings: List[Dict[str, Any]]) -> None:
    """
    hook_hunt() pre-builds `findings` with thin defaults; enrich before security_scan export.
    """
    for f in findings:
        if not isinstance(f, dict):
            continue
        kind = _infer_ad_guidance_kind(title=str(f.get("title") or ""), threat_type=str(f.get("threat_type") or ""))
        if kind == "_skip":
            continue
        recs = _coerce_ad_recommendation_items(f.get("recommendations"))
        d0 = (recs[0].get("description") or "").lower() if len(recs) == 1 and isinstance(recs[0], dict) else ""
        thin = (not recs) or (
            len(recs) == 1
            and isinstance(recs[0], dict)
            and (
                "validate and scope" in d0
                or "review finding" in d0
                or "investigate and remove the persistence mechanism" in d0
            )
        )
        if not thin:
            f["recommendations"] = recs
            continue
        impact, new_recs = get_ad_guidance(kind)
        if not f.get("impact") and impact:
            f["impact"] = impact
        f["recommendations"] = new_recs


def should_upgrade_ad_description(description: Optional[str]) -> bool:
    if not isinstance(description, str):
        return True
    s = description.strip()
    if not s:
        return True
    if len(s) < 70:
        return True
    # Avoid plain status-only messages
    if s.lower().startswith("status:"):
        return True
    return False


def build_ad_vector_description(*, method: Optional[str], status: Optional[str]) -> str:
    m = (method or "attack vector").strip()
    st = (status or "unknown").strip().lower()
    return (
        f"Active Directory attack surface identified ({m}, status={st}). "
        "AD weaknesses are often abused to escalate privileges (up to Domain Admin), dump credentials, and move laterally across the environment. "
        "Even when exploitation is not confirmed, these paths should be treated as high-value for remediation and monitoring."
    )


def _safe_read(path: str, max_bytes: int = 4096) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(max_bytes)
    except Exception:
        return ""


def collect_local_directory_indicators() -> Dict[str, Any]:
    """
    Best-effort local signal collection to explain why AD was/wasn't detected.
    Keep payload small and UI-friendly.
    """
    out: Dict[str, Any] = {
        "krb5_conf_present": os.path.exists("/etc/krb5.conf"),
        "samba_conf_present": os.path.exists("/etc/samba/smb.conf"),
        "resolv_conf_present": os.path.exists("/etc/resolv.conf"),
    }

    # /etc/krb5.conf -> default_realm
    if out["krb5_conf_present"]:
        txt = _safe_read("/etc/krb5.conf")
        m = re.search(r"(?im)^\s*default_realm\s*=\s*([A-Z0-9._-]+)\s*$", txt)
        if m:
            out["krb5_default_realm"] = m.group(1).strip()

    # /etc/samba/smb.conf -> realm/workgroup
    if out["samba_conf_present"]:
        txt = _safe_read("/etc/samba/smb.conf")
        m = re.search(r"(?im)^\s*realm\s*=\s*([A-Z0-9._-]+)\s*$", txt)
        if m:
            out["samba_realm"] = m.group(1).strip()
        m = re.search(r"(?im)^\s*workgroup\s*=\s*([A-Z0-9._-]+)\s*$", txt)
        if m:
            out["samba_workgroup"] = m.group(1).strip()

    # /etc/resolv.conf -> search/domain + nameservers (first few)
    if out["resolv_conf_present"]:
        txt = _safe_read("/etc/resolv.conf")
        search_domains: List[str] = []
        nameservers: List[str] = []
        for line in txt.splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("search "):
                parts = s.split()
                for d in parts[1:]:
                    if d and d not in search_domains:
                        search_domains.append(d)
            if s.startswith("domain "):
                parts = s.split()
                if len(parts) >= 2 and parts[1] and parts[1] not in search_domains:
                    search_domains.append(parts[1])
            if s.startswith("nameserver "):
                parts = s.split()
                if len(parts) >= 2 and parts[1] and parts[1] not in nameservers:
                    nameservers.append(parts[1])
        if search_domains:
            out["dns_search_domains"] = search_domains[:4]
        if nameservers:
            out["dns_nameservers"] = nameservers[:4]

    return out


def build_ad_visibility_gap_description(domain_info: Dict[str, Any], indicators: Dict[str, Any]) -> str:
    """
    Use wording that reflects reality: plugin ran, but could not confirm AD context from this host.
    """
    realm = indicators.get("krb5_default_realm") or indicators.get("samba_realm")
    dns = indicators.get("dns_search_domains")
    if realm or dns:
        return (
            "Directory signals were found on this host (Kerberos/Samba/DNS), but Active Directory enumeration was not possible without "
            "an explicit domain/DC target and credentials. Provide `domain_name` / `ldap_server` and credentials to enumerate users/groups/trusts "
            "and to detect AD-specific attack paths."
        )
    return (
        "This scan ran successfully, but the host does not appear to be domain-joined and no local directory configuration was detected "
        "(Kerberos/Samba/DNS). In this situation, the plugin cannot enumerate AD objects or produce AD attack/persistence vectors. "
        "Run it on a domain-connected machine or provide `domain_name`/`ldap_server` (and credentials) to enable enumeration."
    )


def build_ad_visibility_gap_evidence(domain_info: Dict[str, Any], indicators: Dict[str, Any]) -> Dict[str, Any]:
    # Avoid placeholder values like "unknown"
    di = dict(domain_info or {})
    for k in ("domain_name", "forest_name"):
        v = di.get(k)
        if isinstance(v, str) and v.strip().lower() == "unknown":
            di[k] = None
    return {
        "source": "activedirectory_hunter.directory_detection",
        "domain_info": di,
        "local_indicators": indicators,
    }


def get_ad_visibility_gap_exploitation_commands() -> List[str]:
    cmds = [
        "# Local directory indicators (read-only)",
        "cat /etc/krb5.conf 2>/dev/null || true",
        "cat /etc/samba/smb.conf 2>/dev/null || true",
        "cat /etc/resolv.conf 2>/dev/null || true",
        "",
        "# SRV discovery (set AD_DNS_DOMAIN, e.g. corp.example.com)",
        "dig +short _ldap._tcp.${AD_DNS_DOMAIN} SRV 2>/dev/null || true",
        "dig +short _kerberos._tcp.${AD_DNS_DOMAIN} SRV 2>/dev/null || true",
    ]
    return [c for c in cmds if isinstance(c, str) and c.strip()]

