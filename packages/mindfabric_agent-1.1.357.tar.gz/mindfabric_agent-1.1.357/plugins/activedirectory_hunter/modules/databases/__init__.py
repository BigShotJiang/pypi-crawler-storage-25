"""UI and knowledge-base templates for Active Directory Hunter."""

