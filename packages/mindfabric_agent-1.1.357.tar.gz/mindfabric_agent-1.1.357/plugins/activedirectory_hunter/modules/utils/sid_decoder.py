"""SID Decoder Utility"""

from typing import Optional


def decode_sid(sid_binary: bytes) -> Optional[str]:
    """
    Decodes SID from binary representation.
    
    Args:
        sid_binary: Binary representation of SID
        
    Returns:
        Optional[str]: String representation of SID or None on error
    """
    try:
        if len(sid_binary) < 8:
            return None
        
        # Checking first byte (should be 0x01 for SID version 1)
        if sid_binary[0] != 0x01:
            return None
        
        # Number of sub-identifiers (sub-authorities)
        sub_authority_count = sid_binary[1]
        
        if len(sid_binary) < 8 + 4 * sub_authority_count:
            return None
        
        # Authority identifier (usually 5 for NT Authority)
        authority = int.from_bytes(sid_binary[2:8], byteorder='big')
        
        # Forming SID string
        sid = f"S-1-{authority}"
        
        # Adding sub-identifiers
        for i in range(sub_authority_count):
            offset = 8 + (i * 4)
            sub_authority = int.from_bytes(sid_binary[offset:offset+4], byteorder='little')
            sid += f"-{sub_authority}"
        
        return sid
    except Exception:
        return None

