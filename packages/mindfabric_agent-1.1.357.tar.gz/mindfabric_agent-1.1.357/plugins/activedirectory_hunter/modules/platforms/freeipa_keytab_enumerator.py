"""
FreeIPA Keytab Enumerator Module

Enumerates keytab files in FreeIPA environment
"""

import time
from typing import Dict, Any, List
from ...proto import ScanOptions
from utils.async_subprocess import run_exec


class FreeIPAKeytabEnumerator:
    """Enumerates FreeIPA keytabs"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def enumerate(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """
        Enumerates keytab files in FreeIPA
        
        Args:
            scan_options: Scan parameters
            
        Returns:
            Dict[str, Any]: Enumeration results
        """
        result = {
            "success": False,
            "keytabs": [],
            "errors": [],
            "statistics": {
                "execution_time": 0
            }
        }
        
        start_time = time.time()
        
        if not scan_options.username or not scan_options.password:
            result["errors"].append("Credentials required for FreeIPA keytab enumeration")
            return result
        
        try:
            # Get Kerberos ticket
            await run_exec(
                ["kinit", scan_options.username],
                stdin=f"{scan_options.password}\n",
                timeout=10,
            )
            
            # List services (which have keytabs)
            rc, out, err = await run_exec(["ipa", "service-find", "--all"], timeout=30)
            
            if rc == 0:
                keytabs = []
                service_entries = (out or "").split('Principal name: ')
                
                for entry in service_entries[1:]:
                    lines = entry.splitlines()
                    if not lines:
                        continue
                    
                    principal = lines[0].strip()
                    
                    # Try to get keytab for this service
                    try:
                        keytab_path = f"/tmp/{principal.replace('/', '_')}.keytab"
                        getkeytab_cmd = [
                            "ipa-getkeytab",
                            "-s",
                            scan_options.ldap_server or "localhost",
                            "-p",
                            principal,
                            "-k",
                            keytab_path,
                        ]
                        get_rc, _, _ = await run_exec(getkeytab_cmd, timeout=10)
                        
                        if get_rc == 0:
                            keytabs.append({
                                "principal": principal,
                                "keytab_path": keytab_path,
                                "status": "retrieved"
                            })
                    except Exception:
                        pass
                
                result["keytabs"] = keytabs
                result["success"] = True
            else:
                result["errors"].append(f"Failed to enumerate services: {err}")
        
        except Exception as e:
            result["errors"].append(f"Error during keytab enumeration: {str(e)}")
        
        result["statistics"]["execution_time"] = time.time() - start_time
        
        return result

