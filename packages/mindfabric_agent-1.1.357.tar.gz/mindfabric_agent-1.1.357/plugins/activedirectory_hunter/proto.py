from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any, Set
from plugins.reproduction import ReproStep
from enum import Enum
from datetime import datetime


class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute for AD attack.
    """
    server: Optional[str] = Field(None, description="Target DC/server")
    ip: Optional[str] = Field(None, description="Target IP address")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class DirectoryType(str, Enum):
    """Types of directories."""
    ACTIVE_DIRECTORY = "active_directory"  # Microsoft Active Directory
    FREEIPA = "freeipa"                    # FreeIPA
    AZURE_AD = "azure_ad"                  # Microsoft Azure Active Directory
    UNKNOWN = "unknown"                    # Unknown directory type


class AttackMethod(str, Enum):
    """attack methods and extraction information."""
    KERBEROAST = "kerberohowt"              # Kerberohowting - exploitation weak phowswords service accounts
    ASREPROAST = "asreproast"              # ASREPRoast - attack on accounts with disabled Kerberos pre-authentication
    NTLM_RELAY = "ntlm_relay"              # NTLM Relay - forwarding of authentication
    BLOODHOUND = "bloodhound"              # Gathering information for BloodHound
    CREDENTIAL_Dump = "credential_dump"    # Dump of credentials
    DCSync = "dcsync"                      # DCSync - replication controller domain
    GOLDEN_TICKET = "golden_ticket"        # Golden Ticket - creation of fake TGT
    SILVER_TICKET = "silver_ticket"        # Silver Ticket - creation of fake TGS
    UNCONSTRAINED_DELEGATION = "unconstrained_delegation"  # exploitation of unconstrained delegation
    LDAPSweep = "ldapsweep"                # Scanning LDAP for information gathering
    PASS_THE_HASH = "pass_the_hash"        # Pass-the-Hash
    ZEROLOGON = "zerologon"                # attack ZeroLogon (CVE-2020-1472)
    ACL_ABUSE = "acl_abuse"                # exploitation of weak ACL settings

    # NTLM Coercion Attacks
    PETITPOTAM = "petitpotam"              # PetitPotam - NTLM relay via EfsRpcOpenFileRaw
    PRINTERBUG = "printerbug"              # Printer Bug - SpoolSample NTLM relay
    DFSPIPE = "dfspipe"                    # DFSCoerce - NTLM relay via DFS
    SHADOWCOERCE = "shadowcoerce"          # ShadowCoerce - NTLM relay via VSS
    COERCER = "coercer"                    # Generic coercion (multiple methods)
    
    # ADCS Attacks
    ADCS_ESC1 = "adcs_esc1"                # ESC1 - Misconfigured certificate template
    ADCS_ESC2 = "adcs_esc2"                # ESC2 - Any purpose EKU
    ADCS_ESC3 = "adcs_esc3"                # ESC3 - Enrollment agent certificate
    ADCS_ESC4 = "adcs_esc4"                # ESC4 - Vulnerable certificate template ACL
    ADCS_ESC5 = "adcs_esc5"                # ESC5 - Vulnerable PKI object access control
    ADCS_ESC6 = "adcs_esc6"                # ESC6 - EDITF_ATTRIBUTESUBJECTALTNAME2
    ADCS_ESC7 = "adcs_esc7"                # ESC7 - Vulnerable CA ACL
    ADCS_ESC8 = "adcs_esc8"                # ESC8 - NTLM relay to AD CS HTTP endpoints
    ADCS_ESC9 = "adcs_esc9"                # ESC9 - No security extension (CT_FLAG_NO_SECURITY_EXTENSION)
    ADCS_ESC10 = "adcs_esc10"              # ESC10 - Weak certificate mapping
    ADCS_ESC11 = "adcs_esc11"              # ESC11 - Relaying to ICPR RPC
    CERTIFRIED = "certifried"              # Certifried (CVE-2022-26923)
    
    # Constrained Delegation Attacks
    CONSTRAINED_DELEGATION = "constrained_delegation"        # S4U2Proxy/S4U2Self abuse
    RBCD = "rbcd"                          # Resource-Based Constrained Delegation
    
    # Shadow Credentials
    SHADOW_CREDENTIALS = "shadow_credentials"  # msDS-KeyCredentialLink abuse
    
    # SAMR/LSARPC Attacks
    SAMACCOUNTNAME_SPOOFING = "samaccountname_spoofing"  # sAMAccountName spoofing (CVE-2021-42287/42278)


class PersistenceMethod(str, Enum):
    """methods persistence in infrhowtructure."""
    DCSHADOW = "dcshadow"                  # DCShadow - imitation controller domain
    SKELETON_KEY = "skeleton_key"          # Skeleton Key - injection mhowter phowsword
    GOLDEN_TICKET = "golden_ticket"        # Golden Ticket - persistence via fake TGT
    SID_HISTORY = "sid_history"            # SID History - adding history SID
    COMPUTER_ACCOUNT = "computer_account"  # creation computer account write
    service_ACCOUNT = "service_account"    # creation service account write
    DSRM_PASSWORD = "dsrm_password"        # Changing password DSRM
    GROUP_MEMBERSHIP = "group_membership"  # Changing membership in groups
    GPO_MODIFICATION = "gpo_modification"  # Modification of group policy objects
    KERBEROS_KEY = "kerberos_key"          # Modification keys Kerberos
    SHADOW_ADMINS = "shadow_admins"        # Shadow Admins (hidden administrator rights)
    KEYTAB_THEFT = "keytab_theft"          # Theft of keytab files (for FreeIPA)
    CERTIFICATE_THEFT = "certificate_theft" # Theft of authentication certificates


class LDAPObject(BaseModel):
    """Base class for LDAP objects."""
    distinguished_name: str
    object_class: List[str]
    attributes: Dict[str, Any]
    domain: str
    creation_time: Optional[datetime] = None
    last_modified: Optional[datetime] = None


class User(LDAPObject):
    """Information about user."""
    username: str
    display_name: Optional[str] = None
    user_principal_name: Optional[str] = None
    sam_account_name: Optional[str] = None
    email: Optional[str] = None
    groups: List[str] = []
    enabled: Optional[bool] = None
    password_last_set: Optional[datetime] = None
    password_never_expires: Optional[bool] = None
    password_not_required: Optional[bool] = None
    smart_card_required: Optional[bool] = None
    delegation_permitted: Optional[bool] = None
    delegation_services: List[str] = []
    service_principal_names: List[str] = []
    asreproast_candidate: Optional[bool] = None
    kerberoast_candidate: Optional[bool] = None
    acl_vulnerabilities: List[str] = []
    admin_count: Optional[bool] = None
    sid: Optional[str] = None


class Group(LDAPObject):
    """Information about group."""
    name: str
    display_name: Optional[str] = None
    group_type: Optional[str] = None
    sam_account_name: Optional[str] = None
    members: List[str] = []
    member_of: List[str] = []
    description: Optional[str] = None
    is_privileged: Optional[bool] = None
    sid: Optional[str] = None


class Computer(LDAPObject):
    """Information about computer."""
    name: str
    dns_hostname: Optional[str] = None
    sam_account_name: Optional[str] = None
    os: Optional[str] = None
    os_version: Optional[str] = None
    service_principal_names: List[str] = []
    delegation_permitted: Optional[bool] = None
    delegation_services: List[str] = []
    is_domain_controller: Optional[bool] = None
    last_logon: Optional[datetime] = None
    password_last_set: Optional[datetime] = None
    sid: Optional[str] = None
    is_sensitive: Optional[bool] = None


class TrustRelationship(BaseModel):
    """Information about trust relationships."""
    source_domain: str
    target_domain: str
    trust_type: str
    trust_direction: str
    trust_attributes: List[str]
    created: Optional[datetime] = None
    is_transitive: bool = False


class GPO(LDAPObject):
    """Information about group policies."""
    name: str
    display_name: Optional[str] = None
    gpo_status: Optional[str] = None
    version: Optional[str] = None
    linked_objects: List[str] = []
    acl_vulnerabilities: List[str] = []


class DomainInfo(BaseModel):
    """Information about domain."""
    domain_name: str
    forest_name: Optional[str] = None
    directory_type: DirectoryType
    domain_functional_level: Optional[str] = None
    domain_controllers: List[str] = []
    domain_sid: Optional[str] = None
    password_policy: Optional[Dict[str, Any]] = None
    kerberos_policy: Optional[Dict[str, Any]] = None


class AttackSurface(BaseModel):
    """Information about possible attack vectors."""
    method: AttackMethod
    status: str  # "exploitable", "potentially_exploitable", "not_exploitable", "error"
    details: Optional[Dict[str, Any]] = None
    affected_objects: List[str] = []
    recommendations: List[str] = []
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = None


class PersistenceVector(BaseModel):
    """Information about persistence vectors."""
    method: PersistenceMethod
    status: str  # "applied", "applicable", "not_applicable", "error"
    details: Optional[Dict[str, Any]] = None
    affected_objects: List[str] = []
    cleanup_instructions: Optional[str] = None


class ScanOptions(BaseModel):
    """Options scanning."""
    ldap_server: Optional[str] = None
    use_domain_discovery: bool = True
    username: Optional[str] = None
    password: Optional[str] = None
    ntlm_hash: Optional[str] = None
    kerberos_ticket: Optional[str] = None
    keytab_file: Optional[str] = None
    domain_name: Optional[str] = None
    use_kerberos: bool = False
    enumerate_users: bool = True
    enumerate_groups: bool = True
    enumerate_computers: bool = True
    enumerate_gpo: bool = True
    enumerate_trusts: bool = True
    analyze_acls: bool = False
    search_exploitation_vectors: bool = False
    search_persistence_vectors: bool = False
    attack_methods: Optional[List[AttackMethod]] = None
    persistence_methods: Optional[List[PersistenceMethod]] = None
    ldap_attributes: Optional[List[str]] = None
    output_format: str = "json"
    output_file: Optional[str] = None
    bloodhound_compatible: bool = False
    timeout: int = 300


class HunterResult(BaseModel):
    """Result scanning."""
    domain_info: DomainInfo
    scan_timestamp: datetime
    scan_id: str
    scan_duration: float
    users: List[User] = []
    groups: List[Group] = []
    computers: List[Computer] = []
    trusts: List[TrustRelationship] = []
    gpos: List[GPO] = []
    attack_vectors: List[AttackSurface] = []
    persistence_vectors: List[PersistenceVector] = []
    scan_options: ScanOptions
    total_users: int = 0
    total_groups: int = 0
    total_computers: int = 0
    total_privileged_accounts: int = 0
    total_attack_vectors: int = 0
    total_persistence_vectors: int = 0
    errors: List[str] = []
    warnings: List[str] = []
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for key findings"
    )