"""
Plugin for reconnaissance and exploitation of Active Directory and FreeIPA:
- Collect domain structure (users, groups, computers)
- Find configuration mistakes and weaknesses
- Extract pentest-relevant data (ASREPRoast, Kerberoasting, etc.)
- Domain persistence techniques
"""
from .activedirectory_hunter import ActiveDirectoryHunterPlugin

__all__ = ['ActiveDirectoryHunterPlugin']