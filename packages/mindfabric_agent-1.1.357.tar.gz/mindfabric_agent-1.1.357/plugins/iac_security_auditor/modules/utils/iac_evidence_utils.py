"""Shared evidence preview + risk helpers for IaC scanners."""

from __future__ import annotations

import os
from typing import List, Optional

from ...proto import IaCSeverity


def iac_absolute_path(path: Optional[str]) -> str:
    """Best-effort absolute, normalized filesystem path for UI / dedup."""
    if path is None:
        return ""
    s = str(path).strip()
    if not s:
        return ""
    try:
        return os.path.abspath(os.path.normpath(s))
    except Exception:
        return s


def format_context_for_ui(
    context_lines: Optional[List[str]],
    *,
    max_length: int = 800,
) -> str:
    """
    Single string for threat UI "Context" column (redacted lines already applied upstream).
    """
    if not context_lines:
        return ""
    parts: List[str] = []
    for line in context_lines:
        if line is None:
            continue
        parts.append(str(line).rstrip("\n"))
    text = "\n".join(parts).strip()
    if len(text) > max_length:
        return text[: max_length - 1].rstrip() + "…"
    return text


def iac_severity_risk(severity: IaCSeverity) -> int:
    return {
        IaCSeverity.CRITICAL: 88,
        IaCSeverity.HIGH: 72,
        IaCSeverity.MEDIUM: 48,
        IaCSeverity.LOW: 28,
        IaCSeverity.INFO: 12,
    }.get(severity, 45)


def redact_secret_matched_text(matched: str) -> str:
    """Keep key / operator visible; mask literal value after : or =."""
    if not matched:
        return matched
    s = matched.strip()
    for sep in (":", "="):
        if sep in s:
            head, _, tail = s.partition(sep)
            t = tail.strip().strip("'\"")
            if len(t) <= 4:
                return f"{head}{sep} ****"
            return f"{head}{sep} ****{t[-2:]}"
    if len(s) > 12:
        return s[:4] + "****" + s[-4:]
    return "****"


def context_lines_for_match(content: str, line_1based: int, radius: int = 3) -> List[str]:
    lines = content.splitlines()
    if not lines:
        return []
    idx = max(0, min(len(lines) - 1, line_1based - 1))
    lo = max(0, idx - radius)
    hi = min(len(lines), idx + radius + 1)
    out: List[str] = []
    for i in range(lo, hi):
        line = lines[i]
        if i == idx:
            out.append(redact_secret_matched_text(line))
        else:
            out.append(line)
    return out
