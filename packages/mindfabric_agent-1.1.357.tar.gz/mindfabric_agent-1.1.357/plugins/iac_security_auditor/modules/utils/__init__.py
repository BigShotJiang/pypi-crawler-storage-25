"""Shared utilities for IaC scanners."""
