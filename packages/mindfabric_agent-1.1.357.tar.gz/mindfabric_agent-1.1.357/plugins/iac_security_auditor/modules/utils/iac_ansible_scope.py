"""
Infer logical deployment targets from Ansible paths and YAML (hosts / role / inventory).

Used for Threat "affected_resources" — defenders care about *what* is managed, not only file paths.
"""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional, Tuple


def _nearest_hosts_pattern(content: str, line_number: int) -> Optional[str]:
    """Walk upward from line_number (1-based) to find `hosts:` for the enclosing play."""
    if not content or line_number < 1:
        return None
    lines = content.splitlines()
    idx = min(line_number - 1, len(lines) - 1)
    if idx < 0:
        return None
    i = idx
    while i >= 0:
        raw = lines[i]
        if raw.strip().startswith("#"):
            i -= 1
            continue
        m = re.match(r"^(?:\s*-\s*)?hosts:\s*(.+)$", raw)
        if m:
            val = m.group(1).strip().split("#")[0].strip().strip("\"'")
            if not val or "{{" in val or "{%" in val:
                i -= 1
                continue
            return val[:240]
        i -= 1
        if idx - i > 600:
            break
    return None


def _inventory_host_at_line(content: str, line_number: int) -> Optional[str]:
    """INI-style inventory: hostname at start of a non-section line."""
    if not content or line_number < 1:
        return None
    lines = content.splitlines()
    idx = line_number - 1
    if idx < 0 or idx >= len(lines):
        return None
    line = lines[idx].strip()
    if not line or line.startswith("#") or line.startswith("["):
        return None
    m = re.match(r"^([a-zA-Z0-9_.-]+)\s", line)
    if m:
        return m.group(1)
    return None


def _path_inventory_like(fp_norm: str) -> bool:
    bn = os.path.basename(fp_norm).lower()
    if bn in ("hosts", "inventory", "inventory.ini"):
        return True
    low = fp_norm.lower()
    return "/inventory/" in low or "/inventories/" in low


def ansible_target_key(t: Dict[str, Any]) -> Tuple[Any, ...]:
    return (
        t.get("type"),
        t.get("pattern"),
        t.get("name"),
        t.get("group"),
        t.get("host"),
        t.get("scope"),
    )


def infer_ansible_targets(file_path: str, content: str, line_number: int) -> List[Dict[str, Any]]:
    """
    Return 0..n stable dicts for affected_resources / evidence.ansible_targets.

    Types:
      ansible_hosts — play `hosts:` pattern
      ansible_role — role name from .../roles/<name>/...
      ansible_group_vars — group from group_vars
      ansible_host_vars — host from host_vars
      ansible_inventory_host — host entry in inventory
      ansible_inventory — static inventory file (when no specific host line)
    """
    fp = (file_path or "").replace("\\", "/")
    out: List[Dict[str, Any]] = []
    seen: set = set()

    def add(obj: Dict[str, Any]) -> None:
        k = ansible_target_key(obj)
        if k in seen:
            return
        seen.add(k)
        out.append(obj)

    m = re.search(r"/roles/([^/]+)/", fp)
    if m:
        add({"type": "ansible_role", "name": m.group(1)})

    m = re.search(r"/group_vars/([^/]+?)(?:\.ya?ml|\.yaml)?$", fp)
    if not m:
        m = re.search(r"/group_vars/([^/]+)/", fp)
    if m:
        g = m.group(1)
        if g and g.lower() != "all":
            add({"type": "ansible_group_vars", "group": g})

    m = re.search(r"/host_vars/([^/]+)/", fp)
    if m:
        add({"type": "ansible_host_vars", "host": m.group(1)})

    if content and line_number > 0:
        hp = _nearest_hosts_pattern(content, line_number)
        if hp:
            add({"type": "ansible_hosts", "pattern": hp})

    if _path_inventory_like(fp):
        ih = _inventory_host_at_line(content, line_number) if content else None
        if ih:
            add({"type": "ansible_inventory_host", "host": ih})
        else:
            add({"type": "ansible_inventory", "scope": "static inventory"})

    return out


def merge_ansible_targets(findings_evidence: List[Dict[str, Any]], cap: int = 36) -> List[Dict[str, Any]]:
    """Union ansible_targets from multiple findings (aggregation)."""
    merged: List[Dict[str, Any]] = []
    seen: set = set()
    for ev in findings_evidence:
        if not isinstance(ev, dict):
            continue
        raw = ev.get("ansible_targets")
        if not isinstance(raw, list):
            continue
        for item in raw:
            if not isinstance(item, dict):
                continue
            k = ansible_target_key(item)
            if k in seen:
                continue
            seen.add(k)
            merged.append(dict(item))
            if len(merged) >= cap:
                return merged
    return merged
