from __future__ import annotations

import shlex
from typing import Any, Dict, List, Optional


IAC_GENERAL_RECOMMENDATIONS: List[Dict[str, str]] = [
    {
        "title": "Fix IaC security issues at source",
        "description": "Update IaC templates to enforce encryption, least privilege, and secure defaults; re-run the scan in CI.",
        "priority": "high",
    },
    {
        "title": "Add policy-as-code to CI/CD",
        "description": "Use tools like Checkov/tfsec and block merges on High/Critical misconfigurations.",
        "priority": "medium",
    },
]


def build_iac_rule_recommendations(
    *,
    pattern: Optional[str] = None,
    remediation: Optional[str] = None,
    tool_name: str = "IaC",
) -> List[Dict[str, str]]:
    """
    One general IaC block plus 1–2 concrete steps derived from rule remediation text.
    """
    out: List[Dict[str, str]] = [dict(x) for x in IAC_GENERAL_RECOMMENDATIONS]
    rem = (remediation or "").strip()
    if rem:
        out.append(
            {
                "title": f"Apply the {tool_name} rule fix",
                "description": rem,
                "priority": "high",
            }
        )
    if pattern:
        out.append(
            {
                "title": f"Replace inline `{pattern}` values",
                "description": (
                    f"Move `{pattern}`-like secrets out of YAML into Ansible Vault, "
                    "CI/CD secret stores, or host/group vars loaded from encrypted files; "
                    "reference them with `{{ vault_var }}` variables instead of literals."
                ),
                "priority": "high",
            }
        )
    return out

def build_iac_scan_completed_description(*, directory: str = ".", by_tool: Optional[Dict[str, Any]] = None) -> str:
    """
    Hacker-centric summary for 'no findings' runs.
    The goal is to explain what was checked and why '0 findings' isn't a free pass.
    """
    tools = []
    bt = by_tool or {}
    for k in ("terraform", "cloudformation", "ansible", "pulumi"):
        try:
            if int(bt.get(k) or 0) >= 0:
                tools.append(k)
        except Exception:
            tools.append(k)
    tools_str = ", ".join(tools) if tools else "Terraform/CloudFormation/Ansible/Pulumi"

    return (
        f"No IaC security findings were emitted for the scanned scope (`{directory}`). "
        f"The auditor looked for common misconfigurations and risky defaults across {tools_str} templates. "
        "This reduces the likelihood of obvious issues (public exposure, weak IAM, missing encryption), but it does not guarantee the environment is secure: "
        "some risks are context-dependent (runtime values, CI variables, modules pulled at deploy time) and may not be visible statically. "
        "Use the recommendations below to keep IaC hardened over time and prevent regressions."
    )


def build_iac_scan_completed_impact() -> str:
    return (
        "IaC is an attack surface: insecure defaults can deploy public services, overly-permissive IAM roles, and unencrypted storage at scale. "
        "Even when a scan is clean, drift in templates or CI/CD can reintroduce high-impact misconfigurations."
    )


def build_iac_scan_completed_evidence(*, directory: str = ".", summary: Optional[Dict[str, Any]] = None, by_tool: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    # Keep evidence minimal and structured (avoid dumping large objects).
    ev: Dict[str, Any] = {"source": "iac_security_auditor.summary", "directory": directory}
    if isinstance(summary, dict):
        ev["summary"] = {
            "total_findings": summary.get("total_findings"),
            "critical": summary.get("critical"),
            "high": summary.get("high"),
            "medium": summary.get("medium"),
            "low": summary.get("low"),
            "risk_score": summary.get("risk_score"),
        }
    if isinstance(by_tool, dict):
        ev["by_tool"] = {
            "terraform": by_tool.get("terraform"),
            "cloudformation": by_tool.get("cloudformation"),
            "ansible": by_tool.get("ansible"),
            "pulumi": by_tool.get("pulumi"),
        }
    return ev


def get_iac_exploitation_commands(context: Optional[Dict[str, Any]] = None) -> List[str]:
    """
    Read-only commands to reproduce / locate IaC issues.
    """
    ctx = context or {}
    file_path = str(ctx.get("file_path") or "")
    line_number = ctx.get("line_number")
    directory = str(ctx.get("directory") or ".")

    qdir = shlex.quote(directory or ".")
    cmds: List[str] = [
        "# Locate IaC files (Terraform/CloudFormation/Ansible/Pulumi)",
        f"find {qdir} -maxdepth 6 -type f \\( -name '*.tf' -o -name '*.tfvars' -o -name '*.yml' -o -name '*.yaml' -o -name '*.json' -o -name '*.py' \\) 2>/dev/null | head -n 200",
    ]

    if file_path:
        qfp = shlex.quote(file_path)
        cmds.append(f"# Inspect file: {file_path}")
        if isinstance(line_number, int) and line_number > 0:
            start = max(1, int(line_number) - 5)
            end = int(line_number) + 5
            cmds.append(f"nl -ba {qfp} | sed -n '{start},{end}p'")
        else:
            cmds.append(f"sed -n '1,200p' {qfp}")
        cmds.extend(
            [
                f"file {qfp} 2>/dev/null || true",
                "# Terraform (install terraform; run only after review):",
                f"command -v terraform >/dev/null && terraform -chdir=$(dirname {qfp}) fmt -check -diff 2>/dev/null | head -n 80 || true",
                f"command -v terraform >/dev/null && terraform -chdir=$(dirname {qfp}) validate 2>/dev/null | head -n 80 || true",
                "# CloudFormation JSON/YAML (optional cfn-lint):",
                "command -v cfn-lint >/dev/null && cfn-lint --template " + qfp + " 2>/dev/null | head -n 80 || true",
            ]
        )
    return cmds

