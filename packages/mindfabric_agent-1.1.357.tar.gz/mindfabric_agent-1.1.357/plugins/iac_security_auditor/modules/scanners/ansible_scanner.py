"""
Ansible Security Scanner

Security assessment for Ansible configurations:
- Playbook security (hardcoded credentials, unsafe modules)
- Vault security (weak encryption, exposed passwords)
- Inventory security (credentials in inventory)
- Task security (shell commands, privilege escalation)

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1059: Command and Scripting Interpreter
"""

import os
import re
import logging
from typing import Dict, List, Any, Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from ...proto import (
    IaCFinding, IaCTool, IaCSeverity, IaCCheckCategory,
    ANSIBLE_SECURITY_RULES, ComplianceFramework
)
from ..utils.iac_evidence_utils import (
    context_lines_for_match,
    iac_absolute_path,
    iac_severity_risk,
    redact_secret_matched_text,
)
from ..utils.iac_ansible_scope import infer_ansible_targets

logger = logging.getLogger(__name__)


def _ansible_secret_impact(secret_type: str, file_path: str) -> str:
    base = os.path.basename(file_path or "") or file_path or "playbook"
    return (
        f"Plaintext `{secret_type}` in `{base}` can end up in git history, CI logs, and host backups. "
        "Anyone with repo or artifact access can reuse it to authenticate to managed systems or cloud APIs."
    )


def _ansible_secret_detection_reason(secret_type: str) -> str:
    return (
        f"Static pattern matched Ansible/YAML line suggesting `{secret_type}` is assigned a non-templated literal "
        "(not `{{ ... }}` / vault reference), which violates secret-handling best practice."
    )


# =============================================================================
# Ansible Security Patterns
# =============================================================================

ANSIBLE_SECRET_PATTERNS = {
    # NOTE:
    # Use [ \\t]* instead of \\s* after ":" to avoid matching across newlines.
    # This prevents false positives on YAML keys like "/.../secret:" followed by a nested block on the next line.
    "password_var": r'(?:password|passwd|pwd):[ \t]*["\']?[^"\'\n{]+["\']?',
    "ansible_password": r'ansible_(?:ssh_)?pass(?:word)?:[ \t]*["\']?[^"\'\n{]+["\']?',
    "become_pass": r'ansible_become_pass(?:word)?:[ \t]*["\']?[^"\'\n{]+["\']?',
    "api_key": r'(?:api_key|apikey|api_token):[ \t]*["\']?[^"\'\n{]+["\']?',
    # "secret:" is extremely common in API specs/docs; restrict to explicit key names.
    "secret_key": r'(?:secret_key|private_key):[ \t]*["\']?[^"\'\n{]+["\']?',
    "aws_key": r'aws_(?:access_key_id|secret_access_key):[ \t]*["\']?[^"\'\n{]+["\']?',
}

UNSAFE_MODULES = {
    "shell": {
        "severity": IaCSeverity.MEDIUM,
        "description": "shell module can execute arbitrary commands",
        "remediation": "Use specific modules (yum, apt, file) instead of shell",
    },
    "command": {
        "severity": IaCSeverity.LOW,
        "description": "command module bypasses the shell",
        "remediation": "Consider using specific modules for better idempotency",
    },
    "raw": {
        "severity": IaCSeverity.HIGH,
        "description": "raw module runs low-level commands without module subsystem",
        "remediation": "Only use for bootstrap scenarios",
    },
    "script": {
        "severity": IaCSeverity.MEDIUM,
        "description": "script module transfers and executes scripts",
        "remediation": "Use specific modules or template with validation",
    },
}

DANGEROUS_PATTERNS = {
    "no_log_false": {
        "pattern": r'no_log:\s*(?:false|no)',
        "severity": IaCSeverity.MEDIUM,
        "title": "Sensitive Task Without no_log",
        "description": "Task may log sensitive data",
        "remediation": "Set no_log: true for tasks handling secrets",
    },
    "ignore_errors": {
        "pattern": r'ignore_errors:\s*(?:true|yes)',
        "severity": IaCSeverity.LOW,
        "title": "Task Ignoring Errors",
        "description": "Task configured to ignore all errors",
        "remediation": "Use failed_when or rescue blocks for error handling",
    },
    "check_mode_skip": {
        "pattern": r'check_mode:\s*(?:false|no)',
        "severity": IaCSeverity.LOW,
        "title": "Check Mode Disabled",
        "description": "Task skips check mode which may cause unintended changes",
        "remediation": "Allow check mode for testing",
    },
}


class AnsibleScanner:
    """Ansible security scanner."""
    
    def __init__(self):
        self.findings: List[IaCFinding] = []
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            logger.debug(f"Failed to read {path}: {e}")
            return None
    
    def _find_ansible_files(self, directory: str) -> Dict[str, List[str]]:
        """Find Ansible files by type."""
        files = {
            "playbooks": [],
            "roles": [],
            "inventory": [],
            "vars": [],
            "vault": [],
        }

        # If scanning the filesystem root (common for scheduled agent runs),
        # skip high-noise system directories that contain lots of YAML/JSON docs and vendored content.
        # This dramatically reduces false positives like /snap/.../rest-api.yaml.
        try:
            abs_dir = os.path.abspath(os.path.realpath(directory))
        except Exception:
            abs_dir = os.path.abspath(directory)
        system_excludes = set()
        if abs_dir == "/":
            system_excludes = {
                "proc",
                "sys",
                "dev",
                "run",
                "snap",
                "usr",
                "lib",
                "lib64",
                "bin",
                "sbin",
                "boot",
                "var",
                "tmp",
                "mnt",
                "media",
            }
        
        for root, dirs, filenames in os.walk(directory):
            dirs[:] = [
                d
                for d in dirs
                if not d.startswith(".")
                and d not in ["node_modules", "vendor"]
                and d not in system_excludes
            ]
            
            for filename in filenames:
                if not (filename.endswith('.yml') or filename.endswith('.yaml')):
                    continue
                
                full_path = iac_absolute_path(os.path.join(root, filename))
                
                # Classify files
                if 'playbook' in filename.lower() or filename in ['site.yml', 'site.yaml', 'main.yml']:
                    files["playbooks"].append(full_path)
                elif 'vars' in root or 'defaults' in root or filename.startswith('vars'):
                    files["vars"].append(full_path)
                elif 'inventory' in root or filename in ['hosts', 'inventory']:
                    files["inventory"].append(full_path)
                elif 'tasks' in root or 'handlers' in root:
                    files["roles"].append(full_path)
                elif '.vault' in filename or 'vault' in filename:
                    files["vault"].append(full_path)
                else:
                    files["playbooks"].append(full_path)
        
        return files
    
    def _get_line_number(self, content: str, match_start: int) -> int:
        """Get line number from match position."""
        return content[:match_start].count('\n') + 1

    def _evidence_with_ansible_targets(
        self, file_path: str, content: Optional[str], line_number: int, evidence: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Attach inferred Ansible deployment targets (hosts, role, inventory, …) for Threat UI."""
        ev = dict(evidence)
        if content:
            targets = infer_ansible_targets(file_path, content, line_number)
            if targets:
                ev["ansible_targets"] = targets
        return ev
    
    def scan_for_secrets(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan for hardcoded secrets."""
        findings = []
        
        # Skip if it looks like vault encrypted
        if content.strip().startswith('$ANSIBLE_VAULT;'):
            return findings
        
        for secret_type, pattern in ANSIBLE_SECRET_PATTERNS.items():
            for match in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                matched_text = match.group()

                # Hard safety: ignore multiline matches (shouldn't happen with patterns above,
                # but protects against future regex edits).
                if "\n" in matched_text or "\r" in matched_text:
                    continue
                
                # Skip if it's a variable reference
                if '{{' in matched_text or '}}' in matched_text:
                    continue
                
                # Skip if it's clearly a placeholder
                if any(p in matched_text.lower() for p in ['changeme', 'example', 'xxx', 'your_']):
                    continue
                
                line_num = self._get_line_number(content, match.start())
                ctx = context_lines_for_match(content, line_num, radius=3)
                redacted = redact_secret_matched_text(matched_text)
                desc = (
                    f"Literal `{secret_type}` assignment in `{os.path.basename(file_path)}` "
                    f"(line {line_num}); material is visible in-repo and in many deployment logs."
                )
                findings.append(IaCFinding(
                    tool=IaCTool.ANSIBLE,
                    category=IaCCheckCategory.HARDCODED_CREDENTIALS,
                    severity=IaCSeverity.CRITICAL,
                    title=f"Hardcoded {secret_type.replace('_', ' ').title()}",
                    description=desc,
                    file_path=file_path,
                    line_number=line_num,
                    evidence=self._evidence_with_ansible_targets(
                        file_path,
                        content,
                        line_num,
                        {
                            "pattern": secret_type,
                            "matched_text": redacted,
                            "context_lines": ctx,
                        },
                    ),
                    remediation="Use Ansible Vault to encrypt sensitive data",
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2, ComplianceFramework.PCI_DSS],
                    impact=_ansible_secret_impact(secret_type, file_path),
                    detection_reason=_ansible_secret_detection_reason(secret_type),
                    risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                ))
        
        return findings
    
    def scan_unsafe_modules(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan for unsafe module usage."""
        findings = []
        
        if not YAML_AVAILABLE:
            return findings
        
        try:
            data = yaml.safe_load(content)
            if not data:
                return findings
            
            # Handle both list (playbook) and dict (tasks file)
            tasks = []
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        tasks.extend(item.get('tasks', []))
                        tasks.extend(item.get('pre_tasks', []))
                        tasks.extend(item.get('post_tasks', []))
            elif isinstance(data, dict):
                tasks = [data]
            
            for task in tasks:
                if not isinstance(task, dict):
                    continue
                
                for module_name, module_info in UNSAFE_MODULES.items():
                    if module_name in task:
                        sev = module_info["severity"]
                        tn = task.get("name") or "unnamed task"
                        findings.append(IaCFinding(
                            tool=IaCTool.ANSIBLE,
                            category=IaCCheckCategory.TASK_SECURITY,
                            severity=sev,
                            title=f"Unsafe Module: {module_name}",
                            description=(
                                f"Task `{tn}` in `{os.path.basename(file_path)}` uses `{module_name}`, "
                                f"which {module_info['description']} and expands blast radius if playbooks are attacker-controlled."
                            ),
                            file_path=file_path,
                            resource_name=tn,
                            evidence=self._evidence_with_ansible_targets(
                                file_path,
                                content,
                                0,
                                {"module": module_name, "task_name": task.get('name')},
                            ),
                            remediation=module_info["remediation"],
                            mitre_technique="T1059",
                            impact=(
                                "Shell-style modules run with the privileges of the Ansible user; injected variables or "
                                "host compromise can turn this into arbitrary command execution across inventory."
                            ),
                            detection_reason=(
                                f"YAML task dictionary contains key `{module_name}`, indicating this module drives the action "
                                "rather than a constrained idempotent module."
                            ),
                            risk_score=iac_severity_risk(sev),
                        ))
        except yaml.YAMLError:
            pass
        
        return findings
    
    def scan_dangerous_patterns(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan for dangerous configuration patterns."""
        findings = []
        
        for check_id, check_info in DANGEROUS_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE):
                line_num = self._get_line_number(content, match.start())
                sev = check_info["severity"]
                ctx = context_lines_for_match(content, line_num, radius=2)
                findings.append(IaCFinding(
                    tool=IaCTool.ANSIBLE,
                    category=IaCCheckCategory.PLAYBOOK_SECURITY,
                    severity=sev,
                    title=check_info["title"],
                    description=(
                        f"{check_info['description']} — matched in `{os.path.basename(file_path)}` line {line_num}."
                    ),
                    file_path=file_path,
                    line_number=line_num,
                    evidence=self._evidence_with_ansible_targets(
                        file_path,
                        content,
                        line_num,
                        {
                            "check_id": check_id,
                            "matched_text": match.group(0).strip(),
                            "context_lines": ctx,
                        },
                    ),
                    remediation=check_info["remediation"],
                    impact=(
                        "Misconfigured task logging or error handling can leak credentials into stdout, syslog, or CMDB exports, "
                        "or hide failures that leave hosts in an unsafe state."
                    ),
                    detection_reason=f"Playbook text matched Ansible configuration check `{check_id}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        return findings
    
    def scan_vault_security(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan vault-related security issues."""
        findings = []
        
        # Check for vault password files
        if 'vault_password_file' in file_path.lower():
            findings.append(IaCFinding(
                tool=IaCTool.ANSIBLE,
                category=IaCCheckCategory.VAULT_SECURITY,
                severity=IaCSeverity.HIGH,
                title="Vault Password File Found",
                description=(
                    f"Path `{os.path.basename(file_path)}` suggests a vault password file; if committed or world-readable, "
                    "all ciphertext vault blobs for the project can be decrypted."
                ),
                file_path=file_path,
                evidence=self._evidence_with_ansible_targets(file_path, content or "", 0, {}),
                remediation="Ensure file has 0600 permissions and is in .gitignore",
                compliance_mappings=[ComplianceFramework.SOC2],
                impact="Vault passphrase on disk under weak ACLs or in VCS enables offline decryption of every vaulted secret.",
                detection_reason="File path contains `vault_password_file`, a common Ansible vault passphrase location.",
                risk_score=iac_severity_risk(IaCSeverity.HIGH),
            ))
        
        # Check for weak vault encryption
        if content.strip().startswith('$ANSIBLE_VAULT;'):
            header = content.split('\n')[0]
            if ';AES' in header and ';AES256' not in header:
                findings.append(IaCFinding(
                    tool=IaCTool.ANSIBLE,
                    category=IaCCheckCategory.VAULT_SECURITY,
                    severity=IaCSeverity.MEDIUM,
                    title="Vault Using Weak Encryption",
                    description=f"Vault blob in `{os.path.basename(file_path)}` does not advertise AES256 in the header line.",
                    file_path=file_path,
                    evidence=self._evidence_with_ansible_targets(file_path, content or "", 1, {}),
                    remediation="Re-encrypt vault with ansible-vault rekey --new-vault-password-file",
                    compliance_mappings=[ComplianceFramework.PCI_DSS],
                    impact="Weaker vault ciphers reduce offline brute-force cost if ciphertext leaks.",
                    detection_reason="`$ANSIBLE_VAULT` header line lacks `AES256` marker while still indicating AES encryption.",
                    risk_score=iac_severity_risk(IaCSeverity.MEDIUM),
                ))
        
        return findings
    
    def scan_inventory(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan inventory for security issues."""
        findings = []
        
        # Check for credentials in inventory
        cred_patterns = [
            (r'ansible_ssh_pass(?:word)?[=:]\s*\S+', 'SSH Password'),
            (r'ansible_become_pass(?:word)?[=:]\s*\S+', 'Become Password'),
            (r'ansible_connection_password[=:]\s*\S+', 'Connection Password'),
        ]
        
        for pattern, cred_type in cred_patterns:
            for match in re.finditer(pattern, content, re.IGNORECASE):
                matched_text = match.group()
                
                # Skip variable references
                if '{{' in matched_text:
                    continue
                
                line_num = self._get_line_number(content, match.start())
                ctx = context_lines_for_match(content, line_num, radius=3)
                redacted = redact_secret_matched_text(matched_text)
                findings.append(IaCFinding(
                    tool=IaCTool.ANSIBLE,
                    category=IaCCheckCategory.INVENTORY_SECURITY,
                    severity=IaCSeverity.HIGH,
                    title=f"Credentials in Inventory: {cred_type}",
                    description=(
                        f"{cred_type} stored as plaintext in `{os.path.basename(file_path)}` line {line_num}; "
                        "inventory is often copied to jump hosts and CI workers."
                    ),
                    file_path=file_path,
                    line_number=line_num,
                    evidence=self._evidence_with_ansible_targets(
                        file_path,
                        content,
                        line_num,
                        {
                            "cred_type": cred_type,
                            "matched_text": redacted,
                            "context_lines": ctx,
                        },
                    ),
                    remediation="Use SSH keys and vault for credentials",
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2],
                    impact="Inventory credentials grant direct access to managed hosts; leakage equals lateral movement material.",
                    detection_reason=(
                        f"Inventory line matched `{cred_type}` credential assignment with a literal value (not a vault reference)."
                    ),
                    risk_score=iac_severity_risk(IaCSeverity.HIGH),
                ))
        
        return findings
    
    async def scan(self, directory: str) -> List[IaCFinding]:
        """
        Scan directory for Ansible security issues.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        all_findings = []
        
        files = self._find_ansible_files(directory)
        
        # Scan playbooks
        for file_path in files["playbooks"][:50]:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_for_secrets(file_path, content))
            all_findings.extend(self.scan_unsafe_modules(file_path, content))
            all_findings.extend(self.scan_dangerous_patterns(file_path, content))
        
        # Scan vars files
        for file_path in files["vars"][:50]:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_for_secrets(file_path, content))
        
        # Scan inventory
        for file_path in files["inventory"][:20]:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_inventory(file_path, content))
        
        # Scan vault files
        for file_path in files["vault"][:20]:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_vault_security(file_path, content))
        
        # Scan roles
        for file_path in files["roles"][:50]:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_for_secrets(file_path, content))
            all_findings.extend(self.scan_unsafe_modules(file_path, content))
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[IaCFinding]:
        """Get all findings."""
        return self.findings

