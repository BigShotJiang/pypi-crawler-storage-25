"""
CloudFormation Security Scanner

Security assessment for AWS CloudFormation:
- Template security (injection, NoEcho, metadata)
- IAM security (wildcard policies, boundaries)
- Resource security (encryption, public access)
- Parameter security (default values, constraints)

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1078: Valid Accounts
- T1190: Exploit Public-Facing Application
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from ...proto import (
    IaCFinding, IaCTool, IaCSeverity, IaCCheckCategory,
    CLOUDFORMATION_SECURITY_RULES, ComplianceFramework
)
from ..utils.iac_evidence_utils import context_lines_for_match, iac_severity_risk, redact_secret_matched_text

logger = logging.getLogger(__name__)


# =============================================================================
# CloudFormation Security Patterns
# =============================================================================

CFN_SECRET_PATTERNS = {
    "hardcoded_password": r'(?:Password|Secret|Token|ApiKey):\s*["\']?(?!.*\{\{|\!Ref|\!GetAtt)[A-Za-z0-9@#$%^&*]{8,}["\']?',
    "aws_access_key": r'AKIA[0-9A-Z]{16}',
    "aws_secret_key": r'(?:SecretAccessKey|aws_secret_access_key):\s*["\']?[A-Za-z0-9/+=]{40}["\']?',
}

CFN_IAM_PATTERNS = {
    "wildcard_action": {
        "pattern": r'Action:\s*(?:\[?\s*)?["\']?\*["\']?',
        "severity": IaCSeverity.HIGH,
        "title": "IAM Policy with Wildcard Action",
        "description": "IAM policy allows all actions (*)",
        "remediation": "Specify explicit actions following least privilege",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.NIST_800_53],
    },
    "wildcard_resource": {
        "pattern": r'Resource:\s*(?:\[?\s*)?["\']?\*["\']?',
        "severity": IaCSeverity.HIGH,
        "title": "IAM Policy with Wildcard Resource",
        "description": "IAM policy allows all resources (*)",
        "remediation": "Specify explicit resource ARNs",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.NIST_800_53],
    },
    "admin_policy": {
        "pattern": r'ManagedPolicyArns:[\s\S]*?arn:aws:iam::aws:policy/AdministratorAccess',
        "severity": IaCSeverity.CRITICAL,
        "title": "AdministratorAccess Policy Attached",
        "description": "Role has AdministratorAccess managed policy",
        "remediation": "Use custom policy with minimal required permissions",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
    "pass_role_star": {
        "pattern": r'Action:[\s\S]*?iam:PassRole[\s\S]*?Resource:\s*["\']?\*',
        "severity": IaCSeverity.HIGH,
        "title": "PassRole on All Roles",
        "description": "iam:PassRole allowed on all roles",
        "remediation": "Restrict PassRole to specific role ARNs",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
}

CFN_RESOURCE_PATTERNS = {
    # Security Groups
    "open_security_group": {
        "pattern": r'CidrIp:\s*["\']?0\.0\.0\.0/0["\']?',
        "severity": IaCSeverity.HIGH,
        "title": "Security Group Open to Internet",
        "description": "Security group allows ingress from 0.0.0.0/0",
        "remediation": "Restrict CIDR blocks to specific IP ranges",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS],
    },
    "open_security_group_v6": {
        "pattern": r'CidrIpv6:\s*["\']?::/0["\']?',
        "severity": IaCSeverity.HIGH,
        "title": "Security Group Open to Internet (IPv6)",
        "description": "Security group allows ingress from ::/0",
        "remediation": "Restrict IPv6 CIDR blocks",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
    
    # S3
    "s3_public_read": {
        "pattern": r'AccessControl:\s*["\']?(?:PublicRead|PublicReadWrite)["\']?',
        "severity": IaCSeverity.HIGH,
        "title": "S3 Bucket with Public Access",
        "description": "S3 bucket configured with public access control",
        "remediation": "Use Private access control and bucket policies",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.HIPAA],
    },
    
    # RDS
    "rds_public": {
        "pattern": r'PubliclyAccessible:\s*(?:true|["\']?true["\']?)',
        "severity": IaCSeverity.CRITICAL,
        "title": "RDS Instance Publicly Accessible",
        "description": "RDS instance configured as publicly accessible",
        "remediation": "Set PubliclyAccessible: false",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS],
    },
    "rds_no_encryption": {
        "pattern": r'Type:\s*["\']?AWS::RDS::DBInstance["\']?(?![\s\S]*?StorageEncrypted:\s*true)',
        "severity": IaCSeverity.HIGH,
        "title": "RDS Instance Without Encryption",
        "description": "RDS instance without storage encryption",
        "remediation": "Enable StorageEncrypted: true",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS, ComplianceFramework.HIPAA],
    },
    
    # EC2
    "ec2_imdsv1": {
        "pattern": r'HttpTokens:\s*["\']?optional["\']?',
        "severity": IaCSeverity.MEDIUM,
        "title": "EC2 Instance with IMDSv1",
        "description": "EC2 instance allows IMDSv1",
        "remediation": "Set HttpTokens: required",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
}

CFN_PARAMETER_PATTERNS = {
    "password_default": {
        "pattern": r'Parameters:[\s\S]*?(?:Password|Secret)[\s\S]*?Default:\s*["\']?[^"\'\n]+["\']?',
        "severity": IaCSeverity.MEDIUM,
        "title": "Password Parameter with Default",
        "description": "Sensitive parameter has default value",
        "remediation": "Remove default values from sensitive parameters",
        "compliance": [ComplianceFramework.SOC2],
    },
    "no_echo_missing": {
        "pattern": r'Parameters:[\s\S]*?(?:Password|Secret|Token|Key)[\s\S]*?Type:\s*String(?![\s\S]*?NoEcho:\s*true)',
        "severity": IaCSeverity.HIGH,
        "title": "Sensitive Parameter Without NoEcho",
        "description": "Parameter with sensitive name missing NoEcho: true",
        "remediation": "Add NoEcho: true to sensitive parameters",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.SOC2],
    },
}


class CloudFormationScanner:
    """CloudFormation security scanner."""
    
    def __init__(self):
        self.findings: List[IaCFinding] = []
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            logger.debug(f"Failed to read {path}: {e}")
            return None

    def _is_noise_path(self, path: str) -> bool:
        """Skip vendor/system/documentation paths that are not user IaC."""
        norm = os.path.abspath(path).lower()
        noise_substrings = (
            "/site-packages/",
            "/dist-packages/",
            "/node_modules/",
            "/vendor/",
            "/.venv/",
            "/venv/",
            "/snap/",
            "/share/doc/",
            "/documentation/",
            "/docs/",
            "/examples/",
            "/test/",
            "/tests/",
            "/fixtures/",
            "/__pycache__/",
            "/botocore/data/",
        )
        if any(part in norm for part in noise_substrings):
            return True
        return norm.endswith(("/service-2.json", "/rest-api.yaml"))
    
    def _find_cfn_files(self, directory: str) -> List[str]:
        """Find CloudFormation template files."""
        cfn_files = []

        try:
            abs_dir = os.path.abspath(directory)
        except Exception:
            abs_dir = directory
        system_excludes = set()
        if abs_dir == "/":
            system_excludes = {
                "proc",
                "sys",
                "dev",
                "run",
                "snap",
                "usr",
                "lib",
                "lib64",
                "bin",
                "sbin",
                "boot",
                "var",
                "tmp",
                "mnt",
                "media",
            }
        
        for root, dirs, files in os.walk(directory):
            dirs[:] = [
                d for d in dirs if not d.startswith('.') and d not in [
                    'node_modules', 'vendor', '.aws-sam', '.venv', 'venv', '__pycache__',
                ] and d not in system_excludes
            ]
            
            for filename in files:
                # YAML/JSON templates
                if filename.endswith(('.yaml', '.yml', '.json', '.template')):
                    full_path = os.path.join(root, filename)
                    if self._is_noise_path(full_path):
                        continue
                    
                    # Quick check if it looks like CFN
                    content = self._read_file(full_path)
                    if content and ('AWSTemplateFormatVersion' in content or 
                                   'Resources:' in content or
                                   '"Resources"' in content):
                        cfn_files.append(full_path)
        
        return cfn_files[:100]  # Limit
    
    def _get_line_number(self, content: str, match_start: int) -> int:
        """Get line number from match position."""
        return content[:match_start].count('\n') + 1
    
    def _extract_parameter_info(self, content: str, param_name: str) -> Dict[str, Any]:
        """Extract parameter information from template."""
        # Try to find parameter definition
        param_pattern = rf'Parameters:[\s\S]*?{re.escape(param_name)}:[\s\S]*?(?=\n\s+\w+:|$)'
        match = re.search(param_pattern, content, re.IGNORECASE | re.MULTILINE)
        if match:
            param_block = match.group(0)
            return {
                "parameter_block": param_block[:500],  # Limit size
                "has_default": "Default:" in param_block,
                "has_noecho": "NoEcho:" in param_block and "true" in param_block.lower(),
            }
        return {}
    
    def _parse_template(self, content: str) -> Optional[Dict]:
        """Parse CloudFormation template."""
        # Try YAML first
        if YAML_AVAILABLE:
            try:
                return yaml.safe_load(content)
            except yaml.YAMLError:
                pass
        
        # Try JSON
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            pass
        
        return None
    
    def scan_for_secrets(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan for hardcoded secrets."""
        findings = []
        
        for secret_type, pattern in CFN_SECRET_PATTERNS.items():
            for match in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                matched_text = match.group()
                
                # Skip intrinsic functions
                if any(f in matched_text for f in ['!Ref', '!GetAtt', '!Sub', 'Fn::', '{{resolve:']):
                    continue
                
                line_num = self._get_line_number(content, match.start())
                context_lines = context_lines_for_match(content, line_num, radius=5)
                matched_redacted = redact_secret_matched_text(matched_text)
                
                # Mask sensitive value for evidence (show first/last few chars)
                masked_value = matched_text
                if len(matched_text) > 20:
                    masked_value = matched_text[:8] + "..." + matched_text[-4:]
                
                enhanced_description = (
                    f"Found potential hardcoded {secret_type.replace('_', ' ')} in CloudFormation template. "
                    f"Hardcoded credentials are stored in plaintext in version control and template files, making them accessible to: "
                    f"(1) anyone with repository access, (2) developers with file system access, (3) attackers who compromise the repository or CI/CD pipeline. "
                    f"This enables credential theft (MITRE T1552) and unauthorized access to AWS resources. "
                    f"Hardcoded credentials cannot be rotated without code changes and may be exposed in stack events or logs."
                )
                
                evidence = {
                    "pattern": secret_type,
                    "matched_text": matched_redacted,
                    "matched_text_preview": masked_value,
                    "context_lines": context_lines,
                    "line_number": line_num,
                }
                
                findings.append(IaCFinding(
                    tool=IaCTool.CLOUDFORMATION,
                    category=IaCCheckCategory.HARDCODED_CREDENTIALS,
                    severity=IaCSeverity.CRITICAL,
                    title=f"Hardcoded {secret_type.replace('_', ' ').title()}",
                    description=enhanced_description,
                    file_path=file_path,
                    line_number=line_num,
                    evidence=evidence,
                    remediation="Use AWS Secrets Manager, SSM Parameter Store, or dynamic references (e.g., {{resolve:secretsmanager:...}}) instead of hardcoded values.",
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2, ComplianceFramework.PCI_DSS],
                    impact=(
                        f"Template `{os.path.basename(file_path)}` embeds `{secret_type}` material; stack exports and git forks multiply exposure."
                    ),
                    detection_reason=f"CloudFormation template matched static secret pattern `{secret_type}` (no Ref/GetAtt/dynamic resolve).",
                    risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                ))
        
        return findings
    
    def scan_iam_policies(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan IAM policy configurations."""
        findings = []
        
        for check_id, check_info in CFN_IAM_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                line_num = self._get_line_number(content, match.start())
                matched_text = match.group(0)[:300]  # Limit size
                context_lines = context_lines_for_match(content, line_num, radius=5)
                
                # Enhanced descriptions with attack scenarios
                enhanced_description = check_info["description"]
                if check_id == "wildcard_action":
                    enhanced_description = (
                        f"IAM policy allows all actions (*). This grants excessive permissions, enabling attackers who compromise "
                        f"the role to perform any AWS action, including: (1) creating/deleting resources, (2) accessing all S3 buckets, "
                        f"(3) modifying IAM policies, (4) accessing secrets in Secrets Manager, (5) exfiltrating data. "
                        f"This violates least privilege and enables privilege escalation (MITRE T1078)."
                    )
                elif check_id == "wildcard_resource":
                    enhanced_description = (
                        f"IAM policy allows all resources (*). This grants access to all resources of the specified type, enabling "
                        f"attackers to: (1) access any S3 bucket, (2) read from any Secrets Manager secret, (3) modify any resource, "
                        f"(4) perform cross-account data exfiltration. This violates least privilege and enables unauthorized access."
                    )
                elif check_id == "admin_policy":
                    enhanced_description = (
                        f"Role has AdministratorAccess managed policy attached. This grants full AWS account access, enabling attackers "
                        f"who compromise the role to: (1) create/delete any resource, (2) modify IAM policies and users, (3) access all data, "
                        f"(4) disable security controls, (5) create backdoors. This is a critical security risk (MITRE T1078)."
                    )
                
                evidence = {
                    "check_id": check_id,
                    "matched_text": matched_text,
                    "context_lines": context_lines,
                    "line_number": line_num,
                }
                
                sev = check_info["severity"]
                findings.append(IaCFinding(
                    tool=IaCTool.CLOUDFORMATION,
                    category=IaCCheckCategory.IAM_SECURITY,
                    severity=sev,
                    title=check_info["title"],
                    description=enhanced_description,
                    file_path=file_path,
                    line_number=line_num,
                    evidence=evidence,
                    remediation=check_info["remediation"],
                    mitre_technique="T1078",
                    compliance_mappings=check_info.get("compliance", []),
                    impact="Overly broad IAM in templates becomes live account permissions after stack deploy—direct path to privilege escalation and data exfiltration.",
                    detection_reason=f"CloudFormation IAM scanner matched rule `{check_id}` in this template.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        return findings
    
    def scan_resources(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan resource configurations."""
        findings = []
        
        for check_id, check_info in CFN_RESOURCE_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                line_num = self._get_line_number(content, match.start())
                matched_text = match.group(0)[:300]
                context_lines = context_lines_for_match(content, line_num, radius=5)
                
                # Enhanced descriptions with attack scenarios
                enhanced_description = check_info["description"]
                if check_id == "open_security_group" or check_id == "open_security_group_v6":
                    enhanced_description = (
                        f"Security group allows ingress from {('0.0.0.0/0' if check_id == 'open_security_group' else '::/0')}. "
                        f"This exposes the service to the entire internet, enabling attackers to: (1) scan for vulnerabilities, "
                        f"(2) attempt brute force attacks, (3) exploit known vulnerabilities, (4) perform DDoS attacks. "
                        f"Public exposure significantly increases the attack surface and risk of compromise (MITRE T1190)."
                    )
                elif check_id == "s3_public_read":
                    enhanced_description = (
                        f"S3 bucket configured with public access control. This allows anyone on the internet to read bucket contents, "
                        f"enabling attackers to: (1) enumerate bucket contents, (2) download sensitive data, (3) identify internal resources, "
                        f"(4) access credentials or configuration files. Public S3 buckets are a common source of data breaches."
                    )
                elif check_id == "rds_public":
                    enhanced_description = (
                        f"RDS instance configured as publicly accessible. This exposes the database to the internet, enabling attackers to: "
                        f"(1) attempt SQL injection, (2) brute force database credentials, (3) exploit database vulnerabilities, "
                        f"(4) exfiltrate data. Public databases are a critical security risk and should only be used when absolutely necessary."
                    )
                elif check_id == "rds_no_encryption":
                    enhanced_description = (
                        f"RDS instance without storage encryption. Unencrypted data at rest can be accessed by: (1) attackers who compromise "
                        f"the underlying storage, (2) AWS employees with storage access, (3) anyone who gains access to database snapshots. "
                        f"Encryption protects data even if storage is compromised."
                    )
                
                evidence = {
                    "check_id": check_id,
                    "matched_text": matched_text,
                    "context_lines": context_lines,
                    "line_number": line_num,
                }
                
                sev = check_info["severity"]
                findings.append(IaCFinding(
                    tool=IaCTool.CLOUDFORMATION,
                    category=IaCCheckCategory.RESOURCE_SECURITY,
                    severity=sev,
                    title=check_info["title"],
                    description=enhanced_description,
                    file_path=file_path,
                    line_number=line_num,
                    evidence=evidence,
                    remediation=check_info["remediation"],
                    mitre_technique="T1190",
                    compliance_mappings=check_info.get("compliance", []),
                    impact="Resource misconfigurations in CFN (public SG, public RDS, public S3) are replayed reliably every deployment until fixed.",
                    detection_reason=f"CloudFormation resource scanner matched rule `{check_id}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        return findings
    
    def scan_parameters(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan parameter configurations."""
        findings = []
        
        for check_id, check_info in CFN_PARAMETER_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                line_num = self._get_line_number(content, match.start())
                matched_text = match.group(0)[:200]  # Limit matched text size
                context_lines = context_lines_for_match(content, line_num, radius=5)
                
                # Build enhanced description with risk explanation
                enhanced_description = check_info["description"]
                if check_id == "no_echo_missing":
                    enhanced_description = (
                        f"Parameter with sensitive name missing NoEcho: true. "
                        f"Without NoEcho, parameter values are visible in CloudFormation console, CLI output, and API responses. "
                        f"Attackers with read access to CloudFormation stacks can extract sensitive credentials (passwords, API keys, tokens) "
                        f"by querying stack parameters or viewing stack events. This enables credential theft (MITRE T1552) and privilege escalation."
                    )
                elif check_id == "password_default":
                    enhanced_description = (
                        f"Sensitive parameter has default value. Default values are stored in plaintext in templates and version control. "
                        f"Attackers with access to repository or template files can extract hardcoded credentials. "
                        f"Additionally, default values may be used in production if parameters are not explicitly provided during stack creation, "
                        f"creating a persistent security risk."
                    )
                
                # Enhanced evidence with actual code and context
                evidence = {
                    "check_id": check_id,
                    "matched_text": matched_text,
                    "context_lines": context_lines,
                    "line_number": line_num,
                }
                
                sev = check_info["severity"]
                findings.append(IaCFinding(
                    tool=IaCTool.CLOUDFORMATION,
                    category=IaCCheckCategory.PARAMETER_SECURITY,
                    severity=sev,
                    title=check_info["title"],
                    description=enhanced_description,
                    file_path=file_path,
                    line_number=line_num,
                    evidence=evidence,
                    remediation=check_info["remediation"],
                    mitre_technique="T1552",
                    compliance_mappings=check_info.get("compliance", []),
                    impact="Parameter handling mistakes expose secrets in CloudFormation API responses, console views, and stack events.",
                    detection_reason=f"CloudFormation parameter scanner matched rule `{check_id}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        return findings
    
    def scan_template_structure(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan template structure for security issues."""
        findings = []
        
        template = self._parse_template(content)
        if not template:
            return findings
        
        # Missing Metadata is documentation/ops hygiene, not a security finding (THREAT_QUALITY_ANALYSIS §8).

        # Check parameters
        parameters = template.get('Parameters', {})
        for param_name, param_config in parameters.items() if isinstance(parameters, dict) else []:
            if isinstance(param_config, dict):
                # Check NoEcho for sensitive params
                if any(s in param_name.lower() for s in ['password', 'secret', 'token', 'key', 'credential']):
                    if not param_config.get('NoEcho'):
                        # Find parameter definition in content for context
                        param_info = self._extract_parameter_info(content, param_name)
                        line_num = 0
                        param_match = re.search(rf'^\s*{re.escape(param_name)}:', content, re.MULTILINE)
                        if param_match:
                            line_num = self._get_line_number(content, param_match.start())
                        
                        context_lines = (
                            context_lines_for_match(content, line_num, radius=5) if line_num > 0 else []
                        )
                        matched_text = ""
                        if line_num > 0:
                            lines = content.splitlines()
                            li = line_num - 1
                            if 0 <= li < len(lines):
                                matched_text = redact_secret_matched_text(lines[li])
                        
                        enhanced_description = (
                            f"Parameter '{param_name}' is marked as sensitive (contains 'password', 'secret', 'token', 'key', or 'credential' in name) "
                            f"but is missing NoEcho: true. Without NoEcho, the parameter value is visible in: "
                            f"(1) AWS CloudFormation Console when viewing stack parameters, "
                            f"(2) AWS CLI output when describing stacks or parameters, "
                            f"(3) CloudFormation API responses, and "
                            f"(4) CloudFormation stack events. "
                            f"Attackers with read-only IAM permissions (e.g., cloudformation:DescribeStacks, cloudformation:DescribeStackEvents) "
                            f"can extract sensitive credentials. This enables credential theft (MITRE T1552) and subsequent privilege escalation."
                        )
                        
                        evidence = {
                            "check_id": "cfn_template_param_no_echo",
                            "parameter_name": param_name,
                            "parameter_config": {k: v for k, v in param_config.items() if k != 'Default'},  # Exclude default value from evidence
                            "has_default": param_config.get('Default') is not None,
                            "matched_text": matched_text or f"Parameter {param_name}: NoEcho not set",
                            "context_lines": context_lines,
                            "line_number": line_num,
                        }
                        if param_info.get("parameter_block"):
                            evidence["parameter_block"] = param_info["parameter_block"]
                        
                        findings.append(IaCFinding(
                            tool=IaCTool.CLOUDFORMATION,
                            category=IaCCheckCategory.PARAMETER_SECURITY,
                            severity=IaCSeverity.HIGH,
                            title=f"Sensitive Parameter Without NoEcho: {param_name}",
                            description=enhanced_description,
                            file_path=file_path,
                            line_number=line_num,
                            resource_name=param_name,
                            resource_type="Parameter",
                            evidence=evidence,
                            remediation="Add NoEcho: true to the parameter definition to prevent value exposure in console, CLI, and API responses.",
                            mitre_technique="T1552",
                            compliance_mappings=[ComplianceFramework.CIS_AWS],
                            impact=(
                                f"Parameter `{param_name}` will surface cleartext in DescribeStacks/Console to any principal "
                                "with read access to the stack unless NoEcho is enabled."
                            ),
                            detection_reason=(
                                "Parsed CloudFormation template: parameter name matches sensitive heuristics and `NoEcho` is absent/false."
                            ),
                            risk_score=iac_severity_risk(IaCSeverity.HIGH),
                        ))
        
        return findings
    
    async def scan(self, directory: str) -> List[IaCFinding]:
        """
        Scan directory for CloudFormation security issues.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        all_findings = []
        
        cfn_files = self._find_cfn_files(directory)
        
        for file_path in cfn_files:
            content = self._read_file(file_path)
            if not content:
                continue
            
            all_findings.extend(self.scan_for_secrets(file_path, content))
            all_findings.extend(self.scan_iam_policies(file_path, content))
            all_findings.extend(self.scan_resources(file_path, content))
            all_findings.extend(self.scan_parameters(file_path, content))
            all_findings.extend(self.scan_template_structure(file_path, content))
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[IaCFinding]:
        """Get all findings."""
        return self.findings

