"""
Terraform Security Scanner

Security assessment for Terraform configurations:
- State file security (encryption, remote storage)
- Provider security (credentials, version pinning)
- Resource security (security groups, S3, IAM)
- Module security (trusted sources, version pinning)

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1078: Valid Accounts
- T1190: Exploit Public-Facing Application
"""

import copy
import os
import re
import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

try:
    import hcl2
    HCL2_AVAILABLE = True
except ImportError:
    HCL2_AVAILABLE = False

from ...proto import (
    IaCFinding, IaCTool, IaCSeverity, IaCCheckCategory,
    TERRAFORM_SECURITY_RULES, ComplianceFramework, ExploitationCommands
)
from ..utils.iac_evidence_utils import (
    context_lines_for_match,
    iac_severity_risk,
    redact_secret_matched_text,
)

logger = logging.getLogger(__name__)


# 🔴 IAC EXPLOITATION COMMANDS by category
IAC_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    "state_security": {
        "commands": [
            "$ cat terraform.tfstate | jq '.resources[].instances[].attributes | select(.password != null or .secret != null)'",
            "$ grep -r 'password\\|secret\\|api_key' terraform.tfstate",
            "$ aws s3 cp s3://bucket/terraform.tfstate ."
        ],
        "description": "Extract secrets from Terraform state"
    },
    "secrets_exposure": {
        "commands": [
            "$ grep -rn 'AKIA\\|password\\|secret_key' *.tf",
            "$ trufflehog filesystem --directory .",
            "$ git log -p | grep -i password"
        ],
        "description": "Find hardcoded secrets in IaC"
    },
    "resource_security": {
        "commands": [
            "$ tfsec .",
            "$ checkov -d .",
            "$ terraform plan | grep -i 'cidr_blocks.*0.0.0.0'"
        ],
        "description": "Scan for insecure resource configurations"
    },
    "provider_security": {
        "commands": [
            "$ grep -r 'access_key\\|secret_key' providers.tf",
            "$ env | grep -i 'AWS_\\|AZURE_\\|GOOGLE_'",
            "$ cat ~/.aws/credentials"
        ],
        "description": "Check provider credential exposure"
    },
    "iam_security": {
        "commands": [
            "$ grep -rn '\"\\*\"' *.tf | grep -i 'action\\|resource'",
            "$ terraform plan -out=plan.out && terraform show -json plan.out | jq '.resource_changes[] | select(.type==\"aws_iam_policy\")'",
            "$ aws iam simulate-custom-policy --policy-input-list file://policy.json --action-names '*'"
        ],
        "description": "Analyze IAM policy misconfigurations"
    },
    "default": {
        "commands": [
            "$ tfsec .",
            "$ checkov -d .",
            "$ terrascan scan"
        ],
        "description": "IaC security scan"
    }
}

_IAC_CATEGORY_TEMPLATE_SOURCE = {
    "module_security": "resource_security",
    "playbook_security": "resource_security",
    "vault_security": "secrets_exposure",
    "inventory_security": "secrets_exposure",
    "task_security": "resource_security",
    "stack_security": "state_security",
    "secret_management": "secrets_exposure",
    "template_security": "resource_security",
    "parameter_security": "secrets_exposure",
    "hardcoded_credentials": "secrets_exposure",
    "insecure_defaults": "resource_security",
    "misconfigurations": "resource_security",
    "compliance": "default",
}


def _expand_iac_exploitation_commands() -> None:
    for member in IaCCheckCategory:
        key = member.value
        if key in IAC_EXPLOITATION_COMMANDS:
            continue
        src = _IAC_CATEGORY_TEMPLATE_SOURCE.get(key, "default")
        if src not in IAC_EXPLOITATION_COMMANDS:
            src = "default"
        IAC_EXPLOITATION_COMMANDS[key] = copy.deepcopy(IAC_EXPLOITATION_COMMANDS[src])


_expand_iac_exploitation_commands()


def build_iac_commands(category: IaCCheckCategory) -> ExploitationCommands:
    """Build exploitation commands based on finding category."""
    cat_str = category.value if hasattr(category, 'value') else str(category)
    cmd_template = IAC_EXPLOITATION_COMMANDS.get(cat_str, IAC_EXPLOITATION_COMMANDS["default"])
    
    return ExploitationCommands(
        server="terraform",
        ip=None,
        commands=cmd_template.get("commands", []),
        description=cmd_template.get("description", f"IaC exploitation via {cat_str}")
    )


# =============================================================================
# Terraform Security Patterns
# =============================================================================

TERRAFORM_SECRET_PATTERNS = {
    "aws_access_key": r'AKIA[0-9A-Z]{16}',
    "aws_secret_key": r'(?:aws_secret_access_key|secret_key)\s*=\s*["\'][A-Za-z0-9/+=]{40}["\']',
    "azure_client_secret": r'client_secret\s*=\s*["\'][A-Za-z0-9~._-]{34,}["\']',
    "gcp_private_key": r'-----BEGIN (RSA )?PRIVATE KEY-----',
    "generic_password": r'(?:password|passwd|pwd)\s*=\s*["\'][^"\']+["\']',
    "generic_token": r'(?:token|api_key|apikey)\s*=\s*["\'][A-Za-z0-9_-]{20,}["\']',
    "private_key": r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
}

INSECURE_RESOURCE_PATTERNS = {
    # Security Groups
    "open_ingress": {
        "pattern": r'ingress\s*\{[^}]*cidr_blocks\s*=\s*\[\s*["\']0\.0\.0\.0/0["\']',
        "severity": IaCSeverity.HIGH,
        "title": "Security Group Open to Internet",
        "remediation": "Restrict CIDR blocks to specific IP ranges",
    },
    "open_egress_all": {
        "pattern": r'egress\s*\{[^}]*cidr_blocks\s*=\s*\[\s*["\']0\.0\.0\.0/0["\'][^}]*from_port\s*=\s*0[^}]*to_port\s*=\s*0',
        "severity": IaCSeverity.MEDIUM,
        "title": "Security Group Allows All Egress",
        "remediation": "Restrict egress to required ports and destinations",
    },
    
    # S3
    "s3_public_acl": {
        "pattern": r'acl\s*=\s*["\'](?:public-read|public-read-write)["\']',
        "severity": IaCSeverity.HIGH,
        "title": "S3 Bucket with Public ACL",
        "remediation": "Use private ACL and bucket policies",
    },
    "s3_no_encryption": {
        "pattern": r'resource\s+["\']aws_s3_bucket["\']\s+["\'][^"\']+["\']\s*\{(?!.*server_side_encryption)',
        "severity": IaCSeverity.HIGH,
        "title": "S3 Bucket Without Encryption",
        "remediation": "Enable server-side encryption with KMS",
    },
    "s3_no_versioning": {
        "pattern": r'resource\s+["\']aws_s3_bucket["\']\s+["\'][^"\']+["\']\s*\{(?!.*versioning)',
        "severity": IaCSeverity.MEDIUM,
        "title": "S3 Bucket Without Versioning",
        "remediation": "Enable versioning for data protection",
    },
    
    # IAM
    "iam_wildcard_action": {
        "pattern": r'actions?\s*=\s*\[\s*["\']?\*["\']?\s*\]',
        "severity": IaCSeverity.HIGH,
        "title": "IAM Policy with Wildcard Actions",
        "remediation": "Specify explicit actions following least privilege",
    },
    "iam_wildcard_resource": {
        "pattern": r'resources?\s*=\s*\[\s*["\']?\*["\']?\s*\]',
        "severity": IaCSeverity.HIGH,
        "title": "IAM Policy with Wildcard Resources",
        "remediation": "Specify explicit resource ARNs",
    },
    
    # RDS
    "rds_public": {
        "pattern": r'publicly_accessible\s*=\s*true',
        "severity": IaCSeverity.CRITICAL,
        "title": "RDS Instance Publicly Accessible",
        "remediation": "Set publicly_accessible = false",
    },
    "rds_no_encryption": {
        "pattern": r'resource\s+["\']aws_db_instance["\']\s+["\'][^"\']+["\']\s*\{(?!.*storage_encrypted\s*=\s*true)',
        "severity": IaCSeverity.HIGH,
        "title": "RDS Instance Without Encryption",
        "remediation": "Enable storage_encrypted = true",
    },
    
    # EC2
    "ec2_imds_v1": {
        "pattern": r'http_tokens\s*=\s*["\']optional["\']',
        "severity": IaCSeverity.MEDIUM,
        "title": "EC2 Instance with IMDSv1 Enabled",
        "remediation": "Set http_tokens = required for IMDSv2",
    },
    
    # EBS
    "ebs_no_encryption": {
        "pattern": r'resource\s+["\']aws_ebs_volume["\']\s+["\'][^"\']+["\']\s*\{(?!.*encrypted\s*=\s*true)',
        "severity": IaCSeverity.HIGH,
        "title": "EBS Volume Without Encryption",
        "remediation": "Enable encrypted = true",
    },
}

BACKEND_PATTERNS = {
    "s3_no_encrypt": {
        "pattern": r'backend\s+["\']s3["\']\s*\{(?!.*encrypt\s*=\s*true)',
        "severity": IaCSeverity.HIGH,
        "title": "S3 Backend Without Encryption",
        "remediation": "Add encrypt = true to backend config",
    },
    "local_backend": {
        "pattern": r'backend\s+["\']local["\']',
        "severity": IaCSeverity.MEDIUM,
        "title": "Local Backend Used",
        "remediation": "Use remote backend for team collaboration and state security",
    },
}


class TerraformScanner:
    """Terraform security scanner."""
    
    def __init__(self):
        self.findings: List[IaCFinding] = []
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            logger.debug(f"Failed to read {path}: {e}")
            return None
    
    def _find_terraform_files(self, directory: str) -> List[str]:
        """Find all Terraform files in directory."""
        tf_files = []
        
        for root, dirs, files in os.walk(directory):
            # Skip hidden and vendor directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in [
                'vendor', 'node_modules', '.terraform'
            ]]
            
            for file in files:
                if file.endswith('.tf') or file.endswith('.tf.json'):
                    tf_files.append(os.path.join(root, file))
                elif file == 'terraform.tfstate' or file.endswith('.tfstate'):
                    tf_files.append(os.path.join(root, file))
                elif file == 'terraform.tfvars' or file.endswith('.tfvars'):
                    tf_files.append(os.path.join(root, file))
        
        return tf_files[:200]  # Limit
    
    def _get_line_number(self, content: str, match_start: int) -> int:
        """Get line number from match position."""
        return content[:match_start].count('\n') + 1
    
    def scan_for_secrets(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan file for hardcoded secrets."""
        findings = []
        
        for secret_type, pattern in TERRAFORM_SECRET_PATTERNS.items():
            try:
                for match in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                    line_num = self._get_line_number(content, match.start())
                    raw_m = match.group()
                    ctx = context_lines_for_match(content, line_num, radius=3)
                    redacted = redact_secret_matched_text(raw_m)
                    findings.append(IaCFinding(
                        tool=IaCTool.TERRAFORM,
                        category=IaCCheckCategory.HARDCODED_CREDENTIALS,
                        severity=IaCSeverity.CRITICAL,
                        title=f"Hardcoded {secret_type.replace('_', ' ').title()}",
                        description=(
                            f"Literal `{secret_type}` material in `{os.path.basename(file_path)}` line {line_num}; "
                            "Terraform sources and state backups often replicate these values across machines."
                        ),
                        file_path=file_path,
                        line_number=line_num,
                        evidence={
                            "pattern": secret_type,
                            "matched_text": redacted,
                            "context_lines": ctx,
                        },
                        remediation="Use environment variables, vault, or external secrets management",
                        mitre_technique="T1552",
                        compliance_mappings=[ComplianceFramework.SOC2, ComplianceFramework.PCI_DSS],
                        impact=(
                            f"Hardcoded `{secret_type}` in HCL can leak via git, shared modules, and `.tfstate` copies, "
                            "giving attackers long-lived cloud or SSH access."
                        ),
                        detection_reason=f"Terraform static scan matched built-in `{secret_type}` secret pattern in `.tf`/`.tfvars` text.",
                        risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                        commands=build_iac_commands(IaCCheckCategory.SECRETS_EXPOSURE),
                    ))
            except re.error:
                pass
        
        return findings
    
    def scan_for_insecure_resources(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan for insecure resource configurations."""
        findings = []
        
        for check_id, check_info in INSECURE_RESOURCE_PATTERNS.items():
            try:
                for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                    line_num = self._get_line_number(content, match.start())
                    snippet = (match.group(0) or "")[:400]
                    ctx = context_lines_for_match(content, line_num, radius=3)
                    sev = check_info["severity"]
                    findings.append(IaCFinding(
                        tool=IaCTool.TERRAFORM,
                        category=IaCCheckCategory.RESOURCE_SECURITY,
                        severity=sev,
                        title=check_info["title"],
                        description=(
                            f"{check_info['title']} in `{os.path.basename(file_path)}` near line {line_num}; "
                            "misconfiguration may be applied cluster-wide on the next `terraform apply`."
                        ),
                        file_path=file_path,
                        line_number=line_num,
                        evidence={
                            "check_id": check_id,
                            "matched_text": snippet,
                            "context_lines": ctx,
                        },
                        remediation=check_info["remediation"],
                        mitre_technique="T1190",
                        compliance_mappings=[ComplianceFramework.CIS_AWS],
                        impact=(
                            "Insecure defaults in Terraform often create public attack surface (0.0.0.0/0), "
                            "over-privileged IAM, or unencrypted data at rest—exploitable as soon as resources exist."
                        ),
                        detection_reason=f"Terraform resource scanner matched rule `{check_id}` against this file.",
                        risk_score=iac_severity_risk(sev),
                        commands=build_iac_commands(IaCCheckCategory.RESOURCE_SECURITY),
                    ))
            except re.error:
                pass
        
        return findings
    
    def scan_backend_config(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan backend configuration."""
        findings = []
        
        for check_id, check_info in BACKEND_PATTERNS.items():
            try:
                for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                    line_num = self._get_line_number(content, match.start())
                    snippet = (match.group(0) or "")[:400]
                    ctx = context_lines_for_match(content, line_num, radius=3)
                    sev = check_info["severity"]
                    findings.append(IaCFinding(
                        tool=IaCTool.TERRAFORM,
                        category=IaCCheckCategory.STATE_SECURITY,
                        severity=sev,
                        title=check_info["title"],
                        description=(
                            f"{check_info['title']} in `{os.path.basename(file_path)}` near line {line_num}; "
                            "backend settings affect who can read/write state and whether ciphertext is stored."
                        ),
                        file_path=file_path,
                        line_number=line_num,
                        evidence={
                            "check_id": check_id,
                            "matched_text": snippet,
                            "context_lines": ctx,
                        },
                        remediation=check_info["remediation"],
                        mitre_technique="T1552",
                        compliance_mappings=[ComplianceFramework.SOC2],
                        impact="Weak or local backends increase risk of state theft, concurrent unsafe applies, and secret leakage via plaintext state.",
                        detection_reason=f"Terraform backend scanner matched rule `{check_id}`.",
                        risk_score=iac_severity_risk(sev),
                        commands=build_iac_commands(IaCCheckCategory.STATE_SECURITY),
                    ))
            except re.error:
                pass
        
        return findings
    
    def scan_state_file(self, file_path: str) -> List[IaCFinding]:
        """Scan Terraform state file for secrets."""
        findings = []
        content = self._read_file(file_path)
        
        if not content:
            return findings
        
        # Check if state file in git
        git_dir = os.path.dirname(file_path)
        while git_dir and git_dir != '/':
            if os.path.exists(os.path.join(git_dir, '.git')):
                line_num = 1
                ctx = context_lines_for_match(content, line_num, radius=6)
                findings.append(IaCFinding(
                    tool=IaCTool.TERRAFORM,
                    category=IaCCheckCategory.STATE_SECURITY,
                    severity=IaCSeverity.CRITICAL,
                    title="State File in Git Repository",
                    description=(
                        f"`{os.path.basename(file_path)}` sits under a directory tree that contains `.git`; "
                        "committed state can leak resource IDs, outputs, and sensitive attributes via history and forks."
                    ),
                    file_path=file_path,
                    line_number=line_num,
                    evidence={
                        "check_id": "terraform_state_in_git",
                        "matched_text": f"(terraform state file adjacent to git: {os.path.basename(file_path)})",
                        "context_lines": ctx,
                    },
                    remediation="Add *.tfstate to .gitignore and remove from git history",
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2],
                    impact=(
                        "Anyone with clone access can read full deployment state; combined with weak remotes or leaked tokens "
                        "this often equals credential and infrastructure takeover."
                    ),
                    detection_reason="Walked parent directories from the `.tfstate` path and found a `.git` directory.",
                    risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                    commands=build_iac_commands(IaCCheckCategory.STATE_SECURITY),
                ))
                break
            git_dir = os.path.dirname(git_dir)
        
        # Scan state for secrets
        try:
            state_data = json.loads(content)
            
            # Check for sensitive attributes
            if "resources" in state_data:
                for resource in state_data.get("resources", []):
                    for instance in resource.get("instances", []):
                        attrs = instance.get("attributes", {})
                        
                        for key, value in attrs.items():
                            if any(s in key.lower() for s in ['password', 'secret', 'token', 'key']):
                                if value and str(value) not in ['null', '', '***']:
                                    line_num = 0
                                    pos = -1
                                    for needle in (f'"{key}"', f'"{key}":'):
                                        pos = content.find(needle)
                                        if pos != -1:
                                            break
                                    if pos != -1:
                                        line_num = self._get_line_number(content, pos)
                                    if line_num > 0:
                                        ctx = context_lines_for_match(content, line_num, radius=4)
                                    else:
                                        ctx = [ln[:220] for ln in content.splitlines()[:14]]
                                        if len(content.splitlines()) > 14:
                                            ctx.append("… [state JSON truncated for preview]")
                                    if isinstance(value, (dict, list)):
                                        val_preview = json.dumps(value, default=str)
                                    else:
                                        val_preview = str(value)
                                    if len(val_preview) > 200:
                                        val_preview = val_preview[:197] + "…"
                                    matched_redacted = redact_secret_matched_text(f"{key}: {val_preview}")
                                    rtype = resource.get("type", "") or ""
                                    rname = resource.get("name", "") or ""
                                    findings.append(IaCFinding(
                                        tool=IaCTool.TERRAFORM,
                                        category=IaCCheckCategory.SECRETS_EXPOSURE,
                                        severity=IaCSeverity.CRITICAL,
                                        title="Sensitive Data in State File",
                                        description=(
                                            f"`.tfstate` exposes attribute `{key}` for resource `{rtype}.{rname}` "
                                            f"in `{os.path.basename(file_path)}` — plaintext or weakly redacted values often land in backups and S3."
                                        ),
                                        file_path=file_path,
                                        line_number=line_num,
                                        resource_type=rtype,
                                        resource_name=rname,
                                        evidence={
                                            "check_id": "state_sensitive_attr",
                                            "state_attribute": key,
                                            "attribute": key,
                                            "matched_text": matched_redacted,
                                            "context_lines": ctx,
                                        },
                                        remediation="Use sensitive = true in variable definition",
                                        mitre_technique="T1552",
                                        impact=(
                                            f"State is a durable secret store: `{key}` can be extracted from shared backends, "
                                            "old snapshots, and leaked `.tfstate` copies long after apply."
                                        ),
                                        detection_reason=(
                                            f"Parsed state JSON: `resources[].instances[].attributes.{key}` is non-empty "
                                            "and name matches sensitive material heuristics."
                                        ),
                                        risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                                        commands=build_iac_commands(IaCCheckCategory.SECRETS_EXPOSURE),
                                    ))
        except json.JSONDecodeError:
            pass
        
        return findings
    
    def scan_provider_config(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan provider configurations."""
        findings = []
        
        # Check for hardcoded credentials in provider block
        provider_pattern = r'provider\s+["\'](\w+)["\']\s*\{([^}]+)\}'
        
        for match in re.finditer(provider_pattern, content, re.MULTILINE | re.DOTALL):
            provider_name = match.group(1)
            provider_block = match.group(2)
            line_num = self._get_line_number(content, match.start())
            
            # Check for credentials
            cred_patterns = [
                (r'access_key\s*=\s*["\'][^"\']+["\']', 'access_key'),
                (r'secret_key\s*=\s*["\'][^"\']+["\']', 'secret_key'),
                (r'client_id\s*=\s*["\'][^"\']+["\']', 'client_id'),
                (r'client_secret\s*=\s*["\'][^"\']+["\']', 'client_secret'),
                (r'subscription_id\s*=\s*["\'][^"\']+["\']', 'subscription_id'),
                (r'credentials\s*=\s*["\'][^"\']+["\']', 'credentials'),
            ]
            
            for cred_pattern, cred_type in cred_patterns:
                if re.search(cred_pattern, provider_block):
                    ctx = context_lines_for_match(content, line_num, radius=4)
                    findings.append(IaCFinding(
                        tool=IaCTool.TERRAFORM,
                        category=IaCCheckCategory.PROVIDER_SECURITY,
                        severity=IaCSeverity.CRITICAL,
                        title=f"Hardcoded {cred_type} in Provider",
                        description=(
                            f"Provider `{provider_name}` block in `{os.path.basename(file_path)}` line {line_num} "
                            f"embeds `{cred_type}`; anyone with the module gains long-lived cloud credentials."
                        ),
                        file_path=file_path,
                        line_number=line_num,
                        evidence={
                            "check_id": f"provider_{cred_type}",
                            "provider": provider_name,
                            "credential_type": cred_type,
                            "context_lines": ctx,
                        },
                        remediation="Use environment variables or IAM roles",
                        mitre_technique="T1552",
                        compliance_mappings=[ComplianceFramework.CIS_AWS, ComplianceFramework.SOC2],
                        impact="Static provider credentials bypass workload identity; compromise of repo or laptop equals cloud takeover.",
                        detection_reason=f"Regex matched `{cred_type}` assignment inside a `provider` block.",
                        risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                    ))
        
        # Check for version pinning
        version_pattern = r'required_providers\s*\{[^}]*version\s*=\s*["\']([^"\']+)["\']'
        if not re.search(version_pattern, content, re.MULTILINE | re.DOTALL):
            # Check for any required_providers block without version
            if 'required_providers' in content:
                findings.append(IaCFinding(
                    tool=IaCTool.TERRAFORM,
                    category=IaCCheckCategory.PROVIDER_SECURITY,
                    severity=IaCSeverity.MEDIUM,
                    title="Provider Version Not Pinned",
                    description=(
                        f"`required_providers` present in `{os.path.basename(file_path)}` but provider versions are not pinned; "
                        "supply-chain drift can pull vulnerable provider builds on fresh installs."
                    ),
                    file_path=file_path,
                    evidence={"check_id": "provider_version_unpinned"},
                    remediation="Pin provider versions: version = \"~> 4.0\"",
                    impact="Unpinned providers allow silent upgrades that may introduce bugs or compromised binaries into your pipeline.",
                    detection_reason="File contains `required_providers` without a clear `version =` constraint in the scanned text.",
                    risk_score=iac_severity_risk(IaCSeverity.MEDIUM),
                ))
        
        return findings
    
    async def scan(self, directory: str) -> List[IaCFinding]:
        """
        Scan directory for Terraform security issues.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        all_findings = []
        
        tf_files = self._find_terraform_files(directory)
        
        for file_path in tf_files:
            content = self._read_file(file_path)
            if not content:
                continue
            
            # State files
            if file_path.endswith('.tfstate'):
                all_findings.extend(self.scan_state_file(file_path))
                continue
            
            # Regular TF files
            all_findings.extend(self.scan_for_secrets(file_path, content))
            all_findings.extend(self.scan_for_insecure_resources(file_path, content))
            all_findings.extend(self.scan_backend_config(file_path, content))
            all_findings.extend(self.scan_provider_config(file_path, content))
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[IaCFinding]:
        """Get all findings."""
        return self.findings

