"""
Pulumi Security Scanner

Security assessment for Pulumi configurations:
- Stack security (state encryption, backend config)
- Secret management (config secrets, hardcoded values)
- Provider security (credentials, version pinning)
- Code security (hardcoded secrets in TypeScript/Python/Go)

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1078: Valid Accounts
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from ...proto import (
    IaCFinding, IaCTool, IaCSeverity, IaCCheckCategory,
    PULUMI_SECURITY_RULES, ComplianceFramework
)
from ..utils.iac_evidence_utils import (
    context_lines_for_match,
    iac_severity_risk,
    redact_secret_matched_text,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Pulumi Security Patterns
# =============================================================================

PULUMI_CONFIG_PATTERNS = {
    "unencrypted_secret": {
        "pattern": r'(?:password|secret|token|key|credential)["\']?\s*:\s*["\'][^"\']+["\'](?!\s*:\s*secure)',
        "severity": IaCSeverity.HIGH,
        "title": "Unencrypted Secret in Config",
        "description": "Secret value not marked as secure in Pulumi config",
        "remediation": "Use pulumi config set --secret for sensitive values",
    },
    "plaintext_in_stack": {
        "pattern": r'"secretsProvider"\s*:\s*"passphrase"',
        "severity": IaCSeverity.MEDIUM,
        "title": "Passphrase Secrets Provider",
        "description": "Using passphrase provider instead of cloud KMS",
        "remediation": "Use cloud KMS (awskms://, azurekeyvault://, gcpkms://)",
    },
}

# Patterns for Pulumi code (TypeScript/Python/Go)
CODE_SECRET_PATTERNS = {
    "typescript": {
        "hardcoded_secret": r'(?:password|secret|token|apiKey)\s*[=:]\s*["\'][^"\']+["\']',
        "config_get_plain": r'config\.get\(["\'][^"\']+["\']\)(?!\s*\?\?\s*config\.requireSecret)',
        "new_secret_plain": r'new\s+pulumi\.Config\(\)\.get\(["\'](?:password|secret|token)',
    },
    "python": {
        "hardcoded_secret": r'(?:password|secret|token|api_key)\s*=\s*["\'][^"\']+["\']',
        "config_get_plain": r'config\.get\(["\'][^"\']+["\']\)(?!\s*or\s*config\.require_secret)',
        "pulumi_output_plain": r'pulumi\.Output\.secret\(["\'][^"\']+["\']\)',
    },
    "go": {
        "hardcoded_secret": r'(?:Password|Secret|Token|ApiKey)\s*:\s*["`][^"`]+["`]',
        "config_get_plain": r'cfg\.Get\(["`][^"`]+["`]\)',
    },
}

PULUMI_STATE_PATTERNS = {
    "secrets_in_state": {
        "pattern": r'"outputs"\s*:\s*\{[^}]*"[^"]*(?:password|secret|token|key)[^"]*"\s*:\s*\{[^}]*"secret"\s*:\s*false',
        "severity": IaCSeverity.CRITICAL,
        "title": "Non-Secret Output Contains Sensitive Data",
        "description": "Output with sensitive name not marked as secret",
        "remediation": "Mark outputs as secret: pulumi.Output.secret(value)",
    },
}


class PulumiScanner:
    """Pulumi security scanner."""
    
    def __init__(self):
        self.findings: List[IaCFinding] = []
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            logger.debug(f"Failed to read {path}: {e}")
            return None
    
    def _find_pulumi_files(self, directory: str) -> Dict[str, List[str]]:
        """Find Pulumi files by type."""
        files = {
            "yaml_config": [],
            "stack_json": [],
            "typescript": [],
            "python": [],
            "go": [],
            "state": [],
        }
        
        for root, dirs, filenames in os.walk(directory):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in [
                'node_modules', 'vendor', '__pycache__', '.pulumi'
            ]]
            
            for filename in filenames:
                full_path = os.path.join(root, filename)
                
                # Pulumi YAML configs
                if filename.startswith('Pulumi.') and filename.endswith('.yaml'):
                    files["yaml_config"].append(full_path)
                elif filename == 'Pulumi.yaml':
                    files["yaml_config"].append(full_path)
                
                # Stack state
                elif filename.endswith('.json') and 'stack' in filename.lower():
                    files["stack_json"].append(full_path)
                
                # Code files
                elif filename.endswith('.ts') or filename.endswith('.tsx'):
                    files["typescript"].append(full_path)
                elif filename.endswith('.py'):
                    files["python"].append(full_path)
                elif filename.endswith('.go'):
                    files["go"].append(full_path)
        
        return files
    
    def _get_line_number(self, content: str, match_start: int) -> int:
        """Get line number from match position."""
        return content[:match_start].count('\n') + 1
    
    def scan_yaml_config(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan Pulumi YAML config files."""
        findings = []
        
        for check_id, check_info in PULUMI_CONFIG_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE):
                line_num = self._get_line_number(content, match.start())
                raw_m = match.group(0) or ""
                ctx = context_lines_for_match(content, line_num, radius=3)
                sev = check_info["severity"]
                findings.append(IaCFinding(
                    tool=IaCTool.PULUMI,
                    category=IaCCheckCategory.SECRET_MANAGEMENT,
                    severity=sev,
                    title=check_info["title"],
                    description=(
                        f"{check_info['description']} — matched in `{os.path.basename(file_path)}` line {line_num}."
                    ),
                    file_path=file_path,
                    line_number=line_num,
                    evidence={
                        "check_id": check_id,
                        "matched_text": redact_secret_matched_text(raw_m),
                        "context_lines": ctx,
                    },
                    remediation=check_info["remediation"],
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2],
                    impact="Plaintext secrets in Pulumi YAML propagate with stack configs and can surface in CI logs or shared repos.",
                    detection_reason=f"Pulumi YAML scanner matched config rule `{check_id}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        # Check for config values that should be secrets
        if YAML_AVAILABLE:
            try:
                data = yaml.safe_load(content)
                if data and 'config' in data:
                    config = data['config']
                    for key, value in config.items() if isinstance(config, dict) else []:
                        if any(s in key.lower() for s in ['password', 'secret', 'token', 'key', 'credential']):
                            if not isinstance(value, dict) or not value.get('secure'):
                                line_num = 0
                                km = re.search(rf'^\s*{re.escape(str(key))}\s*:', content, re.MULTILINE)
                                if km:
                                    line_num = self._get_line_number(content, km.start())
                                ctx = context_lines_for_match(content, line_num, radius=3) if line_num > 0 else []
                                findings.append(IaCFinding(
                                    tool=IaCTool.PULUMI,
                                    category=IaCCheckCategory.SECRET_MANAGEMENT,
                                    severity=IaCSeverity.HIGH,
                                    title="Sensitive Config Not Secured",
                                    description=(
                                        f"Pulumi config key `{key}` in `{os.path.basename(file_path)}` is not stored as a secure secret."
                                    ),
                                    file_path=file_path,
                                    line_number=line_num,
                                    evidence={
                                        "check_id": "pulumi_yaml_sensitive_key",
                                        "config_key": key,
                                        "context_lines": ctx,
                                    },
                                    remediation="Use: pulumi config set --secret " + key,
                                    mitre_technique="T1552",
                                    impact="Sensitive stack configuration may be committed in cleartext and copied with project checkouts.",
                                    detection_reason="YAML `config` entry name suggests sensitivity but lacks `secure: true` wrapper.",
                                    risk_score=iac_severity_risk(IaCSeverity.HIGH),
                                ))
            except yaml.YAMLError:
                pass
        
        return findings
    
    def scan_code_secrets(self, file_path: str, content: str, language: str) -> List[IaCFinding]:
        """Scan Pulumi code for hardcoded secrets."""
        findings = []
        
        patterns = CODE_SECRET_PATTERNS.get(language, {})
        
        for pattern_name, pattern in patterns.items():
            for match in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                matched_text = match.group()
                
                # Skip if it's a variable reference or placeholder
                if any(p in matched_text.lower() for p in ['process.env', 'os.environ', 'config.', 'changeme', 'xxx']):
                    continue
                
                line_num = self._get_line_number(content, match.start())
                sev = IaCSeverity.CRITICAL if "hardcoded" in pattern_name else IaCSeverity.HIGH
                ctx = context_lines_for_match(content, line_num, radius=3)
                redacted = redact_secret_matched_text(matched_text)
                findings.append(IaCFinding(
                    tool=IaCTool.PULUMI,
                    category=IaCCheckCategory.HARDCODED_CREDENTIALS,
                    severity=sev,
                    title=f"Potential Secret in Code ({pattern_name})",
                    description=(
                        f"Pattern `{pattern_name}` in `{os.path.basename(file_path)}` line {line_num} ({language}) "
                        "suggests embedded secret material in Pulumi program code."
                    ),
                    file_path=file_path,
                    line_number=line_num,
                    evidence={
                        "pattern": pattern_name,
                        "language": language,
                        "matched_text": redacted,
                        "context_lines": ctx,
                    },
                    remediation="Use pulumi.Config().requireSecret() for secrets",
                    mitre_technique="T1552",
                    compliance_mappings=[ComplianceFramework.SOC2],
                    impact="Secrets in source are trivially harvested from git; rotation requires code deploys and still leaves history exposure.",
                    detection_reason=f"Pulumi code scanner matched `{pattern_name}` regex for `{language}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        return findings
    
    def scan_state_file(self, file_path: str, content: str) -> List[IaCFinding]:
        """Scan Pulumi state files."""
        findings = []
        
        # Check if state file is in git
        git_dir = os.path.dirname(file_path)
        while git_dir and git_dir != '/':
            if os.path.exists(os.path.join(git_dir, '.git')):
                findings.append(IaCFinding(
                    tool=IaCTool.PULUMI,
                    category=IaCCheckCategory.STATE_SECURITY,
                    severity=IaCSeverity.CRITICAL,
                    title="State File in Git Repository",
                    description=f"Pulumi stack/state file `{os.path.basename(file_path)}` lives inside a git working tree.",
                    file_path=file_path,
                    evidence={"check_id": "pulumi_state_in_git"},
                    remediation="Use Pulumi Cloud or configure remote backend",
                    mitre_technique="T1552",
                    impact="Committed state may contain ciphertext and metadata that collapses to secrets when passphrase leaks; history is hard to purge.",
                    detection_reason="Walked parent directories from state path and found a `.git` directory.",
                    risk_score=iac_severity_risk(IaCSeverity.CRITICAL),
                ))
                break
            git_dir = os.path.dirname(git_dir)
        
        # Scan for secrets in state
        for check_id, check_info in PULUMI_STATE_PATTERNS.items():
            for match in re.finditer(check_info["pattern"], content, re.IGNORECASE | re.MULTILINE | re.DOTALL):
                line_num = self._get_line_number(content, match.start())
                ctx = context_lines_for_match(content, line_num, radius=2)
                sev = check_info["severity"]
                findings.append(IaCFinding(
                    tool=IaCTool.PULUMI,
                    category=IaCCheckCategory.SECRETS_EXPOSURE,
                    severity=sev,
                    title=check_info["title"],
                    description=f"{check_info['description']} — seen in `{os.path.basename(file_path)}`.",
                    file_path=file_path,
                    line_number=line_num,
                    evidence={
                        "check_id": check_id,
                        "matched_text": (match.group(0) or "")[:300],
                        "context_lines": ctx,
                    },
                    remediation=check_info["remediation"],
                    mitre_technique="T1552",
                    impact="Sensitive outputs in plaintext Pulumi state are readable by anyone with state backend access.",
                    detection_reason=f"Pulumi state JSON matched rule `{check_id}`.",
                    risk_score=iac_severity_risk(sev),
                ))
        
        # Parse JSON state
        try:
            state = json.loads(content)
            
            # Check encryption provider
            if state.get('deployment', {}).get('secrets_providers', {}).get('type') == 'passphrase':
                findings.append(IaCFinding(
                    tool=IaCTool.PULUMI,
                    category=IaCCheckCategory.STATE_SECURITY,
                    severity=IaCSeverity.MEDIUM,
                    title="State Using Passphrase Encryption",
                    description=f"Pulumi state in `{os.path.basename(file_path)}` uses passphrase-based secrets provider instead of cloud KMS.",
                    file_path=file_path,
                    evidence={"check_id": "pulumi_state_passphrase_kms"},
                    remediation="Migrate to cloud KMS provider (AWS KMS, Azure Key Vault, GCP KMS)",
                    compliance_mappings=[ComplianceFramework.SOC2],
                    impact="Passphrase-based encryption hinges on a shared secret; weaker than per-environment KMS with audit and HSM backing.",
                    detection_reason="Parsed state JSON shows `secrets_providers.type` == `passphrase`.",
                    risk_score=iac_severity_risk(IaCSeverity.MEDIUM),
                ))
        except json.JSONDecodeError:
            pass
        
        return findings
    
    async def scan(self, directory: str) -> List[IaCFinding]:
        """
        Scan directory for Pulumi security issues.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        all_findings = []
        
        files = self._find_pulumi_files(directory)
        
        # Scan YAML configs
        for file_path in files["yaml_config"]:
            content = self._read_file(file_path)
            if content:
                all_findings.extend(self.scan_yaml_config(file_path, content))
        
        # Scan TypeScript code
        for file_path in files["typescript"][:50]:
            content = self._read_file(file_path)
            if content:
                all_findings.extend(self.scan_code_secrets(file_path, content, "typescript"))
        
        # Scan Python code
        for file_path in files["python"][:50]:
            content = self._read_file(file_path)
            if content:
                all_findings.extend(self.scan_code_secrets(file_path, content, "python"))
        
        # Scan Go code
        for file_path in files["go"][:50]:
            content = self._read_file(file_path)
            if content:
                all_findings.extend(self.scan_code_secrets(file_path, content, "go"))
        
        # Scan state files
        for file_path in files["stack_json"][:10]:
            content = self._read_file(file_path)
            if content:
                all_findings.extend(self.scan_state_file(file_path, content))
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[IaCFinding]:
        """Get all findings."""
        return self.findings

