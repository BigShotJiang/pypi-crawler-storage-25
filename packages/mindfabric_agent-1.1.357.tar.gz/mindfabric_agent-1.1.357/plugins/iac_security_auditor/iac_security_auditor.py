"""
IaC Security Auditor Plugin

Comprehensive security assessment for Infrastructure as Code:
- Terraform: State security, provider security, resource security
- Ansible: Playbook security, vault security, inventory security
- Pulumi: Stack security, secret management
- CloudFormation: Template injection, IAM security, parameter security

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1078: Valid Accounts
- T1190: Exploit Public-Facing Application
- T1195: Supply Chain Compromise
"""

import asyncio
import logging
import os
import re
from collections import defaultdict
from typing import Dict, List, Any, Optional, Tuple
from plugins.base_plugin import BasePlugin
from .proto import (
    IaCFinding, IaCTool, IaCSeverity, IaCCheckCategory,
    IaCSecurityReport, ComplianceFramework
)
from .modules.scanners import (
    TerraformScanner,
    AnsibleScanner,
    PulumiScanner,
    CloudFormationScanner,
)
from .modules.utils.iac_ansible_scope import merge_ansible_targets

logger = logging.getLogger(__name__)


def _enrich_iac_recommendations_with_location(recs: List[Any], finding: Dict[str, Any]) -> List[Any]:
    """Append file/line context so generic IaC recs still point analysts at the artifact."""
    if not isinstance(recs, list) or not recs:
        return recs
    fp = finding.get("file_path") or finding.get("path") or finding.get("resource_id")
    ln = finding.get("line_number")
    loc_bits: List[str] = []
    if fp:
        loc_bits.append(str(fp).strip())
    try:
        ln_int = int(ln) if ln is not None and str(ln).strip() != "" else 0
    except (TypeError, ValueError):
        ln_int = 0
    if ln_int > 0:
        loc_bits.append(f"line {ln_int}")
    if not loc_bits:
        return recs
    loc = " ".join(loc_bits)
    suffix = f" Affected artifact: `{loc}`."
    out: List[Any] = []
    for item in recs:
        if isinstance(item, dict):
            d = dict(item)
            desc = (d.get("description") or "").rstrip()
            if "Affected artifact:" not in desc:
                d["description"] = desc + suffix
            out.append(d)
        else:
            out.append(item)
    return out


class IaCSecurityAuditor(BasePlugin):
    """
    IaC Security Auditor Plugin.
    
    Scans Infrastructure as Code for security vulnerabilities:
    - Hardcoded credentials and secrets
    - Insecure resource configurations
    - Overly permissive IAM policies
    - Missing encryption
    - Compliance violations
    """
    
    name = "iac_security_auditor"
    description = "Security assessment for Infrastructure as Code (Terraform, Ansible, Pulumi, CloudFormation)"
    version = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.terraform_scanner = TerraformScanner()
        self.ansible_scanner = AnsibleScanner()
        self.pulumi_scanner = PulumiScanner()
        self.cloudformation_scanner = CloudFormationScanner()
        
        self.last_report: Optional[IaCSecurityReport] = None

    async def run(self):
        """
        Agent entry point. Scheduler/CLI provides options via self.options.
        """
        params: Dict[str, Any] = dict(self.options or {})
        # Remove control/meta keys that are not scan params
        for k in ("command", "command_id", "plugin", "args", "command_type", "options"):
            params.pop(k, None)

        # Common convenience aliases
        if "directory" not in params:
            if "root_dir" in params:
                params["directory"] = params.pop("root_dir")
            else:
                params["directory"] = "."

        raw_output = await self.execute(params)
        return self.to_security_scan_v1(self._with_canonical_ui_blocks(raw_output, directory=params.get("directory")))

    def _with_canonical_ui_blocks(self, output: Any, directory: Optional[str] = None) -> Dict[str, Any]:
        """
        Ensure each finding has UI blocks (recommendations/commands) and
        add a summary finding when scan produced 0 findings.
        """
        try:
            out: Dict[str, Any] = dict(output) if isinstance(output, dict) else {}
        except Exception:
            out = {}

        from .modules.databases.ui_templates import (
            IAC_GENERAL_RECOMMENDATIONS,
            build_iac_scan_completed_description,
            build_iac_scan_completed_evidence,
            build_iac_scan_completed_impact,
            get_iac_exploitation_commands,
        )

        findings = out.get("findings")
        if isinstance(findings, list):
            for f in findings:
                if not isinstance(f, dict):
                    continue
                if not f.get("recommendations"):
                    base_recs = [dict(x) for x in IAC_GENERAL_RECOMMENDATIONS]
                else:
                    base_recs = [dict(x) if isinstance(x, dict) else x for x in f["recommendations"]]
                f["recommendations"] = _enrich_iac_recommendations_with_location(base_recs, f)
                if not f.get("exploitation_commands") and not f.get("commands"):
                    f["exploitation_commands"] = get_iac_exploitation_commands(
                        {
                            "directory": directory,
                            "file_path": f.get("file_path"),
                            "line_number": f.get("line_number"),
                        }
                    )
        # No synthetic threat when there are zero issues — avoids noise on the security / threats board.
        if not isinstance(findings, list) or len(findings) == 0:
            out["findings"] = []
            scope = str(directory or ".").strip() or "."
            out["iac_scan_summary"] = {
                "status": "completed_no_findings",
                "directory": scope,
                "description": build_iac_scan_completed_description(
                    directory=scope,
                    by_tool=out.get("by_tool") if isinstance(out.get("by_tool"), dict) else None,
                ),
                "impact": build_iac_scan_completed_impact(),
                "evidence": build_iac_scan_completed_evidence(
                    directory=scope,
                    summary=out.get("summary") if isinstance(out.get("summary"), dict) else None,
                    by_tool=out.get("by_tool") if isinstance(out.get("by_tool"), dict) else None,
                ),
                "recommendations": [dict(x) for x in IAC_GENERAL_RECOMMENDATIONS],
                "exploitation_commands": get_iac_exploitation_commands({"directory": directory}),
            }
        return out
    
    async def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute IaC security scan.
        
        Args:
            params: Execution parameters
                - directory: Directory to scan (required)
                - scan_terraform: Scan Terraform files (default: True)
                - scan_ansible: Scan Ansible files (default: True)
                - scan_pulumi: Scan Pulumi files (default: True)
                - scan_cloudformation: Scan CloudFormation files (default: True)
                - compliance_frameworks: List of compliance frameworks to check
                - severity_threshold: Minimum severity to report (default: "low")
                
        Returns:
            Scan results
        """
        directory = params.get("directory", ".")
        try:
            directory = os.path.abspath(os.path.realpath(directory))
        except Exception:
            directory = os.path.abspath(directory or ".")
        params["directory"] = directory
        scan_terraform = params.get("scan_terraform", True)
        scan_ansible = params.get("scan_ansible", True)
        scan_pulumi = params.get("scan_pulumi", True)
        scan_cloudformation = params.get("scan_cloudformation", True)
        severity_threshold = params.get("severity_threshold", "low")
        
        logger.info(f"Starting IaC security scan of {directory}")
        
        all_findings: List[IaCFinding] = []
        
        # Run scanners concurrently
        tasks = []
        
        if scan_terraform:
            tasks.append(self.terraform_scanner.scan(directory))
        if scan_ansible:
            tasks.append(self.ansible_scanner.scan(directory))
        if scan_pulumi:
            tasks.append(self.pulumi_scanner.scan(directory))
        if scan_cloudformation:
            tasks.append(self.cloudformation_scanner.scan(directory))
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, Exception):
                    logger.error(f"Scanner error: {result}")
                elif isinstance(result, list):
                    all_findings.extend(result)
        
        # Filter by severity threshold
        severity_order = {
            IaCSeverity.CRITICAL: 5,
            IaCSeverity.HIGH: 4,
            IaCSeverity.MEDIUM: 3,
            IaCSeverity.LOW: 2,
            IaCSeverity.INFO: 1,
        }
        
        threshold_value = {
            "critical": 5,
            "high": 4,
            "medium": 3,
            "low": 2,
            "info": 1,
        }.get(severity_threshold.lower(), 2)
        
        filtered_findings = [
            f for f in all_findings
            if severity_order.get(f.severity, 0) >= threshold_value
        ]

        filtered_findings = self._aggregate_iac_groupable_findings(filtered_findings)
        
        # Build report
        report = self._build_report(filtered_findings)
        self.last_report = report
        
        # Convert to dict for JSON serialization
        return {
            "status": "success",
            "summary": {
                "total_findings": len(report.findings),
                "critical": report.critical_count,
                "high": report.high_count,
                "medium": report.medium_count,
                "low": report.low_count,
                "risk_score": report.risk_score,
            },
            "by_tool": {
                "terraform": report.terraform_findings,
                "ansible": report.ansible_findings,
                "pulumi": report.pulumi_findings,
                "cloudformation": report.cloudformation_findings,
            },
            "findings": [self._finding_to_dict(f) for f in report.findings],
            "compliance_violations": report.compliance_violations,
        }
    
    def _iac_group_meta(self, f: IaCFinding) -> Optional[Tuple[IaCTool, str, str]]:
        """
        Return (tool, bucket, group_id) for findings that should collapse into one row when repeated.
        """
        ev = f.evidence if isinstance(f.evidence, dict) else {}
        if ev.get("aggregated"):
            return None
        t, c = f.tool, f.category

        if t == IaCTool.ANSIBLE and c == IaCCheckCategory.HARDCODED_CREDENTIALS and ev.get("pattern"):
            return (t, "hardcoded", str(ev["pattern"]))
        if t == IaCTool.TERRAFORM and c == IaCCheckCategory.HARDCODED_CREDENTIALS and ev.get("pattern"):
            return (t, "hardcoded", str(ev["pattern"]))
        if t == IaCTool.CLOUDFORMATION and c == IaCCheckCategory.HARDCODED_CREDENTIALS and ev.get("pattern"):
            return (t, "hardcoded", str(ev["pattern"]))
        if t == IaCTool.PULUMI and c == IaCCheckCategory.HARDCODED_CREDENTIALS and ev.get("language") and ev.get("pattern"):
            return (t, "hardcoded_code", f"{ev['language']}:{ev['pattern']}")
        if t == IaCTool.PULUMI and c == IaCCheckCategory.SECRET_MANAGEMENT and ev.get("check_id"):
            cid = str(ev["check_id"])
            if cid == "pulumi_yaml_sensitive_key":
                return None
            return (t, "secret_mgmt", cid)
        if t == IaCTool.TERRAFORM and c == IaCCheckCategory.RESOURCE_SECURITY and ev.get("check_id"):
            return (t, "resource", str(ev["check_id"]))
        if t == IaCTool.TERRAFORM and c == IaCCheckCategory.STATE_SECURITY and ev.get("check_id"):
            return (t, "state", str(ev["check_id"]))
        if t == IaCTool.TERRAFORM and c == IaCCheckCategory.SECRETS_EXPOSURE and ev.get("state_attribute"):
            return (t, "state_secret_key", str(ev["state_attribute"]))
        if t == IaCTool.TERRAFORM and c == IaCCheckCategory.PROVIDER_SECURITY and ev.get("check_id"):
            return (t, "provider", str(ev["check_id"]))
        if t == IaCTool.CLOUDFORMATION and ev.get("check_id") and c in (
            IaCCheckCategory.IAM_SECURITY,
            IaCCheckCategory.RESOURCE_SECURITY,
            IaCCheckCategory.PARAMETER_SECURITY,
        ):
            return (t, c.value, str(ev["check_id"]))
        if t == IaCTool.PULUMI and c == IaCCheckCategory.SECRETS_EXPOSURE and ev.get("check_id"):
            return (t, "secrets_exposure", str(ev["check_id"]))
        if t == IaCTool.PULUMI and c == IaCCheckCategory.STATE_SECURITY and ev.get("check_id"):
            return (t, "pulumi_state", str(ev["check_id"]))
        return None

    def _aggregate_iac_groupable_findings(self, findings: List[IaCFinding]) -> List[IaCFinding]:
        """Collapse high-cardinality repeats (same pattern/rule) into one finding with samples."""
        groups: Dict[Tuple[IaCTool, str, str], List[IaCFinding]] = defaultdict(list)
        rest: List[IaCFinding] = []
        for f in findings:
            meta = self._iac_group_meta(f)
            if meta is None:
                rest.append(f)
            else:
                groups[meta].append(f)

        if not groups:
            return findings

        MAX_SAMPLES = 30
        MAX_FILES_LIST = 400
        tool_names = {
            IaCTool.ANSIBLE: "Ansible",
            IaCTool.TERRAFORM: "Terraform",
            IaCTool.PULUMI: "Pulumi",
            IaCTool.CLOUDFORMATION: "CloudFormation",
        }
        from .modules.utils.iac_evidence_utils import format_context_for_ui, iac_absolute_path

        merged: List[IaCFinding] = []
        for key in sorted(groups.keys(), key=lambda k: (k[0].name, k[1], k[2])):
            items = groups[key]
            if len(items) < 2:
                rest.extend(items)
                continue

            tool, bucket, group_id = key
            files_set = {iac_absolute_path(f.file_path) for f in items if f.file_path}
            files_set = {p for p in files_set if p}
            files_sorted = sorted(files_set)
            total = len(items)
            n_files = len(files_set)
            samples: List[Dict[str, Any]] = []
            for f in items[:MAX_SAMPLES]:
                ev = f.evidence if isinstance(f.evidence, dict) else {}
                cl = ev.get("context_lines")
                ctx_flat = (
                    format_context_for_ui(cl)
                    if isinstance(cl, list)
                    else ""
                )
                samples.append({
                    "file_path": iac_absolute_path(f.file_path) or (f.file_path or ""),
                    "line_number": f.line_number,
                    "matched_text": ev.get("matched_text") or ev.get("matched_text_preview"),
                    "context_lines": cl,
                    "context_line": ctx_flat,
                    "state_attribute": ev.get("state_attribute"),
                    "parameter_name": ev.get("parameter_name"),
                    "resource_type": f.resource_type or None,
                    "resource_name": f.resource_name or None,
                })
            primary = items[0]
            primary_fp = iac_absolute_path(primary.file_path) or primary.file_path
            risk_vals = [f.risk_score for f in items if f.risk_score is not None]
            agg_risk = max(risk_vals) if risk_vals else None
            tool_h = tool_names.get(tool, tool.name.title())
            agg_evidence: Dict[str, Any] = {
                "aggregated": True,
                "total_matches": total,
                "file_count": n_files,
                "files": files_sorted[:MAX_FILES_LIST],
                "files_truncated": len(files_sorted) > MAX_FILES_LIST,
                "samples": samples,
                "samples_truncated": total > MAX_SAMPLES,
            }
            if bucket == "hardcoded":
                agg_evidence["pattern"] = group_id
            elif bucket == "state_secret_key":
                agg_evidence["check_id"] = "state_sensitive_attr"
                agg_evidence["state_attribute"] = group_id
            else:
                agg_evidence["check_id"] = group_id

            if tool == IaCTool.ANSIBLE:
                merged_at = merge_ansible_targets(
                    [f.evidence for f in items if isinstance(getattr(f, "evidence", None), dict)]
                )
                if merged_at:
                    agg_evidence["ansible_targets"] = merged_at

            title_base = primary.title.split("—")[0].strip() if "—" in primary.title else primary.title
            title = f"{tool_h}: {title_base} — {total} matches in {n_files} files"
            desc = (
                f"Grouped {total} occurrences of rule/pattern `{group_id}` across {n_files} files ({tool_h}). "
                "Review samples and remediate at the source."
            )
            impact = (
                f"Repeated `{group_id}` across {total} locations widens blast radius: one missed fix leaves many resources or files exposed."
            )
            detection_reason = (
                f"{tool_h} scanner aggregated {total} matches for `{group_id}` in {n_files} distinct paths."
            )
            merged.append(
                IaCFinding(
                    tool=tool,
                    category=primary.category,
                    severity=primary.severity,
                    title=title,
                    description=desc,
                    file_path=primary_fp or "",
                    line_number=0,
                    evidence=agg_evidence,
                    remediation=primary.remediation,
                    mitre_technique=primary.mitre_technique,
                    compliance_mappings=list(primary.compliance_mappings),
                    impact=impact,
                    detection_reason=detection_reason,
                    risk_score=agg_risk,
                )
            )
        return rest + merged

    def _build_report(self, findings: List[IaCFinding]) -> IaCSecurityReport:
        """Build security report from findings."""
        report = IaCSecurityReport(findings=findings)
        
        # Count by tool
        report.terraform_findings = sum(1 for f in findings if f.tool == IaCTool.TERRAFORM)
        report.ansible_findings = sum(1 for f in findings if f.tool == IaCTool.ANSIBLE)
        report.pulumi_findings = sum(1 for f in findings if f.tool == IaCTool.PULUMI)
        report.cloudformation_findings = sum(1 for f in findings if f.tool == IaCTool.CLOUDFORMATION)
        
        # Count by severity
        report.critical_count = sum(1 for f in findings if f.severity == IaCSeverity.CRITICAL)
        report.high_count = sum(1 for f in findings if f.severity == IaCSeverity.HIGH)
        report.medium_count = sum(1 for f in findings if f.severity == IaCSeverity.MEDIUM)
        report.low_count = sum(1 for f in findings if f.severity == IaCSeverity.LOW)
        report.info_count = sum(1 for f in findings if f.severity == IaCSeverity.INFO)
        
        # Count by category
        for finding in findings:
            cat_name = finding.category.value if hasattr(finding.category, 'value') else str(finding.category)
            report.findings_by_category[cat_name] = report.findings_by_category.get(cat_name, 0) + 1
        
        # Compliance violations
        for finding in findings:
            for framework in finding.compliance_mappings:
                framework_name = framework.value if hasattr(framework, 'value') else str(framework)
                if framework_name not in report.compliance_violations:
                    report.compliance_violations[framework_name] = []
                report.compliance_violations[framework_name].append(finding.title)
        
        # Calculate risk score
        report.risk_score = self._calculate_risk_score(findings)
        
        # Calculate compliance score
        report.compliance_score = self._calculate_compliance_score(findings)
        
        return report
    
    def _calculate_risk_score(self, findings: List[IaCFinding]) -> float:
        """Calculate overall risk score (0-100)."""
        if not findings:
            return 0.0
        
        severity_weights = {
            IaCSeverity.CRITICAL: 10,
            IaCSeverity.HIGH: 7,
            IaCSeverity.MEDIUM: 4,
            IaCSeverity.LOW: 2,
            IaCSeverity.INFO: 0,
        }
        
        total = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_total = len(findings) * 10
        
        return min((total / max_total) * 100 if max_total > 0 else 0, 100)
    
    def _calculate_compliance_score(self, findings: List[IaCFinding]) -> float:
        """Calculate compliance score (100 = fully compliant, 0 = many violations)."""
        compliance_findings = [f for f in findings if f.compliance_mappings]
        
        if not compliance_findings:
            return 100.0  # No compliance-related findings
        
        # More compliance violations = lower score
        violation_count = sum(len(f.compliance_mappings) for f in compliance_findings)
        
        # Simple inverse score
        return max(0, 100 - (violation_count * 5))
    
    def _finding_to_dict(self, finding: IaCFinding) -> Dict[str, Any]:
        """Convert finding to dictionary."""
        from .modules.databases.ui_templates import (
            get_iac_exploitation_commands,
            build_iac_rule_recommendations,
        )
        from .modules.utils.iac_evidence_utils import format_context_for_ui, iac_absolute_path

        ev = dict(finding.evidence) if isinstance(finding.evidence, dict) else {}
        pattern = ev.get("pattern") if isinstance(ev.get("pattern"), str) else None
        check_id_ev = ev.get("check_id") if isinstance(ev.get("check_id"), str) else None
        fp_abs = iac_absolute_path(finding.file_path)
        tool_label_map = {
            IaCTool.ANSIBLE: "Ansible",
            IaCTool.TERRAFORM: "Terraform",
            IaCTool.PULUMI: "Pulumi",
            IaCTool.CLOUDFORMATION: "CloudFormation",
        }
        tool_label = tool_label_map.get(
            finding.tool,
            finding.tool.name.replace("_", " ").title() if hasattr(finding.tool, "name") else str(finding.tool),
        )
        if ev and not ev.get("aggregated"):
            cl0 = ev.get("context_lines")
            if isinstance(cl0, list) and not ev.get("context_line"):
                ev["context_line"] = format_context_for_ui(cl0)

        raw_desc = (finding.description or "").strip()
        if raw_desc and len(raw_desc) < 200:
            audience_desc = (
                "Your infrastructure-as-code (Terraform, Ansible, CloudFormation, Pulumi, etc.) defines how cloud resources "
                "and permissions are created. This finding means a template or config weakens security or exposes secrets if applied as written. "
                + raw_desc
            )
        else:
            audience_desc = finding.description

        out = {
            "tool": finding.tool.name if hasattr(finding.tool, 'name') else str(finding.tool),
            "category": finding.category.value if hasattr(finding.category, 'value') else str(finding.category),
            "severity": finding.severity.value if hasattr(finding.severity, 'value') else str(finding.severity),
            "title": finding.title,
            "description": audience_desc,
            "file_path": fp_abs or finding.file_path,
            "line_number": finding.line_number,
            "resource_type": finding.resource_type,
            "resource_name": finding.resource_name,
            "evidence": ev,
            "remediation": finding.remediation,
            "mitre_technique": finding.mitre_technique,
            "compliance_mappings": [
                c.value if hasattr(c, 'value') else str(c) 
                for c in finding.compliance_mappings
            ],
            "cve": finding.cve,
            "references": finding.references,
        }
        if finding.impact:
            out["impact"] = finding.impact
        if finding.detection_reason:
            out["detection_reason"] = finding.detection_reason
        if finding.risk_score is not None:
            out["risk_score"] = int(finding.risk_score)
        if ev.get("aggregated"):
            slug_src = pattern or check_id_ev or "agg"
            slug = re.sub(r"[^a-zA-Z0-9_]+", "_", f"{finding.tool.name}_{slug_src}")[:72]
            out["threat_type"] = f"iac_agg_{slug}"
        # UI blocks (security_scan v1)
        out["recommendations"] = build_iac_rule_recommendations(
            pattern=pattern or check_id_ev,
            remediation=finding.remediation,
            tool_name=str(tool_label),
        )
        out["exploitation_commands"] = get_iac_exploitation_commands(
            {
                "directory": None,
                "file_path": fp_abs or finding.file_path,
                "line_number": finding.line_number if finding.line_number else None,
            }
        )

        # Affected resources: Ansible → inferred play hosts / roles / inventory (not raw file paths).
        # Other tools: compact aggregate scope or single artifact. Paths stay in Evidence / samples.
        scope_agg: Optional[Dict[str, Any]] = None
        if ev.get("aggregated"):
            n_files = int(ev.get("file_count") or 0)
            total_m = int(ev.get("total_matches") or 0)
            example = fp_abs or ""
            fl = ev.get("files")
            if not example and isinstance(fl, list) and fl:
                example = iac_absolute_path(fl[0]) or str(fl[0]).strip()
            scope_agg = {
                "type": "iac_aggregate_scope",
                "file_count": n_files,
                "match_count": total_m,
                "detail_hint": "Per-file paths and lines: Evidence → Samples below.",
            }
            if pattern:
                scope_agg["rule"] = pattern
            elif check_id_ev:
                scope_agg["rule"] = check_id_ev
            if example:
                scope_agg["example_path"] = example

        if finding.tool == IaCTool.ANSIBLE:
            at_raw = ev.get("ansible_targets")
            ar_ans: List[Dict[str, Any]] = []
            if isinstance(at_raw, list):
                for x in at_raw:
                    if isinstance(x, dict):
                        ar_ans.append(dict(x))
            if scope_agg is not None:
                out["affected_resources"] = ar_ans + [scope_agg] if ar_ans else [scope_agg]
            elif ar_ans:
                out["affected_resources"] = ar_ans
            else:
                out["affected_resources"] = [
                    {
                        "type": "ansible_managed_scope",
                        "detail": (
                            "Ansible-managed infrastructure; play/group/role not inferred from this artifact. "
                            "See Evidence for path and context."
                        ),
                    }
                ]
        elif scope_agg is not None:
            out["affected_resources"] = [scope_agg]
        elif fp_abs:
            ar: Dict[str, Any] = {"type": "iac_file", "path": fp_abs}
            if isinstance(finding.line_number, int) and finding.line_number > 0:
                ar["line"] = finding.line_number
            out["affected_resources"] = [ar]

        return out
    
    def get_capabilities(self) -> Dict[str, Any]:
        """Get plugin capabilities."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "supported_tools": ["terraform", "ansible", "pulumi", "cloudformation"],
            "compliance_frameworks": [f.value for f in ComplianceFramework],
            "check_categories": [c.value for c in IaCCheckCategory],
        }
    
    async def get_status(self) -> Dict[str, Any]:
        """Get plugin status."""
        return {
            "status": "ready",
            "last_scan": self.last_report is not None,
            "findings_count": len(self.last_report.findings) if self.last_report else 0,
        }

