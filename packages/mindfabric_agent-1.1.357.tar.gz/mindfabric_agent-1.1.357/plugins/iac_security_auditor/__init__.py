"""
IaC Security Auditor Plugin

Comprehensive security assessment for Infrastructure as Code:
- Terraform: State security, provider security, resource security
- Ansible: Playbook security, vault security, inventory security
- Pulumi: Stack security, secret management
- CloudFormation: Template injection, IAM security, parameter security
"""

from .iac_security_auditor import IaCSecurityAuditor

__all__ = ['IaCSecurityAuditor']

