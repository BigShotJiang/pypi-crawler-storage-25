"""
IaC Security Auditor Protocol Definitions

Defines enums, dataclasses and types for IaC security assessment.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional


@dataclass
class ExploitationCommands:
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute for IaC exploitation.
    """
    server: Optional[str] = None
    ip: Optional[str] = None
    commands: List[str] = field(default_factory=list)
    description: Optional[str] = None


class IaCTool(Enum):
    """Supported IaC tools."""
    TERRAFORM = auto()
    ANSIBLE = auto()
    PULUMI = auto()
    CLOUDFORMATION = auto()
    KUBERNETES = auto()
    ARM = auto()  # Azure Resource Manager
    CDK = auto()  # AWS CDK


class IaCSeverity(Enum):
    """Finding severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class IaCCheckCategory(Enum):
    """Security check categories."""
    # Terraform
    STATE_SECURITY = "state_security"
    PROVIDER_SECURITY = "provider_security"
    MODULE_SECURITY = "module_security"
    RESOURCE_SECURITY = "resource_security"
    
    # Ansible
    PLAYBOOK_SECURITY = "playbook_security"
    VAULT_SECURITY = "vault_security"
    INVENTORY_SECURITY = "inventory_security"
    TASK_SECURITY = "task_security"
    
    # Pulumi
    STACK_SECURITY = "stack_security"
    SECRET_MANAGEMENT = "secret_management"
    
    # CloudFormation
    TEMPLATE_SECURITY = "template_security"
    IAM_SECURITY = "iam_security"
    PARAMETER_SECURITY = "parameter_security"
    
    # Generic
    SECRETS_EXPOSURE = "secrets_exposure"
    HARDCODED_CREDENTIALS = "hardcoded_credentials"
    INSECURE_DEFAULTS = "insecure_defaults"
    MISCONFIGURATIONS = "misconfigurations"
    COMPLIANCE = "compliance"


class ComplianceFramework(Enum):
    """Compliance frameworks for IaC."""
    CIS_AWS = "cis_aws"
    CIS_AZURE = "cis_azure"
    CIS_GCP = "cis_gcp"
    CIS_KUBERNETES = "cis_kubernetes"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    SOC2 = "soc2"
    NIST_800_53 = "nist_800_53"
    GDPR = "gdpr"


@dataclass
class IaCFinding:
    """IaC security finding."""
    tool: IaCTool
    category: IaCCheckCategory
    severity: IaCSeverity
    title: str
    description: str
    file_path: str = ""
    line_number: int = 0
    resource_type: str = ""
    resource_name: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""
    compliance_mappings: List[ComplianceFramework] = field(default_factory=list)
    cve: str = ""
    references: List[str] = field(default_factory=list)
    # Human-readable impact (distinct from description / detection_reason for UI)
    impact: str = ""
    # Why the rule fired (do not duplicate description; backend avoids copying description here)
    detection_reason: str = ""
    # Per-finding 0–100 score for Threat.risk_score (agent-owned)
    risk_score: Optional[int] = None
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = None


@dataclass
class IaCResource:
    """Parsed IaC resource."""
    tool: IaCTool
    resource_type: str
    resource_name: str
    file_path: str
    line_number: int = 0
    attributes: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)


@dataclass
class IaCSecurityReport:
    """IaC security assessment report."""
    findings: List[IaCFinding] = field(default_factory=list)
    resources_scanned: int = 0
    files_scanned: int = 0
    
    # By tool
    terraform_findings: int = 0
    ansible_findings: int = 0
    pulumi_findings: int = 0
    cloudformation_findings: int = 0
    
    # By severity
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    info_count: int = 0
    
    # By category
    findings_by_category: Dict[str, int] = field(default_factory=dict)
    
    # Compliance
    compliance_violations: Dict[str, List[str]] = field(default_factory=dict)
    
    # Score
    risk_score: float = 0.0
    compliance_score: float = 0.0


# =============================================================================
# Security Rule Definitions
# =============================================================================

TERRAFORM_SECURITY_RULES = {
    # State Security
    "TF001": {
        "title": "Terraform State Contains Secrets",
        "description": "Terraform state file contains sensitive data in plain text",
        "category": IaCCheckCategory.STATE_SECURITY,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Use remote state with encryption (S3+KMS, GCS+KMS, Azure Blob+CMK)",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.SOC2],
    },
    "TF002": {
        "title": "Remote State Without Encryption",
        "description": "Remote state backend configured without encryption",
        "category": IaCCheckCategory.STATE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Enable encryption for state backend (encrypt=true for S3)",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS],
    },
    "TF003": {
        "title": "State File in Version Control",
        "description": "Terraform state file committed to version control",
        "category": IaCCheckCategory.STATE_SECURITY,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Add *.tfstate to .gitignore and use remote state",
        "compliance": [ComplianceFramework.SOC2],
    },
    
    # Provider Security
    "TF010": {
        "title": "Hardcoded Provider Credentials",
        "description": "AWS/Azure/GCP credentials hardcoded in provider block",
        "category": IaCCheckCategory.PROVIDER_SECURITY,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Use environment variables, IAM roles, or credential files",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.SOC2],
    },
    "TF011": {
        "title": "Provider Version Not Pinned",
        "description": "Provider version not pinned, allowing automatic updates",
        "category": IaCCheckCategory.PROVIDER_SECURITY,
        "severity": IaCSeverity.MEDIUM,
        "remediation": "Pin provider versions: version = \"~> 4.0\"",
        "compliance": [],
    },
    
    # Resource Security
    "TF020": {
        "title": "Security Group Allows All Traffic",
        "description": "Security group allows ingress from 0.0.0.0/0",
        "category": IaCCheckCategory.RESOURCE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Restrict CIDR blocks to specific IP ranges",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS],
    },
    "TF021": {
        "title": "S3 Bucket Public Access",
        "description": "S3 bucket configured with public access",
        "category": IaCCheckCategory.RESOURCE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Enable block_public_acls and block_public_policy",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.HIPAA],
    },
    "TF022": {
        "title": "Unencrypted Storage",
        "description": "Storage resource without encryption at rest",
        "category": IaCCheckCategory.RESOURCE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Enable encryption with customer-managed keys",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.PCI_DSS, ComplianceFramework.HIPAA],
    },
    "TF023": {
        "title": "IAM Policy Too Permissive",
        "description": "IAM policy with Action: * or Resource: *",
        "category": IaCCheckCategory.IAM_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Apply least privilege principle",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.NIST_800_53],
    },
}

ANSIBLE_SECURITY_RULES = {
    # Playbook Security
    "ANS001": {
        "title": "Hardcoded Password in Playbook",
        "description": "Plain text password in playbook or vars file",
        "category": IaCCheckCategory.PLAYBOOK_SECURITY,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Use Ansible Vault to encrypt sensitive data",
        "compliance": [ComplianceFramework.SOC2, ComplianceFramework.PCI_DSS],
    },
    "ANS002": {
        "title": "No Become Method Specified",
        "description": "Privilege escalation without explicit become method",
        "category": IaCCheckCategory.PLAYBOOK_SECURITY,
        "severity": IaCSeverity.MEDIUM,
        "remediation": "Specify become_method explicitly (sudo, su, doas)",
        "compliance": [],
    },
    "ANS003": {
        "title": "Command Module Instead of Specific Module",
        "description": "Using shell/command instead of specific module",
        "category": IaCCheckCategory.TASK_SECURITY,
        "severity": IaCSeverity.LOW,
        "remediation": "Use purpose-built modules for better idempotency and security",
        "compliance": [],
    },
    
    # Vault Security
    "ANS010": {
        "title": "Vault Password in Plain Text",
        "description": "Ansible Vault password stored in plain text file",
        "category": IaCCheckCategory.VAULT_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Use vault-password-file with proper permissions or prompt",
        "compliance": [ComplianceFramework.SOC2],
    },
    "ANS011": {
        "title": "Weak Vault Encryption",
        "description": "Vault using deprecated encryption (AES128)",
        "category": IaCCheckCategory.VAULT_SECURITY,
        "severity": IaCSeverity.MEDIUM,
        "remediation": "Re-encrypt vault with AES256",
        "compliance": [ComplianceFramework.PCI_DSS],
    },
    
    # Inventory Security
    "ANS020": {
        "title": "Credentials in Inventory",
        "description": "ansible_password or ansible_become_pass in inventory",
        "category": IaCCheckCategory.INVENTORY_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Use SSH keys and vault for credentials",
        "compliance": [ComplianceFramework.SOC2],
    },
}

PULUMI_SECURITY_RULES = {
    # Stack Security
    "PUL001": {
        "title": "Secrets in Stack Config",
        "description": "Unencrypted secrets in Pulumi stack config",
        "category": IaCCheckCategory.STACK_SECURITY,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Use pulumi config set --secret for sensitive values",
        "compliance": [ComplianceFramework.SOC2],
    },
    "PUL002": {
        "title": "State Backend Not Encrypted",
        "description": "Pulumi state stored without encryption",
        "category": IaCCheckCategory.STACK_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Use Pulumi Cloud or configure encrypted backend",
        "compliance": [ComplianceFramework.SOC2, ComplianceFramework.PCI_DSS],
    },
    
    # Secret Management
    "PUL010": {
        "title": "Hardcoded Secrets in Code",
        "description": "Secrets hardcoded in Pulumi program code",
        "category": IaCCheckCategory.SECRET_MANAGEMENT,
        "severity": IaCSeverity.CRITICAL,
        "remediation": "Use pulumi.Config().requireSecret() for secrets",
        "compliance": [ComplianceFramework.SOC2],
    },
}

CLOUDFORMATION_SECURITY_RULES = {
    # Template Security
    "CFN001": {
        "title": "NoEcho Not Used for Secrets",
        "description": "Parameter with sensitive data not marked NoEcho",
        "category": IaCCheckCategory.TEMPLATE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Add NoEcho: true to sensitive parameters",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
    "CFN002": {
        "title": "Template Injection Risk",
        "description": "Unsanitized Fn::Sub or !Sub with user input",
        "category": IaCCheckCategory.TEMPLATE_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Validate and sanitize all user inputs",
        "compliance": [],
    },
    
    # IAM Security
    "CFN010": {
        "title": "IAM Policy Wildcard Actions",
        "description": "IAM policy with Action: '*'",
        "category": IaCCheckCategory.IAM_SECURITY,
        "severity": IaCSeverity.HIGH,
        "remediation": "Specify explicit actions following least privilege",
        "compliance": [ComplianceFramework.CIS_AWS, ComplianceFramework.NIST_800_53],
    },
    "CFN011": {
        "title": "IAM Role Without Boundary",
        "description": "IAM role created without permissions boundary",
        "category": IaCCheckCategory.IAM_SECURITY,
        "severity": IaCSeverity.MEDIUM,
        "remediation": "Attach a permissions boundary to limit role scope",
        "compliance": [ComplianceFramework.CIS_AWS],
    },
    
    # Parameter Security
    "CFN020": {
        "title": "Default Value for Secret Parameter",
        "description": "Secret parameter has default value",
        "category": IaCCheckCategory.PARAMETER_SECURITY,
        "severity": IaCSeverity.MEDIUM,
        "remediation": "Remove default values from sensitive parameters",
        "compliance": [ComplianceFramework.SOC2],
    },
}

