"""
Output service for AWS Security Assessment with reproduction steps.
"""

import copy
from datetime import datetime
from typing import List, Optional, Dict

from .proto import (
    AWSSecurityOutput,
    ScanOptions,
    ScanMetadata,
    SeveritySummary,
    CategorySummary,
    ResourceTypeSummary,
    AccountSummary,
    SecurityFinding,
    SeverityLevel,
    ExploitationCommands,
    SecuritySubCategory,
)
from plugins.reproduction import ReproStep


# 🔴 AWS EXPLOITATION COMMANDS by finding sub-category
AWS_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    # S3 Issues
    "public_s3_bucket": {
        "commands": [
            "$ aws s3 ls s3://{bucket_name}/ --no-sign-request",
            "$ aws s3api get-bucket-acl --bucket {bucket_name}",
            "$ curl https://{bucket_name}.s3.amazonaws.com/"
        ],
        "description": "Verify public S3 bucket access and enumerate contents"
    },
    "s3_unencrypted": {
        "commands": [
            "$ aws s3api get-bucket-encryption --bucket {bucket_name}",
            "$ aws s3api head-object --bucket {bucket_name} --key {key}"
        ],
        "description": "Check S3 bucket encryption status"
    },
    
    # IAM Issues
    "overly_permissive_policy": {
        "commands": [
            "$ aws iam get-policy --policy-arn {policy_arn}",
            "$ aws iam get-policy-version --policy-arn {policy_arn} --version-id v1",
            "$ aws iam simulate-principal-policy --policy-source-arn {principal_arn} --action-names iam:PassRole iam:CreateAccessKey sts:AssumeRole s3:PutBucketPolicy ec2:RunInstances"
        ],
        "description": "Read-only: review policy JSON and simulate high-impact actions"
    },
    "privilege_escalation_path": {
        "commands": [
            "$ aws iam list-attached-user-policies --user-name {user_name}",
            "$ aws iam list-user-policies --user-name {user_name}",
            "$ aws iam list-groups-for-user --user-name {user_name}",
            "$ aws iam simulate-principal-policy --policy-source-arn {principal_arn} --action-names iam:AttachUserPolicy iam:PutUserPolicy iam:CreateAccessKey sts:AssumeRole"
        ],
        "description": "Read-only: map principal policies and simulate sensitive IAM actions"
    },
    "access_key_old": {
        "commands": [
            "$ aws iam list-access-keys --user-name {user_name}",
            "$ aws iam get-access-key-last-used --access-key-id {access_key_id}"
        ],
        "description": "Check old access key usage"
    },
    "mfa_not_enabled": {
        "commands": [
            "$ aws iam list-mfa-devices --user-name {user_name}",
            "$ aws iam get-login-profile --user-name {user_name}"
        ],
        "description": "Verify MFA status for IAM user"
    },
    "root_account_usage": {
        "commands": [
            "$ aws iam generate-credential-report",
            "$ aws iam get-credential-report --output text --query Content | base64 -d | awk -F, 'NR==1 || $1==\"<root_account>\"' | head -5"
        ],
        "description": "Credential report: confirm root row and password_last_used / access_key fields"
    },
    
    # EC2/Network Issues  
    "security_group_open": {
        "commands": [
            "$ aws ec2 describe-security-groups --group-ids {sg_id}",
            "$ nmap -sV -p {port} {public_ip}",
            "$ nc -zv {public_ip} {port}"
        ],
        "description": "Verify open security group rules and test connectivity"
    },
    "public_instance": {
        "commands": [
            "$ aws ec2 describe-instances --instance-ids {instance_id}",
            "$ curl http://{public_ip}/",
            "$ ssh -o BatchMode=yes ec2-user@{public_ip}"
        ],
        "description": "Check publicly accessible EC2 instance"
    },
    "imdsv1_enabled": {
        "commands": [
            "$ curl -s http://169.254.169.254/latest/meta-data/",
            "$ curl -s http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "$ aws ec2 describe-instances --instance-ids {instance_id} --query 'Reservations[].Instances[].MetadataOptions'"
        ],
        "description": "Demonstrate IMDSv1 credential theft risk"
    },
    
    # Logging Issues
    "cloudtrail_disabled": {
        "commands": [
            "$ aws cloudtrail describe-trails",
            "$ aws cloudtrail get-trail-status --name {trail_name}"
        ],
        "description": "Verify CloudTrail is disabled"
    },
    "guardduty_disabled": {
        "commands": [
            "$ aws guardduty list-detectors",
            "$ aws guardduty get-detector --detector-id {detector_id}"
        ],
        "description": "Check GuardDuty status"
    },
    
    # Lambda Issues
    "lambda_public": {
        "commands": [
            "$ aws lambda get-policy --function-name {function_name}",
            "$ aws lambda get-function-url-config --function-name {function_name} 2>/dev/null || aws lambda get-function --function-name {function_name} --query 'Configuration.[FunctionArn,LastModified]'"
        ],
        "description": "Read-only: resource policy and function URL configuration"
    },
    "lambda_env_secrets": {
        "commands": [
            "$ aws lambda get-function-configuration --function-name {function_name} --query 'Environment.Variables'"
        ],
        "description": "Check Lambda environment variables for secrets"
    },
    
    # RDS Issues
    "rds_public": {
        "commands": [
            "$ aws rds describe-db-instances --db-instance-identifier {db_id}",
            "$ nc -zv {endpoint} {port}",
            "$ mysql -h {endpoint} -u admin -p"
        ],
        "description": "Test publicly accessible RDS instance"
    },
    "rds_unencrypted": {
        "commands": [
            "$ aws rds describe-db-instances --db-instance-identifier {db_id} --query 'DBInstances[].StorageEncrypted'"
        ],
        "description": "Check RDS encryption status"
    },
    
    # Default commands for unknown types
    "default": {
        "commands": [
            "$ aws sts get-caller-identity",
            "$ aws ec2 describe-regions --query 'Regions[].RegionName' --output text | tr '\\t' '\\n' | head -8",
            "$ aws resourcegroupstaggingapi get-resources --resources-per-page 100 --query 'ResourceTagMappingList[0:20].ResourceARN' --output text 2>/dev/null || aws configure list"
        ],
        "description": "Identify account and enumerate tagged resources (requires tagging API permission)"
    }
}

# Enum SecuritySubCategory uses values like public_bucket; legacy dict keys stay as aliases.
_AWS_SUBCAT_TEMPLATE_SOURCE: Dict[str, str] = {
    "public_bucket": "public_s3_bucket",
    "public_object": "public_s3_bucket",
    "block_public_access_disabled": "public_s3_bucket",
    "bucket_not_encrypted": "s3_unencrypted",
    "versioning_disabled": "s3_unencrypted",
    "bucket_logging_disabled": "cloudtrail_disabled",
    "access_key_unused": "access_key_old",
    "cross_account_access": "overly_permissive_policy",
    "password_policy_weak": "mfa_not_enabled",
    "trust_policy_risky": "overly_permissive_policy",
    "public_access": "public_instance",
    "unencrypted_volume": "public_instance",
    "user_data_secrets": "lambda_env_secrets",
    "default_vpc": "public_instance",
    "public_ami": "public_instance",
    "public_snapshot": "public_instance",
    "public_database": "rds_public",
    "database_not_encrypted": "rds_unencrypted",
    "database_no_backup": "rds_public",
    "database_no_ssl": "rds_public",
    "open_security_group": "security_group_open",
    "open_nacl": "security_group_open",
    "vpc_flow_logs_disabled": "cloudtrail_disabled",
    "no_waf": "security_group_open",
    "weak_ssl_policy": "security_group_open",
    "eks_public_endpoint": "public_instance",
    "eks_secrets_not_encrypted": "s3_unencrypted",
    "eks_logging_disabled": "cloudtrail_disabled",
    "privileged_pod": "lambda_public",
    "host_namespace": "lambda_public",
    "lambda_admin_role": "privilege_escalation_path",
    "cloudtrail_not_encrypted": "cloudtrail_disabled",
    "config_disabled": "guardduty_disabled",
    "no_security_alerts": "guardduty_disabled",
    "hardcoded_credentials": "lambda_env_secrets",
    "secret_not_rotated": "access_key_old",
    "kms_key_exposed": "overly_permissive_policy",
    "privileged_container": "lambda_public",
    "ecr_public": "public_s3_bucket",
    "task_role_admin": "privilege_escalation_path",
    "scheduled_persistence": "lambda_public",
    "lambda_persistence": "lambda_public",
    "ssm_persistence": "lambda_public",
    "data_transfer_risk": "public_s3_bucket",
    "cross_account_export": "overly_permissive_policy",
    "external_subscription": "overly_permissive_policy",
}


def _expand_aws_exploitation_commands() -> None:
    for member in SecuritySubCategory:
        key = member.value
        if key in AWS_EXPLOITATION_COMMANDS:
            continue
        src = _AWS_SUBCAT_TEMPLATE_SOURCE.get(key, "default")
        if src not in AWS_EXPLOITATION_COMMANDS:
            src = "default"
        AWS_EXPLOITATION_COMMANDS[key] = copy.deepcopy(AWS_EXPLOITATION_COMMANDS[src])


_expand_aws_exploitation_commands()


class OutputService:
    """Build AWSSecurityOutput and reproduction steps."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _build_commands_for_finding(self, f: SecurityFinding) -> Optional[ExploitationCommands]:
        """Generate exploitation commands based on finding type."""
        sub_cat = f.sub_category.value if hasattr(f.sub_category, 'value') else str(f.sub_category)
        cmd_template = AWS_EXPLOITATION_COMMANDS.get(sub_cat, AWS_EXPLOITATION_COMMANDS["default"])
        
        # Get resource info for replacements
        resource_arn = getattr(f.resource, "arn", "") or ""
        resource_id = getattr(f.resource, "resource_id", "") or ""
        resource_name = getattr(f.resource, "name", "") or resource_id
        account_id = getattr(f.resource, "account_id", "") or ""
        region = getattr(f.resource, "region", "us-east-1") or "us-east-1"
        
        # Extract specific identifiers from evidence or resource_config
        bucket_name = ""
        sg_id = ""
        instance_id = ""
        user_name = ""
        policy_arn = ""
        function_name = ""
        db_id = ""
        
        if f.evidence:
            bucket_name = f.evidence.get("bucket_name", "")
            sg_id = f.evidence.get("security_group_id", "")
            instance_id = f.evidence.get("instance_id", "")
            user_name = f.evidence.get("user_name", "")
            policy_arn = f.evidence.get("policy_arn", "")
            function_name = f.evidence.get("function_name", "")
            db_id = f.evidence.get("db_instance_id", "")
        
        # Build commands with replacements
        commands = []
        for cmd in cmd_template.get("commands", []):
            cmd_replaced = cmd.replace("{bucket_name}", bucket_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{sg_id}", sg_id or resource_id)
            cmd_replaced = cmd_replaced.replace("{instance_id}", instance_id or resource_id)
            cmd_replaced = cmd_replaced.replace("{user_name}", user_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{policy_arn}", policy_arn or resource_arn)
            cmd_replaced = cmd_replaced.replace("{function_name}", function_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{db_id}", db_id or resource_id)
            cmd_replaced = cmd_replaced.replace("{resource_id}", resource_id)
            cmd_replaced = cmd_replaced.replace("{resource_name}", resource_name)
            cmd_replaced = cmd_replaced.replace("{resource}", resource_name)
            cmd_replaced = cmd_replaced.replace("{service}", "iam")  # Default
            cmd_replaced = cmd_replaced.replace("{public_ip}", f.evidence.get("public_ip", "x.x.x.x") if f.evidence else "x.x.x.x")
            cmd_replaced = cmd_replaced.replace("{port}", str(f.evidence.get("port", 22)) if f.evidence else "22")
            cmd_replaced = cmd_replaced.replace("{principal_arn}", resource_arn)
            cmd_replaced = cmd_replaced.replace("{access_key_id}", f.evidence.get("access_key_id", "") if f.evidence else "")
            cmd_replaced = cmd_replaced.replace("{endpoint}", f.evidence.get("endpoint", "") if f.evidence else "")
            cmd_replaced = cmd_replaced.replace("{trail_name}", resource_name)
            cmd_replaced = cmd_replaced.replace("{detector_id}", resource_id)
            cmd_replaced = cmd_replaced.replace("{key}", "example-object-key")
            commands.append(cmd_replaced)
        
        return ExploitationCommands(
            server=resource_name or resource_arn,
            ip=f"AWS:{region}" if region else "AWS:global",
            commands=commands,
            description=cmd_template.get("description", f"Verify/exploit {f.name}")
        )

    def _build_steps_for_finding(self, f: SecurityFinding) -> List[ReproStep]:
        target = getattr(f.resource, "arn", None) or getattr(f.resource, "resource_id", None)
        action = f"Verify misconfig/vuln on {target}" if target else f"Verify finding {f.id}"
        evidence = f.evidence or f.resource_config
        preconditions = ["AWS credentials with read access"]
        return [
            ReproStep(
                title=f.name,
                preconditions=preconditions,
                target=target or f.name,
                action=action,
                payload=None,
                expected_outcome=f.description,
                evidence=str(evidence) if evidence else None,
                tooling=["aws cli", "console"],
                safety="Read-only verification; if changing resources, do so in lab",
                cleanup="No cleanup for read-only; revert if any change was made",
            )
        ]

    def _attach_reproduction_steps(self) -> List[ReproStep]:
        collected: List[ReproStep] = []
        for f in getattr(self.plugin, "findings", []) or []:
            # 🔴 Attach commands if not present
            if not getattr(f, "commands", None):
                f.commands = self._build_commands_for_finding(f)
            
            # Attach reproduction steps
            if getattr(f, "reproduction_steps", None):
                collected.extend(f.reproduction_steps)
                continue
            f.reproduction_steps = self._build_steps_for_finding(f)
            collected.extend(f.reproduction_steps)
        return collected

    def create_output(
        self,
        options: ScanOptions,
        recommendations: List[str],
        quick_wins: List[str],
    ) -> AWSSecurityOutput:
        completed = datetime.utcnow()
        duration = (completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0

        severity_summary = SeveritySummary(
            critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
            high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            medium=len([f for f in self.plugin.findings if f.severity == SeverityLevel.MEDIUM]),
            low=len([f for f in self.plugin.findings if f.severity == SeverityLevel.LOW]),
            info=len([f for f in self.plugin.findings if f.severity == SeverityLevel.INFO]),
            total=len(self.plugin.findings),
        )

        category_summaries = []
        for cat in getattr(self.plugin, "categories", []) or []:
            cat_findings = [f for f in self.plugin.findings if f.category == cat]
            if cat_findings:
                category_summaries.append(
                    CategorySummary(
                        category=cat,
                        findings_count=len(cat_findings),
                        critical=len([f for f in cat_findings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in cat_findings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        resource_summaries = []
        for rtype in getattr(self.plugin, "resource_types", []) or []:
            rfindings = [f for f in self.plugin.findings if f.resource and f.resource.resource_type == rtype]
            if rfindings:
                resource_summaries.append(
                    ResourceTypeSummary(
                        resource_type=rtype,
                        findings_count=len(rfindings),
                        critical=len([f for f in rfindings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in rfindings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        account_summaries = [
            AccountSummary(
                account_id=getattr(self.plugin, "account_id", "unknown"),
                findings_count=len(self.plugin.findings),
                critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
                high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            )
        ]

        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            started_at=self.plugin.scan_start or completed,
            completed_at=completed,
            duration_seconds=duration,
            target_url=getattr(options, "target_account", "aws"),
            api_type="aws",
            endpoints_discovered=0,
            endpoints_tested=0,
            tests_executed=len(self.plugin.findings),
            requests_sent=getattr(self.plugin, "requests_sent", 0),
            total_findings=len(self.plugin.findings),
        )

        repro_steps = self._attach_reproduction_steps()

        return AWSSecurityOutput(
            metadata=metadata,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            resource_type_summaries=resource_summaries,
            account_summaries=account_summaries,
            findings=self.plugin.findings,
            critical_findings=[f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL],
            recommendations=recommendations,
            quick_wins=quick_wins,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            reproduction_steps=repro_steps or None,
        )
