"""
AWS Security Assessment Plugin - Pydantic Models

This module defines all data structures used by the AWS Security Assessment Plugin
for detecting and reporting security misconfigurations in Amazon Web Services.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional, Set
from pydantic import BaseModel, Field
from plugins.reproduction import ReproStep


# =============================================================================
# Enumerations
# =============================================================================

class SeverityLevel(str, Enum):
    """Severity classification for security findings."""
    CRITICAL = "critical"  # Public data exposure, privilege escalation, active threats
    HIGH = "high"          # Missing encryption, broad access, disabled logging
    MEDIUM = "medium"      # Missing best practices, potential risks
    LOW = "low"            # Informational, optimization opportunities
    INFO = "info"          # Non-security findings, baseline information


class AWSResourceType(str, Enum):
    """AWS resource types covered by assessment."""
    # Organizations & Accounts
    ORGANIZATION = "organization"
    ORGANIZATIONAL_UNIT = "organizational_unit"
    ACCOUNT = "account"
    SCP = "service_control_policy"
    
    # IAM
    IAM_USER = "iam_user"
    IAM_GROUP = "iam_group"
    IAM_ROLE = "iam_role"
    IAM_POLICY = "iam_policy"
    IAM_ACCESS_KEY = "iam_access_key"
    IAM_MFA_DEVICE = "iam_mfa_device"
    IAM_INSTANCE_PROFILE = "iam_instance_profile"
    IAM_SAML_PROVIDER = "iam_saml_provider"
    IAM_OIDC_PROVIDER = "iam_oidc_provider"
    IAM_PASSWORD_POLICY = "iam_password_policy"
    
    # EC2 & Compute
    EC2_INSTANCE = "ec2_instance"
    EC2_SECURITY_GROUP = "ec2_security_group"
    EC2_KEY_PAIR = "ec2_key_pair"
    EC2_AMI = "ec2_ami"
    EC2_SNAPSHOT = "ec2_snapshot"
    EC2_VOLUME = "ec2_volume"
    EC2_LAUNCH_TEMPLATE = "ec2_launch_template"
    EC2_AUTO_SCALING_GROUP = "ec2_auto_scaling_group"
    
    # VPC & Networking
    VPC = "vpc"
    SUBNET = "subnet"
    ROUTE_TABLE = "route_table"
    INTERNET_GATEWAY = "internet_gateway"
    NAT_GATEWAY = "nat_gateway"
    VPC_ENDPOINT = "vpc_endpoint"
    NETWORK_ACL = "network_acl"
    VPC_PEERING = "vpc_peering"
    TRANSIT_GATEWAY = "transit_gateway"
    VPN_CONNECTION = "vpn_connection"
    DIRECT_CONNECT = "direct_connect"
    
    # Load Balancing
    ALB = "alb"
    NLB = "nlb"
    CLB = "clb"
    TARGET_GROUP = "target_group"
    
    # S3
    S3_BUCKET = "s3_bucket"
    S3_OBJECT = "s3_object"
    S3_ACCESS_POINT = "s3_access_point"
    
    # Databases
    RDS_INSTANCE = "rds_instance"
    RDS_CLUSTER = "rds_cluster"
    RDS_SNAPSHOT = "rds_snapshot"
    DYNAMODB_TABLE = "dynamodb_table"
    ELASTICACHE_CLUSTER = "elasticache_cluster"
    REDSHIFT_CLUSTER = "redshift_cluster"
    DOCUMENTDB_CLUSTER = "documentdb_cluster"
    NEPTUNE_CLUSTER = "neptune_cluster"
    
    # Containers
    ECS_CLUSTER = "ecs_cluster"
    ECS_SERVICE = "ecs_service"
    ECS_TASK_DEFINITION = "ecs_task_definition"
    ECR_REPOSITORY = "ecr_repository"
    EKS_CLUSTER = "eks_cluster"
    EKS_NODE_GROUP = "eks_node_group"
    EKS_FARGATE_PROFILE = "eks_fargate_profile"
    
    # Serverless
    LAMBDA_FUNCTION = "lambda_function"
    LAMBDA_LAYER = "lambda_layer"
    API_GATEWAY = "api_gateway"
    API_GATEWAY_STAGE = "api_gateway_stage"
    STEP_FUNCTION = "step_function"
    
    # Messaging
    SQS_QUEUE = "sqs_queue"
    SNS_TOPIC = "sns_topic"
    SNS_SUBSCRIPTION = "sns_subscription"
    EVENTBRIDGE_RULE = "eventbridge_rule"
    EVENTBRIDGE_BUS = "eventbridge_bus"
    KINESIS_STREAM = "kinesis_stream"
    KINESIS_FIREHOSE = "kinesis_firehose"
    
    # Security & Secrets
    KMS_KEY = "kms_key"
    SECRETS_MANAGER_SECRET = "secrets_manager_secret"
    SSM_PARAMETER = "ssm_parameter"
    ACM_CERTIFICATE = "acm_certificate"
    WAF_WEB_ACL = "waf_web_acl"
    SHIELD_PROTECTION = "shield_protection"
    
    # Monitoring & Logging
    CLOUDTRAIL_TRAIL = "cloudtrail_trail"
    CLOUDWATCH_LOG_GROUP = "cloudwatch_log_group"
    CLOUDWATCH_ALARM = "cloudwatch_alarm"
    CONFIG_RULE = "config_rule"
    GUARDDUTY_DETECTOR = "guardduty_detector"
    SECURITY_HUB = "security_hub"
    ACCESS_ANALYZER = "access_analyzer"
    MACIE_SESSION = "macie_session"
    
    # IaC & Deployment
    CLOUDFORMATION_STACK = "cloudformation_stack"
    CODEBUILD_PROJECT = "codebuild_project"
    CODEPIPELINE = "codepipeline"
    
    # Analytics
    ATHENA_WORKGROUP = "athena_workgroup"
    EMR_CLUSTER = "emr_cluster"
    GLUE_JOB = "glue_job"
    OPENSEARCH_DOMAIN = "opensearch_domain"
    
    # Other
    ROUTE53_HOSTED_ZONE = "route53_hosted_zone"
    CLOUDFRONT_DISTRIBUTION = "cloudfront_distribution"
    ELASTIC_BEANSTALK = "elastic_beanstalk"
    SAGEMAKER_NOTEBOOK = "sagemaker_notebook"
    UNKNOWN = "unknown"


class SecurityCategory(str, Enum):
    """
    Security assessment categories aligned with MITRE ATT&CK Cloud Matrix.
    """
    # MITRE ATT&CK Tactics
    INITIAL_ACCESS = "initial_access"           # T1190, T1199
    EXECUTION = "execution"                     # T1059, T1648
    PERSISTENCE = "persistence"                 # T1098, T1136
    PRIVILEGE_ESCALATION = "privilege_escalation"  # T1078, T1548
    DEFENSE_EVASION = "defense_evasion"         # T1562, T1578
    CREDENTIAL_ACCESS = "credential_access"     # T1528, T1552
    DISCOVERY = "discovery"                     # T1580, T1087
    LATERAL_MOVEMENT = "lateral_movement"       # T1550
    COLLECTION = "collection"                   # T1530, T1119
    EXFILTRATION = "exfiltration"               # T1537, T1567
    IMPACT = "impact"                           # T1485, T1486
    
    # AWS-Specific Categories
    IAM_MISCONFIGURATION = "iam_misconfiguration"
    NETWORK_EXPOSURE = "network_exposure"
    DATA_EXPOSURE = "data_exposure"
    ENCRYPTION_WEAKNESS = "encryption_weakness"
    LOGGING_GAP = "logging_gap"
    COMPLIANCE_VIOLATION = "compliance_violation"
    CONFIGURATION_DRIFT = "configuration_drift"
    RESOURCE_EXPOSURE = "resource_exposure"


class SecuritySubCategory(str, Enum):
    """Specific security issue sub-categories."""
    # IAM Issues
    ROOT_ACCOUNT_USAGE = "root_account_usage"
    MFA_NOT_ENABLED = "mfa_not_enabled"
    ACCESS_KEY_OLD = "access_key_old"
    ACCESS_KEY_UNUSED = "access_key_unused"
    OVERLY_PERMISSIVE_POLICY = "overly_permissive_policy"
    PRIVILEGE_ESCALATION_PATH = "privilege_escalation_path"
    CROSS_ACCOUNT_ACCESS = "cross_account_access"
    PASSWORD_POLICY_WEAK = "password_policy_weak"
    TRUST_POLICY_RISKY = "trust_policy_risky"
    PUBLIC_ACCESS = "public_access"
    
    # EC2 Issues
    IMDSV1_ENABLED = "imdsv1_enabled"
    PUBLIC_INSTANCE = "public_instance"
    SECURITY_GROUP_OPEN = "security_group_open"
    UNENCRYPTED_VOLUME = "unencrypted_volume"
    USER_DATA_SECRETS = "user_data_secrets"
    DEFAULT_VPC = "default_vpc"
    PUBLIC_AMI = "public_ami"
    PUBLIC_SNAPSHOT = "public_snapshot"
    
    # S3 Issues
    PUBLIC_BUCKET = "public_bucket"
    PUBLIC_OBJECT = "public_object"
    BUCKET_NOT_ENCRYPTED = "bucket_not_encrypted"
    BUCKET_LOGGING_DISABLED = "bucket_logging_disabled"
    VERSIONING_DISABLED = "versioning_disabled"
    BLOCK_PUBLIC_ACCESS_DISABLED = "block_public_access_disabled"
    
    # Database Issues
    PUBLIC_DATABASE = "public_database"
    DATABASE_NOT_ENCRYPTED = "database_not_encrypted"
    DATABASE_NO_BACKUP = "database_no_backup"
    DATABASE_NO_SSL = "database_no_ssl"
    
    # Network Issues
    OPEN_SECURITY_GROUP = "open_security_group"
    OPEN_NACL = "open_nacl"
    VPC_FLOW_LOGS_DISABLED = "vpc_flow_logs_disabled"
    NO_WAF = "no_waf"
    WEAK_SSL_POLICY = "weak_ssl_policy"
    
    # EKS Issues
    EKS_PUBLIC_ENDPOINT = "eks_public_endpoint"
    EKS_SECRETS_NOT_ENCRYPTED = "eks_secrets_not_encrypted"
    EKS_LOGGING_DISABLED = "eks_logging_disabled"
    PRIVILEGED_POD = "privileged_pod"
    HOST_NAMESPACE = "host_namespace"
    
    # Lambda Issues
    LAMBDA_PUBLIC = "lambda_public"
    LAMBDA_ENV_SECRETS = "lambda_env_secrets"
    LAMBDA_ADMIN_ROLE = "lambda_admin_role"
    
    # Logging Issues
    CLOUDTRAIL_DISABLED = "cloudtrail_disabled"
    CLOUDTRAIL_NOT_ENCRYPTED = "cloudtrail_not_encrypted"
    GUARDDUTY_DISABLED = "guardduty_disabled"
    CONFIG_DISABLED = "config_disabled"
    NO_SECURITY_ALERTS = "no_security_alerts"
    
    # Secrets Issues
    HARDCODED_CREDENTIALS = "hardcoded_credentials"
    SECRET_NOT_ROTATED = "secret_not_rotated"
    KMS_KEY_EXPOSED = "kms_key_exposed"
    
    # Container Issues
    PRIVILEGED_CONTAINER = "privileged_container"
    ECR_PUBLIC = "ecr_public"
    TASK_ROLE_ADMIN = "task_role_admin"
    
    # Persistence
    SCHEDULED_PERSISTENCE = "scheduled_persistence"
    LAMBDA_PERSISTENCE = "lambda_persistence"
    SSM_PERSISTENCE = "ssm_persistence"
    
    # Exfiltration
    DATA_TRANSFER_RISK = "data_transfer_risk"
    CROSS_ACCOUNT_EXPORT = "cross_account_export"
    EXTERNAL_SUBSCRIPTION = "external_subscription"


class FindingStatus(str, Enum):
    """Status of security finding."""
    ACTIVE = "active"             # Issue exists and is exploitable
    SUPPRESSED = "suppressed"     # Acknowledged but not fixed
    REMEDIATED = "remediated"     # Issue has been fixed
    FALSE_POSITIVE = "false_positive"  # Not a real issue
    EXCEPTION = "exception"       # Accepted risk with justification


class ComplianceFramework(str, Enum):
    """Compliance frameworks for mapping findings."""
    CIS_AWS = "cis_aws"
    AWS_FOUNDATIONAL = "aws_foundational"
    NIST_800_53 = "nist_800_53"
    NIST_CSF = "nist_csf"
    SOC2 = "soc2"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    GDPR = "gdpr"
    ISO_27001 = "iso_27001"
    FedRAMP = "fedramp"


class AWSRegion(str, Enum):
    """AWS regions."""
    US_EAST_1 = "us-east-1"
    US_EAST_2 = "us-east-2"
    US_WEST_1 = "us-west-1"
    US_WEST_2 = "us-west-2"
    EU_WEST_1 = "eu-west-1"
    EU_WEST_2 = "eu-west-2"
    EU_WEST_3 = "eu-west-3"
    EU_CENTRAL_1 = "eu-central-1"
    EU_NORTH_1 = "eu-north-1"
    AP_NORTHEAST_1 = "ap-northeast-1"
    AP_NORTHEAST_2 = "ap-northeast-2"
    AP_NORTHEAST_3 = "ap-northeast-3"
    AP_SOUTHEAST_1 = "ap-southeast-1"
    AP_SOUTHEAST_2 = "ap-southeast-2"
    AP_SOUTH_1 = "ap-south-1"
    SA_EAST_1 = "sa-east-1"
    CA_CENTRAL_1 = "ca-central-1"
    ME_SOUTH_1 = "me-south-1"
    AF_SOUTH_1 = "af-south-1"
    GLOBAL = "global"


# =============================================================================
# Supporting Models
# =============================================================================

class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute.
    """
    server: Optional[str] = Field(None, description="Target server/hostname/resource")
    ip: Optional[str] = Field(None, description="Target IP address or AWS endpoint")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class MitreAttackReference(BaseModel):
    """MITRE ATT&CK Cloud Matrix reference."""
    tactic: str = Field(..., description="ATT&CK tactic (e.g., 'Persistence')")
    technique_id: str = Field(..., description="Technique ID (e.g., 'T1078')")
    technique_name: str = Field(..., description="Technique name")
    sub_technique_id: Optional[str] = Field(None, description="Sub-technique ID")
    sub_technique_name: Optional[str] = Field(None, description="Sub-technique name")
    url: Optional[str] = Field(None, description="Link to ATT&CK page")


class ComplianceMapping(BaseModel):
    """Compliance framework mapping for a finding."""
    framework: ComplianceFramework = Field(..., description="Compliance framework")
    control_id: str = Field(..., description="Control ID (e.g., 'CIS 1.1')")
    control_name: str = Field(..., description="Control name/description")
    requirement: Optional[str] = Field(None, description="Specific requirement")


class AWSResourceIdentifier(BaseModel):
    """Unique identifier for an AWS resource."""
    resource_type: AWSResourceType = Field(..., description="Resource type")
    account_id: str = Field(..., description="AWS account ID")
    region: Optional[str] = Field(None, description="AWS region")
    arn: Optional[str] = Field(None, description="Full resource ARN")
    resource_id: Optional[str] = Field(None, description="Resource ID")
    name: Optional[str] = Field(None, description="Resource name")
    
    # Additional context
    tags: Optional[Dict[str, str]] = Field(None, description="Resource tags")
    creation_time: Optional[datetime] = Field(None, description="Resource creation time")
    
    # Organization context
    organization_id: Optional[str] = Field(None, description="Organization ID")
    organizational_unit_id: Optional[str] = Field(None, description="OU ID")


class IAMPolicyDocument(BaseModel):
    """IAM policy document analysis."""
    policy_name: str = Field(..., description="Policy name")
    policy_arn: Optional[str] = Field(None, description="Policy ARN")
    policy_type: str = Field(..., description="Type: managed, inline, resource")
    version: Optional[str] = Field(None, description="Policy version")
    
    # Analysis results
    has_admin_access: bool = Field(False, description="Has full admin access")
    has_wildcard_resource: bool = Field(False, description="Uses Resource: *")
    has_wildcard_action: bool = Field(False, description="Uses Action: *")
    dangerous_actions: Optional[List[str]] = Field(None, description="Dangerous actions found")
    allows_privilege_escalation: bool = Field(False, description="Enables privilege escalation")
    escalation_paths: Optional[List[str]] = Field(None, description="Escalation methods")
    
    # Raw content
    document: Optional[Dict[str, Any]] = Field(None, description="Full policy document")


class IAMUserInfo(BaseModel):
    """IAM user details for analysis."""
    user_name: str = Field(..., description="IAM user name")
    user_arn: str = Field(..., description="User ARN")
    user_id: str = Field(..., description="User ID")
    account_id: str = Field(..., description="Account ID")
    
    # Access configuration
    has_console_access: bool = Field(False, description="Has console password")
    has_programmatic_access: bool = Field(False, description="Has access keys")
    mfa_enabled: bool = Field(False, description="MFA is enabled")
    mfa_type: Optional[str] = Field(None, description="MFA type: virtual, hardware, u2f")
    
    # Access keys
    access_key_count: int = Field(0, description="Number of access keys")
    access_keys_info: Optional[List[Dict[str, Any]]] = Field(None, description="Access key details")
    oldest_access_key_age_days: Optional[int] = Field(None, description="Age of oldest key")
    
    # Activity
    password_last_used: Optional[datetime] = Field(None, description="Last console login")
    last_activity: Optional[datetime] = Field(None, description="Last API activity")
    
    # Permissions
    groups: Optional[List[str]] = Field(None, description="Group memberships")
    attached_policies: Optional[List[str]] = Field(None, description="Attached managed policies")
    inline_policies: Optional[List[str]] = Field(None, description="Inline policy names")
    effective_permissions: Optional[List[str]] = Field(None, description="Effective permissions")


class IAMRoleInfo(BaseModel):
    """IAM role details for analysis."""
    role_name: str = Field(..., description="Role name")
    role_arn: str = Field(..., description="Role ARN")
    role_id: str = Field(..., description="Role ID")
    account_id: str = Field(..., description="Account ID")
    
    # Trust policy analysis
    trusted_principals: Optional[List[str]] = Field(None, description="Trusted principals")
    trusted_services: Optional[List[str]] = Field(None, description="Trusted AWS services")
    trusted_accounts: Optional[List[str]] = Field(None, description="Trusted AWS accounts")
    allows_any_principal: bool = Field(False, description="Allows * principal")
    has_external_id: bool = Field(False, description="Requires external ID")
    trust_conditions: Optional[Dict[str, Any]] = Field(None, description="Trust conditions")
    
    # Permissions
    attached_policies: Optional[List[str]] = Field(None, description="Attached managed policies")
    inline_policies: Optional[List[str]] = Field(None, description="Inline policy names")
    has_admin_access: bool = Field(False, description="Has admin access")
    
    # Usage
    last_used_time: Optional[datetime] = Field(None, description="Last role usage")
    last_used_region: Optional[str] = Field(None, description="Region of last usage")
    
    # Instance profile
    instance_profile_arn: Optional[str] = Field(None, description="Linked instance profile")


class SecurityGroupInfo(BaseModel):
    """Security group details for analysis."""
    group_id: str = Field(..., description="Security group ID")
    group_name: str = Field(..., description="Security group name")
    vpc_id: Optional[str] = Field(None, description="VPC ID")
    description: Optional[str] = Field(None, description="Description")
    
    # Inbound rules analysis
    allows_ssh_from_anywhere: bool = Field(False, description="SSH from 0.0.0.0/0")
    allows_rdp_from_anywhere: bool = Field(False, description="RDP from 0.0.0.0/0")
    allows_all_from_anywhere: bool = Field(False, description="All traffic from 0.0.0.0/0")
    open_ports_from_anywhere: Optional[List[int]] = Field(None, description="Open ports from anywhere")
    
    # Outbound rules analysis
    allows_all_egress: bool = Field(False, description="All outbound allowed")
    
    # Usage
    attached_to: Optional[List[str]] = Field(None, description="Resources using this SG")
    is_default: bool = Field(False, description="Is default VPC security group")
    
    # Rules
    inbound_rules: Optional[List[Dict[str, Any]]] = Field(None, description="Inbound rules")
    outbound_rules: Optional[List[Dict[str, Any]]] = Field(None, description="Outbound rules")


class S3BucketInfo(BaseModel):
    """S3 bucket details for analysis."""
    bucket_name: str = Field(..., description="Bucket name")
    bucket_arn: str = Field(..., description="Bucket ARN")
    account_id: str = Field(..., description="Account ID")
    region: str = Field(..., description="Bucket region")
    
    # Public access
    is_public: bool = Field(False, description="Bucket is publicly accessible")
    public_access_type: Optional[str] = Field(None, description="Type: acl, policy, both")
    block_public_access: Optional[Dict[str, bool]] = Field(None, description="Block public access settings")
    
    # Encryption
    encryption_enabled: bool = Field(False, description="Server-side encryption enabled")
    encryption_type: Optional[str] = Field(None, description="SSE-S3, SSE-KMS, SSE-C")
    kms_key_id: Optional[str] = Field(None, description="KMS key ARN if used")
    
    # Logging & versioning
    logging_enabled: bool = Field(False, description="Access logging enabled")
    versioning_enabled: bool = Field(False, description="Versioning enabled")
    mfa_delete: bool = Field(False, description="MFA delete enabled")
    
    # Replication
    replication_enabled: bool = Field(False, description="Cross-region replication")
    replication_destination: Optional[str] = Field(None, description="Replication destination")
    
    # Policy analysis
    bucket_policy_summary: Optional[str] = Field(None, description="Policy summary")
    allows_cross_account: bool = Field(False, description="Allows cross-account access")


class PrivilegeEscalationPath(BaseModel):
    """Detected privilege escalation path."""
    source_identity: str = Field(..., description="Starting identity (user/role ARN)")
    target_identity: str = Field(..., description="Target identity to escalate to")
    escalation_method: str = Field(..., description="Method of escalation")
    required_permissions: List[str] = Field(default_factory=list, description="Permissions needed")
    steps: List[str] = Field(default_factory=list, description="Step-by-step path")
    impact: str = Field(..., description="Impact if exploited")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence score")


class ExfiltrationPath(BaseModel):
    """Detected data exfiltration path."""
    source_resource: str = Field(..., description="Source resource with data")
    source_arn: Optional[str] = Field(None, description="Source resource ARN")
    destination: str = Field(..., description="Potential destination")
    destination_account: Optional[str] = Field(None, description="External account ID")
    method: str = Field(..., description="Exfiltration method")
    data_type: Optional[str] = Field(None, description="Type of data at risk")
    permissions_required: List[str] = Field(default_factory=list, description="Permissions needed")
    mitigations: Optional[List[str]] = Field(None, description="Recommended mitigations")


class PersistenceMechanism(BaseModel):
    """Detected or potential persistence mechanism."""
    mechanism_type: str = Field(..., description="Type of persistence")
    resource_arn: str = Field(..., description="Resource ARN used for persistence")
    resource_name: Optional[str] = Field(None, description="Resource name")
    execution_trigger: str = Field(..., description="What triggers execution")
    execution_role: Optional[str] = Field(None, description="Role used for execution")
    schedule: Optional[str] = Field(None, description="Schedule expression if applicable")
    target: Optional[str] = Field(None, description="Target of execution")
    detected_payload: Optional[str] = Field(None, description="Suspicious payload if found")
    is_suspicious: bool = Field(False, description="Whether appears malicious")
    legitimate_use_case: Optional[str] = Field(None, description="Potential legitimate use")


class IoC(BaseModel):
    """Indicator of Compromise extracted from finding."""
    ioc_type: str = Field(..., description="Type: ip, domain, url, email, hash, access_key")
    value: str = Field(..., description="IoC value")
    context: Optional[str] = Field(None, description="Context where found")
    first_seen: Optional[datetime] = Field(None, description="First observed")
    last_seen: Optional[datetime] = Field(None, description="Last observed")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence 0-1")


class EC2InstanceInfo(BaseModel):
    """EC2 instance details for analysis."""
    instance_id: str = Field(..., description="Instance ID")
    instance_arn: Optional[str] = Field(None, description="Instance ARN")
    instance_type: str = Field(..., description="Instance type")
    account_id: str = Field(..., description="Account ID")
    region: str = Field(..., description="Region")
    
    # Network
    vpc_id: Optional[str] = Field(None, description="VPC ID")
    subnet_id: Optional[str] = Field(None, description="Subnet ID")
    public_ip: Optional[str] = Field(None, description="Public IP address")
    private_ip: Optional[str] = Field(None, description="Private IP address")
    security_groups: Optional[List[str]] = Field(None, description="Security group IDs")
    
    # IAM
    iam_instance_profile: Optional[str] = Field(None, description="Instance profile ARN")
    iam_role: Optional[str] = Field(None, description="IAM role ARN")
    
    # Metadata
    imds_v1_enabled: bool = Field(True, description="IMDSv1 enabled")
    imds_v2_required: bool = Field(False, description="IMDSv2 required")
    
    # State
    state: str = Field(..., description="Instance state")
    launch_time: Optional[datetime] = Field(None, description="Launch time")
    
    # User data
    has_user_data: bool = Field(False, description="Has user data")
    user_data_contains_secrets: bool = Field(False, description="User data has secrets")


# =============================================================================
# Core Finding Models
# =============================================================================

class SecurityFinding(BaseModel):
    """
    Detailed information about a detected security issue.
    This is the primary finding object returned by security checks.
    """
    # Identification
    id: str = Field(..., description="Unique finding ID (UUID)")
    name: str = Field(..., description="Human-readable name")
    description: str = Field(..., description="Detailed description")
    
    # Classification
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific sub-category")
    severity: SeverityLevel = Field(..., description="Severity level")
    status: FindingStatus = Field(FindingStatus.ACTIVE, description="Finding status")
    
    # Resource
    resource: AWSResourceIdentifier = Field(..., description="Affected resource")
    resource_config: Optional[Dict[str, Any]] = Field(None, description="Relevant config excerpt")
    
    # Framework mappings
    mitre_attack: Optional[MitreAttackReference] = Field(None, description="MITRE ATT&CK reference")
    compliance_mappings: Optional[List[ComplianceMapping]] = Field(None, description="Compliance mappings")
    
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Explicit AWS CLI commands for exploitation/verification"
    )
    
    # Evidence
    evidence: Optional[Dict[str, Any]] = Field(None, description="Evidence supporting finding")
    affected_policies: Optional[List[IAMPolicyDocument]] = Field(None, description="Affected IAM policies")
    affected_users: Optional[List[IAMUserInfo]] = Field(None, description="Affected IAM users")
    affected_roles: Optional[List[IAMRoleInfo]] = Field(None, description="Affected IAM roles")
    affected_security_groups: Optional[List[SecurityGroupInfo]] = Field(None, description="Affected SGs")
    affected_buckets: Optional[List[S3BucketInfo]] = Field(None, description="Affected S3 buckets")
    affected_instances: Optional[List[EC2InstanceInfo]] = Field(None, description="Affected EC2 instances")
    
    # Attack paths
    privilege_escalation_paths: Optional[List[PrivilegeEscalationPath]] = Field(None, description="Privesc paths")
    exfiltration_paths: Optional[List[ExfiltrationPath]] = Field(None, description="Exfil paths")
    persistence_mechanisms: Optional[List[PersistenceMechanism]] = Field(None, description="Persistence")
    
    # IoCs
    iocs: Optional[List[IoC]] = Field(None, description="Extracted IoCs")
    
    # Analysis
    risk_score: float = Field(0.0, ge=0.0, le=10.0, description="Risk score 0-10")
    exploitability: Optional[str] = Field(None, description="Exploitability: easy/medium/hard")
    impact_scope: Optional[str] = Field(None, description="Scope: resource/account/org")
    false_positive_likelihood: Optional[str] = Field(None, description="FP likelihood: low/medium/high")
    
    # Remediation
    recommendation: str = Field(..., description="What should be done")
    remediation_steps: Optional[List[str]] = Field(None, description="Step-by-step remediation")
    remediation_commands: Optional[List[str]] = Field(None, description="AWS CLI commands")
    remediation_terraform: Optional[str] = Field(None, description="Terraform fix")
    remediation_cloudformation: Optional[str] = Field(None, description="CloudFormation fix")
    remediation_effort: Optional[str] = Field(None, description="Effort: low/medium/high")
    requires_downtime: bool = Field(False, description="Whether fix requires downtime")
    
    # Metadata
    detected_at: datetime = Field(default_factory=datetime.utcnow, description="Detection time")
    detection_method: Optional[str] = Field(None, description="How this was detected")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Detection confidence 0-1")
    
    # Suppression
    is_suppressed: bool = Field(False, description="Whether suppressed")
    suppression_reason: Optional[str] = Field(None, description="Reason for suppression")
    exception_until: Optional[datetime] = Field(None, description="Exception expiry date")
    
    # Additional context
    tags: Optional[List[str]] = Field(None, description="Finding tags")
    related_findings: Optional[List[str]] = Field(None, description="Related finding IDs")
    references: Optional[List[str]] = Field(None, description="External references")
    aws_config_rule: Optional[str] = Field(None, description="Related AWS Config rule")
    security_hub_finding: Optional[str] = Field(None, description="Security Hub finding ARN")
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this finding"
    )
    raw_data: Optional[Dict[str, Any]] = Field(None, description="Raw API response data")


class CheckResult(BaseModel):
    """Result of a security check."""
    check_id: str = Field(..., description="Check identifier")
    check_name: str = Field(..., description="Human-readable check name")
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific type")
    
    # Status
    passed: bool = Field(..., description="Whether check passed (no issues)")
    findings_count: int = Field(0, description="Number of findings")
    
    # Results
    findings: List[SecurityFinding] = Field(default_factory=list, description="Findings from this check")
    
    # Scope
    resources_checked: int = Field(0, description="Number of resources checked")
    resources_with_issues: int = Field(0, description="Resources with issues")
    regions_checked: Optional[List[str]] = Field(None, description="Regions checked")
    
    # Performance
    duration_ms: Optional[float] = Field(None, description="Check duration in ms")
    api_calls_made: Optional[int] = Field(None, description="Number of API calls")
    
    # Errors
    error: Optional[str] = Field(None, description="Error message if check failed")
    error_details: Optional[str] = Field(None, description="Detailed error info")
    skipped: bool = Field(False, description="Whether check was skipped")
    skipped_reason: Optional[str] = Field(None, description="Skip reason")


# =============================================================================
# Scan Configuration
# =============================================================================

class ScanScope(BaseModel):
    """Scope of the security assessment."""
    # Organization scope
    organization_id: Optional[str] = Field(None, description="Organization ID to scan")
    
    # Account scope
    account_ids: Optional[List[str]] = Field(None, description="Account IDs to scan")
    exclude_account_ids: Optional[List[str]] = Field(None, description="Accounts to exclude")
    
    # Region scope
    regions: Optional[List[str]] = Field(None, description="Regions to scan (None = all)")
    exclude_regions: Optional[List[str]] = Field(None, description="Regions to exclude")
    include_global: bool = Field(True, description="Include global resources (IAM, S3, etc.)")
    
    # Resource scope
    resource_types: Optional[List[AWSResourceType]] = Field(None, description="Resource types to scan")
    exclude_resource_types: Optional[List[AWSResourceType]] = Field(None, description="Types to exclude")
    
    # OU scope
    organizational_units: Optional[List[str]] = Field(None, description="OUs to scan")


class ScanOptions(BaseModel):
    """Configuration options for security scan."""
    # Scope
    scope: ScanScope = Field(default_factory=ScanScope, description="Scan scope")
    
    # Category selection
    categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to scan")
    exclude_categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to exclude")
    
    # Severity filtering
    min_severity: SeverityLevel = Field(SeverityLevel.INFO, description="Minimum severity")
    
    # Scan depth
    deep_scan: bool = Field(False, description="Enable deep/thorough scanning")
    quick_scan: bool = Field(False, description="Quick scan (critical only)")
    
    # Analysis features
    analyze_iam_policies: bool = Field(True, description="Analyze IAM policies in detail")
    analyze_privilege_escalation: bool = Field(True, description="Find privesc paths")
    analyze_exfiltration_paths: bool = Field(True, description="Find exfil paths")
    analyze_persistence: bool = Field(True, description="Find persistence mechanisms")
    analyze_compliance: bool = Field(True, description="Map to compliance frameworks")
    
    # Compliance frameworks
    compliance_frameworks: Optional[List[ComplianceFramework]] = Field(
        None, description="Frameworks to map findings to"
    )
    
    # Performance
    max_workers: int = Field(10, description="Maximum parallel workers")
    timeout_per_check: int = Field(120, description="Timeout per check in seconds")
    max_findings: int = Field(5000, description="Maximum findings to return")
    max_api_calls_per_second: int = Field(10, description="API rate limit")
    
    # Output options
    include_raw_data: bool = Field(False, description="Include raw API responses")
    include_passing_checks: bool = Field(False, description="Include checks with no findings")
    
    # Baseline comparison
    baseline_path: Optional[str] = Field(None, description="Path to baseline for comparison")
    suppress_baseline_findings: bool = Field(False, description="Suppress known findings")
    
    # Assume role for cross-account
    assume_role_name: Optional[str] = Field(None, description="Role name to assume in each account")
    assume_role_external_id: Optional[str] = Field(None, description="External ID for role assumption")


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary counts by severity level."""
    critical: int = Field(0, description="Critical severity count")
    high: int = Field(0, description="High severity count")
    medium: int = Field(0, description="Medium severity count")
    low: int = Field(0, description="Low severity count")
    info: int = Field(0, description="Info count")
    total: int = Field(0, description="Total findings")


class CategorySummary(BaseModel):
    """Summary counts by category."""
    category: SecurityCategory = Field(..., description="Category")
    category_name: str = Field(..., description="Category display name")
    total_count: int = Field(0, description="Total findings in category")
    critical_count: int = Field(0, description="Critical findings")
    high_count: int = Field(0, description="High findings")
    top_issues: Optional[List[str]] = Field(None, description="Top issue types")


class ResourceTypeSummary(BaseModel):
    """Summary by resource type."""
    resource_type: AWSResourceType = Field(..., description="Resource type")
    total_resources: int = Field(0, description="Total resources scanned")
    resources_with_issues: int = Field(0, description="Resources with findings")
    total_findings: int = Field(0, description="Total findings")
    critical_findings: int = Field(0, description="Critical findings")


class AccountSummary(BaseModel):
    """Summary per AWS account."""
    account_id: str = Field(..., description="AWS account ID")
    account_name: Optional[str] = Field(None, description="Account name/alias")
    total_findings: int = Field(0, description="Total findings")
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Severity breakdown"
    )
    top_categories: Optional[List[str]] = Field(None, description="Top issue categories")
    risk_score: float = Field(0.0, description="Overall account risk score")
    regions_scanned: Optional[List[str]] = Field(None, description="Regions scanned")


class RegionSummary(BaseModel):
    """Summary per AWS region."""
    region: str = Field(..., description="AWS region")
    total_findings: int = Field(0, description="Total findings")
    critical_findings: int = Field(0, description="Critical findings")
    resource_count: int = Field(0, description="Resources in region")


class ScanMetadata(BaseModel):
    """Metadata about the scan execution."""
    scan_id: str = Field(..., description="Unique scan ID")
    scan_type: str = Field("full", description="Scan type: full/quick/targeted")
    started_at: datetime = Field(default_factory=datetime.utcnow, description="Start time")
    completed_at: Optional[datetime] = Field(None, description="Completion time")
    duration_seconds: Optional[float] = Field(None, description="Total duration")
    
    # Authentication
    caller_identity: Optional[str] = Field(None, description="IAM identity used")
    caller_arn: Optional[str] = Field(None, description="Caller ARN")
    
    # Coverage
    accounts_scanned: int = Field(0, description="Accounts scanned")
    regions_scanned: int = Field(0, description="Regions scanned")
    resources_scanned: int = Field(0, description="Total resources scanned")
    
    # Checks
    total_checks: int = Field(0, description="Total checks performed")
    passed_checks: int = Field(0, description="Checks with no findings")
    failed_checks: int = Field(0, description="Checks with findings")
    skipped_checks: int = Field(0, description="Checks skipped")
    error_checks: int = Field(0, description="Checks with errors")
    
    # API usage
    total_api_calls: Optional[int] = Field(None, description="Total AWS API calls")


class AWSSecurityOutput(BaseModel):
    """
    Complete output from AWS security assessment.
    This is the main return type from hook_aws_security_scan().
    """
    # Metadata
    metadata: ScanMetadata = Field(..., description="Scan metadata")
    
    # Configuration used
    scan_options: Optional[ScanOptions] = Field(None, description="Options used")
    
    # Check results
    check_results: List[CheckResult] = Field(
        default_factory=list, description="Results from each check"
    )
    
    # All findings
    findings: List[SecurityFinding] = Field(
        default_factory=list, description="All security findings"
    )
    
    # Summaries
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Summary by severity"
    )
    category_summaries: List[CategorySummary] = Field(
        default_factory=list, description="Summary by category"
    )
    resource_type_summaries: List[ResourceTypeSummary] = Field(
        default_factory=list, description="Summary by resource type"
    )
    account_summaries: List[AccountSummary] = Field(
        default_factory=list, description="Summary per account"
    )
    region_summaries: List[RegionSummary] = Field(
        default_factory=list, description="Summary per region"
    )
    
    # Attack analysis
    privilege_escalation_paths: List[PrivilegeEscalationPath] = Field(
        default_factory=list, description="All detected privesc paths"
    )
    exfiltration_paths: List[ExfiltrationPath] = Field(
        default_factory=list, description="All detected exfil paths"
    )
    persistence_mechanisms: List[PersistenceMechanism] = Field(
        default_factory=list, description="All detected persistence"
    )
    
    # Aggregated IoCs
    all_iocs: Optional[List[IoC]] = Field(None, description="All extracted IoCs")
    
    # Top findings
    critical_findings: Optional[List[SecurityFinding]] = Field(
        None, description="Critical severity findings"
    )
    top_risk_resources: Optional[List[AWSResourceIdentifier]] = Field(
        None, description="Highest risk resources"
    )
    
    # Compliance
    compliance_summary: Optional[Dict[str, Dict[str, int]]] = Field(
        None, description="Compliance status per framework"
    )
    
    # Identity analysis
    risky_users: Optional[List[IAMUserInfo]] = Field(None, description="High-risk IAM users")
    risky_roles: Optional[List[IAMRoleInfo]] = Field(None, description="High-risk IAM roles")
    
    # Errors and warnings
    errors: Optional[List[str]] = Field(None, description="Errors encountered")
    warnings: Optional[List[str]] = Field(None, description="Warnings from scan")
    
    # Recommendations
    prioritized_recommendations: Optional[List[str]] = Field(
        None, description="Prioritized action items"
    )
    
    # Baseline comparison
    baseline_comparison: Optional[Dict[str, Any]] = Field(
        None, description="Comparison with baseline"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )


# =============================================================================
# Baseline Models
# =============================================================================

class BaselineFinding(BaseModel):
    """Single finding in baseline."""
    finding_id: str = Field(..., description="Finding ID for matching")
    resource_arn: str = Field(..., description="Resource ARN")
    category: SecurityCategory = Field(..., description="Category")
    sub_category: SecuritySubCategory = Field(..., description="Sub-category")
    severity: SeverityLevel = Field(..., description="Severity")
    first_seen: datetime = Field(default_factory=datetime.utcnow, description="First detection")
    status: str = Field("acknowledged", description="Baseline status")
    notes: Optional[str] = Field(None, description="Notes about this finding")
    accepted_by: Optional[str] = Field(None, description="Who accepted the risk")
    accepted_until: Optional[datetime] = Field(None, description="Acceptance expiry")


class Baseline(BaseModel):
    """Security baseline for comparison."""
    baseline_id: str = Field(..., description="Unique baseline ID")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update")
    organization_id: Optional[str] = Field(None, description="Organization ID")
    account_ids: Optional[List[str]] = Field(None, description="Accounts in baseline")
    findings: List[BaselineFinding] = Field(default_factory=list, description="Baseline findings")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class BaselineComparison(BaseModel):
    """Result of comparing current state to baseline."""
    new_findings: List[SecurityFinding] = Field(
        default_factory=list, description="Findings not in baseline"
    )
    resolved_findings: List[BaselineFinding] = Field(
        default_factory=list, description="Baseline findings now resolved"
    )
    unchanged_findings: int = Field(0, description="Findings unchanged from baseline")
    severity_changes: Optional[Dict[str, int]] = Field(
        None, description="Changes in severity counts"
    )
    comparison_timestamp: datetime = Field(
        default_factory=datetime.utcnow, description="Comparison time"
    )


# =============================================================================
# AWS Security Finding Format (ASFF) Conversion
# =============================================================================

class ASFFSeverity(BaseModel):
    """ASFF severity format."""
    Label: str = Field(..., description="Severity label")
    Normalized: int = Field(..., description="Normalized severity 0-100")


class ASFFFinding(BaseModel):
    """AWS Security Finding Format for Security Hub integration."""
    SchemaVersion: str = Field("2018-10-08", description="ASFF schema version")
    Id: str = Field(..., description="Finding ID")
    ProductArn: str = Field(..., description="Product ARN")
    GeneratorId: str = Field(..., description="Generator ID")
    AwsAccountId: str = Field(..., description="AWS account ID")
    Types: List[str] = Field(default_factory=list, description="Finding types")
    FirstObservedAt: str = Field(..., description="First observation timestamp")
    CreatedAt: str = Field(..., description="Creation timestamp")
    UpdatedAt: str = Field(..., description="Update timestamp")
    Severity: ASFFSeverity = Field(..., description="Severity")
    Title: str = Field(..., description="Finding title")
    Description: str = Field(..., description="Finding description")
    Resources: List[Dict[str, Any]] = Field(default_factory=list, description="Affected resources")
    Compliance: Optional[Dict[str, Any]] = Field(None, description="Compliance status")
    Remediation: Optional[Dict[str, Any]] = Field(None, description="Remediation info")
