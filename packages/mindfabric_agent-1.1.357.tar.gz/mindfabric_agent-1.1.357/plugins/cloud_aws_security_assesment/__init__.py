from .output_service import OutputService
"""
AWS Security Assessment Plugin

Comprehensive security assessment for Amazon Web Services environments.
Detects IAM misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.
"""

from .aws_security_assessment import AWSSecurityPlugin, scan_aws_security
from .proto import (
    SeverityLevel,
    AWSResourceType,
    SecurityCategory,
    SecuritySubCategory,
    FindingStatus,
    ComplianceFramework,
    AWSRegion,
    ScanScope,
    ScanOptions,
    SecurityFinding,
    CheckResult,
    AWSSecurityOutput,
    AWSResourceIdentifier,
    IAMPolicyDocument,
    IAMUserInfo,
    IAMRoleInfo,
    SecurityGroupInfo,
    S3BucketInfo,
    EC2InstanceInfo,
    PrivilegeEscalationPath,
    ExfiltrationPath,
    PersistenceMechanism,
    MitreAttackReference,
    ComplianceMapping,
    AccountSummary,
    RegionSummary,
)

__all__ = [
    "AWSSecurityPlugin",
    "scan_aws_security",
    "SeverityLevel",
    "AWSResourceType",
    "SecurityCategory",
    "SecuritySubCategory",
    "FindingStatus",
    "ComplianceFramework",
    "AWSRegion",
    "ScanScope",
    "ScanOptions",
    "SecurityFinding",
    "CheckResult",
    "AWSSecurityOutput",
    "AWSResourceIdentifier",
    "IAMPolicyDocument",
    "IAMUserInfo",
    "IAMRoleInfo",
    "SecurityGroupInfo",
    "S3BucketInfo",
    "EC2InstanceInfo",
    "PrivilegeEscalationPath",
    "ExfiltrationPath",
    "PersistenceMechanism",
    "MitreAttackReference",
    "ComplianceMapping",
    "AccountSummary",
    "RegionSummary",
]

__version__ = "1.0.0"
