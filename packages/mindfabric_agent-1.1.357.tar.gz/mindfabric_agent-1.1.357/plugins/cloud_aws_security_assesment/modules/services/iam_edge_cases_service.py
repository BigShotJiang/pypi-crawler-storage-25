"""
IAM Edge Cases Security Service

Advanced IAM security checks for AWS:
- SCP bypass detection
- Resource-based policy analysis
- Permission boundary misconfigurations
- IAM policy simulation
- Privilege escalation path detection
- Cross-account access abuse
- Assume role chain analysis

MITRE ATT&CK:
- T1078.004: Valid Accounts: Cloud Accounts
- T1098: Account Manipulation
- T1136.003: Create Account: Cloud Account
- T1548: Abuse Elevation Control Mechanism
"""

import json
import re
from typing import Any, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
import logging

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception
from ...proto import (
    ScanOptions,
    SecurityFinding,
    AWSResourceType,
    SeverityLevel,
)

logger = logging.getLogger(__name__)


# =============================================================================
# IAM Privilege Escalation Paths
# =============================================================================

PRIVILEGE_ESCALATION_ACTIONS = {
    "create_policy_version": {
        "actions": ["iam:CreatePolicyVersion"],
        "description": "Can create new policy version with elevated permissions",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1098",
    },
    "set_default_policy_version": {
        "actions": ["iam:SetDefaultPolicyVersion"],
        "description": "Can set default policy version to escalate privileges",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1098",
    },
    "attach_user_policy": {
        "actions": ["iam:AttachUserPolicy"],
        "description": "Can attach admin policy to own user",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1098",
    },
    "attach_group_policy": {
        "actions": ["iam:AttachGroupPolicy"],
        "description": "Can attach admin policy to own group",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098",
    },
    "attach_role_policy": {
        "actions": ["iam:AttachRolePolicy"],
        "description": "Can attach admin policy to assumable role",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098",
    },
    "put_user_policy": {
        "actions": ["iam:PutUserPolicy"],
        "description": "Can put inline admin policy on own user",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1098",
    },
    "put_group_policy": {
        "actions": ["iam:PutGroupPolicy"],
        "description": "Can put inline admin policy on own group",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098",
    },
    "put_role_policy": {
        "actions": ["iam:PutRolePolicy"],
        "description": "Can put inline admin policy on assumable role",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098",
    },
    "create_access_key": {
        "actions": ["iam:CreateAccessKey"],
        "description": "Can create access keys for other users",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098.001",
    },
    "create_login_profile": {
        "actions": ["iam:CreateLoginProfile"],
        "description": "Can create console login for other users",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098.001",
    },
    "update_login_profile": {
        "actions": ["iam:UpdateLoginProfile"],
        "description": "Can change password for other users",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098.001",
    },
    "assume_role": {
        "actions": ["sts:AssumeRole"],
        "description": "Can assume roles with higher privileges",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1078.004",
    },
    "pass_role": {
        "actions": ["iam:PassRole"],
        "description": "Can pass roles to services for privilege escalation",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1548",
    },
    "lambda_create_function": {
        "actions": ["lambda:CreateFunction", "lambda:InvokeFunction", "iam:PassRole"],
        "description": "Can create Lambda with elevated role and invoke it",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1548",
    },
    "ec2_instance_connect": {
        "actions": ["ec2-instance-connect:SendSSHPublicKey"],
        "description": "Can push SSH key to EC2 instance",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1098.004",
    },
    "ssm_send_command": {
        "actions": ["ssm:SendCommand"],
        "description": "Can execute commands on EC2 via SSM",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1059",
    },
    "cloudformation_create": {
        "actions": ["cloudformation:CreateStack", "iam:PassRole"],
        "description": "Can create CloudFormation with elevated role",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1548",
    },
    "glue_dev_endpoint": {
        "actions": ["glue:CreateDevEndpoint", "iam:PassRole"],
        "description": "Can create Glue endpoint with elevated role",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1548",
    },
    "codestar_create_project": {
        "actions": ["codestar:CreateProject"],
        "description": "Can create CodeStar project with elevated permissions",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1548",
    },
    "datapipeline_create": {
        "actions": ["datapipeline:CreatePipeline", "datapipeline:PutPipelineDefinition", "iam:PassRole"],
        "description": "Can create Data Pipeline with elevated role",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1548",
    },
}


# =============================================================================
# SCP Bypass Patterns
# =============================================================================

SCP_BYPASS_PATTERNS = {
    "not_action_bypass": {
        "pattern": "NotAction",
        "description": "SCP uses NotAction which may allow bypass",
        "severity": SeverityLevel.HIGH,
    },
    "not_resource_bypass": {
        "pattern": "NotResource",
        "description": "SCP uses NotResource which may allow bypass",
        "severity": SeverityLevel.MEDIUM,
    },
    "condition_bypass": {
        "patterns": [
            r"aws:RequestTag",
            r"aws:ResourceTag",
        ],
        "description": "SCP conditions based on tags may be bypassable",
        "severity": SeverityLevel.MEDIUM,
    },
    "missing_deny_all": {
        "description": "No explicit deny for destructive actions",
        "severity": SeverityLevel.MEDIUM,
    },
}


# =============================================================================
# Resource-Based Policy Risks
# =============================================================================

RESOURCE_POLICY_RISKS = {
    "public_access": {
        "principals": ["*"],
        "description": "Resource allows public access",
        "severity": SeverityLevel.CRITICAL,
    },
    "cross_account_no_external_id": {
        "description": "Cross-account access without external ID",
        "severity": SeverityLevel.HIGH,
    },
    "any_authenticated_user": {
        "principals": ["*"],
        "conditions": ["aws:PrincipalAccount"],
        "description": "Any authenticated AWS user can access",
        "severity": SeverityLevel.HIGH,
    },
    "overly_permissive_actions": {
        "actions": ["*"],
        "description": "Resource allows all actions",
        "severity": SeverityLevel.CRITICAL,
    },
}


@dataclass
class IAMEdgeCaseFinding:
    """Finding from IAM edge case analysis."""
    finding_type: str
    severity: SeverityLevel
    title: str
    description: str
    resource_type: str
    resource_id: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""
    escalation_path: List[str] = field(default_factory=list)


class IAMEdgeCasesService:
    """Service for advanced IAM security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize IAM edge cases service."""
        self.plugin = plugin_instance
        self.findings: List[IAMEdgeCaseFinding] = []
    
    async def check_privilege_escalation_paths(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Check for IAM privilege escalation paths.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of privilege escalation findings
        """
        findings = []
        
        try:
            iam = self.plugin._get_client("iam")
            
            # Get all users
            paginator = iam.get_paginator("list_users")
            for page in paginator.paginate():
                for user in page.get("Users", []):
                    user_name = user["UserName"]
                    
                    # Get user policies
                    user_policies = await self._get_user_effective_permissions(iam, user_name)
                    
                    # Check for escalation paths
                    for escalation_type, config in PRIVILEGE_ESCALATION_ACTIONS.items():
                        required_actions = config["actions"]
                        
                        if all(self._has_permission(user_policies, action) for action in required_actions):
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="privilege_escalation",
                                severity=config["severity"],
                                title=f"Privilege Escalation: {escalation_type}",
                                description=config["description"],
                                resource_type="IAM::User",
                                resource_id=user_name,
                                evidence={
                                    "user": user_name,
                                    "escalation_type": escalation_type,
                                    "required_actions": required_actions,
                                },
                                mitre_technique=config["mitre"],
                                recommendation=f"Review and restrict {', '.join(required_actions)} permissions",
                                escalation_path=[f"User:{user_name}", escalation_type, "Admin"],
                            ))
            
            # Get all roles
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for role in page.get("Roles", []):
                    role_name = role["RoleName"]
                    
                    # Skip service-linked roles
                    if role.get("Path", "").startswith("/aws-service-role/"):
                        continue
                    
                    # Get role policies
                    role_policies = await self._get_role_effective_permissions(iam, role_name)
                    
                    # Check for escalation paths
                    for escalation_type, config in PRIVILEGE_ESCALATION_ACTIONS.items():
                        required_actions = config["actions"]
                        
                        if all(self._has_permission(role_policies, action) for action in required_actions):
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="privilege_escalation",
                                severity=config["severity"],
                                title=f"Role Privilege Escalation: {escalation_type}",
                                description=config["description"],
                                resource_type="IAM::Role",
                                resource_id=role_name,
                                evidence={
                                    "role": role_name,
                                    "escalation_type": escalation_type,
                                    "required_actions": required_actions,
                                },
                                mitre_technique=config["mitre"],
                                recommendation=f"Review and restrict {', '.join(required_actions)} permissions",
                                escalation_path=[f"Role:{role_name}", escalation_type, "Admin"],
                            ))
                            
        except ClientError as e:
            logger.error(f"Error checking privilege escalation: {e}")
        
        return findings
    
    async def check_scp_bypass(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Check for SCP bypass vulnerabilities.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of SCP bypass findings
        """
        findings = []
        
        try:
            orgs = self.plugin._get_client("organizations")
            
            # List all SCPs
            paginator = orgs.get_paginator("list_policies")
            for page in paginator.paginate(Filter="SERVICE_CONTROL_POLICY"):
                for policy in page.get("Policies", []):
                    policy_id = policy["Id"]
                    policy_name = policy["Name"]
                    
                    # Skip AWS managed SCPs
                    if policy.get("AwsManaged", False):
                        continue
                    
                    # Get policy content
                    policy_detail = orgs.describe_policy(PolicyId=policy_id)
                    policy_content = policy_detail["Policy"]["Content"]
                    
                    try:
                        policy_doc = json.loads(policy_content)
                    except json.JSONDecodeError:
                        continue
                    
                    # Check for bypass patterns
                    for statement in policy_doc.get("Statement", []):
                        # NotAction bypass
                        if "NotAction" in statement:
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="scp_bypass",
                                severity=SCP_BYPASS_PATTERNS["not_action_bypass"]["severity"],
                                title="SCP NotAction Bypass Risk",
                                description="SCP uses NotAction which may allow unintended actions",
                                resource_type="Organizations::SCP",
                                resource_id=policy_name,
                                evidence={
                                    "policy_id": policy_id,
                                    "not_action": statement.get("NotAction"),
                                },
                                mitre_technique="T1098",
                                recommendation="Replace NotAction with explicit Action list",
                            ))
                        
                        # NotResource bypass
                        if "NotResource" in statement:
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="scp_bypass",
                                severity=SCP_BYPASS_PATTERNS["not_resource_bypass"]["severity"],
                                title="SCP NotResource Bypass Risk",
                                description="SCP uses NotResource which may allow bypass",
                                resource_type="Organizations::SCP",
                                resource_id=policy_name,
                                evidence={
                                    "policy_id": policy_id,
                                    "not_resource": statement.get("NotResource"),
                                },
                                mitre_technique="T1098",
                                recommendation="Replace NotResource with explicit Resource list",
                            ))
                        
                        # Check condition bypass
                        conditions = statement.get("Condition", {})
                        for condition_type, condition_values in conditions.items():
                            for key in condition_values.keys():
                                if any(re.match(p, key) for p in SCP_BYPASS_PATTERNS["condition_bypass"]["patterns"]):
                                    findings.append(IAMEdgeCaseFinding(
                                        finding_type="scp_bypass",
                                        severity=SCP_BYPASS_PATTERNS["condition_bypass"]["severity"],
                                        title="SCP Tag-Based Condition Bypass Risk",
                                        description="SCP uses tag conditions which may be bypassable",
                                        resource_type="Organizations::SCP",
                                        resource_id=policy_name,
                                        evidence={
                                            "policy_id": policy_id,
                                            "condition_key": key,
                                        },
                                        mitre_technique="T1098",
                                        recommendation="Add additional conditions beyond tags",
                                    ))
                                    
        except ClientError as e:
            if "AccessDenied" not in str(e) and "AWSOrganizationsNotInUseException" not in str(e):
                logger.error(f"Error checking SCP bypass: {e}")
        
        return findings
    
    async def check_permission_boundaries(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Check for permission boundary misconfigurations.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of permission boundary findings
        """
        findings = []
        
        try:
            iam = self.plugin._get_client("iam")
            
            # Check users without permission boundaries
            paginator = iam.get_paginator("list_users")
            for page in paginator.paginate():
                for user in page.get("Users", []):
                    user_name = user["UserName"]
                    
                    # Check if user has permission boundary
                    if "PermissionsBoundary" not in user:
                        # Get user policies to check if powerful
                        user_policies = await self._get_user_effective_permissions(iam, user_name)
                        
                        if self._has_admin_permissions(user_policies):
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="permission_boundary",
                                severity=SeverityLevel.HIGH,
                                title="Privileged User Without Permission Boundary",
                                description="User with admin permissions lacks permission boundary",
                                resource_type="IAM::User",
                                resource_id=user_name,
                                evidence={"user": user_name, "admin_access": True},
                                mitre_technique="T1098",
                                recommendation="Apply permission boundary to limit maximum permissions",
                            ))
            
            # Check roles without permission boundaries
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for role in page.get("Roles", []):
                    role_name = role["RoleName"]
                    
                    # Skip service-linked roles
                    if role.get("Path", "").startswith("/aws-service-role/"):
                        continue
                    
                    # Check trust policy for external access
                    trust_policy = role.get("AssumeRolePolicyDocument", {})
                    
                    if self._allows_external_access(trust_policy):
                        if "PermissionsBoundary" not in role:
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="permission_boundary",
                                severity=SeverityLevel.MEDIUM,
                                title="External Role Without Permission Boundary",
                                description="Role allowing external access lacks permission boundary",
                                resource_type="IAM::Role",
                                resource_id=role_name,
                                evidence={"role": role_name, "external_access": True},
                                mitre_technique="T1078.004",
                                recommendation="Apply permission boundary to externally accessible roles",
                            ))
                            
        except ClientError as e:
            logger.error(f"Error checking permission boundaries: {e}")
        
        return findings
    
    async def check_resource_based_policies(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Check for risky resource-based policies.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of resource policy findings
        """
        findings = []
        
        # Check S3 bucket policies
        s3_findings = await self._check_s3_policies(account_id)
        findings.extend(s3_findings)
        
        # Check KMS key policies
        kms_findings = await self._check_kms_policies(account_id)
        findings.extend(kms_findings)
        
        # Check SQS queue policies
        sqs_findings = await self._check_sqs_policies(account_id)
        findings.extend(sqs_findings)
        
        # Check SNS topic policies
        sns_findings = await self._check_sns_policies(account_id)
        findings.extend(sns_findings)
        
        # Check Lambda function policies
        lambda_findings = await self._check_lambda_policies(account_id)
        findings.extend(lambda_findings)
        
        return findings
    
    async def check_assume_role_chains(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Check for risky assume role chains.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of assume role chain findings
        """
        findings = []
        
        try:
            iam = self.plugin._get_client("iam")
            
            # Build role graph
            role_graph = {}
            
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for role in page.get("Roles", []):
                    role_name = role["RoleName"]
                    role_arn = role["Arn"]
                    
                    trust_policy = role.get("AssumeRolePolicyDocument", {})
                    
                    # Find principals that can assume this role
                    assumable_by = self._extract_principals_from_trust(trust_policy)
                    
                    role_graph[role_arn] = {
                        "name": role_name,
                        "assumable_by": assumable_by,
                        "trust_policy": trust_policy,
                    }
            
            # Find chains that lead to admin
            for role_arn, role_info in role_graph.items():
                role_name = role_info["name"]
                
                # Get role policies
                role_policies = await self._get_role_effective_permissions(iam, role_name)
                
                if self._has_admin_permissions(role_policies):
                    # Find all paths to this admin role
                    chains = self._find_assume_chains(role_graph, role_arn, max_depth=3)
                    
                    for chain in chains:
                        if len(chain) > 1:
                            findings.append(IAMEdgeCaseFinding(
                                finding_type="assume_role_chain",
                                severity=SeverityLevel.HIGH,
                                title="Role Chain to Admin",
                                description=f"Role chain leads to admin role: {role_name}",
                                resource_type="IAM::Role",
                                resource_id=role_name,
                                evidence={
                                    "chain": chain,
                                    "target_role": role_name,
                                },
                                mitre_technique="T1078.004",
                                recommendation="Review and restrict role trust relationships",
                                escalation_path=chain,
                            ))
                            
        except ClientError as e:
            logger.error(f"Error checking assume role chains: {e}")
        
        return findings
    
    async def simulate_policy(
        self,
        principal_arn: str,
        actions: List[str],
        resources: List[str] = None,
    ) -> Dict[str, bool]:
        """
        Simulate IAM policy to check effective permissions.
        
        Args:
            principal_arn: ARN of user/role to simulate
            actions: Actions to test
            resources: Resources to test against
            
        Returns:
            Dict of action -> allowed
        """
        results = {}
        
        try:
            iam = self.plugin._get_client("iam")
            
            if not resources:
                resources = ["*"]
            
            response = iam.simulate_principal_policy(
                PolicySourceArn=principal_arn,
                ActionNames=actions,
                ResourceArns=resources,
            )
            
            for result in response.get("EvaluationResults", []):
                action = result["EvalActionName"]
                decision = result["EvalDecision"]
                results[action] = decision == "allowed"
                
        except ClientError as e:
            logger.error(f"Policy simulation failed: {e}")
        
        return results
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    async def _get_user_effective_permissions(
        self,
        iam,
        user_name: str,
    ) -> List[Dict[str, Any]]:
        """Get all policies affecting a user."""
        policies = []
        
        try:
            # Attached policies
            attached = iam.list_attached_user_policies(UserName=user_name)
            for policy in attached.get("AttachedPolicies", []):
                policy_arn = policy["PolicyArn"]
                policy_version = iam.get_policy(PolicyArn=policy_arn)["Policy"]["DefaultVersionId"]
                policy_doc = iam.get_policy_version(
                    PolicyArn=policy_arn,
                    VersionId=policy_version
                )["PolicyVersion"]["Document"]
                policies.append(policy_doc)
            
            # Inline policies
            inline = iam.list_user_policies(UserName=user_name)
            for policy_name in inline.get("PolicyNames", []):
                policy_doc = iam.get_user_policy(
                    UserName=user_name,
                    PolicyName=policy_name
                )["PolicyDocument"]
                policies.append(policy_doc)
            
            # Group policies
            groups = iam.list_groups_for_user(UserName=user_name)
            for group in groups.get("Groups", []):
                group_name = group["GroupName"]
                
                # Attached group policies
                group_attached = iam.list_attached_group_policies(GroupName=group_name)
                for policy in group_attached.get("AttachedPolicies", []):
                    policy_arn = policy["PolicyArn"]
                    policy_version = iam.get_policy(PolicyArn=policy_arn)["Policy"]["DefaultVersionId"]
                    policy_doc = iam.get_policy_version(
                        PolicyArn=policy_arn,
                        VersionId=policy_version
                    )["PolicyVersion"]["Document"]
                    policies.append(policy_doc)
                
                # Inline group policies
                group_inline = iam.list_group_policies(GroupName=group_name)
                for policy_name in group_inline.get("PolicyNames", []):
                    policy_doc = iam.get_group_policy(
                        GroupName=group_name,
                        PolicyName=policy_name
                    )["PolicyDocument"]
                    policies.append(policy_doc)
                    
        except ClientError as e:
            logger.error(f"Error getting user permissions: {e}")
        
        return policies
    
    async def _get_role_effective_permissions(
        self,
        iam,
        role_name: str,
    ) -> List[Dict[str, Any]]:
        """Get all policies affecting a role."""
        policies = []
        
        try:
            # Attached policies
            attached = iam.list_attached_role_policies(RoleName=role_name)
            for policy in attached.get("AttachedPolicies", []):
                policy_arn = policy["PolicyArn"]
                policy_version = iam.get_policy(PolicyArn=policy_arn)["Policy"]["DefaultVersionId"]
                policy_doc = iam.get_policy_version(
                    PolicyArn=policy_arn,
                    VersionId=policy_version
                )["PolicyVersion"]["Document"]
                policies.append(policy_doc)
            
            # Inline policies
            inline = iam.list_role_policies(RoleName=role_name)
            for policy_name in inline.get("PolicyNames", []):
                policy_doc = iam.get_role_policy(
                    RoleName=role_name,
                    PolicyName=policy_name
                )["PolicyDocument"]
                policies.append(policy_doc)
                
        except ClientError as e:
            logger.error(f"Error getting role permissions: {e}")
        
        return policies
    
    def _has_permission(self, policies: List[Dict], action: str) -> bool:
        """Check if policies grant a specific action."""
        for policy in policies:
            for statement in policy.get("Statement", []):
                if statement.get("Effect") != "Allow":
                    continue
                
                actions = statement.get("Action", [])
                if isinstance(actions, str):
                    actions = [actions]
                
                for policy_action in actions:
                    if policy_action == "*" or policy_action == action:
                        return True
                    
                    # Check wildcard
                    if policy_action.endswith("*"):
                        prefix = policy_action[:-1]
                        if action.startswith(prefix):
                            return True
        
        return False
    
    def _has_admin_permissions(self, policies: List[Dict]) -> bool:
        """Check if policies grant admin-level access."""
        admin_indicators = [
            "*:*",
            "iam:*",
            "AdministratorAccess",
        ]
        
        for policy in policies:
            for statement in policy.get("Statement", []):
                if statement.get("Effect") != "Allow":
                    continue
                
                actions = statement.get("Action", [])
                resources = statement.get("Resource", [])
                
                if isinstance(actions, str):
                    actions = [actions]
                if isinstance(resources, str):
                    resources = [resources]
                
                if "*" in actions and "*" in resources:
                    return True
        
        return False
    
    def _allows_external_access(self, trust_policy: Dict) -> bool:
        """Check if trust policy allows external access."""
        for statement in trust_policy.get("Statement", []):
            if statement.get("Effect") != "Allow":
                continue
            
            principal = statement.get("Principal", {})
            
            if principal == "*":
                return True
            
            if isinstance(principal, dict):
                aws_principals = principal.get("AWS", [])
                if isinstance(aws_principals, str):
                    aws_principals = [aws_principals]
                
                for p in aws_principals:
                    # External account
                    if ":root" in p or p == "*":
                        return True
        
        return False
    
    def _extract_principals_from_trust(self, trust_policy: Dict) -> List[str]:
        """Extract all principals from trust policy."""
        principals = []
        
        for statement in trust_policy.get("Statement", []):
            if statement.get("Effect") != "Allow":
                continue
            
            principal = statement.get("Principal", {})
            
            if principal == "*":
                principals.append("*")
            elif isinstance(principal, dict):
                for principal_type, values in principal.items():
                    if isinstance(values, str):
                        values = [values]
                    principals.extend(values)
        
        return principals
    
    def _find_assume_chains(
        self,
        role_graph: Dict,
        target_arn: str,
        max_depth: int = 3,
    ) -> List[List[str]]:
        """Find all chains that can reach target role."""
        chains = []
        
        def dfs(current_arn: str, path: List[str], depth: int):
            if depth > max_depth:
                return
            
            if current_arn == target_arn and len(path) > 1:
                chains.append(path + [current_arn])
                return
            
            if current_arn in path:
                return  # Cycle
            
            if current_arn not in role_graph:
                return
            
            new_path = path + [current_arn]
            
            # Find roles that can assume current role
            for role_arn, role_info in role_graph.items():
                if current_arn in role_info.get("assumable_by", []):
                    dfs(role_arn, new_path, depth + 1)
        
        # Start from any role
        for start_arn in role_graph:
            if start_arn != target_arn:
                dfs(start_arn, [], 0)
        
        return chains
    
    async def _check_s3_policies(self, account_id: str) -> List[IAMEdgeCaseFinding]:
        """Check S3 bucket policies for risks."""
        findings = []
        
        try:
            s3 = self.plugin._get_client("s3")
            
            buckets = s3.list_buckets().get("Buckets", [])
            
            for bucket in buckets:
                bucket_name = bucket["Name"]
                
                try:
                    policy = s3.get_bucket_policy(Bucket=bucket_name)
                    policy_doc = json.loads(policy["Policy"])
                    
                    for statement in policy_doc.get("Statement", []):
                        principal = statement.get("Principal", {})
                        
                        if principal == "*" and statement.get("Effect") == "Allow":
                            # Check for conditions
                            conditions = statement.get("Condition", {})
                            if not conditions:
                                findings.append(IAMEdgeCaseFinding(
                                    finding_type="resource_policy",
                                    severity=SeverityLevel.CRITICAL,
                                    title="S3 Bucket Public Access",
                                    description=f"Bucket {bucket_name} allows public access without conditions",
                                    resource_type="S3::Bucket",
                                    resource_id=bucket_name,
                                    evidence={"policy": statement},
                                    mitre_technique="T1530",
                                    recommendation="Add conditions or restrict principal",
                                ))
                                
                except ClientError as e:
                    if "NoSuchBucketPolicy" not in str(e):
                        pass
                        
        except ClientError as e:
            logger.error(f"Error checking S3 policies: {e}")
        
        return findings
    
    async def _check_kms_policies(self, account_id: str) -> List[IAMEdgeCaseFinding]:
        """Check KMS key policies for risks."""
        findings = []
        
        try:
            kms = self.plugin._get_client("kms")
            
            paginator = kms.get_paginator("list_keys")
            for page in paginator.paginate():
                for key in page.get("Keys", []):
                    key_id = key["KeyId"]
                    
                    try:
                        policy = kms.get_key_policy(KeyId=key_id, PolicyName="default")
                        policy_doc = json.loads(policy["Policy"])
                        
                        for statement in policy_doc.get("Statement", []):
                            principal = statement.get("Principal", {})
                            
                            if principal == "*" and statement.get("Effect") == "Allow":
                                findings.append(IAMEdgeCaseFinding(
                                    finding_type="resource_policy",
                                    severity=SeverityLevel.CRITICAL,
                                    title="KMS Key Public Access",
                                    description=f"KMS key {key_id} allows public access",
                                    resource_type="KMS::Key",
                                    resource_id=key_id,
                                    evidence={"policy": statement},
                                    mitre_technique="T1552",
                                    recommendation="Restrict KMS key access to specific principals",
                                ))
                                
                    except ClientError:
                        pass
                        
        except ClientError as e:
            logger.error(f"Error checking KMS policies: {e}")
        
        return findings
    
    async def _check_sqs_policies(self, account_id: str) -> List[IAMEdgeCaseFinding]:
        """Check SQS queue policies for risks."""
        findings = []
        
        try:
            sqs = self.plugin._get_client("sqs")
            
            queues = sqs.list_queues().get("QueueUrls", [])
            
            for queue_url in queues:
                try:
                    attrs = sqs.get_queue_attributes(
                        QueueUrl=queue_url,
                        AttributeNames=["Policy"]
                    )
                    
                    if "Policy" in attrs.get("Attributes", {}):
                        policy_doc = json.loads(attrs["Attributes"]["Policy"])
                        
                        for statement in policy_doc.get("Statement", []):
                            principal = statement.get("Principal", {})
                            
                            if principal == "*" and statement.get("Effect") == "Allow":
                                queue_name = queue_url.split("/")[-1]
                                findings.append(IAMEdgeCaseFinding(
                                    finding_type="resource_policy",
                                    severity=SeverityLevel.HIGH,
                                    title="SQS Queue Public Access",
                                    description=f"SQS queue {queue_name} allows public access",
                                    resource_type="SQS::Queue",
                                    resource_id=queue_name,
                                    evidence={"policy": statement},
                                    mitre_technique="T1530",
                                    recommendation="Restrict SQS queue access",
                                ))
                                
                except ClientError:
                    pass
                    
        except ClientError as e:
            logger.error(f"Error checking SQS policies: {e}")
        
        return findings
    
    async def _check_sns_policies(self, account_id: str) -> List[IAMEdgeCaseFinding]:
        """Check SNS topic policies for risks."""
        findings = []
        
        try:
            sns = self.plugin._get_client("sns")
            
            paginator = sns.get_paginator("list_topics")
            for page in paginator.paginate():
                for topic in page.get("Topics", []):
                    topic_arn = topic["TopicArn"]
                    
                    try:
                        attrs = sns.get_topic_attributes(TopicArn=topic_arn)
                        
                        if "Policy" in attrs.get("Attributes", {}):
                            policy_doc = json.loads(attrs["Attributes"]["Policy"])
                            
                            for statement in policy_doc.get("Statement", []):
                                principal = statement.get("Principal", {})
                                
                                if principal == "*" and statement.get("Effect") == "Allow":
                                    topic_name = topic_arn.split(":")[-1]
                                    findings.append(IAMEdgeCaseFinding(
                                        finding_type="resource_policy",
                                        severity=SeverityLevel.HIGH,
                                        title="SNS Topic Public Access",
                                        description=f"SNS topic {topic_name} allows public access",
                                        resource_type="SNS::Topic",
                                        resource_id=topic_name,
                                        evidence={"policy": statement},
                                        mitre_technique="T1530",
                                        recommendation="Restrict SNS topic access",
                                    ))
                                    
                    except ClientError:
                        pass
                        
        except ClientError as e:
            logger.error(f"Error checking SNS policies: {e}")
        
        return findings
    
    async def _check_lambda_policies(self, account_id: str) -> List[IAMEdgeCaseFinding]:
        """Check Lambda function policies for risks."""
        findings = []
        
        try:
            lambda_client = self.plugin._get_client("lambda")
            
            paginator = lambda_client.get_paginator("list_functions")
            for page in paginator.paginate():
                for function in page.get("Functions", []):
                    func_name = function["FunctionName"]
                    
                    try:
                        policy = lambda_client.get_policy(FunctionName=func_name)
                        policy_doc = json.loads(policy["Policy"])
                        
                        for statement in policy_doc.get("Statement", []):
                            principal = statement.get("Principal", {})
                            
                            if principal == "*" and statement.get("Effect") == "Allow":
                                findings.append(IAMEdgeCaseFinding(
                                    finding_type="resource_policy",
                                    severity=SeverityLevel.HIGH,
                                    title="Lambda Public Access",
                                    description=f"Lambda {func_name} allows public invocation",
                                    resource_type="Lambda::Function",
                                    resource_id=func_name,
                                    evidence={"policy": statement},
                                    mitre_technique="T1648",
                                    recommendation="Restrict Lambda invocation permissions",
                                ))
                                
                    except ClientError as e:
                        if "ResourceNotFoundException" not in str(e):
                            pass
                            
        except ClientError as e:
            logger.error(f"Error checking Lambda policies: {e}")
        
        return findings
    
    async def scan(
        self,
        account_id: str,
        options: ScanOptions,
    ) -> List[IAMEdgeCaseFinding]:
        """
        Perform comprehensive IAM edge cases scan.
        
        Args:
            account_id: AWS account ID
            options: Scan options
            
        Returns:
            List of all findings
        """
        all_findings = []
        
        # Check privilege escalation paths
        priv_esc = await self.check_privilege_escalation_paths(account_id, options)
        all_findings.extend(priv_esc)
        
        # Check SCP bypass
        scp_bypass = await self.check_scp_bypass(account_id, options)
        all_findings.extend(scp_bypass)
        
        # Check permission boundaries
        perm_boundaries = await self.check_permission_boundaries(account_id, options)
        all_findings.extend(perm_boundaries)
        
        # Check resource-based policies
        resource_policies = await self.check_resource_based_policies(account_id, options)
        all_findings.extend(resource_policies)
        
        # Check assume role chains
        role_chains = await self.check_assume_role_chains(account_id, options)
        all_findings.extend(role_chains)
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[IAMEdgeCaseFinding]:
        """Get all findings."""
        return self.findings

