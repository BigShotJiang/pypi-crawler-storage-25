"""
Database Extended Security Service

Extended AWS database security checks:
- ElastiCache security
- DocumentDB security
- Neptune security
- Redshift security
- DynamoDB security
- MemoryDB security

MITRE ATT&CK:
- T1213: Data from Information Repositories
- T1552: Unsecured Credentials
- T1190: Exploit Public-Facing Application
- T1530: Data from Cloud Storage Object
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception

logger = logging.getLogger(__name__)


class DatabaseSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class DatabaseFindingType(str, Enum):
    """Types of database security findings."""
    ENCRYPTION = "encryption"
    ACCESS_CONTROL = "access_control"
    NETWORK = "network"
    AUTHENTICATION = "authentication"
    CONFIGURATION = "configuration"
    BACKUP = "backup"
    LOGGING = "logging"


# =============================================================================
# ElastiCache Security Checks
# =============================================================================

ELASTICACHE_CHECKS = {
    "no_encryption_at_rest": {
        "name": "ElastiCache No Encryption at Rest",
        "description": "ElastiCache cluster without encryption at rest",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1530",
    },
    "no_encryption_in_transit": {
        "name": "ElastiCache No Encryption in Transit",
        "description": "ElastiCache cluster without TLS encryption",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1040",
    },
    "no_auth_token": {
        "name": "ElastiCache No AUTH Token",
        "description": "Redis cluster without AUTH token authentication",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1552",
    },
    "public_access": {
        "name": "ElastiCache Public Access",
        "description": "ElastiCache cluster accessible from internet",
        "severity": DatabaseSeverity.CRITICAL,
        "mitre": "T1190",
    },
    "default_port": {
        "name": "ElastiCache Default Port",
        "description": "ElastiCache using default port (6379/11211)",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1046",
    },
    "no_backup": {
        "name": "ElastiCache No Backup",
        "description": "ElastiCache without automatic backups",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1490",
    },
    "single_az": {
        "name": "ElastiCache Single AZ",
        "description": "ElastiCache cluster in single availability zone",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1499",
    },
}


# =============================================================================
# DocumentDB Security Checks
# =============================================================================

DOCUMENTDB_CHECKS = {
    "no_encryption": {
        "name": "DocumentDB No Encryption",
        "description": "DocumentDB cluster without encryption at rest",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1530",
    },
    "no_tls": {
        "name": "DocumentDB No TLS",
        "description": "DocumentDB cluster without TLS enabled",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1040",
    },
    "public_access": {
        "name": "DocumentDB Public Access",
        "description": "DocumentDB cluster publicly accessible",
        "severity": DatabaseSeverity.CRITICAL,
        "mitre": "T1190",
    },
    "no_audit_logs": {
        "name": "DocumentDB No Audit Logs",
        "description": "DocumentDB without audit logging enabled",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "no_backup": {
        "name": "DocumentDB No Backup",
        "description": "DocumentDB without backup retention",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1490",
    },
    "master_username_default": {
        "name": "DocumentDB Default Username",
        "description": "DocumentDB using default master username",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1078",
        "default_usernames": ["admin", "docdb", "root", "master"],
    },
}


# =============================================================================
# Neptune Security Checks
# =============================================================================

NEPTUNE_CHECKS = {
    "no_encryption": {
        "name": "Neptune No Encryption",
        "description": "Neptune cluster without encryption at rest",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1530",
    },
    "no_iam_auth": {
        "name": "Neptune No IAM Auth",
        "description": "Neptune cluster without IAM authentication",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1552",
    },
    "public_access": {
        "name": "Neptune Public Access",
        "description": "Neptune cluster publicly accessible",
        "severity": DatabaseSeverity.CRITICAL,
        "mitre": "T1190",
    },
    "no_audit_logs": {
        "name": "Neptune No Audit Logs",
        "description": "Neptune without audit logging enabled",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "no_backup": {
        "name": "Neptune No Backup",
        "description": "Neptune without backup retention",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1490",
    },
    "deletion_protection_disabled": {
        "name": "Neptune Deletion Protection Disabled",
        "description": "Neptune cluster without deletion protection",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1485",
    },
}


# =============================================================================
# Redshift Security Checks
# =============================================================================

REDSHIFT_CHECKS = {
    "no_encryption": {
        "name": "Redshift No Encryption",
        "description": "Redshift cluster without encryption at rest",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1530",
    },
    "public_access": {
        "name": "Redshift Public Access",
        "description": "Redshift cluster publicly accessible",
        "severity": DatabaseSeverity.CRITICAL,
        "mitre": "T1190",
    },
    "no_ssl": {
        "name": "Redshift No SSL",
        "description": "Redshift cluster without SSL required",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1040",
    },
    "no_audit_logging": {
        "name": "Redshift No Audit Logging",
        "description": "Redshift without audit logging to S3",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "no_user_activity_logging": {
        "name": "Redshift No User Activity Logging",
        "description": "Redshift without user activity logging",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "default_port": {
        "name": "Redshift Default Port",
        "description": "Redshift using default port (5439)",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1046",
    },
    "no_backup": {
        "name": "Redshift No Backup",
        "description": "Redshift without automated snapshots",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1490",
    },
    "default_database": {
        "name": "Redshift Default Database",
        "description": "Redshift using default database name 'dev'",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1078",
    },
    "version_upgrade_disabled": {
        "name": "Redshift Version Upgrade Disabled",
        "description": "Redshift without automatic version upgrades",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1190",
    },
}


# =============================================================================
# DynamoDB Security Checks
# =============================================================================

DYNAMODB_CHECKS = {
    "no_encryption": {
        "name": "DynamoDB No Encryption",
        "description": "DynamoDB table without encryption",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1530",
    },
    "no_pitr": {
        "name": "DynamoDB No PITR",
        "description": "DynamoDB table without Point-in-Time Recovery",
        "severity": DatabaseSeverity.MEDIUM,
        "mitre": "T1490",
    },
    "no_deletion_protection": {
        "name": "DynamoDB No Deletion Protection",
        "description": "DynamoDB table without deletion protection",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1485",
    },
    "public_stream": {
        "name": "DynamoDB Public Stream",
        "description": "DynamoDB stream with public access policy",
        "severity": DatabaseSeverity.HIGH,
        "mitre": "T1213",
    },
    "autoscaling_disabled": {
        "name": "DynamoDB Autoscaling Disabled",
        "description": "DynamoDB table without autoscaling",
        "severity": DatabaseSeverity.LOW,
        "mitre": "T1499",
    },
}


@dataclass
class DatabaseSecurityFinding:
    """A database security finding."""
    finding_type: DatabaseFindingType
    severity: DatabaseSeverity
    service: str
    resource_id: str
    name: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class DatabaseSecurityReport:
    """Database security report."""
    findings: List[DatabaseSecurityFinding] = field(default_factory=list)
    elasticache_clusters: int = 0
    documentdb_clusters: int = 0
    neptune_clusters: int = 0
    redshift_clusters: int = 0
    dynamodb_tables: int = 0
    risk_score: float = 0.0


class DatabaseExtendedService:
    """Extended database security service."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[DatabaseSecurityFinding] = []
    
    async def check_elasticache(
        self,
        elasticache_client,
    ) -> List[DatabaseSecurityFinding]:
        """
        Check ElastiCache security.
        
        Args:
            elasticache_client: boto3 ElastiCache client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # Check Redis clusters
            clusters = elasticache_client.describe_cache_clusters(ShowCacheNodeInfo=True)
            
            for cluster in clusters.get("CacheClusters", []):
                cluster_id = cluster.get("CacheClusterId", "")
                engine = cluster.get("Engine", "")
                port = cluster.get("CacheNodes", [{}])[0].get("Endpoint", {}).get("Port", 0)
                
                # Check encryption at rest
                if not cluster.get("AtRestEncryptionEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="ElastiCache",
                        resource_id=cluster_id,
                        name="ElastiCache No Encryption at Rest",
                        description=f"ElastiCache cluster {cluster_id} has no encryption at rest",
                        evidence={"encryption_at_rest": False},
                        remediation="Enable encryption at rest (requires cluster recreation)",
                        mitre_technique="T1530",
                    ))
                
                # Check encryption in transit
                if not cluster.get("TransitEncryptionEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="ElastiCache",
                        resource_id=cluster_id,
                        name="ElastiCache No Encryption in Transit",
                        description=f"ElastiCache cluster {cluster_id} has no TLS encryption",
                        evidence={"encryption_in_transit": False},
                        remediation="Enable transit encryption",
                        mitre_technique="T1040",
                    ))
                
                # Check AUTH token for Redis
                if engine == "redis" and not cluster.get("AuthTokenEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.AUTHENTICATION,
                        severity=DatabaseSeverity.HIGH,
                        service="ElastiCache",
                        resource_id=cluster_id,
                        name="ElastiCache No AUTH Token",
                        description=f"Redis cluster {cluster_id} has no AUTH token",
                        evidence={"auth_token": False},
                        remediation="Enable AUTH token authentication",
                        mitre_technique="T1552",
                    ))
                
                # Check default port
                if (engine == "redis" and port == 6379) or (engine == "memcached" and port == 11211):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="ElastiCache",
                        resource_id=cluster_id,
                        name="ElastiCache Default Port",
                        description=f"ElastiCache cluster {cluster_id} uses default port {port}",
                        evidence={"port": port},
                        remediation="Consider using non-default port",
                        mitre_technique="T1046",
                    ))
                
                # Check snapshot retention
                if cluster.get("SnapshotRetentionLimit", 0) == 0:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.BACKUP,
                        severity=DatabaseSeverity.MEDIUM,
                        service="ElastiCache",
                        resource_id=cluster_id,
                        name="ElastiCache No Backup",
                        description=f"ElastiCache cluster {cluster_id} has no automatic backups",
                        evidence={"snapshot_retention": 0},
                        remediation="Enable automatic backups",
                        mitre_technique="T1490",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking ElastiCache: {e}")
        
        return findings
    
    async def check_documentdb(
        self,
        docdb_client,
    ) -> List[DatabaseSecurityFinding]:
        """
        Check DocumentDB security.
        
        Args:
            docdb_client: boto3 DocDB client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            clusters = docdb_client.describe_db_clusters()
            
            for cluster in clusters.get("DBClusters", []):
                cluster_id = cluster.get("DBClusterIdentifier", "")
                
                # Check encryption
                if not cluster.get("StorageEncrypted"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="DocumentDB",
                        resource_id=cluster_id,
                        name="DocumentDB No Encryption",
                        description=f"DocumentDB cluster {cluster_id} has no encryption at rest",
                        evidence={"storage_encrypted": False},
                        remediation="Enable encryption (requires cluster recreation)",
                        mitre_technique="T1530",
                    ))
                
                # Check backup retention
                if cluster.get("BackupRetentionPeriod", 0) < 7:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.BACKUP,
                        severity=DatabaseSeverity.MEDIUM,
                        service="DocumentDB",
                        resource_id=cluster_id,
                        name="DocumentDB Low Backup Retention",
                        description=f"DocumentDB cluster {cluster_id} has low backup retention",
                        evidence={"backup_retention": cluster.get("BackupRetentionPeriod")},
                        remediation="Increase backup retention to at least 7 days",
                        mitre_technique="T1490",
                    ))
                
                # Check deletion protection
                if not cluster.get("DeletionProtection"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="DocumentDB",
                        resource_id=cluster_id,
                        name="DocumentDB Deletion Protection Disabled",
                        description=f"DocumentDB cluster {cluster_id} has no deletion protection",
                        evidence={"deletion_protection": False},
                        remediation="Enable deletion protection",
                        mitre_technique="T1485",
                    ))
                
                # Check audit logs
                enabled_logs = cluster.get("EnabledCloudwatchLogsExports", [])
                if "audit" not in enabled_logs:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.LOGGING,
                        severity=DatabaseSeverity.MEDIUM,
                        service="DocumentDB",
                        resource_id=cluster_id,
                        name="DocumentDB No Audit Logs",
                        description=f"DocumentDB cluster {cluster_id} has no audit logging",
                        evidence={"enabled_logs": enabled_logs},
                        remediation="Enable audit logging to CloudWatch",
                        mitre_technique="T1562.008",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking DocumentDB: {e}")
        
        return findings
    
    async def check_neptune(
        self,
        neptune_client,
    ) -> List[DatabaseSecurityFinding]:
        """
        Check Neptune security.
        
        Args:
            neptune_client: boto3 Neptune client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            clusters = neptune_client.describe_db_clusters()
            
            for cluster in clusters.get("DBClusters", []):
                cluster_id = cluster.get("DBClusterIdentifier", "")
                
                # Check encryption
                if not cluster.get("StorageEncrypted"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="Neptune",
                        resource_id=cluster_id,
                        name="Neptune No Encryption",
                        description=f"Neptune cluster {cluster_id} has no encryption at rest",
                        evidence={"storage_encrypted": False},
                        remediation="Enable encryption (requires cluster recreation)",
                        mitre_technique="T1530",
                    ))
                
                # Check IAM auth
                if not cluster.get("IAMDatabaseAuthenticationEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.AUTHENTICATION,
                        severity=DatabaseSeverity.MEDIUM,
                        service="Neptune",
                        resource_id=cluster_id,
                        name="Neptune No IAM Auth",
                        description=f"Neptune cluster {cluster_id} has no IAM authentication",
                        evidence={"iam_auth": False},
                        remediation="Enable IAM database authentication",
                        mitre_technique="T1552",
                    ))
                
                # Check deletion protection
                if not cluster.get("DeletionProtection"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="Neptune",
                        resource_id=cluster_id,
                        name="Neptune Deletion Protection Disabled",
                        description=f"Neptune cluster {cluster_id} has no deletion protection",
                        evidence={"deletion_protection": False},
                        remediation="Enable deletion protection",
                        mitre_technique="T1485",
                    ))
                
                # Check audit logs
                enabled_logs = cluster.get("EnabledCloudwatchLogsExports", [])
                if "audit" not in enabled_logs:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.LOGGING,
                        severity=DatabaseSeverity.MEDIUM,
                        service="Neptune",
                        resource_id=cluster_id,
                        name="Neptune No Audit Logs",
                        description=f"Neptune cluster {cluster_id} has no audit logging",
                        evidence={"enabled_logs": enabled_logs},
                        remediation="Enable audit logging to CloudWatch",
                        mitre_technique="T1562.008",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking Neptune: {e}")
        
        return findings
    
    async def check_redshift(
        self,
        redshift_client,
    ) -> List[DatabaseSecurityFinding]:
        """
        Check Redshift security.
        
        Args:
            redshift_client: boto3 Redshift client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            clusters = redshift_client.describe_clusters()
            
            for cluster in clusters.get("Clusters", []):
                cluster_id = cluster.get("ClusterIdentifier", "")
                
                # Check encryption
                if not cluster.get("Encrypted"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift No Encryption",
                        description=f"Redshift cluster {cluster_id} has no encryption at rest",
                        evidence={"encrypted": False},
                        remediation="Enable encryption (requires cluster recreation)",
                        mitre_technique="T1530",
                    ))
                
                # Check public access
                if cluster.get("PubliclyAccessible"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.NETWORK,
                        severity=DatabaseSeverity.CRITICAL,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift Public Access",
                        description=f"Redshift cluster {cluster_id} is publicly accessible",
                        evidence={"publicly_accessible": True},
                        remediation="Disable public accessibility",
                        mitre_technique="T1190",
                    ))
                
                # Check default port
                port = cluster.get("Endpoint", {}).get("Port", 0)
                if port == 5439:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift Default Port",
                        description=f"Redshift cluster {cluster_id} uses default port 5439",
                        evidence={"port": port},
                        remediation="Consider using non-default port",
                        mitre_technique="T1046",
                    ))
                
                # Check logging
                if not cluster.get("LoggingEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.LOGGING,
                        severity=DatabaseSeverity.MEDIUM,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift No Audit Logging",
                        description=f"Redshift cluster {cluster_id} has no audit logging",
                        evidence={"logging_enabled": False},
                        remediation="Enable audit logging to S3",
                        mitre_technique="T1562.008",
                    ))
                
                # Check automated snapshots
                if cluster.get("AutomatedSnapshotRetentionPeriod", 0) == 0:
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.BACKUP,
                        severity=DatabaseSeverity.MEDIUM,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift No Backup",
                        description=f"Redshift cluster {cluster_id} has no automated snapshots",
                        evidence={"snapshot_retention": 0},
                        remediation="Enable automated snapshots",
                        mitre_technique="T1490",
                    ))
                
                # Check version upgrade
                if not cluster.get("AllowVersionUpgrade"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="Redshift",
                        resource_id=cluster_id,
                        name="Redshift Version Upgrade Disabled",
                        description=f"Redshift cluster {cluster_id} has version upgrades disabled",
                        evidence={"version_upgrade": False},
                        remediation="Enable automatic version upgrades",
                        mitre_technique="T1190",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking Redshift: {e}")
        
        return findings
    
    async def check_dynamodb(
        self,
        dynamodb_client,
    ) -> List[DatabaseSecurityFinding]:
        """
        Check DynamoDB security.
        
        Args:
            dynamodb_client: boto3 DynamoDB client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            tables = dynamodb_client.list_tables()
            
            for table_name in tables.get("TableNames", []):
                # Get table details
                table = dynamodb_client.describe_table(TableName=table_name)
                table_info = table.get("Table", {})
                
                # Check encryption
                sse = table_info.get("SSEDescription", {})
                if sse.get("Status") != "ENABLED":
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.ENCRYPTION,
                        severity=DatabaseSeverity.HIGH,
                        service="DynamoDB",
                        resource_id=table_name,
                        name="DynamoDB No Encryption",
                        description=f"DynamoDB table {table_name} has no encryption",
                        evidence={"sse_status": sse.get("Status")},
                        remediation="Enable server-side encryption",
                        mitre_technique="T1530",
                    ))
                
                # Check deletion protection
                if not table_info.get("DeletionProtectionEnabled"):
                    findings.append(DatabaseSecurityFinding(
                        finding_type=DatabaseFindingType.CONFIGURATION,
                        severity=DatabaseSeverity.LOW,
                        service="DynamoDB",
                        resource_id=table_name,
                        name="DynamoDB No Deletion Protection",
                        description=f"DynamoDB table {table_name} has no deletion protection",
                        evidence={"deletion_protection": False},
                        remediation="Enable deletion protection",
                        mitre_technique="T1485",
                    ))
                
                # Check PITR
                try:
                    pitr = dynamodb_client.describe_continuous_backups(TableName=table_name)
                    pitr_status = pitr.get("ContinuousBackupsDescription", {}).get(
                        "PointInTimeRecoveryDescription", {}
                    ).get("PointInTimeRecoveryStatus")
                    
                    if pitr_status != "ENABLED":
                        findings.append(DatabaseSecurityFinding(
                            finding_type=DatabaseFindingType.BACKUP,
                            severity=DatabaseSeverity.MEDIUM,
                            service="DynamoDB",
                            resource_id=table_name,
                            name="DynamoDB No PITR",
                            description=f"DynamoDB table {table_name} has no Point-in-Time Recovery",
                            evidence={"pitr_status": pitr_status},
                            remediation="Enable Point-in-Time Recovery",
                            mitre_technique="T1490",
                        ))
                        
                except ClientError:
                    pass
                    
        except ClientError as e:
            logger.error(f"Error checking DynamoDB: {e}")
        
        return findings
    
    async def run_full_scan(
        self,
        elasticache_client=None,
        docdb_client=None,
        neptune_client=None,
        redshift_client=None,
        dynamodb_client=None,
    ) -> DatabaseSecurityReport:
        """
        Run full database security scan.
        
        Args:
            elasticache_client: boto3 ElastiCache client
            docdb_client: boto3 DocDB client
            neptune_client: boto3 Neptune client
            redshift_client: boto3 Redshift client
            dynamodb_client: boto3 DynamoDB client
            
        Returns:
            DatabaseSecurityReport
        """
        all_findings = []
        elasticache_clusters = 0
        documentdb_clusters = 0
        neptune_clusters = 0
        redshift_clusters = 0
        dynamodb_tables = 0
        
        if elasticache_client:
            ec_findings = await self.check_elasticache(elasticache_client)
            all_findings.extend(ec_findings)
            elasticache_clusters = len(set(f.resource_id for f in ec_findings))
        
        if docdb_client:
            docdb_findings = await self.check_documentdb(docdb_client)
            all_findings.extend(docdb_findings)
            documentdb_clusters = len(set(f.resource_id for f in docdb_findings))
        
        if neptune_client:
            neptune_findings = await self.check_neptune(neptune_client)
            all_findings.extend(neptune_findings)
            neptune_clusters = len(set(f.resource_id for f in neptune_findings))
        
        if redshift_client:
            redshift_findings = await self.check_redshift(redshift_client)
            all_findings.extend(redshift_findings)
            redshift_clusters = len(set(f.resource_id for f in redshift_findings))
        
        if dynamodb_client:
            dynamodb_findings = await self.check_dynamodb(dynamodb_client)
            all_findings.extend(dynamodb_findings)
            dynamodb_tables = len(set(f.resource_id for f in dynamodb_findings))
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return DatabaseSecurityReport(
            findings=all_findings,
            elasticache_clusters=elasticache_clusters,
            documentdb_clusters=documentdb_clusters,
            neptune_clusters=neptune_clusters,
            redshift_clusters=redshift_clusters,
            dynamodb_tables=dynamodb_tables,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[DatabaseSecurityFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            DatabaseSeverity.CRITICAL: 10,
            DatabaseSeverity.HIGH: 7,
            DatabaseSeverity.MEDIUM: 4,
            DatabaseSeverity.LOW: 1,
            DatabaseSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[DatabaseSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_check_databases(self) -> Dict[str, Any]:
        """Get all check databases."""
        return {
            "elasticache_checks": ELASTICACHE_CHECKS,
            "documentdb_checks": DOCUMENTDB_CHECKS,
            "neptune_checks": NEPTUNE_CHECKS,
            "redshift_checks": REDSHIFT_CHECKS,
            "dynamodb_checks": DYNAMODB_CHECKS,
        }

