"""
Data Exfiltration Service

Detection and analysis of data exfiltration techniques:
- Cloud storage exfiltration (S3, GCS, Azure Blob)
- Database exfiltration
- API-based exfiltration
- DNS tunneling
- HTTPS exfiltration
- Container data theft
- Serverless exfiltration

MITRE ATT&CK:
- T1567: Exfiltration Over Web Service
- T1537: Transfer Data to Cloud Account
- T1048: Exfiltration Over Alternative Protocol
- T1030: Data Transfer Size Limits
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception

logger = logging.getLogger(__name__)


class ExfiltrationChannel(str, Enum):
    """Data exfiltration channels."""
    S3_BUCKET = "s3_bucket"
    S3_OBJECT_LAMBDA = "s3_object_lambda"
    S3_REPLICATION = "s3_replication"
    RDS_SNAPSHOT = "rds_snapshot"
    EC2_AMI = "ec2_ami"
    EBS_SNAPSHOT = "ebs_snapshot"
    LAMBDA_LAYERS = "lambda_layers"
    ECR_IMAGES = "ecr_images"
    SECRETS_MANAGER = "secrets_manager"
    SSM_PARAMETER = "ssm_parameter"
    DNS_TUNNELING = "dns_tunneling"
    HTTPS_ENDPOINT = "https_endpoint"
    CLOUDWATCH_LOGS = "cloudwatch_logs"
    SNS_TOPIC = "sns_topic"
    SQS_QUEUE = "sqs_queue"
    KINESIS_STREAM = "kinesis_stream"
    FIREHOSE = "firehose"


class Severity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


# =============================================================================
# Exfiltration Techniques
# =============================================================================

EXFILTRATION_TECHNIQUES = {
    "s3_cross_account": {
        "name": "S3 Cross-Account Exfiltration",
        "description": "Copy data to attacker-controlled S3 bucket in another account",
        "channel": ExfiltrationChannel.S3_BUCKET,
        "severity": Severity.CRITICAL,
        "mitre": "T1537",
        "indicators": [
            "s3:PutObject to external bucket",
            "Cross-account bucket policy",
            "S3 replication to external account",
        ],
        "detection": {
            "cloudtrail_events": ["PutObject", "CopyObject", "PutBucketReplication"],
            "anomaly": "Data transfer to new/unknown account",
        },
    },
    "rds_snapshot_sharing": {
        "name": "RDS Snapshot Sharing",
        "description": "Share RDS snapshot with attacker-controlled account",
        "channel": ExfiltrationChannel.RDS_SNAPSHOT,
        "severity": Severity.CRITICAL,
        "mitre": "T1537",
        "indicators": [
            "ModifyDBSnapshotAttribute to share with external account",
            "Manual snapshot creation followed by sharing",
        ],
        "detection": {
            "cloudtrail_events": ["ModifyDBSnapshotAttribute", "CreateDBSnapshot"],
        },
    },
    "ec2_ami_sharing": {
        "name": "EC2 AMI Sharing",
        "description": "Create and share AMI with attacker-controlled account",
        "channel": ExfiltrationChannel.EC2_AMI,
        "severity": Severity.HIGH,
        "mitre": "T1537",
        "indicators": [
            "CreateImage followed by ModifyImageAttribute",
            "AMI shared with unknown account",
        ],
        "detection": {
            "cloudtrail_events": ["CreateImage", "ModifyImageAttribute"],
        },
    },
    "ebs_snapshot_sharing": {
        "name": "EBS Snapshot Sharing",
        "description": "Share EBS snapshot with attacker-controlled account",
        "channel": ExfiltrationChannel.EBS_SNAPSHOT,
        "severity": Severity.HIGH,
        "mitre": "T1537",
        "indicators": [
            "ModifySnapshotAttribute to share with external account",
        ],
        "detection": {
            "cloudtrail_events": ["ModifySnapshotAttribute", "CreateSnapshot"],
        },
    },
    "lambda_exfiltration": {
        "name": "Lambda-Based Exfiltration",
        "description": "Use Lambda function to exfiltrate data to external endpoint",
        "channel": ExfiltrationChannel.LAMBDA_LAYERS,
        "severity": Severity.HIGH,
        "mitre": "T1567",
        "indicators": [
            "Lambda with internet access",
            "Lambda making external HTTP calls",
            "Unusual Lambda invocation patterns",
        ],
        "detection": {
            "cloudtrail_events": ["Invoke"],
            "vpc_flow_logs": "External HTTPS traffic from Lambda",
        },
    },
    "ecr_image_exfil": {
        "name": "ECR Image Exfiltration",
        "description": "Pull and push container images to external registry",
        "channel": ExfiltrationChannel.ECR_IMAGES,
        "severity": Severity.MEDIUM,
        "mitre": "T1537",
        "indicators": [
            "BatchGetImage from production ECR",
            "Push to external registry",
        ],
        "detection": {
            "cloudtrail_events": ["BatchGetImage", "GetDownloadUrlForLayer"],
        },
    },
    "secrets_exfiltration": {
        "name": "Secrets Manager Exfiltration",
        "description": "Extract secrets from Secrets Manager",
        "channel": ExfiltrationChannel.SECRETS_MANAGER,
        "severity": Severity.CRITICAL,
        "mitre": "T1555",
        "indicators": [
            "Bulk GetSecretValue calls",
            "Access from unusual source",
        ],
        "detection": {
            "cloudtrail_events": ["GetSecretValue", "ListSecrets"],
        },
    },
    "ssm_parameter_exfil": {
        "name": "SSM Parameter Exfiltration",
        "description": "Extract parameters from SSM Parameter Store",
        "channel": ExfiltrationChannel.SSM_PARAMETER,
        "severity": Severity.HIGH,
        "mitre": "T1555",
        "indicators": [
            "GetParameter for SecureString",
            "Bulk parameter access",
        ],
        "detection": {
            "cloudtrail_events": ["GetParameter", "GetParameters", "GetParametersByPath"],
        },
    },
    "dns_tunneling_exfil": {
        "name": "DNS Tunneling Exfiltration",
        "description": "Exfiltrate data through DNS queries",
        "channel": ExfiltrationChannel.DNS_TUNNELING,
        "severity": Severity.HIGH,
        "mitre": "T1048",
        "indicators": [
            "High volume DNS queries",
            "Long DNS query names",
            "TXT record queries",
        ],
        "detection": {
            "route53_resolver_logs": "Unusual DNS patterns",
            "vpc_flow_logs": "UDP port 53 traffic",
        },
    },
    "cloudwatch_log_exfil": {
        "name": "CloudWatch Logs Exfiltration",
        "description": "Write sensitive data to CloudWatch Logs for retrieval",
        "channel": ExfiltrationChannel.CLOUDWATCH_LOGS,
        "severity": Severity.MEDIUM,
        "mitre": "T1567",
        "indicators": [
            "Unusual log group creation",
            "Large log events",
            "Cross-account log subscription",
        ],
        "detection": {
            "cloudtrail_events": ["CreateLogGroup", "PutLogEvents", "PutSubscriptionFilter"],
        },
    },
    "sns_sqs_exfil": {
        "name": "SNS/SQS Exfiltration",
        "description": "Send data to external endpoints via SNS/SQS",
        "channel": ExfiltrationChannel.SNS_TOPIC,
        "severity": Severity.MEDIUM,
        "mitre": "T1567",
        "indicators": [
            "SNS topic with external subscription",
            "SQS queue with cross-account policy",
        ],
        "detection": {
            "cloudtrail_events": ["Publish", "SendMessage", "Subscribe"],
        },
    },
    "kinesis_firehose_exfil": {
        "name": "Kinesis/Firehose Exfiltration",
        "description": "Stream data to external destination",
        "channel": ExfiltrationChannel.KINESIS_STREAM,
        "severity": Severity.HIGH,
        "mitre": "T1567",
        "indicators": [
            "Firehose with external HTTP destination",
            "Kinesis stream with cross-account access",
        ],
        "detection": {
            "cloudtrail_events": ["PutRecord", "PutRecordBatch", "CreateDeliveryStream"],
        },
    },
}


# =============================================================================
# Data Classification Tags
# =============================================================================

SENSITIVE_DATA_TAGS = [
    "Classification=Confidential",
    "Classification=Sensitive",
    "Classification=PII",
    "Classification=PHI",
    "DataType=PII",
    "DataType=Financial",
    "DataType=Healthcare",
    "Compliance=HIPAA",
    "Compliance=PCI",
    "Compliance=GDPR",
]


@dataclass
class ExfiltrationFinding:
    """Finding related to data exfiltration."""
    channel: ExfiltrationChannel
    technique: str
    severity: Severity
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""


@dataclass
class ExfiltrationRisk:
    """Risk assessment for data exfiltration."""
    resource_type: str
    resource_id: str
    risk_level: Severity
    exfiltration_vectors: List[str] = field(default_factory=list)
    mitigations: List[str] = field(default_factory=list)


class DataExfiltrationService:
    """Service for data exfiltration detection and analysis."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[ExfiltrationFinding] = []
    
    async def check_s3_exfiltration_risks(
        self,
        s3_client,
        account_id: str,
    ) -> List[ExfiltrationFinding]:
        """
        Check S3 buckets for exfiltration risks.
        
        Args:
            s3_client: boto3 S3 client
            account_id: AWS account ID
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # List all buckets
            response = s3_client.list_buckets()
            buckets = response.get("Buckets", [])
            
            for bucket in buckets:
                bucket_name = bucket.get("Name", "")
                
                # Check bucket policy for cross-account access
                try:
                    policy_response = s3_client.get_bucket_policy(Bucket=bucket_name)
                    policy = policy_response.get("Policy", "{}")
                    
                    if self._check_cross_account_policy(policy, account_id):
                        findings.append(ExfiltrationFinding(
                            channel=ExfiltrationChannel.S3_BUCKET,
                            technique="s3_cross_account",
                            severity=Severity.HIGH,
                            description=f"Bucket {bucket_name} has cross-account access policy",
                            evidence={"bucket": bucket_name, "policy_snippet": policy[:500]},
                            mitre_technique="T1537",
                            recommendation="Review and restrict cross-account access",
                        ))
                except ClientError as e:
                    if e.response["Error"]["Code"] != "NoSuchBucketPolicy":
                        logger.debug(f"Error getting bucket policy: {e}")
                
                # Check for S3 replication to external account
                try:
                    replication = s3_client.get_bucket_replication(Bucket=bucket_name)
                    rules = replication.get("ReplicationConfiguration", {}).get("Rules", [])
                    
                    for rule in rules:
                        dest_account = rule.get("Destination", {}).get("Account", "")
                        if dest_account and dest_account != account_id:
                            findings.append(ExfiltrationFinding(
                                channel=ExfiltrationChannel.S3_REPLICATION,
                                technique="s3_cross_account",
                                severity=Severity.CRITICAL,
                                description=f"Bucket {bucket_name} replicates to external account {dest_account}",
                                evidence={"bucket": bucket_name, "destination_account": dest_account},
                                mitre_technique="T1537",
                                recommendation="Verify replication destination is authorized",
                            ))
                except ClientError as e:
                    if e.response["Error"]["Code"] != "ReplicationConfigurationNotFoundError":
                        logger.debug(f"Error getting replication config: {e}")
                        
        except Exception as e:
            logger.error(f"Error checking S3 exfiltration risks: {e}")
        
        return findings
    
    async def check_rds_exfiltration_risks(
        self,
        rds_client,
        account_id: str,
    ) -> List[ExfiltrationFinding]:
        """
        Check RDS for exfiltration risks.
        
        Args:
            rds_client: boto3 RDS client
            account_id: AWS account ID
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # Check shared snapshots
            snapshots = rds_client.describe_db_snapshots(SnapshotType="manual")
            
            for snapshot in snapshots.get("DBSnapshots", []):
                snapshot_id = snapshot.get("DBSnapshotIdentifier", "")
                
                # Check snapshot attributes
                try:
                    attrs = rds_client.describe_db_snapshot_attributes(
                        DBSnapshotIdentifier=snapshot_id
                    )
                    
                    for attr in attrs.get("DBSnapshotAttributesResult", {}).get("DBSnapshotAttributes", []):
                        if attr.get("AttributeName") == "restore":
                            values = attr.get("AttributeValues", [])
                            
                            external_accounts = [v for v in values if v != "all" and v != account_id]
                            
                            if external_accounts:
                                findings.append(ExfiltrationFinding(
                                    channel=ExfiltrationChannel.RDS_SNAPSHOT,
                                    technique="rds_snapshot_sharing",
                                    severity=Severity.CRITICAL,
                                    description=f"RDS snapshot {snapshot_id} shared with external accounts",
                                    evidence={
                                        "snapshot": snapshot_id,
                                        "shared_with": external_accounts,
                                    },
                                    mitre_technique="T1537",
                                    recommendation="Remove unauthorized snapshot sharing",
                                ))
                            
                            if "all" in values:
                                findings.append(ExfiltrationFinding(
                                    channel=ExfiltrationChannel.RDS_SNAPSHOT,
                                    technique="rds_snapshot_sharing",
                                    severity=Severity.CRITICAL,
                                    description=f"RDS snapshot {snapshot_id} is PUBLIC",
                                    evidence={"snapshot": snapshot_id, "public": True},
                                    mitre_technique="T1537",
                                    recommendation="Remove public access to snapshot immediately",
                                ))
                                
                except ClientError as e:
                    logger.debug(f"Error getting snapshot attributes: {e}")
                    
        except Exception as e:
            logger.error(f"Error checking RDS exfiltration risks: {e}")
        
        return findings
    
    async def check_ec2_exfiltration_risks(
        self,
        ec2_client,
        account_id: str,
    ) -> List[ExfiltrationFinding]:
        """
        Check EC2 for exfiltration risks (AMIs, EBS snapshots).
        
        Args:
            ec2_client: boto3 EC2 client
            account_id: AWS account ID
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # Check AMI sharing
            images = ec2_client.describe_images(Owners=["self"])
            
            for image in images.get("Images", []):
                image_id = image.get("ImageId", "")
                
                # Check image attributes
                try:
                    attrs = ec2_client.describe_image_attribute(
                        ImageId=image_id,
                        Attribute="launchPermission"
                    )
                    
                    launch_perms = attrs.get("LaunchPermissions", [])
                    
                    for perm in launch_perms:
                        if perm.get("Group") == "all":
                            findings.append(ExfiltrationFinding(
                                channel=ExfiltrationChannel.EC2_AMI,
                                technique="ec2_ami_sharing",
                                severity=Severity.CRITICAL,
                                description=f"AMI {image_id} is PUBLIC",
                                evidence={"ami": image_id, "public": True},
                                mitre_technique="T1537",
                                recommendation="Remove public access to AMI",
                            ))
                        elif perm.get("UserId") and perm.get("UserId") != account_id:
                            findings.append(ExfiltrationFinding(
                                channel=ExfiltrationChannel.EC2_AMI,
                                technique="ec2_ami_sharing",
                                severity=Severity.HIGH,
                                description=f"AMI {image_id} shared with external account",
                                evidence={
                                    "ami": image_id,
                                    "shared_with": perm.get("UserId"),
                                },
                                mitre_technique="T1537",
                                recommendation="Verify AMI sharing is authorized",
                            ))
                            
                except ClientError as e:
                    logger.debug(f"Error getting AMI attributes: {e}")
            
            # Check EBS snapshot sharing
            snapshots = ec2_client.describe_snapshots(OwnerIds=["self"])
            
            for snapshot in snapshots.get("Snapshots", []):
                snapshot_id = snapshot.get("SnapshotId", "")
                
                try:
                    attrs = ec2_client.describe_snapshot_attribute(
                        SnapshotId=snapshot_id,
                        Attribute="createVolumePermission"
                    )
                    
                    perms = attrs.get("CreateVolumePermissions", [])
                    
                    for perm in perms:
                        if perm.get("Group") == "all":
                            findings.append(ExfiltrationFinding(
                                channel=ExfiltrationChannel.EBS_SNAPSHOT,
                                technique="ebs_snapshot_sharing",
                                severity=Severity.CRITICAL,
                                description=f"EBS snapshot {snapshot_id} is PUBLIC",
                                evidence={"snapshot": snapshot_id, "public": True},
                                mitre_technique="T1537",
                                recommendation="Remove public access to snapshot",
                            ))
                        elif perm.get("UserId") and perm.get("UserId") != account_id:
                            findings.append(ExfiltrationFinding(
                                channel=ExfiltrationChannel.EBS_SNAPSHOT,
                                technique="ebs_snapshot_sharing",
                                severity=Severity.HIGH,
                                description=f"EBS snapshot {snapshot_id} shared externally",
                                evidence={
                                    "snapshot": snapshot_id,
                                    "shared_with": perm.get("UserId"),
                                },
                                mitre_technique="T1537",
                                recommendation="Verify snapshot sharing is authorized",
                            ))
                            
                except ClientError as e:
                    logger.debug(f"Error getting snapshot attributes: {e}")
                    
        except Exception as e:
            logger.error(f"Error checking EC2 exfiltration risks: {e}")
        
        return findings
    
    async def check_lambda_exfiltration_risks(
        self,
        lambda_client,
    ) -> List[ExfiltrationFinding]:
        """
        Check Lambda functions for exfiltration risks.
        
        Args:
            lambda_client: boto3 Lambda client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # List functions
            functions = lambda_client.list_functions()
            
            for func in functions.get("Functions", []):
                func_name = func.get("FunctionName", "")
                vpc_config = func.get("VpcConfig", {})
                
                # Check if Lambda has internet access
                if not vpc_config.get("VpcId"):
                    # Lambda not in VPC - has internet access by default
                    findings.append(ExfiltrationFinding(
                        channel=ExfiltrationChannel.LAMBDA_LAYERS,
                        technique="lambda_exfiltration",
                        severity=Severity.MEDIUM,
                        description=f"Lambda {func_name} has internet access (not in VPC)",
                        evidence={
                            "function": func_name,
                            "vpc": "none",
                            "internet_access": True,
                        },
                        mitre_technique="T1567",
                        recommendation="Place Lambda in VPC with controlled egress",
                    ))
                else:
                    # Check if NAT Gateway/Internet Gateway is attached
                    # This would require additional VPC inspection
                    pass
                    
        except Exception as e:
            logger.error(f"Error checking Lambda exfiltration risks: {e}")
        
        return findings
    
    async def analyze_cloudtrail_for_exfiltration(
        self,
        cloudtrail_client,
        lookback_hours: int = 24,
    ) -> List[ExfiltrationFinding]:
        """
        Analyze CloudTrail for exfiltration indicators.
        
        Args:
            cloudtrail_client: boto3 CloudTrail client
            lookback_hours: Hours to look back
            
        Returns:
            List of findings
        """
        findings = []
        
        # This would analyze CloudTrail events for exfiltration indicators
        # Implementation would use lookup_events or query CloudWatch Logs Insights
        
        suspicious_events = [
            ("ModifySnapshotAttribute", ExfiltrationChannel.EBS_SNAPSHOT),
            ("ModifyDBSnapshotAttribute", ExfiltrationChannel.RDS_SNAPSHOT),
            ("ModifyImageAttribute", ExfiltrationChannel.EC2_AMI),
            ("PutBucketReplication", ExfiltrationChannel.S3_REPLICATION),
        ]
        
        # Return informational finding about monitoring
        findings.append(ExfiltrationFinding(
            channel=ExfiltrationChannel.S3_BUCKET,
            technique="monitoring_recommendation",
            severity=Severity.INFO,
            description="Enable CloudTrail monitoring for exfiltration events",
            evidence={"events_to_monitor": [e[0] for e in suspicious_events]},
            mitre_technique="T1537",
            recommendation="Create CloudWatch alarms for suspicious events",
        ))
        
        return findings
    
    def _check_cross_account_policy(
        self,
        policy: str,
        account_id: str,
    ) -> bool:
        """Check if policy allows cross-account access."""
        import json
        
        try:
            policy_doc = json.loads(policy)
            
            for statement in policy_doc.get("Statement", []):
                principal = statement.get("Principal", {})
                
                # Check for "*" principal
                if principal == "*":
                    return True
                
                # Check for AWS principals
                if isinstance(principal, dict):
                    aws_principals = principal.get("AWS", [])
                    if isinstance(aws_principals, str):
                        aws_principals = [aws_principals]
                    
                    for p in aws_principals:
                        if p == "*":
                            return True
                        # Check if different account
                        if "arn:aws" in p:
                            # Extract account ID from ARN
                            parts = p.split(":")
                            if len(parts) >= 5:
                                principal_account = parts[4]
                                if principal_account != account_id and principal_account != "*":
                                    return True
                                    
        except json.JSONDecodeError:
            pass
        
        return False
    
    async def scan(
        self,
        s3_client=None,
        rds_client=None,
        ec2_client=None,
        lambda_client=None,
        account_id: str = None,
    ) -> List[ExfiltrationFinding]:
        """
        Perform comprehensive exfiltration risk scan.
        
        Args:
            Various boto3 clients and account ID
            
        Returns:
            List of all findings
        """
        all_findings = []
        
        if s3_client and account_id:
            s3_findings = await self.check_s3_exfiltration_risks(s3_client, account_id)
            all_findings.extend(s3_findings)
        
        if rds_client and account_id:
            rds_findings = await self.check_rds_exfiltration_risks(rds_client, account_id)
            all_findings.extend(rds_findings)
        
        if ec2_client and account_id:
            ec2_findings = await self.check_ec2_exfiltration_risks(ec2_client, account_id)
            all_findings.extend(ec2_findings)
        
        if lambda_client:
            lambda_findings = await self.check_lambda_exfiltration_risks(lambda_client)
            all_findings.extend(lambda_findings)
        
        self.findings = all_findings
        return all_findings
    
    def get_findings(self) -> List[ExfiltrationFinding]:
        """Get all findings."""
        return self.findings
    
    def get_techniques(self) -> Dict[str, Any]:
        """Get exfiltration techniques database."""
        return EXFILTRATION_TECHNIQUES

