"""
Additional AWS Services Security Check Service

Covers new AWS services security assessments:
- AppSync (GraphQL API)
- Amplify (CI/CD, hosting)
- CodeBuild/CodePipeline (Supply chain)
- Glue (Data catalog, ETL jobs)
- Step Functions (Workflow orchestration)
- Systems Manager (SSM)
- ECS/Fargate (Container tasks)
- ECR (Container registry)
- API Gateway (API security)
- Cognito (Identity management)
- Secrets Manager (Secrets rotation)
- KMS (Key management)
- CloudFormation (IaC)
- CloudWatch (Monitoring)
- EventBridge (Event routing)

MITRE ATT&CK: T1190, T1552, T1562, T1098, T1078
"""

import re
from typing import Any, Dict, List, Optional, Tuple

from ..databases.aws_databases import SECRET_PATTERNS


class AdditionalServicesCheckService:
    """Security checks for additional AWS services."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings = []
    
    # =========================================================================
    # AppSync (GraphQL API) Security Checks
    # =========================================================================
    
    def check_appsync_api_security(self, apis: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check AppSync GraphQL API security.
        
        Checks:
        - Authentication type (API_KEY, AWS_IAM, COGNITO_USER_POOLS, OPENID_CONNECT)
        - Introspection enabled
        - Logging configuration
        - WAF integration
        - X-Ray tracing
        
        Args:
            apis: List of AppSync API configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for api in apis:
            api_id = api.get("apiId", "")
            api_name = api.get("name", "")
            auth_type = api.get("authenticationType", "")
            
            # Check for weak authentication (API_KEY)
            if auth_type == "API_KEY":
                findings.append({
                    "check_id": "appsync_api_key_auth",
                    "resource_id": api_id,
                    "resource_name": api_name,
                    "resource_type": "appsync_api",
                    "severity": "high",
                    "title": "AppSync API uses API Key authentication",
                    "description": f"AppSync API '{api_name}' uses API_KEY authentication which can be leaked",
                    "recommendation": "Use AWS_IAM, COGNITO_USER_POOLS, or OPENID_CONNECT for production APIs",
                    "mitre_technique": "T1190",
                })
            
            # Check for disabled logging
            log_config = api.get("logConfig", {})
            if not log_config.get("cloudWatchLogsRoleArn"):
                findings.append({
                    "check_id": "appsync_logging_disabled",
                    "resource_id": api_id,
                    "resource_name": api_name,
                    "resource_type": "appsync_api",
                    "severity": "medium",
                    "title": "AppSync API logging disabled",
                    "description": f"AppSync API '{api_name}' does not have CloudWatch logging enabled",
                    "recommendation": "Enable CloudWatch logging for API access monitoring",
                    "mitre_technique": "T1562.008",
                })
            
            # Check for disabled X-Ray tracing
            if not api.get("xrayEnabled", False):
                findings.append({
                    "check_id": "appsync_xray_disabled",
                    "resource_id": api_id,
                    "resource_name": api_name,
                    "resource_type": "appsync_api",
                    "severity": "low",
                    "title": "AppSync X-Ray tracing disabled",
                    "description": f"AppSync API '{api_name}' does not have X-Ray tracing enabled",
                    "recommendation": "Enable X-Ray for distributed tracing",
                })
            
            # Check for WAF not associated
            if not api.get("wafWebAclArn"):
                findings.append({
                    "check_id": "appsync_no_waf",
                    "resource_id": api_id,
                    "resource_name": api_name,
                    "resource_type": "appsync_api",
                    "severity": "medium",
                    "title": "AppSync API not protected by WAF",
                    "description": f"AppSync API '{api_name}' is not protected by AWS WAF",
                    "recommendation": "Associate AWS WAF Web ACL for protection against common attacks",
                    "mitre_technique": "T1190",
                })
        
        return findings
    
    # =========================================================================
    # Amplify Security Checks
    # =========================================================================
    
    def check_amplify_app_security(self, apps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check Amplify app security.
        
        Checks:
        - Basic authentication on preview branches
        - Environment variables exposure
        - Build settings secrets
        - Custom headers security
        
        Args:
            apps: List of Amplify app configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for app in apps:
            app_id = app.get("appId", "")
            app_name = app.get("name", "")
            
            # Check for basic auth disabled
            if not app.get("basicAuthCredentials"):
                findings.append({
                    "check_id": "amplify_no_basic_auth",
                    "resource_id": app_id,
                    "resource_name": app_name,
                    "resource_type": "amplify_app",
                    "severity": "low",
                    "title": "Amplify app has no basic authentication",
                    "description": f"Amplify app '{app_name}' does not have basic auth enabled for preview branches",
                    "recommendation": "Enable basic authentication to protect preview branches",
                })
            
            # Check environment variables for secrets
            env_vars = app.get("environmentVariables", {})
            for key, value in env_vars.items():
                for pattern, secret_type in SECRET_PATTERNS:
                    if re.search(pattern, value):
                        findings.append({
                            "check_id": "amplify_env_secret",
                            "resource_id": app_id,
                            "resource_name": app_name,
                            "resource_type": "amplify_app",
                            "severity": "critical",
                            "title": f"Amplify environment contains {secret_type}",
                            "description": f"Amplify app '{app_name}' has potential {secret_type} in environment variable '{key}'",
                            "recommendation": "Use AWS Secrets Manager or SSM Parameter Store for secrets",
                            "mitre_technique": "T1552.001",
                        })
                        break
            
            # Check for auto branch creation (potential exposure)
            if app.get("enableAutoBranchCreation", False):
                auto_branch_patterns = app.get("autoBranchCreationPatterns", [])
                if "*" in auto_branch_patterns:
                    findings.append({
                        "check_id": "amplify_wildcard_auto_branch",
                        "resource_id": app_id,
                        "resource_name": app_name,
                        "resource_type": "amplify_app",
                        "severity": "medium",
                        "title": "Amplify app has wildcard auto-branch creation",
                        "description": f"Amplify app '{app_name}' creates branches for all patterns automatically",
                        "recommendation": "Restrict auto-branch creation patterns",
                    })
        
        return findings
    
    # =========================================================================
    # CodeBuild/CodePipeline Security Checks
    # =========================================================================
    
    def check_codebuild_project_security(self, projects: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check CodeBuild project security.
        
        Checks:
        - Privileged mode enabled
        - Build secrets exposure
        - Source repository security
        - Artifact encryption
        - Service role permissions
        
        Args:
            projects: List of CodeBuild project configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for project in projects:
            project_name = project.get("name", "")
            project_arn = project.get("arn", "")
            
            # Check for privileged mode
            environment = project.get("environment", {})
            if environment.get("privilegedMode", False):
                findings.append({
                    "check_id": "codebuild_privileged_mode",
                    "resource_id": project_arn,
                    "resource_name": project_name,
                    "resource_type": "codebuild_project",
                    "severity": "high",
                    "title": "CodeBuild project uses privileged mode",
                    "description": f"CodeBuild project '{project_name}' has privileged mode enabled (Docker-in-Docker)",
                    "recommendation": "Disable privileged mode unless Docker builds are required",
                    "mitre_technique": "T1611",
                })
            
            # Check environment variables for plaintext secrets
            env_vars = environment.get("environmentVariables", [])
            for env_var in env_vars:
                if env_var.get("type") == "PLAINTEXT":
                    name = env_var.get("name", "")
                    value = env_var.get("value", "")
                    
                    # Check for common secret patterns in names
                    secret_indicators = ["password", "secret", "key", "token", "api_key", "apikey", "credential"]
                    if any(indicator in name.lower() for indicator in secret_indicators):
                        findings.append({
                            "check_id": "codebuild_plaintext_secret",
                            "resource_id": project_arn,
                            "resource_name": project_name,
                            "resource_type": "codebuild_project",
                            "severity": "critical",
                            "title": "CodeBuild project has plaintext secrets",
                            "description": f"CodeBuild project '{project_name}' has potential secret in plaintext variable '{name}'",
                            "recommendation": "Use PARAMETER_STORE or SECRETS_MANAGER type for secrets",
                            "mitre_technique": "T1552.001",
                        })
            
            # Check for encryption disabled on artifacts
            artifacts = project.get("artifacts", {})
            if artifacts.get("encryptionDisabled", False):
                findings.append({
                    "check_id": "codebuild_artifacts_not_encrypted",
                    "resource_id": project_arn,
                    "resource_name": project_name,
                    "resource_type": "codebuild_project",
                    "severity": "medium",
                    "title": "CodeBuild artifacts not encrypted",
                    "description": f"CodeBuild project '{project_name}' has encryption disabled for artifacts",
                    "recommendation": "Enable encryption for build artifacts",
                    "mitre_technique": "T1530",
                })
            
            # Check for CloudWatch logs disabled
            logs_config = project.get("logsConfig", {})
            cloudwatch_logs = logs_config.get("cloudWatchLogs", {})
            if cloudwatch_logs.get("status") == "DISABLED":
                findings.append({
                    "check_id": "codebuild_logs_disabled",
                    "resource_id": project_arn,
                    "resource_name": project_name,
                    "resource_type": "codebuild_project",
                    "severity": "medium",
                    "title": "CodeBuild CloudWatch logs disabled",
                    "description": f"CodeBuild project '{project_name}' has CloudWatch logging disabled",
                    "recommendation": "Enable CloudWatch logging for build monitoring",
                    "mitre_technique": "T1562.008",
                })
        
        return findings
    
    def check_codepipeline_security(self, pipelines: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check CodePipeline security.
        
        Checks:
        - Artifact encryption
        - Service role permissions
        - Source stage security (webhooks, OAuth tokens)
        - Cross-account access
        
        Args:
            pipelines: List of CodePipeline configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for pipeline in pipelines:
            pipeline_name = pipeline.get("name", "")
            pipeline_arn = pipeline.get("pipelineArn", "")
            
            # Check artifact store encryption
            artifact_store = pipeline.get("artifactStore", {})
            encryption_key = artifact_store.get("encryptionKey", {})
            if not encryption_key.get("id"):
                findings.append({
                    "check_id": "codepipeline_no_encryption_key",
                    "resource_id": pipeline_arn,
                    "resource_name": pipeline_name,
                    "resource_type": "codepipeline",
                    "severity": "medium",
                    "title": "CodePipeline uses default encryption",
                    "description": f"CodePipeline '{pipeline_name}' uses default S3 encryption instead of KMS",
                    "recommendation": "Use KMS CMK for artifact encryption",
                })
            
            # Check stages for security issues
            stages = pipeline.get("stages", [])
            for stage in stages:
                stage_name = stage.get("name", "")
                actions = stage.get("actions", [])
                
                for action in actions:
                    action_name = action.get("name", "")
                    action_config = action.get("configuration", {})
                    
                    # Check for GitHub OAuth tokens in configuration
                    if action_config.get("OAuthToken"):
                        findings.append({
                            "check_id": "codepipeline_oauth_token",
                            "resource_id": pipeline_arn,
                            "resource_name": pipeline_name,
                            "resource_type": "codepipeline",
                            "severity": "critical",
                            "title": "CodePipeline has OAuth token in configuration",
                            "description": f"CodePipeline '{pipeline_name}' stage '{stage_name}' action '{action_name}' has OAuth token exposed",
                            "recommendation": "Use AWS Secrets Manager or CodeStar Connections for source authentication",
                            "mitre_technique": "T1552.001",
                        })
        
        return findings
    
    # =========================================================================
    # Glue Security Checks
    # =========================================================================
    
    def check_glue_security(self, jobs: List[Dict[str, Any]], crawlers: List[Dict[str, Any]], catalogs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check AWS Glue security.
        
        Checks:
        - Job security configuration
        - Data catalog encryption
        - Connection secrets
        - IAM role permissions
        
        Args:
            jobs: List of Glue job configurations
            crawlers: List of Glue crawler configurations
            catalogs: List of Glue catalog configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check Glue jobs
        for job in jobs:
            job_name = job.get("Name", "")
            
            # Check for missing security configuration
            if not job.get("SecurityConfiguration"):
                findings.append({
                    "check_id": "glue_job_no_security_config",
                    "resource_id": job_name,
                    "resource_name": job_name,
                    "resource_type": "glue_job",
                    "severity": "medium",
                    "title": "Glue job has no security configuration",
                    "description": f"Glue job '{job_name}' does not have a security configuration for encryption",
                    "recommendation": "Create and attach a security configuration with encryption enabled",
                })
            
            # Check for CloudWatch logging
            default_args = job.get("DefaultArguments", {})
            if not default_args.get("--enable-continuous-cloudwatch-log"):
                findings.append({
                    "check_id": "glue_job_no_logging",
                    "resource_id": job_name,
                    "resource_name": job_name,
                    "resource_type": "glue_job",
                    "severity": "low",
                    "title": "Glue job CloudWatch logging not enabled",
                    "description": f"Glue job '{job_name}' does not have continuous CloudWatch logging",
                    "recommendation": "Enable --enable-continuous-cloudwatch-log for job monitoring",
                    "mitre_technique": "T1562.008",
                })
        
        # Check Glue crawlers
        for crawler in crawlers:
            crawler_name = crawler.get("Name", "")
            
            if not crawler.get("CrawlerSecurityConfiguration"):
                findings.append({
                    "check_id": "glue_crawler_no_security_config",
                    "resource_id": crawler_name,
                    "resource_name": crawler_name,
                    "resource_type": "glue_crawler",
                    "severity": "medium",
                    "title": "Glue crawler has no security configuration",
                    "description": f"Glue crawler '{crawler_name}' does not have a security configuration",
                    "recommendation": "Attach a security configuration with encryption",
                })
        
        return findings
    
    # =========================================================================
    # Step Functions Security Checks
    # =========================================================================
    
    def check_step_functions_security(self, state_machines: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check Step Functions security.
        
        Checks:
        - Logging configuration
        - Tracing configuration
        - IAM role permissions
        - Definition secrets exposure
        
        Args:
            state_machines: List of Step Functions state machine configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for sm in state_machines:
            sm_name = sm.get("name", "")
            sm_arn = sm.get("stateMachineArn", "")
            
            # Check for disabled logging
            logging_config = sm.get("loggingConfiguration", {})
            if logging_config.get("level") == "OFF" or not logging_config.get("destinations"):
                findings.append({
                    "check_id": "stepfunctions_logging_disabled",
                    "resource_id": sm_arn,
                    "resource_name": sm_name,
                    "resource_type": "step_function",
                    "severity": "medium",
                    "title": "Step Functions logging disabled",
                    "description": f"Step Functions state machine '{sm_name}' has logging disabled",
                    "recommendation": "Enable CloudWatch logging for execution monitoring",
                    "mitre_technique": "T1562.008",
                })
            
            # Check for disabled tracing
            tracing_config = sm.get("tracingConfiguration", {})
            if not tracing_config.get("enabled", False):
                findings.append({
                    "check_id": "stepfunctions_tracing_disabled",
                    "resource_id": sm_arn,
                    "resource_name": sm_name,
                    "resource_type": "step_function",
                    "severity": "low",
                    "title": "Step Functions X-Ray tracing disabled",
                    "description": f"Step Functions state machine '{sm_name}' does not have X-Ray tracing enabled",
                    "recommendation": "Enable X-Ray tracing for distributed tracing",
                })
            
            # Check definition for hardcoded secrets
            definition = sm.get("definition", "")
            for pattern, secret_type in SECRET_PATTERNS:
                if re.search(pattern, definition):
                    findings.append({
                        "check_id": "stepfunctions_hardcoded_secret",
                        "resource_id": sm_arn,
                        "resource_name": sm_name,
                        "resource_type": "step_function",
                        "severity": "critical",
                        "title": f"Step Functions definition contains {secret_type}",
                        "description": f"Step Functions '{sm_name}' definition contains potential {secret_type}",
                        "recommendation": "Use Secrets Manager intrinsic function or SSM Parameter Store",
                        "mitre_technique": "T1552.001",
                    })
                    break
        
        return findings
    
    # =========================================================================
    # Systems Manager (SSM) Security Checks
    # =========================================================================
    
    def check_ssm_security(self, parameters: List[Dict[str, Any]], documents: List[Dict[str, Any]], sessions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check Systems Manager security.
        
        Checks:
        - Parameter Store encryption (SecureString)
        - Session Manager logging
        - Document permissions
        - Run Command logging
        
        Args:
            parameters: List of SSM parameter configurations
            documents: List of SSM document configurations
            sessions: List of SSM session configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check SSM parameters
        for param in parameters:
            param_name = param.get("Name", "")
            param_type = param.get("Type", "")
            
            # Check for String type that should be SecureString
            secret_indicators = ["password", "secret", "key", "token", "credential", "api_key"]
            if param_type == "String" and any(indicator in param_name.lower() for indicator in secret_indicators):
                findings.append({
                    "check_id": "ssm_param_not_secure",
                    "resource_id": param_name,
                    "resource_name": param_name,
                    "resource_type": "ssm_parameter",
                    "severity": "high",
                    "title": "SSM parameter should be SecureString",
                    "description": f"SSM parameter '{param_name}' contains sensitive data but is not SecureString",
                    "recommendation": "Use SecureString type with KMS encryption for sensitive parameters",
                    "mitre_technique": "T1552.001",
                })
        
        # Check SSM documents
        for doc in documents:
            doc_name = doc.get("Name", "")
            permissions = doc.get("Permissions", {})
            
            # Check for public documents
            account_ids = permissions.get("AccountIds", [])
            if "all" in [str(aid).lower() for aid in account_ids]:
                findings.append({
                    "check_id": "ssm_document_public",
                    "resource_id": doc_name,
                    "resource_name": doc_name,
                    "resource_type": "ssm_document",
                    "severity": "high",
                    "title": "SSM document is publicly shared",
                    "description": f"SSM document '{doc_name}' is shared with all AWS accounts",
                    "recommendation": "Restrict document sharing to specific accounts",
                    "mitre_technique": "T1098",
                })
        
        return findings
    
    # =========================================================================
    # ECS/Fargate Security Checks
    # =========================================================================
    
    def check_ecs_security(self, clusters: List[Dict[str, Any]], task_definitions: List[Dict[str, Any]], services: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check ECS/Fargate security.
        
        Checks:
        - Task definition secrets exposure
        - Container insights enabled
        - Execute command (ECS Exec) enabled
        - Privileged containers
        - Task role permissions
        
        Args:
            clusters: List of ECS cluster configurations
            task_definitions: List of ECS task definition configurations
            services: List of ECS service configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check ECS clusters
        for cluster in clusters:
            cluster_name = cluster.get("clusterName", "")
            cluster_arn = cluster.get("clusterArn", "")
            
            settings = cluster.get("settings", [])
            container_insights_enabled = False
            for setting in settings:
                if setting.get("name") == "containerInsights" and setting.get("value") == "enabled":
                    container_insights_enabled = True
            
            if not container_insights_enabled:
                findings.append({
                    "check_id": "ecs_container_insights_disabled",
                    "resource_id": cluster_arn,
                    "resource_name": cluster_name,
                    "resource_type": "ecs_cluster",
                    "severity": "low",
                    "title": "ECS Container Insights disabled",
                    "description": f"ECS cluster '{cluster_name}' does not have Container Insights enabled",
                    "recommendation": "Enable Container Insights for monitoring and logging",
                })
        
        # Check task definitions
        for task_def in task_definitions:
            task_def_arn = task_def.get("taskDefinitionArn", "")
            family = task_def.get("family", "")
            
            container_definitions = task_def.get("containerDefinitions", [])
            for container in container_definitions:
                container_name = container.get("name", "")
                
                # Check for privileged container
                if container.get("privileged", False):
                    findings.append({
                        "check_id": "ecs_privileged_container",
                        "resource_id": task_def_arn,
                        "resource_name": f"{family}/{container_name}",
                        "resource_type": "ecs_task_definition",
                        "severity": "critical",
                        "title": "ECS container runs in privileged mode",
                        "description": f"Task definition '{family}' container '{container_name}' runs in privileged mode",
                        "recommendation": "Remove privileged mode unless absolutely necessary",
                        "mitre_technique": "T1611",
                    })
                
                # Check for plaintext secrets in environment
                environment = container.get("environment", [])
                for env_var in environment:
                    name = env_var.get("name", "")
                    value = env_var.get("value", "")
                    
                    for pattern, secret_type in SECRET_PATTERNS:
                        if re.search(pattern, value):
                            findings.append({
                                "check_id": "ecs_env_secret",
                                "resource_id": task_def_arn,
                                "resource_name": f"{family}/{container_name}",
                                "resource_type": "ecs_task_definition",
                                "severity": "critical",
                                "title": f"ECS container has {secret_type} in environment",
                                "description": f"Task definition '{family}' container '{container_name}' has potential {secret_type} in variable '{name}'",
                                "recommendation": "Use secrets property with Secrets Manager or SSM Parameter Store",
                                "mitre_technique": "T1552.001",
                            })
                            break
                
                # Check for disabled read-only root filesystem
                if not container.get("readonlyRootFilesystem", False):
                    findings.append({
                        "check_id": "ecs_writable_root_fs",
                        "resource_id": task_def_arn,
                        "resource_name": f"{family}/{container_name}",
                        "resource_type": "ecs_task_definition",
                        "severity": "low",
                        "title": "ECS container has writable root filesystem",
                        "description": f"Task definition '{family}' container '{container_name}' has writable root filesystem",
                        "recommendation": "Enable readonlyRootFilesystem for security hardening",
                    })
        
        # Check services
        for service in services:
            service_name = service.get("serviceName", "")
            service_arn = service.get("serviceArn", "")
            
            # Check for ECS Exec enabled
            if service.get("enableExecuteCommand", False):
                findings.append({
                    "check_id": "ecs_exec_enabled",
                    "resource_id": service_arn,
                    "resource_name": service_name,
                    "resource_type": "ecs_service",
                    "severity": "medium",
                    "title": "ECS Exec is enabled",
                    "description": f"ECS service '{service_name}' has Execute Command (ECS Exec) enabled",
                    "recommendation": "Ensure ECS Exec is properly monitored and restricted via IAM",
                    "mitre_technique": "T1059",
                })
        
        return findings
    
    # =========================================================================
    # ECR Security Checks
    # =========================================================================
    
    def check_ecr_security(self, repositories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check ECR repository security.
        
        Checks:
        - Image scanning enabled
        - Encryption configuration
        - Repository policy (public access)
        - Image tag mutability
        - Lifecycle policy
        
        Args:
            repositories: List of ECR repository configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for repo in repositories:
            repo_name = repo.get("repositoryName", "")
            repo_arn = repo.get("repositoryArn", "")
            
            # Check for image scanning disabled
            scan_config = repo.get("imageScanningConfiguration", {})
            if not scan_config.get("scanOnPush", False):
                findings.append({
                    "check_id": "ecr_scan_disabled",
                    "resource_id": repo_arn,
                    "resource_name": repo_name,
                    "resource_type": "ecr_repository",
                    "severity": "high",
                    "title": "ECR repository scan on push disabled",
                    "description": f"ECR repository '{repo_name}' does not have image scanning on push enabled",
                    "recommendation": "Enable image scanning on push for vulnerability detection",
                    "mitre_technique": "T1525",
                })
            
            # Check for mutable image tags
            if repo.get("imageTagMutability") == "MUTABLE":
                findings.append({
                    "check_id": "ecr_mutable_tags",
                    "resource_id": repo_arn,
                    "resource_name": repo_name,
                    "resource_type": "ecr_repository",
                    "severity": "medium",
                    "title": "ECR repository has mutable image tags",
                    "description": f"ECR repository '{repo_name}' allows mutable image tags",
                    "recommendation": "Set imageTagMutability to IMMUTABLE to prevent tag overwrites",
                    "mitre_technique": "T1525",
                })
            
            # Check encryption
            encryption = repo.get("encryptionConfiguration", {})
            if encryption.get("encryptionType") != "KMS":
                findings.append({
                    "check_id": "ecr_no_kms_encryption",
                    "resource_id": repo_arn,
                    "resource_name": repo_name,
                    "resource_type": "ecr_repository",
                    "severity": "low",
                    "title": "ECR repository not encrypted with KMS",
                    "description": f"ECR repository '{repo_name}' uses default encryption instead of KMS",
                    "recommendation": "Use KMS CMK for repository encryption",
                })
        
        return findings
    
    # =========================================================================
    # API Gateway Security Checks
    # =========================================================================
    
    def check_api_gateway_security(self, rest_apis: List[Dict[str, Any]], stages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check API Gateway security.
        
        Checks:
        - Authentication/authorization
        - WAF integration
        - Logging configuration
        - Rate limiting
        - Certificate validation
        
        Args:
            rest_apis: List of API Gateway REST API configurations
            stages: List of API Gateway stage configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for api in rest_apis:
            api_id = api.get("id", "")
            api_name = api.get("name", "")
            
            # Check for disabled endpoint configuration
            endpoint_config = api.get("endpointConfiguration", {})
            endpoint_types = endpoint_config.get("types", [])
            
            if "EDGE" in endpoint_types:
                findings.append({
                    "check_id": "apigw_edge_endpoint",
                    "resource_id": api_id,
                    "resource_name": api_name,
                    "resource_type": "api_gateway",
                    "severity": "info",
                    "title": "API Gateway uses edge-optimized endpoint",
                    "description": f"API Gateway '{api_name}' uses edge-optimized endpoint (CloudFront)",
                    "recommendation": "Consider REGIONAL endpoint for VPC-internal APIs",
                })
        
        # Check stages
        for stage in stages:
            stage_name = stage.get("stageName", "")
            api_id = stage.get("restApiId", "")
            
            # Check for disabled access logging
            access_log_settings = stage.get("accessLogSettings", {})
            if not access_log_settings.get("destinationArn"):
                findings.append({
                    "check_id": "apigw_no_access_logs",
                    "resource_id": f"{api_id}/{stage_name}",
                    "resource_name": stage_name,
                    "resource_type": "api_gateway_stage",
                    "severity": "medium",
                    "title": "API Gateway stage has no access logging",
                    "description": f"API Gateway stage '{stage_name}' does not have access logging enabled",
                    "recommendation": "Enable access logging to CloudWatch or Kinesis",
                    "mitre_technique": "T1562.008",
                })
            
            # Check for disabled X-Ray tracing
            if not stage.get("tracingEnabled", False):
                findings.append({
                    "check_id": "apigw_no_xray",
                    "resource_id": f"{api_id}/{stage_name}",
                    "resource_name": stage_name,
                    "resource_type": "api_gateway_stage",
                    "severity": "low",
                    "title": "API Gateway stage has X-Ray tracing disabled",
                    "description": f"API Gateway stage '{stage_name}' does not have X-Ray tracing enabled",
                    "recommendation": "Enable X-Ray tracing for distributed tracing",
                })
            
            # Check for WAF
            if not stage.get("webAclArn"):
                findings.append({
                    "check_id": "apigw_no_waf",
                    "resource_id": f"{api_id}/{stage_name}",
                    "resource_name": stage_name,
                    "resource_type": "api_gateway_stage",
                    "severity": "medium",
                    "title": "API Gateway stage not protected by WAF",
                    "description": f"API Gateway stage '{stage_name}' is not protected by AWS WAF",
                    "recommendation": "Associate AWS WAF Web ACL for protection",
                    "mitre_technique": "T1190",
                })
        
        return findings
    
    # =========================================================================
    # Cognito Security Checks
    # =========================================================================
    
    def check_cognito_security(self, user_pools: List[Dict[str, Any]], identity_pools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check Cognito security.
        
        Checks:
        - MFA configuration
        - Password policy
        - Account recovery settings
        - Identity pool unauthenticated access
        - Advanced security features
        
        Args:
            user_pools: List of Cognito user pool configurations
            identity_pools: List of Cognito identity pool configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check user pools
        for pool in user_pools:
            pool_id = pool.get("Id", "")
            pool_name = pool.get("Name", "")
            
            # Check MFA configuration
            mfa_config = pool.get("MfaConfiguration", "OFF")
            if mfa_config == "OFF":
                findings.append({
                    "check_id": "cognito_mfa_disabled",
                    "resource_id": pool_id,
                    "resource_name": pool_name,
                    "resource_type": "cognito_user_pool",
                    "severity": "high",
                    "title": "Cognito user pool MFA disabled",
                    "description": f"Cognito user pool '{pool_name}' has MFA disabled",
                    "recommendation": "Enable MFA (OPTIONAL or REQUIRED) for better security",
                    "mitre_technique": "T1110",
                })
            
            # Check password policy
            password_policy = pool.get("Policies", {}).get("PasswordPolicy", {})
            min_length = password_policy.get("MinimumLength", 8)
            if min_length < 12:
                findings.append({
                    "check_id": "cognito_weak_password_policy",
                    "resource_id": pool_id,
                    "resource_name": pool_name,
                    "resource_type": "cognito_user_pool",
                    "severity": "medium",
                    "title": "Cognito user pool has weak password policy",
                    "description": f"Cognito user pool '{pool_name}' has minimum password length of {min_length}",
                    "recommendation": "Set minimum password length to at least 12 characters",
                })
            
            # Check for advanced security disabled
            user_pool_add_ons = pool.get("UserPoolAddOns", {})
            if user_pool_add_ons.get("AdvancedSecurityMode") != "ENFORCED":
                findings.append({
                    "check_id": "cognito_advanced_security_disabled",
                    "resource_id": pool_id,
                    "resource_name": pool_name,
                    "resource_type": "cognito_user_pool",
                    "severity": "medium",
                    "title": "Cognito advanced security not enforced",
                    "description": f"Cognito user pool '{pool_name}' does not have advanced security enforced",
                    "recommendation": "Enable advanced security features (adaptive authentication)",
                })
        
        # Check identity pools
        for pool in identity_pools:
            pool_id = pool.get("IdentityPoolId", "")
            pool_name = pool.get("IdentityPoolName", "")
            
            # Check for unauthenticated access
            if pool.get("AllowUnauthenticatedIdentities", False):
                findings.append({
                    "check_id": "cognito_unauth_access",
                    "resource_id": pool_id,
                    "resource_name": pool_name,
                    "resource_type": "cognito_identity_pool",
                    "severity": "high",
                    "title": "Cognito identity pool allows unauthenticated access",
                    "description": f"Cognito identity pool '{pool_name}' allows unauthenticated identities",
                    "recommendation": "Disable unauthenticated access unless specifically required",
                    "mitre_technique": "T1078",
                })
        
        return findings
    
    # =========================================================================
    # Secrets Manager Security Checks
    # =========================================================================
    
    def check_secrets_manager_security(self, secrets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check Secrets Manager security.
        
        Checks:
        - Secret rotation enabled
        - Rotation frequency
        - KMS encryption
        - Resource policy
        
        Args:
            secrets: List of Secrets Manager secret configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for secret in secrets:
            secret_name = secret.get("Name", "")
            secret_arn = secret.get("ARN", "")
            
            # Check for rotation disabled
            if not secret.get("RotationEnabled", False):
                findings.append({
                    "check_id": "secrets_rotation_disabled",
                    "resource_id": secret_arn,
                    "resource_name": secret_name,
                    "resource_type": "secrets_manager_secret",
                    "severity": "medium",
                    "title": "Secrets Manager rotation disabled",
                    "description": f"Secret '{secret_name}' does not have automatic rotation enabled",
                    "recommendation": "Enable automatic rotation with appropriate rotation Lambda",
                })
            
            # Check for default KMS key
            kms_key_id = secret.get("KmsKeyId", "")
            if not kms_key_id or "alias/aws/secretsmanager" in kms_key_id:
                findings.append({
                    "check_id": "secrets_default_kms",
                    "resource_id": secret_arn,
                    "resource_name": secret_name,
                    "resource_type": "secrets_manager_secret",
                    "severity": "low",
                    "title": "Secrets Manager uses default KMS key",
                    "description": f"Secret '{secret_name}' uses default AWS-managed KMS key",
                    "recommendation": "Use customer-managed KMS key for better access control",
                })
        
        return findings
    
    # =========================================================================
    # KMS Security Checks
    # =========================================================================
    
    def check_kms_security(self, keys: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check KMS key security.
        
        Checks:
        - Key rotation enabled
        - Key policy permissions
        - Cross-account access
        - Pending deletion
        
        Args:
            keys: List of KMS key configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for key in keys:
            key_id = key.get("KeyId", "")
            key_arn = key.get("Arn", "")
            key_alias = key.get("AliasName", key_id)
            
            # Check for disabled key rotation
            rotation_status = key.get("KeyRotationEnabled", False)
            if not rotation_status:
                # Only check customer managed keys (not AWS managed)
                key_manager = key.get("KeyManager", "")
                if key_manager == "CUSTOMER":
                    findings.append({
                        "check_id": "kms_rotation_disabled",
                        "resource_id": key_arn,
                        "resource_name": key_alias,
                        "resource_type": "kms_key",
                        "severity": "medium",
                        "title": "KMS key rotation disabled",
                        "description": f"KMS key '{key_alias}' does not have automatic rotation enabled",
                        "recommendation": "Enable automatic key rotation for customer managed keys",
                    })
            
            # Check key policy for overly permissive access
            key_policy = key.get("Policy", {})
            if isinstance(key_policy, dict):
                statements = key_policy.get("Statement", [])
                for stmt in statements:
                    principal = stmt.get("Principal", {})
                    if principal == "*" or principal.get("AWS") == "*":
                        if stmt.get("Effect") == "Allow":
                            findings.append({
                                "check_id": "kms_public_key_policy",
                                "resource_id": key_arn,
                                "resource_name": key_alias,
                                "resource_type": "kms_key",
                                "severity": "critical",
                                "title": "KMS key has overly permissive policy",
                                "description": f"KMS key '{key_alias}' policy allows access to all principals",
                                "recommendation": "Restrict key policy to specific principals",
                                "mitre_technique": "T1552",
                            })
            
            # Check for pending deletion
            key_state = key.get("KeyState", "")
            if key_state == "PendingDeletion":
                findings.append({
                    "check_id": "kms_pending_deletion",
                    "resource_id": key_arn,
                    "resource_name": key_alias,
                    "resource_type": "kms_key",
                    "severity": "info",
                    "title": "KMS key pending deletion",
                    "description": f"KMS key '{key_alias}' is pending deletion",
                    "recommendation": "Verify key deletion is intentional",
                })
        
        return findings
    
    # =========================================================================
    # CloudFormation Security Checks
    # =========================================================================
    
    def check_cloudformation_security(self, stacks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check CloudFormation stack security.
        
        Checks:
        - Stack policy
        - Termination protection
        - IAM capabilities
        - Drift detection
        - Template secrets
        
        Args:
            stacks: List of CloudFormation stack configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        for stack in stacks:
            stack_name = stack.get("StackName", "")
            stack_id = stack.get("StackId", "")
            
            # Check for disabled termination protection
            if not stack.get("EnableTerminationProtection", False):
                findings.append({
                    "check_id": "cfn_no_termination_protection",
                    "resource_id": stack_id,
                    "resource_name": stack_name,
                    "resource_type": "cloudformation_stack",
                    "severity": "low",
                    "title": "CloudFormation stack termination protection disabled",
                    "description": f"CloudFormation stack '{stack_name}' has termination protection disabled",
                    "recommendation": "Enable termination protection for production stacks",
                })
            
            # Check for IAM capabilities
            capabilities = stack.get("Capabilities", [])
            dangerous_capabilities = ["CAPABILITY_NAMED_IAM", "CAPABILITY_IAM", "CAPABILITY_AUTO_EXPAND"]
            has_dangerous = [cap for cap in capabilities if cap in dangerous_capabilities]
            if has_dangerous:
                findings.append({
                    "check_id": "cfn_iam_capabilities",
                    "resource_id": stack_id,
                    "resource_name": stack_name,
                    "resource_type": "cloudformation_stack",
                    "severity": "info",
                    "title": "CloudFormation stack has IAM capabilities",
                    "description": f"CloudFormation stack '{stack_name}' has capabilities: {', '.join(has_dangerous)}",
                    "recommendation": "Review IAM resources created by this stack",
                })
            
            # Check for drift
            drift_status = stack.get("DriftInformation", {}).get("StackDriftStatus", "")
            if drift_status == "DRIFTED":
                findings.append({
                    "check_id": "cfn_drift_detected",
                    "resource_id": stack_id,
                    "resource_name": stack_name,
                    "resource_type": "cloudformation_stack",
                    "severity": "medium",
                    "title": "CloudFormation stack has drifted",
                    "description": f"CloudFormation stack '{stack_name}' has configuration drift",
                    "recommendation": "Investigate drift and update stack or resources as needed",
                })
            
            # Check for CloudFormation Stack Hijacking (T1498.002)
            # Stack hijacking occurs when an attacker modifies stack resources to maintain persistence
            stack_policy = stack.get("StackPolicyBody", "")
            if not stack_policy:
                # No stack policy means anyone with stack update permissions can modify resources
                findings.append({
                    "check_id": "cfn_stack_hijacking_risk",
                    "resource_id": stack_id,
                    "resource_name": stack_name,
                    "resource_type": "cloudformation_stack",
                    "severity": "high",
                    "title": "CloudFormation stack hijacking risk - no stack policy",
                    "description": f"Stack '{stack_name}' has no stack policy, allowing unauthorized resource modifications for persistence",
                    "recommendation": "Create a stack policy to restrict resource modifications. Monitor stack update events.",
                    "mitre_technique": "T1498.002",
                })
            
            # Check for suspicious stack update events (would need CloudTrail analysis)
            # This is a placeholder - in full implementation, would analyze CloudTrail logs
            role_arn = stack.get("RoleARN", "")
            if role_arn:
                # Check if role has excessive permissions
                findings.append({
                    "check_id": "cfn_role_permissions",
                    "resource_id": stack_id,
                    "resource_name": stack_name,
                    "resource_type": "cloudformation_stack",
                    "severity": "info",
                    "title": "CloudFormation stack uses service role",
                    "description": f"Stack '{stack_name}' uses role '{role_arn}' - verify role permissions are least-privilege",
                    "recommendation": "Review IAM role permissions to prevent stack hijacking",
                    "mitre_technique": "T1498.002",
                })
            
            # Check parameters for secrets
            parameters = stack.get("Parameters", [])
            for param in parameters:
                param_key = param.get("ParameterKey", "")
                param_value = param.get("ParameterValue", "")
                
                secret_indicators = ["password", "secret", "key", "token", "credential"]
                if any(indicator in param_key.lower() for indicator in secret_indicators):
                    if param_value and "****" not in param_value:  # Not masked
                        for pattern, secret_type in SECRET_PATTERNS:
                            if re.search(pattern, param_value):
                                findings.append({
                                    "check_id": "cfn_param_secret",
                                    "resource_id": stack_id,
                                    "resource_name": stack_name,
                                    "resource_type": "cloudformation_stack",
                                    "severity": "critical",
                                    "title": f"CloudFormation parameter contains {secret_type}",
                                    "description": f"Stack '{stack_name}' parameter '{param_key}' may contain sensitive data",
                                    "recommendation": "Use NoEcho: true for sensitive parameters or use Secrets Manager",
                                    "mitre_technique": "T1552.001",
                                })
                                break
        
        return findings
    
    # =========================================================================
    # CloudWatch Security Checks
    # =========================================================================
    
    def check_cloudwatch_security(self, log_groups: List[Dict[str, Any]], alarms: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check CloudWatch security.
        
        Checks:
        - Log group encryption
        - Log group retention
        - Missing security alarms
        - Metric filters
        
        Args:
            log_groups: List of CloudWatch log group configurations
            alarms: List of CloudWatch alarm configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check log groups
        for log_group in log_groups:
            log_group_name = log_group.get("logGroupName", "")
            log_group_arn = log_group.get("arn", "")
            
            # Check for missing encryption
            if not log_group.get("kmsKeyId"):
                findings.append({
                    "check_id": "cloudwatch_logs_not_encrypted",
                    "resource_id": log_group_arn,
                    "resource_name": log_group_name,
                    "resource_type": "cloudwatch_log_group",
                    "severity": "medium",
                    "title": "CloudWatch Log Group not encrypted",
                    "description": f"Log group '{log_group_name}' is not encrypted with KMS",
                    "recommendation": "Enable KMS encryption for log groups containing sensitive data",
                })
            
            # Check for missing retention
            retention_days = log_group.get("retentionInDays")
            if retention_days is None:
                findings.append({
                    "check_id": "cloudwatch_logs_no_retention",
                    "resource_id": log_group_arn,
                    "resource_name": log_group_name,
                    "resource_type": "cloudwatch_log_group",
                    "severity": "low",
                    "title": "CloudWatch Log Group has no retention policy",
                    "description": f"Log group '{log_group_name}' logs are retained indefinitely",
                    "recommendation": "Set a retention policy based on compliance requirements",
                })
        
        # Check for recommended security alarms
        recommended_alarms = [
            "RootAccountUsage",
            "UnauthorizedAPICalls",
            "ConsoleSignInWithoutMFA",
            "IAMPolicyChanges",
            "CloudTrailConfigChanges",
            "S3BucketPolicyChanges",
            "AWSConfigChanges",
            "SecurityGroupChanges",
            "NACLChanges",
            "NetworkGatewayChanges",
            "RouteTableChanges",
            "VPCChanges",
        ]
        
        existing_alarm_names = [alarm.get("AlarmName", "").lower() for alarm in alarms]
        for recommended in recommended_alarms:
            if not any(recommended.lower() in name for name in existing_alarm_names):
                findings.append({
                    "check_id": f"cloudwatch_missing_{recommended.lower()}_alarm",
                    "resource_id": "cloudwatch_alarms",
                    "resource_name": recommended,
                    "resource_type": "cloudwatch_alarm",
                    "severity": "medium" if recommended in ["RootAccountUsage", "UnauthorizedAPICalls"] else "low",
                    "title": f"Missing recommended security alarm: {recommended}",
                    "description": f"No CloudWatch alarm found for {recommended}",
                    "recommendation": f"Create alarm for {recommended} based on CIS AWS Foundations Benchmark",
                })
        
        return findings
    
    # =========================================================================
    # EventBridge Security Checks
    # =========================================================================
    
    def check_eventbridge_security(self, rules: List[Dict[str, Any]], buses: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Check EventBridge security.
        
        Checks:
        - Event bus policy (cross-account)
        - Rule targets security
        - DLQ configuration
        
        Args:
            rules: List of EventBridge rule configurations
            buses: List of EventBridge bus configurations
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check event buses
        for bus in buses:
            bus_name = bus.get("Name", "")
            bus_arn = bus.get("Arn", "")
            
            # Check policy
            policy = bus.get("Policy", {})
            if isinstance(policy, dict):
                statements = policy.get("Statement", [])
                for stmt in statements:
                    principal = stmt.get("Principal", {})
                    if principal == "*" or principal.get("AWS") == "*":
                        if stmt.get("Effect") == "Allow":
                            findings.append({
                                "check_id": "eventbridge_public_bus",
                                "resource_id": bus_arn,
                                "resource_name": bus_name,
                                "resource_type": "eventbridge_bus",
                                "severity": "high",
                                "title": "EventBridge bus allows all principals",
                                "description": f"EventBridge bus '{bus_name}' policy allows access from all accounts",
                                "recommendation": "Restrict event bus access to specific accounts",
                                "mitre_technique": "T1098",
                            })
        
        # Check rules
        for rule in rules:
            rule_name = rule.get("Name", "")
            rule_arn = rule.get("Arn", "")
            
            targets = rule.get("Targets", [])
            for target in targets:
                # Check for missing DLQ
                dead_letter_config = target.get("DeadLetterConfig", {})
                if not dead_letter_config.get("Arn"):
                    target_id = target.get("Id", "")
                    findings.append({
                        "check_id": "eventbridge_target_no_dlq",
                        "resource_id": rule_arn,
                        "resource_name": f"{rule_name}/{target_id}",
                        "resource_type": "eventbridge_rule",
                        "severity": "low",
                        "title": "EventBridge rule target has no DLQ",
                        "description": f"EventBridge rule '{rule_name}' target '{target_id}' has no dead letter queue",
                        "recommendation": "Configure dead letter queue for failed event delivery",
                    })
        
        return findings
    
    def run_all_checks(self, aws_resources: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Run all additional service checks.
        
        Args:
            aws_resources: Dictionary of AWS resources by service
            
        Returns:
            Aggregated list of all findings
        """
        all_findings = []
        
        # AppSync
        if "appsync_apis" in aws_resources:
            all_findings.extend(self.check_appsync_api_security(aws_resources["appsync_apis"]))
        
        # Amplify
        if "amplify_apps" in aws_resources:
            all_findings.extend(self.check_amplify_app_security(aws_resources["amplify_apps"]))
        
        # CodeBuild
        if "codebuild_projects" in aws_resources:
            all_findings.extend(self.check_codebuild_project_security(aws_resources["codebuild_projects"]))
        
        # CodePipeline
        if "codepipelines" in aws_resources:
            all_findings.extend(self.check_codepipeline_security(aws_resources["codepipelines"]))
        
        # Glue
        if "glue_jobs" in aws_resources or "glue_crawlers" in aws_resources:
            all_findings.extend(self.check_glue_security(
                aws_resources.get("glue_jobs", []),
                aws_resources.get("glue_crawlers", []),
                aws_resources.get("glue_catalogs", [])
            ))
        
        # Step Functions
        if "step_functions" in aws_resources:
            all_findings.extend(self.check_step_functions_security(aws_resources["step_functions"]))
        
        # Systems Manager
        if "ssm_parameters" in aws_resources or "ssm_documents" in aws_resources:
            all_findings.extend(self.check_ssm_security(
                aws_resources.get("ssm_parameters", []),
                aws_resources.get("ssm_documents", []),
                aws_resources.get("ssm_sessions", [])
            ))
        
        # ECS
        if "ecs_clusters" in aws_resources or "ecs_task_definitions" in aws_resources:
            all_findings.extend(self.check_ecs_security(
                aws_resources.get("ecs_clusters", []),
                aws_resources.get("ecs_task_definitions", []),
                aws_resources.get("ecs_services", [])
            ))
        
        # ECR
        if "ecr_repositories" in aws_resources:
            all_findings.extend(self.check_ecr_security(aws_resources["ecr_repositories"]))
        
        # API Gateway
        if "api_gateway_apis" in aws_resources or "api_gateway_stages" in aws_resources:
            all_findings.extend(self.check_api_gateway_security(
                aws_resources.get("api_gateway_apis", []),
                aws_resources.get("api_gateway_stages", [])
            ))
        
        # Cognito
        if "cognito_user_pools" in aws_resources or "cognito_identity_pools" in aws_resources:
            all_findings.extend(self.check_cognito_security(
                aws_resources.get("cognito_user_pools", []),
                aws_resources.get("cognito_identity_pools", [])
            ))
        
        # Secrets Manager
        if "secrets_manager_secrets" in aws_resources:
            all_findings.extend(self.check_secrets_manager_security(aws_resources["secrets_manager_secrets"]))
        
        # KMS
        if "kms_keys" in aws_resources:
            all_findings.extend(self.check_kms_security(aws_resources["kms_keys"]))
        
        # CloudFormation
        if "cloudformation_stacks" in aws_resources:
            all_findings.extend(self.check_cloudformation_security(aws_resources["cloudformation_stacks"]))
        
        # CloudWatch
        if "cloudwatch_log_groups" in aws_resources or "cloudwatch_alarms" in aws_resources:
            all_findings.extend(self.check_cloudwatch_security(
                aws_resources.get("cloudwatch_log_groups", []),
                aws_resources.get("cloudwatch_alarms", [])
            ))
        
        # EventBridge
        if "eventbridge_rules" in aws_resources or "eventbridge_buses" in aws_resources:
            all_findings.extend(self.check_eventbridge_security(
                aws_resources.get("eventbridge_rules", []),
                aws_resources.get("eventbridge_buses", [])
            ))
        
        return all_findings

