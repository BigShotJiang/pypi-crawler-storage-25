"""
RDS Check Service

Service for executing RDS-related security checks.
"""

import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel

logger = logging.getLogger(__name__)


class RDSCheckService:
    """Service for executing RDS security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize RDS check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute RDS check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_public_rds": self.check_public_rds,
            "check_rds_encryption": self.check_rds_encryption,
            "check_rds_backup": self.check_rds_backup,
            "check_public_rds_snapshot": self.check_public_rds_snapshot,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_public_rds(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for publicly accessible RDS instances."""
        findings = []
        try:
            rds = self.plugin._get_client("rds", region)
            instances = rds.describe_db_instances()["DBInstances"]
            for instance in instances:
                if instance.get("PubliclyAccessible", False):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.RDS_INSTANCE,
                        resource_id=instance["DBInstanceIdentifier"],
                        description=f"RDS instance '{instance['DBInstanceIdentifier']}' is publicly accessible",
                        recommendation="Disable public accessibility and use VPC",
                        severity=SeverityLevel.CRITICAL,
                        evidence={"publicly_accessible": True},
                    ))
        except Exception as e:
            logger.error(f"Public RDS check failed: {e}")
        return findings
    
    async def check_rds_encryption(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check RDS instance encryption."""
        findings = []
        try:
            rds = self.plugin._get_client("rds", region)
            instances = rds.describe_db_instances()["DBInstances"]
            for instance in instances:
                if not instance.get("StorageEncrypted", False):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.RDS_INSTANCE,
                        resource_id=instance["DBInstanceIdentifier"],
                        description=f"RDS instance '{instance['DBInstanceIdentifier']}' is not encrypted",
                        recommendation="Enable encryption at rest",
                        severity=SeverityLevel.HIGH,
                        evidence={"encrypted": False},
                    ))
        except Exception as e:
            logger.error(f"RDS encryption check failed: {e}")
        return findings
    
    async def check_rds_backup(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check RDS instance backups."""
        findings = []
        try:
            rds = self.plugin._get_client("rds", region)
            instances = rds.describe_db_instances()["DBInstances"]
            for instance in instances:
                if instance.get("BackupRetentionPeriod", 0) == 0:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.RDS_INSTANCE,
                        resource_id=instance["DBInstanceIdentifier"],
                        description=f"RDS instance '{instance['DBInstanceIdentifier']}' has no automated backups",
                        recommendation="Enable automated backups",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"backup_retention": 0},
                    ))
        except Exception as e:
            logger.error(f"RDS backup check failed: {e}")
        return findings
    
    async def check_public_rds_snapshot(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public RDS snapshots."""
        findings = []
        try:
            rds = self.plugin._get_client("rds", region)
            snapshots = rds.describe_db_snapshots(SnapshotType="manual")["DBSnapshots"]
            for snapshot in snapshots:
                attrs = rds.describe_db_snapshot_attributes(DBSnapshotIdentifier=snapshot["DBSnapshotIdentifier"])
                for attr in attrs.get("DBSnapshotAttributesResult", {}).get("DBSnapshotAttributes", []):
                    if attr.get("AttributeName") == "restore" and "all" in attr.get("AttributeValues", []):
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region=region,
                            resource_type=AWSResourceType.RDS_SNAPSHOT,
                            resource_id=snapshot["DBSnapshotIdentifier"],
                            description=f"RDS snapshot '{snapshot['DBSnapshotIdentifier']}' is public",
                            recommendation="Remove public access from snapshot",
                            severity=SeverityLevel.CRITICAL,
                            evidence={"public": True},
                        ))
        except Exception as e:
            logger.error(f"Public RDS snapshot check failed: {e}")
        return findings

