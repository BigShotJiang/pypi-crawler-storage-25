"""
Network Security Service

AWS network security analysis:
- Security group analysis
- NACL analysis
- VPC flow logs analysis
- Network exposure detection
- Lateral movement paths
- Egress filtering

MITRE ATT&CK:
- T1046: Network Service Discovery
- T1090: Proxy
- T1095: Non-Application Layer Protocol
- T1571: Non-Standard Port
"""

import logging
import ipaddress
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception

logger = logging.getLogger(__name__)


class NetworkFindingSeverity(str, Enum):
    """Severity levels for network findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class NetworkFindingType(str, Enum):
    """Types of network security findings."""
    OPEN_PORT = "open_port"
    OVERLY_PERMISSIVE = "overly_permissive"
    MISSING_EGRESS = "missing_egress"
    LATERAL_MOVEMENT = "lateral_movement"
    EXPOSURE = "exposure"
    MISCONFIGURATION = "misconfiguration"
    FLOW_ANOMALY = "flow_anomaly"


# =============================================================================
# Dangerous Ports and Protocols
# =============================================================================

DANGEROUS_PORTS = {
    22: {"name": "SSH", "severity": NetworkFindingSeverity.HIGH, "reason": "Remote access"},
    23: {"name": "Telnet", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Unencrypted remote access"},
    25: {"name": "SMTP", "severity": NetworkFindingSeverity.MEDIUM, "reason": "Email relay abuse"},
    53: {"name": "DNS", "severity": NetworkFindingSeverity.MEDIUM, "reason": "DNS amplification"},
    110: {"name": "POP3", "severity": NetworkFindingSeverity.MEDIUM, "reason": "Unencrypted email"},
    135: {"name": "MSRPC", "severity": NetworkFindingSeverity.HIGH, "reason": "Windows RPC"},
    139: {"name": "NetBIOS", "severity": NetworkFindingSeverity.HIGH, "reason": "SMB discovery"},
    143: {"name": "IMAP", "severity": NetworkFindingSeverity.MEDIUM, "reason": "Unencrypted email"},
    389: {"name": "LDAP", "severity": NetworkFindingSeverity.HIGH, "reason": "Directory access"},
    445: {"name": "SMB", "severity": NetworkFindingSeverity.CRITICAL, "reason": "File sharing exploitation"},
    1433: {"name": "MSSQL", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Database access"},
    1521: {"name": "Oracle", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Database access"},
    3306: {"name": "MySQL", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Database access"},
    3389: {"name": "RDP", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Remote desktop"},
    5432: {"name": "PostgreSQL", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Database access"},
    5900: {"name": "VNC", "severity": NetworkFindingSeverity.HIGH, "reason": "Remote desktop"},
    6379: {"name": "Redis", "severity": NetworkFindingSeverity.CRITICAL, "reason": "In-memory database"},
    9200: {"name": "Elasticsearch", "severity": NetworkFindingSeverity.HIGH, "reason": "Search engine"},
    11211: {"name": "Memcached", "severity": NetworkFindingSeverity.HIGH, "reason": "Cache amplification"},
    27017: {"name": "MongoDB", "severity": NetworkFindingSeverity.CRITICAL, "reason": "Database access"},
}


# =============================================================================
# Security Group Best Practices
# =============================================================================

SG_BEST_PRACTICES = {
    "no_0.0.0.0/0_ingress": {
        "description": "No inbound rules allowing 0.0.0.0/0",
        "severity": NetworkFindingSeverity.HIGH,
        "mitre": "T1046",
    },
    "no_::/0_ingress": {
        "description": "No inbound rules allowing ::/0 (IPv6 any)",
        "severity": NetworkFindingSeverity.HIGH,
        "mitre": "T1046",
    },
    "specific_port_ranges": {
        "description": "Use specific ports instead of ranges",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1571",
    },
    "no_all_traffic": {
        "description": "No rules allowing all traffic (-1 protocol)",
        "severity": NetworkFindingSeverity.CRITICAL,
        "mitre": "T1046",
    },
    "principle_of_least_privilege": {
        "description": "Only required ports and sources allowed",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1046",
    },
    "egress_filtering": {
        "description": "Egress traffic should be filtered",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1095",
    },
}


# =============================================================================
# Lateral Movement Patterns
# =============================================================================

LATERAL_MOVEMENT_PATTERNS = {
    "cross_sg_access": {
        "name": "Cross Security Group Access",
        "description": "Security groups allowing access from other SGs",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1090",
    },
    "internal_ssh": {
        "name": "Internal SSH Access",
        "description": "SSH access between internal resources",
        "severity": NetworkFindingSeverity.LOW,
        "mitre": "T1021.004",
    },
    "internal_smb": {
        "name": "Internal SMB Access",
        "description": "SMB access between internal resources",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1021.002",
    },
    "internal_rdp": {
        "name": "Internal RDP Access",
        "description": "RDP access between internal resources",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1021.001",
    },
    "database_access": {
        "name": "Database Access Paths",
        "description": "Database ports accessible from multiple sources",
        "severity": NetworkFindingSeverity.MEDIUM,
        "mitre": "T1046",
    },
}


@dataclass
class NetworkSecurityFinding:
    """A network security finding."""
    finding_type: NetworkFindingType
    severity: NetworkFindingSeverity
    resource_id: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class SecurityGroupAnalysis:
    """Analysis of a security group."""
    sg_id: str
    sg_name: str
    vpc_id: str
    findings: List[NetworkSecurityFinding] = field(default_factory=list)
    inbound_rules: int = 0
    outbound_rules: int = 0
    risk_score: float = 0.0


@dataclass
class VPCNetworkAnalysis:
    """Analysis of VPC network security."""
    vpc_id: str
    security_groups: List[SecurityGroupAnalysis] = field(default_factory=list)
    nacl_findings: List[NetworkSecurityFinding] = field(default_factory=list)
    exposure_score: float = 0.0
    lateral_movement_paths: List[Dict[str, Any]] = field(default_factory=list)


class NetworkSecurityService:
    """Service for AWS network security analysis."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[NetworkSecurityFinding] = []
    
    async def analyze_security_group(
        self,
        ec2_client,
        sg_id: str,
    ) -> SecurityGroupAnalysis:
        """
        Analyze a single security group.
        
        Args:
            ec2_client: boto3 EC2 client
            sg_id: Security group ID
            
        Returns:
            SecurityGroupAnalysis
        """
        findings = []
        
        try:
            response = ec2_client.describe_security_groups(GroupIds=[sg_id])
            sg = response["SecurityGroups"][0]
            
            sg_name = sg.get("GroupName", "")
            vpc_id = sg.get("VpcId", "")
            inbound_rules = sg.get("IpPermissions", [])
            outbound_rules = sg.get("IpPermissionsEgress", [])
            
            # Analyze inbound rules
            for rule in inbound_rules:
                rule_findings = self._analyze_inbound_rule(sg_id, rule)
                findings.extend(rule_findings)
            
            # Analyze outbound rules
            outbound_findings = self._analyze_outbound_rules(sg_id, outbound_rules)
            findings.extend(outbound_findings)
            
            # Calculate risk score
            risk_score = self._calculate_sg_risk_score(findings)
            
            return SecurityGroupAnalysis(
                sg_id=sg_id,
                sg_name=sg_name,
                vpc_id=vpc_id,
                findings=findings,
                inbound_rules=len(inbound_rules),
                outbound_rules=len(outbound_rules),
                risk_score=risk_score,
            )
            
        except ClientError as e:
            logger.error(f"Error analyzing security group {sg_id}: {e}")
            return SecurityGroupAnalysis(sg_id=sg_id, sg_name="", vpc_id="")
    
    def _analyze_inbound_rule(
        self,
        sg_id: str,
        rule: Dict[str, Any],
    ) -> List[NetworkSecurityFinding]:
        """Analyze a single inbound rule."""
        findings = []
        
        protocol = rule.get("IpProtocol", "")
        from_port = rule.get("FromPort", 0)
        to_port = rule.get("ToPort", 0)
        ip_ranges = rule.get("IpRanges", [])
        ipv6_ranges = rule.get("Ipv6Ranges", [])
        sg_refs = rule.get("UserIdGroupPairs", [])
        
        # Check for 0.0.0.0/0
        for ip_range in ip_ranges:
            cidr = ip_range.get("CidrIp", "")
            
            if cidr == "0.0.0.0/0":
                # World accessible
                if protocol == "-1":
                    # All traffic from internet
                    findings.append(NetworkSecurityFinding(
                        finding_type=NetworkFindingType.OVERLY_PERMISSIVE,
                        severity=NetworkFindingSeverity.CRITICAL,
                        resource_id=sg_id,
                        description="Security group allows ALL traffic from internet (0.0.0.0/0)",
                        evidence={
                            "protocol": "all",
                            "source": "0.0.0.0/0",
                        },
                        remediation="Remove 0.0.0.0/0 source; use specific IPs/ranges",
                        mitre_technique="T1046",
                    ))
                else:
                    # Specific port from internet
                    port_info = DANGEROUS_PORTS.get(from_port, {})
                    severity = port_info.get("severity", NetworkFindingSeverity.HIGH)
                    port_name = port_info.get("name", f"port {from_port}")
                    
                    findings.append(NetworkSecurityFinding(
                        finding_type=NetworkFindingType.OPEN_PORT,
                        severity=severity,
                        resource_id=sg_id,
                        description=f"{port_name} ({from_port}) open to internet",
                        evidence={
                            "port": from_port,
                            "protocol": protocol,
                            "source": "0.0.0.0/0",
                            "reason": port_info.get("reason", ""),
                        },
                        remediation=f"Restrict {port_name} access to specific IPs",
                        mitre_technique="T1046",
                    ))
        
        # Check for ::/0 (IPv6)
        for ipv6_range in ipv6_ranges:
            cidr = ipv6_range.get("CidrIpv6", "")
            
            if cidr == "::/0":
                findings.append(NetworkSecurityFinding(
                    finding_type=NetworkFindingType.OVERLY_PERMISSIVE,
                    severity=NetworkFindingSeverity.HIGH,
                    resource_id=sg_id,
                    description=f"Port {from_port} open to all IPv6 addresses",
                    evidence={
                        "port": from_port,
                        "source": "::/0",
                    },
                    remediation="Restrict IPv6 access",
                    mitre_technique="T1046",
                ))
        
        # Check for wide port ranges
        if from_port and to_port and (to_port - from_port) > 100:
            findings.append(NetworkSecurityFinding(
                finding_type=NetworkFindingType.MISCONFIGURATION,
                severity=NetworkFindingSeverity.MEDIUM,
                resource_id=sg_id,
                description=f"Wide port range {from_port}-{to_port} allowed",
                evidence={
                    "port_range": f"{from_port}-{to_port}",
                },
                remediation="Use specific ports instead of ranges",
                mitre_technique="T1571",
            ))
        
        # Check for lateral movement paths
        if sg_refs:
            for sg_ref in sg_refs:
                ref_sg_id = sg_ref.get("GroupId", "")
                
                if from_port in [22, 3389, 445]:
                    findings.append(NetworkSecurityFinding(
                        finding_type=NetworkFindingType.LATERAL_MOVEMENT,
                        severity=NetworkFindingSeverity.MEDIUM,
                        resource_id=sg_id,
                        description=f"Lateral movement path via port {from_port} from {ref_sg_id}",
                        evidence={
                            "port": from_port,
                            "source_sg": ref_sg_id,
                        },
                        remediation="Review if cross-SG access is required",
                        mitre_technique="T1021",
                    ))
        
        return findings
    
    def _analyze_outbound_rules(
        self,
        sg_id: str,
        rules: List[Dict[str, Any]],
    ) -> List[NetworkSecurityFinding]:
        """Analyze outbound rules."""
        findings = []
        
        # Check if all traffic is allowed outbound
        for rule in rules:
            protocol = rule.get("IpProtocol", "")
            ip_ranges = rule.get("IpRanges", [])
            
            if protocol == "-1":
                for ip_range in ip_ranges:
                    if ip_range.get("CidrIp") == "0.0.0.0/0":
                        findings.append(NetworkSecurityFinding(
                            finding_type=NetworkFindingType.MISSING_EGRESS,
                            severity=NetworkFindingSeverity.MEDIUM,
                            resource_id=sg_id,
                            description="All outbound traffic allowed (no egress filtering)",
                            evidence={
                                "protocol": "all",
                                "destination": "0.0.0.0/0",
                            },
                            remediation="Implement egress filtering; allow only required destinations",
                            mitre_technique="T1095",
                        ))
        
        return findings
    
    async def analyze_vpc_nacls(
        self,
        ec2_client,
        vpc_id: str,
    ) -> List[NetworkSecurityFinding]:
        """
        Analyze VPC Network ACLs.
        
        Args:
            ec2_client: boto3 EC2 client
            vpc_id: VPC ID
            
        Returns:
            List of NACL findings
        """
        findings = []
        
        try:
            response = ec2_client.describe_network_acls(
                Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
            )
            
            for nacl in response.get("NetworkAcls", []):
                nacl_id = nacl.get("NetworkAclId", "")
                
                for entry in nacl.get("Entries", []):
                    # Check for overly permissive rules
                    cidr = entry.get("CidrBlock", "")
                    protocol = entry.get("Protocol", "")
                    rule_action = entry.get("RuleAction", "")
                    egress = entry.get("Egress", False)
                    
                    if cidr == "0.0.0.0/0" and protocol == "-1" and rule_action == "allow":
                        findings.append(NetworkSecurityFinding(
                            finding_type=NetworkFindingType.OVERLY_PERMISSIVE,
                            severity=NetworkFindingSeverity.MEDIUM,
                            resource_id=nacl_id,
                            description=f"NACL allows all {'outbound' if egress else 'inbound'} traffic",
                            evidence={
                                "cidr": cidr,
                                "protocol": "all",
                                "direction": "egress" if egress else "ingress",
                            },
                            remediation="Add more restrictive NACL rules",
                            mitre_technique="T1046",
                        ))
                        
        except ClientError as e:
            logger.error(f"Error analyzing NACLs for VPC {vpc_id}: {e}")
        
        return findings
    
    async def find_lateral_movement_paths(
        self,
        ec2_client,
        vpc_id: str,
    ) -> List[Dict[str, Any]]:
        """
        Find potential lateral movement paths in VPC.
        
        Args:
            ec2_client: boto3 EC2 client
            vpc_id: VPC ID
            
        Returns:
            List of lateral movement paths
        """
        paths = []
        
        try:
            # Get all security groups in VPC
            response = ec2_client.describe_security_groups(
                Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
            )
            
            sg_map = {sg["GroupId"]: sg for sg in response.get("SecurityGroups", [])}
            
            for sg_id, sg in sg_map.items():
                for rule in sg.get("IpPermissions", []):
                    from_port = rule.get("FromPort", 0)
                    
                    # Check for references to other SGs
                    for sg_ref in rule.get("UserIdGroupPairs", []):
                        ref_sg_id = sg_ref.get("GroupId", "")
                        
                        if ref_sg_id in sg_map:
                            path = {
                                "source_sg": ref_sg_id,
                                "source_name": sg_map[ref_sg_id].get("GroupName", ""),
                                "target_sg": sg_id,
                                "target_name": sg.get("GroupName", ""),
                                "port": from_port,
                                "protocol": rule.get("IpProtocol", ""),
                            }
                            
                            # Classify the path
                            if from_port == 22:
                                path["type"] = "SSH"
                                path["risk"] = "medium"
                            elif from_port == 3389:
                                path["type"] = "RDP"
                                path["risk"] = "high"
                            elif from_port == 445:
                                path["type"] = "SMB"
                                path["risk"] = "high"
                            elif from_port in [3306, 5432, 1433, 27017]:
                                path["type"] = "Database"
                                path["risk"] = "high"
                            else:
                                path["type"] = "Other"
                                path["risk"] = "low"
                            
                            paths.append(path)
                            
        except ClientError as e:
            logger.error(f"Error finding lateral movement paths: {e}")
        
        return paths
    
    async def check_public_exposure(
        self,
        ec2_client,
    ) -> List[NetworkSecurityFinding]:
        """
        Check for publicly exposed resources.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of exposure findings
        """
        findings = []
        
        try:
            # Check for instances with public IPs in insecure SGs
            instances = ec2_client.describe_instances()
            
            for reservation in instances.get("Reservations", []):
                for instance in reservation.get("Instances", []):
                    instance_id = instance.get("InstanceId", "")
                    public_ip = instance.get("PublicIpAddress")
                    
                    if public_ip:
                        # Check security groups
                        for sg in instance.get("SecurityGroups", []):
                            sg_id = sg.get("GroupId", "")
                            
                            sg_response = ec2_client.describe_security_groups(GroupIds=[sg_id])
                            sg_detail = sg_response["SecurityGroups"][0] if sg_response.get("SecurityGroups") else {}
                            
                            for rule in sg_detail.get("IpPermissions", []):
                                for ip_range in rule.get("IpRanges", []):
                                    if ip_range.get("CidrIp") == "0.0.0.0/0":
                                        port = rule.get("FromPort", 0)
                                        
                                        if port in DANGEROUS_PORTS:
                                            findings.append(NetworkSecurityFinding(
                                                finding_type=NetworkFindingType.EXPOSURE,
                                                severity=DANGEROUS_PORTS[port]["severity"],
                                                resource_id=instance_id,
                                                description=f"Instance with public IP has {DANGEROUS_PORTS[port]['name']} exposed",
                                                evidence={
                                                    "instance_id": instance_id,
                                                    "public_ip": public_ip,
                                                    "port": port,
                                                    "sg_id": sg_id,
                                                },
                                                remediation=f"Restrict access to port {port}",
                                                mitre_technique="T1046",
                                            ))
                                            
        except ClientError as e:
            logger.error(f"Error checking public exposure: {e}")
        
        return findings
    
    async def analyze_vpc_flow_logs(
        self,
        logs_client,
        log_group: str,
        hours: int = 24,
    ) -> List[NetworkSecurityFinding]:
        """
        Analyze VPC flow logs for anomalies.
        
        Args:
            logs_client: boto3 CloudWatch Logs client
            log_group: Log group name
            hours: Hours to analyze
            
        Returns:
            List of flow log findings
        """
        findings = []
        
        # This would query CloudWatch Logs Insights for:
        # - Rejected traffic patterns
        # - Port scanning indicators
        # - Data exfiltration patterns
        # - Unusual traffic volumes
        
        anomaly_queries = {
            "rejected_connections": """
                fields @timestamp, srcAddr, dstAddr, dstPort, action
                | filter action = "REJECT"
                | stats count(*) as rejects by srcAddr, dstPort
                | sort rejects desc
                | limit 10
            """,
            "port_scan_detection": """
                fields @timestamp, srcAddr, dstAddr, dstPort
                | filter action = "REJECT"
                | stats count(distinct dstPort) as ports by srcAddr
                | filter ports > 10
            """,
            "large_data_transfer": """
                fields @timestamp, srcAddr, dstAddr, bytes
                | filter bytes > 1000000000
                | stats sum(bytes) as total_bytes by srcAddr, dstAddr
            """,
        }
        
        # Return informational finding about flow log analysis
        findings.append(NetworkSecurityFinding(
            finding_type=NetworkFindingType.FLOW_ANOMALY,
            severity=NetworkFindingSeverity.INFO,
            resource_id=log_group,
            description="VPC Flow Log analysis queries available",
            evidence={"queries": list(anomaly_queries.keys())},
            remediation="Run anomaly detection queries regularly",
            mitre_technique="T1046",
        ))
        
        return findings
    
    def _calculate_sg_risk_score(
        self,
        findings: List[NetworkSecurityFinding],
    ) -> float:
        """Calculate risk score for security group."""
        severity_weights = {
            NetworkFindingSeverity.CRITICAL: 10,
            NetworkFindingSeverity.HIGH: 7,
            NetworkFindingSeverity.MEDIUM: 4,
            NetworkFindingSeverity.LOW: 1,
            NetworkFindingSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    async def analyze_vpc(
        self,
        ec2_client,
        vpc_id: str,
    ) -> VPCNetworkAnalysis:
        """
        Perform comprehensive VPC network analysis.
        
        Args:
            ec2_client: boto3 EC2 client
            vpc_id: VPC ID
            
        Returns:
            VPCNetworkAnalysis
        """
        # Get all security groups in VPC
        response = ec2_client.describe_security_groups(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
        )
        
        sg_analyses = []
        for sg in response.get("SecurityGroups", []):
            sg_analysis = await self.analyze_security_group(ec2_client, sg["GroupId"])
            sg_analyses.append(sg_analysis)
        
        # Analyze NACLs
        nacl_findings = await self.analyze_vpc_nacls(ec2_client, vpc_id)
        
        # Find lateral movement paths
        lateral_paths = await self.find_lateral_movement_paths(ec2_client, vpc_id)
        
        # Calculate overall exposure score
        all_findings = []
        for sg_analysis in sg_analyses:
            all_findings.extend(sg_analysis.findings)
        all_findings.extend(nacl_findings)
        
        exposure_score = self._calculate_sg_risk_score(all_findings)
        
        self.findings = all_findings
        
        return VPCNetworkAnalysis(
            vpc_id=vpc_id,
            security_groups=sg_analyses,
            nacl_findings=nacl_findings,
            exposure_score=exposure_score,
            lateral_movement_paths=lateral_paths,
        )
    
    def get_findings(self) -> List[NetworkSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_dangerous_ports(self) -> Dict[int, Dict[str, Any]]:
        """Get dangerous ports database."""
        return DANGEROUS_PORTS

