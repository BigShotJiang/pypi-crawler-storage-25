"""
IAM Check Service

Service for executing IAM-related security checks.
"""

import base64
import asyncio
from datetime import datetime
from typing import Any, Dict, List
import logging

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception
from ...proto import (
    ScanOptions,
    SecurityFinding,
    AWSResourceType,
    SeverityLevel,
)
from ..utils import check_content_for_secrets

logger = logging.getLogger(__name__)


class IAMCheckService:
    """Service for executing IAM security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize IAM check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute IAM check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_root_account_usage": self.check_root_account_usage,
            "check_root_mfa": self.check_root_mfa,
            "check_user_mfa": self.check_user_mfa,
            "check_access_key_rotation": self.check_access_key_rotation,
            "check_unused_credentials": self.check_unused_credentials,
            "check_password_policy": self.check_password_policy,
            "check_admin_policy": self.check_admin_policy,
            "check_role_trust_any": self.check_role_trust_any,
            "check_cross_account_external_id": self.check_cross_account_external_id,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_root_account_usage(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check root account access key usage."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            summary = iam.get_account_summary()
            if summary["SummaryMap"].get("AccountAccessKeysPresent", 0) > 0:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region="global",
                    resource_type=AWSResourceType.ACCOUNT, resource_id=account_id,
                    description="Root account has active access keys",
                    recommendation="Delete root account access keys and use IAM users instead",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"access_keys_present": True},
                    remediation_commands=["# Delete root access keys from AWS Console > Security credentials"],
                ))
        except Exception as e:
            logger.error(f"Root account check failed: {e}")
        return findings
    
    async def check_root_mfa(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if root account has MFA enabled."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            summary = iam.get_account_summary()
            if summary["SummaryMap"].get("AccountMFAEnabled", 0) == 0:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region="global",
                    resource_type=AWSResourceType.ACCOUNT, resource_id=account_id,
                    description="Root account does not have MFA enabled",
                    recommendation="Enable MFA on the root account immediately",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"mfa_enabled": False},
                ))
        except Exception as e:
            logger.error(f"Root MFA check failed: {e}")
        return findings
    
    async def check_user_mfa(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for IAM users without MFA."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            users = iam.list_users()["Users"]
            for user in users:
                user_name = user["UserName"]
                try:
                    iam.get_login_profile(UserName=user_name)
                    has_console = True
                except ClientError:
                    has_console = False
                if has_console:
                    mfa_devices = iam.list_mfa_devices(UserName=user_name)["MFADevices"]
                    if not mfa_devices:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.IAM_USER, resource_id=user_name, arn=user["Arn"],
                            description=f"IAM user '{user_name}' has console access but no MFA",
                            recommendation="Enable MFA for all users with console access",
                            severity=SeverityLevel.HIGH,
                            evidence={"has_console_access": True, "mfa_enabled": False},
                            remediation_commands=[
                                f"# Enable MFA via Console or assign virtual MFA:",
                                f"aws iam create-virtual-mfa-device --virtual-mfa-device-name {user_name}-mfa"
                            ],
                        ))
        except Exception as e:
            logger.error(f"User MFA check failed: {e}")
        return findings
    
    async def check_access_key_rotation(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for old access keys."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            users = iam.list_users()["Users"]
            for user in users:
                user_name = user["UserName"]
                keys = iam.list_access_keys(UserName=user_name)["AccessKeyMetadata"]
                for key in keys:
                    if key["Status"] != "Active":
                        continue
                    key_age = (datetime.now(key["CreateDate"].tzinfo) - key["CreateDate"]).days
                    if key_age > 90:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.IAM_ACCESS_KEY, resource_id=key["AccessKeyId"],
                            description=f"Access key for '{user_name}' is {key_age} days old",
                            recommendation="Rotate access keys every 90 days",
                            severity=SeverityLevel.HIGH if key_age > 180 else SeverityLevel.MEDIUM,
                            evidence={"key_age_days": key_age, "user": user_name},
                            remediation_commands=[
                                f"aws iam create-access-key --user-name {user_name}",
                                f"aws iam update-access-key --access-key-id {key['AccessKeyId']} --status Inactive --user-name {user_name}",
                                f"aws iam delete-access-key --access-key-id {key['AccessKeyId']} --user-name {user_name}"
                            ],
                        ))
        except Exception as e:
            logger.error(f"Access key rotation check failed: {e}")
        return findings
    
    async def check_unused_credentials(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for unused IAM credentials."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            iam.generate_credential_report()
            await asyncio.sleep(2)
            report = iam.get_credential_report()
            content = base64.b64decode(report["Content"]).decode("utf-8")
            for line in content.split("\n")[1:]:
                if not line.strip():
                    continue
                fields = line.split(",")
                if len(fields) < 5:
                    continue
                user = fields[0]
                password_last_used = fields[4]
                if user == "<root_account>":
                    continue
                if password_last_used not in ["N/A", "no_information", "not_supported"]:
                    try:
                        last_used = datetime.fromisoformat(password_last_used.replace("Z", "+00:00"))
                        days_unused = (datetime.now(last_used.tzinfo) - last_used).days
                        if days_unused > 90:
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region="global",
                                resource_type=AWSResourceType.IAM_USER, resource_id=user,
                                description=f"IAM user '{user}' has not logged in for {days_unused} days",
                                recommendation="Remove or disable unused IAM users",
                                severity=SeverityLevel.MEDIUM,
                                evidence={"days_since_login": days_unused},
                            ))
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Unused credentials check failed: {e}")
        return findings
    
    async def check_password_policy(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check IAM password policy."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            try:
                policy = iam.get_account_password_policy()["PasswordPolicy"]
            except ClientError as e:
                if e.response["Error"]["Code"] == "NoSuchEntity":
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region="global",
                        resource_type=AWSResourceType.IAM_PASSWORD_POLICY, resource_id="password-policy",
                        description="No IAM password policy is configured",
                        recommendation="Configure a strong password policy",
                        severity=SeverityLevel.HIGH,
                        evidence={"policy_exists": False},
                    ))
                    return findings
                raise
            issues = []
            if policy.get("MinimumPasswordLength", 0) < 14:
                issues.append(f"Minimum length is {policy.get('MinimumPasswordLength', 0)} (should be 14+)")
            if not policy.get("RequireSymbols"):
                issues.append("Does not require symbols")
            if not policy.get("RequireNumbers"):
                issues.append("Does not require numbers")
            if not policy.get("RequireUppercaseCharacters"):
                issues.append("Does not require uppercase")
            if not policy.get("RequireLowercaseCharacters"):
                issues.append("Does not require lowercase")
            if policy.get("MaxPasswordAge", 0) == 0 or policy.get("MaxPasswordAge", 999) > 90:
                issues.append("Password does not expire or expires after 90 days")
            if policy.get("PasswordReusePrevention", 0) < 24:
                issues.append(f"Password reuse prevention is {policy.get('PasswordReusePrevention', 0)} (should be 24)")
            if issues:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region="global",
                    resource_type=AWSResourceType.IAM_PASSWORD_POLICY, resource_id="password-policy",
                    description=f"Password policy issues: {'; '.join(issues)}",
                    recommendation="Strengthen password policy to meet CIS benchmarks",
                    severity=SeverityLevel.HIGH,
                    evidence={"policy": policy, "issues": issues},
                ))
        except Exception as e:
            logger.error(f"Password policy check failed: {e}")
        return findings
    
    async def check_admin_policy(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for AdministratorAccess policy usage."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            admin_policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
            try:
                entities = iam.list_entities_for_policy(PolicyArn=admin_policy_arn)
                for user in entities.get("PolicyUsers", []):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region="global",
                        resource_type=AWSResourceType.IAM_USER, resource_id=user["UserName"],
                        description=f"IAM user '{user['UserName']}' has AdministratorAccess",
                        recommendation="Use least privilege - create specific policies",
                        severity=SeverityLevel.CRITICAL,
                        evidence={"policy": "AdministratorAccess"},
                    ))
                for role in entities.get("PolicyRoles", []):
                    if "AWSServiceRoleFor" in role["RoleName"]:
                        continue
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region="global",
                        resource_type=AWSResourceType.IAM_ROLE, resource_id=role["RoleName"],
                        description=f"IAM role '{role['RoleName']}' has AdministratorAccess",
                        recommendation="Use least privilege - create specific policies",
                        severity=SeverityLevel.HIGH,
                        evidence={"policy": "AdministratorAccess"},
                    ))
            except ClientError:
                pass
        except Exception as e:
            logger.error(f"Admin policy check failed: {e}")
        return findings
    
    async def check_role_trust_any(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for roles assumable by any principal."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for role in page["Roles"]:
                    trust_policy = role.get("AssumeRolePolicyDocument", {})
                    for statement in trust_policy.get("Statement", []):
                        if statement.get("Effect") != "Allow":
                            continue
                        principal = statement.get("Principal", {})
                        if principal == "*" or principal.get("AWS") == "*":
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region="global",
                                resource_type=AWSResourceType.IAM_ROLE, resource_id=role["RoleName"], arn=role["Arn"],
                                description=f"Role '{role['RoleName']}' can be assumed by any AWS principal",
                                recommendation="Restrict trust policy to specific principals",
                                severity=SeverityLevel.CRITICAL,
                                evidence={"trust_policy": trust_policy},
                            ))
        except Exception as e:
            logger.error(f"Role trust check failed: {e}")
        return findings
    
    async def check_cross_account_external_id(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check cross-account roles without external ID."""
        findings = []
        try:
            iam = self.plugin._get_client("iam")
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for role in page["Roles"]:
                    trust_policy = role.get("AssumeRolePolicyDocument", {})
                    for statement in trust_policy.get("Statement", []):
                        if statement.get("Effect") != "Allow":
                            continue
                        principal = statement.get("Principal", {})
                        aws_principals = principal.get("AWS", [])
                        if isinstance(aws_principals, str):
                            aws_principals = [aws_principals]
                        for p in aws_principals:
                            if ":root" in p and account_id not in p:
                                condition = statement.get("Condition", {})
                                has_external_id = "sts:ExternalId" in str(condition)
                                if not has_external_id:
                                    findings.append(self.plugin.finding_factory_service.create_finding(
                                        check=check, account_id=account_id, region="global",
                                        resource_type=AWSResourceType.IAM_ROLE, resource_id=role["RoleName"], arn=role["Arn"],
                                        description=f"Cross-account role '{role['RoleName']}' without ExternalId condition",
                                        recommendation="Add ExternalId condition to prevent confused deputy attacks",
                                        severity=SeverityLevel.HIGH,
                                        evidence={"external_account": p, "has_external_id": False},
                                    ))
        except Exception as e:
            logger.error(f"Cross-account external ID check failed: {e}")
        return findings

