"""
Cost-Based Attack Detection Service

Detects potential cost-based attacks and resource abuse:
- Resource exhaustion attacks
- Billing manipulation
- Spot instance abuse
- Reserved capacity abuse
- Crypto mining detection
- Data transfer abuse

MITRE ATT&CK:
- T1496: Resource Hijacking
- T1499: Endpoint Denial of Service
- T1498: Network Denial of Service
- T1565: Data Manipulation
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception

logger = logging.getLogger(__name__)


class CostAttackSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class CostAttackType(str, Enum):
    """Types of cost-based attacks."""
    RESOURCE_EXHAUSTION = "resource_exhaustion"
    BILLING_MANIPULATION = "billing_manipulation"
    CRYPTO_MINING = "crypto_mining"
    DATA_TRANSFER = "data_transfer"
    SPOT_ABUSE = "spot_abuse"
    RESERVED_ABUSE = "reserved_abuse"
    SERVICE_QUOTAS = "service_quotas"


# =============================================================================
# Resource Exhaustion Patterns
# =============================================================================

RESOURCE_EXHAUSTION_PATTERNS = {
    "ec2_mass_launch": {
        "name": "EC2 Mass Instance Launch",
        "description": "Unusual number of EC2 instances launched",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1496",
        "threshold": 50,
        "timeframe_hours": 24,
    },
    "lambda_invocation_spike": {
        "name": "Lambda Invocation Spike",
        "description": "Unusual spike in Lambda invocations",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1499",
        "threshold_percent": 500,
    },
    "s3_request_flood": {
        "name": "S3 Request Flood",
        "description": "Excessive S3 requests indicating abuse",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1498",
        "threshold": 1000000,
        "timeframe_hours": 1,
    },
    "dynamodb_capacity_spike": {
        "name": "DynamoDB Capacity Spike",
        "description": "Unusual DynamoDB capacity consumption",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1499",
    },
    "rds_storage_growth": {
        "name": "RDS Storage Growth",
        "description": "Rapid RDS storage growth",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1499",
        "threshold_gb_per_day": 100,
    },
}


# =============================================================================
# Crypto Mining Indicators
# =============================================================================

CRYPTO_MINING_INDICATORS = {
    "gpu_instance_launch": {
        "name": "GPU Instance Launch",
        "description": "GPU instance types potentially used for mining",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1496",
        "instance_types": [
            "p2.", "p3.", "p4.", "p5.",
            "g3.", "g4.", "g5.",
            "inf1.", "inf2.",
            "trn1.",
        ],
    },
    "high_cpu_instances": {
        "name": "High CPU Instances",
        "description": "Compute-optimized instances for potential mining",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1496",
        "instance_types": [
            "c5.", "c6.", "c7.",
            "c5a.", "c6a.", "c7a.",
            "hpc6.", "hpc7.",
        ],
    },
    "mining_software_ports": {
        "name": "Mining Pool Ports",
        "description": "Security groups allowing mining pool ports",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1496",
        "ports": [3333, 4444, 5555, 8888, 9999, 14444, 45560],
    },
    "mining_domains": {
        "name": "Mining Pool Domains",
        "description": "DNS queries to known mining pools",
        "severity": CostAttackSeverity.CRITICAL,
        "mitre": "T1496",
        "domains": [
            "pool.minexmr.com",
            "xmr.nanopool.org",
            "pool.supportxmr.com",
            "xmrpool.eu",
            "moneroocean.stream",
            "f2pool.com",
            "nicehash.com",
            "ethermine.org",
            "mining.bitcoin.cz",
        ],
    },
    "high_cpu_utilization": {
        "name": "Sustained High CPU",
        "description": "Sustained high CPU utilization (>90%)",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1496",
        "threshold_percent": 90,
        "duration_hours": 24,
    },
}


# =============================================================================
# Data Transfer Abuse Patterns
# =============================================================================

DATA_TRANSFER_PATTERNS = {
    "cross_region_transfer": {
        "name": "Cross-Region Data Transfer",
        "description": "Unusual cross-region data transfer",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1048",
        "threshold_gb": 100,
    },
    "internet_egress_spike": {
        "name": "Internet Egress Spike",
        "description": "Unusual internet egress traffic",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1048",
        "threshold_gb": 1000,
    },
    "nat_gateway_abuse": {
        "name": "NAT Gateway Abuse",
        "description": "Excessive NAT Gateway data processing",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1498",
        "threshold_gb": 500,
    },
    "vpc_peering_transfer": {
        "name": "VPC Peering Transfer",
        "description": "Unusual VPC peering data transfer",
        "severity": CostAttackSeverity.LOW,
        "mitre": "T1048",
    },
}


# =============================================================================
# Billing Manipulation Patterns
# =============================================================================

BILLING_MANIPULATION_PATTERNS = {
    "budget_alert_disabled": {
        "name": "Budget Alerts Disabled",
        "description": "AWS Budget alerts disabled or removed",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1565",
    },
    "cost_anomaly_subscription_removed": {
        "name": "Cost Anomaly Subscription Removed",
        "description": "Cost anomaly detection subscription removed",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1565",
    },
    "billing_console_access": {
        "name": "Billing Console Access",
        "description": "Unusual billing console access",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1565",
    },
    "payment_method_change": {
        "name": "Payment Method Change",
        "description": "Payment method changed",
        "severity": CostAttackSeverity.HIGH,
        "mitre": "T1565",
    },
}


# =============================================================================
# Service Quota Abuse
# =============================================================================

SERVICE_QUOTA_PATTERNS = {
    "quota_increase_request": {
        "name": "Service Quota Increase",
        "description": "Multiple service quota increase requests",
        "severity": CostAttackSeverity.MEDIUM,
        "mitre": "T1496",
    },
    "limit_exceeded_errors": {
        "name": "Limit Exceeded Errors",
        "description": "Frequent limit exceeded errors",
        "severity": CostAttackSeverity.LOW,
        "mitre": "T1499",
    },
}


@dataclass
class CostAttackFinding:
    """A cost-based attack finding."""
    attack_type: CostAttackType
    severity: CostAttackSeverity
    name: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    estimated_cost_impact: float = 0.0
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class CostSecurityReport:
    """Cost security report."""
    findings: List[CostAttackFinding] = field(default_factory=list)
    total_estimated_impact: float = 0.0
    crypto_mining_indicators: int = 0
    resource_exhaustion_indicators: int = 0
    risk_score: float = 0.0


class CostAttackService:
    """Service for detecting cost-based attacks."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[CostAttackFinding] = []
    
    async def check_ec2_resource_exhaustion(
        self,
        ec2_client,
        cloudwatch_client=None,
    ) -> List[CostAttackFinding]:
        """
        Check for EC2 resource exhaustion indicators.
        
        Args:
            ec2_client: boto3 EC2 client
            cloudwatch_client: boto3 CloudWatch client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # Count running instances
            instances = ec2_client.describe_instances(
                Filters=[{"Name": "instance-state-name", "Values": ["running"]}]
            )
            
            running_count = 0
            gpu_instances = []
            high_cpu_instances = []
            
            for reservation in instances.get("Reservations", []):
                for instance in reservation.get("Instances", []):
                    running_count += 1
                    instance_type = instance.get("InstanceType", "")
                    instance_id = instance.get("InstanceId", "")
                    
                    # Check for GPU instances
                    for gpu_prefix in CRYPTO_MINING_INDICATORS["gpu_instance_launch"]["instance_types"]:
                        if instance_type.startswith(gpu_prefix):
                            gpu_instances.append({
                                "instance_id": instance_id,
                                "instance_type": instance_type,
                            })
                            break
                    
                    # Check for high CPU instances
                    for cpu_prefix in CRYPTO_MINING_INDICATORS["high_cpu_instances"]["instance_types"]:
                        if instance_type.startswith(cpu_prefix):
                            high_cpu_instances.append({
                                "instance_id": instance_id,
                                "instance_type": instance_type,
                            })
                            break
            
            # Check for mass instance launch
            if running_count > RESOURCE_EXHAUSTION_PATTERNS["ec2_mass_launch"]["threshold"]:
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.RESOURCE_EXHAUSTION,
                    severity=CostAttackSeverity.HIGH,
                    name="EC2 Mass Instance Launch",
                    description=f"{running_count} running instances detected",
                    evidence={"running_instances": running_count},
                    estimated_cost_impact=running_count * 50.0,  # Rough estimate
                    remediation="Review and terminate unnecessary instances",
                    mitre_technique="T1496",
                ))
            
            # Report GPU instances
            if gpu_instances:
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.CRYPTO_MINING,
                    severity=CostAttackSeverity.HIGH,
                    name="GPU Instances Detected",
                    description=f"{len(gpu_instances)} GPU instances running - potential mining",
                    evidence={"gpu_instances": gpu_instances[:10]},
                    estimated_cost_impact=len(gpu_instances) * 500.0,
                    remediation="Verify GPU instances are legitimate workloads",
                    mitre_technique="T1496",
                ))
            
            # Report high CPU instances
            if len(high_cpu_instances) > 10:
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.CRYPTO_MINING,
                    severity=CostAttackSeverity.MEDIUM,
                    name="High CPU Instances Cluster",
                    description=f"{len(high_cpu_instances)} compute-optimized instances",
                    evidence={"high_cpu_instances": high_cpu_instances[:10]},
                    estimated_cost_impact=len(high_cpu_instances) * 100.0,
                    remediation="Verify compute instances are legitimate",
                    mitre_technique="T1496",
                ))
                
        except ClientError as e:
            logger.error(f"Error checking EC2: {e}")
        
        return findings
    
    async def check_security_groups_for_mining(
        self,
        ec2_client,
    ) -> List[CostAttackFinding]:
        """
        Check security groups for mining pool ports.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            sgs = ec2_client.describe_security_groups()
            mining_ports = CRYPTO_MINING_INDICATORS["mining_software_ports"]["ports"]
            
            for sg in sgs.get("SecurityGroups", []):
                sg_id = sg.get("GroupId", "")
                
                # Check outbound rules
                for rule in sg.get("IpPermissionsEgress", []):
                    from_port = rule.get("FromPort", 0)
                    to_port = rule.get("ToPort", 0)
                    
                    for mining_port in mining_ports:
                        if from_port <= mining_port <= to_port:
                            for ip_range in rule.get("IpRanges", []):
                                if ip_range.get("CidrIp") == "0.0.0.0/0":
                                    findings.append(CostAttackFinding(
                                        attack_type=CostAttackType.CRYPTO_MINING,
                                        severity=CostAttackSeverity.HIGH,
                                        name="Mining Pool Port Allowed",
                                        description=f"SG {sg_id} allows outbound to mining port {mining_port}",
                                        evidence={
                                            "sg_id": sg_id,
                                            "port": mining_port,
                                        },
                                        remediation="Block outbound traffic to mining pools",
                                        mitre_technique="T1496",
                                    ))
                                    
        except ClientError as e:
            logger.error(f"Error checking security groups: {e}")
        
        return findings
    
    async def check_budget_alerts(
        self,
        budgets_client,
        account_id: str,
    ) -> List[CostAttackFinding]:
        """
        Check AWS Budget configuration.
        
        Args:
            budgets_client: boto3 Budgets client
            account_id: AWS account ID
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            budgets = budgets_client.describe_budgets(AccountId=account_id)
            
            if not budgets.get("Budgets"):
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.BILLING_MANIPULATION,
                    severity=CostAttackSeverity.HIGH,
                    name="No Budget Alerts Configured",
                    description="No AWS Budget alerts configured for cost monitoring",
                    evidence={"budgets_count": 0},
                    remediation="Create budget alerts for cost anomaly detection",
                    mitre_technique="T1565",
                ))
            else:
                # Check each budget for notifications
                for budget in budgets.get("Budgets", []):
                    budget_name = budget.get("BudgetName", "")
                    
                    try:
                        notifications = budgets_client.describe_notifications_for_budget(
                            AccountId=account_id,
                            BudgetName=budget_name
                        )
                        
                        if not notifications.get("Notifications"):
                            findings.append(CostAttackFinding(
                                attack_type=CostAttackType.BILLING_MANIPULATION,
                                severity=CostAttackSeverity.MEDIUM,
                                name="Budget Without Notifications",
                                description=f"Budget {budget_name} has no notifications",
                                evidence={"budget_name": budget_name},
                                remediation="Add notification subscribers to budget",
                                mitre_technique="T1565",
                            ))
                            
                    except ClientError:
                        pass
                        
        except ClientError as e:
            logger.error(f"Error checking budgets: {e}")
        
        return findings
    
    async def check_cost_anomaly_detection(
        self,
        ce_client,
    ) -> List[CostAttackFinding]:
        """
        Check Cost Anomaly Detection configuration.
        
        Args:
            ce_client: boto3 Cost Explorer client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            monitors = ce_client.get_anomaly_monitors()
            
            if not monitors.get("AnomalyMonitors"):
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.BILLING_MANIPULATION,
                    severity=CostAttackSeverity.HIGH,
                    name="No Cost Anomaly Detection",
                    description="AWS Cost Anomaly Detection not configured",
                    evidence={"monitors_count": 0},
                    remediation="Enable Cost Anomaly Detection with subscriptions",
                    mitre_technique="T1565",
                ))
            else:
                # Check subscriptions
                subscriptions = ce_client.get_anomaly_subscriptions()
                
                if not subscriptions.get("AnomalySubscriptions"):
                    findings.append(CostAttackFinding(
                        attack_type=CostAttackType.BILLING_MANIPULATION,
                        severity=CostAttackSeverity.MEDIUM,
                        name="No Anomaly Subscriptions",
                        description="Cost anomaly monitors exist but no subscriptions",
                        evidence={
                            "monitors": len(monitors.get("AnomalyMonitors", [])),
                            "subscriptions": 0,
                        },
                        remediation="Create anomaly subscriptions for alerts",
                        mitre_technique="T1565",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking cost anomaly detection: {e}")
        
        return findings
    
    async def check_data_transfer_costs(
        self,
        ce_client,
    ) -> List[CostAttackFinding]:
        """
        Check for unusual data transfer costs.
        
        Args:
            ce_client: boto3 Cost Explorer client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            import datetime
            
            end_date = datetime.date.today()
            start_date = end_date - datetime.timedelta(days=30)
            
            response = ce_client.get_cost_and_usage(
                TimePeriod={
                    "Start": start_date.strftime("%Y-%m-%d"),
                    "End": end_date.strftime("%Y-%m-%d"),
                },
                Granularity="MONTHLY",
                Metrics=["UnblendedCost"],
                GroupBy=[
                    {"Type": "DIMENSION", "Key": "SERVICE"},
                ],
            )
            
            for result in response.get("ResultsByTime", []):
                for group in result.get("Groups", []):
                    service = group.get("Keys", [""])[0]
                    cost = float(group.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", 0))
                    
                    # Check for high data transfer costs
                    if "Data Transfer" in service and cost > 1000:
                        findings.append(CostAttackFinding(
                            attack_type=CostAttackType.DATA_TRANSFER,
                            severity=CostAttackSeverity.MEDIUM,
                            name="High Data Transfer Costs",
                            description=f"Data transfer costs: ${cost:.2f}",
                            evidence={
                                "service": service,
                                "cost": cost,
                            },
                            estimated_cost_impact=cost,
                            remediation="Review data transfer patterns; use VPC endpoints",
                            mitre_technique="T1048",
                        ))
                        
        except ClientError as e:
            logger.error(f"Error checking data transfer costs: {e}")
        
        return findings
    
    async def check_spot_instance_abuse(
        self,
        ec2_client,
    ) -> List[CostAttackFinding]:
        """
        Check for spot instance abuse.
        
        Args:
            ec2_client: boto3 EC2 client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            spot_requests = ec2_client.describe_spot_instance_requests()
            
            spot_count = len(spot_requests.get("SpotInstanceRequests", []))
            
            if spot_count > 100:
                findings.append(CostAttackFinding(
                    attack_type=CostAttackType.SPOT_ABUSE,
                    severity=CostAttackSeverity.MEDIUM,
                    name="High Spot Instance Requests",
                    description=f"{spot_count} spot instance requests detected",
                    evidence={"spot_requests": spot_count},
                    remediation="Review spot instance requests for legitimacy",
                    mitre_technique="T1496",
                ))
                
        except ClientError as e:
            logger.error(f"Error checking spot instances: {e}")
        
        return findings
    
    async def run_full_scan(
        self,
        ec2_client=None,
        budgets_client=None,
        ce_client=None,
        cloudwatch_client=None,
        account_id: str = "",
    ) -> CostSecurityReport:
        """
        Run full cost-based attack detection.
        
        Args:
            ec2_client: boto3 EC2 client
            budgets_client: boto3 Budgets client
            ce_client: boto3 Cost Explorer client
            cloudwatch_client: boto3 CloudWatch client
            account_id: AWS account ID
            
        Returns:
            CostSecurityReport
        """
        all_findings = []
        crypto_indicators = 0
        exhaustion_indicators = 0
        
        if ec2_client:
            # Check EC2 resource exhaustion
            ec2_findings = await self.check_ec2_resource_exhaustion(ec2_client, cloudwatch_client)
            all_findings.extend(ec2_findings)
            
            # Check security groups for mining
            sg_findings = await self.check_security_groups_for_mining(ec2_client)
            all_findings.extend(sg_findings)
            
            # Check spot instances
            spot_findings = await self.check_spot_instance_abuse(ec2_client)
            all_findings.extend(spot_findings)
        
        if budgets_client and account_id:
            budget_findings = await self.check_budget_alerts(budgets_client, account_id)
            all_findings.extend(budget_findings)
        
        if ce_client:
            # Check cost anomaly detection
            anomaly_findings = await self.check_cost_anomaly_detection(ce_client)
            all_findings.extend(anomaly_findings)
            
            # Check data transfer costs
            transfer_findings = await self.check_data_transfer_costs(ce_client)
            all_findings.extend(transfer_findings)
        
        # Count indicators
        for finding in all_findings:
            if finding.attack_type == CostAttackType.CRYPTO_MINING:
                crypto_indicators += 1
            elif finding.attack_type == CostAttackType.RESOURCE_EXHAUSTION:
                exhaustion_indicators += 1
        
        # Calculate total estimated impact
        total_impact = sum(f.estimated_cost_impact for f in all_findings)
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return CostSecurityReport(
            findings=all_findings,
            total_estimated_impact=total_impact,
            crypto_mining_indicators=crypto_indicators,
            resource_exhaustion_indicators=exhaustion_indicators,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[CostAttackFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            CostAttackSeverity.CRITICAL: 10,
            CostAttackSeverity.HIGH: 7,
            CostAttackSeverity.MEDIUM: 4,
            CostAttackSeverity.LOW: 1,
            CostAttackSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[CostAttackFinding]:
        """Get all findings."""
        return self.findings
    
    def get_attack_patterns(self) -> Dict[str, Any]:
        """Get all attack pattern databases."""
        return {
            "resource_exhaustion": RESOURCE_EXHAUSTION_PATTERNS,
            "crypto_mining": CRYPTO_MINING_INDICATORS,
            "data_transfer": DATA_TRANSFER_PATTERNS,
            "billing_manipulation": BILLING_MANIPULATION_PATTERNS,
            "service_quotas": SERVICE_QUOTA_PATTERNS,
        }

