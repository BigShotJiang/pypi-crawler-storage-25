"""
Check Filter Service

Service for filtering checks based on scan options.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Any, Dict, List
from ...proto import ScanOptions, SeverityLevel


class CheckFilterService:
    """Service for filtering checks based on scan options."""
    
    def __init__(self, plugin_instance):
        """Initialize check filter service."""
        self.plugin = plugin_instance
    
    def filter_checks(self, checks: List[Dict], options: ScanOptions) -> List[Dict]:
        """Filter checks based on options."""
        filtered = checks
        
        if options.categories:
            filtered = [c for c in filtered if c["category"] in options.categories]
        
        if options.exclude_categories:
            filtered = [c for c in filtered if c["category"] not in options.exclude_categories]
        
        if options.scope.resource_types:
            filtered = [c for c in filtered 
                       if any(rt in options.scope.resource_types for rt in c["resource_types"])]
        
        if options.quick_scan:
            filtered = [c for c in filtered 
                       if c["severity"] in [SeverityLevel.CRITICAL, SeverityLevel.HIGH]]
        
        return filtered

