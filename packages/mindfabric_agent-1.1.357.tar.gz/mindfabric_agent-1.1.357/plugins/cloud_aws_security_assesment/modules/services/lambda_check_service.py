"""
Lambda Check Service

Service for executing Lambda and serverless-related security checks.
"""

import json
import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception
from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel
from ..utils import check_content_for_secrets

logger = logging.getLogger(__name__)


class LambdaCheckService:
    """Service for executing Lambda security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize Lambda check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Lambda check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_lambda_public": self.check_lambda_public,
            "check_lambda_admin_role": self.check_lambda_admin_role,
            "check_lambda_env_secrets": self.check_lambda_env_secrets,
            "check_eventbridge_persistence": self.check_eventbridge_persistence,
            "check_ssm_persistence": self.check_ssm_persistence,
            "check_lambda_layer_poisoning": self.check_lambda_layer_poisoning,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_lambda_public(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for publicly invokable Lambda functions."""
        findings = []
        try:
            lam = self.plugin._get_client("lambda", region)
            functions = lam.list_functions()["Functions"]
            for func in functions:
                try:
                    policy = lam.get_policy(FunctionName=func["FunctionName"])
                    policy_doc = json.loads(policy["Policy"])
                    for stmt in policy_doc.get("Statement", []):
                        principal = stmt.get("Principal", {})
                        if principal == "*" and stmt.get("Effect") == "Allow":
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.LAMBDA_FUNCTION,
                                resource_id=func["FunctionName"],
                                description=f"Lambda function '{func['FunctionName']}' is publicly invokable",
                                recommendation="Restrict function invocation to specific principals",
                                severity=SeverityLevel.HIGH,
                                evidence={"public": True},
                            ))
                except ClientError:
                    pass
        except Exception as e:
            logger.error(f"Lambda public check failed: {e}")
        return findings
    
    async def check_lambda_admin_role(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Lambda functions with admin roles."""
        findings = []
        return findings
    
    async def check_lambda_env_secrets(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for secrets in Lambda environment variables."""
        findings = []
        try:
            lam = self.plugin._get_client("lambda", region)
            functions = lam.list_functions()["Functions"]
            for func in functions:
                env_vars = func.get("Environment", {}).get("Variables", {})
                for key, value in env_vars.items():
                    secrets_found = check_content_for_secrets(f"{key}={value}")
                    if secrets_found:
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region=region,
                            resource_type=AWSResourceType.LAMBDA_FUNCTION,
                            resource_id=func["FunctionName"],
                            description=f"Lambda '{func['FunctionName']}' has potential secrets in environment variables",
                            recommendation="Use Secrets Manager or SSM Parameter Store",
                            severity=SeverityLevel.CRITICAL,
                            evidence={"secret_types": [s[1] for s in secrets_found]},
                        ))
                        break
        except Exception as e:
            logger.error(f"Lambda env secrets check failed: {e}")
        return findings
    
    async def check_eventbridge_persistence(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for EventBridge persistence mechanisms."""
        findings = []
        return findings
    
    async def check_ssm_persistence(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for SSM persistence mechanisms."""
        findings = []
        return findings
    
    async def check_lambda_layer_poisoning(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check for Lambda Layer Poisoning attacks.
        
        Lambda Layer Poisoning (T1195.003) - Supply Chain Compromise:
        Attackers can inject malicious code into Lambda layers that are shared
        across multiple functions, allowing persistence and lateral movement.
        """
        findings = []
        try:
            lam = self.plugin._get_client("lambda", region)
            functions = lam.list_functions()["Functions"]
            
            # Track layers across functions to detect shared layers
            layer_usage = {}
            
            for func in functions:
                func_name = func["FunctionName"]
                layers = func.get("Layers", [])
                
                for layer_arn in layers:
                    if layer_arn not in layer_usage:
                        layer_usage[layer_arn] = []
                    layer_usage[layer_arn].append(func_name)
                    
                    try:
                        # Get layer details
                        layer_version = layer_arn.split(":")[-1]
                        layer_name = ":".join(layer_arn.split(":")[:-1])
                        
                        layer_info = lam.get_layer_version(
                            LayerName=layer_name,
                            VersionNumber=int(layer_version)
                        )
                        
                        # Check for suspicious layer properties
                        layer_size = layer_info.get("Content", {}).get("CodeSize", 0)
                        layer_location = layer_info.get("Content", {}).get("Location", "")
                        
                        # Detect if layer is shared across many functions (potential poisoning vector)
                        if len(layer_usage[layer_arn]) > 5:
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.LAMBDA_LAYER,
                                resource_id=layer_arn,
                                description=f"Lambda layer '{layer_arn}' is used by {len(layer_usage[layer_arn])} functions - potential layer poisoning vector",
                                recommendation="Review layer contents and restrict layer sharing. Use least-privilege layer access.",
                                severity=SeverityLevel.HIGH,
                                evidence={
                                    "layer_arn": layer_arn,
                                    "used_by_functions": layer_usage[layer_arn],
                                    "layer_size": layer_size,
                                    "mitre_technique": "T1195.003",
                                },
                            ))
                        
                        # Check for layers from external accounts (supply chain risk)
                        layer_account = layer_arn.split(":")[4]
                        if layer_account != account_id:
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.LAMBDA_LAYER,
                                resource_id=layer_arn,
                                description=f"Lambda layer '{layer_arn}' is from external account {layer_account} - supply chain risk",
                                recommendation="Only use layers from trusted accounts. Review layer contents before use.",
                                severity=SeverityLevel.MEDIUM,
                                evidence={
                                    "layer_arn": layer_arn,
                                    "external_account": layer_account,
                                    "used_by_functions": layer_usage[layer_arn],
                                    "mitre_technique": "T1195.003",
                                },
                            ))
                            
                    except ClientError as e:
                        logger.warning(f"Could not get layer details for {layer_arn}: {e}")
                        continue
                        
        except Exception as e:
            logger.error(f"Lambda layer poisoning check failed: {e}")
        return findings

