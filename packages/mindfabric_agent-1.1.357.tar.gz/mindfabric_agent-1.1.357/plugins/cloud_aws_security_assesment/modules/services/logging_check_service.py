"""
Logging Check Service

Service for executing Logging-related security checks (CloudTrail, GuardDuty, Config).
"""

import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel

logger = logging.getLogger(__name__)


class LoggingCheckService:
    """Service for executing Logging security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize Logging check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Logging check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_cloudtrail_enabled": self.check_cloudtrail_enabled,
            "check_cloudtrail_multiregion": self.check_cloudtrail_multiregion,
            "check_cloudtrail_encryption": self.check_cloudtrail_encryption,
            "check_guardduty_enabled": self.check_guardduty_enabled,
            "check_config_enabled": self.check_config_enabled,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_cloudtrail_enabled(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if CloudTrail is enabled."""
        findings = []
        try:
            ct = self.plugin._get_client("cloudtrail")
            trails = ct.describe_trails()["trailList"]
            if not trails:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region="global",
                    resource_type=AWSResourceType.CLOUDTRAIL_TRAIL, resource_id="cloudtrail",
                    description="CloudTrail is not enabled",
                    recommendation="Enable CloudTrail for audit logging",
                    severity=SeverityLevel.CRITICAL,
                    evidence={"trails_count": 0},
                ))
        except Exception as e:
            logger.error(f"CloudTrail check failed: {e}")
        return findings
    
    async def check_cloudtrail_multiregion(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for multi-region CloudTrail."""
        findings = []
        try:
            ct = self.plugin._get_client("cloudtrail")
            trails = ct.describe_trails()["trailList"]
            has_multiregion = any(t.get("IsMultiRegionTrail") for t in trails)
            if not has_multiregion:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region="global",
                    resource_type=AWSResourceType.CLOUDTRAIL_TRAIL, resource_id="cloudtrail",
                    description="No multi-region CloudTrail trail exists",
                    recommendation="Create a multi-region trail for comprehensive logging",
                    severity=SeverityLevel.HIGH,
                    evidence={"multi_region_trail": False},
                ))
        except Exception as e:
            logger.error(f"CloudTrail multiregion check failed: {e}")
        return findings
    
    async def check_cloudtrail_encryption(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check CloudTrail encryption."""
        findings = []
        try:
            ct = self.plugin._get_client("cloudtrail")
            trails = ct.describe_trails()["trailList"]
            for trail in trails:
                if not trail.get("KMSKeyId"):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region="global",
                        resource_type=AWSResourceType.CLOUDTRAIL_TRAIL, resource_id=trail["Name"],
                        description=f"CloudTrail '{trail['Name']}' is not encrypted with KMS",
                        recommendation="Enable KMS encryption for CloudTrail",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"kms_encrypted": False},
                    ))
        except Exception as e:
            logger.error(f"CloudTrail encryption check failed: {e}")
        return findings
    
    async def check_guardduty_enabled(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if GuardDuty is enabled."""
        findings = []
        try:
            gd = self.plugin._get_client("guardduty", region)
            detectors = gd.list_detectors()["DetectorIds"]
            if not detectors:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region=region,
                    resource_type=AWSResourceType.GUARDDUTY_DETECTOR, resource_id="guardduty",
                    description=f"GuardDuty is not enabled in {region}",
                    recommendation="Enable GuardDuty for threat detection",
                    severity=SeverityLevel.HIGH,
                    evidence={"enabled": False},
                ))
        except Exception as e:
            logger.error(f"GuardDuty check failed: {e}")
        return findings
    
    async def check_config_enabled(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if AWS Config is enabled."""
        findings = []
        try:
            config = self.plugin._get_client("config", region)
            recorders = config.describe_configuration_recorders()["ConfigurationRecorders"]
            if not recorders:
                findings.append(self.plugin.finding_factory_service.create_finding(
                    check=check, account_id=account_id, region=region,
                    resource_type=AWSResourceType.CONFIG_RULE, resource_id="config",
                    description=f"AWS Config is not enabled in {region}",
                    recommendation="Enable AWS Config for configuration compliance",
                    severity=SeverityLevel.MEDIUM,
                    evidence={"enabled": False},
                ))
        except Exception as e:
            logger.error(f"Config check failed: {e}")
        return findings

