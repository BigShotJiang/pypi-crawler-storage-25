"""
VPC Check Service

Service for executing VPC-related security checks.
"""

import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel

logger = logging.getLogger(__name__)


class VPCCheckService:
    """Service for executing VPC security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize VPC check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute VPC check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_vpc_flow_logs": self.check_vpc_flow_logs,
            "check_default_vpc_sg": self.check_default_vpc_sg,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_vpc_flow_logs(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VPC flow logs."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            vpcs = ec2.describe_vpcs()["Vpcs"]
            flow_logs = ec2.describe_flow_logs()["FlowLogs"]
            vpc_ids_with_logs = {fl["ResourceId"] for fl in flow_logs}
            for vpc in vpcs:
                if vpc["VpcId"] not in vpc_ids_with_logs:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.VPC, resource_id=vpc["VpcId"],
                        description=f"VPC '{vpc['VpcId']}' does not have flow logs enabled",
                        recommendation="Enable VPC flow logs for network monitoring",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"flow_logs_enabled": False},
                    ))
        except Exception as e:
            logger.error(f"VPC flow logs check failed: {e}")
        return findings
    
    async def check_default_vpc_sg(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check default VPC security groups."""
        findings = []
        return findings

