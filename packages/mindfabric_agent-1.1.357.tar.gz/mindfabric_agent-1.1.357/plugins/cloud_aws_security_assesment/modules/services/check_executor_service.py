"""
Check Executor Service

Service for executing security checks by delegating to category-specific services.
"""

import time
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    # Allow plugin to import in minimal environments without AWS deps.
    ClientError = Exception
from ...proto import CheckResult, ScanOptions
from .iam_check_service import IAMCheckService
from .ec2_check_service import EC2CheckService
from .s3_check_service import S3CheckService
from .rds_check_service import RDSCheckService
from .vpc_check_service import VPCCheckService
from .logging_check_service import LoggingCheckService
from .eks_check_service import EKSCheckService
from .lambda_check_service import LambdaCheckService


class CheckExecutorService:
    """Service for executing security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize check executor service."""
        self.plugin = plugin_instance
        # Initialize category-specific check services
        self.iam_service = IAMCheckService(plugin_instance)
        self.ec2_service = EC2CheckService(plugin_instance)
        self.s3_service = S3CheckService(plugin_instance)
        self.rds_service = RDSCheckService(plugin_instance)
        self.vpc_service = VPCCheckService(plugin_instance)
        self.logging_service = LoggingCheckService(plugin_instance)
        self.eks_service = EKSCheckService(plugin_instance)
        self.lambda_service = LambdaCheckService(plugin_instance)
    
    async def execute_check(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> CheckResult:
        """Execute a single security check."""
        start_time = time.time()
        findings = []
        resources_checked = 0
        error = None
        
        try:
            check_fn = check.get("check_fn", "")
            
            # Route to appropriate category service
            if check_fn.startswith("check_root_") or \
               check_fn.startswith("check_user_") or \
               check_fn.startswith("check_access_key_") or \
               check_fn.startswith("check_unused_") or \
               check_fn.startswith("check_password_") or \
               check_fn.startswith("check_admin_") or \
               check_fn.startswith("check_role_") or \
               check_fn.startswith("check_cross_account"):
                findings = await self.iam_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_imdsv1") or \
                 check_fn.startswith("check_ec2_") or \
                 check_fn.startswith("check_unencrypted_volume") or \
                 check_fn.startswith("check_user_data_") or \
                 check_fn.startswith("check_public_ami") or \
                 check_fn.startswith("check_public_snapshot"):
                findings = await self.ec2_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_sg_") or \
                 check_fn.startswith("check_default_vpc"):
                findings = await self.vpc_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_public_bucket") or \
                 check_fn.startswith("check_block_public") or \
                 check_fn.startswith("check_s3_"):
                findings = await self.s3_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_public_rds") or \
                 check_fn.startswith("check_rds_"):
                findings = await self.rds_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_vpc_flow") or \
                 check_fn.startswith("check_cloudtrail_") or \
                 check_fn.startswith("check_guardduty_") or \
                 check_fn.startswith("check_config_"):
                findings = await self.logging_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_eks_"):
                findings = await self.eks_service.execute_check_method(check, account_id, region, options)
                
            elif check_fn.startswith("check_lambda_") or \
                 check_fn.startswith("check_eventbridge_") or \
                 check_fn.startswith("check_ssm_"):
                findings = await self.lambda_service.execute_check_method(check, account_id, region, options)
            else:
                # Fallback to plugin's method if not in any service
                method_name = f"_{check_fn}"
                if hasattr(self.plugin, method_name):
                    method = getattr(self.plugin, method_name)
                    findings = await method(account_id, region, check, options)
                else:
                    error = f"Check method {check_fn} not found"
            
            self.plugin.resources_scanned += len(findings) if findings else 0
            resources_checked = len(findings) if findings else 0
            
        except ClientError as e:
            error = f"AWS API error: {e.response['Error']['Code']}"
            self.plugin.errors.append(f"Check '{check['name']}' failed: {error}")
        except Exception as e:
            error = str(e)
            self.plugin.errors.append(f"Check '{check['name']}' failed: {error}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CheckResult(
            check_id=check["id"],
            check_name=check["name"],
            category=check["category"],
            sub_category=check["sub_category"],
            passed=len(findings) == 0,
            findings_count=len(findings),
            findings=findings,
            resources_checked=resources_checked,
            resources_with_issues=len(findings),
            regions_checked=[region] if region != "global" else None,
            duration_ms=duration_ms,
            error=error,
        )

