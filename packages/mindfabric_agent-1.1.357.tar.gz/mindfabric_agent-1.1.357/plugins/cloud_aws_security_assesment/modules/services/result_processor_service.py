"""
Result Processor Service

Service for generating final output and recommendations.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from datetime import datetime
from typing import Dict, List
from ...proto import (
    ScanOptions,
    AWSSecurityOutput,
    ScanMetadata,
    SeveritySummary,
    CategorySummary,
    AccountSummary,
    RegionSummary,
    SecurityCategory,
    SeverityLevel,
)


class ResultProcessorService:
    """Service for processing results and generating output."""
    
    def __init__(self, plugin_instance):
        """Initialize result processor service."""
        self.plugin = plugin_instance
    
    def create_output(self, options: ScanOptions) -> AWSSecurityOutput:
        """Create the final output object."""
        scan_completed = datetime.utcnow()
        duration = (scan_completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0
        
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            scan_type="deep" if options.deep_scan else ("quick" if options.quick_scan else "full"),
            started_at=self.plugin.scan_start or scan_completed,
            completed_at=scan_completed,
            duration_seconds=duration,
            caller_identity=self.plugin._caller_identity.get("UserId") if self.plugin._caller_identity else None,
            caller_arn=self.plugin._caller_identity.get("Arn") if self.plugin._caller_identity else None,
            accounts_scanned=len(self.plugin.accounts_scanned),
            regions_scanned=len(self.plugin.regions_scanned),
            resources_scanned=self.plugin.resources_scanned,
            total_checks=len(self.plugin.check_results),
            passed_checks=len([c for c in self.plugin.check_results if c.passed]),
            failed_checks=len([c for c in self.plugin.check_results if not c.passed]),
            error_checks=len([c for c in self.plugin.check_results if c.error]),
        )
        
        severity_summary = SeveritySummary()
        for finding in self.plugin.findings:
            if finding.severity == SeverityLevel.CRITICAL:
                severity_summary.critical += 1
            elif finding.severity == SeverityLevel.HIGH:
                severity_summary.high += 1
            elif finding.severity == SeverityLevel.MEDIUM:
                severity_summary.medium += 1
            elif finding.severity == SeverityLevel.LOW:
                severity_summary.low += 1
            else:
                severity_summary.info += 1
        severity_summary.total = len(self.plugin.findings)
        
        # Category summaries
        category_counts: Dict[SecurityCategory, Dict[str, int]] = {}
        for finding in self.plugin.findings:
            if finding.category not in category_counts:
                category_counts[finding.category] = {"total": 0, "critical": 0, "high": 0}
            category_counts[finding.category]["total"] += 1
            if finding.severity == SeverityLevel.CRITICAL:
                category_counts[finding.category]["critical"] += 1
            elif finding.severity == SeverityLevel.HIGH:
                category_counts[finding.category]["high"] += 1
        
        category_summaries = [
            CategorySummary(
                category=cat,
                category_name=cat.value.replace("_", " ").title(),
                total_count=counts["total"],
                critical_count=counts["critical"],
                high_count=counts["high"],
            )
            for cat, counts in category_counts.items()
        ]
        
        # Account summaries
        account_summaries = []
        for account_id in self.plugin.accounts_scanned:
            account_findings = [f for f in self.plugin.findings if f.resource.account_id == account_id]
            
            acc_severity = SeveritySummary()
            for f in account_findings:
                if f.severity == SeverityLevel.CRITICAL:
                    acc_severity.critical += 1
                elif f.severity == SeverityLevel.HIGH:
                    acc_severity.high += 1
                elif f.severity == SeverityLevel.MEDIUM:
                    acc_severity.medium += 1
                elif f.severity == SeverityLevel.LOW:
                    acc_severity.low += 1
                else:
                    acc_severity.info += 1
            acc_severity.total = len(account_findings)
            
            risk_score = acc_severity.critical * 10 + acc_severity.high * 5 + acc_severity.medium * 2
            
            account_summaries.append(AccountSummary(
                account_id=account_id,
                total_findings=len(account_findings),
                severity_summary=acc_severity,
                risk_score=min(100.0, risk_score),
            ))
        
        # Region summaries
        region_summaries = []
        for region in self.plugin.regions_scanned:
            region_findings = [f for f in self.plugin.findings if f.resource.region == region]
            critical = len([f for f in region_findings if f.severity == SeverityLevel.CRITICAL])
            
            region_summaries.append(RegionSummary(
                region=region,
                total_findings=len(region_findings),
                critical_findings=critical,
            ))
        
        critical_findings = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]
        
        recommendations = self.generate_recommendations()
        
        return AWSSecurityOutput(
            metadata=metadata,
            scan_options=options,
            check_results=self.plugin.check_results,
            findings=self.plugin.findings,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            account_summaries=account_summaries,
            region_summaries=region_summaries,
            privilege_escalation_paths=self.plugin.privilege_escalation_paths,
            exfiltration_paths=self.plugin.exfiltration_paths,
            persistence_mechanisms=self.plugin.persistence_mechanisms,
            critical_findings=critical_findings if critical_findings else None,
            risky_users=self.plugin.risky_users if self.plugin.risky_users else None,
            risky_roles=self.plugin.risky_roles if self.plugin.risky_roles else None,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            prioritized_recommendations=recommendations if recommendations else None,
        )
    
    def generate_recommendations(self) -> List[str]:
        """Generate prioritized recommendations."""
        recommendations = []
        
        severity_summary = SeveritySummary()
        for finding in self.plugin.findings:
            if finding.severity == SeverityLevel.CRITICAL:
                severity_summary.critical += 1
            elif finding.severity == SeverityLevel.HIGH:
                severity_summary.high += 1
        
        if severity_summary.critical > 0:
            recommendations.append(f"URGENT: Address {severity_summary.critical} critical findings immediately")
        
        categories_found = set(f.category for f in self.plugin.findings)
        
        if SecurityCategory.DATA_EXPOSURE in categories_found:
            recommendations.append(
                "Close public S3/RDS/EFS exposure: block ACLs/policies with Principal * or 0.0.0.0/0, enable default encryption and access logging, then re-verify with this assessment."
            )
        
        if SecurityCategory.IAM_MISCONFIGURATION in categories_found:
            recommendations.append("Implement least privilege - review IAM policies, enable MFA, rotate access keys")
        
        if SecurityCategory.NETWORK_EXPOSURE in categories_found:
            recommendations.append("Restrict security groups - remove 0.0.0.0/0 rules, use VPC endpoints")
        
        if SecurityCategory.LOGGING_GAP in categories_found:
            recommendations.append("Enable comprehensive logging - CloudTrail, VPC Flow Logs, GuardDuty")
        
        if self.plugin.privilege_escalation_paths:
            recommendations.append(f"Review {len(self.plugin.privilege_escalation_paths)} privilege escalation paths")
        
        recommendations.extend([
            "Enable AWS Security Hub for centralized security management",
            "Implement AWS Organizations SCPs for guardrails",
            "Set up AWS Config rules for continuous compliance monitoring",
        ])
        
        return recommendations

