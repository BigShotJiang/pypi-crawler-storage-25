"""
Serverless Extended Security Service

Extended Lambda and serverless security checks:
- Lambda layers security
- Lambda@Edge security
- Lambda VPC configuration
- Lambda dead letter queues
- Lambda reserved concurrency
- Step Functions security
- API Gateway integration security

MITRE ATT&CK:
- T1059: Command and Scripting Interpreter
- T1190: Exploit Public-Facing Application
- T1552: Unsecured Credentials
- T1078: Valid Accounts
"""

import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception

logger = logging.getLogger(__name__)


class ServerlessSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ServerlessFindingType(str, Enum):
    """Types of serverless security findings."""
    LAYER_SECURITY = "layer_security"
    EDGE_SECURITY = "edge_security"
    VPC_SECURITY = "vpc_security"
    DLQ_SECURITY = "dlq_security"
    CONCURRENCY = "concurrency"
    PERMISSIONS = "permissions"
    CONFIGURATION = "configuration"


# =============================================================================
# Lambda Layers Security Checks
# =============================================================================

LAYER_SECURITY_CHECKS = {
    "public_layer": {
        "name": "Public Lambda Layer",
        "description": "Lambda layer accessible by all AWS accounts",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1190",
    },
    "outdated_layer": {
        "name": "Outdated Lambda Layer",
        "description": "Lambda function using outdated layer version",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1190",
    },
    "untrusted_layer": {
        "name": "Untrusted Lambda Layer",
        "description": "Lambda layer from untrusted source",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1195.002",
    },
    "layer_secrets": {
        "name": "Secrets in Layer",
        "description": "Lambda layer may contain hardcoded secrets",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1552.001",
    },
    "vulnerable_runtime_layer": {
        "name": "Vulnerable Runtime Layer",
        "description": "Lambda layer with known vulnerable dependencies",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1190",
        "vulnerable_packages": [
            "log4j",
            "spring-core",
            "lodash",
            "minimist",
        ],
    },
}


# =============================================================================
# Lambda@Edge Security Checks
# =============================================================================

EDGE_SECURITY_CHECKS = {
    "edge_permissions": {
        "name": "Lambda@Edge Permissions",
        "description": "Lambda@Edge with excessive permissions",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1078",
        "dangerous_permissions": [
            "s3:*",
            "dynamodb:*",
            "iam:*",
            "lambda:*",
        ],
    },
    "edge_logging": {
        "name": "Lambda@Edge Logging",
        "description": "Lambda@Edge without proper logging",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "edge_secrets": {
        "name": "Lambda@Edge Secrets",
        "description": "Lambda@Edge with hardcoded secrets",
        "severity": ServerlessSeverity.CRITICAL,
        "mitre": "T1552.001",
    },
    "edge_timeout": {
        "name": "Lambda@Edge Timeout",
        "description": "Lambda@Edge with excessive timeout (viewer-request/response max 5s)",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
        "max_timeouts": {
            "viewer-request": 5,
            "viewer-response": 5,
            "origin-request": 30,
            "origin-response": 30,
        },
    },
    "edge_memory": {
        "name": "Lambda@Edge Memory",
        "description": "Lambda@Edge with excessive memory allocation",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
        "max_memory": 128,  # MB for viewer triggers
    },
}


# =============================================================================
# Lambda VPC Security Checks
# =============================================================================

VPC_SECURITY_CHECKS = {
    "no_vpc": {
        "name": "Lambda Not in VPC",
        "description": "Lambda function not deployed in VPC",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1190",
    },
    "public_subnet": {
        "name": "Lambda in Public Subnet",
        "description": "Lambda function in public subnet with internet access",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1190",
    },
    "no_security_group": {
        "name": "Permissive Security Group",
        "description": "Lambda with permissive security group",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1190",
    },
    "nat_gateway_exposure": {
        "name": "NAT Gateway Exposure",
        "description": "Lambda VPC has NAT gateway allowing egress",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1048",
    },
    "vpc_endpoint_missing": {
        "name": "Missing VPC Endpoints",
        "description": "Lambda VPC missing required VPC endpoints",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1048",
        "required_endpoints": [
            "com.amazonaws.*.s3",
            "com.amazonaws.*.dynamodb",
            "com.amazonaws.*.secretsmanager",
        ],
    },
}


# =============================================================================
# Lambda Configuration Security Checks
# =============================================================================

CONFIGURATION_CHECKS = {
    "no_dlq": {
        "name": "Missing Dead Letter Queue",
        "description": "Lambda function without DLQ for failed invocations",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
    },
    "no_reserved_concurrency": {
        "name": "No Reserved Concurrency",
        "description": "Lambda without reserved concurrency limit",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
    },
    "high_timeout": {
        "name": "High Timeout",
        "description": "Lambda with very high timeout (potential DoS)",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
        "max_timeout": 300,  # 5 minutes
    },
    "high_memory": {
        "name": "High Memory",
        "description": "Lambda with very high memory allocation",
        "severity": ServerlessSeverity.LOW,
        "mitre": "T1499",
        "max_memory": 3008,  # MB
    },
    "no_xray_tracing": {
        "name": "No X-Ray Tracing",
        "description": "Lambda without X-Ray tracing enabled",
        "severity": ServerlessSeverity.INFO,
        "mitre": "T1562.008",
    },
    "deprecated_runtime": {
        "name": "Deprecated Runtime",
        "description": "Lambda using deprecated runtime",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1190",
        "deprecated_runtimes": [
            "python2.7",
            "python3.6",
            "python3.7",
            "nodejs10.x",
            "nodejs12.x",
            "nodejs14.x",
            "ruby2.5",
            "ruby2.7",
            "dotnetcore2.1",
            "dotnetcore3.1",
            "go1.x",
        ],
    },
    "code_signing_disabled": {
        "name": "Code Signing Disabled",
        "description": "Lambda without code signing verification",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1195.002",
    },
}


# =============================================================================
# Step Functions Security Checks
# =============================================================================

STEP_FUNCTIONS_CHECKS = {
    "excessive_permissions": {
        "name": "Step Functions Excessive Permissions",
        "description": "State machine with excessive IAM permissions",
        "severity": ServerlessSeverity.HIGH,
        "mitre": "T1078",
    },
    "no_logging": {
        "name": "Step Functions No Logging",
        "description": "State machine without CloudWatch logging",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1562.008",
    },
    "no_xray": {
        "name": "Step Functions No X-Ray",
        "description": "State machine without X-Ray tracing",
        "severity": ServerlessSeverity.INFO,
        "mitre": "T1562.008",
    },
    "task_token_exposure": {
        "name": "Task Token Exposure",
        "description": "Step Functions task tokens potentially exposed",
        "severity": ServerlessSeverity.MEDIUM,
        "mitre": "T1552",
    },
}


@dataclass
class ServerlessSecurityFinding:
    """A serverless security finding."""
    finding_type: ServerlessFindingType
    severity: ServerlessSeverity
    resource_id: str
    name: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class ServerlessSecurityReport:
    """Serverless security report."""
    findings: List[ServerlessSecurityFinding] = field(default_factory=list)
    functions_scanned: int = 0
    layers_scanned: int = 0
    state_machines_scanned: int = 0
    risk_score: float = 0.0


class ServerlessExtendedService:
    """Extended serverless security service."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[ServerlessSecurityFinding] = []
    
    async def check_lambda_layers(
        self,
        lambda_client,
        account_id: str,
    ) -> List[ServerlessSecurityFinding]:
        """
        Check Lambda layers security.
        
        Args:
            lambda_client: boto3 Lambda client
            account_id: AWS account ID
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # List layers
            layers_response = lambda_client.list_layers()
            
            for layer in layers_response.get("Layers", []):
                layer_name = layer.get("LayerName", "")
                layer_arn = layer.get("LayerArn", "")
                
                # Check layer policy
                try:
                    versions = lambda_client.list_layer_versions(LayerName=layer_name)
                    
                    for version in versions.get("LayerVersions", []):
                        version_num = version.get("Version", 0)
                        
                        try:
                            policy = lambda_client.get_layer_version_policy(
                                LayerName=layer_name,
                                VersionNumber=version_num
                            )
                            
                            policy_doc = json.loads(policy.get("Policy", "{}"))
                            
                            for stmt in policy_doc.get("Statement", []):
                                principal = stmt.get("Principal", {})
                                
                                if principal == "*" or principal.get("AWS") == "*":
                                    findings.append(ServerlessSecurityFinding(
                                        finding_type=ServerlessFindingType.LAYER_SECURITY,
                                        severity=ServerlessSeverity.HIGH,
                                        resource_id=f"{layer_name}:{version_num}",
                                        name="Public Lambda Layer",
                                        description=f"Lambda layer {layer_name} version {version_num} is publicly accessible",
                                        evidence={
                                            "layer_arn": layer_arn,
                                            "version": version_num,
                                            "principal": principal,
                                        },
                                        remediation="Restrict layer access to specific accounts",
                                        mitre_technique="T1190",
                                    ))
                                    
                        except ClientError:
                            # No policy - private layer
                            pass
                            
                except ClientError as e:
                    logger.debug(f"Error checking layer {layer_name}: {e}")
                    
        except ClientError as e:
            logger.error(f"Error listing Lambda layers: {e}")
        
        return findings
    
    async def check_lambda_edge_functions(
        self,
        lambda_client,
        cloudfront_client,
    ) -> List[ServerlessSecurityFinding]:
        """
        Check Lambda@Edge functions security.
        
        Args:
            lambda_client: boto3 Lambda client
            cloudfront_client: boto3 CloudFront client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            # Get CloudFront distributions
            distributions = cloudfront_client.list_distributions()
            
            for dist in distributions.get("DistributionList", {}).get("Items", []):
                dist_id = dist.get("Id", "")
                
                # Check for Lambda@Edge associations
                behaviors = dist.get("DefaultCacheBehavior", {})
                lambda_associations = behaviors.get("LambdaFunctionAssociations", {}).get("Items", [])
                
                for assoc in lambda_associations:
                    lambda_arn = assoc.get("LambdaFunctionARN", "")
                    event_type = assoc.get("EventType", "")
                    
                    # Extract function name from ARN
                    func_name = lambda_arn.split(":")[-2] if ":" in lambda_arn else lambda_arn
                    
                    try:
                        # Get function configuration
                        func_config = lambda_client.get_function_configuration(
                            FunctionName=lambda_arn
                        )
                        
                        timeout = func_config.get("Timeout", 0)
                        memory = func_config.get("MemorySize", 0)
                        
                        # Check timeout limits
                        max_timeout = EDGE_SECURITY_CHECKS["edge_timeout"]["max_timeouts"].get(event_type, 30)
                        
                        if timeout > max_timeout:
                            findings.append(ServerlessSecurityFinding(
                                finding_type=ServerlessFindingType.EDGE_SECURITY,
                                severity=ServerlessSeverity.MEDIUM,
                                resource_id=func_name,
                                name="Lambda@Edge Excessive Timeout",
                                description=f"Lambda@Edge function {func_name} has timeout {timeout}s exceeding limit for {event_type}",
                                evidence={
                                    "function_arn": lambda_arn,
                                    "event_type": event_type,
                                    "timeout": timeout,
                                    "max_allowed": max_timeout,
                                },
                                remediation=f"Reduce timeout to {max_timeout}s for {event_type} triggers",
                                mitre_technique="T1499",
                            ))
                        
                        # Check memory for viewer triggers
                        if event_type in ["viewer-request", "viewer-response"]:
                            max_memory = EDGE_SECURITY_CHECKS["edge_memory"]["max_memory"]
                            
                            if memory > max_memory:
                                findings.append(ServerlessSecurityFinding(
                                    finding_type=ServerlessFindingType.EDGE_SECURITY,
                                    severity=ServerlessSeverity.LOW,
                                    resource_id=func_name,
                                    name="Lambda@Edge Excessive Memory",
                                    description=f"Lambda@Edge function {func_name} has {memory}MB exceeding limit for viewer triggers",
                                    evidence={
                                        "function_arn": lambda_arn,
                                        "event_type": event_type,
                                        "memory": memory,
                                        "max_allowed": max_memory,
                                    },
                                    remediation=f"Reduce memory to {max_memory}MB for viewer triggers",
                                    mitre_technique="T1499",
                                ))
                                
                    except ClientError as e:
                        logger.debug(f"Error checking Lambda@Edge function: {e}")
                        
        except ClientError as e:
            logger.error(f"Error checking Lambda@Edge: {e}")
        
        return findings
    
    async def check_lambda_vpc_configuration(
        self,
        lambda_client,
        ec2_client,
    ) -> List[ServerlessSecurityFinding]:
        """
        Check Lambda VPC configuration security.
        
        Args:
            lambda_client: boto3 Lambda client
            ec2_client: boto3 EC2 client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            functions = lambda_client.list_functions()
            
            for func in functions.get("Functions", []):
                func_name = func.get("FunctionName", "")
                vpc_config = func.get("VpcConfig", {})
                
                if not vpc_config or not vpc_config.get("VpcId"):
                    # Function not in VPC
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.VPC_SECURITY,
                        severity=ServerlessSeverity.MEDIUM,
                        resource_id=func_name,
                        name="Lambda Not in VPC",
                        description=f"Lambda function {func_name} is not deployed in a VPC",
                        evidence={
                            "vpc_config": None,
                        },
                        remediation="Deploy Lambda in VPC for network isolation",
                        mitre_technique="T1190",
                    ))
                    continue
                
                vpc_id = vpc_config.get("VpcId", "")
                subnet_ids = vpc_config.get("SubnetIds", [])
                security_group_ids = vpc_config.get("SecurityGroupIds", [])
                
                # Check if subnets are public
                if subnet_ids:
                    try:
                        subnets = ec2_client.describe_subnets(SubnetIds=subnet_ids)
                        
                        for subnet in subnets.get("Subnets", []):
                            if subnet.get("MapPublicIpOnLaunch"):
                                findings.append(ServerlessSecurityFinding(
                                    finding_type=ServerlessFindingType.VPC_SECURITY,
                                    severity=ServerlessSeverity.MEDIUM,
                                    resource_id=func_name,
                                    name="Lambda in Public Subnet",
                                    description=f"Lambda {func_name} is in public subnet {subnet.get('SubnetId')}",
                                    evidence={
                                        "subnet_id": subnet.get("SubnetId"),
                                        "public": True,
                                    },
                                    remediation="Move Lambda to private subnet",
                                    mitre_technique="T1190",
                                ))
                                
                    except ClientError as e:
                        logger.debug(f"Error checking subnets: {e}")
                
                # Check security groups
                if security_group_ids:
                    try:
                        sgs = ec2_client.describe_security_groups(GroupIds=security_group_ids)
                        
                        for sg in sgs.get("SecurityGroups", []):
                            for rule in sg.get("IpPermissions", []):
                                for ip_range in rule.get("IpRanges", []):
                                    if ip_range.get("CidrIp") == "0.0.0.0/0":
                                        findings.append(ServerlessSecurityFinding(
                                            finding_type=ServerlessFindingType.VPC_SECURITY,
                                            severity=ServerlessSeverity.MEDIUM,
                                            resource_id=func_name,
                                            name="Lambda Permissive Security Group",
                                            description=f"Lambda {func_name} has SG allowing inbound from 0.0.0.0/0",
                                            evidence={
                                                "sg_id": sg.get("GroupId"),
                                                "rule": rule,
                                            },
                                            remediation="Restrict security group inbound rules",
                                            mitre_technique="T1190",
                                        ))
                                        
                    except ClientError as e:
                        logger.debug(f"Error checking security groups: {e}")
                        
        except ClientError as e:
            logger.error(f"Error checking Lambda VPC: {e}")
        
        return findings
    
    async def check_lambda_configuration(
        self,
        lambda_client,
    ) -> List[ServerlessSecurityFinding]:
        """
        Check Lambda configuration security.
        
        Args:
            lambda_client: boto3 Lambda client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            functions = lambda_client.list_functions()
            
            for func in functions.get("Functions", []):
                func_name = func.get("FunctionName", "")
                func_arn = func.get("FunctionArn", "")
                
                # Check for DLQ
                dlq = func.get("DeadLetterConfig", {}).get("TargetArn")
                
                if not dlq:
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.DLQ_SECURITY,
                        severity=ServerlessSeverity.LOW,
                        resource_id=func_name,
                        name="Missing Dead Letter Queue",
                        description=f"Lambda {func_name} has no DLQ configured",
                        evidence={"dlq_configured": False},
                        remediation="Configure DLQ for failed invocation handling",
                        mitre_technique="T1499",
                    ))
                
                # Check reserved concurrency
                try:
                    concurrency = lambda_client.get_function_concurrency(
                        FunctionName=func_name
                    )
                    
                    if not concurrency.get("ReservedConcurrentExecutions"):
                        findings.append(ServerlessSecurityFinding(
                            finding_type=ServerlessFindingType.CONCURRENCY,
                            severity=ServerlessSeverity.LOW,
                            resource_id=func_name,
                            name="No Reserved Concurrency",
                            description=f"Lambda {func_name} has no reserved concurrency limit",
                            evidence={"reserved_concurrency": None},
                            remediation="Set reserved concurrency to prevent resource exhaustion",
                            mitre_technique="T1499",
                        ))
                        
                except ClientError:
                    pass
                
                # Check timeout
                timeout = func.get("Timeout", 0)
                max_timeout = CONFIGURATION_CHECKS["high_timeout"]["max_timeout"]
                
                if timeout > max_timeout:
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.LOW,
                        resource_id=func_name,
                        name="High Timeout",
                        description=f"Lambda {func_name} has high timeout of {timeout}s",
                        evidence={"timeout": timeout},
                        remediation=f"Reduce timeout if not needed (max recommended: {max_timeout}s)",
                        mitre_technique="T1499",
                    ))
                
                # Check runtime
                runtime = func.get("Runtime", "")
                deprecated = CONFIGURATION_CHECKS["deprecated_runtime"]["deprecated_runtimes"]
                
                if runtime in deprecated:
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.MEDIUM,
                        resource_id=func_name,
                        name="Deprecated Runtime",
                        description=f"Lambda {func_name} uses deprecated runtime {runtime}",
                        evidence={"runtime": runtime},
                        remediation="Upgrade to supported runtime version",
                        mitre_technique="T1190",
                    ))
                
                # Check code signing
                code_signing = func.get("CodeSigningConfigArn")
                
                if not code_signing:
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.MEDIUM,
                        resource_id=func_name,
                        name="Code Signing Disabled",
                        description=f"Lambda {func_name} has no code signing configured",
                        evidence={"code_signing": None},
                        remediation="Enable code signing for deployment verification",
                        mitre_technique="T1195.002",
                    ))
                
                # Check X-Ray tracing
                tracing = func.get("TracingConfig", {}).get("Mode", "")
                
                if tracing != "Active":
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.INFO,
                        resource_id=func_name,
                        name="X-Ray Tracing Disabled",
                        description=f"Lambda {func_name} has X-Ray tracing disabled",
                        evidence={"tracing_mode": tracing},
                        remediation="Enable X-Ray tracing for observability",
                        mitre_technique="T1562.008",
                    ))
                    
        except ClientError as e:
            logger.error(f"Error checking Lambda configuration: {e}")
        
        return findings
    
    async def check_step_functions(
        self,
        sfn_client,
        iam_client,
    ) -> List[ServerlessSecurityFinding]:
        """
        Check Step Functions security.
        
        Args:
            sfn_client: boto3 Step Functions client
            iam_client: boto3 IAM client
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            state_machines = sfn_client.list_state_machines()
            
            for sm in state_machines.get("stateMachines", []):
                sm_arn = sm.get("stateMachineArn", "")
                sm_name = sm.get("name", "")
                
                # Get state machine details
                sm_detail = sfn_client.describe_state_machine(stateMachineArn=sm_arn)
                
                role_arn = sm_detail.get("roleArn", "")
                logging_config = sm_detail.get("loggingConfiguration", {})
                tracing_config = sm_detail.get("tracingConfiguration", {})
                
                # Check logging
                if logging_config.get("level") == "OFF" or not logging_config.get("destinations"):
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.MEDIUM,
                        resource_id=sm_name,
                        name="Step Functions No Logging",
                        description=f"State machine {sm_name} has logging disabled",
                        evidence={"logging_config": logging_config},
                        remediation="Enable CloudWatch logging for state machine",
                        mitre_technique="T1562.008",
                    ))
                
                # Check tracing
                if not tracing_config.get("enabled"):
                    findings.append(ServerlessSecurityFinding(
                        finding_type=ServerlessFindingType.CONFIGURATION,
                        severity=ServerlessSeverity.INFO,
                        resource_id=sm_name,
                        name="Step Functions No X-Ray",
                        description=f"State machine {sm_name} has X-Ray tracing disabled",
                        evidence={"tracing_enabled": False},
                        remediation="Enable X-Ray tracing for visibility",
                        mitre_technique="T1562.008",
                    ))
                
                # Check role permissions (simplified check)
                if role_arn:
                    role_name = role_arn.split("/")[-1]
                    
                    try:
                        attached_policies = iam_client.list_attached_role_policies(RoleName=role_name)
                        
                        for policy in attached_policies.get("AttachedPolicies", []):
                            policy_arn = policy.get("PolicyArn", "")
                            
                            # Check for overly permissive managed policies
                            if any(p in policy_arn for p in ["AdministratorAccess", "PowerUserAccess"]):
                                findings.append(ServerlessSecurityFinding(
                                    finding_type=ServerlessFindingType.PERMISSIONS,
                                    severity=ServerlessSeverity.HIGH,
                                    resource_id=sm_name,
                                    name="Step Functions Excessive Permissions",
                                    description=f"State machine {sm_name} has overly permissive role",
                                    evidence={
                                        "role": role_name,
                                        "policy": policy_arn,
                                    },
                                    remediation="Use least privilege permissions",
                                    mitre_technique="T1078",
                                ))
                                
                    except ClientError as e:
                        logger.debug(f"Error checking role: {e}")
                        
        except ClientError as e:
            logger.error(f"Error checking Step Functions: {e}")
        
        return findings
    
    async def run_full_scan(
        self,
        lambda_client,
        cloudfront_client=None,
        ec2_client=None,
        sfn_client=None,
        iam_client=None,
        account_id: str = "",
    ) -> ServerlessSecurityReport:
        """
        Run full serverless security scan.
        
        Args:
            lambda_client: boto3 Lambda client
            cloudfront_client: boto3 CloudFront client (optional)
            ec2_client: boto3 EC2 client (optional)
            sfn_client: boto3 Step Functions client (optional)
            iam_client: boto3 IAM client (optional)
            account_id: AWS account ID
            
        Returns:
            ServerlessSecurityReport
        """
        all_findings = []
        functions_scanned = 0
        layers_scanned = 0
        state_machines_scanned = 0
        
        # Check Lambda layers
        layer_findings = await self.check_lambda_layers(lambda_client, account_id)
        all_findings.extend(layer_findings)
        layers_scanned = len(layer_findings)
        
        # Check Lambda@Edge
        if cloudfront_client:
            edge_findings = await self.check_lambda_edge_functions(lambda_client, cloudfront_client)
            all_findings.extend(edge_findings)
        
        # Check Lambda VPC
        if ec2_client:
            vpc_findings = await self.check_lambda_vpc_configuration(lambda_client, ec2_client)
            all_findings.extend(vpc_findings)
        
        # Check Lambda configuration
        config_findings = await self.check_lambda_configuration(lambda_client)
        all_findings.extend(config_findings)
        functions_scanned = len(set(f.resource_id for f in config_findings))
        
        # Check Step Functions
        if sfn_client and iam_client:
            sfn_findings = await self.check_step_functions(sfn_client, iam_client)
            all_findings.extend(sfn_findings)
            state_machines_scanned = len(set(f.resource_id for f in sfn_findings))
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return ServerlessSecurityReport(
            findings=all_findings,
            functions_scanned=functions_scanned,
            layers_scanned=layers_scanned,
            state_machines_scanned=state_machines_scanned,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[ServerlessSecurityFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            ServerlessSeverity.CRITICAL: 10,
            ServerlessSeverity.HIGH: 7,
            ServerlessSeverity.MEDIUM: 4,
            ServerlessSeverity.LOW: 1,
            ServerlessSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[ServerlessSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_check_databases(self) -> Dict[str, Any]:
        """Get all check databases."""
        return {
            "layer_checks": LAYER_SECURITY_CHECKS,
            "edge_checks": EDGE_SECURITY_CHECKS,
            "vpc_checks": VPC_SECURITY_CHECKS,
            "configuration_checks": CONFIGURATION_CHECKS,
            "step_functions_checks": STEP_FUNCTIONS_CHECKS,
        }

