"""
Attack Path Analyzer Service

Service for analyzing privilege escalation, exfiltration, and persistence paths.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict
from ...proto import ScanOptions, PrivilegeEscalationPath
from ..databases import DANGEROUS_PERMISSIONS

logger = logging.getLogger(__name__)


class AttackPathAnalyzerService:
    """Service for analyzing attack paths."""
    
    def __init__(self, plugin_instance):
        """Initialize attack path analyzer service."""
        self.plugin = plugin_instance
    
    async def analyze_privilege_escalation_paths(self, options: ScanOptions) -> None:
        """Analyze potential privilege escalation paths."""
        try:
            iam = self.plugin._get_client("iam")
            users = iam.list_users()["Users"]
            
            for user in users:
                user_name = user["UserName"]
                
                # Get user policies
                attached = iam.list_attached_user_policies(UserName=user_name)
                inline = iam.list_user_policies(UserName=user_name)
                
                # Check for dangerous permissions
                for policy in attached.get("AttachedPolicies", []):
                    policy_arn = policy["PolicyArn"]
                    
                    try:
                        version = iam.get_policy(PolicyArn=policy_arn)["Policy"]["DefaultVersionId"]
                        doc = iam.get_policy_version(PolicyArn=policy_arn, VersionId=version)["PolicyVersion"]["Document"]
                        
                        self._check_policy_for_privesc(user["Arn"], doc)
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Privilege escalation analysis failed: {e}")
    
    def _check_policy_for_privesc(self, identity_arn: str, policy_doc: Dict) -> None:
        """Check policy document for privilege escalation permissions."""
        statements = policy_doc.get("Statement", [])
        if isinstance(statements, dict):
            statements = [statements]
        
        for statement in statements:
            if statement.get("Effect") != "Allow":
                continue
            
            actions = statement.get("Action", [])
            if isinstance(actions, str):
                actions = [actions]
            
            resource = statement.get("Resource", "*")
            
            for action in actions:
                for perm, info in DANGEROUS_PERMISSIONS.items():
                    if action == "*" or action == perm or (action.endswith("*") and perm.startswith(action[:-1])):
                        self.plugin.privilege_escalation_paths.append(PrivilegeEscalationPath(
                            source_identity=identity_arn,
                            target_identity="Higher privileged identity",
                            escalation_method=info["description"],
                            required_permissions=[perm],
                            steps=[
                                f"1. Identity has {perm} permission",
                                f"2. Can {info['escalation_method']}",
                                "3. Achieves elevated privileges"
                            ],
                            impact="Privilege escalation to higher permissions",
                            confidence=0.8
                        ))
                        break
    
    async def analyze_exfiltration_paths(self, options: ScanOptions) -> None:
        """Analyze potential data exfiltration paths."""
        pass
    
    async def analyze_persistence(self, options: ScanOptions) -> None:
        """Analyze persistence mechanisms."""
        pass

