"""
Project Scope Service

Service for determining accounts and regions to scan.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import List
from ...proto import ScanScope
from ..databases import DEFAULT_REGIONS


class ProjectScopeService:
    """Service for determining accounts and regions to scan."""
    
    def __init__(self, plugin_instance):
        """Initialize project scope service."""
        self.plugin = plugin_instance
    
    async def get_accounts_to_scan(self, scope: ScanScope) -> List[str]:
        """Determine which accounts to scan."""
        accounts = []
        
        if scope.account_ids:
            accounts = scope.account_ids
        elif scope.organization_id:
            try:
                org = self.plugin._get_client("organizations")
                paginator = org.get_paginator("list_accounts")
                for page in paginator.paginate():
                    for account in page.get("Accounts", []):
                        if account["Status"] == "ACTIVE":
                            accounts.append(account["Id"])
            except Exception as e:
                self.plugin.warnings.append(f"Could not list organization accounts: {e}")
        
        # Apply exclusions
        if scope.exclude_account_ids:
            accounts = [a for a in accounts if a not in scope.exclude_account_ids]
        
        return accounts
    
    def get_regions_to_scan(self, scope: ScanScope) -> List[str]:
        """Determine which regions to scan."""
        regions = scope.regions or DEFAULT_REGIONS
        if scope.exclude_regions:
            regions = [r for r in regions if r not in scope.exclude_regions]
        return regions

