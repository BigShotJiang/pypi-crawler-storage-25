"""
EC2 Check Service

Service for executing EC2-related security checks.
"""

import base64
from typing import Any, Dict, List
import logging

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception
from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel
from ..utils import check_content_for_secrets

logger = logging.getLogger(__name__)


class EC2CheckService:
    """Service for executing EC2 security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize EC2 check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute EC2 check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_imdsv1": self.check_imdsv1,
            "check_ec2_public_ip": self.check_ec2_public_ip,
            "check_ec2_admin_role": self.check_ec2_admin_role,
            "check_unencrypted_volume": self.check_unencrypted_volume,
            "check_user_data_secrets": self.check_user_data_secrets,
            "check_public_ami": self.check_public_ami,
            "check_public_snapshot": self.check_public_snapshot,
            "check_sg_open_ssh": self.check_sg_open_ssh,
            "check_sg_open_rdp": self.check_sg_open_rdp,
            "check_sg_open_all": self.check_sg_open_all,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_imdsv1(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for EC2 instances with IMDSv1 enabled."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        if instance["State"]["Name"] != "running":
                            continue
                        metadata_options = instance.get("MetadataOptions", {})
                        http_tokens = metadata_options.get("HttpTokens", "optional")
                        if http_tokens == "optional":
                            instance_id = instance["InstanceId"]
                            name = next((t["Value"] for t in instance.get("Tags", []) 
                                       if t["Key"] == "Name"), instance_id)
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.EC2_INSTANCE, resource_id=instance_id, name=name,
                                description=f"EC2 instance '{name}' has IMDSv1 enabled (vulnerable to SSRF)",
                                recommendation="Require IMDSv2 by setting HttpTokens to 'required'",
                                severity=SeverityLevel.HIGH,
                                evidence={"http_tokens": http_tokens},
                                remediation_commands=[
                                    f"aws ec2 modify-instance-metadata-options --instance-id {instance_id} --http-tokens required --region {region}"
                                ],
                            ))
        except Exception as e:
            logger.error(f"IMDSv1 check failed in {region}: {e}")
        return findings
    
    async def check_ec2_public_ip(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for EC2 instances with public IPs."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        if instance["State"]["Name"] != "running":
                            continue
                        public_ip = instance.get("PublicIpAddress")
                        if public_ip:
                            instance_id = instance["InstanceId"]
                            name = next((t["Value"] for t in instance.get("Tags", []) 
                                       if t["Key"] == "Name"), instance_id)
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.EC2_INSTANCE, resource_id=instance_id, name=name,
                                description=f"EC2 instance '{name}' has public IP: {public_ip}",
                                recommendation="Use private subnets and NAT Gateway for outbound access",
                                severity=SeverityLevel.MEDIUM,
                                evidence={"public_ip": public_ip},
                            ))
        except Exception as e:
            logger.error(f"EC2 public IP check failed in {region}: {e}")
        return findings
    
    async def check_ec2_admin_role(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for EC2 instances with admin IAM roles."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            iam = self.plugin._get_client("iam")
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        if instance["State"]["Name"] != "running":
                            continue
                        profile = instance.get("IamInstanceProfile", {})
                        profile_arn = profile.get("Arn", "")
                        if not profile_arn:
                            continue
                        profile_name = profile_arn.split("/")[-1]
                        try:
                            ip_info = iam.get_instance_profile(InstanceProfileName=profile_name)
                            roles = ip_info["InstanceProfile"].get("Roles", [])
                            for role in roles:
                                role_name = role["RoleName"]
                                attached = iam.list_attached_role_policies(RoleName=role_name)
                                for policy in attached.get("AttachedPolicies", []):
                                    if "AdministratorAccess" in policy["PolicyName"]:
                                        instance_id = instance["InstanceId"]
                                        name = next((t["Value"] for t in instance.get("Tags", []) 
                                                   if t["Key"] == "Name"), instance_id)
                                        findings.append(self.plugin.finding_factory_service.create_finding(
                                            check=check, account_id=account_id, region=region,
                                            resource_type=AWSResourceType.EC2_INSTANCE, resource_id=instance_id, name=name,
                                            description=f"EC2 instance '{name}' has admin IAM role",
                                            recommendation="Use least privilege role for EC2 instances",
                                            severity=SeverityLevel.CRITICAL,
                                            evidence={"role": role_name, "policy": policy["PolicyName"]},
                                        ))
                        except Exception:
                            pass
        except Exception as e:
            logger.error(f"EC2 admin role check failed in {region}: {e}")
        return findings
    
    async def check_unencrypted_volume(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for unencrypted EBS volumes."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            paginator = ec2.get_paginator("describe_volumes")
            for page in paginator.paginate():
                for volume in page["Volumes"]:
                    if not volume.get("Encrypted", False):
                        volume_id = volume["VolumeId"]
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region=region,
                            resource_type=AWSResourceType.EC2_VOLUME, resource_id=volume_id,
                            description=f"EBS volume '{volume_id}' is not encrypted",
                            recommendation="Enable EBS encryption by default and encrypt existing volumes",
                            severity=SeverityLevel.HIGH,
                            evidence={"encrypted": False, "state": volume["State"]},
                        ))
        except Exception as e:
            logger.error(f"Unencrypted volume check failed in {region}: {e}")
        return findings
    
    async def check_user_data_secrets(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for secrets in EC2 user data."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page["Reservations"]:
                    for instance in reservation["Instances"]:
                        instance_id = instance["InstanceId"]
                        try:
                            user_data_response = ec2.describe_instance_attribute(
                                InstanceId=instance_id,
                                Attribute="userData"
                            )
                            user_data = user_data_response.get("UserData", {}).get("Value", "")
                            if user_data:
                                decoded = base64.b64decode(user_data).decode("utf-8", errors="ignore")
                                secrets_found = check_content_for_secrets(decoded)
                                if secrets_found:
                                    name = next((t["Value"] for t in instance.get("Tags", []) 
                                               if t["Key"] == "Name"), instance_id)
                                    findings.append(self.plugin.finding_factory_service.create_finding(
                                        check=check, account_id=account_id, region=region,
                                        resource_type=AWSResourceType.EC2_INSTANCE, resource_id=instance_id, name=name,
                                        description=f"EC2 instance '{name}' has potential secrets in user data: {', '.join([s[1] for s in secrets_found])}",
                                        recommendation="Use Secrets Manager or SSM Parameter Store instead",
                                        severity=SeverityLevel.CRITICAL,
                                        evidence={"secret_types": [s[1] for s in secrets_found]},
                                    ))
                        except Exception:
                            pass
        except Exception as e:
            logger.error(f"User data secrets check failed in {region}: {e}")
        return findings
    
    async def check_public_ami(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public AMIs."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            images = ec2.describe_images(Owners=["self"])["Images"]
            for image in images:
                if image.get("Public", False):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.EC2_AMI, resource_id=image["ImageId"],
                        name=image.get("Name", image["ImageId"]),
                        description=f"AMI '{image.get('Name', image['ImageId'])}' is publicly accessible",
                        recommendation="Make AMI private unless intentionally sharing",
                        severity=SeverityLevel.HIGH,
                        evidence={"public": True},
                    ))
        except Exception as e:
            logger.error(f"Public AMI check failed in {region}: {e}")
        return findings
    
    async def check_public_snapshot(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public EBS snapshots."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            snapshots = ec2.describe_snapshots(OwnerIds=["self"])["Snapshots"]
            for snapshot in snapshots:
                snapshot_id = snapshot["SnapshotId"]
                try:
                    attrs = ec2.describe_snapshot_attribute(
                        SnapshotId=snapshot_id,
                        Attribute="createVolumePermission"
                    )
                    for perm in attrs.get("CreateVolumePermissions", []):
                        if perm.get("Group") == "all":
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region=region,
                                resource_type=AWSResourceType.EC2_SNAPSHOT, resource_id=snapshot_id,
                                description=f"EBS snapshot '{snapshot_id}' is publicly accessible",
                                recommendation="Remove public access from EBS snapshots",
                                severity=SeverityLevel.CRITICAL,
                                evidence={"public": True},
                                remediation_commands=[
                                    f"aws ec2 modify-snapshot-attribute --snapshot-id {snapshot_id} --attribute createVolumePermission --operation-type remove --group-names all --region {region}"
                                ],
                            ))
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"Public snapshot check failed in {region}: {e}")
        return findings
    
    async def check_sg_open_ssh(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for security groups with SSH open to the world."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            sgs = ec2.describe_security_groups()["SecurityGroups"]
            for sg in sgs:
                for rule in sg.get("IpPermissions", []):
                    from_port = rule.get("FromPort", 0)
                    to_port = rule.get("ToPort", 65535)
                    if from_port <= 22 <= to_port:
                        for ip_range in rule.get("IpRanges", []):
                            if ip_range.get("CidrIp") == "0.0.0.0/0":
                                findings.append(self.plugin.finding_factory_service.create_finding(
                                    check=check, account_id=account_id, region=region,
                                    resource_type=AWSResourceType.EC2_SECURITY_GROUP, resource_id=sg["GroupId"],
                                    name=sg["GroupName"],
                                    description=f"Security group '{sg['GroupName']}' allows SSH from 0.0.0.0/0",
                                    recommendation="Restrict SSH access to specific IP ranges",
                                    severity=SeverityLevel.HIGH,
                                    evidence={"port": 22, "cidr": "0.0.0.0/0"},
                                    remediation_commands=[
                                        f"aws ec2 revoke-security-group-ingress --group-id {sg['GroupId']} --protocol tcp --port 22 --cidr 0.0.0.0/0 --region {region}"
                                    ],
                                ))
                                break
        except Exception as e:
            logger.error(f"SG SSH check failed in {region}: {e}")
        return findings
    
    async def check_sg_open_rdp(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for security groups with RDP open to the world."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            sgs = ec2.describe_security_groups()["SecurityGroups"]
            for sg in sgs:
                for rule in sg.get("IpPermissions", []):
                    from_port = rule.get("FromPort", 0)
                    to_port = rule.get("ToPort", 65535)
                    if from_port <= 3389 <= to_port:
                        for ip_range in rule.get("IpRanges", []):
                            if ip_range.get("CidrIp") == "0.0.0.0/0":
                                findings.append(self.plugin.finding_factory_service.create_finding(
                                    check=check, account_id=account_id, region=region,
                                    resource_type=AWSResourceType.EC2_SECURITY_GROUP, resource_id=sg["GroupId"],
                                    name=sg["GroupName"],
                                    description=f"Security group '{sg['GroupName']}' allows RDP from 0.0.0.0/0",
                                    recommendation="Restrict RDP access to specific IP ranges or use SSM",
                                    severity=SeverityLevel.HIGH,
                                    evidence={"port": 3389, "cidr": "0.0.0.0/0"},
                                ))
                                break
        except Exception as e:
            logger.error(f"SG RDP check failed in {region}: {e}")
        return findings
    
    async def check_sg_open_all(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for security groups with all ports open."""
        findings = []
        try:
            ec2 = self.plugin._get_client("ec2", region)
            sgs = ec2.describe_security_groups()["SecurityGroups"]
            for sg in sgs:
                for rule in sg.get("IpPermissions", []):
                    if rule.get("IpProtocol") == "-1":
                        for ip_range in rule.get("IpRanges", []):
                            if ip_range.get("CidrIp") == "0.0.0.0/0":
                                findings.append(self.plugin.finding_factory_service.create_finding(
                                    check=check, account_id=account_id, region=region,
                                    resource_type=AWSResourceType.EC2_SECURITY_GROUP, resource_id=sg["GroupId"],
                                    name=sg["GroupName"],
                                    description=f"Security group '{sg['GroupName']}' allows all traffic from 0.0.0.0/0",
                                    recommendation="Restrict inbound traffic to specific ports and sources",
                                    severity=SeverityLevel.CRITICAL,
                                    evidence={"protocol": "all", "cidr": "0.0.0.0/0"},
                                ))
                                break
        except Exception as e:
            logger.error(f"SG open all check failed in {region}: {e}")
        return findings

