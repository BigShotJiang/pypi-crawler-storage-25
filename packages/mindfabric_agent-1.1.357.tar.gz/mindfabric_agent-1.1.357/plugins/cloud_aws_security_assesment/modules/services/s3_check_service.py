"""
S3 Check Service

Service for executing S3-related security checks.
"""

import json
import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

try:
    from botocore.exceptions import ClientError
except ModuleNotFoundError:  # pragma: no cover
    ClientError = Exception
from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel

logger = logging.getLogger(__name__)


class S3CheckService:
    """Service for executing S3 security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize S3 check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute S3 check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_public_bucket": self.check_public_bucket,
            "check_block_public_access": self.check_block_public_access,
            "check_s3_encryption": self.check_s3_encryption,
            "check_s3_logging": self.check_s3_logging,
            "check_s3_versioning": self.check_s3_versioning,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_public_bucket(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for public S3 buckets."""
        findings = []
        try:
            s3 = self.plugin._get_client("s3")
            buckets = s3.list_buckets()["Buckets"]
            for bucket in buckets:
                bucket_name = bucket["Name"]
                try:
                    acl = s3.get_bucket_acl(Bucket=bucket_name)
                    for grant in acl.get("Grants", []):
                        grantee = grant.get("Grantee", {})
                        uri = grantee.get("URI", "")
                        if "AllUsers" in uri or "AuthenticatedUsers" in uri:
                            findings.append(self.plugin.finding_factory_service.create_finding(
                                check=check, account_id=account_id, region="global",
                                resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                                arn=f"arn:aws:s3:::{bucket_name}",
                                description=f"S3 bucket '{bucket_name}' has public ACL",
                                recommendation="Remove public access from bucket ACL",
                                severity=SeverityLevel.CRITICAL,
                                evidence={"public_acl": True, "grantee": uri},
                                remediation_commands=[
                                    f"aws s3api put-bucket-acl --bucket {bucket_name} --acl private"
                                ],
                            ))
                            break
                except ClientError:
                    pass
                try:
                    policy = s3.get_bucket_policy(Bucket=bucket_name)
                    policy_doc = json.loads(policy["Policy"])
                    for statement in policy_doc.get("Statement", []):
                        principal = statement.get("Principal", {})
                        if principal == "*" or principal.get("AWS") == "*":
                            if statement.get("Effect") == "Allow":
                                condition = statement.get("Condition", {})
                                if not condition:
                                    findings.append(self.plugin.finding_factory_service.create_finding(
                                        check=check, account_id=account_id, region="global",
                                        resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                                        arn=f"arn:aws:s3:::{bucket_name}",
                                        description=f"S3 bucket '{bucket_name}' has public bucket policy",
                                        recommendation="Remove public access from bucket policy",
                                        severity=SeverityLevel.CRITICAL,
                                        evidence={"public_policy": True},
                                    ))
                                    break
                except ClientError:
                    pass
        except Exception as e:
            logger.error(f"Public bucket check failed: {e}")
        return findings
    
    async def check_block_public_access(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check S3 Block Public Access settings."""
        findings = []
        try:
            s3 = self.plugin._get_client("s3")
            s3control = self.plugin._get_client("s3control")
            try:
                account_bpa = s3control.get_public_access_block(AccountId=account_id)
                config = account_bpa.get("PublicAccessBlockConfiguration", {})
                if not all([
                    config.get("BlockPublicAcls"),
                    config.get("IgnorePublicAcls"),
                    config.get("BlockPublicPolicy"),
                    config.get("RestrictPublicBuckets")
                ]):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region="global",
                        resource_type=AWSResourceType.ACCOUNT, resource_id=account_id,
                        description="Account-level S3 Block Public Access is not fully enabled",
                        recommendation="Enable all S3 Block Public Access settings at account level",
                        severity=SeverityLevel.HIGH,
                        evidence={"block_public_access": config},
                    ))
            except ClientError:
                pass
            buckets = s3.list_buckets()["Buckets"]
            for bucket in buckets:
                bucket_name = bucket["Name"]
                try:
                    bpa = s3.get_public_access_block(Bucket=bucket_name)
                    config = bpa.get("PublicAccessBlockConfiguration", {})
                    if not all([
                        config.get("BlockPublicAcls"),
                        config.get("IgnorePublicAcls"),
                        config.get("BlockPublicPolicy"),
                        config.get("RestrictPublicBuckets")
                    ]):
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                            description=f"S3 bucket '{bucket_name}' does not have Block Public Access fully enabled",
                            recommendation="Enable all Block Public Access settings",
                            severity=SeverityLevel.HIGH,
                            evidence={"block_public_access": config},
                        ))
                except ClientError as e:
                    if e.response["Error"]["Code"] == "NoSuchPublicAccessBlockConfiguration":
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                            description=f"S3 bucket '{bucket_name}' has no Block Public Access configuration",
                            recommendation="Enable Block Public Access settings",
                            severity=SeverityLevel.HIGH,
                            evidence={"block_public_access": None},
                        ))
        except Exception as e:
            logger.error(f"Block public access check failed: {e}")
        return findings
    
    async def check_s3_encryption(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check S3 bucket encryption."""
        findings = []
        try:
            s3 = self.plugin._get_client("s3")
            buckets = s3.list_buckets()["Buckets"]
            for bucket in buckets:
                bucket_name = bucket["Name"]
                try:
                    s3.get_bucket_encryption(Bucket=bucket_name)
                except ClientError as e:
                    if e.response["Error"]["Code"] == "ServerSideEncryptionConfigurationNotFoundError":
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                            description=f"S3 bucket '{bucket_name}' does not have default encryption",
                            recommendation="Enable default encryption using SSE-S3 or SSE-KMS",
                            severity=SeverityLevel.MEDIUM,
                            evidence={"encryption_enabled": False},
                        ))
        except Exception as e:
            logger.error(f"S3 encryption check failed: {e}")
        return findings
    
    async def check_s3_logging(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check S3 bucket logging."""
        findings = []
        try:
            s3 = self.plugin._get_client("s3")
            buckets = s3.list_buckets()["Buckets"]
            for bucket in buckets:
                bucket_name = bucket["Name"]
                try:
                    logging_config = s3.get_bucket_logging(Bucket=bucket_name)
                    if not logging_config.get("LoggingEnabled"):
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                            description=f"S3 bucket '{bucket_name}' does not have access logging enabled",
                            recommendation="Enable server access logging for audit trail",
                            severity=SeverityLevel.MEDIUM,
                            evidence={"logging_enabled": False},
                        ))
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"S3 logging check failed: {e}")
        return findings
    
    async def check_s3_versioning(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check S3 bucket versioning."""
        findings = []
        try:
            s3 = self.plugin._get_client("s3")
            buckets = s3.list_buckets()["Buckets"]
            for bucket in buckets:
                bucket_name = bucket["Name"]
                try:
                    versioning = s3.get_bucket_versioning(Bucket=bucket_name)
                    if versioning.get("Status") != "Enabled":
                        findings.append(self.plugin.finding_factory_service.create_finding(
                            check=check, account_id=account_id, region="global",
                            resource_type=AWSResourceType.S3_BUCKET, resource_id=bucket_name,
                            description=f"S3 bucket '{bucket_name}' does not have versioning enabled",
                            recommendation="Enable versioning for data protection",
                            severity=SeverityLevel.LOW,
                            evidence={"versioning_status": versioning.get("Status", "Not enabled")},
                        ))
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"S3 versioning check failed: {e}")
        return findings

