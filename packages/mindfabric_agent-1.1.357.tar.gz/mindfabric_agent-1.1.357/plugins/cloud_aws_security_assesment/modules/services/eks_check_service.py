"""
EKS Check Service

Service for executing EKS-related security checks.
"""

import logging
from typing import Any, Dict, List

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import ScanOptions, SecurityFinding, AWSResourceType, SeverityLevel

logger = logging.getLogger(__name__)


class EKSCheckService:
    """Service for executing EKS security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize EKS check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        account_id: str,
        region: str,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute EKS check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_eks_public_endpoint": self.check_eks_public_endpoint,
            "check_eks_secrets_encryption": self.check_eks_secrets_encryption,
            "check_eks_logging": self.check_eks_logging,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(account_id, region, check, options)
        
        return []
    
    async def check_eks_public_endpoint(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check EKS public endpoint."""
        findings = []
        try:
            eks = self.plugin._get_client("eks", region)
            clusters = eks.list_clusters()["clusters"]
            for cluster_name in clusters:
                cluster = eks.describe_cluster(name=cluster_name)["cluster"]
                vpc_config = cluster.get("resourcesVpcConfig", {})
                if vpc_config.get("endpointPublicAccess") and not vpc_config.get("publicAccessCidrs"):
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.EKS_CLUSTER, resource_id=cluster_name,
                        description=f"EKS cluster '{cluster_name}' has public endpoint without CIDR restrictions",
                        recommendation="Restrict public endpoint access or use private endpoint",
                        severity=SeverityLevel.HIGH,
                        evidence={"public_endpoint": True},
                    ))
        except Exception as e:
            logger.error(f"EKS public endpoint check failed: {e}")
        return findings
    
    async def check_eks_secrets_encryption(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check EKS secrets encryption."""
        findings = []
        try:
            eks = self.plugin._get_client("eks", region)
            clusters = eks.list_clusters()["clusters"]
            for cluster_name in clusters:
                cluster = eks.describe_cluster(name=cluster_name)["cluster"]
                encryption = cluster.get("encryptionConfig", [])
                secrets_encrypted = any(e.get("resources", []) == ["secrets"] for e in encryption)
                if not secrets_encrypted:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.EKS_CLUSTER, resource_id=cluster_name,
                        description=f"EKS cluster '{cluster_name}' does not have secrets encryption enabled",
                        recommendation="Enable envelope encryption for Kubernetes secrets",
                        severity=SeverityLevel.HIGH,
                        evidence={"secrets_encrypted": False},
                    ))
        except Exception as e:
            logger.error(f"EKS secrets encryption check failed: {e}")
        return findings
    
    async def check_eks_logging(
        self, account_id: str, region: str, check: Dict, options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check EKS logging."""
        findings = []
        try:
            eks = self.plugin._get_client("eks", region)
            clusters = eks.list_clusters()["clusters"]
            for cluster_name in clusters:
                cluster = eks.describe_cluster(name=cluster_name)["cluster"]
                logging = cluster.get("logging", {}).get("clusterLogging", [])
                enabled_types = [l for l in logging if l.get("enabled")]
                if not enabled_types:
                    findings.append(self.plugin.finding_factory_service.create_finding(
                        check=check, account_id=account_id, region=region,
                        resource_type=AWSResourceType.EKS_CLUSTER, resource_id=cluster_name,
                        description=f"EKS cluster '{cluster_name}' does not have control plane logging enabled",
                        recommendation="Enable all control plane log types",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"logging_enabled": False},
                    ))
        except Exception as e:
            logger.error(f"EKS logging check failed: {e}")
        return findings

