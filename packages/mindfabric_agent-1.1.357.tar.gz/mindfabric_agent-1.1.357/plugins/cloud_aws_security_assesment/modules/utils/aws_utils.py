"""
AWS Security Assessment Utils

Contains utility functions for AWS security assessment.
"""

import re
import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import List, Optional, Tuple
from ...proto import (
    SecuritySubCategory,
    MitreAttackReference,
    ComplianceMapping,
    ComplianceFramework,
    SeverityLevel,
)
from ..databases import MITRE_MAPPING, CIS_AWS_MAPPING, SECRET_PATTERNS


def get_mitre_reference(sub_category: SecuritySubCategory) -> Optional[MitreAttackReference]:
    """Get MITRE ATT&CK reference for subcategory."""
    mapping = MITRE_MAPPING.get(sub_category)
    if not mapping:
        return None
    
    url = f"https://attack.mitre.org/techniques/{mapping['technique_id']}"
    if mapping.get("sub_technique_id"):
        sub_id = mapping["sub_technique_id"].split(".")[1] if "." in mapping["sub_technique_id"] else mapping["sub_technique_id"]
        url = f"https://attack.mitre.org/techniques/{mapping['technique_id']}/{sub_id}"
    
    return MitreAttackReference(
        tactic=mapping["tactic"],
        technique_id=mapping["technique_id"],
        technique_name=mapping["technique_name"],
        sub_technique_id=mapping.get("sub_technique_id"),
        sub_technique_name=mapping.get("sub_technique_name"),
        url=url
    )


def get_compliance_mappings(sub_category: SecuritySubCategory) -> List[ComplianceMapping]:
    """Get compliance framework mappings."""
    mappings = []
    
    cis_mapping = CIS_AWS_MAPPING.get(sub_category)
    if cis_mapping:
        mappings.append(ComplianceMapping(
            framework=ComplianceFramework.CIS_AWS,
            control_id=cis_mapping["control_id"],
            control_name=cis_mapping["control_name"]
        ))
    
    return mappings


def check_content_for_secrets(content: str) -> List[Tuple[str, str]]:
    """Check content for potential secrets."""
    findings = []
    for pattern, secret_type in SECRET_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
            findings.append((pattern, secret_type))
    return findings


def calculate_risk_score(severity: SeverityLevel, exploitability: str, impact_scope: str) -> float:
    """Calculate risk score based on multiple factors."""
    severity_weights = {
        SeverityLevel.CRITICAL: 9.0,
        SeverityLevel.HIGH: 7.0,
        SeverityLevel.MEDIUM: 5.0,
        SeverityLevel.LOW: 3.0,
        SeverityLevel.INFO: 1.0,
    }
    
    exploitability_multiplier = {
        "easy": 1.0,
        "medium": 0.8,
        "hard": 0.6,
    }
    
    scope_multiplier = {
        "organization": 1.2,
        "account": 1.0,
        "resource": 0.8,
    }
    
    base_score = severity_weights.get(severity, 5.0)
    exp_mult = exploitability_multiplier.get(exploitability, 0.8)
    scope_mult = scope_multiplier.get(impact_scope, 1.0)
    
    return min(10.0, base_score * exp_mult * scope_mult)

