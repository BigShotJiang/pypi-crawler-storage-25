"""
AWS Security Assessment Utils Module

Exports utility functions for AWS security assessment.
"""

from .aws_utils import (
    get_mitre_reference,
    get_compliance_mappings,
    check_content_for_secrets,
    calculate_risk_score,
)

__all__ = [
    "get_mitre_reference",
    "get_compliance_mappings",
    "check_content_for_secrets",
    "calculate_risk_score",
]

