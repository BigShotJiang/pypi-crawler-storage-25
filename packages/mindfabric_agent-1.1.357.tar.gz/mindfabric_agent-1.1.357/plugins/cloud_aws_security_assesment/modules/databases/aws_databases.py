"""
AWS Security Assessment Databases

Contains static data: MITRE mappings, CIS AWS mappings, check definitions,
dangerous permissions, secret patterns, and default regions.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Any, Dict, List
from ...proto import (
    SecuritySubCategory,
    SecurityCategory,
    AWSResourceType,
    SeverityLevel,
)

# =============================================================================
# MITRE ATT&CK Mapping
# =============================================================================

MITRE_MAPPING: Dict[SecuritySubCategory, Dict[str, Any]] = {
    # IAM Issues
    SecuritySubCategory.ROOT_ACCOUNT_USAGE: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
        "sub_technique_id": "T1078.004",
        "sub_technique_name": "Cloud Accounts",
    },
    SecuritySubCategory.MFA_NOT_ENABLED: {
        "tactic": "Initial Access",
        "technique_id": "T1110",
        "technique_name": "Brute Force",
    },
    SecuritySubCategory.ACCESS_KEY_OLD: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
    },
    SecuritySubCategory.OVERLY_PERMISSIVE_POLICY: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
    },
    SecuritySubCategory.PRIVILEGE_ESCALATION_PATH: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1548",
        "technique_name": "Abuse Elevation Control Mechanism",
    },
    SecuritySubCategory.TRUST_POLICY_RISKY: {
        "tactic": "Initial Access",
        "technique_id": "T1199",
        "technique_name": "Trusted Relationship",
    },
    # EC2 Issues
    SecuritySubCategory.IMDSV1_ENABLED: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
        "sub_technique_id": "T1552.005",
        "sub_technique_name": "Cloud Instance Metadata API",
    },
    SecuritySubCategory.SECURITY_GROUP_OPEN: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.USER_DATA_SECRETS: {
        "tactic": "Credential Access",
        "technique_id": "T1552",
        "technique_name": "Unsecured Credentials",
        "sub_technique_id": "T1552.001",
        "sub_technique_name": "Credentials In Files",
    },
    # S3 Issues
    SecuritySubCategory.PUBLIC_BUCKET: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # Database Issues
    SecuritySubCategory.PUBLIC_DATABASE: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # Logging Issues
    SecuritySubCategory.CLOUDTRAIL_DISABLED: {
        "tactic": "Defense Evasion",
        "technique_id": "T1562",
        "technique_name": "Impair Defenses",
        "sub_technique_id": "T1562.008",
        "sub_technique_name": "Disable Cloud Logs",
    },
    SecuritySubCategory.GUARDDUTY_DISABLED: {
        "tactic": "Defense Evasion",
        "technique_id": "T1562",
        "technique_name": "Impair Defenses",
    },
    # Persistence
    SecuritySubCategory.SCHEDULED_PERSISTENCE: {
        "tactic": "Persistence",
        "technique_id": "T1053",
        "technique_name": "Scheduled Task/Job",
    },
    SecuritySubCategory.LAMBDA_PERSISTENCE: {
        "tactic": "Persistence",
        "technique_id": "T1525",
        "technique_name": "Implant Internal Image",
    },
    # EKS Issues
    SecuritySubCategory.EKS_PUBLIC_ENDPOINT: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.PRIVILEGED_POD: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1611",
        "technique_name": "Escape to Host",
    },
    # Exfiltration
    SecuritySubCategory.DATA_TRANSFER_RISK: {
        "tactic": "Exfiltration",
        "technique_id": "T1537",
        "technique_name": "Transfer Data to Cloud Account",
    },
}


# =============================================================================
# CIS AWS Benchmark Mapping
# =============================================================================

CIS_AWS_MAPPING: Dict[SecuritySubCategory, Dict[str, str]] = {
    SecuritySubCategory.ROOT_ACCOUNT_USAGE: {
        "control_id": "1.1",
        "control_name": "Avoid the use of the root account",
    },
    SecuritySubCategory.MFA_NOT_ENABLED: {
        "control_id": "1.5",
        "control_name": "Ensure MFA is enabled for all IAM users with console access",
    },
    SecuritySubCategory.ACCESS_KEY_OLD: {
        "control_id": "1.14",
        "control_name": "Ensure access keys are rotated every 90 days or less",
    },
    SecuritySubCategory.PASSWORD_POLICY_WEAK: {
        "control_id": "1.8",
        "control_name": "Ensure IAM password policy requires minimum length of 14",
    },
    SecuritySubCategory.CLOUDTRAIL_DISABLED: {
        "control_id": "3.1",
        "control_name": "Ensure CloudTrail is enabled in all regions",
    },
    SecuritySubCategory.PUBLIC_BUCKET: {
        "control_id": "2.1.1",
        "control_name": "Ensure S3 Bucket Policy does not allow public access",
    },
    SecuritySubCategory.SECURITY_GROUP_OPEN: {
        "control_id": "5.2",
        "control_name": "Ensure no security groups allow ingress from 0.0.0.0/0 to port 22",
    },
    SecuritySubCategory.VPC_FLOW_LOGS_DISABLED: {
        "control_id": "3.9",
        "control_name": "Ensure VPC flow logging is enabled in all VPCs",
    },
    SecuritySubCategory.GUARDDUTY_DISABLED: {
        "control_id": "4.16",
        "control_name": "Ensure GuardDuty is enabled",
    },
}


# =============================================================================
# Dangerous IAM Permissions for Privilege Escalation
# =============================================================================

DANGEROUS_PERMISSIONS: Dict[str, Dict[str, Any]] = {
    "iam:CreatePolicyVersion": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can modify existing policies by creating new version",
        "escalation_method": "Create policy version with admin permissions",
    },
    "iam:SetDefaultPolicyVersion": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can switch to previous policy version with more permissions",
        "escalation_method": "Set default to older permissive policy version",
    },
    "iam:PassRole": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can pass IAM role to AWS services",
        "escalation_method": "Pass privileged role to Lambda/EC2/etc",
    },
    "iam:CreateAccessKey": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can create access keys for any user",
        "escalation_method": "Create access key for admin user",
    },
    "iam:CreateLoginProfile": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can create console password for any user",
        "escalation_method": "Create login profile for admin user",
    },
    "iam:UpdateLoginProfile": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can change console password for any user",
        "escalation_method": "Reset admin user password",
    },
    "iam:AttachUserPolicy": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can attach any policy to any user",
        "escalation_method": "Attach AdministratorAccess to self",
    },
    "iam:AttachRolePolicy": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can attach any policy to any role",
        "escalation_method": "Attach AdministratorAccess to role",
    },
    "iam:PutUserPolicy": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can add inline policy to any user",
        "escalation_method": "Add admin inline policy to self",
    },
    "iam:PutRolePolicy": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can add inline policy to any role",
        "escalation_method": "Add admin inline policy to role",
    },
    "iam:UpdateAssumeRolePolicy": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can modify role trust policy",
        "escalation_method": "Allow self to assume privileged role",
    },
    "sts:AssumeRole": {
        "severity": SeverityLevel.HIGH,
        "description": "Can assume roles (check which roles)",
        "escalation_method": "Assume privileged role",
    },
    "lambda:CreateFunction": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create Lambda with execution role",
        "escalation_method": "Create Lambda with privileged role",
    },
    "lambda:UpdateFunctionCode": {
        "severity": SeverityLevel.HIGH,
        "description": "Can update Lambda code (with PassRole = escalation)",
        "escalation_method": "Update Lambda to extract credentials",
    },
    "ec2:RunInstances": {
        "severity": SeverityLevel.HIGH,
        "description": "Can launch EC2 with instance profile",
        "escalation_method": "Launch EC2 with admin instance profile",
    },
    "ssm:SendCommand": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can run commands on EC2 instances",
        "escalation_method": "Run commands on instances with privileged roles",
    },
    "cloudformation:CreateStack": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create CloudFormation stacks",
        "escalation_method": "Create stack with privileged role",
    },
    "glue:CreateDevEndpoint": {
        "severity": SeverityLevel.HIGH,
        "description": "Can create Glue dev endpoint with role",
        "escalation_method": "Create endpoint with privileged role",
    },
}


# =============================================================================
# Secret Patterns
# =============================================================================

SECRET_PATTERNS = [
    (r"AKIA[0-9A-Z]{16}", "AWS Access Key ID"),
    (r"(?i)aws[_\-]?secret[_\-]?access[_\-]?key['\"]?\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})", "AWS Secret Key"),
    (r"(?i)password['\"]?\s*[:=]\s*['\"]?([^\s'\"]{8,})", "Password"),
    (r"(?i)api[_\-]?key['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "API Key"),
    (r"(?i)secret[_\-]?key['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "Secret Key"),
    (r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "Private Key"),
    (r"(?i)bearer\s+[a-zA-Z0-9\-_\.]+", "Bearer Token"),
    (r"(?i)database[_\-]?url.*://", "Database Connection String"),
    (r"(?i)redis://[^\s]+", "Redis Connection String"),
    (r"(?i)mongodb(\+srv)?://[^\s]+", "MongoDB Connection String"),
    (r"(?i)mysql://[^\s]+", "MySQL Connection String"),
    (r"(?i)postgresql://[^\s]+", "PostgreSQL Connection String"),
]


# =============================================================================
# AWS Check Definitions
# =============================================================================

AWS_CHECKS: List[Dict[str, Any]] = [
    # =========================================================================
    # IAM Checks
    # =========================================================================
    {
        "id": "iam_root_account_usage",
        "name": "Root Account Usage",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.ROOT_ACCOUNT_USAGE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.ACCOUNT],
        "check_fn": "check_root_account_usage",
        "global_check": True,
    },
    {
        "id": "iam_root_mfa",
        "name": "Root Account MFA",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.MFA_NOT_ENABLED,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.ACCOUNT],
        "check_fn": "check_root_mfa",
        "global_check": True,
    },
    {
        "id": "iam_user_mfa",
        "name": "IAM User MFA",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.MFA_NOT_ENABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.IAM_USER],
        "check_fn": "check_user_mfa",
        "global_check": True,
    },
    {
        "id": "iam_access_key_rotation",
        "name": "Access Key Rotation",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.ACCESS_KEY_OLD,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.IAM_ACCESS_KEY],
        "check_fn": "check_access_key_rotation",
        "global_check": True,
    },
    {
        "id": "iam_unused_credentials",
        "name": "Unused IAM Credentials",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.ACCESS_KEY_UNUSED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.IAM_USER],
        "check_fn": "check_unused_credentials",
        "global_check": True,
    },
    {
        "id": "iam_password_policy",
        "name": "Password Policy",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.PASSWORD_POLICY_WEAK,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.IAM_PASSWORD_POLICY],
        "check_fn": "check_password_policy",
        "global_check": True,
    },
    {
        "id": "iam_admin_policy",
        "name": "Administrator Access Policy",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OVERLY_PERMISSIVE_POLICY,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.IAM_USER, AWSResourceType.IAM_ROLE],
        "check_fn": "check_admin_policy",
        "global_check": True,
    },
    {
        "id": "iam_role_trust_any",
        "name": "Publicly Assumable Role",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.TRUST_POLICY_RISKY,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.IAM_ROLE],
        "check_fn": "check_role_trust_any",
        "global_check": True,
    },
    {
        "id": "iam_cross_account_no_external_id",
        "name": "Cross-Account Without External ID",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.CROSS_ACCOUNT_ACCESS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.IAM_ROLE],
        "check_fn": "check_cross_account_external_id",
        "global_check": True,
    },
    # =========================================================================
    # EC2 Checks
    # =========================================================================
    {
        "id": "ec2_imdsv1",
        "name": "IMDSv1 Enabled",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.IMDSV1_ENABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EC2_INSTANCE],
        "check_fn": "check_imdsv1",
        "global_check": False,
    },
    {
        "id": "ec2_public_ip",
        "name": "EC2 Public IP",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_INSTANCE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.EC2_INSTANCE],
        "check_fn": "check_ec2_public_ip",
        "global_check": False,
    },
    {
        "id": "ec2_admin_role",
        "name": "EC2 Admin IAM Role",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OVERLY_PERMISSIVE_POLICY,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.EC2_INSTANCE],
        "check_fn": "check_ec2_admin_role",
        "global_check": False,
    },
    {
        "id": "ec2_unencrypted_volume",
        "name": "Unencrypted EBS Volume",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.UNENCRYPTED_VOLUME,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EC2_VOLUME],
        "check_fn": "check_unencrypted_volume",
        "global_check": False,
    },
    {
        "id": "ec2_user_data_secrets",
        "name": "Secrets in User Data",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.USER_DATA_SECRETS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.EC2_INSTANCE],
        "check_fn": "check_user_data_secrets",
        "global_check": False,
    },
    {
        "id": "ec2_public_ami",
        "name": "Public AMI",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_AMI,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EC2_AMI],
        "check_fn": "check_public_ami",
        "global_check": False,
    },
    {
        "id": "ec2_public_snapshot",
        "name": "Public EBS Snapshot",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_SNAPSHOT,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.EC2_SNAPSHOT],
        "check_fn": "check_public_snapshot",
        "global_check": False,
    },
    # =========================================================================
    # Security Group Checks
    # =========================================================================
    {
        "id": "sg_open_ssh",
        "name": "Open SSH Access",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.SECURITY_GROUP_OPEN,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EC2_SECURITY_GROUP],
        "check_fn": "check_sg_open_ssh",
        "global_check": False,
    },
    {
        "id": "sg_open_rdp",
        "name": "Open RDP Access",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.SECURITY_GROUP_OPEN,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EC2_SECURITY_GROUP],
        "check_fn": "check_sg_open_rdp",
        "global_check": False,
    },
    {
        "id": "sg_open_all",
        "name": "Open All Ports",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.SECURITY_GROUP_OPEN,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.EC2_SECURITY_GROUP],
        "check_fn": "check_sg_open_all",
        "global_check": False,
    },
    # =========================================================================
    # S3 Checks
    # =========================================================================
    {
        "id": "s3_public_bucket",
        "name": "Public S3 Bucket",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_BUCKET,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.S3_BUCKET],
        "check_fn": "check_public_bucket",
        "global_check": True,
    },
    {
        "id": "s3_block_public_access",
        "name": "S3 Block Public Access",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.BLOCK_PUBLIC_ACCESS_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.S3_BUCKET],
        "check_fn": "check_block_public_access",
        "global_check": True,
    },
    {
        "id": "s3_encryption",
        "name": "S3 Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.BUCKET_NOT_ENCRYPTED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.S3_BUCKET],
        "check_fn": "check_s3_encryption",
        "global_check": True,
    },
    {
        "id": "s3_logging",
        "name": "S3 Logging",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.BUCKET_LOGGING_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.S3_BUCKET],
        "check_fn": "check_s3_logging",
        "global_check": True,
    },
    {
        "id": "s3_versioning",
        "name": "S3 Versioning",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.VERSIONING_DISABLED,
        "severity": SeverityLevel.LOW,
        "resource_types": [AWSResourceType.S3_BUCKET],
        "check_fn": "check_s3_versioning",
        "global_check": True,
    },
    # =========================================================================
    # RDS Checks
    # =========================================================================
    {
        "id": "rds_public",
        "name": "Public RDS Instance",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_DATABASE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.RDS_INSTANCE],
        "check_fn": "check_public_rds",
        "global_check": False,
    },
    {
        "id": "rds_encryption",
        "name": "RDS Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.DATABASE_NOT_ENCRYPTED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.RDS_INSTANCE],
        "check_fn": "check_rds_encryption",
        "global_check": False,
    },
    {
        "id": "rds_backup",
        "name": "RDS Backup",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.DATABASE_NO_BACKUP,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.RDS_INSTANCE],
        "check_fn": "check_rds_backup",
        "global_check": False,
    },
    {
        "id": "rds_public_snapshot",
        "name": "Public RDS Snapshot",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_DATABASE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.RDS_SNAPSHOT],
        "check_fn": "check_public_rds_snapshot",
        "global_check": False,
    },
    # =========================================================================
    # VPC Checks
    # =========================================================================
    {
        "id": "vpc_flow_logs",
        "name": "VPC Flow Logs",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.VPC_FLOW_LOGS_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.VPC],
        "check_fn": "check_vpc_flow_logs",
        "global_check": False,
    },
    {
        "id": "vpc_default_sg",
        "name": "Default VPC Security Group",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.DEFAULT_VPC,
        "severity": SeverityLevel.LOW,
        "resource_types": [AWSResourceType.EC2_SECURITY_GROUP],
        "check_fn": "check_default_vpc_sg",
        "global_check": False,
    },
    # =========================================================================
    # Logging & Monitoring Checks
    # =========================================================================
    {
        "id": "cloudtrail_enabled",
        "name": "CloudTrail Enabled",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.CLOUDTRAIL_DISABLED,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.CLOUDTRAIL_TRAIL],
        "check_fn": "check_cloudtrail_enabled",
        "global_check": True,
    },
    {
        "id": "cloudtrail_multiregion",
        "name": "CloudTrail Multi-Region",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.CLOUDTRAIL_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.CLOUDTRAIL_TRAIL],
        "check_fn": "check_cloudtrail_multiregion",
        "global_check": True,
    },
    {
        "id": "cloudtrail_encryption",
        "name": "CloudTrail Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.CLOUDTRAIL_NOT_ENCRYPTED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.CLOUDTRAIL_TRAIL],
        "check_fn": "check_cloudtrail_encryption",
        "global_check": True,
    },
    {
        "id": "guardduty_enabled",
        "name": "GuardDuty Enabled",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.GUARDDUTY_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.GUARDDUTY_DETECTOR],
        "check_fn": "check_guardduty_enabled",
        "global_check": False,
    },
    {
        "id": "config_enabled",
        "name": "AWS Config Enabled",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.CONFIG_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.CONFIG_RULE],
        "check_fn": "check_config_enabled",
        "global_check": False,
    },
    # =========================================================================
    # EKS Checks
    # =========================================================================
    {
        "id": "eks_public_endpoint",
        "name": "EKS Public Endpoint",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.EKS_PUBLIC_ENDPOINT,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EKS_CLUSTER],
        "check_fn": "check_eks_public_endpoint",
        "global_check": False,
    },
    {
        "id": "eks_secrets_encryption",
        "name": "EKS Secrets Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.EKS_SECRETS_NOT_ENCRYPTED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.EKS_CLUSTER],
        "check_fn": "check_eks_secrets_encryption",
        "global_check": False,
    },
    {
        "id": "eks_logging",
        "name": "EKS Logging",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.EKS_LOGGING_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.EKS_CLUSTER],
        "check_fn": "check_eks_logging",
        "global_check": False,
    },
    # =========================================================================
    # Lambda Checks
    # =========================================================================
    {
        "id": "lambda_public",
        "name": "Public Lambda Function",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.LAMBDA_PUBLIC,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AWSResourceType.LAMBDA_FUNCTION],
        "check_fn": "check_lambda_public",
        "global_check": False,
    },
    {
        "id": "lambda_admin_role",
        "name": "Lambda Admin Role",
        "category": SecurityCategory.IAM_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.LAMBDA_ADMIN_ROLE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.LAMBDA_FUNCTION],
        "check_fn": "check_lambda_admin_role",
        "global_check": False,
    },
    {
        "id": "lambda_env_secrets",
        "name": "Lambda Environment Secrets",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.LAMBDA_ENV_SECRETS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AWSResourceType.LAMBDA_FUNCTION],
        "check_fn": "check_lambda_env_secrets",
        "global_check": False,
    },
    # =========================================================================
    # Persistence Checks
    # =========================================================================
    {
        "id": "eventbridge_persistence",
        "name": "EventBridge Persistence",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.SCHEDULED_PERSISTENCE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.EVENTBRIDGE_RULE],
        "check_fn": "check_eventbridge_persistence",
        "global_check": False,
    },
    {
        "id": "ssm_persistence",
        "name": "SSM Persistence",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.SSM_PERSISTENCE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AWSResourceType.SSM_PARAMETER],
        "check_fn": "check_ssm_persistence",
        "global_check": False,
    },
]


# =============================================================================
# Default Regions to Scan
# =============================================================================

DEFAULT_REGIONS = [
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "eu-west-1", "eu-west-2", "eu-central-1",
    "ap-northeast-1", "ap-southeast-1", "ap-southeast-2",
]

