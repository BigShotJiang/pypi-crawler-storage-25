"""
AWS Security Assessment UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse it)
- fallback recommendations (when plugin check did not supply one)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple


def get_aws_guidance(
    *,
    category: Optional[str],
    sub_category: Optional[str],
    title: Optional[str] = None,
) -> Tuple[Optional[str], List[Dict[str, str]]]:
    c = (category or "").strip().lower()
    sc = (sub_category or "").strip().lower()

    # Broad category-level impacts (good defaults, not check-specific).
    if "iam" in c or "authorization" in c or "authentication" in c:
        impact = "Misconfigured identity/permissions can let attackers escalate privileges, assume roles, and access sensitive resources across the account."
        recs = [
            {"title": "Apply least privilege", "description": "Remove wildcards and unused permissions; scope IAM policies and trust relationships.", "priority": "high"},
            {"title": "Prefer short-lived credentials", "description": "Use role-based access (STS) and MFA; avoid long-lived access keys.", "priority": "medium"},
        ]
        return impact, recs

    if "network" in c or "exposure" in c or "vpc" in c:
        impact = "Network exposure can enable initial access, scanning, and direct exploitation of services. Combined with leaked credentials it accelerates compromise."
        recs = [
            {"title": "Restrict inbound access", "description": "Tighten security groups/NACLs; avoid 0.0.0.0/0 on admin ports; use private subnets.", "priority": "high"},
            {"title": "Add monitoring", "description": "Enable VPC Flow Logs and alert on anomalous traffic/scans.", "priority": "medium"},
        ]
        return impact, recs

    if "storage" in c or "data" in c or "s3" in c:
        impact = "Data exposure in cloud storage can lead to bulk data exfiltration. Attackers often abuse public buckets, overly broad IAM, or weak encryption controls."
        recs = [
            {"title": "Remove public access", "description": "Block public access at account and bucket level; review bucket policies/ACLs.", "priority": "high"},
            {"title": "Encrypt and log access", "description": "Enable default encryption and access logging; alert on large downloads.", "priority": "medium"},
        ]
        return impact, recs

    if "logging" in c or "audit" in c:
        impact = "Missing or weak logging reduces detection and makes incident response difficult. Attackers can act longer without being noticed."
        recs = [
            {"title": "Enable centralized logging", "description": "Turn on CloudTrail, Config, and ship logs to a central account/SIEM with immutability.", "priority": "high"},
            {"title": "Alert on high-risk actions", "description": "Detect IAM changes, key creation, policy changes, and suspicious STS activity.", "priority": "high"},
        ]
        return impact, recs

    t = (title or "").strip()
    if t:
        return (
            f"AWS risk tied to \"{t}\". Abuse potential depends on IAM trust, resource policies, network path, and whether credentials could already be in attacker hands.",
            [
                {
                    "title": "Confirm resource and principal scope",
                    "description": f"Map `{t}` to account, region, ARN, and effective IAM policy; check for unintended cross-account or public principals.",
                    "priority": "high",
                },
                {
                    "title": "Remediate with CloudTrail evidence",
                    "description": "Apply least-privilege changes, then review CloudTrail/Config history for similar patterns on peer resources.",
                    "priority": "medium",
                },
            ],
        )

    return (
        "Cloud misconfigurations can enable privilege escalation, data access, or persistence depending on the affected service and permission scope.",
        [
            {
                "title": "Prioritize by data and exposure",
                "description": "Classify affected assets (credentials, PII, production); treat internet-adjacent or admin-capable misconfigs as urgent.",
                "priority": "high",
            },
            {
                "title": "Remediate and monitor",
                "description": "Fix IAM/network/storage controls, enable detective controls where missing, and alert on policy drift.",
                "priority": "medium",
            },
        ],
    )

