"""
AWS Security Assessment Plugin

Comprehensive security assessment for Amazon Web Services environments.
Detects IAM misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.

Covers 250+ security vectors across 15 categories mapped to MITRE ATT&CK Cloud Matrix.
"""

import asyncio
import base64
import json
import logging
import re
import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False

from .proto import (
    AccountSummary,
    AWSResourceIdentifier,
    AWSResourceType,
    AWSSecurityOutput,
    Baseline,
    BaselineComparison,
    BaselineFinding,
    CategorySummary,
    CheckResult,
    ComplianceFramework,
    ComplianceMapping,
    EC2InstanceInfo,
    ExfiltrationPath,
    ExploitationCommands,
    FindingStatus,
    IAMPolicyDocument,
    IAMRoleInfo,
    IAMUserInfo,
    IoC,
    MitreAttackReference,
    PersistenceMechanism,
    PrivilegeEscalationPath,
    RegionSummary,
    ResourceTypeSummary,
    S3BucketInfo,
    ScanMetadata,
    ScanOptions,
    ScanScope,
    SecurityCategory,
    SecurityFinding,
    SecurityGroupInfo,
    SecuritySubCategory,
    SeverityLevel,
    SeveritySummary,
)

from .modules.databases import (
    MITRE_MAPPING,
    CIS_AWS_MAPPING,
    AWS_CHECKS,
    DANGEROUS_PERMISSIONS,
    SECRET_PATTERNS,
    DEFAULT_REGIONS,
)
from .modules.utils import (
    get_mitre_reference,
    get_compliance_mappings,
    check_content_for_secrets,
    calculate_risk_score,
)
from .modules.databases.ui_templates import get_aws_guidance
from plugins.base_plugin import BasePlugin

from plugins.base_plugin import BasePlugin

from .modules.services import (
    CheckFilterService,
    ProjectScopeService,
    CheckExecutorService,
    FindingFactoryService,
    IAMCheckService,
    EC2CheckService,
    S3CheckService,
    RDSCheckService,
    VPCCheckService,
    LoggingCheckService,
    EKSCheckService,
    LambdaCheckService,
    AttackPathAnalyzerService,
    ResultProcessorService,
    AdditionalServicesCheckService,
    IAMEdgeCasesService,
    DataExfiltrationService,
    NetworkSecurityService,
    ServerlessExtendedService,
    DatabaseExtendedService,
    CostAttackService,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Main Plugin Class
# =============================================================================

class AWSSecurityPlugin(BasePlugin):
    VERSION = "1.0.0"
    """
    AWS Security Assessment Plugin.
    
    Comprehensive security assessment for Amazon Web Services environments.
    Detects 250+ security vectors across 15 categories.
    """
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.findings: List[SecurityFinding] = []
        self.check_results: List[CheckResult] = []
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.accounts_scanned: Set[str] = set()
        self.regions_scanned: Set[str] = set()
        self.resources_scanned: int = 0
        
        # Analysis results
        self.privilege_escalation_paths: List[PrivilegeEscalationPath] = []
        self.exfiltration_paths: List[ExfiltrationPath] = []
        self.persistence_mechanisms: List[PersistenceMechanism] = []
        self.risky_users: List[IAMUserInfo] = []
        self.risky_roles: List[IAMRoleInfo] = []
        
        # AWS clients cache
        self._clients: Dict[str, Any] = {}
        self._current_account_id: Optional[str] = None
        self._caller_identity: Optional[Dict] = None
        
        # Initialize services
        self.project_scope_service = ProjectScopeService(self)
        self.check_filter_service = CheckFilterService(self)
        self.check_executor_service = CheckExecutorService(self)
        self.finding_factory_service = FindingFactoryService(self)
        self.attack_path_analyzer_service = AttackPathAnalyzerService(self)
        self.result_processor_service = ResultProcessorService(self)
        self.additional_services_check_service = AdditionalServicesCheckService(self)
        self.iam_edge_cases_service = IAMEdgeCasesService(self)
        self.data_exfiltration_service = DataExfiltrationService(self)
        self.network_security_service = NetworkSecurityService(self)
        self.serverless_extended_service = ServerlessExtendedService(self)
        self.database_extended_service = DatabaseExtendedService(self)
        self.cost_attack_service = CostAttackService(self)
    
    async def run(self):
        """Main entry point."""
        from .proto import ScanOptions
        options = ScanOptions()
        return self.to_security_scan_v1(self._with_canonical_findings(await self.hook_aws_security_scan(options)))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Ensure findings include analyst-friendly `impact` and structured `recommendations`.
        Keep plugin-specific enrichment inside the plugin (not in security_contract).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        findings = out.get("findings") or []
        if isinstance(findings, list):
            for f in findings:
                if not isinstance(f, dict):
                    continue
                cat = f.get("category")
                if hasattr(cat, "value"):
                    cat = cat.value
                sub = f.get("sub_category") or f.get("subCategory")
                if hasattr(sub, "value"):
                    sub = sub.value

                impact, fallback_recs = get_aws_guidance(
                    category=str(cat) if cat else None,
                    sub_category=str(sub) if sub else None,
                    title=str(f.get("name") or f.get("title") or "") if (f.get("name") or f.get("title")) else None,
                )
                if not f.get("impact") and impact:
                    f["impact"] = impact

                # If check provided only `recommendation` (string), also populate `recommendations` for UI blocks.
                if not f.get("recommendations"):
                    rec_str = f.get("recommendation")
                    if isinstance(rec_str, str) and rec_str.strip():
                        f["recommendations"] = [
                            {"title": "Recommendation", "description": rec_str.strip(), "priority": "medium"}
                        ]
                    elif fallback_recs:
                        f["recommendations"] = fallback_recs

                if not f.get("affected_resources"):
                    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}

                    def _aws_pick(*keys: str) -> Optional[str]:
                        for k in keys:
                            v = f.get(k) or ev.get(k)
                            if isinstance(v, str) and v.strip():
                                return v.strip()
                        return None

                    acct = _aws_pick("account_id", "accountId")
                    rarn = _aws_pick("resource_arn", "arn", "resourceArn")
                    reg = _aws_pick("region")
                    rid = _aws_pick("resource_id", "resourceId")
                    rname = _aws_pick("resource_name", "resourceName")
                    if acct or rarn or reg or rid or rname:
                        row_a: Dict[str, Any] = {"type": "cloud_resource"}
                        if acct:
                            row_a["account_id"] = acct[:40]
                        if rarn:
                            row_a["arn"] = rarn[:500]
                        if reg:
                            row_a["region"] = reg[:80]
                        if rid:
                            row_a["resource_id"] = rid[:500]
                        if rname:
                            row_a["resource"] = rname[:500]
                        f["affected_resources"] = [row_a]

        out["findings"] = findings
        return out
    
    def _get_client(self, service: str, region: str = "us-east-1") -> Any:
        """Get or create boto3 client."""
        if not HAS_BOTO3:
            raise ImportError("boto3 is required for AWS scanning")
        
        cache_key = f"{service}:{region}"
        if cache_key not in self._clients:
            self._clients[cache_key] = boto3.client(service, region_name=region)
        return self._clients[cache_key]
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket."""
        if self.ws:
            try:
                await self.ws.send_json({
                    "type": "progress",
                    "command_id": self.command_id,
                    "percent": percent,
                    "message": message
                })
            except Exception:
                pass
        logger.debug(f"Progress: {percent}% - {message}")
    
    async def hook_aws_security_scan(
        self,
        options: Optional[ScanOptions] = None
    ) -> AWSSecurityOutput:
        """
        Main entry point for AWS security scanning.
        
        Args:
            options: Scan configuration options
            
        Returns:
            AWSSecurityOutput with all findings
        """
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.utcnow()
        self.findings = []
        self.check_results = []
        self.errors = []
        self.warnings = []
        self.accounts_scanned = set()
        self.regions_scanned = set()
        self.resources_scanned = 0
        self.privilege_escalation_paths = []
        self.exfiltration_paths = []
        self.persistence_mechanisms = []
        self.risky_users = []
        self.risky_roles = []
        self._clients = {}
        
        # Default options
        if options is None:
            options = ScanOptions()
        
        await self._handle_progress(0, "Starting AWS security scan")
        
        # Get caller identity
        await self._handle_progress(2, "Getting caller identity")
        try:
            sts = self._get_client("sts")
            self._caller_identity = sts.get_caller_identity()
            self._current_account_id = self._caller_identity["Account"]
        except Exception as e:
            err_msg = f"Failed to get caller identity: {e}"
            self.errors.append(err_msg)
            # Important: missing/invalid AWS credentials is a coverage issue (not a security finding).
            # Do NOT emit a finding/threat for this case; return only errors/warnings.
            self.warnings.append("AWS scan skipped: credentials/tooling not available (STS GetCallerIdentity failed)")
            return self.result_processor_service.create_output(options)
        
        # Determine accounts to scan
        await self._handle_progress(5, "Determining scan scope")
        accounts = await self.project_scope_service.get_accounts_to_scan(options.scope)
        
        if not accounts:
            accounts = [self._current_account_id]
        
        self.accounts_scanned = set(accounts)
        
        # Determine regions
        regions = self.project_scope_service.get_regions_to_scan(options.scope)
        self.regions_scanned = set(regions)
        
        # Filter checks
        checks = self.check_filter_service.filter_checks(AWS_CHECKS, options)
        global_checks = [c for c in checks if c.get("global_check", False)]
        regional_checks = [c for c in checks if not c.get("global_check", False)]
        
        await self._handle_progress(10, f"Scanning {len(accounts)} accounts, {len(regions)} regions")
        
        # Execute global checks (IAM, S3, etc.)
        total_work = len(global_checks) + len(regional_checks) * len(regions)
        work_done = 0
        
        for account_id in accounts:
            # Global checks
            for check in global_checks:
                try:
                    result = await self.check_executor_service.execute_check(check, account_id, "global", options)
                    self.check_results.append(result)
                    self.findings.extend(result.findings)
                except Exception as e:
                    self.errors.append(f"Check '{check['name']}' failed: {str(e)}")
                
                work_done += 1
                progress = 10 + int((work_done / total_work) * 70)
                await self._handle_progress(progress, f"Running check: {check['name']}")
            
            # Regional checks
            for region in regions:
                for check in regional_checks:
                    try:
                        result = await self.check_executor_service.execute_check(check, account_id, region, options)
                        self.check_results.append(result)
                        self.findings.extend(result.findings)
                    except Exception as e:
                        self.errors.append(f"Check '{check['name']}' in {region} failed: {str(e)}")
                    
                    work_done += 1
        
        # Attack path analysis
        if options.analyze_privilege_escalation:
            await self._handle_progress(82, "Analyzing privilege escalation paths")
            await self.attack_path_analyzer_service.analyze_privilege_escalation_paths(options)
        
        if options.analyze_exfiltration_paths:
            await self._handle_progress(86, "Analyzing exfiltration paths")
            await self.attack_path_analyzer_service.analyze_exfiltration_paths(options)
        
        if options.analyze_persistence:
            await self._handle_progress(90, "Analyzing persistence mechanisms")
            await self.attack_path_analyzer_service.analyze_persistence(options)
        
        # Additional AWS services checks (AppSync, Amplify, CodeBuild, Glue, Step Functions,
        # ECS/Fargate, ECR, API Gateway, Cognito, Secrets Manager, KMS, CloudFormation, CloudWatch, EventBridge)
        await self._handle_progress(92, "Checking additional AWS services")
        try:
            additional_findings = await self.hook_additional_services_scan(options)
            self.findings.extend(additional_findings)
        except Exception as e:
            self.warnings.append(f"Additional services scan partial failure: {str(e)}")
        
        await self._handle_progress(95, "Generating summary")
        
        return self.result_processor_service.create_output(options)
    
    async def hook_additional_services_scan(self, options: ScanOptions) -> List[SecurityFinding]:
        """
        Scan additional AWS services for security issues.
        
        Covers: AppSync, Amplify, CodeBuild/CodePipeline, Glue, Step Functions,
        SSM, ECS/Fargate, ECR, API Gateway, Cognito, Secrets Manager, KMS,
        CloudFormation, CloudWatch, EventBridge.
        
        Args:
            options: Scan configuration
            
        Returns:
            List of security findings
        """
        all_findings = []
        aws_resources = {}
        
        regions = list(self.regions_scanned) or ["us-east-1"]
        
        for region in regions:
            try:
                # Collect resources from various services
                
                # AppSync APIs
                try:
                    appsync = self._get_client("appsync", region)
                    apis_response = appsync.list_graphql_apis()
                    aws_resources.setdefault("appsync_apis", []).extend(apis_response.get("graphqlApis", []))
                except Exception:
                    pass
                
                # Amplify Apps
                try:
                    amplify = self._get_client("amplify", region)
                    apps_response = amplify.list_apps()
                    aws_resources.setdefault("amplify_apps", []).extend(apps_response.get("apps", []))
                except Exception:
                    pass
                
                # CodeBuild Projects
                try:
                    codebuild = self._get_client("codebuild", region)
                    projects_response = codebuild.list_projects()
                    project_names = projects_response.get("projects", [])
                    if project_names:
                        details = codebuild.batch_get_projects(names=project_names[:100])
                        aws_resources.setdefault("codebuild_projects", []).extend(details.get("projects", []))
                except Exception:
                    pass
                
                # CodePipeline
                try:
                    codepipeline = self._get_client("codepipeline", region)
                    pipelines_response = codepipeline.list_pipelines()
                    for pipeline_summary in pipelines_response.get("pipelines", []):
                        pipeline_details = codepipeline.get_pipeline(name=pipeline_summary["name"])
                        aws_resources.setdefault("codepipelines", []).append(pipeline_details.get("pipeline", {}))
                except Exception:
                    pass
                
                # Glue Jobs
                try:
                    glue = self._get_client("glue", region)
                    jobs_response = glue.get_jobs()
                    aws_resources.setdefault("glue_jobs", []).extend(jobs_response.get("Jobs", []))
                except Exception:
                    pass
                
                # Step Functions
                try:
                    sfn = self._get_client("stepfunctions", region)
                    machines_response = sfn.list_state_machines()
                    for machine in machines_response.get("stateMachines", []):
                        machine_details = sfn.describe_state_machine(stateMachineArn=machine["stateMachineArn"])
                        aws_resources.setdefault("step_functions", []).append(machine_details)
                except Exception:
                    pass
                
                # SSM Parameters (limited to avoid API throttling)
                try:
                    ssm = self._get_client("ssm", region)
                    params_response = ssm.describe_parameters(MaxResults=50)
                    aws_resources.setdefault("ssm_parameters", []).extend(params_response.get("Parameters", []))
                except Exception:
                    pass
                
                # ECS Clusters
                try:
                    ecs = self._get_client("ecs", region)
                    clusters_response = ecs.list_clusters()
                    cluster_arns = clusters_response.get("clusterArns", [])
                    if cluster_arns:
                        clusters_details = ecs.describe_clusters(clusters=cluster_arns)
                        aws_resources.setdefault("ecs_clusters", []).extend(clusters_details.get("clusters", []))
                except Exception:
                    pass
                
                # ECS Task Definitions
                try:
                    ecs = self._get_client("ecs", region)
                    task_defs_response = ecs.list_task_definitions(status="ACTIVE", maxResults=50)
                    for task_def_arn in task_defs_response.get("taskDefinitionArns", []):
                        task_def_details = ecs.describe_task_definition(taskDefinition=task_def_arn)
                        aws_resources.setdefault("ecs_task_definitions", []).append(task_def_details.get("taskDefinition", {}))
                except Exception:
                    pass
                
                # ECR Repositories
                try:
                    ecr = self._get_client("ecr", region)
                    repos_response = ecr.describe_repositories()
                    aws_resources.setdefault("ecr_repositories", []).extend(repos_response.get("repositories", []))
                except Exception:
                    pass
                
                # API Gateway REST APIs
                try:
                    apigateway = self._get_client("apigateway", region)
                    apis_response = apigateway.get_rest_apis()
                    aws_resources.setdefault("api_gateway_apis", []).extend(apis_response.get("items", []))
                except Exception:
                    pass
                
                # Cognito User Pools
                try:
                    cognito = self._get_client("cognito-idp", region)
                    pools_response = cognito.list_user_pools(MaxResults=50)
                    for pool in pools_response.get("UserPools", []):
                        pool_details = cognito.describe_user_pool(UserPoolId=pool["Id"])
                        aws_resources.setdefault("cognito_user_pools", []).append(pool_details.get("UserPool", {}))
                except Exception:
                    pass
                
                # Cognito Identity Pools
                try:
                    cognito_identity = self._get_client("cognito-identity", region)
                    identity_pools_response = cognito_identity.list_identity_pools(MaxResults=50)
                    for pool in identity_pools_response.get("IdentityPools", []):
                        pool_details = cognito_identity.describe_identity_pool(IdentityPoolId=pool["IdentityPoolId"])
                        aws_resources.setdefault("cognito_identity_pools", []).append(pool_details)
                except Exception:
                    pass
                
                # Secrets Manager
                try:
                    secretsmanager = self._get_client("secretsmanager", region)
                    secrets_response = secretsmanager.list_secrets()
                    aws_resources.setdefault("secrets_manager_secrets", []).extend(secrets_response.get("SecretList", []))
                except Exception:
                    pass
                
                # KMS Keys
                try:
                    kms = self._get_client("kms", region)
                    keys_response = kms.list_keys()
                    for key in keys_response.get("Keys", []):
                        try:
                            key_details = kms.describe_key(KeyId=key["KeyId"])
                            key_metadata = key_details.get("KeyMetadata", {})
                            # Get rotation status
                            try:
                                rotation = kms.get_key_rotation_status(KeyId=key["KeyId"])
                                key_metadata["KeyRotationEnabled"] = rotation.get("KeyRotationEnabled", False)
                            except Exception:
                                key_metadata["KeyRotationEnabled"] = False
                            aws_resources.setdefault("kms_keys", []).append(key_metadata)
                        except Exception:
                            pass
                except Exception:
                    pass
                
                # CloudFormation Stacks
                try:
                    cfn = self._get_client("cloudformation", region)
                    stacks_response = cfn.describe_stacks()
                    aws_resources.setdefault("cloudformation_stacks", []).extend(stacks_response.get("Stacks", []))
                except Exception:
                    pass
                
                # CloudWatch Log Groups (limited)
                try:
                    logs = self._get_client("logs", region)
                    log_groups_response = logs.describe_log_groups(limit=50)
                    aws_resources.setdefault("cloudwatch_log_groups", []).extend(log_groups_response.get("logGroups", []))
                except Exception:
                    pass
                
                # CloudWatch Alarms
                try:
                    cloudwatch = self._get_client("cloudwatch", region)
                    alarms_response = cloudwatch.describe_alarms(MaxRecords=100)
                    aws_resources.setdefault("cloudwatch_alarms", []).extend(alarms_response.get("MetricAlarms", []))
                except Exception:
                    pass
                
                # EventBridge Rules
                try:
                    eventbridge = self._get_client("events", region)
                    rules_response = eventbridge.list_rules()
                    aws_resources.setdefault("eventbridge_rules", []).extend(rules_response.get("Rules", []))
                except Exception:
                    pass
                
            except Exception as e:
                self.warnings.append(f"Error collecting resources in region {region}: {str(e)}")
        
        # Run all additional service checks
        findings_dicts = self.additional_services_check_service.run_all_checks(aws_resources)
        
        # Convert to SecurityFinding objects
        for finding_dict in findings_dicts:
            all_findings.append(self.finding_factory_service.create_finding(
                check_id=finding_dict.get("check_id", ""),
                resource_id=finding_dict.get("resource_id", ""),
                resource_name=finding_dict.get("resource_name", ""),
                resource_type=AWSResourceType(finding_dict.get("resource_type", "unknown")),
                severity=SeverityLevel(finding_dict.get("severity", "medium")),
                title=finding_dict.get("title", ""),
                description=finding_dict.get("description", ""),
                recommendation=finding_dict.get("recommendation", ""),
                region="global" if not aws_resources else list(self.regions_scanned)[0] if self.regions_scanned else "us-east-1",
                mitre_technique=finding_dict.get("mitre_technique", ""),
            ))
        
        return all_findings


# Legacy compatibility
async def scan_aws_security(options: Optional[ScanOptions] = None) -> AWSSecurityOutput:
    """Legacy function for backward compatibility."""
    plugin = AWSSecurityPlugin()
    return await plugin.hook_aws_security_scan(options)
