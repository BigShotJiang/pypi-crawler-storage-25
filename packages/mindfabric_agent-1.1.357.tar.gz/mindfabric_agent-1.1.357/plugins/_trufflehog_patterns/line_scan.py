"""Scan a single text line for high-signal secret patterns (TruffleHog-style)."""

from __future__ import annotations

from typing import List, Tuple

from .patterns import TRUFFLEHOG_PATTERNS


def scan_line_for_secrets(line: str) -> List[Tuple[str, str, str]]:
    """
    Return list of (label, matched_value, severity) for each pattern hit on `line`.
    """
    matched: List[Tuple[str, str, str]] = []
    for pattern, label, severity in TRUFFLEHOG_PATTERNS:
        for m in pattern.findall(line):
            if isinstance(m, tuple):
                matched.append((label, m[0], severity))
            else:
                matched.append((label, m, severity))
    return matched
