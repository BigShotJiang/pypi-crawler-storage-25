"""
Shared TruffleHog-style regex patterns for secret detection.

Used by process_security_scanner (proc environ) and other agent components.
Not a plugin — package name starts with '_' so ExecutorRegistry skips it.
"""

import re

# TruffleHog-style patterns for secret detection
TRUFFLEHOG_PATTERNS = [
    # Stripe
    (re.compile(r'sk_live_[0-9a-zA-Z]{24,}'), 'Stripe API Key', 'critical'),
    # AWS
    (re.compile(r'AKIA[0-9A-Z]{16}'), 'AWS Access Key', 'critical'),
    (re.compile(r'ASIA[0-9A-Z]{16}'), 'AWS Session Key', 'critical'),
    (re.compile(r'ACCA[0-9A-Z]{16}'), 'AWS Account Access Key', 'critical'),
    (re.compile(r'A3T[A-Z0-9]{16}'), 'AWS MFA Device', 'critical'),
    (re.compile(r'("|\")?aws_secret_access_key("|\")(\s|:|=)+[A-Za-z0-9/+=]{40}'), 'AWS Secret Access Key', 'critical'),
    (re.compile(r'("|\")?aws_access_key_id("|\")(\s|:|=)+AKIA[0-9A-Z]{16}'), 'AWS Access Key', 'critical'),
    # GCP
    (re.compile(r'AIza[0-9A-Za-z-_]{35}'), 'Google API Key', 'high'),
    (re.compile(r'"type":\s*"service_account"'), 'Google Service Account', 'high'),
    # Azure
    (re.compile(r'("|\").?azure(_client_id|_tenant_id|_secret|_subscription_id)?("|\")?\s*[:=]\s*[a-zA-Z0-9-_/]{10,60}'), 'Azure Secret', 'high'),
    # Heroku
    (re.compile(r'heroku_[0-9a-fA-F]{32}'), 'Heroku API Key', 'high'),
    # GitHub
    (re.compile(r'ghp_[A-Za-z0-9_]{36,255}'), 'GitHub PAT', 'critical'),
    (re.compile(r'github_pat_[A-Za-z0-9_]{22,255}'), 'GitHub Fine-grained PAT', 'high'),
    # GitLab
    (re.compile(r'glpat-[0-9a-zA-Z\-_]{20,}'), 'GitLab PAT', 'high'),
    # Bitbucket
    (re.compile(r'bbp_[A-Za-z0-9]{32,50}'), 'Bitbucket App Password', 'critical'),
    # Mailgun
    (re.compile(r'key-[0-9a-zA-Z]{32}'), 'Mailgun Private API Key', 'high'),
    # SendGrid
    (re.compile(r'SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}'), 'SendGrid API Key', 'critical'),
    # Slack
    (re.compile(r'xox[baprs]-([0-9a-zA-Z]{10,48})?'), 'Slack Token', 'critical'),
    # Twilio
    (re.compile(r'SK[0-9a-fA-F]{32}'), 'Twilio API Key', 'high'),
    (re.compile(r'SID[0-9a-fA-F]{32}'), 'Twilio SID', 'high'),
    # Okta
    (re.compile(r'00[0-9a-zA-Z]{20}\.[0-9a-zA-Z]{6}\.[0-9a-zA-Z\-_]{16,}'), 'Okta Token', 'critical'),
    # Auth0
    (re.compile(r'\bBearer\s+(eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)'), 'Auth0/Bearer JWT', 'high'),
    # JWT tokens
    (re.compile(r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+'), 'JWT Token', 'high'),
    # Facebook
    (re.compile(r'EAACEdEose0cBA[0-9A-Za-z]+'), 'Facebook Access Token', 'medium'),
    # Instagram
    (re.compile(r'IGQV[0-9A-Za-z]+'), 'Instagram Access Token', 'medium'),
    # LinkedIn
    (re.compile(r'AQX[a-zA-Z0-9_-]{180,}'), 'LinkedIn OAuth', 'medium'),
    # Dropbox
    (re.compile(r'sl.[A-Za-z0-9_-]{16,}'), 'Dropbox Secret', 'high'),
    (re.compile(r'sl.[A-Za-z0-9_-]{16,}'), 'Dropbox OAuth', 'high'),
    # DigitalOcean
    (re.compile(r'dop_v1_[a-f0-9]{64}'), 'DigitalOcean Key', 'critical'),
    # Google OAuth Refresh
    (re.compile(r'1//[A-Za-z0-9\-_]{43}'), 'Google OAuth Refresh Token', 'high'),
    # Generic API/secret/password
    (re.compile(r'(?i)(api[_-]?key|apikey|secret|token|password|pwd|access[_-]?token|refresh[_-]?token)[\"\':=\s]+([0-9a-zA-Z_\-\/=\+]{8,})'), 'Generic Secret', 'medium'),
    (re.compile(r'"password"\s*:\s*"[^\"]{6,}"'), 'Possible Password Field (JSON)', 'medium'),
    # Private keys
    (re.compile(r'-----BEGIN RSA PRIVATE KEY-----'), 'RSA Private Key', 'critical'),
    (re.compile(r'-----BEGIN PRIVATE KEY-----'), 'Generic Private Key', 'critical'),
    (re.compile(r'-----BEGIN OPENSSH PRIVATE KEY-----'), 'OpenSSH Private Key', 'critical'),
    (re.compile(r'-----BEGIN EC PRIVATE KEY-----'), 'EC Private Key', 'critical'),
    (re.compile(r'-----BEGIN DSA PRIVATE KEY-----'), 'DSA Private Key', 'critical'),
    # SSH
    (re.compile(r'ssh-rsa\s+[A-Za-z0-9+/]{100,}'), 'SSH RSA Public Key', 'low'),
    # Database connection strings
    (re.compile(r'mongodb(?:\+srv)?:\/\/[\w\d\-_]+:[\w\d\-.!$]*@[\w\d\-.]+'), 'MongoDB Connection String', 'high'),
    (re.compile(r'postgres(?:ql)?:\/\/[^\s:@]+:[^\s:@]+@[^\s:@]+:[0-9]+(?:\/[^\s]+)?'), 'PostgreSQL Connection String', 'high'),
    (re.compile(r'mysql:\/\/[^\s:@]+:[^\s:@]+@[^\s:@]+:[0-9]+\/[a-zA-Z0-9_]+'), 'MySQL Connection String', 'high'),
    (re.compile(r'sqlserver:\/\/[^\s:@]+:[^\s:@]+@[^\s:@]+:[0-9]+'), 'SQLServer Connection String', 'high'),
    (re.compile(r'redis:\/\/:[^@]+@[\w\d\-.]+:\d+\/\d+'), 'Redis Connection String', 'high'),
    (re.compile(r'\(DESCRIPTION=\(ADDRESS_LIST=\(ADDRESS=\(PROTOCOL=TCP\)[^\)]{10,}\)\)\)'), 'Oracle DB Connection', 'high'),
    # SMTP
    (re.compile(r'(smtp|mailgun|sendgrid)[\.:][0-9a-zA-Z_-]{16,}'), 'SMTP/Mail Secret', 'medium'),
    # Atlassian
    (re.compile(r'Atlassian-Token\s*:\s*(no-check|[A-Za-z0-9-_=]+)'), 'Atlassian Secret', 'medium'),
    # Google Cloud Service Account (private_key)
    (re.compile(r'"private_key":\s*"-----BEGIN PRIVATE KEY-----[\s\S]+?-----END PRIVATE KEY-----"'), 'GCP Service Account Private Key', 'critical'),
    # Paypal
    (re.compile(r'live_[a-zA-Z0-9_]{32,}'), 'Paypal Live Token', 'critical'),
    # Netlify
    (re.compile(r'nf_[a-zA-Z0-9_-]{30,}'), 'Netlify Access Token', 'high'),
    # Square
    (re.compile(r'sq0atp-[0-9A-Za-z\-_]{22,43}'), 'Square Access Token', 'high'),
    # Shopify
    (re.compile(r'shpss_[A-Za-z0-9]{32}'), 'Shopify Access Token', 'high'),
    (re.compile(r'shpat_[A-Za-z0-9]{32}'), 'Shopify Private App Token', 'critical'),
    # Plaid
    (re.compile(r'plaid_(dev|test|prod)_\w{30,60}'), 'Plaid API Key', 'high'),
    # Vercel
    (re.compile(r'vercel_[a-zA-Z0-9_]{28,80}'), 'Vercel Token', 'high'),
    # Linear
    (re.compile(r'lin_api_[0-9a-f]{40,}'), 'Linear API Token', 'high'),
    # Supabase
    (re.compile(r'sbpat_[a-zA-Z0-9_\-]{36,120}'), 'Supabase API Key', 'high'),
]

# Base64 detection regex
BASE64_REGEX = re.compile(r'([A-Za-z0-9+/=]{32,})')

# Target file extensions for scanning
TARGET_EXTENSIONS = (
    '.env', '.txt', '.py', '.js', '.json', '.yml', '.yaml', '.php', '.config', '.ini', '.xml', '.envrc', '.sh', '.bash', '.zsh', '.pl', '.rb',
    '.go', '.c', '.cpp', '.rs', '.ts', '.tsx', '.md', '.log', '.conf', '.out', '.properties', '.crt', '.pem', '.der', '.csr', '.cfg', '.db', '.sqlite', '.sql'
)


# =============================================================================
# Kubernetes Secrets Patterns
# =============================================================================

KUBERNETES_SECRET_PATTERNS = [
    # Kubernetes service account tokens
    (re.compile(r'eyJhbGciOiJSUzI1NiIsI[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'), 'Kubernetes Service Account Token', 'critical'),
    
    # Kubernetes secrets in YAML
    (re.compile(r'apiVersion:\s*v1\s*\nkind:\s*Secret'), 'Kubernetes Secret Manifest', 'high'),
    (re.compile(r'stringData:\s*\n\s+\w+:\s*.+'), 'Kubernetes Secret StringData', 'high'),
    (re.compile(r'data:\s*\n\s+\w+:\s*[A-Za-z0-9+/=]+'), 'Kubernetes Secret Data (base64)', 'high'),
    
    # Kubernetes ConfigMap with secrets
    (re.compile(r'kind:\s*ConfigMap[\s\S]*?(password|secret|key|token|credential)'), 'Kubernetes ConfigMap with Potential Secret', 'medium'),
    
    # Kubernetes cluster credentials
    (re.compile(r'certificate-authority-data:\s*[A-Za-z0-9+/=]+'), 'Kubernetes CA Certificate', 'high'),
    (re.compile(r'client-certificate-data:\s*[A-Za-z0-9+/=]+'), 'Kubernetes Client Certificate', 'high'),
    (re.compile(r'client-key-data:\s*[A-Za-z0-9+/=]+'), 'Kubernetes Client Key', 'critical'),
    
    # Helm secrets
    (re.compile(r'helm\.sh/release\.\w+'), 'Helm Release Secret', 'medium'),
    (re.compile(r'(?i)sops.*:.*enc.*:'), 'SOPS Encrypted Secret', 'low'),
    
    # External Secrets
    (re.compile(r'kind:\s*ExternalSecret'), 'External Secret Reference', 'low'),
    (re.compile(r'secretStoreRef:'), 'Secret Store Reference', 'low'),
]


# =============================================================================
# CI/CD Secrets Patterns
# =============================================================================

CICD_SECRET_PATTERNS = [
    # GitHub Actions
    (re.compile(r'\$\{\{\s*secrets\.([A-Z_]+)\s*\}\}'), 'GitHub Actions Secret Reference', 'low'),
    (re.compile(r'GITHUB_TOKEN'), 'GitHub Token Environment Variable', 'medium'),
    (re.compile(r'GH_TOKEN'), 'GitHub Token (GH_TOKEN)', 'medium'),
    (re.compile(r'GH_PAT'), 'GitHub Personal Access Token Variable', 'high'),
    
    # GitLab CI
    (re.compile(r'\$CI_JOB_TOKEN'), 'GitLab CI Job Token', 'medium'),
    (re.compile(r'\$CI_REGISTRY_PASSWORD'), 'GitLab Registry Password', 'high'),
    (re.compile(r'\$CI_DEPLOY_PASSWORD'), 'GitLab Deploy Password', 'high'),
    (re.compile(r'GITLAB_TOKEN'), 'GitLab Token', 'high'),
    
    # Jenkins
    (re.compile(r'withCredentials\s*\(\s*\['), 'Jenkins Credentials Block', 'medium'),
    (re.compile(r'credentials\s*\(\s*["\'][^"\']+["\']\s*\)'), 'Jenkins Credentials ID', 'medium'),
    (re.compile(r'JENKINS_API_TOKEN'), 'Jenkins API Token', 'high'),
    
    # CircleCI
    (re.compile(r'CIRCLE_TOKEN'), 'CircleCI Token', 'high'),
    (re.compile(r'circleci.*token.*[0-9a-f]{40}'), 'CircleCI API Token', 'high'),
    
    # Travis CI
    (re.compile(r'TRAVIS_TOKEN'), 'Travis CI Token', 'high'),
    (re.compile(r'secure:\s*[A-Za-z0-9+/=]+'), 'Travis CI Encrypted Secret', 'medium'),
    
    # Azure DevOps
    (re.compile(r'AZURE_DEVOPS_EXT_PAT'), 'Azure DevOps PAT', 'high'),
    (re.compile(r'SYSTEM_ACCESSTOKEN'), 'Azure DevOps System Access Token', 'high'),
    
    # AWS CodeBuild
    (re.compile(r'CODEBUILD_[A-Z_]+'), 'AWS CodeBuild Environment Variable', 'medium'),
    
    # General CI/CD
    (re.compile(r'(?i)CI_[A-Z_]*TOKEN'), 'CI Token Environment Variable', 'medium'),
    (re.compile(r'(?i)DEPLOY_[A-Z_]*KEY'), 'Deploy Key Variable', 'high'),
    (re.compile(r'(?i)BUILD_[A-Z_]*SECRET'), 'Build Secret Variable', 'high'),
]


# =============================================================================
# Docker Secrets Patterns
# =============================================================================

DOCKER_SECRET_PATTERNS = [
    # Docker Hub
    (re.compile(r'dckr_pat_[A-Za-z0-9_-]{27,}'), 'Docker Hub PAT', 'critical'),
    
    # Docker Compose secrets
    (re.compile(r'secrets:\s*\n\s+-\s+\w+'), 'Docker Compose Secrets Definition', 'medium'),
    (re.compile(r'external:\s*true\s*\n\s*name:\s*\w+'), 'Docker External Secret', 'medium'),
    
    # Docker config
    (re.compile(r'"auths":\s*\{[^}]*"auth":\s*"[A-Za-z0-9+/=]+"'), 'Docker Registry Auth', 'critical'),
    
    # Dockerfile secrets exposure
    (re.compile(r'ARG\s+\w*(PASSWORD|SECRET|KEY|TOKEN)\w*'), 'Dockerfile ARG with Secret', 'high'),
    (re.compile(r'ENV\s+\w*(PASSWORD|SECRET|KEY|TOKEN)\w*\s*='), 'Dockerfile ENV with Secret', 'high'),
]


# =============================================================================
# AI/ML API Keys
# =============================================================================

AI_ML_SECRET_PATTERNS = [
    # OpenAI
    (re.compile(r'sk-[A-Za-z0-9]{48}'), 'OpenAI API Key', 'critical'),
    (re.compile(r'sk-proj-[A-Za-z0-9_-]{48,}'), 'OpenAI Project API Key', 'critical'),
    
    # Anthropic
    (re.compile(r'sk-ant-api[0-9]{2}-[A-Za-z0-9_-]{86,}'), 'Anthropic API Key', 'critical'),
    
    # Cohere
    (re.compile(r'[A-Za-z0-9]{40}'), 'Cohere API Key (potential)', 'medium'),  # Needs context
    
    # Hugging Face
    (re.compile(r'hf_[A-Za-z0-9]{34,}'), 'Hugging Face Token', 'high'),
    
    # Replicate
    (re.compile(r'r8_[A-Za-z0-9]{37}'), 'Replicate API Token', 'high'),
    
    # Stability AI
    (re.compile(r'sk-[A-Za-z0-9]{49,}'), 'Stability AI Key (potential)', 'high'),
    
    # Google AI (Gemini/Bard)
    (re.compile(r'AIzaSy[A-Za-z0-9_-]{33}'), 'Google AI API Key', 'high'),
    
    # Azure OpenAI
    (re.compile(r'[0-9a-f]{32}'), 'Azure OpenAI Key (potential)', 'medium'),  # Needs context
    
    # Mistral AI
    (re.compile(r'[A-Za-z0-9]{32}'), 'Mistral AI Key (potential)', 'medium'),  # Needs MISTRAL_ context
    
    # Groq
    (re.compile(r'gsk_[A-Za-z0-9]{52}'), 'Groq API Key', 'critical'),
    
    # Together AI
    (re.compile(r'[a-f0-9]{64}'), 'Together AI Key (potential)', 'medium'),  # Needs context
    
    # Perplexity AI
    (re.compile(r'pplx-[A-Za-z0-9]{48}'), 'Perplexity API Key', 'critical'),
    
    # Anyscale
    (re.compile(r'secret_[A-Za-z0-9]{32}'), 'Anyscale API Key', 'high'),
    
    # Databricks
    (re.compile(r'dapi[a-f0-9]{32}'), 'Databricks Token', 'critical'),
    
    # Weights & Biases (wandb)
    (re.compile(r'[0-9a-f]{40}'), 'W&B API Key (potential)', 'medium'),  # Needs WANDB_ context
    
    # Pinecone
    (re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}'), 'Pinecone API Key (UUID format)', 'medium'),
    
    # Weaviate
    (re.compile(r'[A-Za-z0-9]{40,}'), 'Weaviate API Key (potential)', 'medium'),  # Needs WEAVIATE_ context
    
    # Qdrant
    (re.compile(r'api-key:\s*[A-Za-z0-9_-]{20,}'), 'Qdrant API Key', 'high'),
    
    # LangChain/LangSmith
    (re.compile(r'ls__[A-Za-z0-9]{32,}'), 'LangSmith API Key', 'high'),
    (re.compile(r'lsv2_pt_[A-Za-z0-9]{32,}'), 'LangSmith Project Token', 'high'),
    
    # Scale AI
    (re.compile(r'scale_[A-Za-z0-9]{32}'), 'Scale AI API Key', 'critical'),
    
    # Voyage AI
    (re.compile(r'voyage-[A-Za-z0-9]{24}'), 'Voyage AI API Key', 'high'),
    
    # DeepL
    (re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}:fx'), 'DeepL API Key', 'high'),
    
    # ElevenLabs
    (re.compile(r'[a-f0-9]{32}'), 'ElevenLabs API Key (potential)', 'medium'),  # Needs ELEVENLABS_ context
    
    # Midjourney (Discord tokens used)
    (re.compile(r'mj-[A-Za-z0-9_-]{20,}'), 'Midjourney Token', 'high'),
    
    # RunPod
    (re.compile(r'[A-Z0-9]{25}'), 'RunPod API Key (potential)', 'medium'),  # Needs RUNPOD_ context
    
    # Modal
    (re.compile(r'ak-[A-Za-z0-9]{32}'), 'Modal API Key', 'high'),
    
    # Fireworks AI
    (re.compile(r'fw_[A-Za-z0-9]{40}'), 'Fireworks AI Key', 'critical'),
    
    # Claude (Anthropic) Extended
    (re.compile(r'claude-[0-9]+'), 'Claude Model Reference', 'low'),  # Model name, not secret
    
    # MLflow
    (re.compile(r'mlflow[_-]tracking[_-]token\s*[=:]\s*[A-Za-z0-9_-]+'), 'MLflow Tracking Token', 'high'),
    
    # Kubeflow
    (re.compile(r'kubeflow[_-]token\s*[=:]\s*[A-Za-z0-9_-]+'), 'Kubeflow Token', 'high'),
    
    # SageMaker
    (re.compile(r'(?i)sagemaker[_-]?execution[_-]?role'), 'SageMaker Execution Role', 'medium'),
    
    # Vertex AI
    (re.compile(r'(?i)vertex[_-]?ai[_-]?(key|token|secret)'), 'Vertex AI Credential Reference', 'medium'),
]


# =============================================================================
# AI/ML Configuration Secrets
# =============================================================================

AI_ML_CONFIG_PATTERNS = [
    # Model hosting credentials
    (re.compile(r'MODEL_API_KEY\s*[=:]\s*[A-Za-z0-9_-]{20,}'), 'Model API Key', 'high'),
    (re.compile(r'INFERENCE_API_KEY\s*[=:]\s*[A-Za-z0-9_-]{20,}'), 'Inference API Key', 'high'),
    
    # Vector DB credentials
    (re.compile(r'PINECONE_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Pinecone API Key', 'critical'),
    (re.compile(r'WEAVIATE_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Weaviate API Key', 'critical'),
    (re.compile(r'QDRANT_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Qdrant API Key', 'critical'),
    (re.compile(r'MILVUS_TOKEN\s*[=:]\s*[A-Za-z0-9_-]+'), 'Milvus Token', 'critical'),
    (re.compile(r'CHROMA_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'ChromaDB API Key', 'high'),
    
    # LLM Provider credentials
    (re.compile(r'OPENAI_API_KEY\s*[=:]\s*sk-[A-Za-z0-9_-]+'), 'OpenAI API Key (config)', 'critical'),
    (re.compile(r'ANTHROPIC_API_KEY\s*[=:]\s*sk-ant-[A-Za-z0-9_-]+'), 'Anthropic API Key (config)', 'critical'),
    (re.compile(r'COHERE_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Cohere API Key (config)', 'critical'),
    (re.compile(r'MISTRAL_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Mistral API Key (config)', 'critical'),
    (re.compile(r'GROQ_API_KEY\s*[=:]\s*gsk_[A-Za-z0-9_-]+'), 'Groq API Key (config)', 'critical'),
    (re.compile(r'TOGETHER_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Together AI Key (config)', 'critical'),
    (re.compile(r'PERPLEXITY_API_KEY\s*[=:]\s*pplx-[A-Za-z0-9_-]+'), 'Perplexity API Key (config)', 'critical'),
    (re.compile(r'FIREWORKS_API_KEY\s*[=:]\s*fw_[A-Za-z0-9_-]+'), 'Fireworks AI Key (config)', 'critical'),
    
    # Experiment tracking
    (re.compile(r'WANDB_API_KEY\s*[=:]\s*[0-9a-f]{40}'), 'W&B API Key (config)', 'critical'),
    (re.compile(r'MLFLOW_TRACKING_URI\s*[=:]\s*[^\s]+'), 'MLflow Tracking URI', 'medium'),
    (re.compile(r'NEPTUNE_API_TOKEN\s*[=:]\s*[A-Za-z0-9_-]+'), 'Neptune API Token', 'high'),
    (re.compile(r'COMET_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'Comet ML API Key', 'high'),
    
    # HuggingFace
    (re.compile(r'HUGGINGFACE_TOKEN\s*[=:]\s*hf_[A-Za-z0-9]+'), 'HuggingFace Token (config)', 'critical'),
    (re.compile(r'HF_TOKEN\s*[=:]\s*hf_[A-Za-z0-9]+'), 'HuggingFace Token (HF_TOKEN)', 'critical'),
    (re.compile(r'HUGGINGFACE_HUB_TOKEN\s*[=:]\s*hf_[A-Za-z0-9]+'), 'HuggingFace Hub Token', 'critical'),
    
    # LangChain
    (re.compile(r'LANGCHAIN_API_KEY\s*[=:]\s*[A-Za-z0-9_-]+'), 'LangChain API Key', 'high'),
    (re.compile(r'LANGCHAIN_TRACING_V2\s*[=:]\s*true'), 'LangChain Tracing Enabled', 'low'),
    (re.compile(r'LANGSMITH_API_KEY\s*[=:]\s*ls[A-Za-z0-9_-]+'), 'LangSmith API Key', 'critical'),
]


# =============================================================================
# Cloud Provider Extended Patterns
# =============================================================================

CLOUD_EXTENDED_PATTERNS = [
    # AWS Extended
    (re.compile(r'AROA[0-9A-Z]{12}'), 'AWS Role ID', 'medium'),
    (re.compile(r'AIDA[0-9A-Z]{16}'), 'AWS User ID', 'medium'),
    (re.compile(r'AGPA[0-9A-Z]{16}'), 'AWS Group ID', 'low'),
    (re.compile(r'AIPA[0-9A-Z]{16}'), 'AWS Instance Profile ID', 'low'),
    (re.compile(r'ANPA[0-9A-Z]{16}'), 'AWS Managed Policy ID', 'low'),
    (re.compile(r'ANVA[0-9A-Z]{16}'), 'AWS Managed Policy Version', 'low'),
    (re.compile(r'APKA[0-9A-Z]{16}'), 'AWS Public Key ID', 'medium'),
    (re.compile(r'ASCA[0-9A-Z]{16}'), 'AWS Server Cert ID', 'medium'),
    
    # GCP Extended
    (re.compile(r'ya29\.[0-9A-Za-z_-]+'), 'GCP OAuth Access Token', 'critical'),
    (re.compile(r'[0-9]+-[0-9a-z]+\.apps\.googleusercontent\.com'), 'GCP OAuth Client ID', 'medium'),
    (re.compile(r'"project_id":\s*"[a-z][a-z0-9-]{4,28}[a-z0-9]"'), 'GCP Project ID', 'low'),
    
    # Azure Extended
    (re.compile(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}'), 'Azure GUID (potential)', 'low'),
    (re.compile(r'SharedAccessSignature\s+sr=[^&]+&sig=[A-Za-z0-9%]+'), 'Azure SAS Token', 'critical'),
    (re.compile(r'DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[A-Za-z0-9+/=]+'), 'Azure Storage Connection String', 'critical'),
    
    # DigitalOcean Extended
    (re.compile(r'doo_v1_[a-f0-9]{64}'), 'DigitalOcean OAuth Token', 'critical'),
    (re.compile(r'dor_v1_[a-f0-9]{64}'), 'DigitalOcean Refresh Token', 'critical'),
    
    # Alibaba Cloud
    (re.compile(r'LTAI[A-Za-z0-9]{12,20}'), 'Alibaba Cloud Access Key', 'critical'),
    
    # Oracle Cloud
    (re.compile(r'ocid1\.[a-z]+\.[a-z0-9]+\.[a-z0-9-]+\.[a-z0-9]{60}'), 'Oracle Cloud OCID', 'medium'),
]


# =============================================================================
# Entropy Analysis Configuration
# =============================================================================

ENTROPY_CONFIG = {
    "min_length": 20,
    "max_length": 200,
    "min_entropy": 4.5,  # Shannon entropy threshold
    "high_entropy_threshold": 5.0,
    "exclude_patterns": [
        r'^[0-9]+$',  # Pure numbers
        r'^[a-f0-9]+$',  # Hex (might be hash, not secret)
        r'^[A-Z_]+$',  # Constants
        r'.*test.*',  # Test strings
        r'.*example.*',  # Example strings
        r'.*placeholder.*',  # Placeholders
        r'^(true|false|null|none|undefined)$',  # Boolean/null values
    ],
    "context_indicators": {
        "high_risk": [
            r'password', r'secret', r'token', r'api[_-]?key', r'private[_-]?key',
            r'credential', r'auth', r'bearer', r'access[_-]?key',
        ],
        "medium_risk": [
            r'config', r'setting', r'env', r'variable',
        ],
    },
}


# =============================================================================
# False Positive Filters
# =============================================================================

FALSE_POSITIVE_PATTERNS = [
    # Test/Example files
    re.compile(r'(test|spec|mock|fake|sample|example|demo|fixture)s?/', re.IGNORECASE),
    re.compile(r'\.(test|spec)\.(js|ts|py|rb)$'),
    
    # Documentation
    re.compile(r'\.(md|rst|txt|adoc)$'),
    re.compile(r'/docs?/'),
    
    # Placeholder values
    re.compile(r'YOUR[_-]?(API[_-]?KEY|TOKEN|SECRET)', re.IGNORECASE),
    re.compile(r'<[A-Z_]+>', re.IGNORECASE),  # <YOUR_API_KEY>
    re.compile(r'\$\{[A-Z_]+\}'),  # ${API_KEY}
    re.compile(r'xxx+', re.IGNORECASE),
    re.compile(r'dummy', re.IGNORECASE),
    re.compile(r'placeholder', re.IGNORECASE),
    
    # Known safe patterns
    re.compile(r'sha256:[a-f0-9]{64}'),  # Docker image digests
    re.compile(r'[a-f0-9]{40}'),  # Git commit hashes (context needed)
]


# =============================================================================
# Severity Mapping
# =============================================================================

SEVERITY_SCORES = {
    'critical': 10,
    'high': 8,
    'medium': 5,
    'low': 2,
    'info': 1,
}


def calculate_shannon_entropy(data: str) -> float:
    """Calculate Shannon entropy of a string."""
    import math
    from collections import Counter
    
    if not data:
        return 0.0
    
    counter = Counter(data)
    length = len(data)
    
    entropy = 0.0
    for count in counter.values():
        if count > 0:
            probability = count / length
            entropy -= probability * math.log2(probability)
    
    return entropy


def is_high_entropy_secret(value: str, context: str = "") -> bool:
    """Determine if a value is likely a high-entropy secret."""
    # Check length
    if len(value) < ENTROPY_CONFIG["min_length"] or len(value) > ENTROPY_CONFIG["max_length"]:
        return False
    
    # Check exclusion patterns
    for pattern in ENTROPY_CONFIG["exclude_patterns"]:
        if re.match(pattern, value, re.IGNORECASE):
            return False
    
    # Calculate entropy
    entropy = calculate_shannon_entropy(value)
    
    # Check context for risk indicators
    context_lower = context.lower()
    for indicator in ENTROPY_CONFIG["context_indicators"]["high_risk"]:
        if re.search(indicator, context_lower):
            # Lower threshold if high-risk context
            return entropy >= (ENTROPY_CONFIG["min_entropy"] - 0.5)
    
    return entropy >= ENTROPY_CONFIG["high_entropy_threshold"]


# =============================================================================
# Binary File Scanning Patterns
# =============================================================================

BINARY_SECRET_PATTERNS = {
    "file_types": [
        ".exe", ".dll", ".so", ".dylib", ".bin", ".dat",
        ".class", ".jar", ".war", ".ear",
        ".pyc", ".pyo", ".pyd",
        ".wasm",
        ".o", ".a", ".lib",
    ],
    "magic_bytes": {
        b'\x7fELF': "ELF Binary",
        b'MZ': "Windows PE/DLL",
        b'\xca\xfe\xba\xbe': "Mach-O (macOS)",
        b'\xfe\xed\xfa\xce': "Mach-O (32-bit)",
        b'\xfe\xed\xfa\xcf': "Mach-O (64-bit)",
        b'PK\x03\x04': "ZIP/JAR Archive",
        b'\x1f\x8b': "GZIP",
        b'BZ': "BZIP2",
    },
    "embedded_patterns": [
        # Embedded URLs/IPs
        (re.compile(rb'https?://[a-zA-Z0-9._/-]+'), 'Embedded URL', 'medium'),
        (re.compile(rb'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+'), 'Embedded IP:Port', 'medium'),
        
        # Embedded credentials
        (re.compile(rb'password[=:]["\']\s*[^\s"\']{8,}', re.IGNORECASE), 'Embedded Password', 'high'),
        (re.compile(rb'api[_-]?key[=:]["\']\s*[A-Za-z0-9]{16,}', re.IGNORECASE), 'Embedded API Key', 'high'),
        (re.compile(rb'secret[=:]["\']\s*[A-Za-z0-9]{16,}', re.IGNORECASE), 'Embedded Secret', 'high'),
        
        # AWS keys in binaries
        (re.compile(rb'AKIA[0-9A-Z]{16}'), 'Embedded AWS Access Key', 'critical'),
        (re.compile(rb'ASIA[0-9A-Z]{16}'), 'Embedded AWS Session Key', 'critical'),
        
        # Private keys embedded
        (re.compile(rb'-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----'), 'Embedded Private Key', 'critical'),
        
        # Connection strings
        (re.compile(rb'mongodb(\+srv)?://[^\s]+'), 'Embedded MongoDB URI', 'high'),
        (re.compile(rb'mysql://[^\s]+'), 'Embedded MySQL URI', 'high'),
        (re.compile(rb'postgres(ql)?://[^\s]+'), 'Embedded PostgreSQL URI', 'high'),
    ],
}


# =============================================================================
# Archive File Scanning Configuration
# =============================================================================

ARCHIVE_CONFIG = {
    "supported_formats": {
        ".zip": "zip",
        ".tar": "tar",
        ".tar.gz": "tar",
        ".tgz": "tar",
        ".tar.bz2": "tar",
        ".tar.xz": "tar",
        ".gz": "gzip",
        ".bz2": "bzip2",
        ".xz": "xz",
        ".7z": "7z",
        ".rar": "rar",
        ".jar": "zip",  # JAR is ZIP format
        ".war": "zip",  # WAR is ZIP format
        ".ear": "zip",  # EAR is ZIP format
        ".apk": "zip",  # APK is ZIP format
        ".ipa": "zip",  # IPA is ZIP format
    },
    "max_depth": 3,  # Maximum archive nesting depth
    "max_size_mb": 100,  # Maximum archive size to scan
    "skip_extensions": [
        ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg",
        ".mp3", ".mp4", ".avi", ".mov", ".wav",
        ".ttf", ".woff", ".woff2", ".eot",
    ],
    "priority_files": [
        # High priority files to scan in archives
        ".env", ".env.local", ".env.production", ".env.development",
        "config.json", "config.yml", "config.yaml", "settings.json",
        "application.properties", "application.yml", "application.yaml",
        "credentials.json", "secrets.json", "credentials.yml",
        ".npmrc", ".pypirc", ".docker/config.json",
        "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
        "*.pem", "*.key", "*.p12", "*.pfx",
    ],
}


# =============================================================================
# Documentation/Metadata Secret Patterns
# =============================================================================

METADATA_SECRET_PATTERNS = [
    # README secret mentions
    (re.compile(r'(?i)(api[_-]?key|secret|token|password)[:\s]+[`"\']([A-Za-z0-9_\-]{16,})[`"\']'), 'Secret in Documentation', 'high'),
    
    # Example secrets that might be real
    (re.compile(r'(?i)example[:\s]+[`"\']?(AKIA[0-9A-Z]{16})[`"\']?'), 'AWS Key in Example', 'high'),
    (re.compile(r'(?i)example[:\s]+[`"\']?(ghp_[A-Za-z0-9]{36})[`"\']?'), 'GitHub Token in Example', 'high'),
    
    # Hardcoded values in comments
    (re.compile(r'#\s*(?:password|secret|key|token)[:\s]+["\']?([^\s"\']{8,})["\']?', re.IGNORECASE), 'Secret in Comment', 'medium'),
    (re.compile(r'//\s*(?:password|secret|key|token)[:\s]+["\']?([^\s"\']{8,})["\']?', re.IGNORECASE), 'Secret in Comment', 'medium'),
    
    # TODO/FIXME with secrets
    (re.compile(r'(?i)(TODO|FIXME|XXX)[:\s].*(?:password|secret|key|token)[:\s]+([^\s]{8,})'), 'Secret in TODO Comment', 'medium'),
    
    # Changelog/History mentions
    (re.compile(r'(?i)(?:added|changed|updated)[:\s]+(?:api[_-]?key|secret|token)[:\s]+[`"\']([A-Za-z0-9_\-]{16,})[`"\']'), 'Secret in Changelog', 'medium'),
]


# =============================================================================
# Serverless/Cloud Function Secret Patterns
# =============================================================================

SERVERLESS_SECRET_PATTERNS = [
    # AWS Lambda
    (re.compile(r'process\.env\.([A-Z_]*(?:SECRET|KEY|TOKEN|PASSWORD|CREDENTIAL)[A-Z_]*)'), 'Lambda Env Secret Reference', 'medium'),
    
    # Azure Functions
    (re.compile(r'Environment\.GetEnvironmentVariable\(["\']([^"\']*(?:Secret|Key|Token|Password)[^"\']*)["\']'), 'Azure Function Secret Reference', 'medium'),
    
    # GCP Cloud Functions
    (re.compile(r'os\.environ\.get\(["\']([^"\']*(?:SECRET|KEY|TOKEN|PASSWORD)[^"\']*)["\']'), 'Cloud Function Env Secret', 'medium'),
    
    # Serverless Framework
    (re.compile(r'\$\{env:([A-Z_]*(?:SECRET|KEY|TOKEN|PASSWORD)[A-Z_]*)\}'), 'Serverless Env Reference', 'low'),
    (re.compile(r'\$\{ssm:/[^}]*(?:secret|key|token|password)[^}]*\}', re.IGNORECASE), 'Serverless SSM Secret', 'medium'),
    
    # SAM templates
    (re.compile(r'!Ref\s+([A-Za-z]*(?:Secret|Key|Token|Password)[A-Za-z]*)'), 'SAM Secret Reference', 'low'),
]


# =============================================================================
# Infrastructure as Code Secret Patterns
# =============================================================================

IAC_SECRET_PATTERNS = [
    # Terraform
    (re.compile(r'variable\s+["\']([^"\']*(?:password|secret|key|token)[^"\']*)["\']', re.IGNORECASE), 'Terraform Secret Variable', 'medium'),
    (re.compile(r'default\s*=\s*["\']([A-Za-z0-9_\-]{16,})["\']'), 'Terraform Hardcoded Default', 'high'),
    (re.compile(r'sensitive\s*=\s*false'), 'Terraform Non-sensitive Secret', 'medium'),
    
    # Ansible
    (re.compile(r'(?:password|secret|key|token):\s*["\']?([^\s"\']{8,})["\']?', re.IGNORECASE), 'Ansible Hardcoded Secret', 'high'),
    (re.compile(r'vault_password_file'), 'Ansible Vault Password File Reference', 'low'),
    
    # Pulumi
    (re.compile(r'pulumi\.Config\(\)\.requireSecret\(["\']([^"\']+)["\']'), 'Pulumi Secret Config', 'low'),
    (re.compile(r'config:([^:]+):secureString'), 'Pulumi Secure String', 'low'),
    
    # CloudFormation
    (re.compile(r'NoEcho:\s*false'), 'CloudFormation Exposed Parameter', 'medium'),
    (re.compile(r'Default:\s*["\']([A-Za-z0-9_\-]{16,})["\']'), 'CloudFormation Hardcoded Default', 'high'),
    
    # Kubernetes manifests
    (re.compile(r'stringData:\s*\n\s+\w+:\s*["\']?([^\s"\']{16,})["\']?'), 'K8s Hardcoded Secret', 'critical'),
]


# =============================================================================
# Message Queue / Event System Secret Patterns
# =============================================================================

MESSAGE_QUEUE_SECRET_PATTERNS = [
    # RabbitMQ
    (re.compile(r'amqp://([^:]+):([^@]+)@'), 'RabbitMQ Credentials', 'high'),
    
    # Kafka
    (re.compile(r'sasl\.password\s*=\s*["\']?([^\s"\']+)["\']?'), 'Kafka SASL Password', 'high'),
    (re.compile(r'ssl\.key\.password\s*=\s*["\']?([^\s"\']+)["\']?'), 'Kafka SSL Key Password', 'high'),
    
    # Redis (with auth)
    (re.compile(r'redis://:[^@]+@'), 'Redis Auth Password', 'high'),
    (re.compile(r'REDIS_PASSWORD\s*=\s*["\']?([^\s"\']+)["\']?'), 'Redis Password Env', 'high'),
    
    # Apache Pulsar
    (re.compile(r'authParams.*token["\']:\s*["\']([^"\']+)["\']'), 'Pulsar Auth Token', 'high'),
    
    # NATS
    (re.compile(r'nats://([^:]+):([^@]+)@'), 'NATS Credentials', 'high'),
    
    # AWS SQS/SNS
    (re.compile(r'sqs\.[a-z-]+\.amazonaws\.com/\d+/[a-zA-Z0-9_-]+'), 'AWS SQS Queue URL', 'low'),
]


# =============================================================================
# Payment/Financial API Patterns
# =============================================================================

PAYMENT_SECRET_PATTERNS = [
    # Stripe (extended)
    (re.compile(r'sk_test_[0-9a-zA-Z]{24,}'), 'Stripe Test Secret Key', 'medium'),
    (re.compile(r'rk_live_[0-9a-zA-Z]{24,}'), 'Stripe Restricted Key (Live)', 'critical'),
    (re.compile(r'rk_test_[0-9a-zA-Z]{24,}'), 'Stripe Restricted Key (Test)', 'medium'),
    (re.compile(r'whsec_[0-9a-zA-Z]{24,}'), 'Stripe Webhook Secret', 'high'),
    
    # PayPal
    (re.compile(r'access_token\$production\$[a-z0-9]{32}'), 'PayPal Production Token', 'critical'),
    (re.compile(r'access_token\$sandbox\$[a-z0-9]{32}'), 'PayPal Sandbox Token', 'medium'),
    
    # Square
    (re.compile(r'sq0csp-[0-9A-Za-z\-_]{43}'), 'Square OAuth Secret', 'critical'),
    
    # Adyen
    (re.compile(r'AQE[a-zA-Z0-9]{30,}'), 'Adyen API Key', 'critical'),
    
    # Braintree
    (re.compile(r'[a-f0-9]{32}'), 'Braintree Merchant ID (potential)', 'low'),
    
    # Coinbase
    (re.compile(r'[a-f0-9]{64}'), 'Coinbase API Secret (potential)', 'medium'),
]


# =============================================================================
# Live Memory Scanning Patterns (Binary/Bytes)
# =============================================================================
# These patterns are optimized for scanning raw process memory.
# They use bytes patterns (rb'...') for direct memory matching.

MEMORY_SECRET_PATTERNS = {
    # =========================================================================
    # Cloud Providers
    # =========================================================================
    "aws_access_key": {
        "pattern": rb'AKIA[0-9A-Z]{16}',
        "type": "AWS Access Key ID",
        "severity": "critical",
        "description": "AWS IAM access key found in memory",
    },
    "aws_secret_key": {
        "pattern": rb'(?:aws_secret_access_key|AWS_SECRET_ACCESS_KEY)["\s:=]+([A-Za-z0-9/+=]{40})',
        "type": "AWS Secret Access Key",
        "severity": "critical",
        "description": "AWS secret access key - immediate rotation required",
    },
    "aws_session_token": {
        "pattern": rb'(?:aws_session_token|AWS_SESSION_TOKEN)["\s:=]+([A-Za-z0-9/+=]{100,})',
        "type": "AWS Session Token",
        "severity": "critical",
        "description": "AWS temporary session token",
    },
    "gcp_api_key": {
        "pattern": rb'AIza[0-9A-Za-z\-_]{35}',
        "type": "GCP API Key",
        "severity": "high",
        "description": "Google Cloud Platform API key",
    },
    "gcp_service_account": {
        "pattern": rb'"type":\s*"service_account"[^}]+?"private_key"',
        "type": "GCP Service Account JSON",
        "severity": "critical",
        "description": "GCP service account with private key",
    },
    "azure_connection_string": {
        "pattern": rb'DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[A-Za-z0-9/+=]+',
        "type": "Azure Storage Connection String",
        "severity": "critical",
        "description": "Azure Storage connection string with key",
    },
    "azure_client_secret": {
        "pattern": rb'(?:AZURE_CLIENT_SECRET|azure_client_secret)["\s:=]+([A-Za-z0-9\-_.~]{34,})',
        "type": "Azure Client Secret",
        "severity": "critical",
        "description": "Azure AD client secret",
    },
    
    # =========================================================================
    # Git Platforms
    # =========================================================================
    "github_pat": {
        "pattern": rb'ghp_[0-9a-zA-Z]{36}',
        "type": "GitHub Personal Access Token",
        "severity": "high",
        "description": "GitHub PAT - can access repositories",
    },
    "github_oauth": {
        "pattern": rb'gho_[0-9a-zA-Z]{36}',
        "type": "GitHub OAuth Token",
        "severity": "high",
        "description": "GitHub OAuth access token",
    },
    "github_app_token": {
        "pattern": rb'ghu_[0-9a-zA-Z]{36}',
        "type": "GitHub App User Token",
        "severity": "high",
        "description": "GitHub App user-to-server token",
    },
    "github_refresh_token": {
        "pattern": rb'ghr_[0-9a-zA-Z]{36}',
        "type": "GitHub Refresh Token",
        "severity": "high",
        "description": "GitHub refresh token",
    },
    "gitlab_pat": {
        "pattern": rb'glpat-[0-9a-zA-Z\-_]{20}',
        "type": "GitLab Personal Access Token",
        "severity": "high",
        "description": "GitLab PAT",
    },
    "gitlab_runner_token": {
        "pattern": rb'GR1348941[0-9a-zA-Z\-_]{20}',
        "type": "GitLab Runner Token",
        "severity": "high",
        "description": "GitLab CI runner registration token",
    },
    "bitbucket_token": {
        "pattern": rb'ATBB[0-9a-zA-Z]{32}',
        "type": "Bitbucket App Token",
        "severity": "high",
        "description": "Bitbucket app password or token",
    },
    
    # =========================================================================
    # Payment & Finance
    # =========================================================================
    "stripe_secret_live": {
        "pattern": rb'sk_live_[0-9a-zA-Z]{24,}',
        "type": "Stripe Live Secret Key",
        "severity": "critical",
        "description": "Stripe LIVE secret key - can charge real cards!",
    },
    "stripe_secret_test": {
        "pattern": rb'sk_test_[0-9a-zA-Z]{24,}',
        "type": "Stripe Test Secret Key",
        "severity": "medium",
        "description": "Stripe test secret key",
    },
    "stripe_restricted": {
        "pattern": rb'rk_live_[0-9a-zA-Z]{24,}',
        "type": "Stripe Restricted Key",
        "severity": "high",
        "description": "Stripe restricted API key",
    },
    "stripe_webhook": {
        "pattern": rb'whsec_[0-9a-zA-Z]{24,}',
        "type": "Stripe Webhook Secret",
        "severity": "high",
        "description": "Stripe webhook signing secret",
    },
    "paypal_token": {
        "pattern": rb'access_token\$production\$[a-z0-9]{16}\$[a-f0-9]{32}',
        "type": "PayPal Access Token",
        "severity": "critical",
        "description": "PayPal production access token",
    },
    "square_access_token": {
        "pattern": rb'sq0atp-[0-9A-Za-z\-_]{22}',
        "type": "Square Access Token",
        "severity": "critical",
        "description": "Square payment access token",
    },
    
    # =========================================================================
    # Communication
    # =========================================================================
    "slack_token": {
        "pattern": rb'xox[baprs]-[0-9a-zA-Z\-]{10,}',
        "type": "Slack Token",
        "severity": "high",
        "description": "Slack bot/app/user token",
    },
    "slack_webhook": {
        "pattern": rb'https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+',
        "type": "Slack Webhook URL",
        "severity": "medium",
        "description": "Slack incoming webhook URL",
    },
    "discord_webhook": {
        "pattern": rb'https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_-]+',
        "type": "Discord Webhook",
        "severity": "medium",
        "description": "Discord webhook URL",
    },
    "discord_token": {
        "pattern": rb'[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27}',
        "type": "Discord Bot Token",
        "severity": "high",
        "description": "Discord bot authentication token",
    },
    "telegram_token": {
        "pattern": rb'\d{8,10}:[A-Za-z0-9_-]{35}',
        "type": "Telegram Bot Token",
        "severity": "high",
        "description": "Telegram bot API token",
    },
    "twilio_api_key": {
        "pattern": rb'SK[a-f0-9]{32}',
        "type": "Twilio API Key",
        "severity": "high",
        "description": "Twilio API key",
    },
    "sendgrid_api_key": {
        "pattern": rb'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}',
        "type": "SendGrid API Key",
        "severity": "high",
        "description": "SendGrid email API key",
    },
    
    # =========================================================================
    # Databases
    # =========================================================================
    "postgres_url": {
        "pattern": rb'postgres(?:ql)?://[^:]+:[^@]+@[^/\s]+/\w+',
        "type": "PostgreSQL Connection URL",
        "severity": "critical",
        "description": "PostgreSQL connection string with credentials",
    },
    "mysql_url": {
        "pattern": rb'mysql://[^:]+:[^@]+@[^/\s]+/\w+',
        "type": "MySQL Connection URL",
        "severity": "critical",
        "description": "MySQL connection string with credentials",
    },
    "mongodb_url": {
        "pattern": rb'mongodb(?:\+srv)?://[^:]+:[^@]+@[^\s]+',
        "type": "MongoDB Connection URL",
        "severity": "critical",
        "description": "MongoDB connection string with credentials",
    },
    "redis_url": {
        "pattern": rb'redis://[^:]*:[^@]+@[^/\s]+',
        "type": "Redis Connection URL",
        "severity": "high",
        "description": "Redis connection string with password",
    },
    "elasticsearch_url": {
        "pattern": rb'https?://[^:]+:[^@]+@[^/\s]*elastic[^/\s]*',
        "type": "Elasticsearch URL with Credentials",
        "severity": "high",
        "description": "Elasticsearch URL with authentication",
    },
    
    # =========================================================================
    # Authentication Tokens
    # =========================================================================
    "jwt_token": {
        "pattern": rb'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+',
        "type": "JWT Token",
        "severity": "high",
        "description": "JSON Web Token - may contain sensitive claims",
    },
    "bearer_token": {
        "pattern": rb'[Bb]earer\s+([A-Za-z0-9_-]{20,})',
        "type": "Bearer Token",
        "severity": "high",
        "description": "Bearer authentication token",
    },
    "basic_auth": {
        "pattern": rb'[Bb]asic\s+([A-Za-z0-9+/=]{20,})',
        "type": "Basic Auth Credentials",
        "severity": "high",
        "description": "Base64-encoded Basic Auth credentials",
    },
    
    # =========================================================================
    # Private Keys
    # =========================================================================
    "rsa_private_key": {
        "pattern": rb'-----BEGIN RSA PRIVATE KEY-----',
        "type": "RSA Private Key",
        "severity": "critical",
        "description": "RSA private key - IMMEDIATE ACTION REQUIRED",
    },
    "openssh_private_key": {
        "pattern": rb'-----BEGIN OPENSSH PRIVATE KEY-----',
        "type": "OpenSSH Private Key",
        "severity": "critical",
        "description": "OpenSSH private key",
    },
    "ec_private_key": {
        "pattern": rb'-----BEGIN EC PRIVATE KEY-----',
        "type": "EC Private Key",
        "severity": "critical",
        "description": "Elliptic Curve private key",
    },
    "pgp_private_key": {
        "pattern": rb'-----BEGIN PGP PRIVATE KEY BLOCK-----',
        "type": "PGP Private Key",
        "severity": "critical",
        "description": "PGP/GPG private key",
    },
    "pkcs8_private_key": {
        "pattern": rb'-----BEGIN PRIVATE KEY-----',
        "type": "PKCS#8 Private Key",
        "severity": "critical",
        "description": "PKCS#8 format private key",
    },
    "encrypted_private_key": {
        "pattern": rb'-----BEGIN ENCRYPTED PRIVATE KEY-----',
        "type": "Encrypted Private Key",
        "severity": "high",
        "description": "Encrypted private key (password-protected)",
    },
    
    # =========================================================================
    # Kubernetes & Container
    # =========================================================================
    "k8s_service_account_token": {
        "pattern": rb'eyJhbGciOiJSUzI1NiIsImtpZCI6[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
        "type": "Kubernetes Service Account Token",
        "severity": "critical",
        "description": "K8s SA token - can access cluster resources",
    },
    "docker_auth": {
        "pattern": rb'"auth"\s*:\s*"([A-Za-z0-9+/=]{20,})"',
        "type": "Docker Registry Auth",
        "severity": "high",
        "description": "Docker registry authentication",
    },
    "k8s_kubeconfig_token": {
        "pattern": rb'token:\s*([A-Za-z0-9_-]{20,})',
        "type": "Kubernetes Kubeconfig Token",
        "severity": "critical",
        "description": "Token from kubeconfig file",
    },
    
    # =========================================================================
    # AI/ML APIs
    # =========================================================================
    "openai_api_key": {
        "pattern": rb'sk-[A-Za-z0-9]{48}',
        "type": "OpenAI API Key",
        "severity": "critical",
        "description": "OpenAI API key - can incur charges",
    },
    "openai_project_key": {
        "pattern": rb'sk-proj-[A-Za-z0-9_-]{48,}',
        "type": "OpenAI Project API Key",
        "severity": "critical",
        "description": "OpenAI project-scoped API key",
    },
    "anthropic_api_key": {
        "pattern": rb'sk-ant-api[0-9]{2}-[A-Za-z0-9_-]{86,}',
        "type": "Anthropic API Key",
        "severity": "critical",
        "description": "Anthropic Claude API key",
    },
    "huggingface_token": {
        "pattern": rb'hf_[A-Za-z0-9]{34,}',
        "type": "Hugging Face Token",
        "severity": "high",
        "description": "Hugging Face API token",
    },
    "replicate_token": {
        "pattern": rb'r8_[A-Za-z0-9]{37}',
        "type": "Replicate API Token",
        "severity": "high",
        "description": "Replicate ML platform token",
    },
    "groq_api_key": {
        "pattern": rb'gsk_[A-Za-z0-9]{52}',
        "type": "Groq API Key",
        "severity": "critical",
        "description": "Groq LLM API key",
    },
    "langsmith_key": {
        "pattern": rb'ls__[A-Za-z0-9]{32,}',
        "type": "LangSmith API Key",
        "severity": "high",
        "description": "LangChain/LangSmith API key",
    },
    
    # =========================================================================
    # Cryptocurrency
    # =========================================================================
    "bitcoin_wif": {
        "pattern": rb'[5KL][1-9A-HJ-NP-Za-km-z]{50,51}',
        "type": "Bitcoin Private Key (WIF)",
        "severity": "critical",
        "description": "Bitcoin wallet private key - FUNDS AT RISK",
    },
    "ethereum_private_key": {
        "pattern": rb'(?:0x)?[a-fA-F0-9]{64}',
        "type": "Ethereum Private Key (potential)",
        "severity": "high",
        "description": "Potential Ethereum private key",
    },
    
    # =========================================================================
    # Generic Patterns
    # =========================================================================
    "generic_api_key": {
        "pattern": rb'(?:api[_-]?key|apikey|api_secret)["\s:=]+["\']?([a-zA-Z0-9\-_]{20,})["\']?',
        "type": "Generic API Key",
        "severity": "medium",
        "description": "Generic API key pattern",
    },
    "generic_password": {
        "pattern": rb'(?:password|passwd|pwd|pass)["\s:=]+["\']?([^\s"\']{8,64})["\']?',
        "type": "Password in Memory",
        "severity": "high",
        "description": "Password value in memory",
    },
    "generic_secret": {
        "pattern": rb'(?:secret|token|credential)["\s:=]+["\']?([a-zA-Z0-9\-_]{16,})["\']?',
        "type": "Generic Secret/Token",
        "severity": "medium",
        "description": "Generic secret or token",
    },
    "private_key_data": {
        "pattern": rb'PRIVATE[_\s]KEY["\s:=]+["\']?([A-Za-z0-9+/=\n]{50,})["\']?',
        "type": "Private Key Data",
        "severity": "critical",
        "description": "Private key content in memory",
    },
}


# Severity to numeric score mapping for memory secrets
MEMORY_SEVERITY_SCORES = {
    "critical": 10,
    "high": 8,
    "medium": 5,
    "low": 2,
    "info": 1,
}


# =============================================================================
# All Pattern Groups for Easy Import
# =============================================================================

ALL_SECRET_PATTERN_GROUPS = {
    "trufflehog": TRUFFLEHOG_PATTERNS,
    "kubernetes": KUBERNETES_SECRET_PATTERNS,
    "cicd": CICD_SECRET_PATTERNS,
    "docker": DOCKER_SECRET_PATTERNS,
    "ai_ml": AI_ML_SECRET_PATTERNS,
    "cloud_extended": CLOUD_EXTENDED_PATTERNS,
    "metadata": METADATA_SECRET_PATTERNS,
    "serverless": SERVERLESS_SECRET_PATTERNS,
    "iac": IAC_SECRET_PATTERNS,
    "message_queue": MESSAGE_QUEUE_SECRET_PATTERNS,
    "payment": PAYMENT_SECRET_PATTERNS,
    "memory": MEMORY_SECRET_PATTERNS,  # Added memory patterns
}

