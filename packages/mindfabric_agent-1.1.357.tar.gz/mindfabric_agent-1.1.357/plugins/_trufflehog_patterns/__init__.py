"""
Internal pattern pack (not a discoverable plugin).

ExecutorRegistry ignores package names starting with underscore.
"""

from .line_scan import scan_line_for_secrets
from .patterns import TRUFFLEHOG_PATTERNS

__all__ = ["TRUFFLEHOG_PATTERNS", "scan_line_for_secrets"]
