"""
Plugin for security analysis and vulnerability detection in automated deployment (CI/CD) pipelines.
- Detect misconfigurations in CI/CD configuration files
- Analyze excessive privileges and service account permissions
- Scan for secret leaks in environment variables and configs
- Test isolation between pipeline stages and projects
- Simulate malicious code injection to validate defenses
"""
from .cicd_pipeline_auditor import CICDPipelineAuditorPlugin