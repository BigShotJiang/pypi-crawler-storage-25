"""
Response Helper Module

Provides WebSocket response utilities.
"""

from datetime import datetime
from utils.logger import logger
from plugins.plugin_helpers import handle_partial


class ResponseHelper:
    """Helper for sending responses via WebSocket"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def send_result(self, result):
        """Sends the command execution result via WebSocket."""
        if not result:
            await self.send_error("Empty execution result")
            return
            
        status = result.get("status", "failed")
        response_data = {
            "type": "command_result",
            "data": {
                "agent_id": self.plugin.agent_id,
                "command_id": self.plugin.command_id,
                "status": status,
                "result": result.get("result", {}) if status == "success" else None
            }
        }
        
        if status != "success":
            response_data["data"]["errors"] = result.get("errors", ["Unknown error"])
            
        if status == "in_progress":
            response_data["data"]["progress"] = result.get("progress", 0)
            
        logger.info(f"Command result: {response_data}")
        logger.info(f"Result sent for command {self.plugin.command_id}: {status}")
    
    async def send_error(self, error_message):
        """Sends an error message via WebSocket."""
        response_data = {
            "type": "command_result",
            "data": {
                "agent_id": self.plugin.agent_id,
                "command_id": self.plugin.command_id,
                "status": "failed",
                "errors": [error_message]
            }
        }
        logger.info(f"Command result: {response_data}")
        logger.error(f"Error executing command {self.plugin.command_id}: {error_message}")
    
    async def send_progress_update(self, scan_id, progress, message):
        """Sends progress update."""
        update_data = {
            "type": "command_progress",
            "data": {
                "agent_id": self.plugin.agent_id,
                "command_id": self.plugin.command_id,
                "scan_id": scan_id,
                "progress": progress,
                "message": message,
                "timestamp": datetime.now().isoformat()
            }
        }
        await handle_partial(
            self.plugin.command_id, 
            update_data.get("progress", 0), 
            self.plugin.ws, 
            update_data.get("output")
        )
        logger.debug(f"Progress for {scan_id}: {progress}% - {message}")

