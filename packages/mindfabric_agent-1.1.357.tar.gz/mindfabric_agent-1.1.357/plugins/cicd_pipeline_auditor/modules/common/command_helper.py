"""
Command Helper Module

Provides shell command execution utilities.
"""


class CommandHelper:
    """Helper for executing shell commands"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def run_shell_command(self, cmd, **kwargs):
        """Helper method to run shell commands using shell_executor."""
        return self.plugin.shell_executor.run_sync(cmd, **kwargs)
    
    async def run_shell_command_async(self, cmd, **kwargs):
        """Helper method to run shell commands asynchronously."""
        return await self.plugin.shell_executor.run(cmd, **kwargs)

