"""
CICD Pipeline Auditor Modules

Modular architecture for CI/CD pipeline security auditing.
"""

