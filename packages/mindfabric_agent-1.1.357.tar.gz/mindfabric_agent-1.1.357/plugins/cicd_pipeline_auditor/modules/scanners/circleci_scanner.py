"""
CircleCI Scanner Module
"""

import os
import glob
import yaml
import hashlib
from datetime import datetime
from typing import Dict, Any
from ...proto import ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
from utils.logger import logger


class CircleCIScanner:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        from ..analyzers.circleci_analyzer import CircleCIAnalyzer
        self.analyzer = CircleCIAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        results = {
            "config_files": [], "environments": [], "iam_permissions": [],
            "secrets": [], "isolation_issues": [], "injection_vectors": [],
            "vulnerabilities": [], "workflow_permissions": []
        }
        
        patterns = [".circleci/config.yml", ".circleci/config.yaml"]
        
        for repo_path in scan_options.repo_paths:
            for pattern in patterns:
                config_files = glob.glob(os.path.join(repo_path, pattern))
                
                for config_file in config_files:
                    try:
                        with open(config_file, 'r') as f:
                            config_content = f.read()
                        
                        config_data = yaml.safe_load(config_content)
                        
                        config_obj = ConfigurationFile(
                            path=config_file, platform=CICDPlatform.CIRCLECI,
                            content=config_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(config_file)),
                            file_size=len(config_content.encode()),
                            file_hash=hashlib.sha256(config_content.encode()).hexdigest(),
                            config_type=ConfigurationType.CIRCLECI_CONFIG,
                            has_secrets=self.secret_scanner.check_for_secrets(config_content),
                            has_privilege_issues=self.analyzer.check_circleci_privileges(config_data),
                            has_security_issues=True
                        )
                        
                        results["config_files"].append(config_obj)
                        results["vulnerabilities"].extend(self.analyzer.analyze_config(config_file, config_data))
                        results["secrets"].extend(self.secret_scanner.scan_secrets_in_content(
                            config_content, config_file, CICDPlatform.CIRCLECI))
                        
                    except Exception as e:
                        logger.error(f"Error analyzing CircleCI config {config_file}: {str(e)}")
        
        return results

