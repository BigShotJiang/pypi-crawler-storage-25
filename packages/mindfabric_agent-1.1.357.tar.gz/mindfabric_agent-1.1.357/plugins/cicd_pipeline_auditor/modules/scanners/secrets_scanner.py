"""
Pipeline Secrets Scanner

Scans CI/CD pipelines for secret-related security issues:
- Secret rotation verification
- Secret scanning in logs/artifacts
- Hardcoded secrets in pipelines
- Environment variable exposure
- Secret management misconfigurations
- OIDC/keyless authentication analysis

MITRE ATT&CK:
- T1552.001: Unsecured Credentials: Credentials In Files
- T1552.004: Unsecured Credentials: Private Keys
- T1528: Steal Application Access Token
"""

import re
import base64
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class SecretType(str, Enum):
    """Types of secrets detected."""
    API_KEY = "api_key"
    ACCESS_TOKEN = "access_token"
    PASSWORD = "password"
    PRIVATE_KEY = "private_key"
    AWS_CREDENTIALS = "aws_credentials"
    GCP_CREDENTIALS = "gcp_credentials"
    AZURE_CREDENTIALS = "azure_credentials"
    DATABASE_URL = "database_url"
    ENCRYPTION_KEY = "encryption_key"
    JWT_SECRET = "jwt_secret"
    SSH_KEY = "ssh_key"
    OAUTH_SECRET = "oauth_secret"
    WEBHOOK_SECRET = "webhook_secret"


class Severity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


# =============================================================================
# Secret Detection Patterns
# =============================================================================

SECRET_PATTERNS = {
    "aws_access_key": {
        "pattern": r"(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}",
        "type": SecretType.AWS_CREDENTIALS,
        "severity": Severity.CRITICAL,
        "description": "AWS Access Key ID",
    },
    "aws_secret_key": {
        "pattern": r"(?:aws_secret_access_key|aws_secret_key)\s*[=:]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?",
        "type": SecretType.AWS_CREDENTIALS,
        "severity": Severity.CRITICAL,
        "description": "AWS Secret Access Key",
    },
    "gcp_service_account": {
        "pattern": r'"type"\s*:\s*"service_account"',
        "type": SecretType.GCP_CREDENTIALS,
        "severity": Severity.CRITICAL,
        "description": "GCP Service Account JSON",
    },
    "azure_client_secret": {
        "pattern": r"(?:AZURE_CLIENT_SECRET|client_secret)\s*[=:]\s*['\"]?([A-Za-z0-9~_.-]{34,})['\"]?",
        "type": SecretType.AZURE_CREDENTIALS,
        "severity": Severity.CRITICAL,
        "description": "Azure Client Secret",
    },
    "github_token": {
        "pattern": r"(?:ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9]{22}_[A-Za-z0-9]{59}|gho_[A-Za-z0-9]{36}|ghu_[A-Za-z0-9]{36}|ghs_[A-Za-z0-9]{36}|ghr_[A-Za-z0-9]{36})",
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.CRITICAL,
        "description": "GitHub Token",
    },
    "gitlab_token": {
        "pattern": r"glpat-[A-Za-z0-9\-]{20}",
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.CRITICAL,
        "description": "GitLab Personal Access Token",
    },
    "npm_token": {
        "pattern": r"npm_[A-Za-z0-9]{36}",
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.HIGH,
        "description": "NPM Access Token",
    },
    "pypi_token": {
        "pattern": r"pypi-[A-Za-z0-9]{32,}",
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.HIGH,
        "description": "PyPI API Token",
    },
    "slack_token": {
        "pattern": r"xox[baprs]-[0-9]+-[0-9]+-[A-Za-z0-9]+",
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.HIGH,
        "description": "Slack Token",
    },
    "private_key": {
        "pattern": r"-----BEGIN (?:RSA |OPENSSH |DSA |EC )?PRIVATE KEY-----",
        "type": SecretType.PRIVATE_KEY,
        "severity": Severity.CRITICAL,
        "description": "Private Key",
    },
    "jwt_secret": {
        "pattern": r"(?:jwt_secret|jwt_key|secret_key)\s*[=:]\s*['\"]([^'\"]{16,})['\"]",
        "type": SecretType.JWT_SECRET,
        "severity": Severity.HIGH,
        "description": "JWT Secret Key",
    },
    "generic_api_key": {
        "pattern": r"(?:api[_-]?key|apikey)\s*[=:]\s*['\"]?([A-Za-z0-9_-]{20,})['\"]?",
        "type": SecretType.API_KEY,
        "severity": Severity.HIGH,
        "description": "Generic API Key",
    },
    "generic_password": {
        "pattern": r"(?:password|passwd|pwd)\s*[=:]\s*['\"]([^'\"]{8,})['\"]",
        "type": SecretType.PASSWORD,
        "severity": Severity.HIGH,
        "description": "Password",
    },
    "database_url": {
        "pattern": r"(?:postgres|mysql|mongodb)://[^:]+:[^@]+@[^\s]+",
        "type": SecretType.DATABASE_URL,
        "severity": Severity.CRITICAL,
        "description": "Database Connection URL with Credentials",
    },
    "docker_registry_auth": {
        "pattern": r'"auth"\s*:\s*"([A-Za-z0-9+/=]{20,})"',
        "type": SecretType.ACCESS_TOKEN,
        "severity": Severity.HIGH,
        "description": "Docker Registry Auth Token",
    },
}


# =============================================================================
# Secret Rotation Best Practices
# =============================================================================

SECRET_ROTATION_GUIDELINES = {
    "api_keys": {
        "recommended_rotation": "90 days",
        "max_lifetime": "180 days",
        "auto_rotation_supported": True,
    },
    "access_tokens": {
        "recommended_rotation": "30 days",
        "max_lifetime": "90 days",
        "short_lived_preferred": True,
    },
    "service_account_keys": {
        "recommended_rotation": "90 days",
        "max_lifetime": "365 days",
        "use_oidc_preferred": True,
    },
    "ssh_keys": {
        "recommended_rotation": "365 days",
        "use_certificates_preferred": True,
    },
    "database_credentials": {
        "recommended_rotation": "90 days",
        "use_iam_auth_preferred": True,
    },
}


# =============================================================================
# OIDC/Keyless Authentication Patterns
# =============================================================================

OIDC_PATTERNS = {
    "github_oidc": {
        "name": "GitHub OIDC",
        "indicators": ["id-token: write", "aws-actions/configure-aws-credentials", "google-github-actions/auth"],
        "security_benefit": "No long-lived credentials",
    },
    "gitlab_oidc": {
        "name": "GitLab OIDC",
        "indicators": ["CI_JOB_JWT_V2", "OIDC_TOKEN", "id_tokens"],
        "security_benefit": "Short-lived tokens",
    },
    "sigstore_keyless": {
        "name": "Sigstore Keyless Signing",
        "indicators": ["cosign sign", "--oidc-issuer", "SIGSTORE_"],
        "security_benefit": "No signing key management",
    },
}


@dataclass
class SecretFinding:
    """A secret-related finding."""
    secret_type: SecretType
    severity: Severity
    description: str
    location: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class SecretRotationFinding:
    """Finding related to secret rotation."""
    secret_name: str
    current_age_days: Optional[int] = None
    recommended_age_days: int = 90
    rotation_status: str = "unknown"
    remediation: str = ""


class SecretsScanner:
    """Scanner for CI/CD pipeline secrets."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[SecretFinding] = []
        self.rotation_findings: List[SecretRotationFinding] = []
    
    def scan_content_for_secrets(
        self,
        content: str,
        source: str = "unknown",
    ) -> List[SecretFinding]:
        """
        Scan content for exposed secrets.
        
        Args:
            content: Content to scan
            source: Source identifier (e.g., file path)
            
        Returns:
            List of secret findings
        """
        findings = []
        
        for pattern_name, pattern_info in SECRET_PATTERNS.items():
            matches = re.finditer(pattern_info["pattern"], content, re.IGNORECASE)
            
            for match in matches:
                # Mask the secret in evidence
                matched_text = match.group(0)
                masked = self._mask_secret(matched_text)
                
                findings.append(SecretFinding(
                    secret_type=pattern_info["type"],
                    severity=pattern_info["severity"],
                    description=f"Found {pattern_info['description']} in {source}",
                    location=source,
                    evidence={
                        "pattern": pattern_name,
                        "masked_value": masked,
                        "line_number": content[:match.start()].count('\n') + 1,
                    },
                    remediation=f"Remove {pattern_info['description']} from source; use secret management",
                    mitre_technique="T1552.001",
                ))
        
        return findings
    
    def scan_pipeline_config(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> List[SecretFinding]:
        """
        Scan pipeline configuration for secret issues.
        
        Args:
            config: Pipeline configuration dict
            platform: CI/CD platform name
            
        Returns:
            List of findings
        """
        findings = []
        
        # Convert config to string for pattern matching
        config_str = str(config)
        
        # Scan for exposed secrets
        secret_findings = self.scan_content_for_secrets(config_str, f"{platform}_config")
        findings.extend(secret_findings)
        
        # Check for insecure secret references
        insecure_refs = self._check_insecure_secret_refs(config, platform)
        findings.extend(insecure_refs)
        
        # Check for env var exposure
        env_findings = self._check_env_exposure(config, platform)
        findings.extend(env_findings)
        
        return findings
    
    def scan_pipeline_logs(
        self,
        log_content: str,
        source: str = "pipeline_log",
    ) -> List[SecretFinding]:
        """
        Scan pipeline logs for leaked secrets.
        
        Args:
            log_content: Pipeline log content
            source: Log source identifier
            
        Returns:
            List of findings
        """
        findings = []
        
        # Scan for secrets in logs
        secret_findings = self.scan_content_for_secrets(log_content, source)
        
        # Add context about log exposure risk
        for finding in secret_findings:
            finding.severity = Severity.CRITICAL  # Secrets in logs are critical
            finding.description += " (exposed in pipeline logs)"
            finding.remediation = "Enable secret masking; review log output; rotate exposed credentials"
        
        findings.extend(secret_findings)
        
        return findings
    
    def check_secret_rotation(
        self,
        secrets_inventory: List[Dict[str, Any]],
    ) -> List[SecretRotationFinding]:
        """
        Check secret rotation status.
        
        Args:
            secrets_inventory: List of secrets with metadata
            
        Returns:
            List of rotation findings
        """
        findings = []
        
        for secret in secrets_inventory:
            name = secret.get("name", "unknown")
            created_at = secret.get("created_at")
            last_rotated = secret.get("last_rotated")
            secret_type = secret.get("type", "generic")
            
            # Get guidelines for this type
            guidelines = SECRET_ROTATION_GUIDELINES.get(
                secret_type,
                {"recommended_rotation": "90 days", "max_lifetime": "180 days"}
            )
            
            recommended_days = int(guidelines["recommended_rotation"].split()[0])
            max_days = int(guidelines["max_lifetime"].split()[0])
            
            # Calculate age
            age_days = None
            if last_rotated:
                # Would calculate from timestamp
                pass
            elif created_at:
                # Would calculate from timestamp
                pass
            
            # Determine status
            status = "unknown"
            if age_days:
                if age_days > max_days:
                    status = "expired"
                elif age_days > recommended_days:
                    status = "needs_rotation"
                else:
                    status = "healthy"
            
            findings.append(SecretRotationFinding(
                secret_name=name,
                current_age_days=age_days,
                recommended_age_days=recommended_days,
                rotation_status=status,
                remediation=f"Rotate secret; recommended interval: {guidelines['recommended_rotation']}",
            ))
        
        self.rotation_findings = findings
        return findings
    
    def check_oidc_usage(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> Dict[str, Any]:
        """
        Check for OIDC/keyless authentication usage.
        
        Args:
            config: Pipeline configuration
            platform: CI/CD platform
            
        Returns:
            Dict with OIDC analysis
        """
        result = {
            "oidc_detected": False,
            "oidc_providers": [],
            "recommendations": [],
        }
        
        config_str = str(config)
        
        for oidc_name, oidc_info in OIDC_PATTERNS.items():
            for indicator in oidc_info["indicators"]:
                if indicator in config_str:
                    result["oidc_detected"] = True
                    result["oidc_providers"].append({
                        "name": oidc_info["name"],
                        "indicator": indicator,
                        "benefit": oidc_info["security_benefit"],
                    })
                    break
        
        # Add recommendations if OIDC not detected
        if not result["oidc_detected"]:
            if platform == "github":
                result["recommendations"].append({
                    "recommendation": "Use GitHub OIDC for cloud authentication",
                    "example": """permissions:
  id-token: write
  contents: read
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::ACCOUNT:role/ROLE
    aws-region: us-east-1""",
                })
            elif platform == "gitlab":
                result["recommendations"].append({
                    "recommendation": "Use GitLab OIDC for cloud authentication",
                    "example": """id_tokens:
  GITLAB_OIDC_TOKEN:
    aud: https://gitlab.com""",
                })
        
        return result
    
    def analyze_secrets_management(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> Dict[str, Any]:
        """
        Analyze secrets management practices.
        
        Args:
            config: Pipeline configuration
            platform: CI/CD platform
            
        Returns:
            Dict with analysis results
        """
        result = {
            "practices": {
                "uses_vault": False,
                "uses_cloud_secrets": False,
                "uses_env_vars": False,
                "uses_files": False,
            },
            "security_score": 0,
            "recommendations": [],
        }
        
        config_str = str(config).lower()
        
        # Check for secret management tools
        if "hashicorp/vault" in config_str or "vault_" in config_str:
            result["practices"]["uses_vault"] = True
            result["security_score"] += 30
        
        if "aws secretsmanager" in config_str or "sm://" in config_str:
            result["practices"]["uses_cloud_secrets"] = True
            result["security_score"] += 25
        
        if "gcp secrets" in config_str or "secret-manager" in config_str:
            result["practices"]["uses_cloud_secrets"] = True
            result["security_score"] += 25
        
        if "azure keyvault" in config_str or "keyvault" in config_str:
            result["practices"]["uses_cloud_secrets"] = True
            result["security_score"] += 25
        
        # Check for env vars (common but less secure)
        env_patterns = ["${{ secrets.", "env:", "environment:"]
        for pattern in env_patterns:
            if pattern in config_str:
                result["practices"]["uses_env_vars"] = True
                result["security_score"] += 10
                break
        
        # Check for file-based secrets (less secure)
        file_patterns = [".env", "credentials", "secrets.yaml", "secrets.json"]
        for pattern in file_patterns:
            if pattern in config_str:
                result["practices"]["uses_files"] = True
                result["security_score"] -= 10
                result["recommendations"].append(
                    f"Avoid file-based secrets ({pattern}); use secret management tools"
                )
                break
        
        # Generate recommendations
        if not result["practices"]["uses_vault"] and not result["practices"]["uses_cloud_secrets"]:
            result["recommendations"].append(
                "Consider using dedicated secret management (Vault, AWS Secrets Manager, etc.)"
            )
        
        if result["security_score"] < 30:
            result["recommendations"].append(
                "Improve secrets management practices; current score indicates weak security"
            )
        
        return result
    
    def generate_secret_audit_report(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> Dict[str, Any]:
        """
        Generate comprehensive secret audit report.
        
        Args:
            config: Pipeline configuration
            platform: CI/CD platform
            
        Returns:
            Comprehensive audit report
        """
        report = {
            "platform": platform,
            "secret_findings": [],
            "management_analysis": {},
            "oidc_analysis": {},
            "recommendations": [],
            "risk_summary": {},
        }
        
        # Scan for exposed secrets
        report["secret_findings"] = self.scan_pipeline_config(config, platform)
        
        # Analyze secrets management
        report["management_analysis"] = self.analyze_secrets_management(config, platform)
        
        # Check OIDC usage
        report["oidc_analysis"] = self.check_oidc_usage(config, platform)
        
        # Calculate risk summary
        critical_count = sum(1 for f in report["secret_findings"] if f.severity == Severity.CRITICAL)
        high_count = sum(1 for f in report["secret_findings"] if f.severity == Severity.HIGH)
        
        report["risk_summary"] = {
            "total_findings": len(report["secret_findings"]),
            "critical": critical_count,
            "high": high_count,
            "risk_level": "critical" if critical_count > 0 else "high" if high_count > 0 else "low",
        }
        
        # Consolidate recommendations
        report["recommendations"].extend(report["management_analysis"].get("recommendations", []))
        report["recommendations"].extend(
            [r["recommendation"] for r in report["oidc_analysis"].get("recommendations", [])]
        )
        
        return report
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _mask_secret(self, secret: str) -> str:
        """Mask a secret value for safe display."""
        if len(secret) <= 8:
            return "*" * len(secret)
        return secret[:4] + "*" * (len(secret) - 8) + secret[-4:]
    
    def _check_insecure_secret_refs(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> List[SecretFinding]:
        """Check for insecure secret references."""
        findings = []
        config_str = str(config)
        
        # Check for direct secret printing
        insecure_patterns = [
            (r"echo\s+\$\{?secrets\.", "Echoing secret to output"),
            (r"print\(.*secret", "Printing secret to output"),
            (r"console\.log\(.*secret", "Logging secret to console"),
        ]
        
        for pattern, description in insecure_patterns:
            if re.search(pattern, config_str, re.IGNORECASE):
                findings.append(SecretFinding(
                    secret_type=SecretType.ACCESS_TOKEN,
                    severity=Severity.HIGH,
                    description=f"Insecure secret handling: {description}",
                    location=f"{platform}_config",
                    evidence={"pattern": pattern},
                    remediation="Remove secret output; use secret masking",
                    mitre_technique="T1552.001",
                ))
        
        return findings
    
    def _check_env_exposure(
        self,
        config: Dict[str, Any],
        platform: str,
    ) -> List[SecretFinding]:
        """Check for environment variable exposure."""
        findings = []
        
        # Platform-specific checks
        if platform == "github":
            # Check for secrets in env context exposed to forks
            if isinstance(config, dict):
                jobs = config.get("jobs", {})
                for job_name, job_config in jobs.items():
                    if isinstance(job_config, dict):
                        # Check if job runs on pull_request from forks
                        if "pull_request_target" in str(config.get("on", {})):
                            env_vars = job_config.get("env", {})
                            for var_name, var_value in env_vars.items():
                                if "${{ secrets." in str(var_value):
                                    findings.append(SecretFinding(
                                        secret_type=SecretType.ACCESS_TOKEN,
                                        severity=Severity.CRITICAL,
                                        description=f"Secret exposed in pull_request_target workflow: {var_name}",
                                        location=f"job:{job_name}",
                                        evidence={"variable": var_name},
                                        remediation="Do not expose secrets to forked PRs; use pull_request event instead",
                                        mitre_technique="T1552.001",
                                    ))
        
        return findings
    
    def get_findings(self) -> List[SecretFinding]:
        """Get all secret findings."""
        return self.findings
    
    def get_patterns(self) -> Dict[str, Any]:
        """Get secret detection patterns."""
        return SECRET_PATTERNS

