"""
Pipeline Injection and Artifact Poisoning Scanner

Comprehensive detection of:
- Script injection in pipeline steps
- Environment variable injection
- Artifact tampering and poisoning
- Build step manipulation
- Dependency confusion in pipelines
- Package registry poisoning

MITRE ATT&CK: T1195.002 (Supply Chain Compromise), T1059 (Command Execution)
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class InjectionType(str, Enum):
    """Types of pipeline injection vulnerabilities."""
    SCRIPT_INJECTION = "script_injection"
    ENV_VAR_INJECTION = "env_var_injection"
    ARTIFACT_POISONING = "artifact_poisoning"
    DEPENDENCY_CONFUSION = "dependency_confusion"
    BUILD_STEP_INJECTION = "build_step_injection"
    CONFIG_INJECTION = "config_injection"
    COMMAND_INJECTION = "command_injection"


class RiskLevel(str, Enum):
    """Risk levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class InjectionFinding:
    """Finding for pipeline injection vulnerability."""
    injection_type: InjectionType
    title: str
    description: str
    risk: RiskLevel
    evidence: str
    line_number: Optional[int] = None
    remediation: str = ""
    cwe_id: Optional[str] = None
    mitre_id: Optional[str] = None


# =============================================================================
# Script Injection Patterns
# =============================================================================

SCRIPT_INJECTION_PATTERNS = {
    # GitHub Actions script injection
    "github_expression_injection": {
        "patterns": [
            # Direct injection via expressions in run
            r"run:\s*[|\-]?\s*.*\$\{\{\s*github\.event\.(issue|pull_request|comment)\.(body|title)\s*\}\}",
            r"run:\s*[|\-]?\s*.*\$\{\{\s*github\.event\.inputs\.",
            r"run:\s*[|\-]?\s*.*\$\{\{\s*github\.head_ref\s*\}\}",
            r"run:\s*[|\-]?\s*.*\$\{\{\s*github\.event\.head_commit\.message\s*\}\}",
            # Expression in shell command
            r'echo\s+["\']?\$\{\{.*\}\}["\']?',
            r'eval\s+["\']?\$\{\{.*\}\}["\']?',
        ],
        "risk": RiskLevel.CRITICAL,
        "description": "GitHub Actions expression directly interpolated in script, allowing code injection",
        "remediation": "Use intermediate environment variables: env: TITLE: ${{ github.event.pull_request.title }} then use $TITLE",
        "cwe": "CWE-94",
        "mitre": "T1059",
    },
    
    # GitLab CI script injection
    "gitlab_variable_injection": {
        "patterns": [
            # CI variable in script without quotes
            r"script:\s*\n\s*-\s*.*\$CI_COMMIT_MESSAGE(?![\"'])",
            r"script:\s*\n\s*-\s*.*\$CI_MERGE_REQUEST_TITLE(?![\"'])",
            r"script:\s*\n\s*-\s*eval\s+",
            r"script:\s*\n\s*-\s*sh\s+-c\s+[\"'].*\$",
        ],
        "risk": RiskLevel.HIGH,
        "description": "GitLab CI variable used in script without proper escaping",
        "remediation": "Quote variable usage, use input validation, prefer CI_COMMIT_REF_SLUG over user-controlled values",
        "cwe": "CWE-94",
    },
    
    # Jenkins pipeline injection
    "jenkins_groovy_injection": {
        "patterns": [
            r"sh\s+[\"'].*\$\{params\.",
            r"sh\s+[\"'].*\$\{env\.",
            r"evaluate\s*\(",
            r"Eval\.me\s*\(",
            r"GroovyShell\(\)\.parse",
            r"new\s+GroovyShell\(\)",
            # Unsafe parameter handling
            r"params\[.*\]\.execute\(\)",
            r"\".*\$\{.*\}.*\"\.execute\(\)",
        ],
        "risk": RiskLevel.CRITICAL,
        "description": "Jenkins pipeline vulnerable to Groovy code injection",
        "remediation": "Use pipeline input validation, avoid evaluate/Eval.me, sanitize parameters",
        "cwe": "CWE-94",
        "mitre": "T1059.007",
    },
    
    # Azure DevOps injection
    "azure_variable_injection": {
        "patterns": [
            r"script:\s*.*\$\(Build\.SourceBranchName\)",
            r"script:\s*.*\$\(System\.PullRequest\.SourceBranch\)",
            r"script:\s*.*\$\(Build\.RequestedFor\)",
            # PowerShell injection
            r"powershell:\s*.*Invoke-Expression",
            r"powershell:\s*.*iex\s+",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Azure DevOps variable injection in script",
        "remediation": "Validate and sanitize pipeline variables, avoid Invoke-Expression",
        "cwe": "CWE-94",
    },
    
    # CircleCI injection
    "circleci_env_injection": {
        "patterns": [
            r"command:\s*.*\$CIRCLE_BRANCH",
            r"command:\s*.*\$CIRCLE_PR_NUMBER",
            r"command:\s*.*eval\s+",
            r"environment:.*\n.*BASH_ENV",
        ],
        "risk": RiskLevel.HIGH,
        "description": "CircleCI environment variable injection vulnerability",
        "remediation": "Sanitize branch names and PR data before use in commands",
        "cwe": "CWE-94",
    },
}


# =============================================================================
# Environment Variable Injection Patterns
# =============================================================================

ENV_INJECTION_PATTERNS = {
    "path_injection": {
        "patterns": [
            r"PATH=.*\$\{.*\}.*:.*\$PATH",
            r"export\s+PATH=.*\$",
            r"GITHUB_PATH.*<<",
            r"GITHUB_ENV.*<<",
        ],
        "risk": RiskLevel.HIGH,
        "description": "PATH environment variable injection allowing execution hijacking",
        "remediation": "Validate paths before adding, use absolute paths",
        "cwe": "CWE-426",
    },
    "ld_preload_injection": {
        "patterns": [
            r"LD_PRELOAD\s*=",
            r"LD_LIBRARY_PATH\s*=.*\$",
            r"DYLD_INSERT_LIBRARIES\s*=",
        ],
        "risk": RiskLevel.CRITICAL,
        "description": "Library preload injection allowing code execution",
        "remediation": "Never set LD_PRELOAD in CI/CD, use containerization",
        "cwe": "CWE-426",
        "mitre": "T1574.006",
    },
    "git_config_injection": {
        "patterns": [
            r"GIT_SSH_COMMAND\s*=.*\$",
            r"GIT_ASKPASS\s*=",
            r"GIT_PROXY_COMMAND\s*=",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Git configuration injection for command execution",
        "remediation": "Use SSH keys with deploy key pattern, avoid command substitution",
        "cwe": "CWE-78",
    },
    "dynamic_env_expansion": {
        "patterns": [
            r"eval\s+\$",
            r"\$\(.*\$.*\)",
            r"`.*\$.*`",
            r"envsubst",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Dynamic environment variable expansion allowing injection",
        "remediation": "Avoid eval with environment variables, use explicit variable references",
        "cwe": "CWE-78",
    },
}


# =============================================================================
# Artifact Poisoning Patterns
# =============================================================================

ARTIFACT_POISONING_PATTERNS = {
    "unsigned_artifacts": {
        "patterns": [
            # GitHub Actions artifacts
            r"actions/upload-artifact@v\d+(?!.*artifact-attestation)",
            r"actions/download-artifact@v\d+(?!.*verify)",
            # Generic artifact handling
            r"artifact.*publish(?!.*sign)",
            r"artifact.*upload(?!.*hash|.*integrity)",
        ],
        "risk": RiskLevel.MEDIUM,
        "description": "Artifacts uploaded/downloaded without integrity verification",
        "remediation": "Use artifact attestation (SLSA), sign artifacts, verify hashes",
        "cwe": "CWE-494",
    },
    "cross_workflow_artifacts": {
        "patterns": [
            r"workflow_run:.*download.*artifact",
            r"dawidd6/action-download-artifact",
            r"artifact.*from.*fork",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Artifacts shared between workflows without proper isolation",
        "remediation": "Validate artifact source, use run_id verification, avoid cross-fork artifacts",
        "cwe": "CWE-494",
        "mitre": "T1195.002",
    },
    "artifact_path_traversal": {
        "patterns": [
            r"artifact.*path:\s*\.\.",
            r"download.*path:\s*\.\.",
            r"artifact.*\*\*/",
            r"extract.*--strip-components",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Artifact extraction vulnerable to path traversal",
        "remediation": "Validate extraction paths, use safe extraction with path validation",
        "cwe": "CWE-22",
    },
    "binary_artifact_injection": {
        "patterns": [
            r"chmod\s*\+x\s*.*artifact",
            r"artifact.*\.exe|\.dll|\.so|\.dylib",
            r"download.*execute|download.*run",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Binary artifacts executed without verification",
        "remediation": "Verify binary signatures, use checksums, prefer building from source",
        "cwe": "CWE-494",
    },
}


# =============================================================================
# Dependency Confusion Patterns
# =============================================================================

DEPENDENCY_CONFUSION_PATTERNS = {
    "internal_package_exposure": {
        "patterns": [
            # npm
            r"npm\s+publish(?!.*--registry=https://registry\.npmjs\.org)",
            r"\.npmrc.*registry.*internal",
            r"package\.json.*\"name\":\s*\"@",
            # PyPI
            r"pip\s+install.*--extra-index-url",
            r"pip\s+install.*-i\s+http",
            r"twine\s+upload(?!.*--repository-url)",
            # Maven/Gradle
            r"repositories\s*\{.*maven.*internal",
            r"publishMavenPublicationToMavenRepository",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Internal package registry configuration may allow dependency confusion",
        "remediation": "Use scoped packages (@org/), configure registry priority, use dependency lockfiles",
        "cwe": "CWE-494",
        "mitre": "T1195.001",
    },
    "missing_lockfile": {
        "patterns": [
            r"npm\s+install(?!.*--ci)(?!.*--frozen-lockfile)",
            r"pip\s+install(?!.*--require-hashes)",
            r"go\s+get(?!.*@)",
            r"cargo\s+build(?!.*--locked)",
            r"bundle\s+install(?!.*--frozen)",
        ],
        "risk": RiskLevel.MEDIUM,
        "description": "Package installation without lockfile enforcement",
        "remediation": "Use npm ci, pip install --require-hashes, cargo build --locked",
        "cwe": "CWE-494",
    },
    "registry_spoofing": {
        "patterns": [
            r"registry.*http://(?!localhost)",
            r"registry.*\.local\.",
            r"--registry=http://",
            r"index-url.*http://(?!localhost)",
        ],
        "risk": RiskLevel.CRITICAL,
        "description": "Package registry using insecure HTTP connection",
        "remediation": "Always use HTTPS for package registries",
        "cwe": "CWE-319",
    },
    "typosquatting_risk": {
        "patterns": [
            # Common typosquatting targets
            r"(lodash|express|react|vue|angular|django|flask|requests)",
            # Package with single character difference from common packages
            r"(1odash|expresss|reactt|veu|angullar)",
        ],
        "risk": RiskLevel.LOW,
        "description": "Package name similar to common targets for typosquatting",
        "remediation": "Review package names, use organizational scopes, verify publisher",
        "cwe": "CWE-494",
    },
}


# =============================================================================
# Build Step Injection Patterns
# =============================================================================

BUILD_STEP_INJECTION_PATTERNS = {
    "dockerfile_injection": {
        "patterns": [
            r"ARG\s+\w+\s*\n.*RUN.*\$\1",
            r"ENV\s+\w+=\$\{",
            r"RUN\s+.*\$\(.*\)",
            r"COPY\s+--from=\$",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Dockerfile build arguments/variables vulnerable to injection",
        "remediation": "Validate build arguments, avoid command substitution in RUN",
        "cwe": "CWE-94",
    },
    "makefile_injection": {
        "patterns": [
            r"^\s*\$\(shell.*\$",
            r"^\s*eval\s+",
            r"^\s*@.*\$\(",
            r"include\s+\$",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Makefile vulnerable to variable injection",
        "remediation": "Quote variables, validate inputs, avoid $(shell) with user input",
        "cwe": "CWE-78",
    },
    "build_script_injection": {
        "patterns": [
            r"build\.sh.*\$\d+",
            r"build\.sh.*\$@",
            r"configure.*--prefix=\$",
            r"cmake\s+-D.*=\$",
        ],
        "risk": RiskLevel.MEDIUM,
        "description": "Build script parameters vulnerable to injection",
        "remediation": "Validate build parameters, use arrays for arguments",
        "cwe": "CWE-78",
    },
    "gradle_script_injection": {
        "patterns": [
            r"exec\s*\{.*commandLine.*\$",
            r"Runtime\.getRuntime\(\)\.exec",
            r"ProcessBuilder.*\$",
            r"apply\s+from:\s+[\"']\$",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Gradle build script vulnerable to command injection",
        "remediation": "Use typed DSL, validate external inputs, avoid Runtime.exec",
        "cwe": "CWE-78",
    },
    "maven_pom_injection": {
        "patterns": [
            r"<exec>.*\$\{",
            r"<argument>\$\{",
            r"maven-antrun-plugin.*<exec>",
            r"exec-maven-plugin.*<executable>\$",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Maven POM vulnerable to property injection in exec",
        "remediation": "Validate Maven properties, avoid exec in production builds",
        "cwe": "CWE-78",
    },
}


# =============================================================================
# Package Registry Poisoning
# =============================================================================

REGISTRY_POISONING_PATTERNS = {
    "npm_package_scripts": {
        "patterns": [
            r"\"preinstall\":\s*\"",
            r"\"postinstall\":\s*\"",
            r"\"prepublish\":\s*\"",
            r"scripts.*curl|wget|nc|bash",
        ],
        "risk": RiskLevel.HIGH,
        "description": "NPM package with potentially malicious lifecycle scripts",
        "remediation": "Review package scripts, use --ignore-scripts flag, audit dependencies",
        "cwe": "CWE-506",
    },
    "pypi_setup_exec": {
        "patterns": [
            r"setup\.py.*subprocess",
            r"setup\.py.*os\.system",
            r"setup\.py.*exec\(",
            r"__init__\.py.*import\s+os.*system",
        ],
        "risk": RiskLevel.HIGH,
        "description": "Python package setup.py with code execution",
        "remediation": "Use pyproject.toml, audit setup.py, use pip install --no-build-isolation",
        "cwe": "CWE-506",
    },
    "gem_extension_build": {
        "patterns": [
            r"extconf\.rb.*system\(",
            r"Rakefile.*sh\s+",
            r"\.gemspec.*extensions",
        ],
        "risk": RiskLevel.MEDIUM,
        "description": "Ruby gem with native extension build scripts",
        "remediation": "Audit gem extensions, use bundler audit, prefer pure Ruby gems",
        "cwe": "CWE-506",
    },
    "go_module_replace": {
        "patterns": [
            r"go\.mod.*replace.*=>",
            r"go\.mod.*replace.*github\.com.*local",
            r"GOPROXY=direct",
        ],
        "risk": RiskLevel.MEDIUM,
        "description": "Go module with replacement directives may override dependencies",
        "remediation": "Review replace directives, use GOSUM verification, audit dependencies",
        "cwe": "CWE-494",
    },
}


class PipelineInjectionScanner:
    """Scans for pipeline injection and artifact poisoning vulnerabilities."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
        self.findings: List[InjectionFinding] = []
    
    def scan_content(
        self,
        content: str,
        file_path: str,
    ) -> List[InjectionFinding]:
        """
        Scan content for injection vulnerabilities.
        
        Args:
            content: File content to scan
            file_path: Path to the file
            
        Returns:
            List of injection findings
        """
        findings = []
        lines = content.split('\n')
        
        # Scan for script injection
        findings.extend(self._scan_patterns(
            content, lines, SCRIPT_INJECTION_PATTERNS, InjectionType.SCRIPT_INJECTION
        ))
        
        # Scan for environment variable injection
        findings.extend(self._scan_patterns(
            content, lines, ENV_INJECTION_PATTERNS, InjectionType.ENV_VAR_INJECTION
        ))
        
        # Scan for artifact poisoning
        findings.extend(self._scan_patterns(
            content, lines, ARTIFACT_POISONING_PATTERNS, InjectionType.ARTIFACT_POISONING
        ))
        
        # Scan for dependency confusion
        findings.extend(self._scan_patterns(
            content, lines, DEPENDENCY_CONFUSION_PATTERNS, InjectionType.DEPENDENCY_CONFUSION
        ))
        
        # Scan for build step injection
        findings.extend(self._scan_patterns(
            content, lines, BUILD_STEP_INJECTION_PATTERNS, InjectionType.BUILD_STEP_INJECTION
        ))
        
        # Scan for registry poisoning
        findings.extend(self._scan_patterns(
            content, lines, REGISTRY_POISONING_PATTERNS, InjectionType.DEPENDENCY_CONFUSION
        ))
        
        self.findings.extend(findings)
        return findings
    
    def _scan_patterns(
        self,
        content: str,
        lines: List[str],
        patterns: Dict[str, Dict],
        injection_type: InjectionType,
    ) -> List[InjectionFinding]:
        """Scan content against a set of patterns."""
        findings = []
        
        for check_name, check_config in patterns.items():
            for pattern in check_config.get("patterns", []):
                try:
                    # Multi-line search
                    for match in re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE):
                        line_num = content[:match.start()].count('\n') + 1
                        evidence = match.group(0)[:200]  # Limit evidence length
                        
                        findings.append(InjectionFinding(
                            injection_type=injection_type,
                            title=f"{check_name.replace('_', ' ').title()}",
                            description=check_config.get("description", ""),
                            risk=check_config.get("risk", RiskLevel.MEDIUM),
                            evidence=evidence,
                            line_number=line_num,
                            remediation=check_config.get("remediation", ""),
                            cwe_id=check_config.get("cwe"),
                            mitre_id=check_config.get("mitre"),
                        ))
                except re.error:
                    pass  # Skip invalid patterns
        
        return findings
    
    def scan_workflow_file(
        self,
        workflow_content: str,
        workflow_path: str,
    ) -> List[InjectionFinding]:
        """
        Specialized scan for CI/CD workflow files.
        
        Args:
            workflow_content: Workflow file content
            workflow_path: Path to workflow file
            
        Returns:
            List of injection findings
        """
        findings = self.scan_content(workflow_content, workflow_path)
        
        # Additional workflow-specific checks
        findings.extend(self._check_workflow_triggers(workflow_content))
        findings.extend(self._check_workflow_permissions(workflow_content))
        findings.extend(self._check_artifact_handling(workflow_content))
        
        return findings
    
    def _check_workflow_triggers(self, content: str) -> List[InjectionFinding]:
        """Check for dangerous workflow triggers."""
        findings = []
        
        # pull_request_target with checkout
        if "pull_request_target" in content:
            if re.search(r"checkout.*\$\{\{\s*github\.event\.pull_request", content, re.I):
                findings.append(InjectionFinding(
                    injection_type=InjectionType.SCRIPT_INJECTION,
                    title="Dangerous pull_request_target Workflow",
                    description="Workflow uses pull_request_target and checks out PR code, enabling Pwn Request attack",
                    risk=RiskLevel.CRITICAL,
                    evidence="pull_request_target with checkout",
                    remediation="Use pull_request event, or isolate checkout from secrets access",
                    cwe_id="CWE-94",
                    mitre_id="T1195.002",
                ))
        
        # workflow_run with artifact download
        if "workflow_run" in content:
            if re.search(r"download.*artifact|artifact.*download", content, re.I):
                findings.append(InjectionFinding(
                    injection_type=InjectionType.ARTIFACT_POISONING,
                    title="Workflow Run Artifact Download",
                    description="Workflow downloads artifacts from completed workflow runs, may be poisoned",
                    risk=RiskLevel.HIGH,
                    evidence="workflow_run with artifact download",
                    remediation="Verify artifact provenance, use artifact attestation",
                    cwe_id="CWE-494",
                ))
        
        return findings
    
    def _check_workflow_permissions(self, content: str) -> List[InjectionFinding]:
        """Check for overly permissive workflow permissions."""
        findings = []
        
        # Check for write-all permissions
        if re.search(r"permissions:\s*write-all", content, re.I):
            findings.append(InjectionFinding(
                injection_type=InjectionType.CONFIG_INJECTION,
                title="Overly Permissive Workflow Permissions",
                description="Workflow has write-all permissions, violating least privilege",
                risk=RiskLevel.HIGH,
                evidence="permissions: write-all",
                remediation="Specify minimum required permissions per job",
                cwe_id="CWE-250",
            ))
        
        # Check for contents: write without justification
        if re.search(r"contents:\s*write", content, re.I):
            if not re.search(r"push|release|tag", content, re.I):
                findings.append(InjectionFinding(
                    injection_type=InjectionType.CONFIG_INJECTION,
                    title="Contents Write Permission",
                    description="Workflow has contents:write but doesn't appear to need it",
                    risk=RiskLevel.MEDIUM,
                    evidence="contents: write",
                    remediation="Review if contents:write is necessary",
                    cwe_id="CWE-250",
                ))
        
        return findings
    
    def _check_artifact_handling(self, content: str) -> List[InjectionFinding]:
        """Check for unsafe artifact handling."""
        findings = []
        
        # Check for artifact download followed by execution
        if re.search(r"download-artifact.*\n.*\n?.*chmod\s+\+x|\.\/|bash\s+", content, re.I | re.MULTILINE):
            findings.append(InjectionFinding(
                injection_type=InjectionType.ARTIFACT_POISONING,
                title="Artifact Downloaded and Executed",
                description="Downloaded artifact is executed without integrity verification",
                risk=RiskLevel.HIGH,
                evidence="download-artifact followed by execution",
                remediation="Verify artifact hash/signature before execution",
                cwe_id="CWE-494",
            ))
        
        # Check for artifact retention without cleanup
        if "retention-days: 90" in content or "retention-days: 365" in content:
            findings.append(InjectionFinding(
                injection_type=InjectionType.ARTIFACT_POISONING,
                title="Long Artifact Retention",
                description="Artifacts retained for extended period may become stale attack targets",
                risk=RiskLevel.LOW,
                evidence="Long retention-days value",
                remediation="Use shorter retention periods for sensitive artifacts",
                cwe_id="CWE-672",
            ))
        
        return findings
    
    def get_all_patterns(self) -> Dict[str, Dict]:
        """Get all scanning patterns for reference."""
        return {
            "script_injection": SCRIPT_INJECTION_PATTERNS,
            "env_injection": ENV_INJECTION_PATTERNS,
            "artifact_poisoning": ARTIFACT_POISONING_PATTERNS,
            "dependency_confusion": DEPENDENCY_CONFUSION_PATTERNS,
            "build_step_injection": BUILD_STEP_INJECTION_PATTERNS,
            "registry_poisoning": REGISTRY_POISONING_PATTERNS,
        }

