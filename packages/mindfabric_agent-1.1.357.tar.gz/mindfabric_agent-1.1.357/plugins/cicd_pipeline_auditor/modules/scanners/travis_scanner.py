"""
Travis CI Scanner Module
"""

import os
import glob
import yaml
import hashlib
from datetime import datetime
from typing import Dict, Any
from ...proto import ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
from utils.logger import logger


class TravisScanner:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        from ..analyzers.travis_analyzer import TravisAnalyzer
        self.analyzer = TravisAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        results = {
            "config_files": [], "environments": [], "iam_permissions": [],
            "secrets": [], "isolation_issues": [], "injection_vectors": [],
            "vulnerabilities": [], "workflow_permissions": []
        }
        
        patterns = [".travis.yml", ".travis.yaml"]
        
        for repo_path in scan_options.repo_paths:
            for pattern in patterns:
                travis_files = glob.glob(os.path.join(repo_path, pattern))
                
                for travis_file in travis_files:
                    try:
                        with open(travis_file, 'r') as f:
                            travis_content = f.read()
                        
                        travis_data = yaml.safe_load(travis_content)
                        
                        config_file = ConfigurationFile(
                            path=travis_file, platform=CICDPlatform.TRAVIS,
                            content=travis_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(travis_file)),
                            file_size=len(travis_content.encode()),
                            file_hash=hashlib.sha256(travis_content.encode()).hexdigest(),
                            config_type=ConfigurationType.TRAVIS_YML,
                            has_secrets=self.secret_scanner.check_for_secrets(travis_content),
                            has_privilege_issues=self.analyzer.check_travis_privileges(travis_data),
                            has_security_issues=True
                        )
                        
                        results["config_files"].append(config_file)
                        results["vulnerabilities"].extend(self.analyzer.analyze_config(travis_file, travis_data))
                        results["secrets"].extend(self.secret_scanner.scan_secrets_in_content(
                            travis_content, travis_file, CICDPlatform.TRAVIS))
                        results["injection_vectors"].extend(self.analyzer.find_injection_vectors(travis_file, travis_data))
                        
                    except Exception as e:
                        logger.error(f"Error analyzing Travis CI config {travis_file}: {str(e)}")
        
        return results

