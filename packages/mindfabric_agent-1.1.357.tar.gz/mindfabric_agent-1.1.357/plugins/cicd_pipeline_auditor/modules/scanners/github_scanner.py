"""
GitHub Actions Scanner Module

Scans GitHub Actions workflows for security issues.
"""

import os
import glob
import yaml
import hashlib
from datetime import datetime
from typing import Dict, List, Any
from ...proto import (
    ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
)
from utils.logger import logger


class GitHubScanner:
    """Scans GitHub Actions workflows"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        # Get secret scanner from plugin
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        # Get analyzer from plugin
        from ..analyzers.github_analyzer import GitHubAnalyzer
        self.analyzer = GitHubAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """Scans GitHub Actions workflows for security issues."""
        results = {
            "config_files": [],
            "environments": [],
            "iam_permissions": [],
            "secrets": [],
            "isolation_issues": [],
            "injection_vectors": [],
            "vulnerabilities": [],
            "workflow_permissions": []
        }
        
        # Find GitHub workflow files
        workflow_patterns = [
            ".github/workflows/*.yml",
            ".github/workflows/*.yaml"
        ]
        
        for repo_path in scan_options.repo_paths:
            for pattern in workflow_patterns:
                workflow_files = glob.glob(os.path.join(repo_path, pattern))
                
                for workflow_file in workflow_files:
                    try:
                        # Parse workflow file
                        with open(workflow_file, 'r') as f:
                            workflow_content = f.read()
                        
                        workflow_data = yaml.safe_load(workflow_content)
                        
                        # Create configuration file object
                        config_file = ConfigurationFile(
                            path=workflow_file,
                            platform=CICDPlatform.GITHUB,
                            content=workflow_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(workflow_file)),
                            file_size=len(workflow_content.encode()),
                            file_hash=hashlib.sha256(workflow_content.encode()).hexdigest(),
                            config_type=ConfigurationType.GITHUB_WORKFLOW,
                            has_secrets=self.secret_scanner.check_for_secrets(workflow_content),
                            has_privilege_issues=self.analyzer.check_github_privileges(workflow_data),
                            has_security_issues=True  # Will be determined by analysis
                        )
                        
                        results["config_files"].append(config_file)
                        
                        # Analyze workflow for vulnerabilities
                        workflow_vulns = self.analyzer.analyze_workflow(workflow_file, workflow_data)
                        results["vulnerabilities"].extend(workflow_vulns)
                        
                        # Check permissions
                        permissions = self.analyzer.analyze_permissions(workflow_file, workflow_data)
                        if permissions:
                            results["workflow_permissions"].append(permissions)
                        
                        # Check for secrets
                        workflow_secrets = self.secret_scanner.scan_secrets_in_content(
                            workflow_content, workflow_file, CICDPlatform.GITHUB
                        )
                        results["secrets"].extend(workflow_secrets)
                        
                        # Check for injection vectors
                        injection_vectors = self.analyzer.find_injection_vectors(workflow_file, workflow_data)
                        results["injection_vectors"].extend(injection_vectors)
                        
                    except Exception as e:
                        logger.error(f"Error analyzing GitHub workflow {workflow_file}: {str(e)}")
        
        return results

