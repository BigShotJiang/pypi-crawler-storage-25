"""
Collect dependency / lockfiles for SupplyChainScanner and map results to proto SupplyChainCheck.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from ...proto import SupplyChainCheck


TARGET_FILENAMES = {
    "package.json",
    "package-lock.json",
    "yarn.lock",
    ".npmrc",
    "npm-shrinkwrap.json",
    "requirements.txt",
    "requirements-dev.txt",
    "constraints.txt",
    "pipfile",
    "pipfile.lock",
    "pyproject.toml",
    "poetry.lock",
    "setup.py",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "settings.xml",
    "gradle.properties",
    "go.mod",
    "go.sum",
    "gemfile",
    "gemfile.lock",
    ".gemrc",
    "nuget.config",
    "packages.config",
    "cargo.toml",
    "cargo.lock",
}

TARGET_LOWER = {n.lower() for n in TARGET_FILENAMES}

CI_CONTENT_HINTS = (
    ".github/workflows",
    ".gitlab-ci",
    "jenkinsfile",
    "azure-pipelines",
    ".circleci",
    "bitbucket-pipelines",
    "dockerfile",
)


def gather_files_for_supply_chain(
    repo_paths: List[str],
    config_files: List[Any],
    *,
    max_files: int = 280,
) -> Dict[str, str]:
    """Walk repo roots for lockfiles and merge CI config contents for script-level checks."""
    files: Dict[str, str] = {}
    n = 0

    for root in repo_paths or []:
        base = Path(root)
        if not base.is_dir():
            continue
        try:
            for p in base.rglob("*"):
                if n >= max_files:
                    return files
                if not p.is_file():
                    continue
                if p.name.lower() not in TARGET_LOWER:
                    continue
                try:
                    st = p.stat()
                    if st.st_size > 1_500_000:
                        continue
                    key = str(p.resolve())
                    if key not in files:
                        files[key] = p.read_text(encoding="utf-8", errors="ignore")
                        n += 1
                except OSError:
                    continue
        except OSError:
            continue

    for cf in config_files or []:
        if n >= max_files:
            break
        path = getattr(cf, "path", None)
        content = getattr(cf, "content", None)
        if not path or content is None or path in files:
            continue
        pl = path.lower()
        if any(h in pl for h in CI_CONTENT_HINTS) or pl.endswith((".yml", ".yaml")):
            files[path] = content if isinstance(content, str) else str(content)
            n += 1

    return files


def supply_chain_check_from_result(scan_id: str, result: Any) -> SupplyChainCheck:
    """Convert SupplyChainScanResult dataclass into API-friendly SupplyChainCheck."""
    all_findings = (
        list(result.dependency_confusion)
        + list(result.typosquatting)
        + list(result.build_poisoning)
        + list(result.artifact_integrity)
    )

    vulns: List[Dict[str, Any]] = []
    for f in all_findings[:200]:
        sev = getattr(f.severity, "value", str(getattr(f, "severity", "")))
        vulns.append(
            {
                "type": f.finding_type,
                "title": f.title,
                "description": f.description,
                "severity": sev,
                "file_path": f.file_path,
                "line_number": f.line_number,
                "mitre_technique": f.mitre_technique,
                "cwe": f.cwe,
                "recommendation": f.recommendation,
            }
        )

    recs: List[str] = []
    seen: set = set()
    for f in all_findings:
        r = getattr(f, "recommendation", "") or ""
        if r and r not in seen:
            seen.add(r)
            recs.append(r)

    from ...proto import RiskLevel

    crit_bp = sum(1 for f in result.build_poisoning if getattr(f, "severity", None) == RiskLevel.CRITICAL)

    return SupplyChainCheck(
        scan_id=scan_id,
        timestamp=datetime.now(),
        dependency_checks={
            "dependency_confusion_findings": len(result.dependency_confusion),
            "typosquatting_findings": len(result.typosquatting),
            "build_poisoning_findings": len(result.build_poisoning),
            "artifact_integrity_findings": len(result.artifact_integrity),
            "total_findings": result.total_findings,
            "critical_total": result.critical_count,
            "high_total": result.high_count,
            # Count of CRITICAL-severity build-poisoning findings (integer; not bool)
            "critical_build_poisoning_critical_count": crit_bp,
        },
        signature_verification={
            "static_scan_only": True,
            # Proto expects bools here; previously we passed crit_bp (int), which broke validation.
            "critical_build_poisoning_signals": crit_bp > 0,
            "operator_note": "Confirm Sigstore/cosign/SLSA attestations in your registry and CI separately",
        },
        artifact_provenance={
            "unverified_download_pattern_hits": len(result.artifact_integrity),
        },
        vulnerabilities=vulns,
        recommendations=recs[:35],
    )
