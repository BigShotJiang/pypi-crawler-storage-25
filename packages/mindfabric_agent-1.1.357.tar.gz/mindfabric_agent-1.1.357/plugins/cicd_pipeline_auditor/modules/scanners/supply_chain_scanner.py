"""
Supply Chain Security Scanner

Detects supply chain attack vectors in CI/CD pipelines:
- Dependency confusion attacks
- Typosquatting detection
- Compromised dependencies
- Malicious package detection
- Build pipeline poisoning
- Artifact integrity verification

MITRE ATT&CK:
- T1195.001: Supply Chain Compromise: Compromise Software Dependencies
- T1195.002: Supply Chain Compromise: Compromise Software Supply Chain
- T1199: Trusted Relationship
"""

import re
import json
import hashlib
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

from ...proto import RiskLevel


# =============================================================================
# Dependency Confusion Patterns
# =============================================================================

DEPENDENCY_CONFUSION_PATTERNS = {
    "npm": {
        "private_registry_indicators": [
            r"@[\w-]+/",  # Scoped packages
            r"registry\.npmjs\.org",
            r"npm\.pkg\.github\.com",
            r"registry\.yarnpkg\.com",
        ],
        "config_files": [".npmrc", "package.json", "package-lock.json", "yarn.lock"],
        "dangerous_configs": {
            "registry": r"registry\s*=\s*https?://(?!registry\.npmjs\.org)",
            "always_auth": r"always-auth\s*=\s*true",
            "_auth": r"_auth\s*=",
        },
        "attack_indicators": [
            "Internal package published to public npm",
            "Private scope available on public registry",
            "Package name collision detected",
        ],
    },
    "pypi": {
        "private_registry_indicators": [
            r"--index-url\s+https?://",
            r"--extra-index-url\s+https?://",
        ],
        "config_files": ["requirements.txt", "setup.py", "pyproject.toml", "pip.conf"],
        "dangerous_configs": {
            "extra_index": r"extra-index-url\s*=",
            "trusted_host": r"trusted-host\s*=",
        },
        "attack_indicators": [
            "Internal package on PyPI",
            "Version string indicates internal build",
            "Package metadata mismatch",
        ],
    },
    "maven": {
        "private_registry_indicators": [
            r"<url>https?://(?!repo\.maven\.apache\.org|central\.maven\.org)",
        ],
        "config_files": ["pom.xml", "settings.xml", "build.gradle", "build.gradle.kts"],
        "dangerous_configs": {
            "mirror": r"<mirror>.*</mirror>",
            "repository": r"<repository>.*</repository>",
        },
    },
    "nuget": {
        "private_registry_indicators": [
            r"<add key=\"[\w]+\" value=\"https?://(?!api\.nuget\.org)",
        ],
        "config_files": ["nuget.config", "packages.config", "*.csproj"],
        "dangerous_configs": {
            "custom_source": r"<add key=.* value=\"https?://(?!api\.nuget\.org)",
        },
    },
    "rubygems": {
        "private_registry_indicators": [
            r"source\s+['\"]https?://(?!rubygems\.org)",
        ],
        "config_files": ["Gemfile", "Gemfile.lock", ".gemrc"],
    },
}


# =============================================================================
# Typosquatting Patterns
# =============================================================================

TYPOSQUATTING_PATTERNS = {
    "common_substitutions": {
        "0": ["o", "O"],
        "1": ["l", "i", "I"],
        "3": ["e", "E"],
        "4": ["a", "A"],
        "5": ["s", "S"],
        "-": ["_", ""],
        "_": ["-", ""],
    },
    "popular_packages": {
        "npm": [
            "lodash", "express", "react", "webpack", "axios", "moment",
            "jquery", "chalk", "commander", "debug", "uuid", "request",
            "async", "bluebird", "underscore", "eslint", "babel",
        ],
        "pypi": [
            "requests", "numpy", "pandas", "flask", "django", "pytest",
            "boto3", "urllib3", "cryptography", "pillow", "sqlalchemy",
            "celery", "redis", "psycopg2", "aiohttp", "scikit-learn",
        ],
        "rubygems": [
            "rails", "rake", "bundler", "rspec", "nokogiri", "puma",
            "devise", "sidekiq", "capistrano", "rubocop",
        ],
    },
    "known_typosquats": [
        # NPM
        ("crossenv", "cross-env"),
        ("event-stream", "events-stream"),
        ("electron-native-notify", "electron-native-notification"),
        # PyPI
        ("python-dateutil", "python-dateutill"),
        ("jeIlyfish", "jellyfish"),
        ("python3-dateutil", "python-dateutil"),
    ],
}


# =============================================================================
# Build Pipeline Poisoning
# =============================================================================

BUILD_POISONING_PATTERNS = {
    "malicious_scripts": {
        "pre_install": [
            r"preinstall.*curl.*\|.*sh",
            r"preinstall.*wget.*\|.*bash",
            r"preinstall.*eval\s*\(",
            r"postinstall.*curl.*\|.*sh",
        ],
        "build_scripts": [
            r"build.*&&.*curl",
            r"prepare.*wget.*-O",
            r"test.*\|\|.*true",  # Bypassing test failures
        ],
    },
    "environment_exfiltration": [
        r"curl.*\$\{?\w+",
        r"wget.*\$\{?\w+",
        r"echo.*\$\{?(AWS|GITHUB|NPM|PYPI|TOKEN|SECRET|KEY|PASSWORD)",
        r"base64.*\|.*curl",
    ],
    "reverse_shell_patterns": [
        r"nc\s+-[^\s]+\s+[\d\.]+\s+\d+",
        r"bash\s+-i\s+>&\s+/dev/tcp",
        r"/bin/sh\s+-i",
        r"python.*socket.*connect",
        r"php.*fsockopen",
    ],
    "persistence_mechanisms": [
        r"crontab",
        r"\.bashrc",
        r"\.profile",
        r"systemd.*enable",
        r"launchctl.*load",
    ],
}


# =============================================================================
# Artifact Integrity
# =============================================================================

ARTIFACT_INTEGRITY_CHECKS = {
    "missing_checksums": {
        "description": "Artifacts downloaded without checksum verification",
        "patterns": [
            r"curl\s+-[^\s]*O[^\s]*\s+https?://",
            r"wget\s+https?://",
            r"Invoke-WebRequest.*-OutFile",
        ],
        "recommended": [
            "Use SHA256 checksums for all downloaded artifacts",
            "Verify GPG signatures where available",
            "Pin versions in dependency files",
        ],
    },
    "insecure_download": {
        "description": "Artifacts downloaded over HTTP (not HTTPS)",
        "patterns": [
            r"curl\s+http://",
            r"wget\s+http://",
            r"pip install.*http://",
            r"npm install.*http://",
        ],
    },
    "unsigned_packages": {
        "description": "Packages installed without signature verification",
        "patterns": [
            r"--no-check-certificate",
            r"--insecure",
            r"-k\s+https://",
            r"NODE_TLS_REJECT_UNAUTHORIZED=0",
            r"PYTHONHTTPSVERIFY=0",
        ],
    },
}


@dataclass
class SupplyChainFinding:
    """Finding from supply chain security scan."""
    finding_type: str
    severity: RiskLevel
    title: str
    description: str
    file_path: str = ""
    line_number: int = 0
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""
    cwe: str = ""


@dataclass
class SupplyChainScanResult:
    """Result of supply chain security scan."""
    dependency_confusion: List[SupplyChainFinding] = field(default_factory=list)
    typosquatting: List[SupplyChainFinding] = field(default_factory=list)
    build_poisoning: List[SupplyChainFinding] = field(default_factory=list)
    artifact_integrity: List[SupplyChainFinding] = field(default_factory=list)
    total_findings: int = 0
    critical_count: int = 0
    high_count: int = 0


class SupplyChainScanner:
    """Scanner for supply chain security vulnerabilities in CI/CD."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.findings: List[SupplyChainFinding] = []
    
    def scan_dependency_confusion(
        self,
        file_content: str,
        file_path: str,
        package_manager: str = None,
    ) -> List[SupplyChainFinding]:
        """
        Scan for dependency confusion vulnerabilities.
        
        Args:
            file_content: Content of the configuration file
            file_path: Path to the file
            package_manager: Package manager type (npm, pypi, maven, etc.)
            
        Returns:
            List of dependency confusion findings
        """
        findings = []
        
        # Auto-detect package manager if not specified
        if not package_manager:
            package_manager = self._detect_package_manager(file_path)
        
        if not package_manager:
            return findings
        
        patterns = DEPENDENCY_CONFUSION_PATTERNS.get(package_manager, {})
        
        # Check for dangerous configurations
        for config_name, pattern in patterns.get("dangerous_configs", {}).items():
            matches = list(re.finditer(pattern, file_content, re.MULTILINE))
            
            for match in matches:
                line_num = file_content[:match.start()].count('\n') + 1
                
                findings.append(SupplyChainFinding(
                    finding_type="dependency_confusion",
                    severity=RiskLevel.HIGH,
                    title=f"Potential Dependency Confusion: {config_name}",
                    description=f"Configuration may allow dependency confusion attack in {package_manager}",
                    file_path=file_path,
                    line_number=line_num,
                    evidence={"config": config_name, "match": match.group()},
                    mitre_technique="T1195.001",
                    recommendation="Ensure private packages are properly scoped and registries are explicitly configured",
                    cwe="CWE-829",
                ))
        
        # Check for mixed registries (private and public)
        private_indicators = patterns.get("private_registry_indicators", [])
        has_private = any(
            re.search(p, file_content) for p in private_indicators
        )
        
        has_public = self._has_public_registry(file_content, package_manager)
        
        if has_private and has_public:
            findings.append(SupplyChainFinding(
                finding_type="dependency_confusion",
                severity=RiskLevel.CRITICAL,
                title="Mixed Private and Public Registries",
                description="Configuration uses both private and public registries, creating dependency confusion risk",
                file_path=file_path,
                evidence={"package_manager": package_manager},
                mitre_technique="T1195.001",
                recommendation="Configure registry priority or use package scoping",
                cwe="CWE-829",
            ))
        
        return findings
    
    def scan_typosquatting(
        self,
        dependencies: List[str],
        package_manager: str,
    ) -> List[SupplyChainFinding]:
        """
        Scan dependencies for potential typosquatting.
        
        Args:
            dependencies: List of dependency names
            package_manager: Package manager type
            
        Returns:
            List of typosquatting findings
        """
        findings = []
        
        popular = TYPOSQUATTING_PATTERNS["popular_packages"].get(package_manager, [])
        known_typosquats = TYPOSQUATTING_PATTERNS["known_typosquats"]
        
        for dep in dependencies:
            dep_lower = dep.lower()
            
            # Check against known typosquats
            for typo, legitimate in known_typosquats:
                if dep_lower == typo.lower():
                    findings.append(SupplyChainFinding(
                        finding_type="typosquatting",
                        severity=RiskLevel.CRITICAL,
                        title=f"Known Typosquat Detected: {dep}",
                        description=f"Package '{dep}' is a known typosquat of '{legitimate}'",
                        evidence={"package": dep, "legitimate": legitimate},
                        mitre_technique="T1195.001",
                        recommendation=f"Replace '{dep}' with '{legitimate}'",
                        cwe="CWE-829",
                    ))
            
            # Check similarity to popular packages
            for popular_pkg in popular:
                similarity = self._calculate_similarity(dep_lower, popular_pkg.lower())
                
                if similarity > 0.85 and similarity < 1.0:
                    # High similarity but not exact match
                    findings.append(SupplyChainFinding(
                        finding_type="typosquatting",
                        severity=RiskLevel.HIGH,
                        title=f"Potential Typosquat: {dep}",
                        description=f"Package '{dep}' is similar to popular package '{popular_pkg}'",
                        evidence={"package": dep, "similar_to": popular_pkg, "similarity": similarity},
                        mitre_technique="T1195.001",
                        recommendation=f"Verify this is the intended package and not a typosquat",
                        cwe="CWE-829",
                    ))
        
        return findings
    
    def scan_build_poisoning(
        self,
        file_content: str,
        file_path: str,
    ) -> List[SupplyChainFinding]:
        """
        Scan for build pipeline poisoning indicators.
        
        Args:
            file_content: Content of the build file
            file_path: Path to the file
            
        Returns:
            List of build poisoning findings
        """
        findings = []
        
        # Check malicious scripts
        for script_type, patterns in BUILD_POISONING_PATTERNS["malicious_scripts"].items():
            for pattern in patterns:
                matches = list(re.finditer(pattern, file_content, re.IGNORECASE | re.MULTILINE))
                
                for match in matches:
                    line_num = file_content[:match.start()].count('\n') + 1
                    
                    findings.append(SupplyChainFinding(
                        finding_type="build_poisoning",
                        severity=RiskLevel.CRITICAL,
                        title=f"Suspicious {script_type} Script",
                        description=f"Potentially malicious command in {script_type} hook",
                        file_path=file_path,
                        line_number=line_num,
                        evidence={"script_type": script_type, "command": match.group()[:100]},
                        mitre_technique="T1195.002",
                        recommendation="Review and remove suspicious build scripts",
                        cwe="CWE-829",
                    ))
        
        # Check environment exfiltration
        for pattern in BUILD_POISONING_PATTERNS["environment_exfiltration"]:
            matches = list(re.finditer(pattern, file_content, re.IGNORECASE | re.MULTILINE))
            
            for match in matches:
                line_num = file_content[:match.start()].count('\n') + 1
                
                findings.append(SupplyChainFinding(
                    finding_type="build_poisoning",
                    severity=RiskLevel.CRITICAL,
                    title="Potential Environment Variable Exfiltration",
                    description="Command may leak environment variables to external server",
                    file_path=file_path,
                    line_number=line_num,
                    evidence={"command": match.group()[:100]},
                    mitre_technique="T1552.001",
                    recommendation="Remove commands that transmit environment variables externally",
                    cwe="CWE-200",
                ))
        
        # Check reverse shell patterns
        for pattern in BUILD_POISONING_PATTERNS["reverse_shell_patterns"]:
            matches = list(re.finditer(pattern, file_content, re.IGNORECASE | re.MULTILINE))
            
            for match in matches:
                line_num = file_content[:match.start()].count('\n') + 1
                
                findings.append(SupplyChainFinding(
                    finding_type="build_poisoning",
                    severity=RiskLevel.CRITICAL,
                    title="Reverse Shell Pattern Detected",
                    description="Potential reverse shell command in build script",
                    file_path=file_path,
                    line_number=line_num,
                    evidence={"command": match.group()[:100]},
                    mitre_technique="T1059",
                    recommendation="Remove reverse shell commands immediately",
                    cwe="CWE-78",
                ))
        
        return findings
    
    def scan_artifact_integrity(
        self,
        file_content: str,
        file_path: str,
    ) -> List[SupplyChainFinding]:
        """
        Scan for artifact integrity issues.
        
        Args:
            file_content: Content of the build/CI file
            file_path: Path to the file
            
        Returns:
            List of artifact integrity findings
        """
        findings = []
        
        for check_name, check_config in ARTIFACT_INTEGRITY_CHECKS.items():
            for pattern in check_config.get("patterns", []):
                matches = list(re.finditer(pattern, file_content, re.IGNORECASE | re.MULTILINE))
                
                for match in matches:
                    line_num = file_content[:match.start()].count('\n') + 1
                    
                    severity = RiskLevel.CRITICAL if "insecure" in check_name else RiskLevel.MEDIUM
                    
                    findings.append(SupplyChainFinding(
                        finding_type="artifact_integrity",
                        severity=severity,
                        title=f"Artifact Integrity Issue: {check_name.replace('_', ' ').title()}",
                        description=check_config.get("description", ""),
                        file_path=file_path,
                        line_number=line_num,
                        evidence={"command": match.group()[:100]},
                        mitre_technique="T1195.002",
                        recommendation="; ".join(check_config.get("recommended", ["Implement artifact verification"])),
                        cwe="CWE-494",
                    ))
        
        return findings
    
    def _detect_package_manager(self, file_path: str) -> Optional[str]:
        """Detect package manager from file path."""
        file_name = file_path.lower().split("/")[-1]
        
        npm_files = ["package.json", "package-lock.json", "yarn.lock", ".npmrc"]
        pypi_files = ["requirements.txt", "setup.py", "pyproject.toml", "pip.conf", "pipfile"]
        maven_files = ["pom.xml", "build.gradle", "build.gradle.kts", "settings.xml"]
        nuget_files = ["nuget.config", "packages.config"]
        ruby_files = ["gemfile", "gemfile.lock", ".gemrc"]
        
        if any(f in file_name for f in npm_files):
            return "npm"
        if any(f in file_name for f in pypi_files):
            return "pypi"
        if any(f in file_name for f in maven_files):
            return "maven"
        if any(f in file_name for f in nuget_files):
            return "nuget"
        if any(f in file_name for f in ruby_files):
            return "rubygems"
        
        return None
    
    def _has_public_registry(self, content: str, package_manager: str) -> bool:
        """Check if content references public registry."""
        public_registries = {
            "npm": ["registry.npmjs.org", "registry.yarnpkg.com"],
            "pypi": ["pypi.org", "pypi.python.org"],
            "maven": ["repo.maven.apache.org", "central.maven.org"],
            "nuget": ["api.nuget.org"],
            "rubygems": ["rubygems.org"],
        }
        
        registries = public_registries.get(package_manager, [])
        return any(reg in content for reg in registries)
    
    def _calculate_similarity(self, s1: str, s2: str) -> float:
        """Calculate string similarity using Levenshtein distance."""
        if len(s1) < len(s2):
            s1, s2 = s2, s1
        
        if len(s2) == 0:
            return 0.0
        
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return 1.0 - (previous_row[-1] / max(len(s1), len(s2)))
    
    def extract_dependencies(
        self,
        file_content: str,
        file_path: str,
    ) -> List[str]:
        """Extract dependency names from package file."""
        dependencies = []
        package_manager = self._detect_package_manager(file_path)
        
        if package_manager == "npm":
            # Parse package.json
            try:
                data = json.loads(file_content)
                deps = data.get("dependencies", {})
                dev_deps = data.get("devDependencies", {})
                dependencies.extend(deps.keys())
                dependencies.extend(dev_deps.keys())
            except json.JSONDecodeError:
                pass
        
        elif package_manager == "pypi":
            # Parse requirements.txt style
            for line in file_content.split("\n"):
                line = line.strip()
                if line and not line.startswith("#"):
                    # Remove version specifiers
                    dep = re.split(r'[<>=!~\[]', line)[0].strip()
                    if dep:
                        dependencies.append(dep)
        
        return dependencies
    
    async def scan(
        self,
        files: Dict[str, str],
    ) -> SupplyChainScanResult:
        """
        Perform comprehensive supply chain security scan.
        
        Args:
            files: Dictionary of file_path -> file_content
            
        Returns:
            SupplyChainScanResult with all findings
        """
        result = SupplyChainScanResult()
        
        for file_path, content in files.items():
            # Dependency confusion
            dc_findings = self.scan_dependency_confusion(content, file_path)
            result.dependency_confusion.extend(dc_findings)
            
            # Extract and check dependencies for typosquatting
            deps = self.extract_dependencies(content, file_path)
            pm = self._detect_package_manager(file_path)
            if deps and pm:
                typo_findings = self.scan_typosquatting(deps, pm)
                result.typosquatting.extend(typo_findings)
            
            # Build poisoning
            bp_findings = self.scan_build_poisoning(content, file_path)
            result.build_poisoning.extend(bp_findings)
            
            # Artifact integrity
            ai_findings = self.scan_artifact_integrity(content, file_path)
            result.artifact_integrity.extend(ai_findings)
        
        # Calculate totals
        all_findings = (
            result.dependency_confusion +
            result.typosquatting +
            result.build_poisoning +
            result.artifact_integrity
        )
        
        result.total_findings = len(all_findings)
        result.critical_count = sum(1 for f in all_findings if f.severity == RiskLevel.CRITICAL)
        result.high_count = sum(1 for f in all_findings if f.severity == RiskLevel.HIGH)
        
        self.findings = all_findings
        
        return result
    
    def get_findings(self) -> List[SupplyChainFinding]:
        """Get all findings."""
        return self.findings
    
    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Convert findings to list of dictionaries."""
        return [
            {
                "id": hashlib.md5(f"{f.file_path}:{f.line_number}:{f.title}".encode()).hexdigest()[:12],
                "type": f.finding_type,
                "title": f.title,
                "description": f.description,
                "severity": f.severity.value,
                "file_path": f.file_path,
                "line_number": f.line_number,
                "evidence": f.evidence,
                "recommendation": f.recommendation,
                "mitre_technique": f.mitre_technique,
                "cwe": f.cwe,
            }
            for f in self.findings
        ]

