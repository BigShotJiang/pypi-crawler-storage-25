"""
Jenkins Scanner Module

Scans Jenkins configurations for security issues.
"""

import os
import glob
import hashlib
from datetime import datetime
from typing import Dict, Any
from ...proto import ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
from utils.logger import logger


class JenkinsScanner:
    """Scans Jenkins configurations"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        from ..analyzers.jenkins_analyzer import JenkinsAnalyzer
        self.analyzer = JenkinsAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """Scans Jenkins configurations for security issues."""
        results = {
            "config_files": [],
            "environments": [],
            "iam_permissions": [],
            "secrets": [],
            "isolation_issues": [],
            "injection_vectors": [],
            "vulnerabilities": [],
            "workflow_permissions": []
        }
        
        # Find Jenkins files
        jenkins_patterns = [
            "Jenkinsfile",
            "**/Jenkinsfile",
            "jenkins/*.groovy",
            ".jenkins/**"
        ]
        
        for repo_path in scan_options.repo_paths:
            for pattern in jenkins_patterns:
                jenkins_files = glob.glob(os.path.join(repo_path, pattern), recursive=True)
                
                for jenkins_file in jenkins_files:
                    try:
                        if not os.path.isfile(jenkins_file):
                            # glob may return directories (e.g. `.jenkins/`) or stale paths; skip quietly.
                            logger.debug(
                                "Skipping Jenkins path (not a regular file): %s", jenkins_file
                            )
                            continue
                        with open(jenkins_file, 'r', encoding='utf-8', errors='replace') as f:
                            jenkins_content = f.read()
                        
                        # Create configuration file object
                        config_file = ConfigurationFile(
                            path=jenkins_file,
                            platform=CICDPlatform.JENKINS,
                            content=jenkins_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(jenkins_file)),
                            file_size=len(jenkins_content.encode()),
                            file_hash=hashlib.sha256(jenkins_content.encode()).hexdigest(),
                            config_type=ConfigurationType.JENKINSFILE,
                            has_secrets=self.secret_scanner.check_for_secrets(jenkins_content),
                            has_privilege_issues=True,  # Jenkins often has privilege issues
                            has_security_issues=True
                        )
                        
                        results["config_files"].append(config_file)
                        
                        # Analyze Jenkinsfile
                        jenkins_vulns = self.analyzer.analyze_jenkinsfile(jenkins_file, jenkins_content)
                        results["vulnerabilities"].extend(jenkins_vulns)
                        
                        # Check for secrets
                        jenkins_secrets = self.secret_scanner.scan_secrets_in_content(
                            jenkins_content, jenkins_file, CICDPlatform.JENKINS
                        )
                        results["secrets"].extend(jenkins_secrets)
                        
                        # Check for injection vectors
                        injection_vectors = self.analyzer.find_injection_vectors(jenkins_file, jenkins_content)
                        results["injection_vectors"].extend(injection_vectors)
                        
                    except FileNotFoundError:
                        logger.debug(
                            "Jenkins path disappeared before read (race or stale glob): %s",
                            jenkins_file,
                        )
                    except IsADirectoryError:
                        logger.debug("Skipping Jenkins path (directory, not a file): %s", jenkins_file)
                    except Exception as e:
                        logger.warning("Error analyzing Jenkins file %s: %s", jenkins_file, e)
        
        return results

