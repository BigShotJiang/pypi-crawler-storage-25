"""
GitLab CI Scanner Module

Scans GitLab CI configurations for security issues.
"""

import os
import glob
import yaml
import hashlib
from datetime import datetime
from typing import Dict, Any
from ...proto import ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
from utils.logger import logger


class GitLabScanner:
    """Scans GitLab CI configurations"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        from ..analyzers.gitlab_analyzer import GitLabAnalyzer
        self.analyzer = GitLabAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """Scans GitLab CI configurations for security issues."""
        results = {
            "config_files": [],
            "environments": [],
            "iam_permissions": [],
            "secrets": [],
            "isolation_issues": [],
            "injection_vectors": [],
            "vulnerabilities": [],
            "workflow_permissions": []
        }
        
        # Find GitLab CI files
        gitlab_patterns = [
            ".gitlab-ci.yml",
            ".gitlab-ci.yaml",
            "**/.gitlab-ci.yml"
        ]
        
        for repo_path in scan_options.repo_paths:
            for pattern in gitlab_patterns:
                ci_files = glob.glob(os.path.join(repo_path, pattern), recursive=True)
                
                for ci_file in ci_files:
                    try:
                        with open(ci_file, 'r') as f:
                            ci_content = f.read()
                        
                        ci_data = yaml.safe_load(ci_content)
                        
                        # Create configuration file object
                        config_file = ConfigurationFile(
                            path=ci_file,
                            platform=CICDPlatform.GITLAB,
                            content=ci_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(ci_file)),
                            file_size=len(ci_content.encode()),
                            file_hash=hashlib.sha256(ci_content.encode()).hexdigest(),
                            config_type=ConfigurationType.GITLAB_CI,
                            has_secrets=self.secret_scanner.check_for_secrets(ci_content),
                            has_privilege_issues=self.analyzer.check_gitlab_privileges(ci_data),
                            has_security_issues=True
                        )
                        
                        results["config_files"].append(config_file)
                        
                        # Analyze for vulnerabilities
                        gitlab_vulns = self.analyzer.analyze_ci(ci_file, ci_data)
                        results["vulnerabilities"].extend(gitlab_vulns)
                        
                        # Check for secrets
                        ci_secrets = self.secret_scanner.scan_secrets_in_content(
                            ci_content, ci_file, CICDPlatform.GITLAB
                        )
                        results["secrets"].extend(ci_secrets)
                        
                        # Check for injection vectors
                        injection_vectors = self.analyzer.find_injection_vectors(ci_file, ci_data)
                        results["injection_vectors"].extend(injection_vectors)
                        
                    except Exception as e:
                        logger.error(f"Error analyzing GitLab CI {ci_file}: {str(e)}")
        
        return results

