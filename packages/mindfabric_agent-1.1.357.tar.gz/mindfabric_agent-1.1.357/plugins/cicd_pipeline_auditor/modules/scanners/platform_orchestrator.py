"""
Platform Scanner Orchestrator

Orchestrates scanning across all CI/CD platforms.
"""

import time
from datetime import datetime
from typing import Dict, List, Any
from ...proto import (
    ScanOptions, CICDPlatform, ConfigurationFile, Environment, IAMPermission,
    Secret, IsolationIssue, CodeInjectionVector, Vulnerability, WorkflowPermission,
    ComplianceCheck, AccessMatrix, SupplyChainCheck, ScanStatistics, AuditResult
)


class PlatformOrchestrator:
    """Orchestrates scanning across all platforms"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from .github_scanner import GitHubScanner
        from .gitlab_scanner import GitLabScanner
        from .jenkins_scanner import JenkinsScanner
        from .azure_scanner import AzureScanner
        from .circleci_scanner import CircleCIScanner
        from .travis_scanner import TravisScanner
        from .bitbucket_scanner import BitbucketScanner
        
        self.scanners = {
            CICDPlatform.GITHUB: GitHubScanner(plugin_instance),
            CICDPlatform.GITLAB: GitLabScanner(plugin_instance),
            CICDPlatform.JENKINS: JenkinsScanner(plugin_instance),
            CICDPlatform.AZURE_DEVOPS: AzureScanner(plugin_instance),
            CICDPlatform.CIRCLECI: CircleCIScanner(plugin_instance),
            CICDPlatform.TRAVIS: TravisScanner(plugin_instance),
            CICDPlatform.BITBUCKET: BitbucketScanner(plugin_instance)
        }
        
        from ..compliance import ComplianceChecker
        self.compliance_checker = ComplianceChecker(plugin_instance)

        from .supply_chain_scanner import SupplyChainScanner
        self.supply_chain_scanner = SupplyChainScanner(plugin_instance)

        from ..reporting import ReportGenerator
        self.report_generator = ReportGenerator(plugin_instance)
    
    async def run_scan(self, scan_id: str, scan_options: ScanOptions, response_helper) -> Dict[str, Any]:
        """Runs the complete CI/CD security audit."""
        start_time = time.time()
        
        # Initialize results
        config_files = []
        environments = []
        iam_permissions = []
        secrets = []
        isolation_issues = []
        injection_vectors = []
        vulnerabilities = []
        workflow_permissions = []
        compliance_checks = []
        access_matrices = []
        supply_chain_checks = []
        errors = []
        
        try:
            await response_helper.send_progress_update(scan_id, 5, "Starting platform scanning")
            
            # Scan each platform
            progress_per_platform = 80 / len(scan_options.platforms) if scan_options.platforms else 80
            current_progress = 10
            
            for platform in scan_options.platforms:
                try:
                    platform_enum = CICDPlatform(platform)
                    await response_helper.send_progress_update(
                        scan_id, current_progress, f"Scanning {platform} platform"
                    )
                    
                    # Scan platform
                    scanner = self.scanners.get(platform_enum)
                    if scanner:
                        platform_results = await scanner.scan(scan_options)
                        
                        # Merge results
                        config_files.extend(platform_results.get("config_files", []))
                        environments.extend(platform_results.get("environments", []))
                        iam_permissions.extend(platform_results.get("iam_permissions", []))
                        secrets.extend(platform_results.get("secrets", []))
                        isolation_issues.extend(platform_results.get("isolation_issues", []))
                        injection_vectors.extend(platform_results.get("injection_vectors", []))
                        vulnerabilities.extend(platform_results.get("vulnerabilities", []))
                        workflow_permissions.extend(platform_results.get("workflow_permissions", []))
                        
                        # Platform-specific compliance checks
                        compliance_checks.extend(
                            self.compliance_checker.generate_compliance_checks(platform_enum, platform_results)
                        )
                    
                    current_progress += progress_per_platform
                    await response_helper.send_progress_update(
                        scan_id, int(current_progress), f"Completed {platform} platform scan"
                    )
                    
                except Exception as e:
                    errors.append(f"Error scanning {platform}: {str(e)}")
                    from utils.logger import logger
                    logger.error(f"Error scanning {platform}: {str(e)}")
            
            await response_helper.send_progress_update(scan_id, 90, "Generating access matrices")
            from ..analyzers.access_matrix_builder import build_access_matrix

            try:
                access_matrices = [
                    build_access_matrix(
                        scan_id,
                        platforms_scanned=scan_options.platforms,
                        config_files=config_files,
                        workflow_permissions=workflow_permissions,
                        iam_permissions=iam_permissions,
                        secrets=secrets,
                        vulnerabilities=vulnerabilities,
                        injection_vectors=injection_vectors,
                    )
                ]
            except Exception as am_err:
                from utils.logger import logger

                logger.error(f"Access matrix build failed: {am_err}")
                errors.append(f"Access matrix build failed: {am_err}")
                access_matrices = []

            await response_helper.send_progress_update(scan_id, 95, "Performing supply chain checks")
            from .supply_chain_helpers import (
                gather_files_for_supply_chain,
                supply_chain_check_from_result,
            )

            sc_files = gather_files_for_supply_chain(
                list(scan_options.repo_paths or []),
                config_files,
            )
            try:
                supply_result = await self.supply_chain_scanner.scan(sc_files)
                supply_chain_checks = [
                    supply_chain_check_from_result(scan_id, supply_result)
                ]
            except Exception as sc_err:
                from utils.logger import logger

                logger.error(f"Supply chain scan failed: {sc_err}")
                errors.append(f"Supply chain scan failed: {sc_err}")
                from .supply_chain_scanner import SupplyChainScanResult

                supply_result = SupplyChainScanResult()
                supply_chain_checks = [
                    supply_chain_check_from_result(scan_id, supply_result)
                ]

            # Generate statistics
            scan_duration = time.time() - start_time
            from ...proto import RiskLevel
            statistics = ScanStatistics(
                total_repositories=len(set(cf.path.split('/')[0] for cf in config_files if '/' in cf.path)),
                total_config_files=len(config_files),
                total_vulnerabilities=len(vulnerabilities),
                vulnerabilities_by_risk={
                    risk: len([v for v in vulnerabilities if v.risk_level == risk])
                    for risk in RiskLevel
                },
                vulnerabilities_by_platform={
                    platform: len([v for v in vulnerabilities if v.platform == platform])
                    for platform in CICDPlatform
                },
                vulnerabilities_by_type={
                    "config_issues": len([v for v in vulnerabilities if "config" in v.title.lower()]),
                    "permission_issues": len([v for v in vulnerabilities if "permission" in v.title.lower()]),
                    "secret_leaks": len([v for v in vulnerabilities if "secret" in v.title.lower()]),
                    "injection_vectors": len(injection_vectors),
                    "supply_chain_findings": getattr(supply_result, "total_findings", 0),
                },
                scan_duration_seconds=scan_duration,
                files_processed=len(config_files),
                api_calls_made=0
            )
            
            # Create final audit result
            audit_result = AuditResult(
                scan_id=scan_id,
                timestamp=datetime.now(),
                scan_duration=scan_duration,
                auditor_version=self.plugin.VERSION,
                scan_options=scan_options,
                platforms_scanned=scan_options.platforms,
                config_files=config_files,
                environments=environments,
                iam_permissions=iam_permissions,
                secrets=secrets,
                isolation_issues=isolation_issues,
                injection_vectors=injection_vectors,
                vulnerabilities=vulnerabilities,
                workflow_permissions=workflow_permissions,
                compliance_checks=compliance_checks,
                access_matrices=access_matrices,
                supply_chain_checks=supply_chain_checks,
                artifact_metadata=[],
                statistics=statistics,
                errors=errors,
                warnings=[],
                summary=self.report_generator.generate_summary(vulnerabilities, statistics)
            )
            
            return audit_result
            
        except Exception as e:
            errors.append(f"General error during scanning: {str(e)}")
            from utils.logger import logger
            logger.error(f"General error during scanning: {str(e)}")
            raise

