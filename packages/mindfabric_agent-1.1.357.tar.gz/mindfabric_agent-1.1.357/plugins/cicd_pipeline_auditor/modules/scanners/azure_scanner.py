"""
Azure DevOps Scanner Module

Scans Azure DevOps pipelines for security issues.
"""

import os
import glob
import yaml
import hashlib
from datetime import datetime
from typing import Dict, Any
from ...proto import ScanOptions, ConfigurationFile, CICDPlatform, ConfigurationType
from utils.logger import logger


class AzureScanner:
    """Scans Azure DevOps pipelines"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        from ..security import SecretScanner
        self.secret_scanner = SecretScanner(plugin_instance)
        from ..analyzers.azure_analyzer import AzureAnalyzer
        self.analyzer = AzureAnalyzer(plugin_instance)
    
    async def scan(self, scan_options: ScanOptions) -> Dict[str, Any]:
        """Scans Azure DevOps pipelines for security issues."""
        results = {
            "config_files": [], "environments": [], "iam_permissions": [],
            "secrets": [], "isolation_issues": [], "injection_vectors": [],
            "vulnerabilities": [], "workflow_permissions": []
        }
        
        azure_patterns = ["azure-pipelines.yml", "azure-pipelines.yaml", ".azure-pipelines/*.yml", ".azure-pipelines/*.yaml"]
        
        for repo_path in scan_options.repo_paths:
            for pattern in azure_patterns:
                pipeline_files = glob.glob(os.path.join(repo_path, pattern), recursive=True)
                
                for pipeline_file in pipeline_files:
                    try:
                        with open(pipeline_file, 'r') as f:
                            pipeline_content = f.read()
                        
                        pipeline_data = yaml.safe_load(pipeline_content)
                        
                        config_file = ConfigurationFile(
                            path=pipeline_file, platform=CICDPlatform.AZURE_DEVOPS,
                            content=pipeline_content,
                            last_modified=datetime.fromtimestamp(os.path.getmtime(pipeline_file)),
                            file_size=len(pipeline_content.encode()),
                            file_hash=hashlib.sha256(pipeline_content.encode()).hexdigest(),
                            config_type=ConfigurationType.AZURE_PIPELINE,
                            has_secrets=self.secret_scanner.check_for_secrets(pipeline_content),
                            has_privilege_issues=self.analyzer.check_azure_privileges(pipeline_data),
                            has_security_issues=True
                        )
                        
                        results["config_files"].append(config_file)
                        results["vulnerabilities"].extend(self.analyzer.analyze_pipeline(pipeline_file, pipeline_data))
                        results["secrets"].extend(self.secret_scanner.scan_secrets_in_content(
                            pipeline_content, pipeline_file, CICDPlatform.AZURE_DEVOPS))
                        
                    except Exception as e:
                        logger.error(f"Error analyzing Azure pipeline {pipeline_file}: {str(e)}")
        
        return results

