"""
Runner Security Scanner

Scans for security issues in CI/CD self-hosted runners.
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class RunnerType(str, Enum):
    """Types of CI/CD runners."""
    GITHUB_ACTIONS = "github_actions"
    GITLAB_RUNNER = "gitlab_runner"
    JENKINS_AGENT = "jenkins_agent"
    AZURE_AGENT = "azure_agent"
    CIRCLECI_RUNNER = "circleci_runner"
    BITBUCKET_RUNNER = "bitbucket_runner"
    DRONE_RUNNER = "drone_runner"
    TEKTON_RUNNER = "tekton_runner"


class SecurityRisk(str, Enum):
    """Security risk levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class RunnerFinding:
    """Security finding for a runner."""
    runner_type: RunnerType
    finding_type: str
    title: str
    description: str
    risk: SecurityRisk
    evidence: Optional[str] = None
    remediation: str = ""
    cwe_id: Optional[str] = None
    mitre_id: Optional[str] = None


# =============================================================================
# Self-Hosted Runner Security Checks
# =============================================================================

RUNNER_SECURITY_CHECKS = {
    # GitHub Actions Self-Hosted Runners
    "github_actions": {
        "runner_token_exposure": {
            "pattern": r"RUNNER_TOKEN|ACTIONS_RUNNER_INPUT_TOKEN|\.runner|\.credentials",
            "risk": SecurityRisk.CRITICAL,
            "description": "Self-hosted runner tokens exposed in logs or environment",
            "remediation": "Use just-in-time tokens, rotate runner tokens regularly, never log tokens",
            "cwe": "CWE-798",
        },
        "workflow_injection": {
            "pattern": r"\$\{\{\s*github\.event\.(issue|pull_request|comment)\.body\s*\}\}|\$\{\{\s*github\.event\.inputs\.",
            "risk": SecurityRisk.HIGH,
            "description": "Workflow vulnerable to script injection via untrusted input",
            "remediation": "Use intermediate environment variables and proper input validation",
            "cwe": "CWE-94",
        },
        "pwn_request": {
            "pattern": r"pull_request_target.*checkout.*\$\{\{\s*github\.event\.pull_request\.head",
            "risk": SecurityRisk.CRITICAL,
            "description": "Pull request target workflow checking out untrusted PR code (Pwn Request)",
            "remediation": "Use pull_request event or carefully isolate checkout from secrets access",
            "cwe": "CWE-94",
            "mitre": "T1195.002",
        },
        "runner_labels_abuse": {
            "pattern": r"runs-on:\s*\[?\s*self-hosted\s*[,\]]",
            "risk": SecurityRisk.MEDIUM,
            "description": "Workflows targeting self-hosted runners may access internal resources",
            "remediation": "Use dedicated runner groups with restricted access, implement runner isolation",
        },
        "artifact_poisoning": {
            "pattern": r"actions/upload-artifact.*actions/download-artifact",
            "risk": SecurityRisk.MEDIUM,
            "description": "Artifacts shared between workflows may be poisoned",
            "remediation": "Sign and verify artifacts, use artifact attestation",
        },
        "cache_poisoning": {
            "pattern": r"actions/cache@v[0-2]",
            "risk": SecurityRisk.HIGH,
            "description": "Older cache actions vulnerable to cache poisoning attacks",
            "remediation": "Use actions/cache@v3 or later with proper key isolation",
            "cwe": "CWE-494",
        },
        "oidc_misconfiguration": {
            "pattern": r"permissions:\s*id-token:\s*write.*subject.*\*",
            "risk": SecurityRisk.HIGH,
            "description": "OIDC token with overly permissive subject claim",
            "remediation": "Restrict OIDC subject claim to specific repository, environment, or branch",
        },
    },
    
    # GitLab Runner
    "gitlab_runner": {
        "runner_token_exposure": {
            "pattern": r"CI_RUNNER_TOKEN|REGISTRATION_TOKEN|RUNNER_TOKEN|\.runner-token",
            "risk": SecurityRisk.CRITICAL,
            "description": "GitLab runner registration token exposed",
            "remediation": "Use runner authentication tokens, rotate tokens regularly",
            "cwe": "CWE-798",
        },
        "privileged_runner": {
            "pattern": r"privileged\s*=\s*true|--privileged",
            "risk": SecurityRisk.CRITICAL,
            "description": "GitLab runner running in privileged Docker mode",
            "remediation": "Use non-privileged runners, implement container isolation",
            "mitre": "T1611",
        },
        "docker_socket_mount": {
            "pattern": r"volumes\s*=.*docker\.sock|/var/run/docker\.sock",
            "risk": SecurityRisk.CRITICAL,
            "description": "Docker socket mounted in runner container",
            "remediation": "Use Docker-in-Docker (DinD) or Kaniko for container builds",
            "mitre": "T1611",
        },
        "cache_shared": {
            "pattern": r"shared\s*=\s*true.*cache|cache.*shared\s*=\s*true",
            "risk": SecurityRisk.HIGH,
            "description": "Runner cache shared between projects allowing cache poisoning",
            "remediation": "Use per-project cache or signed cache artifacts",
        },
        "unprotected_variables": {
            "pattern": r"CI_JOB_TOKEN|CI_REGISTRY_PASSWORD",
            "risk": SecurityRisk.MEDIUM,
            "description": "Sensitive CI variables may be exposed in logs",
            "remediation": "Mark variables as protected and masked in project settings",
        },
    },
    
    # Jenkins Agent
    "jenkins_agent": {
        "agent_secret_exposure": {
            "pattern": r"JENKINS_SECRET|JNLP_PROTOCOL_OPTS|secret-file",
            "risk": SecurityRisk.CRITICAL,
            "description": "Jenkins agent secret exposed in configuration or logs",
            "remediation": "Use WebSocket protocol, rotate agent secrets, implement secret masking",
            "cwe": "CWE-798",
        },
        "agent_to_controller": {
            "pattern": r"agent.*any|node.*any",
            "risk": SecurityRisk.HIGH,
            "description": "Pipeline can run on any agent including controller",
            "remediation": "Restrict pipeline execution to specific agents, isolate controller",
        },
        "script_security_bypass": {
            "pattern": r"@Grab|@GrabResolver|Script-Security-Plugin.*bypass",
            "risk": SecurityRisk.CRITICAL,
            "description": "Groovy sandbox bypass or unauthorized script execution",
            "remediation": "Keep Script Security plugin updated, review script approvals",
            "cwe": "CWE-94",
        },
        "credentials_binding": {
            "pattern": r"withCredentials.*usernamePassword|withCredentials.*string",
            "risk": SecurityRisk.MEDIUM,
            "description": "Credentials bound to environment may be logged",
            "remediation": "Use credential masking, avoid echoing credentials",
        },
        "shared_workspace": {
            "pattern": r"ws\(.*shared|customWorkspace",
            "risk": SecurityRisk.MEDIUM,
            "description": "Shared workspace may lead to data leakage between builds",
            "remediation": "Use isolated workspaces per build, clean workspace after build",
        },
    },
    
    # Azure DevOps Agent
    "azure_agent": {
        "pat_exposure": {
            "pattern": r"AZURE_DEVOPS_PAT|System\.AccessToken",
            "risk": SecurityRisk.CRITICAL,
            "description": "Azure DevOps PAT or System Access Token exposed",
            "remediation": "Use managed identity, limit PAT scope, rotate tokens",
            "cwe": "CWE-798",
        },
        "agent_pool_security": {
            "pattern": r"pool:.*Default|pool:.*Azure Pipelines",
            "risk": SecurityRisk.MEDIUM,
            "description": "Using default or shared agent pools",
            "remediation": "Use dedicated agent pools with access restrictions",
        },
        "service_connection_exposure": {
            "pattern": r"azureSubscription|serviceConnection",
            "risk": SecurityRisk.HIGH,
            "description": "Service connection may have excessive permissions",
            "remediation": "Use workload identity federation, limit service connection scope",
        },
    },
}


# =============================================================================
# Build Cache Security Checks
# =============================================================================

BUILD_CACHE_ATTACKS = {
    "cache_key_collision": {
        "description": "Attacker manipulates cache key to inject malicious content",
        "indicators": [
            r"cache.*key.*\$\{.*user.*\}",
            r"cache.*key.*\$\{.*branch.*\}",
            r"cache.*restore-keys",
        ],
        "risk": SecurityRisk.HIGH,
        "remediation": "Use cryptographic hash of dependencies in cache key, avoid user-controlled inputs",
    },
    "cache_poisoning_cicd": {
        "description": "Malicious code injected into shared CI/CD cache",
        "indicators": [
            r"npm cache|pip cache|gradle cache|maven cache",
            r"cache.*path.*node_modules|\.npm|\.pip|\.m2|\.gradle",
        ],
        "risk": SecurityRisk.HIGH,
        "remediation": "Use lockfiles with integrity hashes, verify cached dependencies",
    },
    "remote_cache_injection": {
        "description": "Remote build cache vulnerable to injection attacks",
        "indicators": [
            r"--remote_cache=|BUILDBUDDY|BAZEL_REMOTE",
            r"sccache.*S3|ccache.*memcached",
        ],
        "risk": SecurityRisk.MEDIUM,
        "remediation": "Use authenticated and encrypted remote cache, implement cache signing",
    },
    "docker_layer_cache": {
        "description": "Docker layer cache may contain malicious base images",
        "indicators": [
            r"--cache-from|DOCKER_BUILDKIT.*cache",
            r"buildx.*cache-from|cache-to",
        ],
        "risk": SecurityRisk.MEDIUM,
        "remediation": "Use content-addressable cache keys, verify base image digests",
    },
    "artifact_cache_exposure": {
        "description": "Build artifacts cached without integrity verification",
        "indicators": [
            r"artifact.*cache|cache.*artifact",
            r"upload-artifact.*download-artifact",
        ],
        "risk": SecurityRisk.MEDIUM,
        "remediation": "Sign build artifacts, use SLSA provenance attestation",
    },
}


# =============================================================================
# New CI/CD Platforms Configuration
# =============================================================================

NEW_PLATFORM_PATTERNS = {
    # TeamCity
    "teamcity": {
        "indicators": [
            r"\.teamcity|teamcity.*settings\.kts|TeamCity",
        ],
        "checks": {
            "agent_auth_token": {
                "pattern": r"TEAMCITY_BUILD_PROPERTIES_FILE|teamcity\.agent\.authorization\.token",
                "risk": SecurityRisk.CRITICAL,
                "description": "TeamCity agent authorization token exposed",
            },
            "build_config_as_code": {
                "pattern": r"settings\.kts.*password|settings\.kts.*token",
                "risk": SecurityRisk.HIGH,
                "description": "Secrets hardcoded in TeamCity Kotlin DSL",
            },
        },
    },
    
    # Bamboo
    "bamboo": {
        "indicators": [
            r"bamboo-specs|\.bamboo|atlassian\.bamboo",
        ],
        "checks": {
            "remote_agent": {
                "pattern": r"bamboo\.agent\.\w+\.token|BAMBOO_AGENT_HOME",
                "risk": SecurityRisk.HIGH,
                "description": "Bamboo remote agent token exposed",
            },
            "plan_specs": {
                "pattern": r"bamboo-specs.*password|PlanSpec.*secret",
                "risk": SecurityRisk.HIGH,
                "description": "Secrets in Bamboo Plan Specs",
            },
        },
    },
    
    # Drone CI
    "drone": {
        "indicators": [
            r"\.drone\.yml|drone\.io|DRONE_",
        ],
        "checks": {
            "drone_token": {
                "pattern": r"DRONE_TOKEN|DRONE_SERVER|drone-secret",
                "risk": SecurityRisk.CRITICAL,
                "description": "Drone CI token or server secret exposed",
            },
            "trusted_mode": {
                "pattern": r"trusted:\s*true|privileged:\s*true",
                "risk": SecurityRisk.HIGH,
                "description": "Drone pipeline running in trusted/privileged mode",
            },
            "extension_abuse": {
                "pattern": r"extensions:\s*\[|commands:\s*\[",
                "risk": SecurityRisk.MEDIUM,
                "description": "Drone extensions may execute arbitrary commands",
            },
        },
    },
    
    # Tekton
    "tekton": {
        "indicators": [
            r"tekton\.dev|apiVersion.*tekton|kind:\s*Task|kind:\s*Pipeline",
        ],
        "checks": {
            "service_account": {
                "pattern": r"serviceAccountName:|tekton-pipelines",
                "risk": SecurityRisk.MEDIUM,
                "description": "Tekton pipeline service account may have excessive permissions",
            },
            "workspace_security": {
                "pattern": r"workspaces:.*persistentVolumeClaim|emptyDir",
                "risk": SecurityRisk.MEDIUM,
                "description": "Tekton workspace persistence may leak data between runs",
            },
            "step_security": {
                "pattern": r"securityContext:|runAsUser:\s*0|privileged:\s*true",
                "risk": SecurityRisk.HIGH,
                "description": "Tekton step running with elevated privileges",
            },
        },
    },
    
    # Argo Workflows
    "argo_workflows": {
        "indicators": [
            r"argoproj\.io/v1alpha1|kind:\s*Workflow|kind:\s*WorkflowTemplate",
        ],
        "checks": {
            "artifact_repository": {
                "pattern": r"artifactRepository:|s3.*accessKeySecret",
                "risk": SecurityRisk.HIGH,
                "description": "Argo artifact repository credentials may be exposed",
            },
            "executor_security": {
                "pattern": r"executor:.*docker|executor:.*pns|executor:.*k8sapi",
                "risk": SecurityRisk.MEDIUM,
                "description": "Argo executor type may have security implications",
            },
            "workflow_rbac": {
                "pattern": r"serviceAccountName:|workflow-controller",
                "risk": SecurityRisk.MEDIUM,
                "description": "Argo workflow RBAC may be overly permissive",
            },
        },
    },
}


class RunnerSecurityScanner:
    """Scans CI/CD runners for security issues."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
        self.findings: List[RunnerFinding] = []
    
    def scan_content(
        self,
        content: str,
        file_path: str,
        platform: Optional[RunnerType] = None,
    ) -> List[RunnerFinding]:
        """Scan content for runner security issues."""
        findings = []
        
        # Auto-detect platform if not specified
        if platform is None:
            platform = self._detect_platform(content, file_path)
        
        if platform is None:
            return findings
        
        # Get platform-specific checks
        platform_checks = RUNNER_SECURITY_CHECKS.get(platform.value, {})
        
        for check_name, check_config in platform_checks.items():
            pattern = check_config.get("pattern", "")
            if pattern and re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                finding = RunnerFinding(
                    runner_type=platform,
                    finding_type=check_name,
                    title=check_name.replace("_", " ").title(),
                    description=check_config.get("description", ""),
                    risk=check_config.get("risk", SecurityRisk.MEDIUM),
                    evidence=f"Found in {file_path}",
                    remediation=check_config.get("remediation", ""),
                    cwe_id=check_config.get("cwe"),
                    mitre_id=check_config.get("mitre"),
                )
                findings.append(finding)
        
        # Check for build cache issues
        findings.extend(self._scan_cache_security(content, file_path, platform))
        
        # Check for new platform patterns
        findings.extend(self._scan_new_platforms(content, file_path))
        
        self.findings.extend(findings)
        return findings
    
    def _detect_platform(self, content: str, file_path: str) -> Optional[RunnerType]:
        """Auto-detect CI/CD platform from content and file path."""
        
        if ".github" in file_path or "github.com" in content:
            return RunnerType.GITHUB_ACTIONS
        if ".gitlab-ci" in file_path or "gitlab-runner" in content:
            return RunnerType.GITLAB_RUNNER
        if "Jenkinsfile" in file_path or "jenkins" in content.lower():
            return RunnerType.JENKINS_AGENT
        if "azure-pipelines" in file_path or "azuredevops" in content.lower():
            return RunnerType.AZURE_AGENT
        if ".circleci" in file_path or "circleci" in content.lower():
            return RunnerType.CIRCLECI_RUNNER
        if "bitbucket-pipelines" in file_path:
            return RunnerType.BITBUCKET_RUNNER
        if ".drone" in file_path or "DRONE_" in content:
            return RunnerType.DRONE_RUNNER
        if "tekton" in content.lower() or "kind: Task" in content:
            return RunnerType.TEKTON_RUNNER
        
        return None
    
    def _scan_cache_security(
        self,
        content: str,
        file_path: str,
        platform: RunnerType,
    ) -> List[RunnerFinding]:
        """Scan for build cache security issues."""
        findings = []
        
        for attack_name, attack_config in BUILD_CACHE_ATTACKS.items():
            for indicator in attack_config.get("indicators", []):
                if re.search(indicator, content, re.IGNORECASE):
                    finding = RunnerFinding(
                        runner_type=platform,
                        finding_type=f"cache_{attack_name}",
                        title=f"Build Cache: {attack_name.replace('_', ' ').title()}",
                        description=attack_config.get("description", ""),
                        risk=attack_config.get("risk", SecurityRisk.MEDIUM),
                        evidence=f"Found in {file_path}",
                        remediation=attack_config.get("remediation", ""),
                    )
                    findings.append(finding)
                    break
        
        return findings
    
    def _scan_new_platforms(
        self,
        content: str,
        file_path: str,
    ) -> List[RunnerFinding]:
        """Scan for new CI/CD platform security issues."""
        findings = []
        
        for platform_name, platform_config in NEW_PLATFORM_PATTERNS.items():
            # Check if platform is detected
            is_platform = False
            for indicator in platform_config.get("indicators", []):
                if re.search(indicator, content, re.IGNORECASE):
                    is_platform = True
                    break
            
            if not is_platform:
                continue
            
            # Run platform-specific checks
            for check_name, check_config in platform_config.get("checks", {}).items():
                pattern = check_config.get("pattern", "")
                if pattern and re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                    finding = RunnerFinding(
                        runner_type=RunnerType.GITHUB_ACTIONS,  # Use generic
                        finding_type=f"{platform_name}_{check_name}",
                        title=f"{platform_name.title()}: {check_name.replace('_', ' ').title()}",
                        description=check_config.get("description", ""),
                        risk=check_config.get("risk", SecurityRisk.MEDIUM),
                        evidence=f"Found in {file_path}",
                        remediation=check_config.get("remediation", ""),
                    )
                    findings.append(finding)
        
        return findings
    
    def get_high_risk_findings(self) -> List[RunnerFinding]:
        """Get findings with high or critical risk."""
        return [f for f in self.findings if f.risk in [SecurityRisk.CRITICAL, SecurityRisk.HIGH]]
    
    def get_findings_by_platform(self, platform: RunnerType) -> List[RunnerFinding]:
        """Get findings for specific platform."""
        return [f for f in self.findings if f.runner_type == platform]

