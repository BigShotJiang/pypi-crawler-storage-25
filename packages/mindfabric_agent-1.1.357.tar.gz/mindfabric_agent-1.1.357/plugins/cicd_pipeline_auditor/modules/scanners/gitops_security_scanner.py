"""
GitOps Security Scanner Module

Security assessment for GitOps tools:
- ArgoCD: Application security, RBAC, secrets management
- Flux: GitRepository security, Kustomization security
- Helm: Chart security, repository security, values injection

MITRE ATT&CK:
- T1195.002: Supply Chain Compromise: Compromise Software Supply Chain
- T1078: Valid Accounts
- T1552: Unsecured Credentials
"""

import os
import re
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum, auto

logger = logging.getLogger(__name__)


# =============================================================================
# GitOps Security Databases
# =============================================================================

class GitOpsSeverity(Enum):
    CRITICAL = auto()
    HIGH = auto()
    MEDIUM = auto()
    LOW = auto()
    INFO = auto()


# ArgoCD Security Checks
ARGOCD_SECURITY_CHECKS = {
    "rbac_misconfigurations": {
        "name": "ArgoCD RBAC Misconfigurations",
        "description": "Overly permissive RBAC policies",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "admin_all_projects": r'p,\s*role:admin,\s*applications,\s*\*,\s*\*/\*',
            "sync_all": r'p,\s*[^,]+,\s*applications,\s*sync,\s*\*/\*',
            "delete_all": r'p,\s*[^,]+,\s*applications,\s*delete,\s*\*/\*',
            "override_all": r'p,\s*[^,]+,\s*applications,\s*override,\s*\*/\*',
        },
        "mitre": "T1078",
    },
    "insecure_webhook": {
        "name": "ArgoCD Insecure Webhook Configuration",
        "description": "Webhook without authentication or TLS",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "no_secret": r'webhook\.github\.secret:\s*["\']?["\']?$',
            "insecure_tls": r'webhook\..*\.insecure:\s*true',
        },
        "mitre": "T1195.002",
    },
    "application_sync_policy": {
        "name": "ArgoCD Dangerous Sync Policy",
        "description": "Auto-sync with auto-prune enabled",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "auto_sync_prune": r'syncPolicy:\s*\n\s*automated:\s*\n\s*prune:\s*true',
            "self_heal_no_prune": r'syncPolicy:\s*\n\s*automated:\s*\n\s*selfHeal:\s*true',
        },
        "mitre": "T1195.002",
    },
    "secrets_in_repo": {
        "name": "ArgoCD Secrets in Repository",
        "description": "Plain text secrets in Application manifests",
        "severity": GitOpsSeverity.CRITICAL,
        "patterns": {
            "plain_password": r'password:\s*["\'][^"\']+["\']',
            "plain_token": r'token:\s*["\'][^"\']+["\']',
            "plain_key": r'(api[_-]?key|secret[_-]?key):\s*["\'][^"\']+["\']',
        },
        "mitre": "T1552",
    },
    "external_secrets": {
        "name": "ArgoCD External Secrets Misconfig",
        "description": "Insecure External Secrets configuration",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "no_refresh": r'refreshInterval:\s*0',
            "cluster_wide": r'spec:\s*\n\s*target:\s*\n\s*creationPolicy:\s*Owner',
        },
        "mitre": "T1552",
    },
    "project_restrictions": {
        "name": "ArgoCD Project Without Restrictions",
        "description": "AppProject with wildcard destinations or sources",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "any_destination": r'destinations:\s*\n\s*-\s*namespace:\s*["\']?\*',
            "any_source": r'sourceRepos:\s*\n\s*-\s*["\']?\*',
            "any_cluster": r'destinations:\s*\n\s*-\s*server:\s*["\']?\*',
        },
        "mitre": "T1078",
    },
}

# Flux Security Checks
FLUX_SECURITY_CHECKS = {
    "git_repository_security": {
        "name": "Flux GitRepository Security",
        "description": "Insecure GitRepository configuration",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "insecure_skip_tls": r'spec:\s*\n\s*.*\n\s*insecure:\s*true',
            "no_secret_ref": r'kind:\s*GitRepository\s*\n(?!.*secretRef)',
            "public_repo_with_secrets": r'spec:\s*\n\s*url:\s*https://github\.com/[^/]+/[^/]+(?!.*secretRef)',
        },
        "mitre": "T1195.002",
    },
    "kustomization_security": {
        "name": "Flux Kustomization Security",
        "description": "Insecure Kustomization configuration",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "force_sync": r'spec:\s*\n\s*force:\s*true',
            "no_prune": r'spec:\s*\n\s*prune:\s*false',
            "target_namespace_any": r'targetNamespace:\s*["\']?\*',
        },
        "mitre": "T1195.002",
    },
    "image_automation": {
        "name": "Flux Image Automation Security",
        "description": "Insecure image update automation",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "any_image_policy": r'imagePolicy:\s*\n\s*semver:\s*\n\s*range:\s*["\']?\*',
            "latest_tag": r'imagePolicy:\s*\n\s*semver:\s*\n\s*range:\s*["\']?>=0\.0\.0',
        },
        "mitre": "T1195.002",
    },
    "notification_security": {
        "name": "Flux Notification Controller Security",
        "description": "Insecure notification configuration",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "webhook_no_secret": r'kind:\s*Provider\s*\n(?!.*secretRef)',
            "slack_plain_url": r'address:\s*https://hooks\.slack\.com/[^\n]+',
        },
        "mitre": "T1552",
    },
    "sops_decryption": {
        "name": "Flux SOPS Decryption Security",
        "description": "SOPS decryption key exposure",
        "severity": GitOpsSeverity.CRITICAL,
        "patterns": {
            "age_key_in_manifest": r'AGE-SECRET-KEY-[A-Z0-9]+',
            "pgp_key_in_manifest": r'-----BEGIN PGP PRIVATE KEY-----',
        },
        "mitre": "T1552",
    },
}

# Helm Security Checks
HELM_SECURITY_CHECKS = {
    "chart_repository_security": {
        "name": "Helm Chart Repository Security",
        "description": "Insecure chart repository configuration",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "http_repo": r'repository:\s*http://[^\s]+',
            "no_verify": r'--verify\s*=\s*false',
            "skip_tls": r'--insecure-skip-tls-verify',
        },
        "mitre": "T1195.002",
    },
    "values_injection": {
        "name": "Helm Values Injection",
        "description": "Potential values injection vulnerabilities",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "template_injection": r'\{\{\s*\.Values\.[^}]+\s*\|\s*default\s+["\'][^"\']*\$',
            "command_injection": r'command:\s*\[\s*["\']?/bin/sh',
            "env_from_values": r'value:\s*\{\{\s*\.Values\.[^}]+\s*\}\}',
        },
        "mitre": "T1195.002",
    },
    "secrets_in_values": {
        "name": "Helm Secrets in Values",
        "description": "Secrets exposed in values.yaml",
        "severity": GitOpsSeverity.CRITICAL,
        "patterns": {
            "plain_password": r'password:\s*["\'][^"\']+["\']',
            "plain_token": r'token:\s*["\'][^"\']+["\']',
            "base64_secret": r'[A-Za-z0-9+/]{40,}={0,2}',
            "aws_key": r'AKIA[0-9A-Z]{16}',
        },
        "mitre": "T1552",
    },
    "hooks_security": {
        "name": "Helm Hooks Security",
        "description": "Dangerous Helm hooks configuration",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "pre_install_delete": r'helm\.sh/hook:\s*pre-install.*\n.*delete-policy:\s*hook-succeeded',
            "post_delete_hook": r'helm\.sh/hook:\s*post-delete',
            "hook_weight_negative": r'helm\.sh/hook-weight:\s*"-',
        },
        "mitre": "T1195.002",
    },
    "rbac_in_charts": {
        "name": "Helm RBAC in Charts",
        "description": "Overly permissive RBAC in Helm charts",
        "severity": GitOpsSeverity.HIGH,
        "patterns": {
            "cluster_admin": r'clusterrolebinding.*\n.*roleRef:\s*\n.*name:\s*cluster-admin',
            "wildcard_verbs": r'verbs:\s*\n\s*-\s*["\']?\*',
            "wildcard_resources": r'resources:\s*\n\s*-\s*["\']?\*',
        },
        "mitre": "T1078",
    },
    "image_security": {
        "name": "Helm Image Security",
        "description": "Insecure image configurations in charts",
        "severity": GitOpsSeverity.MEDIUM,
        "patterns": {
            "latest_tag": r'tag:\s*["\']?latest["\']?',
            "no_pull_policy": r'image:\s*[^\n]+\n(?!.*imagePullPolicy)',
            "pull_always": r'imagePullPolicy:\s*Always',
        },
        "mitre": "T1195.002",
    },
}

# Git Repository Security Checks
GIT_REPO_SECURITY_CHECKS = {
    "branch_protection": {
        "name": "Branch Protection Missing",
        "description": "Main branch without protection rules",
        "severity": GitOpsSeverity.HIGH,
        "api_check": True,
        "mitre": "T1195.002",
    },
    "commit_signing": {
        "name": "Commit Signing Not Required",
        "description": "Repository allows unsigned commits",
        "severity": GitOpsSeverity.MEDIUM,
        "api_check": True,
        "mitre": "T1195.002",
    },
    "deploy_keys": {
        "name": "Deploy Keys with Write Access",
        "description": "Deploy keys with write permissions",
        "severity": GitOpsSeverity.HIGH,
        "api_check": True,
        "mitre": "T1078",
    },
    "secrets_in_repo": {
        "name": "Secrets in Repository",
        "description": "Hardcoded secrets in repository files",
        "severity": GitOpsSeverity.CRITICAL,
        "patterns": {
            "aws_access_key": r'AKIA[0-9A-Z]{16}',
            "aws_secret_key": r'[A-Za-z0-9/+=]{40}',
            "github_token": r'gh[pousr]_[A-Za-z0-9_]{36,}',
            "private_key": r'-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----',
            "api_key": r'api[_-]?key["\']?\s*[:=]\s*["\'][A-Za-z0-9]{20,}["\']',
        },
        "mitre": "T1552",
    },
}


@dataclass
class GitOpsFinding:
    """GitOps security finding."""
    tool: str  # argocd, flux, helm, git
    check_name: str
    severity: GitOpsSeverity
    description: str
    file_path: str = ""
    line_number: int = 0
    matched_pattern: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class GitOpsSecurityReport:
    """GitOps security scan report."""
    findings: List[GitOpsFinding] = field(default_factory=list)
    argocd_findings: int = 0
    flux_findings: int = 0
    helm_findings: int = 0
    git_findings: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    risk_score: float = 0.0


class GitOpsSecurityScanner:
    """
    GitOps Security Scanner.
    
    Scans for security issues in:
    - ArgoCD configurations
    - Flux configurations
    - Helm charts and values
    - Git repository settings
    """
    
    def __init__(self):
        self.findings: List[GitOpsFinding] = []
    
    def _read_file(self, path: str) -> Optional[str]:
        """Read file contents."""
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return None
    
    def _find_files(self, directory: str, patterns: List[str]) -> List[str]:
        """Find files matching patterns."""
        found = []
        
        for root, dirs, files in os.walk(directory):
            # Skip hidden and vendor directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['vendor', 'node_modules']]
            
            for file in files:
                for pattern in patterns:
                    if re.match(pattern, file):
                        found.append(os.path.join(root, file))
                        break
        
        return found[:100]  # Limit to 100 files
    
    def _scan_file_for_patterns(
        self,
        file_path: str,
        checks: Dict[str, Any],
        tool: str,
    ) -> List[GitOpsFinding]:
        """
        Scan a file for security patterns.
        
        Args:
            file_path: Path to file
            checks: Security checks dictionary
            tool: Tool name (argocd, flux, helm)
            
        Returns:
            List of findings
        """
        findings = []
        content = self._read_file(file_path)
        
        if not content:
            return findings
        
        lines = content.split('\n')
        
        for check_id, check_info in checks.items():
            if "patterns" not in check_info:
                continue
            
            for pattern_name, pattern in check_info["patterns"].items():
                try:
                    matches = list(re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE))
                    
                    for match in matches:
                        # Find line number
                        line_num = content[:match.start()].count('\n') + 1
                        
                        findings.append(GitOpsFinding(
                            tool=tool,
                            check_name=check_info["name"],
                            severity=check_info["severity"],
                            description=check_info["description"],
                            file_path=file_path,
                            line_number=line_num,
                            matched_pattern=pattern_name,
                            evidence={
                                "matched_text": match.group()[:100],
                                "pattern": pattern_name,
                                "context": lines[max(0, line_num-2):line_num+2] if line_num > 0 else [],
                            },
                            mitre_technique=check_info.get("mitre", ""),
                            remediation=self._get_remediation(tool, check_id),
                        ))
                except re.error as e:
                    logger.debug(f"Invalid regex pattern {pattern}: {e}")
        
        return findings
    
    def _get_remediation(self, tool: str, check_id: str) -> str:
        """Get remediation advice for a finding."""
        remediations = {
            "argocd": {
                "rbac_misconfigurations": "Implement least-privilege RBAC policies. Restrict access to specific projects and namespaces.",
                "insecure_webhook": "Configure webhook secret and enable TLS verification.",
                "application_sync_policy": "Review auto-sync and prune policies. Consider manual sync for production.",
                "secrets_in_repo": "Use External Secrets Operator or Sealed Secrets. Never commit plain secrets.",
                "project_restrictions": "Define specific destinations and source repositories. Avoid wildcards.",
            },
            "flux": {
                "git_repository_security": "Use SSH or HTTPS with authentication. Enable TLS verification.",
                "kustomization_security": "Review force and prune settings. Limit target namespaces.",
                "image_automation": "Define specific image policies. Avoid 'latest' or '*' patterns.",
                "sops_decryption": "Use external key management (AWS KMS, GCP KMS, Azure Key Vault).",
            },
            "helm": {
                "chart_repository_security": "Use HTTPS repositories with verification. Enable provenance checking.",
                "values_injection": "Validate all values before template rendering. Use strict input validation.",
                "secrets_in_values": "Use external secrets management. Never commit secrets to values files.",
                "rbac_in_charts": "Apply least-privilege RBAC. Avoid wildcards in verbs and resources.",
            },
            "git": {
                "branch_protection": "Enable branch protection rules for main branches.",
                "commit_signing": "Require GPG or SSH signed commits.",
                "secrets_in_repo": "Use git-secrets or pre-commit hooks. Rotate any exposed credentials.",
            },
        }
        
        return remediations.get(tool, {}).get(
            check_id,
            f"Triage GitOps check `{check_id}` for `{tool}`: confirm affected clusters/namespaces/repos, compare to your secure baseline (RBAC, secrets, sync policy), assign an owner, and track rollback.",
        )
    
    def scan_argocd(self, directory: str) -> List[GitOpsFinding]:
        """
        Scan ArgoCD configurations.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        findings = []
        
        # Find ArgoCD files
        argocd_patterns = [
            r'.*application.*\.ya?ml$',
            r'.*appproject.*\.ya?ml$',
            r'.*argocd.*\.ya?ml$',
            r'.*rbac.*\.ya?ml$',
        ]
        
        files = self._find_files(directory, argocd_patterns)
        
        for file_path in files:
            file_findings = self._scan_file_for_patterns(
                file_path,
                ARGOCD_SECURITY_CHECKS,
                "argocd"
            )
            findings.extend(file_findings)
        
        return findings
    
    def scan_flux(self, directory: str) -> List[GitOpsFinding]:
        """
        Scan Flux configurations.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        findings = []
        
        # Find Flux files
        flux_patterns = [
            r'.*gitrepository.*\.ya?ml$',
            r'.*kustomization.*\.ya?ml$',
            r'.*helmrelease.*\.ya?ml$',
            r'.*imagerepository.*\.ya?ml$',
            r'.*imagepolicy.*\.ya?ml$',
            r'.*provider.*\.ya?ml$',
            r'.*alert.*\.ya?ml$',
        ]
        
        files = self._find_files(directory, flux_patterns)
        
        for file_path in files:
            file_findings = self._scan_file_for_patterns(
                file_path,
                FLUX_SECURITY_CHECKS,
                "flux"
            )
            findings.extend(file_findings)
        
        return findings
    
    def scan_helm(self, directory: str) -> List[GitOpsFinding]:
        """
        Scan Helm charts and values.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of findings
        """
        findings = []
        
        # Find Helm files
        helm_patterns = [
            r'Chart\.ya?ml$',
            r'values.*\.ya?ml$',
            r'.*\.tpl$',
            r'templates/.*\.ya?ml$',
        ]
        
        files = self._find_files(directory, helm_patterns)
        
        for file_path in files:
            file_findings = self._scan_file_for_patterns(
                file_path,
                HELM_SECURITY_CHECKS,
                "helm"
            )
            findings.extend(file_findings)
        
        return findings
    
    def scan_git_repository(self, directory: str) -> List[GitOpsFinding]:
        """
        Scan Git repository for security issues.
        
        Args:
            directory: Repository directory
            
        Returns:
            List of findings
        """
        findings = []
        
        # Scan all text files for secrets
        text_extensions = ['.yaml', '.yml', '.json', '.tf', '.env', '.sh', '.py', '.js', '.ts']
        
        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['vendor', 'node_modules']]
            
            for file in files[:500]:  # Limit files
                if any(file.endswith(ext) for ext in text_extensions):
                    file_path = os.path.join(root, file)
                    file_findings = self._scan_file_for_patterns(
                        file_path,
                        {"secrets_in_repo": GIT_REPO_SECURITY_CHECKS["secrets_in_repo"]},
                        "git"
                    )
                    findings.extend(file_findings)
        
        return findings
    
    async def scan(
        self,
        directory: str,
        scan_argocd: bool = True,
        scan_flux: bool = True,
        scan_helm: bool = True,
        scan_git: bool = True,
    ) -> GitOpsSecurityReport:
        """
        Run comprehensive GitOps security scan.
        
        Args:
            directory: Directory to scan
            scan_argocd: Scan ArgoCD configs
            scan_flux: Scan Flux configs
            scan_helm: Scan Helm charts
            scan_git: Scan Git repo for secrets
            
        Returns:
            GitOpsSecurityReport
        """
        all_findings = []
        
        if scan_argocd:
            argocd_findings = self.scan_argocd(directory)
            all_findings.extend(argocd_findings)
        
        if scan_flux:
            flux_findings = self.scan_flux(directory)
            all_findings.extend(flux_findings)
        
        if scan_helm:
            helm_findings = self.scan_helm(directory)
            all_findings.extend(helm_findings)
        
        if scan_git:
            git_findings = self.scan_git_repository(directory)
            all_findings.extend(git_findings)
        
        # Count by tool
        argocd_count = sum(1 for f in all_findings if f.tool == "argocd")
        flux_count = sum(1 for f in all_findings if f.tool == "flux")
        helm_count = sum(1 for f in all_findings if f.tool == "helm")
        git_count = sum(1 for f in all_findings if f.tool == "git")
        
        # Count by severity
        critical = sum(1 for f in all_findings if f.severity == GitOpsSeverity.CRITICAL)
        high = sum(1 for f in all_findings if f.severity == GitOpsSeverity.HIGH)
        medium = sum(1 for f in all_findings if f.severity == GitOpsSeverity.MEDIUM)
        low = sum(1 for f in all_findings if f.severity == GitOpsSeverity.LOW)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return GitOpsSecurityReport(
            findings=all_findings,
            argocd_findings=argocd_count,
            flux_findings=flux_count,
            helm_findings=helm_count,
            git_findings=git_count,
            critical_count=critical,
            high_count=high,
            medium_count=medium,
            low_count=low,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[GitOpsFinding]) -> float:
        """Calculate overall risk score."""
        if not findings:
            return 0.0
        
        severity_weights = {
            GitOpsSeverity.CRITICAL: 10,
            GitOpsSeverity.HIGH: 7,
            GitOpsSeverity.MEDIUM: 4,
            GitOpsSeverity.LOW: 2,
            GitOpsSeverity.INFO: 0,
        }
        
        total = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_total = len(findings) * 10
        
        return min((total / max_total) * 100 if max_total > 0 else 0, 100)
    
    def get_findings(self) -> List[GitOpsFinding]:
        """Get all findings."""
        return self.findings

