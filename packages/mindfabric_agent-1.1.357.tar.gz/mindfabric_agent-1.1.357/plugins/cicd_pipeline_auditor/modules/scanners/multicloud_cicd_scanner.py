"""
Multi-Cloud CI/CD Security Scanner

Security analysis for multi-cloud CI/CD environments:
- Cross-cloud authentication
- Secrets management across clouds
- Multi-cloud deployment security
- Cloud provider integration risks
- Identity federation attacks
- Cross-cloud lateral movement

MITRE ATT&CK:
- T1552: Unsecured Credentials
- T1078: Valid Accounts
- T1199: Trusted Relationship
- T1550: Use Alternate Authentication Material
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


class MultiCloudSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class MultiCloudFindingType(str, Enum):
    """Types of multi-cloud CI/CD findings."""
    CREDENTIAL_EXPOSURE = "credential_exposure"
    IDENTITY_FEDERATION = "identity_federation"
    CROSS_CLOUD_ACCESS = "cross_cloud_access"
    SECRETS_MANAGEMENT = "secrets_management"
    DEPLOYMENT_SECURITY = "deployment_security"
    TRUST_BOUNDARY = "trust_boundary"


# =============================================================================
# Multi-Cloud Authentication Risks
# =============================================================================

MULTICLOUD_AUTH_RISKS = {
    "static_credentials_in_pipeline": {
        "name": "Static Cloud Credentials",
        "description": "Static credentials for multiple clouds in pipeline",
        "cloud_patterns": {
            "aws": [
                r"AKIA[0-9A-Z]{16}",
                r"aws_access_key_id",
                r"aws_secret_access_key",
            ],
            "azure": [
                r"[a-zA-Z0-9+/]{88}==",  # Azure storage key
                r"AZURE_CLIENT_SECRET",
                r"AZURE_TENANT_ID",
                r"azure_storage_connection_string",
            ],
            "gcp": [
                r"\"type\":\s*\"service_account\"",
                r"GOOGLE_APPLICATION_CREDENTIALS",
                r"gcp_service_account_key",
            ],
        },
        "severity": MultiCloudSeverity.CRITICAL,
        "mitre": "T1552.001",
    },
    "shared_service_accounts": {
        "name": "Shared Service Accounts",
        "description": "Same service account used across multiple clouds",
        "check": "Detect service account reuse",
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1078.004",
    },
    "overpermissioned_identities": {
        "name": "Overpermissioned Identities",
        "description": "CI/CD identities with excessive permissions",
        "aws_permissions": [
            "iam:*",
            "sts:*",
            "s3:*",
            "ec2:*",
        ],
        "azure_permissions": [
            "Owner",
            "Contributor",
            "User Access Administrator",
        ],
        "gcp_permissions": [
            "roles/owner",
            "roles/editor",
            "roles/iam.securityAdmin",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1078",
    },
}


# =============================================================================
# Cross-Cloud Identity Federation
# =============================================================================

IDENTITY_FEDERATION_RISKS = {
    "oidc_misconfiguration": {
        "name": "OIDC Federation Misconfiguration",
        "description": "Insecure OIDC federation between clouds",
        "platforms": {
            "github_aws": {
                "check": "token.actions.githubusercontent.com",
                "misconfigs": [
                    "No audience restriction",
                    "Wildcard subject claim",
                    "Missing repository restriction",
                ],
            },
            "gitlab_aws": {
                "check": "gitlab.com",
                "misconfigs": [
                    "No project_id restriction",
                    "No ref restriction",
                ],
            },
            "azure_devops_aws": {
                "check": "vstoken.dev.azure.com",
                "misconfigs": [
                    "No organization restriction",
                    "No project restriction",
                ],
            },
        },
        "severity": MultiCloudSeverity.CRITICAL,
        "mitre": "T1550.001",
    },
    "trust_relationship_abuse": {
        "name": "Trust Relationship Abuse",
        "description": "Exploitable trust relationships between clouds",
        "attack_vectors": [
            "Cross-account role assumption chain",
            "Federated identity token replay",
            "Service account impersonation",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1199",
    },
    "identity_provider_compromise": {
        "name": "Identity Provider Compromise",
        "description": "Risks from compromised identity provider",
        "providers": [
            "Okta",
            "Azure AD",
            "Google Workspace",
            "PingFederate",
        ],
        "severity": MultiCloudSeverity.CRITICAL,
        "mitre": "T1550",
    },
}


# =============================================================================
# Multi-Cloud Secrets Management
# =============================================================================

SECRETS_MANAGEMENT_RISKS = {
    "secrets_sprawl": {
        "name": "Secrets Sprawl",
        "description": "Secrets duplicated across multiple systems",
        "systems": [
            "AWS Secrets Manager",
            "Azure Key Vault",
            "GCP Secret Manager",
            "HashiCorp Vault",
            "GitHub Secrets",
            "GitLab CI Variables",
        ],
        "severity": MultiCloudSeverity.MEDIUM,
        "mitre": "T1552",
    },
    "no_rotation_policy": {
        "name": "Missing Rotation Policy",
        "description": "Secrets without rotation across clouds",
        "check": "Check for rotation configuration",
        "severity": MultiCloudSeverity.MEDIUM,
        "mitre": "T1552",
    },
    "cross_cloud_secret_access": {
        "name": "Cross-Cloud Secret Access",
        "description": "Secrets accessible from multiple clouds without audit",
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552",
    },
    "plaintext_in_logs": {
        "name": "Secrets in Logs",
        "description": "Secrets exposed in CI/CD logs across platforms",
        "platforms": ["GitHub Actions", "GitLab CI", "Azure DevOps", "Jenkins"],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552.001",
    },
}


# =============================================================================
# Cross-Cloud Deployment Risks
# =============================================================================

DEPLOYMENT_RISKS = {
    "artifact_tampering": {
        "name": "Artifact Tampering",
        "description": "Build artifacts modified between clouds",
        "check": "Verify artifact integrity across clouds",
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1195.002",
    },
    "deployment_credential_reuse": {
        "name": "Deployment Credential Reuse",
        "description": "Same credentials for multiple cloud deployments",
        "severity": MultiCloudSeverity.MEDIUM,
        "mitre": "T1078",
    },
    "no_deployment_approval": {
        "name": "Missing Deployment Approval",
        "description": "Cross-cloud deployments without approval gates",
        "severity": MultiCloudSeverity.MEDIUM,
        "mitre": "T1195",
    },
    "inconsistent_security_policies": {
        "name": "Inconsistent Security Policies",
        "description": "Different security policies across cloud deployments",
        "severity": MultiCloudSeverity.MEDIUM,
        "mitre": "T1195",
    },
}


# =============================================================================
# Platform-Specific Risks
# =============================================================================

PLATFORM_SPECIFIC_RISKS = {
    "terraform_cloud_integration": {
        "name": "Terraform Cloud Integration Risks",
        "description": "Terraform Cloud with multiple cloud providers",
        "risks": [
            "Workspace token exposure",
            "State file secrets",
            "Variable set sharing",
            "Run triggers across workspaces",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552",
    },
    "argocd_multicluster": {
        "name": "ArgoCD Multi-Cluster Risks",
        "description": "ArgoCD managing multiple cloud clusters",
        "risks": [
            "Cluster secret exposure",
            "Application privilege escalation",
            "Repository credential sharing",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552",
    },
    "flux_multicluster": {
        "name": "Flux Multi-Cluster Risks",
        "description": "Flux CD managing multiple cloud clusters",
        "risks": [
            "Kustomization cross-cluster access",
            "Helm release secrets",
            "Source controller credentials",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552",
    },
    "spinnaker_multicloud": {
        "name": "Spinnaker Multi-Cloud Risks",
        "description": "Spinnaker deploying to multiple clouds",
        "risks": [
            "Cloud provider credential exposure",
            "Pipeline secrets",
            "Canary analysis data exposure",
        ],
        "severity": MultiCloudSeverity.HIGH,
        "mitre": "T1552",
    },
}


@dataclass
class MultiCloudFinding:
    """A multi-cloud CI/CD security finding."""
    finding_type: MultiCloudFindingType
    severity: MultiCloudSeverity
    name: str
    description: str
    clouds_affected: List[str] = field(default_factory=list)
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    remediation: str = ""


@dataclass
class MultiCloudSecurityReport:
    """Multi-cloud CI/CD security report."""
    findings: List[MultiCloudFinding] = field(default_factory=list)
    clouds_detected: List[str] = field(default_factory=list)
    platforms_detected: List[str] = field(default_factory=list)
    risk_score: float = 0.0


class MultiCloudCICDScanner:
    """Scanner for multi-cloud CI/CD security."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[MultiCloudFinding] = []
    
    async def scan_pipeline_for_multicloud_credentials(
        self,
        pipeline_config: Dict[str, Any],
    ) -> List[MultiCloudFinding]:
        """
        Scan pipeline configuration for multi-cloud credential issues.
        
        Args:
            pipeline_config: Pipeline configuration to scan
            
        Returns:
            List of findings
        """
        findings = []
        config_str = str(pipeline_config)
        
        clouds_detected = []
        credentials_found = {}
        
        # Check for each cloud's credentials
        auth_risks = MULTICLOUD_AUTH_RISKS["static_credentials_in_pipeline"]
        
        for cloud, patterns in auth_risks["cloud_patterns"].items():
            import re
            for pattern in patterns:
                if re.search(pattern, config_str, re.IGNORECASE):
                    clouds_detected.append(cloud)
                    credentials_found[cloud] = pattern
                    break
        
        # If multiple clouds have credentials, flag it
        if len(clouds_detected) > 1:
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.CREDENTIAL_EXPOSURE,
                severity=auth_risks["severity"],
                name=auth_risks["name"],
                description=f"Static credentials found for multiple clouds: {', '.join(clouds_detected)}",
                clouds_affected=clouds_detected,
                evidence=credentials_found,
                mitre_technique=auth_risks["mitre"],
                remediation="Use OIDC federation instead of static credentials; implement secrets management",
            ))
        
        return findings
    
    async def check_oidc_federation_security(
        self,
        oidc_config: Dict[str, Any],
        cloud_provider: str,
    ) -> List[MultiCloudFinding]:
        """
        Check OIDC federation configuration security.
        
        Args:
            oidc_config: OIDC configuration
            cloud_provider: Target cloud provider
            
        Returns:
            List of findings
        """
        findings = []
        
        federation_risks = IDENTITY_FEDERATION_RISKS["oidc_misconfiguration"]
        
        # Check for missing restrictions
        subject_claim = oidc_config.get("subject", "")
        audience = oidc_config.get("audience", [])
        
        if "*" in subject_claim:
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.IDENTITY_FEDERATION,
                severity=federation_risks["severity"],
                name="Wildcard Subject Claim",
                description="OIDC subject claim contains wildcard, allowing broad access",
                clouds_affected=[cloud_provider],
                evidence={
                    "subject": subject_claim,
                },
                mitre_technique=federation_risks["mitre"],
                remediation="Restrict subject claim to specific repositories/branches",
            ))
        
        if not audience:
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.IDENTITY_FEDERATION,
                severity=MultiCloudSeverity.HIGH,
                name="Missing Audience Restriction",
                description="OIDC configuration missing audience restriction",
                clouds_affected=[cloud_provider],
                evidence={
                    "audience": audience,
                },
                mitre_technique=federation_risks["mitre"],
                remediation="Add audience restriction to OIDC configuration",
            ))
        
        return findings
    
    async def analyze_secrets_management(
        self,
        secrets_config: Dict[str, Any],
    ) -> List[MultiCloudFinding]:
        """
        Analyze secrets management across clouds.
        
        Args:
            secrets_config: Secrets management configuration
            
        Returns:
            List of findings
        """
        findings = []
        
        # Check for secrets sprawl
        secrets_locations = secrets_config.get("locations", [])
        
        if len(secrets_locations) > 2:
            sprawl_risk = SECRETS_MANAGEMENT_RISKS["secrets_sprawl"]
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.SECRETS_MANAGEMENT,
                severity=sprawl_risk["severity"],
                name=sprawl_risk["name"],
                description=f"Secrets stored in {len(secrets_locations)} different locations",
                evidence={
                    "locations": secrets_locations,
                },
                mitre_technique=sprawl_risk["mitre"],
                remediation="Consolidate secrets management; use single source of truth",
            ))
        
        # Check rotation policy
        rotation_enabled = secrets_config.get("rotation_enabled", False)
        
        if not rotation_enabled:
            rotation_risk = SECRETS_MANAGEMENT_RISKS["no_rotation_policy"]
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.SECRETS_MANAGEMENT,
                severity=rotation_risk["severity"],
                name=rotation_risk["name"],
                description="Secrets rotation not configured",
                evidence={
                    "rotation_enabled": False,
                },
                mitre_technique=rotation_risk["mitre"],
                remediation="Enable automatic secrets rotation",
            ))
        
        return findings
    
    async def check_deployment_security(
        self,
        deployment_config: Dict[str, Any],
    ) -> List[MultiCloudFinding]:
        """
        Check multi-cloud deployment security.
        
        Args:
            deployment_config: Deployment configuration
            
        Returns:
            List of findings
        """
        findings = []
        
        # Check for approval gates
        approval_gates = deployment_config.get("approval_gates", [])
        target_clouds = deployment_config.get("target_clouds", [])
        
        if len(target_clouds) > 1 and not approval_gates:
            approval_risk = DEPLOYMENT_RISKS["no_deployment_approval"]
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.DEPLOYMENT_SECURITY,
                severity=approval_risk["severity"],
                name=approval_risk["name"],
                description="Multi-cloud deployment without approval gates",
                clouds_affected=target_clouds,
                evidence={
                    "approval_gates": approval_gates,
                },
                mitre_technique=approval_risk["mitre"],
                remediation="Add approval gates for cross-cloud deployments",
            ))
        
        # Check artifact integrity
        artifact_signing = deployment_config.get("artifact_signing", False)
        
        if not artifact_signing:
            tampering_risk = DEPLOYMENT_RISKS["artifact_tampering"]
            findings.append(MultiCloudFinding(
                finding_type=MultiCloudFindingType.DEPLOYMENT_SECURITY,
                severity=tampering_risk["severity"],
                name=tampering_risk["name"],
                description="Artifacts not signed; potential for tampering",
                evidence={
                    "signing_enabled": False,
                },
                mitre_technique=tampering_risk["mitre"],
                remediation="Enable artifact signing; verify signatures before deployment",
            ))
        
        return findings
    
    async def analyze_platform_integrations(
        self,
        integrations: Dict[str, Any],
    ) -> List[MultiCloudFinding]:
        """
        Analyze multi-cloud platform integrations.
        
        Args:
            integrations: Platform integration configuration
            
        Returns:
            List of findings
        """
        findings = []
        
        for platform, config in integrations.items():
            if platform in PLATFORM_SPECIFIC_RISKS:
                platform_risks = PLATFORM_SPECIFIC_RISKS[platform]
                
                # Check for exposed credentials
                if config.get("credentials_exposed", False):
                    findings.append(MultiCloudFinding(
                        finding_type=MultiCloudFindingType.CREDENTIAL_EXPOSURE,
                        severity=platform_risks["severity"],
                        name=platform_risks["name"],
                        description=f"Credential exposure in {platform}",
                        evidence={
                            "platform": platform,
                            "risks": platform_risks["risks"],
                        },
                        mitre_technique=platform_risks["mitre"],
                        remediation=f"Review and secure {platform} credentials",
                    ))
        
        return findings
    
    async def run_full_scan(
        self,
        pipeline_config: Dict[str, Any] = None,
        oidc_configs: List[Dict[str, Any]] = None,
        secrets_config: Dict[str, Any] = None,
        deployment_config: Dict[str, Any] = None,
        integrations: Dict[str, Any] = None,
    ) -> MultiCloudSecurityReport:
        """
        Run full multi-cloud CI/CD security scan.
        
        Args:
            pipeline_config: Pipeline configuration
            oidc_configs: OIDC configurations
            secrets_config: Secrets management config
            deployment_config: Deployment config
            integrations: Platform integrations
            
        Returns:
            MultiCloudSecurityReport
        """
        all_findings = []
        clouds_detected = set()
        platforms_detected = set()
        
        if pipeline_config:
            cred_findings = await self.scan_pipeline_for_multicloud_credentials(pipeline_config)
            all_findings.extend(cred_findings)
            for f in cred_findings:
                clouds_detected.update(f.clouds_affected)
        
        if oidc_configs:
            for oidc_config in oidc_configs:
                cloud = oidc_config.get("cloud", "unknown")
                oidc_findings = await self.check_oidc_federation_security(oidc_config, cloud)
                all_findings.extend(oidc_findings)
                clouds_detected.add(cloud)
        
        if secrets_config:
            secrets_findings = await self.analyze_secrets_management(secrets_config)
            all_findings.extend(secrets_findings)
        
        if deployment_config:
            deployment_findings = await self.check_deployment_security(deployment_config)
            all_findings.extend(deployment_findings)
            clouds_detected.update(deployment_config.get("target_clouds", []))
        
        if integrations:
            integration_findings = await self.analyze_platform_integrations(integrations)
            all_findings.extend(integration_findings)
            platforms_detected.update(integrations.keys())
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return MultiCloudSecurityReport(
            findings=all_findings,
            clouds_detected=list(clouds_detected),
            platforms_detected=list(platforms_detected),
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[MultiCloudFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            MultiCloudSeverity.CRITICAL: 10,
            MultiCloudSeverity.HIGH: 7,
            MultiCloudSeverity.MEDIUM: 4,
            MultiCloudSeverity.LOW: 1,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[MultiCloudFinding]:
        """Get all findings."""
        return self.findings
    
    def get_all_risks(self) -> Dict[str, Any]:
        """Get all risk databases."""
        return {
            "auth_risks": MULTICLOUD_AUTH_RISKS,
            "federation_risks": IDENTITY_FEDERATION_RISKS,
            "secrets_risks": SECRETS_MANAGEMENT_RISKS,
            "deployment_risks": DEPLOYMENT_RISKS,
            "platform_risks": PLATFORM_SPECIFIC_RISKS,
        }

