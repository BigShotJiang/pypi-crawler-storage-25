"""
Report Generator Module

Generates reports, summaries, and remediation plans.
"""

import copy
from datetime import datetime
from typing import Dict, List, Any, Optional
from ...proto import (
    Vulnerability, VulnerabilityReport, RemediationPlan, RiskLevel,
    ScanStatistics, ComplianceCheck, DetectionMethod, ExploitationCommands
)


# 🔴 CICD EXPLOITATION COMMANDS by detection method
CICD_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    # Static Analysis
    "static_analysis": {
        "commands": [
            "$ cat .github/workflows/*.yml | grep -i 'secrets\\|password\\|token'",
            "$ grep -r 'run:' .github/workflows/ | grep -i 'curl\\|wget\\|eval'"
        ],
        "description": "Static analysis of CI/CD configuration files"
    },
    
    # Code Injection
    "code_injection": {
        "commands": [
            "$ grep -RInE '\\$\\{\\{|github\\.event\\.|fromJSON\\(|toJSON\\(|\\$\\(curl|\\`.*\\`' .github/workflows .gitlab-ci.yml Jenkinsfile 2>/dev/null | head -50",
            "$ git log -5 --format=%B | head -30"
        ],
        "description": "Static review: unsafe expression expansion in workflow definitions and recent commit messages"
    },
    
    # Secret Extraction
    "secret_extraction": {
        "commands": [
            "$ env | grep -iE 'secret|token|key|password|credential|auth' | sed 's/=.*/=***REDACTED***/'",
            "$ tr '\\0' '\\n' < /proc/1/environ 2>/dev/null | grep -iE 'secret|token|key|password' | sed 's/=.*/=***REDACTED***/' || true",
            "$ curl -sS --connect-timeout 2 http://169.254.169.254/latest/meta-data/iam/security-credentials/ 2>/dev/null | head -20 || true"
        ],
        "description": "Triage: detect secret-like env vars (redacted) and IMDS role exposure on runners"
    },
    
    # Excessive Privilege
    "excessive_privilege": {
        "commands": [
            "$ aws sts get-caller-identity",
            "$ aws iam list-attached-user-policies --user-name $(whoami)",
            "$ az ad signed-in-user show"
        ],
        "description": "Check excessive IAM/RBAC privileges"
    },
    
    # Supply Chain Test
    "supply_chain_test": {
        "commands": [
            "$ npm show package-name | grep postinstall",
            "$ pip download package --no-deps && unzip *.whl && cat setup.py",
            "$ cosign verify image:tag"
        ],
        "description": "Supply chain integrity verification"
    },
    
    # Task Injection
    "task_injection": {
        "commands": [
            "$ grep -RInE 'workflow_dispatch|repository_dispatch|inputs\\.|github\\.event\\.' .github/workflows 2>/dev/null | head -40",
            "$ curl -sS -o /dev/null -w '%{http_code}\\n' -H \"Authorization: Bearer ${GH_TOKEN:-}\" -H 'Accept: application/vnd.github+json' \"https://api.github.com/repos/${GITHUB_REPOSITORY:-owner/repo}/actions/workflows\" 2>/dev/null || true"
        ],
        "description": "Review workflow_dispatch inputs and verify GitHub API access is scoped (set GITHUB_REPOSITORY and GH_TOKEN)"
    },
    
    # Cloud Access Monitoring
    "cloud_access_monitoring": {
        "commands": [
            "$ aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventSource,AttributeValue=iam.amazonaws.com",
            "$ az monitor activity-log list --query \"[?authorization.action=='Microsoft.Authorization/roleAssignments/write']\""
        ],
        "description": "Monitor cloud access from CI/CD"
    },
    
    # Default
    "default": {
        "commands": [
            "$ cat .github/workflows/*.yml",
            "$ cat .gitlab-ci.yml",
            "$ cat Jenkinsfile"
        ],
        "description": "CI/CD pipeline analysis"
    }
}


def _expand_cicd_exploitation_commands() -> None:
    for member in DetectionMethod:
        key = member.value
        if key in CICD_EXPLOITATION_COMMANDS:
            continue
        CICD_EXPLOITATION_COMMANDS[key] = copy.deepcopy(CICD_EXPLOITATION_COMMANDS["default"])


_expand_cicd_exploitation_commands()


def build_commands_for_vulnerability(vuln: Vulnerability) -> Optional[ExploitationCommands]:
    """Generate exploitation commands based on vulnerability type."""
    method = vuln.detection_method.value if hasattr(vuln.detection_method, 'value') else str(vuln.detection_method)
    cmd_template = CICD_EXPLOITATION_COMMANDS.get(method, CICD_EXPLOITATION_COMMANDS["default"])
    
    return ExploitationCommands(
        server=vuln.location or vuln.platform.value if hasattr(vuln.platform, 'value') else str(vuln.platform),
        ip=None,
        commands=cmd_template.get("commands", []),
        description=cmd_template.get("description", f"CI/CD exploitation via {method}")
    )


class ReportGenerator:
    """Generates security reports and summaries"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def generate_summary(self, vulnerabilities: List[Vulnerability], statistics: ScanStatistics) -> Dict[str, Any]:
        """Generate summary of scan results."""
        return {
            "total_vulnerabilities": len(vulnerabilities),
            "critical_count": len([v for v in vulnerabilities if v.risk_level == RiskLevel.CRITICAL]),
            "high_count": len([v for v in vulnerabilities if v.risk_level == RiskLevel.HIGH]),
            "medium_count": len([v for v in vulnerabilities if v.risk_level == RiskLevel.MEDIUM]),
            "low_count": len([v for v in vulnerabilities if v.risk_level == RiskLevel.LOW]),
            "most_common_issues": self.get_most_common_issues(vulnerabilities),
            "platforms_with_issues": list(set(v.platform for v in vulnerabilities)),
            "scan_duration": statistics.scan_duration_seconds,
            "files_analyzed": statistics.files_processed
        }
    
    def get_most_common_issues(self, vulnerabilities: List[Vulnerability]) -> List[Dict[str, Any]]:
        """Get most common vulnerability types."""
        issue_counts = {}
        for vuln in vulnerabilities:
            issue_type = vuln.detection_method.value
            issue_counts[issue_type] = issue_counts.get(issue_type, 0) + 1
        
        sorted_issues = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        return [{"type": issue_type, "count": count} for issue_type, count in sorted_issues]
    
    def get_target_environment(self) -> str:
        """Get target environment name."""
        return "ci_cd_infrastructure"
    
    def generate_vulnerability_reports(self, vulnerabilities: List[Vulnerability]) -> List[VulnerabilityReport]:
        """Generate detailed vulnerability reports."""
        reports = []
        
        for vuln in vulnerabilities:
            # 🔴 Attach commands if not present
            if not getattr(vuln, "commands", None):
                vuln.commands = build_commands_for_vulnerability(vuln)
            
            report = VulnerabilityReport(
                vulnerability_id=vuln.id,
                title=vuln.title,
                description=vuln.description,
                affected_components=[vuln.location],
                exploitation_path=[
                    {"step": "1", "description": "Access CI/CD configuration"},
                    {"step": "2", "description": "Exploit identified vulnerability"},
                    {"step": "3", "description": "Gain unauthorized access or execute malicious code"}
                ],
                potential_impact=self.get_impact_description(vuln.risk_level),
                screenshot_paths=[],
                is_false_positive=False,
                verification_steps=[
                    "Review configuration file",
                    "Test exploitation scenario",
                    "Verify security controls"
                ],
                fix_verification=[
                    "Apply recommended fixes",
                    "Re-run security scan",
                    "Verify vulnerability is resolved"
                ]
            )
            reports.append(report)
        
        return reports
    
    def get_impact_description(self, risk_level: RiskLevel) -> str:
        """Get impact description based on risk level."""
        impact_map = {
            RiskLevel.CRITICAL: "Complete compromise of CI/CD pipeline, potential for supply chain attacks",
            RiskLevel.HIGH: "Significant security risk, potential for privilege escalation",
            RiskLevel.MEDIUM: "Moderate security risk, potential for information disclosure",
            RiskLevel.LOW: "Minor security risk, limited impact"
        }
        return impact_map.get(risk_level, "Unknown impact")
    
    def generate_remediation_plan(self, vulnerabilities: List[Vulnerability]) -> RemediationPlan:
        """Generate remediation plan for identified vulnerabilities."""
        critical_vulns = [v for v in vulnerabilities if v.risk_level == RiskLevel.CRITICAL]
        high_vulns = [v for v in vulnerabilities if v.risk_level == RiskLevel.HIGH]
        
        steps = []
        required_changes = {}
        
        priority_vulns = critical_vulns + high_vulns
        
        for i, vuln in enumerate(priority_vulns, 1):
            step = {
                "step_number": i,
                "vulnerability_id": vuln.id,
                "title": vuln.title,
                "priority": "Critical" if vuln.risk_level == RiskLevel.CRITICAL else "High",
                "estimated_effort": "Low" if len(vuln.recommendations) <= 2 else "Medium",
                "actions": vuln.recommendations,
                "validation": f"Re-scan {vuln.location} to verify fix"
            }
            steps.append(step)
            
            file_path = vuln.location.split(':')[0]
            if file_path not in required_changes:
                required_changes[file_path] = []
            required_changes[file_path].extend(vuln.recommendations)
        
        return RemediationPlan(
            plan_id=f"remediation_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            vulnerabilities=[v.id for v in priority_vulns],
            steps=steps,
            required_changes=required_changes,
            estimated_effort=f"{len(steps)} hours",
            priority_order=[v.id for v in priority_vulns],
            validation_steps=[
                "Execute remediation steps in priority order",
                "Re-run CI/CD security audit",
                "Verify all critical and high vulnerabilities are resolved",
                "Update security documentation"
            ]
        )
    
    def calculate_overall_risk(self, vulnerabilities: List[Vulnerability]) -> RiskLevel:
        """Calculate overall risk level based on vulnerabilities."""
        if any(v.risk_level == RiskLevel.CRITICAL for v in vulnerabilities):
            return RiskLevel.CRITICAL
        elif any(v.risk_level == RiskLevel.HIGH for v in vulnerabilities):
            return RiskLevel.HIGH
        elif any(v.risk_level == RiskLevel.MEDIUM for v in vulnerabilities):
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW
    
    def generate_executive_summary(self, vulnerabilities: List[Vulnerability], statistics: ScanStatistics) -> str:
        """Generate executive summary of the audit."""
        critical_count = len([v for v in vulnerabilities if v.risk_level == RiskLevel.CRITICAL])
        high_count = len([v for v in vulnerabilities if v.risk_level == RiskLevel.HIGH])
        
        summary = f"CI/CD Pipeline Security Audit identified {len(vulnerabilities)} vulnerabilities "
        summary += f"({critical_count} critical, {high_count} high risk) across {statistics.total_config_files} "
        summary += f"configuration files in {statistics.total_repositories} repositories. "
        
        if critical_count > 0:
            summary += "Immediate attention required for critical vulnerabilities including potential "
            summary += "code injection and exposed secrets. "
        
        summary += f"Audit completed in {statistics.scan_duration_seconds:.1f} seconds with recommendations "
        summary += "for implementing security best practices and compliance with industry standards."
        
        return summary
    
    def generate_compliance_status(self, compliance_checks: List[ComplianceCheck]) -> Dict[str, str]:
        """Generate compliance status summary."""
        status = {}
        
        for check in compliance_checks:
            standard = check.standard
            if standard not in status:
                status[standard] = "Pass"
            
            if check.status == "Fail":
                status[standard] = "Fail"
        
        return status

