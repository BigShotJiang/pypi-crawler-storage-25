"""
Travis CI Analyzer Module
"""

import re
from typing import Dict, List, Any
from ...proto import Vulnerability, CodeInjectionVector, CICDPlatform, RiskLevel, DetectionMethod


class TravisAnalyzer:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.secret_patterns = plugin_instance.secret_patterns if hasattr(plugin_instance, 'secret_patterns') else {}
    
    def check_travis_privileges(self, travis_data: Dict[str, Any]) -> bool:
        if not travis_data:
            return False
        if travis_data.get('sudo') == 'required':
            return True
        services = travis_data.get('services', [])
        if 'docker' in services:
            return True
        return False
    
    def analyze_config(self, file_path: str, travis_data: Dict[str, Any]) -> List[Vulnerability]:
        vulnerabilities = []
        if not travis_data:
            return vulnerabilities
        
        if travis_data.get('sudo') == 'required':
            vulnerabilities.append(Vulnerability(
                id=f"TR-SUDO-001-{hash(file_path) % 10000}",
                title="Travis CI requires sudo access",
                description="Build configuration requires sudo which increases attack surface",
                location=file_path,
                platform=CICDPlatform.TRAVIS,
                detection_method=DetectionMethod.EXCESSIVE_PRIVILEGE,
                risk_level=RiskLevel.MEDIUM,
                cwes=["CWE-250"],
                recommendations=["Avoid sudo usage when possible", "Use containerized builds instead", "Minimize privileged operations"]
            ))
        
        env_vars = travis_data.get('env', {})
        if isinstance(env_vars, dict):
            global_vars = env_vars.get('global', [])
            if isinstance(global_vars, list):
                for var_idx, var in enumerate(global_vars):
                    if isinstance(var, str) and '=' in var:
                        var_name, var_value = var.split('=', 1)
                        for secret_type, pattern in self.secret_patterns.items():
                            if re.search(pattern, var_value, re.IGNORECASE):
                                vulnerabilities.append(Vulnerability(
                                    id=f"TR-ENV-001-{hash(f'{file_path}:{var_idx}') % 10000}",
                                    title="Travis CI environment variable contains secret",
                                    description=f"Environment variable '{var_name}' contains {secret_type}",
                                    location=f"{file_path}:env.global[{var_idx}]",
                                    platform=CICDPlatform.TRAVIS,
                                    detection_method=DetectionMethod.SECRET_EXTRACTION,
                                    risk_level=RiskLevel.CRITICAL,
                                    cwes=["CWE-798"],
                                    recommendations=["Use Travis CI encrypted environment variables", "Use travis encrypt command for sensitive data", "Implement proper secret management"]
                                ))
        return vulnerabilities
    
    def find_injection_vectors(self, file_path: str, travis_data: Dict[str, Any]) -> List[CodeInjectionVector]:
        injection_vectors = []
        if not travis_data:
            return injection_vectors
        
        script_phases = ['before_script', 'script', 'after_script', 'after_success', 'after_failure']
        for phase in script_phases:
            scripts = travis_data.get(phase, [])
            if isinstance(scripts, list):
                for script_idx, script in enumerate(scripts):
                    if isinstance(script, str):
                        if '$TRAVIS_PULL_REQUEST_BRANCH' in script or '$TRAVIS_COMMIT_MESSAGE' in script:
                            injection_vectors.append(CodeInjectionVector(
                                vector_type="Travis CI Variable Injection",
                                location=f"{file_path}:{phase}[{script_idx}]",
                                trigger_method="User-controlled Travis environment variables",
                                impact="Command injection in Travis CI build",
                                risk_level=RiskLevel.MEDIUM,
                                remediation="Sanitize Travis environment variables before use"
                            ))
        return injection_vectors

