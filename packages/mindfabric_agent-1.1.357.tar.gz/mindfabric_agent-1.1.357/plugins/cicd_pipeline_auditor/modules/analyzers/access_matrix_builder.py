"""
Build operator-facing access matrices from aggregated CI/CD scan artifacts.

Maps who (workflows, tokens, service accounts) can reach what (repos, cloud, registries)
and highlights excessive or high-risk edges. This is not RBAC sync — it is evidence
for security review after a local config scan.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Sequence

from ...proto import AccessMatrix


def _risk_str(obj: Any) -> str:
    rl = getattr(obj, "risk_level", None)
    if rl is None:
        return "unknown"
    return getattr(rl, "value", str(rl))


def build_access_matrix(
    scan_id: str,
    *,
    platforms_scanned: Sequence[Any],
    config_files: Sequence[Any],
    workflow_permissions: Sequence[Any],
    iam_permissions: Sequence[Any],
    secrets: Sequence[Any],
    vulnerabilities: Sequence[Any],
    injection_vectors: Sequence[Any],
) -> AccessMatrix:
    """Single consolidated matrix for the whole scan (suitable for SOC / AppSec handoff)."""

    sources: List[str] = []
    for p in platforms_scanned:
        v = getattr(p, "value", str(p))
        sources.append(f"platform:{v}")
    if config_files:
        sources.append(f"ci_config_files:{len(config_files)}")
    if workflow_permissions:
        sources.append("github_token_workflows")
    if iam_permissions:
        sources.append("declared_iam_rbac")
    if secrets:
        sources.append("detected_secrets_surfaces")

    targets: List[str] = ["repositories", "build_artifacts", "dependency_registries"]
    if iam_permissions:
        targets.extend(["cloud_accounts", "deployment_targets"])
    if secrets:
        targets.append("credential_material_in_pipeline")

    access_levels: Dict[str, Dict[str, str]] = {}

    for wp in workflow_permissions:
        fp = getattr(wp, "file_path", "workflow") or "workflow"
        key = f"workflow:{fp}"
        cur = getattr(wp, "current_permissions", None) or {}
        tok = getattr(wp, "github_token_permissions", None) or {}
        merged: Dict[str, str] = {}
        if isinstance(cur, dict):
            merged.update({str(k): str(v) for k, v in cur.items()})
        if isinstance(tok, dict):
            for k, v in tok.items():
                merged[f"github_token.{k}"] = str(v)
        if merged:
            access_levels[key] = merged

    for iam in iam_permissions:
        sa = getattr(iam, "service_account", "unknown") or "unknown"
        plat = getattr(iam, "platform", "cloud") or "cloud"
        perms = getattr(iam, "permissions", None) or []
        roles = getattr(iam, "roles", None) or []
        summary = []
        if perms:
            summary.append(f"permissions={len(perms)}")
        if roles:
            summary.append(f"roles={len(roles)}")
        access_levels[f"iam:{plat}:{sa}"] = {
            "scope": ", ".join(summary) if summary else "declared",
            "excessive": str(bool(getattr(iam, "excessive", False))),
        }

    excessive_access: List[Dict[str, str]] = []

    for wp in workflow_permissions:
        if getattr(wp, "has_excessive_permissions", False):
            excessive_access.append(
                {
                    "source": getattr(wp, "file_path", ""),
                    "target": "repository_contents_artifacts",
                    "issue": "Workflow permissions or GITHUB_TOKEN scope broader than least-privilege",
                    "risk": _risk_str(wp),
                }
            )

    for iam in iam_permissions:
        if getattr(iam, "excessive", False):
            excessive_access.append(
                {
                    "source": getattr(iam, "service_account", ""),
                    "target": getattr(iam, "platform", "cloud"),
                    "issue": "Declared IAM/RBAC permissions flagged as excessive for CI context",
                    "risk": _risk_str(iam),
                }
            )

    for s in secrets:
        rl = _risk_str(s)
        if rl in ("high", "critical"):
            excessive_access.append(
                {
                    "source": getattr(s, "location", ""),
                    "target": "secret_exposure",
                    "issue": f"High-risk secret pattern: {getattr(s, 'secret_type', 'unknown')}",
                    "risk": rl,
                }
            )

    for v in vulnerabilities:
        if getattr(v, "risk_level", None) and _risk_str(v) in ("high", "critical"):
            excessive_access.append(
                {
                    "source": getattr(v, "location", ""),
                    "target": "pipeline_integrity",
                    "issue": getattr(v, "title", "Vulnerability")[:200],
                    "risk": _risk_str(v),
                }
            )

    for inj in injection_vectors[:50]:
        excessive_access.append(
            {
                "source": getattr(inj, "location", ""),
                "target": "pipeline_execution",
                "issue": f"Injection vector: {getattr(inj, 'vector_type', 'unknown')}",
                "risk": _risk_str(inj),
            }
        )

    recommended_changes: List[Dict[str, Any]] = []
    if any(getattr(wp, "has_excessive_permissions", False) for wp in workflow_permissions):
        recommended_changes.append(
            {
                "area": "github_actions",
                "action": "Set permissions: read-all or explicit least privilege; avoid contents: write unless required",
                "reference": "https://docs.github.com/actions/security-guides/automatic-token-authentication",
            }
        )
    if any(getattr(iam, "excessive", False) for iam in iam_permissions):
        recommended_changes.append(
            {
                "area": "iam",
                "action": "Split CI service accounts; scope cloud roles to pipeline needs only",
                "reference": "NIST AC-6 least privilege",
            }
        )
    if secrets:
        recommended_changes.append(
            {
                "area": "secrets",
                "action": "Move secrets to OIDC / vault / platform secret store; rotate any exposed values",
                "reference": "OWASP CI/CD Top 10",
            }
        )

    excessive_access = excessive_access[:100]

    return AccessMatrix(
        scan_id=scan_id,
        timestamp=datetime.now(),
        source_components=sources,
        target_components=sorted(set(targets)),
        access_levels=access_levels,
        excessive_access=excessive_access,
        recommended_changes=recommended_changes,
    )
