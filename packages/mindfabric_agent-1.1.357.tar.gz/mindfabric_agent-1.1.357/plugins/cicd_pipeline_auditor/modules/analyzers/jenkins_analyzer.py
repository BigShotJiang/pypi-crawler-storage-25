"""
Jenkins Analyzer Module

Analyzes Jenkinsfiles for security vulnerabilities.
"""

import re
from typing import Dict, List, Any
from ...proto import (
    Vulnerability, CodeInjectionVector, CICDPlatform, RiskLevel, DetectionMethod
)


class JenkinsAnalyzer:
    """Analyzes Jenkinsfiles"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.secret_patterns = plugin_instance.secret_patterns if hasattr(plugin_instance, 'secret_patterns') else {}
    
    def analyze_jenkinsfile(self, file_path: str, jenkins_content: str) -> List[Vulnerability]:
        """Analyze Jenkinsfile for security vulnerabilities."""
        vulnerabilities = []
        
        # Check for hardcoded credentials
        lines = jenkins_content.split('\n')
        for line_num, line in enumerate(lines, 1):
            # Check for environment blocks with hardcoded secrets
            if 'environment' in line.lower() and '{' in line:
                # Look for patterns like: AWS_ACCESS_KEY = 'AKIA...'
                env_pattern = r'(\w+)\s*=\s*[\'"]([^\'"]+)[\'"]'
                matches = re.finditer(env_pattern, line)
                for match in matches:
                    var_name, var_value = match.groups()
                    # Check if value looks like a secret
                    for secret_type, pattern in self.secret_patterns.items():
                        if re.search(pattern, var_value, re.IGNORECASE):
                            vuln = Vulnerability(
                                id=f"JK-SECRET-001-{hash(f'{file_path}:{line_num}') % 10000}",
                                title="Hardcoded secret in Jenkinsfile",
                                description=f"Variable '{var_name}' contains hardcoded {secret_type}",
                                location=f"{file_path}:{line_num}",
                                platform=CICDPlatform.JENKINS,
                                detection_method=DetectionMethod.SECRET_EXTRACTION,
                                risk_level=RiskLevel.CRITICAL,
                                cwes=["CWE-798"],
                                recommendations=[
                                    "Use Jenkins Credentials Store for secrets",
                                    "Use credentials() function to access stored credentials",
                                    "Implement credential rotation"
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        # Check for shell injection vulnerabilities
        shell_injection_patterns = [
            r'sh\s+[\'"].*\$\{.*\}.*[\'"]',  # Shell commands with variable interpolation
            r'bat\s+[\'"].*\$\{.*\}.*[\'"]',  # Batch commands with variable interpolation
        ]
        
        for line_num, line in enumerate(lines, 1):
            for pattern in shell_injection_patterns:
                if re.search(pattern, line):
                    vuln = Vulnerability(
                        id=f"JK-INJECT-001-{hash(f'{file_path}:{line_num}') % 10000}",
                        title="Potential shell injection in Jenkinsfile",
                        description="Shell command uses unsanitized variable interpolation",
                        location=f"{file_path}:{line_num}",
                        platform=CICDPlatform.JENKINS,
                        detection_method=DetectionMethod.CODE_INJECTION,
                        risk_level=RiskLevel.HIGH,
                        cwes=["CWE-78"],
                        recommendations=[
                            "Sanitize variables before using in shell commands",
                            "Use parameterized builds instead of direct interpolation",
                            "Validate and escape user input"
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def find_injection_vectors(self, file_path: str, jenkins_content: str) -> List[CodeInjectionVector]:
        """Find potential code injection vectors in Jenkins files."""
        injection_vectors = []
        
        lines = jenkins_content.split('\n')
        for line_num, line in enumerate(lines, 1):
            # Check for parameter injection
            if 'params.' in line and ('sh ' in line or 'bat ' in line):
                vector = CodeInjectionVector(
                    vector_type="Jenkins Parameter Injection",
                    location=f"{file_path}:{line_num}",
                    trigger_method="Build parameters in shell commands",
                    impact="Command injection through build parameters",
                    risk_level=RiskLevel.HIGH,
                    remediation="Validate and sanitize build parameters"
                )
                injection_vectors.append(vector)
        
        return injection_vectors

