"""
GitHub Actions Analyzer Module

Analyzes GitHub Actions workflows for security vulnerabilities.
"""

import re
from typing import Dict, List, Any, Optional
from ...proto import (
    Vulnerability, WorkflowPermission, CodeInjectionVector,
    CICDPlatform, RiskLevel, DetectionMethod
)


class GitHubAnalyzer:
    """Analyzes GitHub Actions workflows"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check_github_privileges(self, workflow_data: Dict[str, Any]) -> bool:
        """Check if GitHub workflow has privilege issues."""
        if not workflow_data:
            return False
        
        # Check for excessive permissions
        permissions = workflow_data.get('permissions', {})
        if not permissions:
            return True  # No explicit permissions means write-all by default
        
        # Check for write-all or admin permissions
        dangerous_permissions = ['write-all', 'admin']
        for perm_value in permissions.values():
            if perm_value in dangerous_permissions:
                return True
        
        return False
    
    def analyze_workflow(self, file_path: str, workflow_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitHub workflow for security vulnerabilities."""
        vulnerabilities = []
        
        if not workflow_data:
            return vulnerabilities
        
        # Check for excessive permissions
        permissions = workflow_data.get('permissions', {})
        if not permissions:
            vuln = Vulnerability(
                id=f"GH-PERM-001-{hash(file_path) % 10000}",
                title="GitHub Workflow missing explicit permissions",
                description="Workflow uses default write-all permissions for GITHUB_TOKEN",
                location=file_path,
                platform=CICDPlatform.GITHUB,
                detection_method=DetectionMethod.STATIC_ANALYSIS,
                risk_level=RiskLevel.HIGH,
                cwes=["CWE-250"],
                recommendations=[
                    "Add explicit permissions block with minimal required permissions",
                    "Use 'read-all' as base permission and grant specific write permissions only when needed"
                ]
            )
            vulnerabilities.append(vuln)
        
        # Check for third-party actions without version pinning
        jobs = workflow_data.get('jobs', {})
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict) and 'uses' in step:
                        action = step['uses']
                        if '@' in action and not action.split('@')[1].startswith('v'):
                            # Check if it's not pinned to a specific version
                            if action.endswith('@main') or action.endswith('@master') or action.endswith('@latest'):
                                vuln = Vulnerability(
                                    id=f"GH-ACTION-001-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                    title="Unpinned third-party GitHub Action",
                                    description=f"Action '{action}' is not pinned to a specific version",
                                    location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                    platform=CICDPlatform.GITHUB,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.MEDIUM,
                                    cwes=["CWE-829"],
                                    recommendations=[
                                        "Pin actions to specific versions or commit SHAs",
                                        "Use Dependabot to keep action versions updated"
                                    ]
                                )
                                vulnerabilities.append(vuln)
        
        # Check for command injection vulnerabilities
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict) and 'run' in step:
                        run_command = step['run']
                        # Look for potential injection points
                        if '${{' in run_command and ('github.event' in run_command):
                            vuln = Vulnerability(
                                id=f"GH-INJECT-001-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                title="Potential command injection in workflow",
                                description="Workflow uses user-controlled input in shell commands",
                                location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                platform=CICDPlatform.GITHUB,
                                detection_method=DetectionMethod.CODE_INJECTION,
                                risk_level=RiskLevel.CRITICAL,
                                cwes=["CWE-78", "CWE-94"],
                                recommendations=[
                                    "Sanitize user input before using in shell commands",
                                    "Use environment variables instead of direct interpolation",
                                    "Validate and escape user-controlled data"
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def analyze_permissions(self, file_path: str, workflow_data: Dict[str, Any]) -> Optional[WorkflowPermission]:
        """Analyze GitHub workflow permissions."""
        if not workflow_data:
            return None
        
        permissions = workflow_data.get('permissions', {})
        
        # If no permissions specified, it defaults to write-all
        if not permissions:
            current_permissions = {'default': 'write-all'}
            has_excessive = True
            recommended_permissions = {'contents': 'read'}
            risk_level = RiskLevel.HIGH
        else:
            current_permissions = permissions
            # Check for excessive permissions
            excessive_perms = []
            for perm, level in permissions.items():
                if level in ['write', 'admin'] and perm not in ['contents', 'deployments']:
                    excessive_perms.append(perm)
            
            has_excessive = len(excessive_perms) > 0
            risk_level = RiskLevel.HIGH if has_excessive else RiskLevel.LOW
            
            # Recommend minimal permissions
            recommended_permissions = {'contents': 'read'}
            if 'deployments' in permissions:
                recommended_permissions['deployments'] = 'write'
        
        return WorkflowPermission(
            file_path=file_path,
            current_permissions=current_permissions,
            recommended_permissions=recommended_permissions,
            has_excessive_permissions=has_excessive,
            risk_level=risk_level,
            github_token_permissions=current_permissions
        )
    
    def find_injection_vectors(self, file_path: str, workflow_data: Dict[str, Any]) -> List[CodeInjectionVector]:
        """Find potential code injection vectors in GitHub workflows."""
        injection_vectors = []
        
        if not workflow_data:
            return injection_vectors
        
        jobs = workflow_data.get('jobs', {})
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict) and 'run' in step:
                        run_command = step['run']
                        
                        # Check for various injection patterns
                        injection_patterns = [
                            (r'\$\{\{\s*github\.event\.pull_request\.title\s*\}\}', 'Pull Request Title Injection'),
                            (r'\$\{\{\s*github\.event\.head_commit\.message\s*\}\}', 'Commit Message Injection'),
                            (r'\$\{\{\s*github\.event\.issue\.title\s*\}\}', 'Issue Title Injection'),
                            (r'\$\{\{\s*github\.event\..*\.body\s*\}\}', 'User Content Injection')
                        ]
                        
                        for pattern, vector_type in injection_patterns:
                            if re.search(pattern, run_command):
                                vector = CodeInjectionVector(
                                    vector_type=vector_type,
                                    location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                    trigger_method="User-controlled event data in workflow context",
                                    impact="Arbitrary command execution in CI/CD environment",
                                    risk_level=RiskLevel.CRITICAL,
                                    remediation="Sanitize user input and use environment variables"
                                )
                                injection_vectors.append(vector)
        
        return injection_vectors
    
    def analyze_self_hosted_runners(self, file_path: str, workflow_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitHub workflow for self-hosted runner security issues."""
        vulnerabilities = []
        
        if not workflow_data:
            return vulnerabilities
        
        jobs = workflow_data.get('jobs', {})
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                runs_on = job_config.get('runs-on', '')
                
                # Check for self-hosted runners
                if 'self-hosted' in str(runs_on):
                    # Self-hosted runner with fork access
                    on_config = workflow_data.get('on', {})
                    if isinstance(on_config, dict):
                        pr_config = on_config.get('pull_request', {}) or on_config.get('pull_request_target', {})
                        if pr_config:
                            vuln = Vulnerability(
                                id=f"GH-RUNNER-001-{hash(f'{file_path}:{job_name}') % 10000}",
                                title="Self-hosted runner accessible from pull requests",
                                description="Self-hosted runners can be exploited by malicious PRs from forks",
                                location=f"{file_path}:job[{job_name}]",
                                platform=CICDPlatform.GITHUB,
                                detection_method=DetectionMethod.STATIC_ANALYSIS,
                                risk_level=RiskLevel.CRITICAL,
                                cwes=["CWE-284", "CWE-269"],
                                recommendations=[
                                    "Use 'pull_request_target' event carefully with proper security controls",
                                    "Implement approval workflow for fork PRs",
                                    "Use GitHub-hosted runners for untrusted workflows",
                                    "Implement runner group isolation"
                                ]
                            )
                            vulnerabilities.append(vuln)
                    
                    # Self-hosted runner without environment isolation
                    steps = job_config.get('steps', [])
                    for step_idx, step in enumerate(steps):
                        if isinstance(step, dict):
                            # Check for dangerous commands on self-hosted
                            run_cmd = step.get('run', '')
                            dangerous_patterns = [
                                'docker', 'sudo', 'rm -rf', 'chmod 777',
                                '/etc/', '/var/', '/root/', '~/',
                            ]
                            for pattern in dangerous_patterns:
                                if pattern in run_cmd:
                                    vuln = Vulnerability(
                                        id=f"GH-RUNNER-002-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                        title=f"Potentially dangerous command on self-hosted runner",
                                        description=f"Self-hosted runner executing potentially dangerous command containing '{pattern}'",
                                        location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                        platform=CICDPlatform.GITHUB,
                                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                                        risk_level=RiskLevel.HIGH,
                                        cwes=["CWE-78"],
                                        recommendations=[
                                            "Use containerized runners for isolation",
                                            "Implement least privilege for runner service account",
                                            "Clean up runner environment after each job",
                                            "Use ephemeral runners"
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
                
                # Check for runner group not specified
                if 'self-hosted' in str(runs_on):
                    if isinstance(runs_on, str) and runs_on == 'self-hosted':
                        vuln = Vulnerability(
                            id=f"GH-RUNNER-003-{hash(f'{file_path}:{job_name}') % 10000}",
                            title="Self-hosted runner without group specification",
                            description="Workflow uses self-hosted runners without specifying a runner group",
                            location=f"{file_path}:job[{job_name}]",
                            platform=CICDPlatform.GITHUB,
                            detection_method=DetectionMethod.STATIC_ANALYSIS,
                            risk_level=RiskLevel.MEDIUM,
                            cwes=["CWE-284"],
                            recommendations=[
                                "Specify runner group labels for access control",
                                "Use runner labels to match specific runner configurations",
                                "Implement runner groups for different security levels"
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def analyze_artifact_security(self, file_path: str, workflow_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitHub workflow for artifact poisoning vulnerabilities."""
        vulnerabilities = []
        
        if not workflow_data:
            return vulnerabilities
        
        jobs = workflow_data.get('jobs', {})
        artifact_uploads = []
        artifact_downloads = []
        
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict):
                        uses = step.get('uses', '')
                        
                        # Track artifact uploads
                        if 'actions/upload-artifact' in uses:
                            with_config = step.get('with', {})
                            artifact_name = with_config.get('name', 'unknown')
                            retention = with_config.get('retention-days', 90)
                            artifact_uploads.append({
                                'job': job_name,
                                'step': step_idx,
                                'name': artifact_name,
                                'retention': retention
                            })
                            
                            # Check for sensitive artifact without protection
                            path = with_config.get('path', '')
                            sensitive_patterns = ['.env', 'secrets', 'credentials', 'key', 'token', '.pem', '.key']
                            for pattern in sensitive_patterns:
                                if pattern in path.lower():
                                    vuln = Vulnerability(
                                        id=f"GH-ARTIFACT-001-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                        title="Potentially sensitive artifact upload",
                                        description=f"Workflow uploads artifact that may contain sensitive data: {path}",
                                        location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                        platform=CICDPlatform.GITHUB,
                                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                                        risk_level=RiskLevel.HIGH,
                                        cwes=["CWE-312", "CWE-538"],
                                        recommendations=[
                                            "Exclude sensitive files from artifact uploads",
                                            "Use encrypted artifacts for sensitive data",
                                            "Reduce artifact retention for sensitive data",
                                            "Use GitHub Secrets instead of artifact-based secret passing"
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
                        
                        # Track artifact downloads
                        if 'actions/download-artifact' in uses:
                            with_config = step.get('with', {})
                            artifact_name = with_config.get('name', 'unknown')
                            artifact_downloads.append({
                                'job': job_name,
                                'step': step_idx,
                                'name': artifact_name
                            })
                            
                            # Check if downloaded artifact is executed
                            next_steps = steps[step_idx + 1:] if step_idx + 1 < len(steps) else []
                            for ns_idx, next_step in enumerate(next_steps):
                                if isinstance(next_step, dict):
                                    run_cmd = next_step.get('run', '')
                                    download_path = with_config.get('path', '.')
                                    if download_path in run_cmd or 'chmod' in run_cmd or 'sh ' in run_cmd or './' in run_cmd:
                                        vuln = Vulnerability(
                                            id=f"GH-ARTIFACT-002-{hash(f'{file_path}:{job_name}:{step_idx}:{ns_idx}') % 10000}",
                                            title="Artifact execution without verification",
                                            description="Downloaded artifact is executed without integrity verification",
                                            location=f"{file_path}:job[{job_name}]:step[{step_idx + 1 + ns_idx}]",
                                            platform=CICDPlatform.GITHUB,
                                            detection_method=DetectionMethod.STATIC_ANALYSIS,
                                            risk_level=RiskLevel.CRITICAL,
                                            cwes=["CWE-494", "CWE-829"],
                                            recommendations=[
                                                "Verify artifact integrity before execution using checksums",
                                                "Sign artifacts and verify signatures before use",
                                                "Use immutable artifact storage",
                                                "Implement artifact provenance verification"
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
        
        # Check for artifact poisoning across jobs
        on_config = workflow_data.get('on', {})
        if isinstance(on_config, dict):
            if 'workflow_run' in on_config:
                # Cross-workflow artifact usage
                for download in artifact_downloads:
                    job_name = download.get("job", "unknown")
                    vuln = Vulnerability(
                        id=f"GH-ARTIFACT-003-{hash(f'{file_path}:{job_name}') % 10000}",
                        title="Cross-workflow artifact download vulnerability",
                        description="Workflow downloads artifacts from another workflow, which could be poisoned",
                        location=f"{file_path}:job[{job_name}]",
                        platform=CICDPlatform.GITHUB,
                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                        risk_level=RiskLevel.HIGH,
                        cwes=["CWE-494"],
                        recommendations=[
                            "Verify artifact provenance from trusted workflow runs only",
                            "Implement artifact signing in the source workflow",
                            "Use workflow_run event filtering to restrict artifact sources",
                            "Validate artifact checksums before use"
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def analyze_cache_poisoning(self, file_path: str, workflow_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitHub workflow for cache poisoning vulnerabilities."""
        vulnerabilities = []
        
        if not workflow_data:
            return vulnerabilities
        
        jobs = workflow_data.get('jobs', {})
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict):
                        uses = step.get('uses', '')
                        
                        # Check for cache action usage
                        if 'actions/cache' in uses:
                            with_config = step.get('with', {})
                            key = with_config.get('key', '')
                            path = with_config.get('path', '')
                            
                            # Check for predictable cache keys
                            if '${{' not in key or ('github.sha' not in key and 'hashFiles' not in key):
                                vuln = Vulnerability(
                                    id=f"GH-CACHE-001-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                    title="Predictable cache key without content hash",
                                    description="Cache key doesn't include content hash, making it susceptible to poisoning",
                                    location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                    platform=CICDPlatform.GITHUB,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.MEDIUM,
                                    cwes=["CWE-807"],
                                    recommendations=[
                                        "Include hashFiles() in cache key for content-based caching",
                                        "Use github.sha or github.run_id for unique cache identification",
                                        "Implement cache versioning prefix"
                                    ]
                                )
                                vulnerabilities.append(vuln)
                            
                            # Check for executable path caching
                            dangerous_cache_paths = ['node_modules', '.npm', 'bin/', 'scripts/', '.local/bin']
                            for dangerous_path in dangerous_cache_paths:
                                if dangerous_path in path:
                                    vuln = Vulnerability(
                                        id=f"GH-CACHE-002-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                        title="Caching of executable content",
                                        description=f"Workflow caches potentially executable content: {path}",
                                        location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                        platform=CICDPlatform.GITHUB,
                                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                                        risk_level=RiskLevel.MEDIUM,
                                        cwes=["CWE-494"],
                                        recommendations=[
                                            "Verify integrity of cached executable content before use",
                                            "Use lockfiles to validate dependency versions",
                                            "Consider using official setup actions instead of caching"
                                        ]
                                    )
                                    vulnerabilities.append(vuln)
                                    break
        
        return vulnerabilities

