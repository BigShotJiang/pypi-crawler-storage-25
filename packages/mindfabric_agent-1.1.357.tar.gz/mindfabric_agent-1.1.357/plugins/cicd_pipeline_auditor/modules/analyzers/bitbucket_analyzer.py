"""
Bitbucket Pipelines Analyzer Module
"""

import re
from typing import Dict, List, Any
from ...proto import Vulnerability, CICDPlatform, RiskLevel, DetectionMethod


class BitbucketAnalyzer:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.secret_patterns = plugin_instance.secret_patterns if hasattr(plugin_instance, 'secret_patterns') else {}
    
    def check_bitbucket_privileges(self, pipeline_data: Dict[str, Any]) -> bool:
        if not pipeline_data:
            return False
        definitions = pipeline_data.get('definitions', {})
        services = definitions.get('services', {})
        if 'docker' in services:
            return True
        return False
    
    def analyze_pipeline(self, file_path: str, pipeline_data: Dict[str, Any]) -> List[Vulnerability]:
        vulnerabilities = []
        if not pipeline_data:
            return vulnerabilities
        
        definitions = pipeline_data.get('definitions', {})
        services = definitions.get('services', {})
        
        if 'docker' in services:
            docker_config = services['docker']
            if isinstance(docker_config, dict):
                if docker_config.get('memory', 0) > 7128:
                    vulnerabilities.append(Vulnerability(
                        id=f"BB-DOCKER-001-{hash(file_path) % 10000}",
                        title="Bitbucket Pipeline Docker service with high privileges",
                        description="Docker service configured with potentially excessive resources",
                        location=f"{file_path}:definitions.services.docker",
                        platform=CICDPlatform.BITBUCKET,
                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                        risk_level=RiskLevel.MEDIUM,
                        cwes=["CWE-250"],
                        recommendations=["Review Docker service memory allocation", "Use minimal required resources", "Implement proper resource limits"]
                    ))
        
        pipelines = pipeline_data.get('pipelines', {})
        if isinstance(pipelines, dict):
            for pipeline_type, pipeline_config in pipelines.items():
                if isinstance(pipeline_config, dict):
                    for branch_name, branch_config in pipeline_config.items():
                        if isinstance(branch_config, list):
                            for step_idx, step in enumerate(branch_config):
                                if isinstance(step, dict):
                                    step_script = step.get('step', {}).get('script', [])
                                    if isinstance(step_script, list):
                                        for script_line in step_script:
                                            if isinstance(script_line, str):
                                                for secret_type, pattern in self.secret_patterns.items():
                                                    if re.search(pattern, script_line, re.IGNORECASE):
                                                        vulnerabilities.append(Vulnerability(
                                                            id=f"BB-SECRET-001-{hash(f'{file_path}:{step_idx}') % 10000}",
                                                            title="Hardcoded secret in Bitbucket pipeline",
                                                            description=f"Step contains {secret_type}",
                                                            location=f"{file_path}:pipelines[{pipeline_type}][{branch_name}][{step_idx}]",
                                                            platform=CICDPlatform.BITBUCKET,
                                                            detection_method=DetectionMethod.SECRET_EXTRACTION,
                                                            risk_level=RiskLevel.CRITICAL,
                                                            cwes=["CWE-798"],
                                                            recommendations=["Use Bitbucket Pipelines repository variables", "Mark variables as secured", "Implement secret rotation"]
                                                        ))
        return vulnerabilities

