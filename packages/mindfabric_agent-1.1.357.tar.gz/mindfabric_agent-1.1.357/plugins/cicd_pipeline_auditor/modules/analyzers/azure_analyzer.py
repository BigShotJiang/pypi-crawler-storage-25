"""
Azure DevOps Analyzer Module
"""

import re
from typing import Dict, List, Any
from ...proto import Vulnerability, CICDPlatform, RiskLevel, DetectionMethod


class AzureAnalyzer:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.secret_patterns = plugin_instance.secret_patterns if hasattr(plugin_instance, 'secret_patterns') else {}
    
    def check_azure_privileges(self, pipeline_data: Dict[str, Any]) -> bool:
        if not pipeline_data:
            return False
        pool = pipeline_data.get('pool', {})
        if isinstance(pool, dict):
            demands = pool.get('demands', [])
            if any('Agent.OS' in str(demand) for demand in demands):
                return True
        return False
    
    def analyze_pipeline(self, file_path: str, pipeline_data: Dict[str, Any]) -> List[Vulnerability]:
        vulnerabilities = []
        if not pipeline_data:
            return vulnerabilities
        
        variables = pipeline_data.get('variables', [])
        if isinstance(variables, list):
            for var_item in variables:
                if isinstance(var_item, dict):
                    for var_name, var_value in var_item.items():
                        if isinstance(var_value, str):
                            for secret_type, pattern in self.secret_patterns.items():
                                if re.search(pattern, var_value, re.IGNORECASE):
                                    vulnerabilities.append(Vulnerability(
                                        id=f"AZ-VAR-001-{hash(f'{file_path}:{var_name}') % 10000}",
                                        title="Hardcoded secret in Azure pipeline",
                                        description=f"Variable '{var_name}' contains {secret_type}",
                                        location=f"{file_path}:variables[{var_name}]",
                                        platform=CICDPlatform.AZURE_DEVOPS,
                                        detection_method=DetectionMethod.SECRET_EXTRACTION,
                                        risk_level=RiskLevel.CRITICAL,
                                        cwes=["CWE-798"],
                                        recommendations=[
                                            "Use Azure DevOps Variable Groups",
                                            "Mark sensitive variables as secret",
                                            "Use Azure Key Vault integration"
                                        ]
                                    ))
        return vulnerabilities

