"""
GitLab CI Analyzer Module

Analyzes GitLab CI configurations for security vulnerabilities.
"""

import re
from typing import Dict, List, Any
from ...proto import (
    Vulnerability, CodeInjectionVector, CICDPlatform, RiskLevel, DetectionMethod
)


class GitLabAnalyzer:
    """Analyzes GitLab CI configurations"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        # Get secret patterns from plugin
        self.secret_patterns = plugin_instance.secret_patterns if hasattr(plugin_instance, 'secret_patterns') else {}
    
    def check_gitlab_privileges(self, ci_data: Dict[str, Any]) -> bool:
        """Check if GitLab CI has privilege issues."""
        if not ci_data:
            return False
        
        # Check for privileged containers
        for job_name, job_config in ci_data.items():
            if isinstance(job_config, dict):
                image_config = job_config.get('image', {})
                if isinstance(image_config, dict):
                    if image_config.get('docker', {}).get('privileged', False):
                        return True
        
        return False
    
    def analyze_ci(self, file_path: str, ci_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitLab CI configuration for vulnerabilities."""
        vulnerabilities = []
        
        if not ci_data:
            return vulnerabilities
        
        # Check for privileged containers
        for job_name, job_config in ci_data.items():
            if isinstance(job_config, dict):
                image_config = job_config.get('image', {})
                if isinstance(image_config, dict):
                    docker_config = image_config.get('docker', {})
                    if docker_config.get('privileged', False):
                        vuln = Vulnerability(
                            id=f"GL-PRIV-001-{hash(f'{file_path}:{job_name}') % 10000}",
                            title="GitLab CI job runs in privileged container",
                            description=f"Job '{job_name}' configured with privileged Docker container",
                            location=f"{file_path}:job[{job_name}]",
                            platform=CICDPlatform.GITLAB,
                            detection_method=DetectionMethod.STATIC_ANALYSIS,
                            risk_level=RiskLevel.HIGH,
                            cwes=["CWE-250"],
                            recommendations=[
                                "Remove privileged mode unless absolutely necessary",
                                "Use specific capabilities instead of privileged mode",
                                "Implement proper container isolation"
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        # Check for missing variable masking
        variables = ci_data.get('variables', {})
        for var_name, var_value in variables.items():
            if isinstance(var_value, str):
                # Check if variable contains potential secrets
                for secret_type, pattern in self.secret_patterns.items():
                    if re.search(pattern, var_value, re.IGNORECASE):
                        vuln = Vulnerability(
                            id=f"GL-VAR-001-{hash(f'{file_path}:{var_name}') % 10000}",
                            title="GitLab CI variable contains unmasked secret",
                            description=f"Variable '{var_name}' appears to contain a {secret_type}",
                            location=f"{file_path}:variables[{var_name}]",
                            platform=CICDPlatform.GITLAB,
                            detection_method=DetectionMethod.SECRET_EXTRACTION,
                            risk_level=RiskLevel.CRITICAL,
                            cwes=["CWE-798"],
                            recommendations=[
                                "Use GitLab CI/CD Variables instead of hardcoded values",
                                "Enable variable masking and protection",
                                "Implement secret rotation"
                            ]
                        )
                        vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def find_injection_vectors(self, file_path: str, ci_data: Dict[str, Any]) -> List[CodeInjectionVector]:
        """Find potential code injection vectors in GitLab CI."""
        injection_vectors = []
        
        if not ci_data:
            return injection_vectors
        
        # Check for script injection in jobs
        for job_name, job_config in ci_data.items():
            if isinstance(job_config, dict):
                scripts = job_config.get('script', [])
                if isinstance(scripts, list):
                    for script_idx, script in enumerate(scripts):
                        if isinstance(script, str):
                            # Check for variable injection
                            if '$CI_COMMIT_MESSAGE' in script or '$CI_MERGE_REQUEST_TITLE' in script:
                                vector = CodeInjectionVector(
                                    vector_type="GitLab CI Variable Injection",
                                    location=f"{file_path}:job[{job_name}]:script[{script_idx}]",
                                    trigger_method="User-controlled CI variables in script",
                                    impact="Command injection in GitLab runner",
                                    risk_level=RiskLevel.HIGH,
                                    remediation="Sanitize CI variables before using in shell commands"
                                )
                                injection_vectors.append(vector)
        
        return injection_vectors
    
    def analyze_runner_security(self, file_path: str, ci_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitLab CI for runner security issues."""
        vulnerabilities = []
        
        if not ci_data:
            return vulnerabilities
        
        for job_name, job_config in ci_data.items():
            if isinstance(job_config, dict):
                # Check for specific runner tags
                tags = job_config.get('tags', [])
                
                # Check for self-hosted runners with shared tag
                if 'shared' in tags or not tags:
                    # Check if job has access to protected variables
                    rules = job_config.get('rules', [])
                    for rule in rules:
                        if isinstance(rule, dict):
                            if_clause = rule.get('if', '')
                            # Jobs triggered on MR from forks
                            if 'CI_PIPELINE_SOURCE' in if_clause and 'merge_request' in if_clause:
                                vuln = Vulnerability(
                                    id=f"GL-RUNNER-001-{hash(f'{file_path}:{job_name}') % 10000}",
                                    title="GitLab runner accessible from merge requests",
                                    description="Job may run on shared runner for external merge requests",
                                    location=f"{file_path}:job[{job_name}]",
                                    platform=CICDPlatform.GITLAB,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.HIGH,
                                    cwes=["CWE-284"],
                                    recommendations=[
                                        "Use protected runners for sensitive jobs",
                                        "Implement runner group isolation",
                                        "Use protected variables and protect branches"
                                    ]
                                )
                                vulnerabilities.append(vuln)
                
                # Check for Docker socket mounting in services
                services = job_config.get('services', [])
                for svc_idx, service in enumerate(services):
                    if isinstance(service, dict):
                        if 'docker:dind' in service.get('name', '') or 'docker:dind' in str(service):
                            vuln = Vulnerability(
                                id=f"GL-RUNNER-002-{hash(f'{file_path}:{job_name}:{svc_idx}') % 10000}",
                                title="Docker-in-Docker service with potential security issues",
                                description="DinD service may expose container escape vectors",
                                location=f"{file_path}:job[{job_name}]:services[{svc_idx}]",
                                platform=CICDPlatform.GITLAB,
                                detection_method=DetectionMethod.STATIC_ANALYSIS,
                                risk_level=RiskLevel.MEDIUM,
                                cwes=["CWE-269"],
                                recommendations=[
                                    "Use rootless Docker or Podman instead",
                                    "Implement proper container isolation",
                                    "Consider using Kaniko for container builds"
                                ]
                            )
                            vulnerabilities.append(vuln)
                
                # Check for shell executor on self-hosted
                image = job_config.get('image')
                if not image:
                    # Jobs without image likely use shell executor
                    scripts = job_config.get('script', [])
                    if scripts:
                        dangerous_cmds = ['sudo', 'rm -rf', 'chmod 777', '/etc/', '/var/']
                        for script in scripts if isinstance(scripts, list) else [scripts]:
                            if isinstance(script, str):
                                for cmd in dangerous_cmds:
                                    if cmd in script:
                                        vuln = Vulnerability(
                                            id=f"GL-RUNNER-003-{hash(f'{file_path}:{job_name}') % 10000}",
                                            title="Dangerous command on potential shell executor",
                                            description=f"Job uses shell executor with dangerous command: {cmd}",
                                            location=f"{file_path}:job[{job_name}]",
                                            platform=CICDPlatform.GITLAB,
                                            detection_method=DetectionMethod.STATIC_ANALYSIS,
                                            risk_level=RiskLevel.HIGH,
                                            cwes=["CWE-78"],
                                            recommendations=[
                                                "Use Docker executor instead of shell",
                                                "Implement least privilege for runner",
                                                "Clean up runner environment after jobs"
                                            ]
                                        )
                                        vulnerabilities.append(vuln)
                                        break
        
        return vulnerabilities
    
    def analyze_artifact_security(self, file_path: str, ci_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitLab CI for artifact poisoning vulnerabilities."""
        vulnerabilities = []
        
        if not ci_data:
            return vulnerabilities
        
        for job_name, job_config in ci_data.items():
            if isinstance(job_config, dict):
                artifacts = job_config.get('artifacts', {})
                if artifacts:
                    paths = artifacts.get('paths', [])
                    expire_in = artifacts.get('expire_in', '30 days')
                    
                    # Check for sensitive artifacts
                    sensitive_patterns = ['.env', 'secret', 'credential', 'key', 'token', '.pem', '.key']
                    for path in paths:
                        for pattern in sensitive_patterns:
                            if pattern in path.lower():
                                vuln = Vulnerability(
                                    id=f"GL-ARTIFACT-001-{hash(f'{file_path}:{job_name}:{path}') % 10000}",
                                    title="Potentially sensitive artifact",
                                    description=f"Artifact path may contain sensitive data: {path}",
                                    location=f"{file_path}:job[{job_name}]:artifacts",
                                    platform=CICDPlatform.GITLAB,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.HIGH,
                                    cwes=["CWE-312", "CWE-538"],
                                    recommendations=[
                                        "Exclude sensitive files from artifacts",
                                        "Use GitLab CI/CD variables for secrets",
                                        "Set short expiration for sensitive artifacts"
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
                    
                    # Check for executable artifacts
                    executable_patterns = ['*.sh', '*.exe', '*.bin', 'scripts/', 'bin/']
                    for path in paths:
                        for pattern in executable_patterns:
                            if pattern.replace('*', '') in path:
                                vuln = Vulnerability(
                                    id=f"GL-ARTIFACT-002-{hash(f'{file_path}:{job_name}:{path}') % 10000}",
                                    title="Executable artifact without integrity verification",
                                    description=f"Executable artifact '{path}' may be tampered between jobs",
                                    location=f"{file_path}:job[{job_name}]:artifacts",
                                    platform=CICDPlatform.GITLAB,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.MEDIUM,
                                    cwes=["CWE-494"],
                                    recommendations=[
                                        "Generate and verify artifact checksums",
                                        "Sign artifacts for integrity verification",
                                        "Use needs keyword with artifacts: true for explicit dependencies"
                                    ]
                                )
                                vulnerabilities.append(vuln)
                                break
                
                # Check for cache poisoning
                cache = job_config.get('cache', {})
                if cache:
                    key = cache.get('key', {})
                    paths = cache.get('paths', [])
                    
                    # Check for weak cache keys
                    if isinstance(key, str) and '$CI_COMMIT_SHA' not in key and '$CI_JOB_ID' not in key:
                        if 'files' not in str(key):
                            vuln = Vulnerability(
                                id=f"GL-CACHE-001-{hash(f'{file_path}:{job_name}') % 10000}",
                                title="Predictable cache key",
                                description="Cache key doesn't include content hash, vulnerable to poisoning",
                                location=f"{file_path}:job[{job_name}]:cache",
                                platform=CICDPlatform.GITLAB,
                                detection_method=DetectionMethod.STATIC_ANALYSIS,
                                risk_level=RiskLevel.MEDIUM,
                                cwes=["CWE-807"],
                                recommendations=[
                                    "Use files keyword for content-based cache keys",
                                    "Include CI_COMMIT_SHA in cache key",
                                    "Use cache:key:prefix for versioning"
                                ]
                            )
                            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def analyze_include_security(self, file_path: str, ci_data: Dict[str, Any]) -> List[Vulnerability]:
        """Analyze GitLab CI include directives for supply chain risks."""
        vulnerabilities = []
        
        if not ci_data:
            return vulnerabilities
        
        includes = ci_data.get('include', [])
        if not isinstance(includes, list):
            includes = [includes]
        
        for inc_idx, include in enumerate(includes):
            if isinstance(include, dict):
                # Check for remote includes
                remote = include.get('remote')
                if remote:
                    # Check for non-HTTPS
                    if remote.startswith('http://'):
                        vuln = Vulnerability(
                            id=f"GL-INCLUDE-001-{hash(f'{file_path}:{inc_idx}') % 10000}",
                            title="Insecure remote include over HTTP",
                            description=f"Remote include uses insecure HTTP: {remote}",
                            location=f"{file_path}:include[{inc_idx}]",
                            platform=CICDPlatform.GITLAB,
                            detection_method=DetectionMethod.STATIC_ANALYSIS,
                            risk_level=RiskLevel.CRITICAL,
                            cwes=["CWE-319"],
                            recommendations=[
                                "Use HTTPS for remote includes",
                                "Pin includes to specific commits or tags",
                                "Consider using local includes instead"
                            ]
                        )
                        vulnerabilities.append(vuln)
                    
                    # Check for external/untrusted sources
                    untrusted_domains = ['github.com', 'raw.githubusercontent.com', 'pastebin.com']
                    for domain in untrusted_domains:
                        if domain in remote:
                            vuln = Vulnerability(
                                id=f"GL-INCLUDE-002-{hash(f'{file_path}:{inc_idx}') % 10000}",
                                title="Remote include from external source",
                                description=f"CI configuration includes external source: {remote}",
                                location=f"{file_path}:include[{inc_idx}]",
                                platform=CICDPlatform.GITLAB,
                                detection_method=DetectionMethod.SUPPLY_CHAIN_TEST,
                                risk_level=RiskLevel.HIGH,
                                cwes=["CWE-829"],
                                recommendations=[
                                    "Mirror external configurations to your GitLab instance",
                                    "Pin to specific versions or commits",
                                    "Review included configurations regularly"
                                ]
                            )
                            vulnerabilities.append(vuln)
                            break
                
                # Check for project includes without ref
                project = include.get('project')
                ref = include.get('ref')
                if project and not ref:
                    vuln = Vulnerability(
                        id=f"GL-INCLUDE-003-{hash(f'{file_path}:{inc_idx}') % 10000}",
                        title="Project include without pinned version",
                        description=f"Include from project '{project}' without specific ref",
                        location=f"{file_path}:include[{inc_idx}]",
                        platform=CICDPlatform.GITLAB,
                        detection_method=DetectionMethod.STATIC_ANALYSIS,
                        risk_level=RiskLevel.MEDIUM,
                        cwes=["CWE-829"],
                        recommendations=[
                            "Pin include to specific tag or commit SHA",
                            "Use semantic versioning for template projects",
                            "Implement change review process for shared templates"
                        ]
                    )
                    vulnerabilities.append(vuln)
        
        return vulnerabilities

