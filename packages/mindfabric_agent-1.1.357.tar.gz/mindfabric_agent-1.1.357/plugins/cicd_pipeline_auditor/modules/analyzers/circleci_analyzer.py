"""
CircleCI Analyzer Module
"""

from typing import Dict, List, Any
from ...proto import Vulnerability, CICDPlatform, RiskLevel, DetectionMethod


class CircleCIAnalyzer:
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def check_circleci_privileges(self, config_data: Dict[str, Any]) -> bool:
        if not config_data:
            return False
        jobs = config_data.get('jobs', {})
        for job_config in jobs.values():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step in steps:
                    if isinstance(step, dict) and 'setup_remote_docker' in step:
                        return True
        return False
    
    def analyze_config(self, file_path: str, config_data: Dict[str, Any]) -> List[Vulnerability]:
        vulnerabilities = []
        if not config_data:
            return vulnerabilities
        
        jobs = config_data.get('jobs', {})
        for job_name, job_config in jobs.items():
            if isinstance(job_config, dict):
                steps = job_config.get('steps', [])
                for step_idx, step in enumerate(steps):
                    if isinstance(step, dict):
                        if 'setup_remote_docker' in step:
                            docker_config = step['setup_remote_docker']
                            if not docker_config.get('version'):
                                vulnerabilities.append(Vulnerability(
                                    id=f"CC-DOCKER-001-{hash(f'{file_path}:{job_name}:{step_idx}') % 10000}",
                                    title="CircleCI remote Docker without version pinning",
                                    description="setup_remote_docker step without explicit version",
                                    location=f"{file_path}:job[{job_name}]:step[{step_idx}]",
                                    platform=CICDPlatform.CIRCLECI,
                                    detection_method=DetectionMethod.STATIC_ANALYSIS,
                                    risk_level=RiskLevel.MEDIUM,
                                    cwes=["CWE-829"],
                                    recommendations=[
                                        "Pin setup_remote_docker to specific version",
                                        "Use latest stable Docker version",
                                        "Regularly update Docker version"
                                    ]
                                ))
        return vulnerabilities

