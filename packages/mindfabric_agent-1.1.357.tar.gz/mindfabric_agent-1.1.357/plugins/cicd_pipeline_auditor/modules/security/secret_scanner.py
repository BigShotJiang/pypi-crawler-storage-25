"""
Secret Scanner Module

Scans CI/CD pipeline configurations for exposed secrets.
"""

import re
from typing import List
from ...proto import Secret, CICDPlatform, RiskLevel


class SecretScanner:
    """Scans for secrets in CI/CD configuration files"""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.secret_patterns = {
            'aws_access_key': r'AKIA[0-9A-Z]{16}',
            'aws_secret_key': r'[0-9a-zA-Z/+]{40}',
            'github_token': r'ghp_[0-9a-zA-Z]{36}',
            'gitlab_token': r'glpat-[0-9a-zA-Z_\-]{20}',
            'docker_token': r'dckr_pat_[0-9a-zA-Z_\-]{28}',
            'api_key': r'[aA][pP][iI][_]?[kK][eE][yY].*[\'"][0-9a-zA-Z]{32,45}[\'"]',
            'private_key': r'-----BEGIN\s+.*PRIVATE\s+KEY.*-----',
            'password': r'[pP][aA][sS][sS][wW][oO][rR][dD].*[\'"][^\'"\s]{8,}[\'"]',
            'database_url': r'[a-zA-Z][a-zA-Z0-9+.-]*://[^\s]*',
            'jwt_token': r'eyJ[0-9a-zA-Z_-]*\.[0-9a-zA-Z_-]*\.[0-9a-zA-Z_-]*'
        }
    
    def check_for_secrets(self, content: str) -> bool:
        """Check if content contains potential secrets."""
        for pattern_name, pattern in self.secret_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                return True
        return False
    
    def scan_secrets_in_content(self, content: str, file_path: str, platform: CICDPlatform) -> List[Secret]:
        """Scan for secrets in configuration content."""
        secrets = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            for secret_type, pattern in self.secret_patterns.items():
                matches = re.finditer(pattern, line, re.IGNORECASE)
                for match in matches:
                    secret = Secret(
                        secret_type=secret_type,
                        location=f"{file_path}:{line_num}",
                        masked=False,
                        exposed_in_logs=True,  # Assume exposed unless proven otherwise
                        risk_level=self.determine_secret_risk_level(secret_type),
                        remediation=self.get_secret_remediation(secret_type, platform)
                    )
                    secrets.append(secret)
        
        return secrets
    
    def determine_secret_risk_level(self, secret_type: str) -> RiskLevel:
        """Determine risk level based on secret type."""
        high_risk_secrets = ['aws_access_key', 'aws_secret_key', 'private_key', 'database_url']
        medium_risk_secrets = ['github_token', 'gitlab_token', 'api_key', 'jwt_token']
        
        if secret_type in high_risk_secrets:
            return RiskLevel.CRITICAL
        elif secret_type in medium_risk_secrets:
            return RiskLevel.HIGH
        else:
            return RiskLevel.MEDIUM
    
    def get_secret_remediation(self, secret_type: str, platform: CICDPlatform) -> str:
        """Get remediation advice for specific secret type and platform."""
        remediation_map = {
            CICDPlatform.GITHUB: {
                'aws_access_key': 'Use GitHub Secrets to store AWS credentials securely',
                'github_token': 'Use GITHUB_TOKEN or GitHub App installation token',
                'api_key': 'Store API keys in GitHub Secrets with proper masking',
                'private_key': 'Use GitHub Secrets for private keys and certificate management'
            },
            CICDPlatform.GITLAB: {
                'aws_access_key': 'Use GitLab CI/CD Variables with protection and masking',
                'gitlab_token': 'Use project or group access tokens with minimal permissions',
                'api_key': 'Store in GitLab CI/CD Variables as protected and masked',
                'private_key': 'Use GitLab CI/CD Variables with file type for certificates'
            },
            CICDPlatform.JENKINS: {
                'aws_access_key': 'Use Jenkins Credentials Store for AWS keys',
                'api_key': 'Store in Jenkins Credentials with proper access control',
                'private_key': 'Use Jenkins Certificate Credentials for private keys'
            }
        }
        
        platform_remediation = remediation_map.get(platform, {})
        return platform_remediation.get(secret_type, 'Use secure secret storage appropriate for your platform')

