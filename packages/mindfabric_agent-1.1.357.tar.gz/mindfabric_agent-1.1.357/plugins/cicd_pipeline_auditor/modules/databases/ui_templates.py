from __future__ import annotations

import os
from typing import Any, Dict, List, Optional


CICD_AUDITOR_RECOMMENDATIONS: List[Dict[str, str]] = [
    {
        "title": "Pin and verify third-party actions",
        "description": "Pin GitHub Actions to commit SHAs, verify provenance, and restrict trusted sources.",
        "priority": "high",
    },
    {
        "title": "Reduce secrets exposure",
        "description": "Scope secrets to required environments, avoid printing to logs, and rotate any leaked tokens immediately.",
        "priority": "high",
    },
    {
        "title": "Least privilege for CI/CD",
        "description": "Restrict workflow permissions (GITHUB_TOKEN), runner privileges, and network egress.",
        "priority": "medium",
    },
]

CICD_AUDITOR_IMPACT: str = (
    "CI/CD vulnerabilities can lead to code execution in build runners, secrets theft, and supply-chain compromise. "
    "Attackers often exploit unpinned actions, excessive workflow permissions, and injection into build steps to pivot into production."
)


def cicd_scan_has_actionable_finding_material(result: Optional[Dict[str, Any]]) -> bool:
    """
    True if the audit produced anything that should surface as a standalone threat-style row
    (vulns, secrets, injection issues, etc.). Used to avoid spamming a generic "summary" card.
    """
    if not isinstance(result, dict):
        return False
    totals = 0
    for ar in result.get("audit_results") or []:
        if not isinstance(ar, dict):
            continue
        totals += len(ar.get("vulnerabilities") or [])
        totals += len(ar.get("secrets") or [])
        totals += len(ar.get("injection_vectors") or [])
        totals += len(ar.get("isolation_issues") or [])
        totals += len(ar.get("workflow_permissions") or [])
    return totals > 0


def cicd_infer_scan_root(result: Optional[Dict[str, Any]], fallback: str = ".") -> str:
    """Best directory for `find` / `grep` triage commands."""
    if not isinstance(result, dict):
        return fallback
    for key in ("root_dir", "root"):
        v = result.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    for ar in result.get("audit_results") or []:
        if not isinstance(ar, dict):
            continue
        cfs = ar.get("config_files") or []
        if cfs and isinstance(cfs[0], dict):
            p = cfs[0].get("file_path") or cfs[0].get("path")
            if isinstance(p, str) and p.strip():
                try:
                    return os.path.dirname(p.strip()) or fallback
                except Exception:
                    pass
    td = result.get("technical_details")
    if isinstance(td, dict):
        so = td.get("scan_options")
        if isinstance(so, dict):
            rp = so.get("repo_paths") or so.get("repoPaths")
            if isinstance(rp, list) and rp:
                f0 = rp[0]
                if isinstance(f0, str) and f0.strip():
                    return f0.strip()
    return fallback


def build_cicd_summary_description(result: Optional[Dict[str, Any]]) -> str:
    """
    Human-friendly, hacker-centric summary for the UI when plugin doesn't emit canonical findings.
    """
    if not isinstance(result, dict):
        return (
            "This scan audits CI/CD pipeline configuration for common attack paths: untrusted code execution in runners, secrets exposure, "
            "workflow permission abuse, and supply-chain risks."
        )

    overall_risk = result.get("overall_risk_level") or result.get("overallRiskLevel")
    if hasattr(overall_risk, "value"):
        overall_risk = overall_risk.value

    # Concrete counts from nested audit_results (more useful than generic prose)
    ar0: Optional[Dict[str, Any]] = None
    ars = result.get("audit_results") or []
    if isinstance(ars, list) and ars and isinstance(ars[0], dict):
        ar0 = ars[0]
    stats_blob = ""
    if isinstance(ar0, dict):
        st = ar0.get("statistics") or {}
        if isinstance(st, dict):
            files_n = st.get("total_config_files") or st.get("files_processed")
            repos_n = st.get("total_repositories")
            if files_n is not None or repos_n is not None:
                stats_blob = f" Scanned about {files_n or '?'} config file(s) across {repos_n or '?'} repo root(s)."
        vcount = len(ar0.get("vulnerabilities") or [])
        scount = len(ar0.get("secrets") or [])
        icount = len(ar0.get("injection_vectors") or [])
        if vcount or scount or icount:
            stats_blob += (
                f" Flagged items this run: {vcount} vulnerability/vulnerabilities, {scount} secret-like hit(s), "
                f"{icount} injection vector(s) — review listed findings in the full report output, not this line alone."
            )

    exec_summary = result.get("executive_summary") or result.get("executiveSummary") or {}
    if isinstance(exec_summary, dict):
        headline = exec_summary.get("headline") or exec_summary.get("summary")
    else:
        headline = None

    parts: List[str] = []
    if headline and isinstance(headline, str):
        parts.append(headline.strip())
    parts.append(
        "CI/CD weaknesses can be abused to run attacker-controlled commands during builds, steal tokens/secrets, and poison artifacts that get deployed downstream."
    )
    if overall_risk:
        parts.append(f"Overall risk level: {str(overall_risk).lower()}.")
    return " ".join([p for p in parts if p])

def _exists(path: str) -> bool:
    try:
        return os.path.exists(path)
    except Exception:
        return False


def _join(root: str, rel: str) -> str:
    try:
        return os.path.join(root, rel)
    except Exception:
        return rel


def _detect_ci_platforms(root: str) -> Dict[str, bool]:
    """
    Best-effort detection of CI/CD config presence.
    We intentionally keep this lightweight and file-presence-based.
    """
    return {
        "github": _exists(_join(root, ".github/workflows")),
        "gitlab": _exists(_join(root, ".gitlab-ci.yml")),
        "jenkins": _exists(_join(root, "Jenkinsfile")) or _exists(_join(root, "jenkinsfile")),
        "azure": _exists(_join(root, "azure-pipelines.yml")),
        "circleci": _exists(_join(root, ".circleci")),
        "bitbucket": _exists(_join(root, "bitbucket-pipelines.yml")),
        "drone": _exists(_join(root, ".drone.yml")),
        "travis": _exists(_join(root, ".travis.yml")),
    }


def get_cicd_auditor_commands_by_scanner(root: str) -> Dict[str, List[str]]:
    """
    Return commands grouped by scanner/platform.
    This allows the plugin to select only relevant sections and avoid huge payloads.
    """
    return {
        "common": [
            "# Locate CI/CD configs (multi-platform)",
            f"find {root} -maxdepth 7 -type f \\( -name '.gitlab-ci.yml' -o -name 'Jenkinsfile' -o -name 'jenkinsfile' -o -name 'azure-pipelines.yml' -o -name '.travis.yml' -o -name 'bitbucket-pipelines.yml' -o -name '.drone.yml' -o -path '*/.github/workflows/*.yml' -o -path '*/.github/workflows/*.yaml' -o -path '*/.circleci/config.yml' -o -path '*/.circleci/config.yaml' \\) 2>/dev/null | head -n 200",
        ],
        "github_actions": [
            "# GitHub Actions: unpinned actions + risky permissions",
            f"grep -RIn \"^\\s*uses:\\s*[^#]+@\" {root}/.github/workflows 2>/dev/null | head -n 80",
            f"grep -RIn \"^\\s*permissions:\\s*\" {root}/.github/workflows 2>/dev/null | head -n 80",
            f"grep -RIn \"write-all\" {root}/.github/workflows 2>/dev/null | head -n 40",
            f"grep -RIn \"secrets\\.\" {root}/.github/workflows 2>/dev/null | head -n 80",
        ],
        "gitlab_ci": [
            "# GitLab CI: risky scripts + includes + secrets exposure",
            f"grep -RIn \"(^\\s*script:|\\beval\\b|\\bcurl\\b|\\bwget\\b|\\bchmod\\b|\\bchown\\b|\\bsudo\\b)\" {root}/.gitlab-ci.yml 2>/dev/null | head -n 120",
            f"grep -RIn \"(^\\s*include:|\\bextends:|\\btrigger:)\" {root}/.gitlab-ci.yml 2>/dev/null | head -n 80",
            f"grep -RIn \"\\b(variables:|CI_JOB_TOKEN|PRIVATE-TOKEN|glpat-|masked|protected)\\b\" {root}/.gitlab-ci.yml 2>/dev/null | head -n 120",
        ],
        "jenkins": [
            "# Jenkins: Groovy injection surfaces + credentials usage",
            f"grep -RIn \"\\b(sh|bat|powershell)\\s*\\(\" {root} 2>/dev/null | grep -E \"Jenkinsfile|jenkinsfile\" | head -n 120",
            f"grep -RIn \"\\b(withCredentials|credentials\\()\\b\" {root} 2>/dev/null | grep -E \"Jenkinsfile|jenkinsfile\" | head -n 120",
            f"grep -RIn \"\\b(input|parameters)\\b\" {root} 2>/dev/null | grep -E \"Jenkinsfile|jenkinsfile\" | head -n 120",
        ],
        "azure_devops": [
            "# Azure DevOps: scripts/steps + secret variables (best-effort)",
            f"grep -RIn \"\\b(script:|bash:|powershell:|pwsh:)\\b\" {root}/azure-pipelines.yml 2>/dev/null | head -n 120",
            f"grep -RIn \"\\b(variables:|isSecret:|secret)\\b\" {root}/azure-pipelines.yml 2>/dev/null | head -n 120",
        ],
        "circleci": [
            "# CircleCI: run steps + contexts + orbs",
            f"grep -RIn \"\\b(run:|orbs:|context:)\\b\" {root}/.circleci 2>/dev/null | head -n 160",
        ],
        "bitbucket": [
            "# Bitbucket Pipelines: pipe usage + scripts + deployment",
            f"grep -RIn \"\\b(pipes:|pipe:|script:|deployment:)\\b\" {root}/bitbucket-pipelines.yml 2>/dev/null | head -n 160",
        ],
        "drone": [
            "# Drone CI: commands + secrets",
            f"grep -RIn \"\\b(commands:|image:|environment:|secrets:)\\b\" {root}/.drone.yml 2>/dev/null | head -n 160",
        ],
        "travis": [
            "# Travis CI: scripts + env + secure vars",
            f"grep -RIn \"\\b(script:|before_script:|after_script:|env:)\\b\" {root}/.travis.yml 2>/dev/null | head -n 160",
        ],
        "secrets": [
            "# Token patterns in repo/configs (best-effort)",
            f"grep -RIn \"(AKIA[0-9A-Z]{{16}}|ASIA[0-9A-Z]{{16}}|ghp_[0-9A-Za-z]{{36}}|glpat-[0-9A-Za-z_\\-]{{20}}|xox[baprs]-[0-9A-Za-z-]{{10,}}|AIza[0-9A-Za-z_\\-]{{35}})\" {root} 2>/dev/null | head -n 80",
        ],
        "injection": [
            "# Command injection patterns (generic) — untrusted inputs fed into shell",
            "grep -RIn \"(\\$\\{\\{\\s*github\\.event\\.|\\$\\{\\{\\s*inputs\\.|\\$CI_|\\$\\{?CI_|\\$\\{?BUILD_|\\$\\{?BRANCH)\" "
            + root
            + " 2>/dev/null | head -n 120",
        ],
    }


def get_cicd_auditor_exploitation_commands(
    context: Optional[Dict[str, Any]] = None,
    *,
    include_wide_repo_secret_grep: bool = True,
) -> List[str]:
    """
    Read-only verification commands to validate CI/CD configuration locally.
    If include_wide_repo_secret_grep is False, omits recursive secret-pattern greps over the whole tree
    (keeps platform-scoped greps only — less noise in summary-only UI).
    """
    ctx = context or {}
    root = str(ctx.get("root") or ".")
    commands_by = get_cicd_auditor_commands_by_scanner(root)
    present = _detect_ci_platforms(root)

    selected_keys: List[str] = ["common"]
    if present.get("github"):
        selected_keys.append("github_actions")
    if present.get("gitlab"):
        selected_keys.append("gitlab_ci")
    if present.get("jenkins"):
        selected_keys.append("jenkins")
    if present.get("azure"):
        selected_keys.append("azure_devops")
    if present.get("circleci"):
        selected_keys.append("circleci")
    if present.get("bitbucket"):
        selected_keys.append("bitbucket")
    if present.get("drone"):
        selected_keys.append("drone")
    if present.get("travis"):
        selected_keys.append("travis")

    if include_wide_repo_secret_grep:
        selected_keys.extend(["secrets", "injection"])

    out: List[str] = []
    for key in selected_keys:
        section = commands_by.get(key) or []
        if out and section:
            out.append("")
        out.extend(section)
    return out

