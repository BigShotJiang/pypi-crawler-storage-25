"""UI templates / databases for cicd_pipeline_auditor (strings, commands, recommendations)."""

