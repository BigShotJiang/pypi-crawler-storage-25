"""
Compliance Checker Module

This is not a full GRC / compliance product: it maps **already collected scan
artifacts** (IAM, workflows, secrets, injections) to a small set of **control
labels** (NIST 800-53, CIS, OWASP CI/CD Top 10) so security operators can
prioritize remediation and attach evidence to audit narratives.
"""

from typing import Dict, List, Any
from ...proto import ComplianceCheck, CICDPlatform, DetectionMethod, RiskLevel


class ComplianceChecker:
    """
    Derives pass/fail-style control rows from platform scan results.
    All checks are heuristic and based on static/local analysis unless noted.
    """
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    def generate_compliance_checks(self, platform: CICDPlatform, platform_results: Dict[str, Any]) -> List[ComplianceCheck]:
        """Generate compliance checks for a specific platform."""
        compliance_checks = []
        compliance_checks.extend(self.check_nist_compliance(platform, platform_results))
        compliance_checks.extend(self.check_cis_compliance(platform, platform_results))
        compliance_checks.extend(self.check_owasp_cicd_compliance(platform, platform_results))
        compliance_checks.extend(self.check_secret_and_workflow_hygiene(platform, platform_results))
        return compliance_checks
    
    def check_nist_compliance(self, platform: CICDPlatform, results: Dict[str, Any]) -> List[ComplianceCheck]:
        """Check NIST SP 800-53 compliance."""
        checks = []
        
        # AC-6: Least Privilege
        excessive_permissions = any(
            perm.excessive for perm in results.get('iam_permissions', [])
        )
        
        from ...proto import ComplianceCheck
        ac6_check = ComplianceCheck(
            standard="NIST-SP-800-53",
            control_id="AC-6",
            description="Least Privilege",
            status="Fail" if excessive_permissions else "Pass",
            evidence=f"Found {len([p for p in results.get('iam_permissions', []) if p.excessive])} accounts with excessive privileges",
            remediation="Apply principle of least privilege to all service accounts" if excessive_permissions else None
        )
        checks.append(ac6_check)
        
        # CM-3: Configuration Change Control
        config_issues = len(results.get('vulnerabilities', []))
        cm3_check = ComplianceCheck(
            standard="NIST-SP-800-53",
            control_id="CM-3",
            description="Configuration Change Control",
            status="Fail" if config_issues > 0 else "Pass",
            evidence=f"Found {config_issues} configuration vulnerabilities",
            remediation="Implement change management process for CI/CD configurations" if config_issues > 0 else None
        )
        checks.append(cm3_check)
        
        return checks
    
    def check_cis_compliance(self, platform: CICDPlatform, results: Dict[str, Any]) -> List[ComplianceCheck]:
        """Check CIS Benchmarks compliance."""
        checks = []
        
        from ...proto import ComplianceCheck
        isolation_issues = len(results.get('isolation_issues', []))
        cis_check = ComplianceCheck(
            standard="CIS-Benchmarks",
            control_id="5.2",
            description="Ensure that registered runners are isolated properly",
            status="Fail" if isolation_issues > 0 else "Pass",
            evidence=f"Found {isolation_issues} isolation issues",
            remediation="Configure proper isolation between CI/CD runners" if isolation_issues > 0 else None
        )
        checks.append(cis_check)
        
        return checks
    
    def check_owasp_cicd_compliance(self, platform: CICDPlatform, results: Dict[str, Any]) -> List[ComplianceCheck]:
        """Check OWASP CI/CD Top 10 compliance."""
        checks = []
        
        from ...proto import ComplianceCheck
        injection_vectors = len(results.get('injection_vectors', []))
        sec1_check = ComplianceCheck(
            standard="OWASP-CICD-TOP10",
            control_id="CICD-SEC-1",
            description="Insufficient Flow Control Mechanisms",
            status="Fail" if injection_vectors > 0 else "Pass",
            evidence=f"Found {injection_vectors} potential injection vectors",
            remediation="Implement proper input validation and flow control" if injection_vectors > 0 else None
        )
        checks.append(sec1_check)
        
        code_injection_vulns = len([v for v in results.get('vulnerabilities', []) 
                                   if v.detection_method == DetectionMethod.CODE_INJECTION])
        sec4_check = ComplianceCheck(
            standard="OWASP-CICD-TOP10",
            control_id="CICD-SEC-4",
            description="Poisoned Pipeline Execution (PPE)",
            status="Fail" if code_injection_vulns > 0 else "Pass",
            evidence=f"Found {code_injection_vulns} code injection vulnerabilities",
            remediation="Implement input sanitization and integrity verification" if code_injection_vulns > 0 else None
        )
        checks.append(sec4_check)

        return checks

    def check_secret_and_workflow_hygiene(
        self, platform: CICDPlatform, results: Dict[str, Any]
    ) -> List[ComplianceCheck]:
        """
        NIST IA-5 / SC-13 style: secrets in pipeline definitions; workflow token scope.
        """
        checks: List[ComplianceCheck] = []
        secrets = results.get("secrets", []) or []
        critical_or_high = [
            s
            for s in secrets
            if getattr(s, "risk_level", None) in (RiskLevel.HIGH, RiskLevel.CRITICAL)
        ]
        exposed_logs = [s for s in secrets if getattr(s, "exposed_in_logs", False)]

        if not secrets:
            ia_status = "Pass"
        elif critical_or_high or exposed_logs:
            ia_status = "Fail"
        else:
            ia_status = "Warning"

        ia5 = ComplianceCheck(
            standard="NIST-SP-800-53",
            control_id="IA-5",
            description="Authenticator management — secrets must not live in VCS or logs",
            status=ia_status,
            evidence=(
                f"{len(secrets)} secret pattern(s) in configs; "
                f"{len(critical_or_high)} high/critical; {len(exposed_logs)} flagged as log-exposed"
            ),
            remediation=(
                "Use OIDC to cloud, GitHub/GitLab encrypted secrets, or vault; rotate any exposed material"
                if secrets
                else None
            ),
        )
        checks.append(ia5)

        wps = results.get("workflow_permissions", []) or []
        wide_token = [
            wp
            for wp in wps
            if getattr(wp, "has_excessive_permissions", False)
            or any(
                "write" in str(v).lower() or "all" in str(v).lower()
                for v in (getattr(wp, "github_token_permissions", None) or {}).values()
            )
        ]
        sc7 = ComplianceCheck(
            standard="NIST-SP-800-53",
            control_id="SC-7",
            description="Boundary protection — limit what CI jobs can modify via default tokens",
            status="Fail" if wide_token else "Pass",
            evidence=f"{len(wide_token)} workflow(s) with broad GITHUB_TOKEN / permissions settings",
            remediation=(
                "Tighten permissions: block in workflows; use environments + protection rules"
                if wide_token
                else None
            ),
        )
        checks.append(sc7)

        return checks

