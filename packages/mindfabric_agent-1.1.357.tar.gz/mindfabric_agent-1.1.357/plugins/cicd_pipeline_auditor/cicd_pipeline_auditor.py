"""
CICD Pipeline Auditor Plugin

Plugin for security analysis and vulnerability detection in CI/CD pipelines.
Detects configuration flaws, excessive privileges, secret leaks, and vulnerabilities
in continuous integration and delivery infrastructure.
"""

import os
import time
from datetime import datetime
from typing import Dict, List, Any
from plugins.base_plugin import BasePlugin
from utils.logger import logger
from plugins.plugin_helpers import send_alert, handle_partial, upload_file
from plugins.reproduction import ReproStep

from .proto import (
    AuditType, CICDPlatform, RiskLevel, DetectionMethod, ConfigurationType,
    ScanOptions, ConfigurationFile, Environment, IAMPermission, Secret,
    IsolationIssue, CodeInjectionVector, Vulnerability, WorkflowPermission,
    PipelineSecret, SecretsReport, WorkflowVulnerability, ComplianceCheck,
    AccessMatrix, SupplyChainCheck, ScanStatistics, ArtifactMetadata,
    AuditResult, VulnerabilityReport, RemediationPlan, CICDPipelineAuditorResult
)

# Import modules
from .modules.common import CommandHelper, ResponseHelper
from .modules.scanners.platform_orchestrator import PlatformOrchestrator
from .modules.scanners.runner_security_scanner import RunnerSecurityScanner
from .modules.scanners.pipeline_injection_scanner import PipelineInjectionScanner
from .modules.compliance import ComplianceChecker
from .modules.reporting import ReportGenerator

# Import additional scanners
try:
    from .modules.scanners.gitops_security_scanner import GitOpsSecurityScanner
    from .modules.scanners.supply_chain_scanner import SupplyChainScanner
    from .modules.scanners.secrets_scanner import SecretsScanner
    from .modules.scanners.multicloud_cicd_scanner import MultiCloudCICDScanner
    ADDITIONAL_SCANNERS_AVAILABLE = True
except ImportError:
    ADDITIONAL_SCANNERS_AVAILABLE = False
    GitOpsSecurityScanner = None
    SupplyChainScanner = None
    SecretsScanner = None
    MultiCloudCICDScanner = None


class CICDPipelineAuditorPlugin(BasePlugin):
    """
    Plugin for security analysis and vulnerability detection in CI/CD pipelines.
    Detects configuration flaws, excessive privileges, secret leaks, and vulnerabilities
    in continuous integration and delivery infrastructure.
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.active_scans = {}
        self.agent_id = options.get("agent_id", "unknown_agent")
        
        # Secret patterns for detection
        self.secret_patterns = {
            'aws_access_key': r'AKIA[0-9A-Z]{16}',
            'aws_secret_key': r'[0-9a-zA-Z/+]{40}',
            'github_token': r'ghp_[0-9a-zA-Z]{36}',
            'gitlab_token': r'glpat-[0-9a-zA-Z_\-]{20}',
            'docker_token': r'dckr_pat_[0-9a-zA-Z_\-]{28}',
            'api_key': r'[aA][pP][iI][_]?[kK][eE][yY].*[\'"][0-9a-zA-Z]{32,45}[\'"]',
            'private_key': r'-----BEGIN\s+.*PRIVATE\s+KEY.*-----',
            'password': r'[pP][aA][sS][sS][wW][oO][rR][dD].*[\'"][^\'"\s]{8,}[\'"]',
            'database_url': r'[a-zA-Z][a-zA-Z0-9+.-]*://[^\s]*',
            'jwt_token': r'eyJ[0-9a-zA-Z_-]*\.[0-9a-zA-Z_-]*\.[0-9a-zA-Z_-]*'
        }
        
        # Initialize modules
        self.command_helper = CommandHelper(self)
        self.response_helper = ResponseHelper(self)
        self.platform_orchestrator = PlatformOrchestrator(self)
        self.runner_security_scanner = RunnerSecurityScanner(self)
        self.pipeline_injection_scanner = PipelineInjectionScanner(self)
        self.compliance_checker = ComplianceChecker(self)
        self.report_generator = ReportGenerator(self)
        
        # Initialize additional scanners if available
        if ADDITIONAL_SCANNERS_AVAILABLE:
            # GitOpsSecurityScanner does not accept plugin_instance
            self.gitops_scanner = GitOpsSecurityScanner() if GitOpsSecurityScanner else None
            self.supply_chain_scanner = SupplyChainScanner(self) if SupplyChainScanner else None
            self.secrets_scanner = SecretsScanner(self) if SecretsScanner else None
            self.multicloud_cicd_scanner = MultiCloudCICDScanner(self) if MultiCloudCICDScanner else None
        else:
            self.gitops_scanner = None
            self.supply_chain_scanner = None
            self.secrets_scanner = None
            self.multicloud_cicd_scanner = None
    
    async def run(self):
        """Main method for running the plugin."""
        # Scheduler calls this plugin as `run` without specifying action.
        opts = self.options or {}
        action = opts.get("action") or "start_scan"
            
        logger.info(f"Starting CICD Pipeline Auditor with action: {action}")
        
        # Route to appropriate handler
        handlers = {
            "start_scan": self.hook_start_scan,
            "get_config_audit_details": self.hook_get_config_audit_details,
            "get_privilege_analysis": self.hook_get_privilege_analysis,
            "scan_pipeline_secrets": self.hook_scan_pipeline_secrets,
            "get_isolation_test_results": self.hook_get_isolation_test_results,
            "test_code_injection": self.hook_test_code_injection,
            "check_workflow_permissions": self.hook_check_workflow_permissions,
            "fix_workflow_permissions": self.hook_fix_workflow_permissions,
            "get_access_matrix": self.hook_get_access_matrix,
            "get_compliance_report": self.hook_get_compliance_report,
            "create_remediation_plan": self.hook_create_remediation_plan,
            "check_supply_chain_security": self.hook_check_supply_chain_security,
            "scan_runner_security": self.hook_scan_runner_security,
            "scan_pipeline_injection": self.hook_scan_pipeline_injection,
            "scan_gitops_security": self.hook_scan_gitops_security,
            "plugin_handover": self.hook_plugin_handover,
            "get_full_report": self.hook_get_full_report,
            "get_version": self.hook_get_version
        }
        
        handler = handlers.get(action)
        if handler:
            try:
                # Scheduler default: run a prod-like FULL local scan.
                # `start_scan()` requires non-empty `platforms` and `repo_paths`; otherwise it returns mostly empty results.
                # We auto-discover repo roots containing CI/CD configs across the filesystem (with safe exclusions).
                if action == "start_scan" and "action" not in opts:
                    repo_paths = self._discover_repo_paths_full_scan()
                    if not repo_paths:
                        # Nothing to scan locally; silent skip (no findings/warnings/errors)
                        return {
                            "status": "success",
                            "result": {
                                "skipped": True,
                                "reason": "no_repo_paths_discovered",
                            },
                            "findings": [],
                            "warnings": [],
                            "errors": [],
                        }
                    # Scan ALL supported platforms against discovered repos.
                    # Note: ScanOptions accepts CICDPlatform enums.
                    platforms = list(CICDPlatform)
                    result = await self.hook_start_scan(repo_paths=repo_paths, platforms=platforms)
                else:
                    # Pass through only user-provided fields.
                    payload = dict(opts)
                    for k in ("command", "command_id", "plugin", "args", "command_type", "options"):
                        payload.pop(k, None)
                    result = await handler(**payload)

                # Ensure UI blocks exist even when the scan returns only a report dict.
                return self.to_security_scan_v1(self._with_canonical_ui_blocks(result))
            except Exception as e:
                logger.error(f"Error in {action}: {str(e)}")
                return self.to_security_scan_v1(self._with_canonical_ui_blocks({
                    "status": "error",
                    "result": f"Error executing {action}: {str(e)}",
                    "data": {},
                }))
        else:
            return self.to_security_scan_v1(self._with_canonical_ui_blocks({
                "status": "error",
                "result": f"Unknown action: {action}",
                "data": {},
            }))

    def _with_canonical_ui_blocks(self, output: Any) -> Dict[str, Any]:
        """
        Add top-level UI blocks for the generic security_scan fallback.
        We avoid building plugin-specific findings here; we just ensure that when
        `findings` are not emitted, the UI still shows actionable blocks.
        """
        try:
            if isinstance(output, dict):
                out: Dict[str, Any] = dict(output)
            elif hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            else:
                out = {}
        except Exception:
            out = {}

        from plugins.security_contract import get_default_exploitation_commands
        from .modules.databases.ui_templates import (
            CICD_AUDITOR_RECOMMENDATIONS,
            CICD_AUDITOR_IMPACT,
            build_cicd_summary_description,
            cicd_infer_scan_root,
            cicd_scan_has_actionable_finding_material,
            get_cicd_auditor_exploitation_commands,
        )

        # Provide safe defaults when plugin doesn't return canonical findings.
        if not out.get("recommendations"):
            out["recommendations"] = CICD_AUDITOR_RECOMMENDATIONS
        result_obj = out.get("result") if isinstance(out.get("result"), dict) else None
        root = cicd_infer_scan_root(result_obj, fallback=".")
        if not out.get("exploitation_commands") and not out.get("commands"):
            # Platform-scoped greps only for summary path — avoid whole-repo token grep unless needed.
            actionable = cicd_scan_has_actionable_finding_material(result_obj)
            cmds = get_cicd_auditor_exploitation_commands(
                {"root": root},
                include_wide_repo_secret_grep=actionable,
            )
            if isinstance(cmds, list):
                cmds = [c for c in cmds if isinstance(c, str) and c.strip()]
            out["exploitation_commands"] = cmds
            if not out.get("exploitation_commands"):
                out["exploitation_commands"] = get_default_exploitation_commands()

        # If the scan output is a report dict (no canonical findings), optionally add one informational summary row.
        # Skip entirely when the run produced no vulns/secrets/injection/isolation/workflow issues — avoids polluting the threat stream.
        if not out.get("findings"):
            if cicd_scan_has_actionable_finding_material(result_obj):
                scan_id = (result_obj or {}).get("scan_id") if isinstance(result_obj, dict) else None
                plat_summary = ""
                try:
                    ars = (result_obj or {}).get("audit_results") or []
                    if ars and isinstance(ars[0], dict):
                        plats = ars[0].get("platforms_scanned") or []
                        if plats:
                            plat_summary = ", ".join(str(p) for p in plats[:12])
                except Exception:
                    plat_summary = ""
                out["findings"] = [
                    {
                        "title": "CI/CD audit completed — review reported pipeline issues",
                        "description": build_cicd_summary_description(result_obj),
                        "severity": "info",
                        "category": "CICD Pipeline Auditor",
                        "threat_type": "cicd_audit_summary",
                        "impact": (
                            "Operational follow-up: validate each listed vulnerability or secret finding in the audit output. "
                            "This row summarizes the scan; it is not a standalone incident."
                        ),
                        "recommendations": out.get("recommendations") or CICD_AUDITOR_RECOMMENDATIONS,
                        "exploitation_commands": out.get("exploitation_commands")
                        or get_cicd_auditor_exploitation_commands(
                            {"root": root},
                            include_wide_repo_secret_grep=True,
                        ),
                        "triage_hints": {
                            "stream_visibility": "secondary",
                            "finding_role": "posture_summary",
                            "scan_root": root[:800],
                            "platforms_scanned_preview": plat_summary[:500] if plat_summary else None,
                        },
                        "affected_resources": [
                            {
                                "type": "cicd_pipeline_scope",
                                "detail": "CI/CD definitions reviewed in this audit pass (see full JSON report for file paths).",
                                **(
                                    {
                                        "repository_root": str(
                                            (result_obj or {}).get("root_dir")
                                            or (result_obj or {}).get("root")
                                            or root
                                        ).strip()[:500]
                                    }
                                    if isinstance(result_obj, dict)
                                    else {"repository_root": root[:500]}
                                ),
                            }
                        ],
                        "evidence": {
                            "source": "cicd_pipeline_auditor.summary",
                            "overall_risk_level": (result_obj or {}).get("overall_risk_level")
                            if isinstance(result_obj, dict)
                            else None,
                            "scan_id": scan_id,
                            "audit_snapshot_note": (
                                "Open the plugin `result.audit_results` payload for concrete file paths, "
                                "line numbers, and secret/vuln records tied to this scan_id."
                            ),
                        },
                    }
                ]
            else:
                out["findings"] = []
        return out

    def _discover_repo_paths_full_scan(self) -> List[str]:
        """
        Discover repository roots to scan for CI/CD configs.

        Goals:
        - Avoid hardcoding a single directory (prod-safe).
        - Prefer CI/CD-relevant locations, but allow broad discovery.
        - Keep runtime bounded by pruning system dirs and timeboxing the walk.
        """
        # Candidate roots: allow override, otherwise use common workspace locations + cwd.
        env_roots = os.environ.get("CICD_AUDIT_ROOTS", "").strip()
        roots: List[str] = []
        if env_roots:
            for p in env_roots.split(":"):
                p = p.strip()
                if p:
                    roots.append(p)
        else:
            # NOTE: When running under systemd without WorkingDirectory, cwd is usually "/".
            # Never use "/" as a default scan root: some scanners use recursive glob patterns
            # which can traverse the entire filesystem and easily hit command timeouts.
            cwd = os.getcwd()
            if cwd == "/":
                cwd = ""
            roots = [
                cwd,
                "/app",
                "/workspace",
                "/repo",
                "/home",
                "/root",
            ]
            roots = [r for r in roots if r]

        # De-dup and keep existing paths only.
        seen = set()
        norm_roots: List[str] = []
        for r in roots:
            rr = os.path.abspath(r)
            if rr in seen:
                continue
            seen.add(rr)
            if os.path.exists(rr):
                norm_roots.append(rr)

        # Last resort: if nothing exists (very rare), avoid "/" (can be extremely slow).
        if not norm_roots:
            norm_roots = [p for p in ("/home", "/root") if os.path.exists(p)]

        # Timeboxed discovery to avoid runaway scans.
        start = time.time()
        max_seconds = int(os.environ.get("CICD_AUDIT_DISCOVERY_SECONDS", "20") or "20")
        max_repo_roots = int(os.environ.get("CICD_AUDIT_MAX_REPOS", "50") or "50")

        # Exclusions: performance + avoid virtual/system trees.
        excluded_dir_names = {
            ".git", "node_modules", "__pycache__", "venv", ".venv", ".tox",
            "dist", "build", "target", ".idea", ".pytest_cache",
        }
        excluded_path_prefixes = (
            "/proc", "/sys", "/dev", "/run",
            "/var/lib/docker", "/var/run/docker.sock",
            "/var/cache", "/var/tmp",
        )

        # CI/CD markers to identify repo roots.
        marker_files = {
            ".gitlab-ci.yml",
            "jenkinsfile",
            "azure-pipelines.yml",
            ".travis.yml",
            "bitbucket-pipelines.yml",
            ".drone.yml",
        }
        marker_dirs = {
            ".git",
            ".circleci",
            ".github",
        }

        repo_roots: List[str] = []
        repo_root_set = set()

        def _is_excluded_path(p: str) -> bool:
            for pref in excluded_path_prefixes:
                if p == pref or p.startswith(pref + "/"):
                    return True
            return False

        for base in norm_roots:
            if time.time() - start > max_seconds:
                break
            if _is_excluded_path(base):
                continue

            for root, dirs, files in os.walk(base):
                if time.time() - start > max_seconds:
                    break
                if _is_excluded_path(root):
                    dirs[:] = []
                    continue

                # Prune excluded dirs early.
                dirs[:] = [d for d in dirs if d not in excluded_dir_names and not _is_excluded_path(os.path.join(root, d))]

                lower_files = {f.lower() for f in files}

                # If we hit a well-known marker directory, treat current root as repo root.
                if any(d in marker_dirs for d in dirs):
                    if root not in repo_root_set:
                        repo_root_set.add(root)
                        repo_roots.append(root)
                        if len(repo_roots) >= max_repo_roots:
                            break

                # If we hit marker file in this directory, treat current root as repo root.
                if any(m in lower_files for m in marker_files):
                    if root not in repo_root_set:
                        repo_root_set.add(root)
                        repo_roots.append(root)
                        if len(repo_roots) >= max_repo_roots:
                            break

                # Special-case: GitHub workflows live under .github/workflows/*.
                if root.endswith("/.github/workflows") or "/.github/workflows/" in root:
                    repo_root = root.split("/.github/workflows")[0]
                    if repo_root and (repo_root not in repo_root_set):
                        repo_root_set.add(repo_root)
                        repo_roots.append(repo_root)
                        if len(repo_roots) >= max_repo_roots:
                            break

            if len(repo_roots) >= max_repo_roots:
                break

        # If nothing found, skip instead of scanning a huge tree.
        if not repo_roots:
            logger.info("[cicd_pipeline_auditor] No repo_paths discovered for full scan (no CI/CD markers found); skipping scan.")
            return []

        # Stable output (helps deterministic behavior).
        repo_roots = sorted(set(repo_roots))
        logger.info(f"[cicd_pipeline_auditor] Discovered repo_paths for full scan: {repo_roots[:10]}{'...' if len(repo_roots) > 10 else ''}")
        return repo_roots
    
    async def hook_start_scan(self, **kwargs) -> Dict[str, Any]:
        """Main method for starting CI/CD pipeline security audit."""
        scan_options = ScanOptions(**kwargs)
        scan_id = f"cicd_audit_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Save scan info
        self.active_scans[scan_id] = {
            "status": "running",
            "start_time": datetime.now(),
            "options": scan_options,
            "results": {},
            "progress": 0
        }
        
        try:
            # Run scan using orchestrator
            audit_result = await self.platform_orchestrator.run_scan(
                scan_id, scan_options, self.response_helper
            )
            
            # Generate final report
            final_report = CICDPipelineAuditorResult(
                type="cicd_pipeline_audit_result",
                scan_id=scan_id,
                timestamp=datetime.now(),
                target_environment=self.report_generator.get_target_environment(),
                audit_results=[audit_result],
                vulnerability_reports=self.report_generator.generate_vulnerability_reports(audit_result.vulnerabilities),
                remediation_plan=self.report_generator.generate_remediation_plan(audit_result.vulnerabilities),
                overall_risk_level=self.report_generator.calculate_overall_risk(audit_result.vulnerabilities),
                executive_summary=self.report_generator.generate_executive_summary(
                    audit_result.vulnerabilities, audit_result.statistics
                ),
                technical_details={"scan_options": scan_options.dict(), "statistics": audit_result.statistics.dict()},
                compliance_status=self.report_generator.generate_compliance_status(audit_result.compliance_checks)
            )

            # Build reproduction steps from audit_result (vulns/secrets/workflow perms/injection vectors)
            repro_steps: List[ReproStep] = []

            for vuln in audit_result.vulnerabilities or []:
                if getattr(vuln, "reproduction_steps", None):
                    repro_steps.extend(vuln.reproduction_steps)
                    continue
                action = vuln.proof_of_concept or f"Review and exploit vulnerability at {vuln.location}"
                step = ReproStep(
                    title=vuln.title,
                    preconditions=[f"Access to repo/pipeline config ({vuln.platform.value})"],
                    target=vuln.location,
                    action=action,
                    payload=None,
                    expected_outcome=vuln.description,
                    evidence=None,
                    tooling=["git", "api client", "ci-cli"],
                    safety="May change pipeline behavior; use lab/authorized scope",
                    cleanup="Revert workflow/config changes",
                )
                vuln.reproduction_steps = [step]
                repro_steps.append(step)

            for secret in audit_result.secrets or []:
                step = ReproStep(
                    title=f"Secret found: {secret.name}",
                    preconditions=["Read access to pipeline config/logs"],
                    target=secret.location,
                    action="Verify secret exposure",
                    expected_outcome="Secret value retrievable",
                    evidence=secret.value if hasattr(secret, "value") else None,
                    tooling=["grep", "rg", "api client"],
                    safety="Do not use secret in prod; rotate if confirmed",
                    cleanup="Rotate secret; scrub logs",
                )
                repro_steps.append(step)

            for wf in audit_result.workflow_permissions or []:
                step = ReproStep(
                    title=f"Workflow permission issue ({wf.platform.value})",
                    preconditions=["Access to workflow file/repo"],
                    target=wf.file_path if hasattr(wf, "file_path") else "workflow",
                    action="Review workflow permissions; attempt restricted action",
                    expected_outcome="Confirm excessive permission",
                    evidence=None,
                    tooling=["git", "ci-cli"],
                    safety="May execute workflow; use dry-run/lab",
                    cleanup="Restore permissions to least privilege",
                )
                repro_steps.append(step)

            for inj in audit_result.injection_vectors or []:
                step = ReproStep(
                    title=f"Code injection vector ({inj.vector_type})",
                    preconditions=["Access to pipeline config"],
                    target=inj.location if hasattr(inj, "location") else "pipeline",
                    action=inj.description,
                    expected_outcome="Injected step executes",
                    evidence=None,
                    tooling=["ci-cli"],
                    safety="Potential code execution; lab/authorized scope only",
                    cleanup="Remove injected step; re-run pipeline",
                )
                repro_steps.append(step)

            final_report.reproduction_steps = repro_steps or None
            
            # Update scan status
            self.active_scans[scan_id] = {
                "status": "completed",
                "start_time": self.active_scans[scan_id]["start_time"],
                "end_time": datetime.now(),
                "options": scan_options,
                "results": final_report.dict(),
                "progress": 100
            }
            
            return {
                "status": "success",
                "result": final_report.dict()
            }
            
        except Exception as e:
            self.active_scans[scan_id]["status"] = "failed"
            self.active_scans[scan_id]["errors"] = [str(e)]
            return {
                "status": "failed",
                "errors": [str(e)]
            }
    
    async def hook_get_version(self, **kwargs) -> Dict[str, Any]:
        """Get plugin version."""
        return {
            "status": "success",
            "result": {"version": self.VERSION}
        }
    
    # Hook methods - implemented using existing scan results
    async def hook_get_config_audit_details(self, **kwargs) -> Dict[str, Any]:
        """Get detailed configuration audit results."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    config_files = audit_results[0].get("config_files", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "config_files": [cf.dict() if hasattr(cf, 'dict') else cf for cf in config_files],
                            "total_files": len(config_files)
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_get_privilege_analysis(self, **kwargs) -> Dict[str, Any]:
        """Get privilege analysis results."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    workflow_permissions = audit_results[0].get("workflow_permissions", [])
                    iam_permissions = audit_results[0].get("iam_permissions", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "workflow_permissions": [wp.dict() if hasattr(wp, 'dict') else wp for wp in workflow_permissions],
                            "iam_permissions": [iam.dict() if hasattr(iam, 'dict') else iam for iam in iam_permissions]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_scan_pipeline_secrets(self, **kwargs) -> Dict[str, Any]:
        """Scan for secrets in pipeline configurations."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    secrets = audit_results[0].get("secrets", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "secrets": [s.dict() if hasattr(s, 'dict') else s for s in secrets],
                            "total_secrets": len(secrets),
                            "critical_secrets": len([s for s in secrets if hasattr(s, 'risk_level') and s.risk_level == RiskLevel.CRITICAL])
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_get_isolation_test_results(self, **kwargs) -> Dict[str, Any]:
        """Get isolation test results."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    isolation_issues = audit_results[0].get("isolation_issues", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "isolation_issues": [ii.dict() if hasattr(ii, 'dict') else ii for ii in isolation_issues]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_test_code_injection(self, **kwargs) -> Dict[str, Any]:
        """Test code injection vectors."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    injection_vectors = audit_results[0].get("injection_vectors", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "injection_vectors": [iv.dict() if hasattr(iv, 'dict') else iv for iv in injection_vectors]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_check_workflow_permissions(self, **kwargs) -> Dict[str, Any]:
        """Check workflow permissions."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    workflow_permissions = audit_results[0].get("workflow_permissions", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "workflow_permissions": [wp.dict() if hasattr(wp, 'dict') else wp for wp in workflow_permissions]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_fix_workflow_permissions(self, **kwargs) -> Dict[str, Any]:
        """Fix workflow permissions."""
        # This would require actual file modification - not implemented yet
        return {
            "status": "failed",
            "errors": ["Workflow permission fixing not yet implemented in modular version"]
        }
    
    async def hook_get_access_matrix(self, **kwargs) -> Dict[str, Any]:
        """Get access matrix."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    access_matrices = audit_results[0].get("access_matrices", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "access_matrices": [am.dict() if hasattr(am, 'dict') else am for am in access_matrices]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_get_compliance_report(self, **kwargs) -> Dict[str, Any]:
        """Get compliance report."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            audit_result = self.active_scans[scan_id].get("results", {})
            if isinstance(audit_result, dict):
                compliance_checks = audit_result.get("audit_results", [{}])[0].get("compliance_checks", [])
                return {
                    "status": "success",
                    "result": {"compliance_checks": compliance_checks}
                }
        return {
            "status": "success",
            "result": {"message": "No scan results available"}
        }
    
    async def hook_create_remediation_plan(self, **kwargs) -> Dict[str, Any]:
        """Create remediation plan."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            audit_result = self.active_scans[scan_id].get("results", {})
            if isinstance(audit_result, dict):
                remediation_plan = audit_result.get("remediation_plan", {})
                return {
                    "status": "success",
                    "result": {"remediation_plan": remediation_plan}
                }
        return {
            "status": "success",
            "result": {"message": "No scan results available for remediation plan"}
        }
    
    async def hook_check_supply_chain_security(self, **kwargs) -> Dict[str, Any]:
        """Check supply chain security."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            results = self.active_scans[scan_id].get("results", {})
            if isinstance(results, dict):
                audit_results = results.get("audit_results", [])
                if audit_results:
                    supply_chain_checks = audit_results[0].get("supply_chain_checks", [])
                    return {
                        "status": "success",
                        "result": {
                            "scan_id": scan_id,
                            "supply_chain_checks": [scc.dict() if hasattr(scc, 'dict') else scc for scc in supply_chain_checks]
                        }
                    }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }
    
    async def hook_scan_runner_security(self, **kwargs) -> Dict[str, Any]:
        """
        Scan CI/CD runner configurations for security issues.
        
        This includes:
        - Self-hosted runner security (GitHub Actions, GitLab Runner, Jenkins Agent)
        - Build cache security (cache poisoning, key collision)
        - New platform patterns (TeamCity, Bamboo, Drone, Tekton, Argo)
        """
        target_path = kwargs.get("target_path", ".")
        platform = kwargs.get("platform")  # Optional: github_actions, gitlab_runner, etc.
        
        import os
        all_findings = []
        
        # Scan files recursively for CI/CD configurations
        for root, dirs, files in os.walk(target_path):
            # Skip common non-relevant directories
            dirs[:] = [d for d in dirs if d not in ['.git', 'node_modules', '__pycache__', 'venv']]
            
            for file in files:
                # Check for CI/CD config files
                if any(pattern in file.lower() for pattern in [
                    '.yml', '.yaml', 'jenkinsfile', 'dockerfile', '.drone', 'bamboo',
                    '.gitlab-ci', 'azure-pipelines', '.circleci', '.travis', 'bitbucket-pipelines'
                ]):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        
                        # Scan content for runner security issues
                        findings = self.runner_security_scanner.scan_content(content, file_path, platform)
                        all_findings.extend(findings)
                    except Exception as e:
                        logger.warning(f"Could not scan {file_path}: {e}")
        
        # Get high-risk findings
        high_risk = self.runner_security_scanner.get_high_risk_findings()
        
        return {
            "status": "success",
            "result": {
                "total_findings": len(all_findings),
                "high_risk_count": len(high_risk),
                "findings": [
                    {
                        "runner_type": f.runner_type.value,
                        "finding_type": f.finding_type,
                        "title": f.title,
                        "description": f.description,
                        "risk": f.risk.value,
                        "evidence": f.evidence,
                        "remediation": f.remediation,
                        "cwe_id": f.cwe_id,
                        "mitre_id": f.mitre_id,
                    }
                    for f in all_findings
                ],
            }
        }
    
    async def hook_scan_pipeline_injection(self, **kwargs) -> Dict[str, Any]:
        """
        Scan for pipeline injection and artifact poisoning vulnerabilities.
        
        This includes:
        - Script injection in pipeline steps (GitHub Actions, GitLab CI, Jenkins, Azure)
        - Environment variable injection (PATH, LD_PRELOAD, Git config)
        - Artifact tampering and poisoning
        - Dependency confusion in pipelines
        - Build step injection (Dockerfile, Makefile, Gradle, Maven)
        - Package registry poisoning (npm, PyPI, Gem, Go)
        """
        target_path = kwargs.get("target_path", ".")
        
        import os
        all_findings = []
        
        # Scan files recursively for CI/CD configurations
        for root, dirs, files in os.walk(target_path):
            # Skip common non-relevant directories
            dirs[:] = [d for d in dirs if d not in ['.git', 'node_modules', '__pycache__', 'venv', '.venv', 'vendor']]
            
            for file in files:
                # Check for CI/CD config and build files
                if any(pattern in file.lower() for pattern in [
                    '.yml', '.yaml', 'jenkinsfile', 'dockerfile', '.drone',
                    '.gitlab-ci', 'azure-pipelines', '.circleci', '.travis',
                    'bitbucket-pipelines', 'makefile', 'build.gradle', 'pom.xml',
                    'package.json', 'setup.py', 'go.mod', '.gemspec', 'rakefile'
                ]):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        
                        # Scan content for injection vulnerabilities
                        findings = self.pipeline_injection_scanner.scan_content(content, file_path)
                        
                        # For workflow files, do additional checks
                        if any(p in file.lower() for p in ['.yml', '.yaml', 'jenkinsfile']):
                            workflow_findings = self.pipeline_injection_scanner.scan_workflow_file(content, file_path)
                            findings.extend(workflow_findings)
                        
                        all_findings.extend(findings)
                    except Exception as e:
                        logger.warning(f"Could not scan {file_path}: {e}")
        
        # Categorize findings by type
        findings_by_type = {}
        for f in all_findings:
            ftype = f.injection_type.value
            if ftype not in findings_by_type:
                findings_by_type[ftype] = []
            findings_by_type[ftype].append(f)
        
        # Get critical/high risk findings
        critical_high = [f for f in all_findings if f.risk.value in ['critical', 'high']]
        
        return {
            "status": "success",
            "result": {
                "total_findings": len(all_findings),
                "critical_high_count": len(critical_high),
                "findings_by_type": {
                    ftype: len(findings) for ftype, findings in findings_by_type.items()
                },
                "findings": [
                    {
                        "injection_type": f.injection_type.value,
                        "title": f.title,
                        "description": f.description,
                        "risk": f.risk.value,
                        "evidence": f.evidence,
                        "line_number": f.line_number,
                        "remediation": f.remediation,
                        "cwe_id": f.cwe_id,
                        "mitre_id": f.mitre_id,
                    }
                    for f in all_findings
                ],
            }
        }
    
    async def hook_scan_gitops_security(self, **kwargs) -> Dict[str, Any]:
        """
        Scan GitOps configurations for security issues.
        
        This includes:
        - ArgoCD security: RBAC, webhooks, sync policy, secrets in repo
        - Flux security: GitRepository, Kustomization, image automation
        - Helm security: Chart repository, values injection, secrets
        - Git repository security: Branch protection, commit signing, deploy keys
        """
        if not self.gitops_scanner:
            return {
                "status": "failed",
                "errors": ["GitOps scanner not available"]
            }
        
        target_path = kwargs.get("target_path", ".")
        
        import os
        all_findings = []
        
        # ArgoCD scan
        argocd_findings = await self.gitops_scanner.scan_argocd(target_path)
        all_findings.extend(argocd_findings)
        
        # Flux scan
        flux_findings = await self.gitops_scanner.scan_flux(target_path)
        all_findings.extend(flux_findings)
        
        # Helm scan
        helm_findings = await self.gitops_scanner.scan_helm(target_path)
        all_findings.extend(helm_findings)
        
        # Git repository security scan
        git_findings = await self.gitops_scanner.scan_git_security(target_path)
        all_findings.extend(git_findings)
        
        # Categorize findings
        findings_by_category = {}
        for f in all_findings:
            category = f.get("category", "unknown")
            if category not in findings_by_category:
                findings_by_category[category] = []
            findings_by_category[category].append(f)
        
        # Count by severity
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in all_findings:
            severity = f.get("severity", "low")
            if severity in severity_counts:
                severity_counts[severity] += 1
        
        return {
            "status": "success",
            "result": {
                "total_findings": len(all_findings),
                "severity_counts": severity_counts,
                "findings_by_category": {
                    cat: len(findings) for cat, findings in findings_by_category.items()
                },
                "findings": all_findings,
            }
        }
    
    async def hook_plugin_handover(self, **kwargs) -> Dict[str, Any]:
        """Hand over to another plugin."""
        # Plugin handover functionality not yet implemented
        return {
            "status": "failed",
            "errors": ["Plugin handover not yet implemented in modular version"]
        }
    
    async def hook_get_full_report(self, **kwargs) -> Dict[str, Any]:
        """Get full audit report."""
        scan_id = kwargs.get("scan_id")
        if scan_id and scan_id in self.active_scans:
            return {
                "status": "success",
                "result": self.active_scans[scan_id].get("results", {})
            }
        return {
            "status": "failed",
            "errors": ["Scan ID not found or scan not completed"]
        }

