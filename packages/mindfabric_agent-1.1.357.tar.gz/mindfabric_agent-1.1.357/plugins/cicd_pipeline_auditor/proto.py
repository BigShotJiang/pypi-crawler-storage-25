from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any, Set, Union, Literal
from plugins.reproduction import ReproStep
from enum import Enum
from datetime import datetime


class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute for CI/CD attack.
    """
    server: Optional[str] = Field(None, description="Target CI/CD platform/repo")
    ip: Optional[str] = Field(None, description="Target IP address")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")

class AuditType(str, Enum):
    """Types of security audits for CI/CD pipelines."""
    CONFIG_AUDIT = "config_audit"                # Configuration files audit
    PRIVILEGE_CHECK = "privilege_check"          # IAM/RBAC privileges analysis
    SECRET_ANALYSIS = "secret_analysis"          # Detection of secrets in pipelines
    ISOLATION_TEST = "isolation_test"            # Testing isolation between stages/projects
    CODE_INJECTION = "code_injection"            # Malicious code injection simulation
    
class CICDPlatform(str, Enum):
    """Supported CI/CD platforms for security auditing."""
    GITHUB = "github"                            # GitHub Actions
    JENKINS = "jenkins"                          # Jenkins
    GITLAB = "gitlab"                            # GitLab CI/CD
    AZURE_DEVOPS = "azure_devops"                # Azure DevOps
    CIRCLECI = "circleci"                        # CircleCI
    TRAVIS = "travis"                            # Travis CI
    BITBUCKET = "bitbucket"                      # Bitbucket Pipelines
    
class RiskLevel(str, Enum):
    """Risk levels for identified vulnerabilities."""
    LOW = "low"                                  # Low risk, minimal impact
    MEDIUM = "medium"                            # Medium risk, potential impact
    HIGH = "high"                                # High risk, significant impact
    CRITICAL = "critical"                        # Critical risk, severe impact
    
class DetectionMethod(str, Enum):
    """Methods for detecting vulnerabilities in CI/CD pipelines."""
    STATIC_ANALYSIS = "static_analysis"          # Static analysis of configurations
    CLOUD_ACCESS_MONITORING = "cloud_access_monitoring"  # Monitoring access to cloud resources
    CODE_INJECTION = "code_injection"            # Injecting malicious code into pipeline
    SECRET_EXTRACTION = "secret_extraction"      # Extracting secrets from pipeline
    EXCESSIVE_PRIVILEGE = "excessive_privilege"  # Checking for excessive privileges
    SUPPLY_CHAIN_TEST = "supply_chain_test"      # Testing supply chain integrity
    TASK_INJECTION = "task_injection"            # Injecting tasks into existing pipelines

class ConfigurationType(str, Enum):
    """Types of CI/CD configuration files."""
    GITHUB_WORKFLOW = "github_workflow"          # GitHub Actions workflow file
    JENKINSFILE = "jenkinsfile"                  # Jenkins pipeline file
    GITLAB_CI = "gitlab_ci"                      # GitLab CI/CD configuration
    AZURE_PIPELINE = "azure_pipeline"            # Azure DevOps pipeline
    CIRCLECI_CONFIG = "circleci_config"          # CircleCI configuration
    TRAVIS_YML = "travis_yml"                    # Travis CI configuration
    BITBUCKET_PIPELINE = "bitbucket_pipeline"    # Bitbucket Pipelines configuration

class ScanOptions(BaseModel):
    """Options for CI/CD pipeline security auditing."""
    platforms: List[CICDPlatform] = []           # Platforms to scan
    scan_types: List[AuditType] = []             # Types of scans to perform
    repo_paths: List[str] = []                   # Local repository paths
    remote_repos: List[str] = []                 # Remote repository URLs
    credentials: Dict[str, Dict[str, str]] = {}  # API credentials by platform
    max_depth: int = 3                           # Maximum depth for dependency scanning
    stealth_mode: bool = False                   # Minimize API calls for stealth
    simulation: bool = False                     # Simulate attacks without execution
    output_format: str = "json"                  # Output format for results

class ConfigurationFile(BaseModel):
    """Information about a CI/CD configuration file."""
    path: str                                    # File path
    platform: CICDPlatform                       # Associated CI/CD platform
    content: str                                 # File content
    last_modified: datetime                      # Last modification time
    file_size: int                               # File size in bytes
    file_hash: str                               # SHA256 hash of file
    config_type: ConfigurationType               # Type of configuration file
    has_secrets: bool = False                    # Contains secrets
    has_privilege_issues: bool = False           # Contains privilege issues
    has_security_issues: bool = False            # Contains security issues
    is_template: bool = False                    # Is a template file

class Environment(BaseModel):
    """Information about CI/CD execution environment."""
    platform: CICDPlatform                       # CI/CD platform
    runner_type: str                             # Type of runner/agent
    container_image: Optional[str] = None        # Container image if containerized
    os_type: str                                 # Operating system type
    isolation_level: str                         # Level of isolation
    privileged: bool = False                     # Runs in privileged mode
    network_access: bool = True                  # Has network access
    exposed_secrets: List[str] = []              # Secrets exposed to environment
    mountpoints: List[str] = []                  # Mounted volumes/directories
    environment_variables: Dict[str, str] = {}   # Environment variables
    
class IAMPermission(BaseModel):
    """Information about IAM/RBAC permissions."""
    service_account: str                         # Service account name
    platform: str                                # Platform (AWS, GCP, Azure, etc.)
    permissions: List[str] = []                  # List of permissions
    roles: List[str] = []                        # List of roles
    excessive: bool = False                      # Has excessive permissions
    recommended_permissions: List[str] = []      # Recommended permissions
    risk_level: RiskLevel = RiskLevel.MEDIUM     # Risk level

class Secret(BaseModel):
    """Information about a discovered secret."""
    secret_type: str                             # Type of secret (API key, token, etc.)
    location: str                                # Where the secret was found
    variable_name: Optional[str] = None          # Name of variable if applicable
    masked: bool = False                         # Is masked/protected
    exposed_in_logs: bool = False                # Is exposed in logs
    rotation_status: Optional[str] = None        # Rotation status if available
    risk_level: RiskLevel                        # Risk level
    remediation: str                             # Remediation advice

class IsolationIssue(BaseModel):
    """Information about isolation issues between CI/CD stages."""
    issue_type: str                              # Type of isolation issue
    source_stage: str                            # Source stage
    target_stage: str                            # Target stage
    description: str                             # Issue description
    risk_level: RiskLevel                        # Risk level
    remediation: str                             # Remediation advice

class CodeInjectionVector(BaseModel):
    """Information about potential code injection vectors."""
    vector_type: str                             # Type of injection vector
    location: str                                # Location of vulnerability
    trigger_method: str                          # How it can be triggered
    impact: str                                  # Potential impact
    proof_of_concept: Optional[str] = None       # PoC if simulation is enabled
    risk_level: RiskLevel                        # Risk level
    remediation: str                             # Remediation advice

class Vulnerability(BaseModel):
    """Information about an identified vulnerability."""
    id: str                                      # Unique identifier
    title: str                                   # Vulnerability title
    description: str                             # Detailed description
    location: str                                # File/location of vulnerability
    platform: CICDPlatform                       # Affected CI/CD platform
    detection_method: DetectionMethod            # How it was detected
    risk_level: RiskLevel                        # Risk level
    cve_id: Optional[str] = None                 # CVE ID if applicable
    cwes: List[str] = []                         # CWE identifiers
    is_exploitable: bool = True                  # Can be exploited
    exploitation_complexity: str = "Medium"      # Complexity to exploit
    proof_of_concept: Optional[str] = None       # PoC if available
    affected_components: List[str] = []          # Affected components
    references: List[str] = []                   # Reference links
    recommendations: List[str] = []              # Security recommendations
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = None  # Explicit shell commands
    reproduction_steps: Optional[List[ReproStep]] = None  # How to reproduce/verify

class WorkflowPermission(BaseModel):
    """Information about GitHub workflow permissions."""
    file_path: str                               # Workflow file path
    current_permissions: Dict[str, str] = {}     # Current permission settings
    recommended_permissions: Dict[str, str] = {} # Recommended permissions
    has_excessive_permissions: bool = False      # Has excessive permissions
    risk_level: RiskLevel                        # Risk level
    github_token_permissions: Dict[str, str] = {} # GITHUB_TOKEN permissions

class PipelineSecret(BaseModel):
    """Information about a secret in a CI/CD pipeline."""
    secret_id: str                               # Unique identifier
    platform: CICDPlatform                       # CI/CD platform
    secret_type: str                             # Type of secret
    location: str                                # Where it was found
    is_exposed: bool = False                     # Is exposed/leaked
    exposure_locations: List[str] = []           # Where it's exposed
    risk_level: RiskLevel                        # Risk level
    remediation: str                             # Remediation advice

class SecretsReport(BaseModel):
    """Report on secrets scanning in CI/CD pipelines."""
    type: Literal["secrets_report"] = "secrets_report"
    scan_id: str                                 # Scan identifier
    timestamp: datetime                          # Scan timestamp
    total_secrets: int                           # Total secrets found
    exposed_secrets: int                         # Exposed secrets count
    secrets: List[PipelineSecret] = []           # Details of found secrets
    platforms_scanned: List[CICDPlatform] = []   # Platforms that were scanned
    included_history: bool                       # Was history included
    scanned_logs: bool                           # Were logs scanned
    risk_summary: Dict[RiskLevel, int] = {}      # Count by risk level

class WorkflowVulnerability(BaseModel):
    """Information about a vulnerability in a workflow configuration."""
    name: str                                    # Vulnerability name
    description: str                             # Detailed description
    severity: RiskLevel                          # Severity level
    file_path: str                               # File path
    line_numbers: List[int] = []                 # Affected line numbers
    recommendations: List[str] = []              # Recommendations for fixing
    is_fixable: bool = True                      # Can be automatically fixed
    fix_command: Optional[str] = None            # Command to fix if applicable

class ComplianceCheck(BaseModel):
    """Information about a compliance check against security standards."""
    standard: str                                # Compliance standard
    control_id: str                              # Control identifier
    description: str                             # Control description
    status: str                                  # Pass/Fail/Warning
    evidence: str                                # Evidence for result
    remediation: Optional[str] = None            # Remediation if failed

class AccessMatrix(BaseModel):
    """Matrix showing access between CI/CD components."""
    type: Literal["access_matrix"] = "access_matrix"
    scan_id: str                                 # Scan identifier
    timestamp: datetime                          # Scan timestamp
    source_components: List[str] = []            # Source components
    target_components: List[str] = []            # Target components
    access_levels: Dict[str, Dict[str, str]] = {} # Access level mapping
    excessive_access: List[Dict[str, str]] = []  # Points of excessive access
    recommended_changes: List[Dict[str, Any]] = [] # Recommended changes

class SupplyChainCheck(BaseModel):
    """Check of supply chain security in CI/CD."""
    type: Literal["supply_chain_check"] = "supply_chain_check"
    scan_id: str                                 # Scan identifier
    timestamp: datetime                          # Scan timestamp
    dependency_checks: Dict[str, Any] = {}       # Dependency integrity checks
    # Mix of flags (bools) and human-readable notes (str); not bool-only
    signature_verification: Dict[str, Any] = {}  # Signature verification results
    artifact_provenance: Dict[str, Any] = {}     # Artifact provenance checks
    vulnerabilities: List[Dict[str, Any]] = []   # Identified vulnerabilities
    recommendations: List[str] = []              # Security recommendations

class ScanStatistics(BaseModel):
    """Statistics about the security audit scan."""
    total_repositories: int                      # Total repositories scanned
    total_config_files: int                      # Total config files analyzed
    total_vulnerabilities: int                   # Total vulnerabilities found
    vulnerabilities_by_risk: Dict[RiskLevel, int] = {} # Count by risk level
    vulnerabilities_by_platform: Dict[CICDPlatform, int] = {} # Count by platform
    vulnerabilities_by_type: Dict[str, int] = {} # Count by vulnerability type
    scan_duration_seconds: float                 # Scan duration
    files_processed: int                         # Files processed
    api_calls_made: int                          # API calls made

class ArtifactMetadata(BaseModel):
    """Metadata about an artifact from CI/CD pipeline."""
    artifact_id: str                             # Artifact identifier
    name: str                                    # Artifact name
    type: str                                    # Artifact type
    size: int                                    # Size in bytes
    created_at: datetime                         # Creation time
    created_by: str                              # Creator
    digest: Optional[str] = None                 # Digest/hash if available
    signatures: List[Dict[str, str]] = []        # Signatures if available
    has_integrity_verification: bool = False     # Has integrity verification
    is_tamper_proof: bool = False                # Is tamper-proof

class AuditResult(BaseModel):
    """Result of CI/CD pipeline security audit."""
    scan_id: str                                 # Unique scan identifier
    timestamp: datetime                          # Scan timestamp
    scan_duration: float                         # Scan duration in seconds
    auditor_version: str                         # Auditor plugin version
    scan_options: ScanOptions                    # Options used for scanning
    platforms_scanned: List[CICDPlatform] = []   # Platforms that were scanned
    config_files: List[ConfigurationFile] = []   # Scanned configuration files
    environments: List[Environment] = []         # Analyzed environments
    iam_permissions: List[IAMPermission] = []    # IAM/RBAC permissions
    secrets: List[Secret] = []                   # Discovered secrets
    isolation_issues: List[IsolationIssue] = []  # Isolation issues
    injection_vectors: List[CodeInjectionVector] = [] # Injection vectors
    vulnerabilities: List[Vulnerability] = []    # Identified vulnerabilities
    workflow_permissions: List[WorkflowPermission] = [] # Workflow permissions
    compliance_checks: List[ComplianceCheck] = [] # Compliance checks
    access_matrices: List[AccessMatrix] = []     # Access matrices
    supply_chain_checks: List[SupplyChainCheck] = [] # Supply chain checks
    artifact_metadata: List[ArtifactMetadata] = [] # Artifact metadata
    statistics: ScanStatistics                   # Scan statistics
    raw_data: Dict[str, Any] = {}                # Raw scan data
    errors: List[str] = []                       # Errors during scanning
    warnings: List[str] = []                     # Warnings during scanning
    summary: Dict[str, Any] = {}                 # Summary of findings
    
class VulnerabilityReport(BaseModel):
    """Detailed report of a specific vulnerability."""
    vulnerability_id: str                        # Vulnerability identifier
    title: str                                   # Vulnerability title
    description: str                             # Detailed description
    affected_components: List[str] = []          # Affected components
    exploitation_path: List[Dict[str, str]] = [] # Steps to exploit
    potential_impact: str                        # Potential impact
    screenshot_paths: List[str] = []             # Paths to screenshots
    is_false_positive: bool = False              # Is a false positive
    verification_steps: List[str] = []           # Steps to verify
    fix_verification: List[str] = []             # Steps to verify fix

class RemediationPlan(BaseModel):
    """Plan for remediating identified vulnerabilities."""
    plan_id: str                                 # Plan identifier
    vulnerabilities: List[str] = []              # Vulnerabilities to remediate
    steps: List[Dict[str, Any]] = []             # Remediation steps
    required_changes: Dict[str, List[str]] = {}  # Required changes by file
    estimated_effort: str                        # Estimated effort
    priority_order: List[str] = []               # Priority order for fixes
    validation_steps: List[str] = []             # Steps to validate fixes
    
class CICDPipelineAuditorResult(BaseModel):
    """Overall result of CI/CD pipeline security auditing."""
    type: Literal["cicd_pipeline_audit_result"] = "cicd_pipeline_audit_result"
    scan_id: str                                 # Scan identifier
    timestamp: datetime                          # Scan timestamp
    target_environment: str                      # Target environment name
    audit_results: List[AuditResult] = []        # Results by repository/pipeline
    vulnerability_reports: List[VulnerabilityReport] = [] # Detailed reports
    remediation_plan: Optional[RemediationPlan] = None # Remediation plan
    overall_risk_level: RiskLevel                # Overall risk assessment
    executive_summary: str                       # Executive summary
    technical_details: Dict[str, Any] = {}       # Technical details
    compliance_status: Dict[str, str] = {}       # Compliance status
    reproduction_steps: Optional[List[ReproStep]] = None  # Global reproduction plan