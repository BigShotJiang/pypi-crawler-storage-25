"""
Normalize plugin `affected_resources` into stable dicts and strip URL/path noise.

Used from security_contract.normalize_security_output for all security plugins.
"""

from __future__ import annotations

import re
import socket
from typing import Any, Dict, List


# Slash-tokens scraped from remediation text (backend regex) — not operational resources.
_NOISE_EXACT = frozenset(
    s.lower()
    for s in (
        "/cd",
        "/critical",
        "/tfsec",
        "/group",
        "/configuration",
        "/inspect",
        "/security",
        "/tooling",
        "/folder",
        "/project",
        "/resources",
        "/resources.",
        "/control",
        "/validate",
        "/sockets",
        "/hostpath",
        "/module",
        "/sgid",
        "/vector",
        "/vector.",
        "/baselines",
        "/baselines.",
        "/entries",
        "/system",
        "/rollback",
        "/ldap",
        "/dc",
        "/version",
        "/version.",
    )
)


def is_noise_affected_string(s: str) -> bool:
    """True if a legacy string should not appear in affected_resources (URL fragments, /CD, etc.)."""
    return _is_noise_string_impl(s)


def _is_noise_string_impl(s: str) -> bool:
    t = (s or "").strip()
    if not t:
        return True
    low = t.lower()
    if low in _NOISE_EXACT:
        return True
    # Trailing-dot fragments from broken URL parsing
    if len(t) < 36 and t.endswith(".") and t.startswith("/"):
        return True
    if low in ("local system", "localhost", "n/a", "none", "unknown"):
        return True
    # Single meaningless segment: /foo (no further path) and short
    if t.startswith("/") and t.count("/") == 1 and len(t) <= 16:
        seg = t[1:].split("/", 1)[0].lower()
        if seg in {"cd", "critical", "tfsec", "group", "security", "resources", "control", "sockets"}:
            return True
    return False


def _dedupe_objects(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: set = set()
    out: List[Dict[str, Any]] = []
    for d in items:
        key = tuple(sorted((k, str(v)[:500]) for k, v in d.items() if v is not None))
        if key in seen:
            continue
        seen.add(key)
        out.append(d)
    return out


def _default_host_scope(raw: Dict[str, Any], normalized: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    ip = raw.get("target_ip") or raw.get("targetIp") or normalized.get("target_ip")
    dns = raw.get("target_dns") or raw.get("targetDns")
    if isinstance(ip, str) and ip.strip():
        rows.append({"type": "network_host", "ip": ip.strip()})
    if isinstance(dns, str) and dns.strip():
        rows.append({"type": "network_host", "hostname": dns.strip()})
    ta = raw.get("target_asset") or raw.get("targetAsset") or normalized.get("target_asset")
    if isinstance(ta, str) and ta.strip() and ta.strip().lower() not in ("local system", "localhost"):
        rows.append({"type": "target_asset", "name": ta.strip()[:500]})
    try:
        hn = socket.gethostname()
    except Exception:
        hn = ""
    if hn:
        rows.append({"type": "scanned_host", "hostname": hn})
    return _dedupe_objects(rows)


def _inject_structured_context(raw: Dict[str, Any], acc: List[Dict[str, Any]]) -> None:
    th = raw.get("target_host")
    if isinstance(th, dict):
        hn = th.get("hostname") or th.get("host") or th.get("name")
        ip = th.get("ip_address") or th.get("ip") or th.get("address")
        obj: Dict[str, Any] = {"type": "lateral_target_host"}
        if isinstance(hn, str) and hn.strip():
            obj["hostname"] = hn.strip()[:500]
        if isinstance(ip, str) and ip.strip():
            obj["ip"] = ip.strip()[:80]
        if len(obj) > 1:
            acc.append(obj)

    user = raw.get("user")
    if isinstance(user, dict):
        un = user.get("username") or user.get("name") or user.get("sam_account_name")
        if isinstance(un, str) and un.strip():
            acc.append({"type": "directory_user", "username": un.strip()[:260]})

    loc = raw.get("detection_location") or raw.get("location")
    if not loc:
        pth = raw.get("path")
        if isinstance(pth, str) and pth.strip():
            ps = pth.strip()
            if ps.startswith("/") or ps.lower().startswith("c:\\") or ps.lower().startswith("c:/"):
                loc = ps
    if isinstance(loc, str) and loc.strip().startswith("/") and len(loc.strip()) >= 4:
        try:
            hn = socket.gethostname()
        except Exception:
            hn = ""
        row = {"type": "persistence_location", "path": loc.strip().split(":")[0][:2000]}
        if hn:
            row["hostname"] = hn
        acc.append(row)
    elif isinstance(loc, str) and loc.strip() and (loc.strip().lower().startswith("c:\\") or loc.strip().lower().startswith("c:/")):
        acc.append({"type": "persistence_location", "path": loc.strip()[:2000]})

    th_str = raw.get("target_host") if isinstance(raw.get("target_host"), str) else None
    if isinstance(th_str, str) and th_str.strip() and th_str.strip().lower() not in ("localhost", "unknown"):
        acc.append({"type": "lateral_target_host", "hostname": th_str.strip()[:500]})

    for ip_key in ("target_ip", "targetIp"):
        v = raw.get(ip_key)
        if isinstance(v, str) and v.strip():
            acc.append({"type": "network_host", "ip": v.strip()[:80]})
    for hn_key in ("target_dns", "targetDns", "hostname", "scan_hostname", "scanHostname"):
        v = raw.get(hn_key)
        if isinstance(v, str) and v.strip() and v.strip().lower() not in ("localhost", "unknown", "n/a"):
            acc.append({"type": "network_host", "hostname": v.strip()[:500]})

    user_s = raw.get("user") if isinstance(raw.get("user"), str) else None
    if isinstance(user_s, str) and user_s.strip() and user_s.strip().lower() not in ("unknown", "n/a", "none"):
        acc.append({"type": "directory_user", "username": user_s.strip()[:260]})

    pname = raw.get("process_name") or raw.get("processName")
    if isinstance(pname, str) and pname.strip():
        rowp: Dict[str, Any] = {"type": "process", "name": pname.strip()[:260]}
        pidv = raw.get("pid") or raw.get("process_id") or raw.get("processId")
        if pidv is not None:
            try:
                rowp["pid"] = int(pidv)
            except (TypeError, ValueError):
                pass
        acc.append(rowp)

    for ukey in ("url", "endpoint", "base_url", "baseUrl", "target_url", "targetUrl"):
        u = raw.get(ukey)
        if isinstance(u, str) and u.strip().lower().startswith(("http://", "https://")):
            acc.append({"type": "api_target", "url": u.strip()[:2000]})
            break

    proj = raw.get("project_id") or raw.get("projectId")
    rid = raw.get("resource_id") or raw.get("resourceId")
    rarn = raw.get("resource_arn") or raw.get("arn") or raw.get("resourceArn")
    sub = raw.get("subscription_id") or raw.get("subscriptionId")
    reg = raw.get("region")
    acct = raw.get("account_id") or raw.get("accountId")
    rname = raw.get("resource_name") or raw.get("resourceName")
    if any(x is not None and str(x).strip() for x in (proj, rid, rarn, sub, reg, acct, rname)):
        cr: Dict[str, Any] = {"type": "cloud_resource"}
        if isinstance(proj, str) and proj.strip():
            cr["project_id"] = proj.strip()[:260]
        if isinstance(rid, str) and rid.strip():
            cr["resource_id"] = rid.strip()[:500]
        if isinstance(rarn, str) and rarn.strip():
            cr["arn"] = rarn.strip()[:500]
        if isinstance(sub, str) and sub.strip():
            cr["subscription_id"] = sub.strip()[:120]
        if isinstance(reg, str) and reg.strip():
            cr["region"] = reg.strip()[:80]
        if isinstance(acct, str) and acct.strip():
            cr["account_id"] = acct.strip()[:40]
        if isinstance(rname, str) and rname.strip():
            cr["resource"] = rname.strip()[:500]
        if len(cr) > 1:
            acc.append(cr)

    dbh = raw.get("database_host") or raw.get("databaseHost")
    cat_l = str(raw.get("category") or "").lower()
    sub_l = str(raw.get("sub_category") or raw.get("subCategory") or "").lower()
    db_ctx = bool(
        raw.get("database_type")
        or raw.get("databaseType")
        or "database" in cat_l
        or "database" in sub_l
        or "dbsec" in cat_l
        or "sql" in sub_l
    )
    if (not isinstance(dbh, str) or not dbh.strip()) and db_ctx:
        h = raw.get("host")
        if isinstance(h, str) and h.strip():
            dbh = h
    if isinstance(dbh, str) and dbh.strip() and (db_ctx or raw.get("database_host") or raw.get("databaseHost")):
        dbrow: Dict[str, Any] = {"type": "database_instance", "host": dbh.strip()[:500]}
        dp = raw.get("port") or raw.get("database_port") or raw.get("databasePort")
        if dp is not None:
            try:
                dbrow["port"] = int(dp)
            except (TypeError, ValueError):
                pass
        acc.append(dbrow)

    dump_path = raw.get("dump_path") or raw.get("dumpPath") or raw.get("memory_dump_path")
    if isinstance(dump_path, str) and dump_path.strip():
        acc.append({"type": "memory_dump_artifact", "path": dump_path.strip()[:2000]})

    proc = raw.get("process") if isinstance(raw.get("process"), dict) else None
    if proc:
        pid = proc.get("pid")
        name = proc.get("name")
        if isinstance(name, str) and name.strip():
            row: Dict[str, Any] = {"type": "process", "name": name.strip()[:260]}
            if pid is not None:
                try:
                    row["pid"] = int(pid)
                except (TypeError, ValueError):
                    pass
            acc.append(row)


def _coerce_string(s: str) -> Optional[Dict[str, Any]]:
    t = s.strip()
    if _is_noise_string_impl(t):
        return None
    low = t.lower()
    if low.startswith(("http://", "https://")):
        return {"type": "network_service", "url": t[:2000]}
    if low.startswith(("redis://", "amqp://", "tcp://", "ssl://", "tls://")):
        return {"type": "network_service", "url": t[:2000]}
    # IPv4 / simple host:port
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", t):
        return {"type": "network_host", "ip": t}
    if re.match(r"^[a-zA-Z0-9._-]+:\d{1,5}$", t):
        return {"type": "network_service", "endpoint": t[:500]}
    # Filesystem paths — evidence location on scanned host (not “the” resource, but better than /CD)
    if t.startswith("/") and len(t) >= 4:
        return {"type": "filesystem_indicator", "path": t[:2000]}
    # Free-text labels (SIEM product names, etc.)
    return {"type": "security_control_surface", "label": t[:500]}


def polish_affected_resources_for_finding(
    _plugin_name: str,
    raw_finding: Dict[str, Any],
    normalized_finding: Dict[str, Any],
    normalized_list: List[Any],
) -> List[Dict[str, Any]]:
    """
    Turn mixed legacy strings/objects into a deduped list of dicts.
    Enriches from target_host / user / process / target_ip when present on the raw finding.
    """
    acc: List[Dict[str, Any]] = []
    _inject_structured_context(raw_finding, acc)

    for item in normalized_list or []:
        if isinstance(item, dict):
            # Already structured (IaC ansible_*, iac_aggregate_scope, etc.)
            acc.append(dict(item))
            continue
        if isinstance(item, str):
            co = _coerce_string(item)
            if co:
                acc.append(co)

    acc = _dedupe_objects(acc)
    if not acc:
        acc = _default_host_scope(raw_finding, normalized_finding)
    return acc
