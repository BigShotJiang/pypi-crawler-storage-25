"""
WebSocket C2 Detector Service

Detects WebSocket-based C2 communication.
"""

import logging
import uuid
import ipaddress
from datetime import datetime, timezone
from typing import List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    WebSocketC2Finding,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreAttackReference,
    MitreTactic,
    MitreTechnique,
)

logger = logging.getLogger(__name__)


class WebSocketC2DetectorService:
    """Service for detecting WebSocket C2 communication."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance

    @staticmethod
    def _is_internal_endpoint(address: str) -> bool:
        if not isinstance(address, str) or not address.strip():
            return True
        value = address.strip().lower()
        if value in {"localhost", "ip6-localhost"}:
            return True
        try:
            ip_obj = ipaddress.ip_address(value)
            return bool(
                ip_obj.is_loopback
                or ip_obj.is_private
                or ip_obj.is_link_local
                or ip_obj.is_reserved
                or ip_obj.is_multicast
            )
        except ValueError:
            return value.endswith(".local")

    @staticmethod
    def _has_suspicious_process_context(proc_name: Optional[str]) -> bool:
        if not isinstance(proc_name, str) or not proc_name.strip():
            return False
        proc = proc_name.strip().lower()
        suspicious_names = {
            "curl", "wget", "python", "python3", "perl", "ruby",
            "php", "node", "nodejs", "powershell", "pwsh",
            "cmd", "sh", "bash", "nc", "ncat", "socat",
        }
        return proc in suspicious_names

    @staticmethod
    def _build_ws_preview(
        *,
        remote_ip: str,
        remote_port: int,
        proc_name: Optional[str],
        proc_pid: Optional[int],
        conn_status: Optional[str],
        local_port: Optional[int],
        duration_sec: float,
        sample_count: int,
    ) -> List[str]:
        lines = [
            "Source: psutil TCP socket table — WebSocket-like long-lived session heuristic.",
            f"Remote: {remote_ip}:{remote_port}",
        ]
        if local_port:
            lines.append(f"Local ephemeral port: {local_port}")
        if conn_status:
            lines.append(f"Status: {conn_status}")
        if proc_pid is not None or (proc_name and proc_name.strip()):
            lines.append(f"Process: pid={proc_pid if proc_pid is not None else '?'} name={proc_name or 'unknown'}")
        lines.append(f"Observed span: ~{duration_sec:.0f}s across {sample_count} samples in scan window")
        lines.append("WebSocket upgrade headers and frame payloads are not available from psutil alone.")
        return lines

    async def detect(self, target: Optional[ScanTarget] = None) -> List[WebSocketC2Finding]:
        """
        Detect WebSocket C2 communication.
        
        Args:
            target: Scan target configuration
            
        Returns:
            List of WebSocket C2 findings
        """
        findings = []
        
        try:
            import psutil
            import socket
            from collections import defaultdict
            from datetime import datetime, timezone, timedelta
            
            # WebSocket connections are typically long-lived TCP connections
            # on ports 80, 443, or custom ports
            websocket_ports = {80, 443, 8080, 8443, 8888, 9001}
            
            # Track WebSocket-like connections
            ws_connections = defaultdict(lambda: {
                'connections': [],
                'duration': 0,
                'last_seen': None,
            })
            
            try:
                connections = psutil.net_connections(kind='inet')
                now = datetime.now(timezone.utc).replace(tzinfo=None)
                
                for conn in connections:
                    try:
                        if not conn.raddr:
                            continue
                        
                        remote_ip = conn.raddr.ip
                        remote_port = conn.raddr.port
                        local_port = conn.laddr.port if conn.laddr else 0
                        
                        # Check if TCP
                        is_tcp = False
                        try:
                            if hasattr(conn, 'type'):
                                conn_type = str(conn.type).lower()
                                if 'tcp' in conn_type or conn_type == '1':
                                    is_tcp = True
                        except (AttributeError, TypeError):
                            pass
                        
                        if not is_tcp:
                            continue
                        
                        # Check if this could be a WebSocket connection
                        is_ws_port = remote_port in websocket_ports or local_port in websocket_ports
                        is_established = hasattr(conn, 'status') and 'ESTABLISHED' in str(conn.status).upper()
                        
                        if is_ws_port and is_established:
                            key = f"{remote_ip}:{remote_port}"
                            ws_connections[key]['connections'].append(now)
                            ws_connections[key]['last_seen'] = now
                            
                            # Get process info
                            proc_name = None
                            proc_pid = conn.pid
                            if proc_pid:
                                try:
                                    proc = psutil.Process(proc_pid)
                                    proc_name = proc.name()
                                except (psutil.NoSuchProcess, psutil.AccessDenied):
                                    pass
                            
                            # Check for long-lived connections (WebSocket characteristic)
                            if len(ws_connections[key]['connections']) >= 3:
                                time_span = (max(ws_connections[key]['connections']) - min(ws_connections[key]['connections'])).total_seconds()
                                if time_span > 60:  # Connection alive for more than 1 minute
                                    if (
                                        not self._is_internal_endpoint(remote_ip)
                                        or (remote_port in {8888, 9001} and self._has_suspicious_process_context(proc_name))
                                    ):
                                        st = str(getattr(conn, "status", "") or "")
                                        n = len(ws_connections[key]["connections"])
                                        finding = self._create_finding(
                                            c2_server=remote_ip,
                                            c2_port=remote_port,
                                            ws_path=None,  # Cannot extract from psutil
                                            message_frequency=None,
                                            proc_name=proc_name,
                                            proc_pid=proc_pid,
                                            conn_status=st or None,
                                            local_port=local_port,
                                            duration_sec=time_span,
                                            sample_count=n,
                                        )
                                        findings.append(finding)
                                        logger.warning(f"Long-lived WebSocket-like connection: {remote_ip}:{remote_port} (duration: {time_span:.0f}s)")
                            
                    except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                        continue
                
            except Exception as e:
                logger.debug(f"Error analyzing WebSocket connections: {e}")
            
            logger.info(f"WebSocket C2 detection completed: {len(findings)} findings")
            
        except ImportError:
            logger.warning("psutil not available, WebSocket C2 detection limited")
        except Exception as e:
            logger.error(f"WebSocket C2 detection failed: {e}", exc_info=True)
        
        return findings
    
    def _create_finding(
        self,
        c2_server: str,
        c2_port: int,
        ws_path: Optional[str] = None,
        message_frequency: Optional[float] = None,
        proc_name: Optional[str] = None,
        proc_pid: Optional[int] = None,
        conn_status: Optional[str] = None,
        local_port: Optional[int] = None,
        duration_sec: float = 0.0,
        sample_count: int = 0,
    ) -> WebSocketC2Finding:
        """Create a WebSocket C2 finding."""
        preview = self._build_ws_preview(
            remote_ip=c2_server,
            remote_port=c2_port,
            proc_name=proc_name,
            proc_pid=proc_pid,
            conn_status=conn_status,
            local_port=local_port,
            duration_sec=duration_sec,
            sample_count=sample_count,
        )
        return WebSocketC2Finding(
            id=str(uuid.uuid4()),
            severity=SeverityLevel.HIGH,
            confidence=ConfidenceLevel.MEDIUM,
            title=f"WebSocket C2 communication detected: {c2_server}:{c2_port}",
            description=f"WebSocket C2 communication detected to {c2_server}:{c2_port}{' at ' + ws_path if ws_path else ''}. This may indicate malware command and control activity.",
            c2_server=c2_server,
            c2_port=c2_port,
            ws_path=ws_path,
            message_frequency=message_frequency,
            first_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            mitre_attack=MitreAttackReference(
                tactic=MitreTactic.COMMAND_AND_CONTROL,
                technique_id="T1071",
                technique_name="Application Layer Protocol",
                sub_technique_id="T1071.001",
                sub_technique_name="Web Protocols",
            ),
            recommendation="Block WebSocket connections to suspicious servers. Monitor WebSocket traffic patterns.",
            risk_score=8.5,
            evidence_preview=preview,
        )
