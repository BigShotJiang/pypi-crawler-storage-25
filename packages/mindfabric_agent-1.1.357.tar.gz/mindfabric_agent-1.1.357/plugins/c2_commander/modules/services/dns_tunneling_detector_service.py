"""
DNS Tunneling C2 Detector Service

Detects DNS tunneling-based C2 communication.
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    DNSTunnelingFinding,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreAttackReference,
    MitreTactic,
    MitreTechnique,
)

logger = logging.getLogger(__name__)


class DNSTunnelingDetectorService:
    """Service for detecting DNS tunneling C2 communication."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def detect(self, target: Optional[ScanTarget] = None) -> List[DNSTunnelingFinding]:
        """
        Detect DNS tunneling C2 communication.
        
        Args:
            target: Scan target configuration
            
        Returns:
            List of DNS tunneling findings
        """
        findings = []
        
        try:
            import psutil
            import socket
            import re
            from collections import defaultdict
            from datetime import datetime, timezone
            
            # Track DNS connections
            dns_connections = defaultdict(lambda: {
                'queries': [],
                'domains': set(),
                'query_types': set(),
            })
            
            try:
                connections = psutil.net_connections(kind='inet')
                now = datetime.now(timezone.utc).replace(tzinfo=None)
                
                for conn in connections:
                    try:
                        if not conn.raddr:
                            continue
                        
                        remote_ip = conn.raddr.ip
                        remote_port = conn.raddr.port
                        
                        # Check if this is DNS traffic (UDP/TCP port 53)
                        is_dns = remote_port == 53
                        is_udp = False
                        try:
                            if hasattr(conn, 'type'):
                                conn_type = str(conn.type).lower()
                                if 'udp' in conn_type or conn_type == '2':
                                    is_udp = True
                        except (AttributeError, TypeError):
                            pass
                        
                        if is_dns:
                            key = f"{remote_ip}:{remote_port}"
                            dns_connections[key]['queries'].append(now)
                            
                            # Get process info to check for suspicious DNS clients
                            proc_name = None
                            proc_pid = conn.pid
                            if proc_pid:
                                try:
                                    proc = psutil.Process(proc_pid)
                                    proc_name = proc.name()
                                except (psutil.NoSuchProcess, psutil.AccessDenied):
                                    pass
                            
                            # Check for high DNS query frequency (potential tunneling)
                            queries = dns_connections[key]['queries']
                            if len(queries) >= 10:
                                time_span = (max(queries) - min(queries)).total_seconds()
                                if time_span > 0:
                                    queries_per_second = len(queries) / time_span
                                    if queries_per_second > 5:  # High frequency threshold
                                        finding = self._create_finding(
                                            c2_server=remote_ip,
                                            domain=f"resolver-{remote_ip}",
                                            query_type=None,
                                            data_volume=len(queries),
                                            query_frequency=queries_per_second,
                                            proc_name=proc_name,
                                            proc_pid=proc_pid,
                                            time_span_sec=time_span,
                                        )
                                        findings.append(finding)
                                        logger.warning(f"High DNS query frequency detected: {remote_ip} ({queries_per_second:.1f} queries/sec)")
                            
                    except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                        continue
                
            except Exception as e:
                logger.debug(f"Error analyzing DNS connections: {e}")
            
            # Additional analysis: check DNS resolver configuration and processes
            try:
                # Check for processes making DNS queries
                for proc in psutil.process_iter(['pid', 'name']):
                    try:
                        proc_info = proc.info
                        proc_name = proc_info.get('name', '').lower()
                        # Check for processes that might be using DNS tunneling
                        suspicious_names = ['dig', 'nslookup', 'host', 'python', 'perl']
                        if any(name in proc_name for name in suspicious_names):
                            try:
                                conns = proc.connections()
                                for conn in conns:
                                    if conn.raddr and conn.raddr.port == 53:
                                        logger.debug(f"Process {proc_name} (PID {proc_info['pid']}) has DNS connection")
                            except (psutil.AccessDenied, psutil.NoSuchProcess):
                                pass
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            except Exception as e:
                logger.debug(f"Error analyzing DNS processes: {e}")
            
            logger.info(f"DNS tunneling C2 detection completed: {len(findings)} findings")
            
        except ImportError:
            logger.warning("psutil not available, DNS tunneling detection limited")
        except Exception as e:
            logger.error(f"DNS tunneling detection failed: {e}", exc_info=True)
        
        return findings
    
    def _create_finding(
        self,
        c2_server: str,
        domain: str,
        query_type: Optional[str] = None,
        data_volume: Optional[int] = None,
        query_frequency: Optional[float] = None,
        proc_name: Optional[str] = None,
        proc_pid: Optional[int] = None,
        time_span_sec: Optional[float] = None,
    ) -> DNSTunnelingFinding:
        """Create a DNS tunneling finding."""
        preview: List[str] = [
            "Source: psutil connection table — DNS port 53 activity rate heuristic (not DNS payload inspection).",
            f"Resolver endpoint observed: {c2_server}:53",
            f"Label: {domain}",
        ]
        if query_frequency is not None:
            preview.append(f"Estimated query rate in window: ~{query_frequency:.1f} queries/sec")
        if data_volume is not None:
            preview.append(f"Samples in window: {data_volume} connection observations")
        if time_span_sec is not None and time_span_sec > 0:
            preview.append(f"Window duration: ~{time_span_sec:.1f}s")
        if proc_pid is not None or (proc_name and proc_name.strip()):
            preview.append(f"Associated process: pid={proc_pid if proc_pid is not None else '?'} name={proc_name or 'unknown'}")
        preview.append("QNAME / TXT entropy / tunnel encoding are not available without packet capture or resolver logs.")

        return DNSTunnelingFinding(
            id=str(uuid.uuid4()),
            severity=SeverityLevel.CRITICAL,
            confidence=ConfidenceLevel.MEDIUM,
            title=f"DNS Tunneling C2 detected: {domain}",
            description=f"DNS tunneling C2 communication detected to {domain} via {c2_server}. This may indicate data exfiltration or C2 communication.",
            c2_server=c2_server,
            domain=domain,
            query_type=query_type,
            data_volume=data_volume,
            query_frequency=query_frequency,
            first_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            mitre_attack=MitreAttackReference(
                tactic=MitreTactic.COMMAND_AND_CONTROL,
                technique_id="T1071",
                technique_name="Application Layer Protocol",
                sub_technique_id="T1071.004",
                sub_technique_name="DNS",
            ),
            recommendation="Block suspicious DNS queries. Monitor DNS traffic for anomalies. Use DNS filtering.",
            risk_score=9.0,
            evidence_preview=preview,
        )
