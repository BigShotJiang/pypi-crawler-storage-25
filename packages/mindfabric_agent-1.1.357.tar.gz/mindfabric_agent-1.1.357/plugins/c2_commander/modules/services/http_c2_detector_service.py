"""
HTTP/HTTPS C2 Detector Service

Detects HTTP/HTTPS-based C2 communication patterns.
"""

import logging
import uuid
import ipaddress
from datetime import datetime, timezone
from typing import List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    HTTPC2Finding,
    C2Type,
    ProtocolType,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreAttackReference,
    MitreTactic,
    MitreTechnique,
)

logger = logging.getLogger(__name__)


class HTTPC2DetectorService:
    """Service for detecting HTTP/HTTPS C2 communication."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance

    @staticmethod
    def _is_internal_endpoint(address: str) -> bool:
        if not isinstance(address, str) or not address.strip():
            return True
        value = address.strip().lower()
        if value in {"localhost", "ip6-localhost"}:
            return True
        try:
            ip_obj = ipaddress.ip_address(value)
            return bool(
                ip_obj.is_loopback
                or ip_obj.is_private
                or ip_obj.is_link_local
                or ip_obj.is_reserved
                or ip_obj.is_multicast
            )
        except ValueError:
            return value.endswith(".local")

    @staticmethod
    def _has_suspicious_process_context(proc_name: Optional[str]) -> bool:
        if not isinstance(proc_name, str) or not proc_name.strip():
            return False
        proc = proc_name.strip().lower()
        suspicious_names = {
            "curl", "wget", "python", "python3", "perl", "ruby",
            "php", "node", "nodejs", "powershell", "pwsh",
            "cmd", "sh", "bash", "nc", "ncat", "socat",
        }
        return proc in suspicious_names

    def _should_report_connection(
        self,
        *,
        remote_ip: str,
        remote_port: int,
        proc_name: Optional[str],
        beacon_interval: Optional[int] = None,
    ) -> bool:
        if not self._is_internal_endpoint(remote_ip):
            return True
        if beacon_interval is not None and beacon_interval > 0 and self._has_suspicious_process_context(proc_name):
            return True
        if remote_port in {4444, 8888, 9999} and self._has_suspicious_process_context(proc_name):
            return True
        return False

    @staticmethod
    def _build_evidence_preview(
        *,
        remote_ip: str,
        remote_port: int,
        protocol: ProtocolType,
        proc_name: Optional[str],
        proc_pid: Optional[int],
        conn_status: Optional[str],
        local_port: Optional[int],
        beacon_interval: Optional[int],
        reason: str,
    ) -> List[str]:
        lines = [
            "Source: host netlink/socket table snapshot (psutil) — not a full PCAP.",
            f"Signal: {reason}",
            f"Remote: {remote_ip}:{remote_port} (tcp, {protocol.value})",
        ]
        if local_port is not None and local_port > 0:
            lines.append(f"Local side: ephemeral port {local_port}")
        if conn_status:
            lines.append(f"Socket status: {conn_status}")
        if proc_pid is not None or (proc_name and proc_name.strip()):
            lines.append(f"Owning process: pid={proc_pid if proc_pid is not None else '?'} name={proc_name or 'unknown'}")
        else:
            lines.append("Owning process: unavailable (permissions or transient socket)")
        if beacon_interval is not None and beacon_interval > 0:
            lines.append(f"Timing: ~{beacon_interval}s between samples (beacon-like regularity heuristic)")
        lines.append("L7 (User-Agent, path, TLS SNI) is not visible from this data source alone.")
        return lines

    async def detect(self, target: Optional[ScanTarget] = None) -> List[HTTPC2Finding]:
        """
        Detect HTTP/HTTPS C2 communication.
        
        Args:
            target: Scan target configuration
            
        Returns:
            List of HTTP C2 findings
        """
        findings = []
        
        try:
            import psutil
            import socket
            from collections import defaultdict
            from datetime import datetime, timezone, timedelta
            
            # Known C2 ports (HTTP/HTTPS)
            c2_ports = {80, 443, 8080, 8443, 4444, 8888, 9999}
            
            # Track connections for beaconing detection
            connection_history = defaultdict(lambda: {
                'timestamps': [],
                'remote_ips': set(),
                'ports': set(),
            })
            
            try:
                connections = psutil.net_connections(kind='inet')
                now = datetime.now(timezone.utc).replace(tzinfo=None)
                
                for conn in connections:
                    try:
                        if not conn.raddr:
                            continue
                        
                        remote_ip = conn.raddr.ip
                        remote_port = conn.raddr.port
                        local_port = conn.laddr.port if conn.laddr else 0
                        
                        # Check if this is HTTP/HTTPS traffic
                        is_http = remote_port in c2_ports or local_port in c2_ports
                        is_tcp = hasattr(conn, 'type') and (str(conn.type) == 'tcp' or (hasattr(socket, 'SOCK_STREAM') and conn.type == socket.SOCK_STREAM))
                        
                        if is_http and is_tcp:
                            # Get process info
                            proc_name = None
                            proc_pid = conn.pid
                            if proc_pid:
                                try:
                                    proc = psutil.Process(proc_pid)
                                    proc_name = proc.name()
                                except (psutil.NoSuchProcess, psutil.AccessDenied):
                                    pass
                            
                            # Track connection for beaconing analysis
                            key = f"{remote_ip}:{remote_port}"
                            connection_history[key]['timestamps'].append(now)
                            connection_history[key]['remote_ips'].add(remote_ip)
                            connection_history[key]['ports'].add(remote_port)
                            
                            # Check for suspicious patterns
                            # 1. Connections to non-standard ports with HTTP-like behavior
                            if remote_port not in {80, 443} and remote_port in c2_ports:
                                if self._should_report_connection(
                                    remote_ip=remote_ip,
                                    remote_port=remote_port,
                                    proc_name=proc_name,
                                ):
                                    st = str(getattr(conn, "status", "") or "")
                                    finding = self._create_finding(
                                        c2_server=remote_ip,
                                        c2_port=remote_port,
                                        protocol=ProtocolType.HTTP if remote_port == 80 else ProtocolType.HTTPS,
                                        user_agent=None,  # Cannot extract from psutil
                                        http_method=None,
                                        uri_pattern=None,
                                        beacon_interval=None,
                                        proc_name=proc_name,
                                        proc_pid=proc_pid,
                                        conn_status=st or None,
                                        local_port=local_port,
                                        preview_reason="non-standard HTTP(S) port with outbound TCP",
                                    )
                                    findings.append(finding)
                                    logger.warning(f"Suspicious HTTP/HTTPS connection: {remote_ip}:{remote_port}")
                            
                            # 2. Detect beaconing patterns (regular intervals)
                            timestamps = connection_history[key]['timestamps']
                            if len(timestamps) >= 3:
                                # Calculate intervals
                                intervals = []
                                for i in range(1, len(timestamps)):
                                    interval = (timestamps[i] - timestamps[i-1]).total_seconds()
                                    intervals.append(interval)
                                
                                # Check if intervals are regular (beaconing)
                                if len(intervals) >= 2:
                                    avg_interval = sum(intervals) / len(intervals)
                                    variance = sum((x - avg_interval) ** 2 for x in intervals) / len(intervals)
                                    
                                    # Low variance indicates regular intervals (beaconing)
                                    if variance < (avg_interval * 0.2) ** 2 and avg_interval > 0:
                                        beacon_interval = int(avg_interval)
                                        if self._should_report_connection(
                                            remote_ip=remote_ip,
                                            remote_port=remote_port,
                                            proc_name=proc_name,
                                            beacon_interval=beacon_interval,
                                        ):
                                            st = str(getattr(conn, "status", "") or "")
                                            finding = self._create_finding(
                                                c2_server=remote_ip,
                                                c2_port=remote_port,
                                                protocol=ProtocolType.HTTPS if remote_port == 443 else ProtocolType.HTTP,
                                                user_agent=None,
                                                http_method=None,
                                                uri_pattern=None,
                                                beacon_interval=beacon_interval,
                                                proc_name=proc_name,
                                                proc_pid=proc_pid,
                                                conn_status=st or None,
                                                local_port=local_port,
                                                preview_reason="repeated connection timing suggests beaconing",
                                            )
                                            findings.append(finding)
                                            logger.warning(f"Potential C2 beaconing detected: {remote_ip}:{remote_port} (interval: {avg_interval:.1f}s)")
                            
                    except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                        continue
                
            except Exception as e:
                logger.debug(f"Error analyzing HTTP/HTTPS connections: {e}")
            
            # Additional analysis: check for processes making network connections
            try:
                for proc in psutil.process_iter(['pid', 'name', 'connections']):
                    try:
                        proc_info = proc.info
                        proc_name = proc_info.get('name', '').lower()
                        # Check for suspicious processes that might be C2 clients
                        suspicious_names = ['curl', 'wget', 'python', 'perl', 'ruby', 'php', 'node']
                        if any(name in proc_name for name in suspicious_names):
                            try:
                                conns = proc.connections()
                                for conn in conns:
                                    if conn.raddr and conn.raddr.port in c2_ports:
                                        # Found suspicious process making C2-like connections
                                        logger.debug(f"Process {proc_name} (PID {proc_info['pid']}) has connection to C2 port {conn.raddr.port}")
                            except (psutil.AccessDenied, psutil.NoSuchProcess):
                                pass
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            except Exception as e:
                logger.debug(f"Error analyzing processes: {e}")
            
            logger.info(f"HTTP/HTTPS C2 detection completed: {len(findings)} findings")
            
        except ImportError:
            logger.warning("psutil not available, HTTP C2 detection limited")
        except Exception as e:
            logger.error(f"HTTP C2 detection failed: {e}", exc_info=True)
        
        return findings
    
    def _create_finding(
        self,
        c2_server: str,
        c2_port: int,
        protocol: ProtocolType,
        user_agent: Optional[str] = None,
        http_method: Optional[str] = None,
        uri_pattern: Optional[str] = None,
        beacon_interval: Optional[int] = None,
        proc_name: Optional[str] = None,
        proc_pid: Optional[int] = None,
        conn_status: Optional[str] = None,
        local_port: Optional[int] = None,
        preview_reason: str = "HTTP/HTTPS C2 heuristic",
    ) -> HTTPC2Finding:
        """Create an HTTP C2 finding."""
        c2_type = C2Type.HTTPS_C2 if protocol == ProtocolType.HTTPS else C2Type.HTTP_C2
        preview = self._build_evidence_preview(
            remote_ip=c2_server,
            remote_port=c2_port,
            protocol=protocol,
            proc_name=proc_name,
            proc_pid=proc_pid,
            conn_status=conn_status,
            local_port=local_port,
            beacon_interval=beacon_interval,
            reason=preview_reason,
        )

        return HTTPC2Finding(
            id=str(uuid.uuid4()),
            c2_type=c2_type,
            severity=SeverityLevel.CRITICAL,
            confidence=ConfidenceLevel.MEDIUM,
            title=f"{protocol.value.upper()} C2 communication detected: {c2_server}:{c2_port}",
            description=f"HTTP/HTTPS C2 communication detected to {c2_server}:{c2_port}. This may indicate malware command and control activity.",
            c2_server=c2_server,
            c2_port=c2_port,
            protocol=protocol,
            user_agent=user_agent,
            http_method=http_method,
            uri_pattern=uri_pattern,
            beacon_interval=beacon_interval,
            first_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            mitre_attack=MitreAttackReference(
                tactic=MitreTactic.COMMAND_AND_CONTROL,
                technique_id="T1071",
                technique_name="Application Layer Protocol",
                sub_technique_id="T1071.001",
                sub_technique_name="Web Protocols",
            ),
            recommendation="Block C2 server IP/domain. Investigate affected systems. Review network traffic patterns.",
            risk_score=9.5,
            evidence_preview=preview,
        )
