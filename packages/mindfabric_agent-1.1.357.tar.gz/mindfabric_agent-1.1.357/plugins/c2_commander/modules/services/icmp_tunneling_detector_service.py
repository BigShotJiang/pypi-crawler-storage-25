"""
ICMP Tunneling C2 Detector Service

Detects ICMP tunneling-based C2 communication.
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import List, Optional

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    ICMPTunnelingFinding,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreAttackReference,
    MitreTactic,
    MitreTechnique,
)

logger = logging.getLogger(__name__)


class ICMPTunnelingDetectorService:
    """Service for detecting ICMP tunneling C2 communication."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
    
    async def detect(self, target: Optional[ScanTarget] = None) -> List[ICMPTunnelingFinding]:
        """
        Detect ICMP tunneling C2 communication.
        
        Args:
            target: Scan target configuration
            
        Returns:
            List of ICMP tunneling findings
        """
        findings = []
        
        try:
            import psutil
            from collections import defaultdict
            from datetime import datetime, timezone
            from utils.async_subprocess import run_exec
            import platform
            
            # ICMP traffic is harder to detect via psutil, but we can check:
            # 1. Process network statistics
            # 2. Network interface statistics for ICMP packets
            # 3. System ping activity
            
            # Track processes with unusual network activity
            process_stats = defaultdict(lambda: {
                'connections': 0,
                'last_seen': None,
            })
            
            try:
                # Check network interface statistics for ICMP activity
                interfaces = psutil.net_if_stats()
                io_counters = psutil.net_io_counters(pernic=True)
                
                for iface_name, stats in interfaces.items():
                    if iface_name in io_counters:
                        io = io_counters[iface_name]
                        # High packet count with low byte count might indicate ICMP tunneling
                        if io.packets_sent > 1000 and io.bytes_sent < io.packets_sent * 100:
                            # Suspicious pattern: many small packets (potential ICMP tunneling)
                            logger.debug(f"Suspicious network pattern on {iface_name}: {io.packets_sent} packets, {io.bytes_sent} bytes")
                
                # Check for ping processes (potential ICMP tunneling)
                system = platform.system().lower()
                for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                    try:
                        proc_info = proc.info
                        proc_name = proc_info.get('name', '').lower()
                        cmdline = ' '.join(proc_info.get('cmdline', [])).lower()
                        
                        # Check for ping or ICMP-related processes
                        if 'ping' in proc_name or 'ping' in cmdline:
                            # Check if it's running continuously (potential tunneling)
                            try:
                                proc_obj = psutil.Process(proc_info['pid'])
                                create_time = datetime.fromtimestamp(proc_obj.create_time(), tz=timezone.utc).replace(tzinfo=None)
                                now = datetime.now(timezone.utc).replace(tzinfo=None)
                                uptime = (now - create_time).total_seconds()
                                
                                # Long-running ping is weak signal for tunneling (monitoring, stuck scripts, VPN diagnostics).
                        # Do not emit HIGH-severity ICMP tunnel findings without PCAP/byte ratios (avoids "local-process-indicator" FP).
                                if uptime > 300:  # 5 minutes
                                    logger.debug(
                                        "ICMP detector: long-running ping pid=%s uptime≈%.0fs — ignored (insufficient tunnel evidence)",
                                        proc_info.get("pid"),
                                        uptime,
                                    )
                            except (psutil.NoSuchProcess, psutil.AccessDenied):
                                pass
                                
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                
            except Exception as e:
                logger.debug(f"Error analyzing ICMP connections: {e}")
            
            logger.info(f"ICMP tunneling C2 detection completed: {len(findings)} findings")
            
        except ImportError:
            logger.warning("psutil not available, ICMP tunneling detection limited")
        except Exception as e:
            logger.error(f"ICMP tunneling detection failed: {e}", exc_info=True)
        
        return findings
    
    def _create_finding(
        self,
        c2_server: Optional[str] = None,
        packet_size: Optional[int] = None,
        data_volume: Optional[int] = None,
        evidence_preview: Optional[List[str]] = None,
    ) -> ICMPTunnelingFinding:
        """Create an ICMP tunneling finding."""
        label = c2_server or "insufficient-evidence"
        preview = evidence_preview or [
            "Source: host process/network heuristics (no ICMP capture).",
            f"Declared peer: {c2_server or 'unknown'}",
        ]
        desc_peer = c2_server if c2_server else "an undetermined remote peer (requires PCAP or iface counters)"
        return ICMPTunnelingFinding(
            id=str(uuid.uuid4()),
            severity=SeverityLevel.HIGH,
            confidence=ConfidenceLevel.MEDIUM,
            title=f"ICMP tunneling indicator: {label}",
            description=(
                f"Possible ICMP tunneling. Remote context: {desc_peer}. "
                "Confirm with PCAP, packet sizes, or interface ICMP stats — psutil alone cannot prove tunneling."
            ),
            c2_server=c2_server,
            packet_size=packet_size,
            data_volume=data_volume,
            first_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            mitre_attack=MitreAttackReference(
                tactic=MitreTactic.COMMAND_AND_CONTROL,
                technique_id="T1095",
                technique_name="Non-Application Layer Protocol",
            ),
            recommendation="Block ICMP traffic to external hosts if not needed. Monitor ICMP packet sizes and patterns.",
            risk_score=8.0,
            evidence_preview=preview,
        )
