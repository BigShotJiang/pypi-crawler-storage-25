"""
Domain Fronting Detector Service

Detects domain fronting C2 communication.
Enriches findings with process, socket, protocol, DNS, volume/pattern, and path-trust context.
"""

import ipaddress
import logging
import socket as socket_mod
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import sys
from pathlib import Path as PathLib

sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from ...proto import (
    DomainFrontingFinding,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreAttackReference,
    MitreTactic,
)

logger = logging.getLogger(__name__)

# Common anycast CDN IPv4 ranges (heuristic label only — confirm with ASN/WHOIS).
_CLOUDFLARE_HINT_NETS = (
    ipaddress.ip_network("104.16.0.0/12"),
    ipaddress.ip_network("172.64.0.0/13"),
    ipaddress.ip_network("198.41.128.0/17"),
)

# Known public HTTPS edge / CDN-style ranges (Google, AWS CloudFront sample blocks, Azure Front Door / Microsoft).
# Many services (browsers, agents, GCP APIs) legitimately open many parallel TLS connections here — not C2 by SNI gap alone.
_PUBLIC_EDGE_HTTPS_NETS: Tuple[ipaddress.IPv4Network, ...] = (
    # Cloudflare (overlap with above; included for one-shot checks)
    ipaddress.ip_network("104.16.0.0/12"),
    ipaddress.ip_network("172.64.0.0/13"),
    ipaddress.ip_network("198.41.128.0/17"),
    # Google / GCP egress-style IPv4 (user-facing HTTPS, APIs; not exhaustive)
    ipaddress.ip_network("64.233.160.0/19"),
    ipaddress.ip_network("66.102.0.0/20"),
    ipaddress.ip_network("72.14.192.0/18"),
    ipaddress.ip_network("74.125.0.0/16"),
    ipaddress.ip_network("108.177.8.0/21"),
    ipaddress.ip_network("142.250.0.0/15"),
    ipaddress.ip_network("172.217.0.0/16"),
    ipaddress.ip_network("173.194.0.0/16"),
    ipaddress.ip_network("209.85.128.0/17"),
    ipaddress.ip_network("216.58.192.0/19"),
    ipaddress.ip_network("216.239.32.0/19"),
    # Additional Google / GCP edge (seen on live hosts; complements narrower /21 blocks above)
    ipaddress.ip_network("108.177.0.0/16"),
    ipaddress.ip_network("192.178.0.0/15"),
    # AWS CloudFront / edge (published ranges change; representative / coarse blocks)
    ipaddress.ip_network("13.32.0.0/15"),
    ipaddress.ip_network("13.224.0.0/14"),
    ipaddress.ip_network("18.64.0.0/14"),
    ipaddress.ip_network("52.84.0.0/14"),
    ipaddress.ip_network("54.230.0.0/15"),
    ipaddress.ip_network("143.204.0.0/16"),
    # Azure Front Door / Microsoft edge (sample)
    ipaddress.ip_network("13.107.42.0/24"),
    ipaddress.ip_network("13.107.128.0/22"),
    ipaddress.ip_network("20.190.128.0/18"),
)


def _psutil_tls_label_is_self_peer_ip_noise(remote_ip: str) -> bool:
    """
    The psutil-only pipeline synthesizes ``front_domain=tls-<ip>`` with ``actual_c2_domain=<ip>``.

    That is **not** observable domain fronting (no distinct TLS SNI vs HTTP Host vs routing hop).
    Suppress these rows entirely — real fronting needs proxy/PCAP/JA3 correlation, not socket tables.
    """
    try:
        ipaddress.ip_address((remote_ip or "").strip())
    except ValueError:
        return False
    return True


def _public_edge_https_label(remote_ip: str) -> Optional[str]:
    """If peer is in a known public CDN / cloud HTTPS edge range, return a short label; else None."""
    try:
        addr = ipaddress.ip_address(remote_ip)
    except ValueError:
        return None
    if addr.version != 4:
        return None
    for net in _PUBLIC_EDGE_HTTPS_NETS:
        try:
            if addr in net:
                return f"public_edge:{net}"
        except Exception:
            continue
    return None


def _guess_cdn_provider(remote_ip: str) -> Optional[str]:
    try:
        addr = ipaddress.ip_address(remote_ip)
    except ValueError:
        return None
    if addr.version != 4:
        return None
    for net in _CLOUDFLARE_HINT_NETS:
        if addr in net:
            return "Cloudflare (heuristic — IP in common anycast range; verify ASN)"
    pl = _public_edge_https_label(str(remote_ip))
    if pl:
        if pl.startswith("public_edge:"):
            return "Public CDN / cloud HTTPS edge (heuristic IP range; likely benign without SNI/Correlation)"
    return None


def _reverse_ptr(ip: str) -> Tuple[Optional[str], Optional[str]]:
    try:
        host, _, _ = socket.gethostbyaddr(ip)
        return host, None
    except Exception as ex:
        return None, str(ex)[:160]


def _trust_assessment(exe: Optional[str]) -> str:
    if not exe:
        return "Executable path unknown — verify pid with ps/lsof and inspect binary."
    el = exe.lower()
    if any(el.startswith(p) for p in ("/usr/bin/", "/usr/sbin/", "/bin/", "/sbin/")):
        return "Binary under standard OS paths — often legitimate; confirm this process should egress HTTPS to the peer."
    if "/tmp/" in el or "/var/tmp/" in el or "/dev/shm/" in el:
        return "Executable under temp/shm path — higher suspicion; verify origin and signature."
    if ".local/share" in el or "Downloads" in exe:
        return "User-writable location — review whether network use is expected."
    return "Outside standard system dirs — review vendor, signature, and deployment intent."


def _enrich_process(pid: Optional[int]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if pid is None:
        return out
    try:
        import psutil

        p = psutil.Process(pid)
        out["source_process_exe"] = p.exe()
        try:
            out["source_username"] = p.username()
        except Exception:
            out["source_username"] = None
        try:
            cmd = p.cmdline() or []
            out["process_cmdline_preview"] = " ".join(cmd)[:600]
        except Exception:
            pass
        out["source_process_name"] = p.name()
        chain: List[str] = []
        cur = p
        for _ in range(8):
            try:
                chain.append(f"pid={cur.pid} {cur.name()}")
                cur = cur.parent()
            except Exception:
                break
        out["parent_process_chain"] = " <- ".join(chain)
        try:
            io = p.io_counters()
            out["process_io_read_bytes_total"] = io.read_bytes
            out["process_io_write_bytes_total"] = io.write_bytes
            out["process_io_note"] = "Whole-process I/O totals (not per-socket) — use for coarse volume context."
        except Exception:
            pass
    except Exception as ex:
        out["process_enrichment_error"] = str(ex)[:200]
    return out


class DomainFrontingDetectorService:
    """Service for detecting domain fronting C2 communication."""

    def __init__(self, plugin_instance):
        self.plugin = plugin_instance

    async def detect(self, target: Optional[ScanTarget] = None) -> List[DomainFrontingFinding]:
        findings: List[DomainFrontingFinding] = []
        try:
            import psutil

            # peer_key -> list of sample dicts
            samples_by_peer: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
            now = datetime.now(timezone.utc).replace(tzinfo=None)

            try:
                connections = psutil.net_connections(kind="inet")
            except Exception as e:
                logger.debug(f"net_connections failed: {e}")
                connections = []

            for conn in connections:
                try:
                    if not conn.raddr:
                        continue
                    remote_ip = conn.raddr.ip
                    remote_port = conn.raddr.port
                    if remote_port != 443:
                        continue
                    is_tcp = False
                    try:
                        ct = conn.type
                        if ct == socket_mod.SOCK_STREAM:
                            is_tcp = True
                        else:
                            try:
                                if int(ct) == int(socket_mod.SOCK_STREAM):
                                    is_tcp = True
                            except (TypeError, ValueError):
                                conn_type = str(ct).lower()
                                if "tcp" in conn_type or conn_type in ("1", "sock_stream"):
                                    is_tcp = True
                    except (AttributeError, TypeError):
                        is_tcp = True
                    if not is_tcp:
                        continue

                    local_ip = conn.laddr.ip if conn.laddr else None
                    local_port = conn.laddr.port if conn.laddr else None
                    st = str(getattr(conn, "status", "") or "") or "UNKNOWN"
                    key = f"{remote_ip}:{remote_port}"
                    samples_by_peer[key].append(
                        {
                            "ts": now,
                            "pid": conn.pid,
                            "local_ip": str(local_ip) if local_ip is not None else None,
                            "local_port": local_port,
                            "status": st,
                        }
                    )
                except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                    continue

            for peer_key, samples in samples_by_peer.items():
                if len(samples) < 5:
                    continue
                remote_ip = peer_key.rsplit(":", 1)[0]
                if _psutil_tls_label_is_self_peer_ip_noise(remote_ip):
                    logger.info(
                        "Domain fronting: skipping synthetic tls-%s -> %s (no SNI/host mismatch observable from sockets).",
                        remote_ip,
                        remote_ip,
                    )
                    continue
                # Many parallel HTTPS connections to Google/AWS/Azure/CDN edge IPs are common (browsers, SDKs, agents).
                # Without TLS SNI vs HTTP Host vs threat intel, this psutil-only heuristic is a strong FP as "C2 domain fronting".
                if _public_edge_https_label(remote_ip):
                    logger.info(
                        "Domain fronting: skipping peer %s (public CDN/cloud HTTPS edge range; "
                        "correlate with PCAP/proxy/JA3 before treating as domain-fronting C2).",
                        remote_ip,
                    )
                    continue
                # Representative pid: last sample with pid
                pid = None
                for s in reversed(samples):
                    if s.get("pid"):
                        pid = s["pid"]
                        break
                last = samples[-1]
                proc_name = None
                if pid:
                    try:
                        proc_name = psutil.Process(pid).name()
                    except Exception:
                        pass

                telemetry = self._build_telemetry_details(
                    remote_ip=remote_ip,
                    remote_port=443,
                    samples=samples,
                    pid=pid,
                    proc_name=proc_name,
                    local_ip=last.get("local_ip"),
                    local_port=last.get("local_port"),
                )
                finding = self._create_finding(
                    front_domain=f"tls-{remote_ip}",
                    actual_c2_domain=str(remote_ip),
                    cdn_provider=_guess_cdn_provider(str(remote_ip)),
                    proc_name=proc_name,
                    proc_pid=pid,
                    conn_status=last.get("status"),
                    local_port=last.get("local_port"),
                    local_ip=last.get("local_ip"),
                    https_sample_count=len(samples),
                    telemetry_details=telemetry,
                )
                findings.append(finding)
                logger.warning(
                    f"Multiple HTTPS connections to {remote_ip}:443 (potential domain fronting), samples={len(samples)}"
                )

            logger.info(f"Domain fronting detection completed: {len(findings)} findings")

        except ImportError:
            logger.warning("psutil not available, domain fronting detection limited")
        except Exception as e:
            logger.error(f"Domain fronting detection failed: {e}", exc_info=True)

        return findings

    def _build_telemetry_details(
        self,
        *,
        remote_ip: str,
        remote_port: int,
        samples: List[Dict[str, Any]],
        pid: Optional[int],
        proc_name: Optional[str],
        local_ip: Optional[str],
        local_port: Optional[int],
    ) -> Dict[str, Any]:
        """Six buckets: process, socket, protocol, DNS, pattern/volume, trust."""
        statuses = Counter(s.get("status") or "?" for s in samples)
        pids_seen = sorted({s.get("pid") for s in samples if s.get("pid")})
        tss = [s.get("ts") for s in samples if s.get("ts")]
        span_s: Optional[float] = None
        if len(tss) >= 2:
            try:
                span_s = (max(tss) - min(tss)).total_seconds()
            except Exception:
                span_s = None
        snapshot_note = (
            "Samples are from one psutil.net_connections() snapshot — timestamps may be identical; "
            "span≈0 does not disprove periodic beaconing between scans."
            if span_s == 0 or span_s is None
            else None
        )

        ptr, ptr_err = _reverse_ptr(remote_ip)
        proc_blob = _enrich_process(pid)
        exe = proc_blob.get("source_process_exe")
        trust = _trust_assessment(exe if isinstance(exe, str) else None)

        return {
            "1_process": {
                "pid": pid,
                "name": proc_name or proc_blob.get("source_process_name"),
                "exe": proc_blob.get("source_process_exe"),
                "username": proc_blob.get("source_username"),
                "cmdline_preview": proc_blob.get("process_cmdline_preview"),
                "parent_chain": proc_blob.get("parent_process_chain"),
                "process_io": {
                    "read_bytes_total": proc_blob.get("process_io_read_bytes_total"),
                    "write_bytes_total": proc_blob.get("process_io_write_bytes_total"),
                    "note": proc_blob.get("process_io_note"),
                },
                "enrichment_error": proc_blob.get("process_enrichment_error"),
            },
            "2_local_socket": {
                "local_ip": local_ip,
                "local_port": local_port,
                "remote_ip": remote_ip,
                "remote_port": remote_port,
            },
            "3_protocol": {
                "layer4": "tcp",
                "application": "https_tls",
                "sni_from_socket_table": False,
                "http_host_from_socket_table": False,
                "note": "True domain-fronting verdict needs TLS SNI vs HTTP Host vs routing (pcap or TLS termination logs).",
            },
            "4_dns": {
                "reverse_ptr": ptr,
                "reverse_ptr_error": ptr_err,
                "note": "Forward DNS for apps using IP literals may be empty; correlate with proxy and resolver logs.",
            },
            "5_pattern_volume": {
                "connection_samples_in_scan": len(samples),
                "tcp_state_counts": dict(statuses),
                "distinct_pids_in_samples": pids_seen,
                "batch_time_span_seconds": span_s,
                "note": "Counts reflect rows in one snapshot (same peer:port may repeat per socket state). "
                "Not byte-level volume; use per-process io_counters as coarse process-wide I/O.",
                "snapshot_timing_note": snapshot_note,
            },
            "6_trust_and_expectations": {
                "assessment": trust,
                "exe_path_evaluated": exe,
            },
        }

    def _create_finding(
        self,
        front_domain: str,
        actual_c2_domain: str,
        cdn_provider: Optional[str] = None,
        proc_name: Optional[str] = None,
        proc_pid: Optional[int] = None,
        conn_status: Optional[str] = None,
        local_port: Optional[int] = None,
        local_ip: Optional[str] = None,
        https_sample_count: int = 0,
        telemetry_details: Optional[Dict[str, Any]] = None,
    ) -> DomainFrontingFinding:
        """Create a domain fronting finding."""
        td = telemetry_details or {}
        preview = [
            "Source: psutil — many HTTPS:443 samples to same peer (weak domain-fronting proxy signal).",
            f"TLS peer: {actual_c2_domain}:443",
            f"Synthetic front label: {front_domain} (SNI/Host not available from socket table)",
        ]
        if local_ip or local_port:
            preview.append(
                f"Local endpoint: {local_ip or '?'}:{local_port if local_port is not None else '?'}"
            )
        if conn_status:
            preview.append(f"Example TCP status: {conn_status}")
        if proc_pid is not None or (proc_name and proc_name.strip()):
            preview.append(f"Process: pid={proc_pid if proc_pid is not None else '?'} name={proc_name or 'unknown'}")
        pex = (td.get("1_process") or {}).get("exe")
        if pex:
            preview.append(f"Executable: {pex}")
        usr = (td.get("1_process") or {}).get("username")
        if usr:
            preview.append(f"OS user: {usr}")
        ptr = (td.get("4_dns") or {}).get("reverse_ptr")
        if ptr:
            preview.append(f"Reverse DNS (PTR): {ptr}")
        pv = td.get("5_pattern_volume") or {}
        if pv.get("tcp_state_counts"):
            preview.append(f"TCP state mix: {pv['tcp_state_counts']}")
        if pv.get("distinct_pids_in_samples"):
            preview.append(f"PIDs seen in samples: {pv['distinct_pids_in_samples']}")
        tr = (td.get("6_trust_and_expectations") or {}).get("assessment")
        if tr:
            preview.append(f"Path trust heuristic: {tr}")
        preview.append(f"Repeated samples in scan window: {https_sample_count}")
        preview.append("Confirm with: openssl/s_client SNI tests, pcap, or proxy logs — not socket table alone.")

        return DomainFrontingFinding(
            id=str(uuid.uuid4()),
            severity=SeverityLevel.CRITICAL,
            confidence=ConfidenceLevel.MEDIUM,
            title=f"Domain Fronting C2 detected: {front_domain} -> {actual_c2_domain}",
            description=(
                f"Domain fronting C2 communication suspected. Front label: {front_domain}, peer: {actual_c2_domain}. "
                f"CDN hint: {cdn_provider or 'Unknown'}. Enriched telemetry is in evidence.telemetry_details."
            ),
            front_domain=front_domain,
            actual_c2_domain=actual_c2_domain,
            cdn_provider=cdn_provider,
            c2_port=443,
            source_pid=proc_pid,
            source_process=proc_name,
            local_port=local_port,
            telemetry_details=td,
            first_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
            mitre_attack=MitreAttackReference(
                tactic=MitreTactic.COMMAND_AND_CONTROL,
                technique_id="T1090",
                technique_name="Proxy",
                sub_technique_id="T1090.004",
                sub_technique_name="Domain Fronting",
            ),
            recommendation=(
                "Block domain fronting at the network edge where possible; correlate TLS SNI and HTTP Host. "
                "Use process exe/cmdline and PTR to rule out benign agents before incident escalation."
            ),
            risk_score=9.5,
            evidence_preview=preview,
        )
