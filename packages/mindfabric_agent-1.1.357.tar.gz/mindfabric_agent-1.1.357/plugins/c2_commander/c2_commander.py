"""
C2 Commander Plugin

Comprehensive Command & Control (C2) detection and analysis.
Detects various C2 communication patterns and techniques.
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .proto import (
    C2Type,
    ProtocolType,
    C2CommanderOutput,
    C2Finding,
    HTTPC2Finding,
    DNSTunnelingFinding,
    ICMPTunnelingFinding,
    WebSocketC2Finding,
    DomainFrontingFinding,
    ScanOptions,
    ScanTarget,
    SeverityLevel,
    ConfidenceLevel,
    MitreTactic,
    MitreTechnique,
    MitreAttackReference,
)

from plugins.base_plugin import BasePlugin

from .modules.services import (
    HTTPC2DetectorService,
    DNSTunnelingDetectorService,
    ICMPTunnelingDetectorService,
    WebSocketC2DetectorService,
    DomainFrontingDetectorService,
)

logger = logging.getLogger(__name__)


class C2CommanderPlugin(BasePlugin):
    """
    C2 Commander Detection Plugin.
    
    Detects various Command & Control communication patterns including:
    - HTTP/HTTPS C2
    - DNS tunneling
    - ICMP tunneling
    - WebSocket C2
    - Domain fronting
    - CDN-based C2
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
        # Initialize services
        self.http_c2_detector = HTTPC2DetectorService(self)
        self.dns_tunneling_detector = DNSTunnelingDetectorService(self)
        self.icmp_tunneling_detector = ICMPTunnelingDetectorService(self)
        self.websocket_c2_detector = WebSocketC2DetectorService(self)
        self.domain_fronting_detector = DomainFrontingDetectorService(self)
        
        # Results
        self.findings: List[C2Finding] = []
        self.http_c2_findings: List[HTTPC2Finding] = []
        self.dns_tunneling_findings: List[DNSTunnelingFinding] = []
        self.icmp_tunneling_findings: List[ICMPTunnelingFinding] = []
        self.websocket_c2_findings: List[WebSocketC2Finding] = []
        self.domain_fronting_findings: List[DomainFrontingFinding] = []
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket."""
        if self.ws:
            try:
                await self.ws.send_json({
                    "type": "progress",
                    "command_id": self.command_id,
                    "percent": percent,
                    "message": message
                })
            except Exception:
                pass
        logger.debug(f"Progress: {percent}% - {message}")
    
    async def run(self):
        """Main entry point."""
        import sys
        import traceback
        try:
            logger.info("[c2_commander] run() method called")
            sys.stderr.write("[c2_commander] run() method called\n")
            sys.stderr.flush()
            
            from .proto import ScanOptions, ScanTarget
            
            logger.info("[c2_commander] Importing proto models")
            sys.stderr.write("[c2_commander] Importing proto models\n")
            sys.stderr.flush()
            
            # Create target with default settings
            target = ScanTarget()
            logger.info(f"[c2_commander] Created ScanTarget: {target}")
            sys.stderr.write(f"[c2_commander] Created ScanTarget\n")
            sys.stderr.flush()
            
            # Create options with all detections enabled by default
            options = ScanOptions(
                target=target,
                detect_http_c2=True,
                detect_dns_tunneling=True,
                detect_icmp_tunneling=True,
                detect_websocket_c2=True,
                detect_domain_fronting=True,
            )
            logger.info(f"[c2_commander] Created ScanOptions: detect_http_c2={options.detect_http_c2}")
            sys.stderr.write(f"[c2_commander] Created ScanOptions\n")
            sys.stderr.flush()
            
            logger.info("[c2_commander] Calling hook_c2_scan()")
            sys.stderr.write("[c2_commander] Calling hook_c2_scan()\n")
            sys.stderr.flush()
            
            result = await self.hook_c2_scan(options)
            
            logger.info(f"[c2_commander] hook_c2_scan() completed, result type: {type(result)}")
            sys.stderr.write(f"[c2_commander] hook_c2_scan() completed\n")
            sys.stderr.flush()
            
            logger.info("[c2_commander] Calling _with_canonical_findings()")
            sys.stderr.write("[c2_commander] Calling _with_canonical_findings()\n")
            sys.stderr.flush()
            
            canonical = self._with_canonical_findings(result)
            
            logger.info("[c2_commander] Calling to_security_scan_v1()")
            sys.stderr.write("[c2_commander] Calling to_security_scan_v1()\n")
            sys.stderr.flush()
            
            final_result = self.to_security_scan_v1(canonical)
            
            logger.info(f"[c2_commander] run() completed successfully, result keys: {list(final_result.keys()) if isinstance(final_result, dict) else 'N/A'}")
            sys.stderr.write(f"[c2_commander] run() completed successfully\n")
            sys.stderr.flush()
            
            return final_result
        except Exception as e:
            error_msg = f"[c2_commander] ERROR in run(): {e}\n{traceback.format_exc()}"
            logger.error(error_msg)
            sys.stderr.write(error_msg + "\n")
            sys.stderr.flush()
            raise
    
    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """Add plugin-owned findings for canonical security_scan v1."""
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}
        
        # Convert findings to canonical format with rich metadata for Threat UI.
        findings = []
        for finding in self.findings:
            details = {
                "c2_server": finding.c2_server,
                "c2_port": finding.c2_port,
                "protocol": finding.protocol.value if finding.protocol else None,
                **finding.details,
            }
            c2_type = finding.c2_type.value
            mitre_id = finding.mitre_attack.sub_technique_id or finding.mitre_attack.technique_id
            confidence = finding.confidence.value if hasattr(finding.confidence, "value") else str(finding.confidence)
            severity = finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
            first_seen = finding.first_seen.isoformat() if hasattr(finding.first_seen, "isoformat") else str(finding.first_seen)
            last_seen = finding.last_seen.isoformat() if hasattr(finding.last_seen, "isoformat") else str(finding.last_seen)
            c2_server = finding.c2_server or "unknown endpoint"
            c2_port = finding.c2_port if finding.c2_port is not None else "n/a"
            c2_server_ip = None
            c2_server_host = None
            if isinstance(finding.c2_server, str) and finding.c2_server.strip():
                try:
                    import re
                    ip_match = re.search(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", finding.c2_server)
                    if ip_match:
                        c2_server_ip = ip_match.group(1)
                    else:
                        from urllib.parse import urlparse

                        parsed = urlparse(finding.c2_server)
                        c2_server_host = parsed.hostname or finding.c2_server
                except Exception:
                    c2_server_host = finding.c2_server

            ev_preview = [str(x) for x in (getattr(finding, "evidence_preview", None) or []) if str(x).strip()]

            c2_recommendations: List[Dict[str, str]] = []
            _rec_text = str(getattr(finding, "recommendation", "") or "").strip()
            if _rec_text:
                c2_recommendations.append(
                    {
                        "title": "Detector guidance",
                        "description": _rec_text,
                        "priority": "high",
                    }
                )
            c2_recommendations.extend(
                [
                    {
                        "title": f"Correlate `{c2_type}` channel to {c2_server}:{c2_port}",
                        "description": (
                            "Join process/socket ownership, DNS queries, proxy logs, and firewall flow data for the same timeframe; "
                            "confirm whether userland malware or a legitimate agent owns the session."
                        ),
                        "priority": "high",
                    },
                    {
                        "title": "Contain persistent beaconing",
                        "description": (
                            f"If connections to {c2_server}:{c2_port} continue after policy review, block the destination at egress "
                            "and isolate the host after evidence capture."
                        ),
                        "priority": "medium",
                    },
                ]
            )

            findings.append({
                "id": finding.id,
                "title": finding.title,
                "description": (
                    f"{finding.description}\n\n"
                    f"C2 channel: {c2_type}. Endpoint: {c2_server}:{c2_port}. "
                    f"Severity={severity}, confidence={confidence}, MITRE={mitre_id}."
                ),
                "severity": severity,
                "category": "Command & Control",
                "threat_type": c2_type,
                "sub_category": c2_type,
                "mitre_technique": finding.mitre_attack.technique_id,
                "risk_score": finding.risk_score,
                "impact": (
                    f"Potential active C2 communication path detected for {c2_type}. "
                    f"This can enable remote tasking, payload delivery, and data exfiltration."
                ),
                "detection_reason": finding.description,
                "detection_location": "Network telemetry (socket/process communication patterns)",
                "target_ip": c2_server_ip,
                "target_dns": c2_server_host,
                "direction": "outbound",
                "affected_resources": (
                    [{"type": "c2_endpoint", "address": finding.c2_server.strip()[:2000]}]
                    if isinstance(finding.c2_server, str) and finding.c2_server.strip()
                    else []
                ),
                "recommendations": c2_recommendations,
                "exploitation_commands": self._build_exploitation_commands(c2_type, details),
                "evidence": {
                    "c2_type": c2_type,
                    "c2_server": finding.c2_server,
                    "c2_port": finding.c2_port,
                    "target_ip": c2_server_ip,
                    "target_dns": c2_server_host,
                    "direction": "outbound",
                    "protocol": finding.protocol.value if finding.protocol else None,
                    "confidence": confidence,
                    "risk_score": finding.risk_score,
                    "first_seen": first_seen,
                    "last_seen": last_seen,
                    "mitre_technique": finding.mitre_attack.technique_id,
                    "mitre_sub_technique": finding.mitre_attack.sub_technique_id,
                    "details": details,
                    "context_lines": ev_preview,
                    "telemetry_style": True,
                },
                "details": details,
            })
        
        out["findings"] = findings
        return out

    def _build_exploitation_commands(self, c2_type: str, details: Dict[str, Any]) -> List[str]:
        """Provide operator commands for triage/reproduction in UI."""
        c2_server = str(details.get("c2_server") or "").strip()
        c2_port = details.get("c2_port")
        domain = str(details.get("domain") or "").strip() or c2_server

        if c2_type in ("http_c2", "https_c2"):
            port = c2_port if c2_port is not None else 443
            if c2_server:
                return [
                    f"curl -vk --connect-timeout 5 https://{c2_server}:{port}/",
                    f"tcpdump -nn -vv host {c2_server} and '(tcp port 80 or tcp port 443 or tcp port {port})' -c 200",
                    "grep -Ei 'curl|wget|python|nc|socat' /var/log/auth.log /var/log/syslog 2>/dev/null | tail -80",
                ]
            return [
                "ss -ntup",
                "tcpdump -nn -vv 'tcp port 80 or tcp port 443' -c 200",
                "grep -Ei 'curl|wget|python|nc|socat' /var/log/auth.log /var/log/syslog 2>/dev/null | tail -80",
            ]
        if c2_type == "dns_tunneling":
            dcmd = f"dig +short {domain}" if domain else "dig +short cloudflare.com"
            if c2_server:
                return [
                    dcmd,
                    f"tcpdump -nn -vv host {c2_server} and '(udp port 53 or tcp port 53)' -c 200",
                    "grep -Ei 'named|dns|resolver' /var/log/syslog 2>/dev/null | tail -80",
                ]
            return [
                dcmd,
                "tcpdump -nn -vv 'udp port 53 or tcp port 53' -c 200",
                "grep -Ei 'named|dns|resolver' /var/log/syslog 2>/dev/null | tail -80",
            ]
        if c2_type == "icmp_tunneling":
            if c2_server:
                return [
                    f"ping -c 5 {c2_server}",
                    f"tcpdump -nn -vv host {c2_server} and icmp -c 200",
                    "ps aux | grep -Ei 'ping|ptunnel|icmp' | grep -v grep",
                ]
            return [
                "tcpdump -nn -vv icmp -c 200",
                "ps aux | grep -Ei 'ping|ptunnel|icmp' | grep -v grep",
            ]
        if c2_type == "websocket_c2":
            port = c2_port if c2_port is not None else 443
            if c2_server:
                return [
                    f"tcpdump -nn -vv host {c2_server} and tcp port {port} -c 200",
                    f"curl -vk -H 'Connection: Upgrade' -H 'Upgrade: websocket' https://{c2_server}:{port}/",
                    "ss -ntp | grep -E 'ESTAB|:443|:8080|:8443'",
                ]
            return [
                f"tcpdump -nn -vv tcp port {port} -c 200",
                "ss -ntp | grep -E 'ESTAB|:443|:8080|:8443'",
            ]
        if c2_type == "domain_fronting":
            port = int(c2_port) if c2_port is not None else 443
            front = str(details.get("front_domain") or "").strip()
            spid = details.get("source_pid")
            proc = str(details.get("source_process") or "").strip()
            td = details.get("telemetry_details") if isinstance(details.get("telemetry_details"), dict) else {}
            sock = td.get("2_local_socket") if isinstance(td.get("2_local_socket"), dict) else {}
            local_ip = str(sock.get("local_ip") or "").strip()
            cmds: List[str] = [
                "# Domain fronting / proxy (T1090.004) triage — compare TLS SNI, cert CN/SAN, and HTTP Host to routing",
            ]
            if local_ip:
                cmds.append(f"# Local endpoint (from scan): {local_ip} -> {c2_server}:{port}")
            if c2_server:
                cmds.extend(
                    [
                        f"openssl s_client -connect {c2_server}:{port} -servername {c2_server} </dev/null 2>/dev/null | openssl x509 -noout -subject -issuer -dates -ext subjectAltName 2>/dev/null || true",
                        f"# Optional: force a different SNI (front) vs peer IP — replace FRONT_DOMAIN",
                        f"# openssl s_client -connect {c2_server}:{port} -servername FRONT_DOMAIN </dev/null 2>/dev/null | head -60",
                        f"ss -ntp state established dst {c2_server} :{port} 2>/dev/null || ss -ntp | grep -F '{c2_server}:{port}' | head -n 20",
                        f"tcpdump -nn -vv host {c2_server} and tcp port {port} -c 200",
                    ]
                )
            else:
                cmds.extend(
                    [
                        f"tcpdump -nn -vv tcp port {port} -c 200",
                        "ss -ntp | grep -E 'ESTAB|:443' | head -n 40",
                    ]
                )
            if spid is not None:
                try:
                    pid_s = str(int(spid))
                    cmds.append(f"# Owning process from scan: pid={pid_s} ({proc or 'unknown'})")
                    cmds.append(f"ps -p {pid_s} -o pid,ppid,user,etime,cmd 2>/dev/null || true")
                    cmds.append(f"tr '\\0' ' ' </proc/{pid_s}/cmdline 2>/dev/null; echo")
                    cmds.append(f"readlink /proc/{pid_s}/exe 2>/dev/null || true")
                    cmds.append(f"command -v lsof >/dev/null && lsof -p {pid_s} 2>/dev/null | head -n 50 || true")
                except (TypeError, ValueError):
                    pass
            if front:
                cmds.append(f"# Synthetic front label from detector: {front}")
            cmds.append(
                "grep -Ei 'sni|host:|front' /var/log/nginx/access.log /var/log/nginx/error.log 2>/dev/null | tail -80 || true"
            )
            return cmds
        return [
            "ss -ntup",
            "tcpdump -nn -c 200",
        ]
    
    async def hook_c2_scan(
        self,
        options: ScanOptions
    ) -> C2CommanderOutput:
        """
        Main entry point for C2 detection.
        
        Args:
            options: Scan configuration options
            
        Returns:
            C2CommanderOutput with all findings
        """
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.now(timezone.utc).replace(tzinfo=None)
        self.findings = []
        self.http_c2_findings = []
        self.dns_tunneling_findings = []
        self.icmp_tunneling_findings = []
        self.websocket_c2_findings = []
        self.domain_fronting_findings = []
        self.errors = []
        self.warnings = []
        
        await self._handle_progress(0, "Starting C2 communication detection")
        logger.info(f"[c2_commander] Starting scan, scan_id={self.scan_id}")
        import sys
        sys.stderr.flush()  # Force flush to ensure logs are visible
        
        # HTTP/HTTPS C2 Detection
        if options.detect_http_c2:
            await self._handle_progress(20, "Detecting HTTP/HTTPS C2 communication")
            logger.info("[c2_commander] Starting HTTP/HTTPS C2 detection")
            sys.stderr.write("[c2_commander] VECTOR_START: HTTP/HTTPS C2\n")
            sys.stderr.flush()
            try:
                http_findings = await self.http_c2_detector.detect(options.target)
                logger.info(f"[c2_commander] HTTP/HTTPS C2 detection completed: {len(http_findings)} findings")
                sys.stderr.write(f"[c2_commander] VECTOR_DONE: HTTP/HTTPS C2 findings={len(http_findings)}\n")
                sys.stderr.flush()
                self.http_c2_findings.extend(http_findings)
                self.findings.extend([
                    C2Finding(
                        id=f.id,
                        c2_type=f.c2_type,
                        severity=f.severity,
                        confidence=f.confidence,
                        title=f.title,
                        description=f.description,
                        c2_server=f.c2_server,
                        c2_port=f.c2_port,
                        protocol=f.protocol,
                        details={
                            "user_agent": f.user_agent,
                            "http_method": f.http_method,
                            "uri_pattern": f.uri_pattern,
                            "beacon_interval": f.beacon_interval,
                        },
                        first_seen=f.first_seen,
                        last_seen=f.last_seen,
                        mitre_attack=f.mitre_attack,
                        recommendation=f.recommendation,
                        risk_score=f.risk_score,
                        evidence_preview=list(f.evidence_preview or []),
                    )
                    for f in http_findings
                ])
            except Exception as e:
                error_msg = f"HTTP C2 detection failed: {e}"
                self.errors.append(error_msg)
                logger.error(error_msg)
                sys.stderr.write(f"[c2_commander] VECTOR_ERROR: HTTP/HTTPS C2 error={e}\n")
                sys.stderr.flush()
        
        # DNS Tunneling Detection
        if options.detect_dns_tunneling:
            await self._handle_progress(40, "Detecting DNS tunneling C2")
            logger.info("[c2_commander] Starting DNS tunneling detection")
            sys.stderr.write("[c2_commander] VECTOR_START: DNS tunneling\n")
            sys.stderr.flush()
            try:
                dns_findings = await self.dns_tunneling_detector.detect(options.target)
                logger.info(f"[c2_commander] DNS tunneling detection completed: {len(dns_findings)} findings")
                sys.stderr.write(f"[c2_commander] VECTOR_DONE: DNS tunneling findings={len(dns_findings)}\n")
                sys.stderr.flush()
                self.dns_tunneling_findings.extend(dns_findings)
                self.findings.extend([
                    C2Finding(
                        id=f.id,
                        c2_type=C2Type.DNS_TUNNELING,
                        severity=f.severity,
                        confidence=f.confidence,
                        title=f.title,
                        description=f.description,
                        c2_server=f.c2_server,
                        protocol=ProtocolType.DNS,
                        details={
                            "domain": f.domain,
                            "query_type": f.query_type,
                            "data_volume": f.data_volume,
                            "query_frequency": f.query_frequency,
                        },
                        first_seen=f.first_seen,
                        last_seen=f.last_seen,
                        mitre_attack=f.mitre_attack,
                        recommendation=f.recommendation,
                        risk_score=f.risk_score,
                        evidence_preview=list(f.evidence_preview or []),
                    )
                    for f in dns_findings
                ])
            except Exception as e:
                error_msg = f"DNS tunneling detection failed: {e}"
                self.errors.append(error_msg)
                logger.error(error_msg)
                sys.stderr.write(f"[c2_commander] VECTOR_ERROR: DNS tunneling error={e}\n")
                sys.stderr.flush()
        
        # ICMP Tunneling Detection
        if options.detect_icmp_tunneling:
            await self._handle_progress(60, "Detecting ICMP tunneling C2")
            logger.info("[c2_commander] Starting ICMP tunneling detection")
            sys.stderr.write("[c2_commander] VECTOR_START: ICMP tunneling\n")
            sys.stderr.flush()
            try:
                icmp_findings = await self.icmp_tunneling_detector.detect(options.target)
                logger.info(f"[c2_commander] ICMP tunneling detection completed: {len(icmp_findings)} findings")
                sys.stderr.write(f"[c2_commander] VECTOR_DONE: ICMP tunneling findings={len(icmp_findings)}\n")
                sys.stderr.flush()
                self.icmp_tunneling_findings.extend(icmp_findings)
                self.findings.extend([
                    C2Finding(
                        id=f.id,
                        c2_type=C2Type.ICMP_TUNNELING,
                        severity=f.severity,
                        confidence=f.confidence,
                        title=f.title,
                        description=f.description,
                        c2_server=f.c2_server,
                        protocol=ProtocolType.ICMP,
                        details={
                            "packet_size": f.packet_size,
                            "data_volume": f.data_volume,
                        },
                        first_seen=f.first_seen,
                        last_seen=f.last_seen,
                        mitre_attack=f.mitre_attack,
                        recommendation=f.recommendation,
                        risk_score=f.risk_score,
                        evidence_preview=list(f.evidence_preview or []),
                    )
                    for f in icmp_findings
                ])
            except Exception as e:
                error_msg = f"ICMP tunneling detection failed: {e}"
                self.errors.append(error_msg)
                logger.error(error_msg)
                sys.stderr.write(f"[c2_commander] VECTOR_ERROR: ICMP tunneling error={e}\n")
                sys.stderr.flush()
        
        # WebSocket C2 Detection
        if options.detect_websocket_c2:
            await self._handle_progress(75, "Detecting WebSocket C2 communication")
            logger.info("[c2_commander] Starting WebSocket C2 detection")
            sys.stderr.write("[c2_commander] VECTOR_START: WebSocket C2\n")
            sys.stderr.flush()
            try:
                ws_findings = await self.websocket_c2_detector.detect(options.target)
                logger.info(f"[c2_commander] WebSocket C2 detection completed: {len(ws_findings)} findings")
                sys.stderr.write(f"[c2_commander] VECTOR_DONE: WebSocket C2 findings={len(ws_findings)}\n")
                sys.stderr.flush()
                self.websocket_c2_findings.extend(ws_findings)
                self.findings.extend([
                    C2Finding(
                        id=f.id,
                        c2_type=C2Type.WEBSOCKET_C2,
                        severity=f.severity,
                        confidence=f.confidence,
                        title=f.title,
                        description=f.description,
                        c2_server=f.c2_server,
                        c2_port=f.c2_port,
                        protocol=ProtocolType.WEBSOCKET,
                        details={
                            "ws_path": f.ws_path,
                            "message_frequency": f.message_frequency,
                        },
                        first_seen=f.first_seen,
                        last_seen=f.last_seen,
                        mitre_attack=f.mitre_attack,
                        recommendation=f.recommendation,
                        risk_score=f.risk_score,
                        evidence_preview=list(f.evidence_preview or []),
                    )
                    for f in ws_findings
                ])
            except Exception as e:
                error_msg = f"WebSocket C2 detection failed: {e}"
                self.errors.append(error_msg)
                logger.error(error_msg)
                sys.stderr.write(f"[c2_commander] VECTOR_ERROR: WebSocket C2 error={e}\n")
                sys.stderr.flush()
        
        # Domain Fronting Detection
        if options.detect_domain_fronting:
            await self._handle_progress(85, "Detecting domain fronting")
            logger.info("[c2_commander] Starting domain fronting detection")
            sys.stderr.write("[c2_commander] VECTOR_START: Domain fronting\n")
            sys.stderr.flush()
            try:
                df_findings = await self.domain_fronting_detector.detect(options.target)
                logger.info(f"[c2_commander] Domain fronting detection completed: {len(df_findings)} findings")
                sys.stderr.write(f"[c2_commander] VECTOR_DONE: Domain fronting findings={len(df_findings)}\n")
                sys.stderr.flush()
                self.domain_fronting_findings.extend(df_findings)
                self.findings.extend([
                    C2Finding(
                        id=f.id,
                        c2_type=C2Type.DOMAIN_FRONTING,
                        severity=f.severity,
                        confidence=f.confidence,
                        title=f.title,
                        description=f.description,
                        c2_server=f.actual_c2_domain,
                        c2_port=getattr(f, "c2_port", None) or 443,
                        protocol=ProtocolType.HTTPS,
                        details={
                            "front_domain": f.front_domain,
                            "cdn_provider": f.cdn_provider,
                            "source_pid": f.source_pid,
                            "source_process": f.source_process,
                            "local_port": f.local_port,
                            "telemetry_details": getattr(f, "telemetry_details", None) or {},
                        },
                        first_seen=f.first_seen,
                        last_seen=f.last_seen,
                        mitre_attack=f.mitre_attack,
                        recommendation=f.recommendation,
                        risk_score=f.risk_score,
                        evidence_preview=list(f.evidence_preview or []),
                    )
                    for f in df_findings
                ])
            except Exception as e:
                error_msg = f"Domain fronting detection failed: {e}"
                self.errors.append(error_msg)
                logger.error(error_msg)
                sys.stderr.write(f"[c2_commander] VECTOR_ERROR: Domain fronting error={e}\n")
                sys.stderr.flush()
        
        await self._handle_progress(100, "C2 detection complete")
        logger.info(f"[c2_commander] Scan completed: {len(self.findings)} total findings")
        
        scan_end = datetime.now(timezone.utc).replace(tzinfo=None)
        
        return C2CommanderOutput(
            scan_id=self.scan_id,
            scan_start=self.scan_start,
            scan_end=scan_end,
            findings=self.findings,
            http_c2_findings=self.http_c2_findings,
            dns_tunneling_findings=self.dns_tunneling_findings,
            icmp_tunneling_findings=self.icmp_tunneling_findings,
            websocket_c2_findings=self.websocket_c2_findings,
            domain_fronting_findings=self.domain_fronting_findings,
            total_findings=len(self.findings),
            errors=self.errors,
            warnings=self.warnings,
        )
