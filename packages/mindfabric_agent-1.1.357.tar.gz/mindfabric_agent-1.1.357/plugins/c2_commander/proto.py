"""
C2 Commander Plugin - Protocol Models

Data models for Command & Control (C2) detection.
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from plugins.reproduction import ReproStep


# =============================================================================
# ENUMS
# =============================================================================

class C2Type(str, Enum):
    """Types of C2 communication."""
    HTTP_C2 = "http_c2"
    HTTPS_C2 = "https_c2"
    DNS_TUNNELING = "dns_tunneling"
    ICMP_TUNNELING = "icmp_tunneling"
    WEBSOCKET_C2 = "websocket_c2"
    GRPC_C2 = "grpc_c2"
    SSH_TUNNELING = "ssh_tunneling"
    DOMAIN_FRONTING = "domain_fronting"
    CDN_C2 = "cdn_c2"
    MULTI_STAGE = "multi_stage"
    ENCRYPTED = "encrypted"
    STEGANOGRAPHY = "steganography"


class ProtocolType(str, Enum):
    """Network protocol types."""
    HTTP = "http"
    HTTPS = "https"
    DNS = "dns"
    ICMP = "icmp"
    WEBSOCKET = "websocket"
    GRPC = "grpc"
    SSH = "ssh"
    TCP = "tcp"
    UDP = "udp"


class SeverityLevel(str, Enum):
    """Severity levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ConfidenceLevel(str, Enum):
    """Confidence levels for detections."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class MitreTactic(str, Enum):
    """MITRE ATT&CK tactics."""
    COMMAND_AND_CONTROL = "command_and_control"


class MitreTechnique(str, Enum):
    """MITRE ATT&CK techniques."""
    T1071 = "T1071"  # Application Layer Protocol
    T1071_001 = "T1071.001"  # Web Protocols
    T1071_002 = "T1071.002"  # File Transfer Protocols
    T1071_003 = "T1071.003"  # Mail Protocols
    T1071_004 = "T1071.004"  # DNS
    T1095 = "T1095"  # Non-Application Layer Protocol
    T1573 = "T1573"  # Encrypted Channel
    T1573_001 = "T1573.001"  # Symmetric Cryptography
    T1573_002 = "T1573.002"  # Asymmetric Cryptography
    T1105 = "T1105"  # Ingress Tool Transfer
    T1571 = "T1571"  # Non-Standard Port
    T1572 = "T1572"  # Protocol Tunneling
    T1090 = "T1090"  # Proxy
    T1090_001 = "T1090.001"  # Internal Proxy
    T1090_002 = "T1090.002"  # External Proxy
    T1090_003 = "T1090.003"  # Multi-hop Proxy
    T1090_004 = "T1090.004"  # Domain Fronting


# =============================================================================
# MODELS
# =============================================================================

class MitreAttackReference(BaseModel):
    """MITRE ATT&CK technique reference."""
    tactic: MitreTactic
    technique_id: str
    technique_name: str
    sub_technique_id: Optional[str] = None
    sub_technique_name: Optional[str] = None


class HTTPC2Finding(BaseModel):
    """HTTP/HTTPS C2 finding."""
    id: str
    c2_type: C2Type
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    c2_server: str
    c2_port: int
    protocol: ProtocolType
    user_agent: Optional[str] = None
    http_method: Optional[str] = None
    uri_pattern: Optional[str] = None
    beacon_interval: Optional[int] = None
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    evidence_preview: List[str] = Field(default_factory=list)


class DNSTunnelingFinding(BaseModel):
    """DNS tunneling C2 finding."""
    id: str
    c2_type: C2Type = C2Type.DNS_TUNNELING
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    c2_server: str
    domain: str
    query_type: Optional[str] = None
    data_volume: Optional[int] = None
    query_frequency: Optional[float] = None
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    evidence_preview: List[str] = Field(default_factory=list)


class ICMPTunnelingFinding(BaseModel):
    """ICMP tunneling C2 finding."""
    id: str
    c2_type: C2Type = C2Type.ICMP_TUNNELING
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    c2_server: Optional[str] = None
    packet_size: Optional[int] = None
    data_volume: Optional[int] = None
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    evidence_preview: List[str] = Field(default_factory=list)


class WebSocketC2Finding(BaseModel):
    """WebSocket C2 finding."""
    id: str
    c2_type: C2Type = C2Type.WEBSOCKET_C2
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    c2_server: str
    c2_port: int
    ws_path: Optional[str] = None
    message_frequency: Optional[float] = None
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    evidence_preview: List[str] = Field(default_factory=list)


class DomainFrontingFinding(BaseModel):
    """Domain fronting C2 finding."""
    id: str
    c2_type: C2Type = C2Type.DOMAIN_FRONTING
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    front_domain: str
    actual_c2_domain: str
    cdn_provider: Optional[str] = None
    c2_port: int = 443
    source_pid: Optional[int] = None
    source_process: Optional[str] = None
    local_port: Optional[int] = None
    # Extended psutil / host telemetry (see detector for keys)
    telemetry_details: Dict[str, Any] = Field(default_factory=dict)
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    evidence_preview: List[str] = Field(default_factory=list)


class C2Finding(BaseModel):
    """Generic C2 finding."""
    id: str
    c2_type: C2Type
    severity: SeverityLevel
    confidence: ConfidenceLevel
    title: str
    description: str
    c2_server: Optional[str] = None
    c2_port: Optional[int] = None
    protocol: Optional[ProtocolType] = None
    details: Dict[str, Any] = {}
    first_seen: datetime
    last_seen: datetime
    mitre_attack: MitreAttackReference
    recommendation: str
    risk_score: float = Field(ge=0.0, le=10.0)
    exploitation_commands: Optional[List[ReproStep]] = None
    evidence_preview: List[str] = Field(default_factory=list)


class ScanTarget(BaseModel):
    """Scan target configuration."""
    network_interface: Optional[str] = None
    target_ips: Optional[List[str]] = None
    target_subnet: Optional[str] = None
    capture_duration: int = 300  # seconds
    packet_count_limit: Optional[int] = None
    log_paths: Optional[List[str]] = None


class ScanOptions(BaseModel):
    """Scan configuration options."""
    target: Optional[ScanTarget] = None
    detect_http_c2: bool = True
    detect_dns_tunneling: bool = True
    detect_icmp_tunneling: bool = True
    detect_websocket_c2: bool = True
    detect_domain_fronting: bool = True
    detect_cdn_c2: bool = True
    detect_ssh_tunneling: bool = False
    detect_grpc_c2: bool = False
    quick_scan: bool = False
    deep_scan: bool = False


class C2CommanderOutput(BaseModel):
    """Output from C2 detection."""
    scan_id: str
    scan_start: datetime
    scan_end: datetime
    findings: List[C2Finding]
    http_c2_findings: List[HTTPC2Finding] = []
    dns_tunneling_findings: List[DNSTunnelingFinding] = []
    icmp_tunneling_findings: List[ICMPTunnelingFinding] = []
    websocket_c2_findings: List[WebSocketC2Finding] = []
    domain_fronting_findings: List[DomainFrontingFinding] = []
    total_findings: int
    errors: List[str] = []
    warnings: List[str] = []
