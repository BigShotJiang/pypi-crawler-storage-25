"""
C2 Commander Plugin

Comprehensive Command & Control (C2) detection and analysis plugin.
Detects various C2 communication patterns including:
- HTTP/HTTPS C2
- DNS tunneling C2
- ICMP tunneling C2
- WebSocket C2
- gRPC C2
- SSH tunneling as C2
- Domain fronting
- CDN-based C2 (CloudFlare Workers, AWS Lambda)
- Multi-stage payloads
- Encrypted communications
- Steganography in C2 communications

Supports MITRE ATT&CK mapping for Command & Control tactics.
"""

from .c2_commander import (
    C2CommanderPlugin,
)
from .modules.services import (
    HTTPC2DetectorService as HTTPC2Detector,
    DNSTunnelingDetectorService as DNSTunnelingDetector,
    ICMPTunnelingDetectorService as ICMPTunnelingDetector,
    WebSocketC2DetectorService as WebSocketC2Detector,
    DomainFrontingDetectorService as DomainFrontingDetector,
)
from .proto import (
    # Enums
    SeverityLevel,
    ConfidenceLevel,
    C2Type,
    ProtocolType,
    MitreTactic,
    MitreTechnique,
    # Models
    C2Finding,
    HTTPC2Finding,
    DNSTunnelingFinding,
    ICMPTunnelingFinding,
    WebSocketC2Finding,
    DomainFrontingFinding,
    C2CommanderOutput,
    ScanOptions,
    ScanTarget,
)

__all__ = [
    # Main classes
    "C2CommanderPlugin",
    # Services
    "HTTPC2Detector",
    "DNSTunnelingDetector",
    "ICMPTunnelingDetector",
    "WebSocketC2Detector",
    "DomainFrontingDetector",
    # Models
    "C2Finding",
    "HTTPC2Finding",
    "DNSTunnelingFinding",
    "ICMPTunnelingFinding",
    "WebSocketC2Finding",
    "DomainFrontingFinding",
    "C2CommanderOutput",
    "ScanOptions",
    "ScanTarget",
    # Enums
    "SeverityLevel",
    "ConfidenceLevel",
    "C2Type",
    "ProtocolType",
    "MitreTactic",
    "MitreTechnique",
]
