"""
Database Security Assessment Plugin - Pydantic Models

Comprehensive database security assessment covering:
- Database discovery and enumeration
- Authentication and authorization analysis
- Configuration security
- SQL/NoSQL injection testing
- Privilege escalation paths
- Persistence mechanisms
- Data protection assessment
- Audit logging verification
- Compliance mapping
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from plugins.reproduction import ReproStep


# =============================================================================
# Enumerations
# =============================================================================

class DatabaseType(str, Enum):
    """Supported database types."""
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    MARIADB = "mariadb"
    MSSQL = "mssql"
    ORACLE = "oracle"
    MONGODB = "mongodb"
    REDIS = "redis"
    CASSANDRA = "cassandra"
    COUCHDB = "couchdb"
    ELASTICSEARCH = "elasticsearch"
    SQLITE = "sqlite"
    DYNAMODB = "dynamodb"
    COSMOSDB = "cosmosdb"
    UNKNOWN = "unknown"


class SeverityLevel(str, Enum):
    """Severity classification for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ConfidenceLevel(str, Enum):
    """Confidence level for detections."""
    CONFIRMED = "confirmed"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    TENTATIVE = "tentative"


class FindingCategory(str, Enum):
    """Categories of database security findings."""
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    CONFIGURATION = "configuration"
    ENCRYPTION = "encryption"
    INJECTION = "injection"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    PERSISTENCE = "persistence"
    AUDIT_LOGGING = "audit_logging"
    NETWORK = "network"
    DATA_EXPOSURE = "data_exposure"
    COMPLIANCE = "compliance"
    BACKUP = "backup"
    VULNERABILITY = "vulnerability"


class FindingSubCategory(str, Enum):
    """Sub-categories of findings."""
    # Authentication
    WEAK_PASSWORD = "weak_password"
    DEFAULT_CREDENTIALS = "default_credentials"
    NO_PASSWORD = "no_password"
    WEAK_PASSWORD_POLICY = "weak_password_policy"
    NO_MFA = "no_mfa"
    EXPIRED_CREDENTIALS = "expired_credentials"
    
    # Authorization
    EXCESSIVE_PRIVILEGES = "excessive_privileges"
    PUBLIC_ACCESS = "public_access"
    WILDCARD_GRANTS = "wildcard_grants"
    ROLE_MISCONFIGURATION = "role_misconfiguration"
    UNUSED_ACCOUNTS = "unused_accounts"
    SERVICE_ACCOUNT_ABUSE = "service_account_abuse"
    
    # Configuration
    INSECURE_SETTING = "insecure_setting"
    DEBUG_ENABLED = "debug_enabled"
    UNSAFE_FUNCTIONS = "unsafe_functions"
    EXPOSED_METADATA = "exposed_metadata"
    
    # Encryption
    UNENCRYPTED_CONNECTION = "unencrypted_connection"
    WEAK_TLS = "weak_tls"
    UNENCRYPTED_DATA = "unencrypted_data"
    WEAK_ENCRYPTION = "weak_encryption"
    MISSING_TDE = "missing_tde"
    
    # Injection
    SQL_INJECTION = "sql_injection"
    NOSQL_INJECTION = "nosql_injection"
    COMMAND_INJECTION = "command_injection"
    
    # Privilege Escalation
    ESCALATION_PATH = "escalation_path"
    DANGEROUS_PERMISSIONS = "dangerous_permissions"
    CROSS_DB_ACCESS = "cross_db_access"
    
    # Persistence
    MALICIOUS_TRIGGER = "malicious_trigger"
    MALICIOUS_PROCEDURE = "malicious_procedure"
    MALICIOUS_JOB = "malicious_job"
    BACKDOOR_ACCOUNT = "backdoor_account"
    
    # Audit Logging
    LOGGING_DISABLED = "logging_disabled"
    INSUFFICIENT_LOGGING = "insufficient_logging"
    LOG_TAMPERING = "log_tampering"
    NO_RETENTION = "no_retention"
    
    # Network
    OPEN_PORT = "open_port"
    NO_FIREWALL = "no_firewall"
    EXPOSED_MANAGEMENT = "exposed_management"
    NETWORK_MISCONFIGURATION = "network_misconfiguration"
    
    # Data Exposure
    PII_EXPOSURE = "pii_exposure"
    SENSITIVE_DATA_UNMASKED = "sensitive_data_unmasked"
    BACKUP_EXPOSURE = "backup_exposure"
    
    # Compliance
    PCI_DSS_VIOLATION = "pci_dss_violation"
    HIPAA_VIOLATION = "hipaa_violation"
    GDPR_VIOLATION = "gdpr_violation"
    SOX_VIOLATION = "sox_violation"


class ComplianceFramework(str, Enum):
    """Compliance frameworks."""
    PCI_DSS = "PCI-DSS"
    HIPAA = "HIPAA"
    GDPR = "GDPR"
    SOX = "SOX"
    SOC2 = "SOC 2"
    ISO_27001 = "ISO 27001"
    CIS = "CIS"
    NIST = "NIST"


class MitreTactic(str, Enum):
    """MITRE ATT&CK Tactics."""
    INITIAL_ACCESS = "TA0001 Initial Access"
    PERSISTENCE = "TA0003 Persistence"
    PRIVILEGE_ESCALATION = "TA0004 Privilege Escalation"
    DEFENSE_EVASION = "TA0005 Defense Evasion"
    CREDENTIAL_ACCESS = "TA0006 Credential Access"
    DISCOVERY = "TA0007 Discovery"
    LATERAL_MOVEMENT = "TA0008 Lateral Movement"
    COLLECTION = "TA0009 Collection"
    EXFILTRATION = "TA0010 Exfiltration"
    IMPACT = "TA0040 Impact"


class MitreTechnique(str, Enum):
    """MITRE ATT&CK Techniques for databases."""
    # Initial Access
    T1190 = "T1190 Exploit Public-Facing Application"
    T1078 = "T1078 Valid Accounts"
    
    # Persistence
    T1136 = "T1136 Create Account"
    T1505_001 = "T1505.001 SQL Stored Procedures"
    T1546_004 = "T1546.004 .profile and .bashrc"
    
    # Privilege Escalation
    T1068 = "T1068 Exploitation for Privilege Escalation"
    T1548 = "T1548 Abuse Elevation Control Mechanism"
    
    # Credential Access
    T1003 = "T1003 OS Credential Dumping"
    T1110 = "T1110 Brute Force"
    T1552 = "T1552 Unsecured Credentials"
    T1555 = "T1555 Credentials from Password Stores"
    
    # Discovery
    T1087 = "T1087 Account Discovery"
    T1046 = "T1046 Network Service Discovery"
    
    # Collection
    T1119 = "T1119 Automated Collection"
    T1530 = "T1530 Data from Cloud Storage"
    
    # Exfiltration
    T1048 = "T1048 Exfiltration Over Alternative Protocol"
    
    # Impact
    T1485 = "T1485 Data Destruction"
    T1486 = "T1486 Data Encrypted for Impact"
    T1565 = "T1565 Data Manipulation"


# =============================================================================
# Exploitation Commands Model
# =============================================================================

class ExploitationCommands(BaseModel):
    """Explicit commands for database security verification, exploitation, or remediation."""
    server: Optional[str] = Field(None, description="Target database server/host")
    ip: Optional[str] = Field(None, description="Target IP address")
    commands: List[str] = Field(default_factory=list, description="List of SQL/CLI commands")
    description: Optional[str] = Field(None, description="Description of the commands")


# =============================================================================
# Supporting Models
# =============================================================================

class DatabaseConnection(BaseModel):
    """Database connection information."""
    host: str = Field(..., description="Database host")
    port: int = Field(..., description="Database port")
    database_type: DatabaseType = Field(..., description="Database type")
    database_name: Optional[str] = Field(None, description="Database name")
    username: Optional[str] = Field(None, description="Connection username")
    ssl_enabled: bool = Field(False, description="SSL/TLS enabled")
    ssl_verified: bool = Field(False, description="SSL certificate verified")
    connection_string: Optional[str] = Field(None, description="Connection string (masked)")


class DatabaseUser(BaseModel):
    """Database user information."""
    username: str = Field(..., description="Username")
    host: Optional[str] = Field(None, description="Allowed host")
    roles: List[str] = Field(default_factory=list, description="Assigned roles")
    privileges: List[str] = Field(default_factory=list, description="Direct privileges")
    is_superuser: bool = Field(False, description="Has superuser privileges")
    has_mfa: bool = Field(False, description="MFA enabled")
    password_expires: Optional[datetime] = Field(None, description="Password expiration")
    last_login: Optional[datetime] = Field(None, description="Last login time")
    is_locked: bool = Field(False, description="Account locked")
    created_at: Optional[datetime] = Field(None, description="Account creation time")


class DatabaseObject(BaseModel):
    """Database object (table, procedure, etc.)."""
    name: str = Field(..., description="Object name")
    object_type: str = Field(..., description="Object type")
    schema_name: Optional[str] = Field(None, description="Schema name")
    owner: Optional[str] = Field(None, description="Object owner")
    size_bytes: Optional[int] = Field(None, description="Object size")
    row_count: Optional[int] = Field(None, description="Row count for tables")
    has_sensitive_data: bool = Field(False, description="Contains sensitive data")
    is_encrypted: bool = Field(False, description="Data is encrypted")


class MitreReference(BaseModel):
    """MITRE ATT&CK reference."""
    tactic: MitreTactic = Field(..., description="MITRE tactic")
    technique: MitreTechnique = Field(..., description="MITRE technique")
    url: Optional[str] = Field(None, description="Reference URL")


class ComplianceMapping(BaseModel):
    """Compliance framework mapping."""
    framework: ComplianceFramework = Field(..., description="Framework")
    control_id: str = Field(..., description="Control ID")
    control_name: str = Field(..., description="Control name")
    description: Optional[str] = Field(None, description="Description")


# =============================================================================
# Finding Model
# =============================================================================

class DatabaseSecurityFinding(BaseModel):
    """Database security finding."""
    id: str = Field(..., description="Finding ID")
    
    # Classification
    category: FindingCategory = Field(..., description="Finding category")
    sub_category: FindingSubCategory = Field(..., description="Sub-category")
    severity: SeverityLevel = Field(..., description="Severity")
    confidence: ConfidenceLevel = Field(..., description="Confidence")
    
    # Target
    database_type: DatabaseType = Field(..., description="Database type")
    database_name: Optional[str] = Field(None, description="Database name")
    host: Optional[str] = Field(None, description="Host")
    
    # Details
    title: str = Field(..., description="Finding title")
    description: str = Field(..., description="Detailed description")
    evidence: Optional[str] = Field(None, description="Evidence/proof")
    
    # Affected resources
    affected_users: List[str] = Field(default_factory=list)
    affected_objects: List[str] = Field(default_factory=list)
    affected_settings: List[str] = Field(default_factory=list)
    
    # Risk
    risk_score: float = Field(0.0, ge=0.0, le=10.0, description="Risk score")
    exploitability: str = Field("Medium", description="Exploitability")
    potential_impact: str = Field(..., description="Potential impact")
    
    # MITRE mapping
    mitre: Optional[MitreReference] = Field(None)
    
    # Compliance mapping
    compliance: List[ComplianceMapping] = Field(default_factory=list)
    
    # Remediation
    recommendation: str = Field(..., description="Recommendation")
    remediation_steps: List[str] = Field(default_factory=list)
    remediation_sql: Optional[str] = Field(None, description="SQL to fix")
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Exploitation/Investigation commands
    commands: Optional[ExploitationCommands] = Field(
        None, description="Commands to verify, exploit, or remediate this finding"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(None)


# =============================================================================
# Scan Configuration
# =============================================================================

class ScanTarget(BaseModel):
    """Database scan target."""
    host: str = Field(..., description="Database host")
    port: int = Field(..., description="Database port")
    database_type: Optional[DatabaseType] = Field(None, description="Database type")
    database_name: Optional[str] = Field(None, description="Database name")
    
    # Authentication
    username: Optional[str] = Field(None, description="Username")
    password: Optional[str] = Field(None, description="Password")
    auth_file: Optional[str] = Field(None, description="Auth file path")
    use_kerberos: bool = Field(False, description="Use Kerberos auth")
    ssl_cert: Optional[str] = Field(None, description="SSL certificate path")


class ScanOptions(BaseModel):
    """Scan configuration options."""
    targets: List[ScanTarget] = Field(default_factory=list)
    
    # Scan types
    check_authentication: bool = Field(True)
    check_authorization: bool = Field(True)
    check_configuration: bool = Field(True)
    check_encryption: bool = Field(True)
    check_injection: bool = Field(False)  # Risky, disabled by default
    check_privilege_escalation: bool = Field(True)
    check_persistence: bool = Field(True)
    check_audit_logging: bool = Field(True)
    check_network: bool = Field(True)
    check_data_exposure: bool = Field(True)
    check_compliance: bool = Field(True)
    check_backup: bool = Field(True)
    check_vulnerabilities: bool = Field(True)
    
    # Compliance frameworks to check
    compliance_frameworks: List[ComplianceFramework] = Field(default_factory=list)
    
    # Depth
    enumerate_users: bool = Field(True)
    enumerate_objects: bool = Field(True)
    enumerate_privileges: bool = Field(True)
    
    # Safety
    read_only: bool = Field(True)  # Don't modify database
    test_default_credentials: bool = Field(True)
    brute_force: bool = Field(False)  # Disabled by default
    
    # Performance
    timeout_seconds: int = Field(30)
    max_connections: int = Field(5)


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary by severity."""
    critical: int = Field(0)
    high: int = Field(0)
    medium: int = Field(0)
    low: int = Field(0)
    info: int = Field(0)
    total: int = Field(0)


class CategorySummary(BaseModel):
    """Summary by category."""
    category: FindingCategory = Field(...)
    count: int = Field(0)
    critical_count: int = Field(0)
    high_count: int = Field(0)


class ComplianceSummary(BaseModel):
    """Compliance status summary."""
    framework: ComplianceFramework = Field(...)
    total_controls: int = Field(0)
    passing: int = Field(0)
    failing: int = Field(0)
    not_applicable: int = Field(0)
    compliance_score: float = Field(0.0)


class DatabaseSummary(BaseModel):
    """Summary for a single database."""
    host: str = Field(...)
    port: int = Field(...)
    database_type: DatabaseType = Field(...)
    database_name: Optional[str] = Field(None)
    
    # Discovery
    version: Optional[str] = Field(None)
    users_count: int = Field(0)
    objects_count: int = Field(0)
    
    # Security
    ssl_enabled: bool = Field(False)
    auth_type: Optional[str] = Field(None)
    
    # Findings
    findings_count: int = Field(0)
    critical_findings: int = Field(0)
    high_findings: int = Field(0)
    
    # Risk
    overall_risk_score: float = Field(0.0)
    risk_level: str = Field("Unknown")


class ScanMetadata(BaseModel):
    """Scan metadata."""
    scan_id: str = Field(...)
    scan_type: str = Field("database_security")
    
    # Timing
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(None)
    duration_seconds: Optional[float] = Field(None)
    
    # Coverage
    databases_scanned: int = Field(0)
    hosts_scanned: int = Field(0)
    
    # Results
    total_findings: int = Field(0)
    
    # Tool info
    tool_version: str = Field("1.0.0")


class DatabaseSecurityScanOutput(BaseModel):
    """Complete output from database security scan."""
    # Metadata
    metadata: ScanMetadata = Field(...)
    
    # Options used
    options: Optional[ScanOptions] = Field(None)
    
    # Summaries
    severity_summary: SeveritySummary = Field(default_factory=SeveritySummary)
    category_summaries: List[CategorySummary] = Field(default_factory=list)
    compliance_summaries: List[ComplianceSummary] = Field(default_factory=list)
    database_summaries: List[DatabaseSummary] = Field(default_factory=list)
    
    # Discovered info
    connections: List[DatabaseConnection] = Field(default_factory=list)
    users: List[DatabaseUser] = Field(default_factory=list)
    objects: List[DatabaseObject] = Field(default_factory=list)
    
    # Findings
    findings: List[DatabaseSecurityFinding] = Field(default_factory=list)
    critical_findings: List[DatabaseSecurityFinding] = Field(default_factory=list)
    
    # Recommendations
    recommendations: List[str] = Field(default_factory=list)
    immediate_actions: List[str] = Field(default_factory=list)
    
    # Errors
    errors: Optional[List[str]] = Field(None)
    warnings: Optional[List[str]] = Field(None)
    
    # Exploitation/Investigation commands
    commands: Optional[ExploitationCommands] = Field(
        None, description="Overall commands related to database security assessment"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(None)

