"""
Database Security Assessment Plugin

Comprehensive database security assessment covering:
- Database discovery and enumeration
- Authentication and authorization analysis
- Configuration security
- SQL/NoSQL injection testing
- Privilege escalation paths
- Persistence mechanisms
- Data protection assessment
- Audit logging verification
- Compliance mapping
"""

from .database_security_assessment import DatabaseSecurityAssessmentPlugin

__all__ = ["DatabaseSecurityAssessmentPlugin"]

