"""
Database Privilege Escalation Service

Detects privilege escalation paths in databases.
"""

from typing import Any, Dict, List, Optional

from ...proto import (
    DatabaseType,
    DatabaseUser,
    SeverityLevel,
    ConfidenceLevel,
    FindingCategory,
    FindingSubCategory,
)
from .finding_service import FindingService


# =============================================================================
# Privilege Escalation Techniques
# =============================================================================

PRIVILEGE_ESCALATION_TECHNIQUES = {
    DatabaseType.POSTGRESQL: {
        "superuser_escalation": {
            "description": "Escalate to superuser via vulnerable functions",
            "checks": [
                {
                    "name": "security_definer_function",
                    "query": """
                        SELECT proname, proowner::regrole, prosecdef 
                        FROM pg_proc 
                        WHERE prosecdef = true 
                        AND proowner::regrole::text IN (SELECT rolname FROM pg_roles WHERE rolsuper)
                    """,
                    "vulnerability": "SECURITY DEFINER functions owned by superuser",
                    "severity": SeverityLevel.HIGH,
                },
                {
                    "name": "copy_to_program",
                    "query": "SELECT setting FROM pg_settings WHERE name = 'logging_collector'",
                    "vulnerability": "COPY TO PROGRAM can execute OS commands (if superuser)",
                    "severity": SeverityLevel.CRITICAL,
                },
                {
                    "name": "pg_execute_server_program",
                    "query": """
                        SELECT rolname FROM pg_roles 
                        WHERE pg_has_role(rolname, 'pg_execute_server_program', 'MEMBER')
                    """,
                    "vulnerability": "User has pg_execute_server_program role",
                    "severity": SeverityLevel.CRITICAL,
                },
                {
                    "name": "large_object_abuse",
                    "query": """
                        SELECT rolname FROM pg_roles 
                        WHERE pg_has_role(rolname, 'pg_read_server_files', 'MEMBER')
                           OR pg_has_role(rolname, 'pg_write_server_files', 'MEMBER')
                    """,
                    "vulnerability": "User can read/write server files via large objects",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
        "lateral_movement": {
            "description": "Move to other databases/servers",
            "checks": [
                {
                    "name": "dblink_extension",
                    "query": "SELECT extname FROM pg_extension WHERE extname = 'dblink'",
                    "vulnerability": "dblink extension enables connections to other databases",
                    "severity": SeverityLevel.MEDIUM,
                },
                {
                    "name": "postgres_fdw",
                    "query": "SELECT extname FROM pg_extension WHERE extname = 'postgres_fdw'",
                    "vulnerability": "postgres_fdw enables foreign data wrapper connections",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
        },
    },
    DatabaseType.MYSQL: {
        "file_privilege_abuse": {
            "description": "Abuse FILE privilege for escalation",
            "checks": [
                {
                    "name": "file_privilege",
                    "query": """
                        SELECT User, Host FROM mysql.user 
                        WHERE File_priv = 'Y'
                    """,
                    "vulnerability": "FILE privilege allows reading/writing files",
                    "severity": SeverityLevel.HIGH,
                },
                {
                    "name": "into_outfile",
                    "query": "SELECT @@secure_file_priv",
                    "vulnerability": "INTO OUTFILE/LOAD_FILE restrictions",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
        },
        "udf_injection": {
            "description": "User-Defined Function injection",
            "checks": [
                {
                    "name": "plugin_dir_writable",
                    "query": "SELECT @@plugin_dir",
                    "vulnerability": "UDF can be loaded from plugin directory",
                    "severity": SeverityLevel.CRITICAL,
                },
            ],
        },
        "trigger_abuse": {
            "description": "Abuse triggers for privilege escalation",
            "checks": [
                {
                    "name": "trigger_privilege",
                    "query": """
                        SELECT User, Host FROM mysql.user 
                        WHERE Trigger_priv = 'Y'
                    """,
                    "vulnerability": "TRIGGER privilege can execute code on table operations",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
        },
    },
    DatabaseType.MSSQL: {
        "impersonation": {
            "description": "Impersonate other users/logins",
            "checks": [
                {
                    "name": "impersonate_login",
                    "query": """
                        SELECT DISTINCT grantee_principal.name AS grantee_name,
                               grantor_principal.name AS grantor_name
                        FROM sys.server_permissions perm
                        JOIN sys.server_principals grantee_principal ON perm.grantee_principal_id = grantee_principal.principal_id
                        JOIN sys.server_principals grantor_principal ON perm.grantor_principal_id = grantor_principal.principal_id
                        WHERE perm.permission_name = 'IMPERSONATE'
                    """,
                    "vulnerability": "User can impersonate other logins",
                    "severity": SeverityLevel.HIGH,
                },
                {
                    "name": "execute_as",
                    "query": """
                        SELECT DISTINCT p.name AS procedure_name, p.execute_as_principal_id
                        FROM sys.procedures p
                        WHERE p.execute_as_principal_id IS NOT NULL
                    """,
                    "vulnerability": "Procedures with EXECUTE AS context",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
        },
        "linked_server_abuse": {
            "description": "Abuse linked servers for lateral movement",
            "checks": [
                {
                    "name": "linked_servers",
                    "query": """
                        SELECT name, data_source, provider, is_linked, is_remote_login_enabled
                        FROM sys.servers
                        WHERE is_linked = 1
                    """,
                    "vulnerability": "Linked servers enable cross-server queries",
                    "severity": SeverityLevel.HIGH,
                },
                {
                    "name": "openquery_abuse",
                    "query": """
                        SELECT name FROM sys.servers 
                        WHERE is_linked = 1 
                        AND is_data_access_enabled = 1
                    """,
                    "vulnerability": "OPENQUERY can be used on linked server",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
        },
        "clr_abuse": {
            "description": "Abuse CLR for code execution",
            "checks": [
                {
                    "name": "clr_enabled",
                    "query": "SELECT value FROM sys.configurations WHERE name = 'clr enabled'",
                    "vulnerability": "CLR assemblies can execute arbitrary .NET code",
                    "severity": SeverityLevel.HIGH,
                },
                {
                    "name": "trustworthy_db",
                    "query": """
                        SELECT name FROM sys.databases 
                        WHERE is_trustworthy_on = 1 
                        AND name NOT IN ('msdb')
                    """,
                    "vulnerability": "TRUSTWORTHY database can escalate via CLR",
                    "severity": SeverityLevel.CRITICAL,
                },
            ],
        },
        "xp_cmdshell": {
            "description": "OS command execution via xp_cmdshell",
            "checks": [
                {
                    "name": "xp_cmdshell_enabled",
                    "query": "SELECT value FROM sys.configurations WHERE name = 'xp_cmdshell'",
                    "vulnerability": "xp_cmdshell allows OS command execution",
                    "severity": SeverityLevel.CRITICAL,
                },
                {
                    "name": "ole_automation",
                    "query": "SELECT value FROM sys.configurations WHERE name = 'Ole Automation Procedures'",
                    "vulnerability": "OLE Automation can execute external code",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
    },
    DatabaseType.ORACLE: {
        "java_abuse": {
            "description": "Abuse Java for privilege escalation",
            "checks": [
                {
                    "name": "java_permissions",
                    "query": """
                        SELECT grantee, privilege 
                        FROM dba_java_policy 
                        WHERE action = 'grant' 
                        AND type_name LIKE '%FilePermission%'
                    """,
                    "vulnerability": "Java FilePermission grants file access",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
        "dbms_scheduler_abuse": {
            "description": "Abuse DBMS_SCHEDULER for code execution",
            "checks": [
                {
                    "name": "scheduler_jobs",
                    "query": """
                        SELECT owner, job_name, job_action 
                        FROM dba_scheduler_jobs 
                        WHERE job_type = 'EXECUTABLE'
                    """,
                    "vulnerability": "DBMS_SCHEDULER can execute OS commands",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
        "db_link_abuse": {
            "description": "Abuse database links for lateral movement",
            "checks": [
                {
                    "name": "database_links",
                    "query": "SELECT owner, db_link, host, username FROM dba_db_links",
                    "vulnerability": "Database links enable cross-database access",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
    },
    DatabaseType.MONGODB: {
        "eval_abuse": {
            "description": "Abuse $eval for code execution",
            "checks": [
                {
                    "name": "eval_enabled",
                    "query": "db.adminCommand({getParameter: 1, javascriptEnabled: 1})",
                    "vulnerability": "$eval allows JavaScript execution",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
        "role_escalation": {
            "description": "Escalate MongoDB roles",
            "checks": [
                {
                    "name": "user_admin_role",
                    "query": "db.getUsers()",
                    "vulnerability": "userAdmin role can create new admin users",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        },
    },
}


class PrivilegeEscalationService:
    """Service for detecting privilege escalation paths."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.finding_service = FindingService()
        self.findings: List[Any] = []
    
    def check_escalation_paths(
        self,
        db_type: DatabaseType,
        query_executor: callable,
        current_user: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Check for privilege escalation paths.
        
        Args:
            db_type: Database type
            query_executor: Function to execute queries
            current_user: Current database user
            
        Returns:
            List of escalation path findings
        """
        escalation_paths = []
        
        techniques = PRIVILEGE_ESCALATION_TECHNIQUES.get(db_type, {})
        
        for technique_name, technique_config in techniques.items():
            for check in technique_config.get("checks", []):
                try:
                    result = query_executor(check["query"])
                    
                    # Check if vulnerability exists
                    if self._is_vulnerable(result, check):
                        escalation_path = {
                            "technique": technique_name,
                            "check": check["name"],
                            "description": technique_config["description"],
                            "vulnerability": check["vulnerability"],
                            "severity": check["severity"],
                            "evidence": str(result)[:500],
                        }
                        escalation_paths.append(escalation_path)
                        
                        # Create finding
                        finding = self.finding_service.create_finding(
                            category=FindingCategory.PRIVILEGE_ESCALATION,
                            sub_category=FindingSubCategory.ESCALATION_PATH,
                            severity=check["severity"],
                            title=f"Privilege Escalation: {check['vulnerability']}",
                            description=f"{technique_config['description']}: {check['vulnerability']}",
                            database_type=db_type,
                            evidence=str(result)[:500],
                            recommendation=self._get_recommendation(technique_name, db_type),
                            remediation_steps=self._get_remediation_steps(technique_name, db_type),
                        )
                        self.findings.append(finding)
                except Exception:
                    pass
        
        return escalation_paths
    
    def _is_vulnerable(self, result: Any, check: Dict[str, Any]) -> bool:
        """Check if result indicates vulnerability."""
        if result is None:
            return False
        
        # For queries that return rows - vulnerable if rows exist
        if isinstance(result, (list, tuple)) and len(result) > 0:
            return True
        
        # For configuration checks
        if isinstance(result, str):
            if check["name"] in ["xp_cmdshell_enabled", "ole_automation", "clr_enabled"]:
                return result.strip() == "1"
            if check["name"] == "eval_enabled":
                return "true" in result.lower()
        
        # For value checks
        result_str = str(result).lower()
        if check["name"] == "secure_file_priv" and result_str in ["", "null", "none"]:
            return True
        
        return bool(result)
    
    def _get_recommendation(self, technique: str, db_type: DatabaseType) -> str:
        """Get remediation recommendation."""
        recommendations = {
            "superuser_escalation": "Review and restrict superuser access. Remove SECURITY DEFINER from unnecessary functions.",
            "file_privilege_abuse": "Revoke FILE privilege from non-admin users. Set secure_file_priv.",
            "udf_injection": "Restrict access to plugin directory. Disable dynamic loading if not needed.",
            "impersonation": "Review IMPERSONATE permissions. Remove unnecessary impersonation rights.",
            "linked_server_abuse": "Review linked server configurations. Use least-privilege accounts for linked servers.",
            "clr_abuse": "Disable CLR if not needed. Set TRUSTWORTHY to OFF for user databases.",
            "xp_cmdshell": "Disable xp_cmdshell and Ole Automation. Use proxy accounts if command execution is needed.",
            "java_abuse": "Review Java permissions. Remove unnecessary FilePermission grants.",
            "dbms_scheduler_abuse": "Review scheduler jobs. Restrict EXECUTE permissions on DBMS_SCHEDULER.",
            "db_link_abuse": "Review database links. Use secure authentication for links.",
            "eval_abuse": "Disable JavaScript execution if not needed. Restrict $eval usage.",
            "role_escalation": "Review user roles. Avoid granting userAdmin to non-admin users.",
        }
        return recommendations.get(technique, "Review and restrict the vulnerable configuration.")
    
    def _get_remediation_steps(self, technique: str, db_type: DatabaseType) -> List[str]:
        """Get remediation steps."""
        steps = {
            "xp_cmdshell": [
                "EXEC sp_configure 'show advanced options', 1; RECONFIGURE;",
                "EXEC sp_configure 'xp_cmdshell', 0; RECONFIGURE;",
                "If needed, create proxy account with limited permissions",
            ],
            "clr_abuse": [
                "EXEC sp_configure 'clr enabled', 0; RECONFIGURE;",
                "ALTER DATABASE [db_name] SET TRUSTWORTHY OFF;",
                "Review and remove unnecessary CLR assemblies",
            ],
            "linked_server_abuse": [
                "EXEC sp_droplinkedsrvlogin @rmtsrvname = N'server', @locallogin = NULL;",
                "Review and minimize linked server permissions",
                "Use stored credentials with least privileges",
            ],
            "file_privilege_abuse": [
                "REVOKE FILE ON *.* FROM 'user'@'host';",
                "SET GLOBAL secure_file_priv = '/secure/path/';",
            ],
            "superuser_escalation": [
                "ALTER FUNCTION function_name SECURITY INVOKER;",
                "REVOKE pg_execute_server_program FROM user;",
                "REVOKE pg_read_server_files, pg_write_server_files FROM user;",
            ],
        }
        return steps.get(technique, ["Review the affected configuration", "Apply principle of least privilege"])
    
    def check_lateral_movement(
        self,
        db_type: DatabaseType,
        query_executor: callable,
    ) -> List[Dict[str, Any]]:
        """Check for lateral movement opportunities."""
        lateral_paths = []
        
        lateral_checks = {
            DatabaseType.MSSQL: [
                {
                    "name": "linked_servers",
                    "query": "SELECT name, data_source FROM sys.servers WHERE is_linked = 1",
                    "description": "Linked server can be used for lateral movement",
                },
                {
                    "name": "openrowset",
                    "query": "SELECT value FROM sys.configurations WHERE name = 'Ad Hoc Distributed Queries'",
                    "description": "OPENROWSET can access remote data sources",
                },
            ],
            DatabaseType.POSTGRESQL: [
                {
                    "name": "dblink",
                    "query": "SELECT extname FROM pg_extension WHERE extname = 'dblink'",
                    "description": "dblink extension enables remote database access",
                },
                {
                    "name": "foreign_servers",
                    "query": "SELECT srvname, srvowner FROM pg_foreign_server",
                    "description": "Foreign servers for cross-database access",
                },
            ],
            DatabaseType.ORACLE: [
                {
                    "name": "db_links",
                    "query": "SELECT db_link, host FROM dba_db_links",
                    "description": "Database links for lateral movement",
                },
            ],
        }
        
        checks = lateral_checks.get(db_type, [])
        
        for check in checks:
            try:
                result = query_executor(check["query"])
                if result:
                    lateral_paths.append({
                        "name": check["name"],
                        "description": check["description"],
                        "targets": result,
                    })
                    
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.LATERAL_MOVEMENT,
                        sub_category=FindingSubCategory.DATABASE_LINK,
                        severity=SeverityLevel.HIGH,
                        title=f"Lateral Movement: {check['name']}",
                        description=check["description"],
                        database_type=db_type,
                        evidence=str(result)[:500],
                        recommendation="Review and restrict cross-database access",
                    )
                    self.findings.append(finding)
            except Exception:
                pass
        
        return lateral_paths
    
    def check_persistence(
        self,
        db_type: DatabaseType,
        query_executor: callable,
    ) -> List[Dict[str, Any]]:
        """Check for persistence mechanisms."""
        persistence_findings = []
        
        persistence_checks = {
            DatabaseType.MSSQL: [
                {
                    "name": "agent_jobs",
                    "query": "SELECT name, enabled FROM msdb.dbo.sysjobs WHERE enabled = 1",
                    "description": "SQL Agent jobs can execute scheduled tasks",
                    "severity": SeverityLevel.MEDIUM,
                },
                {
                    "name": "startup_procedures",
                    "query": """
                        SELECT name FROM sys.procedures 
                        WHERE OBJECTPROPERTY(object_id, 'ExecIsStartup') = 1
                    """,
                    "description": "Startup procedures execute on server start",
                    "severity": SeverityLevel.HIGH,
                },
            ],
            DatabaseType.POSTGRESQL: [
                {
                    "name": "event_triggers",
                    "query": "SELECT evtname, evtowner, evtevent FROM pg_event_trigger",
                    "description": "Event triggers execute on DDL events",
                    "severity": SeverityLevel.MEDIUM,
                },
            ],
            DatabaseType.ORACLE: [
                {
                    "name": "logon_triggers",
                    "query": """
                        SELECT owner, trigger_name FROM dba_triggers 
                        WHERE triggering_event LIKE '%LOGON%'
                    """,
                    "description": "Logon triggers execute on user login",
                    "severity": SeverityLevel.HIGH,
                },
            ],
        }
        
        checks = persistence_checks.get(db_type, [])
        
        for check in checks:
            try:
                result = query_executor(check["query"])
                if result:
                    persistence_findings.append({
                        "name": check["name"],
                        "description": check["description"],
                        "items": result,
                    })
                    
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.PERSISTENCE,
                        sub_category=FindingSubCategory.DATABASE_PERSISTENCE,
                        severity=check["severity"],
                        title=f"Persistence: {check['name']}",
                        description=check["description"],
                        database_type=db_type,
                        evidence=str(result)[:500],
                        recommendation="Review and remove unauthorized persistence mechanisms",
                    )
                    self.findings.append(finding)
            except Exception:
                pass
        
        return persistence_findings
    
    def get_findings(self) -> List[Any]:
        """Get all findings."""
        return self.findings
    
    def clear(self):
        """Clear findings."""
        self.findings.clear()
        self.finding_service.clear()

