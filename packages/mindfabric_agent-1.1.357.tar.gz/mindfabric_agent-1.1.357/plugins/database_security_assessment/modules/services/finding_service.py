"""
Finding Service for Database Security Assessment

Creates standardized security findings.
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from ...proto import (
    DatabaseSecurityFinding,
    DatabaseType,
    FindingCategory,
    FindingSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    MitreReference,
    ComplianceMapping,
    ComplianceFramework,
    ExploitationCommands,
)
from ..databases.database_security_databases import (
    MITRE_MAPPINGS,
    COMPLIANCE_MAPPINGS,
)


class FindingService:
    """Service for creating database security findings."""
    
    def __init__(self):
        self.findings: List[DatabaseSecurityFinding] = []
    
    def create_finding(
        self,
        category: FindingCategory,
        sub_category: FindingSubCategory,
        severity: SeverityLevel,
        title: str,
        description: str,
        database_type: DatabaseType,
        database_name: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        evidence: Optional[str] = None,
        confidence: ConfidenceLevel = ConfidenceLevel.HIGH,
        affected_users: Optional[List[str]] = None,
        affected_objects: Optional[List[str]] = None,
        affected_settings: Optional[List[str]] = None,
        recommendation: Optional[str] = None,
        remediation_steps: Optional[List[str]] = None,
        remediation_sql: Optional[str] = None,
        commands: Optional[ExploitationCommands] = None,
    ) -> DatabaseSecurityFinding:
        """Create a database security finding."""
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(severity, confidence)
        
        # Get MITRE mapping
        mitre = self._get_mitre_mapping(sub_category)
        
        # Get compliance mappings
        compliance = self._get_compliance_mappings(sub_category)
        
        # Determine potential impact
        potential_impact = self._get_potential_impact(category, sub_category, severity)
        
        # Default recommendation if not provided
        if not recommendation:
            recommendation = self._get_default_recommendation(sub_category)
        
        # Generate commands if not provided
        if not commands:
            commands = self._generate_commands(
                sub_category, database_type, host, port, 
                database_name, affected_users, remediation_sql
            )
        
        finding = DatabaseSecurityFinding(
            id=str(uuid.uuid4()),
            category=category,
            sub_category=sub_category,
            severity=severity,
            confidence=confidence,
            database_type=database_type,
            database_name=database_name,
            host=host,
            title=title,
            description=description,
            evidence=evidence,
            affected_users=affected_users or [],
            affected_objects=affected_objects or [],
            affected_settings=affected_settings or [],
            risk_score=risk_score,
            exploitability=self._get_exploitability(severity),
            potential_impact=potential_impact,
            mitre=mitre,
            compliance=compliance,
            recommendation=recommendation,
            remediation_steps=remediation_steps or [],
            remediation_sql=remediation_sql,
            commands=commands,
            discovered_at=datetime.utcnow(),
        )
        
        self.findings.append(finding)
        return finding
    
    def _calculate_risk_score(self, severity: SeverityLevel, confidence: ConfidenceLevel) -> float:
        """Calculate risk score based on severity and confidence."""
        severity_scores = {
            SeverityLevel.CRITICAL: 10.0,
            SeverityLevel.HIGH: 8.0,
            SeverityLevel.MEDIUM: 5.0,
            SeverityLevel.LOW: 3.0,
            SeverityLevel.INFO: 1.0,
        }
        
        confidence_multipliers = {
            ConfidenceLevel.CONFIRMED: 1.0,
            ConfidenceLevel.HIGH: 0.9,
            ConfidenceLevel.MEDIUM: 0.7,
            ConfidenceLevel.LOW: 0.5,
            ConfidenceLevel.TENTATIVE: 0.3,
        }
        
        base_score = severity_scores.get(severity, 5.0)
        multiplier = confidence_multipliers.get(confidence, 0.7)
        
        return round(base_score * multiplier, 1)
    
    def _get_mitre_mapping(self, sub_category: FindingSubCategory) -> Optional[MitreReference]:
        """Get MITRE ATT&CK mapping for finding."""
        mapping = MITRE_MAPPINGS.get(sub_category)
        if mapping:
            tactic, technique = mapping
            return MitreReference(
                tactic=tactic,
                technique=technique,
                url=f"https://attack.mitre.org/techniques/{technique.value.split()[0]}/",
            )
        return None
    
    def _get_compliance_mappings(self, sub_category: FindingSubCategory) -> List[ComplianceMapping]:
        """Get compliance framework mappings for finding."""
        mappings = COMPLIANCE_MAPPINGS.get(sub_category, [])
        result = []
        for m in mappings:
            result.append(ComplianceMapping(
                framework=ComplianceFramework(m["framework"]),
                control_id=m["control"],
                control_name=m["name"],
            ))
        return result
    
    def _get_potential_impact(
        self,
        category: FindingCategory,
        sub_category: FindingSubCategory,
        severity: SeverityLevel,
    ) -> str:
        """Get potential impact description."""
        impact_map = {
            FindingSubCategory.NO_PASSWORD: "Complete database compromise, data theft, data manipulation",
            FindingSubCategory.DEFAULT_CREDENTIALS: "Unauthorized access to database, potential data breach",
            FindingSubCategory.WEAK_PASSWORD: "Brute force attack, unauthorized access",
            FindingSubCategory.EXCESSIVE_PRIVILEGES: "Privilege escalation, unauthorized data access",
            FindingSubCategory.PUBLIC_ACCESS: "Remote exploitation, data exfiltration",
            FindingSubCategory.SQL_INJECTION: "Data breach, database takeover, system compromise",
            FindingSubCategory.COMMAND_INJECTION: "Remote code execution, system compromise",
            FindingSubCategory.UNENCRYPTED_CONNECTION: "Credential interception, data sniffing",
            FindingSubCategory.LOGGING_DISABLED: "Undetected attacks, compliance violation",
            FindingSubCategory.MALICIOUS_TRIGGER: "Data manipulation, backdoor persistence",
            FindingSubCategory.MALICIOUS_PROCEDURE: "Code execution, privilege escalation",
        }
        
        impact = impact_map.get(sub_category)
        if impact:
            return impact
        
        if severity == SeverityLevel.CRITICAL:
            return "Complete database compromise possible"
        elif severity == SeverityLevel.HIGH:
            return "Significant data exposure or system compromise"
        elif severity == SeverityLevel.MEDIUM:
            return "Moderate security risk, potential data exposure"
        else:
            return "Limited security impact"
    
    def _get_exploitability(self, severity: SeverityLevel) -> str:
        """Get exploitability rating based on severity."""
        exploitability_map = {
            SeverityLevel.CRITICAL: "Easy",
            SeverityLevel.HIGH: "Moderate",
            SeverityLevel.MEDIUM: "Moderate",
            SeverityLevel.LOW: "Difficult",
            SeverityLevel.INFO: "N/A",
        }
        return exploitability_map.get(severity, "Moderate")
    
    def _get_default_recommendation(self, sub_category: FindingSubCategory) -> str:
        """Get default recommendation for finding type."""
        recommendations = {
            FindingSubCategory.NO_PASSWORD: "Configure strong authentication for all database accounts",
            FindingSubCategory.DEFAULT_CREDENTIALS: "Change default credentials immediately",
            FindingSubCategory.WEAK_PASSWORD: "Implement strong password policy and change weak passwords",
            FindingSubCategory.EXCESSIVE_PRIVILEGES: "Apply principle of least privilege",
            FindingSubCategory.PUBLIC_ACCESS: "Restrict database access to authorized networks only",
            FindingSubCategory.UNENCRYPTED_CONNECTION: "Enable TLS/SSL encryption for all connections",
            FindingSubCategory.LOGGING_DISABLED: "Enable comprehensive audit logging",
            FindingSubCategory.UNSAFE_FUNCTIONS: "Disable dangerous functions and features",
            FindingSubCategory.INSECURE_SETTING: "Update configuration to secure settings",
        }
        return recommendations.get(
            sub_category,
            "Validate listener exposure, authentication mode, role grants, and audit logging for this database engine; apply vendor hardening, then re-run the scan to confirm closure.",
        )
    
    def _generate_commands(
        self,
        sub_category: FindingSubCategory,
        database_type: DatabaseType,
        host: Optional[str],
        port: Optional[int],
        database_name: Optional[str],
        affected_users: Optional[List[str]],
        remediation_sql: Optional[str],
    ) -> Optional[ExploitationCommands]:
        """Generate exploitation/verification commands for the finding."""
        commands_list = []
        description = ""
        server = f"{host}:{port}" if host and port else host
        
        # Database-specific client commands
        db_clients = {
            DatabaseType.POSTGRESQL: "psql",
            DatabaseType.MYSQL: "mysql",
            DatabaseType.MARIADB: "mysql",
            DatabaseType.MSSQL: "sqlcmd",
            DatabaseType.MONGODB: "mongosh",
            DatabaseType.REDIS: "redis-cli",
            DatabaseType.ORACLE: "sqlplus",
        }
        client = db_clients.get(database_type, "db-client")
        
        if sub_category == FindingSubCategory.NO_PASSWORD:
            description = "Verify no-password access and exploit"
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# Connect without password",
                    f"psql -h {host} -p {port or 5432} -U postgres -d {database_name or 'postgres'}",
                    f"# List all databases",
                    f"\\list",
                    f"# List all users",
                    f"\\du",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# Connect without password",
                    f"mysql -h {host} -P {port or 3306} -u root",
                    f"# Show databases",
                    f"SHOW DATABASES;",
                    f"# Show users",
                    f"SELECT user, host FROM mysql.user;",
                ]
            elif database_type == DatabaseType.REDIS:
                commands_list = [
                    f"# Connect to Redis without auth",
                    f"redis-cli -h {host} -p {port or 6379}",
                    f"# Get all keys",
                    f"KEYS *",
                    f"# Get server info",
                    f"INFO",
                ]
            elif database_type == DatabaseType.MONGODB:
                commands_list = [
                    f"# Connect to MongoDB without auth",
                    f"mongosh --host {host} --port {port or 27017}",
                    f"# List databases",
                    f"show dbs",
                    f"# List collections",
                    f"show collections",
                ]
                
        elif sub_category == FindingSubCategory.DEFAULT_CREDENTIALS:
            description = "Verify default credentials access"
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# Try default postgres credentials",
                    f"PGPASSWORD=postgres psql -h {host} -p {port or 5432} -U postgres -c '\\conninfo'",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# Try default root credentials",
                    f"mysql -h {host} -P {port or 3306} -u root -proot -e 'SELECT VERSION();'",
                    f"mysql -h {host} -P {port or 3306} -u root -p'' -e 'SELECT VERSION();'",
                ]
                
        elif sub_category == FindingSubCategory.WEAK_PASSWORD:
            description = "Password weakness verification"
            commands_list = [
                f"# Use password cracking tools like hashcat or john",
                f"# Extract hashes and attempt offline cracking",
                f"# For MySQL/MariaDB:",
                f"mysql -h {host} -P {port or 3306} -u root -p -e 'SELECT user, authentication_string FROM mysql.user;'",
            ]
            
        elif sub_category == FindingSubCategory.EXCESSIVE_PRIVILEGES:
            description = "Verify excessive privileges"
            users_str = ", ".join(f"'{u}'" for u in (affected_users or ["user"])) 
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# Check user privileges",
                    f"SELECT usename, usesuper, usecreatedb, usecreaterole FROM pg_user WHERE usename IN ({users_str});",
                    f"# Check role memberships",
                    f"SELECT r.rolname, m.rolname as member FROM pg_roles r JOIN pg_auth_members am ON r.oid = am.roleid JOIN pg_roles m ON am.member = m.oid;",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# Show grants for users",
                    f"SHOW GRANTS FOR {affected_users[0] if affected_users else 'root'}@'%';",
                    f"# Check global privileges",
                    f"SELECT * FROM mysql.user WHERE User IN ({users_str});",
                ]
                
        elif sub_category == FindingSubCategory.SQL_INJECTION:
            description = "SQL Injection exploitation"
            commands_list = [
                f"# Use sqlmap for automated exploitation",
                f"sqlmap -u 'http://{host}/vulnerable_endpoint?id=1' --dbs",
                f"# Manual injection test",
                f"curl -X POST 'http://{host}/api' -d \"id=1' OR '1'='1\"",
            ]
            
        elif sub_category == FindingSubCategory.UNENCRYPTED_CONNECTION:
            description = "Verify unencrypted connection and sniff traffic"
            commands_list = [
                f"# Check for TLS support",
                f"openssl s_client -connect {host}:{port or 5432}",
                f"# Capture database traffic",
                f"tcpdump -i any -w db_traffic.pcap host {host} and port {port or 5432}",
                f"# For MySQL/MariaDB",
                f"mysql -h {host} -P {port or 3306} -u root -p --ssl-mode=DISABLED -e 'SHOW STATUS LIKE \"%ssl%\";'",
            ]
            
        elif sub_category == FindingSubCategory.LOGGING_DISABLED:
            description = "Verify audit logging is disabled"
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# Check logging settings",
                    f"SHOW log_statement;",
                    f"SHOW log_connections;",
                    f"SHOW log_disconnections;",
                    f"# Enable logging:",
                    f"ALTER SYSTEM SET log_statement = 'all';",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# Check audit logging",
                    f"SHOW VARIABLES LIKE '%audit%';",
                    f"SHOW VARIABLES LIKE 'general_log%';",
                    f"# Enable general log:",
                    f"SET GLOBAL general_log = 'ON';",
                ]
                
        elif sub_category == FindingSubCategory.MALICIOUS_TRIGGER:
            description = "Detect and remove malicious triggers"
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# List all triggers",
                    f"SELECT trigger_name, event_manipulation, event_object_table, action_statement FROM information_schema.triggers;",
                    f"# Drop suspicious trigger",
                    f"DROP TRIGGER IF EXISTS suspicious_trigger ON target_table;",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# List all triggers",
                    f"SELECT * FROM information_schema.triggers;",
                    f"# Drop suspicious trigger",
                    f"DROP TRIGGER IF EXISTS suspicious_trigger;",
                ]
                
        elif sub_category == FindingSubCategory.MALICIOUS_PROCEDURE:
            description = "Detect and remove malicious stored procedures"
            if database_type == DatabaseType.POSTGRESQL:
                commands_list = [
                    f"# List all functions",
                    f"SELECT proname, prosrc FROM pg_proc WHERE pronamespace = 'public'::regnamespace;",
                    f"# Drop suspicious function",
                    f"DROP FUNCTION IF EXISTS suspicious_function();",
                ]
            elif database_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                commands_list = [
                    f"# List all procedures",
                    f"SELECT ROUTINE_NAME, ROUTINE_DEFINITION FROM information_schema.routines WHERE ROUTINE_TYPE='PROCEDURE';",
                    f"# Drop suspicious procedure",
                    f"DROP PROCEDURE IF EXISTS suspicious_procedure;",
                ]
        
        # Add remediation SQL if provided
        if remediation_sql:
            commands_list.append(f"# Remediation SQL:")
            commands_list.append(remediation_sql)
        
        if not commands_list:
            # Default commands
            commands_list = [
                f"# Connect to database",
                f"{client} -h {host} -p {port}",
                f"# Run security assessment queries specific to finding",
            ]
            description = f"Verify {sub_category.value}"
        
        return ExploitationCommands(
            server=server,
            commands=commands_list,
            description=description
        )
    
    def get_findings(self) -> List[DatabaseSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_critical_findings(self) -> List[DatabaseSecurityFinding]:
        """Get critical severity findings."""
        return [f for f in self.findings if f.severity == SeverityLevel.CRITICAL]
    
    def clear(self):
        """Clear all findings."""
        self.findings.clear()

