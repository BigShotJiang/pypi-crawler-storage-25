"""
Database Discovery Service

Discovers databases in the network and enumerates their configurations.
"""

import socket
import re
import os
from typing import Any, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

logger = logging.getLogger(__name__)

from ...proto import (
    DatabaseType,
    DatabaseConnection,
    SeverityLevel,
    FindingCategory,
    FindingSubCategory,
)
from ..databases.database_security_databases import DEFAULT_PORTS, DEFAULT_CREDENTIALS
from .finding_service import FindingService


# =============================================================================
# Database Fingerprints
# =============================================================================

DATABASE_FINGERPRINTS = {
    DatabaseType.POSTGRESQL: {
        "banner_patterns": [
            r"PostgreSQL",
            r"PGSQL",
            r"psql",
        ],
        "probe": b"\x00\x00\x00\x08\x04\xd2\x16\x2f",  # SSL request
        "response_pattern": r"^[SNE]",
    },
    DatabaseType.MYSQL: {
        "banner_patterns": [
            r"mysql_native_password",
            r"MariaDB",
            r"MySQL",
            r"\x4a\x00\x00\x00\x0a",  # MySQL greeting
        ],
        "probe": None,  # MySQL sends banner on connect
    },
    DatabaseType.MSSQL: {
        "banner_patterns": [
            r"Microsoft SQL Server",
            r"MSSQL",
            r"SQLServer",
        ],
        "probe": b"\x12\x01\x00\x34\x00\x00",  # TDS prelogin
    },
    DatabaseType.MONGODB: {
        "banner_patterns": [
            r"MongoDB",
            r"ismaster",
        ],
        "probe": b"\x3e\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\xd4\x07\x00\x00\x00\x00\x00\x00admin.$cmd\x00\x00\x00\x00\x00\xff\xff\xff\xff\x1a\x00\x00\x00\x10ismaster\x00\x01\x00\x00\x00\x00",
    },
    DatabaseType.REDIS: {
        "banner_patterns": [
            r"REDIS",
            r"\+PONG",
            r"-NOAUTH",
            r"-ERR",
        ],
        "probe": b"*1\r\n$4\r\nPING\r\n",
    },
    DatabaseType.ORACLE: {
        "banner_patterns": [
            r"Oracle",
            r"TNS",
            r"ORA-",
        ],
        "probe": None,  # Complex TNS handshake
    },
    DatabaseType.CASSANDRA: {
        "banner_patterns": [
            r"cassandra",
            r"CQL",
        ],
    },
    DatabaseType.ELASTICSEARCH: {
        "banner_patterns": [
            r"elasticsearch",
            r'"cluster_name"',
            r'"tagline"\s*:\s*"You Know, for Search"',
        ],
        "http_probe": True,
    },
}


# =============================================================================
# Version Detection Queries
# =============================================================================

VERSION_QUERIES = {
    DatabaseType.POSTGRESQL: "SELECT version()",
    DatabaseType.MYSQL: "SELECT version()",
    DatabaseType.MSSQL: "SELECT @@VERSION",
    DatabaseType.ORACLE: "SELECT * FROM v$version WHERE banner LIKE 'Oracle%'",
    DatabaseType.MONGODB: "db.version()",
    DatabaseType.SQLITE: "SELECT sqlite_version()",
}


# =============================================================================
# Enumeration Queries
# =============================================================================

ENUMERATION_QUERIES = {
    DatabaseType.POSTGRESQL: {
        "users": "SELECT usename, usesuperuser, usecreatedb, usecreaterole, usebypassrls FROM pg_user",
        "databases": "SELECT datname, datdba::regrole, encoding, datctype FROM pg_database",
        "schemas": "SELECT schema_name FROM information_schema.schemata",
        "tables": "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog', 'information_schema')",
        "functions": "SELECT proname, prosrc FROM pg_proc WHERE pronamespace = 'public'::regnamespace",
        "extensions": "SELECT extname, extversion FROM pg_extension",
        "triggers": "SELECT trigger_name, event_object_table, action_statement FROM information_schema.triggers",
        "roles": "SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin FROM pg_roles",
    },
    DatabaseType.MYSQL: {
        "users": "SELECT User, Host, authentication_string, plugin FROM mysql.user",
        "databases": "SHOW DATABASES",
        "tables": "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('information_schema', 'mysql', 'performance_schema', 'sys')",
        "procedures": "SELECT routine_name, routine_schema, routine_type FROM information_schema.routines",
        "triggers": "SELECT trigger_name, event_object_table, action_statement FROM information_schema.triggers",
        "grants": "SHOW GRANTS",
        "variables": "SHOW VARIABLES",
    },
    DatabaseType.MSSQL: {
        "users": "SELECT name, type_desc, is_disabled FROM sys.sql_logins",
        "databases": "SELECT name, state_desc, is_encrypted FROM sys.databases",
        "tables": "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES",
        "procedures": "SELECT name, type_desc FROM sys.procedures",
        "triggers": "SELECT name, type_desc FROM sys.triggers",
        "linked_servers": "SELECT name, provider, data_source FROM sys.servers WHERE is_linked = 1",
        "jobs": "SELECT name, enabled, description FROM msdb.dbo.sysjobs",
        "server_principals": "SELECT name, type_desc, is_disabled FROM sys.server_principals",
    },
}


class DatabaseDiscoveryService:
    """Service for discovering and enumerating databases."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.finding_service = FindingService()
        self.discovered_databases: List[DatabaseConnection] = []
        self.findings: List[Any] = []
    
    def scan_network(
        self,
        targets: List[str],
        ports: List[int] = None,
        timeout: float = 3.0,
        threads: int = 10,
    ) -> List[DatabaseConnection]:
        """
        Scan network for databases.
        
        Args:
            targets: List of IP addresses or CIDR ranges
            ports: Ports to scan (defaults to all database ports)
            timeout: Connection timeout
            threads: Number of concurrent threads
            
        Returns:
            List of discovered databases
        """
        if ports is None:
            ports = list(DEFAULT_PORTS.values())
        
        # Expand CIDR ranges to IP list
        ip_list = self._expand_targets(targets)
        
        # Create scan tasks
        scan_tasks = [(ip, port) for ip in ip_list for port in ports]
        
        discovered = []
        
        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = {
                executor.submit(self._probe_host, ip, port, timeout): (ip, port)
                for ip, port in scan_tasks
            }
            
            for future in as_completed(futures):
                result = future.result()
                if result:
                    discovered.append(result)
                    self.discovered_databases.append(result)
        
        return discovered
    
    def _expand_targets(self, targets: List[str]) -> List[str]:
        """Expand CIDR ranges to IP list."""
        ip_list = []
        
        for target in targets:
            if "/" in target:
                # CIDR range - simplified expansion
                try:
                    base_ip, prefix = target.split("/")
                    prefix = int(prefix)
                    
                    if prefix >= 24:
                        # Only expand /24 and smaller
                        parts = base_ip.split(".")
                        base = ".".join(parts[:3])
                        num_hosts = 2 ** (32 - prefix)
                        start = int(parts[3])
                        
                        for i in range(min(num_hosts, 256)):
                            ip_list.append(f"{base}.{(start + i) % 256}")
                    else:
                        ip_list.append(base_ip)
                except Exception:
                    ip_list.append(target)
            else:
                ip_list.append(target)
        
        return ip_list
    
    def _probe_host(
        self,
        host: str,
        port: int,
        timeout: float,
    ) -> Optional[DatabaseConnection]:
        """Probe a host:port for database service."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((host, port))
            
            # Determine database type from port
            db_type = self._port_to_db_type(port)
            
            # Try to fingerprint
            fingerprint = DATABASE_FINGERPRINTS.get(db_type, {})
            
            # Send probe if available
            banner = ""
            if fingerprint.get("probe"):
                sock.send(fingerprint["probe"])
            
            # Receive banner
            try:
                banner = sock.recv(1024).decode('utf-8', errors='ignore')
            except Exception:
                pass
            
            sock.close()
            
            # Confirm database type from banner
            confirmed_type = self._identify_from_banner(banner, db_type)
            
            # Create connection info
            return DatabaseConnection(
                host=host,
                port=port,
                database_type=confirmed_type,
                ssl_enabled=False,
                version=self._extract_version(banner),
            )
        except (socket.timeout, ConnectionRefusedError, OSError):
            return None
    
    def _port_to_db_type(self, port: int) -> DatabaseType:
        """Get database type from port number."""
        for db_type, default_port in DEFAULT_PORTS.items():
            if port == default_port:
                return db_type
        return DatabaseType.UNKNOWN
    
    def _identify_from_banner(self, banner: str, default: DatabaseType) -> DatabaseType:
        """Identify database type from banner."""
        for db_type, fingerprint in DATABASE_FINGERPRINTS.items():
            patterns = fingerprint.get("banner_patterns", [])
            for pattern in patterns:
                if re.search(pattern, banner, re.I):
                    return db_type
        return default
    
    def _extract_version(self, banner: str) -> Optional[str]:
        """Extract version from banner."""
        # Common version patterns
        patterns = [
            r"(\d+\.\d+\.\d+[-\w]*)",
            r"version\s*[:\s]*(\d+\.\d+)",
            r"v(\d+\.\d+)",
        ]
        
        for pattern in patterns:
            match = re.search(pattern, banner, re.I)
            if match:
                return match.group(1)
        return None
    
    def scan_local(self) -> List[DatabaseConnection]:
        """Scan for locally running databases."""
        discovered = []
        seen_ports = set()  # Track ports to avoid duplicates
        
        # Check for running processes
        processes = self._get_database_processes()
        
        for proc in processes:
            db_type = proc["type"]
            # Try to get port from process command line first
            port = proc.get("port")
            
            # If port not found in command line, try to detect from listening ports
            if not port or port == 0:
                port = self._get_listening_port_for_process(db_type)
            
            # Fallback to default port for this database type
            if not port or port == 0:
                port = DEFAULT_PORTS.get(db_type, 0)
            
            # Skip if we still don't have a valid port
            if not port or port == 0:
                continue
            
            # Skip duplicates
            port_key = (db_type, port)
            if port_key in seen_ports:
                continue
            seen_ports.add(port_key)
            
            conn = DatabaseConnection(
                host="localhost",
                port=port,
                database_type=db_type,
                ssl_enabled=False,
            )
            discovered.append(conn)
            self.discovered_databases.append(conn)
        
        # Also check listening ports directly for common database ports
        listening_ports = self._get_listening_ports()
        for port, db_type in listening_ports.items():
            port_key = (db_type, port)
            if port_key not in seen_ports:
                seen_ports.add(port_key)
                conn = DatabaseConnection(
                    host="localhost",
                    port=port,
                    database_type=db_type,
                    ssl_enabled=False,
                )
                discovered.append(conn)
                self.discovered_databases.append(conn)
        
        # Check config files for database connections
        config_findings = self._scan_config_files()
        self.findings.extend(config_findings)
        
        return discovered
    
    def _get_database_processes(self) -> List[Dict[str, Any]]:
        """Get running database processes."""
        processes = []
        
        try:
            process_patterns = {
                DatabaseType.POSTGRESQL: [r"postgres", r"postgresql", r"pg_ctl", r"postmaster", r"/usr/lib/postgresql"],
                DatabaseType.MYSQL: [r"mysqld", r"mariadbd", r"mysql"],
                DatabaseType.MONGODB: [r"mongod", r"mongos"],
                DatabaseType.REDIS: [r"redis-server", r"redis"],
                DatabaseType.MSSQL: [r"sqlservr"],
                DatabaseType.ORACLE: [r"oracle", r"tnslsnr"],
                DatabaseType.CASSANDRA: [r"cassandra"],
                DatabaseType.ELASTICSEARCH: [r"elasticsearch", r"java.*elasticsearch"],
            }
            
            seen_processes = set()  # Avoid duplicates

            try:
                import psutil  # type: ignore
            except Exception:
                return processes

            for proc in psutil.process_iter(["pid", "name", "exe", "cmdline", "username"]):
                try:
                    info = proc.info or {}
                    name = info.get("name") or ""
                    exe = info.get("exe") or ""
                    cmdline_list = info.get("cmdline") or []
                    cmdline = " ".join(cmdline_list) if isinstance(cmdline_list, list) else str(cmdline_list)
                    line = f"{name} {exe} {cmdline}"

                    for db_type, patterns in process_patterns.items():
                        if any(re.search(p, line, re.I) for p in patterns):
                            # Extract port if visible in command line
                            port_match = re.search(r"-p\\s*(\\d+)|--port[=\\s]+(\\d+)|:(\\d+)", line)
                            port = None
                            if port_match:
                                port = int(port_match.group(1) or port_match.group(2) or port_match.group(3))

                            proc_key = (db_type, port)
                            if proc_key in seen_processes:
                                break
                            seen_processes.add(proc_key)
                            processes.append({
                                "type": db_type,
                                "command": cmdline.strip()[:200] if cmdline else name,
                                "port": port,
                            })
                            break
                except Exception:
                    continue
        except Exception:
            pass
        
        return processes
    
    def _get_listening_port_for_process(self, db_type: DatabaseType) -> Optional[int]:
        """Get listening port for a database type by checking netstat/ss."""
        default_port = DEFAULT_PORTS.get(db_type)
        if not default_port:
            return None

        # Best-effort: if the default port for this DB type is currently listening, return it.
        try:
            listening = self._get_listening_ports()
            return default_port if default_port in listening else None
        except Exception:
            return None
    
    def _get_listening_ports(self) -> Dict[int, DatabaseType]:
        """Get all listening ports and map them to database types."""
        port_map = {}
        
        # Reverse mapping: port -> db_type
        port_to_db = {port: db_type for db_type, port in DEFAULT_PORTS.items()}

        try:
            import psutil  # type: ignore
        except Exception:
            return port_map

        try:
            for conn in psutil.net_connections(kind="inet"):
                try:
                    if not conn.laddr:
                        continue
                    status = getattr(conn, "status", None)
                    if status and str(status).upper() != "LISTEN":
                        continue
                    port = int(getattr(conn.laddr, "port", 0) or 0)
                    if port in port_to_db:
                        port_map[port] = port_to_db[port]
                except Exception:
                    continue
        except Exception:
            pass

        return port_map
    
    def _scan_config_files(self) -> List[Any]:
        """Scan configuration files for database connections."""
        findings = []
        
        config_paths = [
            # Application configs
            "/etc/app/database.yml",
            "/etc/app/config.yml",
            "~/.my.cnf",
            "~/.pgpass",
            "~/.mongorc.js",
            
            # Common locations
            "/var/www/*/config/*",
            "/opt/*/config/*",
            "/home/*/.*rc",
        ]
        
        connection_patterns = [
            # Database URLs
            (r"(postgres(ql)?|mysql|mongodb|redis|oracle|mssql)://[^\s\"']+", "Database connection string"),
            
            # Host/port patterns
            (r"(?:db_?host|database_?host)\s*[:=]\s*['\"]?([^\s'\"]+)", "Database host configuration"),
            (r"(?:db_?port|database_?port)\s*[:=]\s*['\"]?(\d+)", "Database port configuration"),
            
            # Credential patterns
            (r"(?:db_?password|database_?password)\s*[:=]\s*['\"]?([^\s'\"]+)", "Database password in config"),
        ]
        
        for path_pattern in config_paths:
            expanded_path = os.path.expanduser(path_pattern)
            
            # Use glob for wildcards
            if "*" in expanded_path:
                import glob
                paths = glob.glob(expanded_path)
            else:
                paths = [expanded_path] if os.path.exists(expanded_path) else []
            
            for path in paths:
                try:
                    with open(path, 'r') as f:
                        content = f.read()
                    
                    for pattern, desc in connection_patterns:
                        matches = re.findall(pattern, content, re.I)
                        if matches:
                            finding = self.finding_service.create_finding(
                                category=FindingCategory.DISCOVERY,
                                sub_category=FindingSubCategory.CREDENTIALS_IN_CONFIG,
                                severity=SeverityLevel.HIGH if "password" in pattern else SeverityLevel.INFO,
                                title=desc,
                                description=f"Found {desc.lower()} in {path}",
                                evidence=f"File: {path}\nMatches: {matches[:3]}",
                                recommendation="Move credentials to secure secret storage",
                            )
                            findings.append(finding)
                except (IOError, PermissionError):
                    pass
        
        return findings
    
    def enumerate_database(
        self,
        connection: DatabaseConnection,
        query_executor: callable,
    ) -> Dict[str, Any]:
        """
        Enumerate database objects.
        
        Args:
            connection: Database connection info
            query_executor: Function to execute queries
            
        Returns:
            Dictionary with enumerated objects
        """
        results = {
            "version": None,
            "users": [],
            "databases": [],
            "tables": [],
            "procedures": [],
            "triggers": [],
            "findings": [],
        }
        
        db_type = connection.database_type
        
        # Get version
        version_query = VERSION_QUERIES.get(db_type)
        if version_query:
            try:
                version = query_executor(version_query)
                results["version"] = version
            except Exception:
                pass
        
        # Run enumeration queries
        queries = ENUMERATION_QUERIES.get(db_type, {})
        
        for query_name, query in queries.items():
            try:
                result = query_executor(query)
                results[query_name] = result
            except Exception as e:
                results["findings"].append({
                    "query": query_name,
                    "error": str(e),
                })
        
        # Check for sensitive findings during enumeration
        sensitive_findings = self._analyze_enumeration_results(results, db_type)
        results["findings"].extend(sensitive_findings)
        self.findings.extend(sensitive_findings)
        
        return results
    
    def _analyze_enumeration_results(
        self,
        results: Dict[str, Any],
        db_type: DatabaseType,
    ) -> List[Any]:
        """Analyze enumeration results for security issues."""
        findings = []
        
        # Check for public databases
        if db_type == DatabaseType.MSSQL:
            linked_servers = results.get("linked_servers", [])
            if linked_servers:
                finding = self.finding_service.create_finding(
                    category=FindingCategory.CONFIGURATION,
                    sub_category=FindingSubCategory.LINKED_SERVERS,
                    severity=SeverityLevel.HIGH,
                    title="Linked servers detected",
                    description=f"Found {len(linked_servers)} linked servers",
                    database_type=db_type,
                    evidence=str(linked_servers)[:500],
                    recommendation="Review linked server configurations for lateral movement risk",
                )
                findings.append(finding)
        
        # Check for dangerous triggers
        triggers = results.get("triggers", [])
        if triggers:
            finding = self.finding_service.create_finding(
                category=FindingCategory.PERSISTENCE,
                sub_category=FindingSubCategory.DATABASE_TRIGGERS,
                severity=SeverityLevel.MEDIUM,
                title=f"Database triggers found ({len(triggers)})",
                description="Review triggers for potential persistence mechanisms",
                database_type=db_type,
                evidence=str(triggers)[:500],
            )
            findings.append(finding)
        
        return findings
    
    def get_findings(self) -> List[Any]:
        """Get all findings."""
        return self.findings
    
    def get_discovered_databases(self) -> List[DatabaseConnection]:
        """Get discovered databases."""
        return self.discovered_databases
    
    def clear(self):
        """Clear all data."""
        self.findings.clear()
        self.discovered_databases.clear()
        self.finding_service.clear()

