"""
Database Scanner Service

Core scanning functionality for database security assessment.
"""

import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

from ...proto import (
    DatabaseType,
    DatabaseConnection,
    DatabaseUser,
    DatabaseObject,
    SeverityLevel,
    ConfidenceLevel,
    FindingCategory,
    FindingSubCategory,
    ScanTarget,
)
from ..databases.database_security_databases import (
    DEFAULT_CREDENTIALS,
    SECURITY_CHECKS,
    DANGEROUS_PRIVILEGES,
    DEFAULT_PORTS,
)
from .finding_service import FindingService


class DatabaseScannerService:
    """Service for scanning database security."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.finding_service = FindingService()
        self.connections: List[DatabaseConnection] = []
        self.users: List[DatabaseUser] = []
        self.objects: List[DatabaseObject] = []
        self._db_clients: Dict[str, Any] = {}
    
    async def scan_target(self, target: ScanTarget) -> Dict[str, Any]:
        """
        Scan a database target for security issues.
        
        Returns dict with:
        - connection: DatabaseConnection info
        - users: List of discovered users
        - objects: List of discovered objects
        - findings: List of security findings
        """
        results = {
            "connection": None,
            "users": [],
            "objects": [],
            "findings": [],
            "errors": [],
        }
        
        # Detect database type if not specified
        db_type = target.database_type
        if not db_type:
            db_type = self._detect_database_type(target.host, target.port)
        
        if db_type == DatabaseType.UNKNOWN:
            results["errors"].append(f"Could not detect database type for {target.host}:{target.port}")
            return results
        
        # Test connection
        connection = await self._test_connection(target, db_type)
        results["connection"] = connection
        self.connections.append(connection)
        
        # Check for default credentials
        if target.username is None:
            await self._check_default_credentials(target, db_type, results)
        
        # Run security checks
        await self._run_security_checks(target, db_type, results)
        
        # Enumerate users
        users = await self._enumerate_users(target, db_type)
        results["users"] = users
        self.users.extend(users)
        
        # Check user privileges
        await self._check_user_privileges(users, db_type, target, results)
        
        # Enumerate objects
        objects = await self._enumerate_objects(target, db_type)
        results["objects"] = objects
        self.objects.extend(objects)
        
        # Check for persistence mechanisms
        await self._check_persistence(target, db_type, results)
        
        return results
    
    def _detect_database_type(self, host: str, port: int) -> DatabaseType:
        """Detect database type from port number."""
        for db_type, default_port in DEFAULT_PORTS.items():
            if port == default_port:
                return db_type
        return DatabaseType.UNKNOWN
    
    async def _test_connection(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
    ) -> DatabaseConnection:
        """Test database connection."""
        # This would actually attempt connection
        # For now, return connection info based on target
        return DatabaseConnection(
            host=target.host,
            port=target.port,
            database_type=db_type,
            database_name=target.database_name,
            username=target.username,
            ssl_enabled=target.ssl_cert is not None,
            ssl_verified=False,
        )
    
    async def _check_default_credentials(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
        results: Dict[str, Any],
    ):
        """Check for default credentials."""
        default_creds = DEFAULT_CREDENTIALS.get(db_type, [])
        
        for creds in default_creds:
            username = creds["username"]
            password = creds["password"]
            
            # Actually test connection with these credentials
            if await self._test_credentials(target, db_type, username, password):
                finding = self.finding_service.create_finding(
                    category=FindingCategory.AUTHENTICATION,
                    sub_category=FindingSubCategory.DEFAULT_CREDENTIALS,
                    severity=SeverityLevel.CRITICAL,
                    title=f"Default credentials detected for {db_type.value}",
                    description=f"Database accepts default credentials: username='{username}'",
                    database_type=db_type,
                    database_name=target.database_name,
                    host=target.host,
                    port=target.port,
                    evidence=f"Successfully authenticated with {username}:{password if password else '(no password)'}",
                    affected_users=[username],
                    recommendation="Change default credentials immediately",
                    remediation_steps=[
                        f"Change password for user '{username}'",
                        "Implement strong password policy",
                        "Disable or remove default accounts if not needed",
                    ],
                )
                results["findings"].append(finding)
                # Stop after first successful credential test to avoid duplicate findings
                break
    
    async def _test_credentials(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
        username: str,
        password: str,
    ) -> bool:
        """Test if credentials are valid."""
        try:
            if db_type == DatabaseType.POSTGRESQL:
                try:
                    import psycopg2
                    conn = psycopg2.connect(
                        host=target.host,
                        port=target.port,
                        user=username,
                        password=password,
                        database=target.database_name or "postgres",
                        connect_timeout=5,
                    )
                    conn.close()
                    return True
                except Exception:
                    return False
            elif db_type in [DatabaseType.MYSQL, DatabaseType.MARIADB]:
                try:
                    import pymysql
                    conn = pymysql.connect(
                        host=target.host,
                        port=target.port or 3306,
                        user=username,
                        password=password,
                        database=target.database_name,
                        connect_timeout=5,
                    )
                    conn.close()
                    return True
                except Exception:
                    return False
            elif db_type == DatabaseType.MONGODB:
                try:
                    import pymongo
                    client = pymongo.MongoClient(
                        host=target.host,
                        port=target.port or 27017,
                        username=username,
                        password=password,
                        serverSelectionTimeoutMS=5000,
                    )
                    client.server_info()  # Test connection
                    client.close()
                    return True
                except Exception:
                    return False
            elif db_type == DatabaseType.REDIS:
                try:
                    import redis
                    r = redis.Redis(
                        host=target.host,
                        port=target.port or 6379,
                        password=password if password else None,
                        socket_timeout=5,
                        socket_connect_timeout=5,
                    )
                    r.ping()
                    return True
                except Exception:
                    return False
            else:
                # For other database types, try generic connection test
                return False
        except Exception as e:
            # If any import or connection error, return False
            return False
    
    async def _run_security_checks(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
        results: Dict[str, Any],
    ):
        """Run database-specific security checks."""
        checks = SECURITY_CHECKS.get(db_type, [])
        
        for check in checks:
            # Would execute check_sql or check_command
            # Simulating detection of issues
            finding = await self._execute_check(target, db_type, check)
            if finding:
                results["findings"].append(finding)
    
    async def _execute_check(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
        check: Dict[str, Any],
    ) -> Optional[Any]:
        """Execute a security check."""
        # This would execute the actual check
        # Placeholder implementation
        return None
    
    async def _enumerate_users(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
    ) -> List[DatabaseUser]:
        """Enumerate database users."""
        users = []
        
        # Queries by database type
        queries = {
            DatabaseType.POSTGRESQL: "SELECT usename, usesuperuser, usecreatedb, usecreaterole FROM pg_user",
            DatabaseType.MYSQL: "SELECT User, Host FROM mysql.user",
            DatabaseType.MSSQL: "SELECT name, is_disabled FROM sys.sql_logins",
        }
        
        # Would execute query and return users
        # Placeholder
        return users
    
    async def _check_user_privileges(
        self,
        users: List[DatabaseUser],
        db_type: DatabaseType,
        target: ScanTarget,
        results: Dict[str, Any],
    ):
        """Check for excessive user privileges."""
        dangerous_privs = DANGEROUS_PRIVILEGES.get(db_type, [])
        
        for user in users:
            for priv in dangerous_privs:
                if priv["privilege"] in user.privileges or priv["privilege"] in user.roles:
                    finding = self.finding_service.create_finding(
                        category=FindingCategory.AUTHORIZATION,
                        sub_category=FindingSubCategory.EXCESSIVE_PRIVILEGES,
                        severity=priv["severity"],
                        title=f"Dangerous privilege: {priv['privilege']}",
                        description=f"User '{user.username}' has dangerous privilege: {priv['description']}",
                        database_type=db_type,
                        database_name=target.database_name,
                        host=target.host,
                        evidence=f"User '{user.username}' has {priv['privilege']}",
                        affected_users=[user.username],
                        recommendation="Review and revoke unnecessary privileges",
                    )
                    results["findings"].append(finding)
    
    async def _enumerate_objects(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
    ) -> List[DatabaseObject]:
        """Enumerate database objects."""
        objects = []
        # Would query database schema
        return objects
    
    async def _check_persistence(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
        results: Dict[str, Any],
    ):
        """Check for persistence mechanisms (triggers, jobs, procedures)."""
        
        # Check for triggers
        triggers = await self._get_triggers(target, db_type)
        for trigger in triggers:
            # Analyze trigger for suspicious patterns
            if self._is_suspicious_trigger(trigger):
                finding = self.finding_service.create_finding(
                    category=FindingCategory.PERSISTENCE,
                    sub_category=FindingSubCategory.MALICIOUS_TRIGGER,
                    severity=SeverityLevel.HIGH,
                    title=f"Suspicious trigger detected: {trigger.get('name')}",
                    description="Trigger contains potentially malicious code patterns",
                    database_type=db_type,
                    database_name=target.database_name,
                    host=target.host,
                    evidence=f"Trigger: {trigger.get('name')} on table {trigger.get('table')}",
                    affected_objects=[trigger.get("name")],
                    recommendation="Review trigger code and remove if unauthorized",
                )
                results["findings"].append(finding)
        
        # Check for scheduled jobs
        jobs = await self._get_jobs(target, db_type)
        for job in jobs:
            if self._is_suspicious_job(job):
                finding = self.finding_service.create_finding(
                    category=FindingCategory.PERSISTENCE,
                    sub_category=FindingSubCategory.MALICIOUS_JOB,
                    severity=SeverityLevel.HIGH,
                    title=f"Suspicious scheduled job: {job.get('name')}",
                    description="Scheduled job may be used for persistence",
                    database_type=db_type,
                    database_name=target.database_name,
                    host=target.host,
                    evidence=f"Job: {job.get('name')}",
                    affected_objects=[job.get("name")],
                    recommendation="Review job and disable if unauthorized",
                )
                results["findings"].append(finding)
    
    async def _get_triggers(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
    ) -> List[Dict[str, Any]]:
        """Get database triggers."""
        # Would query for triggers
        return []
    
    async def _get_jobs(
        self,
        target: ScanTarget,
        db_type: DatabaseType,
    ) -> List[Dict[str, Any]]:
        """Get scheduled jobs."""
        # Would query for jobs
        return []
    
    def _is_suspicious_trigger(self, trigger: Dict[str, Any]) -> bool:
        """Check if trigger contains suspicious patterns."""
        suspicious_patterns = [
            "xp_cmdshell", "exec(", "EXECUTE", "SHELL",
            "system(", "os.system", "subprocess",
            "eval(", "base64", "decode",
        ]
        
        code = trigger.get("code", "").lower()
        return any(pattern.lower() in code for pattern in suspicious_patterns)
    
    def _is_suspicious_job(self, job: Dict[str, Any]) -> bool:
        """Check if job is suspicious."""
        suspicious_indicators = [
            "xp_cmdshell", "powershell", "cmd.exe",
            "curl", "wget", "nc ", "netcat",
        ]
        
        code = job.get("code", "").lower()
        return any(indicator in code for indicator in suspicious_indicators)
    
    def get_findings(self) -> List:
        """Get all findings from scans."""
        return self.finding_service.get_findings()
    
    def get_critical_findings(self) -> List:
        """Get critical findings."""
        return self.finding_service.get_critical_findings()
    
    def clear(self):
        """Clear all scan data."""
        self.connections.clear()
        self.users.clear()
        self.objects.clear()
        self.finding_service.clear()

