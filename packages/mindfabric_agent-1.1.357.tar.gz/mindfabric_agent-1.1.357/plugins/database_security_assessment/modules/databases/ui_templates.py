"""
Database Security Assessment UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse it)
- fallback recommendations (when missing)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple


def get_dbsec_guidance(
    *,
    category: Optional[str],
    sub_category: Optional[str],
    title: Optional[str] = None,
) -> Tuple[str, List[Dict[str, str]]]:
    c = (category or "").strip().lower()
    sc = (sub_category or "").strip().lower()

    if "credential" in c or "default" in sc or "weak" in sc:
        return (
            "Weak/default database credentials can lead to immediate unauthorized access and data theft. Attackers frequently pivot from DB access to application or host compromise.",
            [
                {"title": "Rotate credentials", "description": "Remove default accounts and rotate passwords; enforce strong auth and MFA for admin access where applicable.", "priority": "high"},
                {"title": "Restrict network access", "description": "Ensure the DB is not publicly reachable; allowlist application hosts only.", "priority": "high"},
            ],
        )

    if "privilege" in c or "excess" in sc:
        return (
            "Excessive DB privileges can allow attackers to dump sensitive tables, create backdoor users, or execute OS-level actions (depending on DB features).",
            [
                {"title": "Apply least privilege", "description": "Limit roles to required schemas/tables; remove superuser where not needed.", "priority": "high"},
                {"title": "Audit role grants", "description": "Review grants and ownership; monitor changes to roles and permissions.", "priority": "medium"},
            ],
        )

    if "encryption" in c or "tls" in sc:
        return (
            "Missing TLS/encryption can expose credentials and data in transit, enabling interception and reuse. Weak encryption also increases breach impact.",
            [
                {"title": "Enforce TLS", "description": "Require TLS for client connections; disable plaintext listeners; rotate credentials if exposure is possible.", "priority": "high"},
                {"title": "Encrypt at rest", "description": "Use disk/volume encryption and DB-native encryption features where appropriate.", "priority": "medium"},
            ],
        )

    if "audit" in c or "logging" in c:
        return (
            "Without database audit logs, attackers can access and modify data without detection, increasing dwell time and complicating incident response.",
            [
                {"title": "Enable DB auditing", "description": "Turn on audit logging for auth events, role changes, and sensitive table access.", "priority": "high"},
                {"title": "Ship logs to SIEM", "description": "Centralize logs and alert on anomalies (new users, mass reads, privilege changes).", "priority": "medium"},
            ],
        )

    t = (title or "").strip()
    if t:
        return (
            f"Database security issue tied to \"{t}\". Risk hinges on whether the DB is reachable from untrusted networks, which roles can read/write sensitive schemas, and whether audits capture abuse.",
            [
                {
                    "title": "Validate instance and access path",
                    "description": f"Record cluster/host, listener addresses, and application roles touching `{t}`; confirm firewall/VNet rules match intent.",
                    "priority": "high",
                },
                {
                    "title": "Harden and verify",
                    "description": "Apply auth/TLS/privilege fixes; re-run checks and sample query logs for anomalous access after deployment.",
                    "priority": "medium",
                },
            ],
        )

    return (
        "Database misconfigurations can enable unauthorized access, data exfiltration, and persistence depending on the affected service, privileges, and network exposure.",
        [
            {
                "title": "Contain network and credentials",
                "description": "Ensure the database is not broadly exposed; rotate secrets if weak auth or cleartext transport was involved.",
                "priority": "high",
            },
            {
                "title": "Reduce privileges and enable auditing",
                "description": "Apply least privilege on DB roles; turn on audit logs for admin and sensitive table access.",
                "priority": "medium",
            },
        ],
    )


def should_upgrade_dbsec_description(description: Optional[str]) -> bool:
    if not isinstance(description, str):
        return True
    s = description.strip()
    if not s:
        return True
    if len(s) < 70:
        return True
    return False


def build_dbsec_description(
    *,
    category: Optional[str],
    sub_category: Optional[str],
    database_type: Optional[str],
    host: Optional[str],
) -> str:
    c = (category or "").strip().lower()
    sc = (sub_category or "").strip().lower()
    dbt = (database_type or "database").strip()
    h = (host or "").strip()
    target = f"{dbt} on {h}" if h else dbt

    if "credential" in c or "default" in sc or "weak" in sc:
        return (
            f"Weak or default credentials were detected for {target}. "
            "Attackers frequently brute-force or reuse leaked credentials to gain DB access, then dump sensitive tables and pivot into applications or hosts."
        )

    if "privilege" in c or "excess" in sc:
        return (
            f"Excessive privileges were detected for {target}. "
            "Attackers who obtain an over-privileged DB account can read/modify sensitive data, create backdoor users, or execute dangerous DB features to escalate impact."
        )

    if "encryption" in c or "tls" in sc:
        return (
            f"Transport security/encryption appears misconfigured for {target}. "
            "Attackers on the network can intercept credentials or data-in-transit and reuse them to access the database or downstream systems."
        )

    if "audit" in c or "logging" in c:
        return (
            f"Audit logging is insufficient for {target}. "
            "Without strong DB audit trails, attackers can access or exfiltrate data without detection, increasing dwell time and complicating incident response."
        )

    return (
        f"A database security weakness was detected for {target}. "
        "Depending on exposure and privileges, attackers may use it to gain access, exfiltrate data, or establish persistence."
    )

