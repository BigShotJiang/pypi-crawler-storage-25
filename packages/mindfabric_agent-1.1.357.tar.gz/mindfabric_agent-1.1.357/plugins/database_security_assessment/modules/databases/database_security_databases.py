"""
Database Security Assessment Databases

Contains static data: default credentials, security checks, MITRE mappings.
"""

from typing import Dict, List, Any, Tuple

from ...proto import (
    DatabaseType,
    FindingCategory,
    FindingSubCategory,
    SeverityLevel,
    ComplianceFramework,
    MitreTactic,
    MitreTechnique,
)


# =============================================================================
# Default Credentials
# =============================================================================

DEFAULT_CREDENTIALS: Dict[DatabaseType, List[Dict[str, str]]] = {
    DatabaseType.POSTGRESQL: [
        {"username": "postgres", "password": "postgres"},
        {"username": "postgres", "password": "postgres123"},  # From Dockerfile
        {"username": "postgres", "password": ""},
        {"username": "postgres", "password": "admin"},
        {"username": "postgres", "password": "password"},
        {"username": "admin", "password": "admin"},
    ],
    DatabaseType.MYSQL: [
        {"username": "root", "password": ""},
        {"username": "root", "password": "root"},
        {"username": "root", "password": "root123"},  # From Dockerfile
        {"username": "root", "password": "mysql"},
        {"username": "root", "password": "password"},
        {"username": "admin", "password": "admin"},
    ],
    DatabaseType.MSSQL: [
        {"username": "sa", "password": ""},
        {"username": "sa", "password": "sa"},
        {"username": "sa", "password": "password"},
        {"username": "sa", "password": "Password123"},
        {"username": "admin", "password": "admin"},
    ],
    DatabaseType.ORACLE: [
        {"username": "SYS", "password": "change_on_install"},
        {"username": "SYSTEM", "password": "manager"},
        {"username": "SYSMAN", "password": "oem_temp"},
        {"username": "DBSNMP", "password": "dbsnmp"},
        {"username": "SCOTT", "password": "tiger"},
    ],
    DatabaseType.MONGODB: [
        {"username": "admin", "password": "admin"},
        {"username": "admin", "password": "password"},
        {"username": "root", "password": "root"},
        {"username": "", "password": ""},  # No auth
    ],
    DatabaseType.REDIS: [
        {"username": "", "password": ""},  # No auth
        {"username": "default", "password": ""},
        {"username": "default", "password": "redis"},
    ],
    DatabaseType.CASSANDRA: [
        {"username": "cassandra", "password": "cassandra"},
    ],
    DatabaseType.ELASTICSEARCH: [
        {"username": "elastic", "password": "changeme"},
        {"username": "elastic", "password": "elastic"},
        {"username": "", "password": ""},  # No auth
    ],
}


# =============================================================================
# Security Checks
# =============================================================================

SECURITY_CHECKS: Dict[DatabaseType, List[Dict[str, Any]]] = {
    DatabaseType.POSTGRESQL: [
        {
            "id": "PG-AUTH-001",
            "name": "Password authentication disabled",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.INSECURE_SETTING,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT setting FROM pg_settings WHERE name = 'password_encryption'",
            "vulnerable_if": "plain",
            "description": "Password encryption is disabled, passwords stored in plain text",
            "recommendation": "Set password_encryption to 'scram-sha-256' in postgresql.conf",
        },
        {
            "id": "PG-AUTH-002",
            "name": "Trust authentication in pg_hba.conf",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.NO_PASSWORD,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT auth_method FROM pg_hba_file_rules WHERE auth_method = 'trust'",
            "vulnerable_if_exists": True,
            "description": "Trust authentication allows connections without password",
            "recommendation": "Change trust entries in pg_hba.conf to md5 or scram-sha-256",
        },
        {
            "id": "PG-NET-001",
            "name": "Listening on all interfaces",
            "category": FindingCategory.NETWORK,
            "sub_category": FindingSubCategory.NETWORK_MISCONFIGURATION,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT setting FROM pg_settings WHERE name = 'listen_addresses'",
            "vulnerable_if": "*",
            "description": "PostgreSQL listening on all network interfaces",
            "recommendation": "Restrict listen_addresses to specific IPs in postgresql.conf",
        },
        {
            "id": "PG-ENC-001",
            "name": "SSL disabled",
            "category": FindingCategory.ENCRYPTION,
            "sub_category": FindingSubCategory.UNENCRYPTED_CONNECTION,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT setting FROM pg_settings WHERE name = 'ssl'",
            "vulnerable_if": "off",
            "description": "SSL encryption is disabled for connections",
            "recommendation": "Enable SSL by setting ssl = on in postgresql.conf",
        },
        {
            "id": "PG-LOG-001",
            "name": "Logging disabled",
            "category": FindingCategory.AUDIT_LOGGING,
            "sub_category": FindingSubCategory.LOGGING_DISABLED,
            "severity": SeverityLevel.MEDIUM,
            "check_sql": "SELECT setting FROM pg_settings WHERE name = 'log_statement'",
            "vulnerable_if": "none",
            "description": "SQL statement logging is disabled",
            "recommendation": "Set log_statement = 'all' or 'ddl' for audit logging",
        },
        {
            "id": "PG-CFG-001",
            "name": "Row-level security disabled",
            "category": FindingCategory.AUTHORIZATION,
            "sub_category": FindingSubCategory.INSECURE_SETTING,
            "severity": SeverityLevel.MEDIUM,
            "check_sql": "SELECT relname FROM pg_class WHERE relrowsecurity = false AND relkind = 'r'",
            "check_type": "count_tables",
            "description": "Row-level security not enabled on tables",
            "recommendation": "Enable row-level security on tables with sensitive data",
        },
    ],
    DatabaseType.MYSQL: [
        {
            "id": "MY-AUTH-001",
            "name": "Root without password",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.NO_PASSWORD,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT User, Host FROM mysql.user WHERE User = 'root' AND authentication_string = ''",
            "vulnerable_if_exists": True,
            "description": "Root user has no password set",
            "recommendation": "Set a strong password for root: ALTER USER 'root'@'localhost' IDENTIFIED BY 'password'",
        },
        {
            "id": "MY-AUTH-002",
            "name": "Anonymous user exists",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.UNUSED_ACCOUNTS,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT User, Host FROM mysql.user WHERE User = ''",
            "vulnerable_if_exists": True,
            "description": "Anonymous user account exists",
            "recommendation": "Remove anonymous users: DROP USER ''@'localhost'",
        },
        {
            "id": "MY-AUTH-003",
            "name": "Remote root login allowed",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.INSECURE_SETTING,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT User, Host FROM mysql.user WHERE User = 'root' AND Host = '%'",
            "vulnerable_if_exists": True,
            "description": "Root user can connect from any host",
            "recommendation": "Restrict root to localhost: UPDATE mysql.user SET Host='localhost' WHERE User='root'",
        },
        {
            "id": "MY-ENC-001",
            "name": "SSL not required",
            "category": FindingCategory.ENCRYPTION,
            "sub_category": FindingSubCategory.UNENCRYPTED_CONNECTION,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT @@require_secure_transport",
            "vulnerable_if": "0",
            "description": "SSL/TLS is not required for connections",
            "recommendation": "Set require_secure_transport = ON in my.cnf",
        },
        {
            "id": "MY-CFG-001",
            "name": "LOCAL INFILE enabled",
            "category": FindingCategory.CONFIGURATION,
            "sub_category": FindingSubCategory.UNSAFE_FUNCTIONS,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT @@local_infile",
            "vulnerable_if": "1",
            "description": "LOCAL INFILE allows reading server files",
            "recommendation": "Set local_infile = 0 in my.cnf",
        },
        {
            "id": "MY-LOG-001",
            "name": "General query log disabled",
            "category": FindingCategory.AUDIT_LOGGING,
            "sub_category": FindingSubCategory.LOGGING_DISABLED,
            "severity": SeverityLevel.LOW,
            "check_sql": "SELECT @@general_log",
            "vulnerable_if": "0",
            "description": "General query logging is disabled",
            "recommendation": "Enable general_log for debugging or use audit plugin for production",
        },
    ],
    DatabaseType.MSSQL: [
        {
            "id": "MS-AUTH-001",
            "name": "SA account enabled with weak password",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.WEAK_PASSWORD,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT name, is_disabled FROM sys.sql_logins WHERE name = 'sa' AND is_disabled = 0",
            "vulnerable_if_exists": True,
            "description": "SA account is enabled (potential weak password)",
            "recommendation": "Disable SA account: ALTER LOGIN sa DISABLE",
        },
        {
            "id": "MS-CFG-001",
            "name": "xp_cmdshell enabled",
            "category": FindingCategory.CONFIGURATION,
            "sub_category": FindingSubCategory.UNSAFE_FUNCTIONS,
            "severity": SeverityLevel.CRITICAL,
            "check_sql": "SELECT value FROM sys.configurations WHERE name = 'xp_cmdshell'",
            "vulnerable_if": "1",
            "description": "xp_cmdshell allows OS command execution",
            "recommendation": "Disable xp_cmdshell: sp_configure 'xp_cmdshell', 0; RECONFIGURE",
        },
        {
            "id": "MS-CFG-002",
            "name": "CLR enabled",
            "category": FindingCategory.CONFIGURATION,
            "sub_category": FindingSubCategory.UNSAFE_FUNCTIONS,
            "severity": SeverityLevel.MEDIUM,
            "check_sql": "SELECT value FROM sys.configurations WHERE name = 'clr enabled'",
            "vulnerable_if": "1",
            "description": "CLR integration enabled (code execution risk)",
            "recommendation": "Disable CLR if not needed: sp_configure 'clr enabled', 0; RECONFIGURE",
        },
        {
            "id": "MS-CFG-003",
            "name": "OLE Automation enabled",
            "category": FindingCategory.CONFIGURATION,
            "sub_category": FindingSubCategory.UNSAFE_FUNCTIONS,
            "severity": SeverityLevel.HIGH,
            "check_sql": "SELECT value FROM sys.configurations WHERE name = 'Ole Automation Procedures'",
            "vulnerable_if": "1",
            "description": "OLE Automation allows executing external code",
            "recommendation": "Disable OLE Automation: sp_configure 'Ole Automation Procedures', 0; RECONFIGURE",
        },
        {
            "id": "MS-ENC-001",
            "name": "Transparent Data Encryption disabled",
            "category": FindingCategory.ENCRYPTION,
            "sub_category": FindingSubCategory.MISSING_TDE,
            "severity": SeverityLevel.MEDIUM,
            "check_sql": "SELECT name FROM sys.databases WHERE is_encrypted = 0 AND name NOT IN ('master', 'tempdb', 'model', 'msdb')",
            "vulnerable_if_exists": True,
            "description": "Database not encrypted with TDE",
            "recommendation": "Enable TDE for sensitive databases",
        },
    ],
    DatabaseType.MONGODB: [
        {
            "id": "MG-AUTH-001",
            "name": "Authentication disabled",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.NO_PASSWORD,
            "severity": SeverityLevel.CRITICAL,
            "check_command": "db.adminCommand('getCmdLineOpts')",
            "check_field": "security.authorization",
            "vulnerable_if": "disabled",
            "description": "MongoDB authentication is disabled",
            "recommendation": "Enable authentication in mongod.conf: security.authorization: enabled",
        },
        {
            "id": "MG-NET-001",
            "name": "Bind to all interfaces",
            "category": FindingCategory.NETWORK,
            "sub_category": FindingSubCategory.NETWORK_MISCONFIGURATION,
            "severity": SeverityLevel.HIGH,
            "check_command": "db.adminCommand('getCmdLineOpts')",
            "check_field": "net.bindIp",
            "vulnerable_if": "0.0.0.0",
            "description": "MongoDB bound to all network interfaces",
            "recommendation": "Restrict bindIp to specific IPs in mongod.conf",
        },
        {
            "id": "MG-ENC-001",
            "name": "TLS disabled",
            "category": FindingCategory.ENCRYPTION,
            "sub_category": FindingSubCategory.UNENCRYPTED_CONNECTION,
            "severity": SeverityLevel.HIGH,
            "check_command": "db.adminCommand('getCmdLineOpts')",
            "check_field": "net.tls.mode",
            "vulnerable_if": "disabled",
            "description": "TLS encryption is disabled",
            "recommendation": "Enable TLS: net.tls.mode: requireTLS",
        },
    ],
    DatabaseType.REDIS: [
        {
            "id": "RD-AUTH-001",
            "name": "No authentication",
            "category": FindingCategory.AUTHENTICATION,
            "sub_category": FindingSubCategory.NO_PASSWORD,
            "severity": SeverityLevel.CRITICAL,
            "check_command": "CONFIG GET requirepass",
            "vulnerable_if": "",
            "description": "Redis has no password configured",
            "recommendation": "Set requirepass in redis.conf",
        },
        {
            "id": "RD-NET-001",
            "name": "Protected mode disabled",
            "category": FindingCategory.NETWORK,
            "sub_category": FindingSubCategory.NETWORK_MISCONFIGURATION,
            "severity": SeverityLevel.CRITICAL,
            "check_command": "CONFIG GET protected-mode",
            "vulnerable_if": "no",
            "description": "Protected mode is disabled",
            "recommendation": "Enable protected-mode in redis.conf",
        },
        {
            "id": "RD-CFG-001",
            "name": "Dangerous commands not renamed",
            "category": FindingCategory.CONFIGURATION,
            "sub_category": FindingSubCategory.UNSAFE_FUNCTIONS,
            "severity": SeverityLevel.HIGH,
            "dangerous_commands": ["FLUSHALL", "FLUSHDB", "CONFIG", "DEBUG", "EVAL"],
            "description": "Dangerous commands are available",
            "recommendation": "Rename dangerous commands in redis.conf",
        },
    ],
}


# =============================================================================
# Dangerous Privileges
# =============================================================================

DANGEROUS_PRIVILEGES: Dict[DatabaseType, List[Dict[str, Any]]] = {
    DatabaseType.POSTGRESQL: [
        {"privilege": "SUPERUSER", "severity": SeverityLevel.CRITICAL, "description": "Full database control"},
        {"privilege": "CREATEROLE", "severity": SeverityLevel.HIGH, "description": "Can create roles with any privilege"},
        {"privilege": "CREATEDB", "severity": SeverityLevel.MEDIUM, "description": "Can create databases"},
        {"privilege": "pg_execute_server_program", "severity": SeverityLevel.CRITICAL, "description": "Can execute OS commands"},
        {"privilege": "pg_read_server_files", "severity": SeverityLevel.HIGH, "description": "Can read server files"},
        {"privilege": "pg_write_server_files", "severity": SeverityLevel.HIGH, "description": "Can write server files"},
    ],
    DatabaseType.MYSQL: [
        {"privilege": "SUPER", "severity": SeverityLevel.CRITICAL, "description": "Administrative privileges"},
        {"privilege": "FILE", "severity": SeverityLevel.HIGH, "description": "Read/write files on server"},
        {"privilege": "PROCESS", "severity": SeverityLevel.MEDIUM, "description": "View all processes"},
        {"privilege": "GRANT OPTION", "severity": SeverityLevel.HIGH, "description": "Can grant privileges to others"},
        {"privilege": "ALL PRIVILEGES", "severity": SeverityLevel.CRITICAL, "description": "All privileges on object"},
    ],
    DatabaseType.MSSQL: [
        {"privilege": "sysadmin", "severity": SeverityLevel.CRITICAL, "description": "Full server control"},
        {"privilege": "serveradmin", "severity": SeverityLevel.HIGH, "description": "Server configuration"},
        {"privilege": "securityadmin", "severity": SeverityLevel.HIGH, "description": "Security management"},
        {"privilege": "db_owner", "severity": SeverityLevel.HIGH, "description": "Full database control"},
        {"privilege": "CONTROL SERVER", "severity": SeverityLevel.CRITICAL, "description": "Full server control"},
    ],
}


# =============================================================================
# MITRE ATT&CK Mappings
# =============================================================================

MITRE_MAPPINGS: Dict[FindingSubCategory, Tuple[MitreTactic, MitreTechnique]] = {
    FindingSubCategory.DEFAULT_CREDENTIALS: (MitreTactic.INITIAL_ACCESS, MitreTechnique.T1078),
    FindingSubCategory.WEAK_PASSWORD: (MitreTactic.CREDENTIAL_ACCESS, MitreTechnique.T1110),
    FindingSubCategory.NO_PASSWORD: (MitreTactic.INITIAL_ACCESS, MitreTechnique.T1078),
    FindingSubCategory.EXCESSIVE_PRIVILEGES: (MitreTactic.PRIVILEGE_ESCALATION, MitreTechnique.T1068),
    FindingSubCategory.PUBLIC_ACCESS: (MitreTactic.INITIAL_ACCESS, MitreTechnique.T1190),
    FindingSubCategory.MALICIOUS_TRIGGER: (MitreTactic.PERSISTENCE, MitreTechnique.T1505_001),
    FindingSubCategory.MALICIOUS_PROCEDURE: (MitreTactic.PERSISTENCE, MitreTechnique.T1505_001),
    FindingSubCategory.BACKDOOR_ACCOUNT: (MitreTactic.PERSISTENCE, MitreTechnique.T1136),
    FindingSubCategory.SQL_INJECTION: (MitreTactic.INITIAL_ACCESS, MitreTechnique.T1190),
    FindingSubCategory.COMMAND_INJECTION: (MitreTactic.INITIAL_ACCESS, MitreTechnique.T1190),
    FindingSubCategory.UNENCRYPTED_CONNECTION: (MitreTactic.CREDENTIAL_ACCESS, MitreTechnique.T1552),
    FindingSubCategory.PII_EXPOSURE: (MitreTactic.COLLECTION, MitreTechnique.T1119),
}


# =============================================================================
# Compliance Mappings
# =============================================================================

COMPLIANCE_MAPPINGS: Dict[FindingSubCategory, List[Dict[str, str]]] = {
    FindingSubCategory.WEAK_PASSWORD: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "8.2.3", "name": "Strong Passwords"},
        {"framework": ComplianceFramework.HIPAA.value, "control": "164.312(d)", "name": "Authentication"},
        {"framework": ComplianceFramework.SOC2.value, "control": "CC6.1", "name": "Logical Access Security"},
    ],
    FindingSubCategory.NO_PASSWORD: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "8.2.1", "name": "Unique IDs"},
        {"framework": ComplianceFramework.HIPAA.value, "control": "164.312(d)", "name": "Authentication"},
    ],
    FindingSubCategory.UNENCRYPTED_CONNECTION: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "4.1", "name": "Transmission Encryption"},
        {"framework": ComplianceFramework.HIPAA.value, "control": "164.312(e)(1)", "name": "Transmission Security"},
        {"framework": ComplianceFramework.GDPR.value, "control": "Art. 32", "name": "Security of Processing"},
    ],
    FindingSubCategory.LOGGING_DISABLED: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "10.2", "name": "Audit Logs"},
        {"framework": ComplianceFramework.HIPAA.value, "control": "164.312(b)", "name": "Audit Controls"},
        {"framework": ComplianceFramework.SOC2.value, "control": "CC7.1", "name": "Detection and Monitoring"},
    ],
    FindingSubCategory.EXCESSIVE_PRIVILEGES: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "7.1", "name": "Least Privilege"},
        {"framework": ComplianceFramework.SOC2.value, "control": "CC6.3", "name": "Access Modification"},
    ],
    FindingSubCategory.UNENCRYPTED_DATA: [
        {"framework": ComplianceFramework.PCI_DSS.value, "control": "3.4", "name": "PAN Masking/Encryption"},
        {"framework": ComplianceFramework.HIPAA.value, "control": "164.312(a)(2)(iv)", "name": "Encryption"},
        {"framework": ComplianceFramework.GDPR.value, "control": "Art. 32", "name": "Encryption of Personal Data"},
    ],
}


# =============================================================================
# Database Port Mapping
# =============================================================================

DEFAULT_PORTS: Dict[DatabaseType, int] = {
    DatabaseType.POSTGRESQL: 5432,
    DatabaseType.MYSQL: 3306,
    DatabaseType.MARIADB: 3306,
    DatabaseType.MSSQL: 1433,
    DatabaseType.ORACLE: 1521,
    DatabaseType.MONGODB: 27017,
    DatabaseType.REDIS: 6379,
    DatabaseType.CASSANDRA: 9042,
    DatabaseType.COUCHDB: 5984,
    DatabaseType.ELASTICSEARCH: 9200,
}

