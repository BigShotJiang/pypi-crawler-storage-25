"""
Database Security Assessment Plugin

Main plugin implementation for database security scanning.
"""

import uuid
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional

from plugins.base_plugin import BasePlugin
from plugins.reproduction import ReproStep

from .proto import (
    DatabaseSecurityScanOutput,
    ScanMetadata,
    ScanOptions,
    ScanTarget,
    SeveritySummary,
    CategorySummary,
    ComplianceSummary,
    DatabaseSummary,
    DatabaseType,
    FindingCategory,
    SeverityLevel,
)
from .modules.services.scanner_service import DatabaseScannerService
from .modules.services.sql_injection_scanner import SQLInjectionScanner
from .modules.services.discovery_service import DatabaseDiscoveryService
from .modules.services.privilege_escalation_service import PrivilegeEscalationService
from .modules.databases.ui_templates import (
    build_dbsec_description,
    get_dbsec_guidance,
    should_upgrade_dbsec_description,
)


class DatabaseSecurityAssessmentPlugin(BasePlugin):
    """
    Database Security Assessment Plugin
    
    Scans databases for security vulnerabilities including:
    - Default and weak credentials
    - Misconfigurations
    - Excessive privileges
    - Encryption issues
    - Audit logging gaps
    - Persistence mechanisms
    - Compliance violations
    """
    
    NAME = "database_security_assessment"
    DESCRIPTION = "Comprehensive database security assessment and vulnerability scanning"
    VERSION = "1.0.0"
    
    SUPPORTED_HOOKS = [
        "hook_database_security_scan",
        "hook_database_credential_check",
        "hook_database_config_audit",
        "hook_database_privilege_audit",
        "hook_database_compliance_check",
        "hook_database_discovery",
        "hook_database_sql_injection_scan",
        "hook_database_privilege_escalation_check",
    ]
    
    def __init__(self, ws=None, command_id=None, options=None):
        super().__init__(ws, command_id, options or {})
        self.scanner_service = DatabaseScannerService(self)
        self.sql_injection_scanner = SQLInjectionScanner(self)
        self.discovery_service = DatabaseDiscoveryService(self)
        self.privilege_escalation_service = PrivilegeEscalationService(self)
    
    async def hook_database_security_scan(
        self,
        targets: List[Dict[str, Any]] = None,
        options: Dict[str, Any] = None,
    ) -> DatabaseSecurityScanOutput:
        """
        Perform comprehensive database security scan.
        
        Args:
            targets: List of database targets with host, port, credentials
            options: Scan configuration options
            
        Returns:
            DatabaseSecurityScanOutput with findings and recommendations
        """
        scan_id = str(uuid.uuid4())
        started_at = datetime.utcnow()
        
        # Parse options
        scan_options = self._parse_options(targets, options)
        
        # Initialize output
        all_findings = []
        all_connections = []
        all_users = []
        all_objects = []
        errors = []
        database_summaries = []
        
        # Check if we have targets to scan
        if not scan_options.targets or len(scan_options.targets) == 0:
            errors.append("No targets specified for scanning")
            completed_at = datetime.utcnow()
            duration = (completed_at - started_at).total_seconds()
            return DatabaseSecurityScanOutput(
                metadata=ScanMetadata(
                    scan_id=scan_id,
                    scan_type="database_security",
                    started_at=started_at,
                    completed_at=completed_at,
                    duration_seconds=duration,
                    databases_scanned=0,
                    hosts_scanned=0,
                    total_findings=0,
                    tool_version=self.VERSION,
                ),
                options=scan_options,
                severity_summary=SeveritySummary(critical=0, high=0, medium=0, low=0, info=0),
                category_summaries=[],
                database_summaries=[],
                connections=[],
                users=[],
                objects=[],
                findings=[],
                critical_findings=[],
                recommendations=[],
                immediate_actions=[],
                errors=errors,
                reproduction_steps=[],
            )
        
        # Scan each target
        for target in scan_options.targets:
            try:
                results = await self.scanner_service.scan_target(target)
                
                if results.get("connection"):
                    all_connections.append(results["connection"])
                if results.get("users"):
                    all_users.extend(results["users"])
                if results.get("objects"):
                    all_objects.extend(results["objects"])
                if results.get("findings"):
                    all_findings.extend(results["findings"])
                if results.get("errors"):
                    errors.extend(results["errors"])
                
                # Create database summary
                conn = results.get("connection")
                if conn:
                    summary = DatabaseSummary(
                        host=conn.host,
                        port=conn.port,
                        database_type=conn.database_type,
                        database_name=conn.database_name,
                        ssl_enabled=conn.ssl_enabled,
                        users_count=len(results.get("users", [])),
                        objects_count=len(results.get("objects", [])),
                        findings_count=len(results.get("findings", [])),
                        critical_findings=len([
                            f for f in (results.get("findings") or [])
                            if f and hasattr(f, 'severity') and f.severity == SeverityLevel.CRITICAL
                        ]),
                        high_findings=len([
                            f for f in (results.get("findings") or [])
                            if f and hasattr(f, 'severity') and f.severity == SeverityLevel.HIGH
                        ]),
                    )
                    database_summaries.append(summary)
                    
            except Exception as e:
                errors.append(f"Error scanning {target.host}:{target.port}: {str(e)}")
        
        completed_at = datetime.utcnow()
        duration = (completed_at - started_at).total_seconds()
        
        # Calculate summaries
        severity_summary = self._calculate_severity_summary(all_findings)
        category_summaries = self._calculate_category_summaries(all_findings)
        
        # Get critical findings
        critical_findings = [f for f in (all_findings or []) if f and hasattr(f, 'severity') and f.severity == SeverityLevel.CRITICAL]
        
        # Generate recommendations
        recommendations = self._generate_recommendations(all_findings)
        immediate_actions = self._get_immediate_actions(critical_findings)
        
        # Create metadata
        metadata = ScanMetadata(
            scan_id=scan_id,
            scan_type="database_security",
            started_at=started_at,
            completed_at=completed_at,
            duration_seconds=duration,
            databases_scanned=len(database_summaries),
            hosts_scanned=len(set(t.host for t in (scan_options.targets or []))),
            total_findings=len(all_findings),
            tool_version=self.VERSION,
        )
        
        # Create reproduction steps
        reproduction_steps = self._create_reproduction_steps(scan_options, critical_findings)
        
        return DatabaseSecurityScanOutput(
            metadata=metadata,
            options=scan_options,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            database_summaries=database_summaries,
            connections=all_connections,
            users=all_users,
            objects=all_objects,
            findings=all_findings,
            critical_findings=critical_findings,
            recommendations=recommendations,
            immediate_actions=immediate_actions,
            errors=errors if errors else None,
            reproduction_steps=reproduction_steps,
        )
    
    async def run(self):
        """Main plugin execution method - runs database security scan."""
        try:
            # Ensure options is a dict
            if self.options is None:
                self.options = {}
            
            # Get parameters from options
            targets = self.options.get("targets") if self.options else None
            if targets is None:
                targets = []
            if not isinstance(targets, list):
                targets = []
            
            options = self.options.get("options") if self.options else None
            if options is None:
                options = {}
            if not isinstance(options, dict):
                options = {}
            
            # If no targets specified, discover databases automatically using hook
            if not targets:
                try:
                    discovery_result = await self.hook_database_discovery(scan_local=True, targets=None, ports=None)
                    if discovery_result and isinstance(discovery_result, dict):
                        discovered_databases = discovery_result.get("discovered_databases", [])
                        
                        if discovered_databases and isinstance(discovered_databases, list) and len(discovered_databases) > 0:
                            targets = []
                            for db in discovered_databases:
                                if db and isinstance(db, dict):
                                    targets.append({
                                        "host": db.get("host", "localhost"),
                                        "port": db.get("port", 5432),
                                        "database_type": db.get("database_type", "postgresql"),
                                    })
                except Exception as e:
                    # If discovery fails, fall through to default ports
                    pass
            
            # Fallback: try common database ports on localhost if discovery found nothing
            if not targets:
                # Try common database ports on localhost
                common_ports = [5432, 3306, 27017, 6379]  # PostgreSQL, MySQL, MongoDB, Redis
                for port in common_ports:
                    targets.append({
                        "host": "localhost",
                        "port": port,
                        "database_type": "postgresql" if port == 5432 else "mysql" if port == 3306 else "mongodb" if port == 27017 else "redis",
                    })
            
            return self.to_security_scan_v1(
                self._with_canonical_findings(await self.hook_database_security_scan(targets=targets, options=options))
            )
        except Exception as e:
            import traceback
            error_msg = f"Error in run(): {str(e)}\n{traceback.format_exc()}"
            # Return error result that can be processed
            from .proto import DatabaseSecurityScanOutput, ScanMetadata, SeveritySummary
            from datetime import datetime
            return self.to_security_scan_v1(DatabaseSecurityScanOutput(
                metadata=ScanMetadata(
                    scan_id="error",
                    scan_type="database_security",
                    started_at=datetime.utcnow(),
                    completed_at=datetime.utcnow(),
                    duration_seconds=0,
                    databases_scanned=0,
                    hosts_scanned=0,
                    total_findings=0,
                    tool_version=self.VERSION,
                ),
                options=None,
                severity_summary=SeveritySummary(critical=0, high=0, medium=0, low=0, info=0),
                category_summaries=[],
                database_summaries=[],
                connections=[],
                users=[],
                objects=[],
                findings=[],
                critical_findings=[],
                recommendations=[],
                immediate_actions=[],
                errors=[error_msg],
                reproduction_steps=[],
            ))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Ensure findings include analyst-friendly `impact` and structured `recommendations`.
        Keep plugin-specific enrichment inside the plugin (not in security_contract).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        findings = out.get("findings") or []
        if isinstance(findings, list):
            for f in findings:
                if not isinstance(f, dict):
                    continue
                # Upgrade low-signal descriptions.
                if should_upgrade_dbsec_description(f.get("description")):
                    cat = f.get("category")
                    if hasattr(cat, "value"):
                        cat = cat.value
                    sub = f.get("sub_category") or f.get("subCategory")
                    if hasattr(sub, "value"):
                        sub = sub.value
                    dbt = f.get("database_type") or f.get("databaseType")
                    if hasattr(dbt, "value"):
                        dbt = dbt.value
                    f["description"] = build_dbsec_description(
                        category=str(cat) if cat else None,
                        sub_category=str(sub) if sub else None,
                        database_type=str(dbt) if dbt else None,
                        host=str(f.get("host") or "") if f.get("host") else None,
                    )
                cat = f.get("category")
                if hasattr(cat, "value"):
                    cat = cat.value
                sub = f.get("sub_category") or f.get("subCategory")
                if hasattr(sub, "value"):
                    sub = sub.value

                impact_val = f.get("potential_impact") or f.get("potentialImpact")
                if not f.get("impact") and isinstance(impact_val, str) and impact_val.strip():
                    f["impact"] = impact_val.strip()
                elif not f.get("impact"):
                    impact, _ = get_dbsec_guidance(
                        category=str(cat) if cat else None,
                        sub_category=str(sub) if sub else None,
                        title=str(f.get("title") or "") if f.get("title") else None,
                    )
                    f["impact"] = impact

                if not f.get("recommendations"):
                    rec_str = f.get("recommendation")
                    if isinstance(rec_str, str) and rec_str.strip():
                        f["recommendations"] = [
                            {"title": "Recommendation", "description": rec_str.strip(), "priority": "medium"}
                        ]
                    else:
                        _, fallback_recs = get_dbsec_guidance(
                            category=str(cat) if cat else None,
                            sub_category=str(sub) if sub else None,
                            title=str(f.get("title") or "") if f.get("title") else None,
                        )
                        f["recommendations"] = fallback_recs

                if not f.get("affected_resources"):
                    db_host = f.get("host") or f.get("database_host") or f.get("databaseHost")
                    ar_db: List[Dict[str, Any]] = []
                    if isinstance(db_host, str) and db_host.strip():
                        row_db: Dict[str, Any] = {"type": "database_instance", "host": db_host.strip()[:500]}
                        dp = f.get("port") or f.get("database_port") or f.get("databasePort")
                        if dp is not None:
                            try:
                                row_db["port"] = int(dp)
                            except (TypeError, ValueError):
                                pass
                        ar_db.append(row_db)
                    dbt = f.get("database_type") or f.get("databaseType")
                    if hasattr(dbt, "value"):
                        dbt = dbt.value
                    if isinstance(dbt, str) and dbt.strip() and ar_db:
                        ar_db[0]["engine"] = dbt.strip()[:80]
                    if ar_db:
                        f["affected_resources"] = ar_db

        out["findings"] = findings
        return out
    
    async def hook_database_credential_check(
        self,
        host: str,
        port: int,
        database_type: str = None,
    ) -> Dict[str, Any]:
        """Check for default/weak credentials on a database."""
        target = ScanTarget(
            host=host,
            port=port,
            database_type=DatabaseType(database_type) if database_type else None,
        )
        
        results = await self.scanner_service.scan_target(target)
        
        credential_findings = [
            f for f in results.get("findings", [])
            if f.sub_category in [
                "default_credentials",
                "weak_password",
                "no_password",
            ]
        ]
        
        return {
            "host": host,
            "port": port,
            "database_type": target.database_type.value if target.database_type else "unknown",
            "vulnerable": len(credential_findings) > 0,
            "findings": credential_findings,
        }
    
    async def hook_database_config_audit(
        self,
        host: str,
        port: int,
        username: str = None,
        password: str = None,
    ) -> Dict[str, Any]:
        """Audit database configuration for security issues."""
        target = ScanTarget(
            host=host,
            port=port,
            username=username,
            password=password,
        )
        
        results = await self.scanner_service.scan_target(target)
        
        config_findings = [
            f for f in results.get("findings", [])
            if f.category == FindingCategory.CONFIGURATION
        ]
        
        return {
            "host": host,
            "port": port,
            "findings": config_findings,
            "recommendations": [f.recommendation for f in config_findings],
        }
    
    async def hook_database_privilege_audit(
        self,
        host: str,
        port: int,
        username: str = None,
        password: str = None,
    ) -> Dict[str, Any]:
        """Audit user privileges for excessive permissions."""
        target = ScanTarget(
            host=host,
            port=port,
            username=username,
            password=password,
        )
        
        results = await self.scanner_service.scan_target(target)
        
        privilege_findings = [
            f for f in results.get("findings", [])
            if f.category == FindingCategory.AUTHORIZATION
        ]
        
        return {
            "host": host,
            "port": port,
            "users": results.get("users", []),
            "findings": privilege_findings,
        }
    
    async def hook_database_compliance_check(
        self,
        host: str,
        port: int,
        frameworks: List[str] = None,
        username: str = None,
        password: str = None,
    ) -> Dict[str, Any]:
        """Check database compliance with security frameworks."""
        target = ScanTarget(
            host=host,
            port=port,
            username=username,
            password=password,
        )
        
        results = await self.scanner_service.scan_target(target)
        
        # Filter findings by requested frameworks
        compliance_findings = []
        findings_list = results.get("findings") or []
        for finding in findings_list:
            if not finding or not hasattr(finding, 'compliance') or not finding.compliance:
                continue
            compliance_list = finding.compliance if isinstance(finding.compliance, list) else [finding.compliance]
            for mapping in compliance_list:
                    if not frameworks or mapping.framework.value in frameworks:
                        compliance_findings.append(finding)
                        break
        
        return {
            "host": host,
            "port": port,
            "frameworks_checked": frameworks or ["all"],
            "findings": compliance_findings,
            "compliance_summary": self._get_compliance_summary(compliance_findings, frameworks),
        }
    
    def _parse_options(
        self,
        targets: List[Dict[str, Any]],
        options: Dict[str, Any],
    ) -> ScanOptions:
        """Parse scan options from input."""
        parsed_targets = []
        
        # Ensure targets is a list
        if targets is None:
            targets = []
        
        if isinstance(targets, list) and len(targets) > 0:
            for t in targets:
                if t and isinstance(t, dict):
                    parsed_targets.append(ScanTarget(
                        host=t.get("host", "localhost"),
                        port=t.get("port", 5432),
                        database_type=DatabaseType(t["database_type"]) if t.get("database_type") else None,
                        database_name=t.get("database_name"),
                        username=t.get("username"),
                        password=t.get("password"),
                    ))
        
        opts = options or {}
        
        return ScanOptions(
            targets=parsed_targets,
            check_authentication=opts.get("check_authentication", True),
            check_authorization=opts.get("check_authorization", True),
            check_configuration=opts.get("check_configuration", True),
            check_encryption=opts.get("check_encryption", True),
            check_injection=opts.get("check_injection", False),
            check_privilege_escalation=opts.get("check_privilege_escalation", True),
            check_persistence=opts.get("check_persistence", True),
            check_audit_logging=opts.get("check_audit_logging", True),
            check_network=opts.get("check_network", True),
            check_data_exposure=opts.get("check_data_exposure", True),
            check_compliance=opts.get("check_compliance", True),
            read_only=opts.get("read_only", True),
            test_default_credentials=opts.get("test_default_credentials", True),
        )
    
    def _calculate_severity_summary(self, findings: List) -> SeveritySummary:
        """Calculate severity summary from findings."""
        summary = SeveritySummary()
        
        if not findings:
            return summary
        
        for finding in findings:
            if not finding or not hasattr(finding, 'severity'):
                continue
            if finding.severity == SeverityLevel.CRITICAL:
                summary.critical += 1
            elif finding.severity == SeverityLevel.HIGH:
                summary.high += 1
            elif finding.severity == SeverityLevel.MEDIUM:
                summary.medium += 1
            elif finding.severity == SeverityLevel.LOW:
                summary.low += 1
            else:
                summary.info += 1
        
        summary.total = len(findings)
        return summary
    
    def _calculate_category_summaries(self, findings: List) -> List[CategorySummary]:
        """Calculate category summaries from findings."""
        category_counts: Dict[FindingCategory, Dict[str, int]] = {}
        
        if not findings:
            return []
        
        for finding in findings:
            if not finding or not hasattr(finding, 'category'):
                continue
            if finding.category not in category_counts:
                category_counts[finding.category] = {
                    "count": 0,
                    "critical": 0,
                    "high": 0,
                }
            
            category_counts[finding.category]["count"] += 1
            if finding.severity == SeverityLevel.CRITICAL:
                category_counts[finding.category]["critical"] += 1
            elif finding.severity == SeverityLevel.HIGH:
                category_counts[finding.category]["high"] += 1
        
        return [
            CategorySummary(
                category=category,
                count=counts["count"],
                critical_count=counts["critical"],
                high_count=counts["high"],
            )
            for category, counts in category_counts.items()
        ]
    
    def _generate_recommendations(self, findings: List) -> List[str]:
        """Generate prioritized recommendations from findings."""
        recommendations = []
        seen = set()
        
        # Sort by severity
        sorted_findings = sorted(
            findings,
            key=lambda f: (
                0 if f.severity == SeverityLevel.CRITICAL else
                1 if f.severity == SeverityLevel.HIGH else
                2 if f.severity == SeverityLevel.MEDIUM else 3
            ),
        )
        
        for finding in sorted_findings:
            if not finding:
                continue
            if finding.recommendation and finding.recommendation not in seen:
                recommendations.append(finding.recommendation)
                seen.add(finding.recommendation)
        
        return recommendations[:20]  # Top 20
    
    def _get_immediate_actions(self, critical_findings: List) -> List[str]:
        """Get immediate actions for critical findings."""
        actions = []
        
        if not critical_findings:
            return []
        
        for finding in critical_findings:
            if not finding:
                continue
            action = f"[{finding.category.value.upper()}] {finding.title}: {finding.recommendation}"
            actions.append(action)
        
        return actions
    
    def _get_compliance_summary(
        self,
        findings: List,
        frameworks: List[str] = None,
    ) -> Dict[str, Any]:
        """Get compliance summary."""
        summary = {}
        
        if not findings:
            return summary
        
        for finding in findings:
            if not finding or not hasattr(finding, 'compliance') or not finding.compliance:
                continue
            compliance_list = finding.compliance if isinstance(finding.compliance, list) else [finding.compliance]
            for mapping in compliance_list:
                framework = mapping.framework.value
                if framework not in summary:
                    summary[framework] = {"failing": 0, "controls": set()}
                
                summary[framework]["failing"] += 1
                summary[framework]["controls"].add(mapping.control_id)
        
        # Convert sets to lists
        for framework in summary:
            summary[framework]["controls"] = list(summary[framework]["controls"])
        
        return summary
    
    def _create_reproduction_steps(
        self,
        options: ScanOptions,
        critical_findings: List,
    ) -> List[ReproStep]:
        """Create reproduction steps for critical findings."""
        steps = []
        
        critical_list = [f for f in (critical_findings or []) if f][:5]
        for i, finding in enumerate(critical_list):  # Top 5 critical
            # Build command string from finding's commands
            command_str = None
            if finding and hasattr(finding, 'commands') and finding.commands and hasattr(finding.commands, 'commands') and finding.commands.commands:
                command_str = "\n".join(finding.commands.commands)
                if finding.commands.description:
                    command_str = f"# {finding.commands.description}\n{command_str}"
                if finding.commands.server:
                    command_str = f"# Target: {finding.commands.server}\n{command_str}"
            
            step = ReproStep(
                title=finding.title,
                preconditions=[
                    f"Network access to {finding.host}",
                    "Database client tools installed",
                ] if finding.host else None,
                target=f"{finding.host}" if finding.host else finding.database_name,
                action=command_str or finding.description,
                payload=finding.remediation_sql,
                expected_outcome=f"Vulnerability confirmed: {finding.potential_impact}",
                evidence=finding.evidence,
                tooling=["psql", "mysql", "sqlmap", "tcpdump"],
                safety="Use only in authorized test environments",
                cleanup=None,
            )
            steps.append(step)
            
            # Also attach reproduction steps to the finding
            if not finding.reproduction_steps:
                finding.reproduction_steps = [step]
        
        return steps
    
    async def hook_database_discovery(
        self,
        targets: List[str] = None,
        ports: List[int] = None,
        scan_local: bool = True,
    ) -> Dict[str, Any]:
        """
        Discover databases in the network.
        
        Args:
            targets: List of IP addresses or CIDR ranges to scan
            ports: Ports to scan (defaults to common database ports)
            scan_local: Whether to scan for local databases
            
        Returns:
            Dictionary with discovered databases
        """
        discovered = []
        findings = []
        
        # Scan local databases
        if scan_local:
            local_dbs = await asyncio.to_thread(self.discovery_service.scan_local)
            if local_dbs and isinstance(local_dbs, list):
                discovered.extend(local_dbs)
            local_findings = await asyncio.to_thread(self.discovery_service.get_findings)
            if local_findings and isinstance(local_findings, list):
                findings.extend(local_findings)
        
        # Scan network if targets provided
        if targets and isinstance(targets, list) and len(targets) > 0:
            network_dbs = await asyncio.to_thread(self.discovery_service.scan_network, targets, ports)
            if network_dbs and isinstance(network_dbs, list):
                discovered.extend(network_dbs)
        
        return {
            "discovered_databases": [
                {
                    "host": db.host if hasattr(db, 'host') else "localhost",
                    "port": db.port if hasattr(db, 'port') else 5432,
                    "database_type": db.database_type.value if hasattr(db, 'database_type') and db.database_type else "unknown",
                    "version": db.version if hasattr(db, 'version') else None,
                    "ssl_enabled": db.ssl_enabled if hasattr(db, 'ssl_enabled') else False,
                }
                for db in (discovered or [])
                if db
            ],
            "total_discovered": len(discovered) if discovered else 0,
            "findings": findings,
        }
    
    async def hook_database_sql_injection_scan(
        self,
        host: str,
        port: int,
        database_type: str = None,
        parameters: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Scan for SQL injection vulnerabilities.
        
        Args:
            host: Database host
            port: Database port
            database_type: Type of database
            parameters: Specific parameters to test
            
        Returns:
            Dictionary with SQL injection findings
        """
        db_type = DatabaseType(database_type) if database_type else DatabaseType.UNKNOWN
        
        findings = []
        
        # This would typically receive a test function from caller
        # For standalone use, we report capabilities
        
        return {
            "host": host,
            "port": port,
            "database_type": db_type.value,
            "capabilities": {
                "error_based": True,
                "union_based": True,
                "boolean_based": True,
                "time_based": True,
                "nosql_injection": db_type in [DatabaseType.MONGODB, DatabaseType.COUCHDB, DatabaseType.REDIS],
            },
            "payload_count": {
                "error_based": 19,
                "union_based": 8,
                "boolean_based": 8,
                "time_based": 10,
            },
            "findings": findings,
        }
    
    async def hook_database_privilege_escalation_check(
        self,
        host: str,
        port: int,
        database_type: str = None,
        username: str = None,
        password: str = None,
    ) -> Dict[str, Any]:
        """
        Check for privilege escalation paths.
        
        Args:
            host: Database host
            port: Database port
            database_type: Type of database
            username: Database username
            password: Database password
            
        Returns:
            Dictionary with privilege escalation findings
        """
        db_type = DatabaseType(database_type) if database_type else self._detect_db_type(port)
        
        # Get escalation techniques for this database type
        from .modules.services.privilege_escalation_service import PRIVILEGE_ESCALATION_TECHNIQUES
        
        techniques = PRIVILEGE_ESCALATION_TECHNIQUES.get(db_type, {})
        
        return {
            "host": host,
            "port": port,
            "database_type": db_type.value,
            "available_techniques": list(techniques.keys()),
            "technique_details": {
                name: {
                    "description": config["description"],
                    "checks_count": len(config.get("checks", [])),
                }
                for name, config in techniques.items()
            },
            "findings": self.privilege_escalation_service.get_findings(),
        }
    
    def _detect_db_type(self, port: int) -> DatabaseType:
        """Detect database type from port."""
        port_map = {
            5432: DatabaseType.POSTGRESQL,
            3306: DatabaseType.MYSQL,
            1433: DatabaseType.MSSQL,
            1521: DatabaseType.ORACLE,
            27017: DatabaseType.MONGODB,
            6379: DatabaseType.REDIS,
            9042: DatabaseType.CASSANDRA,
            9200: DatabaseType.ELASTICSEARCH,
        }
        return port_map.get(port, DatabaseType.UNKNOWN)

