import asyncio
import inspect
import re
from utils.logger import logger

class BasePlugin:
    """
    Base class for all security-agent plugins.

    Plugin architecture:
    - run() — main entry point, invoked when the plugin starts
    - hook_*() — plugin-specific commands (e.g. hook_scan, hook_map)
    - Parameters are passed via self.options (dict)
    - Hook methods are registered automatically on initialization

    Example implementation:
        class MyPlugin(BasePlugin):
            VERSION = "1.0.0"
            
            async def run(self):
                # Main plugin logic
                return await self.hook_scan()
            
            async def hook_scan(self, root_dir="/", **kwargs):
                '''
                System scan
                
                Args:
                    root_dir: Root directory to scan
                    
                Examples:
                    plugin:my_plugin scan root_dir=/etc
                    plugin:my_plugin scan root_dir=/home max_files=1000
                '''
                # Scan implementation
                pass
    """
    
    # Plugin version — must be overridden in subclasses
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        self.ws = ws
        self.command_id = command_id
        self.options = options
        self.hooks = {}
        self._parse_args()
        self._auto_register_hooks()

    @property
    def version(self):
        """Returns the plugin version."""
        return getattr(self, 'VERSION', '1.0.0')

    async def run(self):
        """
        Main plugin entry point.
        
        Called when the plugin starts; should contain the main logic
        or delegate to the appropriate hook methods.
        
        Raises:
            NotImplementedError: If the method is not overridden in a subclass
        """
        raise NotImplementedError("Plugin must implement run")

    def to_security_scan_v1(self, output):
        """
        Helper for security plugins: wrap/normalize any plugin output to canonical
        security_scan v1 contract.
        
        This is intentionally safe to call for any plugin: if plugin_name is not
        considered "security" by the contract, the output is returned as-is.
        """
        try:
            from plugins.security_contract import is_security_plugin, normalize_security_output
            plugin_name = None
            if isinstance(self.options, dict):
                plugin_name = self.options.get("plugin") or self.options.get("plugin_name")
            if not plugin_name:
                # Best-effort: fallback to module path ...plugins.<name>.*
                mod = getattr(self.__class__, "__module__", "") or ""
                if ".plugins." in mod:
                    plugin_name = mod.split(".plugins.", 1)[1].split(".", 1)[0]

            if not plugin_name or not is_security_plugin(plugin_name):
                return output

            plugin_options = self.options if isinstance(self.options, dict) else None
            return normalize_security_output(plugin_name, output, plugin_options=plugin_options)
        except Exception:
            # Never fail a plugin run because of postprocessing
            return output

    def _parse_args(self):
        """
        Parses arguments from self.options['args'] and merges them into self.options.
        
        Argument format: key=value or key='json_value'
        """
        args = self.options.get('args', []) if self.options else []
        if args is None:
            args = []
        if not isinstance(args, list):
            args = []
        for arg in args:
            if '=' in arg:
                key, value = arg.split('=', 1)
                # Try to parse JSON values
                if value.startswith('{') and value.endswith('}'):
                    try:
                        import json
                        value = json.loads(value)
                    except json.JSONDecodeError:
                        pass  # Keep as string
                elif value.startswith('[') and value.endswith(']'):
                    try:
                        import json
                        value = json.loads(value)
                    except json.JSONDecodeError:
                        pass  # Keep as string
                else:
                    # Try to convert to bool when applicable
                    try:
                        v = str(value).strip().lower()
                        if v in ("true", "1", "yes", "y", "on"):
                            value = True
                        elif v in ("false", "0", "no", "n", "off"):
                            value = False
                    except Exception:
                        # On any issue — leave value unchanged
                        pass

                    # Try to convert to a number when applicable
                    try:
                        # Do not convert bool to int/float
                        if not isinstance(value, bool):
                            if '.' in value:
                                value = float(value)
                            else:
                                value = int(value)
                    except (ValueError, TypeError):
                        pass  # Keep as string
                self.options[key] = value

    def _auto_register_hooks(self):
        """
        Automatically registers all hook methods on the plugin.
        
        Finds every method whose name starts with 'hook_' and adds it
        to self.hooks for later use.
        """
        for attr in dir(self):
            if attr.startswith("hook_") and callable(getattr(self, attr)):
                hook_name = attr[5:]  # strip 'hook_' prefix
                self.hooks[hook_name] = getattr(self, attr)

    def register_hook(self, name, fn):
        """
        Registers a custom hook method.
        
        Args:
            name (str): Hook name
            fn (callable): Function to run
        """
        self.hooks[name] = fn

    async def run_custom_hook(self, hook_name, **kwargs):
        """
        Runs the specified hook method.
        
        Args:
            hook_name (str): Name of the hook to run
            **kwargs: Arguments passed to the hook
            
        Returns:
            Hook return value or None on error
        """
        if hook_name not in self.hooks:
            logger.error(f"Unknown custom hook: {hook_name}")
            return None
        try:
            result = await self.hooks[hook_name](**kwargs)
            return result
        except Exception as e:
            logger.exception(f"Exception in custom hook {hook_name}: {e}")
            return None

    async def run_all_hooks(self, **kwargs):
        """
        Runs all registered hook methods.
        
        Args:
            **kwargs: Arguments passed to every hook
            
        Returns:
            dict: Map of hook name to return value
        """
        results = {}
        for name in self.hooks:
            results[name] = await self.run_custom_hook(name, **kwargs)
        return results

    def get_command_examples(self):
        """
        Extracts command examples from plugin method docstrings.
        
        Looks for sections starting with 'Examples:' or 'Example:'
        and returns them in a structured form.
        
        Returns:
            dict: Command examples per method name
        """
        examples = {}
        
        # Check main run method
        if hasattr(self, 'run'):
            run_examples = self._extract_examples_from_docstring(self.run.__doc__)
            if run_examples:
                examples['run'] = run_examples
        
        # Check all hook methods
        for hook_name, hook_method in self.hooks.items():
            hook_examples = self._extract_examples_from_docstring(hook_method.__doc__)
            if hook_examples:
                examples[hook_name] = hook_examples
        
        return examples
    
    def _extract_examples_from_docstring(self, docstring):
        """
        Extracts command examples from a docstring.
        
        Args:
            docstring (str): Method docstring
            
        Returns:
            list: Unique command example strings
        """
        if not docstring:
            return []
        
        examples = []
        
        # Find example sections
        example_patterns = [
            r'Examples?:\s*\n(.*?)(?=\n\s*\n|\n\s*[A-Z]|\Z)',
            r'Examples?:\s*(.*?)(?=\n\s*\n|\n\s*[A-Z]|\Z)',
            r'Example:\s*\n(.*?)(?=\n\s*\n|\n\s*[A-Z]|\Z)',
            r'Example:\s*(.*?)(?=\n\s*\n|\n\s*[A-Z]|\Z)'
        ]
        
        for pattern in example_patterns:
            matches = re.findall(pattern, docstring, re.DOTALL | re.IGNORECASE)
            for match in matches:
                # Split into individual examples
                lines = match.strip().split('\n')
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Strip bullets and numbering
                        line = re.sub(r'^\s*[-*]\s*', '', line)
                        line = re.sub(r'^\s*\d+\.\s*', '', line)
                        if line:
                            examples.append(line)
        
        # Deduplicate while preserving order
        unique_examples = list(dict.fromkeys(examples))
        return unique_examples


