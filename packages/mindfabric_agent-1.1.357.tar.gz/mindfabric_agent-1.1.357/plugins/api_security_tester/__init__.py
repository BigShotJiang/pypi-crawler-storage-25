"""
API Security Tester Plugin

Comprehensive API security testing covering:
- REST API (BOLA, BFLA, Mass Assignment, Injection)
- GraphQL (Introspection, DoS, Batching, Authorization)
- OAuth 2.0/OIDC (Redirect URI, State, PKCE, Token Leakage)
- JWT (None Algorithm, Algorithm Confusion, Weak Secret, Claim Tampering)

Includes OWASP API Security Top 10 2023 coverage.
"""

from .api_security_tester import (
    APISecurityTesterPlugin,
    test_api_security,
    analyze_jwt_token,
    get_owasp_api_top10,
    get_test_categories,
)
from .modules.services import (
    RESTSecurityService as RESTSecurityTester,
    GraphQLSecurityService as GraphQLSecurityTester,
    OAuthSecurityService as OAuthSecurityTester,
    JWTSecurityService as JWTSecurityTester,
    ConfigurationSecurityService as ConfigurationTester,
)
from .proto import (
    # Enums
    SeverityLevel,
    ConfidenceLevel,
    FindingStatus,
    TestCategory,
    TestSubCategory,
    HTTPMethod,
    AuthType,
    APIType,
    OAuthGrantType,
    JWTAlgorithm,
    OWASPCategory,
    CWECategory,
    # API Models
    APIEndpoint,
    GraphQLOperation,
    GraphQLSchema,
    OAuthConfig,
    JWTInfo,
    # Request/Response
    TestRequest,
    TestResponse,
    TestCase,
    TestResult,
    # Finding Models
    APISecurityFinding,
    # REST Models
    RESTAPIInfo,
    BOLATestResult,
    MassAssignmentResult,
    # GraphQL Models
    GraphQLEndpointInfo,
    GraphQLIntrospectionResult,
    GraphQLDoSResult,
    # OAuth Models
    OAuthFlowResult,
    RedirectURITestResult,
    TokenLeakageResult,
    # JWT Models
    JWTAnalysis,
    JWTAttackResult,
    # Auth Models
    AuthenticationTestResult,
    AuthorizationTestResult,
    # Rate Limiting
    RateLimitTestResult,
    # Config
    APITarget,
    ScanOptions,
    # Output
    SeveritySummary,
    CategorySummary,
    OWASPSummary,
    EndpointSummary,
    ScanMetadata,
    APISecurityScanOutput,
)

__all__ = [
    # Main classes
    "APISecurityTesterPlugin",
    "test_api_security",
    "analyze_jwt_token",
    "get_owasp_api_top10",
    "get_test_categories",
    "RESTSecurityTester",
    "GraphQLSecurityTester",
    "OAuthSecurityTester",
    "JWTSecurityTester",
    "ConfigurationTester",
    # Enums
    "SeverityLevel",
    "ConfidenceLevel",
    "FindingStatus",
    "TestCategory",
    "TestSubCategory",
    "HTTPMethod",
    "AuthType",
    "APIType",
    "OAuthGrantType",
    "JWTAlgorithm",
    "OWASPCategory",
    "CWECategory",
    # API Models
    "APIEndpoint",
    "GraphQLOperation",
    "GraphQLSchema",
    "OAuthConfig",
    "JWTInfo",
    # Request/Response
    "TestRequest",
    "TestResponse",
    "TestCase",
    "TestResult",
    # Finding Models
    "APISecurityFinding",
    # REST Models
    "RESTAPIInfo",
    "BOLATestResult",
    "MassAssignmentResult",
    # GraphQL Models
    "GraphQLEndpointInfo",
    "GraphQLIntrospectionResult",
    "GraphQLDoSResult",
    # OAuth Models
    "OAuthFlowResult",
    "RedirectURITestResult",
    "TokenLeakageResult",
    # JWT Models
    "JWTAnalysis",
    "JWTAttackResult",
    # Auth Models
    "AuthenticationTestResult",
    "AuthorizationTestResult",
    # Rate Limiting
    "RateLimitTestResult",
    # Config
    "APITarget",
    "ScanOptions",
    # Output
    "SeveritySummary",
    "CategorySummary",
    "OWASPSummary",
    "EndpointSummary",
    "ScanMetadata",
    "APISecurityScanOutput",
]

__version__ = "1.0.0"
