"""
API Security Tester Plugin - Pydantic Models

Comprehensive API security testing covering REST, GraphQL,
OAuth 2.0/OIDC, and JWT vulnerabilities.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional, Union
from plugins.reproduction import ReproStep
from pydantic import BaseModel, Field


# =============================================================================
# Supporting Models
# =============================================================================

class ExploitationCommands(BaseModel):
    """Explicit exploitation commands for display in UI."""
    server: Optional[str] = Field(None, description="Target server")
    ip: Optional[str] = Field(None, description="Target IP")
    commands: List[str] = Field(default_factory=list, description="Shell commands")
    description: Optional[str] = Field(None, description="What these commands accomplish")


# =============================================================================
# Enumerations
# =============================================================================

class SeverityLevel(str, Enum):
    """Severity classification for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ConfidenceLevel(str, Enum):
    """Confidence level for detections."""
    CONFIRMED = "confirmed"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    TENTATIVE = "tentative"


class FindingStatus(str, Enum):
    """Status of a finding."""
    OPEN = "open"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    FIXED = "fixed"
    ACCEPTED_RISK = "accepted_risk"


class TestCategory(str, Enum):
    """Categories of API security testing."""
    REST_API = "rest_api"
    GRAPHQL = "graphql"
    OAUTH = "oauth"
    JWT = "jwt"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    INPUT_VALIDATION = "input_validation"
    RATE_LIMITING = "rate_limiting"
    DATA_EXPOSURE = "data_exposure"
    INJECTION = "injection"
    CONFIGURATION = "configuration"
    TRANSPORT_SECURITY = "transport_security"
    AI_ML_SECURITY = "ai_ml_security"
    OTHER = "other"


class TestSubCategory(str, Enum):
    """Detailed sub-categories for tests."""
    # REST API
    BOLA = "bola"  # Broken Object Level Authorization
    BFLA = "bfla"  # Broken Function Level Authorization
    MASS_ASSIGNMENT = "mass_assignment"
    EXCESSIVE_DATA_EXPOSURE = "excessive_data_exposure"
    LACK_OF_RESOURCES_RATE_LIMITING = "lack_of_resources_rate_limiting"
    SSRF = "ssrf"
    IMPROPER_INVENTORY = "improper_inventory"
    UNSAFE_CONSUMPTION = "unsafe_consumption"
    
    # GraphQL
    GRAPHQL_INTROSPECTION = "graphql_introspection"
    GRAPHQL_DOS = "graphql_dos"
    GRAPHQL_BATCHING = "graphql_batching"
    GRAPHQL_DEPTH_LIMIT = "graphql_depth_limit"
    GRAPHQL_FIELD_SUGGESTION = "graphql_field_suggestion"
    GRAPHQL_INJECTION = "graphql_injection"
    GRAPHQL_AUTHORIZATION = "graphql_authorization"
    GRAPHQL_ALIAS_OVERLOAD = "graphql_alias_overload"
    
    # OAuth
    OAUTH_REDIRECT_URI = "oauth_redirect_uri"
    OAUTH_STATE_BYPASS = "oauth_state_bypass"
    OAUTH_PKCE_BYPASS = "oauth_pkce_bypass"
    OAUTH_TOKEN_LEAKAGE = "oauth_token_leakage"
    OAUTH_SCOPE_ABUSE = "oauth_scope_abuse"
    OAUTH_CLIENT_SECRET_EXPOSURE = "oauth_client_secret_exposure"
    OAUTH_IMPLICIT_FLOW = "oauth_implicit_flow"
    OAUTH_CODE_INJECTION = "oauth_code_injection"
    OAUTH_OPEN_REDIRECT = "oauth_open_redirect"
    OAUTH_MIX_UP_ATTACK = "oauth_mix_up_attack"
    
    # JWT
    JWT_NONE_ALGORITHM = "jwt_none_algorithm"
    JWT_ALGORITHM_CONFUSION = "jwt_algorithm_confusion"
    JWT_WEAK_SECRET = "jwt_weak_secret"
    JWT_KEY_INJECTION = "jwt_key_injection"
    JWT_CLAIM_TAMPERING = "jwt_claim_tampering"
    JWT_EXPIRED_TOKEN = "jwt_expired_token"
    JWT_SIGNATURE_BYPASS = "jwt_signature_bypass"
    JWT_KID_INJECTION = "jwt_kid_injection"
    JWT_JKU_INJECTION = "jwt_jku_injection"
    JWT_X5U_INJECTION = "jwt_x5u_injection"
    
    # Authentication
    BROKEN_AUTH = "broken_auth"
    CREDENTIAL_STUFFING = "credential_stuffing"
    BRUTE_FORCE = "brute_force"
    SESSION_FIXATION = "session_fixation"
    INSECURE_PASSWORD_RESET = "insecure_password_reset"
    MFA_BYPASS = "mfa_bypass"
    
    # Authorization
    PRIVILEGE_ESCALATION = "privilege_escalation"
    IDOR = "idor"
    HORIZONTAL_PRIVILEGE = "horizontal_privilege"
    VERTICAL_PRIVILEGE = "vertical_privilege"
    
    # Input Validation
    SQL_INJECTION = "sql_injection"
    NOSQL_INJECTION = "nosql_injection"
    COMMAND_INJECTION = "command_injection"
    XSS = "xss"
    XXE = "xxe"
    PATH_TRAVERSAL = "path_traversal"
    
    # Configuration
    CORS_MISCONFIGURATION = "cors_misconfiguration"
    SECURITY_HEADERS = "security_headers"
    DEBUG_ENABLED = "debug_enabled"
    VERBOSE_ERRORS = "verbose_errors"
    
    # Transport
    INSECURE_TLS = "insecure_tls"
    MISSING_HTTPS = "missing_https"
    CERTIFICATE_ISSUES = "certificate_issues"

    # gRPC
    GRPC_REFLECTION = "grpc_reflection"
    GRPC_INSECURE_CHANNEL = "grpc_insecure_channel"
    GRPC_NO_TLS = "grpc_no_tls"
    GRPC_WEAK_AUTH = "grpc_weak_auth"
    GRPC_DOS = "grpc_dos"
    GRPC_MESSAGE_SIZE = "grpc_message_size"
    GRPC_METADATA_INJECTION = "grpc_metadata_injection"
    GRPC_DEADLINE_ABUSE = "grpc_deadline_abuse"
    GRPC_STREAM_EXHAUSTION = "grpc_stream_exhaustion"
    GRPC_PROTO_POISONING = "grpc_proto_poisoning"
    
    # WebSocket
    WEBSOCKET_ORIGIN_BYPASS = "websocket_origin_bypass"
    WEBSOCKET_NO_AUTH = "websocket_no_auth"
    WEBSOCKET_INJECTION = "websocket_injection"
    WEBSOCKET_DOS = "websocket_dos"
    WEBSOCKET_HIJACKING = "websocket_hijacking"
    WEBSOCKET_CSWSH = "websocket_cswsh"  # Cross-Site WebSocket Hijacking
    WEBSOCKET_MESSAGE_TAMPERING = "websocket_message_tampering"
    WEBSOCKET_INSECURE_PROTOCOL = "websocket_insecure_protocol"
    WEBSOCKET_RATE_LIMITING = "websocket_rate_limiting"
    WEBSOCKET_RECONNECTION_ABUSE = "websocket_reconnection_abuse"
    
    # AI/ML Security
    PROMPT_INJECTION = "prompt_injection"
    API_KEY_EXPOSURE = "api_key_exposure"
    RATE_LIMITING_BYPASS = "rate_limiting_bypass"
    ADVERSARIAL_INPUT = "adversarial_input"
    MODEL_EXTRACTION = "model_extraction"
    AI_SUPPLY_CHAIN = "ai_supply_chain"
    LLM_JAILBREAK = "llm_jailbreak"
    AI_DATA_POISONING = "ai_data_poisoning"


class HTTPMethod(str, Enum):
    """HTTP methods."""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    OPTIONS = "OPTIONS"
    HEAD = "HEAD"
    TRACE = "TRACE"


class AuthType(str, Enum):
    """Authentication types."""
    NONE = "none"
    BASIC = "basic"
    BEARER = "bearer"
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    JWT = "jwt"
    COOKIE = "cookie"
    CUSTOM = "custom"


class APIType(str, Enum):
    """API types."""
    REST = "rest"
    GRAPHQL = "graphql"
    GRPC = "grpc"
    SOAP = "soap"
    WEBSOCKET = "websocket"


class OAuthGrantType(str, Enum):
    """OAuth 2.0 grant types."""
    AUTHORIZATION_CODE = "authorization_code"
    CLIENT_CREDENTIALS = "client_credentials"
    PASSWORD = "password"
    IMPLICIT = "implicit"
    REFRESH_TOKEN = "refresh_token"
    DEVICE_CODE = "device_code"
    JWT_BEARER = "jwt_bearer"


class JWTAlgorithm(str, Enum):
    """JWT algorithms."""
    NONE = "none"
    HS256 = "HS256"
    HS384 = "HS384"
    HS512 = "HS512"
    RS256 = "RS256"
    RS384 = "RS384"
    RS512 = "RS512"
    ES256 = "ES256"
    ES384 = "ES384"
    ES512 = "ES512"
    PS256 = "PS256"
    PS384 = "PS384"
    PS512 = "PS512"


class OWASPCategory(str, Enum):
    """OWASP API Security Top 10 2023."""
    API1_BOLA = "API1:2023 Broken Object Level Authorization"
    API2_BROKEN_AUTH = "API2:2023 Broken Authentication"
    API3_BOPLA = "API3:2023 Broken Object Property Level Authorization"
    API4_UNRESTRICTED_RESOURCE = "API4:2023 Unrestricted Resource Consumption"
    API5_BFLA = "API5:2023 Broken Function Level Authorization"
    API6_UNRESTRICTED_SENSITIVE = "API6:2023 Unrestricted Access to Sensitive Business Flows"
    API7_SSRF = "API7:2023 Server Side Request Forgery"
    API8_SECURITY_MISCONFIG = "API8:2023 Security Misconfiguration"
    API9_IMPROPER_INVENTORY = "API9:2023 Improper Inventory Management"
    API10_UNSAFE_CONSUMPTION = "API10:2023 Unsafe Consumption of APIs"


class CWECategory(str, Enum):
    """Common Weakness Enumeration categories."""
    CWE_22 = "CWE-22: Path Traversal"
    CWE_78 = "CWE-78: OS Command Injection"
    CWE_79 = "CWE-79: Cross-site Scripting"
    CWE_89 = "CWE-89: SQL Injection"
    CWE_287 = "CWE-287: Improper Authentication"
    CWE_306 = "CWE-306: Missing Authentication"
    CWE_307 = "CWE-307: Brute Force"
    CWE_311 = "CWE-311: Missing Encryption"
    CWE_345 = "CWE-345: Insufficient Verification"
    CWE_346 = "CWE-346: Origin Validation Error"
    CWE_352 = "CWE-352: CSRF"
    CWE_384 = "CWE-384: Session Fixation"
    CWE_400 = "CWE-400: Resource Exhaustion"
    CWE_434 = "CWE-434: Unrestricted Upload"
    CWE_522 = "CWE-522: Insufficiently Protected Credentials"
    CWE_601 = "CWE-601: Open Redirect"
    CWE_611 = "CWE-611: XXE"
    CWE_639 = "CWE-639: IDOR"
    CWE_732 = "CWE-732: Incorrect Permission"
    CWE_798 = "CWE-798: Hard-coded Credentials"
    CWE_918 = "CWE-918: SSRF"
    CWE_942 = "CWE-942: Permissive CORS"


# =============================================================================
# API Models
# =============================================================================

class APIEndpoint(BaseModel):
    """API endpoint definition."""
    path: str = Field(..., description="Endpoint path")
    method: HTTPMethod = Field(..., description="HTTP method")
    
    # Description
    name: Optional[str] = Field(None, description="Endpoint name")
    description: Optional[str] = Field(None, description="Description")
    tags: Optional[List[str]] = Field(None, description="Tags")
    
    # Parameters
    path_params: Optional[List[str]] = Field(None, description="Path parameters")
    query_params: Optional[Dict[str, Any]] = Field(None, description="Query params")
    headers: Optional[Dict[str, str]] = Field(None, description="Headers")
    body_schema: Optional[Dict[str, Any]] = Field(None, description="Request body")
    
    # Authentication
    auth_required: bool = Field(False, description="Auth required")
    auth_type: Optional[AuthType] = Field(None, description="Auth type")
    scopes: Optional[List[str]] = Field(None, description="Required scopes")
    
    # Response
    response_codes: Optional[List[int]] = Field(None, description="Response codes")
    response_schema: Optional[Dict[str, Any]] = Field(None, description="Response")


class GraphQLOperation(BaseModel):
    """GraphQL operation definition."""
    operation_type: str = Field(..., description="query/mutation/subscription")
    name: str = Field(..., description="Operation name")
    
    # Fields
    fields: Optional[List[str]] = Field(None, description="Fields")
    arguments: Optional[Dict[str, Any]] = Field(None, description="Arguments")
    
    # Authorization
    auth_required: bool = Field(False, description="Auth required")
    allowed_roles: Optional[List[str]] = Field(None, description="Allowed roles")


class GraphQLSchema(BaseModel):
    """GraphQL schema information."""
    types: List[Dict[str, Any]] = Field(default_factory=list, description="Types")
    queries: List[str] = Field(default_factory=list, description="Queries")
    mutations: List[str] = Field(default_factory=list, description="Mutations")
    subscriptions: List[str] = Field(default_factory=list, description="Subscriptions")
    
    # Introspection
    introspection_enabled: bool = Field(True, description="Introspection on")
    
    # Analysis
    max_depth: Optional[int] = Field(None, description="Max query depth")
    complexity_limit: Optional[int] = Field(None, description="Complexity limit")


class OAuthConfig(BaseModel):
    """OAuth 2.0 configuration."""
    authorization_endpoint: str = Field(..., description="Auth endpoint")
    token_endpoint: str = Field(..., description="Token endpoint")
    
    # Optional endpoints
    userinfo_endpoint: Optional[str] = Field(None, description="Userinfo")
    revocation_endpoint: Optional[str] = Field(None, description="Revocation")
    introspection_endpoint: Optional[str] = Field(None, description="Introspection")
    jwks_uri: Optional[str] = Field(None, description="JWKS URI")
    
    # Client
    client_id: Optional[str] = Field(None, description="Client ID")
    client_secret: Optional[str] = Field(None, description="Client secret")
    
    # Settings
    grant_types: List[OAuthGrantType] = Field(
        default_factory=list, description="Grant types"
    )
    scopes: Optional[List[str]] = Field(None, description="Available scopes")
    redirect_uris: Optional[List[str]] = Field(None, description="Redirect URIs")
    
    # Security
    pkce_required: bool = Field(False, description="PKCE required")
    state_required: bool = Field(True, description="State required")


class JWTInfo(BaseModel):
    """JWT token information."""
    raw_token: str = Field(..., description="Raw JWT")
    
    # Header
    algorithm: JWTAlgorithm = Field(..., description="Algorithm")
    token_type: str = Field("JWT", description="Token type")
    key_id: Optional[str] = Field(None, description="Key ID (kid)")
    
    # Payload
    issuer: Optional[str] = Field(None, description="Issuer (iss)")
    subject: Optional[str] = Field(None, description="Subject (sub)")
    audience: Optional[Union[str, List[str]]] = Field(None, description="Audience")
    expiration: Optional[datetime] = Field(None, description="Expiration (exp)")
    issued_at: Optional[datetime] = Field(None, description="Issued at (iat)")
    not_before: Optional[datetime] = Field(None, description="Not before (nbf)")
    jwt_id: Optional[str] = Field(None, description="JWT ID (jti)")
    
    # Custom claims
    custom_claims: Optional[Dict[str, Any]] = Field(None, description="Custom claims")
    
    # Validation
    is_valid: bool = Field(False, description="Signature valid")
    is_expired: bool = Field(False, description="Token expired")
    validation_errors: Optional[List[str]] = Field(None, description="Errors")


# =============================================================================
# Request/Response Models
# =============================================================================

class TestRequest(BaseModel):
    """HTTP request for testing."""
    request_id: str = Field(..., description="Request ID")
    
    # Target
    url: str = Field(..., description="Full URL")
    method: HTTPMethod = Field(..., description="Method")
    
    # Headers
    headers: Dict[str, str] = Field(default_factory=dict, description="Headers")
    
    # Body
    body: Optional[Union[str, Dict[str, Any]]] = Field(None, description="Body")
    content_type: Optional[str] = Field(None, description="Content-Type")
    
    # Auth
    auth_type: Optional[AuthType] = Field(None, description="Auth type")
    auth_token: Optional[str] = Field(None, description="Auth token")
    
    # Timing
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    timeout: int = Field(30, description="Timeout seconds")


class TestResponse(BaseModel):
    """HTTP response from test."""
    request_id: str = Field(..., description="Request ID")
    
    # Response
    status_code: int = Field(..., description="Status code")
    headers: Dict[str, str] = Field(default_factory=dict, description="Headers")
    body: Optional[Union[str, Dict[str, Any]]] = Field(None, description="Body")
    
    # Timing
    response_time_ms: float = Field(..., description="Response time")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    # Analysis
    content_type: Optional[str] = Field(None, description="Content-Type")
    content_length: Optional[int] = Field(None, description="Content-Length")


class TestCase(BaseModel):
    """Test case definition."""
    test_id: str = Field(..., description="Test ID")
    name: str = Field(..., description="Test name")
    description: str = Field(..., description="Description")
    
    # Classification
    category: TestCategory = Field(..., description="Category")
    sub_category: TestSubCategory = Field(..., description="Sub-category")
    
    # OWASP/CWE
    owasp: Optional[OWASPCategory] = Field(None, description="OWASP category")
    cwe: Optional[CWECategory] = Field(None, description="CWE")
    
    # Test details
    endpoint: Optional[str] = Field(None, description="Target endpoint")
    method: Optional[HTTPMethod] = Field(None, description="HTTP method")
    payload: Optional[str] = Field(None, description="Test payload")
    
    # Expected
    expected_status: Optional[int] = Field(None, description="Expected status")
    expected_behavior: Optional[str] = Field(None, description="Expected behavior")
    
    # Severity if vulnerable
    severity: SeverityLevel = Field(SeverityLevel.MEDIUM)


class TestResult(BaseModel):
    """Result of a test case."""
    test_id: str = Field(..., description="Test ID")
    test_name: str = Field(..., description="Test name")
    
    # Result
    passed: bool = Field(..., description="Test passed (no vuln)")
    vulnerable: bool = Field(False, description="Vulnerability found")
    
    # Details
    request: Optional[TestRequest] = Field(None, description="Request sent")
    response: Optional[TestResponse] = Field(None, description="Response")
    
    # Analysis
    evidence: Optional[str] = Field(None, description="Evidence")
    details: Optional[str] = Field(None, description="Details")
    
    # Timing
    duration_ms: float = Field(0, description="Test duration")


# =============================================================================
# Finding Models
# =============================================================================

class APISecurityFinding(BaseModel):
    """API security finding."""
    id: str = Field(..., description="Finding ID")
    
    # Classification
    category: TestCategory = Field(..., description="Category")
    sub_category: TestSubCategory = Field(..., description="Sub-category")
    severity: SeverityLevel = Field(..., description="Severity")
    confidence: ConfidenceLevel = Field(..., description="Confidence")
    
    # OWASP/CWE
    owasp: Optional[OWASPCategory] = Field(None, description="OWASP")
    cwe: Optional[CWECategory] = Field(None, description="CWE")
    
    # Details
    title: str = Field(..., description="Finding title")
    description: str = Field(..., description="Description")
    
    # Location
    endpoint: Optional[str] = Field(None, description="Endpoint")
    method: Optional[HTTPMethod] = Field(None, description="Method")
    parameter: Optional[str] = Field(None, description="Vulnerable param")
    
    # Evidence
    request: Optional[TestRequest] = Field(None, description="Request")
    response: Optional[TestResponse] = Field(None, description="Response")
    evidence: Optional[str] = Field(None, description="Evidence")
    
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = Field(None, description="Curl/API commands")
    
    # Risk
    risk_score: float = Field(0.0, ge=0.0, le=10.0, description="Risk score")
    
    # Remediation
    recommendation: str = Field(..., description="Recommendation")
    remediation_steps: Optional[List[str]] = Field(None, description="Steps")
    references: Optional[List[str]] = Field(None, description="References")
    
    # Status
    status: FindingStatus = Field(FindingStatus.OPEN)
    
    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this finding"
    )


# Backwards-compat alias used by some services.
Finding = APISecurityFinding


# =============================================================================
# REST API Specific Models
# =============================================================================

class RESTAPIInfo(BaseModel):
    """REST API information."""
    base_url: str = Field(..., description="Base URL")
    
    # Version
    version: Optional[str] = Field(None, description="API version")
    
    # Spec
    openapi_spec: Optional[str] = Field(None, description="OpenAPI spec URL")
    swagger_url: Optional[str] = Field(None, description="Swagger UI URL")
    
    # Endpoints
    endpoints: List[APIEndpoint] = Field(default_factory=list)
    
    # Auth
    auth_types: List[AuthType] = Field(default_factory=list)
    
    # Features
    pagination: bool = Field(False, description="Has pagination")
    filtering: bool = Field(False, description="Has filtering")
    rate_limiting: bool = Field(False, description="Has rate limiting")


class BOLATestResult(BaseModel):
    """BOLA (Broken Object Level Authorization) test result."""
    test_id: str = Field(..., description="Test ID")
    endpoint: str = Field(..., description="Endpoint tested")
    
    # Object IDs tested
    original_id: str = Field(..., description="Original object ID")
    target_id: str = Field(..., description="Target object ID")
    
    # Result
    vulnerable: bool = Field(False, description="BOLA vulnerable")
    can_access: bool = Field(False, description="Can access other's object")
    can_modify: bool = Field(False, description="Can modify other's object")
    can_delete: bool = Field(False, description="Can delete other's object")
    
    # Evidence
    evidence: Optional[str] = Field(None, description="Evidence")


class MassAssignmentResult(BaseModel):
    """Mass assignment test result."""
    test_id: str = Field(..., description="Test ID")
    endpoint: str = Field(..., description="Endpoint")
    
    # Fields tested
    injected_fields: List[str] = Field(default_factory=list)
    accepted_fields: List[str] = Field(default_factory=list)
    
    # Sensitive fields
    role_field_accepted: bool = Field(False)
    admin_field_accepted: bool = Field(False)
    id_field_accepted: bool = Field(False)
    
    # Result
    vulnerable: bool = Field(False)


# =============================================================================
# GraphQL Specific Models
# =============================================================================

class GraphQLEndpointInfo(BaseModel):
    """GraphQL endpoint information."""
    endpoint_url: str = Field(..., description="GraphQL endpoint")
    
    # Schema
    graphql_schema: Optional[GraphQLSchema] = Field(None, description="GraphQL schema", alias="schema")
    
    class Config:
        populate_by_name = True
    
    # Security features
    introspection_disabled: bool = Field(False)
    depth_limit: Optional[int] = Field(None)
    complexity_limit: Optional[int] = Field(None)
    rate_limiting: bool = Field(False)
    
    # Auth
    auth_required: bool = Field(False)


class GraphQLIntrospectionResult(BaseModel):
    """GraphQL introspection test result."""
    introspection_enabled: bool = Field(..., description="Enabled")
    
    # Schema info
    types_count: int = Field(0, description="Number of types")
    queries_count: int = Field(0, description="Number of queries")
    mutations_count: int = Field(0, description="Number of mutations")
    
    # Sensitive info exposed
    exposes_internal_types: bool = Field(False)
    exposes_debug_fields: bool = Field(False)
    
    # Full schema
    raw_schema: Optional[Dict[str, Any]] = Field(None)


class GraphQLDoSResult(BaseModel):
    """GraphQL DoS test result."""
    test_type: str = Field(..., description="DoS test type")
    
    # Test parameters
    query_depth: Optional[int] = Field(None, description="Query depth")
    alias_count: Optional[int] = Field(None, description="Alias count")
    batch_size: Optional[int] = Field(None, description="Batch size")
    
    # Result
    request_blocked: bool = Field(False, description="Request blocked")
    response_time_ms: float = Field(0, description="Response time")
    error_returned: bool = Field(False, description="Error returned")
    
    # Analysis
    vulnerable: bool = Field(False, description="Vulnerable to DoS")


# =============================================================================
# OAuth Specific Models
# =============================================================================

class OAuthFlowResult(BaseModel):
    """OAuth flow test result."""
    flow_type: OAuthGrantType = Field(..., description="Flow type")
    
    # Endpoints tested
    authorization_tested: bool = Field(False)
    token_tested: bool = Field(False)
    
    # Vulnerabilities
    redirect_uri_bypass: bool = Field(False)
    state_bypass: bool = Field(False)
    pkce_bypass: bool = Field(False)
    token_leakage: bool = Field(False)
    
    # Evidence
    vulnerable_endpoints: List[str] = Field(default_factory=list)
    evidence: Optional[str] = Field(None)


class RedirectURITestResult(BaseModel):
    """OAuth redirect URI test result."""
    test_id: str = Field(..., description="Test ID")
    
    # Original
    original_uri: str = Field(..., description="Original redirect URI")
    
    # Tests
    tests_performed: List[str] = Field(default_factory=list)
    bypassed_uris: List[str] = Field(default_factory=list)
    
    # Result
    vulnerable: bool = Field(False)
    
    # Bypass techniques that worked
    open_redirect_worked: bool = Field(False)
    subdomain_bypass: bool = Field(False)
    path_traversal: bool = Field(False)
    parameter_pollution: bool = Field(False)


class TokenLeakageResult(BaseModel):
    """Token leakage test result."""
    test_id: str = Field(..., description="Test ID")
    
    # Token type
    token_type: str = Field(..., description="Token type")
    
    # Leakage vectors
    referer_leakage: bool = Field(False)
    browser_history: bool = Field(False)
    server_logs: bool = Field(False)
    url_fragment_leakage: bool = Field(False)
    
    # Result
    vulnerable: bool = Field(False)


# =============================================================================
# JWT Specific Models
# =============================================================================

class JWTAnalysis(BaseModel):
    """JWT token analysis."""
    token_info: JWTInfo = Field(..., description="Token info")
    
    # Algorithm analysis
    uses_none_algorithm: bool = Field(False)
    uses_weak_algorithm: bool = Field(False)
    algorithm_in_token: str = Field(..., description="Algorithm")
    
    # Key analysis
    symmetric_key: bool = Field(False)
    asymmetric_key: bool = Field(False)
    key_size_bits: Optional[int] = Field(None)
    
    # Claims analysis
    missing_exp: bool = Field(False)
    long_expiration: bool = Field(False)
    missing_iat: bool = Field(False)
    missing_iss: bool = Field(False)
    
    # Security issues
    issues: List[str] = Field(default_factory=list)


class JWTAttackResult(BaseModel):
    """JWT attack test result."""
    test_id: str = Field(..., description="Test ID")
    attack_type: TestSubCategory = Field(..., description="Attack type")
    
    # Original token
    original_token: str = Field(..., description="Original JWT")
    
    # Modified token
    modified_token: Optional[str] = Field(None, description="Modified JWT")
    
    # Result
    attack_successful: bool = Field(False)
    server_accepted: bool = Field(False)
    
    # Evidence
    response_status: Optional[int] = Field(None)
    evidence: Optional[str] = Field(None)


# =============================================================================
# Authentication/Authorization Models
# =============================================================================

class AuthenticationTestResult(BaseModel):
    """Authentication test result."""
    test_type: TestSubCategory = Field(..., description="Test type")
    endpoint: str = Field(..., description="Endpoint")
    
    # Result
    vulnerable: bool = Field(False)
    
    # Details
    attempts_before_lockout: Optional[int] = Field(None)
    lockout_duration: Optional[int] = Field(None)
    rate_limited: bool = Field(False)
    
    # Evidence
    evidence: Optional[str] = Field(None)


class AuthorizationTestResult(BaseModel):
    """Authorization test result."""
    test_type: TestSubCategory = Field(..., description="Test type")
    endpoint: str = Field(..., description="Endpoint")
    
    # Roles tested
    source_role: str = Field(..., description="Source role")
    target_role: str = Field(..., description="Target role")
    
    # Result
    escalation_possible: bool = Field(False)
    unauthorized_access: bool = Field(False)
    
    # Evidence
    evidence: Optional[str] = Field(None)


# =============================================================================
# Rate Limiting Models
# =============================================================================

class RateLimitTestResult(BaseModel):
    """Rate limiting test result."""
    endpoint: str = Field(..., description="Endpoint")
    
    # Test parameters
    requests_sent: int = Field(0, description="Requests sent")
    time_window_seconds: int = Field(60, description="Time window")
    
    # Result
    rate_limited: bool = Field(False)
    limit_value: Optional[int] = Field(None, description="Limit value")
    
    # Response
    limit_response_code: Optional[int] = Field(None)
    retry_after: Optional[int] = Field(None)
    
    # Analysis
    rate_limit_missing: bool = Field(False)
    bypass_possible: bool = Field(False)


# =============================================================================
# Scan Configuration
# =============================================================================

class APITarget(BaseModel):
    """API target configuration."""
    base_url: str = Field(..., description="Base URL")
    api_type: APIType = Field(APIType.REST, description="API type")
    
    # Spec files
    openapi_spec: Optional[str] = Field(None, description="OpenAPI spec path/URL")
    graphql_endpoint: Optional[str] = Field(None, description="GraphQL endpoint")
    
    # Auth
    auth_type: Optional[AuthType] = Field(None, description="Auth type")
    auth_token: Optional[str] = Field(None, description="Auth token")
    api_key: Optional[str] = Field(None, description="API key")
    api_key_header: Optional[str] = Field(None, description="API key header name")
    
    # OAuth
    oauth_config: Optional[OAuthConfig] = Field(None, description="OAuth config")
    
    # Headers
    custom_headers: Optional[Dict[str, str]] = Field(None, description="Custom headers")
    
    # Credentials for testing
    test_credentials: Optional[Dict[str, str]] = Field(None, description="Test creds")


class ScanOptions(BaseModel):
    """Configuration options for API security scan."""
    target: APITarget = Field(..., description="Target")
    
    # Categories to test
    categories: Optional[List[TestCategory]] = Field(
        None, description="Categories (None = all)"
    )
    
    # REST tests
    test_bola: bool = Field(True, description="Test BOLA")
    test_bfla: bool = Field(True, description="Test BFLA")
    test_mass_assignment: bool = Field(True, description="Test mass assignment")
    test_injection: bool = Field(True, description="Test injection")
    test_rate_limiting: bool = Field(True, description="Test rate limiting")
    
    # GraphQL tests
    test_introspection: bool = Field(True, description="Test introspection")
    test_graphql_dos: bool = Field(True, description="Test GraphQL DoS")
    test_batching: bool = Field(True, description="Test batching")
    
    # OAuth tests
    test_oauth_flows: bool = Field(True, description="Test OAuth flows")
    test_redirect_uri: bool = Field(True, description="Test redirect URI")
    test_token_leakage: bool = Field(True, description="Test token leakage")
    
    # JWT tests
    test_jwt_attacks: bool = Field(True, description="Test JWT attacks")
    jwt_secret_wordlist: Optional[str] = Field(None, description="JWT wordlist")
    
    # General tests
    test_cors: bool = Field(True, description="Test CORS")
    test_security_headers: bool = Field(True, description="Test headers")
    test_tls: bool = Field(True, description="Test TLS")
    
    # Test settings
    max_requests_per_endpoint: int = Field(100, description="Max requests")
    request_delay_ms: int = Field(100, description="Delay between requests")
    timeout_seconds: int = Field(30, description="Request timeout")
    
    # Severity filter
    min_severity: SeverityLevel = Field(SeverityLevel.LOW)
    
    # Output
    include_evidence: bool = Field(True, description="Include evidence")


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary by severity."""
    critical: int = Field(0)
    high: int = Field(0)
    medium: int = Field(0)
    low: int = Field(0)
    info: int = Field(0)
    total: int = Field(0)


class CategorySummary(BaseModel):
    """Summary by category."""
    category: TestCategory = Field(..., description="Category")
    findings_count: int = Field(0)
    critical: int = Field(0)
    high: int = Field(0)
    tests_run: int = Field(0)
    tests_passed: int = Field(0)


class OWASPSummary(BaseModel):
    """Summary by OWASP API Top 10."""
    category: OWASPCategory = Field(..., description="OWASP category")
    findings_count: int = Field(0)
    severity: SeverityLevel = Field(SeverityLevel.INFO)


class EndpointSummary(BaseModel):
    """Summary per endpoint."""
    endpoint: str = Field(..., description="Endpoint")
    method: HTTPMethod = Field(..., description="Method")
    
    findings_count: int = Field(0)
    critical: int = Field(0)
    high: int = Field(0)
    
    vulnerabilities: List[str] = Field(default_factory=list)


class ScanMetadata(BaseModel):
    """Metadata about the scan."""
    scan_id: str = Field(..., description="Scan ID")
    scan_type: str = Field("api_security", description="Scan type")
    
    # Timing
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(None)
    duration_seconds: Optional[float] = Field(None)
    
    # Target
    target_url: str = Field(..., description="Target URL")
    api_type: APIType = Field(..., description="API type")
    
    # Coverage
    endpoints_discovered: int = Field(0)
    endpoints_tested: int = Field(0)
    tests_executed: int = Field(0)
    requests_sent: int = Field(0)
    
    # Results
    total_findings: int = Field(0)
    
    # Tool
    tool_version: str = Field("2.0.0")


class APISecurityScanOutput(BaseModel):
    """Complete output from API security scan."""
    # Metadata
    metadata: ScanMetadata = Field(..., description="Scan metadata")
    
    # API info
    rest_api_info: Optional[RESTAPIInfo] = Field(None)
    graphql_info: Optional[GraphQLEndpointInfo] = Field(None)
    oauth_config: Optional[OAuthConfig] = Field(None)
    
    # Summaries
    severity_summary: SeveritySummary = Field(default_factory=SeveritySummary)
    category_summaries: List[CategorySummary] = Field(default_factory=list)
    owasp_summaries: List[OWASPSummary] = Field(default_factory=list)
    endpoint_summaries: List[EndpointSummary] = Field(default_factory=list)
    
    # Findings
    findings: List[APISecurityFinding] = Field(default_factory=list)
    critical_findings: List[APISecurityFinding] = Field(default_factory=list)
    
    # Test results
    test_results: List[TestResult] = Field(default_factory=list)
    
    # Specific results
    bola_results: List[BOLATestResult] = Field(default_factory=list)
    jwt_analysis: Optional[JWTAnalysis] = Field(None)
    jwt_attack_results: List[JWTAttackResult] = Field(default_factory=list)
    oauth_results: List[OAuthFlowResult] = Field(default_factory=list)
    graphql_introspection: Optional[GraphQLIntrospectionResult] = Field(None)
    rate_limit_results: List[RateLimitTestResult] = Field(default_factory=list)
    
    # Recommendations
    recommendations: List[str] = Field(default_factory=list)
    quick_wins: List[str] = Field(default_factory=list)
    
    # Errors
    errors: Optional[List[str]] = Field(None)
    warnings: Optional[List[str]] = Field(None)
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )
