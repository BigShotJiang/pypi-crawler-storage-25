"""
Output Service

Service for creating final output.
"""

import copy
import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from collections import defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from ...proto import (
    ScanOptions,
    APISecurityScanOutput,
    RESTAPIInfo,
    SeverityLevel,
    TestCategory,
    TestSubCategory,
    SeveritySummary,
    CategorySummary,
    OWASPSummary,
    OWASPCategory,
    ScanMetadata,
    APISecurityFinding,
    ExploitationCommands,
)
from plugins.reproduction import ReproStep


# 🔴 API EXPLOITATION COMMANDS by category
API_EXPLOIT_COMMANDS: Dict[str, Dict] = {
    "rest_api": {
        "commands": [
            "$ curl -X GET '{endpoint}' -H 'Authorization: Bearer TOKEN'",
            "$ curl -X POST '{endpoint}' -d '{payload}' -H 'Content-Type: application/json'"
        ],
        "description": "REST API security test"
    },
    "graphql": {
        "commands": [
            "$ curl '{endpoint}' -d '{\"query\":\"{ __schema { types { name } } }\"}' -H 'Content-Type: application/json'",
            "$ graphql-cop -t '{endpoint}'",
            "$ curl '{endpoint}' -d '{\"query\":\"query { user(id: \\\"1 OR 1=1\\\") { id } }\"}'"
        ],
        "description": "GraphQL security test"
    },
    "oauth": {
        "commands": [
            "$ curl '{endpoint}/authorize?response_type=code&redirect_uri=https://oauth-callback.example.test/cb'",
            "$ curl '{endpoint}/token' -d 'grant_type=authorization_code&code=${OAUTH_AUTH_CODE}&redirect_uri=https://oauth-callback.example.test/cb'"
        ],
        "description": "OAuth security test"
    },
    "jwt": {
        "commands": [
            "$ python3 -c \"import base64,json,sys; p=sys.argv[1].split('.'); b=p[1]+'='*((4-len(p[1])%4)%4); print(json.dumps(json.loads(base64.urlsafe_b64decode(b)), indent=2))\" \"$JWT\"",
            "$ curl -sS -D- -o /dev/null -H \"Authorization: Bearer $JWT\" '{endpoint}'"
        ],
        "description": "Decode JWT payload (set JWT env) and send a single authenticated request for replay/header checks"
    },
    "bola": {
        "commands": [
            "$ curl '{endpoint}/api/users/1' -H 'Authorization: Bearer USER2_TOKEN'",
            "$ for i in $(seq 1 100); do curl '{endpoint}/api/resource/$i'; done"
        ],
        "description": "BOLA (Broken Object Level Authorization) test"
    },
    "default": {
        "commands": [
            "$ curl -v '{endpoint}'",
            "$ curl '{endpoint}' -H 'X-Forwarded-For: 127.0.0.1'"
        ],
        "description": "API security test"
    }
}


def _api_template_source_for_subcategory(sub: str) -> str:
    if sub in API_EXPLOIT_COMMANDS:
        return sub
    if sub.startswith("graphql_"):
        return "graphql"
    if sub.startswith("oauth_"):
        return "oauth"
    if sub.startswith("jwt_"):
        return "jwt"
    if sub in (
        "bfla",
        "mass_assignment",
        "excessive_data_exposure",
        "lack_of_resources_rate_limiting",
        "ssrf",
        "improper_inventory",
        "unsafe_consumption",
    ):
        return "rest_api"
    if sub in (
        "broken_auth",
        "credential_stuffing",
        "brute_force",
        "session_fixation",
        "insecure_password_reset",
        "mfa_bypass",
    ):
        return "rest_api"
    if sub in (
        "privilege_escalation",
        "idor",
        "horizontal_privilege",
        "vertical_privilege",
    ):
        return "bola"
    if sub in (
        "sql_injection",
        "nosql_injection",
        "command_injection",
        "xss",
        "xxe",
        "path_traversal",
    ):
        return "rest_api"
    if sub in (
        "cors_misconfiguration",
        "security_headers",
        "debug_enabled",
        "verbose_errors",
    ):
        return "rest_api"
    if sub in ("insecure_tls", "missing_https", "certificate_issues"):
        return "rest_api"
    if sub.startswith("grpc_") or sub.startswith("websocket_"):
        return "rest_api"
    if sub in (
        "prompt_injection",
        "api_key_exposure",
        "rate_limiting_bypass",
        "adversarial_input",
        "model_extraction",
        "ai_supply_chain",
        "llm_jailbreak",
        "ai_data_poisoning",
    ):
        return "rest_api"
    return "default"


_CATEGORY_TO_API_TEMPLATE: Dict[str, str] = {
    "rest_api": "rest_api",
    "graphql": "graphql",
    "oauth": "oauth",
    "jwt": "jwt",
    "authentication": "oauth",
    "authorization": "bola",
    "input_validation": "rest_api",
    "rate_limiting": "rest_api",
    "data_exposure": "bola",
    "injection": "rest_api",
    "configuration": "rest_api",
    "transport_security": "rest_api",
    "ai_ml_security": "rest_api",
    "other": "default",
}


def _expand_api_exploit_commands() -> None:
    for member in TestSubCategory:
        key = member.value
        if key in API_EXPLOIT_COMMANDS:
            continue
        src = _api_template_source_for_subcategory(key)
        if src not in API_EXPLOIT_COMMANDS:
            src = "default"
        API_EXPLOIT_COMMANDS[key] = copy.deepcopy(API_EXPLOIT_COMMANDS[src])
    for member in TestCategory:
        key = member.value
        if key in API_EXPLOIT_COMMANDS:
            continue
        src = _CATEGORY_TO_API_TEMPLATE.get(key, "default")
        if src not in API_EXPLOIT_COMMANDS:
            src = "default"
        API_EXPLOIT_COMMANDS[key] = copy.deepcopy(API_EXPLOIT_COMMANDS[src])


_expand_api_exploit_commands()


def build_api_commands(finding: APISecurityFinding) -> Optional[ExploitationCommands]:
    """Build exploitation commands for API finding."""
    cat_str = finding.category.value if hasattr(finding.category, 'value') else str(finding.category)
    subcat_str = finding.sub_category.value if hasattr(finding.sub_category, 'value') else str(finding.sub_category)
    
    cmd_template = API_EXPLOIT_COMMANDS.get(subcat_str, 
                   API_EXPLOIT_COMMANDS.get(cat_str, 
                   API_EXPLOIT_COMMANDS["default"]))
    
    endpoint = finding.endpoint or "http://api.target/"
    payload = "{}"
    
    try:
        parsed = urlparse(endpoint)
        host = parsed.netloc or "api.target"
    except:
        host = "api.target"
    
    commands = []
    for cmd in cmd_template.get("commands", []):
        cmd_replaced = cmd.replace("{endpoint}", endpoint).replace("{payload}", payload)
        commands.append(cmd_replaced)
    
    return ExploitationCommands(
        server=host,
        ip=None,
        commands=commands[:5],
        description=cmd_template.get("description", "API security test")
    )


class OutputService:
    """Service for creating final output."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance

    def _attach_finding_commands(self, findings: List[APISecurityFinding]) -> None:
        """Attach commands to findings."""
        for f in findings:
            if not getattr(f, "commands", None):
                f.commands = build_api_commands(f)

    def _build_reproduction_steps(self) -> List[ReproStep]:
        """
        Build reproduction steps from executed test results.
        """
        steps: List[ReproStep] = []
        
        # 🔴 Attach commands to findings
        self._attach_finding_commands(getattr(self.plugin, "findings", []) or [])

        for tr in getattr(self.plugin, "test_results", []) or []:
            req = getattr(tr, "request", None)
            resp = getattr(tr, "response", None)
            action = None
            target = None
            payload = None
            expected = None
            evidence = None

            if req:
                method = getattr(req, "method", None)
                url = getattr(req, "url", None)
                action = f"{method} {url}" if method and url else None
                target = url
                payload = getattr(req, "body", None)
            if resp:
                status = getattr(resp, "status_code", None)
                expected = f"HTTP {status}" if status is not None else None
                if getattr(resp, "body", None):
                    evidence = f"Response body present ({len(str(resp.body))} chars)"
            if getattr(tr, "evidence", None):
                evidence = tr.evidence
            if getattr(tr, "details", None) and not expected:
                expected = tr.details

            steps.append(
                ReproStep(
                    title=tr.test_name,
                    preconditions=[
                        p for p in [
                            "Auth token required" if getattr(req, "auth_token", None) else None,
                        ] if p
                    ] or None,
                    target=target,
                    action=action,
                    payload=str(payload) if payload is not None else None,
                    expected_outcome=expected,
                    evidence=evidence,
                    tooling=["http", "curl"],
                    safety="May affect target API; run in authorized/lab scope",
                )
            )

        return steps
    
    def create_output(
        self,
        options: ScanOptions,
        api_info: Optional[RESTAPIInfo],
        recommendations: List[str],
        quick_wins: List[str],
    ) -> APISecurityScanOutput:
        """Create the final output."""
        completed = datetime.utcnow()
        duration = (completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0
        
        severity_summary = SeveritySummary(
            critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
            high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            medium=len([f for f in self.plugin.findings if f.severity == SeverityLevel.MEDIUM]),
            low=len([f for f in self.plugin.findings if f.severity == SeverityLevel.LOW]),
            info=len([f for f in self.plugin.findings if f.severity == SeverityLevel.INFO]),
            total=len(self.plugin.findings),
        )
        
        category_summaries = []
        for category in TestCategory:
            cat_findings = [f for f in self.plugin.findings if f.category == category]
            if cat_findings:
                category_summaries.append(CategorySummary(
                    category=category,
                    findings_count=len(cat_findings),
                    critical=len([f for f in cat_findings if f.severity == SeverityLevel.CRITICAL]),
                    high=len([f for f in cat_findings if f.severity == SeverityLevel.HIGH]),
                ))
        
        owasp_summaries = []
        owasp_findings: Dict[OWASPCategory, List[APISecurityFinding]] = defaultdict(list)
        
        for finding in self.plugin.findings:
            if finding.owasp:
                owasp_findings[finding.owasp].append(finding)
        
        for owasp_cat, findings in owasp_findings.items():
            owasp_summaries.append(OWASPSummary(
                category=owasp_cat,
                findings_count=len(findings),
                severity=max(f.severity for f in findings),
            ))
        
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            started_at=self.plugin.scan_start or completed,
            completed_at=completed,
            duration_seconds=duration,
            target_url=options.target.base_url,
            api_type=options.target.api_type,
            endpoints_discovered=len(self.plugin.endpoints),
            endpoints_tested=len(self.plugin.endpoints),
            tests_executed=self.plugin.tests_executed,
            requests_sent=self.plugin.requests_sent,
            total_findings=len(self.plugin.findings),
        )
        
        critical_findings = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]

        # Attach reproduction steps per finding (best-effort) if missing
        for finding in self.plugin.findings:
            if getattr(finding, "reproduction_steps", None):
                continue
            action = None
            if finding.endpoint and finding.method:
                action = f"{finding.method} {finding.endpoint}"
            finding.reproduction_steps = [
                ReproStep(
                    title=finding.title,
                    target=finding.endpoint,
                    action=action,
                    payload=finding.parameter,
                    expected_outcome=finding.evidence or finding.description,
                    evidence=finding.evidence,
                    tooling=["http", "curl"],
                    safety="May affect target API; run in authorized/lab scope",
                )
            ]

        repro_steps = self._build_reproduction_steps()
        
        return APISecurityScanOutput(
            metadata=metadata,
            rest_api_info=api_info,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            owasp_summaries=owasp_summaries,
            findings=self.plugin.findings,
            critical_findings=critical_findings,
            test_results=self.plugin.test_results,
            recommendations=recommendations,
            quick_wins=quick_wins,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            reproduction_steps=repro_steps or None,
        )

