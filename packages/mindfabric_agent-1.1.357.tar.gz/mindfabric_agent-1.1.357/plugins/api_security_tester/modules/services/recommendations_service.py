"""
Recommendations Service

Service for generating recommendations.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Any, List

from ...proto import TestSubCategory, SeverityLevel


class RecommendationsService:
    """Service for generating recommendations."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
    
    def generate_recommendations(self) -> List[str]:
        """Generate prioritized recommendations."""
        recommendations = []
        
        critical = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]
        high = [f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]
        
        if critical:
            recommendations.append(
                f"CRITICAL: {len(critical)} critical vulnerabilities require immediate fix"
            )
        
        categories = {f.sub_category for f in self.plugin.findings}
        
        if TestSubCategory.JWT_NONE_ALGORITHM in categories:
            recommendations.append("Explicitly reject 'none' algorithm in JWT validation")
        
        if TestSubCategory.JWT_WEAK_SECRET in categories:
            recommendations.append("Use strong, random JWT secrets (256+ bits)")
        
        if TestSubCategory.OAUTH_REDIRECT_URI in categories:
            recommendations.append("Implement strict redirect URI validation")
        
        if TestSubCategory.BOLA in categories:
            recommendations.append("Implement proper object-level authorization checks")
        
        if TestSubCategory.GRAPHQL_INTROSPECTION in categories:
            recommendations.append("Disable GraphQL introspection in production")
        
        if TestSubCategory.LACK_OF_RESOURCES_RATE_LIMITING in categories:
            recommendations.append("Implement rate limiting on all endpoints")
        
        recommendations.extend([
            "Use HTTPS for all API endpoints",
            "Implement proper input validation",
            "Add security headers (CSP, HSTS, etc.)",
            "Use parameterized queries to prevent injection",
        ])
        
        return recommendations[:10]
    
    def get_quick_wins(self) -> List[str]:
        """Get easy fixes with high impact."""
        quick_wins = []
        
        if any(f.sub_category == TestSubCategory.SECURITY_HEADERS for f in self.plugin.findings):
            quick_wins.append("Add security headers via middleware/reverse proxy")
        
        if any(f.sub_category == TestSubCategory.GRAPHQL_INTROSPECTION for f in self.plugin.findings):
            quick_wins.append("Disable introspection: introspection: false in schema config")
        
        if any(f.sub_category == TestSubCategory.CORS_MISCONFIGURATION for f in self.plugin.findings):
            quick_wins.append("Configure CORS to allow only trusted origins")
        
        return quick_wins

