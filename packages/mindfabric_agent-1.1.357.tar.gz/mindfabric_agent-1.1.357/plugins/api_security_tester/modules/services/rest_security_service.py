"""
REST Security Service

Service for testing REST API security.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
from typing import Any, List, Optional
from urllib.parse import urljoin

from ...proto import (
    APISecurityFinding,
    APIEndpoint,
    BOLATestResult,
    MassAssignmentResult,
    TestResult,
)
from ..databases.api_security_databases import (
    MASS_ASSIGNMENT_FIELDS,
    SQL_INJECTION_PAYLOADS,
    NOSQL_INJECTION_PAYLOADS,
    COMMAND_INJECTION_PAYLOADS,
    SSRF_PAYLOADS,
    XXE_PAYLOADS,
    OWASP_MAPPINGS,
    CWE_MAPPINGS,
)


class RESTSecurityService:
    """Service for testing REST API security."""
    
    def __init__(self, plugin_instance: Any, http_client: Any = None):
        self.plugin = plugin_instance
        self.http_client = http_client
        self.findings: List[APISecurityFinding] = []
        self.test_results: List[TestResult] = []
    
    async def test_bola(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        auth_token: Optional[str] = None,
        user1_id: str = "1",
        user2_id: str = "2",
    ) -> List[BOLATestResult]:
        """Test for Broken Object Level Authorization."""
        results = []
        
        # Replace ID in path
        test_path = endpoint.path.replace("{id}", user2_id)
        test_url = urljoin(base_url, test_path)
        
        # In real implementation, make HTTP request
        result = BOLATestResult(
            test_id=str(uuid.uuid4()),
            endpoint=endpoint.path,
            original_id=user1_id,
            target_id=user2_id,
            vulnerable=False,  # Set based on response
        )
        
        results.append(result)
        return results
    
    async def test_mass_assignment(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        auth_token: Optional[str] = None,
    ) -> MassAssignmentResult:
        """Test for mass assignment vulnerabilities."""
        accepted_fields = []
        
        for field in MASS_ASSIGNMENT_FIELDS:
            # In real implementation, send request with extra field
            pass
        
        return MassAssignmentResult(
            test_id=str(uuid.uuid4()),
            endpoint=endpoint.path,
            injected_fields=MASS_ASSIGNMENT_FIELDS,
            accepted_fields=accepted_fields,
            vulnerable=len(accepted_fields) > 0,
        )
    
    async def test_sql_injection(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        parameter: str,
    ) -> List[TestResult]:
        """Test for SQL injection vulnerabilities."""
        results = []
        
        for payload_info in SQL_INJECTION_PAYLOADS:
            if isinstance(payload_info, dict):
                payload = payload_info.get("payload", "")
                severity = payload_info.get("severity", "high")
            else:
                payload = str(payload_info)
                severity = "high"
            
            result = TestResult(
                test_id=str(uuid.uuid4()),
                test_name="SQL Injection",
                endpoint=endpoint.path,
                parameter=parameter,
                payload=payload,
                vulnerable=False,  # Set based on response
                owasp=OWASP_MAPPINGS.get("injection", {}),
                cwe=CWE_MAPPINGS.get("sql_injection", {}),
            )
            results.append(result)
        
        return results
    
    async def test_nosql_injection(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        parameter: str,
    ) -> List[TestResult]:
        """Test for NoSQL injection vulnerabilities."""
        results = []
        
        for payload_info in NOSQL_INJECTION_PAYLOADS:
            if isinstance(payload_info, dict):
                payload = payload_info.get("payload", "")
            else:
                payload = str(payload_info)
            
            result = TestResult(
                test_id=str(uuid.uuid4()),
                test_name="NoSQL Injection",
                endpoint=endpoint.path,
                parameter=parameter,
                payload=payload,
                vulnerable=False,
                owasp=OWASP_MAPPINGS.get("injection", {}),
                cwe=CWE_MAPPINGS.get("nosql_injection", {}),
            )
            results.append(result)
        
        return results
    
    async def test_command_injection(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        parameter: str,
    ) -> List[TestResult]:
        """Test for command injection vulnerabilities."""
        results = []
        
        for payload_info in COMMAND_INJECTION_PAYLOADS:
            if isinstance(payload_info, dict):
                payload = payload_info.get("payload", "")
            else:
                payload = str(payload_info)
            
            result = TestResult(
                test_id=str(uuid.uuid4()),
                test_name="Command Injection",
                endpoint=endpoint.path,
                parameter=parameter,
                payload=payload,
                vulnerable=False,
                owasp=OWASP_MAPPINGS.get("injection", {}),
                cwe=CWE_MAPPINGS.get("command_injection", {}),
            )
            results.append(result)
        
        return results
    
    async def test_ssrf(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        parameter: str,
    ) -> List[TestResult]:
        """Test for SSRF vulnerabilities."""
        results = []
        
        for payload_info in SSRF_PAYLOADS:
            if isinstance(payload_info, dict):
                payload = payload_info.get("payload", "")
            else:
                payload = str(payload_info)
            
            result = TestResult(
                test_id=str(uuid.uuid4()),
                test_name="SSRF",
                endpoint=endpoint.path,
                parameter=parameter,
                payload=payload,
                vulnerable=False,
                owasp=OWASP_MAPPINGS.get("ssrf", {}),
                cwe=CWE_MAPPINGS.get("ssrf", {}),
            )
            results.append(result)
        
        return results
    
    async def test_xxe(
        self,
        endpoint: APIEndpoint,
        base_url: str,
    ) -> List[TestResult]:
        """Test for XXE vulnerabilities."""
        results = []
        
        for payload_info in XXE_PAYLOADS:
            if isinstance(payload_info, dict):
                payload = payload_info.get("payload", "")
            else:
                payload = str(payload_info)
            
            result = TestResult(
                test_id=str(uuid.uuid4()),
                test_name="XXE",
                endpoint=endpoint.path,
                parameter="body",
                payload=payload,
                vulnerable=False,
                owasp=OWASP_MAPPINGS.get("xxe", {}),
                cwe=CWE_MAPPINGS.get("xxe", {}),
            )
            results.append(result)
        
        return results

