"""
Configuration Security Service

Service for testing API configuration security.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
from typing import Any, List
from urllib.parse import urljoin

from utils.enum_coerce import coerce_str_enum

from ...proto import (
    APISecurityFinding,
    APIEndpoint,
    RateLimitTestResult,
    TestCategory,
    TestSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    OWASPCategory,
    CWECategory,
)
from ..databases.api_security_databases import SECURITY_HEADERS


class ConfigurationSecurityService:
    """Service for testing API configuration security."""
    
    def __init__(self, plugin_instance: Any, http_client: Any = None):
        self.plugin = plugin_instance
        self.http_client = http_client
        self.findings: List[APISecurityFinding] = []
    
    async def test_rate_limiting(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        requests_count: int = 100,
    ) -> RateLimitTestResult:
        """Test rate limiting."""
        test_url = urljoin(base_url, endpoint.path)
        
        result = RateLimitTestResult(
            endpoint=endpoint.path,
            requests_sent=requests_count,
            rate_limited=False,
            rate_limit_missing=True,
        )
        
        if result.rate_limit_missing:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.RATE_LIMITING,
                sub_category=TestSubCategory.LACK_OF_RESOURCES_RATE_LIMITING,
                severity=SeverityLevel.MEDIUM,
                confidence=ConfidenceLevel.HIGH,
                owasp=OWASPCategory.API4_UNRESTRICTED_RESOURCE,
                cwe=CWECategory.CWE_400,
                title="No Rate Limiting Detected",
                description=f"Endpoint {endpoint.path} has no rate limiting",
                endpoint=endpoint.path,
                method=endpoint.method,
                risk_score=5.0,
                recommendation="Implement rate limiting to prevent abuse and DoS",
            ))
        
        return result
    
    async def test_security_headers(
        self,
        endpoint: APIEndpoint,
        base_url: str,
        response_headers: dict = None,
    ) -> List[APISecurityFinding]:
        """Test for missing or misconfigured security headers using SECURITY_HEADERS database."""
        findings = []
        
        if response_headers is None:
            response_headers = {}
        
        for header_name, header_info in SECURITY_HEADERS.items():
            if not isinstance(header_info, dict):
                continue
            
            header_value = response_headers.get(header_name) or response_headers.get(header_name.lower())
            expected_value = header_info.get("expected_value")
            severity = header_info.get("severity", "medium")
            description = header_info.get("description", f"Security header {header_name}")
            
            # Check if header is missing
            if header_value is None:
                findings.append(APISecurityFinding(
                    id=str(uuid.uuid4()),
                    category=TestCategory.CONFIGURATION,
                    sub_category=TestSubCategory.SECURITY_MISCONFIGURATION,
                    severity=coerce_str_enum(SeverityLevel, severity, default=SeverityLevel.MEDIUM),
                    confidence=ConfidenceLevel.CONFIRMED,
                    owasp=OWASPCategory.API8_SECURITY_MISCONFIG,
                    title=f"Missing Security Header: {header_name}",
                    description=f"{description}. This header is not present in the response.",
                    endpoint=endpoint.path,
                    method=endpoint.method,
                    risk_score=header_info.get("risk_score", 5.0),
                    recommendation=header_info.get("recommendation", f"Add {header_name} header to responses"),
                ))
            # Check if header value is correct
            elif expected_value and header_value != expected_value:
                findings.append(APISecurityFinding(
                    id=str(uuid.uuid4()),
                    category=TestCategory.CONFIGURATION,
                    sub_category=TestSubCategory.SECURITY_MISCONFIGURATION,
                    severity=SeverityLevel.LOW,
                    confidence=ConfidenceLevel.HIGH,
                    owasp=OWASPCategory.API8_SECURITY_MISCONFIG,
                    title=f"Misconfigured Security Header: {header_name}",
                    description=f"{description}. Expected: {expected_value}, Found: {header_value}",
                    endpoint=endpoint.path,
                    method=endpoint.method,
                    risk_score=3.0,
                    recommendation=f"Set {header_name} to recommended value: {expected_value}",
                ))
        
        self.findings.extend(findings)
        return findings

