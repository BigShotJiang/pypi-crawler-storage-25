"""
Advanced API Security Service

Service for testing advanced API security attack vectors:
- API versioning attacks
- Rate limiting bypass
- API gateway & WAF bypass
- Serverless API attacks
- API documentation exposure
- API chaining attacks
- Authorization bypass (RBAC/ABAC)
- Data exposure detection
- Input validation attacks
"""

import re
import json
import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlencode, quote

from ..databases.api_security_databases import (
    API_VERSIONING_ATTACKS,
    RATE_LIMITING_BYPASS,
    API_GATEWAY_ATTACKS,
    SERVERLESS_API_ATTACKS,
    API_DOCUMENTATION_EXPOSURE,
    API_CHAINING_ATTACKS,
    API_AUTHORIZATION_BYPASS,
    API_DATA_EXPOSURE,
    API_INPUT_VALIDATION_ATTACKS,
)


class AttackCategory(str, Enum):
    """Categories of advanced API attacks."""
    VERSION_CONFUSION = "version_confusion"
    RATE_LIMIT_BYPASS = "rate_limit_bypass"
    WAF_BYPASS = "waf_bypass"
    SERVERLESS = "serverless"
    DOCUMENTATION_EXPOSURE = "documentation_exposure"
    CHAINING = "chaining"
    AUTHORIZATION_BYPASS = "authorization_bypass"
    DATA_EXPOSURE = "data_exposure"
    INPUT_VALIDATION = "input_validation"


class Severity(str, Enum):
    """Severity levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class APISecurityFinding:
    """A security finding from API testing."""
    category: AttackCategory
    title: str
    description: str
    severity: Severity
    endpoint: str
    evidence: Optional[str] = None
    remediation: str = ""
    cwe_id: Optional[str] = None
    owasp_category: Optional[str] = None


class AdvancedAPISecurityService:
    """Service for advanced API security testing."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
        self.findings: List[APISecurityFinding] = []
        self.http_client = None  # Will be set by plugin
    
    async def test_api_versioning(
        self,
        base_url: str,
        endpoint: str,
    ) -> List[APISecurityFinding]:
        """Test for API versioning vulnerabilities."""
        findings = []
        
        # Test version confusion via URL paths
        for technique in API_VERSIONING_ATTACKS["version_confusion"]["techniques"]:
            test_path = technique["path"].replace("{endpoint}", endpoint)
            test_url = f"{base_url}{test_path}"
            
            response = await self._make_request("GET", test_url)
            if response and response.get("status_code") in [200, 201, 403]:
                # Check if this reveals different/deprecated functionality
                finding = APISecurityFinding(
                    category=AttackCategory.VERSION_CONFUSION,
                    title=f"API Version Accessible: {technique['desc']}",
                    description=f"Endpoint {test_url} is accessible. This may expose deprecated or internal functionality.",
                    severity=Severity.MEDIUM,
                    endpoint=test_url,
                    evidence=f"HTTP {response.get('status_code')}",
                    remediation="Disable or properly secure deprecated API versions",
                    cwe_id="CWE-693",
                    owasp_category="API9:2023 - Improper Inventory Management",
                )
                findings.append(finding)
        
        # Test version header manipulation
        for header_config in API_VERSIONING_ATTACKS["version_confusion"]["headers"]:
            for value in header_config["values"]:
                headers = {header_config["header"]: value}
                response = await self._make_request(
                    "GET", f"{base_url}{endpoint}", headers=headers
                )
                if response and self._detect_version_change(response):
                    finding = APISecurityFinding(
                        category=AttackCategory.VERSION_CONFUSION,
                        title=f"Version Header Accepted: {header_config['header']}",
                        description=f"API accepts version control via {header_config['header']} header",
                        severity=Severity.LOW,
                        endpoint=endpoint,
                        evidence=f"Header: {header_config['header']}: {value}",
                        remediation="Ensure version headers are properly validated",
                    )
                    findings.append(finding)
        
        self.findings.extend(findings)
        return findings
    
    async def test_rate_limiting_bypass(
        self,
        base_url: str,
        endpoint: str,
    ) -> List[APISecurityFinding]:
        """Test for rate limiting bypass vulnerabilities."""
        findings = []
        
        # Test header manipulation bypass
        for technique in RATE_LIMITING_BYPASS["header_manipulation"]["techniques"]:
            headers = {technique["header"]: technique["value"]}
            
            # Send multiple requests with the bypass header
            responses = []
            for _ in range(5):
                response = await self._make_request(
                    "GET", f"{base_url}{endpoint}", headers=headers
                )
                if response:
                    responses.append(response.get("status_code"))
            
            # Check if we bypassed rate limiting
            if all(code == 200 for code in responses):
                finding = APISecurityFinding(
                    category=AttackCategory.RATE_LIMIT_BYPASS,
                    title=f"Rate Limit Bypass via {technique['header']}",
                    description=f"Rate limiting can be bypassed using {technique['header']} header with IP spoofing",
                    severity=Severity.HIGH,
                    endpoint=endpoint,
                    evidence=f"Header: {technique['header']}: {technique['value']}",
                    remediation="Validate and sanitize IP headers; use multiple rate limiting strategies",
                    cwe_id="CWE-770",
                    owasp_category="API4:2023 - Unrestricted Resource Consumption",
                )
                findings.append(finding)
        
        # Check for rate limit headers (information disclosure)
        response = await self._make_request("GET", f"{base_url}{endpoint}")
        if response:
            for header in RATE_LIMITING_BYPASS["detection_headers"]["headers"]:
                if header.lower() in [h.lower() for h in response.get("headers", {}).keys()]:
                    finding = APISecurityFinding(
                        category=AttackCategory.RATE_LIMIT_BYPASS,
                        title="Rate Limit Headers Exposed",
                        description=f"Rate limit information exposed via {header} header",
                        severity=Severity.INFO,
                        endpoint=endpoint,
                        evidence=f"Header: {header}",
                        remediation="Consider if exposing rate limit details is necessary",
                    )
                    findings.append(finding)
                    break
        
        self.findings.extend(findings)
        return findings
    
    async def test_waf_bypass(
        self,
        base_url: str,
        endpoint: str,
    ) -> List[APISecurityFinding]:
        """Test for WAF/API gateway bypass vulnerabilities."""
        findings = []
        
        # Test encoding bypasses
        for bypass in API_GATEWAY_ATTACKS["waf_bypass"]["techniques"]["encoding_bypass"]:
            test_url = f"{base_url}{endpoint}?test={quote(bypass['payload'])}"
            response = await self._make_request("GET", test_url)
            
            if response and response.get("status_code") != 403:
                finding = APISecurityFinding(
                    category=AttackCategory.WAF_BYPASS,
                    title=f"WAF Bypass via {bypass['type']}",
                    description=f"WAF can be bypassed using {bypass['type']} encoding",
                    severity=Severity.HIGH,
                    endpoint=endpoint,
                    evidence=f"Payload: {bypass['payload']}",
                    remediation="Implement multi-layer input validation; decode before filtering",
                    cwe_id="CWE-693",
                )
                findings.append(finding)
        
        # Test method override
        for override in API_GATEWAY_ATTACKS["waf_bypass"]["techniques"]["method_override"]:
            headers = {override["header"]: override["value"]}
            response = await self._make_request(
                "POST", f"{base_url}{endpoint}", headers=headers
            )
            
            if response and response.get("status_code") in [200, 201, 204]:
                finding = APISecurityFinding(
                    category=AttackCategory.WAF_BYPASS,
                    title=f"HTTP Method Override Accepted",
                    description=f"API accepts method override via {override['header']}",
                    severity=Severity.MEDIUM,
                    endpoint=endpoint,
                    evidence=f"Header: {override['header']}: {override['value']}",
                    remediation="Disable HTTP method override or restrict to specific endpoints",
                    cwe_id="CWE-650",
                )
                findings.append(finding)
        
        self.findings.extend(findings)
        return findings
    
    async def test_serverless_vulnerabilities(
        self,
        base_url: str,
        endpoint: str,
    ) -> List[APISecurityFinding]:
        """Test for serverless-specific vulnerabilities."""
        findings = []
        
        # Check for serverless indicators in response
        response = await self._make_request("GET", f"{base_url}{endpoint}")
        if response:
            headers = response.get("headers", {})
            
            # Check for AWS Lambda indicators
            for indicator in SERVERLESS_API_ATTACKS["serverless_enumeration"]["indicators"]["aws_lambda"]:
                for header_name, header_value in headers.items():
                    if indicator.lower() in header_name.lower() or indicator.lower() in str(header_value).lower():
                        finding = APISecurityFinding(
                            category=AttackCategory.SERVERLESS,
                            title="AWS Lambda Function Detected",
                            description=f"Response indicates AWS Lambda execution: {indicator}",
                            severity=Severity.INFO,
                            endpoint=endpoint,
                            evidence=f"Header: {header_name}: {header_value}",
                            remediation="Remove or minimize serverless execution indicators in responses",
                        )
                        findings.append(finding)
                        break
            
            # Check for Azure Functions indicators
            for indicator in SERVERLESS_API_ATTACKS["serverless_enumeration"]["indicators"]["azure_functions"]:
                for header_name, header_value in headers.items():
                    if indicator.lower() in header_name.lower():
                        finding = APISecurityFinding(
                            category=AttackCategory.SERVERLESS,
                            title="Azure Function Detected",
                            description=f"Response indicates Azure Function execution: {indicator}",
                            severity=Severity.INFO,
                            endpoint=endpoint,
                            evidence=f"Header: {header_name}",
                            remediation="Remove or minimize serverless execution indicators in responses",
                        )
                        findings.append(finding)
                        break
        
        # Test for event injection
        for payload in SERVERLESS_API_ATTACKS["lambda_injection"]["payloads"]["event_injection"]:
            try:
                response = await self._make_request(
                    "POST",
                    f"{base_url}{endpoint}",
                    json=json.loads(payload) if payload.startswith("{") else {"data": payload}
                )
                if response and "error" in str(response.get("body", "")).lower():
                    finding = APISecurityFinding(
                        category=AttackCategory.SERVERLESS,
                        title="Serverless Event Injection",
                        description="Serverless function may be vulnerable to event injection",
                        severity=Severity.HIGH,
                        endpoint=endpoint,
                        evidence=f"Payload: {payload}",
                        remediation="Validate and sanitize all event input",
                        cwe_id="CWE-94",
                    )
                    findings.append(finding)
            except Exception:
                pass
        
        self.findings.extend(findings)
        return findings
    
    async def test_documentation_exposure(
        self,
        base_url: str,
    ) -> List[APISecurityFinding]:
        """Test for API documentation exposure."""
        findings = []
        
        # Check for OpenAPI/Swagger endpoints
        for endpoint in API_DOCUMENTATION_EXPOSURE["openapi_swagger"]["endpoints"]:
            response = await self._make_request("GET", f"{base_url}{endpoint}")
            
            if response and response.get("status_code") == 200:
                body = response.get("body", "")
                
                # Check for sensitive patterns in documentation
                sensitive_found = []
                for pattern in API_DOCUMENTATION_EXPOSURE["openapi_swagger"]["sensitive_patterns"]:
                    if re.search(pattern, body, re.IGNORECASE):
                        sensitive_found.append(pattern)
                
                severity = Severity.HIGH if sensitive_found else Severity.MEDIUM
                
                finding = APISecurityFinding(
                    category=AttackCategory.DOCUMENTATION_EXPOSURE,
                    title="API Documentation Exposed",
                    description=f"API documentation accessible at {endpoint}",
                    severity=severity,
                    endpoint=endpoint,
                    evidence=f"Sensitive patterns found: {', '.join(sensitive_found)}" if sensitive_found else "Documentation accessible",
                    remediation="Restrict access to API documentation in production; remove sensitive endpoints",
                    cwe_id="CWE-200",
                    owasp_category="API9:2023 - Improper Inventory Management",
                )
                findings.append(finding)
        
        # Check for GraphQL introspection
        for query in API_DOCUMENTATION_EXPOSURE["graphql_schema"]["queries"]:
            response = await self._make_request(
                "POST",
                f"{base_url}/graphql",
                json=json.loads(query),
            )
            
            if response and response.get("status_code") == 200:
                body = response.get("body", "")
                if "__schema" in body or "types" in body:
                    finding = APISecurityFinding(
                        category=AttackCategory.DOCUMENTATION_EXPOSURE,
                        title="GraphQL Introspection Enabled",
                        description="GraphQL introspection allows schema enumeration",
                        severity=Severity.MEDIUM,
                        endpoint="/graphql",
                        evidence="Introspection query returns schema",
                        remediation="Disable introspection in production",
                        cwe_id="CWE-200",
                    )
                    findings.append(finding)
                    break
        
        self.findings.extend(findings)
        return findings
    
    async def test_authorization_bypass(
        self,
        base_url: str,
        endpoint: str,
        auth_headers: Optional[Dict[str, str]] = None,
    ) -> List[APISecurityFinding]:
        """Test for authorization bypass vulnerabilities."""
        findings = []
        
        # Test RBAC bypass via parameter manipulation
        for technique in API_AUTHORIZATION_BYPASS["rbac_bypass"]["techniques"]:
            if technique["type"] == "role_parameter":
                for param in technique["params"]:
                    # Test query parameter
                    test_url = f"{base_url}{endpoint}?{param}=admin"
                    response = await self._make_request("GET", test_url, headers=auth_headers)
                    
                    if response and response.get("status_code") == 200:
                        body = response.get("body", "")
                        if "admin" in body.lower() or "unauthorized" not in body.lower():
                            finding = APISecurityFinding(
                                category=AttackCategory.AUTHORIZATION_BYPASS,
                                title="RBAC Bypass via Parameter",
                                description=f"Role parameter '{param}' may allow privilege escalation",
                                severity=Severity.HIGH,
                                endpoint=endpoint,
                                evidence=f"Parameter: {param}=admin",
                                remediation="Never trust client-supplied role information",
                                cwe_id="CWE-639",
                                owasp_category="API5:2023 - Broken Function Level Authorization",
                            )
                            findings.append(finding)
            
            elif technique["type"] == "admin_flag":
                for param in technique["params"]:
                    # Test JSON body
                    response = await self._make_request(
                        "POST",
                        f"{base_url}{endpoint}",
                        headers=auth_headers,
                        json={param: True},
                    )
                    
                    if response and response.get("status_code") in [200, 201]:
                        finding = APISecurityFinding(
                            category=AttackCategory.AUTHORIZATION_BYPASS,
                            title="Admin Flag Injection",
                            description=f"Admin flag '{param}' accepted in request body",
                            severity=Severity.CRITICAL,
                            endpoint=endpoint,
                            evidence=f"Body: {{{param}: true}}",
                            remediation="Never accept privilege flags from client; use server-side authorization",
                            cwe_id="CWE-269",
                            owasp_category="API5:2023 - Broken Function Level Authorization",
                        )
                        findings.append(finding)
        
        self.findings.extend(findings)
        return findings
    
    async def test_data_exposure(
        self,
        base_url: str,
        endpoint: str,
        auth_headers: Optional[Dict[str, str]] = None,
    ) -> List[APISecurityFinding]:
        """Test for excessive data exposure."""
        findings = []
        
        response = await self._make_request("GET", f"{base_url}{endpoint}", headers=auth_headers)
        
        if response and response.get("status_code") == 200:
            body = response.get("body", "")
            
            # Check for sensitive fields in response
            exposed_fields = []
            for field in API_DATA_EXPOSURE["excessive_data"]["sensitive_fields"]:
                if re.search(rf'["\']?{field}["\']?\s*[:=]', body, re.IGNORECASE):
                    exposed_fields.append(field)
            
            if exposed_fields:
                severity = Severity.HIGH if any(f in exposed_fields for f in ["password", "secret", "token", "api_key"]) else Severity.MEDIUM
                
                finding = APISecurityFinding(
                    category=AttackCategory.DATA_EXPOSURE,
                    title="Excessive Data Exposure",
                    description=f"API response contains sensitive fields: {', '.join(exposed_fields[:5])}",
                    severity=severity,
                    endpoint=endpoint,
                    evidence=f"Fields found: {', '.join(exposed_fields[:10])}",
                    remediation="Implement response filtering; only return required fields",
                    cwe_id="CWE-200",
                    owasp_category="API3:2023 - Broken Object Property Level Authorization",
                )
                findings.append(finding)
            
            # Check for error disclosure patterns
            for pattern in API_DATA_EXPOSURE["error_disclosure"]["patterns"]:
                if re.search(pattern, body, re.IGNORECASE):
                    finding = APISecurityFinding(
                        category=AttackCategory.DATA_EXPOSURE,
                        title="Error Information Disclosure",
                        description="API response may contain sensitive error information",
                        severity=Severity.MEDIUM,
                        endpoint=endpoint,
                        evidence=f"Pattern matched: {pattern}",
                        remediation="Implement generic error responses; log detailed errors server-side only",
                        cwe_id="CWE-209",
                    )
                    findings.append(finding)
                    break
            
            # Check response headers for metadata exposure
            headers = response.get("headers", {})
            for header in API_DATA_EXPOSURE["metadata_exposure"]["headers_to_check"]:
                if header.lower() in [h.lower() for h in headers.keys()]:
                    finding = APISecurityFinding(
                        category=AttackCategory.DATA_EXPOSURE,
                        title="Server Information Disclosure",
                        description=f"Response header {header} exposes server information",
                        severity=Severity.LOW,
                        endpoint=endpoint,
                        evidence=f"Header: {header}",
                        remediation=f"Remove or obfuscate {header} header",
                        cwe_id="CWE-200",
                    )
                    findings.append(finding)
        
        self.findings.extend(findings)
        return findings
    
    async def test_input_validation(
        self,
        base_url: str,
        endpoint: str,
        method: str = "POST",
    ) -> List[APISecurityFinding]:
        """Test for input validation vulnerabilities."""
        findings = []
        
        # Test type confusion
        for type_name, payloads in API_INPUT_VALIDATION_ATTACKS["type_confusion"]["payloads"].items():
            for payload in payloads[:3]:  # Test first 3 payloads per type
                try:
                    response = await self._make_request(
                        method,
                        f"{base_url}{endpoint}",
                        json={"test_param": payload if not isinstance(payload, str) else json.loads(payload) if payload.startswith(('[', '{')) else payload},
                    )
                    
                    if response and response.get("status_code") == 500:
                        finding = APISecurityFinding(
                            category=AttackCategory.INPUT_VALIDATION,
                            title=f"Type Confusion: {type_name}",
                            description=f"API may be vulnerable to type confusion ({type_name})",
                            severity=Severity.MEDIUM,
                            endpoint=endpoint,
                            evidence=f"Payload: {payload}",
                            remediation="Implement strict type checking on all inputs",
                            cwe_id="CWE-843",
                        )
                        findings.append(finding)
                except Exception:
                    pass
        
        # Test prototype pollution
        for payload in API_INPUT_VALIDATION_ATTACKS["object_injection"]["payloads"]:
            try:
                response = await self._make_request(
                    method,
                    f"{base_url}{endpoint}",
                    json=json.loads(payload),
                )
                
                if response and response.get("status_code") in [200, 201]:
                    body = response.get("body", "")
                    if "isAdmin" in body or "polluted" in body:
                        finding = APISecurityFinding(
                            category=AttackCategory.INPUT_VALIDATION,
                            title="Prototype Pollution",
                            description="API may be vulnerable to prototype pollution",
                            severity=Severity.CRITICAL,
                            endpoint=endpoint,
                            evidence=f"Payload: {payload}",
                            remediation="Sanitize JSON input; block __proto__ and constructor properties",
                            cwe_id="CWE-1321",
                        )
                        findings.append(finding)
            except Exception:
                pass
        
        self.findings.extend(findings)
        return findings
    
    async def run_all_tests(
        self,
        base_url: str,
        endpoint: str,
        auth_headers: Optional[Dict[str, str]] = None,
    ) -> List[APISecurityFinding]:
        """Run all advanced API security tests."""
        all_findings = []
        
        # Run all test methods
        tests = [
            self.test_api_versioning(base_url, endpoint),
            self.test_rate_limiting_bypass(base_url, endpoint),
            self.test_waf_bypass(base_url, endpoint),
            self.test_serverless_vulnerabilities(base_url, endpoint),
            self.test_documentation_exposure(base_url),
            self.test_authorization_bypass(base_url, endpoint, auth_headers),
            self.test_data_exposure(base_url, endpoint, auth_headers),
            self.test_input_validation(base_url, endpoint),
        ]
        
        results = await asyncio.gather(*tests, return_exceptions=True)
        
        for result in results:
            if isinstance(result, list):
                all_findings.extend(result)
        
        return all_findings
    
    def _detect_version_change(self, response: Dict[str, Any]) -> bool:
        """Detect if response indicates version change."""
        # Check for version indicators in response
        headers = response.get("headers", {})
        body = response.get("body", "")
        
        version_patterns = [
            r"version[\"']?\s*[:=]\s*[\"']?[0-9]+",
            r"api[_-]?version",
            r"v[0-9]+\.[0-9]+",
        ]
        
        for pattern in version_patterns:
            if re.search(pattern, str(headers), re.IGNORECASE):
                return True
            if re.search(pattern, body, re.IGNORECASE):
                return True
        
        return False
    
    async def _make_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        data: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Make HTTP request (placeholder - will be implemented by plugin)."""
        # This method should be overridden by the plugin with actual HTTP client
        # For now, return None to indicate no response
        if hasattr(self.plugin, 'make_http_request'):
            return await self.plugin.make_http_request(method, url, headers, json, data)
        return None
    
    def get_findings_by_severity(self, severity: Severity) -> List[APISecurityFinding]:
        """Get findings filtered by severity."""
        return [f for f in self.findings if f.severity == severity]
    
    def get_findings_by_category(self, category: AttackCategory) -> List[APISecurityFinding]:
        """Get findings filtered by category."""
        return [f for f in self.findings if f.category == category]
    
    def get_critical_findings(self) -> List[APISecurityFinding]:
        """Get all critical and high severity findings."""
        return [f for f in self.findings if f.severity in [Severity.CRITICAL, Severity.HIGH]]

