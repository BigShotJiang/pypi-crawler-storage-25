"""
GraphQL Federation Security Service

Security testing for GraphQL Federation (Apollo Federation, Hasura, etc.):
- Subgraph enumeration and analysis
- Cross-subgraph authorization bypass
- Entity resolution abuse
- Federation gateway vulnerabilities
- Subscription escalation
- Schema stitching attacks

MITRE ATT&CK:
- T1190: Exploit Public-Facing Application
- T1087: Account Discovery
- T1552: Unsecured Credentials
- T1059: Command and Scripting Interpreter
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
import re
import json
import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class FederationSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FederationFindingType(str, Enum):
    """Types of federation security findings."""
    SUBGRAPH_EXPOSURE = "subgraph_exposure"
    AUTHORIZATION_BYPASS = "authorization_bypass"
    ENTITY_ABUSE = "entity_abuse"
    GATEWAY_VULNERABILITY = "gateway_vulnerability"
    SCHEMA_STITCHING = "schema_stitching"
    SUBSCRIPTION_ABUSE = "subscription_abuse"


# =============================================================================
# Federation Introspection Queries
# =============================================================================

FEDERATION_INTROSPECTION = """
query FederationIntrospection {
  _service {
    sdl
  }
}
"""

SUBGRAPH_SERVICE_QUERY = """
query {
  _entities(representations: [{ __typename: "%s", id: "%s" }]) {
    ... on %s {
      __typename
      %s
    }
  }
}
"""

ENTITY_RESOLUTION_QUERY = """
query EntityResolution($representations: [_Any!]!) {
  _entities(representations: $representations) {
    __typename
    ... on %s {
      %s
    }
  }
}
"""


# =============================================================================
# Federation Attack Patterns
# =============================================================================

FEDERATION_ATTACK_PATTERNS = {
    "subgraph_sdl_exposure": {
        "name": "Subgraph SDL Exposure",
        "description": "Federation subgraph exposes SDL schema",
        "severity": FederationSeverity.MEDIUM,
        "mitre": "T1087",
        "query": "_service { sdl }",
    },
    "entity_type_enumeration": {
        "name": "Entity Type Enumeration",
        "description": "Enumerate federated entity types via introspection",
        "severity": FederationSeverity.LOW,
        "mitre": "T1087",
    },
    "cross_subgraph_idor": {
        "name": "Cross-Subgraph IDOR",
        "description": "Access entities from other subgraphs without authorization",
        "severity": FederationSeverity.HIGH,
        "mitre": "T1190",
    },
    "entity_representation_injection": {
        "name": "Entity Representation Injection",
        "description": "Inject malicious entity representations",
        "severity": FederationSeverity.HIGH,
        "mitre": "T1059",
    },
    "subscription_amplification": {
        "name": "Subscription Amplification",
        "description": "Abuse federated subscriptions for DoS",
        "severity": FederationSeverity.MEDIUM,
        "mitre": "T1499",
    },
    "schema_stitching_bypass": {
        "name": "Schema Stitching Bypass",
        "description": "Bypass authorization in stitched schemas",
        "severity": FederationSeverity.HIGH,
        "mitre": "T1190",
    },
}


# =============================================================================
# Apollo Federation Specific Patterns
# =============================================================================

APOLLO_FEDERATION_PATTERNS = {
    "apollo_studio_exposure": {
        "name": "Apollo Studio Exposure",
        "description": "Apollo Studio schema registry exposed",
        "severity": FederationSeverity.MEDIUM,
        "headers": {
            "apollographql-client-name": "apollo-studio",
        },
    },
    "apollo_gateway_debug": {
        "name": "Apollo Gateway Debug Mode",
        "description": "Apollo Gateway running in debug mode",
        "severity": FederationSeverity.MEDIUM,
        "indicators": ["APOLLO_DEBUG", "gateway in debug mode"],
    },
    "apollo_tracing_enabled": {
        "name": "Apollo Tracing Enabled",
        "description": "Apollo Tracing exposing internal details",
        "severity": FederationSeverity.LOW,
        "extensions": ["tracing"],
    },
    "apollo_operation_registry_bypass": {
        "name": "Apollo Operation Registry Bypass",
        "description": "Bypass Apollo operation registry (persisted queries)",
        "severity": FederationSeverity.HIGH,
        "mitre": "T1190",
    },
}


# =============================================================================
# Hasura Specific Patterns
# =============================================================================

HASURA_PATTERNS = {
    "hasura_console_exposed": {
        "name": "Hasura Console Exposed",
        "description": "Hasura console accessible without authentication",
        "severity": FederationSeverity.HIGH,
        "endpoint": "/console",
    },
    "hasura_admin_secret_weak": {
        "name": "Hasura Admin Secret Weak",
        "description": "Hasura admin secret is weak or default",
        "severity": FederationSeverity.CRITICAL,
        "header": "x-hasura-admin-secret",
        "weak_secrets": ["admin", "secret", "hasura", "password", "123456"],
    },
    "hasura_metadata_exposed": {
        "name": "Hasura Metadata Exposed",
        "description": "Hasura metadata API accessible",
        "severity": FederationSeverity.HIGH,
        "endpoint": "/v1/metadata",
    },
    "hasura_jwt_bypass": {
        "name": "Hasura JWT Bypass",
        "description": "Bypass Hasura JWT authentication",
        "severity": FederationSeverity.CRITICAL,
        "mitre": "T1552",
    },
    "hasura_webhook_abuse": {
        "name": "Hasura Webhook Abuse",
        "description": "Abuse Hasura auth webhooks for SSRF",
        "severity": FederationSeverity.HIGH,
        "mitre": "T1190",
    },
}


@dataclass
class FederationSecurityFinding:
    """A federation security finding."""
    test_id: str
    finding_type: FederationFindingType
    severity: FederationSeverity
    name: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class SubgraphInfo:
    """Information about a federated subgraph."""
    name: str
    url: Optional[str] = None
    sdl: Optional[str] = None
    entity_types: List[str] = field(default_factory=list)
    queries: List[str] = field(default_factory=list)
    mutations: List[str] = field(default_factory=list)


@dataclass
class FederationSecurityReport:
    """Federation security analysis report."""
    findings: List[FederationSecurityFinding] = field(default_factory=list)
    subgraphs: List[SubgraphInfo] = field(default_factory=list)
    entity_types: List[str] = field(default_factory=list)
    federation_type: str = "unknown"
    risk_score: float = 0.0


class GraphQLFederationService:
    """Service for GraphQL federation security testing."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[FederationSecurityFinding] = []
        self.http_client = None
    
    def set_http_client(self, client):
        """Set HTTP client for requests."""
        self.http_client = client
    
    async def check_federation_introspection(
        self,
        endpoint: str,
        headers: Dict[str, str] = None,
    ) -> List[FederationSecurityFinding]:
        """
        Check for federation introspection exposure.
        
        Args:
            endpoint: GraphQL endpoint URL
            headers: Optional headers
            
        Returns:
            List of findings
        """
        findings = []
        
        # Try _service query
        service_query = {
            "query": FEDERATION_INTROSPECTION,
        }
        
        try:
            if self.http_client:
                response = await self.http_client.post(
                    endpoint,
                    json=service_query,
                    headers=headers or {},
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if "data" in data and data["data"].get("_service"):
                        sdl = data["data"]["_service"].get("sdl", "")
                        
                        findings.append(FederationSecurityFinding(
                            test_id=str(uuid.uuid4()),
                            finding_type=FederationFindingType.SUBGRAPH_EXPOSURE,
                            severity=FederationSeverity.MEDIUM,
                            name="Subgraph SDL Exposure",
                            description="Federation subgraph exposes SDL schema via _service query",
                            evidence={
                                "sdl_length": len(sdl),
                                "has_sdl": bool(sdl),
                            },
                            remediation="Disable _service query in production or restrict access",
                            mitre_technique="T1087",
                        ))
                        
                        # Extract entity types from SDL
                        entity_pattern = r'@key\(fields:\s*"([^"]+)"\)'
                        entities = re.findall(entity_pattern, sdl)
                        
                        if entities:
                            findings.append(FederationSecurityFinding(
                                test_id=str(uuid.uuid4()),
                                finding_type=FederationFindingType.ENTITY_ABUSE,
                                severity=FederationSeverity.LOW,
                                name="Entity Types Enumerated",
                                description=f"Found {len(entities)} entity key fields in SDL",
                                evidence={
                                    "entity_keys": entities[:10],  # Limit to 10
                                },
                                remediation="Review entity exposure and access controls",
                                mitre_technique="T1087",
                            ))
                            
        except Exception as e:
            pass
        
        return findings
    
    async def test_entity_resolution_bypass(
        self,
        endpoint: str,
        entity_type: str,
        entity_id: str,
        fields: List[str],
        headers: Dict[str, str] = None,
    ) -> List[FederationSecurityFinding]:
        """
        Test for entity resolution authorization bypass.
        
        Args:
            endpoint: GraphQL endpoint
            entity_type: Entity type name
            entity_id: Entity ID to test
            fields: Fields to request
            headers: Optional headers
            
        Returns:
            List of findings
        """
        findings = []
        
        # Build entity query
        fields_str = "\n".join(fields)
        query = SUBGRAPH_SERVICE_QUERY % (entity_type, entity_id, entity_type, fields_str)
        
        try:
            if self.http_client:
                # Test without auth
                response = await self.http_client.post(
                    endpoint,
                    json={"query": query},
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if "data" in data and data["data"].get("_entities"):
                        entities = data["data"]["_entities"]
                        
                        if entities and any(e for e in entities if e):
                            findings.append(FederationSecurityFinding(
                                test_id=str(uuid.uuid4()),
                                finding_type=FederationFindingType.AUTHORIZATION_BYPASS,
                                severity=FederationSeverity.HIGH,
                                name="Entity Resolution Bypass",
                                description=f"Entity {entity_type} accessible without proper authorization",
                                evidence={
                                    "entity_type": entity_type,
                                    "entity_id": entity_id,
                                    "data_returned": bool(entities[0]) if entities else False,
                                },
                                remediation="Implement entity-level authorization in resolvers",
                                mitre_technique="T1190",
                            ))
                            
        except Exception as e:
            pass
        
        return findings
    
    async def check_apollo_specific_vulnerabilities(
        self,
        endpoint: str,
        headers: Dict[str, str] = None,
    ) -> List[FederationSecurityFinding]:
        """
        Check for Apollo-specific vulnerabilities.
        
        Args:
            endpoint: GraphQL endpoint
            headers: Optional headers
            
        Returns:
            List of findings
        """
        findings = []
        
        # Check for Apollo tracing
        test_query = {"query": "{ __typename }"}
        
        try:
            if self.http_client:
                response = await self.http_client.post(
                    endpoint,
                    json=test_query,
                    headers=headers or {},
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # Check for tracing in extensions
                    if "extensions" in data:
                        extensions = data["extensions"]
                        
                        if "tracing" in extensions:
                            findings.append(FederationSecurityFinding(
                                test_id=str(uuid.uuid4()),
                                finding_type=FederationFindingType.GATEWAY_VULNERABILITY,
                                severity=FederationSeverity.LOW,
                                name="Apollo Tracing Enabled",
                                description="Apollo tracing is enabled, exposing internal timing details",
                                evidence={
                                    "tracing": True,
                                },
                                remediation="Disable tracing in production",
                                mitre_technique="T1087",
                            ))
                            
        except Exception as e:
            pass
        
        return findings
    
    async def check_hasura_vulnerabilities(
        self,
        base_url: str,
    ) -> List[FederationSecurityFinding]:
        """
        Check for Hasura-specific vulnerabilities.
        
        Args:
            base_url: Base URL of Hasura instance
            
        Returns:
            List of findings
        """
        findings = []
        
        try:
            if self.http_client:
                # Check console exposure
                console_url = f"{base_url.rstrip('/')}/console"
                
                try:
                    response = await self.http_client.get(console_url)
                    
                    if response.status_code == 200 and "hasura" in response.text.lower():
                        findings.append(FederationSecurityFinding(
                            test_id=str(uuid.uuid4()),
                            finding_type=FederationFindingType.GATEWAY_VULNERABILITY,
                            severity=FederationSeverity.HIGH,
                            name="Hasura Console Exposed",
                            description="Hasura console is publicly accessible",
                            evidence={
                                "url": console_url,
                            },
                            remediation="Disable console in production or restrict access",
                            mitre_technique="T1190",
                        ))
                except Exception:
                    pass
                
                # Check metadata endpoint
                metadata_url = f"{base_url.rstrip('/')}/v1/metadata"
                
                try:
                    response = await self.http_client.post(
                        metadata_url,
                        json={"type": "export_metadata", "args": {}},
                    )
                    
                    if response.status_code == 200:
                        findings.append(FederationSecurityFinding(
                            test_id=str(uuid.uuid4()),
                            finding_type=FederationFindingType.GATEWAY_VULNERABILITY,
                            severity=FederationSeverity.HIGH,
                            name="Hasura Metadata Exposed",
                            description="Hasura metadata API is accessible without authentication",
                            evidence={
                                "url": metadata_url,
                            },
                            remediation="Require admin secret for metadata API",
                            mitre_technique="T1552",
                        ))
                except Exception:
                    pass
                
                # Check for weak admin secrets
                graphql_url = f"{base_url.rstrip('/')}/v1/graphql"
                weak_secrets = HASURA_PATTERNS["hasura_admin_secret_weak"]["weak_secrets"]
                
                for secret in weak_secrets:
                    try:
                        response = await self.http_client.post(
                            graphql_url,
                            json={"query": "{ __typename }"},
                            headers={"x-hasura-admin-secret": secret},
                        )
                        
                        if response.status_code == 200:
                            data = response.json()
                            
                            if "data" in data:
                                findings.append(FederationSecurityFinding(
                                    test_id=str(uuid.uuid4()),
                                    finding_type=FederationFindingType.GATEWAY_VULNERABILITY,
                                    severity=FederationSeverity.CRITICAL,
                                    name="Hasura Weak Admin Secret",
                                    description=f"Hasura admin secret is weak: '{secret}'",
                                    evidence={
                                        "secret_hint": secret[:2] + "***",
                                    },
                                    remediation="Use a strong, randomly generated admin secret",
                                    mitre_technique="T1552",
                                ))
                                break
                    except Exception:
                        pass
                        
        except Exception as e:
            pass
        
        return findings
    
    async def test_subscription_abuse(
        self,
        endpoint: str,
        subscription_query: str = None,
    ) -> List[FederationSecurityFinding]:
        """
        Test for subscription abuse vulnerabilities.
        
        Args:
            endpoint: GraphQL endpoint
            subscription_query: Optional subscription query
            
        Returns:
            List of findings
        """
        findings = []
        
        # Check if subscriptions are enabled without limits
        test_subscription = subscription_query or "subscription { __typename }"
        
        # Note: Full subscription testing requires WebSocket support
        # This is a basic check
        
        findings.append(FederationSecurityFinding(
            test_id=str(uuid.uuid4()),
            finding_type=FederationFindingType.SUBSCRIPTION_ABUSE,
            severity=FederationSeverity.INFO,
            name="Subscription Security Check",
            description="Manual subscription security review recommended",
            evidence={
                "endpoint": endpoint,
            },
            remediation="Implement rate limiting and authentication for subscriptions",
            mitre_technique="T1499",
        ))
        
        return findings
    
    async def run_full_scan(
        self,
        endpoint: str,
        headers: Dict[str, str] = None,
        entity_tests: List[Dict[str, Any]] = None,
        is_hasura: bool = False,
    ) -> FederationSecurityReport:
        """
        Run full federation security scan.
        
        Args:
            endpoint: GraphQL endpoint
            headers: Optional headers
            entity_tests: Optional list of entity tests
            is_hasura: Whether endpoint is Hasura
            
        Returns:
            FederationSecurityReport
        """
        all_findings = []
        subgraphs = []
        entity_types = []
        federation_type = "unknown"
        
        # Check federation introspection
        intro_findings = await self.check_federation_introspection(endpoint, headers)
        all_findings.extend(intro_findings)
        
        if intro_findings:
            federation_type = "apollo_federation"
        
        # Check Apollo-specific
        apollo_findings = await self.check_apollo_specific_vulnerabilities(endpoint, headers)
        all_findings.extend(apollo_findings)
        
        if apollo_findings:
            federation_type = "apollo_federation"
        
        # Check Hasura-specific
        if is_hasura:
            base_url = endpoint.rsplit("/", 1)[0] if "/graphql" in endpoint else endpoint
            hasura_findings = await self.check_hasura_vulnerabilities(base_url)
            all_findings.extend(hasura_findings)
            
            if hasura_findings:
                federation_type = "hasura"
        
        # Test entity resolution
        if entity_tests:
            for test in entity_tests:
                entity_findings = await self.test_entity_resolution_bypass(
                    endpoint,
                    test.get("type", ""),
                    test.get("id", ""),
                    test.get("fields", []),
                    headers,
                )
                all_findings.extend(entity_findings)
        
        # Test subscriptions
        subscription_findings = await self.test_subscription_abuse(endpoint)
        all_findings.extend(subscription_findings)
        
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return FederationSecurityReport(
            findings=all_findings,
            subgraphs=subgraphs,
            entity_types=entity_types,
            federation_type=federation_type,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[FederationSecurityFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            FederationSeverity.CRITICAL: 10,
            FederationSeverity.HIGH: 7,
            FederationSeverity.MEDIUM: 4,
            FederationSeverity.LOW: 1,
            FederationSeverity.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[FederationSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_attack_patterns(self) -> Dict[str, Any]:
        """Get all attack pattern databases."""
        return {
            "federation_patterns": FEDERATION_ATTACK_PATTERNS,
            "apollo_patterns": APOLLO_FEDERATION_PATTERNS,
            "hasura_patterns": HASURA_PATTERNS,
        }

