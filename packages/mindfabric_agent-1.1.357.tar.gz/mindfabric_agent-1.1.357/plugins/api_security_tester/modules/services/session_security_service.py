"""
Session Security Service

API session management attack techniques:
- Session fixation
- Session hijacking
- Session prediction
- Session token manipulation
- Concurrent session abuse
- Session timeout bypass
- Cookie security analysis

MITRE ATT&CK:
- T1539: Steal Web Session Cookie
- T1550.001: Use Alternate Authentication Material: Application Access Token
- T1185: Browser Session Hijacking
"""

import re
import time
import hashlib
import base64
import secrets
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

from ...proto import (
    ScanOptions,
    Finding,
    SeverityLevel,
    TestCategory,
    TestSubCategory,
)


class SessionVulnerabilityType(str, Enum):
    """Types of session vulnerabilities."""
    SESSION_FIXATION = "session_fixation"
    SESSION_HIJACKING = "session_hijacking"
    SESSION_PREDICTION = "session_prediction"
    WEAK_SESSION_ID = "weak_session_id"
    MISSING_SECURE_FLAG = "missing_secure_flag"
    MISSING_HTTPONLY_FLAG = "missing_httponly_flag"
    MISSING_SAMESITE = "missing_samesite"
    SESSION_TIMEOUT_BYPASS = "session_timeout_bypass"
    CONCURRENT_SESSIONS = "concurrent_sessions"
    SESSION_REGENERATION = "session_regeneration"
    COOKIE_SCOPE = "cookie_scope"


# =============================================================================
# Session Attack Techniques
# =============================================================================

SESSION_ATTACK_TECHNIQUES = {
    "session_fixation": {
        "name": "Session Fixation",
        "description": "Force victim to use attacker-known session ID",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1185",
        "test_method": "Try setting session ID before authentication",
        "indicators": [
            "Session ID not regenerated after login",
            "Session ID accepted from URL parameter",
            "Session ID accepted from custom header",
        ],
        "exploitation": {
            "url_based": "https://target.com/login?SESSIONID=attacker_known_id",
            "cookie_based": "Set-Cookie via XSS or MITM before login",
        },
    },
    "session_prediction": {
        "name": "Session ID Prediction",
        "description": "Predict or brute-force session identifiers",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1550.001",
        "weak_patterns": [
            r"^[0-9]+$",  # Numeric only
            r"^[a-f0-9]{8}$",  # Short hex
            r"^session_\d+$",  # Predictable format
            r"^\d{10}$",  # Timestamp
            r"^user_\d+_\d+$",  # User ID based
        ],
        "minimum_entropy_bits": 128,
    },
    "cookie_attributes": {
        "name": "Cookie Security Attributes",
        "description": "Analyze cookie security flags",
        "checks": {
            "secure": {
                "missing_severity": SeverityLevel.HIGH,
                "description": "Cookie sent over HTTP (not HTTPS only)",
            },
            "httponly": {
                "missing_severity": SeverityLevel.HIGH,
                "description": "Cookie accessible via JavaScript (XSS risk)",
            },
            "samesite": {
                "missing_severity": SeverityLevel.MEDIUM,
                "description": "Cookie vulnerable to CSRF attacks",
            },
            "path": {
                "overly_broad_severity": SeverityLevel.LOW,
                "description": "Cookie scope too broad",
            },
            "domain": {
                "overly_broad_severity": SeverityLevel.MEDIUM,
                "description": "Cookie shared with subdomains",
            },
        },
    },
    "session_timeout": {
        "name": "Session Timeout Analysis",
        "description": "Check for proper session timeout implementation",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1550.001",
        "checks": [
            "Absolute timeout exists",
            "Idle timeout exists",
            "Session invalidation on logout",
            "Token refresh mechanism",
        ],
    },
    "concurrent_sessions": {
        "name": "Concurrent Session Analysis",
        "description": "Check for concurrent session controls",
        "severity": SeverityLevel.LOW,
        "mitre": "T1550.001",
        "checks": [
            "Multiple simultaneous sessions allowed",
            "Session limit enforcement",
            "Previous session invalidation on new login",
        ],
    },
}


# =============================================================================
# Cookie Security Flags
# =============================================================================

COOKIE_SECURITY_FLAGS = {
    "Secure": {
        "description": "Cookie only sent over HTTPS",
        "missing_risk": "Cookie can be intercepted over HTTP",
        "severity": SeverityLevel.HIGH,
    },
    "HttpOnly": {
        "description": "Cookie not accessible via JavaScript",
        "missing_risk": "Cookie can be stolen via XSS",
        "severity": SeverityLevel.HIGH,
    },
    "SameSite": {
        "description": "Cookie not sent with cross-site requests",
        "missing_risk": "Vulnerable to CSRF attacks",
        "severity": SeverityLevel.MEDIUM,
        "valid_values": ["Strict", "Lax", "None"],
    },
    "__Host-": {
        "description": "Cookie prefix requiring Secure, no Domain, Path=/",
        "note": "Modern secure cookie prefix",
        "severity": SeverityLevel.INFO,
    },
    "__Secure-": {
        "description": "Cookie prefix requiring Secure flag",
        "note": "Modern secure cookie prefix",
        "severity": SeverityLevel.INFO,
    },
}


@dataclass
class SessionSecurityFinding:
    """Finding from session security analysis."""
    vulnerability_type: SessionVulnerabilityType
    title: str
    description: str
    severity: SeverityLevel
    evidence: Dict[str, Any] = field(default_factory=dict)
    exploitation: Dict[str, str] = field(default_factory=dict)
    mitre_technique: str = ""
    recommendation: str = ""


@dataclass
class SessionAnalysisResult:
    """Result of session security analysis."""
    session_id_analysis: Dict[str, Any] = field(default_factory=dict)
    cookie_analysis: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[SessionSecurityFinding] = field(default_factory=list)
    overall_risk: str = "unknown"


class SessionSecurityService:
    """Service for session security testing."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[SessionSecurityFinding] = []
    
    async def analyze_session_id(
        self,
        session_id: str,
        session_ids: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Analyze session ID for weaknesses.
        
        Args:
            session_id: Single session ID to analyze
            session_ids: Multiple session IDs for pattern analysis
            
        Returns:
            Dict with session ID analysis
        """
        result = {
            "length": len(session_id),
            "entropy_estimate": 0,
            "character_set": "",
            "predictable": False,
            "weak_patterns": [],
            "recommendations": [],
        }
        
        # Determine character set
        char_sets = {
            "numeric": r"^[0-9]+$",
            "lowercase_hex": r"^[a-f0-9]+$",
            "uppercase_hex": r"^[A-F0-9]+$",
            "mixed_hex": r"^[a-fA-F0-9]+$",
            "alphanumeric_lower": r"^[a-z0-9]+$",
            "alphanumeric_upper": r"^[A-Z0-9]+$",
            "alphanumeric_mixed": r"^[a-zA-Z0-9]+$",
            "base64": r"^[a-zA-Z0-9+/=]+$",
            "base64url": r"^[a-zA-Z0-9_-]+$",
        }
        
        for name, pattern in char_sets.items():
            if re.match(pattern, session_id):
                result["character_set"] = name
                break
        
        if not result["character_set"]:
            result["character_set"] = "custom"
        
        # Estimate entropy
        charset_sizes = {
            "numeric": 10,
            "lowercase_hex": 16,
            "uppercase_hex": 16,
            "mixed_hex": 16,
            "alphanumeric_lower": 36,
            "alphanumeric_upper": 36,
            "alphanumeric_mixed": 62,
            "base64": 64,
            "base64url": 64,
            "custom": 95,  # Printable ASCII
        }
        
        charset_size = charset_sizes.get(result["character_set"], 95)
        result["entropy_estimate"] = len(session_id) * (charset_size.bit_length())
        
        # Check for weak patterns
        weak_patterns = SESSION_ATTACK_TECHNIQUES["session_prediction"]["weak_patterns"]
        for pattern in weak_patterns:
            if re.match(pattern, session_id):
                result["weak_patterns"].append(pattern)
                result["predictable"] = True
        
        # Check for embedded data
        if "_" in session_id or "-" in session_id:
            parts = re.split(r"[_-]", session_id)
            if any(part.isdigit() and len(part) < 8 for part in parts):
                result["weak_patterns"].append("Contains short numeric segments")
                result["predictable"] = True
        
        # Try base64 decode
        try:
            decoded = base64.b64decode(session_id)
            if b"user" in decoded.lower() or b"admin" in decoded.lower():
                result["weak_patterns"].append("Contains user info when decoded")
                result["predictable"] = True
        except Exception:
            pass
        
        # Analyze multiple session IDs for patterns
        if session_ids and len(session_ids) >= 3:
            pattern_result = self._analyze_session_id_patterns(session_ids)
            result["pattern_analysis"] = pattern_result
            if pattern_result.get("sequential"):
                result["predictable"] = True
                result["weak_patterns"].append("Sequential pattern detected")
        
        # Generate recommendations
        if result["predictable"]:
            result["recommendations"].append("Use cryptographically secure random number generator")
        
        if result["entropy_estimate"] < 128:
            result["recommendations"].append(f"Increase session ID length (current entropy: {result['entropy_estimate']} bits, recommended: 128+)")
        
        if result["character_set"] in ["numeric", "lowercase_hex", "uppercase_hex"]:
            result["recommendations"].append("Use larger character set (alphanumeric or base64)")
        
        # Create finding if vulnerable
        if result["predictable"] or result["entropy_estimate"] < 64:
            self.findings.append(SessionSecurityFinding(
                vulnerability_type=SessionVulnerabilityType.WEAK_SESSION_ID,
                title="Weak Session ID Generation",
                description="Session ID may be predictable or has low entropy",
                severity=SeverityLevel.CRITICAL if result["predictable"] else SeverityLevel.HIGH,
                evidence={
                    "session_id_sample": session_id[:8] + "...",
                    "entropy": result["entropy_estimate"],
                    "patterns": result["weak_patterns"],
                },
                exploitation={
                    "method": "Brute force or predict session IDs",
                    "tool": "Burp Sequencer for analysis",
                },
                mitre_technique="T1550.001",
                recommendation="; ".join(result["recommendations"]),
            ))
        
        return result
    
    def analyze_cookie(
        self,
        cookie_header: str,
    ) -> List[Dict[str, Any]]:
        """
        Analyze Set-Cookie header for security issues.
        
        Args:
            cookie_header: Set-Cookie header value
            
        Returns:
            List of cookie analysis results
        """
        results = []
        
        # Parse cookie
        parts = cookie_header.split(";")
        if not parts:
            return results
        
        # Get cookie name and value
        name_value = parts[0].strip().split("=", 1)
        cookie_name = name_value[0].strip()
        cookie_value = name_value[1].strip() if len(name_value) > 1 else ""
        
        analysis = {
            "name": cookie_name,
            "value_length": len(cookie_value),
            "flags": {},
            "issues": [],
        }
        
        # Parse flags
        flags_found = {}
        for part in parts[1:]:
            part = part.strip()
            if "=" in part:
                key, value = part.split("=", 1)
                flags_found[key.strip().lower()] = value.strip()
            else:
                flags_found[part.lower()] = True
        
        analysis["flags"] = flags_found
        
        # Check Secure flag
        if "secure" not in flags_found:
            analysis["issues"].append({
                "flag": "Secure",
                "status": "missing",
                "severity": COOKIE_SECURITY_FLAGS["Secure"]["severity"].value,
                "risk": COOKIE_SECURITY_FLAGS["Secure"]["missing_risk"],
            })
            self.findings.append(SessionSecurityFinding(
                vulnerability_type=SessionVulnerabilityType.MISSING_SECURE_FLAG,
                title=f"Cookie '{cookie_name}' Missing Secure Flag",
                description="Cookie will be sent over unencrypted HTTP",
                severity=SeverityLevel.HIGH,
                evidence={"cookie": cookie_name},
                recommendation="Add Secure flag to cookie",
            ))
        
        # Check HttpOnly flag
        if "httponly" not in flags_found:
            analysis["issues"].append({
                "flag": "HttpOnly",
                "status": "missing",
                "severity": COOKIE_SECURITY_FLAGS["HttpOnly"]["severity"].value,
                "risk": COOKIE_SECURITY_FLAGS["HttpOnly"]["missing_risk"],
            })
            self.findings.append(SessionSecurityFinding(
                vulnerability_type=SessionVulnerabilityType.MISSING_HTTPONLY_FLAG,
                title=f"Cookie '{cookie_name}' Missing HttpOnly Flag",
                description="Cookie accessible via JavaScript (XSS risk)",
                severity=SeverityLevel.HIGH,
                evidence={"cookie": cookie_name},
                mitre_technique="T1539",
                recommendation="Add HttpOnly flag to cookie",
            ))
        
        # Check SameSite flag
        samesite = flags_found.get("samesite", "")
        if not samesite:
            analysis["issues"].append({
                "flag": "SameSite",
                "status": "missing",
                "severity": COOKIE_SECURITY_FLAGS["SameSite"]["severity"].value,
                "risk": COOKIE_SECURITY_FLAGS["SameSite"]["missing_risk"],
            })
            self.findings.append(SessionSecurityFinding(
                vulnerability_type=SessionVulnerabilityType.MISSING_SAMESITE,
                title=f"Cookie '{cookie_name}' Missing SameSite Attribute",
                description="Cookie vulnerable to CSRF attacks",
                severity=SeverityLevel.MEDIUM,
                evidence={"cookie": cookie_name},
                recommendation="Add SameSite=Lax or SameSite=Strict",
            ))
        elif samesite.lower() == "none" and "secure" not in flags_found:
            analysis["issues"].append({
                "flag": "SameSite",
                "status": "insecure",
                "severity": "high",
                "risk": "SameSite=None requires Secure flag",
            })
        
        # Check cookie scope
        domain = flags_found.get("domain", "")
        path = flags_found.get("path", "/")
        
        if domain and domain.startswith("."):
            analysis["issues"].append({
                "flag": "Domain",
                "status": "broad",
                "severity": "medium",
                "risk": f"Cookie shared with all subdomains of {domain}",
            })
        
        if path == "/":
            analysis["issues"].append({
                "flag": "Path",
                "status": "broad",
                "severity": "low",
                "risk": "Cookie accessible from entire site",
            })
        
        # Check for secure cookie prefixes
        if cookie_name.startswith("__Host-"):
            if "secure" not in flags_found or domain or path != "/":
                analysis["issues"].append({
                    "flag": "__Host- prefix",
                    "status": "invalid",
                    "severity": "medium",
                    "risk": "__Host- prefix requirements not met",
                })
        elif cookie_name.startswith("__Secure-"):
            if "secure" not in flags_found:
                analysis["issues"].append({
                    "flag": "__Secure- prefix",
                    "status": "invalid",
                    "severity": "medium",
                    "risk": "__Secure- prefix requires Secure flag",
                })
        
        results.append(analysis)
        return results
    
    async def test_session_fixation(
        self,
        scan_options: ScanOptions,
        target_url: str,
        login_url: str,
    ) -> Dict[str, Any]:
        """
        Test for session fixation vulnerability.
        
        Args:
            scan_options: Scan parameters
            target_url: Target application URL
            login_url: Login endpoint URL
            
        Returns:
            Dict with session fixation test results
        """
        result = {
            "vulnerable": False,
            "tests": [],
            "evidence": {},
        }
        
        # Test 1: Session ID from URL parameter
        result["tests"].append({
            "name": "URL Parameter Session Fixation",
            "method": f"GET {login_url}?SESSIONID=attacker_session",
            "description": "Check if session ID is accepted from URL",
        })
        
        # Test 2: Session ID not regenerated after login
        result["tests"].append({
            "name": "Session Regeneration on Login",
            "method": "Compare session ID before and after authentication",
            "description": "Session ID should change after successful login",
        })
        
        # Test 3: Session ID from custom header
        result["tests"].append({
            "name": "Custom Header Session Fixation",
            "method": "X-Session-ID header injection",
            "description": "Check if session ID accepted from custom header",
        })
        
        # Generate exploitation if vulnerable
        result["exploitation"] = {
            "attack_flow": [
                "1. Attacker obtains valid session ID from target site",
                "2. Attacker crafts URL with session ID: ?SESSIONID=known_id",
                "3. Victim clicks malicious link",
                "4. Victim authenticates",
                "5. Attacker uses known session ID to access victim's session",
            ],
            "payloads": [
                f"{login_url}?PHPSESSID=attacker_session",
                f"{login_url}?JSESSIONID=attacker_session",
                f"{login_url}?ASP.NET_SessionId=attacker_session",
            ],
        }
        
        self.findings.append(SessionSecurityFinding(
            vulnerability_type=SessionVulnerabilityType.SESSION_FIXATION,
            title="Session Fixation Test Required",
            description="Manual testing required for session fixation",
            severity=SeverityLevel.HIGH,
            evidence=result["tests"],
            exploitation=result["exploitation"],
            mitre_technique="T1185",
            recommendation="Regenerate session ID after authentication; reject externally set session IDs",
        ))
        
        return result
    
    async def test_session_timeout(
        self,
        scan_options: ScanOptions,
        session_token: str,
    ) -> Dict[str, Any]:
        """
        Test session timeout implementation.
        
        Args:
            scan_options: Scan parameters
            session_token: Session token to test
            
        Returns:
            Dict with session timeout analysis
        """
        result = {
            "tests": {
                "absolute_timeout": {
                    "description": "Session expires after fixed time regardless of activity",
                    "status": "unknown",
                    "recommendation": "Implement 8-24 hour absolute timeout",
                },
                "idle_timeout": {
                    "description": "Session expires after period of inactivity",
                    "status": "unknown",
                    "recommendation": "Implement 15-30 minute idle timeout",
                },
                "logout_invalidation": {
                    "description": "Session properly invalidated on logout",
                    "status": "unknown",
                    "recommendation": "Server-side session destruction on logout",
                },
                "token_refresh": {
                    "description": "Token refresh mechanism present",
                    "status": "unknown",
                    "recommendation": "Implement sliding expiration or refresh tokens",
                },
            },
            "exploitation": {
                "no_timeout": "Session tokens remain valid indefinitely - stolen tokens never expire",
                "no_logout_invalidation": "Logout doesn't invalidate server session - tokens remain usable",
            },
        }
        
        return result
    
    async def test_concurrent_sessions(
        self,
        scan_options: ScanOptions,
        target_url: str,
    ) -> Dict[str, Any]:
        """
        Test concurrent session handling.
        
        Args:
            scan_options: Scan parameters
            target_url: Target application URL
            
        Returns:
            Dict with concurrent session test results
        """
        result = {
            "tests": {
                "multiple_sessions_allowed": {
                    "description": "Can user have multiple active sessions",
                    "status": "unknown",
                    "security_implication": "Stolen credentials usable without detection",
                },
                "session_limit": {
                    "description": "Maximum concurrent sessions enforced",
                    "status": "unknown",
                    "recommendation": "Limit to reasonable number (e.g., 5)",
                },
                "old_session_invalidation": {
                    "description": "Old sessions invalidated on new login",
                    "status": "unknown",
                    "recommendation": "Option to invalidate other sessions",
                },
                "session_listing": {
                    "description": "User can view active sessions",
                    "status": "unknown",
                    "recommendation": "Allow users to see and terminate sessions",
                },
            },
        }
        
        return result
    
    def _analyze_session_id_patterns(
        self,
        session_ids: List[str],
    ) -> Dict[str, Any]:
        """Analyze multiple session IDs for patterns."""
        result = {
            "sequential": False,
            "common_prefix": "",
            "common_suffix": "",
            "length_consistent": True,
        }
        
        if not session_ids:
            return result
        
        # Check length consistency
        lengths = set(len(sid) for sid in session_ids)
        result["length_consistent"] = len(lengths) == 1
        
        # Check for common prefix/suffix
        if len(session_ids) >= 2:
            # Common prefix
            prefix = session_ids[0]
            for sid in session_ids[1:]:
                while not sid.startswith(prefix) and prefix:
                    prefix = prefix[:-1]
            if len(prefix) > 5:
                result["common_prefix"] = prefix
            
            # Common suffix
            suffix = session_ids[0]
            for sid in session_ids[1:]:
                while not sid.endswith(suffix) and suffix:
                    suffix = suffix[1:]
            if len(suffix) > 5:
                result["common_suffix"] = suffix
        
        # Check for sequential patterns
        try:
            # Try to find incrementing numeric parts
            numeric_parts = []
            for sid in session_ids:
                nums = re.findall(r'\d+', sid)
                if nums:
                    numeric_parts.append(int(nums[-1]))
            
            if len(numeric_parts) >= 3:
                diffs = [numeric_parts[i+1] - numeric_parts[i] for i in range(len(numeric_parts)-1)]
                if len(set(diffs)) == 1 and diffs[0] in [1, 2]:
                    result["sequential"] = True
        except Exception:
            pass
        
        return result
    
    async def scan(
        self,
        scan_options: ScanOptions,
        target_url: str,
        cookies: List[str] = None,
        session_ids: List[str] = None,
    ) -> SessionAnalysisResult:
        """
        Perform comprehensive session security scan.
        
        Args:
            scan_options: Scan parameters
            target_url: Target application URL
            cookies: List of Set-Cookie headers to analyze
            session_ids: List of session IDs to analyze
            
        Returns:
            SessionAnalysisResult with findings
        """
        result = SessionAnalysisResult()
        
        # Analyze cookies
        if cookies:
            for cookie in cookies:
                cookie_analysis = self.analyze_cookie(cookie)
                result.cookie_analysis.extend(cookie_analysis)
        
        # Analyze session IDs
        if session_ids:
            for sid in session_ids[:5]:  # Analyze up to 5
                sid_analysis = await self.analyze_session_id(sid, session_ids)
                if not result.session_id_analysis:
                    result.session_id_analysis = sid_analysis
        
        # Test session fixation
        fixation_result = await self.test_session_fixation(
            scan_options, target_url, f"{target_url}/login"
        )
        
        # Collect all findings
        result.findings = self.findings
        
        # Determine overall risk
        critical_count = sum(1 for f in self.findings if f.severity == SeverityLevel.CRITICAL)
        high_count = sum(1 for f in self.findings if f.severity == SeverityLevel.HIGH)
        
        if critical_count > 0:
            result.overall_risk = "critical"
        elif high_count > 0:
            result.overall_risk = "high"
        elif self.findings:
            result.overall_risk = "medium"
        else:
            result.overall_risk = "low"
        
        return result
    
    def get_attack_techniques(self) -> Dict[str, Any]:
        """Get session attack techniques database."""
        return SESSION_ATTACK_TECHNIQUES
    
    def get_findings(self) -> List[SessionSecurityFinding]:
        """Get all findings."""
        return self.findings

