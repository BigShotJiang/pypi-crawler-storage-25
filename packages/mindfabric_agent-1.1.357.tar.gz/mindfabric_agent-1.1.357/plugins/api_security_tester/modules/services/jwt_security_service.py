"""
JWT Security Service

Service for testing JWT security.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
from datetime import datetime, timedelta
from typing import Any, List, Optional

from ...proto import (
    APISecurityFinding,
    JWTAnalysis,
    JWTInfo,
    JWTAlgorithm,
    JWTAttackResult,
    TestCategory,
    TestSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    CWECategory,
)
from ..utils.api_security_utils import decode_jwt_parts, create_jwt, calculate_risk_score
from ..databases.api_security_databases import COMMON_JWT_SECRETS


class JWTSecurityService:
    """Service for testing JWT security."""
    
    def __init__(self, plugin_instance: Any):
        self.plugin = plugin_instance
        self.findings: List[APISecurityFinding] = []
    
    def analyze_token(self, token: str, endpoint_url: Optional[str] = None) -> JWTAnalysis:
        """Analyze JWT token for security issues and create findings."""
        try:
            header, payload, signature = decode_jwt_parts(token)
        except Exception as e:
            return JWTAnalysis(
                token_info=JWTInfo(
                    raw_token=token,
                    algorithm=JWTAlgorithm.NONE,
                    is_valid=False,
                    validation_errors=[str(e)],
                ),
                algorithm_in_token="unknown",
                issues=["Failed to decode token"],
            )
        
        algorithm = header.get("alg", "none")
        issues = []
        
        if algorithm.lower() == "none":
            issues.append("Token uses 'none' algorithm - signature not verified")
        elif algorithm in ["HS256", "HS384", "HS512"]:
            issues.append("Token uses symmetric algorithm - vulnerable to secret brute-force")
        
        exp = payload.get("exp")
        iat = payload.get("iat")
        
        if not exp:
            issues.append("Token has no expiration (exp) claim")
        elif exp:
            exp_time = datetime.fromtimestamp(exp)
            if exp_time - datetime.utcnow() > timedelta(days=7):
                issues.append("Token has very long expiration (>7 days)")
        
        if not iat:
            issues.append("Token has no issued-at (iat) claim")
        
        if not payload.get("iss"):
            issues.append("Token has no issuer (iss) claim")
        
        sensitive_fields = ["password", "secret", "credit_card", "ssn"]
        for field in sensitive_fields:
            if field in payload:
                issues.append(f"Token contains sensitive field: {field}")
        
        token_info = JWTInfo(
            raw_token=token,
            algorithm=JWTAlgorithm(algorithm) if algorithm in [a.value for a in JWTAlgorithm] else JWTAlgorithm.NONE,
            issuer=payload.get("iss"),
            subject=payload.get("sub"),
            audience=payload.get("aud"),
            expiration=datetime.fromtimestamp(exp) if exp else None,
            issued_at=datetime.fromtimestamp(iat) if iat else None,
            custom_claims={k: v for k, v in payload.items() if k not in ["iss", "sub", "aud", "exp", "iat", "nbf", "jti"]},
            is_expired=exp and datetime.fromtimestamp(exp) < datetime.utcnow() if exp else False,
        )
        
        # Create findings for issues if endpoint_url is provided
        if endpoint_url:
            for issue in issues:
                severity = SeverityLevel.HIGH if "none algorithm" in issue.lower() else SeverityLevel.MEDIUM
                self.findings.append(APISecurityFinding(
                    id=str(uuid.uuid4()),
                    category=TestCategory.JWT,
                    sub_category=TestSubCategory.JWT_CLAIM_TAMPERING,
                    severity=severity,
                    confidence=ConfidenceLevel.HIGH,
                    title=f"JWT Issue: {issue}",
                    description=issue,
                    endpoint=endpoint_url,
                    risk_score=calculate_risk_score(severity, ConfidenceLevel.HIGH),
                    recommendation="Review JWT implementation",
                ))
        
        return JWTAnalysis(
            token_info=token_info,
            uses_none_algorithm=algorithm.lower() == "none",
            uses_weak_algorithm=algorithm in ["HS256", "HS384", "HS512"],
            algorithm_in_token=algorithm,
            missing_exp=not exp,
            missing_iat=not iat,
            missing_iss=not payload.get("iss"),
            issues=issues,
        )
    
    async def test_none_algorithm(self, original_token: str, endpoint_url: str) -> JWTAttackResult:
        """Test for 'none' algorithm vulnerability."""
        try:
            header, payload, _ = decode_jwt_parts(original_token)
        except Exception:
            return JWTAttackResult(
                test_id=str(uuid.uuid4()),
                attack_type=TestSubCategory.JWT_NONE_ALGORITHM,
                original_token=original_token,
                attack_successful=False,
            )
        
        header["alg"] = "none"
        modified_token = create_jwt(header, payload, algorithm="none")
        
        result = JWTAttackResult(
            test_id=str(uuid.uuid4()),
            attack_type=TestSubCategory.JWT_NONE_ALGORITHM,
            original_token=original_token,
            modified_token=modified_token,
            attack_successful=False,
        )
        
        if result.attack_successful:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.JWT,
                sub_category=TestSubCategory.JWT_NONE_ALGORITHM,
                severity=SeverityLevel.CRITICAL,
                confidence=ConfidenceLevel.CONFIRMED,
                title="JWT None Algorithm Accepted",
                description="Server accepts JWT tokens with 'none' algorithm, bypassing signature verification",
                endpoint=endpoint_url,
                evidence=modified_token,
                risk_score=10.0,
                recommendation="Explicitly reject 'none' algorithm and validate algorithm against allowlist",
            ))
        
        return result
    
    async def test_weak_secret(self, token: str, wordlist: Optional[List[str]] = None) -> JWTAttackResult:
        """Test for weak JWT secret via brute force."""
        try:
            header, payload, signature = decode_jwt_parts(token)
        except Exception:
            return JWTAttackResult(
                test_id=str(uuid.uuid4()),
                attack_type=TestSubCategory.JWT_WEAK_SECRET,
                original_token=token,
                attack_successful=False,
            )
        
        if not header.get("alg", "").startswith("HS"):
            return JWTAttackResult(
                test_id=str(uuid.uuid4()),
                attack_type=TestSubCategory.JWT_WEAK_SECRET,
                original_token=token,
                attack_successful=False,
                evidence="Token does not use HMAC algorithm",
            )
        
        secrets_to_test = wordlist or COMMON_JWT_SECRETS
        found_secret = None
        
        for secret in secrets_to_test:
            test_token = create_jwt(header, payload, secret=secret)
            if test_token.split(".")[-1] == signature:
                found_secret = secret
                break
        
        result = JWTAttackResult(
            test_id=str(uuid.uuid4()),
            attack_type=TestSubCategory.JWT_WEAK_SECRET,
            original_token=token,
            attack_successful=found_secret is not None,
            evidence=f"Found secret: {found_secret}" if found_secret else None,
        )
        
        if found_secret:
            self.findings.append(APISecurityFinding(
                id=str(uuid.uuid4()),
                category=TestCategory.JWT,
                sub_category=TestSubCategory.JWT_WEAK_SECRET,
                severity=SeverityLevel.CRITICAL,
                confidence=ConfidenceLevel.CONFIRMED,
                cwe=CWECategory.CWE_522,
                title="JWT Weak Secret Discovered",
                description=f"JWT signing secret is weak and was cracked: '{found_secret}'",
                evidence=f"Secret: {found_secret}",
                risk_score=10.0,
                recommendation="Use a strong, randomly generated secret of at least 256 bits",
            ))
        
        return result

