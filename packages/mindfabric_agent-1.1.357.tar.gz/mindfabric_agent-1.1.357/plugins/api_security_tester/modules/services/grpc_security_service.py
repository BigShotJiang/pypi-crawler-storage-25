"""
gRPC Security Service

Service for testing gRPC API security vulnerabilities:
- Reflection API exposure
- Insecure channel (no TLS)
- Weak authentication
- Message size limits
- Metadata injection
- Deadline abuse
- Stream exhaustion
- Proto poisoning
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
import asyncio
from typing import Any, List, Optional, Dict, Tuple
from dataclasses import dataclass

from ...proto import (
    APISecurityFinding,
    TestResult,
    TestCategory,
    TestSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    OWASPCategory,
)


@dataclass
class GRPCServiceInfo:
    """Information about a gRPC service."""
    name: str
    methods: List[str]
    has_reflection: bool = False
    uses_tls: bool = False
    auth_type: Optional[str] = None


@dataclass
class GRPCTestResult:
    """Result of a gRPC security test."""
    test_id: str
    service: str
    method: Optional[str]
    test_type: TestSubCategory
    vulnerable: bool
    evidence: Optional[str] = None
    request_metadata: Optional[Dict[str, str]] = None
    response_metadata: Optional[Dict[str, str]] = None


# gRPC reflection payloads
REFLECTION_METHODS = [
    "grpc.reflection.v1alpha.ServerReflection/ServerReflectionInfo",
    "grpc.reflection.v1.ServerReflection/ServerReflectionInfo",
]

# Metadata injection payloads
METADATA_INJECTION_PAYLOADS = [
    {"x-custom-header": "'; DROP TABLE users;--"},
    {"authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJzdWIiOiIxMjM0NTY3ODkwIn0."},
    {"x-forwarded-for": "127.0.0.1"},
    {"x-real-ip": "127.0.0.1"},
    {"x-user-id": "admin"},
    {"grpc-timeout": "999999999S"},  # Extreme timeout
    {"content-type": "application/grpc+json"},  # Content type confusion
]

# Large message payloads for DoS testing
MESSAGE_SIZE_LIMITS = [
    1024,           # 1KB
    1024 * 100,     # 100KB
    1024 * 1024,    # 1MB
    1024 * 1024 * 10,  # 10MB
    1024 * 1024 * 100, # 100MB
]


class GRPCSecurityService:
    """Service for testing gRPC API security."""
    
    def __init__(self, plugin_instance: Any, grpc_client: Any = None):
        self.plugin = plugin_instance
        self.grpc_client = grpc_client
        self.findings: List[APISecurityFinding] = []
        self.test_results: List[GRPCTestResult] = []
        self.discovered_services: List[GRPCServiceInfo] = []
    
    async def _check_reflection(
        self,
        host: str,
        port: int,
    ) -> Tuple[bool, List[str]]:
        """
        Check if gRPC reflection is enabled.
        
        Returns:
            Tuple of (reflection_enabled, list_of_services)
        """
        if self.grpc_client is None:
            # Simulate for testing
            return (False, [])
        
        try:
            # In real implementation, use grpc reflection client
            # from grpc_reflection.v1alpha import reflection_pb2_grpc
            # stub = reflection_pb2_grpc.ServerReflectionStub(channel)
            pass
        except Exception:
            pass
        
        return (False, [])
    
    async def _check_tls(
        self,
        host: str,
        port: int,
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if gRPC channel uses TLS.
        
        Returns:
            Tuple of (uses_tls, certificate_info)
        """
        if self.grpc_client is None:
            return (True, None)  # Assume secure for testing
        
        try:
            # In real implementation, check channel credentials
            pass
        except Exception:
            pass
        
        return (True, None)
    
    async def test_reflection_exposure(
        self,
        host: str,
        port: int = 50051,
    ) -> GRPCTestResult:
        """Test if gRPC reflection API is exposed."""
        reflection_enabled, services = await self._check_reflection(host, port)
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}",
            method="ServerReflection",
            test_type=TestSubCategory.GRPC_REFLECTION,
            vulnerable=reflection_enabled,
            evidence=f"Discovered {len(services)} services: {', '.join(services[:5])}{'...' if len(services) > 5 else ''}" if services else None,
        )
        
        if reflection_enabled:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_REFLECTION,
                severity=SeverityLevel.MEDIUM,
                description="gRPC reflection API is enabled. This allows attackers to discover all available services and methods.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_insecure_channel(
        self,
        host: str,
        port: int = 50051,
    ) -> GRPCTestResult:
        """Test if gRPC channel uses insecure transport."""
        uses_tls, cert_info = await self._check_tls(host, port)
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}",
            method=None,
            test_type=TestSubCategory.GRPC_INSECURE_CHANNEL,
            vulnerable=not uses_tls,
            evidence="Channel does not use TLS encryption" if not uses_tls else None,
        )
        
        if not uses_tls:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_INSECURE_CHANNEL,
                severity=SeverityLevel.HIGH,
                description="gRPC channel is using insecure transport (no TLS). All data including authentication tokens is transmitted in plaintext.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_metadata_injection(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
    ) -> List[GRPCTestResult]:
        """Test for metadata injection vulnerabilities."""
        results = []
        
        for payload in METADATA_INJECTION_PAYLOADS:
            result = GRPCTestResult(
                test_id=str(uuid.uuid4()),
                service=f"{host}:{port}/{service}",
                method=method,
                test_type=TestSubCategory.GRPC_METADATA_INJECTION,
                vulnerable=False,  # Set based on response analysis
                request_metadata=payload,
            )
            
            if self.grpc_client:
                # In real implementation, send request with injected metadata
                # and analyze response for injection success
                pass
            
            results.append(result)
        
        self.test_results.extend(results)
        return results
    
    async def test_message_size_dos(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
    ) -> GRPCTestResult:
        """Test for message size DoS vulnerabilities."""
        max_accepted_size = 0
        
        for size in MESSAGE_SIZE_LIMITS:
            # In real implementation, send large message and check response
            if self.grpc_client:
                try:
                    # Create message of specified size
                    # Send to service
                    # Check if accepted
                    pass
                except Exception:
                    break
            max_accepted_size = size
        
        # Vulnerable if accepts very large messages (>10MB)
        vulnerable = max_accepted_size >= 1024 * 1024 * 10
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}/{service}",
            method=method,
            test_type=TestSubCategory.GRPC_MESSAGE_SIZE,
            vulnerable=vulnerable,
            evidence=f"Accepts messages up to {max_accepted_size / (1024*1024):.1f}MB" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_MESSAGE_SIZE,
                severity=SeverityLevel.MEDIUM,
                description="gRPC service accepts very large messages which could lead to resource exhaustion DoS.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_deadline_abuse(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
    ) -> GRPCTestResult:
        """Test for deadline/timeout abuse vulnerabilities."""
        # Test with extremely long deadline
        long_deadline_accepted = False
        
        if self.grpc_client:
            # In real implementation, send request with very long deadline
            # and check if server accepts it
            pass
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}/{service}",
            method=method,
            test_type=TestSubCategory.GRPC_DEADLINE_ABUSE,
            vulnerable=long_deadline_accepted,
            request_metadata={"grpc-timeout": "999999999S"},
            evidence="Server accepts extremely long deadlines" if long_deadline_accepted else None,
        )
        
        if long_deadline_accepted:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_DEADLINE_ABUSE,
                severity=SeverityLevel.LOW,
                description="gRPC service accepts extremely long deadlines which could be abused for resource exhaustion.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_stream_exhaustion(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
        max_streams: int = 1000,
    ) -> GRPCTestResult:
        """Test for stream exhaustion vulnerabilities."""
        streams_opened = 0
        
        if self.grpc_client:
            # In real implementation, open many concurrent streams
            # to test for stream exhaustion
            pass
        
        # Vulnerable if can open many streams without rate limiting
        vulnerable = streams_opened >= max_streams
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}/{service}",
            method=method,
            test_type=TestSubCategory.GRPC_STREAM_EXHAUSTION,
            vulnerable=vulnerable,
            evidence=f"Successfully opened {streams_opened} concurrent streams" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_STREAM_EXHAUSTION,
                severity=SeverityLevel.MEDIUM,
                description="gRPC service allows excessive concurrent streams which could lead to resource exhaustion.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_weak_authentication(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
    ) -> GRPCTestResult:
        """Test for weak or missing authentication."""
        auth_required = True
        auth_bypassable = False
        
        if self.grpc_client:
            # In real implementation:
            # 1. Try request without any auth
            # 2. Try request with invalid auth
            # 3. Try request with malformed auth
            pass
        
        vulnerable = not auth_required or auth_bypassable
        
        result = GRPCTestResult(
            test_id=str(uuid.uuid4()),
            service=f"{host}:{port}/{service}",
            method=method,
            test_type=TestSubCategory.GRPC_WEAK_AUTH,
            vulnerable=vulnerable,
            evidence="Authentication is not required or can be bypassed" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                host=host,
                port=port,
                test_type=TestSubCategory.GRPC_WEAK_AUTH,
                severity=SeverityLevel.CRITICAL,
                description="gRPC service does not properly enforce authentication, allowing unauthorized access.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def scan_service(
        self,
        host: str,
        port: int = 50051,
        service: str = "",
        method: str = "",
    ) -> List[GRPCTestResult]:
        """
        Comprehensive gRPC security scan.
        
        Runs all gRPC security tests on the specified service.
        """
        all_results = []
        
        # Test reflection exposure
        result = await self.test_reflection_exposure(host, port)
        all_results.append(result)
        
        # Test insecure channel
        result = await self.test_insecure_channel(host, port)
        all_results.append(result)
        
        # Test weak authentication
        result = await self.test_weak_authentication(host, port, service, method)
        all_results.append(result)
        
        # Test metadata injection
        results = await self.test_metadata_injection(host, port, service, method)
        all_results.extend(results)
        
        # Test message size DoS
        result = await self.test_message_size_dos(host, port, service, method)
        all_results.append(result)
        
        # Test deadline abuse
        result = await self.test_deadline_abuse(host, port, service, method)
        all_results.append(result)
        
        # Test stream exhaustion
        result = await self.test_stream_exhaustion(host, port, service, method)
        all_results.append(result)
        
        return all_results
    
    def _create_finding(
        self,
        host: str,
        port: int,
        test_type: TestSubCategory,
        severity: SeverityLevel,
        description: str,
        evidence: Optional[str] = None,
    ) -> APISecurityFinding:
        """Create a security finding."""
        owasp_mapping = {
            TestSubCategory.GRPC_REFLECTION: OWASPCategory.API9_IMPROPER_INVENTORY,
            TestSubCategory.GRPC_INSECURE_CHANNEL: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.GRPC_NO_TLS: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.GRPC_WEAK_AUTH: OWASPCategory.API2_BROKEN_AUTH,
            TestSubCategory.GRPC_DOS: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.GRPC_MESSAGE_SIZE: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.GRPC_METADATA_INJECTION: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.GRPC_DEADLINE_ABUSE: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.GRPC_STREAM_EXHAUSTION: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.GRPC_PROTO_POISONING: OWASPCategory.API10_UNSAFE_CONSUMPTION,
        }
        
        recommendation_mapping = {
            TestSubCategory.GRPC_REFLECTION: "Disable gRPC reflection in production environments or restrict access to authorized clients only.",
            TestSubCategory.GRPC_INSECURE_CHANNEL: "Enable TLS encryption for all gRPC channels. Use mTLS for sensitive services.",
            TestSubCategory.GRPC_NO_TLS: "Configure gRPC server to require TLS connections. Reject insecure connections.",
            TestSubCategory.GRPC_WEAK_AUTH: "Implement proper authentication using call credentials or interceptors. Use mTLS for service-to-service auth.",
            TestSubCategory.GRPC_DOS: "Implement rate limiting and circuit breakers for gRPC services.",
            TestSubCategory.GRPC_MESSAGE_SIZE: "Set appropriate message size limits using MaxRecvMsgSize and MaxSendMsgSize options.",
            TestSubCategory.GRPC_METADATA_INJECTION: "Validate and sanitize all metadata headers. Use allowlist for accepted metadata keys.",
            TestSubCategory.GRPC_DEADLINE_ABUSE: "Set maximum deadline limits server-side to prevent resource exhaustion.",
            TestSubCategory.GRPC_STREAM_EXHAUSTION: "Limit maximum concurrent streams per connection using MaxConcurrentStreams option.",
            TestSubCategory.GRPC_PROTO_POISONING: "Validate protobuf messages against expected schema. Use proto validation libraries.",
        }
        
        return APISecurityFinding(
            id=str(uuid.uuid4()),
            category=TestCategory.REST_API,  # Using REST_API as gRPC is not a separate category yet
            sub_category=test_type,
            severity=severity,
            confidence=ConfidenceLevel.HIGH,
            owasp=owasp_mapping.get(test_type, OWASPCategory.API8_SECURITY_MISCONFIGURATION),
            title=f"gRPC Security Issue: {test_type.value}",
            description=description,
            url=f"grpc://{host}:{port}",
            parameter=None,
            payload_used=None,
            risk_score=self._calculate_risk_score(severity),
            recommendation=recommendation_mapping.get(test_type, "Review and fix the security issue."),
            remediation_steps=[
                "Review gRPC security configuration",
                recommendation_mapping.get(test_type, ""),
                "Implement security monitoring for gRPC services",
                "Conduct regular security audits of gRPC endpoints",
            ],
            evidence={"raw": evidence} if evidence else None,
        )
    
    def _calculate_risk_score(self, severity: SeverityLevel) -> float:
        """Calculate risk score based on severity."""
        scores = {
            SeverityLevel.CRITICAL: 9.5,
            SeverityLevel.HIGH: 7.5,
            SeverityLevel.MEDIUM: 5.0,
            SeverityLevel.LOW: 3.0,
            SeverityLevel.INFO: 1.0,
        }
        return scores.get(severity, 5.0)
    
    def get_results(self) -> List[GRPCTestResult]:
        """Get all test results."""
        return self.test_results
    
    def get_findings(self) -> List[APISecurityFinding]:
        """Get all security findings."""
        return self.findings
    
    def clear(self):
        """Clear results and findings."""
        self.test_results.clear()
        self.findings.clear()
        self.discovered_services.clear()

