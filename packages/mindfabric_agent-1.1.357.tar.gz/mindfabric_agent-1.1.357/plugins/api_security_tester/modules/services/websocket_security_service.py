"""
WebSocket Security Service

Service for testing WebSocket API security vulnerabilities:
- Origin bypass (missing/weak origin validation)
- Missing authentication
- Message injection
- DoS via message flooding
- Cross-Site WebSocket Hijacking (CSWSH)
- Message tampering
- Insecure protocol (ws:// instead of wss://)
- Rate limiting
- Reconnection abuse
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
import asyncio
from typing import Any, List, Optional, Dict, Tuple
from dataclasses import dataclass
from urllib.parse import urlparse

from ...proto import (
    APISecurityFinding,
    TestResult,
    TestCategory,
    TestSubCategory,
    SeverityLevel,
    ConfidenceLevel,
    OWASPCategory,
)


@dataclass
class WebSocketEndpointInfo:
    """Information about a WebSocket endpoint."""
    url: str
    origin_required: bool = False
    auth_required: bool = False
    protocols: List[str] = None
    max_message_size: Optional[int] = None
    
    def __post_init__(self):
        if self.protocols is None:
            self.protocols = []


@dataclass
class WebSocketTestResult:
    """Result of a WebSocket security test."""
    test_id: str
    url: str
    test_type: TestSubCategory
    vulnerable: bool
    evidence: Optional[str] = None
    request_headers: Optional[Dict[str, str]] = None
    message_sent: Optional[str] = None
    message_received: Optional[str] = None


# Origin bypass payloads
ORIGIN_BYPASS_PAYLOADS = [
    None,  # No origin header
    "",  # Empty origin
    "null",  # null origin
    "http://198.51.100.10",  # Different domain (TEST-NET-2, documentation)
    "http://localhost",  # Localhost
    "http://127.0.0.1",  # Loopback
    "file://",  # File protocol
    "https://198.51.100.10.victim.example.test",  # Subdomain confusion pattern
    "https://victim.example.test.different-origin.example.test",  # Suffix confusion pattern
]

# Message injection payloads
MESSAGE_INJECTION_PAYLOADS = [
    '{"type":"auth","token":"admin"}',
    '{"type":"subscribe","channel":"*"}',
    '{"type":"admin","action":"list_users"}',
    '<script>alert(1)</script>',
    '{"__proto__":{"admin":true}}',
    '{"constructor":{"prototype":{"admin":true}}}',
    '"; DROP TABLE users;--',
    '${7*7}',
    '{{7*7}}',
    '../../../etc/passwd',
]

# DoS test parameters
DOS_TEST_PARAMS = {
    "message_flood_count": 1000,
    "large_message_sizes": [1024, 10240, 102400, 1048576],  # 1KB, 10KB, 100KB, 1MB
    "rapid_reconnect_count": 100,
}


class WebSocketSecurityService:
    """Service for testing WebSocket API security."""
    
    def __init__(self, plugin_instance: Any, ws_client: Any = None):
        self.plugin = plugin_instance
        self.ws_client = ws_client
        self.findings: List[APISecurityFinding] = []
        self.test_results: List[WebSocketTestResult] = []
        self.discovered_endpoints: List[WebSocketEndpointInfo] = []
    
    async def _connect(
        self,
        url: str,
        origin: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 10.0,
    ) -> Tuple[bool, Optional[str]]:
        """
        Attempt WebSocket connection.
        
        Returns:
            Tuple of (success, error_message)
        """
        if self.ws_client is None:
            # Simulate for testing
            return (True, None)
        
        try:
            # In real implementation, use websocket client
            # import websockets
            # async with websockets.connect(url, origin=origin, extra_headers=headers) as ws:
            #     return (True, None)
            pass
        except Exception as e:
            return (False, str(e))
        
        return (True, None)
    
    async def _send_message(
        self,
        url: str,
        message: str,
        origin: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Send message and get response.
        
        Returns:
            Tuple of (response, error_message)
        """
        if self.ws_client is None:
            return (None, None)
        
        try:
            # In real implementation:
            # async with websockets.connect(url, origin=origin, extra_headers=headers) as ws:
            #     await ws.send(message)
            #     response = await ws.recv()
            #     return (response, None)
            pass
        except Exception as e:
            return (None, str(e))
        
        return (None, None)
    
    async def test_origin_bypass(
        self,
        url: str,
        legitimate_origin: Optional[str] = None,
    ) -> List[WebSocketTestResult]:
        """Test for origin validation bypass."""
        results = []
        
        # Parse URL to get expected origin
        parsed = urlparse(url)
        if legitimate_origin is None:
            legitimate_origin = f"{parsed.scheme.replace('ws', 'http')}://{parsed.netloc}"
        
        for malicious_origin in ORIGIN_BYPASS_PAYLOADS:
            success, error = await self._connect(url, origin=malicious_origin)
            
            result = WebSocketTestResult(
                test_id=str(uuid.uuid4()),
                url=url,
                test_type=TestSubCategory.WEBSOCKET_ORIGIN_BYPASS,
                vulnerable=success,
                evidence=f"Connection accepted with origin: {malicious_origin}" if success else None,
                request_headers={"Origin": malicious_origin} if malicious_origin else {},
            )
            
            if success and malicious_origin != legitimate_origin:
                self.findings.append(self._create_finding(
                    url=url,
                    test_type=TestSubCategory.WEBSOCKET_ORIGIN_BYPASS,
                    severity=SeverityLevel.HIGH,
                    description=f"WebSocket endpoint accepts connections from untrusted origin: {malicious_origin}",
                    evidence=result.evidence,
                ))
                results.append(result)
                break  # Found vulnerability, no need to test more
            
            results.append(result)
        
        self.test_results.extend(results)
        return results
    
    async def test_missing_auth(
        self,
        url: str,
    ) -> WebSocketTestResult:
        """Test if WebSocket requires authentication."""
        # Try connecting without any auth
        success, error = await self._connect(url)
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_NO_AUTH,
            vulnerable=success,
            evidence="Connection established without authentication" if success else None,
        )
        
        if success:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_NO_AUTH,
                severity=SeverityLevel.HIGH,
                description="WebSocket endpoint does not require authentication. Any client can connect.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_message_injection(
        self,
        url: str,
        origin: Optional[str] = None,
    ) -> List[WebSocketTestResult]:
        """Test for message injection vulnerabilities."""
        results = []
        
        for payload in MESSAGE_INJECTION_PAYLOADS:
            response, error = await self._send_message(url, payload, origin)
            
            # Analyze response for injection success indicators
            injection_success = False
            if response:
                # Check for various injection success patterns
                if any(indicator in response.lower() for indicator in [
                    "admin", "success", "authorized", "granted", "true",
                    "users", "password", "token", "7*7=49", "49"
                ]):
                    injection_success = True
            
            result = WebSocketTestResult(
                test_id=str(uuid.uuid4()),
                url=url,
                test_type=TestSubCategory.WEBSOCKET_INJECTION,
                vulnerable=injection_success,
                evidence=f"Injection payload accepted: {payload[:50]}..." if injection_success else None,
                message_sent=payload,
                message_received=response[:200] if response else None,
            )
            
            if injection_success:
                self.findings.append(self._create_finding(
                    url=url,
                    test_type=TestSubCategory.WEBSOCKET_INJECTION,
                    severity=SeverityLevel.CRITICAL,
                    description=f"WebSocket endpoint vulnerable to message injection. Payload: {payload[:50]}...",
                    evidence=result.evidence,
                ))
            
            results.append(result)
        
        self.test_results.extend(results)
        return results
    
    async def test_insecure_protocol(
        self,
        url: str,
    ) -> WebSocketTestResult:
        """Test if WebSocket uses insecure ws:// instead of wss://."""
        parsed = urlparse(url)
        uses_tls = parsed.scheme == "wss"
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_INSECURE_PROTOCOL,
            vulnerable=not uses_tls,
            evidence=f"WebSocket using insecure protocol: {parsed.scheme}://" if not uses_tls else None,
        )
        
        if not uses_tls:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_INSECURE_PROTOCOL,
                severity=SeverityLevel.HIGH,
                description="WebSocket endpoint uses unencrypted ws:// protocol. All data is transmitted in plaintext.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_cswsh(
        self,
        url: str,
        legitimate_origin: Optional[str] = None,
    ) -> WebSocketTestResult:
        """Test for Cross-Site WebSocket Hijacking (CSWSH)."""
        # CSWSH is possible if:
        # 1. Origin validation is missing/weak
        # 2. Authentication relies only on cookies (auto-sent by browser)
        
        # Test with cross-origin connection
        success, error = await self._connect(url, origin="http://198.51.100.10")
        
        # If connection succeeds from cross-origin, check if it's using cookie auth
        vulnerable = success  # Simplified check
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_CSWSH,
            vulnerable=vulnerable,
            evidence="WebSocket accepts cross-origin connections and may be vulnerable to CSWSH" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_CSWSH,
                severity=SeverityLevel.CRITICAL,
                description="WebSocket endpoint vulnerable to Cross-Site WebSocket Hijacking (CSWSH). Attacker can hijack authenticated sessions.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_rate_limiting(
        self,
        url: str,
        message_count: int = 100,
        origin: Optional[str] = None,
    ) -> WebSocketTestResult:
        """Test if WebSocket has rate limiting."""
        messages_sent = 0
        rate_limited = False
        
        if self.ws_client:
            # In real implementation, rapidly send messages
            # and check for rate limiting responses
            pass
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_RATE_LIMITING,
            vulnerable=not rate_limited,
            evidence=f"Successfully sent {messages_sent} messages without rate limiting" if not rate_limited else None,
        )
        
        if not rate_limited:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_RATE_LIMITING,
                severity=SeverityLevel.MEDIUM,
                description="WebSocket endpoint does not implement rate limiting, making it vulnerable to flooding attacks.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_dos(
        self,
        url: str,
        origin: Optional[str] = None,
    ) -> WebSocketTestResult:
        """Test for DoS vulnerabilities via large messages."""
        max_accepted_size = 0
        
        for size in DOS_TEST_PARAMS["large_message_sizes"]:
            # Create large message
            large_message = "A" * size
            response, error = await self._send_message(url, large_message, origin)
            
            if error is None:
                max_accepted_size = size
            else:
                break
        
        # Vulnerable if accepts very large messages (>100KB)
        vulnerable = max_accepted_size >= 102400
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_DOS,
            vulnerable=vulnerable,
            evidence=f"Accepts messages up to {max_accepted_size / 1024:.1f}KB" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_DOS,
                severity=SeverityLevel.MEDIUM,
                description="WebSocket endpoint accepts very large messages which could be used for DoS attacks.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def test_reconnection_abuse(
        self,
        url: str,
        reconnect_count: int = 50,
        origin: Optional[str] = None,
    ) -> WebSocketTestResult:
        """Test for reconnection abuse (rapid connect/disconnect)."""
        successful_reconnects = 0
        
        if self.ws_client:
            # In real implementation, rapidly connect and disconnect
            # to test for reconnection rate limiting
            pass
        
        # Vulnerable if all reconnects succeed without delay
        vulnerable = successful_reconnects >= reconnect_count
        
        result = WebSocketTestResult(
            test_id=str(uuid.uuid4()),
            url=url,
            test_type=TestSubCategory.WEBSOCKET_RECONNECTION_ABUSE,
            vulnerable=vulnerable,
            evidence=f"Successfully reconnected {successful_reconnects} times rapidly" if vulnerable else None,
        )
        
        if vulnerable:
            self.findings.append(self._create_finding(
                url=url,
                test_type=TestSubCategory.WEBSOCKET_RECONNECTION_ABUSE,
                severity=SeverityLevel.LOW,
                description="WebSocket endpoint allows rapid reconnection which could be used for connection exhaustion attacks.",
                evidence=result.evidence,
            ))
        
        self.test_results.append(result)
        return result
    
    async def scan_endpoint(
        self,
        url: str,
        origin: Optional[str] = None,
    ) -> List[WebSocketTestResult]:
        """
        Comprehensive WebSocket security scan.
        
        Runs all WebSocket security tests on the specified endpoint.
        """
        all_results = []
        
        # Test insecure protocol
        result = await self.test_insecure_protocol(url)
        all_results.append(result)
        
        # Test missing authentication
        result = await self.test_missing_auth(url)
        all_results.append(result)
        
        # Test origin bypass
        results = await self.test_origin_bypass(url, origin)
        all_results.extend(results)
        
        # Test CSWSH
        result = await self.test_cswsh(url, origin)
        all_results.append(result)
        
        # Test message injection
        results = await self.test_message_injection(url, origin)
        all_results.extend(results)
        
        # Test rate limiting
        result = await self.test_rate_limiting(url, origin=origin)
        all_results.append(result)
        
        # Test DoS
        result = await self.test_dos(url, origin)
        all_results.append(result)
        
        # Test reconnection abuse
        result = await self.test_reconnection_abuse(url, origin=origin)
        all_results.append(result)
        
        return all_results
    
    def _create_finding(
        self,
        url: str,
        test_type: TestSubCategory,
        severity: SeverityLevel,
        description: str,
        evidence: Optional[str] = None,
    ) -> APISecurityFinding:
        """Create a security finding."""
        owasp_mapping = {
            TestSubCategory.WEBSOCKET_ORIGIN_BYPASS: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.WEBSOCKET_NO_AUTH: OWASPCategory.API2_BROKEN_AUTH,
            TestSubCategory.WEBSOCKET_INJECTION: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.WEBSOCKET_DOS: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.WEBSOCKET_HIJACKING: OWASPCategory.API2_BROKEN_AUTH,
            TestSubCategory.WEBSOCKET_CSWSH: OWASPCategory.API2_BROKEN_AUTH,
            TestSubCategory.WEBSOCKET_MESSAGE_TAMPERING: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.WEBSOCKET_INSECURE_PROTOCOL: OWASPCategory.API8_SECURITY_MISCONFIGURATION,
            TestSubCategory.WEBSOCKET_RATE_LIMITING: OWASPCategory.API4_LACK_OF_RESOURCES,
            TestSubCategory.WEBSOCKET_RECONNECTION_ABUSE: OWASPCategory.API4_LACK_OF_RESOURCES,
        }
        
        recommendation_mapping = {
            TestSubCategory.WEBSOCKET_ORIGIN_BYPASS: "Implement strict Origin header validation. Only allow connections from trusted domains.",
            TestSubCategory.WEBSOCKET_NO_AUTH: "Implement authentication for WebSocket connections. Use token-based auth passed in initial handshake.",
            TestSubCategory.WEBSOCKET_INJECTION: "Validate and sanitize all incoming WebSocket messages. Use allowlist for message types.",
            TestSubCategory.WEBSOCKET_DOS: "Implement message size limits and rate limiting. Set maximum message size in server configuration.",
            TestSubCategory.WEBSOCKET_HIJACKING: "Use CSRF tokens in WebSocket handshake. Validate session on each message.",
            TestSubCategory.WEBSOCKET_CSWSH: "Implement Origin validation and use custom authentication headers instead of cookies.",
            TestSubCategory.WEBSOCKET_MESSAGE_TAMPERING: "Sign messages and validate signatures. Use message integrity checks.",
            TestSubCategory.WEBSOCKET_INSECURE_PROTOCOL: "Use wss:// (WebSocket Secure) instead of ws://. Configure server to reject insecure connections.",
            TestSubCategory.WEBSOCKET_RATE_LIMITING: "Implement rate limiting per connection and per user. Use sliding window rate limiting.",
            TestSubCategory.WEBSOCKET_RECONNECTION_ABUSE: "Implement reconnection backoff. Limit reconnection attempts per IP.",
        }
        
        return APISecurityFinding(
            id=str(uuid.uuid4()),
            category=TestCategory.REST_API,  # Using REST_API as WebSocket is not a separate category yet
            sub_category=test_type,
            severity=severity,
            confidence=ConfidenceLevel.HIGH,
            owasp=owasp_mapping.get(test_type, OWASPCategory.API8_SECURITY_MISCONFIGURATION),
            title=f"WebSocket Security Issue: {test_type.value}",
            description=description,
            url=url,
            parameter=None,
            payload_used=None,
            risk_score=self._calculate_risk_score(severity),
            recommendation=recommendation_mapping.get(test_type, "Review and fix the security issue."),
            remediation_steps=[
                "Review WebSocket security configuration",
                recommendation_mapping.get(test_type, ""),
                "Implement security monitoring for WebSocket connections",
                "Use secure WebSocket libraries with built-in security features",
            ],
            evidence={"raw": evidence} if evidence else None,
        )
    
    def _calculate_risk_score(self, severity: SeverityLevel) -> float:
        """Calculate risk score based on severity."""
        scores = {
            SeverityLevel.CRITICAL: 9.5,
            SeverityLevel.HIGH: 7.5,
            SeverityLevel.MEDIUM: 5.0,
            SeverityLevel.LOW: 3.0,
            SeverityLevel.INFO: 1.0,
        }
        return scores.get(severity, 5.0)
    
    def get_results(self) -> List[WebSocketTestResult]:
        """Get all test results."""
        return self.test_results
    
    def get_findings(self) -> List[APISecurityFinding]:
        """Get all security findings."""
        return self.findings
    
    def clear(self):
        """Clear results and findings."""
        self.test_results.clear()
        self.findings.clear()
        self.discovered_endpoints.clear()

