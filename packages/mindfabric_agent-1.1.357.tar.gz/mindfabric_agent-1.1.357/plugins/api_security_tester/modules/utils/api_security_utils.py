"""
API Security Utilities

Contains utility functions for API security testing.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import base64
import hashlib
import hmac
import json
from typing import Dict, List, Tuple

from ...proto import (
    SeverityLevel,
    ConfidenceLevel,
    APIEndpoint,
    HTTPMethod,
)


def calculate_risk_score(
    severity: SeverityLevel,
    confidence: ConfidenceLevel,
    is_authenticated: bool = False,
) -> float:
    """Calculate risk score 0-10."""
    severity_weights = {
        SeverityLevel.CRITICAL: 9.0,
        SeverityLevel.HIGH: 7.0,
        SeverityLevel.MEDIUM: 5.0,
        SeverityLevel.LOW: 3.0,
        SeverityLevel.INFO: 1.0,
    }
    
    confidence_multiplier = {
        ConfidenceLevel.CONFIRMED: 1.0,
        ConfidenceLevel.HIGH: 0.9,
        ConfidenceLevel.MEDIUM: 0.7,
        ConfidenceLevel.LOW: 0.5,
        ConfidenceLevel.TENTATIVE: 0.3,
    }
    
    base = severity_weights.get(severity, 5.0)
    conf = confidence_multiplier.get(confidence, 0.7)
    
    score = base * conf
    
    # Unauthenticated access is more severe
    if not is_authenticated:
        score += 0.5
    
    return min(10.0, score)


def decode_jwt_parts(token: str) -> Tuple[Dict, Dict, str]:
    """Decode JWT without verification."""
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")
    
    def decode_part(part: str) -> Dict:
        # Add padding if needed
        padding = 4 - len(part) % 4
        if padding != 4:
            part += "=" * padding
        decoded = base64.urlsafe_b64decode(part)
        return json.loads(decoded)
    
    header = decode_part(parts[0])
    payload = decode_part(parts[1])
    signature = parts[2]
    
    return header, payload, signature


def encode_jwt_part(data: Dict) -> str:
    """Encode data as JWT part."""
    json_bytes = json.dumps(data, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(json_bytes).decode().rstrip("=")


def create_jwt(header: Dict, payload: Dict, secret: str = "", algorithm: str = "HS256") -> str:
    """Create a JWT token."""
    header_b64 = encode_jwt_part(header)
    payload_b64 = encode_jwt_part(payload)
    
    message = f"{header_b64}.{payload_b64}"
    
    if algorithm.lower() == "none":
        signature = ""
    elif algorithm.startswith("HS"):
        signature = base64.urlsafe_b64encode(
            hmac.new(secret.encode(), message.encode(), hashlib.sha256).digest()
        ).decode().rstrip("=")
    else:
        signature = "INVALID"
    
    return f"{message}.{signature}"


def parse_openapi_spec(spec: Dict) -> List[APIEndpoint]:
    """Parse OpenAPI/Swagger specification."""
    endpoints = []
    
    paths = spec.get("paths", {})
    
    for path, methods in paths.items():
        for method, details in methods.items():
            if method.upper() in [m.value for m in HTTPMethod]:
                endpoint = APIEndpoint(
                    path=path,
                    method=HTTPMethod(method.upper()),
                    name=details.get("operationId"),
                    description=details.get("summary") or details.get("description"),
                    tags=details.get("tags"),
                    auth_required="security" in details or "security" in spec,
                )
                endpoints.append(endpoint)
    
    return endpoints

