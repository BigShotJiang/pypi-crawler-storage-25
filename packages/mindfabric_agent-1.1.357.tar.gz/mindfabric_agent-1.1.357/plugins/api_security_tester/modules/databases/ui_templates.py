from __future__ import annotations

from typing import Any, Dict, List, Optional


API_SECURITY_HARDENING_IMPACT: str = (
    "APIs are a direct attack surface. Weak authorization, excessive permissions, missing rate limits, and insecure token handling "
    "can lead to data exfiltration (IDOR/BOLA), account takeover, privilege escalation, and service disruption."
)


def build_api_hardening_description(target_url: Optional[str], reco_count: int) -> str:
    base = (target_url or "").strip()
    scope = f" for `{base}`" if base else ""
    return (
        f"Hardening guidance{scope} based on API security checks. "
        "These recommendations focus on common hacker playbooks: abusing missing object-level authorization (BOLA/IDOR), "
        "skipping authz checks, exploiting weak JWT/OAuth validation, probing for GraphQL introspection, and brute-forcing when rate limits are absent. "
        f"Generated {reco_count} recommendation(s)."
    )


def build_api_hardening_evidence(target_url: Optional[str], reco_count: int) -> Dict[str, Any]:
    return {
        "source": "api_security_tester.recommendations",
        "target_url": target_url,
        "recommendations_count": int(reco_count),
    }


def get_api_hardening_exploitation_commands(target_url: Optional[str]) -> List[str]:
    """
    Read-only verification commands for API hardening.
    Keep them safe: no fuzzing loops, no destructive payloads.
    """
    base = (target_url or "").rstrip("/")
    tgt = base or "${TARGET_URL}"

    cmds: List[str] = [
        "# Basic liveness / headers",
        f"curl -sS -i {tgt} || true",
        "# Health and API docs exposure (best-effort)",
        f"curl -sS -i {tgt + '/health' if base else '${TARGET_URL}/health'} || true",
        f"curl -sS -i {tgt + '/swagger.json' if base else '${TARGET_URL}/swagger.json'} || true",
        f"curl -sS -i {tgt + '/openapi.json' if base else '${TARGET_URL}/openapi.json'} || true",
        "# Check if auth is enforced (expect 401/403 on protected endpoints)",
        f"curl -sS -i {tgt + '/api/me' if base else '${TARGET_URL}/api/me'} || true",
        f"curl -sS -i -H 'Authorization: Bearer INVALID' {tgt + '/api/me' if base else '${TARGET_URL}/api/me'} || true",
        "# CORS and security headers (best-effort)",
        (
            f"curl -sS -i -H 'Origin: https://foreign-origin.example.test' {tgt} | "
            "grep -iE 'access-control-allow-origin|access-control-allow-credentials|strict-transport-security|content-security-policy|x-frame-options|x-content-type-options' || true"
        ),
    ]
    # Remove empty separator lines so UI doesn't show blank command blocks.
    return [c for c in cmds if isinstance(c, str) and c.strip()]

