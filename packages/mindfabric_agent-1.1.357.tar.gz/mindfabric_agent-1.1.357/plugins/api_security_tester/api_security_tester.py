"""
API Security Tester Plugin

Comprehensive API security testing covering:
- REST API (BOLA, BFLA, Mass Assignment, Injection)
- GraphQL (Introspection, DoS, Batching, Authorization)
- OAuth 2.0/OIDC (Redirect URI, State, PKCE, Token Leakage)
- JWT (None Algorithm, Algorithm Confusion, Weak Secret, Claim Tampering)
"""

import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from .proto import (
    APITarget,
    APIType,
    APISecurityScanOutput,
    ScanOptions,
    RESTAPIInfo,
    APIEndpoint,
    TestResult,
    HTTPMethod,
    TestSubCategory,
    JWTAnalysis,
    OWASPCategory,
    TestCategory,
    APISecurityFinding,
    SeverityLevel,
    ConfidenceLevel,
)

from .modules.utils.api_security_utils import parse_openapi_spec
from .modules.services import (
    RESTSecurityService,
    GraphQLSecurityService,
    OAuthSecurityService,
    JWTSecurityService,
    GRPCSecurityService,
    WebSocketSecurityService,
    ConfigurationSecurityService,
    AdvancedAPISecurityService,
    AIMLSecurityService,
    SessionSecurityService,
    GraphQLFederationService,
    RecommendationsService,
    OutputService,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Main Plugin Class
# =============================================================================

from plugins.base_plugin import BasePlugin

class APISecurityTesterPlugin(BasePlugin):
    VERSION = "1.0.0"
    """
    API Security Tester Plugin.
    
    Tests REST APIs, GraphQL, OAuth 2.0/OIDC, and JWT
    for security vulnerabilities.
    """
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
        # Initialize services
        self.rest_service = RESTSecurityService(self)
        self.graphql_service = GraphQLSecurityService(self)
        self.oauth_service = OAuthSecurityService(self)
        self.jwt_service = JWTSecurityService(self)
        self.grpc_service = GRPCSecurityService(self)
        self.websocket_service = WebSocketSecurityService(self)
        self.config_service = ConfigurationSecurityService(self)
        self.advanced_security_service = AdvancedAPISecurityService(self)
        self.ai_ml_service = AIMLSecurityService(self)
        self.session_service = SessionSecurityService(self)
        self.graphql_federation_service = GraphQLFederationService(self)
        self.recommendations_service = RecommendationsService(self)
        self.output_service = OutputService(self)
        
        # Results
        self.findings: List[APISecurityFinding] = []
        self.test_results: List[TestResult] = []
        self.endpoints: List[APIEndpoint] = []
        
        # Counters
        self.requests_sent: int = 0
        self.tests_executed: int = 0
        
        # MindFabric integration
        self.command_id: Optional[str] = None
        self.ws: Optional[Any] = None
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket."""
        if self.ws:
            try:
                await self.ws.send_json({
                    "type": "progress",
                    "command_id": self.command_id,
                    "percent": percent,
                    "message": message
                })
            except Exception:
                pass
        logger.debug(f"Progress: {percent}% - {message}")
    
    async def run(self):
        """Main entry point."""
        from .proto import ScanOptions, APITarget, APIType
        
        # Check if a specific command was requested
        command = self.options.get('command', 'run')
        
        # Parse URL from various possible option keys
        target_url = (
            self.options.get("url")
            or self.options.get("target_url")
            or self.options.get("base_url")
            or self.options.get("target")
        )

        # Auto-discovery (local-only) when URL isn't explicitly provided.
        targets: List[str] = []
        if not target_url:
            try:
                from utils.target_discovery import discover_local_api_targets

                targets = await discover_local_api_targets(max_targets=2)
            except Exception:
                targets = []
        else:
            targets = [str(target_url)]

        if not targets:
            from .proto import APISecurityScanOutput, ScanMetadata

            now = datetime.utcnow()
            output = APISecurityScanOutput(
                metadata=ScanMetadata(
                    scan_id=str(uuid.uuid4()),
                    scan_type="api_security",
                    started_at=now,
                    completed_at=now,
                    duration_seconds=0.0,
                    target_url="(not provided)",
                    api_type=APIType.REST,
                    endpoints_discovered=0,
                    endpoints_tested=0,
                    tests_executed=0,
                    requests_sent=0,
                    total_findings=0,
                    tool_version=self.VERSION,
                ),
                errors=[],
                # Silent skip: do not emit warnings/findings when there is nothing to scan.
                warnings=[],
                findings=[],
                critical_findings=[],
                test_results=[],
                recommendations=[],
                quick_wins=[],
            )
            return self.to_security_scan_v1(self._with_canonical_findings(output))
        
        logger.info(f"API Security Tester targeting: {targets[0]}")
        
        # Run for all discovered targets (local-only); merge outputs.
        merged: Dict[str, Any] = {"findings": [], "errors": [], "warnings": [], "metadata": {"auto_targets": targets if not target_url else None}}
        for t in targets:
            target = APITarget(base_url=t, api_type=APIType.REST)
            options = ScanOptions(target=target)
            result = await self.hook_api_security_scan(options)
            if hasattr(result, "model_dump"):
                r = result.model_dump()
            elif hasattr(result, "dict"):
                r = result.dict()
            elif isinstance(result, dict):
                r = dict(result)
            else:
                r = {}

            if isinstance(r.get("findings"), list):
                merged["findings"].extend(r.get("findings") or [])
            if isinstance(r.get("errors"), list):
                merged["errors"].extend([str(x) for x in r.get("errors") if x])
            if isinstance(r.get("warnings"), list):
                merged["warnings"].extend([str(x) for x in r.get("warnings") if x])
            # Prefer first target metadata for UI
            if not merged.get("metadata") and isinstance(r.get("metadata"), dict):
                merged["metadata"] = r.get("metadata")

        return self.to_security_scan_v1(self._with_canonical_findings(merged))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Add plugin-owned `findings` for canonical security_scan v1.
        Avoids any plugin-specific parsing in security_contract.
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        findings_existing = out.get("findings") or []
        meta = out.get("metadata") if isinstance(out.get("metadata"), dict) else {}
        base_url = meta.get("target_url")
        at = meta.get("auto_targets")
        if isinstance(at, list) and at:
            first = at[0]
            if isinstance(first, str) and first.strip():
                base_url = base_url or first.strip()
            elif isinstance(first, dict):
                u0 = first.get("url") or first.get("base_url") or first.get("baseUrl")
                if isinstance(u0, str) and u0.strip():
                    base_url = base_url or u0.strip()

        if isinstance(findings_existing, list) and len(findings_existing) > 0:
            for f in findings_existing:
                if not isinstance(f, dict) or f.get("affected_resources"):
                    continue
                u = (
                    f.get("endpoint")
                    or f.get("url")
                    or f.get("request_url")
                    or f.get("requestUrl")
                    or f.get("target_url")
                    or f.get("targetUrl")
                    or base_url
                )
                if isinstance(u, str) and u.strip().lower().startswith(("http://", "https://")):
                    f["affected_resources"] = [{"type": "api_target", "url": u.strip()[:2000]}]
            out["findings"] = findings_existing
            return out

        # If the run produced errors (e.g., no target URL), do not synthesize findings.
        errors = out.get("errors") or []
        if isinstance(errors, list) and len(errors) > 0:
            out["findings"] = []
            return out

        # Recommendations / quick_wins stay on the scan output model — not as synthetic threat findings.
        out["findings"] = []
        return out

    
    async def hook_api_security_scan(
        self,
        options: ScanOptions,
    ) -> APISecurityScanOutput:
        """
        Main entry point for API security testing.
        
        Args:
            options: Scan configuration
            
        Returns:
            APISecurityScanOutput
        """
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.utcnow()
        self.errors = []
        self.warnings = []
        self.findings = []
        self.test_results = []
        self.requests_sent = 0
        self.tests_executed = 0
        
        await self._handle_progress(0, "Starting API security scan")
        
        # Discover endpoints
        await self._handle_progress(5, "Discovering API endpoints")
        api_info = await self._discover_api(options.target)
        
        # REST API tests
        if options.target.api_type == APIType.REST:
            await self._handle_progress(15, "Testing REST API security")
            await self._test_rest_api(options, api_info)
        
        # GraphQL tests
        if options.target.api_type == APIType.GRAPHQL or options.target.graphql_endpoint:
            await self._handle_progress(35, "Testing GraphQL security")
            await self._test_graphql(options)
        
        # OAuth tests
        if options.target.oauth_config and options.test_oauth_flows:
            await self._handle_progress(55, "Testing OAuth security")
            await self._test_oauth(options)
        
        # JWT tests
        if options.target.auth_token and options.test_jwt_attacks:
            await self._handle_progress(70, "Testing JWT security")
            await self._test_jwt(options)
        
        # Configuration tests
        await self._handle_progress(75, "Testing security configuration")
        await self._test_configuration(options)
        
        # Advanced API security tests (versioning, rate limiting, WAF bypass, etc.)
        await self._handle_progress(80, "Running advanced API security tests")
        await self._test_advanced_security(options, api_info)
        
        # AI/ML API security tests
        await self._handle_progress(85, "Testing AI/ML API security")
        await self._test_ai_ml_security(options)
        
        # Session security tests
        await self._handle_progress(88, "Testing session security")
        await self._test_session_security(options)
        
        # GraphQL Federation tests (if GraphQL detected)
        if any(e.path and 'graphql' in e.path.lower() for e in api_info.endpoints if e.path):
            await self._handle_progress(92, "Testing GraphQL federation security")
            await self._test_graphql_federation(options)
        
        # Generate recommendations
        await self._handle_progress(95, "Generating recommendations")
        recommendations = self.recommendations_service.generate_recommendations()
        quick_wins = self.recommendations_service.get_quick_wins()
        
        await self._handle_progress(100, "Scan complete")
        
        return self.output_service.create_output(
            options, api_info, recommendations, quick_wins
        )
    
    async def _discover_api(self, target: APITarget) -> Optional[RESTAPIInfo]:
        """Discover API endpoints."""
        api_info = RESTAPIInfo(
            base_url=target.base_url,
            endpoints=[],
        )
        
        # Parse OpenAPI spec if provided
        if target.openapi_spec:
            try:
                endpoints = parse_openapi_spec(target.openapi_spec)
                api_info.endpoints = endpoints
                self.endpoints = endpoints
            except Exception as e:
                self.warnings.append(f"Failed to parse OpenAPI spec: {e}")
        
        # Auto-discover common endpoints if none provided
        if not api_info.endpoints:
            await self._auto_discover_endpoints(target, api_info)
        
        return api_info
    
    async def _auto_discover_endpoints(self, target: APITarget, api_info: RESTAPIInfo):
        """Auto-discover common API endpoints by probing."""
        import aiohttp
        
        common_paths = [
            "/api/users", "/api/user", "/users", "/user",
            "/api/admin", "/admin", "/api/debug", "/debug",
            "/api/health", "/health", "/api/status", "/status",
            "/api/config", "/config", "/api/settings", "/settings",
            "/api/schema", "/schema", "/graphql", "/api/graphql",
            "/api/v1/users", "/api/v2/users",
            "/swagger.json", "/openapi.json", "/api-docs",
            "/.env", "/api/env", "/api/secrets",
        ]
        
        discovered = []
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                for path in common_paths:
                    try:
                        url = f"{target.base_url.rstrip('/')}{path}"
                        async with session.get(url) as response:
                            if response.status in [200, 201, 401, 403]:
                                endpoint = APIEndpoint(
                                    path=path,
                                    method=HTTPMethod.GET,
                                    name=f"Discovered: {path}",
                                    description=f"Auto-discovered endpoint (status {response.status})",
                                    auth_required=(response.status in [401, 403]),
                                )
                                discovered.append(endpoint)
                                
                                # Check for security issues in response
                                try:
                                    data = await response.json()
                                    await self._check_response_for_issues(path, data)
                                except:
                                    pass
                    except Exception:
                        continue
        except Exception as e:
            self.warnings.append(f"Auto-discovery failed: {e}")
        
        api_info.endpoints = discovered
        self.endpoints = discovered
        logger.info(f"Auto-discovered {len(discovered)} endpoints")
    
    async def _check_response_for_issues(self, path: str, data: dict):
        """Check API response for security issues."""
        if not isinstance(data, dict):
            return
        
        # Check for sensitive data exposure
        sensitive_keys = ['password', 'secret', 'api_key', 'token', 'private_key', 'credential']
        found_sensitive = []
        
        def check_dict(d, prefix=""):
            for key, value in d.items():
                full_key = f"{prefix}.{key}" if prefix else key
                if any(s in key.lower() for s in sensitive_keys):
                    found_sensitive.append(full_key)
                if isinstance(value, dict):
                    check_dict(value, full_key)
        
        check_dict(data)
        
        if found_sensitive:
            finding = APISecurityFinding(
                id=str(uuid.uuid4()),
                severity=SeverityLevel.HIGH,
                confidence=ConfidenceLevel.HIGH,
                category=TestCategory.DATA_EXPOSURE,
                owasp=OWASPCategory.API3_EXCESSIVE_DATA_EXPOSURE,
                title=f"Sensitive Data Exposed at {path}",
                description=f"API endpoint exposes sensitive fields: {', '.join(found_sensitive)}",
                endpoint=path,
                method=HTTPMethod.GET,
                evidence=f"Response contains: {', '.join(found_sensitive)}",
                recommendation="Remove sensitive data from API responses. Use data filtering and projection.",
                remediation_steps=["Review API response schema", "Implement field-level access control", "Use DTOs to filter sensitive data"],
            )
            self.findings.append(finding)
    
    async def _test_rest_api(
        self,
        options: ScanOptions,
        api_info: Optional[RESTAPIInfo]
    ):
        """Run REST API security tests."""
        if not api_info or not api_info.endpoints:
            return
        
        for endpoint in api_info.endpoints:
            # BOLA tests
            if options.test_bola:
                results = await self.rest_service.test_bola(
                    endpoint,
                    options.target.base_url,
                    options.target.auth_token,
                )
                self.tests_executed += len(results)
            
            # Mass assignment tests
            if options.test_mass_assignment and endpoint.method in [HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH]:
                result = await self.rest_service.test_mass_assignment(
                    endpoint,
                    options.target.base_url,
                    options.target.auth_token,
                )
                self.tests_executed += 1
        
        self.findings.extend(self.rest_service.findings)
    
    async def _test_graphql(self, options: ScanOptions):
        """Run GraphQL security tests."""
        endpoint_url = options.target.graphql_endpoint or f"{options.target.base_url}/graphql"
        
        # Introspection test
        if options.test_introspection:
            introspection_result = await self.graphql_service.test_introspection(endpoint_url)
            self.tests_executed += 1
        
        # DoS tests
        if options.test_graphql_dos:
            depth_result = await self.graphql_service.test_depth_limit(endpoint_url)
            batch_result = await self.graphql_service.test_batching_attack(endpoint_url)
            alias_result = await self.graphql_service.test_alias_overload(endpoint_url)
            self.tests_executed += 3
        
        self.findings.extend(self.graphql_service.findings)
    
    async def _test_oauth(self, options: ScanOptions):
        """Run OAuth security tests."""
        oauth_config = options.target.oauth_config
        if not oauth_config:
            return
        
        # Redirect URI bypass
        if options.test_redirect_uri and oauth_config.redirect_uris:
            for redirect_uri in oauth_config.redirect_uris:
                result = await self.oauth_service.test_redirect_uri_bypass(
                    oauth_config, redirect_uri
                )
                self.tests_executed += 1
        
        # State parameter
        state_result = await self.oauth_service.test_state_parameter(oauth_config)
        self.tests_executed += 1
        
        # PKCE bypass
        if oauth_config.pkce_required:
            pkce_result = await self.oauth_service.test_pkce_bypass(oauth_config)
            self.tests_executed += 1
        
        # Token leakage
        if options.test_token_leakage:
            leakage_result = await self.oauth_service.test_token_leakage(oauth_config)
            self.tests_executed += 1
        
        self.findings.extend(self.oauth_service.findings)
    
    async def _test_jwt(self, options: ScanOptions):
        """Run JWT security tests."""
        token = options.target.auth_token
        if not token:
            return
        
        # Analyze token (creates findings automatically if endpoint_url provided)
        analysis = self.jwt_service.analyze_token(token, options.target.base_url)
        
        # None algorithm attack
        none_result = await self.jwt_service.test_none_algorithm(
            token, options.target.base_url
        )
        self.tests_executed += 1
        
        # Weak secret
        wordlist = None
        if options.jwt_secret_wordlist:
            # Load wordlist
            pass
        
        secret_result = await self.jwt_service.test_weak_secret(token, wordlist)
        self.tests_executed += 1
        
        self.findings.extend(self.jwt_service.findings)
    
    async def _test_configuration(self, options: ScanOptions):
        """Run configuration security tests."""
        # Rate limiting
        if options.test_rate_limiting:
            for endpoint in self.endpoints:
                rate_result = await self.config_service.test_rate_limiting(
                    endpoint,
                    options.target.base_url,
                )
                self.tests_executed += 1
        
        self.findings.extend(self.config_service.findings)
    
    async def _test_advanced_security(
        self,
        options: ScanOptions,
        api_info: Optional[RESTAPIInfo]
    ):
        """Run advanced API security tests."""
        base_url = options.target.base_url.rstrip('/')
        auth_headers = {}
        if options.target.auth_token:
            auth_headers["Authorization"] = f"Bearer {options.target.auth_token}"
        
        # Test documentation exposure (always test)
        doc_findings = await self.advanced_security_service.test_documentation_exposure(base_url)
        self.tests_executed += 1
        
        # Convert advanced findings to plugin findings
        for adv_finding in doc_findings:
            finding = APISecurityFinding(
                id=str(uuid.uuid4()),
                severity=self._map_severity(adv_finding.severity.value),
                confidence=ConfidenceLevel.MEDIUM,
                category=TestCategory.CONFIGURATION,
                owasp=OWASPCategory.API9_IMPROPER_INVENTORY,
                title=adv_finding.title,
                description=adv_finding.description,
                endpoint=adv_finding.endpoint,
                method=HTTPMethod.GET,
                evidence=adv_finding.evidence or "",
                recommendation=adv_finding.remediation,
                remediation_steps=[adv_finding.remediation],
            )
            self.findings.append(finding)
        
        # Test each endpoint for advanced vulnerabilities
        if api_info and api_info.endpoints:
            for endpoint in api_info.endpoints[:10]:  # Limit to first 10 endpoints
                # API versioning tests
                version_findings = await self.advanced_security_service.test_api_versioning(
                    base_url, endpoint.path
                )
                self.tests_executed += 1
                
                # Rate limiting bypass tests
                rate_findings = await self.advanced_security_service.test_rate_limiting_bypass(
                    base_url, endpoint.path
                )
                self.tests_executed += 1
                
                # Data exposure tests
                data_findings = await self.advanced_security_service.test_data_exposure(
                    base_url, endpoint.path, auth_headers
                )
                self.tests_executed += 1
                
                # Input validation tests (for POST/PUT/PATCH endpoints)
                if endpoint.method in [HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH]:
                    input_findings = await self.advanced_security_service.test_input_validation(
                        base_url, endpoint.path, endpoint.method.value
                    )
                    self.tests_executed += 1
                
                # Convert all findings
                for adv_finding in self.advanced_security_service.findings[-20:]:  # Last 20 findings
                    finding = APISecurityFinding(
                        id=str(uuid.uuid4()),
                        severity=self._map_severity(adv_finding.severity.value),
                        confidence=ConfidenceLevel.MEDIUM,
                        category=self._map_category(adv_finding.category.value),
                        owasp=self._map_owasp(adv_finding.owasp_category),
                        title=adv_finding.title,
                        description=adv_finding.description,
                        endpoint=adv_finding.endpoint,
                        method=HTTPMethod.GET,
                        evidence=adv_finding.evidence or "",
                        recommendation=adv_finding.remediation,
                        remediation_steps=[adv_finding.remediation] if adv_finding.remediation else [],
                    )
                    if finding not in self.findings:
                        self.findings.append(finding)
    
    async def _test_ai_ml_security(self, options: ScanOptions):
        """Test AI/ML API security (prompt injection, model extraction, etc.)"""
        if not self.ai_ml_service:
            return
        
        base_url = options.target.base_url
        
        # Test for AI API endpoints
        ai_endpoints = ['/api/v1/chat', '/api/v1/completions', '/api/v1/embeddings',
                        '/api/generate', '/api/inference', '/v1/chat/completions']
        
        for endpoint in ai_endpoints:
            test_url = f"{base_url.rstrip('/')}{endpoint}"
            try:
                findings = await self.ai_ml_service.test_prompt_injection(test_url)
                self.findings.extend(findings)
                self.tests_executed += 1
            except Exception:
                pass
        
        # Collect service findings
        self.findings.extend(self.ai_ml_service.findings)
    
    async def _test_session_security(self, options: ScanOptions):
        """Test session and cookie security"""
        if not self.session_service:
            return
        
        base_url = options.target.base_url
        
        try:
            findings = await self.session_service.test_session_security(base_url)
            self.findings.extend(findings)
            self.tests_executed += 1
        except Exception:
            pass
        
        # Collect service findings
        self.findings.extend(self.session_service.findings)
    
    async def _test_graphql_federation(self, options: ScanOptions):
        """Test GraphQL federation security"""
        if not self.graphql_federation_service:
            return
        
        base_url = options.target.base_url
        graphql_endpoints = ['/graphql', '/api/graphql', '/v1/graphql']
        
        for endpoint in graphql_endpoints:
            test_url = f"{base_url.rstrip('/')}{endpoint}"
            try:
                findings = await self.graphql_federation_service.test_federation_security(test_url)
                self.findings.extend(findings)
                self.tests_executed += 1
            except Exception:
                pass
        
        # Collect service findings
        self.findings.extend(self.graphql_federation_service.findings)
    
    def _map_severity(self, severity_str: str) -> SeverityLevel:
        """Map severity string to SeverityLevel enum."""
        mapping = {
            "critical": SeverityLevel.CRITICAL,
            "high": SeverityLevel.HIGH,
            "medium": SeverityLevel.MEDIUM,
            "low": SeverityLevel.LOW,
            "info": SeverityLevel.INFO,
        }
        return mapping.get(severity_str.lower(), SeverityLevel.MEDIUM)
    
    def _map_category(self, category_str: str) -> TestCategory:
        """Map category string to TestCategory enum."""
        mapping = {
            "version_confusion": TestCategory.CONFIGURATION,
            "rate_limit_bypass": TestCategory.RATE_LIMITING,
            "waf_bypass": TestCategory.INJECTION,
            "serverless": TestCategory.CONFIGURATION,
            "documentation_exposure": TestCategory.DATA_EXPOSURE,
            "chaining": TestCategory.AUTHORIZATION,
            "authorization_bypass": TestCategory.AUTHORIZATION,
            "data_exposure": TestCategory.DATA_EXPOSURE,
            "input_validation": TestCategory.INJECTION,
        }
        return mapping.get(category_str.lower(), TestCategory.OTHER)
    
    def _map_owasp(self, owasp_str: Optional[str]) -> OWASPCategory:
        """Map OWASP string to OWASPCategory enum."""
        if not owasp_str:
            return OWASPCategory.API8_SECURITY_MISCONFIG
        
        mapping = {
            "API1": OWASPCategory.API1_BOLA,
            "API2": OWASPCategory.API2_BROKEN_AUTH,
            "API3": OWASPCategory.API3_BOPLA,
            "API4": OWASPCategory.API4_UNRESTRICTED_RESOURCE,
            "API5": OWASPCategory.API5_BFLA,
            "API6": OWASPCategory.API6_UNRESTRICTED_SENSITIVE,
            "API7": OWASPCategory.API7_SSRF,
            "API8": OWASPCategory.API8_SECURITY_MISCONFIG,
            "API9": OWASPCategory.API9_IMPROPER_INVENTORY,
            "API10": OWASPCategory.API10_UNSAFE_CONSUMPTION,
        }
        
        for key, value in mapping.items():
            if key in owasp_str:
                return value
        
        return OWASPCategory.API8_SECURITY_MISCONFIG


# =============================================================================
# Utility Functions
# =============================================================================

async def test_api_security(
    base_url: str,
    api_type: APIType = APIType.REST,
    auth_token: Optional[str] = None,
) -> APISecurityScanOutput:
    """
    Convenience function for API security testing.
    
    Args:
        base_url: API base URL
        api_type: Type of API
        auth_token: Authentication token
        
    Returns:
        APISecurityScanOutput
    """
    target = APITarget(
        base_url=base_url,
        api_type=api_type,
        auth_token=auth_token,
    )
    options = ScanOptions(target=target)
    
    plugin = APISecurityTesterPlugin()
    return await plugin.hook_api_security_scan(options)


def analyze_jwt_token(token: str) -> JWTAnalysis:
    """Analyze a JWT token without making requests."""
    from .modules.services.jwt_security_service import JWTSecurityService
    service = JWTSecurityService(None)
    return service.analyze_token(token)


def get_owasp_api_top10() -> List[str]:
    """Get OWASP API Security Top 10 2023 categories."""
    return [c.value for c in OWASPCategory]


def get_test_categories() -> List[str]:
    """Get list of test categories."""
    return [c.value for c in TestCategory]
