"""
Azure Security Assessment Plugin - Pydantic Models

This module defines all data structures used by the Azure Security Assessment Plugin
for detecting and reporting security misconfigurations in Microsoft Azure.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from plugins.reproduction import ReproStep


# =============================================================================
# Enumerations
# =============================================================================

class SeverityLevel(str, Enum):
    """Severity classification for security findings."""
    CRITICAL = "critical"  # Public data exposure, privilege escalation, active threats
    HIGH = "high"          # Missing encryption, broad access, disabled logging
    MEDIUM = "medium"      # Missing best practices, potential risks
    LOW = "low"            # Informational, optimization opportunities
    INFO = "info"          # Non-security findings, baseline information


class AzureResourceType(str, Enum):
    """Azure resource types covered by assessment."""
    # Azure AD / Entra ID
    AAD_USER = "aad_user"
    AAD_GROUP = "aad_group"
    AAD_APPLICATION = "aad_application"
    AAD_SERVICE_PRINCIPAL = "aad_service_principal"
    AAD_ROLE_DEFINITION = "aad_role_definition"
    AAD_ROLE_ASSIGNMENT = "aad_role_assignment"
    AAD_CONDITIONAL_ACCESS = "aad_conditional_access"
    AAD_NAMED_LOCATION = "aad_named_location"
    AAD_DIRECTORY_ROLE = "aad_directory_role"
    
    # Management & Governance
    MANAGEMENT_GROUP = "management_group"
    SUBSCRIPTION = "subscription"
    RESOURCE_GROUP = "resource_group"
    POLICY_DEFINITION = "policy_definition"
    POLICY_ASSIGNMENT = "policy_assignment"
    BLUEPRINT = "blueprint"
    RESOURCE_LOCK = "resource_lock"
    
    # Compute
    VIRTUAL_MACHINE = "virtual_machine"
    VMSS = "virtual_machine_scale_set"
    AVAILABILITY_SET = "availability_set"
    DISK = "disk"
    SNAPSHOT = "snapshot"
    IMAGE = "image"
    VM_EXTENSION = "vm_extension"
    
    # Networking
    VIRTUAL_NETWORK = "virtual_network"
    SUBNET = "subnet"
    NSG = "network_security_group"
    NSG_RULE = "nsg_rule"
    PUBLIC_IP = "public_ip"
    LOAD_BALANCER = "load_balancer"
    APPLICATION_GATEWAY = "application_gateway"
    AZURE_FIREWALL = "azure_firewall"
    FRONT_DOOR = "front_door"
    VPN_GATEWAY = "vpn_gateway"
    EXPRESS_ROUTE = "express_route"
    PRIVATE_ENDPOINT = "private_endpoint"
    PRIVATE_DNS_ZONE = "private_dns_zone"
    NETWORK_WATCHER = "network_watcher"
    BASTION = "bastion"
    NAT_GATEWAY = "nat_gateway"
    ROUTE_TABLE = "route_table"
    
    # Storage
    STORAGE_ACCOUNT = "storage_account"
    BLOB_CONTAINER = "blob_container"
    FILE_SHARE = "file_share"
    QUEUE = "queue"
    TABLE = "table"
    DATA_LAKE_STORE = "data_lake_store"
    
    # Databases
    SQL_SERVER = "sql_server"
    SQL_DATABASE = "sql_database"
    SQL_MANAGED_INSTANCE = "sql_managed_instance"
    COSMOS_DB_ACCOUNT = "cosmos_db_account"
    MYSQL_SERVER = "mysql_server"
    POSTGRESQL_SERVER = "postgresql_server"
    MARIADB_SERVER = "mariadb_server"
    REDIS_CACHE = "redis_cache"
    SYNAPSE_WORKSPACE = "synapse_workspace"
    
    # Containers
    AKS_CLUSTER = "aks_cluster"
    AKS_NODE_POOL = "aks_node_pool"
    CONTAINER_REGISTRY = "container_registry"
    CONTAINER_INSTANCE = "container_instance"
    CONTAINER_APP = "container_app"
    
    # Serverless
    FUNCTION_APP = "function_app"
    APP_SERVICE = "app_service"
    APP_SERVICE_PLAN = "app_service_plan"
    LOGIC_APP = "logic_app"
    API_MANAGEMENT = "api_management"
    
    # Security
    KEY_VAULT = "key_vault"
    KEY_VAULT_SECRET = "key_vault_secret"
    KEY_VAULT_KEY = "key_vault_key"
    KEY_VAULT_CERTIFICATE = "key_vault_certificate"
    MANAGED_IDENTITY = "managed_identity"
    
    # Monitoring
    LOG_ANALYTICS_WORKSPACE = "log_analytics_workspace"
    APPLICATION_INSIGHTS = "application_insights"
    DIAGNOSTIC_SETTING = "diagnostic_setting"
    ACTION_GROUP = "action_group"
    ALERT_RULE = "alert_rule"
    
    # Security Center
    DEFENDER_PLAN = "defender_plan"
    SECURITY_CONTACT = "security_contact"
    AUTO_PROVISIONING = "auto_provisioning"
    
    # Messaging
    SERVICE_BUS_NAMESPACE = "service_bus_namespace"
    EVENT_HUB_NAMESPACE = "event_hub_namespace"
    EVENT_GRID_TOPIC = "event_grid_topic"
    NOTIFICATION_HUB = "notification_hub"
    
    # Integration
    DATA_FACTORY = "data_factory"
    AUTOMATION_ACCOUNT = "automation_account"
    RUNBOOK = "runbook"
    
    # DevOps
    DEVOPS_ORGANIZATION = "devops_organization"
    DEVOPS_PROJECT = "devops_project"
    DEVOPS_PIPELINE = "devops_pipeline"
    DEVOPS_SERVICE_CONNECTION = "devops_service_connection"
    
    # Other
    COGNITIVE_SERVICES = "cognitive_services"
    MACHINE_LEARNING_WORKSPACE = "machine_learning_workspace"
    SEARCH_SERVICE = "search_service"
    UNKNOWN = "unknown"


class SecurityCategory(str, Enum):
    """
    Security assessment categories aligned with MITRE ATT&CK Cloud Matrix.
    """
    # MITRE ATT&CK Tactics
    INITIAL_ACCESS = "initial_access"
    EXECUTION = "execution"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DEFENSE_EVASION = "defense_evasion"
    CREDENTIAL_ACCESS = "credential_access"
    DISCOVERY = "discovery"
    LATERAL_MOVEMENT = "lateral_movement"
    COLLECTION = "collection"
    EXFILTRATION = "exfiltration"
    IMPACT = "impact"
    
    # Azure-Specific Categories
    IDENTITY_MISCONFIGURATION = "identity_misconfiguration"
    NETWORK_EXPOSURE = "network_exposure"
    DATA_EXPOSURE = "data_exposure"
    ENCRYPTION_WEAKNESS = "encryption_weakness"
    LOGGING_GAP = "logging_gap"
    COMPLIANCE_VIOLATION = "compliance_violation"
    CONFIGURATION_DRIFT = "configuration_drift"
    RESOURCE_EXPOSURE = "resource_exposure"


class SecuritySubCategory(str, Enum):
    """Specific security issue sub-categories."""
    # Azure AD Issues
    GLOBAL_ADMIN_NO_MFA = "global_admin_no_mfa"
    USER_NO_MFA = "user_no_mfa"
    LEGACY_AUTH_ENABLED = "legacy_auth_enabled"
    GUEST_ELEVATED_ACCESS = "guest_elevated_access"
    STALE_USER_ACCOUNT = "stale_user_account"
    PERMANENT_ADMIN_ROLE = "permanent_admin_role"
    SERVICE_PRINCIPAL_ADMIN = "service_principal_admin"
    APP_EXCESSIVE_PERMISSIONS = "app_excessive_permissions"
    OLD_APP_SECRET = "old_app_secret"
    NO_CONDITIONAL_ACCESS = "no_conditional_access"
    PRIVILEGE_ESCALATION_PATH = "privilege_escalation_path"
    
    # VM Issues
    PUBLIC_VM = "public_vm"
    VM_NO_ENCRYPTION = "vm_no_encryption"
    NSG_OPEN = "nsg_open"
    MANAGED_IDENTITY_ABUSE = "managed_identity_abuse"
    JIT_DISABLED = "jit_disabled"
    VM_EXTENSION_SECRETS = "vm_extension_secrets"
    
    # Storage Issues
    PUBLIC_BLOB = "public_blob"
    STORAGE_NO_HTTPS = "storage_no_https"
    STORAGE_FIREWALL_DISABLED = "storage_firewall_disabled"
    SHARED_KEY_AUTH = "shared_key_auth"
    STORAGE_NO_ENCRYPTION = "storage_no_encryption"
    SAS_TOKEN_LONG_EXPIRY = "sas_token_long_expiry"
    
    # Database Issues
    PUBLIC_DATABASE = "public_database"
    DATABASE_NO_TDE = "database_no_tde"
    DATABASE_NO_AUDITING = "database_no_auditing"
    DATABASE_ALLOW_AZURE = "database_allow_azure"
    SQL_AUTH_ONLY = "sql_auth_only"
    
    # Network Issues
    NSG_ANY_ANY = "nsg_any_any"
    NSG_SSH_RDP_OPEN = "nsg_ssh_rdp_open"
    NO_WAF = "no_waf"
    NO_DDOS_PROTECTION = "no_ddos_protection"
    NSG_FLOW_LOGS_DISABLED = "nsg_flow_logs_disabled"
    
    # AKS Issues
    AKS_PUBLIC_API = "aks_public_api"
    AKS_LOCAL_ACCOUNTS = "aks_local_accounts"
    AKS_NO_AZURE_AD = "aks_no_azure_ad"
    PRIVILEGED_POD = "privileged_pod"
    HOST_NAMESPACE = "host_namespace"
    AKS_NO_NETWORK_POLICY = "aks_no_network_policy"
    
    # App Service Issues
    APP_NO_HTTPS = "app_no_https"
    APP_REMOTE_DEBUG = "app_remote_debug"
    APP_FTP_ENABLED = "app_ftp_enabled"
    APP_NO_AUTH = "app_no_auth"
    APP_SECRETS_IN_CONFIG = "app_secrets_in_config"
    
    # Key Vault Issues
    KEYVAULT_PUBLIC = "keyvault_public"
    KEYVAULT_NO_SOFT_DELETE = "keyvault_no_soft_delete"
    SECRET_NO_EXPIRY = "secret_no_expiry"
    KEYVAULT_BROAD_ACCESS = "keyvault_broad_access"
    
    # Logging Issues
    DEFENDER_DISABLED = "defender_disabled"
    ACTIVITY_LOG_NOT_EXPORTED = "activity_log_not_exported"
    DIAGNOSTIC_LOGS_DISABLED = "diagnostic_logs_disabled"
    NO_SECURITY_ALERTS = "no_security_alerts"
    SENTINEL_NOT_DEPLOYED = "sentinel_not_deployed"
    
    # Governance Issues
    NO_AZURE_POLICY = "no_azure_policy"
    OWNER_TOO_MANY = "owner_too_many"
    CLASSIC_ADMIN = "classic_admin"
    NO_RESOURCE_LOCKS = "no_resource_locks"
    
    # Persistence
    AUTOMATION_RUNBOOK = "automation_runbook"
    LOGIC_APP_TRIGGER = "logic_app_trigger"
    FUNCTION_TIMER = "function_timer"
    APP_REGISTRATION = "app_registration"
    
    # Exfiltration
    DATA_TRANSFER_RISK = "data_transfer_risk"
    CROSS_TENANT_ACCESS = "cross_tenant_access"
    EXTERNAL_SHARING = "external_sharing"


class FindingStatus(str, Enum):
    """Status of security finding."""
    ACTIVE = "active"
    SUPPRESSED = "suppressed"
    REMEDIATED = "remediated"
    FALSE_POSITIVE = "false_positive"
    EXCEPTION = "exception"


class ComplianceFramework(str, Enum):
    """Compliance frameworks for mapping findings."""
    CIS_AZURE = "cis_azure"
    AZURE_SECURITY_BENCHMARK = "azure_security_benchmark"
    NIST_800_53 = "nist_800_53"
    NIST_CSF = "nist_csf"
    SOC2 = "soc2"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    GDPR = "gdpr"
    ISO_27001 = "iso_27001"
    FedRAMP = "fedramp"


class AzureRegion(str, Enum):
    """Azure regions."""
    EAST_US = "eastus"
    EAST_US_2 = "eastus2"
    WEST_US = "westus"
    WEST_US_2 = "westus2"
    WEST_US_3 = "westus3"
    CENTRAL_US = "centralus"
    NORTH_CENTRAL_US = "northcentralus"
    SOUTH_CENTRAL_US = "southcentralus"
    WEST_CENTRAL_US = "westcentralus"
    NORTH_EUROPE = "northeurope"
    WEST_EUROPE = "westeurope"
    UK_SOUTH = "uksouth"
    UK_WEST = "ukwest"
    FRANCE_CENTRAL = "francecentral"
    GERMANY_WEST_CENTRAL = "germanywestcentral"
    SWITZERLAND_NORTH = "switzerlandnorth"
    NORWAY_EAST = "norwayeast"
    SWEDEN_CENTRAL = "swedencentral"
    EAST_ASIA = "eastasia"
    SOUTHEAST_ASIA = "southeastasia"
    JAPAN_EAST = "japaneast"
    JAPAN_WEST = "japanwest"
    AUSTRALIA_EAST = "australiaeast"
    AUSTRALIA_SOUTHEAST = "australiasoutheast"
    KOREA_CENTRAL = "koreacentral"
    INDIA_CENTRAL = "centralindia"
    BRAZIL_SOUTH = "brazilsouth"
    SOUTH_AFRICA_NORTH = "southafricanorth"
    UAE_NORTH = "uaenorth"
    CANADA_CENTRAL = "canadacentral"
    CANADA_EAST = "canadaeast"
    GLOBAL = "global"


# =============================================================================
# Supporting Models
# =============================================================================

class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute.
    """
    server: Optional[str] = Field(None, description="Target server/hostname/resource")
    ip: Optional[str] = Field(None, description="Target IP address or Azure endpoint")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class MitreAttackReference(BaseModel):
    """MITRE ATT&CK Cloud Matrix reference."""
    tactic: str = Field(..., description="ATT&CK tactic (e.g., 'Persistence')")
    technique_id: str = Field(..., description="Technique ID (e.g., 'T1078')")
    technique_name: str = Field(..., description="Technique name")
    sub_technique_id: Optional[str] = Field(None, description="Sub-technique ID")
    sub_technique_name: Optional[str] = Field(None, description="Sub-technique name")
    url: Optional[str] = Field(None, description="Link to ATT&CK page")


class ComplianceMapping(BaseModel):
    """Compliance framework mapping for a finding."""
    framework: ComplianceFramework = Field(..., description="Compliance framework")
    control_id: str = Field(..., description="Control ID (e.g., 'CIS 1.1')")
    control_name: str = Field(..., description="Control name/description")
    requirement: Optional[str] = Field(None, description="Specific requirement")


class AzureResourceIdentifier(BaseModel):
    """Unique identifier for an Azure resource."""
    resource_type: AzureResourceType = Field(..., description="Resource type")
    subscription_id: Optional[str] = Field(None, description="Azure subscription ID")
    resource_group: Optional[str] = Field(None, description="Resource group name")
    resource_id: Optional[str] = Field(None, description="Full resource ID")
    name: Optional[str] = Field(None, description="Resource name")
    location: Optional[str] = Field(None, description="Azure region")
    
    # Tenant context
    tenant_id: Optional[str] = Field(None, description="Azure AD tenant ID")
    
    # Management group context
    management_group_id: Optional[str] = Field(None, description="Management group ID")
    
    # Additional context
    tags: Optional[Dict[str, str]] = Field(None, description="Resource tags")
    creation_time: Optional[datetime] = Field(None, description="Resource creation time")


class AzureADUserInfo(BaseModel):
    """Azure AD user details for analysis."""
    user_principal_name: str = Field(..., description="User principal name (UPN)")
    object_id: str = Field(..., description="Azure AD object ID")
    display_name: Optional[str] = Field(None, description="Display name")
    user_type: str = Field("Member", description="Member or Guest")
    
    # Authentication
    mfa_enabled: bool = Field(False, description="MFA is enabled")
    mfa_methods: Optional[List[str]] = Field(None, description="MFA methods configured")
    password_policies: Optional[str] = Field(None, description="Password policies")
    
    # Status
    account_enabled: bool = Field(True, description="Account is enabled")
    last_sign_in: Optional[datetime] = Field(None, description="Last sign-in time")
    created_datetime: Optional[datetime] = Field(None, description="Account creation time")
    
    # Roles
    directory_roles: Optional[List[str]] = Field(None, description="Azure AD roles")
    azure_roles: Optional[List[str]] = Field(None, description="Azure RBAC roles")
    is_global_admin: bool = Field(False, description="Has Global Administrator role")
    is_privileged: bool = Field(False, description="Has any privileged role")
    
    # Risk
    risk_level: Optional[str] = Field(None, description="User risk level")
    risk_state: Optional[str] = Field(None, description="User risk state")


class ServicePrincipalInfo(BaseModel):
    """Service principal details for analysis."""
    app_id: str = Field(..., description="Application (client) ID")
    object_id: str = Field(..., description="Service principal object ID")
    display_name: Optional[str] = Field(None, description="Display name")
    service_principal_type: str = Field(..., description="Application or ManagedIdentity")
    
    # Credentials
    has_password_credentials: bool = Field(False, description="Has password secrets")
    has_key_credentials: bool = Field(False, description="Has certificate credentials")
    credential_count: int = Field(0, description="Number of credentials")
    oldest_credential_age_days: Optional[int] = Field(None, description="Age of oldest credential")
    
    # Permissions
    app_roles: Optional[List[str]] = Field(None, description="Assigned app roles")
    oauth2_permissions: Optional[List[str]] = Field(None, description="Delegated permissions")
    directory_roles: Optional[List[str]] = Field(None, description="Azure AD roles")
    azure_roles: Optional[List[str]] = Field(None, description="Azure RBAC roles")
    
    # Risk assessment
    is_privileged: bool = Field(False, description="Has privileged permissions")
    has_dangerous_permissions: bool = Field(False, description="Has dangerous API permissions")
    dangerous_permissions: Optional[List[str]] = Field(None, description="List of dangerous permissions")
    
    # Multi-tenant
    is_multi_tenant: bool = Field(False, description="Multi-tenant application")


class NSGRuleInfo(BaseModel):
    """Network Security Group rule details."""
    name: str = Field(..., description="Rule name")
    priority: int = Field(..., description="Rule priority")
    direction: str = Field(..., description="Inbound or Outbound")
    access: str = Field(..., description="Allow or Deny")
    protocol: str = Field(..., description="Protocol (TCP, UDP, *)")
    source_address_prefix: Optional[str] = Field(None, description="Source address prefix")
    source_address_prefixes: Optional[List[str]] = Field(None, description="Source address prefixes")
    destination_address_prefix: Optional[str] = Field(None, description="Destination address prefix")
    destination_address_prefixes: Optional[List[str]] = Field(None, description="Destination address prefixes")
    source_port_range: Optional[str] = Field(None, description="Source port range")
    destination_port_range: Optional[str] = Field(None, description="Destination port range")
    destination_port_ranges: Optional[List[str]] = Field(None, description="Destination port ranges")
    
    # Analysis
    allows_any_source: bool = Field(False, description="Allows from any source (*/0.0.0.0/0)")
    allows_any_destination: bool = Field(False, description="Allows to any destination")
    is_management_port: bool = Field(False, description="SSH/RDP/management port")


class NSGInfo(BaseModel):
    """Network Security Group details for analysis."""
    nsg_id: str = Field(..., description="NSG resource ID")
    nsg_name: str = Field(..., description="NSG name")
    resource_group: str = Field(..., description="Resource group")
    location: str = Field(..., description="Azure region")
    
    # Association
    associated_subnets: Optional[List[str]] = Field(None, description="Associated subnet IDs")
    associated_nics: Optional[List[str]] = Field(None, description="Associated NIC IDs")
    is_associated: bool = Field(False, description="Is associated with any resource")
    
    # Rules analysis
    allows_ssh_from_internet: bool = Field(False, description="SSH from Internet")
    allows_rdp_from_internet: bool = Field(False, description="RDP from Internet")
    allows_any_from_internet: bool = Field(False, description="All traffic from Internet")
    open_management_ports: Optional[List[int]] = Field(None, description="Open management ports")
    
    # Flow logs
    flow_logs_enabled: bool = Field(False, description="NSG flow logs enabled")
    
    # Rules
    security_rules: Optional[List[NSGRuleInfo]] = Field(None, description="Security rules")


class StorageAccountInfo(BaseModel):
    """Storage account details for analysis."""
    storage_account_id: str = Field(..., description="Storage account resource ID")
    storage_account_name: str = Field(..., description="Storage account name")
    resource_group: str = Field(..., description="Resource group")
    location: str = Field(..., description="Azure region")
    
    # Access settings
    allow_blob_public_access: bool = Field(False, description="Anonymous blob access allowed")
    allow_shared_key_access: bool = Field(True, description="Shared key access allowed")
    public_network_access: str = Field("Enabled", description="Public network access status")
    default_action: str = Field("Allow", description="Network default action")
    
    # Encryption
    https_only: bool = Field(True, description="HTTPS traffic only")
    min_tls_version: str = Field("TLS1_2", description="Minimum TLS version")
    infrastructure_encryption: bool = Field(False, description="Infrastructure encryption")
    encryption_key_source: str = Field("Microsoft.Storage", description="Encryption key source")
    
    # Data protection
    soft_delete_blob_enabled: bool = Field(False, description="Blob soft delete enabled")
    soft_delete_container_enabled: bool = Field(False, description="Container soft delete enabled")
    versioning_enabled: bool = Field(False, description="Blob versioning enabled")
    
    # Containers
    public_containers: Optional[List[str]] = Field(None, description="Public container names")
    
    # Private endpoints
    has_private_endpoints: bool = Field(False, description="Has private endpoints")


class KeyVaultInfo(BaseModel):
    """Key Vault details for analysis."""
    keyvault_id: str = Field(..., description="Key Vault resource ID")
    keyvault_name: str = Field(..., description="Key Vault name")
    resource_group: str = Field(..., description="Resource group")
    location: str = Field(..., description="Azure region")
    
    # Network
    public_network_access: str = Field("Enabled", description="Public network access")
    default_action: str = Field("Allow", description="Network default action")
    has_private_endpoints: bool = Field(False, description="Has private endpoints")
    
    # Recovery
    soft_delete_enabled: bool = Field(True, description="Soft delete enabled")
    purge_protection_enabled: bool = Field(False, description="Purge protection enabled")
    soft_delete_retention_days: int = Field(90, description="Soft delete retention days")
    
    # Access
    enable_rbac_authorization: bool = Field(False, description="RBAC authorization enabled")
    
    # Diagnostics
    diagnostic_logs_enabled: bool = Field(False, description="Diagnostic logs enabled")
    
    # Content
    secrets_without_expiry: Optional[int] = Field(None, description="Secrets without expiration")
    keys_without_rotation: Optional[int] = Field(None, description="Keys without rotation policy")
    expiring_certificates: Optional[int] = Field(None, description="Certificates expiring soon")


class PrivilegeEscalationPath(BaseModel):
    """Detected privilege escalation path."""
    source_identity: str = Field(..., description="Starting identity (user/SP)")
    source_type: str = Field(..., description="Type: User, ServicePrincipal, Group")
    target_identity: str = Field(..., description="Target identity to escalate to")
    target_type: str = Field(..., description="Type of target")
    escalation_method: str = Field(..., description="Method of escalation")
    required_permissions: List[str] = Field(default_factory=list, description="Permissions needed")
    steps: List[str] = Field(default_factory=list, description="Step-by-step path")
    impact: str = Field(..., description="Impact if exploited")
    scope: str = Field(..., description="Scope: Tenant, Subscription, ResourceGroup")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence score")


class ExfiltrationPath(BaseModel):
    """Detected data exfiltration path."""
    source_resource: str = Field(..., description="Source resource with data")
    source_resource_id: Optional[str] = Field(None, description="Source resource ID")
    destination: str = Field(..., description="Potential destination")
    destination_tenant: Optional[str] = Field(None, description="External tenant ID")
    method: str = Field(..., description="Exfiltration method")
    data_type: Optional[str] = Field(None, description="Type of data at risk")
    permissions_required: List[str] = Field(default_factory=list, description="Permissions needed")
    mitigations: Optional[List[str]] = Field(None, description="Recommended mitigations")


class PersistenceMechanism(BaseModel):
    """Detected or potential persistence mechanism."""
    mechanism_type: str = Field(..., description="Type of persistence")
    resource_id: str = Field(..., description="Resource ID used for persistence")
    resource_name: Optional[str] = Field(None, description="Resource name")
    execution_trigger: str = Field(..., description="What triggers execution")
    identity_used: Optional[str] = Field(None, description="Identity used for execution")
    schedule: Optional[str] = Field(None, description="Schedule if applicable")
    target: Optional[str] = Field(None, description="Target of execution")
    detected_payload: Optional[str] = Field(None, description="Suspicious payload if found")
    is_suspicious: bool = Field(False, description="Whether appears malicious")
    legitimate_use_case: Optional[str] = Field(None, description="Potential legitimate use")


class IoC(BaseModel):
    """Indicator of Compromise extracted from finding."""
    ioc_type: str = Field(..., description="Type: ip, domain, url, email, hash, app_id")
    value: str = Field(..., description="IoC value")
    context: Optional[str] = Field(None, description="Context where found")
    first_seen: Optional[datetime] = Field(None, description="First observed")
    last_seen: Optional[datetime] = Field(None, description="Last observed")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence 0-1")


class VMInfo(BaseModel):
    """Virtual Machine details for analysis."""
    vm_id: str = Field(..., description="VM resource ID")
    vm_name: str = Field(..., description="VM name")
    resource_group: str = Field(..., description="Resource group")
    location: str = Field(..., description="Azure region")
    vm_size: str = Field(..., description="VM size/SKU")
    
    # Network
    has_public_ip: bool = Field(False, description="Has public IP address")
    public_ip_address: Optional[str] = Field(None, description="Public IP if assigned")
    private_ip_address: Optional[str] = Field(None, description="Private IP address")
    nsg_ids: Optional[List[str]] = Field(None, description="Associated NSG IDs")
    
    # Identity
    system_assigned_identity: bool = Field(False, description="System-assigned managed identity")
    user_assigned_identities: Optional[List[str]] = Field(None, description="User-assigned identity IDs")
    identity_roles: Optional[List[str]] = Field(None, description="RBAC roles of managed identity")
    
    # Security
    os_disk_encrypted: bool = Field(False, description="OS disk encrypted")
    data_disks_encrypted: bool = Field(False, description="All data disks encrypted")
    jit_access_enabled: bool = Field(False, description="JIT access enabled")
    endpoint_protection: Optional[str] = Field(None, description="Endpoint protection status")
    
    # Extensions
    extensions: Optional[List[str]] = Field(None, description="Installed extensions")
    
    # State
    power_state: str = Field(..., description="VM power state")


class ConditionalAccessPolicy(BaseModel):
    """Conditional Access policy details."""
    policy_id: str = Field(..., description="Policy ID")
    display_name: str = Field(..., description="Policy display name")
    state: str = Field(..., description="enabled, disabled, enabledForReportingButNotEnforced")
    
    # Conditions
    include_users: Optional[List[str]] = Field(None, description="Included users/groups")
    exclude_users: Optional[List[str]] = Field(None, description="Excluded users/groups")
    include_applications: Optional[List[str]] = Field(None, description="Included applications")
    include_locations: Optional[List[str]] = Field(None, description="Included locations")
    include_platforms: Optional[List[str]] = Field(None, description="Included platforms")
    
    # Grant controls
    require_mfa: bool = Field(False, description="Requires MFA")
    require_compliant_device: bool = Field(False, description="Requires compliant device")
    require_hybrid_azure_ad_joined: bool = Field(False, description="Requires hybrid Azure AD join")
    block_access: bool = Field(False, description="Blocks access")
    
    # Analysis
    has_all_users_exclusion: bool = Field(False, description="Has exclusion from All Users")
    targets_privileged_roles: bool = Field(False, description="Targets privileged roles")


# =============================================================================
# Core Finding Models
# =============================================================================

class SecurityFinding(BaseModel):
    """
    Detailed information about a detected security issue.
    This is the primary finding object returned by security checks.
    """
    # Identification
    id: str = Field(..., description="Unique finding ID (UUID)")
    name: str = Field(..., description="Human-readable name")
    description: str = Field(..., description="Detailed description")
    
    # Classification
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific sub-category")
    severity: SeverityLevel = Field(..., description="Severity level")
    status: FindingStatus = Field(FindingStatus.ACTIVE, description="Finding status")
    
    # Resource
    resource: AzureResourceIdentifier = Field(..., description="Affected resource")
    resource_config: Optional[Dict[str, Any]] = Field(None, description="Relevant config excerpt")
    
    # Framework mappings
    mitre_attack: Optional[MitreAttackReference] = Field(None, description="MITRE ATT&CK reference")
    compliance_mappings: Optional[List[ComplianceMapping]] = Field(None, description="Compliance mappings")
    
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Explicit Azure CLI commands for exploitation/verification"
    )
    
    # Evidence
    evidence: Optional[Dict[str, Any]] = Field(None, description="Evidence supporting finding")
    affected_users: Optional[List[AzureADUserInfo]] = Field(None, description="Affected Azure AD users")
    affected_service_principals: Optional[List[ServicePrincipalInfo]] = Field(None, description="Affected SPs")
    affected_nsgs: Optional[List[NSGInfo]] = Field(None, description="Affected NSGs")
    affected_storage_accounts: Optional[List[StorageAccountInfo]] = Field(None, description="Affected storage")
    affected_key_vaults: Optional[List[KeyVaultInfo]] = Field(None, description="Affected Key Vaults")
    affected_vms: Optional[List[VMInfo]] = Field(None, description="Affected VMs")
    affected_conditional_access: Optional[List[ConditionalAccessPolicy]] = Field(None, description="Affected CA policies")
    
    # Attack paths
    privilege_escalation_paths: Optional[List[PrivilegeEscalationPath]] = Field(None, description="Privesc paths")
    exfiltration_paths: Optional[List[ExfiltrationPath]] = Field(None, description="Exfil paths")
    persistence_mechanisms: Optional[List[PersistenceMechanism]] = Field(None, description="Persistence")
    
    # IoCs
    iocs: Optional[List[IoC]] = Field(None, description="Extracted IoCs")
    
    # Analysis
    risk_score: float = Field(0.0, ge=0.0, le=10.0, description="Risk score 0-10")
    exploitability: Optional[str] = Field(None, description="Exploitability: easy/medium/hard")
    impact_scope: Optional[str] = Field(None, description="Scope: resource/subscription/tenant")
    false_positive_likelihood: Optional[str] = Field(None, description="FP likelihood: low/medium/high")
    
    # Remediation
    recommendation: str = Field(..., description="What should be done")
    remediation_steps: Optional[List[str]] = Field(None, description="Step-by-step remediation")
    remediation_commands: Optional[List[str]] = Field(None, description="Azure CLI/PowerShell commands")
    remediation_arm_template: Optional[str] = Field(None, description="ARM template fix")
    remediation_terraform: Optional[str] = Field(None, description="Terraform fix")
    remediation_effort: Optional[str] = Field(None, description="Effort: low/medium/high")
    requires_downtime: bool = Field(False, description="Whether fix requires downtime")
    
    # Metadata
    detected_at: datetime = Field(default_factory=datetime.utcnow, description="Detection time")
    detection_method: Optional[str] = Field(None, description="How this was detected")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Detection confidence 0-1")
    
    # Suppression
    is_suppressed: bool = Field(False, description="Whether suppressed")
    suppression_reason: Optional[str] = Field(None, description="Reason for suppression")
    exception_until: Optional[datetime] = Field(None, description="Exception expiry date")
    
    # Additional context
    tags: Optional[List[str]] = Field(None, description="Finding tags")
    related_findings: Optional[List[str]] = Field(None, description="Related finding IDs")
    references: Optional[List[str]] = Field(None, description="External references")
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this finding"
    )
    defender_recommendation_id: Optional[str] = Field(None, description="Related Defender recommendation")
    raw_data: Optional[Dict[str, Any]] = Field(None, description="Raw API response data")


class CheckResult(BaseModel):
    """Result of a security check."""
    check_id: str = Field(..., description="Check identifier")
    check_name: str = Field(..., description="Human-readable check name")
    category: SecurityCategory = Field(..., description="Security category")
    sub_category: SecuritySubCategory = Field(..., description="Specific type")
    
    # Status
    passed: bool = Field(..., description="Whether check passed (no issues)")
    findings_count: int = Field(0, description="Number of findings")
    
    # Results
    findings: List[SecurityFinding] = Field(default_factory=list, description="Findings from this check")
    
    # Scope
    resources_checked: int = Field(0, description="Number of resources checked")
    resources_with_issues: int = Field(0, description="Resources with issues")
    subscriptions_checked: Optional[List[str]] = Field(None, description="Subscriptions checked")
    
    # Performance
    duration_ms: Optional[float] = Field(None, description="Check duration in ms")
    api_calls_made: Optional[int] = Field(None, description="Number of API calls")
    
    # Errors
    error: Optional[str] = Field(None, description="Error message if check failed")
    error_details: Optional[str] = Field(None, description="Detailed error info")
    skipped: bool = Field(False, description="Whether check was skipped")
    skipped_reason: Optional[str] = Field(None, description="Skip reason")


# =============================================================================
# Scan Configuration
# =============================================================================

class ScanScope(BaseModel):
    """Scope of the security assessment."""
    # Tenant scope
    tenant_id: Optional[str] = Field(None, description="Azure AD tenant ID")
    include_azure_ad: bool = Field(True, description="Include Azure AD analysis")
    
    # Management group scope
    management_group_ids: Optional[List[str]] = Field(None, description="Management group IDs")
    
    # Subscription scope
    subscription_ids: Optional[List[str]] = Field(None, description="Subscription IDs to scan")
    exclude_subscription_ids: Optional[List[str]] = Field(None, description="Subscriptions to exclude")
    
    # Resource group scope
    resource_group_names: Optional[List[str]] = Field(None, description="Specific resource groups")
    
    # Resource scope
    resource_types: Optional[List[AzureResourceType]] = Field(None, description="Resource types to scan")
    exclude_resource_types: Optional[List[AzureResourceType]] = Field(None, description="Types to exclude")
    
    # Region scope
    locations: Optional[List[str]] = Field(None, description="Locations to scan")
    exclude_locations: Optional[List[str]] = Field(None, description="Locations to exclude")


class ScanOptions(BaseModel):
    """Configuration options for security scan."""
    # Scope
    scope: ScanScope = Field(default_factory=ScanScope, description="Scan scope")
    
    # Category selection
    categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to scan")
    exclude_categories: Optional[List[SecurityCategory]] = Field(None, description="Categories to exclude")
    
    # Severity filtering
    min_severity: SeverityLevel = Field(SeverityLevel.INFO, description="Minimum severity")
    
    # Scan depth
    deep_scan: bool = Field(False, description="Enable deep/thorough scanning")
    quick_scan: bool = Field(False, description="Quick scan (critical only)")
    
    # Analysis features
    analyze_azure_ad: bool = Field(True, description="Analyze Azure AD/Entra ID")
    analyze_privilege_escalation: bool = Field(True, description="Find privesc paths")
    analyze_exfiltration_paths: bool = Field(True, description="Find exfil paths")
    analyze_persistence: bool = Field(True, description="Find persistence mechanisms")
    analyze_compliance: bool = Field(True, description="Map to compliance frameworks")
    
    # Compliance frameworks
    compliance_frameworks: Optional[List[ComplianceFramework]] = Field(
        None, description="Frameworks to map findings to"
    )
    
    # Performance
    max_workers: int = Field(10, description="Maximum parallel workers")
    timeout_per_check: int = Field(120, description="Timeout per check in seconds")
    max_findings: int = Field(5000, description="Maximum findings to return")
    max_api_calls_per_second: int = Field(10, description="API rate limit")
    
    # Output options
    include_raw_data: bool = Field(False, description="Include raw API responses")
    include_passing_checks: bool = Field(False, description="Include checks with no findings")
    
    # Baseline comparison
    baseline_path: Optional[str] = Field(None, description="Path to baseline for comparison")
    suppress_baseline_findings: bool = Field(False, description="Suppress known findings")


# =============================================================================
# Output Models
# =============================================================================

class SeveritySummary(BaseModel):
    """Summary counts by severity level."""
    critical: int = Field(0, description="Critical severity count")
    high: int = Field(0, description="High severity count")
    medium: int = Field(0, description="Medium severity count")
    low: int = Field(0, description="Low severity count")
    info: int = Field(0, description="Info count")
    total: int = Field(0, description="Total findings")


class CategorySummary(BaseModel):
    """Summary counts by category."""
    category: SecurityCategory = Field(..., description="Category")
    category_name: str = Field(..., description="Category display name")
    total_count: int = Field(0, description="Total findings in category")
    critical_count: int = Field(0, description="Critical findings")
    high_count: int = Field(0, description="High findings")
    top_issues: Optional[List[str]] = Field(None, description="Top issue types")


class ResourceTypeSummary(BaseModel):
    """Summary by resource type."""
    resource_type: AzureResourceType = Field(..., description="Resource type")
    total_resources: int = Field(0, description="Total resources scanned")
    resources_with_issues: int = Field(0, description="Resources with findings")
    total_findings: int = Field(0, description="Total findings")
    critical_findings: int = Field(0, description="Critical findings")


class SubscriptionSummary(BaseModel):
    """Summary per Azure subscription."""
    subscription_id: str = Field(..., description="Azure subscription ID")
    subscription_name: Optional[str] = Field(None, description="Subscription name")
    total_findings: int = Field(0, description="Total findings")
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Severity breakdown"
    )
    top_categories: Optional[List[str]] = Field(None, description="Top issue categories")
    risk_score: float = Field(0.0, description="Overall subscription risk score")
    secure_score: Optional[float] = Field(None, description="Azure Secure Score")


class TenantSummary(BaseModel):
    """Summary for Azure AD tenant."""
    tenant_id: str = Field(..., description="Tenant ID")
    tenant_name: Optional[str] = Field(None, description="Tenant name")
    total_findings: int = Field(0, description="Total findings")
    identity_findings: int = Field(0, description="Identity-related findings")
    users_without_mfa: int = Field(0, description="Users without MFA")
    privileged_users: int = Field(0, description="Users with privileged roles")
    risky_service_principals: int = Field(0, description="Risky service principals")


class ScanMetadata(BaseModel):
    """Metadata about the scan execution."""
    scan_id: str = Field(..., description="Unique scan ID")
    scan_type: str = Field("full", description="Scan type: full/quick/targeted")
    started_at: datetime = Field(default_factory=datetime.utcnow, description="Start time")
    completed_at: Optional[datetime] = Field(None, description="Completion time")
    duration_seconds: Optional[float] = Field(None, description="Total duration")
    
    # Authentication
    caller_identity: Optional[str] = Field(None, description="Identity used for scan")
    caller_object_id: Optional[str] = Field(None, description="Caller object ID")
    
    # Coverage
    tenant_id: Optional[str] = Field(None, description="Tenant ID scanned")
    subscriptions_scanned: int = Field(0, description="Subscriptions scanned")
    resource_groups_scanned: int = Field(0, description="Resource groups scanned")
    resources_scanned: int = Field(0, description="Total resources scanned")
    
    # Checks
    total_checks: int = Field(0, description="Total checks performed")
    passed_checks: int = Field(0, description="Checks with no findings")
    failed_checks: int = Field(0, description="Checks with findings")
    skipped_checks: int = Field(0, description="Checks skipped")
    error_checks: int = Field(0, description="Checks with errors")
    
    # API usage
    total_api_calls: Optional[int] = Field(None, description="Total Azure API calls")


class AzureSecurityOutput(BaseModel):
    """
    Complete output from Azure security assessment.
    This is the main return type from hook_azure_security_scan().
    """
    # Metadata
    metadata: ScanMetadata = Field(..., description="Scan metadata")
    
    # Configuration used
    scan_options: Optional[ScanOptions] = Field(None, description="Options used")
    
    # Check results
    check_results: List[CheckResult] = Field(
        default_factory=list, description="Results from each check"
    )
    
    # All findings
    findings: List[SecurityFinding] = Field(
        default_factory=list, description="All security findings"
    )
    
    # Summaries
    severity_summary: SeveritySummary = Field(
        default_factory=SeveritySummary, description="Summary by severity"
    )
    category_summaries: List[CategorySummary] = Field(
        default_factory=list, description="Summary by category"
    )
    resource_type_summaries: List[ResourceTypeSummary] = Field(
        default_factory=list, description="Summary by resource type"
    )
    subscription_summaries: List[SubscriptionSummary] = Field(
        default_factory=list, description="Summary per subscription"
    )
    tenant_summary: Optional[TenantSummary] = Field(
        None, description="Azure AD tenant summary"
    )
    
    # Attack analysis
    privilege_escalation_paths: List[PrivilegeEscalationPath] = Field(
        default_factory=list, description="All detected privesc paths"
    )
    exfiltration_paths: List[ExfiltrationPath] = Field(
        default_factory=list, description="All detected exfil paths"
    )
    persistence_mechanisms: List[PersistenceMechanism] = Field(
        default_factory=list, description="All detected persistence"
    )
    
    # Aggregated IoCs
    all_iocs: Optional[List[IoC]] = Field(None, description="All extracted IoCs")
    
    # Top findings
    critical_findings: Optional[List[SecurityFinding]] = Field(
        None, description="Critical severity findings"
    )
    top_risk_resources: Optional[List[AzureResourceIdentifier]] = Field(
        None, description="Highest risk resources"
    )
    
    # Compliance
    compliance_summary: Optional[Dict[str, Dict[str, int]]] = Field(
        None, description="Compliance status per framework"
    )
    
    # Identity analysis
    risky_users: Optional[List[AzureADUserInfo]] = Field(None, description="High-risk users")
    risky_service_principals: Optional[List[ServicePrincipalInfo]] = Field(
        None, description="High-risk service principals"
    )
    
    # Errors and warnings
    errors: Optional[List[str]] = Field(None, description="Errors encountered")
    warnings: Optional[List[str]] = Field(None, description="Warnings from scan")
    
    # Recommendations
    prioritized_recommendations: Optional[List[str]] = Field(
        None, description="Prioritized action items"
    )
    
    # Baseline comparison
    baseline_comparison: Optional[Dict[str, Any]] = Field(
        None, description="Comparison with baseline"
    )
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )


# =============================================================================
# Baseline Models
# =============================================================================

class BaselineFinding(BaseModel):
    """Single finding in baseline."""
    finding_id: str = Field(..., description="Finding ID for matching")
    resource_id: str = Field(..., description="Resource ID")
    category: SecurityCategory = Field(..., description="Category")
    sub_category: SecuritySubCategory = Field(..., description="Sub-category")
    severity: SeverityLevel = Field(..., description="Severity")
    first_seen: datetime = Field(default_factory=datetime.utcnow, description="First detection")
    status: str = Field("acknowledged", description="Baseline status")
    notes: Optional[str] = Field(None, description="Notes about this finding")
    accepted_by: Optional[str] = Field(None, description="Who accepted the risk")
    accepted_until: Optional[datetime] = Field(None, description="Acceptance expiry")


class Baseline(BaseModel):
    """Security baseline for comparison."""
    baseline_id: str = Field(..., description="Unique baseline ID")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation time")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last update")
    tenant_id: Optional[str] = Field(None, description="Tenant ID")
    subscription_ids: Optional[List[str]] = Field(None, description="Subscriptions in baseline")
    findings: List[BaselineFinding] = Field(default_factory=list, description="Baseline findings")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class BaselineComparison(BaseModel):
    """Result of comparing current state to baseline."""
    new_findings: List[SecurityFinding] = Field(
        default_factory=list, description="Findings not in baseline"
    )
    resolved_findings: List[BaselineFinding] = Field(
        default_factory=list, description="Baseline findings now resolved"
    )
    unchanged_findings: int = Field(0, description="Findings unchanged from baseline")
    severity_changes: Optional[Dict[str, int]] = Field(
        None, description="Changes in severity counts"
    )
    comparison_timestamp: datetime = Field(
        default_factory=datetime.utcnow, description="Comparison time"
    )
