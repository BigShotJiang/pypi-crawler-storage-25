"""
Output service for Azure Security Assessment with reproduction steps.
"""

import copy
from datetime import datetime
from typing import List, Optional, Dict

from .proto import (
    AzureSecurityOutput,
    ScanOptions,
    ScanMetadata,
    SeveritySummary,
    CategorySummary,
    ResourceTypeSummary,
    SubscriptionSummary,
    SecurityFinding,
    SeverityLevel,
    ExploitationCommands,
    SecuritySubCategory,
)
from plugins.reproduction import ReproStep


# 🔴 AZURE EXPLOITATION COMMANDS by finding sub-category
AZURE_EXPLOITATION_COMMANDS: Dict[str, Dict] = {
    # Storage Issues
    "public_blob_container": {
        "commands": [
            "$ az storage container list --account-name {storage_account} --query '[?properties.publicAccess!=`None`]'",
            "$ az storage blob list --container-name {container_name} --account-name {storage_account}",
            "$ curl https://{storage_account}.blob.core.windows.net/{container_name}?restype=container&comp=list"
        ],
        "description": "List public Azure blob containers and enumerate contents"
    },
    "storage_https_disabled": {
        "commands": [
            "$ az storage account show --name {storage_account} --query 'enableHttpsTrafficOnly'"
        ],
        "description": "Check if storage account allows insecure HTTP"
    },
    
    # Identity Issues
    "mfa_not_enforced": {
        "commands": [
            "$ az ad user list --query '[].{UPN:userPrincipalName, MFA:strongAuthenticationDetail}'",
            "$ az ad user show --id {user_id} --query 'strongAuthenticationRequirements'"
        ],
        "description": "Check MFA status for Azure AD users"
    },
    "privileged_role_assignment": {
        "commands": [
            "$ az role assignment list --all --query '[?roleDefinitionName==`Owner` || roleDefinitionName==`Contributor`]'",
            "$ az ad user list --query '[?assignedPlans[?servicePlanId==`AAD Premium`]]'"
        ],
        "description": "Enumerate privileged role assignments"
    },
    "guest_user_access": {
        "commands": [
            "$ az ad user list --filter \"userType eq 'Guest'\"",
            "$ az role assignment list --assignee {guest_upn}"
        ],
        "description": "Enumerate guest users and their permissions"
    },
    
    # Network Issues
    "nsg_rule_open": {
        "commands": [
            "$ az network nsg rule list --nsg-name {nsg_name} --resource-group {rg} --query '[?sourceAddressPrefix==`*` || sourceAddressPrefix==`Internet`]'",
            "$ nmap -sV -p {port} {public_ip}"
        ],
        "description": "Check open NSG rules and test connectivity"
    },
    "public_ip_exposed": {
        "commands": [
            "$ az network public-ip list --query '[].{Name:name, IP:ipAddress, Associated:ipConfiguration.id}'",
            "$ nmap -sV {public_ip}"
        ],
        "description": "Enumerate public IPs and scan exposed services"
    },
    
    # Logging Issues
    "activity_log_disabled": {
        "commands": [
            "$ az account show --query '{subscriptionId,name,tenantId}' -o jsonc",
            "$ az monitor activity-log list --resource-id {resource_id} --query '[0:20]' -o jsonc 2>/dev/null || az monitor activity-log list --query '[0:20]' -o jsonc",
            "$ az monitor diagnostic-settings list --resource {resource_id}"
        ],
        "description": "Verify subscription/resource activity log visibility and diagnostic settings"
    },
    "security_center_disabled": {
        "commands": [
            "$ az security pricing list",
            "$ az security auto-provisioning-setting list"
        ],
        "description": "Check Azure Security Center/Defender status"
    },
    
    # Key Vault Issues
    "key_vault_public": {
        "commands": [
            "$ az keyvault show --name {vault_name} --query 'properties.networkAcls'",
            "$ az keyvault secret list --vault-name {vault_name}"
        ],
        "description": "Check Key Vault network access and enumerate secrets"
    },
    
    # Default
    "default": {
        "commands": [
            "$ az resource show --ids {resource_id}",
            "$ az resource list --resource-group {resource_group} --resource-type {resource_type}"
        ],
        "description": "Verify Azure resource configuration"
    }
}

_AZURE_SUBCAT_TEMPLATE_SOURCE: Dict[str, str] = {
    "public_blob": "public_blob_container",
    "storage_no_https": "storage_https_disabled",
    "global_admin_no_mfa": "mfa_not_enforced",
    "user_no_mfa": "mfa_not_enforced",
    "legacy_auth_enabled": "mfa_not_enforced",
    "guest_elevated_access": "guest_user_access",
    "stale_user_account": "guest_user_access",
    "permanent_admin_role": "privileged_role_assignment",
    "service_principal_admin": "privileged_role_assignment",
    "app_excessive_permissions": "privileged_role_assignment",
    "old_app_secret": "key_vault_public",
    "no_conditional_access": "mfa_not_enforced",
    "privilege_escalation_path": "privileged_role_assignment",
    "public_vm": "public_ip_exposed",
    "vm_no_encryption": "storage_https_disabled",
    "nsg_open": "nsg_rule_open",
    "managed_identity_abuse": "privileged_role_assignment",
    "jit_disabled": "public_ip_exposed",
    "vm_extension_secrets": "key_vault_public",
    "storage_firewall_disabled": "public_blob_container",
    "shared_key_auth": "public_blob_container",
    "storage_no_encryption": "storage_https_disabled",
    "sas_token_long_expiry": "public_blob_container",
    "public_database": "public_ip_exposed",
    "database_no_tde": "storage_https_disabled",
    "database_no_auditing": "activity_log_disabled",
    "database_allow_azure": "public_ip_exposed",
    "sql_auth_only": "public_ip_exposed",
    "nsg_any_any": "nsg_rule_open",
    "nsg_ssh_rdp_open": "nsg_rule_open",
    "no_waf": "nsg_rule_open",
    "no_ddos_protection": "nsg_rule_open",
    "nsg_flow_logs_disabled": "activity_log_disabled",
    "aks_public_api": "public_ip_exposed",
    "aks_local_accounts": "key_vault_public",
    "aks_no_azure_ad": "mfa_not_enforced",
    "privileged_pod": "key_vault_public",
    "host_namespace": "key_vault_public",
    "aks_no_network_policy": "nsg_rule_open",
    "app_no_https": "storage_https_disabled",
    "app_remote_debug": "public_ip_exposed",
    "app_ftp_enabled": "public_ip_exposed",
    "app_no_auth": "guest_user_access",
    "app_secrets_in_config": "key_vault_public",
    "keyvault_public": "key_vault_public",
    "keyvault_no_soft_delete": "key_vault_public",
    "secret_no_expiry": "key_vault_public",
    "keyvault_broad_access": "key_vault_public",
    "defender_disabled": "security_center_disabled",
    "activity_log_not_exported": "activity_log_disabled",
    "diagnostic_logs_disabled": "activity_log_disabled",
    "no_security_alerts": "security_center_disabled",
    "sentinel_not_deployed": "security_center_disabled",
    "no_azure_policy": "activity_log_disabled",
    "owner_too_many": "privileged_role_assignment",
    "classic_admin": "privileged_role_assignment",
    "no_resource_locks": "default",
    "automation_runbook": "default",
    "logic_app_trigger": "default",
    "function_timer": "default",
    "app_registration": "guest_user_access",
    "data_transfer_risk": "public_blob_container",
    "cross_tenant_access": "guest_user_access",
    "external_sharing": "guest_user_access",
}


def _expand_azure_exploitation_commands() -> None:
    for member in SecuritySubCategory:
        key = member.value
        if key in AZURE_EXPLOITATION_COMMANDS:
            continue
        src = _AZURE_SUBCAT_TEMPLATE_SOURCE.get(key, "default")
        if src not in AZURE_EXPLOITATION_COMMANDS:
            src = "default"
        AZURE_EXPLOITATION_COMMANDS[key] = copy.deepcopy(AZURE_EXPLOITATION_COMMANDS[src])


_expand_azure_exploitation_commands()


class OutputService:
    """Build AzureSecurityOutput and reproduction steps."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _build_commands_for_finding(self, f: SecurityFinding) -> Optional[ExploitationCommands]:
        """Generate exploitation commands based on finding type."""
        sub_cat = f.sub_category.value if hasattr(f.sub_category, 'value') else str(f.sub_category)
        cmd_template = AZURE_EXPLOITATION_COMMANDS.get(sub_cat, AZURE_EXPLOITATION_COMMANDS["default"])
        
        # Get resource info
        resource_id = getattr(f.resource, "resource_id", "") or ""
        resource_name = getattr(f.resource, "name", "") or ""
        resource_group = getattr(f.resource, "resource_group", "") or ""
        subscription_id = getattr(f.resource, "subscription_id", "") or ""
        location = getattr(f.resource, "location", "eastus") or "eastus"
        
        # Extract specific identifiers from evidence
        storage_account = ""
        container_name = ""
        nsg_name = ""
        vault_name = ""
        user_id = ""
        public_ip = ""
        port = "22"
        
        if f.evidence:
            storage_account = f.evidence.get("storage_account", "")
            container_name = f.evidence.get("container_name", "")
            nsg_name = f.evidence.get("nsg_name", "")
            vault_name = f.evidence.get("vault_name", "")
            user_id = f.evidence.get("user_id", "")
            public_ip = f.evidence.get("public_ip", "x.x.x.x")
            port = str(f.evidence.get("port", 22))
        
        # Build commands with replacements
        commands = []
        for cmd in cmd_template.get("commands", []):
            cmd_replaced = cmd.replace("{storage_account}", storage_account or resource_name)
            cmd_replaced = cmd_replaced.replace("{container_name}", container_name or "default")
            cmd_replaced = cmd_replaced.replace("{nsg_name}", nsg_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{vault_name}", vault_name or resource_name)
            cmd_replaced = cmd_replaced.replace("{user_id}", user_id)
            cmd_replaced = cmd_replaced.replace("{resource_id}", resource_id)
            cmd_replaced = cmd_replaced.replace("{resource_group}", resource_group)
            cmd_replaced = cmd_replaced.replace("{rg}", resource_group)
            cmd_replaced = cmd_replaced.replace("{public_ip}", public_ip)
            cmd_replaced = cmd_replaced.replace("{port}", port)
            cmd_replaced = cmd_replaced.replace("{resource_type}", str(getattr(f.resource, "resource_type", "")))
            cmd_replaced = cmd_replaced.replace("{guest_upn}", f.evidence.get("guest_upn", "") if f.evidence else "")
            commands.append(cmd_replaced)
        
        return ExploitationCommands(
            server=resource_name or resource_id,
            ip=f"Azure:{location}",
            commands=commands,
            description=cmd_template.get("description", f"Verify/exploit {f.name}")
        )

    def _build_steps_for_finding(self, f: SecurityFinding) -> List[ReproStep]:
        target = getattr(f.resource, "resource_id", None) or getattr(f.resource, "name", None)
        action = f"Verify misconfig/vuln on {target}" if target else f"Verify finding {f.id}"
        evidence = f.evidence or f.resource_config
        preconditions = ["Azure credentials with read access"]
        return [
            ReproStep(
                title=f.name,
                preconditions=preconditions,
                target=target or f.name,
                action=action,
                payload=None,
                expected_outcome=f.description,
                evidence=str(evidence) if evidence else None,
                tooling=["az cli", "portal"],
                safety="Read-only verification; if changing resources, do so in lab",
                cleanup="No cleanup for read-only; revert if any change was made",
            )
        ]

    def _attach_reproduction_steps(self) -> List[ReproStep]:
        collected: List[ReproStep] = []
        for f in getattr(self.plugin, "findings", []) or []:
            # 🔴 Attach commands if not present
            if not getattr(f, "commands", None):
                f.commands = self._build_commands_for_finding(f)
            
            if getattr(f, "reproduction_steps", None):
                collected.extend(f.reproduction_steps)
                continue
            f.reproduction_steps = self._build_steps_for_finding(f)
            collected.extend(f.reproduction_steps)
        return collected

    def create_output(
        self,
        options: ScanOptions,
        recommendations: List[str],
        quick_wins: List[str],
    ) -> AzureSecurityOutput:
        completed = datetime.utcnow()
        duration = (completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0

        severity_summary = SeveritySummary(
            critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
            high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            medium=len([f for f in self.plugin.findings if f.severity == SeverityLevel.MEDIUM]),
            low=len([f for f in self.plugin.findings if f.severity == SeverityLevel.LOW]),
            info=len([f for f in self.plugin.findings if f.severity == SeverityLevel.INFO]),
            total=len(self.plugin.findings),
        )

        category_summaries = []
        for cat in getattr(self.plugin, "categories", []) or []:
            cat_findings = [f for f in self.plugin.findings if f.category == cat]
            if cat_findings:
                category_summaries.append(
                    CategorySummary(
                        category=cat,
                        findings_count=len(cat_findings),
                        critical=len([f for f in cat_findings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in cat_findings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        resource_summaries = []
        for rtype in getattr(self.plugin, "resource_types", []) or []:
            rfindings = [f for f in self.plugin.findings if f.resource and f.resource.resource_type == rtype]
            if rfindings:
                resource_summaries.append(
                    ResourceTypeSummary(
                        resource_type=rtype,
                        findings_count=len(rfindings),
                        critical=len([f for f in rfindings if f.severity == SeverityLevel.CRITICAL]),
                        high=len([f for f in rfindings if f.severity == SeverityLevel.HIGH]),
                    )
                )

        subscription_summaries = [
            SubscriptionSummary(
                subscription_id=getattr(self.plugin, "subscription_id", "unknown"),
                findings_count=len(self.plugin.findings),
                critical=len([f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]),
                high=len([f for f in self.plugin.findings if f.severity == SeverityLevel.HIGH]),
            )
        ]

        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            started_at=self.plugin.scan_start or completed,
            completed_at=completed,
            duration_seconds=duration,
            total_findings=len(self.plugin.findings),
        )

        repro_steps = self._attach_reproduction_steps()

        return AzureSecurityOutput(
            metadata=metadata,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            resource_type_summaries=resource_summaries,
            subscription_summaries=subscription_summaries,
            findings=self.plugin.findings,
            critical_findings=[f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL],
            recommendations=recommendations,
            quick_wins=quick_wins,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            reproduction_steps=repro_steps or None,
        )
