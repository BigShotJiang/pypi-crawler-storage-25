"""
Azure Security Assessment Plugin

Comprehensive security assessment for Microsoft Azure environments.
Detects Azure AD misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.
"""

from .azure_security_assessment import AzureSecurityPlugin, scan_azure_security
from .output_service import OutputService
from .proto import (
    SeverityLevel,
    AzureResourceType,
    SecurityCategory,
    SecuritySubCategory,
    FindingStatus,
    ComplianceFramework,
    AzureRegion,
    ScanScope,
    ScanOptions,
    SecurityFinding,
    CheckResult,
    AzureSecurityOutput,
    AzureResourceIdentifier,
    AzureADUserInfo,
    ServicePrincipalInfo,
    NSGInfo,
    NSGRuleInfo,
    StorageAccountInfo,
    KeyVaultInfo,
    VMInfo,
    ConditionalAccessPolicy,
    PrivilegeEscalationPath,
    ExfiltrationPath,
    PersistenceMechanism,
    MitreAttackReference,
    ComplianceMapping,
    SubscriptionSummary,
    TenantSummary,
)

__all__ = [
    "AzureSecurityPlugin",
    "scan_azure_security",
    "SeverityLevel",
    "AzureResourceType",
    "SecurityCategory",
    "SecuritySubCategory",
    "FindingStatus",
    "ComplianceFramework",
    "AzureRegion",
    "ScanScope",
    "ScanOptions",
    "SecurityFinding",
    "CheckResult",
    "AzureSecurityOutput",
    "AzureResourceIdentifier",
    "AzureADUserInfo",
    "ServicePrincipalInfo",
    "NSGInfo",
    "NSGRuleInfo",
    "StorageAccountInfo",
    "KeyVaultInfo",
    "VMInfo",
    "ConditionalAccessPolicy",
    "PrivilegeEscalationPath",
    "ExfiltrationPath",
    "PersistenceMechanism",
    "MitreAttackReference",
    "ComplianceMapping",
    "SubscriptionSummary",
    "TenantSummary",
]

__version__ = "1.0.0"
