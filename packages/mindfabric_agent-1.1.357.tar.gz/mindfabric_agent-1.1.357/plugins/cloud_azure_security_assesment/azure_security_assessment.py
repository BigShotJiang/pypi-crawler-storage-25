"""
Azure Security Assessment Plugin

Comprehensive security assessment for Microsoft Azure environments.
Detects Azure AD misconfigurations, privilege escalation paths, data exposure,
persistence mechanisms, and compliance violations.

Covers 290+ security vectors across 15 categories mapped to MITRE ATT&CK Cloud Matrix.
"""

import asyncio
import json
import logging
import re
import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

try:
    from azure.identity import DefaultAzureCredential
    from azure.mgmt.resource import ResourceManagementClient, SubscriptionClient
    from azure.mgmt.compute import ComputeManagementClient
    from azure.mgmt.network import NetworkManagementClient
    from azure.mgmt.storage import StorageManagementClient
    from azure.mgmt.keyvault import KeyVaultManagementClient
    from azure.mgmt.sql import SqlManagementClient
    from azure.mgmt.web import WebSiteManagementClient
    from azure.mgmt.containerservice import ContainerServiceClient
    from azure.mgmt.monitor import MonitorManagementClient
    from azure.mgmt.security import SecurityCenter
    HAS_AZURE_SDK = True
except ImportError:
    HAS_AZURE_SDK = False

from .proto import (
    AzureADUserInfo,
    AzureResourceIdentifier,
    AzureResourceType,
    AzureSecurityOutput,
    Baseline,
    BaselineComparison,
    BaselineFinding,
    CategorySummary,
    CheckResult,
    ComplianceFramework,
    ComplianceMapping,
    ConditionalAccessPolicy,
    ExfiltrationPath,
    ExploitationCommands,
    FindingStatus,
    IoC,
    KeyVaultInfo,
    MitreAttackReference,
    NSGInfo,
    NSGRuleInfo,
    PersistenceMechanism,
    PrivilegeEscalationPath,
    ResourceTypeSummary,
    ScanMetadata,
    ScanOptions,
    ScanScope,
    SecurityCategory,
    SecurityFinding,
    SecuritySubCategory,
    ServicePrincipalInfo,
    SeverityLevel,
    SeveritySummary,
    StorageAccountInfo,
    SubscriptionSummary,
    TenantSummary,
    VMInfo,
)

from .modules.databases import (
    MITRE_MAPPING,
    CIS_AZURE_MAPPING,
    AZURE_CHECKS,
    DANGEROUS_AAD_PERMISSIONS,
    DANGEROUS_RBAC_ROLES,
    SECRET_PATTERNS,
)
from plugins.base_plugin import BasePlugin

from .modules.utils import (
    get_mitre_reference,
    get_compliance_mappings,
    check_content_for_secrets,
    calculate_risk_score,
)
from .modules.services import (
    FindingFactoryService,
    ResultProcessorService,
    AttackPathAnalyzerService,
    AADCheckService,
    VMCheckService,
    NSGCheckService,
    StorageCheckService,
    KeyVaultCheckService,
    SQLCheckService,
    AKSCheckService,
    AppServiceCheckService,
    MonitoringCheckService,
    PersistenceCheckService,
    AdditionalAzureServicesCheckService,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Main Plugin Class
# =============================================================================

class AzureSecurityPlugin(BasePlugin):
    VERSION = "1.0.0"
    """
    Azure Security Assessment Plugin.
    
    Comprehensive security assessment for Microsoft Azure environments.
    Detects 290+ security vectors across 15 categories.
    """
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self.scan_id: str = ""
        self.scan_start: Optional[datetime] = None
        self.findings: List[SecurityFinding] = []
        self.check_results: List[CheckResult] = []
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.subscriptions_scanned: Set[str] = set()
        self.resource_groups_scanned: Set[str] = set()
        self.resources_scanned: int = 0
        
        # Analysis results
        self.privilege_escalation_paths: List[PrivilegeEscalationPath] = []
        self.exfiltration_paths: List[ExfiltrationPath] = []
        self.persistence_mechanisms: List[PersistenceMechanism] = []
        self.risky_users: List[AzureADUserInfo] = []
        self.risky_service_principals: List[ServicePrincipalInfo] = []
        
        # Azure clients cache
        self._credential: Optional[Any] = None
        self._clients: Dict[str, Any] = {}
        self._tenant_id: Optional[str] = None
        self._caller_identity: Optional[str] = None
        
        # MindFabric integration
        self.command_id: Optional[str] = None
        self.ws: Optional[Any] = None
        
        # Initialize services
        self.finding_factory = FindingFactoryService(self)
        self.result_processor = ResultProcessorService(self)
        self.attack_path_analyzer = AttackPathAnalyzerService(self)
        
        # Initialize check services
        self.aad_check_service = AADCheckService(self)
        self.vm_check_service = VMCheckService(self)
        self.nsg_check_service = NSGCheckService(self)
        self.storage_check_service = StorageCheckService(self)
        self.keyvault_check_service = KeyVaultCheckService(self)
        self.sql_check_service = SQLCheckService(self)
        self.aks_check_service = AKSCheckService(self)
        self.app_service_check_service = AppServiceCheckService(self)
        self.monitoring_check_service = MonitoringCheckService(self)
        self.persistence_check_service = PersistenceCheckService(self)
        self.additional_services_check_service = AdditionalAzureServicesCheckService(self)
        
        # Map check function names to services
        self.check_services = {
            "check_global_admin_mfa": self.aad_check_service,
            "check_user_mfa": self.aad_check_service,
            "check_legacy_auth": self.aad_check_service,
            "check_guest_elevated": self.aad_check_service,
            "check_stale_users": self.aad_check_service,
            "check_permanent_admin": self.aad_check_service,
            "check_sp_admin": self.aad_check_service,
            "check_app_permissions": self.aad_check_service,
            "check_old_app_secrets": self.aad_check_service,
            "check_conditional_access": self.aad_check_service,
            "check_vm_public_ip": self.vm_check_service,
            "check_vm_disk_encryption": self.vm_check_service,
            "check_vm_managed_identity": self.vm_check_service,
            "check_vm_jit": self.vm_check_service,
            "check_nsg_open_ssh": self.nsg_check_service,
            "check_nsg_open_rdp": self.nsg_check_service,
            "check_nsg_open_all": self.nsg_check_service,
            "check_nsg_flow_logs": self.nsg_check_service,
            "check_public_blob": self.storage_check_service,
            "check_storage_https": self.storage_check_service,
            "check_storage_firewall": self.storage_check_service,
            "check_storage_shared_key": self.storage_check_service,
            "check_keyvault_public": self.keyvault_check_service,
            "check_keyvault_soft_delete": self.keyvault_check_service,
            "check_secret_expiry": self.keyvault_check_service,
            "check_sql_public": self.sql_check_service,
            "check_sql_tde": self.sql_check_service,
            "check_sql_auditing": self.sql_check_service,
            "check_aks_public_api": self.aks_check_service,
            "check_aks_local_accounts": self.aks_check_service,
            "check_aks_azure_ad": self.aks_check_service,
            "check_aks_network_policy": self.aks_check_service,
            "check_app_https": self.app_service_check_service,
            "check_app_remote_debug": self.app_service_check_service,
            "check_app_ftp": self.app_service_check_service,
            "check_defender_enabled": self.monitoring_check_service,
            "check_diagnostic_logs": self.monitoring_check_service,
            "check_owner_count": self.monitoring_check_service,
            "check_classic_admin": self.monitoring_check_service,
            "check_azure_policy": self.monitoring_check_service,
            "check_resource_locks": self.monitoring_check_service,
            "check_automation_runbooks": self.persistence_check_service,
            "check_logic_apps": self.persistence_check_service,
        }
    
    def _get_credential(self):
        """Get Azure credential."""
        if not HAS_AZURE_SDK:
            raise ImportError("Azure SDK is required for Azure scanning")
        
        if self._credential is None:
            self._credential = DefaultAzureCredential()
        return self._credential
    
    def _get_subscription_client(self):
        """Get subscription client."""
        if "subscription" not in self._clients:
            self._clients["subscription"] = SubscriptionClient(self._get_credential())
        return self._clients["subscription"]
    
    def _get_resource_client(self, subscription_id: str):
        """Get resource management client."""
        key = f"resource:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = ResourceManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_compute_client(self, subscription_id: str):
        """Get compute management client."""
        key = f"compute:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = ComputeManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_network_client(self, subscription_id: str):
        """Get network management client."""
        key = f"network:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = NetworkManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_storage_client(self, subscription_id: str):
        """Get storage management client."""
        key = f"storage:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = StorageManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_keyvault_client(self, subscription_id: str):
        """Get key vault management client."""
        key = f"keyvault:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = KeyVaultManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    async def run(self):
        """Main entry point."""
        from .proto import ScanOptions
        options = ScanOptions()
        result = await self.hook_azure_security_scan(options)
        return self.to_security_scan_v1(self._with_canonical_findings(result))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Add plugin-owned `findings` for canonical security_scan v1.
        Keeps UI clean: short description + rich evidence (no giant credential chain dumps).
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        errors = out.get("errors") or []
        warnings = out.get("warnings") or []

        # Collapse verbose DefaultAzureCredential chain into a short summary.
        def _shorten_azure_error(msg: str) -> str:
            s = str(msg or "").strip()
            if not s:
                return "Azure authentication/authorization failed."
            low = s.lower()
            if "defaultazurecredential failed" in low or "failed to retrieve a token" in low:
                return "Azure credentials are not configured (DefaultAzureCredential could not obtain a token)."
            if "failed to list subscriptions" in low:
                return "Failed to list Azure subscriptions (insufficient credentials/permissions)."
            return s[:240] + ("…" if len(s) > 240 else "")

        from .modules.databases.azure_databases import (
            AZURE_AUTH_CONFIG_COMMANDS,
            AZURE_AUTH_CONFIG_RECOMMENDATIONS,
        )
        commands = AZURE_AUTH_CONFIG_COMMANDS
        recommendations = AZURE_AUTH_CONFIG_RECOMMENDATIONS

        # If plugin already emitted findings, normalize them (keep structured content,
        # but collapse verbose DefaultAzureCredential chains and ensure UI blocks exist).
        findings_existing = out.get("findings") or []
        if isinstance(findings_existing, list) and len(findings_existing) > 0:
            for f in findings_existing:
                if not isinstance(f, dict):
                    continue
                desc = str(f.get("description") or "")
                if desc:
                    short_desc = _shorten_azure_error(desc)
                    if short_desc != desc:
                        ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}
                        ev = dict(ev)
                        ev.setdefault("error_full", desc)
                        ev.setdefault("error_short", short_desc)
                        f["evidence"] = ev
                        f["description"] = short_desc
                if not f.get("recommendations"):
                    f["recommendations"] = recommendations
                # Accept either `commands` object or `exploitation_commands` list in security_contract.
                if not f.get("exploitation_commands") and not f.get("commands"):
                    f["exploitation_commands"] = commands
                if f.get("remediation_steps") is None:
                    f["remediation_steps"] = []
                if not f.get("affected_resources"):
                    ev = f.get("evidence") if isinstance(f.get("evidence"), dict) else {}

                    def _az_pick(*keys: str) -> Optional[str]:
                        for k in keys:
                            v = f.get(k) or ev.get(k)
                            if isinstance(v, str) and v.strip():
                                return v.strip()
                        return None

                    sub = _az_pick("subscription_id", "subscriptionId")
                    rgrp = _az_pick("resource_group", "resourceGroup")
                    rid = _az_pick("resource_id", "resourceId")
                    rname = _az_pick("resource_name", "resourceName")
                    rtype = _az_pick("resource_type", "resourceType")
                    reg = _az_pick("region")
                    if sub or rgrp or rid or rname or rtype or reg:
                        row_z: Dict[str, Any] = {"type": "cloud_resource"}
                        if sub:
                            row_z["subscription_id"] = sub[:120]
                        if rgrp:
                            row_z["resource_group"] = rgrp[:260]
                        if rid:
                            row_z["resource_id"] = rid[:500]
                        if rname:
                            row_z["resource"] = rname[:500]
                        if rtype:
                            row_z["resource_type"] = rtype[:200]
                        if reg:
                            row_z["region"] = reg[:80]
                        f["affected_resources"] = [row_z]
            out["findings"] = findings_existing
            return out

        # Important: missing/invalid Azure credentials or "no findings emitted" are coverage/info events,
        # not security findings. Do NOT emit a finding/threat for these cases.
        out["findings"] = []
        return out
    
    def _get_sql_client(self, subscription_id: str):
        """Get SQL management client."""
        key = f"sql:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = SqlManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_web_client(self, subscription_id: str):
        """Get web site management client."""
        key = f"web:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = WebSiteManagementClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_aks_client(self, subscription_id: str):
        """Get AKS management client."""
        key = f"aks:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = ContainerServiceClient(self._get_credential(), subscription_id)
        return self._clients[key]
    
    def _get_security_client(self, subscription_id: str):
        """Get security center client."""
        key = f"security:{subscription_id}"
        if key not in self._clients:
            self._clients[key] = SecurityCenter(self._get_credential(), subscription_id, "")
        return self._clients[key]
    
    async def _handle_progress(self, percent: int, message: str):
        """Send progress update via WebSocket."""
        if self.ws:
            try:
                await self.ws.send_json({
                    "type": "progress",
                    "command_id": self.command_id,
                    "percent": percent,
                    "message": message
                })
            except Exception:
                pass
        logger.debug(f"Progress: {percent}% - {message}")
    
    async def hook_azure_security_scan(
        self,
        options: Optional[ScanOptions] = None
    ) -> AzureSecurityOutput:
        """
        Main entry point for Azure security scanning.
        
        Args:
            options: Scan configuration options
            
        Returns:
            AzureSecurityOutput with all findings
        """
        self.scan_id = str(uuid.uuid4())
        self.scan_start = datetime.utcnow()
        self.findings = []
        self.check_results = []
        self.errors = []
        self.warnings = []
        self.subscriptions_scanned = set()
        self.resource_groups_scanned = set()
        self.resources_scanned = 0
        self.privilege_escalation_paths = []
        self.exfiltration_paths = []
        self.persistence_mechanisms = []
        self.risky_users = []
        self.risky_service_principals = []
        self._clients = {}
        
        if options is None:
            options = ScanOptions()
        
        await self._handle_progress(0, "Starting Azure security scan")
        
        # Get subscriptions to scan
        await self._handle_progress(5, "Enumerating subscriptions")
        subscriptions = await self._get_subscriptions_to_scan(options.scope)
        
        if not subscriptions:
            self.errors.append("No subscriptions found to scan")
            # Important: missing/invalid Azure credentials is a coverage issue (not a security finding).
            # Do NOT emit a finding/threat for this case; return only errors/warnings.
            self.warnings.append("Azure scan skipped: credentials/tooling not available (no subscriptions enumerated)")
            return self.result_processor.create_output(options)
        
        self.subscriptions_scanned = set(subscriptions)
        
        # Filter checks
        checks = self._filter_checks(AZURE_CHECKS, options)
        tenant_checks = [c for c in checks if c.get("tenant_check", False)]
        subscription_checks = [c for c in checks if not c.get("tenant_check", False)]
        
        await self._handle_progress(10, f"Scanning {len(subscriptions)} subscriptions")
        
        # Execute tenant-level checks (Azure AD)
        if options.scope.include_azure_ad and tenant_checks:
            await self._handle_progress(12, "Scanning Azure AD")
            for check in tenant_checks:
                try:
                    result = await self._execute_check(check, None, None, options)
                    self.check_results.append(result)
                    self.findings.extend(result.findings)
                except Exception as e:
                    self.errors.append(f"Tenant check '{check['name']}' failed: {str(e)}")
        
        # Execute subscription-level checks
        total_work = len(subscription_checks) * len(subscriptions)
        work_done = 0
        
        for subscription_id in subscriptions:
            for check in subscription_checks:
                try:
                    result = await self._execute_check(check, subscription_id, None, options)
                    self.check_results.append(result)
                    self.findings.extend(result.findings)
                except Exception as e:
                    self.errors.append(f"Check '{check['name']}' in {subscription_id} failed: {str(e)}")
                
                work_done += 1
                progress = 15 + int((work_done / max(total_work, 1)) * 65)
                await self._handle_progress(progress, f"Running check: {check['name']}")
        
        # Attack path analysis
        if options.analyze_privilege_escalation:
            await self._handle_progress(82, "Analyzing privilege escalation paths")
            await self.attack_path_analyzer.analyze_privilege_escalation_paths(options)
        
        if options.analyze_exfiltration_paths:
            await self._handle_progress(86, "Analyzing exfiltration paths")
            await self.attack_path_analyzer.analyze_exfiltration_paths(options)
        
        if options.analyze_persistence:
            await self._handle_progress(90, "Analyzing persistence mechanisms")
            await self.attack_path_analyzer.analyze_persistence(options)
        
        # Additional Azure services security checks
        await self._handle_progress(92, "Scanning additional Azure services")
        for subscription_id in subscriptions:
            try:
                additional_findings = await self.additional_services_check_service.run_all_checks(subscription_id, options)
                self.findings.extend(additional_findings)
            except Exception as e:
                self.errors.append(f"Additional services check in {subscription_id} failed: {str(e)}")
        
        await self._handle_progress(95, "Generating summary")
        
        return self.result_processor.create_output(options)
    
    async def _get_subscriptions_to_scan(self, scope: ScanScope) -> List[str]:
        """Determine which subscriptions to scan."""
        subscriptions = []
        
        if scope.subscription_ids:
            subscriptions = scope.subscription_ids
        else:
            try:
                sub_client = self._get_subscription_client()
                for sub in sub_client.subscriptions.list():
                    if sub.state.value == "Enabled":
                        subscriptions.append(sub.subscription_id)
            except Exception as e:
                self.errors.append(f"Failed to list subscriptions: {e}")
        
        if scope.exclude_subscription_ids:
            subscriptions = [s for s in subscriptions if s not in scope.exclude_subscription_ids]
        
        return subscriptions
    
    def _filter_checks(self, checks: List[Dict], options: ScanOptions) -> List[Dict]:
        """Filter checks based on options."""
        filtered = checks
        
        if options.categories:
            filtered = [c for c in filtered if c["category"] in options.categories]
        
        if options.exclude_categories:
            filtered = [c for c in filtered if c["category"] not in options.exclude_categories]
        
        if options.scope.resource_types:
            filtered = [c for c in filtered 
                       if any(rt in options.scope.resource_types for rt in c["resource_types"])]
        
        if options.quick_scan:
            filtered = [c for c in filtered 
                       if c["severity"] in [SeverityLevel.CRITICAL, SeverityLevel.HIGH]]
        
        return filtered
    
    async def _execute_check(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> CheckResult:
        """Execute a single security check."""
        start_time = time.time()
        findings = []
        error = None
        
        try:
            check_fn = check.get("check_fn", "")
            check_service = self.check_services.get(check_fn)
            
            if check_service:
                check_findings = await check_service.execute_check_method(
                    check, subscription_id, resource_group, options
                )
                findings.extend(check_findings)
                self.resources_scanned += len(check_findings)
                # All checks are now handled by services
        except Exception as e:
            error = str(e)
            logger.error(f"Check {check['id']} failed: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CheckResult(
            check_id=check["id"],
            check_name=check["name"],
            category=check["category"],
            sub_category=check["sub_category"],
            passed=len(findings) == 0,
            findings_count=len(findings),
            findings=findings,
            resources_checked=0,
            resources_with_issues=len(findings),
            subscriptions_checked=[subscription_id] if subscription_id else None,
            duration_ms=duration_ms,
            error=error,
        )


# Legacy compatibility
async def scan_azure_security(options: Optional[ScanOptions] = None) -> AzureSecurityOutput:
    """Legacy function for backward compatibility."""
    plugin = AzureSecurityPlugin()
    return await plugin.hook_azure_security_scan(options)
