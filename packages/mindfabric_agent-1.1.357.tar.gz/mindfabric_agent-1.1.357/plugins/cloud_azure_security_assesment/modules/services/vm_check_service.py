"""
VM Check Service

Service for executing VM-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class VMCheckService:
    """Service for executing VM security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize VM check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute VM check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_vm_public_ip": self.check_vm_public_ip,
            "check_vm_disk_encryption": self.check_vm_disk_encryption,
            "check_vm_managed_identity": self.check_vm_managed_identity,
            "check_vm_jit": self.check_vm_jit,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_vm_public_ip(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs with public IP addresses."""
        findings = []
        
        try:
            compute_client = self.plugin._get_compute_client(subscription_id)
            network_client = self.plugin._get_network_client(subscription_id)
            
            for vm in compute_client.virtual_machines.list_all():
                if vm.network_profile and vm.network_profile.network_interfaces:
                    for nic_ref in vm.network_profile.network_interfaces:
                        nic_name = nic_ref.id.split("/")[-1]
                        nic_rg = nic_ref.id.split("/")[4]
                        
                        try:
                            nic = network_client.network_interfaces.get(nic_rg, nic_name)
                            
                            for ip_config in nic.ip_configurations or []:
                                if ip_config.public_ip_address:
                                    # Get actual public IP address
                                    public_ip_id = ip_config.public_ip_address.id if hasattr(ip_config.public_ip_address, 'id') else None
                                    public_ip_address = None
                                    if public_ip_id:
                                        try:
                                            pip_rg = public_ip_id.split("/")[4]
                                            pip_name = public_ip_id.split("/")[-1]
                                            pip = network_client.public_ip_addresses.get(pip_rg, pip_name)
                                            public_ip_address = pip.ip_address if pip else None
                                        except Exception:
                                            pass
                                    
                                    findings.append(self.plugin.finding_factory.create_finding(
                                        check=check,
                                        subscription_id=subscription_id,
                                        resource_group=vm.id.split("/")[4],
                                        resource_type=AzureResourceType.VIRTUAL_MACHINE,
                                        resource_id=vm.id,
                                        name=vm.name,
                                        location=vm.location,
                                        description=f"VM '{vm.name}' has a public IP address" + (f": {public_ip_address}" if public_ip_address else ""),
                                        recommendation="Remove public IP and use Azure Bastion or VPN for access",
                                        severity=SeverityLevel.HIGH,
                                        evidence={"public_ip": public_ip_address if public_ip_address else True, "public_ip_address": public_ip_address},
                                    ))
                        except Exception:
                            pass
        except Exception as e:
            logger.error(f"VM public IP check failed: {e}")
        
        return findings
    
    async def check_vm_disk_encryption(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs without disk encryption."""
        findings = []
        
        try:
            compute_client = self.plugin._get_compute_client(subscription_id)
            
            for vm in compute_client.virtual_machines.list_all():
                # Check OS disk
                os_disk = vm.storage_profile.os_disk
                os_encrypted = os_disk.encryption_settings and os_disk.encryption_settings.enabled
                
                # Check data disks
                data_encrypted = True
                for disk in vm.storage_profile.data_disks or []:
                    if not (disk.encryption_settings and disk.encryption_settings.enabled):
                        data_encrypted = False
                        break
                
                if not os_encrypted or not data_encrypted:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=vm.id.split("/")[4],
                        resource_type=AzureResourceType.VIRTUAL_MACHINE,
                        resource_id=vm.id,
                        name=vm.name,
                        location=vm.location,
                        description=f"VM '{vm.name}' has unencrypted disks",
                        recommendation="Enable Azure Disk Encryption (ADE) for all disks",
                        severity=SeverityLevel.HIGH,
                        evidence={"os_encrypted": os_encrypted, "data_encrypted": data_encrypted},
                    ))
        except Exception as e:
            logger.error(f"VM disk encryption check failed: {e}")
        
        return findings
    
    async def check_vm_managed_identity(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for VMs with managed identity and elevated permissions."""
        findings = []
        
        try:
            compute_client = self.plugin._get_compute_client(subscription_id)
            
            for vm in compute_client.virtual_machines.list_all():
                identity = vm.identity
                
                if identity and identity.type:
                    # VM has managed identity - would need to check RBAC assignments
                    # For now, flag if it exists for review
                    if "SystemAssigned" in str(identity.type):
                        # In production, check actual RBAC roles assigned
                        pass
        except Exception as e:
            logger.error(f"VM managed identity check failed: {e}")
        
        return findings
    
    async def check_vm_jit(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if JIT access is enabled for VMs."""
        findings = []
        
        # Requires Security Center API
        
        return findings

