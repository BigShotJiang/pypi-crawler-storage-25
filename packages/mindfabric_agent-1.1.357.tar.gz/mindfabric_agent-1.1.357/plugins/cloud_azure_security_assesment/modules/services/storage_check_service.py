"""
Storage Check Service

Service for executing Storage-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class StorageCheckService:
    """Service for executing Storage security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize Storage check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Storage check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_public_blob": self.check_public_blob,
            "check_storage_https": self.check_storage_https,
            "check_storage_firewall": self.check_storage_firewall,
            "check_storage_shared_key": self.check_storage_shared_key,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_public_blob(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for storage accounts with public blob access."""
        findings = []
        
        try:
            storage_client = self.plugin._get_storage_client(subscription_id)
            
            for account in storage_client.storage_accounts.list():
                if account.allow_blob_public_access:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=account.id.split("/")[4],
                        resource_type=AzureResourceType.STORAGE_ACCOUNT,
                        resource_id=account.id,
                        name=account.name,
                        location=account.location,
                        description=f"Storage account '{account.name}' allows public blob access",
                        recommendation="Disable anonymous public access to blob data",
                        severity=SeverityLevel.CRITICAL,
                        evidence={"allow_blob_public_access": True},
                        remediation_commands=[
                            f"az storage account update --name {account.name} --resource-group {account.id.split('/')[4]} --allow-blob-public-access false"
                        ],
                    ))
        except Exception as e:
            logger.error(f"Public blob check failed: {e}")
        
        return findings
    
    async def check_storage_https(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for storage accounts without HTTPS-only."""
        findings = []
        
        try:
            storage_client = self.plugin._get_storage_client(subscription_id)
            
            for account in storage_client.storage_accounts.list():
                if not account.enable_https_traffic_only:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=account.id.split("/")[4],
                        resource_type=AzureResourceType.STORAGE_ACCOUNT,
                        resource_id=account.id,
                        name=account.name,
                        location=account.location,
                        description=f"Storage account '{account.name}' allows non-HTTPS traffic",
                        recommendation="Enable 'Secure transfer required' setting",
                        severity=SeverityLevel.HIGH,
                        evidence={"https_only": False},
                    ))
        except Exception as e:
            logger.error(f"Storage HTTPS check failed: {e}")
        
        return findings
    
    async def check_storage_firewall(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for storage accounts without firewall enabled."""
        findings = []
        
        try:
            storage_client = self.plugin._get_storage_client(subscription_id)
            
            for account in storage_client.storage_accounts.list():
                network_rules = account.network_rule_set
                
                if network_rules and network_rules.default_action == "Allow":
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=account.id.split("/")[4],
                        resource_type=AzureResourceType.STORAGE_ACCOUNT,
                        resource_id=account.id,
                        name=account.name,
                        location=account.location,
                        description=f"Storage account '{account.name}' allows access from all networks",
                        recommendation="Configure firewall to allow only specific networks",
                        severity=SeverityLevel.HIGH,
                        evidence={"default_action": "Allow"},
                    ))
        except Exception as e:
            logger.error(f"Storage firewall check failed: {e}")
        
        return findings
    
    async def check_storage_shared_key(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for storage accounts with shared key access enabled."""
        findings = []
        
        try:
            storage_client = self.plugin._get_storage_client(subscription_id)
            
            for account in storage_client.storage_accounts.list():
                if account.allow_shared_key_access != False:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=account.id.split("/")[4],
                        resource_type=AzureResourceType.STORAGE_ACCOUNT,
                        resource_id=account.id,
                        name=account.name,
                        location=account.location,
                        description=f"Storage account '{account.name}' allows shared key access",
                        recommendation="Disable shared key access and use Azure AD authentication",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"shared_key_access": True},
                    ))
        except Exception as e:
            logger.error(f"Storage shared key check failed: {e}")
        
        return findings

