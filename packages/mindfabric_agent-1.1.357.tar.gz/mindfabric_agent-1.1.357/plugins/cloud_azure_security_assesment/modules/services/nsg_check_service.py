"""
NSG Check Service

Service for executing NSG-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class NSGCheckService:
    """Service for executing NSG security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize NSG check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute NSG check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_nsg_open_ssh": self.check_nsg_open_ssh,
            "check_nsg_open_rdp": self.check_nsg_open_rdp,
            "check_nsg_open_all": self.check_nsg_open_all,
            "check_nsg_flow_logs": self.check_nsg_flow_logs,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    def is_port_in_range(self, port: int, port_range: Optional[str], port_ranges: Optional[List[str]]) -> bool:
        """Check if a port is within the specified range(s)."""
        if port_range:
            if port_range == "*":
                return True
            if "-" in port_range:
                start, end = map(int, port_range.split("-"))
                return start <= port <= end
            return int(port_range) == port
        
        if port_ranges:
            for pr in port_ranges:
                if pr == "*":
                    return True
                if "-" in pr:
                    start, end = map(int, pr.split("-"))
                    if start <= port <= end:
                        return True
                elif int(pr) == port:
                    return True
        
        return False
    
    def is_any_source(self, prefix: Optional[str], prefixes: Optional[List[str]]) -> bool:
        """Check if source allows any address."""
        any_sources = ["*", "0.0.0.0/0", "Internet", "Any"]
        
        if prefix and prefix in any_sources:
            return True
        
        if prefixes:
            for p in prefixes:
                if p in any_sources:
                    return True
        
        return False
    
    async def check_nsg_open_ssh(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for NSGs with SSH open to the internet."""
        findings = []
        
        try:
            network_client = self.plugin._get_network_client(subscription_id)
            
            for nsg in network_client.network_security_groups.list_all():
                for rule in nsg.security_rules or []:
                    if (rule.direction == "Inbound" and 
                        rule.access == "Allow" and
                        self.is_port_in_range(22, rule.destination_port_range, rule.destination_port_ranges)):
                        
                        if self.is_any_source(rule.source_address_prefix, rule.source_address_prefixes):
                            findings.append(self.plugin.finding_factory.create_finding(
                                check=check,
                                subscription_id=subscription_id,
                                resource_group=nsg.id.split("/")[4],
                                resource_type=AzureResourceType.NSG,
                                resource_id=nsg.id,
                                name=nsg.name,
                                location=nsg.location,
                                description=f"NSG '{nsg.name}' allows SSH from the internet",
                                recommendation="Restrict SSH access to specific IP ranges or use Azure Bastion",
                                severity=SeverityLevel.HIGH,
                                evidence={"rule": rule.name, "port": 22},
                                remediation_commands=[
                                    f"az network nsg rule update --nsg-name {nsg.name} --resource-group {nsg.id.split('/')[4]} --name {rule.name} --source-address-prefixes <specific-ip-range>"
                                ],
                            ))
        except Exception as e:
            logger.error(f"NSG SSH check failed: {e}")
        
        return findings
    
    async def check_nsg_open_rdp(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for NSGs with RDP open to the internet."""
        findings = []
        
        try:
            network_client = self.plugin._get_network_client(subscription_id)
            
            for nsg in network_client.network_security_groups.list_all():
                for rule in nsg.security_rules or []:
                    if (rule.direction == "Inbound" and 
                        rule.access == "Allow" and
                        self.is_port_in_range(3389, rule.destination_port_range, rule.destination_port_ranges)):
                        
                        if self.is_any_source(rule.source_address_prefix, rule.source_address_prefixes):
                            findings.append(self.plugin.finding_factory.create_finding(
                                check=check,
                                subscription_id=subscription_id,
                                resource_group=nsg.id.split("/")[4],
                                resource_type=AzureResourceType.NSG,
                                resource_id=nsg.id,
                                name=nsg.name,
                                location=nsg.location,
                                description=f"NSG '{nsg.name}' allows RDP from the internet",
                                recommendation="Restrict RDP access or use Azure Bastion",
                                severity=SeverityLevel.HIGH,
                                evidence={"rule": rule.name, "port": 3389},
                            ))
        except Exception as e:
            logger.error(f"NSG RDP check failed: {e}")
        
        return findings
    
    async def check_nsg_open_all(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for NSGs with all ports open."""
        findings = []
        
        try:
            network_client = self.plugin._get_network_client(subscription_id)
            
            for nsg in network_client.network_security_groups.list_all():
                for rule in nsg.security_rules or []:
                    if (rule.direction == "Inbound" and 
                        rule.access == "Allow" and
                        rule.destination_port_range == "*"):
                        
                        if self.is_any_source(rule.source_address_prefix, rule.source_address_prefixes):
                            findings.append(self.plugin.finding_factory.create_finding(
                                check=check,
                                subscription_id=subscription_id,
                                resource_group=nsg.id.split("/")[4],
                                resource_type=AzureResourceType.NSG,
                                resource_id=nsg.id,
                                name=nsg.name,
                                location=nsg.location,
                                description=f"NSG '{nsg.name}' allows all inbound traffic from the internet",
                                recommendation="Restrict inbound access to specific ports and sources",
                                severity=SeverityLevel.CRITICAL,
                                evidence={"rule": rule.name, "port": "*"},
                            ))
        except Exception as e:
            logger.error(f"NSG open all check failed: {e}")
        
        return findings
    
    async def check_nsg_flow_logs(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for NSGs without flow logs enabled."""
        findings = []
        
        # Requires Network Watcher API
        
        return findings

