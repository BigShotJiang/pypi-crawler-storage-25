"""
Result Processor Service

Service for processing scan results and generating output.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from datetime import datetime
from typing import Dict, List

from ...proto import (
    AzureSecurityOutput,
    CategorySummary,
    ScanMetadata,
    ScanOptions,
    SecurityCategory,
    SecurityFinding,
    SeverityLevel,
    SeveritySummary,
    SubscriptionSummary,
)


class ResultProcessorService:
    """Service for processing scan results and generating output."""
    
    def __init__(self, plugin_instance):
        """Initialize result processor service."""
        self.plugin = plugin_instance
    
    def create_output(self, options: ScanOptions) -> AzureSecurityOutput:
        """Create the final output object."""
        scan_completed = datetime.utcnow()
        duration = (scan_completed - self.plugin.scan_start).total_seconds() if self.plugin.scan_start else 0
        
        metadata = ScanMetadata(
            scan_id=self.plugin.scan_id,
            scan_type="deep" if options.deep_scan else ("quick" if options.quick_scan else "full"),
            started_at=self.plugin.scan_start or scan_completed,
            completed_at=scan_completed,
            duration_seconds=duration,
            caller_identity=self.plugin._caller_identity,
            tenant_id=self.plugin._tenant_id,
            subscriptions_scanned=len(self.plugin.subscriptions_scanned),
            resource_groups_scanned=len(self.plugin.resource_groups_scanned),
            resources_scanned=self.plugin.resources_scanned,
            total_checks=len(self.plugin.check_results),
            passed_checks=len([c for c in self.plugin.check_results if c.passed]),
            failed_checks=len([c for c in self.plugin.check_results if not c.passed]),
            error_checks=len([c for c in self.plugin.check_results if c.error]),
        )
        
        severity_summary = self._calculate_severity_summary(self.plugin.findings)
        
        category_summaries = self._calculate_category_summaries(self.plugin.findings)
        
        subscription_summaries = self._calculate_subscription_summaries(
            self.plugin.subscriptions_scanned,
            self.plugin.findings
        )
        
        critical_findings = [f for f in self.plugin.findings if f.severity == SeverityLevel.CRITICAL]
        
        recommendations = self._generate_recommendations()
        
        return AzureSecurityOutput(
            metadata=metadata,
            scan_options=options,
            check_results=self.plugin.check_results,
            findings=self.plugin.findings,
            severity_summary=severity_summary,
            category_summaries=category_summaries,
            subscription_summaries=subscription_summaries,
            privilege_escalation_paths=self.plugin.privilege_escalation_paths,
            exfiltration_paths=self.plugin.exfiltration_paths,
            persistence_mechanisms=self.plugin.persistence_mechanisms,
            critical_findings=critical_findings if critical_findings else None,
            risky_users=self.plugin.risky_users if self.plugin.risky_users else None,
            risky_service_principals=self.plugin.risky_service_principals if self.plugin.risky_service_principals else None,
            errors=self.plugin.errors if self.plugin.errors else None,
            warnings=self.plugin.warnings if self.plugin.warnings else None,
            prioritized_recommendations=recommendations if recommendations else None,
        )
    
    def _calculate_severity_summary(self, findings: List[SecurityFinding]) -> SeveritySummary:
        """Calculate severity summary from findings."""
        severity_summary = SeveritySummary()
        for finding in findings:
            if finding.severity == SeverityLevel.CRITICAL:
                severity_summary.critical += 1
            elif finding.severity == SeverityLevel.HIGH:
                severity_summary.high += 1
            elif finding.severity == SeverityLevel.MEDIUM:
                severity_summary.medium += 1
            elif finding.severity == SeverityLevel.LOW:
                severity_summary.low += 1
            else:
                severity_summary.info += 1
        severity_summary.total = len(findings)
        return severity_summary
    
    def _calculate_category_summaries(self, findings: List[SecurityFinding]) -> List[CategorySummary]:
        """Calculate category summaries from findings."""
        category_counts: Dict[SecurityCategory, Dict[str, int]] = {}
        for finding in findings:
            if finding.category not in category_counts:
                category_counts[finding.category] = {"total": 0, "critical": 0, "high": 0}
            category_counts[finding.category]["total"] += 1
            if finding.severity == SeverityLevel.CRITICAL:
                category_counts[finding.category]["critical"] += 1
            elif finding.severity == SeverityLevel.HIGH:
                category_counts[finding.category]["high"] += 1
        
        return [
            CategorySummary(
                category=cat,
                category_name=cat.value.replace("_", " ").title(),
                total_count=counts["total"],
                critical_count=counts["critical"],
                high_count=counts["high"],
            )
            for cat, counts in category_counts.items()
        ]
    
    def _calculate_subscription_summaries(
        self,
        subscriptions: set,
        findings: List[SecurityFinding]
    ) -> List[SubscriptionSummary]:
        """Calculate subscription summaries from findings."""
        subscription_summaries = []
        for sub_id in subscriptions:
            sub_findings = [f for f in findings if f.resource.subscription_id == sub_id]
            
            sub_severity = self._calculate_severity_summary(sub_findings)
            
            risk_score = sub_severity.critical * 10 + sub_severity.high * 5 + sub_severity.medium * 2
            
            subscription_summaries.append(SubscriptionSummary(
                subscription_id=sub_id,
                total_findings=len(sub_findings),
                severity_summary=sub_severity,
                risk_score=min(100.0, risk_score),
            ))
        
        return subscription_summaries
    
    def _generate_recommendations(self) -> List[str]:
        """Generate prioritized recommendations."""
        recommendations = []
        
        severity_summary = self._calculate_severity_summary(self.plugin.findings)
        
        if severity_summary.critical > 0:
            recommendations.append(f"URGENT: Address {severity_summary.critical} critical findings immediately")
        
        categories_found = set(f.category for f in self.plugin.findings)
        
        if SecurityCategory.DATA_EXPOSURE in categories_found:
            recommendations.append(
                "Remediate public storage/SQL: remove anonymous or overly broad RBAC, enforce private endpoints/firewall rules, enable Microsoft Defender data alerts, and re-scan."
            )
        
        if SecurityCategory.IDENTITY_MISCONFIGURATION in categories_found:
            recommendations.append("Implement Azure AD best practices - enable MFA, use PIM, review app permissions")
        
        if SecurityCategory.NETWORK_EXPOSURE in categories_found:
            recommendations.append("Restrict NSG rules - remove 0.0.0.0/0 inbound rules, use Azure Bastion")
        
        if SecurityCategory.LOGGING_GAP in categories_found:
            recommendations.append("Enable comprehensive logging - Defender for Cloud, diagnostic settings")
        
        if self.plugin.privilege_escalation_paths:
            recommendations.append(f"Review {len(self.plugin.privilege_escalation_paths)} privilege escalation paths")
        
        recommendations.extend([
            "Enable Microsoft Defender for Cloud for all resource types",
            "Implement Azure Policy for governance and compliance",
            "Use Azure Security Center Secure Score recommendations",
        ])
        
        return recommendations

