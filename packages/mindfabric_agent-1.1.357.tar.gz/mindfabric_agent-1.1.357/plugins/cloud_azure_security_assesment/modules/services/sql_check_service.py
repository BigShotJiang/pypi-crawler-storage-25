"""
SQL Check Service

Service for executing SQL-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class SQLCheckService:
    """Service for executing SQL security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize SQL check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute SQL check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_sql_public": self.check_sql_public,
            "check_sql_tde": self.check_sql_tde,
            "check_sql_auditing": self.check_sql_auditing,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_sql_public(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for publicly accessible SQL servers."""
        findings = []
        
        try:
            sql_client = self.plugin._get_sql_client(subscription_id)
            
            for server in sql_client.servers.list():
                # Check firewall rules
                rg = server.id.split("/")[4]
                
                for rule in sql_client.firewall_rules.list_by_server(rg, server.name):
                    if rule.start_ip_address == "0.0.0.0" and rule.end_ip_address == "255.255.255.255":
                        findings.append(self.plugin.finding_factory.create_finding(
                            check=check,
                            subscription_id=subscription_id,
                            resource_group=rg,
                            resource_type=AzureResourceType.SQL_SERVER,
                            resource_id=server.id,
                            name=server.name,
                            location=server.location,
                            description=f"SQL server '{server.name}' allows access from all IP addresses",
                            recommendation="Configure firewall rules to allow only specific IP ranges",
                            severity=SeverityLevel.CRITICAL,
                            evidence={"allow_all_ips": True},
                        ))
                        break
        except Exception as e:
            logger.error(f"SQL public check failed: {e}")
        
        return findings
    
    async def check_sql_tde(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for SQL databases without TDE."""
        findings = []
        
        # TDE is now enabled by default for Azure SQL
        
        return findings
    
    async def check_sql_auditing(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for SQL servers without auditing."""
        findings = []
        
        try:
            sql_client = self.plugin._get_sql_client(subscription_id)
            
            for server in sql_client.servers.list():
                rg = server.id.split("/")[4]
                
                try:
                    audit_settings = sql_client.server_blob_auditing_policies.get(rg, server.name)
                    
                    if audit_settings.state != "Enabled":
                        findings.append(self.plugin.finding_factory.create_finding(
                            check=check,
                            subscription_id=subscription_id,
                            resource_group=rg,
                            resource_type=AzureResourceType.SQL_SERVER,
                            resource_id=server.id,
                            name=server.name,
                            location=server.location,
                            description=f"SQL server '{server.name}' does not have auditing enabled",
                            recommendation="Enable auditing for compliance and security monitoring",
                            severity=SeverityLevel.MEDIUM,
                            evidence={"auditing_enabled": False},
                        ))
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"SQL auditing check failed: {e}")
        
        return findings

