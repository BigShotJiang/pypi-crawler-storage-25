"""
AKS Check Service

Service for executing AKS-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class AKSCheckService:
    """Service for executing AKS security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize AKS check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute AKS check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_aks_public_api": self.check_aks_public_api,
            "check_aks_local_accounts": self.check_aks_local_accounts,
            "check_aks_azure_ad": self.check_aks_azure_ad,
            "check_aks_network_policy": self.check_aks_network_policy,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_aks_public_api(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for AKS clusters with public API server."""
        findings = []
        
        try:
            aks_client = self.plugin._get_aks_client(subscription_id)
            
            for cluster in aks_client.managed_clusters.list():
                api_access = cluster.api_server_access_profile
                
                if not api_access or not api_access.enable_private_cluster:
                    # Check if authorized IP ranges are set
                    if not api_access or not api_access.authorized_ip_ranges:
                        findings.append(self.plugin.finding_factory.create_finding(
                            check=check,
                            subscription_id=subscription_id,
                            resource_group=cluster.id.split("/")[4],
                            resource_type=AzureResourceType.AKS_CLUSTER,
                            resource_id=cluster.id,
                            name=cluster.name,
                            location=cluster.location,
                            description=f"AKS cluster '{cluster.name}' has public API without IP restrictions",
                            recommendation="Enable private cluster or configure authorized IP ranges",
                            severity=SeverityLevel.HIGH,
                            evidence={"public_api": True, "authorized_ip_ranges": []},
                        ))
        except Exception as e:
            logger.error(f"AKS public API check failed: {e}")
        
        return findings
    
    async def check_aks_local_accounts(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for AKS clusters with local accounts enabled."""
        findings = []
        
        try:
            aks_client = self.plugin._get_aks_client(subscription_id)
            
            for cluster in aks_client.managed_clusters.list():
                if cluster.disable_local_accounts != True:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=cluster.id.split("/")[4],
                        resource_type=AzureResourceType.AKS_CLUSTER,
                        resource_id=cluster.id,
                        name=cluster.name,
                        location=cluster.location,
                        description=f"AKS cluster '{cluster.name}' has local accounts enabled",
                        recommendation="Disable local accounts and use Azure AD authentication",
                        severity=SeverityLevel.HIGH,
                        evidence={"local_accounts_enabled": True},
                    ))
        except Exception as e:
            logger.error(f"AKS local accounts check failed: {e}")
        
        return findings
    
    async def check_aks_azure_ad(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for AKS clusters without Azure AD integration."""
        findings = []
        
        try:
            aks_client = self.plugin._get_aks_client(subscription_id)
            
            for cluster in aks_client.managed_clusters.list():
                aad_profile = cluster.aad_profile
                
                if not aad_profile or not aad_profile.managed:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=cluster.id.split("/")[4],
                        resource_type=AzureResourceType.AKS_CLUSTER,
                        resource_id=cluster.id,
                        name=cluster.name,
                        location=cluster.location,
                        description=f"AKS cluster '{cluster.name}' does not have Azure AD integration",
                        recommendation="Enable managed Azure AD integration",
                        severity=SeverityLevel.HIGH,
                        evidence={"azure_ad_enabled": False},
                    ))
        except Exception as e:
            logger.error(f"AKS Azure AD check failed: {e}")
        
        return findings
    
    async def check_aks_network_policy(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for AKS clusters without network policy."""
        findings = []
        
        try:
            aks_client = self.plugin._get_aks_client(subscription_id)
            
            for cluster in aks_client.managed_clusters.list():
                network_profile = cluster.network_profile
                
                if not network_profile or not network_profile.network_policy:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=cluster.id.split("/")[4],
                        resource_type=AzureResourceType.AKS_CLUSTER,
                        resource_id=cluster.id,
                        name=cluster.name,
                        location=cluster.location,
                        description=f"AKS cluster '{cluster.name}' does not have network policy enabled",
                        recommendation="Enable Azure or Calico network policy",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"network_policy": None},
                    ))
        except Exception as e:
            logger.error(f"AKS network policy check failed: {e}")
        
        return findings

