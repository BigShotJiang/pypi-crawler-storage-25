"""
App Service Check Service

Service for executing App Service-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class AppServiceCheckService:
    """Service for executing App Service security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize App Service check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute App Service check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_app_https": self.check_app_https,
            "check_app_remote_debug": self.check_app_remote_debug,
            "check_app_ftp": self.check_app_ftp,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_app_https(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for App Services without HTTPS-only."""
        findings = []
        
        try:
            web_client = self.plugin._get_web_client(subscription_id)
            
            for app in web_client.web_apps.list():
                if not app.https_only:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=app.resource_group,
                        resource_type=AzureResourceType.APP_SERVICE,
                        resource_id=app.id,
                        name=app.name,
                        location=app.location,
                        description=f"App Service '{app.name}' does not enforce HTTPS",
                        recommendation="Enable 'HTTPS Only' setting",
                        severity=SeverityLevel.HIGH,
                        evidence={"https_only": False},
                    ))
        except Exception as e:
            logger.error(f"App HTTPS check failed: {e}")
        
        return findings
    
    async def check_app_remote_debug(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for App Services with remote debugging enabled."""
        findings = []
        
        try:
            web_client = self.plugin._get_web_client(subscription_id)
            
            for app in web_client.web_apps.list():
                config = web_client.web_apps.get_configuration(app.resource_group, app.name)
                
                if config.remote_debugging_enabled:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=app.resource_group,
                        resource_type=AzureResourceType.APP_SERVICE,
                        resource_id=app.id,
                        name=app.name,
                        location=app.location,
                        description=f"App Service '{app.name}' has remote debugging enabled",
                        recommendation="Disable remote debugging in production",
                        severity=SeverityLevel.HIGH,
                        evidence={"remote_debugging": True},
                    ))
        except Exception as e:
            logger.error(f"App remote debug check failed: {e}")
        
        return findings
    
    async def check_app_ftp(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for App Services with FTP enabled."""
        findings = []
        
        try:
            web_client = self.plugin._get_web_client(subscription_id)
            
            for app in web_client.web_apps.list():
                config = web_client.web_apps.get_configuration(app.resource_group, app.name)
                
                if config.ftp_state != "Disabled":
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=app.resource_group,
                        resource_type=AzureResourceType.APP_SERVICE,
                        resource_id=app.id,
                        name=app.name,
                        location=app.location,
                        description=f"App Service '{app.name}' has FTP/FTPS enabled",
                        recommendation="Disable FTP and use deployment slots or CI/CD",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"ftp_state": config.ftp_state},
                    ))
        except Exception as e:
            logger.error(f"App FTP check failed: {e}")
        
        return findings

