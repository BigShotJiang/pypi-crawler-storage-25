"""
Finding Factory Service

Service for creating SecurityFinding objects for Azure security assessment.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from ...proto import (
    AzureResourceIdentifier,
    AzureResourceType,
    FindingStatus,
    SecurityFinding,
    SeverityLevel,
)

from ..utils import calculate_risk_score, get_compliance_mappings, get_mitre_reference


class FindingFactoryService:
    """Service for creating SecurityFinding objects for Azure."""
    
    def __init__(self, plugin_instance):
        """Initialize finding factory service."""
        self.plugin = plugin_instance
    
    def create_finding(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        resource_type: AzureResourceType,
        resource_id: str,
        name: str,
        description: str,
        recommendation: str,
        severity: Optional[SeverityLevel] = None,
        location: Optional[str] = None,
        evidence: Optional[Dict[str, Any]] = None,
        remediation_commands: Optional[List[str]] = None,
    ) -> SecurityFinding:
        """Create a security finding."""
        
        finding_severity = severity or check["severity"]
        
        risk_score = calculate_risk_score(
            finding_severity,
            "easy" if finding_severity in [SeverityLevel.CRITICAL, SeverityLevel.HIGH] else "medium",
            "subscription"
        )
        
        mitre_ref = get_mitre_reference(check["sub_category"])
        compliance_mappings = get_compliance_mappings(check["sub_category"])
        
        return SecurityFinding(
            id=str(uuid.uuid4()),
            name=f"{check['name']} - {name}",
            description=description,
            category=check["category"],
            sub_category=check["sub_category"],
            severity=finding_severity,
            status=FindingStatus.ACTIVE,
            resource=AzureResourceIdentifier(
                resource_type=resource_type,
                subscription_id=subscription_id,
                resource_group=resource_group,
                resource_id=resource_id,
                name=name,
                location=location,
                tenant_id=self.plugin._tenant_id,
            ),
            mitre_attack=mitre_ref,
            compliance_mappings=compliance_mappings if compliance_mappings else None,
            evidence=evidence,
            risk_score=risk_score,
            exploitability="easy" if finding_severity == SeverityLevel.CRITICAL else "medium",
            impact_scope="subscription",
            recommendation=recommendation,
            remediation_commands=remediation_commands,
            detected_at=datetime.utcnow(),
            detection_method="api_check",
            confidence=0.95,
        )

