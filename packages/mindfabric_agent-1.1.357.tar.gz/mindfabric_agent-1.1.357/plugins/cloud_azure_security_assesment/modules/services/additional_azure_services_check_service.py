"""
Additional Azure Services Security Check Service

Covers additional Azure services security assessments:
- Azure Functions (Managed identity, triggers, keys)
- Azure DevOps (Pipelines, artifacts, service connections)
- Azure Container Instances (ACI)
- Azure Service Bus (Message queue security)
- Azure Cosmos DB (Access control, firewall)
- Azure Logic Apps
- Azure Event Grid
- Azure Data Factory
- Azure Synapse Analytics
- Azure Databricks

MITRE ATT&CK: T1190, T1552, T1098, T1078
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
import re
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class AdditionalAzureServicesCheckService:
    """Service for executing additional Azure services security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize additional Azure services check service."""
        self.plugin = plugin_instance
    
    # =========================================================================
    # Azure Functions Security Checks
    # =========================================================================
    
    async def check_function_app_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Functions security.
        
        Checks:
        - Managed identity configuration
        - HTTP trigger authentication
        - Function keys security
        - App settings for secrets
        - Runtime version
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            web_client = self.plugin._get_web_client(subscription_id)
            
            for func_app in web_client.web_apps.list():
                if func_app.kind and "functionapp" in func_app.kind.lower():
                    func_name = func_app.name
                    rg = func_app.id.split("/")[4]
                    
                    # Check managed identity
                    if not func_app.identity:
                        findings.append(self._create_finding(
                            check_id="function_no_managed_identity",
                            resource_id=func_app.id,
                            resource_name=func_name,
                            severity="medium",
                            title="Function app has no managed identity",
                            description=f"Function app '{func_name}' does not have managed identity enabled",
                            recommendation="Enable system-assigned or user-assigned managed identity",
                            subscription_id=subscription_id,
                        ))
                    
                    # Check HTTPS only
                    if not func_app.https_only:
                        findings.append(self._create_finding(
                            check_id="function_https_disabled",
                            resource_id=func_app.id,
                            resource_name=func_name,
                            severity="high",
                            title="Function app allows HTTP",
                            description=f"Function app '{func_name}' does not require HTTPS",
                            recommendation="Enable HTTPS-only setting",
                            subscription_id=subscription_id,
                        ))
                    
                    # Check authentication
                    try:
                        config = web_client.web_apps.get_configuration(rg, func_name)
                        
                        # Check client cert mode
                        if config.client_cert_mode == "Optional" or not config.client_cert_enabled:
                            findings.append(self._create_finding(
                                check_id="function_weak_client_cert",
                                resource_id=func_app.id,
                                resource_name=func_name,
                                severity="low",
                                title="Function app client certificates optional",
                                description=f"Function app '{func_name}' does not require client certificates",
                                recommendation="Consider enabling client certificate requirement",
                                subscription_id=subscription_id,
                            ))
                        
                        # Check minimum TLS version
                        if config.min_tls_version and config.min_tls_version < "1.2":
                            findings.append(self._create_finding(
                                check_id="function_weak_tls",
                                resource_id=func_app.id,
                                resource_name=func_name,
                                severity="medium",
                                title="Function app allows weak TLS",
                                description=f"Function app '{func_name}' allows TLS version {config.min_tls_version}",
                                recommendation="Set minimum TLS version to 1.2",
                                subscription_id=subscription_id,
                            ))
                    except Exception:
                        pass
                    
                    # Check app settings for secrets
                    try:
                        settings = web_client.web_apps.list_application_settings(rg, func_name)
                        secret_indicators = ["password", "secret", "key", "token", "credential", "apikey"]
                        
                        for key, value in settings.properties.items():
                            if any(indicator in key.lower() for indicator in secret_indicators):
                                # Check if it's a Key Vault reference
                                if not value.startswith("@Microsoft.KeyVault"):
                                    findings.append(self._create_finding(
                                        check_id="function_plaintext_secret",
                                        resource_id=func_app.id,
                                        resource_name=func_name,
                                        severity="critical",
                                        title="Function app has plaintext secrets",
                                        description=f"Function app '{func_name}' has potential secret in app setting '{key}'",
                                        recommendation="Use Key Vault references for sensitive settings",
                                        subscription_id=subscription_id,
                                    ))
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Function app security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Container Instances (ACI) Security Checks
    # =========================================================================
    
    async def check_container_instances_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Container Instances security.
        
        Checks:
        - Public IP exposure
        - Container privileges
        - Environment secrets
        - Network isolation
        - Image registry security
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            # Get Container Instance client
            from azure.mgmt.containerinstance import ContainerInstanceManagementClient
            credential = self.plugin._get_credential()
            aci_client = ContainerInstanceManagementClient(credential, subscription_id)
            
            for container_group in aci_client.container_groups.list():
                cg_name = container_group.name
                rg = container_group.id.split("/")[4]
                
                # Check for public IP
                if container_group.ip_address and container_group.ip_address.type == "Public":
                    findings.append(self._create_finding(
                        check_id="aci_public_ip",
                        resource_id=container_group.id,
                        resource_name=cg_name,
                        severity="high",
                        title="Container group has public IP",
                        description=f"Container group '{cg_name}' is exposed with public IP",
                        recommendation="Use private IP or Virtual Network integration",
                        subscription_id=subscription_id,
                    ))
                
                # Check containers
                for container in container_group.containers:
                    container_name = container.name
                    
                    # Check for privileged container
                    if container.security_context:
                        if container.security_context.privileged:
                            findings.append(self._create_finding(
                                check_id="aci_privileged_container",
                                resource_id=container_group.id,
                                resource_name=f"{cg_name}/{container_name}",
                                severity="critical",
                                title="Container runs in privileged mode",
                                description=f"Container '{container_name}' in group '{cg_name}' runs privileged",
                                recommendation="Remove privileged mode unless absolutely necessary",
                                subscription_id=subscription_id,
                            ))
                        
                        if container.security_context.run_as_user == 0:
                            findings.append(self._create_finding(
                                check_id="aci_root_user",
                                resource_id=container_group.id,
                                resource_name=f"{cg_name}/{container_name}",
                                severity="medium",
                                title="Container runs as root",
                                description=f"Container '{container_name}' runs as root user",
                                recommendation="Run container as non-root user",
                                subscription_id=subscription_id,
                            ))
                    
                    # Check environment variables for secrets
                    if container.environment_variables:
                        secret_indicators = ["password", "secret", "key", "token", "credential"]
                        for env_var in container.environment_variables:
                            if any(indicator in env_var.name.lower() for indicator in secret_indicators):
                                if env_var.value and not env_var.secure_value:
                                    findings.append(self._create_finding(
                                        check_id="aci_env_secret",
                                        resource_id=container_group.id,
                                        resource_name=f"{cg_name}/{container_name}",
                                        severity="critical",
                                        title="Container has plaintext secrets in environment",
                                        description=f"Container '{container_name}' has potential secret in env var '{env_var.name}'",
                                        recommendation="Use secureValue for sensitive environment variables",
                                        subscription_id=subscription_id,
                                    ))
        except ImportError:
            logger.warning("Azure Container Instance SDK not available")
        except Exception as e:
            logger.error(f"Container instances security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Service Bus Security Checks
    # =========================================================================
    
    async def check_service_bus_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Service Bus security.
        
        Checks:
        - Public network access
        - Authorization rules
        - Encryption
        - Zone redundancy
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.servicebus import ServiceBusManagementClient
            credential = self.plugin._get_credential()
            sb_client = ServiceBusManagementClient(credential, subscription_id)
            
            for namespace in sb_client.namespaces.list():
                ns_name = namespace.name
                rg = namespace.id.split("/")[4]
                
                # Check public network access
                if namespace.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="servicebus_public_access",
                        resource_id=namespace.id,
                        resource_name=ns_name,
                        severity="medium",
                        title="Service Bus namespace has public access",
                        description=f"Service Bus namespace '{ns_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check minimum TLS version
                if namespace.minimum_tls_version and namespace.minimum_tls_version < "1.2":
                    findings.append(self._create_finding(
                        check_id="servicebus_weak_tls",
                        resource_id=namespace.id,
                        resource_name=ns_name,
                        severity="medium",
                        title="Service Bus allows weak TLS",
                        description=f"Service Bus namespace '{ns_name}' allows TLS {namespace.minimum_tls_version}",
                        recommendation="Set minimum TLS version to 1.2",
                        subscription_id=subscription_id,
                    ))
                
                # Check authorization rules
                try:
                    for rule in sb_client.namespaces.list_authorization_rules(rg, ns_name):
                        # Check for overly permissive rules
                        if rule.rights and "Manage" in rule.rights:
                            findings.append(self._create_finding(
                                check_id="servicebus_manage_rights",
                                resource_id=namespace.id,
                                resource_name=f"{ns_name}/{rule.name}",
                                severity="medium",
                                title="Service Bus rule has Manage rights",
                                description=f"Authorization rule '{rule.name}' has Manage rights",
                                recommendation="Review and restrict authorization rules",
                                subscription_id=subscription_id,
                            ))
                except Exception:
                    pass
        except ImportError:
            logger.warning("Azure Service Bus SDK not available")
        except Exception as e:
            logger.error(f"Service Bus security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Cosmos DB Security Checks
    # =========================================================================
    
    async def check_cosmos_db_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Cosmos DB security.
        
        Checks:
        - Public network access
        - Firewall rules
        - Encryption
        - Analytical storage
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.cosmosdb import CosmosDBManagementClient
            credential = self.plugin._get_credential()
            cosmos_client = CosmosDBManagementClient(credential, subscription_id)
            
            for account in cosmos_client.database_accounts.list():
                acc_name = account.name
                
                # Check public network access
                if account.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="cosmosdb_public_access",
                        resource_id=account.id,
                        resource_name=acc_name,
                        severity="high",
                        title="Cosmos DB has public network access",
                        description=f"Cosmos DB account '{acc_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check IP firewall rules (if empty = allow all)
                if account.ip_rules is None or len(account.ip_rules) == 0:
                    if account.is_virtual_network_filter_enabled is False:
                        findings.append(self._create_finding(
                            check_id="cosmosdb_no_firewall",
                            resource_id=account.id,
                            resource_name=acc_name,
                            severity="high",
                            title="Cosmos DB has no firewall rules",
                            description=f"Cosmos DB account '{acc_name}' has no IP firewall rules configured",
                            recommendation="Configure IP firewall rules or virtual network service endpoints",
                            subscription_id=subscription_id,
                        ))
                
                # Check disable key based metadata write access
                if not account.disable_key_based_metadata_write_access:
                    findings.append(self._create_finding(
                        check_id="cosmosdb_key_metadata_write",
                        resource_id=account.id,
                        resource_name=acc_name,
                        severity="medium",
                        title="Cosmos DB allows key-based metadata writes",
                        description=f"Cosmos DB account '{acc_name}' allows key-based metadata write access",
                        recommendation="Disable key-based metadata write access",
                        subscription_id=subscription_id,
                    ))
                
                # Check local authentication
                if not account.disable_local_auth:
                    findings.append(self._create_finding(
                        check_id="cosmosdb_local_auth",
                        resource_id=account.id,
                        resource_name=acc_name,
                        severity="medium",
                        title="Cosmos DB allows local authentication",
                        description=f"Cosmos DB account '{acc_name}' allows local authentication with keys",
                        recommendation="Disable local auth and use Azure AD authentication",
                        subscription_id=subscription_id,
                    ))
        except ImportError:
            logger.warning("Azure Cosmos DB SDK not available")
        except Exception as e:
            logger.error(f"Cosmos DB security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Logic Apps Security Checks
    # =========================================================================
    
    async def check_logic_apps_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Logic Apps security.
        
        Checks:
        - Access control
        - Managed identity
        - Trigger authentication
        - Secure inputs/outputs
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.logic import LogicManagementClient
            credential = self.plugin._get_credential()
            logic_client = LogicManagementClient(credential, subscription_id)
            
            for workflow in logic_client.workflows.list_by_subscription():
                wf_name = workflow.name
                rg = workflow.id.split("/")[4]
                
                # Check managed identity
                if not workflow.identity:
                    findings.append(self._create_finding(
                        check_id="logicapp_no_managed_identity",
                        resource_id=workflow.id,
                        resource_name=wf_name,
                        severity="medium",
                        title="Logic App has no managed identity",
                        description=f"Logic App '{wf_name}' does not have managed identity enabled",
                        recommendation="Enable system-assigned or user-assigned managed identity",
                        subscription_id=subscription_id,
                    ))
                
                # Check access control
                if workflow.access_control:
                    # Check triggers access
                    if workflow.access_control.triggers:
                        triggers = workflow.access_control.triggers
                        if triggers.allowed_caller_ip_addresses is None:
                            findings.append(self._create_finding(
                                check_id="logicapp_trigger_no_ip_restriction",
                                resource_id=workflow.id,
                                resource_name=wf_name,
                                severity="medium",
                                title="Logic App trigger has no IP restrictions",
                                description=f"Logic App '{wf_name}' trigger allows all IP addresses",
                                recommendation="Configure IP address restrictions for triggers",
                                subscription_id=subscription_id,
                            ))
        except ImportError:
            logger.warning("Azure Logic Apps SDK not available")
        except Exception as e:
            logger.error(f"Logic Apps security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Event Grid Security Checks
    # =========================================================================
    
    async def check_event_grid_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Event Grid security.
        
        Checks:
        - Topic public access
        - Input schema validation
        - Managed identity
        - Private endpoints
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.eventgrid import EventGridManagementClient
            credential = self.plugin._get_credential()
            eg_client = EventGridManagementClient(credential, subscription_id)
            
            # Check topics
            for topic in eg_client.topics.list_by_subscription():
                topic_name = topic.name
                
                # Check public network access
                if topic.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="eventgrid_topic_public",
                        resource_id=topic.id,
                        resource_name=topic_name,
                        severity="medium",
                        title="Event Grid topic has public access",
                        description=f"Event Grid topic '{topic_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check local authentication
                if not topic.disable_local_auth:
                    findings.append(self._create_finding(
                        check_id="eventgrid_topic_local_auth",
                        resource_id=topic.id,
                        resource_name=topic_name,
                        severity="low",
                        title="Event Grid topic allows local authentication",
                        description=f"Event Grid topic '{topic_name}' allows local authentication with keys",
                        recommendation="Disable local auth and use Azure AD authentication",
                        subscription_id=subscription_id,
                    ))
            
            # Check domains
            for domain in eg_client.domains.list_by_subscription():
                domain_name = domain.name
                
                if domain.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="eventgrid_domain_public",
                        resource_id=domain.id,
                        resource_name=domain_name,
                        severity="medium",
                        title="Event Grid domain has public access",
                        description=f"Event Grid domain '{domain_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
        except ImportError:
            logger.warning("Azure Event Grid SDK not available")
        except Exception as e:
            logger.error(f"Event Grid security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Data Factory Security Checks
    # =========================================================================
    
    async def check_data_factory_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Data Factory security.
        
        Checks:
        - Public network access
        - Managed identity
        - Git integration security
        - Linked services
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.datafactory import DataFactoryManagementClient
            credential = self.plugin._get_credential()
            adf_client = DataFactoryManagementClient(credential, subscription_id)
            
            for factory in adf_client.factories.list():
                factory_name = factory.name
                rg = factory.id.split("/")[4]
                
                # Check public network access
                if factory.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="datafactory_public_access",
                        resource_id=factory.id,
                        resource_name=factory_name,
                        severity="medium",
                        title="Data Factory has public network access",
                        description=f"Data Factory '{factory_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check managed identity
                if not factory.identity:
                    findings.append(self._create_finding(
                        check_id="datafactory_no_managed_identity",
                        resource_id=factory.id,
                        resource_name=factory_name,
                        severity="medium",
                        title="Data Factory has no managed identity",
                        description=f"Data Factory '{factory_name}' does not have managed identity enabled",
                        recommendation="Enable system-assigned or user-assigned managed identity",
                        subscription_id=subscription_id,
                    ))
                
                # Check Git configuration
                if factory.repo_configuration:
                    # Has Git integration - check for security concerns
                    if hasattr(factory.repo_configuration, 'account_name'):
                        findings.append(self._create_finding(
                            check_id="datafactory_git_integration",
                            resource_id=factory.id,
                            resource_name=factory_name,
                            severity="info",
                            title="Data Factory has Git integration",
                            description=f"Data Factory '{factory_name}' has Git repository configured",
                            recommendation="Ensure Git repository access is properly secured",
                            subscription_id=subscription_id,
                        ))
        except ImportError:
            logger.warning("Azure Data Factory SDK not available")
        except Exception as e:
            logger.error(f"Data Factory security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Synapse Analytics Security Checks
    # =========================================================================
    
    async def check_synapse_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Synapse Analytics security.
        
        Checks:
        - Public network access
        - Managed identity
        - SQL pools security
        - Firewall rules
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.synapse import SynapseManagementClient
            credential = self.plugin._get_credential()
            synapse_client = SynapseManagementClient(credential, subscription_id)
            
            for workspace in synapse_client.workspaces.list():
                ws_name = workspace.name
                rg = workspace.id.split("/")[4]
                
                # Check public network access
                if workspace.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="synapse_public_access",
                        resource_id=workspace.id,
                        resource_name=ws_name,
                        severity="high",
                        title="Synapse workspace has public network access",
                        description=f"Synapse workspace '{ws_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check managed identity
                if not workspace.identity:
                    findings.append(self._create_finding(
                        check_id="synapse_no_managed_identity",
                        resource_id=workspace.id,
                        resource_name=ws_name,
                        severity="medium",
                        title="Synapse workspace has no managed identity",
                        description=f"Synapse workspace '{ws_name}' does not have managed identity",
                        recommendation="Enable system-assigned managed identity",
                        subscription_id=subscription_id,
                    ))
                
                # Check Azure AD only authentication
                if hasattr(workspace, 'azure_ad_only_authentication') and not workspace.azure_ad_only_authentication:
                    findings.append(self._create_finding(
                        check_id="synapse_sql_auth",
                        resource_id=workspace.id,
                        resource_name=ws_name,
                        severity="medium",
                        title="Synapse workspace allows SQL authentication",
                        description=f"Synapse workspace '{ws_name}' allows SQL authentication",
                        recommendation="Enable Azure AD-only authentication",
                        subscription_id=subscription_id,
                    ))
                
                # Check firewall rules
                try:
                    rules = synapse_client.ip_firewall_rules.list_by_workspace(rg, ws_name)
                    for rule in rules:
                        if rule.start_ip_address == "0.0.0.0" and rule.end_ip_address == "255.255.255.255":
                            findings.append(self._create_finding(
                                check_id="synapse_firewall_open",
                                resource_id=workspace.id,
                                resource_name=f"{ws_name}/{rule.name}",
                                severity="critical",
                                title="Synapse firewall allows all IPs",
                                description=f"Synapse workspace '{ws_name}' has firewall rule allowing all IPs",
                                recommendation="Restrict firewall rules to specific IP ranges",
                                subscription_id=subscription_id,
                            ))
                except Exception:
                    pass
        except ImportError:
            logger.warning("Azure Synapse SDK not available")
        except Exception as e:
            logger.error(f"Synapse security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Azure Databricks Security Checks
    # =========================================================================
    
    async def check_databricks_security(
        self,
        subscription_id: str,
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """
        Check Azure Databricks security.
        
        Checks:
        - Public network access
        - VNet integration
        - DBFS encryption
        - Cluster security
        
        Args:
            subscription_id: Azure subscription ID
            check: Check configuration
            options: Scan options
            
        Returns:
            List of security findings
        """
        findings = []
        
        try:
            from azure.mgmt.databricks import AzureDatabricksManagementClient
            credential = self.plugin._get_credential()
            databricks_client = AzureDatabricksManagementClient(credential, subscription_id)
            
            for workspace in databricks_client.workspaces.list_by_subscription():
                ws_name = workspace.name
                
                # Check public network access
                if workspace.public_network_access == "Enabled":
                    findings.append(self._create_finding(
                        check_id="databricks_public_access",
                        resource_id=workspace.id,
                        resource_name=ws_name,
                        severity="high",
                        title="Databricks workspace has public network access",
                        description=f"Databricks workspace '{ws_name}' allows public network access",
                        recommendation="Disable public network access and use private endpoints",
                        subscription_id=subscription_id,
                    ))
                
                # Check VNet injection
                if not workspace.parameters or not workspace.parameters.custom_virtual_network_id:
                    findings.append(self._create_finding(
                        check_id="databricks_no_vnet",
                        resource_id=workspace.id,
                        resource_name=ws_name,
                        severity="medium",
                        title="Databricks workspace not VNet-injected",
                        description=f"Databricks workspace '{ws_name}' is not deployed in a VNet",
                        recommendation="Deploy Databricks workspace in a VNet for network isolation",
                        subscription_id=subscription_id,
                    ))
                
                # Check DBFS encryption
                if workspace.parameters:
                    if not workspace.parameters.prepare_encryption:
                        findings.append(self._create_finding(
                            check_id="databricks_no_cmk",
                            resource_id=workspace.id,
                            resource_name=ws_name,
                            severity="low",
                            title="Databricks DBFS not encrypted with CMK",
                            description=f"Databricks workspace '{ws_name}' does not use customer-managed keys",
                            recommendation="Enable customer-managed keys for DBFS encryption",
                            subscription_id=subscription_id,
                        ))
        except ImportError:
            logger.warning("Azure Databricks SDK not available")
        except Exception as e:
            logger.error(f"Databricks security check failed: {e}")
        
        return findings
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _create_finding(
        self,
        check_id: str,
        resource_id: str,
        resource_name: str,
        severity: str,
        title: str,
        description: str,
        recommendation: str,
        subscription_id: str,
    ) -> Dict[str, Any]:
        """Create a finding dictionary."""
        return {
            "check_id": check_id,
            "resource_id": resource_id,
            "resource_name": resource_name,
            "severity": severity,
            "title": title,
            "description": description,
            "recommendation": recommendation,
            "subscription_id": subscription_id,
        }
    
    async def run_all_checks(
        self,
        subscription_id: str,
        options: ScanOptions
    ) -> List[Dict[str, Any]]:
        """
        Run all additional Azure service checks.
        
        Args:
            subscription_id: Azure subscription ID
            options: Scan options
            
        Returns:
            Aggregated list of all findings
        """
        all_findings = []
        check = {}  # Empty check dict for compatibility
        
        # Azure Functions
        findings = await self.check_function_app_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Container Instances
        findings = await self.check_container_instances_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Service Bus
        findings = await self.check_service_bus_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Cosmos DB
        findings = await self.check_cosmos_db_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Logic Apps
        findings = await self.check_logic_apps_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Event Grid
        findings = await self.check_event_grid_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Data Factory
        findings = await self.check_data_factory_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Synapse Analytics
        findings = await self.check_synapse_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        # Databricks
        findings = await self.check_databricks_security(subscription_id, check, options)
        all_findings.extend(findings)
        
        return all_findings

