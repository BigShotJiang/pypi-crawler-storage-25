"""
Monitoring Check Service

Service for executing monitoring and governance-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class MonitoringCheckService:
    """Service for executing monitoring and governance security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize monitoring check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute monitoring check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_defender_enabled": self.check_defender_enabled,
            "check_diagnostic_logs": self.check_diagnostic_logs,
            "check_owner_count": self.check_owner_count,
            "check_classic_admin": self.check_classic_admin,
            "check_azure_policy": self.check_azure_policy,
            "check_resource_locks": self.check_resource_locks,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_defender_enabled(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check if Defender for Cloud is enabled."""
        findings = []
        
        try:
            security_client = self.plugin._get_security_client(subscription_id)
            
            # Check pricing tiers for various resource types
            resource_types = ["VirtualMachines", "SqlServers", "AppServices", "StorageAccounts", "KeyVaults"]
            
            for rt in resource_types:
                try:
                    pricing = security_client.pricings.get(rt)
                    
                    if pricing.pricing_tier == "Free":
                        findings.append(self.plugin.finding_factory.create_finding(
                            check=check,
                            subscription_id=subscription_id,
                            resource_group=None,
                            resource_type=AzureResourceType.DEFENDER_PLAN,
                            resource_id=f"/subscriptions/{subscription_id}/providers/Microsoft.Security/pricings/{rt}",
                            name=f"Defender for {rt}",
                            description=f"Defender for {rt} is not enabled (Free tier)",
                            recommendation=f"Enable Defender for {rt} for enhanced threat protection",
                            severity=SeverityLevel.HIGH,
                            evidence={"resource_type": rt, "pricing_tier": "Free"},
                        ))
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"Defender check failed: {e}")
        
        return findings
    
    async def check_diagnostic_logs(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for resources without diagnostic logs."""
        findings = []
        
        # Requires Monitor API
        
        return findings
    
    async def check_owner_count(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for excessive Owner role assignments."""
        findings = []
        
        # Requires Authorization API
        
        return findings
    
    async def check_classic_admin(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for classic administrators."""
        findings = []
        
        # Requires Authorization API
        
        return findings
    
    async def check_azure_policy(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Azure Policy assignments."""
        findings = []
        
        try:
            resource_client = self.plugin._get_resource_client(subscription_id)
            
            # Check if any policy assignments exist
            assignments = list(resource_client.policy_assignments.list())
            
            if not assignments:
                findings.append(self.plugin.finding_factory.create_finding(
                    check=check,
                    subscription_id=subscription_id,
                    resource_group=None,
                    resource_type=AzureResourceType.POLICY_ASSIGNMENT,
                    resource_id=f"/subscriptions/{subscription_id}",
                    name="Azure Policy",
                    description="No Azure Policy assignments found",
                    recommendation="Implement Azure Policy for governance and compliance",
                    severity=SeverityLevel.HIGH,
                    evidence={"policy_count": 0},
                ))
        except Exception as e:
            logger.error(f"Azure Policy check failed: {e}")
        
        return findings
    
    async def check_resource_locks(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for resource locks on critical resources."""
        findings = []
        
        # Would check for locks on critical resources
        
        return findings

