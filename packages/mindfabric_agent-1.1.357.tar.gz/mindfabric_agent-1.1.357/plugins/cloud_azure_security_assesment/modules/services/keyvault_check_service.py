"""
Key Vault Check Service

Service for executing Key Vault-related security checks.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

import logging
from typing import Any, Dict, List, Optional

from ...proto import AzureResourceType, ScanOptions, SecurityFinding, SeverityLevel

logger = logging.getLogger(__name__)


class KeyVaultCheckService:
    """Service for executing Key Vault security checks."""
    
    def __init__(self, plugin_instance):
        """Initialize Key Vault check service."""
        self.plugin = plugin_instance
    
    async def execute_check_method(
        self,
        check: Dict[str, Any],
        subscription_id: Optional[str],
        resource_group: Optional[str],
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Execute Key Vault check method."""
        check_fn = check.get("check_fn", "")
        
        method_map = {
            "check_keyvault_public": self.check_keyvault_public,
            "check_keyvault_soft_delete": self.check_keyvault_soft_delete,
            "check_secret_expiry": self.check_secret_expiry,
        }
        
        method = method_map.get(check_fn)
        if method:
            return await method(subscription_id, resource_group, check, options)
        
        return []
    
    async def check_keyvault_public(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Key Vaults with public network access."""
        findings = []
        
        try:
            kv_client = self.plugin._get_keyvault_client(subscription_id)
            
            for vault in kv_client.vaults.list():
                if vault.properties.public_network_access == "Enabled":
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=vault.id.split("/")[4],
                        resource_type=AzureResourceType.KEY_VAULT,
                        resource_id=vault.id,
                        name=vault.name,
                        location=vault.location,
                        description=f"Key Vault '{vault.name}' has public network access enabled",
                        recommendation="Disable public access and use private endpoints",
                        severity=SeverityLevel.HIGH,
                        evidence={"public_network_access": "Enabled"},
                    ))
        except Exception as e:
            logger.error(f"Key Vault public check failed: {e}")
        
        return findings
    
    async def check_keyvault_soft_delete(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for Key Vaults without soft delete."""
        findings = []
        
        try:
            kv_client = self.plugin._get_keyvault_client(subscription_id)
            
            for vault in kv_client.vaults.list():
                if not vault.properties.enable_soft_delete:
                    findings.append(self.plugin.finding_factory.create_finding(
                        check=check,
                        subscription_id=subscription_id,
                        resource_group=vault.id.split("/")[4],
                        resource_type=AzureResourceType.KEY_VAULT,
                        resource_id=vault.id,
                        name=vault.name,
                        location=vault.location,
                        description=f"Key Vault '{vault.name}' does not have soft delete enabled",
                        recommendation="Enable soft delete for data protection",
                        severity=SeverityLevel.MEDIUM,
                        evidence={"soft_delete": False},
                    ))
        except Exception as e:
            logger.error(f"Key Vault soft delete check failed: {e}")
        
        return findings
    
    async def check_secret_expiry(
        self,
        subscription_id: str,
        resource_group: Optional[str],
        check: Dict,
        options: ScanOptions
    ) -> List[SecurityFinding]:
        """Check for secrets without expiration dates."""
        findings = []
        
        # Requires Key Vault data plane access
        
        return findings

