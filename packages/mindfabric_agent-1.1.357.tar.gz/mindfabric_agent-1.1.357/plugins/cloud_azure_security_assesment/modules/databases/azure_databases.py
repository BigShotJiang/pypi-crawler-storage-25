"""
Azure Security Assessment Databases

Contains static data: MITRE mappings, CIS Azure mappings, check definitions,
dangerous permissions, secret patterns.
"""

import sys
from pathlib import Path as PathLib
sys.path.insert(0, str(PathLib(__file__).parent.parent.parent))

from typing import Any, Dict, List
from ...proto import (
    SecuritySubCategory,
    SecurityCategory,
    AzureResourceType,
    SeverityLevel,
)

# =============================================================================
# MITRE ATT&CK Mapping
# =============================================================================

MITRE_MAPPING: Dict[SecuritySubCategory, Dict[str, Any]] = {
    # Azure AD Issues
    SecuritySubCategory.GLOBAL_ADMIN_NO_MFA: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
        "sub_technique_id": "T1078.004",
        "sub_technique_name": "Cloud Accounts",
    },
    SecuritySubCategory.USER_NO_MFA: {
        "tactic": "Initial Access",
        "technique_id": "T1110",
        "technique_name": "Brute Force",
    },
    SecuritySubCategory.LEGACY_AUTH_ENABLED: {
        "tactic": "Initial Access",
        "technique_id": "T1110",
        "technique_name": "Brute Force",
    },
    SecuritySubCategory.PERMANENT_ADMIN_ROLE: {
        "tactic": "Persistence",
        "technique_id": "T1098",
        "technique_name": "Account Manipulation",
    },
    SecuritySubCategory.SERVICE_PRINCIPAL_ADMIN: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
    },
    SecuritySubCategory.APP_EXCESSIVE_PERMISSIONS: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1098",
        "technique_name": "Account Manipulation",
        "sub_technique_id": "T1098.003",
        "sub_technique_name": "Additional Cloud Roles",
    },
    SecuritySubCategory.PRIVILEGE_ESCALATION_PATH: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1548",
        "technique_name": "Abuse Elevation Control Mechanism",
    },
    # VM Issues
    SecuritySubCategory.PUBLIC_VM: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.NSG_OPEN: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.MANAGED_IDENTITY_ABUSE: {
        "tactic": "Credential Access",
        "technique_id": "T1528",
        "technique_name": "Steal Application Access Token",
    },
    # Storage Issues
    SecuritySubCategory.PUBLIC_BLOB: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # Database Issues
    SecuritySubCategory.PUBLIC_DATABASE: {
        "tactic": "Collection",
        "technique_id": "T1530",
        "technique_name": "Data from Cloud Storage Object",
    },
    # Logging Issues
    SecuritySubCategory.DEFENDER_DISABLED: {
        "tactic": "Defense Evasion",
        "technique_id": "T1562",
        "technique_name": "Impair Defenses",
        "sub_technique_id": "T1562.008",
        "sub_technique_name": "Disable Cloud Logs",
    },
    SecuritySubCategory.DIAGNOSTIC_LOGS_DISABLED: {
        "tactic": "Defense Evasion",
        "technique_id": "T1562",
        "technique_name": "Impair Defenses",
    },
    # Persistence
    SecuritySubCategory.AUTOMATION_RUNBOOK: {
        "tactic": "Persistence",
        "technique_id": "T1053",
        "technique_name": "Scheduled Task/Job",
    },
    SecuritySubCategory.LOGIC_APP_TRIGGER: {
        "tactic": "Persistence",
        "technique_id": "T1053",
        "technique_name": "Scheduled Task/Job",
    },
    SecuritySubCategory.APP_REGISTRATION: {
        "tactic": "Persistence",
        "technique_id": "T1098",
        "technique_name": "Account Manipulation",
    },
    # AKS Issues
    SecuritySubCategory.AKS_PUBLIC_API: {
        "tactic": "Initial Access",
        "technique_id": "T1190",
        "technique_name": "Exploit Public-Facing Application",
    },
    SecuritySubCategory.PRIVILEGED_POD: {
        "tactic": "Privilege Escalation",
        "technique_id": "T1611",
        "technique_name": "Escape to Host",
    },
    # Exfiltration
    SecuritySubCategory.DATA_TRANSFER_RISK: {
        "tactic": "Exfiltration",
        "technique_id": "T1537",
        "technique_name": "Transfer Data to Cloud Account",
    },
    SecuritySubCategory.CROSS_TENANT_ACCESS: {
        "tactic": "Exfiltration",
        "technique_id": "T1537",
        "technique_name": "Transfer Data to Cloud Account",
    },
}


# =============================================================================
# CIS Azure Benchmark Mapping
# =============================================================================

CIS_AZURE_MAPPING: Dict[SecuritySubCategory, Dict[str, str]] = {
    SecuritySubCategory.GLOBAL_ADMIN_NO_MFA: {
        "control_id": "1.1.1",
        "control_name": "Ensure MFA is enabled for all privileged users",
    },
    SecuritySubCategory.USER_NO_MFA: {
        "control_id": "1.1.2",
        "control_name": "Ensure MFA is enabled for all users",
    },
    SecuritySubCategory.LEGACY_AUTH_ENABLED: {
        "control_id": "1.1.6",
        "control_name": "Ensure legacy authentication is blocked",
    },
    SecuritySubCategory.NO_CONDITIONAL_ACCESS: {
        "control_id": "1.2.1",
        "control_name": "Ensure Conditional Access Policy is enabled",
    },
    SecuritySubCategory.PUBLIC_BLOB: {
        "control_id": "3.5",
        "control_name": "Ensure blob public access is disabled",
    },
    SecuritySubCategory.NSG_SSH_RDP_OPEN: {
        "control_id": "6.1",
        "control_name": "Ensure RDP/SSH access is restricted from the internet",
    },
    SecuritySubCategory.DEFENDER_DISABLED: {
        "control_id": "2.1",
        "control_name": "Ensure Microsoft Defender for Cloud is set to On",
    },
    SecuritySubCategory.KEYVAULT_NO_SOFT_DELETE: {
        "control_id": "8.5",
        "control_name": "Ensure Key Vault soft delete is enabled",
    },
    SecuritySubCategory.NSG_FLOW_LOGS_DISABLED: {
        "control_id": "6.4",
        "control_name": "Ensure Network Watcher flow logs are enabled",
    },
}


# =============================================================================
# Dangerous Azure AD Permissions
# =============================================================================

DANGEROUS_AAD_PERMISSIONS: Dict[str, Dict[str, Any]] = {
    "Application.ReadWrite.All": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can create, modify, and delete all applications",
        "escalation_method": "Create admin application with privileged permissions",
    },
    "AppRoleAssignment.ReadWrite.All": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can grant any app role to any principal",
        "escalation_method": "Grant Global Administrator role to self",
    },
    "RoleManagement.ReadWrite.Directory": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can assign any Azure AD role to any principal",
        "escalation_method": "Assign Global Administrator role to self",
    },
    "Directory.ReadWrite.All": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Full read/write access to directory",
        "escalation_method": "Modify user attributes, reset passwords",
    },
    "User.ReadWrite.All": {
        "severity": SeverityLevel.HIGH,
        "description": "Can modify all users",
        "escalation_method": "Reset user passwords, modify MFA",
    },
    "Group.ReadWrite.All": {
        "severity": SeverityLevel.HIGH,
        "description": "Can modify all groups",
        "escalation_method": "Add self to privileged groups",
    },
    "Mail.ReadWrite": {
        "severity": SeverityLevel.HIGH,
        "description": "Full access to user mailboxes",
        "escalation_method": "Read sensitive emails, exfiltrate data",
    },
    "Files.ReadWrite.All": {
        "severity": SeverityLevel.HIGH,
        "description": "Full access to all files",
        "escalation_method": "Access and exfiltrate files",
    },
    "Policy.ReadWrite.ConditionalAccess": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can modify Conditional Access policies",
        "escalation_method": "Disable MFA requirements",
    },
    "ServicePrincipalEndpoint.ReadWrite.All": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can modify service principal endpoints",
        "escalation_method": "Add malicious redirect URIs",
    },
}


# =============================================================================
# Dangerous Azure RBAC Roles
# =============================================================================

DANGEROUS_RBAC_ROLES: Dict[str, Dict[str, Any]] = {
    "Owner": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Full control including access management",
        "scope_impact": "Full resource and RBAC control",
    },
    "Contributor": {
        "severity": SeverityLevel.HIGH,
        "description": "Full resource control without RBAC",
        "scope_impact": "Full resource control",
    },
    "User Access Administrator": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Can manage access to Azure resources",
        "scope_impact": "Can grant Owner to self",
    },
    "Virtual Machine Contributor": {
        "severity": SeverityLevel.HIGH,
        "description": "Can manage VMs including extensions",
        "scope_impact": "Code execution on VMs",
    },
    "Key Vault Administrator": {
        "severity": SeverityLevel.CRITICAL,
        "description": "Full control of Key Vault",
        "scope_impact": "Access to all secrets",
    },
    "Automation Contributor": {
        "severity": SeverityLevel.HIGH,
        "description": "Can manage Automation accounts",
        "scope_impact": "Code execution via runbooks",
    },
}


# =============================================================================
# Secret Patterns
# =============================================================================

SECRET_PATTERNS = [
    (r"(?i)password['\"]?\s*[:=]\s*['\"]?([^\s'\"]{8,})", "Password"),
    (r"(?i)secret['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "Secret"),
    (r"(?i)api[_\-]?key['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-]{20,})", "API Key"),
    (r"(?i)connection[_\-]?string.*?(?:AccountKey|SharedAccessKey)=([^;]+)", "Storage Account Key"),
    (r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "Private Key"),
    (r"(?i)client[_\-]?secret['\"]?\s*[:=]\s*['\"]?([a-zA-Z0-9_\-~.]{32,})", "Client Secret"),
    (r"eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*", "JWT Token"),
    (r"(?i)sas[_\-]?token.*?sig=([^&]+)", "SAS Token"),
    (r"DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;]+", "Storage Connection String"),
    (r"(?i)sql.*?password=([^;]+)", "SQL Password"),
]


# =============================================================================
# Azure Check Definitions
# =============================================================================

AZURE_CHECKS: List[Dict[str, Any]] = [
    # =========================================================================
    # Azure AD Checks
    # =========================================================================
    {
        "id": "aad_global_admin_mfa",
        "name": "Global Admin MFA",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.GLOBAL_ADMIN_NO_MFA,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.AAD_USER],
        "check_fn": "check_global_admin_mfa",
        "tenant_check": True,
    },
    {
        "id": "aad_user_mfa",
        "name": "User MFA Status",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.USER_NO_MFA,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_USER],
        "check_fn": "check_user_mfa",
        "tenant_check": True,
    },
    {
        "id": "aad_legacy_auth",
        "name": "Legacy Authentication",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.LEGACY_AUTH_ENABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_CONDITIONAL_ACCESS],
        "check_fn": "check_legacy_auth",
        "tenant_check": True,
    },
    {
        "id": "aad_guest_elevated",
        "name": "Guest Elevated Access",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.GUEST_ELEVATED_ACCESS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_USER],
        "check_fn": "check_guest_elevated",
        "tenant_check": True,
    },
    {
        "id": "aad_stale_users",
        "name": "Stale User Accounts",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.STALE_USER_ACCOUNT,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.AAD_USER],
        "check_fn": "check_stale_users",
        "tenant_check": True,
    },
    {
        "id": "aad_permanent_admin",
        "name": "Permanent Admin Roles",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.PERMANENT_ADMIN_ROLE,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_ROLE_ASSIGNMENT],
        "check_fn": "check_permanent_admin",
        "tenant_check": True,
    },
    {
        "id": "aad_sp_admin",
        "name": "Service Principal Admin",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.SERVICE_PRINCIPAL_ADMIN,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.AAD_SERVICE_PRINCIPAL],
        "check_fn": "check_sp_admin",
        "tenant_check": True,
    },
    {
        "id": "aad_app_permissions",
        "name": "Excessive App Permissions",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.APP_EXCESSIVE_PERMISSIONS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_APPLICATION],
        "check_fn": "check_app_permissions",
        "tenant_check": True,
    },
    {
        "id": "aad_old_secrets",
        "name": "Old Application Secrets",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.OLD_APP_SECRET,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AAD_APPLICATION],
        "check_fn": "check_old_app_secrets",
        "tenant_check": True,
    },
    {
        "id": "aad_conditional_access",
        "name": "Conditional Access Policies",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.NO_CONDITIONAL_ACCESS,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.AAD_CONDITIONAL_ACCESS],
        "check_fn": "check_conditional_access",
        "tenant_check": True,
    },
    # =========================================================================
    # VM Checks
    # =========================================================================
    {
        "id": "vm_public_ip",
        "name": "VM Public IP",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_VM,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.VIRTUAL_MACHINE],
        "check_fn": "check_vm_public_ip",
        "tenant_check": False,
    },
    {
        "id": "vm_disk_encryption",
        "name": "VM Disk Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.VM_NO_ENCRYPTION,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.VIRTUAL_MACHINE],
        "check_fn": "check_vm_disk_encryption",
        "tenant_check": False,
    },
    {
        "id": "vm_managed_identity",
        "name": "VM Managed Identity",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.MANAGED_IDENTITY_ABUSE,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.VIRTUAL_MACHINE],
        "check_fn": "check_vm_managed_identity",
        "tenant_check": False,
    },
    {
        "id": "vm_jit_access",
        "name": "JIT Access Status",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.JIT_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.VIRTUAL_MACHINE],
        "check_fn": "check_vm_jit",
        "tenant_check": False,
    },
    # =========================================================================
    # NSG Checks
    # =========================================================================
    {
        "id": "nsg_open_ssh",
        "name": "Open SSH Access",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.NSG_SSH_RDP_OPEN,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.NSG],
        "check_fn": "check_nsg_open_ssh",
        "tenant_check": False,
    },
    {
        "id": "nsg_open_rdp",
        "name": "Open RDP Access",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.NSG_SSH_RDP_OPEN,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.NSG],
        "check_fn": "check_nsg_open_rdp",
        "tenant_check": False,
    },
    {
        "id": "nsg_open_all",
        "name": "Open All Ports",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.NSG_ANY_ANY,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.NSG],
        "check_fn": "check_nsg_open_all",
        "tenant_check": False,
    },
    {
        "id": "nsg_flow_logs",
        "name": "NSG Flow Logs",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.NSG_FLOW_LOGS_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.NSG],
        "check_fn": "check_nsg_flow_logs",
        "tenant_check": False,
    },
    # =========================================================================
    # Storage Checks
    # =========================================================================
    {
        "id": "storage_public_blob",
        "name": "Public Blob Access",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_BLOB,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.STORAGE_ACCOUNT],
        "check_fn": "check_public_blob",
        "tenant_check": False,
    },
    {
        "id": "storage_https",
        "name": "Storage HTTPS",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.STORAGE_NO_HTTPS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.STORAGE_ACCOUNT],
        "check_fn": "check_storage_https",
        "tenant_check": False,
    },
    {
        "id": "storage_firewall",
        "name": "Storage Firewall",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.STORAGE_FIREWALL_DISABLED,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.STORAGE_ACCOUNT],
        "check_fn": "check_storage_firewall",
        "tenant_check": False,
    },
    {
        "id": "storage_shared_key",
        "name": "Shared Key Auth",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.SHARED_KEY_AUTH,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.STORAGE_ACCOUNT],
        "check_fn": "check_storage_shared_key",
        "tenant_check": False,
    },
    # =========================================================================
    # Key Vault Checks
    # =========================================================================
    {
        "id": "keyvault_public",
        "name": "Key Vault Public Access",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.KEYVAULT_PUBLIC,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.KEY_VAULT],
        "check_fn": "check_keyvault_public",
        "tenant_check": False,
    },
    {
        "id": "keyvault_soft_delete",
        "name": "Key Vault Soft Delete",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.KEYVAULT_NO_SOFT_DELETE,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.KEY_VAULT],
        "check_fn": "check_keyvault_soft_delete",
        "tenant_check": False,
    },
    {
        "id": "keyvault_secret_expiry",
        "name": "Secrets Without Expiry",
        "category": SecurityCategory.CREDENTIAL_ACCESS,
        "sub_category": SecuritySubCategory.SECRET_NO_EXPIRY,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.KEY_VAULT_SECRET],
        "check_fn": "check_secret_expiry",
        "tenant_check": False,
    },
    # =========================================================================
    # SQL Checks
    # =========================================================================
    {
        "id": "sql_public",
        "name": "Public SQL Server",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.PUBLIC_DATABASE,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.SQL_SERVER],
        "check_fn": "check_sql_public",
        "tenant_check": False,
    },
    {
        "id": "sql_tde",
        "name": "SQL TDE Encryption",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.DATABASE_NO_TDE,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.SQL_DATABASE],
        "check_fn": "check_sql_tde",
        "tenant_check": False,
    },
    {
        "id": "sql_auditing",
        "name": "SQL Auditing",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.DATABASE_NO_AUDITING,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.SQL_SERVER],
        "check_fn": "check_sql_auditing",
        "tenant_check": False,
    },
    # =========================================================================
    # AKS Checks
    # =========================================================================
    {
        "id": "aks_public_api",
        "name": "AKS Public API",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.AKS_PUBLIC_API,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AKS_CLUSTER],
        "check_fn": "check_aks_public_api",
        "tenant_check": False,
    },
    {
        "id": "aks_local_accounts",
        "name": "AKS Local Accounts",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.AKS_LOCAL_ACCOUNTS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AKS_CLUSTER],
        "check_fn": "check_aks_local_accounts",
        "tenant_check": False,
    },
    {
        "id": "aks_azure_ad",
        "name": "AKS Azure AD Integration",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.AKS_NO_AZURE_AD,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.AKS_CLUSTER],
        "check_fn": "check_aks_azure_ad",
        "tenant_check": False,
    },
    {
        "id": "aks_network_policy",
        "name": "AKS Network Policy",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.AKS_NO_NETWORK_POLICY,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.AKS_CLUSTER],
        "check_fn": "check_aks_network_policy",
        "tenant_check": False,
    },
    # =========================================================================
    # App Service Checks
    # =========================================================================
    {
        "id": "app_https",
        "name": "App Service HTTPS",
        "category": SecurityCategory.ENCRYPTION_WEAKNESS,
        "sub_category": SecuritySubCategory.APP_NO_HTTPS,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.APP_SERVICE],
        "check_fn": "check_app_https",
        "tenant_check": False,
    },
    {
        "id": "app_remote_debug",
        "name": "App Remote Debugging",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.APP_REMOTE_DEBUG,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.APP_SERVICE],
        "check_fn": "check_app_remote_debug",
        "tenant_check": False,
    },
    {
        "id": "app_ftp",
        "name": "App FTP Status",
        "category": SecurityCategory.NETWORK_EXPOSURE,
        "sub_category": SecuritySubCategory.APP_FTP_ENABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.APP_SERVICE],
        "check_fn": "check_app_ftp",
        "tenant_check": False,
    },
    # =========================================================================
    # Defender Checks
    # =========================================================================
    {
        "id": "defender_enabled",
        "name": "Defender for Cloud",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.DEFENDER_DISABLED,
        "severity": SeverityLevel.CRITICAL,
        "resource_types": [AzureResourceType.DEFENDER_PLAN],
        "check_fn": "check_defender_enabled",
        "tenant_check": False,
    },
    {
        "id": "diagnostic_logs",
        "name": "Diagnostic Logs",
        "category": SecurityCategory.LOGGING_GAP,
        "sub_category": SecuritySubCategory.DIAGNOSTIC_LOGS_DISABLED,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.DIAGNOSTIC_SETTING],
        "check_fn": "check_diagnostic_logs",
        "tenant_check": False,
    },
    # =========================================================================
    # Governance Checks
    # =========================================================================
    {
        "id": "owner_count",
        "name": "Owner Role Count",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.OWNER_TOO_MANY,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.SUBSCRIPTION],
        "check_fn": "check_owner_count",
        "tenant_check": False,
    },
    {
        "id": "classic_admin",
        "name": "Classic Administrators",
        "category": SecurityCategory.IDENTITY_MISCONFIGURATION,
        "sub_category": SecuritySubCategory.CLASSIC_ADMIN,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.SUBSCRIPTION],
        "check_fn": "check_classic_admin",
        "tenant_check": False,
    },
    {
        "id": "azure_policy",
        "name": "Azure Policy",
        "category": SecurityCategory.COMPLIANCE_VIOLATION,
        "sub_category": SecuritySubCategory.NO_AZURE_POLICY,
        "severity": SeverityLevel.HIGH,
        "resource_types": [AzureResourceType.POLICY_ASSIGNMENT],
        "check_fn": "check_azure_policy",
        "tenant_check": False,
    },
    {
        "id": "resource_locks",
        "name": "Resource Locks",
        "category": SecurityCategory.DATA_EXPOSURE,
        "sub_category": SecuritySubCategory.NO_RESOURCE_LOCKS,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.RESOURCE_LOCK],
        "check_fn": "check_resource_locks",
        "tenant_check": False,
    },
    # =========================================================================
    # Persistence Checks
    # =========================================================================
    {
        "id": "automation_runbooks",
        "name": "Automation Runbooks",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.AUTOMATION_RUNBOOK,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.AUTOMATION_ACCOUNT],
        "check_fn": "check_automation_runbooks",
        "tenant_check": False,
    },
    {
        "id": "logic_apps",
        "name": "Logic App Triggers",
        "category": SecurityCategory.PERSISTENCE,
        "sub_category": SecuritySubCategory.LOGIC_APP_TRIGGER,
        "severity": SeverityLevel.MEDIUM,
        "resource_types": [AzureResourceType.LOGIC_APP],
        "check_fn": "check_logic_apps",
        "tenant_check": False,
    },
]



# =============================================================================
# UI helpers (security_scan v1)
# =============================================================================

AZURE_AUTH_CONFIG_COMMANDS: List[str] = [
    "# Configure Azure credentials for the agent (choose ONE):",
    "# 1) Environment variables (Service Principal):",
    "export AZURE_TENANT_ID='<tenant>'",
    "export AZURE_CLIENT_ID='<client_id>'",
    "export AZURE_CLIENT_SECRET='<client_secret>'",
    "export AZURE_SUBSCRIPTION_ID='<subscription_id>'",
    "# 2) Managed Identity (IMDS) if running on Azure VM/AKS",
]

AZURE_AUTH_CONFIG_RECOMMENDATIONS: List[Dict[str, str]] = [
    {
        "title": "Configure Azure credentials",
        "description": "Provide Service Principal env vars or Managed Identity so the plugin can enumerate subscriptions/resources.",
        "priority": "high",
    },
    {
        "title": "Least privilege",
        "description": "Grant read-only roles first (e.g., Reader/Security Reader) and expand permissions only if necessary.",
        "priority": "medium",
    },
]


AZURE_NO_FINDINGS_RECOMMENDATIONS: List[Dict[str, str]] = [
    {
        "title": "Review scope",
        "description": "Ensure the scan scope includes at least one enabled subscription and required resource providers.",
        "priority": "low",
    }
]
