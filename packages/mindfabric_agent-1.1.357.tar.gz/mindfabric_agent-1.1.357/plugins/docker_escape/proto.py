"""
Docker Escape Plugin - Pydantic Models (Complete Edition)

Comprehensive data structures for container security assessment,
escape vector detection, and container breakout capabilities.

Covers 50+ escape techniques, 20+ CVEs, and full MITRE ATT&CK mapping.
"""

from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional, Union
from plugins.reproduction import ReproStep
from pydantic import BaseModel, Field, computed_field


# =============================================================================
# Enumerations
# =============================================================================

class EscapeMethod(str, Enum):
    """Container escape methods/vectors - Complete list of 50+ techniques."""
    
    # =========================================================================
    # Socket-Based Escapes
    # =========================================================================
    DOCKER_SOCK = "docker_sock"
    CONTAINERD_SOCK = "containerd_sock"
    CRIO_SOCK = "crio_sock"
    PODMAN_SOCK = "podman_sock"
    KUBELET_API = "kubelet_api"
    DOCKER_TCP = "docker_tcp"  # Docker API exposed on TCP
    
    # =========================================================================
    # Filesystem-Based Escapes
    # =========================================================================
    PROC_ROOT_CHROOT = "proc_root_chroot"
    HOST_MOUNT = "host_mount"
    PROC_SELF_MOUNTS = "proc_self_mounts"
    DOCKER_FILESYSTEM = "docker_filesystem"
    SENSITIVE_FILES = "sensitive_files"
    OVERLAYFS_ESCAPE = "overlayfs_escape"
    DEBUGFS_MOUNT = "debugfs_mount"
    SYSFS_WRITE = "sysfs_write"
    PROCFS_WRITE = "procfs_write"
    SYMLINK_RACE = "symlink_race"
    
    # =========================================================================
    # Capability-Based Escapes
    # =========================================================================
    CAP_SYS_ADMIN = "cap_sys_admin"
    CAP_SYS_PTRACE = "cap_sys_ptrace"
    CAP_SYS_MODULE = "cap_sys_module"
    CAP_SYS_RAWIO = "cap_sys_rawio"
    CAP_SYS_CHROOT = "cap_sys_chroot"
    CAP_SYS_BOOT = "cap_sys_boot"
    CAP_NET_ADMIN = "cap_net_admin"
    CAP_NET_RAW = "cap_net_raw"
    CAP_DAC_OVERRIDE = "cap_dac_override"
    CAP_DAC_READ_SEARCH = "cap_dac_read_search"
    CAP_MKNOD = "cap_mknod"
    CAP_SETUID = "cap_setuid"
    CAP_SETGID = "cap_setgid"
    CAP_SETFCAP = "cap_setfcap"
    CAP_FOWNER = "cap_fowner"
    CAP_AUDIT_WRITE = "cap_audit_write"
    CAP_BPF = "cap_bpf"
    CAP_PERFMON = "cap_perfmon"
    CAP_SYS_RESOURCE = "cap_sys_resource"
    
    # =========================================================================
    # Namespace-Based Escapes
    # =========================================================================
    NSENTER = "nsenter"
    PIVOT_ROOT = "pivot_root"
    UNSHARE = "unshare"
    SETNS = "setns"
    USER_NAMESPACE = "user_namespace"
    
    # =========================================================================
    # Privileged Mode / Host Sharing
    # =========================================================================
    PRIVILEGED_CONTAINER = "privileged_container"
    HOST_PID = "host_pid"
    HOST_NETWORK = "host_network"
    HOST_IPC = "host_ipc"
    HOST_UTS = "host_uts"
    
    # =========================================================================
    # Kernel-Based Escapes
    # =========================================================================
    CORE_PATTERN = "core_pattern"
    MODPROBE_PATH = "modprobe_path"
    KERNEL_MODULES = "kernel_modules"
    EBPF_EXPLOIT = "ebpf_exploit"
    IO_URING = "io_uring"
    UEVENT_HELPER = "uevent_helper"
    PROC_KCORE = "proc_kcore"
    PROC_KMEM = "proc_kmem"
    KALLSYMS = "kallsyms"
    
    # =========================================================================
    # Cgroup-Based Escapes
    # =========================================================================
    CGROUP_RELEASE_AGENT = "cgroup_release_agent"
    CGROUP_NOTIFY_ON_RELEASE = "cgroup_notify_on_release"
    CGROUP_DEVICES = "cgroup_devices"
    CGROUPV2_ESCAPE = "cgroupv2_escape"
    
    # =========================================================================
    # Device-Based Escapes
    # =========================================================================
    MKNOD_DEVICE = "mknod_device"
    DEVICE_ACCESS = "device_access"
    DEV_MEM = "dev_mem"
    DEV_KMEM = "dev_kmem"
    DEV_PORT = "dev_port"
    DISK_DEVICE = "disk_device"
    
    # =========================================================================
    # CVE-Based Escapes
    # =========================================================================
    CVE_2016_5195 = "cve_2016_5195"  # Dirty COW
    CVE_2019_5736 = "cve_2019_5736"  # runc escape
    CVE_2019_14271 = "cve_2019_14271"  # docker cp
    CVE_2019_16884 = "cve_2019_16884"  # AppArmor bypass
    CVE_2020_15257 = "cve_2020_15257"  # containerd-shim
    CVE_2021_30465 = "cve_2021_30465"  # runc symlink
    CVE_2021_41091 = "cve_2021_41091"  # Moby traversal
    CVE_2022_0185 = "cve_2022_0185"  # fsconfig heap overflow
    CVE_2022_0492 = "cve_2022_0492"  # cgroup release_agent
    CVE_2022_0847 = "cve_2022_0847"  # Dirty Pipe
    CVE_2022_23648 = "cve_2022_23648"  # containerd imgcrypt
    CVE_2022_24769 = "cve_2022_24769"  # Moby supplementary groups
    CVE_2023_25809 = "cve_2023_25809"  # runc rootless
    CVE_2023_27561 = "cve_2023_27561"  # runc TOCTOU
    CVE_2023_28642 = "cve_2023_28642"  # runc AppArmor
    CVE_2024_21626 = "cve_2024_21626"  # runc fd leak
    
    # =========================================================================
    # Security Policy Weakness
    # =========================================================================
    SELINUX_DISABLED = "selinux_disabled"
    APPARMOR_DISABLED = "apparmor_disabled"
    SECCOMP_DISABLED = "seccomp_disabled"
    NO_NEW_PRIVS_DISABLED = "no_new_privs_disabled"
    READ_ONLY_ROOTFS_DISABLED = "read_only_rootfs_disabled"
    
    # =========================================================================
    # Network-Based Escapes
    # =========================================================================
    DOCKER_API_EXPOSED = "docker_api_exposed"
    NETWORK_HOST_MODE = "network_host_mode"
    IPTABLES_ACCESS = "iptables_access"
    ARP_SPOOFING = "arp_spoofing"
    DNS_POISONING = "dns_poisoning"
    CONTAINER_PIVOT = "container_pivot"
    IMDS_ACCESS = "imds_access"  # Cloud metadata service
    
    # =========================================================================
    # Cloud/Kubernetes Specific
    # =========================================================================
    K8S_SERVICE_ACCOUNT = "k8s_service_account"
    K8S_API_ACCESS = "k8s_api_access"
    K8S_SECRETS = "k8s_secrets"
    K8S_CONFIGMAP = "k8s_configmap"
    AWS_IMDS = "aws_imds"
    GCP_METADATA = "gcp_metadata"
    AZURE_IMDS = "azure_imds"
    
    # =========================================================================
    # TTY/Process Injection
    # =========================================================================
    TIOCSTI_INJECTION = "tiocsti_injection"
    PTRACE_INJECTION = "ptrace_injection"
    LD_PRELOAD = "ld_preload"
    
    # =========================================================================
    # Misc/Advanced
    # =========================================================================
    WEAK_TMP_MOUNT = "weak_tmp_mount"
    WEAK_IMAGE_CONFIG = "weak_image_config"
    SYSCALL_ABUSE = "syscall_abuse"
    X11_FORWARDING = "x11_forwarding"
    SSH_AGENT_FORWARDING = "ssh_agent_forwarding"
    DBUS_SOCKET = "dbus_socket"
    DOCKER_CP_ABUSE = "docker_cp_abuse"
    RUNC_EXEC = "runc_exec"
    
    # =========================================================================
    # Alternative Runtime Escapes
    # =========================================================================
    ALTERNATIVE_RUNTIME = "alternative_runtime"  # Podman, CRI-O, Kata, gVisor, etc.
    KATA_CONTAINERS = "kata_containers"
    GVISOR = "gvisor"
    FIRECRACKER = "firecracker"
    
    # =========================================================================
    # Namespace-Based Escapes (Extended)
    # =========================================================================
    NAMESPACE_ESCAPE = "namespace_escape"  # Generic namespace escape
    PID_NS_ESCAPE = "pid_ns_escape"
    NET_NS_ESCAPE = "net_ns_escape"
    MNT_NS_ESCAPE = "mnt_ns_escape"
    USER_NS_ESCAPE = "user_ns_escape"
    IPC_NS_ESCAPE = "ipc_ns_escape"
    UTS_NS_ESCAPE = "uts_ns_escape"
    CGROUP_NS_ESCAPE = "cgroup_ns_escape"


class EscapeStatus(str, Enum):
    """Status of escape attempt."""
    EXPLOITED = "exploited"          # Successfully escaped
    VULNERABLE = "vulnerable"        # Vulnerability confirmed, not exploited
    POSSIBLE = "possible"            # May be exploitable
    NOT_VULNERABLE = "not_vulnerable"
    NOT_FOUND = "not_found"          # Required component not found
    NOT_CAPABLE = "not_capable"      # Missing required capability
    BLOCKED = "blocked"              # Blocked by security policy
    ERROR = "error"
    SKIPPED = "skipped"
    TIMEOUT = "timeout"
    REQUIRES_INTERACTION = "requires_interaction"  # Manual steps needed


class SeverityLevel(str, Enum):
    """Severity level classification."""
    CRITICAL = "critical"  # Direct container escape
    HIGH = "high"          # Privilege escalation / partial escape
    MEDIUM = "medium"      # Information disclosure / lateral movement
    LOW = "low"            # Minor security issue
    INFO = "info"          # Informational finding


class ContainerRuntime(str, Enum):
    """Container runtimes."""
    DOCKER = "docker"
    CONTAINERD = "containerd"
    CRIO = "crio"
    PODMAN = "podman"
    LXC = "lxc"
    LXD = "lxd"
    RUNC = "runc"
    CRUN = "crun"
    KATA = "kata"
    GVISOR = "gvisor"
    FIRECRACKER = "firecracker"
    YOUKI = "youki"
    UNKNOWN = "unknown"


class VulnerabilityType(str, Enum):
    """Types of container vulnerabilities."""
    CONTAINER_ESCAPE = "container_escape"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    INFORMATION_DISCLOSURE = "information_disclosure"
    HOST_ACCESS = "host_access"
    CREDENTIAL_THEFT = "credential_theft"
    LATERAL_MOVEMENT = "lateral_movement"
    PERSISTENCE = "persistence"
    DENIAL_OF_SERVICE = "denial_of_service"
    CODE_EXECUTION = "code_execution"
    ARBITRARY_WRITE = "arbitrary_write"
    ARBITRARY_READ = "arbitrary_read"
    RACE_CONDITION = "race_condition"


class CapabilityRisk(str, Enum):
    """Risk level for Linux capabilities."""
    CRITICAL = "critical"  # Direct escape possible
    HIGH = "high"          # Escape with additional steps
    MEDIUM = "medium"      # Privilege escalation
    LOW = "low"            # Limited impact
    NONE = "none"          # Safe


class AssessmentPhase(str, Enum):
    """Assessment execution phases."""
    ENVIRONMENT_DETECTION = "environment_detection"
    CAPABILITY_ENUMERATION = "capability_enumeration"
    MOUNT_ANALYSIS = "mount_analysis"
    NETWORK_ANALYSIS = "network_analysis"
    KERNEL_ANALYSIS = "kernel_analysis"
    CLOUD_DETECTION = "cloud_detection"
    CVE_SCANNING = "cve_scanning"
    EXPLOITATION = "exploitation"
    POST_EXPLOITATION = "post_exploitation"


class CloudProvider(str, Enum):
    """Cloud providers for metadata service detection."""
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"
    ALIBABA = "alibaba"
    ORACLE = "oracle"
    DIGITALOCEAN = "digitalocean"
    UNKNOWN = "unknown"
    NONE = "none"


class KernelExploitType(str, Enum):
    """Types of kernel exploits."""
    MEMORY_CORRUPTION = "memory_corruption"
    RACE_CONDITION = "race_condition"
    USE_AFTER_FREE = "use_after_free"
    HEAP_OVERFLOW = "heap_overflow"
    STACK_OVERFLOW = "stack_overflow"
    INTEGER_OVERFLOW = "integer_overflow"
    NULL_POINTER = "null_pointer"
    PRIVILEGE_ESCALATION = "privilege_escalation"


# =============================================================================
# Supporting Models
# =============================================================================

class ExploitationCommands(BaseModel):
    """
    Explicit exploitation commands for display in UI.
    Shows exactly what attacker can/did execute for container escape.
    """
    server: Optional[str] = Field(None, description="Container name/ID or host")
    ip: Optional[str] = Field(None, description="Container/host IP address")
    commands: List[str] = Field(default_factory=list, description="Shell commands (prefixed with $)")
    description: Optional[str] = Field(None, description="What these commands accomplish")


class CVEReference(BaseModel):
    """CVE reference information."""
    cve_id: str = Field(..., description="CVE identifier (e.g., CVE-2019-5736)")
    cvss_score: float = Field(0.0, ge=0.0, le=10.0, description="CVSS v3 score")
    cvss_vector: Optional[str] = Field(None, description="CVSS vector string")
    description: str = Field("", description="Vulnerability description")
    vulnerability_type: VulnerabilityType = Field(VulnerabilityType.CONTAINER_ESCAPE)
    
    # Affected components
    affected_runtimes: List[ContainerRuntime] = Field(default_factory=list)
    affected_versions: List[str] = Field(default_factory=list)
    fixed_versions: List[str] = Field(default_factory=list)
    affected_kernels: List[str] = Field(default_factory=list)
    
    # Exploitation info
    requires_privileged: bool = Field(False)
    requires_capabilities: List[str] = Field(default_factory=list)
    requires_host_network: bool = Field(False)
    requires_host_pid: bool = Field(False)
    requires_root: bool = Field(False)
    public_exploit: bool = Field(False)
    exploit_url: Optional[str] = Field(None)
    metasploit_module: Optional[str] = Field(None)
    
    # Reliability
    reliability: float = Field(0.8, ge=0.0, le=1.0, description="Exploit reliability")
    
    # MITRE ATT&CK
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # References
    references: List[str] = Field(default_factory=list)
    
    # Dates
    published_date: Optional[str] = Field(None)
    
    # Detection/Exploitation
    detection_method: Optional[str] = Field(None)
    exploitation_notes: Optional[str] = Field(None)


class LinuxCapability(BaseModel):
    """Linux capability information."""
    name: str = Field(..., description="Capability name (e.g., CAP_SYS_ADMIN)")
    bit_position: int = Field(..., description="Bit position in capability set")
    hex_mask: str = Field(..., description="Hex mask for capability")
    description: str = Field("")
    risk_level: CapabilityRisk = Field(CapabilityRisk.MEDIUM)
    escape_methods: List[EscapeMethod] = Field(default_factory=list)
    exploitation_notes: Optional[str] = Field(None)
    mitre_techniques: List[str] = Field(default_factory=list)


class MountPoint(BaseModel):
    """Container mount point information."""
    source: str = Field(..., description="Source path on host")
    destination: str = Field(..., description="Mount point in container")
    fs_type: str = Field("", description="Filesystem type")
    options: List[str] = Field(default_factory=list)
    is_dangerous: bool = Field(False)
    risk_level: SeverityLevel = Field(SeverityLevel.INFO)
    escape_method: Optional[EscapeMethod] = Field(None)
    notes: Optional[str] = Field(None)


class NetworkInterface(BaseModel):
    """Network interface information."""
    name: str = Field(...)
    mac_address: Optional[str] = Field(None)
    ip_addresses: List[str] = Field(default_factory=list)
    is_host_interface: bool = Field(False)
    is_bridge: bool = Field(False)


class KernelInfo(BaseModel):
    """Kernel information for exploit matching."""
    version: str = Field("")
    release: str = Field("")
    full_version: str = Field("")
    major: int = Field(0)
    minor: int = Field(0)
    patch: int = Field(0)
    is_vulnerable_dirty_cow: bool = Field(False)
    is_vulnerable_dirty_pipe: bool = Field(False)
    has_ebpf: bool = Field(False)
    has_io_uring: bool = Field(False)
    has_user_namespaces: bool = Field(False)


class CloudMetadata(BaseModel):
    """Cloud provider metadata."""
    provider: CloudProvider = Field(CloudProvider.NONE)
    instance_id: Optional[str] = Field(None)
    region: Optional[str] = Field(None)
    availability_zone: Optional[str] = Field(None)
    instance_type: Optional[str] = Field(None)
    iam_role: Optional[str] = Field(None)
    security_credentials: Optional[Dict[str, Any]] = Field(None)
    user_data: Optional[str] = Field(None)


class KubernetesInfo(BaseModel):
    """Kubernetes environment information."""
    in_kubernetes: bool = Field(False)
    namespace: Optional[str] = Field(None)
    pod_name: Optional[str] = Field(None)
    service_account: Optional[str] = Field(None)
    token_path: Optional[str] = Field(None)
    has_token: bool = Field(False)
    api_server: Optional[str] = Field(None)
    can_access_api: bool = Field(False)
    secrets_accessible: List[str] = Field(default_factory=list)


class ContainerEnvironment(BaseModel):
    """Container environment information."""
    # Runtime detection
    inside_container: bool = Field(False)
    runtime: ContainerRuntime = Field(ContainerRuntime.UNKNOWN)
    runtime_version: Optional[str] = Field(None)
    container_id: Optional[str] = Field(None)
    container_name: Optional[str] = Field(None)
    image_name: Optional[str] = Field(None)
    
    # Privileges
    is_privileged: bool = Field(False)
    is_root: bool = Field(False)
    user_id: int = Field(-1)
    group_id: int = Field(-1)
    groups: List[int] = Field(default_factory=list)
    
    # Namespaces
    has_host_pid: bool = Field(False)
    has_host_network: bool = Field(False)
    has_host_ipc: bool = Field(False)
    has_host_uts: bool = Field(False)
    has_user_namespace: bool = Field(False)
    
    # Capabilities
    effective_caps: List[str] = Field(default_factory=list)
    effective_caps_hex: Optional[str] = Field(None)
    permitted_caps: List[str] = Field(default_factory=list)
    bounding_caps: List[str] = Field(default_factory=list)
    ambient_caps: List[str] = Field(default_factory=list)
    
    # Security policies
    selinux_enforcing: Optional[bool] = Field(None)
    selinux_context: Optional[str] = Field(None)
    apparmor_profile: Optional[str] = Field(None)
    seccomp_profile: Optional[str] = Field(None)
    no_new_privs: bool = Field(False)
    read_only_rootfs: bool = Field(False)
    
    # Mounts
    mounts: List[MountPoint] = Field(default_factory=list)
    docker_sock_available: bool = Field(False)
    containerd_sock_available: bool = Field(False)
    
    # Network
    network_interfaces: List[NetworkInterface] = Field(default_factory=list)
    can_access_internet: bool = Field(False)
    
    # Kernel
    kernel: KernelInfo = Field(default_factory=KernelInfo)
    # Extra kernel escape indicators (populated by EnvironmentDetector)
    kernel_escape_paths: Dict[str, Any] = Field(default_factory=dict)
    
    # Cloud
    cloud: CloudMetadata = Field(default_factory=CloudMetadata)
    
    # Kubernetes
    kubernetes: KubernetesInfo = Field(default_factory=KubernetesInfo)
    
    # Detection methods used
    detection_methods: List[str] = Field(default_factory=list)
    
    # Available binaries
    available_tools: List[str] = Field(default_factory=list)


def escape_attempt_include_in_threat_graph(
    status: Union[EscapeStatus, str],
    severity: Union[SeverityLevel, str],
) -> bool:
    """
    Single rule for whether an escape attempt becomes a threat in security_scan / threat graph.

    Excludes benign outcomes (nothing to exploit, no capability, resource missing) and
    severity=info posture rows (except ERROR, which signals a failed check worth surfacing).
    Accepts enums or raw strings (e.g. from model_dump).
    """
    st = status.value if isinstance(status, EscapeStatus) else str(status or "").lower()
    sev = severity.value if isinstance(severity, SeverityLevel) else str(severity or "").lower()
    if st in (
        "skipped",
        "not_vulnerable",
        "not_found",
        "not_capable",
        "safe",
        "not_vulnerable_or_not_applicable",
    ):
        return False
    if sev == "info":
        return False
    return True


class ExploitArtifact(BaseModel):
    """Artifact obtained during exploitation."""
    artifact_type: str = Field(..., description="Type of artifact")
    path: Optional[str] = Field(None, description="File path if applicable")
    content: Optional[str] = Field(None, description="Content preview")
    content_hash: Optional[str] = Field(None, description="SHA256 hash")
    size_bytes: Optional[int] = Field(None)
    description: Optional[str] = Field(None)
    sensitive: bool = Field(False, description="Contains sensitive data")


class EscapeAttemptResult(BaseModel):
    """Result of a single escape attempt."""
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    method: EscapeMethod = Field(..., description="Escape method used")
    status: EscapeStatus = Field(..., description="Attempt status")
    
    # Details
    description: Optional[str] = Field(
        None,
        description="Short description of the method (enriched from method metadata when missing)",
    )
    message: str = Field("", description="Human-readable message")
    technical_details: Optional[str] = Field(None)
    
    # Operational metadata
    detection_difficulty: Optional[str] = Field(
        None,
        description="How difficult this escape is to detect in logs/telemetry (low/medium/high)",
    )
    
    # 🔴 EXPLICIT EXPLOITATION COMMANDS
    commands: Optional[ExploitationCommands] = Field(
        None, description="Explicit shell commands for container escape"
    )
    
    # Evidence
    artifacts: List[ExploitArtifact] = Field(default_factory=list)
    
    # Legacy fields for compatibility
    artifact_path: Optional[str] = Field(None)
    artifact_content: Optional[str] = Field(None)
    
    # Impact
    severity: SeverityLevel = Field(SeverityLevel.INFO)
    impact_description: Optional[str] = Field(None)
    
    # CVE if applicable
    cve_id: Optional[str] = Field(None)
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # Requirements that were met/not met
    requirements_met: List[str] = Field(default_factory=list)
    requirements_missing: List[str] = Field(default_factory=list)
    
    # Next steps
    demo_next_steps: Optional[str] = Field(None)
    remediation: Optional[str] = Field(None)
    
    # Timing
    executed_at: datetime = Field(default_factory=datetime.utcnow)
    duration_ms: Optional[int] = Field(
        None,
        description=(
            "Wall-clock time for this specific escape check in milliseconds, when the detector records it. "
            "Often unset for fast synchronous checks; omitted from evidence when unknown."
        ),
    )

    @computed_field
    @property
    def include_in_threat_graph(self) -> bool:
        """Derived from status/severity; see escape_attempt_include_in_threat_graph()."""
        return escape_attempt_include_in_threat_graph(self.status, self.severity)


class VulnerabilityFinding(BaseModel):
    """Detected vulnerability."""
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    
    # Classification
    vulnerability_type: VulnerabilityType = Field(...)
    severity: SeverityLevel = Field(...)
    
    # CVE info
    cve: Optional[CVEReference] = Field(None)
    
    # Detection
    detection_method: str = Field("")
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    verified: bool = Field(False)
    
    # Evidence
    evidence: Optional[str] = Field(None)
    indicators: List[str] = Field(default_factory=list)
    
    # Exploitation
    exploitable: bool = Field(False)
    exploit_complexity: Optional[str] = Field(None)
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
    
    # Remediation
    remediation: Optional[str] = Field(None)
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Step-by-step reproduction for this vulnerability"
    )


# =============================================================================
# Configuration Models
# =============================================================================

class EscapeScope(BaseModel):
    """Scope for escape assessment."""
    # Methods to test
    target_methods: Optional[List[EscapeMethod]] = Field(
        None, description="Specific methods to test (None = all)"
    )
    exclude_methods: Optional[List[EscapeMethod]] = Field(
        None, description="Methods to skip"
    )
    
    # Method categories
    test_socket_escapes: bool = Field(True)
    test_capability_escapes: bool = Field(True)
    test_namespace_escapes: bool = Field(True)
    test_kernel_escapes: bool = Field(True)
    test_cve_escapes: bool = Field(True)
    test_cloud_escapes: bool = Field(True)
    test_network_escapes: bool = Field(True)
    
    # CVE filtering
    target_cves: Optional[List[str]] = Field(None, description="Specific CVEs to check")
    min_cvss_score: float = Field(0.0, ge=0.0, le=10.0)
    
    # Severity filtering
    min_severity: SeverityLevel = Field(SeverityLevel.INFO)
    
    # Performance
    timeout_seconds: int = Field(30, description="Timeout per method")
    max_concurrent: int = Field(5)
    
    # Kernel exploit settings
    kernel_exploit_max_attempts: int = Field(3)


class EscapeOptions(BaseModel):
    """Configuration for escape assessment."""
    scope: EscapeScope = Field(default_factory=EscapeScope)
    
    # Operation modes
    safe_mode: bool = Field(True, description="Avoid destructive operations")
    verify_only: bool = Field(False, description="Only check, don't exploit")
    quick_scan: bool = Field(False, description="Fast scan, skip slow checks")
    deep_scan: bool = Field(False, description="Thorough scan including kernel")
    
    # Exploitation
    exploit_on_find: bool = Field(False, description="Exploit immediately when found")
    stop_on_success: bool = Field(False, description="Stop after first success")
    chain_exploits: bool = Field(False, description="Try exploit chains")
    
    # Evidence collection
    collect_artifacts: bool = Field(True)
    max_artifact_size: int = Field(10240, description="Max artifact size in bytes")
    hash_artifacts: bool = Field(True)
    capture_screenshots: bool = Field(False)
    
    # Cloud
    check_cloud_metadata: bool = Field(True)
    exfiltrate_cloud_creds: bool = Field(False)
    
    # Kubernetes
    check_kubernetes: bool = Field(True)
    enumerate_k8s_secrets: bool = Field(False)
    
    # Network
    scan_internal_network: bool = Field(False)
    pivot_to_containers: bool = Field(False)
    
    # Capabilities to prioritize
    prioritize_capabilities: List[str] = Field(
        default=["CAP_SYS_ADMIN", "CAP_SYS_PTRACE", "CAP_NET_ADMIN", "CAP_SYS_MODULE"]
    )
    
    # Output control
    verbose: bool = Field(False)
    include_remediation: bool = Field(True)
    include_mitre_mapping: bool = Field(True)
    # Host profile: production (default) vs lab/training — caps non-exploit severities when set via options or env.
    host_profile: Optional[str] = Field(
        None,
        description="production | lab | training | intentionally_vulnerable — optional; also reads MINDFABRIC_HOST_PROFILE",
    )


# =============================================================================
# Output Models
# =============================================================================

class MethodSummary(BaseModel):
    """Summary of escape methods tested."""
    total_tested: int = Field(0)
    exploited: int = Field(0)
    vulnerable: int = Field(0)
    possible: int = Field(0)
    not_vulnerable: int = Field(0)
    blocked: int = Field(0)
    errors: int = Field(0)
    skipped: int = Field(0)
    
    # By category
    socket_findings: int = Field(0)
    capability_findings: int = Field(0)
    namespace_findings: int = Field(0)
    kernel_findings: int = Field(0)
    cve_findings: int = Field(0)
    cloud_findings: int = Field(0)


class SeveritySummary(BaseModel):
    """Summary by severity."""
    critical: int = Field(0)
    high: int = Field(0)
    medium: int = Field(0)
    low: int = Field(0)
    info: int = Field(0)


class CapabilitySummary(BaseModel):
    """Summary of dangerous capabilities."""
    total_effective: int = Field(0)
    dangerous_caps: List[str] = Field(default_factory=list)
    escape_enabling_caps: List[str] = Field(default_factory=list)
    risk_score: float = Field(0.0, ge=0.0, le=10.0)


class MitreSummary(BaseModel):
    """MITRE ATT&CK coverage summary."""
    techniques: List[str] = Field(default_factory=list)
    tactics: List[str] = Field(default_factory=list)
    procedures: List[str] = Field(default_factory=list)


class AnalysisMetadata(BaseModel):
    """Metadata about the analysis."""
    analysis_id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(None)
    duration_seconds: Optional[float] = Field(None)
    
    # Scope
    methods_tested: int = Field(0)
    cves_checked: int = Field(0)
    
    # Plugin info
    plugin_version: str = Field("1.0.0")
    
    # Host info
    hostname: Optional[str] = Field(None)


class AttackPath(BaseModel):
    """Recommended attack path."""
    id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    name: str = Field(...)
    description: str = Field("")
    steps: List[str] = Field(default_factory=list)
    methods: List[EscapeMethod] = Field(default_factory=list)
    success_probability: float = Field(0.5, ge=0.0, le=1.0)
    complexity: str = Field("medium")  # low, medium, high
    mitre_techniques: List[str] = Field(default_factory=list)


class DockerEscapeResult(BaseModel):
    """
    Complete output from Docker escape analysis.
    This is the main return type from hook_docker_escape().
    """
    # Metadata
    metadata: AnalysisMetadata = Field(default_factory=AnalysisMetadata)
    
    # Configuration used
    options: Optional[EscapeOptions] = Field(None)
    
    # Environment detection
    environment: ContainerEnvironment = Field(default_factory=ContainerEnvironment)
    
    # Results
    escape_attempts: List[EscapeAttemptResult] = Field(
        default_factory=list, description="All escape attempt results"
    )
    
    # Successful escapes
    successful_escapes: List[EscapeAttemptResult] = Field(
        default_factory=list, description="Only successful escapes"
    )
    
    # Vulnerabilities
    vulnerabilities: List[VulnerabilityFinding] = Field(
        default_factory=list, description="Detected vulnerabilities"
    )
    
    # Summaries
    method_summary: MethodSummary = Field(default_factory=MethodSummary)
    severity_summary: SeveritySummary = Field(default_factory=SeveritySummary)
    capability_summary: CapabilitySummary = Field(default_factory=CapabilitySummary)
    mitre_summary: MitreSummary = Field(default_factory=MitreSummary)
    
    # Attack guidance
    attack_paths: List[AttackPath] = Field(default_factory=list)
    recommended_methods: List[EscapeMethod] = Field(default_factory=list)
    
    # Remediation
    remediation_steps: List[str] = Field(default_factory=list)
    
    # Errors
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    
    # Reproduction
    reproduction_steps: Optional[List[ReproStep]] = Field(
        None, description="Global reproduction plan for key findings"
    )
    
    # Risk assessment
    overall_risk: SeverityLevel = Field(SeverityLevel.INFO)
    risk_score: float = Field(0.0, ge=0.0, le=10.0)
    escape_possible: bool = Field(False)
    escape_confirmed: bool = Field(False)
    
    # Timestamp
    completed_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# Legacy Compatibility
# =============================================================================

class DockerEscapeOutput(BaseModel):
    """
    Legacy output format for backward compatibility.
    Maps to the old simple format.
    """
    inside_docker: bool = Field(False)
    methods: List[EscapeAttemptResult] = Field(default_factory=list)
    
    @classmethod
    def from_result(cls, result: DockerEscapeResult) -> "DockerEscapeOutput":
        """Convert new result format to legacy format."""
        return cls(
            inside_docker=result.environment.inside_container,
            methods=result.escape_attempts
        )


# =============================================================================
# Exploit Chain Models
# =============================================================================

class ExploitChain(BaseModel):
    """Chain of techniques for complex escapes."""
    chain_id: str = Field(default_factory=lambda: str(__import__('uuid').uuid4()))
    name: str = Field(...)
    description: str = Field("")
    
    # Steps
    steps: List[EscapeMethod] = Field(default_factory=list)
    step_descriptions: List[str] = Field(default_factory=list)
    
    # Requirements
    required_capabilities: List[str] = Field(default_factory=list)
    requires_docker_sock: bool = Field(False)
    requires_privileged: bool = Field(False)
    requires_root: bool = Field(False)
    
    # Outcome
    final_outcome: str = Field("")
    provides_host_shell: bool = Field(False)
    provides_host_root: bool = Field(False)
    
    # Reliability
    success_rate: float = Field(0.5, ge=0.0, le=1.0)
    complexity: str = Field("medium")
    
    # MITRE
    mitre_techniques: List[str] = Field(default_factory=list)
