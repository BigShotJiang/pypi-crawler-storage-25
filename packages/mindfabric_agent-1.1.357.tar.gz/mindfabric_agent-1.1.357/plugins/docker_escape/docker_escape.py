"""
Docker Escape Plugin (Complete Edition)

A comprehensive plugin for container security assessment, escape vector detection,
and container breakout capabilities during authorized penetration testing.

Covers 50+ escape techniques across:
- Socket-based escapes (Docker, containerd, CRI-O)
- Capability-based escapes (20+ Linux capabilities)
- Namespace-based escapes (nsenter, pivot_root, unshare)
- Kernel-based escapes (core_pattern, eBPF, io_uring)
- Cgroup-based escapes (release_agent, notify_on_release)
- CVE-based escapes (20+ CVEs)
- Cloud/Kubernetes escapes (IMDS, service accounts)
- Network-based escapes (ARP spoofing, DNS poisoning)

Supports: Docker, containerd, CRI-O, Podman, and other OCI-compliant runtimes.
"""

import socket
import os
import json
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4

from plugins.base_plugin import BasePlugin

from .proto import (
    EscapeMethod,
    EscapeStatus,
    EscapeScope,
    EscapeOptions,
    EscapeAttemptResult,
    AnalysisMetadata,
    DockerEscapeResult,
    DockerEscapeOutput,
    escape_attempt_include_in_threat_graph,
)
from .modules.detection import (
    EnvironmentDetector,
    RuntimeSecurityDetector,
    OrchestrationEscapeDetector,
    AdvancedEscapeDetector,
    HardwareEscapeDetector,
)
from .modules.analysis import CapabilityAnalyzer, ResultProcessor, ContainerSecurityAnalyzer
from .modules.testing import EscapeTester
from .output_service import OutputService
from .modules.databases.ui_templates import (
    build_docker_escape_description,
    get_docker_escape_guidance,
    should_upgrade_docker_escape_description,
)


# =============================================================================
# Constants
# =============================================================================

PLUGIN_VERSION = "1.0.0"


# =============================================================================
# Plugin Class
# =============================================================================

class DockerEscapePlugin(BasePlugin):
    """
    Docker Escape and Container Security Assessment Plugin (Complete Edition).
    
    Performs comprehensive container security assessment including:
    - Environment detection (runtime, capabilities, mounts, kernel)
    - 50+ escape vector identification and testing
    - 20+ CVE-based vulnerability scanning
    - Cloud/Kubernetes specific attacks
    - Network-based attacks
    - Kernel-based escapes
    - Post-exploitation guidance
    
    MITRE ATT&CK Coverage:
    - T1611: Escape to Host
    - T1610: Deploy Container
    - T1068: Exploitation for Privilege Escalation
    - T1055: Process Injection
    - T1552: Unsecured Credentials
    - T1557: Adversary-in-the-Middle
    - T1078: Valid Accounts
    """
    
    VERSION = PLUGIN_VERSION
    PLUGIN_NAME = "docker_escape"
    _COOLDOWN_CACHE_PATH = "/tmp/mindfabric_docker_escape_cooldown.json"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        self._start_time: Optional[datetime] = None
        self._analysis_id: str = ""
        self._env = None
        # Initialize modular components
        self.env_detector = EnvironmentDetector()
        self.capability_analyzer = CapabilityAnalyzer()
        self.escape_tester = EscapeTester()
        self.runtime_security_detector = RuntimeSecurityDetector(self)
        self.orchestration_escape_detector = OrchestrationEscapeDetector(self)
        self.advanced_escape_detector = AdvancedEscapeDetector(self)
        self.hardware_escape_detector = HardwareEscapeDetector(self)
        self.container_security_analyzer = ContainerSecurityAnalyzer(self)
    
    # =========================================================================
    # Main Entry Points
    # =========================================================================
    
    async def run(self, **kwargs) -> DockerEscapeResult:
        """Main plugin execution method."""
        result = await self.hook_docker_escape(**kwargs)
        return self.to_security_scan_v1(self._with_canonical_findings(result))

    def _with_canonical_findings(self, output: Any) -> Dict[str, Any]:
        """
        Add plugin-owned `findings` for canonical security_scan v1.
        Avoids any plugin-specific parsing in security_contract.
        """
        try:
            if hasattr(output, "model_dump"):
                out = output.model_dump()
            elif hasattr(output, "dict"):
                out = output.dict()
            elif isinstance(output, dict):
                out = dict(output)
            else:
                out = {}
        except Exception:
            out = {}

        findings: List[Dict[str, Any]] = []

        def _escape_exploitation_cmd_strings(method_key: Any = None) -> List[str]:
            from .modules.databases.escape_databases import DOCKER_ESCAPE_COMMANDS
            k = str(method_key.value if hasattr(method_key, "value") else method_key or "").strip()
            tpl = DOCKER_ESCAPE_COMMANDS.get(k) or DOCKER_ESCAPE_COMMANDS["default"]
            return [
                str(c).strip()
                for c in (tpl.get("commands") or [])
                if c is not None and str(c).strip()
            ]

        try:
            cooldown_hours = int((self.options or {}).get("finding_cooldown_hours", 24))
        except Exception:
            cooldown_hours = 24
        cooldown_seconds = max(0, cooldown_hours) * 3600
        now_ts = int(datetime.utcnow().timestamp())

        def _load_cooldown_cache() -> Dict[str, int]:
            try:
                if os.path.exists(self._COOLDOWN_CACHE_PATH):
                    with open(self._COOLDOWN_CACHE_PATH, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, dict):
                            return {str(k): int(v) for k, v in data.items()}
            except Exception:
                pass
            return {}

        def _save_cooldown_cache(cache: Dict[str, int]) -> None:
            try:
                with open(self._COOLDOWN_CACHE_PATH, "w", encoding="utf-8") as f:
                    json.dump(cache, f)
            except Exception:
                pass

        cache = _load_cooldown_cache()
        seen_run_keys: set = set()

        opt_profile = None
        if isinstance(self.options, dict):
            opt_profile = self.options.get("host_profile")
        dumped_opts = out.get("options") if isinstance(out.get("options"), dict) else {}
        if not opt_profile and isinstance(dumped_opts, dict):
            opt_profile = dumped_opts.get("host_profile")
        host_profile = str(
            opt_profile or os.environ.get("MINDFABRIC_HOST_PROFILE", "production")
        ).strip().lower()
        lab_profiles = {"lab", "training", "intentionally_vulnerable", "vulnerable", "vuln", "ctf"}

        def _lab_cap_severity(sev: str, status_str: str) -> str:
            if host_profile not in lab_profiles:
                return sev
            if status_str in ("exploited", "confirmed"):
                return sev
            order = ("info", "low", "medium", "high", "critical")
            try:
                return order[min(order.index(sev), order.index("low"))]
            except ValueError:
                return "low"

        _posture_only_methods = {
            "cap_dac_override",
            "cap_mknod",
            "host_network",
            "proc_kcore",
            "proc_root_chroot",
        }

        def _escape_method_key(m: Any) -> str:
            if m is None:
                return ""
            v = getattr(m, "value", m)
            return str(v).strip().lower()

        def _artifact_summaries(arts: Any, limit: int = 24) -> List[Dict[str, Any]]:
            out_a: List[Dict[str, Any]] = []
            if not isinstance(arts, list):
                return out_a
            for x in arts[:limit]:
                if isinstance(x, dict):
                    out_a.append(
                        {
                            "artifact_type": x.get("artifact_type"),
                            "path": x.get("path"),
                            "description": (str(x.get("description") or "")[:500] or None),
                            "sensitive": x.get("sensitive"),
                            "size_bytes": x.get("size_bytes"),
                        }
                    )
                else:
                    out_a.append({"artifact_type": str(type(x).__name__), "path": str(x)[:500]})
            return out_a

        attempts = out.get("escape_attempts") or out.get("escapeAttempts") or []
        if isinstance(attempts, list):
            for a in attempts:
                if not isinstance(a, dict):
                    continue
                status = a.get("status")
                if hasattr(status, "value"):
                    status = status.value
                status_str = str(status or "").lower()
                sev = a.get("severity") or "medium"
                if hasattr(sev, "value"):
                    sev = sev.value
                sev_lower = str(sev).lower()
                method = a.get("method")
                if hasattr(method, "value"):
                    method = method.value
                m_low = str(method or "").strip().lower()
                method_key = _escape_method_key(method)
                if (
                    status_str not in ("exploited", "confirmed")
                    and m_low in _posture_only_methods
                    and sev_lower in ("critical", "high")
                ):
                    sev_lower = "high" if sev_lower == "critical" else "medium"
                if not escape_attempt_include_in_threat_graph(status_str, sev_lower):
                    continue
                success = status_str in ("exploited", "confirmed")
                # Unconfirmed posture-only signals are not actionable threats; do not emit bundles or rows.
                if m_low in _posture_only_methods and not success:
                    continue

                sev_lower = _lab_cap_severity(sev_lower, status_str)
                if not escape_attempt_include_in_threat_graph(status_str, sev_lower):
                    continue
                dedup_key = f"{socket.gethostname()}|{method_key}|{status_str}"
                if dedup_key in seen_run_keys:
                    continue
                seen_run_keys.add(dedup_key)
                last_ts = cache.get(dedup_key, 0)
                if cooldown_seconds > 0 and last_ts > 0 and (now_ts - last_ts) < cooldown_seconds:
                    continue
                cache[dedup_key] = now_ts

                exploitation_commands = None
                cmd_obj = a.get("commands")
                if isinstance(cmd_obj, dict):
                    cmds = cmd_obj.get("commands")
                    if isinstance(cmds, list):
                        exploitation_commands = [str(c).strip() for c in cmds if c is not None and str(c).strip()]
                if not exploitation_commands:
                    from .modules.databases.escape_databases import DOCKER_ESCAPE_COMMANDS
                    m_key = method_key or str(method or "").strip()
                    tpl = DOCKER_ESCAPE_COMMANDS.get(m_key) or DOCKER_ESCAPE_COMMANDS["default"]
                    exploitation_commands = [
                        str(c).strip()
                        for c in (tpl.get("commands") or [])
                        if c is not None and str(c).strip()
                    ]

                impact, recs, remediation_steps = get_docker_escape_guidance(method=str(method) if method else None)
                raw_desc = a.get("message") or ""
                description = raw_desc
                if should_upgrade_docker_escape_description(description):
                    description = build_docker_escape_description(
                        method=str(method) if method else None, status=status_str, message=raw_desc
                    )
                if not impact:
                    impact = (
                        "Container escape conditions can allow an attacker to break isolation and execute code on the host. "
                        "Even if exploitation was not completed, the prerequisite is a high-value hardening target."
                    )
                if not recs:
                    recs = [
                        {"title": "Reduce container privileges", "description": "Drop dangerous capabilities and avoid privileged/host namespace settings.", "priority": "high"},
                        {"title": "Enable runtime hardening", "description": "Enforce seccomp/AppArmor/SELinux and no_new_privileges where possible.", "priority": "medium"},
                    ]

                arts_raw = a.get("artifacts")
                evidence: Dict[str, Any] = {
                    "source": "docker_escape.escape_attempts",
                    "status": status_str,
                    "method": method_key or m_low,
                    "method_raw": str(method) if method is not None else None,
                    "cve_id": a.get("cve_id"),
                    "hostname": socket.gethostname(),
                    "host_profile": host_profile,
                    "detector_message": raw_desc or None,
                    "technical_details": a.get("technical_details"),
                    "requirements_met": a.get("requirements_met"),
                    "requirements_missing": a.get("requirements_missing"),
                    "impact_description": a.get("impact_description"),
                    "remediation": a.get("remediation"),
                    "demo_next_steps": a.get("demo_next_steps"),
                    "duration_ms": a.get("duration_ms"),
                    "artifact_path": a.get("artifact_path"),
                    "artifact_content_preview": (
                        (str(a.get("artifact_content") or "")[:1200] or None)
                        if a.get("artifact_content")
                        else None
                    ),
                }
                details = a.get("details")
                if details is not None:
                    evidence["details"] = details
                if not evidence.get("details"):
                    _parts = [
                        str(a.get("technical_details") or "").strip(),
                        str(raw_desc or "").strip(),
                    ]
                    if a.get("artifact_path"):
                        _parts.append(f"artifact_path={a.get('artifact_path')}")
                    if a.get("demo_next_steps"):
                        _parts.append(f"next_steps={a.get('demo_next_steps')}")
                    evidence["details"] = " | ".join(p for p in _parts if p) or None
                if not a.get("cve_id"):
                    evidence["cve_note"] = "Not applicable (behavioral / namespace exposure, no CVE identifier)."
                summ = _artifact_summaries(arts_raw)
                if summ:
                    evidence["artifacts"] = summ
                elif arts_raw:
                    evidence["artifacts"] = arts_raw
                elif a.get("artifact_path"):
                    evidence["artifacts"] = [
                        {
                            "artifact_type": "filesystem_probe",
                            "path": a.get("artifact_path"),
                            "description": "Path used to verify host exposure from the container",
                        }
                    ]
                mitre = a.get("mitre_techniques")
                if mitre:
                    evidence["mitre_techniques"] = mitre

                findings.append({
                    "id": a.get("id"),
                    "title": f"Docker escape: {method_key}" if method_key else "Docker escape attempt",
                    "description": description,
                    "impact": impact,
                    "severity": sev_lower,
                    "category": "Docker Escape",
                    "threat_type": "container_escape",
                    "commands": cmd_obj,
                    "exploitation_commands": exploitation_commands,
                    "recommendations": recs,
                    "remediation_steps": remediation_steps,
                    "affected_resources": [
                        {
                            "type": "container_workload",
                            "hostname": socket.gethostname(),
                            **(
                                {"container_id": cid}
                                if (cid := (a.get("container_id") or a.get("containerId")))
                                else {}
                            ),
                        }
                    ],
                    "evidence": evidence,
                    "mitre_attack": a.get("mitre_techniques"),
                })

        vulns = out.get("vulnerabilities") or []
        if isinstance(vulns, list):
            for v in vulns:
                if not isinstance(v, dict):
                    continue
                sev = v.get("severity") or "medium"
                if hasattr(sev, "value"):
                    sev = sev.value
                vtype = v.get("vulnerability_type")
                if hasattr(vtype, "value"):
                    vtype = vtype.value
                cve = v.get("cve") if isinstance(v.get("cve"), dict) else {}
                title = (cve.get("cve_id") or v.get("id") or vtype or "Container vulnerability")
                impact, recs, remediation_steps = get_docker_escape_guidance(
                    method=str(cve.get("cve_id") or v.get("id") or vtype or ""),
                    title=str(title),
                )
                vuln_method = str(cve.get("cve_id") or v.get("id") or vtype or "").strip()
                cid_v = v.get("container_id") or v.get("containerId")
                findings.append({
                    "id": v.get("id"),
                    "title": str(title),
                    "description": cve.get("description") or v.get("evidence") or "",
                    "impact": impact,
                    "severity": str(sev).lower(),
                    "category": "Docker Escape",
                    "threat_type": "container_vulnerability",
                    "exploitation_commands": _escape_exploitation_cmd_strings(vuln_method),
                    "reproduction_steps": v.get("reproduction_steps"),
                    "recommendations": recs,
                    "remediation_steps": remediation_steps,
                    "affected_resources": [
                        {
                            "type": "container_workload",
                            "hostname": socket.gethostname(),
                            **({"container_id": cid_v} if cid_v else {}),
                        }
                    ],
                    "evidence": {"source": "docker_escape.vulnerabilities", **v},
                    "mitre_attack": v.get("mitre_techniques"),
                })

        out["findings"] = findings
        _save_cooldown_cache(cache)
        return out
    
    async def hook_docker_escape(
        self,
        options: Optional[EscapeOptions] = None,
        **kwargs
    ) -> DockerEscapeResult:
        """
        Perform comprehensive Docker container escape assessment.
        
        Args:
            options: Assessment configuration options
            
        Returns:
            DockerEscapeResult: Comprehensive assessment results
            
        Examples:
            # Full assessment
            result = await plugin.hook_docker_escape()
            
            # Quick scan
            result = await plugin.hook_docker_escape(
                options=EscapeOptions(quick_scan=True)
            )
            
            # Deep scan with kernel exploits
            result = await plugin.hook_docker_escape(
                options=EscapeOptions(deep_scan=True)
            )
            
            # Specific methods only
            result = await plugin.hook_docker_escape(
                options=EscapeOptions(
                    scope=EscapeScope(
                        target_methods=[EscapeMethod.DOCKER_SOCK, EscapeMethod.CAP_SYS_ADMIN]
                    )
                )
            )
        """
        self._start_time = datetime.utcnow()
        self._analysis_id = str(uuid4())
        
        if options is None:
            options = EscapeOptions()
        
        # Initialize result
        result = DockerEscapeResult(
            metadata=AnalysisMetadata(
                analysis_id=self._analysis_id,
                started_at=self._start_time,
                plugin_version=self.VERSION,
                hostname=socket.gethostname()
            ),
            options=options
        )
        
        try:
            # Phase 1: Environment Detection
            result.environment = await self.env_detector.detect_environment()
            self._env = result.environment
            
            # Phase 1.1: Check for kernel escape paths
            kernel_escape_paths = self.env_detector.check_kernel_escape_paths()
            if kernel_escape_paths:
                result.environment.kernel_escape_paths = kernel_escape_paths
                for path_name, path_info in kernel_escape_paths.items():
                    if path_info.get("writable"):
                        result.warnings.append(f"Writable kernel path found: {path_info.get('path')} ({path_name})")
            
            if not result.environment.inside_container:
                result.warnings.append("Not running inside a container")
                result.escape_attempts.append(EscapeAttemptResult(
                    method=EscapeMethod.DOCKER_SOCK,
                    status=EscapeStatus.SKIPPED,
                    message="Agent not running inside Docker container"
                ))
                processor = ResultProcessor(self._start_time)
                return processor.finalize(result)
            
            # Phase 2: Capability Analysis
            result.capability_summary = self.capability_analyzer.analyze(result.environment)
            
            # Phase 3: Socket-based Escapes
            if options.scope.test_socket_escapes:
                socket_results = await self.escape_tester._test_socket_escapes(result.environment, options)
                result.escape_attempts.extend(socket_results)
            
            # Phase 4: Capability-based Escapes
            if options.scope.test_capability_escapes:
                cap_results = await self.escape_tester._test_capability_escapes(result.environment, options)
                result.escape_attempts.extend(cap_results)
            
            # Phase 5: Namespace-based Escapes
            if options.scope.test_namespace_escapes:
                ns_results = await self.escape_tester._test_namespace_escapes(result.environment, options)
                result.escape_attempts.extend(ns_results)
            
            # Phase 6: Kernel-based Escapes
            if options.scope.test_kernel_escapes and (options.deep_scan or not options.quick_scan):
                kernel_results = await self.escape_tester._test_kernel_escapes(result.environment, options)
                result.escape_attempts.extend(kernel_results)
            
            # Phase 7: CVE Scanning
            if options.scope.test_cve_escapes and not options.quick_scan:
                cve_results = await self.escape_tester._scan_cves(result.environment, options)
                result.vulnerabilities = cve_results
            
            # Phase 8: Cloud/Kubernetes
            if options.scope.test_cloud_escapes:
                cloud_results = await self.escape_tester._test_cloud_escapes(result.environment, options)
                result.escape_attempts.extend(cloud_results)
            
            # Phase 9: Network-based Escapes
            if options.scope.test_network_escapes and not options.quick_scan:
                net_results = await self.escape_tester._test_network_escapes(result.environment, options)
                result.escape_attempts.extend(net_results)
            
            # Phase 10: Security Policy Checks
            security_results = await self.escape_tester._test_security_policies(result.environment, options)
            result.escape_attempts.extend(security_results)
            
            # Phase 10.5: Runtime Security Bypass Detection (Seccomp, AppArmor, SELinux)
            runtime_status, runtime_findings = self.runtime_security_detector.detect_all()
            result.runtime_security_status = runtime_status
            
            # Convert runtime security findings to escape attempts
            for finding in runtime_findings:
                # Map runtime-security findings to a relevant EscapeMethod so we don't show unrelated commands.
                module = getattr(finding, "module", None)
                module_val = getattr(module, "value", None) or str(module or "")
                if module_val == "seccomp":
                    mapped_method = EscapeMethod.SECCOMP_DISABLED
                elif module_val == "apparmor":
                    mapped_method = EscapeMethod.APPARMOR_DISABLED
                elif module_val == "selinux":
                    mapped_method = EscapeMethod.SELINUX_DISABLED
                else:
                    mapped_method = EscapeMethod.SYSCALL_ABUSE

                escape_attempt = EscapeAttemptResult(
                    method=mapped_method,
                    status=EscapeStatus.VULNERABLE if finding.risk.value in ["critical", "high"] else EscapeStatus.POSSIBLE,
                    message=f"{finding.title}: {finding.description}",
                    details={
                        "security_module": finding.module.value,
                        "status": finding.status.value,
                        "risk": finding.risk.value,
                        "bypass_techniques": finding.bypass_techniques,
                        "evidence": finding.evidence,
                        "remediation": finding.remediation,
                        "mitre": finding.mitre_technique,
                    }
                )
                result.escape_attempts.append(escape_attempt)
            
            # Add warnings for critical runtime security findings
            for finding in self.runtime_security_detector.get_critical_findings():
                result.warnings.append(f"[{finding.module.value.upper()}] {finding.title}")
            
            # Phase 11: Generate summaries and recommendations
            processor = ResultProcessor(self._start_time)
            result = processor.finalize(result)
            
        except Exception as e:
            result.errors.append(f"Assessment error: {str(e)}")
            import traceback
            result.errors.append(traceback.format_exc())
        
        # Expose data for output service and build final output with reproduction steps
        self.escape_attempts = result.escape_attempts
        self.environment = result.environment
        self.vulnerabilities = result.vulnerabilities
        self.method_summary = getattr(result, "method_summary", None)
        self.severity_summary = getattr(result, "severity_summary", None)
        self.capability_summary = getattr(result, "capability_summary", None)
        self.mitre_summary = getattr(result, "mitre_summary", None)
        self.attack_paths = getattr(result, "attack_paths", [])
        self.recommended_methods = getattr(result, "recommended_methods", [])
        self.remediation_steps = getattr(result, "remediation_steps", [])
        self.errors = result.errors
        self.warnings = result.warnings

        output_service = OutputService(self)
        return output_service.create_output(options)
    
    async def hook_escape(self, **kwargs) -> DockerEscapeOutput:
        """Legacy hook for backward compatibility."""
        result = await self.hook_docker_escape(**kwargs)
        return DockerEscapeOutput.from_result(result)


# =============================================================================
# Plugin Registration
# =============================================================================

def register_plugin():
    """Register the plugin with MindFabric."""
    return DockerEscapePlugin()
