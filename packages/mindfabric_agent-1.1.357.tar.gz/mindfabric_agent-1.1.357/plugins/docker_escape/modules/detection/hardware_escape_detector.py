"""
Hardware-based Container Escape Detector

Detects escape vectors related to hardware devices:
- GPU device escape (NVIDIA, AMD)
- TPM bypass and abuse
- Hardware passthrough vulnerabilities
- DMA attacks
- PCI/USB device escape
- FPGA access abuse

MITRE ATT&CK:
- T1611: Escape to Host
- T1068: Exploitation for Privilege Escalation
- T1601: Modify System Image
"""

import os
import re
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


class EscapeSeverity(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class HardwareEscapeType(str, Enum):
    """Types of hardware-based escapes."""
    GPU_ESCAPE = "gpu_escape"
    TPM_BYPASS = "tpm_bypass"
    DMA_ATTACK = "dma_attack"
    PCIE_ESCAPE = "pcie_escape"
    USB_ESCAPE = "usb_escape"
    FPGA_ABUSE = "fpga_abuse"
    MEMORY_MAPPING = "memory_mapping"
    DEVICE_PLUGIN = "device_plugin"


# =============================================================================
# GPU Escape Vulnerabilities
# =============================================================================

GPU_ESCAPE_VECTORS = {
    "nvidia_device_access": {
        "name": "NVIDIA GPU Device Access",
        "description": "Direct access to NVIDIA GPU device files",
        "device_paths": [
            "/dev/nvidia0",
            "/dev/nvidia1",
            "/dev/nvidiactl",
            "/dev/nvidia-uvm",
            "/dev/nvidia-uvm-tools",
            "/dev/nvidia-modeset",
        ],
        "severity": EscapeSeverity.HIGH,
        "escape_method": "GPU memory can be used to read/write host memory",
        "mitre": "T1611",
        "cves": [
            "CVE-2021-1056",  # NVIDIA GPU driver vulnerability
            "CVE-2022-28181",  # Memory corruption
            "CVE-2023-0180",  # Kernel memory access
        ],
    },
    "nvidia_mig_bypass": {
        "name": "NVIDIA MIG Bypass",
        "description": "Multi-Instance GPU partition escape",
        "check": "Check for MIG device access without proper isolation",
        "severity": EscapeSeverity.MEDIUM,
        "mitre": "T1611",
    },
    "cuda_toolkit_abuse": {
        "name": "CUDA Toolkit Abuse",
        "description": "CUDA libraries can be used for privilege escalation",
        "libraries": [
            "libcuda.so",
            "libnvidia-ml.so",
            "libnvidia-ptxjitcompiler.so",
        ],
        "severity": EscapeSeverity.MEDIUM,
        "mitre": "T1068",
    },
    "amd_gpu_escape": {
        "name": "AMD GPU Escape",
        "description": "AMD GPU device access vulnerabilities",
        "device_paths": [
            "/dev/dri/card0",
            "/dev/dri/renderD128",
            "/dev/kfd",
        ],
        "severity": EscapeSeverity.HIGH,
        "mitre": "T1611",
        "cves": [
            "CVE-2020-12912",  # AMD GPU driver vulnerability
        ],
    },
    "rocm_escape": {
        "name": "ROCm Platform Escape",
        "description": "AMD ROCm platform vulnerabilities",
        "check": "ROCm can provide direct hardware access",
        "severity": EscapeSeverity.MEDIUM,
        "mitre": "T1611",
    },
}


# =============================================================================
# TPM Vulnerabilities
# =============================================================================

TPM_VULNERABILITIES = {
    "tpm_device_access": {
        "name": "TPM Device Direct Access",
        "description": "Direct access to TPM device",
        "device_paths": [
            "/dev/tpm0",
            "/dev/tpmrm0",
        ],
        "severity": EscapeSeverity.HIGH,
        "escape_method": "TPM can be used to extract secrets or bypass security",
        "mitre": "T1552",
    },
    "tpm_sniffing": {
        "name": "TPM Communication Sniffing",
        "description": "Sniff TPM communications for secrets",
        "check": "Check for TPM bus access",
        "severity": EscapeSeverity.HIGH,
        "mitre": "T1552",
        "cves": [
            "CVE-2023-1017",  # TPM 2.0 out-of-bounds write
            "CVE-2023-1018",  # TPM 2.0 out-of-bounds read
        ],
    },
    "tpm_reset_attack": {
        "name": "TPM Reset Attack",
        "description": "Reset TPM to bypass security measures",
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1601",
    },
    "bitlocker_bypass": {
        "name": "BitLocker TPM Bypass",
        "description": "Bypass BitLocker encryption via TPM",
        "check": "TPM can be used to extract BitLocker keys",
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1552.004",
    },
}


# =============================================================================
# DMA Attack Vectors
# =============================================================================

DMA_ATTACK_VECTORS = {
    "thunderbolt_dma": {
        "name": "Thunderbolt DMA Attack",
        "description": "Direct Memory Access via Thunderbolt",
        "device_paths": [
            "/sys/bus/thunderbolt",
            "/dev/thunderbolt",
        ],
        "severity": EscapeSeverity.CRITICAL,
        "escape_method": "Direct memory access to host",
        "mitre": "T1200",
        "cves": [
            "CVE-2020-8938",  # Thunderspy attack
        ],
    },
    "pcie_dma": {
        "name": "PCIe DMA Attack",
        "description": "Direct Memory Access via PCIe devices",
        "check": "Check for PCIe passthrough without IOMMU",
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1200",
    },
    "firewire_dma": {
        "name": "FireWire DMA Attack",
        "description": "Direct Memory Access via FireWire",
        "device_paths": [
            "/dev/fw0",
            "/dev/fw1",
        ],
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1200",
    },
    "iommu_bypass": {
        "name": "IOMMU Bypass",
        "description": "Bypass IOMMU protection",
        "check": "Check for IOMMU configuration",
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1611",
        "iommu_checks": [
            "/sys/kernel/iommu_groups",
            "/sys/class/iommu",
        ],
    },
}


# =============================================================================
# Other Hardware Escapes
# =============================================================================

OTHER_HARDWARE_ESCAPES = {
    "usb_device_abuse": {
        "name": "USB Device Abuse",
        "description": "USB device passthrough abuse",
        "device_paths": [
            "/dev/bus/usb",
            "/dev/usb",
        ],
        "severity": EscapeSeverity.HIGH,
        "escape_method": "USB devices can be used for data exfiltration",
        "mitre": "T1091",
    },
    "fpga_escape": {
        "name": "FPGA Device Escape",
        "description": "FPGA devices with direct memory access",
        "device_paths": [
            "/dev/xdma",
            "/dev/qdma",
            "/dev/fpga",
        ],
        "severity": EscapeSeverity.CRITICAL,
        "mitre": "T1611",
    },
    "infiniband_escape": {
        "name": "InfiniBand RDMA Escape",
        "description": "InfiniBand Remote DMA access",
        "device_paths": [
            "/dev/infiniband",
            "/dev/uverbs0",
        ],
        "severity": EscapeSeverity.HIGH,
        "escape_method": "RDMA can read/write remote host memory",
        "mitre": "T1611",
    },
    "sgx_bypass": {
        "name": "Intel SGX Bypass",
        "description": "Bypass Intel SGX enclave protection",
        "device_paths": [
            "/dev/sgx_enclave",
            "/dev/sgx_provision",
        ],
        "severity": EscapeSeverity.HIGH,
        "mitre": "T1611",
        "cves": [
            "CVE-2020-0551",  # LVI attack on SGX
            "CVE-2021-0186",  # SGX bypass
        ],
    },
    "sev_bypass": {
        "name": "AMD SEV Bypass",
        "description": "Bypass AMD Secure Encrypted Virtualization",
        "check": "Check for SEV vulnerabilities",
        "severity": EscapeSeverity.HIGH,
        "mitre": "T1611",
        "cves": [
            "CVE-2019-9836",  # SEV-ES bypass
            "CVE-2021-26311",  # SEV key extraction
        ],
    },
    "memory_map_escape": {
        "name": "Memory Mapping Escape",
        "description": "/dev/mem or /dev/kmem access",
        "device_paths": [
            "/dev/mem",
            "/dev/kmem",
            "/dev/port",
        ],
        "severity": EscapeSeverity.CRITICAL,
        "escape_method": "Direct kernel/physical memory access",
        "mitre": "T1611",
    },
}


@dataclass
class HardwareEscapeFinding:
    """A hardware escape finding."""
    escape_type: HardwareEscapeType
    severity: EscapeSeverity
    name: str
    description: str
    device_path: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    cves: List[str] = field(default_factory=list)
    exploitation_method: str = ""
    mitre_technique: str = ""
    remediation: str = ""


@dataclass
class HardwareSecurityReport:
    """Hardware security analysis report."""
    findings: List[HardwareEscapeFinding] = field(default_factory=list)
    gpu_present: bool = False
    tpm_present: bool = False
    dma_devices: List[str] = field(default_factory=list)
    iommu_enabled: bool = False
    risk_score: float = 0.0


class HardwareEscapeDetector:
    """Detector for hardware-based container escapes."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[HardwareEscapeFinding] = []
    
    async def detect_gpu_escapes(self) -> List[HardwareEscapeFinding]:
        """
        Detect GPU-based escape vectors.
        
        Returns:
            List of GPU escape findings
        """
        findings = []
        
        # Check NVIDIA GPUs
        nvidia_vectors = GPU_ESCAPE_VECTORS["nvidia_device_access"]
        for device_path in nvidia_vectors["device_paths"]:
            if os.path.exists(device_path):
                accessible = os.access(device_path, os.R_OK | os.W_OK)
                
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.GPU_ESCAPE,
                    severity=nvidia_vectors["severity"] if accessible else EscapeSeverity.LOW,
                    name=nvidia_vectors["name"],
                    description=f"NVIDIA GPU device accessible: {device_path}",
                    device_path=device_path,
                    evidence={
                        "exists": True,
                        "readable": os.access(device_path, os.R_OK),
                        "writable": os.access(device_path, os.W_OK),
                    },
                    cves=nvidia_vectors.get("cves", []),
                    exploitation_method=nvidia_vectors.get("escape_method", ""),
                    mitre_technique=nvidia_vectors.get("mitre", "T1611"),
                    remediation="Remove GPU device access if not required; use device isolation",
                ))
        
        # Check AMD GPUs
        amd_vectors = GPU_ESCAPE_VECTORS["amd_gpu_escape"]
        for device_path in amd_vectors["device_paths"]:
            if os.path.exists(device_path):
                accessible = os.access(device_path, os.R_OK | os.W_OK)
                
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.GPU_ESCAPE,
                    severity=amd_vectors["severity"] if accessible else EscapeSeverity.LOW,
                    name=amd_vectors["name"],
                    description=f"AMD GPU device accessible: {device_path}",
                    device_path=device_path,
                    evidence={
                        "exists": True,
                        "readable": os.access(device_path, os.R_OK),
                        "writable": os.access(device_path, os.W_OK),
                    },
                    cves=amd_vectors.get("cves", []),
                    mitre_technique=amd_vectors.get("mitre", "T1611"),
                    remediation="Remove GPU device access if not required",
                ))
        
        # Check for CUDA libraries
        cuda_info = GPU_ESCAPE_VECTORS["cuda_toolkit_abuse"]
        cuda_paths = [
            "/usr/lib/x86_64-linux-gnu",
            "/usr/local/cuda/lib64",
            "/usr/lib",
        ]
        
        for lib in cuda_info["libraries"]:
            for path in cuda_paths:
                lib_path = os.path.join(path, lib)
                if os.path.exists(lib_path):
                    findings.append(HardwareEscapeFinding(
                        escape_type=HardwareEscapeType.GPU_ESCAPE,
                        severity=cuda_info["severity"],
                        name=cuda_info["name"],
                        description=f"CUDA library present: {lib}",
                        device_path=lib_path,
                        evidence={"library": lib},
                        mitre_technique=cuda_info.get("mitre", "T1068"),
                        remediation="Remove CUDA libraries if GPU is not required",
                    ))
                    break
        
        return findings
    
    async def detect_tpm_vulnerabilities(self) -> List[HardwareEscapeFinding]:
        """
        Detect TPM-related vulnerabilities.
        
        Returns:
            List of TPM vulnerability findings
        """
        findings = []
        
        tpm_info = TPM_VULNERABILITIES["tpm_device_access"]
        for device_path in tpm_info["device_paths"]:
            if os.path.exists(device_path):
                accessible = os.access(device_path, os.R_OK | os.W_OK)
                
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.TPM_BYPASS,
                    severity=tpm_info["severity"] if accessible else EscapeSeverity.MEDIUM,
                    name=tpm_info["name"],
                    description=f"TPM device accessible: {device_path}",
                    device_path=device_path,
                    evidence={
                        "exists": True,
                        "readable": os.access(device_path, os.R_OK),
                        "writable": os.access(device_path, os.W_OK),
                    },
                    exploitation_method=tpm_info.get("escape_method", ""),
                    mitre_technique=tpm_info.get("mitre", "T1552"),
                    remediation="Remove TPM device access from container",
                ))
        
        # Check for TPM sniffing vulnerabilities
        sniff_info = TPM_VULNERABILITIES["tpm_sniffing"]
        
        if os.path.exists("/sys/class/tpm"):
            findings.append(HardwareEscapeFinding(
                escape_type=HardwareEscapeType.TPM_BYPASS,
                severity=sniff_info["severity"],
                name=sniff_info["name"],
                description="TPM sysfs accessible - potential for communication sniffing",
                device_path="/sys/class/tpm",
                evidence={"sysfs_accessible": True},
                cves=sniff_info.get("cves", []),
                mitre_technique=sniff_info.get("mitre", "T1552"),
                remediation="Restrict TPM sysfs access",
            ))
        
        return findings
    
    async def detect_dma_attacks(self) -> List[HardwareEscapeFinding]:
        """
        Detect DMA attack vectors.
        
        Returns:
            List of DMA attack findings
        """
        findings = []
        
        # Check Thunderbolt
        thunderbolt_info = DMA_ATTACK_VECTORS["thunderbolt_dma"]
        for device_path in thunderbolt_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.DMA_ATTACK,
                    severity=thunderbolt_info["severity"],
                    name=thunderbolt_info["name"],
                    description=f"Thunderbolt DMA accessible: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    cves=thunderbolt_info.get("cves", []),
                    exploitation_method=thunderbolt_info.get("escape_method", ""),
                    mitre_technique=thunderbolt_info.get("mitre", "T1200"),
                    remediation="Disable Thunderbolt passthrough; enable IOMMU",
                ))
        
        # Check FireWire
        firewire_info = DMA_ATTACK_VECTORS["firewire_dma"]
        for device_path in firewire_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.DMA_ATTACK,
                    severity=firewire_info["severity"],
                    name=firewire_info["name"],
                    description=f"FireWire DMA accessible: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    mitre_technique=firewire_info.get("mitre", "T1200"),
                    remediation="Remove FireWire device access",
                ))
        
        # Check IOMMU status
        iommu_info = DMA_ATTACK_VECTORS["iommu_bypass"]
        iommu_enabled = os.path.exists("/sys/kernel/iommu_groups") and \
                        len(os.listdir("/sys/kernel/iommu_groups")) > 0 if os.path.exists("/sys/kernel/iommu_groups") else False
        
        if not iommu_enabled:
            findings.append(HardwareEscapeFinding(
                escape_type=HardwareEscapeType.DMA_ATTACK,
                severity=iommu_info["severity"],
                name=iommu_info["name"],
                description="IOMMU not enabled - DMA attacks possible",
                evidence={
                    "iommu_enabled": False,
                },
                mitre_technique=iommu_info.get("mitre", "T1611"),
                remediation="Enable IOMMU in BIOS and kernel (intel_iommu=on or amd_iommu=on)",
            ))
        
        return findings
    
    async def detect_memory_mapping_escapes(self) -> List[HardwareEscapeFinding]:
        """
        Detect memory mapping escape vectors.
        
        Returns:
            List of memory mapping findings
        """
        findings = []
        
        mem_info = OTHER_HARDWARE_ESCAPES["memory_map_escape"]
        for device_path in mem_info["device_paths"]:
            if os.path.exists(device_path):
                accessible = os.access(device_path, os.R_OK)
                
                if accessible:
                    findings.append(HardwareEscapeFinding(
                        escape_type=HardwareEscapeType.MEMORY_MAPPING,
                        severity=mem_info["severity"],
                        name=mem_info["name"],
                        description=f"Direct memory access device accessible: {device_path}",
                        device_path=device_path,
                        evidence={
                            "exists": True,
                            "readable": True,
                        },
                        exploitation_method=mem_info.get("escape_method", ""),
                        mitre_technique=mem_info.get("mitre", "T1611"),
                        remediation="Remove /dev/mem, /dev/kmem, /dev/port access",
                    ))
        
        return findings
    
    async def detect_other_hardware_escapes(self) -> List[HardwareEscapeFinding]:
        """
        Detect other hardware-based escape vectors.
        
        Returns:
            List of hardware escape findings
        """
        findings = []
        
        # USB devices
        usb_info = OTHER_HARDWARE_ESCAPES["usb_device_abuse"]
        for device_path in usb_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.USB_ESCAPE,
                    severity=usb_info["severity"],
                    name=usb_info["name"],
                    description=f"USB device access: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    exploitation_method=usb_info.get("escape_method", ""),
                    mitre_technique=usb_info.get("mitre", "T1091"),
                    remediation="Remove USB device access if not required",
                ))
        
        # FPGA devices
        fpga_info = OTHER_HARDWARE_ESCAPES["fpga_escape"]
        for device_path in fpga_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.FPGA_ABUSE,
                    severity=fpga_info["severity"],
                    name=fpga_info["name"],
                    description=f"FPGA device accessible: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    mitre_technique=fpga_info.get("mitre", "T1611"),
                    remediation="Remove FPGA device access; use proper isolation",
                ))
        
        # InfiniBand
        ib_info = OTHER_HARDWARE_ESCAPES["infiniband_escape"]
        for device_path in ib_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.PCIE_ESCAPE,
                    severity=ib_info["severity"],
                    name=ib_info["name"],
                    description=f"InfiniBand RDMA device accessible: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    exploitation_method=ib_info.get("escape_method", ""),
                    mitre_technique=ib_info.get("mitre", "T1611"),
                    remediation="Remove InfiniBand access if not required",
                ))
        
        # Intel SGX
        sgx_info = OTHER_HARDWARE_ESCAPES["sgx_bypass"]
        for device_path in sgx_info["device_paths"]:
            if os.path.exists(device_path):
                findings.append(HardwareEscapeFinding(
                    escape_type=HardwareEscapeType.DEVICE_PLUGIN,
                    severity=sgx_info["severity"],
                    name=sgx_info["name"],
                    description=f"Intel SGX device accessible: {device_path}",
                    device_path=device_path,
                    evidence={"exists": True},
                    cves=sgx_info.get("cves", []),
                    mitre_technique=sgx_info.get("mitre", "T1611"),
                    remediation="Update SGX SDK; apply microcode patches",
                ))
        
        return findings
    
    async def run_full_detection(self) -> HardwareSecurityReport:
        """
        Run full hardware escape detection.
        
        Returns:
            HardwareSecurityReport
        """
        all_findings = []
        
        # Detect all hardware escape vectors
        gpu_findings = await self.detect_gpu_escapes()
        all_findings.extend(gpu_findings)
        
        tpm_findings = await self.detect_tpm_vulnerabilities()
        all_findings.extend(tpm_findings)
        
        dma_findings = await self.detect_dma_attacks()
        all_findings.extend(dma_findings)
        
        mem_findings = await self.detect_memory_mapping_escapes()
        all_findings.extend(mem_findings)
        
        other_findings = await self.detect_other_hardware_escapes()
        all_findings.extend(other_findings)
        
        # Determine GPU/TPM presence
        gpu_present = any(f.escape_type == HardwareEscapeType.GPU_ESCAPE for f in all_findings)
        tpm_present = any(f.escape_type == HardwareEscapeType.TPM_BYPASS for f in all_findings)
        
        # Get DMA devices
        dma_devices = [f.device_path for f in all_findings if f.escape_type == HardwareEscapeType.DMA_ATTACK]
        
        # Check IOMMU
        iommu_enabled = os.path.exists("/sys/kernel/iommu_groups") and \
                        len(os.listdir("/sys/kernel/iommu_groups")) > 0 if os.path.exists("/sys/kernel/iommu_groups") else False
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(all_findings)
        
        self.findings = all_findings
        
        return HardwareSecurityReport(
            findings=all_findings,
            gpu_present=gpu_present,
            tpm_present=tpm_present,
            dma_devices=dma_devices,
            iommu_enabled=iommu_enabled,
            risk_score=risk_score,
        )
    
    def _calculate_risk_score(self, findings: List[HardwareEscapeFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            EscapeSeverity.CRITICAL: 10,
            EscapeSeverity.HIGH: 7,
            EscapeSeverity.MEDIUM: 4,
            EscapeSeverity.LOW: 1,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def get_findings(self) -> List[HardwareEscapeFinding]:
        """Get all findings."""
        return self.findings
    
    def get_all_vectors(self) -> Dict[str, Any]:
        """Get all hardware escape vector databases."""
        return {
            "gpu_escapes": GPU_ESCAPE_VECTORS,
            "tpm_vulnerabilities": TPM_VULNERABILITIES,
            "dma_attacks": DMA_ATTACK_VECTORS,
            "other_escapes": OTHER_HARDWARE_ESCAPES,
        }

