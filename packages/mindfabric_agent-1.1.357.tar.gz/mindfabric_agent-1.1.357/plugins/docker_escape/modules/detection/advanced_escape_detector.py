"""
Advanced Container Escape Detector

Detection of advanced container escape techniques:
- eBPF-based escapes
- Filesystem escapes (overlay, bind mount)
- Cgroup escapes
- User namespace escapes
- Hardware-based escapes (GPU, TPM)
- Kernel module loading

MITRE ATT&CK:
- T1611: Escape to Host
- T1068: Exploitation for Privilege Escalation
"""

import os
import re
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
import shutil


# =============================================================================
# eBPF Escape Techniques
# =============================================================================

EBPF_ESCAPE_TECHNIQUES = {
    "bpf_write_user": {
        "name": "BPF Write User Memory",
        "description": "Use eBPF to write to host process memory",
        "severity": "critical",
        "mitre": "T1611",
        "requirements": ["CAP_BPF or CAP_SYS_ADMIN", "kernel 5.8+"],
        "detection": {
            "check_caps": ["CAP_BPF", "CAP_SYS_ADMIN"],
            "check_file": "/sys/kernel/btf/vmlinux",
        },
        "exploitation": {
            "method": "Load eBPF program that writes to host memory",
            "tools": ["libbpf", "BCC", "custom eBPF program"],
        },
    },
    "bpf_lsm_bypass": {
        "name": "eBPF LSM Bypass",
        "description": "Bypass Linux Security Modules via eBPF",
        "severity": "critical",
        "mitre": "T1611",
        "requirements": ["CAP_BPF", "kernel 5.7+"],
        "detection": {
            "check_file": "/sys/kernel/security/lsm",
        },
    },
    "tc_egress_escape": {
        "name": "TC Egress Manipulation",
        "description": "Use TC eBPF to escape network namespace",
        "severity": "high",
        "mitre": "T1611",
        "requirements": ["CAP_NET_ADMIN"],
        "detection": {
            "check_caps": ["CAP_NET_ADMIN"],
        },
    },
    "bpftrace_escape": {
        "name": "bpftrace Escape",
        "description": "Use bpftrace to read/write host memory",
        "severity": "critical",
        "mitre": "T1611",
        "requirements": ["CAP_SYS_ADMIN or CAP_BPF+CAP_PERFMON"],
        "detection": {
            "check_binary": "bpftrace",
        },
    },
    "bpf_verifier_bypass": {
        "name": "BPF Verifier Bypass",
        "description": "Exploit BPF verifier bugs for escape",
        "severity": "critical",
        "mitre": "T1068",
        "cves": [
            "CVE-2021-3490",
            "CVE-2021-31440",
            "CVE-2021-34866",
            "CVE-2022-0185",
            "CVE-2022-23222",
        ],
    },
}


# =============================================================================
# Filesystem Escape Techniques
# =============================================================================

FILESYSTEM_ESCAPE_TECHNIQUES = {
    "overlay_escape": {
        "name": "Overlay Filesystem Escape",
        "description": "Escape via overlay filesystem manipulation",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_mount": "overlay",
            "check_file": "/proc/mounts",
        },
        "exploitation": {
            "method": "Manipulate overlay lower/upper dirs if accessible",
        },
    },
    "bind_mount_escape": {
        "name": "Bind Mount Escape",
        "description": "Escape via misconfigured bind mounts",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "sensitive_mounts": [
                "/proc/sys",
                "/sys",
                "/etc",
                "/var/run",
                "/root",
            ],
        },
        "exploitation": {
            "methods": [
                "Write to /etc/crontab",
                "Modify /etc/passwd",
                "Write SSH keys",
            ],
        },
    },
    "procfs_escape": {
        "name": "Procfs Escape",
        "description": "Escape via /proc filesystem",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_files": [
                "/proc/sys/kernel/core_pattern",
                "/proc/sys/kernel/modprobe",
                "/proc/sysrq-trigger",
            ],
        },
        "exploitation": {
            "core_pattern": "echo '|/path/to/exploit' > /proc/sys/kernel/core_pattern",
            "modprobe": "echo '/path/to/exploit' > /proc/sys/kernel/modprobe",
            "sysrq": "echo c > /proc/sysrq-trigger # Crash host (DoS)",
        },
    },
    "sysfs_escape": {
        "name": "Sysfs Escape",
        "description": "Escape via /sys filesystem",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_files": [
                "/sys/kernel/uevent_helper",
                "/sys/class/mem/",
                "/sys/firmware/efi/",
            ],
        },
    },
    "debugfs_escape": {
        "name": "Debugfs Escape",
        "description": "Escape via debugfs access",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check_mount": "debugfs",
            "check_file": "/sys/kernel/debug",
        },
        "exploitation": {
            "method": "Direct memory access via debugfs",
        },
    },
    "tmpfs_symlink": {
        "name": "Tmpfs Symlink Attack",
        "description": "Symlink attack via shared tmpfs",
        "severity": "medium",
        "mitre": "T1611",
        "detection": {
            "check_mount": "tmpfs",
            "check_writeable": "/tmp",
        },
    },
}


# =============================================================================
# Cgroup Escape Techniques
# =============================================================================

CGROUP_ESCAPE_TECHNIQUES = {
    "release_agent": {
        "name": "Cgroup Release Agent Escape",
        "description": "Escape via cgroup release_agent",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check_file": "/sys/fs/cgroup/*/release_agent",
            "check_writeable": True,
        },
        "exploitation": {
            "steps": [
                "mkdir /tmp/cgrp && mount -t cgroup -o memory cgroup /tmp/cgrp",
                "mkdir /tmp/cgrp/x",
                "echo 1 > /tmp/cgrp/x/notify_on_release",
                "echo '/path/to/exploit' > /tmp/cgrp/release_agent",
                "sh -c 'echo $$ > /tmp/cgrp/x/cgroup.procs'",
            ],
        },
    },
    "cgroup_notify": {
        "name": "Cgroup Notify Escape",
        "description": "Escape via cgroup notify_on_release",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check_file": "/sys/fs/cgroup/*/notify_on_release",
        },
    },
    "devices_cgroup": {
        "name": "Devices Cgroup Escape",
        "description": "Escape via devices cgroup manipulation",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_file": "/sys/fs/cgroup/devices/devices.allow",
        },
        "exploitation": {
            "method": "Write 'a' to devices.allow to access all devices",
        },
    },
    "cgroup_v2_escape": {
        "name": "Cgroup v2 Escape",
        "description": "Escape techniques for cgroup v2",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_file": "/sys/fs/cgroup/cgroup.controllers",
        },
    },
}


# =============================================================================
# User Namespace Escape Techniques
# =============================================================================

USER_NAMESPACE_ESCAPES = {
    "userns_root_mapping": {
        "name": "User Namespace Root Mapping",
        "description": "Exploit user namespace with root mapping",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_file": "/proc/self/uid_map",
            "pattern": "0\\s+0",
        },
    },
    "userns_setgroups": {
        "name": "User Namespace Setgroups",
        "description": "Abuse setgroups in user namespace",
        "severity": "medium",
        "mitre": "T1611",
        "detection": {
            "check_file": "/proc/self/setgroups",
        },
    },
    "userns_nested": {
        "name": "Nested User Namespace",
        "description": "Create nested user namespace for escape",
        "severity": "medium",
        "mitre": "T1611",
        "detection": {
            "check_file": "/proc/sys/user/max_user_namespaces",
        },
    },
}


# =============================================================================
# Hardware-Based Escape Techniques
# =============================================================================

HARDWARE_ESCAPES = {
    "nvidia_gpu": {
        "name": "NVIDIA GPU Container Escape",
        "description": "Escape via NVIDIA GPU passthrough",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check_device": "/dev/nvidia*",
            "check_binary": "nvidia-smi",
        },
        "cves": [
            "CVE-2020-5963",
            "CVE-2021-1056",
        ],
    },
    "dri_escape": {
        "name": "DRI Device Escape",
        "description": "Escape via Direct Rendering Infrastructure",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_device": "/dev/dri/*",
        },
    },
    "usb_escape": {
        "name": "USB Device Escape",
        "description": "Escape via USB device passthrough",
        "severity": "high",
        "mitre": "T1611",
        "detection": {
            "check_device": "/dev/bus/usb/*",
        },
    },
    "fuse_escape": {
        "name": "FUSE Device Escape",
        "description": "Escape via FUSE device access",
        "severity": "medium",
        "mitre": "T1611",
        "detection": {
            "check_device": "/dev/fuse",
        },
    },
    "kvm_escape": {
        "name": "KVM Device Escape",
        "description": "Escape via KVM virtualization",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check_device": "/dev/kvm",
        },
    },
}


@dataclass
class AdvancedEscapeFinding:
    """Finding from advanced escape detection."""
    technique_type: str
    technique_name: str
    severity: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    exploitation: Dict[str, Any] = field(default_factory=dict)
    cves: List[str] = field(default_factory=list)
    recommendation: str = ""


@dataclass 
class AdvancedEscapeResult:
    """Result of advanced escape detection."""
    ebpf_findings: List[AdvancedEscapeFinding] = field(default_factory=list)
    filesystem_findings: List[AdvancedEscapeFinding] = field(default_factory=list)
    cgroup_findings: List[AdvancedEscapeFinding] = field(default_factory=list)
    userns_findings: List[AdvancedEscapeFinding] = field(default_factory=list)
    hardware_findings: List[AdvancedEscapeFinding] = field(default_factory=list)
    total_findings: int = 0
    critical_count: int = 0
    escape_possible: bool = False


class AdvancedEscapeDetector:
    """Detector for advanced container escape techniques."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.findings: List[AdvancedEscapeFinding] = []
    
    def detect_ebpf_escapes(self) -> List[AdvancedEscapeFinding]:
        """
        Detect eBPF-based escape possibilities.
        
        Returns:
            List of eBPF escape findings
        """
        findings = []
        
        # Check for CAP_BPF or CAP_SYS_ADMIN
        caps = self._get_capabilities()
        
        if "CAP_BPF" in caps or "CAP_SYS_ADMIN" in caps:
            # Check if BTF is available (modern eBPF)
            if os.path.exists("/sys/kernel/btf/vmlinux"):
                findings.append(AdvancedEscapeFinding(
                    technique_type="ebpf",
                    technique_name="bpf_write_user",
                    severity="critical",
                    description="eBPF capability with BTF available - host memory access possible",
                    evidence={
                        "capabilities": caps,
                        "btf_available": True,
                    },
                    mitre_technique="T1611",
                    exploitation=EBPF_ESCAPE_TECHNIQUES["bpf_write_user"]["exploitation"],
                    recommendation="Remove CAP_BPF/CAP_SYS_ADMIN capabilities",
                ))
        
        # Check for bpftrace
        if self._check_binary_exists("bpftrace"):
            findings.append(AdvancedEscapeFinding(
                technique_type="ebpf",
                technique_name="bpftrace_escape",
                severity="critical",
                description="bpftrace available in container",
                evidence={"binary": "bpftrace"},
                mitre_technique="T1611",
                exploitation={"command": "bpftrace -e 'kprobe:do_sys_open { printf(\"%s\\n\", str(arg1)); }'"},
                recommendation="Remove bpftrace from container image",
            ))
        
        # Check kernel version for BPF verifier bugs
        kernel_version = self._get_kernel_version()
        vulnerable_kernels = self._check_bpf_kernel_cves(kernel_version)
        
        if vulnerable_kernels:
            findings.append(AdvancedEscapeFinding(
                technique_type="ebpf",
                technique_name="bpf_verifier_bypass",
                severity="critical",
                description="Kernel version may be vulnerable to BPF verifier bypass",
                evidence={
                    "kernel_version": kernel_version,
                    "potential_cves": vulnerable_kernels,
                },
                mitre_technique="T1068",
                cves=vulnerable_kernels,
                recommendation="Update kernel to patched version",
            ))
        
        return findings
    
    def detect_filesystem_escapes(self) -> List[AdvancedEscapeFinding]:
        """
        Detect filesystem-based escape possibilities.
        
        Returns:
            List of filesystem escape findings
        """
        findings = []
        
        # Check for procfs dangerous files
        procfs_files = FILESYSTEM_ESCAPE_TECHNIQUES["procfs_escape"]["detection"]["check_files"]
        
        for filepath in procfs_files:
            if os.path.exists(filepath) and os.access(filepath, os.W_OK):
                findings.append(AdvancedEscapeFinding(
                    technique_type="filesystem",
                    technique_name="procfs_escape",
                    severity="critical",
                    description=f"Writable procfs file: {filepath}",
                    evidence={"path": filepath, "writeable": True},
                    mitre_technique="T1611",
                    exploitation=FILESYSTEM_ESCAPE_TECHNIQUES["procfs_escape"]["exploitation"],
                    recommendation=f"Mount /proc with hidepid=2 or restrict access to {filepath}",
                ))
        
        # Check for debugfs
        if os.path.exists("/sys/kernel/debug") and os.access("/sys/kernel/debug", os.R_OK):
            findings.append(AdvancedEscapeFinding(
                technique_type="filesystem",
                technique_name="debugfs_escape",
                severity="critical",
                description="Debugfs mounted and accessible",
                evidence={"path": "/sys/kernel/debug"},
                mitre_technique="T1611",
                recommendation="Remove debugfs mount from container",
            ))
        
        # Check for sensitive bind mounts
        sensitive_paths = FILESYSTEM_ESCAPE_TECHNIQUES["bind_mount_escape"]["detection"]["sensitive_mounts"]
        
        for path in sensitive_paths:
            if os.path.exists(path) and os.access(path, os.W_OK):
                # Check if it's a mount from host
                if self._is_host_mount(path):
                    findings.append(AdvancedEscapeFinding(
                        technique_type="filesystem",
                        technique_name="bind_mount_escape",
                        severity="critical",
                        description=f"Host path mounted and writeable: {path}",
                        evidence={"path": path, "writeable": True},
                        mitre_technique="T1611",
                        exploitation={"method": f"Arbitrary write to host path {path} (verify bind mount scope)"},
                        recommendation=f"Remove bind mount for {path} or mount read-only",
                    ))
        
        # Check for overlay filesystem access
        if self._check_overlay_access():
            findings.append(AdvancedEscapeFinding(
                technique_type="filesystem",
                technique_name="overlay_escape",
                severity="high",
                description="Overlay filesystem layers accessible",
                evidence={"overlay_accessible": True},
                mitre_technique="T1611",
                recommendation="Restrict access to overlay filesystem directories",
            ))
        
        return findings
    
    def detect_cgroup_escapes(self) -> List[AdvancedEscapeFinding]:
        """
        Detect cgroup-based escape possibilities.
        
        Returns:
            List of cgroup escape findings
        """
        findings = []
        
        # Check for release_agent
        release_agent_paths = [
            "/sys/fs/cgroup/memory/release_agent",
            "/sys/fs/cgroup/cpu/release_agent",
            "/sys/fs/cgroup/release_agent",
        ]
        
        for path in release_agent_paths:
            if os.path.exists(path) and os.access(path, os.W_OK):
                findings.append(AdvancedEscapeFinding(
                    technique_type="cgroup",
                    technique_name="release_agent",
                    severity="critical",
                    description=f"Cgroup release_agent writable: {path}",
                    evidence={"path": path, "writeable": True},
                    mitre_technique="T1611",
                    exploitation=CGROUP_ESCAPE_TECHNIQUES["release_agent"]["exploitation"],
                    recommendation="Mount cgroups read-only or use cgroup v2",
                ))
        
        # Check for notify_on_release
        notify_paths = [
            "/sys/fs/cgroup/*/notify_on_release",
        ]
        
        # Check cgroup v2
        if os.path.exists("/sys/fs/cgroup/cgroup.controllers"):
            # Cgroup v2 in use
            pass
        else:
            # Cgroup v1 - check for various subsystems
            cgroup_path = "/sys/fs/cgroup"
            if os.path.exists(cgroup_path):
                for subsystem in os.listdir(cgroup_path):
                    subsystem_path = os.path.join(cgroup_path, subsystem)
                    if os.path.isdir(subsystem_path):
                        release_agent = os.path.join(subsystem_path, "release_agent")
                        if os.path.exists(release_agent) and os.access(release_agent, os.W_OK):
                            findings.append(AdvancedEscapeFinding(
                                technique_type="cgroup",
                                technique_name="release_agent",
                                severity="critical",
                                description=f"Cgroup release_agent writable: {release_agent}",
                                evidence={"path": release_agent},
                                mitre_technique="T1611",
                                recommendation="Use cgroup v2 or mount read-only",
                            ))
        
        # Check devices cgroup
        devices_allow = "/sys/fs/cgroup/devices/devices.allow"
        if os.path.exists(devices_allow) and os.access(devices_allow, os.W_OK):
            findings.append(AdvancedEscapeFinding(
                technique_type="cgroup",
                technique_name="devices_cgroup",
                severity="high",
                description="Devices cgroup writable - can allow access to all devices",
                evidence={"path": devices_allow},
                mitre_technique="T1611",
                exploitation={"command": "echo 'a' > /sys/fs/cgroup/devices/devices.allow"},
                recommendation="Restrict device cgroup access",
            ))
        
        return findings
    
    def detect_userns_escapes(self) -> List[AdvancedEscapeFinding]:
        """
        Detect user namespace escape possibilities.
        
        Returns:
            List of user namespace escape findings
        """
        findings = []
        
        # Check uid_map
        try:
            with open("/proc/self/uid_map", "r") as f:
                uid_map = f.read()
                
            # Check if root in container maps to root on host
            if re.search(r"^\s*0\s+0", uid_map):
                findings.append(AdvancedEscapeFinding(
                    technique_type="userns",
                    technique_name="userns_root_mapping",
                    severity="high",
                    description="Container root maps to host root (no user namespace isolation)",
                    evidence={"uid_map": uid_map.strip()},
                    mitre_technique="T1611",
                    recommendation="Use user namespace remapping",
                ))
        except Exception:
            pass
        
        # Check if we can create nested namespaces
        try:
            with open("/proc/sys/user/max_user_namespaces", "r") as f:
                max_ns = int(f.read().strip())
                
            if max_ns > 0:
                findings.append(AdvancedEscapeFinding(
                    technique_type="userns",
                    technique_name="userns_nested",
                    severity="medium",
                    description=f"Can create up to {max_ns} nested user namespaces",
                    evidence={"max_user_namespaces": max_ns},
                    mitre_technique="T1611",
                    recommendation="Limit max_user_namespaces if not needed",
                ))
        except Exception:
            pass
        
        return findings
    
    def detect_hardware_escapes(self) -> List[AdvancedEscapeFinding]:
        """
        Detect hardware-based escape possibilities.
        
        Returns:
            List of hardware escape findings
        """
        findings = []
        
        # Check for NVIDIA GPU
        if os.path.exists("/dev/nvidia0") or os.path.exists("/dev/nvidiactl"):
            findings.append(AdvancedEscapeFinding(
                technique_type="hardware",
                technique_name="nvidia_gpu",
                severity="critical",
                description="NVIDIA GPU device accessible in container",
                evidence={
                    "devices": [d for d in os.listdir("/dev") if d.startswith("nvidia")],
                },
                mitre_technique="T1611",
                cves=HARDWARE_ESCAPES["nvidia_gpu"]["cves"],
                recommendation="Use nvidia-container-runtime with proper isolation",
            ))
        
        # Check for DRI devices
        if os.path.exists("/dev/dri"):
            dri_devices = os.listdir("/dev/dri")
            if dri_devices:
                findings.append(AdvancedEscapeFinding(
                    technique_type="hardware",
                    technique_name="dri_escape",
                    severity="high",
                    description="DRI devices accessible in container",
                    evidence={"devices": dri_devices},
                    mitre_technique="T1611",
                    recommendation="Remove DRI device access if not needed",
                ))
        
        # Check for KVM
        if os.path.exists("/dev/kvm") and os.access("/dev/kvm", os.R_OK | os.W_OK):
            findings.append(AdvancedEscapeFinding(
                technique_type="hardware",
                technique_name="kvm_escape",
                severity="critical",
                description="KVM device accessible - nested virtualization possible",
                evidence={"device": "/dev/kvm"},
                mitre_technique="T1611",
                recommendation="Remove /dev/kvm access",
            ))
        
        # Check for USB devices
        if os.path.exists("/dev/bus/usb"):
            findings.append(AdvancedEscapeFinding(
                technique_type="hardware",
                technique_name="usb_escape",
                severity="high",
                description="USB devices accessible in container",
                evidence={"path": "/dev/bus/usb"},
                mitre_technique="T1611",
                recommendation="Remove USB device passthrough",
            ))
        
        # Check for FUSE
        if os.path.exists("/dev/fuse") and os.access("/dev/fuse", os.R_OK | os.W_OK):
            findings.append(AdvancedEscapeFinding(
                technique_type="hardware",
                technique_name="fuse_escape",
                severity="medium",
                description="FUSE device accessible in container",
                evidence={"device": "/dev/fuse"},
                mitre_technique="T1611",
                recommendation="Remove /dev/fuse access if not needed",
            ))
        
        return findings
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _get_capabilities(self) -> List[str]:
        """Get effective capabilities of current process."""
        caps = []
        
        try:
            # Avoid subprocess in async plugin path: parse /proc/self/status CapEff.
            with open("/proc/self/status", "r") as f:
                for line in f:
                    if line.startswith("CapEff:"):
                        cap_hex = int(line.split(":")[1].strip(), 16)
                        # Decode only what we need in this detector
                        if cap_hex & (1 << 21):  # CAP_SYS_ADMIN
                            caps.append("CAP_SYS_ADMIN")
                        if cap_hex & (1 << 39):  # CAP_BPF (kernel 5.8+)
                            caps.append("CAP_BPF")
                        break
        except Exception:
            pass
        
        return caps
    
    def _get_kernel_version(self) -> str:
        """Get kernel version."""
        try:
            with open("/proc/version", "r") as f:
                version_line = f.read()
            
            match = re.search(r"Linux version (\d+\.\d+\.\d+)", version_line)
            if match:
                return match.group(1)
        except Exception:
            pass
        
        return ""
    
    def _check_bpf_kernel_cves(self, kernel_version: str) -> List[str]:
        """Check if kernel version is vulnerable to BPF CVEs."""
        vulnerable = []
        
        if not kernel_version:
            return vulnerable
        
        try:
            parts = kernel_version.split(".")
            major = int(parts[0])
            minor = int(parts[1])
            patch = int(parts[2]) if len(parts) > 2 else 0
            
            # CVE-2021-3490: < 5.11.12
            if (major, minor, patch) < (5, 11, 12):
                vulnerable.append("CVE-2021-3490")
            
            # CVE-2022-0185: < 5.16.2
            if (major, minor, patch) < (5, 16, 2):
                vulnerable.append("CVE-2022-0185")
            
            # CVE-2022-23222: < 5.16.5
            if (major, minor, patch) < (5, 16, 5):
                vulnerable.append("CVE-2022-23222")
                
        except Exception:
            pass
        
        return vulnerable
    
    def _check_binary_exists(self, binary: str) -> bool:
        """Check if binary exists in PATH."""
        return shutil.which(binary) is not None
    
    def _is_host_mount(self, path: str) -> bool:
        """Check if path is a mount from host."""
        try:
            with open("/proc/mounts", "r") as f:
                mounts = f.read()
            
            # Check if path appears in mounts
            return path in mounts
        except Exception:
            return False
    
    def _check_overlay_access(self) -> bool:
        """Check if overlay filesystem layers are accessible."""
        try:
            with open("/proc/mounts", "r") as f:
                for line in f:
                    if "overlay" in line:
                        # Parse overlay mount options
                        parts = line.split()
                        if len(parts) >= 4:
                            options = parts[3]
                            # Check if lowerdir/upperdir are accessible
                            for opt in options.split(","):
                                if opt.startswith("upperdir="):
                                    upperdir = opt.split("=")[1]
                                    if os.path.exists(upperdir) and os.access(upperdir, os.W_OK):
                                        return True
        except Exception:
            pass
        
        return False
    
    async def detect_all(self) -> AdvancedEscapeResult:
        """
        Perform comprehensive advanced escape detection.
        
        Returns:
            AdvancedEscapeResult with all findings
        """
        result = AdvancedEscapeResult()
        
        # Detect all escape types
        result.ebpf_findings = self.detect_ebpf_escapes()
        result.filesystem_findings = self.detect_filesystem_escapes()
        result.cgroup_findings = self.detect_cgroup_escapes()
        result.userns_findings = self.detect_userns_escapes()
        result.hardware_findings = self.detect_hardware_escapes()
        
        # Collect all findings
        all_findings = (
            result.ebpf_findings +
            result.filesystem_findings +
            result.cgroup_findings +
            result.userns_findings +
            result.hardware_findings
        )
        
        result.total_findings = len(all_findings)
        result.critical_count = sum(1 for f in all_findings if f.severity == "critical")
        result.escape_possible = result.critical_count > 0
        
        self.findings = all_findings
        
        return result
    
    def get_findings(self) -> List[AdvancedEscapeFinding]:
        """Get all findings."""
        return self.findings

