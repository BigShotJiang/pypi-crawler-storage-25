"""
Container Orchestration Escape Detector

Detects advanced container escape techniques:
- Container-to-container escape
- Sidecar container escape
- Pod-to-pod lateral movement
- Shared namespace abuse
- Volume mount escape
- Network namespace escape

MITRE ATT&CK:
- T1611: Escape to Host
- T1610: Deploy Container
- T1613: Container and Resource Discovery
"""

import os
import re
import asyncio
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from utils.async_subprocess import run_exec


# =============================================================================
# Container-to-Container Escape Techniques
# =============================================================================

C2C_ESCAPE_TECHNIQUES = {
    "shared_pid_namespace": {
        "description": "Shared PID namespace allows process injection",
        "severity": "critical",
        "mitre": "T1611",
        "detection": {
            "check": "shareProcessNamespace",
            "file": "/proc/1/root",
        },
        "exploitation": {
            "inject": "nsenter -t ${TARGET_PID} -p -r /bin/sh",
            "ptrace": "Use ptrace to inject into other container processes",
        },
    },
    "shared_network_namespace": {
        "description": "Shared network namespace allows traffic interception",
        "severity": "high",
        "mitre": "T1040",
        "detection": {
            "check": "hostNetwork",
            "file": "/proc/net/tcp",
        },
        "exploitation": {
            "tcpdump": "tcpdump -i any -w capture.pcap",
            "arp_spoof": "arpspoof -i eth0 -t ${TARGET_IP} ${GATEWAY_IP}",
        },
    },
    "shared_ipc_namespace": {
        "description": "Shared IPC namespace allows shared memory access",
        "severity": "medium",
        "mitre": "T1055",
        "detection": {
            "check": "hostIPC",
            "file": "/dev/shm",
        },
        "exploitation": {
            "shm_inject": "Access shared memory segments from /dev/shm",
        },
    },
    "shared_uts_namespace": {
        "description": "Shared UTS namespace may indicate host access",
        "severity": "low",
        "mitre": "T1611",
        "detection": {
            "check": "hostUTS",
        },
    },
}


# =============================================================================
# Sidecar Escape Techniques
# =============================================================================

SIDECAR_ESCAPE_TECHNIQUES = {
    "envoy_admin_api": {
        "description": "Envoy admin API exposed allows configuration tampering",
        "severity": "critical",
        "mitre": "T1190",
        "ports": [15000, 15001, 15004, 15006, 15020, 15021, 15090],
        "detection": {
            "url": "http://localhost:15000/config_dump",
            "check_file": "/etc/envoy/envoy.yaml",
        },
        "exploitation": {
            "config_dump": "curl localhost:15000/config_dump",
            "clusters": "curl localhost:15000/clusters",
            "stats": "curl localhost:15000/stats",
            "modify_routes": "curl -X POST localhost:15000/runtime_modify?key=value",
        },
    },
    "istio_debug_api": {
        "description": "Istio debug API allows credential theft",
        "severity": "critical",
        "mitre": "T1552",
        "ports": [15014, 15020],
        "detection": {
            "url": "http://localhost:15014/debug/",
            "secret_path": "/etc/certs/",
        },
        "exploitation": {
            "certs": "cat /etc/certs/cert-chain.pem",
            "key": "cat /etc/certs/key.pem",
            "debug": "curl localhost:15014/debug/syncz",
        },
    },
    "linkerd_identity": {
        "description": "Linkerd identity sidecar credential access",
        "severity": "high",
        "mitre": "T1552",
        "ports": [4191, 4143],
        "detection": {
            "check_process": "linkerd-proxy",
        },
        "exploitation": {
            "identity": "cat /var/run/linkerd/identity/certificate.crt",
        },
    },
    "dapr_sidecar": {
        "description": "Dapr sidecar API allows service invocation",
        "severity": "high",
        "mitre": "T1190",
        "ports": [3500, 50001],
        "detection": {
            "url": "http://localhost:3500/v1.0/metadata",
        },
        "exploitation": {
            "invoke": "curl http://localhost:3500/v1.0/invoke/${DAPR_APP_ID}/method/${DAPR_METHOD_NAME}",
            "secrets": "curl http://localhost:3500/v1.0/secrets/${DAPR_SECRET_STORE}/${DAPR_SECRET_KEY}",
            "state": "curl http://localhost:3500/v1.0/state/${DAPR_STATE_STORE}/${DAPR_STATE_KEY}",
        },
    },
    "aws_xray_daemon": {
        "description": "AWS X-Ray daemon may expose trace data",
        "severity": "medium",
        "mitre": "T1530",
        "ports": [2000],
        "detection": {
            "check_process": "xray",
        },
    },
}


# =============================================================================
# Volume Mount Escape Techniques
# =============================================================================

VOLUME_ESCAPE_TECHNIQUES = {
    "docker_socket": {
        "description": "Docker socket mounted allows container escape",
        "severity": "critical",
        "mitre": "T1611",
        "paths": ["/var/run/docker.sock", "/run/docker.sock"],
        "exploitation": {
            "escape": "docker run -v /:/host --privileged -it alpine chroot /host",
            "list": "curl --unix-socket /var/run/docker.sock http://localhost/containers/json",
        },
    },
    "containerd_socket": {
        "description": "Containerd socket mounted allows container escape",
        "severity": "critical",
        "mitre": "T1611",
        "paths": ["/run/containerd/containerd.sock"],
        "exploitation": {
            "escape": "ctr -a /run/containerd/containerd.sock run --privileged ...",
        },
    },
    "cri_socket": {
        "description": "CRI socket allows pod manipulation",
        "severity": "critical",
        "mitre": "T1611",
        "paths": ["/var/run/crio/crio.sock", "/run/cri-dockerd.sock"],
        "exploitation": {
            "crictl": "crictl --runtime-endpoint ${CRI_SOCKET} pods",
        },
    },
    "host_root": {
        "description": "Host root filesystem mounted",
        "severity": "critical",
        "mitre": "T1611",
        "paths": ["/host", "/hostfs", "/rootfs"],
        "exploitation": {
            "chroot": "chroot /host /bin/bash",
            "cron": "echo '* * * * * root /bin/bash -c \"...\"' >> /host/etc/crontab",
        },
    },
    "kubernetes_secrets": {
        "description": "Kubernetes secrets directory accessible",
        "severity": "high",
        "mitre": "T1552",
        "paths": ["/var/run/secrets/kubernetes.io/serviceaccount/"],
        "exploitation": {
            "token": "cat /var/run/secrets/kubernetes.io/serviceaccount/token",
            "ca": "cat /var/run/secrets/kubernetes.io/serviceaccount/ca.crt",
        },
    },
    "cloud_credentials": {
        "description": "Cloud provider credentials accessible",
        "severity": "critical",
        "mitre": "T1552",
        "paths": [
            "~/.aws/credentials",
            "~/.azure/credentials",
            "~/.config/gcloud/",
        ],
        "exploitation": {
            "aws": "cat ~/.aws/credentials",
        },
    },
}


# =============================================================================
# Network Namespace Escape
# =============================================================================

NETWORK_ESCAPE_TECHNIQUES = {
    "host_network": {
        "description": "Host network namespace allows full network access",
        "severity": "critical",
        "mitre": "T1040",
        "detection": {
            "check": "cat /proc/1/ns/net",
        },
        "exploitation": {
            "scan": "nmap -sn 10.0.0.0/24",
            "capture": "tcpdump -i any",
            "bind": "Bind to any host port",
        },
    },
    "pod_network_access": {
        "description": "Access to pod network CIDR",
        "severity": "medium",
        "mitre": "T1046",
        "exploitation": {
            "discovery": "nmap -sn ${POD_CIDR}",
            "service_discovery": "curl kubernetes.default.svc",
        },
    },
    "service_mesh_bypass": {
        "description": "Service mesh can be bypassed",
        "severity": "high",
        "mitre": "T1090",
        "detection": {
            "check_iptables": "iptables -t nat -L",
        },
        "exploitation": {
            "direct_connect": "Connect directly to pod IP bypassing mesh",
        },
    },
}


@dataclass
class OrchestrationEscapeFinding:
    """Finding from orchestration escape detection."""
    technique_type: str
    technique_name: str
    severity: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    mitre_technique: str = ""
    exploitation_commands: Dict[str, str] = field(default_factory=dict)
    recommendation: str = ""


@dataclass
class OrchestrationEscapeResult:
    """Result of orchestration escape detection."""
    c2c_findings: List[OrchestrationEscapeFinding] = field(default_factory=list)
    sidecar_findings: List[OrchestrationEscapeFinding] = field(default_factory=list)
    volume_findings: List[OrchestrationEscapeFinding] = field(default_factory=list)
    network_findings: List[OrchestrationEscapeFinding] = field(default_factory=list)
    total_findings: int = 0
    critical_count: int = 0
    escape_possible: bool = False


class OrchestrationEscapeDetector:
    """Detector for container orchestration escape techniques."""
    
    def __init__(self, plugin_instance: Any = None):
        self.plugin = plugin_instance
        self.findings: List[OrchestrationEscapeFinding] = []
    
    def detect_c2c_escape(self) -> List[OrchestrationEscapeFinding]:
        """
        Detect container-to-container escape possibilities.
        
        Returns:
            List of C2C escape findings
        """
        findings = []
        
        for technique_name, technique in C2C_ESCAPE_TECHNIQUES.items():
            detection = technique.get("detection", {})
            
            # Check namespace sharing
            if technique_name == "shared_pid_namespace":
                if self._check_shared_pid_namespace():
                    findings.append(OrchestrationEscapeFinding(
                        technique_type="c2c_escape",
                        technique_name=technique_name,
                        severity=technique["severity"],
                        description=technique["description"],
                        evidence={"shared_pid": True},
                        mitre_technique=technique["mitre"],
                        exploitation_commands=technique.get("exploitation", {}),
                        recommendation="Disable shareProcessNamespace in pod spec",
                    ))
            
            elif technique_name == "shared_network_namespace":
                if self._check_host_network():
                    findings.append(OrchestrationEscapeFinding(
                        technique_type="c2c_escape",
                        technique_name=technique_name,
                        severity=technique["severity"],
                        description=technique["description"],
                        evidence={"host_network": True},
                        mitre_technique=technique["mitre"],
                        exploitation_commands=technique.get("exploitation", {}),
                        recommendation="Disable hostNetwork in pod spec",
                    ))
            
            elif technique_name == "shared_ipc_namespace":
                if self._check_host_ipc():
                    findings.append(OrchestrationEscapeFinding(
                        technique_type="c2c_escape",
                        technique_name=technique_name,
                        severity=technique["severity"],
                        description=technique["description"],
                        evidence={"host_ipc": True},
                        mitre_technique=technique["mitre"],
                        exploitation_commands=technique.get("exploitation", {}),
                        recommendation="Disable hostIPC in pod spec",
                    ))
        
        return findings
    
    async def detect_sidecar_escape(self) -> List[OrchestrationEscapeFinding]:
        """
        Detect sidecar container escape possibilities.
        
        Returns:
            List of sidecar escape findings
        """
        findings = []
        
        for technique_name, technique in SIDECAR_ESCAPE_TECHNIQUES.items():
            # Check if sidecar ports are accessible
            ports = technique.get("ports", [])
            
            for port in ports:
                if self._is_port_open("localhost", port):
                    detection = technique.get("detection", {})
                    url = detection.get("url")
                    
                    evidence = {"port": port, "accessible": True}
                    
                    # Try to access API if URL provided
                    if url:
                        response = await self._try_http_request(url)
                        if response:
                            evidence["api_response"] = response[:500]
                    
                    findings.append(OrchestrationEscapeFinding(
                        technique_type="sidecar_escape",
                        technique_name=technique_name,
                        severity=technique["severity"],
                        description=technique["description"],
                        evidence=evidence,
                        mitre_technique=technique["mitre"],
                        exploitation_commands=technique.get("exploitation", {}),
                        recommendation="Restrict sidecar admin API access",
                    ))
                    break
            
            # Check for sidecar files/processes
            detection = technique.get("detection", {})
            check_file = detection.get("check_file")
            check_process = detection.get("check_process")
            secret_path = detection.get("secret_path")
            
            if check_file and os.path.exists(check_file):
                findings.append(OrchestrationEscapeFinding(
                    technique_type="sidecar_escape",
                    technique_name=technique_name,
                    severity=technique["severity"],
                    description=f"Sidecar config file found: {check_file}",
                    evidence={"file": check_file},
                    mitre_technique=technique["mitre"],
                    exploitation_commands=technique.get("exploitation", {}),
                    recommendation="Review sidecar configuration security",
                ))
            
            if secret_path and os.path.exists(secret_path):
                findings.append(OrchestrationEscapeFinding(
                    technique_type="sidecar_escape",
                    technique_name=technique_name,
                    severity="critical",
                    description=f"Sidecar secrets accessible: {secret_path}",
                    evidence={"secret_path": secret_path},
                    mitre_technique="T1552",
                    exploitation_commands=technique.get("exploitation", {}),
                    recommendation="Secure sidecar certificate storage",
                ))
        
        return findings
    
    def detect_volume_escape(self) -> List[OrchestrationEscapeFinding]:
        """
        Detect volume mount escape possibilities.
        
        Returns:
            List of volume escape findings
        """
        findings = []
        
        for technique_name, technique in VOLUME_ESCAPE_TECHNIQUES.items():
            paths = technique.get("paths", [])
            
            for path in paths:
                expanded_path = os.path.expanduser(path)
                
                if os.path.exists(expanded_path):
                    # Check if it's accessible
                    is_socket = os.path.exists(expanded_path) and not os.path.isfile(expanded_path) and not os.path.isdir(expanded_path)
                    is_accessible = os.access(expanded_path, os.R_OK)
                    
                    evidence = {
                        "path": expanded_path,
                        "exists": True,
                        "is_socket": is_socket,
                        "readable": is_accessible,
                    }
                    
                    # Special handling for sockets
                    if technique_name in ["docker_socket", "containerd_socket", "cri_socket"]:
                        if is_socket or os.path.exists(expanded_path):
                            findings.append(OrchestrationEscapeFinding(
                                technique_type="volume_escape",
                                technique_name=technique_name,
                                severity=technique["severity"],
                                description=f"{technique['description']}: {expanded_path}",
                                evidence=evidence,
                                mitre_technique=technique["mitre"],
                                exploitation_commands=technique.get("exploitation", {}),
                                recommendation="Remove container runtime socket mounts",
                            ))
                    else:
                        findings.append(OrchestrationEscapeFinding(
                            technique_type="volume_escape",
                            technique_name=technique_name,
                            severity=technique["severity"],
                            description=f"{technique['description']}: {expanded_path}",
                            evidence=evidence,
                            mitre_technique=technique["mitre"],
                            exploitation_commands=technique.get("exploitation", {}),
                            recommendation=f"Review necessity of mounting {path}",
                        ))
        
        return findings
    
    async def detect_network_escape(self) -> List[OrchestrationEscapeFinding]:
        """
        Detect network namespace escape possibilities.
        
        Returns:
            List of network escape findings
        """
        findings = []
        
        # Check host network
        if self._check_host_network():
            technique = NETWORK_ESCAPE_TECHNIQUES["host_network"]
            findings.append(OrchestrationEscapeFinding(
                technique_type="network_escape",
                technique_name="host_network",
                severity=technique["severity"],
                description=technique["description"],
                evidence={"host_network": True},
                mitre_technique=technique["mitre"],
                exploitation_commands=technique.get("exploitation", {}),
                recommendation="Use pod network instead of host network",
            ))
        
        # Check if we can access other pods
        if await self._can_access_pod_network():
            technique = NETWORK_ESCAPE_TECHNIQUES["pod_network_access"]
            findings.append(OrchestrationEscapeFinding(
                technique_type="network_escape",
                technique_name="pod_network_access",
                severity=technique["severity"],
                description=technique["description"],
                evidence={"pod_network_accessible": True},
                mitre_technique=technique["mitre"],
                exploitation_commands=technique.get("exploitation", {}),
                recommendation="Implement network policies",
            ))
        
        # Check for service mesh bypass
        if await self._check_service_mesh_bypass():
            technique = NETWORK_ESCAPE_TECHNIQUES["service_mesh_bypass"]
            findings.append(OrchestrationEscapeFinding(
                technique_type="network_escape",
                technique_name="service_mesh_bypass",
                severity=technique["severity"],
                description=technique["description"],
                evidence={"mesh_bypass_possible": True},
                mitre_technique=technique["mitre"],
                exploitation_commands=technique.get("exploitation", {}),
                recommendation="Enable strict mTLS enforcement",
            ))
        
        return findings
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _check_shared_pid_namespace(self) -> bool:
        """Check if PID namespace is shared."""
        try:
            # Check if we can see host processes
            with open("/proc/1/cmdline", "r") as f:
                cmdline = f.read()
                # If PID 1 is not the container's init, namespace is shared
                return "init" in cmdline or "systemd" in cmdline
        except (IOError, PermissionError):
            return False
    
    def _check_host_network(self) -> bool:
        """Check if using host network namespace."""
        try:
            # Compare network namespace with host
            container_ns = os.readlink("/proc/self/ns/net")
            
            # Try to read host namespace via /proc/1
            try:
                host_ns = os.readlink("/proc/1/ns/net")
                return container_ns == host_ns
            except (IOError, PermissionError):
                pass
            
            # Alternative: check for host interfaces
            with open("/proc/net/route", "r") as f:
                routes = f.read()
                # If we see multiple non-container interfaces, likely host network
                return routes.count("eth") > 1 or "ens" in routes or "enp" in routes
                
        except (IOError, PermissionError):
            return False
    
    def _check_host_ipc(self) -> bool:
        """Check if using host IPC namespace."""
        try:
            # Check for host shared memory
            shm_files = os.listdir("/dev/shm")
            # Host typically has more shm files
            return len(shm_files) > 5
        except (IOError, PermissionError):
            return False
    
    def _is_port_open(self, host: str, port: int) -> bool:
        """Check if a port is open."""
        import socket
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((host, port))
            sock.close()
            return result == 0
        except Exception:
            return False
    
    async def _try_http_request(self, url: str) -> Optional[str]:
        """Try to make HTTP request."""
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0, verify=False) as client:
                resp = await client.get(url, headers={"User-Agent": "security-scanner"})
                if resp.status_code < 400:
                    return resp.text
        except Exception:
            return None
    
    async def _can_access_pod_network(self) -> bool:
        """Check if we can access other pods."""
        try:
            # Try to resolve kubernetes service
            import socket
            await asyncio.get_running_loop().getaddrinfo(
                "kubernetes.default.svc",
                None,
                family=socket.AF_INET,
                type=socket.SOCK_STREAM,
            )
            return True
        except Exception:
            return False
    
    async def _check_service_mesh_bypass(self) -> bool:
        """Check if service mesh can be bypassed."""
        try:
            # Check if iptables rules exist for mesh
            rc, out, _ = await run_exec(["iptables", "-t", "nat", "-L", "ISTIO_OUTPUT"], timeout=5)
            if rc == 0:
                # Mesh is present, check for bypass
                output = out or ""
                # If RETURN rules exist, bypass may be possible
                return "RETURN" in output
            
            return False
        except Exception:
            return False
    
    async def detect_all(self) -> OrchestrationEscapeResult:
        """
        Perform comprehensive orchestration escape detection.
        
        Returns:
            OrchestrationEscapeResult with all findings
        """
        result = OrchestrationEscapeResult()
        
        # Detect all escape types
        result.c2c_findings = self.detect_c2c_escape()
        result.sidecar_findings = await self.detect_sidecar_escape()
        result.volume_findings = self.detect_volume_escape()
        result.network_findings = await self.detect_network_escape()
        
        # Collect all findings
        all_findings = (
            result.c2c_findings +
            result.sidecar_findings +
            result.volume_findings +
            result.network_findings
        )
        
        result.total_findings = len(all_findings)
        result.critical_count = sum(1 for f in all_findings if f.severity == "critical")
        result.escape_possible = result.critical_count > 0
        
        self.findings = all_findings
        
        return result

    def get_findings(self) -> List[OrchestrationEscapeFinding]:
        """Get all findings."""
        return self.findings

