"""
Runtime Security Detector

Detects container runtime security configuration and bypass opportunities:
- Seccomp profile status and bypass techniques
- AppArmor profile status and bypass techniques
- SELinux status and bypass techniques
- Combined security posture assessment

MITRE ATT&CK: T1562.001 (Impair Defenses: Disable or Modify Tools)
"""

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from ..databases.escape_databases import (
    SECCOMP_BYPASS_TECHNIQUES,
    APPARMOR_CONTAINER_BYPASS,
    SELINUX_CONTAINER_BYPASS,
    RUNTIME_SECURITY_BYPASS,
)


class SecurityModule(str, Enum):
    """Security module types."""
    SECCOMP = "seccomp"
    APPARMOR = "apparmor"
    SELINUX = "selinux"
    NONE = "none"


class SecurityStatus(str, Enum):
    """Security module status."""
    DISABLED = "disabled"
    PERMISSIVE = "permissive"
    ENFORCING = "enforcing"
    UNCONFINED = "unconfined"
    RESTRICTED = "restricted"
    UNKNOWN = "unknown"


class RiskLevel(str, Enum):
    """Risk levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class SecurityFinding:
    """A runtime security finding."""
    module: SecurityModule
    status: SecurityStatus
    risk: RiskLevel
    title: str
    description: str
    bypass_techniques: List[str] = field(default_factory=list)
    evidence: str = ""
    remediation: str = ""
    mitre_technique: str = ""


@dataclass
class RuntimeSecurityStatus:
    """Overall runtime security status."""
    seccomp: SecurityStatus = SecurityStatus.UNKNOWN
    seccomp_profile: str = ""
    apparmor: SecurityStatus = SecurityStatus.UNKNOWN
    apparmor_profile: str = ""
    selinux: SecurityStatus = SecurityStatus.UNKNOWN
    selinux_context: str = ""
    is_privileged: bool = False
    escape_risk: RiskLevel = RiskLevel.INFO


class RuntimeSecurityDetector:
    """Detects runtime security configuration and bypass opportunities."""
    
    def __init__(self, plugin_instance):
        self.plugin = plugin_instance
        self.findings: List[SecurityFinding] = []
    
    def detect_all(self) -> Tuple[RuntimeSecurityStatus, List[SecurityFinding]]:
        """
        Detect all runtime security configurations and potential bypasses.
        
        Returns:
            Tuple of (RuntimeSecurityStatus, List[SecurityFinding])
        """
        self.findings = []
        status = RuntimeSecurityStatus()
        
        # Detect Seccomp
        seccomp_status, seccomp_profile = self._detect_seccomp()
        status.seccomp = seccomp_status
        status.seccomp_profile = seccomp_profile
        self._check_seccomp_bypass(seccomp_status, seccomp_profile)
        
        # Detect AppArmor
        apparmor_status, apparmor_profile = self._detect_apparmor()
        status.apparmor = apparmor_status
        status.apparmor_profile = apparmor_profile
        self._check_apparmor_bypass(apparmor_status, apparmor_profile)
        
        # Detect SELinux
        selinux_status, selinux_context = self._detect_selinux()
        status.selinux = selinux_status
        status.selinux_context = selinux_context
        self._check_selinux_bypass(selinux_status, selinux_context)
        
        # Check for privileged container
        status.is_privileged = self._is_privileged_container()
        
        # Calculate overall escape risk
        status.escape_risk = self._calculate_escape_risk(status)
        
        # Check combined security posture
        self._check_combined_security(status)
        
        return status, self.findings
    
    def _detect_seccomp(self) -> Tuple[SecurityStatus, str]:
        """Detect seccomp status and profile."""
        status = SecurityStatus.UNKNOWN
        profile = ""
        
        try:
            # Read seccomp status from /proc/self/status
            with open("/proc/self/status", "r") as f:
                content = f.read()
            
            seccomp_match = re.search(r"Seccomp:\s*(\d+)", content)
            if seccomp_match:
                seccomp_value = int(seccomp_match.group(1))
                if seccomp_value == 0:
                    status = SecurityStatus.DISABLED
                    profile = "unconfined"
                elif seccomp_value == 1:
                    status = SecurityStatus.ENFORCING
                    profile = "strict"
                elif seccomp_value == 2:
                    status = SecurityStatus.ENFORCING
                    profile = "filter"
        except Exception:
            pass
        
        # Try to get more info from seccomp_filter count
        try:
            seccomp_filters = "/proc/self/attr/seccomp"
            if os.path.exists(seccomp_filters):
                with open(seccomp_filters, "r") as f:
                    profile = f.read().strip() or profile
        except Exception:
            pass
        
        return status, profile
    
    def _detect_apparmor(self) -> Tuple[SecurityStatus, str]:
        """Detect AppArmor status and profile."""
        status = SecurityStatus.UNKNOWN
        profile = ""
        
        try:
            # Read AppArmor profile from /proc/self/attr/current
            attr_path = "/proc/self/attr/current"
            if os.path.exists(attr_path):
                with open(attr_path, "r") as f:
                    profile = f.read().strip()
                
                if profile == "unconfined" or not profile:
                    status = SecurityStatus.UNCONFINED
                elif "(complain)" in profile:
                    status = SecurityStatus.PERMISSIVE
                elif "(enforce)" in profile or profile.startswith("docker-default"):
                    status = SecurityStatus.ENFORCING
                else:
                    status = SecurityStatus.ENFORCING
        except Exception:
            pass
        
        # Check if AppArmor is available
        if not os.path.exists("/sys/module/apparmor"):
            status = SecurityStatus.DISABLED
            profile = "not_available"
        
        return status, profile
    
    def _detect_selinux(self) -> Tuple[SecurityStatus, str]:
        """Detect SELinux status and context."""
        status = SecurityStatus.UNKNOWN
        context = ""
        
        try:
            # Read SELinux context from /proc/self/attr/current
            attr_path = "/proc/self/attr/current"
            if os.path.exists(attr_path):
                with open(attr_path, "r") as f:
                    context = f.read().strip()
                
                if context and ":" in context:  # SELinux context format
                    if "unconfined_t" in context:
                        status = SecurityStatus.UNCONFINED
                    elif "spc_t" in context:
                        status = SecurityStatus.UNCONFINED  # Super privileged container
                    elif "container_t" in context or "svirt_lxc_net_t" in context:
                        status = SecurityStatus.ENFORCING
        except Exception:
            pass
        
        # Prefer reading SELinux kernel state directly (avoids subprocess in async plugin)
        try:
            enforce_path = "/sys/fs/selinux/enforce"
            if os.path.exists(enforce_path):
                with open(enforce_path, "r") as f:
                    mode = f.read().strip()
                if mode == "1":
                    # If context didn't already indicate unconfined/special types, mark enforcing
                    if status == SecurityStatus.UNKNOWN:
                        status = SecurityStatus.ENFORCING
                elif mode == "0":
                    status = SecurityStatus.PERMISSIVE
            else:
                # If SELinux fs isn't mounted, it's typically disabled
                if os.path.exists("/sys/fs/selinux"):
                    status = status if status != SecurityStatus.UNKNOWN else SecurityStatus.UNKNOWN
                else:
                    status = SecurityStatus.DISABLED
        except Exception:
            pass
        
        return status, context
    
    def _is_privileged_container(self) -> bool:
        """Check if container is running in privileged mode."""
        # Check for full capabilities
        try:
            with open("/proc/self/status", "r") as f:
                content = f.read()
            cap_match = re.search(r"CapEff:\s*([0-9a-fA-F]+)", content)
            if cap_match:
                cap_value = int(cap_match.group(1), 16)
                # Full capabilities would be all bits set (41 bits in typical kernels)
                if cap_value == 0x1FFFF_FFFFFF or cap_value >= 0x1FFFF_FFFFFF:
                    return True
        except Exception:
            pass
        
        # Check for device access
        if os.path.exists("/dev/sda") or os.path.exists("/dev/nvme0n1"):
            return True
        
        return False
    
    def _calculate_escape_risk(self, status: RuntimeSecurityStatus) -> RiskLevel:
        """Calculate overall escape risk based on security posture."""
        if status.is_privileged:
            return RiskLevel.CRITICAL
        
        disabled_count = 0
        if status.seccomp == SecurityStatus.DISABLED:
            disabled_count += 1
        if status.apparmor in [SecurityStatus.DISABLED, SecurityStatus.UNCONFINED]:
            disabled_count += 1
        if status.selinux in [SecurityStatus.DISABLED, SecurityStatus.UNCONFINED]:
            disabled_count += 1
        
        if disabled_count >= 2:
            return RiskLevel.CRITICAL
        elif disabled_count == 1:
            return RiskLevel.HIGH
        elif status.apparmor == SecurityStatus.PERMISSIVE or status.selinux == SecurityStatus.PERMISSIVE:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW
    
    def _check_seccomp_bypass(self, status: SecurityStatus, profile: str):
        """Check for seccomp bypass opportunities."""
        if status == SecurityStatus.DISABLED:
            self.findings.append(SecurityFinding(
                module=SecurityModule.SECCOMP,
                status=status,
                risk=RiskLevel.CRITICAL,
                title="Seccomp Disabled",
                description=SECCOMP_BYPASS_TECHNIQUES["seccomp_disabled"]["description"],
                bypass_techniques=["All syscalls available", "No filtering applied"],
                evidence=f"Seccomp status: disabled, profile: {profile}",
                remediation="Enable seccomp with appropriate profile (e.g., docker-default)",
                mitre_technique="T1562.001",
            ))
        
        # Check for kernel CVEs affecting seccomp
        try:
            kernel_version = os.uname().release
            for cve_info in SECCOMP_BYPASS_TECHNIQUES["seccomp_kernel_cve"]["cves"]:
                for affected in cve_info.get("affected_kernels", []):
                    if self._is_kernel_affected(kernel_version, affected):
                        self.findings.append(SecurityFinding(
                            module=SecurityModule.SECCOMP,
                            status=SecurityStatus.ENFORCING,
                            risk=RiskLevel.CRITICAL,
                            title=f"Kernel CVE: {cve_info['id']}",
                            description=cve_info["description"],
                            bypass_techniques=["Kernel exploit to bypass seccomp"],
                            evidence=f"Kernel {kernel_version} may be affected by {cve_info['id']}",
                            remediation="Update kernel to patched version",
                            mitre_technique="T1068",
                        ))
                        break
        except Exception:
            pass
    
    def _check_apparmor_bypass(self, status: SecurityStatus, profile: str):
        """Check for AppArmor bypass opportunities."""
        if status in [SecurityStatus.DISABLED, SecurityStatus.UNCONFINED]:
            info = APPARMOR_CONTAINER_BYPASS["apparmor_disabled"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.APPARMOR,
                status=status,
                risk=RiskLevel.CRITICAL,
                title="AppArmor Disabled/Unconfined",
                description=info["description"],
                bypass_techniques=["No AppArmor restrictions apply"],
                evidence=f"AppArmor profile: {profile}",
                remediation="Enable AppArmor with docker-default or custom profile",
                mitre_technique="T1562.001",
            ))
        elif status == SecurityStatus.PERMISSIVE:
            self.findings.append(SecurityFinding(
                module=SecurityModule.APPARMOR,
                status=status,
                risk=RiskLevel.HIGH,
                title="AppArmor in Complain Mode",
                description="AppArmor profile is in complain (permissive) mode - logging only",
                bypass_techniques=["All actions logged but not blocked"],
                evidence=f"AppArmor profile: {profile}",
                remediation="Switch profile to enforce mode",
                mitre_technique="T1562.001",
            ))
        elif "docker-default" in profile:
            # Check for docker-default bypass techniques
            info = APPARMOR_CONTAINER_BYPASS["docker_default_bypass"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.APPARMOR,
                status=status,
                risk=RiskLevel.MEDIUM,
                title="Docker Default AppArmor Profile Weaknesses",
                description=info["description"],
                bypass_techniques=[t["name"] for t in info["techniques"]],
                evidence=f"AppArmor profile: {profile}",
                remediation="Consider using custom hardened AppArmor profile",
                mitre_technique="T1562.001",
            ))
    
    def _check_selinux_bypass(self, status: SecurityStatus, context: str):
        """Check for SELinux bypass opportunities."""
        if status == SecurityStatus.DISABLED:
            info = SELINUX_CONTAINER_BYPASS["selinux_disabled"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.SELINUX,
                status=status,
                risk=RiskLevel.CRITICAL,
                title="SELinux Disabled",
                description=info["description"],
                bypass_techniques=["No SELinux restrictions apply"],
                evidence=f"SELinux context: {context}",
                remediation="Enable SELinux in enforcing mode",
                mitre_technique="T1562.001",
            ))
        elif status == SecurityStatus.PERMISSIVE:
            self.findings.append(SecurityFinding(
                module=SecurityModule.SELINUX,
                status=status,
                risk=RiskLevel.HIGH,
                title="SELinux in Permissive Mode",
                description="SELinux is in permissive mode - logging only, not enforcing",
                bypass_techniques=["All actions logged but not blocked"],
                evidence=f"SELinux context: {context}",
                remediation="Switch SELinux to enforcing mode",
                mitre_technique="T1562.001",
            ))
        elif status == SecurityStatus.UNCONFINED or "spc_t" in context:
            info = SELINUX_CONTAINER_BYPASS["container_spc_type"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.SELINUX,
                status=status,
                risk=RiskLevel.CRITICAL,
                title="Super Privileged Container (spc_t)",
                description=info["description"],
                bypass_techniques=info["techniques"],
                evidence=f"SELinux context: {context}",
                remediation="Use restricted container type (container_t)",
                mitre_technique="T1562.001",
            ))
    
    def _check_combined_security(self, status: RuntimeSecurityStatus):
        """Check combined security posture."""
        if status.is_privileged:
            info = RUNTIME_SECURITY_BYPASS["privileged_container"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.NONE,
                status=SecurityStatus.DISABLED,
                risk=RiskLevel.CRITICAL,
                title="Privileged Container Detected",
                description=info["description"],
                bypass_techniques=info["escape_methods"],
                evidence=f"Full capabilities, device access, no security modules",
                remediation="Avoid privileged containers; use minimal capabilities",
                mitre_technique="T1611",
            ))
        
        # Check if all security disabled
        all_disabled = (
            status.seccomp == SecurityStatus.DISABLED and
            status.apparmor in [SecurityStatus.DISABLED, SecurityStatus.UNCONFINED] and
            status.selinux in [SecurityStatus.DISABLED, SecurityStatus.UNCONFINED]
        )
        
        if all_disabled and not status.is_privileged:
            info = RUNTIME_SECURITY_BYPASS["no_security_modules"]
            self.findings.append(SecurityFinding(
                module=SecurityModule.NONE,
                status=SecurityStatus.DISABLED,
                risk=RiskLevel.CRITICAL,
                title="No Runtime Security Modules Active",
                description=info["description"],
                bypass_techniques=["Maximum escape potential - no restrictions"],
                evidence="Seccomp disabled, AppArmor unconfined, SELinux disabled",
                remediation="Enable at least one security module (seccomp + AppArmor/SELinux)",
                mitre_technique="T1562.001",
            ))
    
    def _is_kernel_affected(self, current_version: str, affected_range: str) -> bool:
        """Check if kernel version is affected by a vulnerability."""
        try:
            # Extract major.minor.patch from kernel version
            version_match = re.match(r"(\d+)\.(\d+)\.(\d+)", current_version)
            if not version_match:
                return False
            
            current = tuple(map(int, version_match.groups()))
            
            # Parse affected range (e.g., "< 5.12.4")
            if affected_range.startswith("<"):
                affected_str = affected_range[1:].strip()
                affected = tuple(map(int, affected_str.split(".")))
                return current < affected
            elif affected_range.startswith(">="):
                affected_str = affected_range[2:].strip()
                affected = tuple(map(int, affected_str.split(".")))
                return current >= affected
            elif " - " in affected_range:
                parts = affected_range.split(" - ")
                start = tuple(map(int, parts[0].strip().split(".")))
                end = tuple(map(int, parts[1].strip().split(".")))
                return start <= current <= end
        except Exception:
            pass
        
        return False
    
    def get_findings_by_risk(self, risk: RiskLevel) -> List[SecurityFinding]:
        """Get findings filtered by risk level."""
        return [f for f in self.findings if f.risk == risk]
    
    def get_findings_by_module(self, module: SecurityModule) -> List[SecurityFinding]:
        """Get findings filtered by security module."""
        return [f for f in self.findings if f.module == module]
    
    def get_critical_findings(self) -> List[SecurityFinding]:
        """Get all critical and high risk findings."""
        return [f for f in self.findings if f.risk in [RiskLevel.CRITICAL, RiskLevel.HIGH]]

