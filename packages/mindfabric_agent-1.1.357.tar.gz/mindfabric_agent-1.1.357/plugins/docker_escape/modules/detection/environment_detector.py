"""Environment detection for Docker escape assessment."""

import os
import re
import socket
from typing import Dict, List, Optional, Any
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from ....docker_escape.proto import (
    ContainerEnvironment, ContainerRuntime, KernelInfo, CloudMetadata,
    KubernetesInfo, MountPoint, NetworkInterface
)
from modules.databases import (
    DANGEROUS_MOUNTS,
    CLOUD_METADATA_ENDPOINTS,
    K8S_PATHS,
    CAPABILITIES_DATABASE,
    KERNEL_ESCAPE_PATHS
)


class EnvironmentDetector:
    """Detects container environment and configuration."""

    async def detect_environment(self) -> ContainerEnvironment:
        """Comprehensive container environment detection."""
        env = ContainerEnvironment()

        # Check if inside container
        env.inside_container = self._is_inside_container()
        if not env.inside_container:
            return env

        env.detection_methods.append("container_detection")

        # Basic info
        env.runtime = self._detect_runtime()
        env.container_id = self._get_container_id()

        # User info
        env.user_id = os.getuid()
        env.group_id = os.getgid()
        env.is_root = env.user_id == 0
        try:
            env.groups = list(os.getgroups())
        except:
            pass

        # Capabilities
        caps = self._get_capabilities()
        env.effective_caps = caps.get("effective", [])
        env.effective_caps_hex = caps.get("effective_hex")
        env.permitted_caps = caps.get("permitted", [])
        env.bounding_caps = caps.get("bounding", [])
        env.ambient_caps = caps.get("ambient", [])

        # Privileged mode
        env.is_privileged = self._is_privileged()

        # Namespaces
        env.has_host_pid = self._has_host_pid_namespace()
        env.has_host_network = self._has_host_network()
        env.has_host_ipc = self._has_host_ipc()
        env.has_host_uts = self._has_host_uts()
        env.has_user_namespace = self._has_user_namespace()

        # Security policies
        env.selinux_enforcing = self._check_selinux()
        env.selinux_context = self._get_selinux_context()
        env.apparmor_profile = self._get_apparmor_profile()
        env.seccomp_profile = self._get_seccomp_status()
        env.no_new_privs = self._check_no_new_privs()
        env.read_only_rootfs = self._check_read_only_rootfs()

        # Mounts
        env.mounts = self._enumerate_mounts()
        env.docker_sock_available = os.path.exists("/var/run/docker.sock")
        env.containerd_sock_available = os.path.exists("/run/containerd/containerd.sock")

        # Kernel info
        env.kernel = self._get_kernel_info()

        # Network
        env.network_interfaces = self._enumerate_network_interfaces()

        # Cloud detection
        env.cloud = await self._detect_cloud_environment()

        # Kubernetes detection
        env.kubernetes = self._detect_kubernetes()

        # Available tools
        env.available_tools = self._enumerate_tools()

        return env

    def _is_inside_container(self) -> bool:
        """Check if running inside a container using multiple methods."""
        # NOTE: This check must be conservative. False positives here cause the plugin to
        # run container-escape tests on a normal host and generate bogus "escape" findings.

        # Method 1: Check cgroup
        try:
            with open('/proc/1/cgroup', 'r') as f:
                content = f.read()
            if any(x in content for x in ['docker', 'containerd', 'kubepods', 'lxc', 'podman']):
                return True
        except:
            pass

        # Method 2: Check /.dockerenv
        if os.path.exists('/.dockerenv'):
            return True

        # Method 3: Check /run/.containerenv (podman)
        if os.path.exists('/run/.containerenv'):
            return True

        return False

    def _detect_runtime(self) -> ContainerRuntime:
        """Detect container runtime."""
        # Check sockets
        if os.path.exists('/var/run/docker.sock'):
            return ContainerRuntime.DOCKER
        if os.path.exists('/run/containerd/containerd.sock'):
            return ContainerRuntime.CONTAINERD
        if os.path.exists('/var/run/crio/crio.sock'):
            return ContainerRuntime.CRIO
        if os.path.exists('/run/podman/podman.sock'):
            return ContainerRuntime.PODMAN

        # Check cgroup
        try:
            with open('/proc/1/cgroup', 'r') as f:
                content = f.read().lower()
            if 'docker' in content:
                return ContainerRuntime.DOCKER
            if 'containerd' in content:
                return ContainerRuntime.CONTAINERD
            if 'crio' in content:
                return ContainerRuntime.CRIO
            if 'podman' in content:
                return ContainerRuntime.PODMAN
            if 'lxc' in content:
                return ContainerRuntime.LXC
        except:
            pass

        return ContainerRuntime.UNKNOWN

    def _get_container_id(self) -> Optional[str]:
        """Get container ID."""
        try:
            with open('/proc/self/cgroup', 'r') as f:
                for line in f:
                    match = re.search(r'([a-f0-9]{64})', line)
                    if match:
                        return match.group(1)[:12]
        except:
            pass

        try:
            hostname = socket.gethostname()
            if len(hostname) == 12 and all(c in '0123456789abcdef' for c in hostname):
                return hostname
        except:
            pass

        return None

    def _get_capabilities(self) -> Dict[str, Any]:
        """Get Linux capabilities."""
        result = {
            "effective": [], "permitted": [], "bounding": [],
            "ambient": [], "effective_hex": None
        }

        try:
            with open('/proc/self/status', 'r') as f:
                for line in f:
                    if line.startswith('CapEff:'):
                        cap_hex = line.split()[1]
                        result["effective_hex"] = cap_hex
                        result["effective"] = self._decode_capabilities(int(cap_hex, 16))
                    elif line.startswith('CapPrm:'):
                        cap_hex = line.split()[1]
                        result["permitted"] = self._decode_capabilities(int(cap_hex, 16))
                    elif line.startswith('CapBnd:'):
                        cap_hex = line.split()[1]
                        result["bounding"] = self._decode_capabilities(int(cap_hex, 16))
                    elif line.startswith('CapAmb:'):
                        cap_hex = line.split()[1]
                        result["ambient"] = self._decode_capabilities(int(cap_hex, 16))
        except:
            pass

        return result

    def _decode_capabilities(self, cap_value: int) -> List[str]:
        """Decode capability bitmask to names."""
        caps = []
        for cap_name, cap_info in CAPABILITIES_DATABASE.items():
            if cap_value & (1 << cap_info["bit"]):
                caps.append(cap_name)
        return caps

    def _is_privileged(self) -> bool:
        """Check if container is running in privileged mode."""
        # Check for high capability value
        try:
            with open('/proc/self/status', 'r') as f:
                for line in f:
                    if line.startswith('CapEff:'):
                        cap_hex = int(line.split()[1], 16)
                        if cap_hex > 0x1ffffffffff:
                            return True
        except:
            pass

        # Check device access
        if os.path.exists('/dev/sda') and os.access('/dev/sda', os.R_OK):
            return True

        # Check /sys/kernel/security write access
        if os.access('/sys/kernel/security', os.W_OK):
            return True

        return False

    def _has_host_pid_namespace(self) -> bool:
        """Check if using host PID namespace."""
        try:
            with open('/proc/1/cmdline', 'r') as f:
                cmdline = f.read()
            if 'systemd' in cmdline or '/sbin/init' in cmdline:
                return True
        except:
            pass
        return False

    def _has_host_network(self) -> bool:
        """Check if using host network namespace."""
        try:
            interfaces = os.listdir('/sys/class/net/')
            if len(interfaces) > 3:
                return True
            for iface in interfaces:
                if any(iface.startswith(p) for p in ['eth', 'ens', 'enp', 'em', 'wlan']):
                    return True
        except:
            pass
        return False

    def _has_host_ipc(self) -> bool:
        """Check if using host IPC namespace."""
        try:
            if os.path.exists('/dev/shm'):
                shm_files = os.listdir('/dev/shm')
                if len(shm_files) > 5:
                    return True
        except:
            pass
        return False

    def _has_host_uts(self) -> bool:
        """Check if using host UTS namespace."""
        try:
            hostname = socket.gethostname()
            # Container hostnames are usually short hex strings
            if not (len(hostname) == 12 or len(hostname) == 64):
                return True
        except:
            pass
        return False

    def _has_user_namespace(self) -> bool:
        """Check if using user namespace."""
        try:
            with open('/proc/self/uid_map', 'r') as f:
                content = f.read().strip()
            # If mapping exists, user namespace is in use
            if content and '4294967295' not in content:
                return True
        except:
            pass
        return False

    def _check_selinux(self) -> Optional[bool]:
        """Check SELinux status."""
        try:
            if os.path.exists('/sys/fs/selinux/enforce'):
                with open('/sys/fs/selinux/enforce', 'r') as f:
                    return f.read().strip() == '1'
        except:
            pass
        return None

    def _get_selinux_context(self) -> Optional[str]:
        """Get current SELinux context."""
        try:
            with open('/proc/self/attr/current', 'r') as f:
                return f.read().strip()
        except:
            pass
        return None

    def _get_apparmor_profile(self) -> Optional[str]:
        """Get AppArmor profile."""
        try:
            with open('/proc/self/attr/current', 'r') as f:
                profile = f.read().strip()
            if profile and profile != 'unconfined':
                return profile
        except:
            pass
        return None

    def _get_seccomp_status(self) -> Optional[str]:
        """Get seccomp status."""
        try:
            with open('/proc/self/status', 'r') as f:
                for line in f:
                    if line.startswith('Seccomp:'):
                        mode = int(line.split()[1])
                        return {0: "disabled", 1: "strict", 2: "filter"}.get(mode)
        except:
            pass
        return None

    def _check_no_new_privs(self) -> bool:
        """Check NoNewPrivs flag."""
        try:
            with open('/proc/self/status', 'r') as f:
                for line in f:
                    if line.startswith('NoNewPrivs:'):
                        return line.split()[1] == '1'
        except:
            pass
        return False

    def _check_read_only_rootfs(self) -> bool:
        """Check if root filesystem is read-only."""
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 4 and parts[1] == '/':
                        return 'ro' in parts[3].split(',')
        except:
            pass
        return False

    def _enumerate_mounts(self) -> List[MountPoint]:
        """Enumerate container mounts."""
        mounts = []
        try:
            with open('/proc/self/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 4:
                        mount = MountPoint(
                            source=parts[0],
                            destination=parts[1],
                            fs_type=parts[2],
                            options=parts[3].split(',')
                        )

                        for pattern in DANGEROUS_MOUNTS:
                            if pattern["pattern"] in mount.destination or pattern["pattern"] in mount.source:
                                mount.is_dangerous = True
                                mount.risk_level = pattern["risk"]
                                mount.escape_method = pattern["method"]
                                mount.notes = f"Potentially dangerous: {pattern['method'].value}"
                                break

                        mounts.append(mount)
        except:
            pass

        return mounts

    def _get_kernel_info(self) -> KernelInfo:
        """Get kernel information."""
        info = KernelInfo()
        try:
            with open('/proc/version', 'r') as f:
                info.full_version = f.read().strip()

            match = re.search(r'Linux version (\d+)\.(\d+)\.(\d+)', info.full_version)
            if match:
                info.major = int(match.group(1))
                info.minor = int(match.group(2))
                info.patch = int(match.group(3))
                info.version = f"{info.major}.{info.minor}.{info.patch}"

            info.release = os.uname().release

            # Check for vulnerable kernel versions
            # Dirty COW: < 4.8.3
            if info.major < 4 or (info.major == 4 and info.minor < 8):
                info.is_vulnerable_dirty_cow = True

            # Dirty Pipe: 5.8 - 5.16.11
            if info.major == 5 and 8 <= info.minor <= 16:
                info.is_vulnerable_dirty_pipe = True

            # eBPF availability (5.8+)
            info.has_ebpf = info.major > 5 or (info.major == 5 and info.minor >= 8)

            # io_uring (5.1+)
            info.has_io_uring = info.major > 5 or (info.major == 5 and info.minor >= 1)

            # User namespaces
            info.has_user_namespaces = os.path.exists('/proc/sys/user/max_user_namespaces')

        except:
            pass

        return info

    def _enumerate_network_interfaces(self) -> List[NetworkInterface]:
        """Enumerate network interfaces."""
        interfaces = []
        try:
            for name in os.listdir('/sys/class/net/'):
                iface = NetworkInterface(name=name)

                # Get MAC
                try:
                    with open(f'/sys/class/net/{name}/address', 'r') as f:
                        iface.mac_address = f.read().strip()
                except:
                    pass

                # Check if host interface
                if any(name.startswith(p) for p in ['eth', 'ens', 'enp', 'em', 'wlan']):
                    iface.is_host_interface = True

                if name.startswith('docker') or name.startswith('br-'):
                    iface.is_bridge = True

                interfaces.append(iface)
        except:
            pass

        return interfaces

    async def _detect_cloud_environment(self) -> CloudMetadata:
        """Detect cloud environment and metadata."""
        metadata = CloudMetadata()

        # Try each cloud provider
        for provider_name, config in CLOUD_METADATA_ENDPOINTS.items():
            try:
                import httpx
                async with httpx.AsyncClient(timeout=2.0) as client:
                    headers = config.get("headers", {})
                    resp = await client.get(
                        f"{config['base_url']}{config['metadata_endpoint']}",
                        headers=headers
                    )
                    if resp.status_code == 200:
                        metadata.provider = config["provider"]
                        break
            except:
                continue

        return metadata

    def _detect_kubernetes(self) -> KubernetesInfo:
        """Detect Kubernetes environment."""
        k8s = KubernetesInfo()

        # Check for K8s environment variables
        if os.environ.get('KUBERNETES_SERVICE_HOST'):
            k8s.in_kubernetes = True
            k8s.api_server = f"https://{os.environ.get('KUBERNETES_SERVICE_HOST')}:{os.environ.get('KUBERNETES_SERVICE_PORT', '443')}"

        # Check for service account token
        if os.path.exists(K8S_PATHS["token"]):
            k8s.token_path = K8S_PATHS["token"]
            k8s.has_token = True
            k8s.in_kubernetes = True

        # Get namespace
        if os.path.exists(K8S_PATHS["namespace"]):
            try:
                with open(K8S_PATHS["namespace"], 'r') as f:
                    k8s.namespace = f.read().strip()
            except:
                pass

        # Get pod name from hostname
        try:
            k8s.pod_name = socket.gethostname()
        except:
            pass

        return k8s

    def _enumerate_tools(self) -> List[str]:
        """Enumerate available tools in container."""
        tools = []
        common_tools = [
            'curl', 'wget', 'nc', 'ncat', 'netcat', 'socat', 'python', 'python3',
            'perl', 'ruby', 'php', 'node', 'gcc', 'make', 'strace', 'ltrace',
            'gdb', 'nsenter', 'unshare', 'mount', 'umount', 'chroot', 'pivot_root',
            'capsh', 'getcap', 'setcap', 'iptables', 'ip', 'ss', 'nmap',
            'docker', 'kubectl', 'crictl', 'ctr', 'runc', 'mknod', 'dd'
        ]

        import shutil
        for tool in common_tools:
            if shutil.which(tool):
                tools.append(tool)

        return tools
    
    def check_kernel_escape_paths(self) -> Dict[str, Dict[str, Any]]:
        """Check for accessible kernel escape paths using KERNEL_ESCAPE_PATHS.
        
        Returns dict of accessible paths with their metadata.
        """
        accessible_paths = {}
        
        for path_name, path_info in KERNEL_ESCAPE_PATHS.items():
            if not isinstance(path_info, dict):
                continue
            
            path = path_info.get("path", "")
            if not path:
                continue
            
            # Check if path exists and is accessible
            if os.path.exists(path):
                is_writable = os.access(path, os.W_OK)
                is_readable = os.access(path, os.R_OK)
                
                if is_readable or is_writable:
                    accessible_paths[path_name] = {
                        "path": path,
                        "readable": is_readable,
                        "writable": is_writable,
                        "description": path_info.get("description", ""),
                        "severity": path_info.get("severity", "high"),
                        "escape_method": path_info.get("escape_method", ""),
                        "required_caps": path_info.get("required_caps", []),
                        "mitre_technique": path_info.get("mitre", "T1611"),
                    }
                    
                    # Try to read current value if readable
                    if is_readable:
                        try:
                            with open(path, 'r') as f:
                                accessible_paths[path_name]["current_value"] = f.read().strip()[:200]
                        except:
                            pass
        
        return accessible_paths

        # =========================================================================
        # Phase 2: Capability Analysis
        # =========================================================================
