"""Capability analyzer for Docker escape assessment."""
from typing import List
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from plugins.docker_escape.proto import ContainerEnvironment, CapabilitySummary, CapabilityRisk
from modules.databases import CAPABILITIES_DATABASE


class CapabilityAnalyzer:
    """Analyzes container capabilities for escape potential."""
    
    def analyze(self, env: ContainerEnvironment) -> CapabilitySummary:
        """Analyze effective capabilities for escape potential."""
        summary = CapabilitySummary(total_effective=len(env.effective_caps))
        
        risk_score = 0.0
        for cap in env.effective_caps:
            if cap in CAPABILITIES_DATABASE:
                cap_info = CAPABILITIES_DATABASE[cap]
                if cap_info["risk"] == CapabilityRisk.CRITICAL:
                    summary.dangerous_caps.append(cap)
                    risk_score += 3.0
                elif cap_info["risk"] == CapabilityRisk.HIGH:
                    summary.dangerous_caps.append(cap)
                    risk_score += 2.0
                elif cap_info["risk"] == CapabilityRisk.MEDIUM:
                    risk_score += 1.0
                
                if cap_info.get("escape_methods"):
                    summary.escape_enabling_caps.append(cap)
        
        summary.risk_score = min(10.0, risk_score)
        return summary
