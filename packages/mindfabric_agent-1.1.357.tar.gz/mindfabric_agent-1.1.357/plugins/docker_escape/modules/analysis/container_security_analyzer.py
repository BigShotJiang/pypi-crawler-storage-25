"""
Container Security Analyzer

Comprehensive container security analysis:
- Image security scanning
- Runtime protection analysis
- Supply chain security
- Container hardening
- Vulnerability detection
- Compliance checking

MITRE ATT&CK:
- T1610: Deploy Container
- T1525: Implant Internal Image
- T1611: Escape to Host
"""

import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from utils.async_subprocess import run_exec


class SeverityLevel(str, Enum):
    """Severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class VulnerabilityType(str, Enum):
    """Types of container vulnerabilities."""
    CVE = "cve"
    MISCONFIGURATION = "misconfiguration"
    SECRET_LEAK = "secret_leak"
    MALWARE = "malware"
    SUPPLY_CHAIN = "supply_chain"
    RUNTIME = "runtime"
    COMPLIANCE = "compliance"


# =============================================================================
# Container Image Security Checks
# =============================================================================

IMAGE_SECURITY_CHECKS = {
    "base_image_vulnerability": {
        "name": "Base Image Vulnerabilities",
        "description": "Check base image for known CVEs",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1525",
        "check_method": "scan_base_image",
    },
    "outdated_packages": {
        "name": "Outdated Packages",
        "description": "Detect outdated packages with known vulnerabilities",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1525",
        "check_method": "scan_packages",
    },
    "hardcoded_secrets": {
        "name": "Hardcoded Secrets",
        "description": "Detect secrets embedded in image layers",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1552",
        "patterns": [
            r"(?:password|passwd|pwd)\s*[=:]\s*['\"]?([^'\"\s]+)",
            r"(?:api[_-]?key|apikey)\s*[=:]\s*['\"]?([^'\"\s]+)",
            r"(?:secret|token)\s*[=:]\s*['\"]?([^'\"\s]+)",
            r"-----BEGIN (?:RSA |OPENSSH |DSA |EC )?PRIVATE KEY-----",
            r"(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}",
        ],
    },
    "setuid_binaries": {
        "name": "SETUID Binaries",
        "description": "Detect SETUID/SETGID binaries that could be exploited",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1548.001",
        "dangerous_binaries": [
            "/usr/bin/sudo",
            "/usr/bin/su",
            "/usr/bin/passwd",
            "/usr/bin/chsh",
            "/usr/bin/chfn",
            "/usr/bin/newgrp",
            "/usr/sbin/unix_chkpwd",
        ],
    },
    "writable_binaries": {
        "name": "World-Writable Binaries",
        "description": "Detect world-writable executables",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1222",
        "check_method": "find_writable_binaries",
    },
    "root_user": {
        "name": "Root User Container",
        "description": "Container running as root user",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1610",
        "check_method": "check_container_user",
    },
    "shell_available": {
        "name": "Shell Available",
        "description": "Interactive shell available in container",
        "severity": SeverityLevel.LOW,
        "mitre": "T1059",
        "shells": ["/bin/bash", "/bin/sh", "/bin/zsh", "/bin/ash"],
    },
    "package_managers": {
        "name": "Package Managers Present",
        "description": "Package managers that could install malware",
        "severity": SeverityLevel.LOW,
        "mitre": "T1059",
        "managers": ["apt", "apt-get", "yum", "dnf", "apk", "pip", "npm"],
    },
}


# =============================================================================
# Runtime Security Checks
# =============================================================================

RUNTIME_SECURITY_CHECKS = {
    "privileged_mode": {
        "name": "Privileged Mode",
        "description": "Container running in privileged mode",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1611",
        "check": "SecurityOpt does not contain no-new-privileges",
    },
    "capabilities": {
        "name": "Dangerous Capabilities",
        "description": "Container has dangerous Linux capabilities",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1611",
        "dangerous_caps": [
            "CAP_SYS_ADMIN",
            "CAP_SYS_PTRACE",
            "CAP_SYS_MODULE",
            "CAP_NET_ADMIN",
            "CAP_NET_RAW",
            "CAP_DAC_READ_SEARCH",
            "CAP_DAC_OVERRIDE",
            "CAP_SYS_RAWIO",
            "CAP_MKNOD",
        ],
    },
    "host_namespaces": {
        "name": "Host Namespace Sharing",
        "description": "Container shares host namespaces",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1611",
        "namespaces": {
            "pid": "hostPID enables process visibility/manipulation",
            "network": "hostNetwork exposes host network stack",
            "ipc": "hostIPC enables IPC abuse",
            "uts": "hostUTS allows hostname manipulation",
        },
    },
    "sensitive_mounts": {
        "name": "Sensitive Host Mounts",
        "description": "Sensitive host paths mounted in container",
        "severity": SeverityLevel.CRITICAL,
        "mitre": "T1611",
        "sensitive_paths": [
            "/",
            "/etc",
            "/var/run/docker.sock",
            "/var/run/containerd/containerd.sock",
            "/var/run/crio/crio.sock",
            "/proc",
            "/sys",
            "/dev",
            "/root",
            "/home",
        ],
    },
    "seccomp_disabled": {
        "name": "Seccomp Disabled",
        "description": "Seccomp security profile disabled",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1611",
        "check": "seccomp:unconfined",
    },
    "apparmor_disabled": {
        "name": "AppArmor Disabled",
        "description": "AppArmor security profile disabled",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1611",
        "check": "apparmor:unconfined",
    },
    "read_only_rootfs": {
        "name": "Writable Root Filesystem",
        "description": "Container filesystem is writable",
        "severity": SeverityLevel.LOW,
        "mitre": "T1610",
        "check": "ReadonlyRootfs=false",
    },
    "resource_limits": {
        "name": "Missing Resource Limits",
        "description": "No CPU/memory limits configured",
        "severity": SeverityLevel.LOW,
        "mitre": "T1610",
        "check": "Missing NanoCpus or Memory limits",
    },
}


# =============================================================================
# Supply Chain Security Checks
# =============================================================================

SUPPLY_CHAIN_CHECKS = {
    "unsigned_image": {
        "name": "Unsigned Image",
        "description": "Image is not signed or signature not verified",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1525",
        "tools": ["cosign", "notary", "docker trust"],
    },
    "untrusted_registry": {
        "name": "Untrusted Registry",
        "description": "Image pulled from untrusted registry",
        "severity": SeverityLevel.HIGH,
        "mitre": "T1525",
        "trusted_registries": [
            "docker.io/library",
            "gcr.io",
            "ghcr.io",
            "ecr.aws",
            "registry.k8s.io",
        ],
    },
    "latest_tag": {
        "name": "Latest Tag Usage",
        "description": "Using 'latest' tag instead of specific version",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1525",
        "check": "image:latest",
    },
    "dockerfile_security": {
        "name": "Dockerfile Security Issues",
        "description": "Security issues in Dockerfile",
        "severity": SeverityLevel.MEDIUM,
        "mitre": "T1525",
        "issues": [
            "ADD instead of COPY",
            "curl | bash patterns",
            "Running as root",
            "Exposed secrets in ENV",
        ],
    },
    "sbom_missing": {
        "name": "Missing SBOM",
        "description": "No Software Bill of Materials available",
        "severity": SeverityLevel.LOW,
        "mitre": "T1525",
        "tools": ["syft", "trivy", "grype"],
    },
}


# =============================================================================
# Compliance Checks
# =============================================================================

COMPLIANCE_CHECKS = {
    "cis_docker_benchmark": {
        "name": "CIS Docker Benchmark",
        "description": "Docker CIS Benchmark compliance",
        "checks": [
            {"id": "1.1.1", "name": "Ensure container host is hardened"},
            {"id": "1.1.2", "name": "Ensure Docker version is up to date"},
            {"id": "4.1", "name": "Ensure image is from trusted registry"},
            {"id": "4.2", "name": "Ensure no unnecessary packages in container"},
            {"id": "4.5", "name": "Ensure HEALTHCHECK is configured"},
            {"id": "4.6", "name": "Ensure containers have fixed tags"},
            {"id": "5.1", "name": "Ensure AppArmor Profile is enabled"},
            {"id": "5.2", "name": "Ensure SELinux security options are set"},
            {"id": "5.3", "name": "Ensure container is not privileged"},
            {"id": "5.4", "name": "Ensure sensitive host paths are not mounted"},
            {"id": "5.7", "name": "Ensure no privileged ports are mapped"},
            {"id": "5.9", "name": "Ensure container's root filesystem is read-only"},
            {"id": "5.10", "name": "Ensure host's network namespace is not shared"},
            {"id": "5.11", "name": "Ensure memory is limited"},
            {"id": "5.12", "name": "Ensure CPU priority is appropriately set"},
            {"id": "5.13", "name": "Ensure container's root filesystem is read-only"},
            {"id": "5.25", "name": "Ensure container is restricted from acquiring additional privileges"},
        ],
    },
    "nist_container_security": {
        "name": "NIST Container Security",
        "description": "NIST SP 800-190 compliance",
        "areas": [
            "Image vulnerabilities",
            "Image configuration defects",
            "Embedded malware",
            "Embedded secrets",
            "Use of untrusted images",
        ],
    },
}


@dataclass
class ContainerSecurityFinding:
    """A container security finding."""
    check_name: str
    vulnerability_type: VulnerabilityType
    severity: SeverityLevel
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    mitre_technique: str = ""
    compliance: List[str] = field(default_factory=list)


@dataclass
class ContainerSecurityReport:
    """Container security analysis report."""
    container_id: str
    image: str
    findings: List[ContainerSecurityFinding] = field(default_factory=list)
    risk_score: float = 0.0
    compliance_status: Dict[str, bool] = field(default_factory=dict)


class ContainerSecurityAnalyzer:
    """Comprehensive container security analyzer."""
    
    def __init__(self, plugin_instance=None):
        self.plugin = plugin_instance
        self.findings: List[ContainerSecurityFinding] = []
    
    async def analyze_image(
        self,
        image_name: str,
    ) -> List[ContainerSecurityFinding]:
        """
        Analyze container image for security issues.
        
        Args:
            image_name: Container image name/tag
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Check for latest tag
        if image_name.endswith(":latest") or ":" not in image_name:
            findings.append(ContainerSecurityFinding(
                check_name="latest_tag",
                vulnerability_type=VulnerabilityType.SUPPLY_CHAIN,
                severity=SeverityLevel.MEDIUM,
                description=f"Image '{image_name}' uses 'latest' tag",
                evidence={"image": image_name},
                remediation="Use specific version tags for reproducibility",
                mitre_technique="T1525",
                compliance=["CIS 4.6"],
            ))
        
        # Check for untrusted registry
        trusted = False
        for registry in SUPPLY_CHAIN_CHECKS["untrusted_registry"]["trusted_registries"]:
            if image_name.startswith(registry):
                trusted = True
                break
        
        if not trusted and "/" in image_name:
            findings.append(ContainerSecurityFinding(
                check_name="untrusted_registry",
                vulnerability_type=VulnerabilityType.SUPPLY_CHAIN,
                severity=SeverityLevel.MEDIUM,
                description=f"Image from potentially untrusted registry",
                evidence={"image": image_name},
                remediation="Use images from trusted registries only",
                mitre_technique="T1525",
                compliance=["CIS 4.1"],
            ))
        
        # Try to inspect image
        image_info = await self._inspect_image(image_name)
        
        if image_info:
            # Check for root user
            user = image_info.get("Config", {}).get("User", "")
            if not user or user == "root" or user == "0":
                findings.append(ContainerSecurityFinding(
                    check_name="root_user",
                    vulnerability_type=VulnerabilityType.MISCONFIGURATION,
                    severity=SeverityLevel.MEDIUM,
                    description="Image configured to run as root",
                    evidence={"user": user or "root"},
                    remediation="Add USER directive in Dockerfile",
                    mitre_technique="T1610",
                ))
            
            # Check for exposed ports
            exposed_ports = image_info.get("Config", {}).get("ExposedPorts", {})
            privileged_ports = [p for p in exposed_ports.keys() if int(p.split("/")[0]) < 1024]
            
            if privileged_ports:
                findings.append(ContainerSecurityFinding(
                    check_name="privileged_ports",
                    vulnerability_type=VulnerabilityType.MISCONFIGURATION,
                    severity=SeverityLevel.LOW,
                    description="Image exposes privileged ports",
                    evidence={"ports": privileged_ports},
                    remediation="Use non-privileged ports (>1024)",
                    compliance=["CIS 5.7"],
                ))
            
            # Check for secrets in environment
            env_vars = image_info.get("Config", {}).get("Env", [])
            secrets_found = self._check_env_for_secrets(env_vars)
            
            if secrets_found:
                findings.append(ContainerSecurityFinding(
                    check_name="hardcoded_secrets",
                    vulnerability_type=VulnerabilityType.SECRET_LEAK,
                    severity=SeverityLevel.CRITICAL,
                    description="Secrets found in image environment variables",
                    evidence={"variables": [s[0] for s in secrets_found]},
                    remediation="Use secrets management; don't embed secrets in images",
                    mitre_technique="T1552",
                ))
        
        return findings
    
    async def analyze_container(
        self,
        container_id: str,
    ) -> List[ContainerSecurityFinding]:
        """
        Analyze running container for security issues.
        
        Args:
            container_id: Container ID or name
            
        Returns:
            List of security findings
        """
        findings = []
        
        # Inspect container
        container_info = await self._inspect_container(container_id)
        
        if not container_info:
            return findings
        
        host_config = container_info.get("HostConfig", {})
        
        # Check privileged mode
        if host_config.get("Privileged"):
            findings.append(ContainerSecurityFinding(
                check_name="privileged_mode",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.CRITICAL,
                description="Container running in privileged mode",
                evidence={"privileged": True},
                remediation="Remove privileged flag; use specific capabilities",
                mitre_technique="T1611",
                compliance=["CIS 5.3"],
            ))
        
        # Check capabilities
        cap_add = host_config.get("CapAdd", []) or []
        dangerous_caps = [c for c in cap_add if c in RUNTIME_SECURITY_CHECKS["capabilities"]["dangerous_caps"]]
        
        if dangerous_caps:
            findings.append(ContainerSecurityFinding(
                check_name="dangerous_capabilities",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.HIGH,
                description="Container has dangerous capabilities",
                evidence={"capabilities": dangerous_caps},
                remediation="Remove unnecessary capabilities",
                mitre_technique="T1611",
            ))
        
        # Check host namespaces
        if host_config.get("PidMode") == "host":
            findings.append(ContainerSecurityFinding(
                check_name="host_pid",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.CRITICAL,
                description="Container shares host PID namespace",
                evidence={"pidMode": "host"},
                remediation="Remove hostPID",
                mitre_technique="T1611",
                compliance=["CIS 5.10"],
            ))
        
        if host_config.get("NetworkMode") == "host":
            findings.append(ContainerSecurityFinding(
                check_name="host_network",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.HIGH,
                description="Container shares host network namespace",
                evidence={"networkMode": "host"},
                remediation="Remove hostNetwork",
                mitre_technique="T1611",
                compliance=["CIS 5.10"],
            ))
        
        if host_config.get("IpcMode") == "host":
            findings.append(ContainerSecurityFinding(
                check_name="host_ipc",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.HIGH,
                description="Container shares host IPC namespace",
                evidence={"ipcMode": "host"},
                remediation="Remove hostIPC",
                mitre_technique="T1611",
            ))
        
        # Check sensitive mounts
        mounts = host_config.get("Binds", []) or []
        sensitive_mounts = []
        
        for mount in mounts:
            source = mount.split(":")[0]
            for sensitive in RUNTIME_SECURITY_CHECKS["sensitive_mounts"]["sensitive_paths"]:
                if source == sensitive or source.startswith(sensitive + "/"):
                    sensitive_mounts.append(mount)
                    break
        
        if sensitive_mounts:
            findings.append(ContainerSecurityFinding(
                check_name="sensitive_mounts",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.CRITICAL,
                description="Sensitive host paths mounted",
                evidence={"mounts": sensitive_mounts},
                remediation="Remove sensitive host mounts",
                mitre_technique="T1611",
                compliance=["CIS 5.4"],
            ))
        
        # Check security options
        security_opt = host_config.get("SecurityOpt", []) or []
        
        if "seccomp:unconfined" in security_opt or "seccomp=unconfined" in security_opt:
            findings.append(ContainerSecurityFinding(
                check_name="seccomp_disabled",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.HIGH,
                description="Seccomp profile is disabled",
                evidence={"securityOpt": security_opt},
                remediation="Use default or custom seccomp profile",
                mitre_technique="T1611",
            ))
        
        if "apparmor:unconfined" in security_opt or "apparmor=unconfined" in security_opt:
            findings.append(ContainerSecurityFinding(
                check_name="apparmor_disabled",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.MEDIUM,
                description="AppArmor profile is disabled",
                evidence={"securityOpt": security_opt},
                remediation="Use default or custom AppArmor profile",
                mitre_technique="T1611",
                compliance=["CIS 5.1"],
            ))
        
        # Check for no-new-privileges
        if "no-new-privileges" not in str(security_opt) and "no-new-privileges=true" not in str(security_opt):
            findings.append(ContainerSecurityFinding(
                check_name="no_new_privileges",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.MEDIUM,
                description="Container can acquire new privileges",
                evidence={"securityOpt": security_opt},
                remediation="Add --security-opt=no-new-privileges",
                compliance=["CIS 5.25"],
            ))
        
        # Check read-only filesystem
        if not host_config.get("ReadonlyRootfs"):
            findings.append(ContainerSecurityFinding(
                check_name="writable_rootfs",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.LOW,
                description="Container filesystem is writable",
                evidence={"readonlyRootfs": False},
                remediation="Use --read-only flag",
                compliance=["CIS 5.9", "CIS 5.13"],
            ))
        
        # Check resource limits
        if not host_config.get("Memory") or host_config.get("Memory") == 0:
            findings.append(ContainerSecurityFinding(
                check_name="no_memory_limit",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.LOW,
                description="No memory limit configured",
                evidence={"memory": host_config.get("Memory")},
                remediation="Set memory limit with --memory flag",
                compliance=["CIS 5.11"],
            ))
        
        if not host_config.get("NanoCpus") or host_config.get("NanoCpus") == 0:
            findings.append(ContainerSecurityFinding(
                check_name="no_cpu_limit",
                vulnerability_type=VulnerabilityType.RUNTIME,
                severity=SeverityLevel.LOW,
                description="No CPU limit configured",
                evidence={"cpus": host_config.get("NanoCpus")},
                remediation="Set CPU limit with --cpus flag",
                compliance=["CIS 5.12"],
            ))
        
        return findings
    
    async def check_image_vulnerabilities(
        self,
        image_name: str,
    ) -> List[ContainerSecurityFinding]:
        """
        Scan image for CVE vulnerabilities using available tools.
        
        Args:
            image_name: Container image to scan
            
        Returns:
            List of vulnerability findings
        """
        findings = []
        
        # Try trivy
        trivy_result = await self._run_trivy_scan(image_name)
        if trivy_result:
            for vuln in trivy_result.get("vulnerabilities", []):
                severity_map = {
                    "CRITICAL": SeverityLevel.CRITICAL,
                    "HIGH": SeverityLevel.HIGH,
                    "MEDIUM": SeverityLevel.MEDIUM,
                    "LOW": SeverityLevel.LOW,
                }
                
                findings.append(ContainerSecurityFinding(
                    check_name=f"cve_{vuln.get('id', 'unknown')}",
                    vulnerability_type=VulnerabilityType.CVE,
                    severity=severity_map.get(vuln.get("severity", ""), SeverityLevel.MEDIUM),
                    description=f"{vuln.get('id')}: {vuln.get('title', 'Unknown')}",
                    evidence={
                        "package": vuln.get("package"),
                        "installed_version": vuln.get("installed_version"),
                        "fixed_version": vuln.get("fixed_version"),
                    },
                    remediation=f"Upgrade {vuln.get('package')} to {vuln.get('fixed_version', 'latest')}",
                    mitre_technique="T1525",
                ))
        
        return findings
    
    async def generate_report(
        self,
        container_id: str = None,
        image_name: str = None,
    ) -> ContainerSecurityReport:
        """
        Generate comprehensive security report.
        
        Args:
            container_id: Container ID to analyze
            image_name: Image name to analyze
            
        Returns:
            ContainerSecurityReport
        """
        all_findings = []
        
        if image_name:
            image_findings = await self.analyze_image(image_name)
            all_findings.extend(image_findings)
            
            vuln_findings = await self.check_image_vulnerabilities(image_name)
            all_findings.extend(vuln_findings)
        
        if container_id:
            container_findings = await self.analyze_container(container_id)
            all_findings.extend(container_findings)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(all_findings)
        
        # Check compliance
        compliance_status = self._check_compliance(all_findings)
        
        self.findings = all_findings
        
        return ContainerSecurityReport(
            container_id=container_id or "",
            image=image_name or "",
            findings=all_findings,
            risk_score=risk_score,
            compliance_status=compliance_status,
        )
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    async def _inspect_image(self, image_name: str) -> Optional[Dict[str, Any]]:
        """Inspect Docker image."""
        try:
            rc, out, _ = await run_exec(["docker", "image", "inspect", image_name], timeout=30)
            if rc == 0:
                data = json.loads(out)
                if data:
                    return data[0]
        except Exception:
            pass
        
        return None
    
    async def _inspect_container(self, container_id: str) -> Optional[Dict[str, Any]]:
        """Inspect Docker container."""
        try:
            rc, out, _ = await run_exec(["docker", "container", "inspect", container_id], timeout=30)
            if rc == 0:
                data = json.loads(out)
                if data:
                    return data[0]
        except Exception:
            pass
        
        return None
    
    def _check_env_for_secrets(self, env_vars: List[str]) -> List[Tuple[str, str]]:
        """Check environment variables for secrets."""
        secrets = []
        patterns = IMAGE_SECURITY_CHECKS["hardcoded_secrets"]["patterns"]
        
        for env in env_vars:
            for pattern in patterns:
                if re.search(pattern, env, re.IGNORECASE):
                    # Extract variable name
                    var_name = env.split("=")[0] if "=" in env else env
                    secrets.append((var_name, pattern))
                    break
        
        return secrets
    
    async def _run_trivy_scan(self, image_name: str) -> Optional[Dict[str, Any]]:
        """Run trivy vulnerability scan."""
        try:
            rc, out, _ = await run_exec(["trivy", "image", "--format", "json", image_name], timeout=300)
            if rc == 0:
                return json.loads(out)
        except Exception:
            pass
        
        return None
    
    def _calculate_risk_score(self, findings: List[ContainerSecurityFinding]) -> float:
        """Calculate overall risk score."""
        severity_weights = {
            SeverityLevel.CRITICAL: 10,
            SeverityLevel.HIGH: 7,
            SeverityLevel.MEDIUM: 4,
            SeverityLevel.LOW: 1,
            SeverityLevel.INFO: 0,
        }
        
        if not findings:
            return 0.0
        
        total_weight = sum(severity_weights.get(f.severity, 0) for f in findings)
        max_weight = len(findings) * 10
        
        return min((total_weight / max_weight) * 100 if max_weight > 0 else 0, 100)
    
    def _check_compliance(self, findings: List[ContainerSecurityFinding]) -> Dict[str, bool]:
        """Check compliance status based on findings."""
        compliance = {
            "CIS Docker Benchmark": True,
            "NIST SP 800-190": True,
        }
        
        for finding in findings:
            if finding.severity in [SeverityLevel.CRITICAL, SeverityLevel.HIGH]:
                if "CIS" in str(finding.compliance):
                    compliance["CIS Docker Benchmark"] = False
                compliance["NIST SP 800-190"] = False
        
        return compliance
    
    def get_findings(self) -> List[ContainerSecurityFinding]:
        """Get all findings."""
        return self.findings
    
    def get_check_databases(self) -> Dict[str, Any]:
        """Get all check databases."""
        return {
            "image_checks": IMAGE_SECURITY_CHECKS,
            "runtime_checks": RUNTIME_SECURITY_CHECKS,
            "supply_chain_checks": SUPPLY_CHAIN_CHECKS,
            "compliance_checks": COMPLIANCE_CHECKS,
        }

