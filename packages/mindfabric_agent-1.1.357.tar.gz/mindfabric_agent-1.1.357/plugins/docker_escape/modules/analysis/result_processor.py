"""Result processing and finalization for Docker escape assessment."""
from datetime import datetime
from typing import List
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from plugins.docker_escape.proto import (
    DockerEscapeResult, EscapeStatus, SeverityLevel, EscapeMethod,
    MethodSummary, SeveritySummary, MitreSummary, AttackPath
)
from modules.databases import EXPLOIT_CHAINS, CVE_DATABASE, ESCAPE_METHOD_INFO


class ResultProcessor:
    """Processes and finalizes Docker escape assessment results."""
    
    def __init__(self, start_time: datetime):
        """Initialize result processor."""
        self.start_time = start_time
    
    def finalize(self, result: DockerEscapeResult) -> DockerEscapeResult:
        """Finalize and summarize results."""
        # Calculate timing
        result.metadata.completed_at = datetime.utcnow()
        if self.start_time:
            result.metadata.duration_seconds = (
                result.metadata.completed_at - self.start_time
            ).total_seconds()
        
        result.metadata.methods_tested = len(result.escape_attempts)
        result.metadata.cves_checked = len(CVE_DATABASE)
        
        # Enrich escape attempts with metadata from ESCAPE_METHOD_INFO
        result = self.enrich_escape_attempts(result)
        
        # Generate summaries
        result.method_summary = self._generate_method_summary(result.escape_attempts)
        result.severity_summary = self._generate_severity_summary(result.escape_attempts)
        
        # Identify successful escapes
        result.successful_escapes = [
            r for r in result.escape_attempts 
            if r.status == EscapeStatus.EXPLOITED
        ]
        
        # Set escape flags
        result.escape_confirmed = len(result.successful_escapes) > 0
        result.escape_possible = result.escape_confirmed or any(
            r.status == EscapeStatus.VULNERABLE for r in result.escape_attempts
        )
        
        # Calculate risk score and level
        result.risk_score = self._calculate_risk_score(result)
        result.overall_risk = self._determine_overall_risk(result)
        
        # Generate MITRE summary
        result.mitre_summary = self._generate_mitre_summary(result)
        
        # Generate attack paths
        result.attack_paths = self._generate_attack_paths(result)
        
        # Generate recommended methods
        result.recommended_methods = self._get_recommended_methods(result)
        
        # Generate remediation steps
        result.remediation_steps = self._generate_remediation(result)
        
        result.completed_at = datetime.utcnow()
        
        return result
    
    def _generate_method_summary(self, attempts: List) -> MethodSummary:
        """Generate method execution summary."""
        summary = MethodSummary(total_tested=len(attempts))
        
        for attempt in attempts:
            if attempt.status == EscapeStatus.EXPLOITED:
                summary.exploited += 1
            elif attempt.status == EscapeStatus.VULNERABLE:
                summary.vulnerable += 1
            elif attempt.status == EscapeStatus.POSSIBLE:
                summary.possible += 1
            elif attempt.status in [EscapeStatus.NOT_VULNERABLE, EscapeStatus.NOT_FOUND, EscapeStatus.NOT_CAPABLE]:
                summary.not_vulnerable += 1
            elif attempt.status == EscapeStatus.BLOCKED:
                summary.blocked += 1
            elif attempt.status == EscapeStatus.ERROR:
                summary.errors += 1
            elif attempt.status == EscapeStatus.SKIPPED:
                summary.skipped += 1
        
        return summary
    
    def _generate_severity_summary(self, attempts: List) -> SeveritySummary:
        """Generate severity summary."""
        summary = SeveritySummary()
        
        for attempt in attempts:
            if attempt.status in [EscapeStatus.EXPLOITED, EscapeStatus.VULNERABLE]:
                if attempt.severity == SeverityLevel.CRITICAL:
                    summary.critical += 1
                elif attempt.severity == SeverityLevel.HIGH:
                    summary.high += 1
                elif attempt.severity == SeverityLevel.MEDIUM:
                    summary.medium += 1
                elif attempt.severity == SeverityLevel.LOW:
                    summary.low += 1
                else:
                    summary.info += 1
        
        return summary
    
    def _calculate_risk_score(self, result: DockerEscapeResult) -> float:
        """Calculate overall risk score (0-10)."""
        score = 0.0
        
        # Exploited = highest weight
        score += result.method_summary.exploited * 3.0
        
        # Vulnerable = high weight
        score += result.method_summary.vulnerable * 2.0
        
        # Possible = medium weight
        score += result.method_summary.possible * 1.0
        
        # Add capability risk
        score += result.capability_summary.risk_score * 0.5
        
        # Add CVE risk
        for vuln in result.vulnerabilities:
            score += vuln.cve.cvss_score * 0.1 if vuln.cve else 0
        
        return min(10.0, score)
    
    def _determine_overall_risk(self, result: DockerEscapeResult) -> SeverityLevel:
        """Determine overall risk level."""
        if result.severity_summary.critical > 0 or result.escape_confirmed:
            return SeverityLevel.CRITICAL
        elif result.severity_summary.high > 0:
            return SeverityLevel.HIGH
        elif result.severity_summary.medium > 0:
            return SeverityLevel.MEDIUM
        elif result.severity_summary.low > 0:
            return SeverityLevel.LOW
        return SeverityLevel.INFO
    
    def _generate_mitre_summary(self, result: DockerEscapeResult) -> MitreSummary:
        """Generate MITRE ATT&CK summary."""
        techniques = set()
        
        for attempt in result.escape_attempts:
            if attempt.status in [EscapeStatus.EXPLOITED, EscapeStatus.VULNERABLE]:
                techniques.update(attempt.mitre_techniques)
        
        for vuln in result.vulnerabilities:
            techniques.update(vuln.mitre_techniques)
        
        return MitreSummary(techniques=sorted(techniques))
    
    def _generate_attack_paths(self, result: DockerEscapeResult) -> List[AttackPath]:
        """Generate recommended attack paths."""
        paths = []
        
        for chain in EXPLOIT_CHAINS:
            # Check if chain is viable
            viable = True
            if chain.get("requires_docker_sock") and not result.environment.docker_sock_available:
                viable = False
            if chain.get("requires_privileged") and not result.environment.is_privileged:
                viable = False
            
            required_caps = chain.get("required_capabilities", [])
            if required_caps:
                if not all(cap in result.environment.effective_caps for cap in required_caps):
                    viable = False
            
            if viable:
                paths.append(AttackPath(
                    name=chain["name"],
                    description=" → ".join(chain["step_descriptions"]),
                    steps=chain["step_descriptions"],
                    methods=chain["steps"],
                    success_probability=chain["success_rate"],
                    complexity=chain["complexity"],
                    mitre_techniques=chain.get("mitre", [])
                ))
        
        return paths
    
    def _get_recommended_methods(self, result: DockerEscapeResult) -> List[EscapeMethod]:
        """Get prioritized list of escape methods to try based on ESCAPE_METHOD_INFO."""
        # Sort methods by severity and success rate from ESCAPE_METHOD_INFO
        priority_order = []
        
        # Build priority from ESCAPE_METHOD_INFO metadata
        method_priorities = []
        for method, info in ESCAPE_METHOD_INFO.items():
            if isinstance(info, dict):
                severity_weight = {
                    SeverityLevel.CRITICAL: 4,
                    SeverityLevel.HIGH: 3,
                    SeverityLevel.MEDIUM: 2,
                    SeverityLevel.LOW: 1,
                }.get(info.get("severity", SeverityLevel.MEDIUM), 2)
                
                success_rate = info.get("success_rate", 0.5)
                priority = severity_weight * 10 + success_rate * 10
                method_priorities.append((method, priority))
        
        # Sort by priority descending
        method_priorities.sort(key=lambda x: x[1], reverse=True)
        priority_order = [m[0] for m in method_priorities]
        
        # Fallback to hardcoded order if ESCAPE_METHOD_INFO is empty
        if not priority_order:
            priority_order = [
                EscapeMethod.DOCKER_SOCK,
                EscapeMethod.PRIVILEGED_CONTAINER,
                EscapeMethod.CAP_SYS_ADMIN,
                EscapeMethod.HOST_MOUNT,
                EscapeMethod.PROC_ROOT_CHROOT,
                EscapeMethod.CGROUP_RELEASE_AGENT,
                EscapeMethod.CORE_PATTERN,
                EscapeMethod.NSENTER,
                EscapeMethod.CAP_SYS_PTRACE,
                EscapeMethod.K8S_SERVICE_ACCOUNT,
                EscapeMethod.IMDS_ACCESS,
            ]
        
        recommended = []
        for method in priority_order:
            attempt = next(
                (r for r in result.escape_attempts if r.method == method),
                None
            )
            if attempt and attempt.status in [EscapeStatus.VULNERABLE, EscapeStatus.POSSIBLE]:
                recommended.append(method)
        
        return recommended[:10]
    
    def get_method_metadata(self, method: EscapeMethod) -> dict:
        """Get detailed metadata for an escape method from ESCAPE_METHOD_INFO."""
        return ESCAPE_METHOD_INFO.get(method, {
            "severity": SeverityLevel.MEDIUM,
            "description": f"Container escape method: {method.value}",
            "mitre_techniques": ["T1611"],
            "detection_difficulty": "medium",
        })
    
    def enrich_escape_attempts(self, result: DockerEscapeResult) -> DockerEscapeResult:
        """Enrich escape attempts with metadata from ESCAPE_METHOD_INFO."""
        for attempt in result.escape_attempts:
            metadata = self.get_method_metadata(attempt.method)
            
            # Enrich with detection difficulty if not set
            if not attempt.detection_difficulty:
                attempt.detection_difficulty = metadata.get("detection_difficulty", "medium")
            
            # Add MITRE techniques if not present
            if not attempt.mitre_techniques and metadata.get("mitre_techniques"):
                attempt.mitre_techniques = metadata.get("mitre_techniques", [])
            
            # Add description if not present
            if not attempt.description:
                attempt.description = metadata.get("description", "")
        
        return result
    
    def _generate_remediation(self, result: DockerEscapeResult) -> List[str]:
        """Generate remediation steps."""
        steps = set()
        
        for attempt in result.escape_attempts:
            if attempt.status in [EscapeStatus.EXPLOITED, EscapeStatus.VULNERABLE]:
                if attempt.remediation:
                    steps.add(attempt.remediation)
                
                # Also get remediation from method metadata
                metadata = self.get_method_metadata(attempt.method)
                if metadata.get("remediation"):
                    steps.add(metadata.get("remediation"))
        
        # Add general recommendations based on environment
        if result.environment.is_privileged:
            steps.add("Remove --privileged flag, use specific capabilities instead")
        
        if result.environment.docker_sock_available:
            steps.add("Remove docker.sock mount from container")
        
        if result.environment.is_root:
            steps.add("Run container as non-root user")
        
        if not result.environment.selinux_enforcing:
            steps.add("Enable SELinux enforcing mode")
        
        if not result.environment.seccomp_profile or result.environment.seccomp_profile == 'disabled':
            steps.add("Enable seccomp profile")
        
        if not result.environment.apparmor_profile or result.environment.apparmor_profile == 'unconfined':
            steps.add("Apply AppArmor profile")
        
        if not result.environment.no_new_privs:
            steps.add("Set security-opt no-new-privileges:true")
        
        if result.environment.has_host_pid:
            steps.add("Don't use --pid=host")
        
        if result.environment.has_host_network:
            steps.add("Don't use --network=host")
        
        if result.environment.kubernetes.has_token:
            steps.add("Set automountServiceAccountToken: false")
        
        # Sort by importance
        priority_steps = [
            "Remove --privileged flag",
            "Remove docker.sock mount",
            "Drop CAP_SYS_ADMIN",
            "Run container as non-root",
            "Enable seccomp profile",
        ]
        
        sorted_steps = []
        for priority in priority_steps:
            for step in steps:
                if priority.lower() in step.lower() and step not in sorted_steps:
                    sorted_steps.append(step)
        
        for step in steps:
            if step not in sorted_steps:
                sorted_steps.append(step)
        
        return sorted_steps[:15]
