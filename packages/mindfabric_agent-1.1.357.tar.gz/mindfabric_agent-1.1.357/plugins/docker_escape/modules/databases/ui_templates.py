"""
Docker Escape UI templates.

Centralizes analyst-oriented text for:
- impact (how attacker can abuse it)
- recommendations / remediation_steps (what to change)

Keep plugin-specific content OUT of the global security contract.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple


def get_docker_escape_guidance(
    *,
    method: Optional[str],
    title: Optional[str] = None,
) -> Tuple[Optional[str], List[Dict[str, str]], List[Dict[str, Any]]]:
    """
    Return (impact, recommendations, remediation_steps).
    The goal is to be understandable for a junior security analyst.
    """
    m = (method or "").strip().lower()

    # Socket / runtime API exposure
    if m in ("docker_sock", "containerd_sock", "crio_sock", "podman_sock", "docker_tcp", "docker_api_exposed"):
        return (
            "If an attacker can access the container runtime socket/API, they can start privileged containers, mount the host filesystem, and execute commands on the host (full host takeover).",
            [
                {
                    "title": "Remove runtime socket/API exposure",
                    "description": "Do not mount container runtime sockets into application containers. Avoid exposing Docker API over TCP.",
                    "priority": "high",
                },
                {
                    "title": "Isolate build/ops containers",
                    "description": "If runtime access is required, isolate it in dedicated build agents with strict network policies and short-lived credentials.",
                    "priority": "medium",
                },
            ],
            [
                {
                    "order": 1,
                    "action": "Remove mounts to /var/run/docker.sock (or containerd/crio/podman sockets) from container definitions.",
                    "command": None,
                    "verification": "Container no longer has access to the runtime socket.",
                    "config_change": "compose/k8s manifest update",
                },
                {
                    "order": 2,
                    "action": "If Docker API is exposed over TCP, disable it or require TLS + firewall restrictions.",
                    "command": None,
                    "verification": "Port 2375 is closed; 2376 requires client auth.",
                    "config_change": "daemon.json / systemd service",
                },
            ],
        )

    # Privileged / host namespace sharing
    if m in ("privileged_container", "host_pid", "host_network", "host_ipc", "host_uts"):
        return (
            "Host namespace sharing (or privileged containers) removes isolation. Attackers can read host processes/files, sniff traffic, and potentially escape to the host.",
            [
                {
                    "title": "Avoid host namespace sharing",
                    "description": "Do not run containers with --privileged or with host PID/network/IPC/UTS namespaces unless strictly required.",
                    "priority": "high",
                }
            ],
            [
                {
                    "order": 1,
                    "action": "Remove privileged/host namespace flags from container runtime configuration.",
                    "command": None,
                    "verification": "Container cannot access host namespaces.",
                    "config_change": "runtime/k8s securityContext",
                }
            ],
        )

    # Dangerous Linux capabilities
    if m in ("cap_sys_admin", "cap_sys_ptrace", "cap_net_admin", "cap_net_raw", "cap_sys_module", "cap_sys_rawio"):
        return (
            "High-risk Linux capabilities can enable container breakout (mount/cgroups), process injection, or network manipulation. Attackers can escalate from container to host impact.",
            [
                {
                    "title": "Drop dangerous Linux capabilities",
                    "description": "Remove high-risk capabilities (CAP_SYS_ADMIN/CAP_SYS_PTRACE/CAP_NET_ADMIN/CAP_NET_RAW/CAP_SYS_MODULE/CAP_SYS_RAWIO) from containers.",
                    "priority": "high",
                }
            ],
            [
                {
                    "order": 1,
                    "action": "Set capabilities allowlist; drop all by default and add back only what is needed.",
                    "command": None,
                    "verification": "capsh --print shows capabilities removed.",
                    "config_change": "docker/k8s capabilities",
                }
            ],
        )

    # Cgroup-based escapes
    if m in ("cgroup_release_agent", "cgroup_notify_on_release", "cgroup_escape", "cgroup"):
        return (
            "Cgroup escape primitives can allow a process inside a container to influence host-side execution via cgroup configuration (e.g., release_agent). "
            "If a container is granted powerful capabilities (notably CAP_SYS_ADMIN) and has the right cgroup mounts, an attacker may execute code on the host (container breakout).",
            [
                {
                    "title": "Do not grant CAP_SYS_ADMIN to application containers",
                    "description": "CAP_SYS_ADMIN is effectively root-equivalent for many escape techniques. Remove it unless absolutely required.",
                    "priority": "high",
                },
                {
                    "title": "Harden cgroup mounts and container runtime policies",
                    "description": "Avoid writable host cgroup mounts inside containers; use restrictive seccomp/AppArmor/SELinux and keep containers non-privileged.",
                    "priority": "high",
                },
                {
                    "title": "Prefer rootless / least-privilege runtime configuration",
                    "description": "Use rootless containers where possible and reduce host surface (no host PID/IPC/NET, read-only FS, no_new_privileges).",
                    "priority": "medium",
                },
            ],
            [
                {
                    "order": 1,
                    "action": "Remove CAP_SYS_ADMIN and other dangerous capabilities from container definitions.",
                    "command": None,
                    "verification": "capsh --print shows capabilities removed; escape technique no longer applicable.",
                    "config_change": "docker/k8s capabilities",
                },
                {
                    "order": 2,
                    "action": "Ensure cgroup filesystem is not writable inside application containers.",
                    "command": None,
                    "verification": "Container cannot write to cgroup control files; escape attempt fails safely.",
                    "config_change": "runtime/k8s securityContext + mounts",
                },
            ],
        )

    # Missing security profiles / hardening
    if m in ("seccomp_disabled", "apparmor_disabled", "selinux_disabled", "no_new_privs_disabled", "read_only_rootfs_disabled"):
        return (
            "When runtime hardening is disabled (seccomp/AppArmor/SELinux/no_new_privileges), attackers have a larger syscall surface and fewer containment barriers, making breakout and privilege escalation more likely.",
            [
                {
                    "title": "Enable container security profiles",
                    "description": "Enable/enforce seccomp + AppArmor/SELinux, set no_new_privileges, and prefer read-only root filesystem where possible.",
                    "priority": "high",
                }
            ],
            [
                {
                    "order": 1,
                    "action": "Apply a non-default seccomp profile (Docker default or custom allowlist).",
                    "command": None,
                    "verification": "Seccomp enabled in /proc/self/status and runtime policy.",
                    "config_change": "runtime/k8s seccompProfile",
                },
                {
                    "order": 2,
                    "action": "Apply AppArmor/SELinux confinement (avoid unconfined).",
                    "command": None,
                    "verification": "Container shows confined profile in /proc/self/attr/current.",
                    "config_change": "AppArmor profile / SELinux labels",
                },
            ],
        )

    # CVE-based findings (generic)
    if m.startswith("cve_") or m.startswith("cve-") or "cve" in m:
        return (
            "If this CVE applies to your kernel/runtime, attackers may escape the container or gain elevated privileges on the host. Impact depends on exploitability and patch level.",
            [
                {"title": "Patch kernel/runtime", "description": "Upgrade kernel and container runtime (runc/containerd/docker) to patched versions.", "priority": "high"},
                {"title": "Reduce blast radius", "description": "Enforce least privilege, enable seccomp/AppArmor/SELinux, and keep containers non-privileged.", "priority": "medium"},
            ],
            [
                {"order": 1, "action": "Identify kernel/runtime versions and compare with vendor advisories for the CVE.", "command": None, "verification": "Versions confirmed patched or mitigations applied.", "config_change": "OS/runtime upgrade plan"},
            ],
        )

    # Default
    return (
        None,
        [],
        [],
    )


def should_upgrade_docker_escape_description(description: Optional[str]) -> bool:
    if not isinstance(description, str):
        return True
    s = description.strip()
    if not s:
        return True
    if len(s) < 90:
        return True
    # Status-only / prerequisite-only messages are not helpful as descriptions.
    low = s.lower()
    if "required for" in low and "escape" in low:
        return True
    if low.startswith("cap_") and "required" in low:
        return True
    return False


def build_docker_escape_description(*, method: Optional[str], status: Optional[str], message: Optional[str]) -> str:
    m = (method or "").strip()
    st = (status or "").strip().lower()
    msg = (message or "").strip()

    if (m or "").lower() in ("cgroup_release_agent", "cgroup_notify_on_release"):
        return (
            "Cgroup escape technique detected (release_agent). If a container can write to cgroup control files and has powerful privileges "
            "(typically CAP_SYS_ADMIN), an attacker can configure `release_agent` so the host executes an attacker-controlled program when the cgroup is released. "
            "This is a classic container breakout path that can lead to host code execution. "
            + (f"Observed status={st}. " if st else "")
            + (f"Note: {msg}" if msg else "")
        )

    if m:
        return (
            f"Container escape signal detected for method `{m}`. "
            "Container breakouts are high-impact because they turn an app-level compromise inside a container into host-level access. "
            + (f"Observed status={st}. " if st else "")
            + (f"Note: {msg}" if msg else "")
        )

    return msg or "Potential container escape condition detected."

