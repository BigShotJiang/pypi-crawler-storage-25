"""
Output service for Docker Escape plugin with reproduction steps.
"""

from datetime import datetime
from typing import List, Optional, Dict

from .proto import (
    DockerEscapeResult,
    EscapeAttemptResult,
    EscapeOptions,
    AnalysisMetadata,
    SeveritySummary,
    SeverityLevel,
    ExploitationCommands,
)
from plugins.reproduction import ReproStep
from .modules.databases.escape_databases import DOCKER_ESCAPE_COMMANDS


class OutputService:
    """Build DockerEscapeResult and attach reproduction steps."""

    def __init__(self, plugin):
        self.plugin = plugin

    def _build_commands_for_attempt(self, attempt: EscapeAttemptResult) -> Optional[ExploitationCommands]:
        """Generate exploitation commands based on escape method."""
        method = attempt.method.value if hasattr(attempt.method, 'value') else str(attempt.method)
        cmd_template = DOCKER_ESCAPE_COMMANDS.get(method, DOCKER_ESCAPE_COMMANDS["default"])
        
        # Get container info
        env = getattr(self.plugin, "environment", None)
        container_id = getattr(env, "container_id", None) if env else None
        # container_id can be None in non-container environments; always use a safe string.
        container_name = (container_id or "container")[:12]
        hostname = (getattr(env, "hostname", None) if env else None) or container_name
        
        return ExploitationCommands(
            server=hostname or container_name,
            ip=getattr(env, "container_ip", "172.17.0.x") if env else "172.17.0.x",
            commands=cmd_template.get("commands", []),
            description=cmd_template.get("description", f"Container escape via {method}")
        )

    def _steps_for_attempt(self, attempt: EscapeAttemptResult) -> List[ReproStep]:
        action = attempt.message or attempt.method.value if hasattr(attempt.method, "value") else attempt.method
        evidence = attempt.technical_details or attempt.artifact_path or attempt.artifact_content
        return [
            ReproStep(
                title=f"Escape via {attempt.method.value if hasattr(attempt.method, 'value') else attempt.method}",
                preconditions=["Container access", "Potentially privileged container", "Access to docker/socket if needed"],
                target="container/host",
                action=action,
                payload=None,
                expected_outcome=attempt.impact_description or str(attempt.status),
                evidence=str(evidence) if evidence else None,
                tooling=["docker", "sh", "nsenter"],
                safety="May break container/host; lab/authorized scope only",
                cleanup="Remove created artifacts; stop containers if needed",
            )
        ]

    def _attach_repro(self, attempts: List[EscapeAttemptResult]) -> List[ReproStep]:
        collected: List[ReproStep] = []
        for a in attempts or []:
            # 🔴 Attach commands if not present
            if not getattr(a, "commands", None):
                a.commands = self._build_commands_for_attempt(a)
            
            if getattr(a, "reproduction_steps", None):
                collected.extend(a.reproduction_steps)
            else:
                steps = self._steps_for_attempt(a)
                collected.extend(steps)
        return collected

    def _is_success(self, attempt: EscapeAttemptResult) -> bool:
        status = getattr(attempt, "status", None)
        if hasattr(status, "value"):
            status = status.value
        return status == "success"

    def create_output(
        self,
        options: EscapeOptions,
    ) -> DockerEscapeResult:
        completed = datetime.utcnow()
        start_time = getattr(self.plugin, '_start_time', None) or getattr(self.plugin, 'scan_start', None)
        duration = (completed - start_time).total_seconds() if start_time else 0

        severity_summary = SeveritySummary(
            critical=len([a for a in self.plugin.escape_attempts if a.severity == SeverityLevel.CRITICAL]),
            high=len([a for a in self.plugin.escape_attempts if a.severity == SeverityLevel.HIGH]),
            medium=len([a for a in self.plugin.escape_attempts if a.severity == SeverityLevel.MEDIUM]),
            low=len([a for a in self.plugin.escape_attempts if a.severity == SeverityLevel.LOW]),
            info=len([a for a in self.plugin.escape_attempts if a.severity == SeverityLevel.INFO]),
            total=len(self.plugin.escape_attempts),
        )

        repro_steps = self._attach_repro(self.plugin.escape_attempts)

        metadata = AnalysisMetadata(
            scan_id=getattr(self.plugin, "scan_id", ""),
            started_at=start_time or completed,
            completed_at=completed,
            duration_seconds=duration,
            inside_docker=getattr(self.plugin.environment, "inside_container", False) if hasattr(self.plugin, "environment") else None,
            hostname=getattr(self.plugin.environment, "hostname", None) if hasattr(self.plugin, "environment") else None,
            errors=len(getattr(self.plugin, "errors", []) or []),
            warnings=len(getattr(self.plugin, "warnings", []) or []),
        )

        return DockerEscapeResult(
            metadata=metadata,
            options=options,
            environment=getattr(self.plugin, "environment", None),
            escape_attempts=self.plugin.escape_attempts,
            successful_escapes=[a for a in self.plugin.escape_attempts if self._is_success(a)],
            vulnerabilities=getattr(self.plugin, "vulnerabilities", []),
            method_summary=getattr(self.plugin, "method_summary", None),
            severity_summary=severity_summary,
            capability_summary=getattr(self.plugin, "capability_summary", None),
            mitre_summary=getattr(self.plugin, "mitre_summary", None),
            attack_paths=getattr(self.plugin, "attack_paths", []),
            recommended_methods=getattr(self.plugin, "recommended_methods", []),
            remediation_steps=getattr(self.plugin, "remediation_steps", []),
            errors=getattr(self.plugin, "errors", []),
            warnings=getattr(self.plugin, "warnings", []),
            reproduction_steps=repro_steps or None,
        )
