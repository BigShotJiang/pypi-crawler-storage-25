"""
Schema Discovery Service

Handles database schema discovery for various database types.
"""

import datetime
from typing import Any

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from database_connector import SchemaInfo
from utils.logger import logger

# Database connection libraries
try:
    import psycopg2
    import psycopg2.extras
except ImportError:
    psycopg2 = None

try:
    import mysql.connector
except ImportError:
    mysql = None

try:
    import sqlite3
except ImportError:
    sqlite3 = None

try:
    import pymongo
except ImportError:
    pymongo = None

try:
    import cx_Oracle
except ImportError:
    cx_Oracle = None


class SchemaDiscoveryService:
    """Handle database schema discovery operations."""
    
    def __init__(self, plugin):
        self.plugin = plugin
    
    async def discover_schema(self, database_id: str) -> SchemaInfo:
        """Discover database schema structure"""
        connection = self.plugin.connections[database_id]
        db_connection = self.plugin.active_connections[database_id]
        
        # Implementation depends on database type
        if connection.db_type == "postgresql":
            return await self._discover_postgresql_schema(db_connection, connection.database)
        elif connection.db_type == "mysql":
            return await self._discover_mysql_schema(db_connection, connection.database)
        elif connection.db_type == "sqlite":
            return await self._discover_sqlite_schema(db_connection, connection.database)
        elif connection.db_type == "mongodb":
            return await self._discover_mongodb_schema(db_connection, connection.database)
        elif connection.db_type == "oracle":
            return await self._discover_oracle_schema(db_connection, connection.database)
        elif connection.db_type == "mariadb":
            return await self._discover_mariadb_schema(db_connection, connection.database)
        elif connection.db_type == "mssql":
            return await self._discover_mssql_schema(db_connection, connection.database)
        elif connection.db_type == "clickhouse":
            return await self._discover_clickhouse_schema(db_connection, connection.database)
        
        # Default empty schema
        return SchemaInfo(
            database_name=connection.database,
            tables=[],
            views=[],
            relationships=[],
            indexes=[],
            updated_at=datetime.datetime.utcnow().isoformat()
        )
    
async def _discover_postgresql_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover PostgreSQL schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables
        cursor.execute("""
            SELECT table_name, table_type
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            ORDER BY table_name
        """)
        
        for row in cursor.fetchall():
            table_name, table_type = row
            if table_type == 'BASE TABLE':
                # Get columns for each table
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable, column_default
                    FROM information_schema.columns 
                    WHERE table_name = %s AND table_schema = 'public'
                    ORDER BY ordinal_position
                """, (table_name,))
                
                columns = []
                for col_row in cursor.fetchall():
                    col_name, data_type, is_nullable, default = col_row
                    columns.append({
                        'name': col_name,
                        'type': data_type,
                        'nullable': is_nullable == 'YES',
                        'default': default
                    })
                
                # Get row count and table size
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    row_count = cursor.fetchone()[0]
                    
                    cursor.execute("""
                        SELECT pg_size_pretty(pg_total_relation_size(%s)) as size
                    """, (table_name,))
                    size_result = cursor.fetchone()
                    size_mb = size_result[0] if size_result else None
                except Exception as e:
                    logger.warning(f"Could not get stats for table {table_name}: {e}")
                    row_count = None
                    size_mb = None
                
                # Get preview data (first 5 rows)
                try:
                    cursor.execute(f"SELECT * FROM {table_name} LIMIT 2")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get preview for table {table_name}: {e}")
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'row_count': row_count,
                    'size_mb': size_mb,
                    'preview_data': preview_data
                })
            elif table_type == 'VIEW':
                views.append({'name': table_name})
        
        # Get foreign key relationships
        cursor.execute("""
            SELECT 
                tc.table_name,
                kcu.column_name,
                ccu.table_name AS foreign_table_name,
                ccu.column_name AS foreign_column_name
            FROM information_schema.table_constraints AS tc 
            JOIN information_schema.key_column_usage AS kcu
                ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage AS ccu
                ON ccu.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY'
            ORDER BY tc.table_name, kcu.column_name
        """)
        
        for row in cursor.fetchall():
            table_name, column_name, foreign_table, foreign_column = row
            relationships.append({
                'from_table': table_name,
                'from_column': column_name,
                'to_table': foreign_table,
                'to_column': foreign_column
            })
        
        # Get indexes
        cursor.execute("""
            SELECT 
                schemaname,
                tablename,
                indexname,
                indexdef
            FROM pg_indexes 
            WHERE schemaname = 'public'
            ORDER BY tablename, indexname
        """)
        
        for row in cursor.fetchall():
            schema, table, index_name, index_def = row
            indexes.append({
                'name': index_name,
                'table': table,
                'definition': index_def
            })
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering PostgreSQL schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_mysql_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover MySQL schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT table_name, table_type
            FROM information_schema.tables 
            WHERE table_schema = %s 
            ORDER BY table_name
        """, (database_name,))
        
        for row in cursor.fetchall():
            table_name, table_type = row
            if table_type == 'BASE TABLE':
                # Get columns for each table
                cursor.execute("""
                    SELECT column_name, data_type, is_nullable, column_default, column_key, extra
                    FROM information_schema.columns 
                    WHERE table_name = %s AND table_schema = %s
                    ORDER BY ordinal_position
                """, (table_name, database_name))
                
                columns = []
                for col_row in cursor.fetchall():
                    col_name, data_type, is_nullable, default, key, extra = col_row
                    columns.append({
                        'name': col_name,
                        'type': data_type,
                        'nullable': is_nullable == 'YES',
                        'default': default,
                        'key': key,
                        'extra': extra
                    })
                
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM `{table_name}`")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT * FROM `{table_name}` LIMIT 5")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {table_name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
            elif table_type == 'VIEW':
                views.append({'name': table_name})
        
        # Get foreign key relationships
        cursor.execute("""
            SELECT 
                table_name,
                column_name,
                referenced_table_name,
                referenced_column_name,
                constraint_name
            FROM information_schema.key_column_usage 
            WHERE table_schema = %s 
            AND referenced_table_name IS NOT NULL
            ORDER BY table_name, column_name
        """, (database_name,))
        
        for row in cursor.fetchall():
            table_name, column_name, ref_table, ref_column, constraint_name = row
            relationships.append({
                'from_table': table_name,
                'from_column': column_name,
                'to_table': ref_table,
                'to_column': ref_column,
                'constraint_name': constraint_name
            })
        
        # Get indexes
        cursor.execute("""
            SELECT 
                table_name,
                index_name,
                column_name,
                seq_in_index,
                non_unique
            FROM information_schema.statistics 
            WHERE table_schema = %s
            ORDER BY table_name, index_name, seq_in_index
        """, (database_name,))
        
        current_index = None
        for row in cursor.fetchall():
            table_name, index_name, column_name, seq_in_index, non_unique = row
            
            if current_index is None or current_index['name'] != index_name or current_index['table'] != table_name:
                if current_index is not None:
                    indexes.append(current_index)
                
                current_index = {
                    'name': index_name,
                    'table': table_name,
                    'unique': non_unique == 0,
                    'columns': []
                }
            
            current_index['columns'].append({
                'name': column_name,
                'sequence': seq_in_index
            })
        
        if current_index is not None:
            indexes.append(current_index)
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering MySQL schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_sqlite_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover SQLite schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT name, type 
            FROM sqlite_master 
            WHERE type IN ('table', 'view') 
            ORDER BY name
        """)
        
        for row in cursor.fetchall():
            name, obj_type = row
            if obj_type == 'table':
                # Get columns for each table
                cursor.execute(f"PRAGMA table_info({name})")
                columns = []
                
                for col_row in cursor.fetchall():
                    col_id, col_name, col_type, not_null, default, pk = col_row
                    columns.append({
                        'name': col_name,
                        'type': col_type,
                        'nullable': not_null == 0,
                        'default': default,
                        'primary_key': pk == 1
                    })
                
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM `{name}`")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT * FROM `{name}` LIMIT 5")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': name,
                    'columns': columns,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
            elif obj_type == 'view':
                views.append({'name': name})
        
        # Get foreign key relationships
        for table in tables:
            table_name = table['name']
            cursor.execute(f"PRAGMA foreign_key_list({table_name})")
            
            for fk_row in cursor.fetchall():
                id, seq, table_ref, from_col, to_col, on_update, on_delete, match = fk_row
                relationships.append({
                    'from_table': table_name,
                    'from_column': from_col,
                    'to_table': table_ref,
                    'to_column': to_col,
                    'on_update': on_update,
                    'on_delete': on_delete
                })
        
        # Get indexes
        cursor.execute("""
            SELECT name, tbl_name, sql 
            FROM sqlite_master 
            WHERE type = 'index' AND name NOT LIKE 'sqlite_%'
            ORDER BY tbl_name, name
        """)
        
        for row in cursor.fetchall():
            index_name, table_name, index_sql = row
            indexes.append({
                'name': index_name,
                'table': table_name,
                'definition': index_sql
            })
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering SQLite schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_mongodb_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover MongoDB schema"""
    tables = []  # Collections in MongoDB
    views = []   # Views in MongoDB
    relationships = []  # References between collections
    indexes = []  # Indexes on collections
    
    try:
        # Get database
        db = connection[database_name]
        
        # Get all collections
        collection_names = db.list_collection_names()
        
        for collection_name in collection_names:
            collection = db[collection_name]
            
            # Get collection stats
            stats = db.command("collStats", collection_name)
            
            # Sample documents to understand schema
            sample_docs = list(collection.find().limit(10))
            
            # Analyze field types from sample documents
            field_types = {}
            for doc in sample_docs:
                for field, value in doc.items():
                    if field not in field_types:
                        field_types[field] = set()
                    field_types[field].add(type(value).__name__)
            
            # Convert field types to readable format
            columns = []
            for field, types in field_types.items():
                type_str = " | ".join(sorted(types))
                columns.append({
                    'name': field,
                    'type': type_str,
                    'nullable': True,  # MongoDB fields are always nullable
                    'default': None
                })
            
            # Check if it's a view
            is_view = False
            try:
                # Try to get view definition
                view_info = db.command("listCollections", filter={"name": collection_name, "type": "view"})
                if view_info.get('cursor', {}).get('firstBatch'):
                    is_view = True
            except:
                pass
            
            if is_view:
                views.append({
                    'name': collection_name,
                    'columns': columns
                })
            else:
                # Get preview documents (first 5)
                try:
                    preview_docs = list(collection.find().limit(5))
                    # Convert ObjectId and other MongoDB types to strings
                    preview_data = []
                    for doc in preview_docs:
                        preview_doc = {}
                        for key, value in doc.items():
                            if hasattr(value, '__str__'):
                                preview_doc[key] = str(value)
                            else:
                                preview_doc[key] = value
                        preview_data.append(preview_doc)
                except Exception as e:
                    logger.warning(f"Could not get preview for collection {collection_name}: {e}")
                    preview_data = []
                
                tables.append({
                    'name': collection_name,
                    'columns': columns,
                    'document_count': stats.get('count', 0),
                    'size_bytes': stats.get('size', 0),
                    'preview_data': preview_data
                })
        
        # Get indexes for each collection
        for collection_name in collection_names:
            collection = db[collection_name]
            indexes_info = collection.list_indexes()
            
            for index_info in indexes_info:
                index_name = index_info.get('name', 'unknown')
                index_keys = index_info.get('key', {})
                index_options = index_info.get('options', {})
                
                # Convert index keys to readable format
                key_columns = []
                for key, direction in index_keys.items():
                    key_columns.append({
                        'name': key,
                        'direction': direction
                    })
                
                indexes.append({
                    'name': index_name,
                    'table': collection_name,
                    'columns': key_columns,
                    'unique': index_options.get('unique', False),
                    'sparse': index_options.get('sparse', False)
                })
        
        # MongoDB doesn't have traditional foreign keys, but we can look for references
        # This is a simplified approach - in real scenarios you'd need more sophisticated analysis
        for collection_name in collection_names:
            collection = db[collection_name]
            sample_docs = list(collection.find().limit(100))
            
            for doc in sample_docs:
                for field, value in doc.items():
                    # Look for ObjectId references to other collections
                    if isinstance(value, dict) and '$ref' in value and '$id' in value:
                        relationships.append({
                            'from_table': collection_name,
                            'from_column': field,
                            'to_table': value['$ref'],
                            'to_column': '_id',
                            'type': 'DBRef'
                        })
        
    except Exception as e:
        logger.error(f"Error discovering MongoDB schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_oracle_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover Oracle schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT table_name, 'TABLE' as table_type
            FROM user_tables
            UNION ALL
            SELECT view_name, 'VIEW' as table_type
            FROM user_views
            ORDER BY table_name
        """)
        
        for row in cursor.fetchall():
            table_name, table_type = row
            
            if table_type == 'TABLE':
                # Get columns for each table
                cursor.execute("""
                    SELECT column_name, data_type, data_length, data_precision, data_scale, 
                           nullable, data_default, column_id
                    FROM user_tab_columns 
                    WHERE table_name = :table_name
                    ORDER BY column_id
                """, {'table_name': table_name})
                
                columns = []
                for col_row in cursor.fetchall():
                    col_name, data_type, data_length, precision, scale, nullable, default, col_id = col_row
                    
                    # Build full data type
                    full_type = data_type
                    if precision is not None:
                        if scale is not None and scale > 0:
                            full_type += f"({precision},{scale})"
                        else:
                            full_type += f"({precision})"
                    elif data_length is not None and data_type in ['VARCHAR2', 'CHAR', 'RAW']:
                        full_type += f"({data_length})"
                    
                    columns.append({
                        'name': col_name,
                        'type': full_type,
                        'nullable': nullable == 'Y',
                        'default': default,
                        'position': col_id
                    })
                
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT * FROM {table_name} WHERE ROWNUM <= 5")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {table_name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
            elif table_type == 'VIEW':
                views.append({'name': table_name})
        
        # Get foreign key relationships
        cursor.execute("""
            SELECT 
                a.table_name,
                a.column_name,
                c_pk.table_name AS referenced_table,
                b.column_name AS referenced_column,
                a.constraint_name
            FROM user_cons_columns a
            JOIN user_constraints c ON a.owner = c.owner
                AND a.constraint_name = c.constraint_name
            JOIN user_constraints c_pk ON c.r_owner = c_pk.owner
                AND c.r_constraint_name = c_pk.constraint_name
            JOIN user_cons_columns b ON C_PK.owner = b.owner
                AND C_PK.constraint_name = b.constraint_name
                AND b.position = a.position
            WHERE c.constraint_type = 'R'
            ORDER BY a.table_name, a.column_name
        """)
        
        for row in cursor.fetchall():
            table_name, column_name, ref_table, ref_column, constraint_name = row
            relationships.append({
                'from_table': table_name,
                'from_column': column_name,
                'to_table': ref_table,
                'to_column': ref_column,
                'constraint_name': constraint_name
            })
        
        # Get indexes
        cursor.execute("""
            SELECT 
                i.index_name,
                i.table_name,
                i.uniqueness,
                ic.column_name,
                ic.column_position
            FROM user_indexes i
            JOIN user_ind_columns ic ON i.index_name = ic.index_name
            WHERE i.index_type = 'NORMAL'
            ORDER BY i.table_name, i.index_name, ic.column_position
        """)
        
        current_index = None
        for row in cursor.fetchall():
            index_name, table_name, uniqueness, column_name, position = row
            
            if (current_index is None or 
                current_index['name'] != index_name or 
                current_index['table'] != table_name):
                
                if current_index is not None:
                    indexes.append(current_index)
                
                current_index = {
                    'name': index_name,
                    'table': table_name,
                    'unique': uniqueness == 'UNIQUE',
                    'columns': []
                }
            
            current_index['columns'].append({
                'name': column_name,
                'position': position
            })
        
        if current_index is not None:
            indexes.append(current_index)
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering Oracle schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )
        
async def _discover_mariadb_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover MariaDB schema (similar to MySQL)"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT table_name, table_type
            FROM information_schema.tables
            WHERE table_schema = %s
            ORDER BY table_name
        """, (database_name,))
        
        for row in cursor.fetchall():
            table_name, table_type = row
            
            if table_type == 'BASE TABLE':
                # Get columns for each table
                cursor.execute("""
                    SELECT column_name, data_type, character_maximum_length, 
                           numeric_precision, numeric_scale, is_nullable, column_default, ordinal_position
                    FROM information_schema.columns
                    WHERE table_schema = %s AND table_name = %s
                    ORDER BY ordinal_position
                """, (database_name, table_name))
                
                columns = []
                for col_row in cursor.fetchall():
                    col_name, data_type, char_max_len, num_precision, num_scale, nullable, default, position = col_row
                    
                    # Build full data type
                    full_type = data_type
                    if char_max_len:
                        full_type += f"({char_max_len})"
                    elif num_precision:
                        if num_scale:
                            full_type += f"({num_precision},{num_scale})"
                        else:
                            full_type += f"({num_precision})"
                    
                    columns.append({
                        'name': col_name,
                        'type': full_type,
                        'nullable': nullable == 'YES',
                        'default': default,
                        'position': position
                    })
                
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM `{table_name}`")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT * FROM `{table_name}` LIMIT 5")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {table_name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
            elif table_type == 'VIEW':
                views.append({'name': table_name})
        
        # Get foreign key relationships
        cursor.execute("""
            SELECT 
                kcu.table_name,
                kcu.column_name,
                kcu.referenced_table_name,
                kcu.referenced_column_name,
                kcu.constraint_name
            FROM information_schema.key_column_usage kcu
            JOIN information_schema.referential_constraints rc 
                ON kcu.constraint_name = rc.constraint_name
                AND kcu.table_schema = rc.constraint_schema
            WHERE kcu.table_schema = %s
                AND kcu.referenced_table_name IS NOT NULL
            ORDER BY kcu.table_name, kcu.column_name
        """, (database_name,))
        
        for row in cursor.fetchall():
            table_name, column_name, ref_table, ref_column, constraint_name = row
            relationships.append({
                'from_table': table_name,
                'from_column': column_name,
                'to_table': ref_table,
                'to_column': ref_column,
                'constraint_name': constraint_name
            })
        
        # Get indexes
        cursor.execute("""
            SELECT 
                s.index_name,
                s.table_name,
                s.non_unique,
                s.column_name,
                s.seq_in_index
            FROM information_schema.statistics s
            WHERE s.table_schema = %s
            ORDER BY s.table_name, s.index_name, s.seq_in_index
        """, (database_name,))
        
        current_index = None
        for row in cursor.fetchall():
            index_name, table_name, non_unique, column_name, position = row
            
            if (current_index is None or 
                current_index['name'] != index_name or 
                current_index['table'] != table_name):
                
                if current_index is not None:
                    indexes.append(current_index)
                
                current_index = {
                    'name': index_name,
                    'table': table_name,
                    'unique': non_unique == 0,
                    'columns': []
                }
            
            current_index['columns'].append({
                'name': column_name,
                'position': position
            })
        
        if current_index is not None:
            indexes.append(current_index)
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering MariaDB schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_mssql_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover Microsoft SQL Server schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT name, type_desc
            FROM sys.objects
            WHERE type IN ('U', 'V') AND schema_id = SCHEMA_ID('dbo')
            ORDER BY name
        """)
        
        for row in cursor.fetchall():
            table_name, type_desc = row
            
            if type_desc == 'USER_TABLE':
                # Get columns for each table
                cursor.execute("""
                    SELECT 
                        c.name,
                        t.name as data_type,
                        c.max_length,
                        c.precision,
                        c.scale,
                        c.is_nullable,
                        dc.definition as default_value,
                        c.column_id
                    FROM sys.columns c
                    JOIN sys.types t ON c.user_type_id = t.user_type_id
                    LEFT JOIN sys.default_constraints dc ON c.default_object_id = dc.object_id
                    WHERE c.object_id = OBJECT_ID(%s)
                    ORDER BY c.column_id
                """, (f'dbo.{table_name}',))
                
                columns = []
                for col_row in cursor.fetchall():
                    col_name, data_type, max_length, precision, scale, nullable, default, col_id = col_row
                    
                    # Build full data type
                    full_type = data_type
                    if data_type in ['varchar', 'nvarchar', 'char', 'nchar', 'binary', 'varbinary']:
                        if max_length == -1:
                            full_type += '(MAX)'
                        else:
                            full_type += f'({max_length})'
                    elif data_type in ['decimal', 'numeric']:
                        full_type += f'({precision},{scale})'
                    elif data_type in ['float', 'real']:
                        if precision:
                            full_type += f'({precision})'
                    
                    columns.append({
                        'name': col_name,
                        'type': full_type,
                        'nullable': nullable == 1,
                        'default': default,
                        'position': col_id
                    })
                
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM [{table_name}]")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT TOP 5 * FROM [{table_name}]")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {table_name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
            elif type_desc == 'VIEW':
                views.append({'name': table_name})
        
        # Get foreign key relationships
        cursor.execute("""
            SELECT 
                fk.name as constraint_name,
                tp.name as parent_table,
                cp.name as parent_column,
                tr.name as referenced_table,
                cr.name as referenced_column
            FROM sys.foreign_keys fk
            INNER JOIN sys.tables tp ON fk.parent_object_id = tp.object_id
            INNER JOIN sys.tables tr ON fk.referenced_object_id = tr.object_id
            INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
            INNER JOIN sys.columns cp ON fkc.parent_column_id = cp.column_id AND fkc.parent_object_id = cp.object_id
            INNER JOIN sys.columns cr ON fkc.referenced_column_id = cr.column_id AND fkc.referenced_object_id = cr.object_id
            ORDER BY tp.name, cp.name
        """)
        
        for row in cursor.fetchall():
            constraint_name, parent_table, parent_column, ref_table, ref_column = row
            relationships.append({
                'from_table': parent_table,
                'from_column': parent_column,
                'to_table': ref_table,
                'to_column': ref_column,
                'constraint_name': constraint_name
            })
        
        # Get indexes
        cursor.execute("""
            SELECT 
                i.name as index_name,
                t.name as table_name,
                i.is_unique,
                c.name as column_name,
                ic.key_ordinal
            FROM sys.indexes i
            INNER JOIN sys.tables t ON i.object_id = t.object_id
            INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
            INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
            WHERE i.type > 0  -- Exclude heaps
            ORDER BY t.name, i.name, ic.key_ordinal
        """)
        
        current_index = None
        for row in cursor.fetchall():
            index_name, table_name, is_unique, column_name, position = row
            
            if (current_index is None or 
                current_index['name'] != index_name or 
                current_index['table'] != table_name):
                
                if current_index is not None:
                    indexes.append(current_index)
                
                current_index = {
                    'name': index_name,
                    'table': table_name,
                    'unique': is_unique == 1,
                    'columns': []
                }
            
            current_index['columns'].append({
                'name': column_name,
                'position': position
            })
        
        if current_index is not None:
            indexes.append(current_index)
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering MSSQL schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )

async def _discover_clickhouse_schema(self, connection, database_name: str) -> SchemaInfo:
    """Discover ClickHouse schema"""
    tables = []
    views = []
    relationships = []
    indexes = []
    
    try:
        cursor = connection.cursor()
        
        # Get tables and views
        cursor.execute("""
            SELECT name, engine
            FROM system.tables
            WHERE database = %s
            ORDER BY name
        """, (database_name,))
        
        for row in cursor.fetchall():
            table_name, engine = row
            
            # Get columns for each table
            cursor.execute("""
                SELECT name, type, default_kind, default_expression, comment
                FROM system.columns
                WHERE database = %s AND table = %s
                ORDER BY position
            """, (database_name, table_name))
            
            columns = []
            for col_row in cursor.fetchall():
                col_name, col_type, default_kind, default_expr, comment = col_row
                
                columns.append({
                    'name': col_name,
                    'type': col_type,
                    'nullable': 'Nullable' in col_type,
                    'default': default_expr if default_kind else None,
                    'comment': comment
                })
            
            # Check if it's a view
            if engine.startswith('View') or engine.startswith('MaterializedView'):
                views.append({
                    'name': table_name,
                    'columns': columns,
                    'engine': engine
                })
            else:
                # Get row count and preview data
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    row_count = cursor.fetchone()[0]
                    
                    # Get preview data (first 5 rows)
                    cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
                    preview_rows = cursor.fetchall()
                    
                    # Convert preview rows to dictionaries
                    preview_data = []
                    for row in preview_rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]['name']] = str(value) if value is not None else None
                        preview_data.append(row_dict)
                except Exception as e:
                    logger.warning(f"Could not get stats/preview for table {table_name}: {e}")
                    row_count = None
                    preview_data = []
                
                tables.append({
                    'name': table_name,
                    'columns': columns,
                    'engine': engine,
                    'row_count': row_count,
                    'preview_data': preview_data
                })
        
        # ClickHouse doesn't have traditional foreign keys, but we can look for references
        # This is a simplified approach - ClickHouse relationships are usually logical
        for table in tables:
            table_name = table['name']
            cursor.execute("""
                SELECT name, type
                FROM system.columns
                WHERE database = %s AND table = %s
                AND type LIKE '%%UUID%%'
            """, (database_name, table_name))
            
            for col_row in cursor.fetchall():
                col_name, col_type = col_row
                # Look for potential foreign key patterns
                if 'id' in col_name.lower() and col_name.lower() != 'id':
                    relationships.append({
                        'from_table': table_name,
                        'from_column': col_name,
                        'to_table': 'unknown',  # Would need more sophisticated analysis
                        'to_column': 'id',
                        'type': 'logical_reference'
                    })
        
        # Get indexes (ClickHouse has sparse indexes)
        cursor.execute("""
            SELECT name, table, type, expr
            FROM system.data_skipping_indices
            WHERE database = %s
            ORDER BY table, name
        """, (database_name,))
        
        for row in cursor.fetchall():
            index_name, table_name, index_type, expression = row
            indexes.append({
                'name': index_name,
                'table': table_name,
                'type': index_type,
                'expression': expression,
                'unique': False  # ClickHouse sparse indexes are not unique
            })
        
        cursor.close()
        
    except Exception as e:
        logger.error(f"Error discovering ClickHouse schema: {e}")
    
    return SchemaInfo(
        database_name=database_name,
        tables=tables,
        views=views,
        relationships=relationships,
        indexes=indexes,
        updated_at=datetime.datetime.utcnow().isoformat()
    )


