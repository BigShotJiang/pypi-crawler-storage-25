"""
Query Execution Service

Handles SQL query execution and validation.
"""

from typing import Any, Dict, List

# Database connection libraries
try:
    import psycopg2
    import psycopg2.extras
except ImportError:
    psycopg2 = None

try:
    import mysql.connector
except ImportError:
    mysql = None

try:
    import sqlite3
except ImportError:
    sqlite3 = None

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from database_connector import DatabaseConnection
from ..utils.database_connector_utils import is_safe_query
from utils.logger import logger


class QueryExecutionService:
    """Handle SQL query execution."""
    
    def __init__(self, plugin):
        self.plugin = plugin
    
    async def execute_query(self, database_id: str, sql_query: str) -> List[Dict[str, Any]]:
        """Execute SQL query and return results"""
        connection = self.plugin.connections[database_id]
        db_connection = self.plugin.active_connections[database_id]
        
        try:
            if connection.db_type == "postgresql":
                cursor = db_connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cursor.execute(sql_query)
                results = cursor.fetchall()
                cursor.close()
                return [dict(row) for row in results]
            
            elif connection.db_type == "mysql":
                cursor = db_connection.cursor(dictionary=True)
                cursor.execute(sql_query)
                results = cursor.fetchall()
                cursor.close()
                return results
            
            elif connection.db_type == "sqlite":
                cursor = db_connection.cursor()
                cursor.execute(sql_query)
                columns = [description[0] for description in cursor.description]
                results = cursor.fetchall()
                cursor.close()
                return [dict(zip(columns, row)) for row in results]
            
            return []
            
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            return []

