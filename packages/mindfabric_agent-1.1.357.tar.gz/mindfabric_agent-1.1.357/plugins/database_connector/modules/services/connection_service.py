"""
Connection Service

Handles database connection establishment and management.
"""

import datetime
from typing import Any, Dict, Optional

# Database connection libraries (will need to be installed)
try:
    import psycopg2
    import psycopg2.extras
except ImportError:
    psycopg2 = None

try:
    import mysql.connector
except ImportError:
    mysql = None

try:
    import sqlite3
except ImportError:
    sqlite3 = None

try:
    import pymongo
except ImportError:
    pymongo = None

try:
    import cx_Oracle
except ImportError:
    cx_Oracle = None

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from database_connector import DatabaseConnection
from ..utils.database_connector_utils import build_connection_string, get_default_port
from utils.logger import logger


class ConnectionService:
    """Handle database connection operations."""
    
    def __init__(self, plugin):
        self.plugin = plugin
    
    async def establish_connection(self, connection: DatabaseConnection) -> Optional[Any]:
        """Establish actual database connection"""
        try:
            if connection.db_type == "postgresql" and psycopg2:
                conn = psycopg2.connect(
                    host=connection.host,
                    port=connection.port,
                    database=connection.database,
                    user=connection.username,
                    password=connection.password
                )
                return conn
            elif connection.db_type == "mysql" and mysql:
                conn = mysql.connector.connect(
                    host=connection.host,
                    port=connection.port,
                    database=connection.database,
                    user=connection.username,
                    password=connection.password
                )
                return conn
            elif connection.db_type == "sqlite" and sqlite3:
                conn = sqlite3.connect(connection.database)
                return conn
            # Add other database types...
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to establish connection: {e}")
            return None
    
    async def close_connection(self, database_id: str):
        """Close database connection"""
        if database_id in self.plugin.active_connections:
            try:
                self.plugin.active_connections[database_id].close()
                del self.plugin.active_connections[database_id]
            except Exception as e:
                logger.error(f"Error closing connection: {e}")

