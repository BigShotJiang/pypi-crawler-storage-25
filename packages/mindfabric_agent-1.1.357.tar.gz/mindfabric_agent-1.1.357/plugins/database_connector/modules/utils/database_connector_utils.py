"""
Database Connector Utilities

Contains utility functions for database operations.
"""

import re
from typing import Dict, Any

from ..databases.database_connector_databases import DEFAULT_PORTS, DANGEROUS_SQL_PATTERNS


def get_default_port(db_type: str) -> int:
    """Get default port for database type"""
    return DEFAULT_PORTS.get(db_type, 5432)


def build_connection_string(config: Dict[str, Any]) -> str:
    """Build connection string based on database type"""
    db_type = config['db_type']
    
    if db_type == "postgresql":
        return f"postgresql://{config['username']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
    elif db_type == "mysql":
        return f"mysql://{config['username']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
    elif db_type == "sqlite":
        return f"sqlite:///{config['database']}"
    elif db_type == "mongodb":
        return f"mongodb://{config['username']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
    elif db_type == "oracle":
        return f"oracle://{config['username']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
    
    return ""


def is_safe_query(sql_query: str) -> bool:
    """
    Validate SQL query for security
    
    Only allows SELECT statements and blocks dangerous operations.
    """
    # Only allow SELECT statements
    if not re.match(r'^\s*SELECT\b', sql_query.strip(), re.IGNORECASE):
        return False
    
    # Check for dangerous patterns
    for pattern in DANGEROUS_SQL_PATTERNS:
        if re.search(pattern, sql_query, re.IGNORECASE):
            return False
    
    return True

