"""
Database Connector Databases

Contains static data: default ports and connection configuration.
"""

from typing import Dict


# Default ports for different database types
DEFAULT_PORTS: Dict[str, int] = {
    "postgresql": 5432,
    "mysql": 3306,
    "sqlite": 0,  # No port for SQLite
    "mongodb": 27017,
    "oracle": 1521,
    "mariadb": 3306,
    "mssql": 1433,
    "clickhouse": 8123,
}


# Dangerous SQL patterns that should be blocked
DANGEROUS_SQL_PATTERNS = [
    r'\bDROP\b',
    r'\bDELETE\b',
    r'\bUPDATE\b',
    r'\bINSERT\b',
    r'\bCREATE\b',
    r'\bALTER\b',
    r'\bTRUNCATE\b',
    r'\bEXEC\b',
    r'--',
    r'/\*',
    r'\*/'
]

