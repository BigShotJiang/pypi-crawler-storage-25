"""
Database Connector Databases

Contains static data: default ports, connection string templates.
"""

