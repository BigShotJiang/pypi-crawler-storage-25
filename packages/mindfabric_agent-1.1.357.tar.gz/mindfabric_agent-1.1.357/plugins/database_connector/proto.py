"""
Protocol definitions for Database Connector Plugin

Defines the standard interfaces and data structures used by the database connector plugin
for communication with backend systems and LLM services.
"""

from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass
from enum import Enum

class DatabaseType(Enum):
    """Supported database types"""
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    SQLITE = "sqlite"
    MONGODB = "mongodb"
    ORACLE = "oracle"
    MARIADB = "mariadb"
    MSSQL = "mssql"

class ConnectionStatus(Enum):
    """Database connection statuses"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    FAILED = "failed"
    CONNECTING = "connecting"

class QueryStatus(Enum):
    """Query execution statuses"""
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"

@dataclass
class DatabaseConnectionConfig:
    """Configuration for database connection"""
    name: str
    db_type: DatabaseType
    host: str
    port: int
    database: str
    username: str
    password: str
    ssl_enabled: bool = False
    connection_timeout: int = 30
    query_timeout: int = 300
    max_pool_size: int = 10

@dataclass
class TableInfo:
    """Information about a database table"""
    name: str
    schema: str
    columns: List[Dict[str, Any]]
    row_count: Optional[int] = None
    size_mb: Optional[float] = None
    description: Optional[str] = None

@dataclass
class ColumnInfo:
    """Information about a table column"""
    name: str
    data_type: str
    is_nullable: bool
    is_primary_key: bool = False
    is_foreign_key: bool = False
    default_value: Optional[str] = None
    max_length: Optional[int] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    description: Optional[str] = None

@dataclass
class RelationshipInfo:
    """Information about table relationships"""
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    relationship_type: str  # "one_to_one", "one_to_many", "many_to_one", "many_to_many"
    constraint_name: Optional[str] = None

@dataclass
class IndexInfo:
    """Information about database indexes"""
    name: str
    table: str
    columns: List[str]
    is_unique: bool = False
    is_primary: bool = False
    index_type: Optional[str] = None

@dataclass
class ViewInfo:
    """Information about database views"""
    name: str
    schema: str
    definition: str
    description: Optional[str] = None

@dataclass
class DatabaseSchema:
    """Complete database schema information"""
    database_name: str
    schema_name: str
    tables: List[TableInfo]
    views: List[ViewInfo]
    relationships: List[RelationshipInfo]
    indexes: List[IndexInfo]
    functions: List[Dict[str, Any]]
    procedures: List[Dict[str, Any]]
    updated_at: str

@dataclass
class NaturalLanguageQuery:
    """Natural language query request"""
    user_request: str
    database_id: str
    context: Optional[Dict[str, Any]] = None
    max_rows: int = 1000
    timeout: int = 300

@dataclass
class SQLQuery:
    """Generated SQL query"""
    sql: str
    dialect: str
    estimated_rows: Optional[int] = None
    estimated_time: Optional[float] = None
    confidence_score: Optional[float] = None
    explanation: Optional[str] = None

@dataclass
class QueryExecution:
    """Query execution metadata"""
    query_id: str
    sql_query: str
    user_request: str
    database_id: str
    status: QueryStatus
    execution_time: float
    rows_returned: int
    bytes_processed: Optional[int] = None
    cache_hit: bool = False
    error_message: Optional[str] = None
    timestamp: str

@dataclass
class QueryResult:
    """Query execution result"""
    execution: QueryExecution
    data: List[Dict[str, Any]]
    columns: List[ColumnInfo]
    metadata: Dict[str, Any]

@dataclass
class BackendSQLRequest:
    """Request from Backend with generated SQL"""
    sql_query: str
    database_id: str
    query_context: Optional[Dict[str, Any]] = None
    user_request: str = ""
    timeout: int = 300

# Protocol interfaces for external communication

class DatabaseConnectorProtocol:
    """Protocol for database connector operations"""
    
    async def connect_database(self, config: DatabaseConnectionConfig) -> Dict[str, Any]:
        """Establish database connection"""
        pass
    
    async def disconnect_database(self, database_id: str) -> Dict[str, Any]:
        """Close database connection"""
        pass
    
    async def discover_schema(self, database_id: str) -> DatabaseSchema:
        """Discover and return database schema"""
        pass
    
    async def execute_backend_query(self, request: BackendSQLRequest) -> QueryResult:
        """Execute SQL query from backend"""
        pass
    
    async def execute_sql(self, database_id: str, sql: str) -> QueryResult:
        """Execute raw SQL query"""
        pass
    
    async def get_connection_status(self, database_id: Optional[str] = None) -> Dict[str, Any]:
        """Get connection status"""
        pass



class BackendAPIProtocol:
    """Protocol for backend API communication"""
    
    async def register_database_connection(self, connection_info: Dict[str, Any]) -> str:
        """Register new database connection with backend"""
        pass
    
    async def update_schema_cache(self, database_id: str, schema: DatabaseSchema) -> bool:
        """Update cached schema in backend"""
        pass
    
    async def log_query_execution(self, execution: QueryExecution) -> bool:
        """Log query execution for analytics"""
        pass
    
    async def get_user_preferences(self, user_id: str) -> Dict[str, Any]:
        """Get user query preferences and settings"""
        pass

# Error types

class DatabaseConnectorError(Exception):
    """Base exception for database connector"""
    pass

class ConnectionError(DatabaseConnectorError):
    """Database connection error"""
    pass

class QueryError(DatabaseConnectorError):
    """Query execution error"""
    pass

class SchemaDiscoveryError(DatabaseConnectorError):
    """Schema discovery error"""
    pass

class LLMServiceError(DatabaseConnectorError):
    """LLM service error"""
    pass

class ValidationError(DatabaseConnectorError):
    """Data validation error"""
    pass

# Constants and configurations

DEFAULT_PORTS = {
    DatabaseType.POSTGRESQL: 5432,
    DatabaseType.MYSQL: 3306,
    DatabaseType.MARIADB: 3306,
    DatabaseType.MSSQL: 1433,
    DatabaseType.ORACLE: 1521,
    DatabaseType.MONGODB: 27017,
    DatabaseType.SQLITE: 0  # No port for SQLite
}

SUPPORTED_SQL_DIALECTS = [
    "postgresql",
    "mysql", 
    "sqlite",
    "oracle",
    "mssql",
    "mariadb"
]

MAX_QUERY_TIMEOUT = 3600  # 1 hour
MAX_RESULT_ROWS = 100000
MAX_SCHEMA_CACHE_AGE = 86400  # 24 hours

# Validation helpers

def validate_connection_config(config: DatabaseConnectionConfig) -> List[str]:
    """Validate database connection configuration"""
    errors = []
    
    if not config.name:
        errors.append("Connection name is required")
    
    if not config.database:
        errors.append("Database name is required")
    
    if config.db_type != DatabaseType.SQLITE:
        if not config.host:
            errors.append("Host is required for non-SQLite databases")
        if not config.username:
            errors.append("Username is required for non-SQLite databases")
    
    if config.port <= 0 or config.port > 65535:
        errors.append("Port must be between 1 and 65535")
    
    if config.connection_timeout <= 0:
        errors.append("Connection timeout must be positive")
    
    if config.query_timeout <= 0:
        errors.append("Query timeout must be positive")
    
    return errors

def sanitize_sql_query(sql: str) -> str:
    """Basic SQL sanitization"""
    # Remove dangerous keywords and patterns
    dangerous_patterns = [
        r'\bDROP\b', r'\bDELETE\b', r'\bUPDATE\b', r'\bINSERT\b',
        r'\bCREATE\b', r'\bALTER\b', r'\bTRUNCATE\b', r'\bEXEC\b',
        r'--', r'/\*', r'\*/', r';.*$'
    ]
    
    import re
    cleaned_sql = sql.strip()
    
    for pattern in dangerous_patterns:
        cleaned_sql = re.sub(pattern, '', cleaned_sql, flags=re.IGNORECASE)
    
    return cleaned_sql

def is_safe_query(sql: str) -> bool:
    """Check if SQL query is safe to execute"""
    import re
    
    # Only allow SELECT statements
    if not re.match(r'^\s*SELECT\b', sql.strip(), re.IGNORECASE):
        return False
    
    # Check for dangerous patterns
    dangerous_patterns = [
        r'\bDROP\b', r'\bDELETE\b', r'\bUPDATE\b', r'\bINSERT\b',
        r'\bCREATE\b', r'\bALTER\b', r'\bTRUNCATE\b', r'\bEXEC\b',
        r'--', r'/\*', r'\*/'
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, sql, re.IGNORECASE):
            return False
    
    return True
