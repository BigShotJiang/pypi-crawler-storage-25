import asyncio
import json
import datetime
import hashlib
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, asdict
from plugins.base_plugin import BasePlugin
from utils.logger import logger

# Database connection libraries (will need to be installed)
try:
    import psycopg2
    import psycopg2.extras
except ImportError:
    psycopg2 = None

try:
    import mysql.connector
except ImportError:
    mysql = None

try:
    import sqlite3
except ImportError:
    sqlite3 = None

try:
    import pymongo
except ImportError:
    pymongo = None

try:
    import cx_Oracle
except ImportError:
    cx_Oracle = None

@dataclass
class DatabaseConnection:
    """Represents to databhowe"""
    id: str
    name: str
    db_type: str
    host: str
    port: int
    database: str
    username: str
    password: str
    status: str = "inactive"
    last_connected: Optional[str] = None
    schema_info: Optional[Dict] = None
    connection_string: Optional[str] = None

@dataclass
class QueryResult:
    """Result executing SQL request"""
    query_id: str
    sql_query: str
    user_request: str
    database_id: str
    status: str
    execution_time: float
    rows_returned: int
    data: List[Dict[str, Any]]
    error: Optional[str] = None
    timestamp: Optional[str] = None

@dataclass
class SchemaInfo:
    """Information about structure databases"""
    database_name: str
    tables: List[Dict[str, Any]]
    views: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    indexes: List[Dict[str, Any]]
    updated_at: str

# Global connection storage (shared across all plugin instances)
_global_connections: Dict[str, DatabaseConnection] = {}
_global_active_connections: Dict[str, Any] = {}  # Active database connections
_global_schema_cache: Dict[str, SchemaInfo] = {}

class DatabaseConnectorPlugin(BasePlugin):
    """
    Database Connector Plugin for Database Operations
    
    Provides comprehensive database connectivity and management:
    - Multi-database support (PostgreSQL, MySQL, SQLite, MongoDB, Oracle)
    - Schema discovery and caching
    - Raw SQL query execution
    - Connection management and pooling
    - Result formatting and validation
    - Security and query validation
    """
    VERSION = "1.0.0"
    
    def __init__(self, ws, command_id, options):
        super().__init__(ws, command_id, options)
        # Use global connection storage
        self.connections = _global_connections
        self.active_connections = _global_active_connections
        self.schema_cache = _global_schema_cache
        
        # Initialize services
        from .modules.services import ConnectionService, QueryExecutionService, SchemaDiscoveryService
        from .modules.utils.database_connector_utils import build_connection_string, get_default_port, is_safe_query
        
        self.connection_service = ConnectionService(self)
        self.query_service = QueryExecutionService(self)
        self.schema_service = SchemaDiscoveryService(self)
        self._build_connection_string = build_connection_string
        self._get_default_port = get_default_port
        self._is_safe_query = is_safe_query
        
    async def run(self):
        """Main plugin execution method"""
        # Parse command from options to determine action
        command = self.options.get("command", "")
        
        if "connect" in command:
            return await self.hook_connect(**self.options)
        elif "execute_sql" in command:
            return await self.hook_execute_sql(**self.options)
        elif "schema" in command:
            return await self.hook_schema(**self.options)
        elif "disconnect" in command:
            return await self.hook_disconnect(**self.options)
        else:
            return await self.hook_status()
    
    async def hook_connect(self, connection_config: Dict[str, Any], connection_id: str = None, **kwargs):
        """
        Establish database connection and discover schema
        
        Args:
            connection_config: Database connection parameters
                - name: Connection name
                - db_type: Database type (postgresql, mysql, sqlite, mongodb, oracle)
                - host: Database host
                - port: Database port
                - database: Database name
                - username: Username
                - password: Password
            connection_id: Database connection ID from backend (optional)
                
        Returns:
            dict: Connection status and schema information
            
        Examples:
            plugin:database_connector connect connection_config='{"name":"prod_analytics","db_type":"postgresql","host":"localhost","port":5432,"database":"analytics","username":"analyst","password":"secret"}'
            plugin:database_connector connect connection_config='{"name":"local_dev","db_type":"sqlite","database":"/path/to/db.sqlite"}'
        """
        try:
            # Use provided connection_id or generate one
            if connection_id:
                # Remove quotes if present (backend sometimes sends connection_id in quotes)
                conn_id = connection_id.strip('"') if isinstance(connection_id, str) else connection_id
            else:
                conn_id = hashlib.md5(f"{connection_config['name']}_{connection_config['host']}_{connection_config['database']}".encode()).hexdigest()[:8]
            
            # Create connection object
                connection = DatabaseConnection(
                id=conn_id,
                name=connection_config['name'],
                db_type=connection_config['db_type'],
                host=connection_config.get('host', 'localhost'),
                port=connection_config.get('port', self._get_default_port(connection_config['db_type'])),
                database=connection_config['database'],
                username=connection_config.get('username', ''),
                password=connection_config.get('password', ''),
                connection_string=self._build_connection_string(connection_config)
            )
            
            # Test connection
            db_connection = await self.connection_service.establish_connection(connection)
            if db_connection:
                connection.status = "active"
                connection.last_connected = datetime.datetime.utcnow().isoformat()
                
                # Store connections
                self.connections[conn_id] = connection
                self.active_connections[conn_id] = db_connection
                
                # Discover schema
                schema_info = await self.schema_service.discover_schema(conn_id)
                connection.schema_info = asdict(schema_info)
                self.schema_cache[conn_id] = schema_info
                
                return {
                    "database_status": "connected",
                    "connection_id": conn_id,
                    "connection_info": asdict(connection),
                    "schema_summary": {
                        "tables_count": len(schema_info.tables),
                        "views_count": len(schema_info.views),
                        "relationships_count": len(schema_info.relationships)
                    }
                }
            else:
                connection.status = "failed"
                return {
                    "database_status": "disconnected",
                    "message": "Failed to establish database connection",
                    "connection_info": asdict(connection)
                }
                
        except Exception as e:
            logger.error(f"Database connection error: {e}")
            return {
                "database_status": "disconnected",
                "message": str(e)
            }
    
    async def hook_execute_sql(self, database_id: str, sql_query: str, **kwargs):
        """
        Execute raw SQL query against database
        
        Args:
            database_id: Database connection ID
            sql_query: Raw SQL query to execute
            
        Returns:
            dict: Query results and metadata
            
        Examples:
            plugin:database_connector execute_sql database_id="abc123" sql_query="SELECT * FROM customers LIMIT 10"
            plugin:database_connector execute_sql database_id="abc123" sql_query="SELECT COUNT(*) FROM orders WHERE created_at >= '2024-01-01'"
        """
        try:
            if database_id not in self.connections:
                return {
                    "status": "error",
                    "message": f"Database connection {database_id} not found"
                }
            
            connection = self.connections[database_id]
            
            # Validate SQL for security
            if not self._is_safe_query(sql_query):
                return {
                    "status": "error",
                    "message": "Query contains unsafe operations. Only SELECT queries are allowed."
                }
            
            # Execute query
            start_time = datetime.datetime.utcnow()
            result = await self.query_service.execute_query(database_id, sql_query)
            execution_time = (datetime.datetime.utcnow() - start_time).total_seconds()
            
            # Create query result
            query_result = QueryResult(
                query_id=hashlib.md5(f"{database_id}_{sql_query}_{start_time.isoformat()}".encode()).hexdigest()[:8],
                sql_query=sql_query,
                user_request="",  # No user request for raw SQL
                database_id=database_id,
                status="success" if result is not None else "error",
                execution_time=execution_time,
                rows_returned=len(result) if result else 0,
                data=result if result else [],
                timestamp=start_time.isoformat()
            )
            
            return {
                "status": "success",
                "query_result": asdict(query_result),
                "database_info": {
                    "name": connection.name,
                    "type": connection.db_type
                }
            }
            
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def hook_schema(self, database_id: str = None, refresh: bool = False, **kwargs):
        """
        Get or refresh database schema information
        
        Args:
            database_id: Specific database ID (optional, returns all if not specified)
            refresh: Whether to refresh cached schema
            
        Returns:
            dict: Schema information
            
        Examples:
            plugin:database_connector schema
            plugin:database_connector schema database_id="abc123"
            plugin:database_connector schema database_id="abc123" refresh=true
        """
        try:
            if database_id:
                # Remove quotes if present (backend sometimes sends database_id in quotes)
                database_id = database_id.strip('"') if isinstance(database_id, str) else database_id
                if database_id not in self.connections:
                    return {
                        "status": "error",
                        "message": f"Database connection {database_id} not found"
                    }
                
                if refresh or database_id not in self.schema_cache:
                    schema_info = await self.schema_service.discover_schema(database_id)
                    self.schema_cache[database_id] = schema_info
                    self.connections[database_id].schema_info = asdict(schema_info)
                
                return {
                    "status": "success",
                    "database_id": database_id,
                    "schema": asdict(self.schema_cache[database_id])
                }
            else:
                # Return all schemas
                all_schemas = {}
                for conn_id, connection in self.connections.items():
                    if conn_id in self.schema_cache:
                        all_schemas[conn_id] = {
                            "connection_name": connection.name,
                            "db_type": connection.db_type,
                            "schema": asdict(self.schema_cache[conn_id])
                        }
                
                return {
                    "status": "success",
                    "schemas": all_schemas
                }
                
        except Exception as e:
            logger.error(f"Schema discovery error: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def hook_disconnect(self, database_id: str = None, **kwargs):
        """
        Disconnect from database(s)
        
        Args:
            database_id: Specific database to disconnect (optional, disconnects all if not specified)
            
        Returns:
            dict: Disconnection status
            
        Examples:
            plugin:database_connector disconnect
            plugin:database_connector disconnect database_id="abc123"
        """
        try:
            if database_id:
                if database_id in self.active_connections:
                    await self.connection_service.close_connection(database_id)
                    self.connections[database_id].status = "inactive"
                    return {
                        "status": "success",
                        "message": f"Disconnected from database {database_id}"
                    }
                else:
                    return {
                        "status": "error",
                        "message": f"Database {database_id} not connected"
                    }
            else:
                # Disconnect all
                disconnected = []
                for conn_id in list(self.active_connections.keys()):
                    await self.connection_service.close_connection(conn_id)
                    self.connections[conn_id].status = "inactive"
                    disconnected.append(conn_id)
                
                return {
                    "status": "success",
                    "message": f"Disconnected from {len(disconnected)} database(s)",
                    "disconnected": disconnected
                }
                
        except Exception as e:
            logger.error(f"Disconnect error: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def hook_status(self, **kwargs):
        """
        Get current plugin status and active connections
        
        Returns:
            dict: Plugin status and connection information
            
        Examples:
            plugin:database_connector status
        """
        active_count = len([c for c in self.connections.values() if c.status == "active"])
        total_count = len(self.connections)
        
        connection_summary = []
        for conn_id, connection in self.connections.items():
            summary = {
                "id": conn_id,
                "name": connection.name,
                "db_type": connection.db_type,
                "host": connection.host,
                "database": connection.database,
                "status": connection.status,
                "last_connected": connection.last_connected,
                "tables_count": len(connection.schema_info.get("tables", [])) if connection.schema_info else 0
            }
            connection_summary.append(summary)
        
        return {
            "status": "success",
            "plugin_version": self.VERSION,
            "active_connections": active_count,
            "total_connections": total_count,
            "connections": connection_summary
        }
    

