#!/usr/bin/env python3
"""Install MindFabric Agent as systemd service"""

import os
import re
import sys
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from core.install_integrity import prepare_runtime_environment, format_root_summary

_PLACEHOLDER = "__MINDFABRIC_AGENT_BIN__"


def _resolve_systemd_dir() -> Optional[Path]:
    """Prefer core/systemd (ships in wheels), then legacy layouts."""
    try:
        import core

        core_sd = Path(core.__file__).resolve().parent / "systemd"
        if (core_sd / "mindfabric-agent.service").exists():
            return core_sd
    except ImportError:
        pass
    legacy = Path(__file__).resolve().parent / "systemd"
    if (legacy / "mindfabric-agent.service").exists():
        return legacy
    try:
        import mindfabric_agent

        pd = Path(mindfabric_agent.__file__).resolve().parent.parent / "systemd"
        if (pd / "mindfabric-agent.service").exists():
            return pd
    except ImportError:
        pass
    import site

    for site_dir in site.getsitepackages():
        test_dir = Path(site_dir) / "mindfabric_agent" / "systemd"
        if (test_dir / "mindfabric-agent.service").exists():
            return test_dir
    return None


def _resolve_agent_bin() -> Optional[str]:
    w = shutil.which("mindfabric-agent")
    if w:
        return w
    for p in (
        Path("/opt/mindfabric-agent-venv/bin/mindfabric-agent"),
        Path("/usr/local/bin/mindfabric-agent"),
        Path("/usr/bin/mindfabric-agent"),
    ):
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return None


def _env_file_has_access_key(env_path: Path) -> bool:
    if not env_path.is_file():
        return False
    try:
        text = env_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^ACCESS_KEY\s*=\s*(.*)$", line)
        if not m:
            continue
        val = m.group(1).strip().strip('"').strip("'")
        return bool(val)
    return False


def install_systemd_service():
    """Install agent as systemd service"""
    
    # Check if running as root
    if os.geteuid() != 0:
        print("Error: This command must be run as root (use sudo)")
        return 1
    
    package_dir = None
    try:
        import mindfabric_agent

        package_dir = Path(mindfabric_agent.__file__).resolve().parent.parent
    except ImportError:
        package_dir = Path(__file__).resolve().parent

    try:
        integrity_report = prepare_runtime_environment(current_root=package_dir, clean_pycache=True)
        if integrity_report.foreign_roots:
            print("Warning: Multiple agent install roots detected.")
            print(f"  Active root: {integrity_report.current_root}")
            print(f"  Other roots: {format_root_summary(integrity_report.foreign_roots)}")
        if integrity_report.cleared_pycache_dirs:
            print(f"✓ Cleared {len(integrity_report.cleared_pycache_dirs)} local __pycache__ directories")
    except Exception as exc:
        print(f"Warning: Could not run installation integrity cleanup: {exc}")

    systemd_dir = _resolve_systemd_dir()
    if systemd_dir is None:
        print("Error: systemd template directory not found (mindfabric-agent.service missing).")
        return 1

    service_template = systemd_dir / "mindfabric-agent.service"
    env_example = systemd_dir / "agent.env.example"

    agent_bin = _resolve_agent_bin()
    if not agent_bin:
        print("Error: mindfabric-agent binary not found in PATH.")
        print("  Install the package first, e.g.: pip install mindfabric-agent")
        return 1

    template_body = service_template.read_text(encoding="utf-8")
    if _PLACEHOLDER not in template_body:
        print(f"Error: Service template missing {_PLACEHOLDER!r} placeholder")
        return 1
    unit_body = template_body.replace(_PLACEHOLDER, agent_bin)

    print("Installing MindFabric Agent as systemd service...")
    print()
    
    # Create config directory
    config_dir = Path("/etc/mindfabric-agent")
    config_dir.mkdir(parents=True, exist_ok=True)
    print(f"✓ Created config directory: {config_dir}")
    
    # Copy environment file example if it doesn't exist
    env_file = config_dir / "agent.env"
    if not env_file.exists() and env_example.exists():
        shutil.copy(env_example, env_file)
        print(f"✓ Created config file: {env_file}")
        print(f"  Please edit this file and configure your agent settings")
    else:
        print(f"✓ Config file already exists: {env_file}")
    
    systemd_service_path = Path("/etc/systemd/system/mindfabric-agent.service")
    systemd_service_path.write_text(unit_body, encoding="utf-8")
    os.chmod(systemd_service_path, 0o644)
    print(f"✓ Installed service file: {systemd_service_path}")
    print(f"  ExecStart: {agent_bin}")
    
    # Reload systemd
    print("\nReloading systemd daemon...")
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    print("✓ Systemd daemon reloaded")

    skip_enable = os.environ.get("MINDFABRIC_SKIP_SYSTEMD_ENABLE", "").lower() in (
        "1",
        "true",
        "yes",
    )
    if not skip_enable and _env_file_has_access_key(env_file):
        print("\nACCESS_KEY is set; enabling and starting unit (boot + crash restart via Restart=always)…")
        r = subprocess.run(
            ["systemctl", "enable", "--now", "mindfabric-agent"],
            check=False,
        )
        if r.returncode == 0:
            print("✓ systemctl enable --now mindfabric-agent")
        else:
            print("Warning: systemctl enable --now failed; start manually after fixing config.")
    
    print("\n" + "="*60)
    print("Installation complete!")
    print("="*60)
    print()
    if not _env_file_has_access_key(env_file):
        print("Next steps:")
        print(f"  1. Edit configuration: sudo nano {env_file}")
        print("  2. Enable service: sudo systemctl enable --now mindfabric-agent")
        print("  3. Check status: sudo systemctl status mindfabric-agent")
    else:
        print("Service management:")
        print("  Status:  sudo systemctl status mindfabric-agent")
    print()
    print("  Start:   sudo systemctl start mindfabric-agent")
    print("  Stop:    sudo systemctl stop mindfabric-agent")
    print("  Restart: sudo systemctl restart mindfabric-agent")
    print("  Logs:    sudo journalctl -u mindfabric-agent -f")
    print()
    
    return 0

def uninstall_systemd_service():
    """Uninstall systemd service"""
    
    if os.geteuid() != 0:
        print("Error: This command must be run as root (use sudo)")
        return 1
    
    print("Uninstalling MindFabric Agent systemd service...")
    
    # Stop and disable service
    try:
        subprocess.run(["systemctl", "stop", "mindfabric-agent"], check=False)
        subprocess.run(["systemctl", "disable", "mindfabric-agent"], check=False)
        print("✓ Service stopped and disabled")
    except Exception as e:
        print(f"Warning: Could not stop service: {e}")
    
    # Remove service file
    systemd_service_path = Path("/etc/systemd/system/mindfabric-agent.service")
    if systemd_service_path.exists():
        systemd_service_path.unlink()
        print(f"✓ Removed service file: {systemd_service_path}")
    
    # Reload systemd
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    print("✓ Systemd daemon reloaded")
    
    print("\nNote: Configuration files in /etc/mindfabric-agent/ were not removed.")
    print("To remove them: sudo rm -rf /etc/mindfabric-agent/")
    
    return 0

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "uninstall":
        sys.exit(uninstall_systemd_service())
    else:
        sys.exit(install_systemd_service())

