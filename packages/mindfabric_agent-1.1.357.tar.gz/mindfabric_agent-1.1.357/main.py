import asyncio
import websockets
import sys
import os

# Добавляем /app в PYTHONPATH для абсолютных импортов
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.config import load_config
from core.install_integrity import prepare_runtime_environment
from utils.logger import setup_logger

async def main():
    config = load_config()
    setup_logger(config.get("log_level", "INFO"))

    prepare_runtime_environment(clean_pycache=False)

    from core.ws.ws_client import WebSocketAgentClient
    from core.executor.registry import ExecutorRegistry

    registry = ExecutorRegistry()
    registry.load_plugins()

    base_url = config["backend_ws_url"].rstrip("/")
    # Remove /ws/init if already present to avoid double path
    if base_url.endswith("/ws/init"):
        base_url = base_url[:-8]  # Remove "/ws/init"
    # Extract host from URL (handle ws://, wss://, http://, https://)
    if "://" in base_url:
        protocol, host = base_url.split("://", 1)
        # Convert http/https to ws/wss
        if protocol == "http":
            protocol = "ws"
        elif protocol == "https":
            protocol = "wss"
        ws_url = f"{protocol}://{host}/ws/init"
    else:
        # If user passed a plain host without scheme, default to secure WebSocket for public domains.
        # Keep ws:// for typical local/dev hosts.
        host = base_url
        is_local = host.startswith(("localhost", "127.0.0.1")) or host.endswith(".local") or ":" in host
        ws_url = f"{'ws' if is_local else 'wss'}://{host}/ws/init"

    agent = WebSocketAgentClient(
        ws_url=ws_url,
        agent_id=config.get("agent_id") or config["agent_name"],
        access_key=config["access_key"],
        registry=registry,
        ws_proxy_url=config.get("ws_proxy_url"),
        ws_proxy_enabled=config.get("ws_proxy_enabled", False),
        stealth_mode=config.get("stealth_mode", False),
        allow_remote_shell=config.get("allow_remote_shell", False)
    )
    await agent.run()

if __name__ == "__main__":
    # To run this main.py, execute `python -m agent.main` from the `infrastructure_agent` directory.
    asyncio.run(main())
