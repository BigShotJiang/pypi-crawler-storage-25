#!/usr/bin/env python3
"""CLI entry point for MindFabric Agent"""
import os

# Ensure allocator tuning is applied even when the agent is not started via systemd.
# This helps on small hosts by reducing glibc malloc arena fragmentation/overhead.
# Safe no-op on non-glibc systems.
os.environ.setdefault("MALLOC_ARENA_MAX", os.getenv("MALLOC_ARENA_MAX", "2"))

import asyncio
import sys
import argparse
import subprocess
import websockets
import logging
from pathlib import Path
from typing import Optional

from config.config import load_config
from core.install_integrity import prepare_runtime_environment, format_root_summary
from core.capabilities.runtime_capabilities import (
    collect_runtime_capabilities,
    format_runtime_capability_log_lines,
)
from utils.logger import setup_logger


def _use_cli_color() -> bool:
    """ANSI colors for interactive help/status (respect https://no-color.org/)."""
    if os.environ.get("NO_COLOR", "").strip():
        return False
    if os.environ.get("FORCE_COLOR", "").strip():
        return True
    return sys.stdout.isatty()


def _style(code: str, text: str, *, enabled: bool) -> str:
    if not enabled or not code:
        return text
    return f"\033[{code}m{text}\033[0m"


def _make_color_help_formatter_class(use_color: bool):
    """Bold usage line and section headings in ``--help`` when colors are on."""

    class ColorHelpFormatter(argparse.ArgumentDefaultsHelpFormatter):
        def add_usage(self, usage, actions, groups, prefix=None):
            if prefix is None:
                prefix = "usage: "
            if use_color:
                prefix = f"{_style('1;34', prefix.rstrip(), enabled=True)} "
            super().add_usage(usage, actions, groups, prefix)

        def start_section(self, heading):
            if use_color:
                heading = _style("1;35", heading, enabled=True)
            super().start_section(heading)

    return ColorHelpFormatter


def get_package_version() -> str:
    """Version from installed distribution (PyPI / wheel), for ``-v`` / ``--version``."""
    try:
        try:
            from importlib.metadata import version as pkg_version
        except ImportError:
            from importlib_metadata import version as pkg_version  # type: ignore[no-redef,import-not-found]
        for dist in ("mindfabric-agent", "mindfabric_agent"):
            try:
                return pkg_version(dist)
            except Exception:
                continue
    except Exception:
        pass
    return "unknown"


def build_arg_parser() -> argparse.ArgumentParser:
    """Build CLI parser (used for ``parse_args`` and bare-invocation help)."""
    use_color = _use_cli_color()
    fmt = _make_color_help_formatter_class(use_color) if use_color else argparse.ArgumentDefaultsHelpFormatter
    parser = argparse.ArgumentParser(
        description=_style("1;36", "MindFabric AI Agent", enabled=use_color) if use_color else "MindFabric AI Agent",
        formatter_class=fmt,
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {get_package_version()}",
    )
    parser.add_argument(
        "-u",
        "--update",
        action="store_true",
        help="Update agent package to latest version (from TestPyPI) and exit",
    )
    parser.add_argument(
        "--auto-update",
        action="store_true",
        help="Enable automatic self-update from PyPI (override index via AGENT_AUTO_UPDATE_* env)",
    )
    parser.add_argument(
        "--auto-update-interval",
        type=int,
        help="Auto-update check interval in seconds (default: 21600)",
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--backend-url", help="Backend URL (overrides config)")
    parser.add_argument("--agent-name", help="Agent name (overrides config)")
    parser.add_argument("--access-key", help="Access key (overrides config)")
    parser.add_argument("--stealth", action="store_true", help="Enable stealth mode")
    parser.add_argument(
        "--allow-remote-shell",
        action="store_true",
        help="Allow ad-hoc remote shell commands from backend/UI (unsafe; prefer plugin commands)",
    )
    return parser


def parse_args():
    """Parse command line arguments"""
    return build_arg_parser().parse_args()


def _is_bare_cli_invocation() -> bool:
    """True when the user passed no arguments (only the program name)."""
    return len(sys.argv) <= 1


def _effective_config_path_display() -> str:
    """Same resolution as ``load_config`` (for status output only)."""
    agent_root = Path(__file__).resolve().parent
    config_dir = agent_root / "config"
    primary = os.getenv("AGENT_CONFIG") or str(config_dir / "config.json")
    if os.path.exists(primary):
        return primary
    fallback = config_dir / "config.example.json"
    if fallback.exists():
        return f"{primary} (missing; using {fallback})"
    return primary


def _kv_line(label: str, value: str, *, c: bool, value_codes: Optional[str] = None) -> None:
    """One status row: bright label + emphasized value (no dim gray)."""
    lw = _style("1;94", f"{label}:", enabled=c)
    sep = " "
    val = _style(value_codes, value, enabled=c) if value_codes else value
    print(f"  {lw}{sep}{val}")


def _bool_str(v: bool, *, c: bool) -> str:
    if not c:
        return str(v)
    return _style("92", "True", enabled=True) if v else _style("91", "False", enabled=True)


def _print_status_block(config: dict, *, use_color: bool) -> None:
    """Effective settings (no secrets) for a bare CLI run."""
    c = use_color
    ver = get_package_version()
    access_key_set = bool((config.get("access_key") or "").strip())
    backend_url = config.get("backend_url") or "agent.mindfabric.ai"
    backend_ws = config.get("backend_ws_url")
    ws_preview = get_ws_url(backend_ws if backend_ws else backend_url)

    title = "MindFabric Agent — status"
    print(_style("1;34", title, enabled=c) if c else title)
    _kv_line("Version", ver, c=c, value_codes="1;32")
    _kv_line("Config file", _effective_config_path_display(), c=c, value_codes="36")
    ak_txt = "set" if access_key_set else "not set"
    ak_styled = (
        _style("92", "set", enabled=c)
        if access_key_set
        else _style("1;91", "not set", enabled=c)
        if c
        else ak_txt
    )
    if c:
        print(f"  {_style('1;94', 'ACCESS_KEY:', enabled=c)} {ak_styled}")
    else:
        print(f"  ACCESS_KEY:        {ak_txt}")
    _kv_line("Agent name", str(config.get("agent_name", "")), c=c, value_codes="1;33")
    _kv_line("Backend URL", backend_url, c=c, value_codes="36")
    if backend_ws and str(backend_ws).strip() != str(backend_url).strip():
        _kv_line("Backend WS URL", str(backend_ws), c=c, value_codes="36")
    _kv_line("WebSocket (init)", ws_preview, c=c, value_codes="36")
    for label, key in (
        ("Debug mode", "debug_mode"),
        ("Stealth mode", "stealth_mode"),
        ("Allow remote shell", "allow_remote_shell"),
    ):
        bval = bool(config.get(key))
        if c:
            print(f"  {_style('1;94', f'{label}:', enabled=True)} {_bool_str(bval, c=True)}")
        else:
            print(f"  {label}: {bval}")


def _svc_line(text: str, *, c: bool, as_command: bool = False, as_heading: bool = False) -> None:
    if not c:
        print(text)
        return
    if as_heading:
        print(_style("1;35", text, enabled=True))
    elif as_command:
        print(_style("36", text, enabled=True))
    else:
        print(text)


def _print_service_management_hints(*, use_color: bool) -> None:
    """Stop / restart / remove when the agent was installed as an OS service (official installers)."""
    plat = sys.platform
    c = use_color
    title = "Service management (this OS)"
    print(_style("1;34", title, enabled=c) if c else title)
    print()

    if plat.startswith("linux"):
        _svc_line("systemd unit: mindfabric-agent", c=c, as_heading=True)
        for cmd in (
            "sudo systemctl status mindfabric-agent --no-pager",
            "sudo systemctl stop mindfabric-agent",
            "sudo systemctl start mindfabric-agent",
            "sudo systemctl restart mindfabric-agent",
            "sudo journalctl -u mindfabric-agent -f",
        ):
            _svc_line(f"  {cmd}", c=c, as_command=True)
        _svc_line("Remove service unit:", c=c, as_heading=True)
        for cmd in (
            "sudo systemctl stop mindfabric-agent",
            "sudo systemctl disable mindfabric-agent",
            "sudo rm -f /etc/systemd/system/mindfabric-agent.service",
            "sudo systemctl daemon-reload",
        ):
            _svc_line(f"  {cmd}", c=c, as_command=True)
        _svc_line("Packaged helper (same as above; keeps /etc/mindfabric-agent/):", c=c, as_heading=False)
        _svc_line("  sudo mindfabric-agent-uninstall-service", c=c, as_command=True)
        return

    if plat == "darwin":
        _svc_line("launchd label: ai.mindfabric.agent", c=c, as_heading=True)
        _svc_line("LaunchDaemon (system):", c=c, as_heading=True)
        for cmd in (
            "sudo launchctl unload /Library/LaunchDaemons/ai.mindfabric.agent.plist",
            "sudo launchctl load /Library/LaunchDaemons/ai.mindfabric.agent.plist",
        ):
            _svc_line(f"  {cmd}", c=c, as_command=True)
        _svc_line("LaunchAgent (user):", c=c, as_heading=True)
        for cmd in (
            "launchctl unload ~/Library/LaunchAgents/ai.mindfabric.agent.plist",
            "launchctl load ~/Library/LaunchAgents/ai.mindfabric.agent.plist",
        ):
            _svc_line(f"  {cmd}", c=c, as_command=True)
        print(
            "Remove: unload the plist you use, delete that plist file,"
            if not c
            else _style("33", "Remove: unload the plist you use, delete that plist file,", enabled=True)
        )
        print(
            "  then remove wrapper/env paths if you no longer need them (~/.mindfabric/ or /usr/local/)."
            if not c
            else _style(
                "33",
                "  then remove wrapper/env paths if you no longer need them (~/.mindfabric/ or /usr/local/).",
                enabled=True,
            )
        )
        return

    if plat == "win32":
        _svc_line("Task Scheduler task name: MindFabricAgent", c=c, as_heading=True)
        for cmd in (
            "schtasks /End /TN MindFabricAgent",
            "schtasks /Run /TN MindFabricAgent",
            "schtasks /Delete /TN MindFabricAgent /F",
        ):
            _svc_line(f"  {cmd}", c=c, as_command=True)
        return

    print(
        _style("33", "No built-in service snippet for this platform.", enabled=c)
        if c
        else "No built-in service snippet for this platform."
    )
    print(
        _style(
            "33",
            "Official installers target Linux (systemd), macOS (launchd), or Windows (Task Scheduler).",
            enabled=c,
        )
        if c
        else "Official installers target Linux (systemd), macOS (launchd), or Windows (Task Scheduler)."
    )


def _self_update_from_testpypi() -> int:
    """
    Best-effort self-update.

    Notes:
    - Uses the current interpreter (venv-aware) to run pip.
    - If installed in a root-owned venv (common for systemd installs), this may require sudo.
    """
    pkg = "mindfabric-agent"
    py = sys.executable
    cmd = [
        py, "-m", "pip", "install",
        "--disable-pip-version-check",
        "--no-input",
        "--no-cache-dir",
        "--upgrade",
        "--force-reinstall",
        "--index-url", "https://test.pypi.org/simple/",
        "--extra-index-url", "https://pypi.org/simple",
        pkg,
    ]
    print(f"[update] running: {' '.join(cmd)}")
    try:
        p = subprocess.run(cmd, check=False)
        if p.returncode == 0:
            try:
                subprocess.run([py, "-m", "pip", "show", pkg], check=False)
            except Exception:
                pass
        else:
            print(f"[update] failed with exit code {p.returncode}")
        return int(p.returncode)
    except PermissionError:
        print("[update] permission denied. If agent is installed as a system service, run with sudo, e.g.:")
        print(f"  sudo {py} -m pip install -U --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple {pkg}")
        return 1
    except FileNotFoundError as e:
        print(f"[update] failed to execute pip: {e}")
        return 1

def get_ws_url(backend_url):
    """Умная логика определения WebSocket URL"""
    if '://' in backend_url:
        protocol = backend_url.split('://')[0]
        host = backend_url.split('://')[1]

        # If caller already included /ws or /ws/init, strip it to avoid double paths.
        if host.endswith("/ws/init"):
            host = host[:-8]
        elif host.endswith("/ws"):
            host = host[:-3]
        
        if protocol == 'https':
            return f"wss://{host}/ws/init"
        elif protocol == 'http':
            return f"ws://{host}/ws/init"
        else:
            # Если другой протокол, используем его как есть
            return f"{protocol}://{host}/ws/init"
    else:
        backend_url = backend_url.rstrip("/")
        if backend_url.endswith("/ws/init"):
            backend_url = backend_url[:-8]
        elif backend_url.endswith("/ws"):
            backend_url = backend_url[:-3]
        # Без префикса = HTTPS по умолчанию
        return f"wss://{backend_url}/ws/init"


def _log_runtime_capability_summary() -> None:
    try:
        summary = collect_runtime_capabilities()
        log_method = logging.info if summary.get("mode") == "full" else logging.warning
        for line in format_runtime_capability_log_lines(summary):
            log_method(line)
    except Exception as exc:
        logging.debug(f"[capabilities] failed to collect runtime capability summary: {exc}")

async def run_agent(args=None):
    """Run the agent"""
    config = load_config()
    
    # Переопределяем конфиг аргументами командной строки
    if args:
        if getattr(args, "auto_update", False):
            config["auto_update_enabled"] = True
        if getattr(args, "auto_update_interval", None):
            config["auto_update_interval_s"] = int(args.auto_update_interval)
        if args.debug:
            config["debug_mode"] = True
        if args.backend_url:
            config["backend_url"] = args.backend_url
            # IMPORTANT: config.json historically had `backend_ws_url=http://backend:8088`,
            # which would override `--backend-url`. If user specifies backend-url, prefer it.
            config.pop("backend_ws_url", None)
        if args.agent_name:
            config["agent_name"] = args.agent_name
        if args.access_key:
            config["access_key"] = args.access_key
        if args.stealth:
            config["stealth_mode"] = True
        if getattr(args, "allow_remote_shell", False):
            config["allow_remote_shell"] = True
    
    # Проверяем обязательность access_key
    if not config.get("access_key") or config.get("access_key", "").strip() == "":
        print("❌ Error: ACCESS_KEY is required!")
        print("Please specify ACCESS_KEY using one of the following methods:")
        print("1. Environment variable: ACCESS_KEY=your-key mindfabric-agent")
        print("2. Configuration file: Edit config/config.json and set 'access_key'")
        print("3. Command line (not recommended; visible in `ps`): mindfabric-agent --access-key your-key")
        sys.exit(1)
    
    # Настроить логирование в зависимости от debug режима
    debug_mode = config.get("debug_mode", False)
    if debug_mode:
        setup_logger("DEBUG")
        # Включаем debug для HTTP запросов
        import http.client
        http.client.HTTPConnection.debuglevel = 1
    else:
        setup_logger(config.get("log_level", "WARNING"))

    integrity_report = prepare_runtime_environment(clean_pycache=False)
    if integrity_report.foreign_roots:
        logging.warning(
            "[install] multiple agent roots detected; using %s and ignoring %s",
            integrity_report.current_root,
            format_root_summary(integrity_report.foreign_roots),
        )
    if integrity_report.dropped_modules:
        logging.warning(
            "[install] dropped %d stale agent modules from a foreign install root",
            len(integrity_report.dropped_modules),
        )

    from core.executor.registry import ExecutorRegistry
    from core.ws.ws_client import WebSocketAgentClient

    _log_runtime_capability_summary()

    registry = ExecutorRegistry()
    registry.load_plugins(debug_mode=debug_mode)

    # Используем backend_ws_url если он установлен, иначе backend_url
    backend_ws_url = config.get("backend_ws_url")
    backend_url = config.get("backend_url", "agent.mindfabric.ai")
    
    if backend_ws_url:
        # Если backend_ws_url уже содержит полный URL (ws:// или wss://), используем его как есть
        if backend_ws_url.startswith("ws://") or backend_ws_url.startswith("wss://"):
            ws_url = backend_ws_url.rstrip("/")
            if not ws_url.endswith("/ws/init"):
                ws_url = f"{ws_url}/ws/init"
        else:
            # Если только хост, формируем URL
            ws_url = get_ws_url(backend_ws_url)
    else:
        backend_url_clean = backend_url.rstrip("/")
        ws_url = get_ws_url(backend_url_clean)

    # agent_id теперь управляется бэкендом и сохраняется локально
    # Проверяем наличие сохраненного agent_id в локальных файлах (приоритет сохраненному значению)
    from pathlib import Path
    import os
    
    agent_id = None
    # Проверяем несколько возможных мест сохранения agent_id
    agent_id_files = [
        Path("/app/.agent_id"),  # В рабочей директории
        Path("/usr/local/lib/python3.11/site-packages/.agent_id"),  # В site-packages
        Path(__file__).parent.parent / ".agent_id"  # В корне пакета
    ]
    
    for agent_id_file in agent_id_files:
        if agent_id_file.exists():
            try:
                agent_id = agent_id_file.read_text().strip()
                if agent_id:
                    break
            except Exception:
                pass
    
    # Если agent_id не найден в файлах, используем ENV (только если файла нет)
    if not agent_id:
        agent_id = os.getenv("AGENT_ID")

    if debug_mode:
        print(f"Agent name: {config['agent_name']}")
        print(f"Backend URL: {config.get('backend_url', 'not set')}")
        print(f"Backend WS URL: {backend_ws_url or 'not set'}")
        print(f"WebSocket URL: {ws_url}")
        print(f"Debug mode: {debug_mode}")

    agent = WebSocketAgentClient(
        ws_url=ws_url,
        agent_id=agent_id,  # Может быть None при первой регистрации
        access_key=config["access_key"],
        registry=registry,
        config=config,  # Передаем весь config для доступа к agent_name
        stealth_mode=config.get("stealth_mode", False),
        debug_mode=debug_mode,
        allow_remote_shell=config.get("allow_remote_shell", False)
    )
    await agent.run()

def main():
    """Main entry point for the agent"""
    try:
        # Bare ``mindfabric-agent``: on an interactive terminal always print status + help.
        # With ACCESS_KEY, continue into the agent; without it, exit (0 in TTY, 1 otherwise).
        # Non-TTY + ACCESS_KEY (e.g. systemd): skip the banner so logs stay clean.
        if _is_bare_cli_invocation():
            cfg = load_config()
            key_ok = bool((cfg.get("access_key") or "").strip())
            tty = sys.stdout.isatty()
            cli_color = _use_cli_color()
            if tty or not key_ok:
                _print_status_block(cfg, use_color=cli_color)
                print()
                build_arg_parser().print_help()
                print()
                _print_service_management_hints(use_color=cli_color)
                print()
            if not key_ok:
                msg = (
                    "ACCESS_KEY is not set. Export it or use a service env file "
                    "(e.g. source /etc/mindfabric-agent/agent.env on Linux), then run again."
                )
                print(_style("1;33", msg, enabled=cli_color) if cli_color else msg)
                sys.exit(0 if tty else 1)
            if tty:
                print(_style("1;32", "Starting agent...", enabled=cli_color) if cli_color else "Starting agent...")
                print()

        args = parse_args()
        if getattr(args, "update", False):
            rc = _self_update_from_testpypi()
            sys.exit(rc)
        asyncio.run(run_agent(args))
    except KeyboardInterrupt:
        print("\nAgent stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"Error starting agent: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()

