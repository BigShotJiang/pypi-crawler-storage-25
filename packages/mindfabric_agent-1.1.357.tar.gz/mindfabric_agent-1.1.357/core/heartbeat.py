import asyncio
import json
from datetime import datetime
from utils.logger import logger

class HeartbeatManager:
    def __init__(self, agent_client):
        self.agent_client = agent_client
        self.interval = int(agent_client.config.get("heartbeat_interval", 30))

    async def run(self, ws):
        while True:
            msg = {
                "type": "heartbeat",
                "agent_id": self.agent_client.agent_id,
                "timestamp": int(datetime.utcnow().timestamp()),
                "status": "online",
                "metrics": {"cpu": 0.0, "mem": 0.0} # TODO: добавить реальное измерение
            }
            await ws.send(json.dumps(msg))
            logger.debug("Heartbeat sent.")
            await asyncio.sleep(self.interval)
