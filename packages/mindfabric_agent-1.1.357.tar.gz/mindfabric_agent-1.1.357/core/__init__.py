"""
Core functionality module for the agent.
""" 