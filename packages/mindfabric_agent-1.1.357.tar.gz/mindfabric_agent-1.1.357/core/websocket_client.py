import asyncio
import websockets
import json
from datetime import datetime
from core.heartbeat import HeartbeatManager
from queue.manager import CommandQueueManager
from proto.message import MessageProtocol
from utils.logger import logger

class WebSocketAgentClient:
    def __init__(self, config):
        self.config = config
        self.uri = config["backend_ws_url"]
        self.agent_id = config["agent_id"]
        self.access_key = config["access_key"]
        self.heartbeat = HeartbeatManager(self)
        self.queue_manager = CommandQueueManager(self)
        self.session_token = None
        self.reconnect_timeout = 5

    async def run(self):
        while True:
            try:
                async with websockets.connect(self.uri, ping_interval=None) as ws:
                    logger.info(f"Connected to {self.uri}")
                    await self._send_registration(ws)
                    ack = await ws.recv()
                    resp = json.loads(ack)
                    if resp.get("type") == "registration_ack" and resp.get("status") == "ok":
                        self.session_token = resp.get("session_token")
                        logger.info("Registration OK. New session active.")
                    else:
                        logger.error(f"Registration failed: {resp}")
                        return
                    # Heartbeat как background task
                    hb_task = asyncio.create_task(self.heartbeat.run(ws))
                    queue_task = asyncio.create_task(self.queue_manager.run(ws))
                    await asyncio.gather(hb_task, queue_task)
            except Exception as e:
                logger.error(f"WebSocket error: {e}. Reconnecting in {self.reconnect_timeout}s")
                await asyncio.sleep(self.reconnect_timeout)

    async def _send_registration(self, ws):
        msg = MessageProtocol.registration_message(self.config)
        await ws.send(json.dumps(msg))
