import asyncio
import os
from utils.logger import logger
from utils.logger import access_log_line
from core.executor.shell_executor import ShellExecutor
import time
try:
    import psutil  # type: ignore
except Exception:  # pragma: no cover
    psutil = None

class TaskQueue:
    def __init__(self, registry, ws, on_result=None, active_tasks=None, stealth_mode=False, allow_remote_shell=True):
        # Lanes:
        # - fast_queue: time-sensitive lightweight tasks (e.g., infra anomaly context snapshots)
        # - pentest_queue: autonomous pentest / gated campaign actions (do not block behind long plugin scans)
        # - queue: normal tasks (scheduled security scans, asset discovery, etc.)
        self.queue = asyncio.Queue()
        self.fast_queue = asyncio.Queue()
        self.pentest_queue = asyncio.Queue()
        self.registry = registry
        self.ws = ws
        self._running = True
        self._worker_tasks = []
        self.on_result = on_result
        self.active_tasks = active_tasks if active_tasks is not None else {}
        self.global_stealth_mode = stealth_mode
        # Regular executor for normal commands
        self.shell_executor = ShellExecutor(stealth_mode=False)
        # Stealth executor for stealth commands
        self.stealth_shell_executor = ShellExecutor(stealth_mode=True)
        self.allow_remote_shell = allow_remote_shell
        # Concurrency: number of worker loops pulling from the queue.
        # Default is 3 (combat-safe) to avoid long queue delays and backend timeouts.
        # On low-memory hosts (< 1GB) default to 1 to reduce OOM pressure.
        # Can be overridden via AGENT_TASK_WORKERS.
        default_workers = "3"
        if "AGENT_TASK_WORKERS" not in os.environ and psutil is not None:
            try:
                total = int(psutil.virtual_memory().total)
                if total < 1024**3:
                    default_workers = "1"
            except Exception:
                pass
        try:
            self.worker_count = int(os.getenv("AGENT_TASK_WORKERS", default_workers))
        except Exception:
            self.worker_count = int(default_workers)
        if self.worker_count < 1:
            self.worker_count = 1
        # Hard cap to avoid accidental fork-bomb configs
        if self.worker_count > 8:
            self.worker_count = 8

        # Dedicated pentest lane (default 1 worker). Set AGENT_PENTEST_TASK_WORKERS=0 to share the normal queue.
        try:
            self.pentest_workers = min(2, max(0, int(os.getenv("AGENT_PENTEST_TASK_WORKERS", "1"))))
        except Exception:
            self.pentest_workers = 1

        # Fast lane: always enabled by default (no env toggles).
        # We reserve exactly 1 worker for time-sensitive tasks (infrastructure_intelligence mode=context),
        # optional pentest worker(s), and at least 1 normal worker for all other tasks.
        self.fast_workers = 1
        self.normal_workers = max(1, self.worker_count - self.fast_workers - self.pentest_workers)
        self.total_workers = self.fast_workers + self.pentest_workers + self.normal_workers

    async def start(self):
        logger.info(
            f"TaskQueue started with {self.total_workers} worker(s) "
            f"(normal={self.normal_workers}, fast={self.fast_workers}, pentest={self.pentest_workers})."
        )
        self._worker_tasks = []
        # Fast lane workers first
        for i in range(self.fast_workers):
            self._worker_tasks.append(asyncio.create_task(self.worker(worker_id=i, lane="fast")))
        # Pentest lane (isolated from long-running plugin backlog)
        for p in range(self.pentest_workers):
            wid = self.fast_workers + p
            self._worker_tasks.append(asyncio.create_task(self.worker(worker_id=wid, lane="pentest")))
        # Normal workers
        for j in range(self.normal_workers):
            self._worker_tasks.append(
                asyncio.create_task(
                    self.worker(worker_id=self.fast_workers + self.pentest_workers + j, lane="normal")
                )
            )

    async def shutdown(self):
        logger.info("Shutting down TaskQueue.")
        self._running = False
        # Cancel running tasks first
        try:
            for _, t in list(self.active_tasks.items()):
                try:
                    t.cancel()
                except Exception:
                    pass
        except Exception:
            pass
        # Stop workers
        if self._worker_tasks:
            for t in self._worker_tasks:
                t.cancel()
            await asyncio.gather(*self._worker_tasks, return_exceptions=True)
            logger.info("TaskQueue worker(s) stopped.")

    def _is_fast_lane_task(self, plugin_name: str, data: dict) -> bool:
        """
        Decide whether a task should go to the fast lane.

        Fast lane is intended for time-sensitive, lightweight tasks that must execute promptly even while
        long-running scans are executing (e.g., infrastructure_intelligence mode=context snapshots).
        """
        if self.fast_workers <= 0:
            return False
        try:
            pname = str(plugin_name or "").strip().lower()
        except Exception:
            pname = ""
        if pname != "infrastructure_intelligence":
            return False

        # Prefer explicit args/options mode
        mode = None
        try:
            if isinstance(data.get("args"), dict):
                mode = data["args"].get("mode")
            if mode is None and isinstance(data.get("options"), dict):
                mode = data["options"].get("mode")
            if mode is None:
                mode = data.get("mode")
        except Exception:
            mode = None

        if isinstance(mode, str) and mode.strip().lower() == "context":
            return True

        # Fallback: parse from command string
        cmd = data.get("command", "")
        try:
            if isinstance(cmd, str) and "mode=context" in cmd.replace(" ", "").lower():
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def _is_pentest_lane_task(data: dict) -> bool:
        """Backend tags autonomous pentest commands with a top-level `pentest` dict."""
        try:
            return isinstance(data, dict) and isinstance(data.get("pentest"), dict)
        except Exception:
            return False

    async def worker(self, worker_id: int = 0, lane: str = "normal"):
        logger.info(f"[TaskQueue] Worker {worker_id} started for {lane} lane")
        while self._running:
            try:
                if lane == "fast":
                    q = self.fast_queue
                elif lane == "pentest":
                    q = self.pentest_queue
                else:
                    q = self.queue
                queue_size = q.qsize()
                if queue_size > 0:
                    logger.info(f"[TaskQueue] Worker {worker_id} ({lane}) queue has {queue_size} pending tasks")
                logger.debug(f"[TaskQueue] Worker {worker_id} ({lane}) waiting for task...")
                task = await q.get()
                plugin_name, data = task
                command_id = data.get("command_id")
                logger.info(f"[TaskQueue] Worker {worker_id} ({lane}) picked up command {command_id} (plugin={plugin_name})")
                command_type = data.get("command_type")
                coro = None
                started_ts = time.time()
                hook_name = (
                    data.get("hook")
                    or data.get("hook_name")
                    or (data.get("command_payload") or {}).get("hook")
                    or (data.get("command_payload") or {}).get("hook_name")
                )
                
                # Отправляем command_ack со статусом "executing" когда команда начинает выполняться
                # Это необходимо, потому что send_command_progress отправляет commands_output с in_progress,
                # но backend переводит в executing только если is_streaming_update=True (требует chunking).
                # Без chunking is_last_chunk=True по умолчанию, поэтому is_streaming_update=False и статус не обновляется.
                # command_ack с executing явно переводит команду из accepted в executing независимо от chunking.
                if hasattr(self.ws, 'send_command_ack'):
                    try:
                        await self.ws.send_command_ack(command_id, status="executing")
                        logger.info(f"[TaskQueue] Worker {worker_id} sent command_ack(executing) for command {command_id}")
                    except Exception as send_ack_error:
                        # If WS is temporarily down, don't fail the task execution; result will be queued and resent.
                        logger.warning(f"Failed to send command_ack(executing) for command {command_id}: {send_ack_error}")
                
                # Отправляем статус "in_progress" когда команда начинает выполняться
                if hasattr(self.ws, 'send_command_progress'):
                    try:
                        await self.ws.send_command_progress(
                            command_id,
                            progress=0,
                            output={"stdout": "Starting command execution...", "stderr": "", "return_code": None},
                            metadata={"started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
                        )
                    except Exception as send_progress_error:
                        # If WS is temporarily down, don't fail the task execution; result will be queued and resent.
                        logger.warning(f"Failed to send progress for command {command_id}: {send_progress_error}")
                
                if command_type == "shell":
                    if not self.allow_remote_shell:
                        error = Exception("Shell commands from backend are disabled by agent policy")
                        if self.on_result:
                            await self.on_result(plugin_name, data, None, error)
                        continue
                    command_payload = data.get("command_payload", {})
                    logger.info(f"Executing shell command: {command_payload}")
                    
                    # Check if stealth mode requested for this specific command
                    # stealth_run can be in command_payload or data directly
                    use_stealth = (
                        self.global_stealth_mode or 
                        command_payload.get("stealth_run", False) or 
                        command_payload.get("stealth", False) or
                        data.get("stealth_run", False) or
                        data.get("stealth", False)
                    )
                    
                    shell_payload = {
                        "cmd": command_payload.get("command", ""),
                        "timeout": command_payload.get("timeout", 30) / 1000,  # конвертируем из миллисекунд в секунды
                        "working_directory": command_payload.get("working_directory")
                    }
                    
                    async def progress_callback(progress, output):
                        if hasattr(self.ws, 'send_command_progress'):
                            await self.ws.send_command_progress(
                                command_id,
                                progress=progress,
                                output=output,
                                metadata={"progress_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
                            )
                    
                    # Choose executor based on stealth mode
                    executor = self.stealth_shell_executor if use_stealth else self.shell_executor
                    if use_stealth:
                        logger.info(f"[STEALTH] Executing command in stealth mode")
                    coro = executor.run(shell_payload, progress_callback=progress_callback)
                elif command_type == "plugin":
                    # Execute via plugin path even if the plugin isn't loadable in this agent runtime.
                    # Registry can still serve mock outputs when test_output=true.
                    logger.info(f"Executing plugin (forced): {plugin_name}")
                    coro = self.registry.execute(plugin_name, data, ws=self.ws)
                elif plugin_name and plugin_name in self.registry.plugins:
                    # Выполнить через плагин
                    logger.info(f"Executing plugin: {plugin_name}")
                    coro = self.registry.execute(plugin_name, data, ws=self.ws)
                else:
                    if not self.allow_remote_shell:
                        error = Exception("Shell commands from backend are disabled by agent policy (no matching plugin)")
                        if self.on_result:
                            await self.on_result(plugin_name, data, None, error)
                        continue
                    logger.warning(f"Plugin '{plugin_name}' not found, using shell executor")
                    
                    # Check if stealth mode requested
                    use_stealth = (
                        self.global_stealth_mode or 
                        data.get("stealth_run", False) or
                        data.get("stealth", False)
                    )
                    
                    shell_payload = {
                        "cmd": data.get("command", ""),
                        "timeout": data.get("timeout", 30) / 1000,  # конвертируем из миллисекунд в секунды
                        "working_directory": data.get("working_directory")
                    }
                    
                    # Choose executor based on stealth mode
                    executor = self.stealth_shell_executor if use_stealth else self.shell_executor
                    if use_stealth:
                        logger.info(f"[STEALTH] Executing fallback command in stealth mode")
                    coro = executor.run(shell_payload)
                
                # Record structured "current task" metadata for correlation (agent_logs reporter).
                try:
                    agent_id = getattr(self.ws, "agent_id", None)
                    meta = {
                        "agent_id": agent_id,
                        "command_id": command_id,
                        "plugin": plugin_name,
                        "command_type": command_type,
                        "hook": hook_name,
                        "started_ts": float(started_ts),
                        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(started_ts)),
                    }
                    # lightweight string for heartbeat display
                    try:
                        if hasattr(self.ws, "current_task"):
                            self.ws.current_task = f"{plugin_name or '-'}:{hook_name or 'run'} ({command_id or '-'})"
                    except Exception:
                        pass
                    if hasattr(self.ws, "active_task_meta") and command_id:
                        try:
                            self.ws.active_task_meta[command_id] = meta
                        except Exception:
                            pass
                except Exception:
                    pass

                # Get timeout from command data (in milliseconds, convert to seconds)
                timeout_seconds = None
                try:
                    timeout_ms = data.get("timeout") or (data.get("command_payload") or {}).get("timeout") or 0
                    if timeout_ms and timeout_ms > 0:
                        timeout_seconds = float(timeout_ms) / 1000.0
                        # Add 10% buffer to timeout to avoid premature cancellation
                        timeout_seconds = timeout_seconds * 1.1
                except Exception:
                    timeout_seconds = None
                
                t = asyncio.create_task(coro)
                if command_id:
                    self.active_tasks[command_id] = t
                try:
                    if timeout_seconds and timeout_seconds > 0:
                        logger.info(f"[TaskQueue] Executing command {command_id} with timeout {timeout_seconds:.1f}s")
                        result = await asyncio.wait_for(t, timeout=timeout_seconds)
                    else:
                        logger.info(f"[TaskQueue] Executing command {command_id} without timeout")
                        result = await t
                    logger.info(
                        f"[worker:{worker_id}] Command {command_id} result: "
                        f"{self._summarize_result_for_log(result)}"
                    )
                    if self.on_result:
                        try:
                            logger.info(f"[worker:{worker_id}] Calling on_task_result for command {command_id}, plugin={plugin_name}")
                            await self.on_result(plugin_name, data, result, None)
                            logger.info(f"[worker:{worker_id}] on_task_result completed successfully for command {command_id}")
                        except Exception as result_error:
                            logger.error(f"Error in on_task_result callback for {command_id}: {result_error}", exc_info=True)
                    else:
                        logger.warning(f"on_result callback is None for command {command_id}")

                    # Access log (nginx-like): one line per completed command
                    duration_ms = int((time.time() - started_ts) * 1000)
                    rc = None
                    try:
                        if isinstance(result, dict):
                            rc = result.get("return_code")
                    except Exception:
                        rc = None
                    agent_id = getattr(self.ws, "agent_id", None)
                    access_log_line(
                        f'agent_id={agent_id or "-"} command_id={command_id or "-"} '
                        f'type={command_type or "-"} plugin={plugin_name or "-"} hook={hook_name or "-"} '
                        f'status=ok duration_ms={duration_ms} return_code={rc if rc is not None else "-"}'
                    )
                except asyncio.TimeoutError:
                    logger.error(f"[worker:{worker_id}] Command {command_id} timed out after {timeout_seconds:.1f}s")
                    if self.on_result:
                        await self.on_result(plugin_name, data, None, Exception(f"Command timed out after {timeout_seconds:.1f}s"))
                    duration_ms = int((time.time() - started_ts) * 1000)
                    agent_id = getattr(self.ws, "agent_id", None)
                    access_log_line(
                        f'agent_id={agent_id or "-"} command_id={command_id or "-"} '
                        f'type={command_type or "-"} plugin={plugin_name or "-"} hook={hook_name or "-"} '
                        f'status=timeout duration_ms={duration_ms} return_code=-'
                    )
                except asyncio.CancelledError:
                    logger.warning(f"[worker:{worker_id}] Command {command_id} was cancelled.")
                    if self.on_result:
                        await self.on_result(plugin_name, data, None, Exception("Cancelled by backend"))
                    duration_ms = int((time.time() - started_ts) * 1000)
                    agent_id = getattr(self.ws, "agent_id", None)
                    access_log_line(
                        f'agent_id={agent_id or "-"} command_id={command_id or "-"} '
                        f'type={command_type or "-"} plugin={plugin_name or "-"} hook={hook_name or "-"} '
                        f'status=cancelled duration_ms={duration_ms} return_code=-'
                    )
                except Exception as e:
                    # Keep logs compact and structured:
                    # - loguru already includes the traceback when exc_info=True
                    # - avoid printing full tracebacks to stderr (systemd/syslog), which floods System Logs
                    logger.error(
                        f"Queue command error: {type(e).__name__}: {str(e)}",
                        exc_info=True,
                    )
                    if self.on_result:
                        try:
                            await self.on_result(plugin_name, data, None, e)
                        except Exception as result_error:
                            # Если не удалось отправить результат об ошибке, логируем
                            logger.error(f"Failed to send error result for command {command_id}: {result_error}")
                    duration_ms = int((time.time() - started_ts) * 1000)
                    agent_id = getattr(self.ws, "agent_id", None)
                    access_log_line(
                        f'agent_id={agent_id or "-"} command_id={command_id or "-"} '
                        f'type={command_type or "-"} plugin={plugin_name or "-"} hook={hook_name or "-"} '
                        f'status=error duration_ms={duration_ms} return_code=- error="{type(e).__name__}: {str(e)}"'
                    )
                finally:
                    if command_id and command_id in self.active_tasks:
                        del self.active_tasks[command_id]
                    # Move task metadata to recent list for correlation after completion
                    try:
                        if hasattr(self.ws, "active_task_meta") and command_id and command_id in getattr(self.ws, "active_task_meta", {}):
                            m = self.ws.active_task_meta.pop(command_id, None)
                            if m and hasattr(self.ws, "recent_task_meta"):
                                try:
                                    m = dict(m)
                                    m["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                                    self.ws.recent_task_meta.appendleft(m)
                                except Exception:
                                    pass
                    except Exception:
                        pass
                    try:
                        q.task_done()
                    except Exception:
                        pass

            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(f"TaskQueue error: {exc}", exc_info=True)
                await asyncio.sleep(1)

    @staticmethod
    def _summarize_result_for_log(result) -> str:
        """
        Compact summary for agent logs only.
        IMPORTANT: Full `result` is still sent to backend via WS (send_command_output).
        """
        try:
            if isinstance(result, dict):
                keys = list(result.keys())
                out_type = result.get("output_type")
                schema_v = result.get("schema_version")
                meta = result.get("metadata") if isinstance(result.get("metadata"), dict) else None
                plugin = meta.get("plugin_name") if meta else None

                if out_type == "security_scan":
                    findings = result.get("findings")
                    findings_n = len(findings) if isinstance(findings, list) else 0
                    has_errors = meta.get("has_errors") if meta else None
                    raw = result.get("raw")
                    raw_keys_n = len(raw.keys()) if isinstance(raw, dict) else 0
                    return (
                        f"dict(output_type=security_scan schema_version={schema_v} "
                        f"plugin={plugin or '-'} findings={findings_n} raw_keys={raw_keys_n} has_errors={has_errors})"
                    )

                services = result.get("services")
                assets = result.get("assets")
                connections = result.get("connections")
                if isinstance(services, list) or isinstance(assets, list) or isinstance(connections, list):
                    return (
                        f"dict(plugin={plugin or result.get('plugin') or '-'} "
                        f"services={len(services) if isinstance(services, list) else 0} "
                        f"assets={len(assets) if isinstance(assets, list) else 0} "
                        f"connections={len(connections) if isinstance(connections, list) else 0} "
                        f"keys={keys[:12]}{'…' if len(keys) > 12 else ''})"
                    )

                return f"dict(keys={keys[:12]}{'…' if len(keys) > 12 else ''})"

            if isinstance(result, tuple):
                return f"tuple(len={len(result)})"

            if isinstance(result, str):
                s = result.replace("\n", "\\n")
                return (s[:500] + "…") if len(s) > 500 else s

            s = repr(result)
            return (s[:500] + "…") if len(s) > 500 else s
        except Exception:
            return "<unprintable result summary>"

    async def add(self, plugin_name, data):
        command_id = data.get("command_id", "unknown")
        if self._is_fast_lane_task(plugin_name, data):
            logger.info(f"[TaskQueue] Adding command {command_id} to FAST queue (plugin={plugin_name})")
            await self.fast_queue.put((plugin_name, data))
        elif self.pentest_workers > 0 and self._is_pentest_lane_task(data):
            logger.info(f"[TaskQueue] Adding command {command_id} to PENTEST queue (plugin={plugin_name})")
            await self.pentest_queue.put((plugin_name, data))
        else:
            logger.info(f"[TaskQueue] Adding command {command_id} to NORMAL queue (plugin={plugin_name})")
            await self.queue.put((plugin_name, data))
