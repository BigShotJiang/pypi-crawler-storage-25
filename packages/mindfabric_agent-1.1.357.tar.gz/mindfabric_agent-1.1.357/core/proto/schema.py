from pydantic import BaseModel
from typing import List, Dict, Optional, Any
from datetime import datetime

# --- Pydantic схемы (как раньше) ---
class RegisterAgentMsg(BaseModel):
    type: str = "register_agent"
    data: Dict[str, Any]

class HeartbeatMsg(BaseModel):
    type: str = "heartbeat"
    data: Dict[str, str]

class ExecCommandMsg(BaseModel):
    type: str = "exec_command"
    data: Dict[str, Any]

class CommandResultMsg(BaseModel):
    type: str = "command_result"
    data: Dict[str, Any]

class PluginsListRequestMsg(BaseModel):
    type: str = "get_plugins"
    data: Optional[Dict[str, Any]] = None

class PluginsListResponseMsg(BaseModel):
    type: str = "plugins_list"
    data: Dict[str, Any]

# --- Расширенные утилиты для формирования сложных сообщений (в стиле message.py) ---
def registration_message(config) -> dict:
    return {
        "type": "agent_registration",
        "agent_id": config.get("agent_id"),
        "version": config.get("version", "0.1"),
        "os": config.get("os", "linux"),
        "hostname": config.get("hostname", "unknown"),
        "role": config.get("role"),
        "capabilities": config.get("capabilities", []),
        "tags": config.get("tags", []),
        "access_key": config.get("access_key"),
        "heartbeat_interval": config.get("heartbeat_interval", 30),
        "config_hash": config.get("config_hash", "none")
    }

def command_ack(command_id: str, status: str):
    return {
        "type": "command_ack",
        "command_id": command_id,
        "status": status,
        "received_at": datetime.utcnow().isoformat()
    }

def commands_output(command_id, status, output=None, files=None, logs=None, alerts=None, error=None, traceback=None, meta=None):
    return {
        "type": "commands_output",
        "command_id": command_id,
        "status": status,
        "output": output or {},
        "files": files or [],
        "logs": logs or [],
        "alerts": alerts or [],
        "error": error,
        "traceback": traceback,
        "metadata": meta or {"finished_at": datetime.utcnow().isoformat()}
    }

def partial_progress(command_id, percent, output=None):
    return {
        "type": "commands_output",
        "command_id": command_id,
        "status": "partial_result",
        "progress": percent,
        "output": output or {},
        "metadata": {"partial_at": datetime.utcnow().isoformat()}
    }

def file_upload(command_id, file_url, b64=None, filename=None, size=None, meta=None):
    return {
        "type": "file_upload",
        "command_id": command_id,
        "file_url": file_url,
        "payload_b64": b64,
        "filename": filename,
        "size": size,
        "metadata": meta or {}
    }
