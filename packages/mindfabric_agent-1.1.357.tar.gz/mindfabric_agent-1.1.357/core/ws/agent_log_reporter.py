from __future__ import annotations

import asyncio
import hashlib
import os
import time
from datetime import datetime, timezone, timedelta
from typing import Any, Optional

from utils.logger import logger


async def agent_log_reporter_loop(ws_client: Any) -> None:
    """
    Periodically scan local log files for error signals and report them to backend as system logs.

    This function is intentionally defined outside `ws_client.py` to keep that module manageable.
    It expects a `ws_client` object with:
      - attributes: `_stop`, `session_token`, `active_task_meta`, `recent_task_meta`
      - method: `send_agent_logs(log_level: str, logs: list[dict])`
    """
    try:
        interval = int(os.getenv("AGENT_LOG_REPORT_INTERVAL_SECONDS", "120"))
    except Exception:
        interval = 120
    if interval < 30:
        interval = 30

    try:
        max_entries = int(os.getenv("AGENT_LOG_REPORT_MAX_ENTRIES", "30"))
    except Exception:
        max_entries = 30
    if max_entries < 5:
        max_entries = 5
    if max_entries > 200:
        max_entries = 200

    try:
        max_bytes = int(os.getenv("AGENT_LOG_REPORT_MAX_BYTES", str(200 * 1024)))
    except Exception:
        max_bytes = 200 * 1024
    if max_bytes < 32 * 1024:
        max_bytes = 32 * 1024

    # Never send very old lines (prevents "historical" errors resurfacing due to log rotation / state resets).
    try:
        max_age_seconds = int(os.getenv("AGENT_LOG_REPORT_MAX_AGE_SECONDS", "900"))
    except Exception:
        max_age_seconds = 900
    if max_age_seconds < 0:
        max_age_seconds = 0
    if max_age_seconds > 7 * 24 * 3600:
        max_age_seconds = 7 * 24 * 3600

    # Prefer MindFabric's error.log (ERROR+) and agent.log (all), location controlled by MINDFABRIC_AGENT_LOG_DIR.
    base_dir = os.getenv("MINDFABRIC_AGENT_LOG_DIR") or os.getenv("AGENT_LOG_DIR") or "/var/log/mindfabric-agent"
    paths = [
        f"{base_dir.rstrip('/')}/error.log",
        f"{base_dir.rstrip('/')}/agent.log",
        "/var/log/syslog",
    ]

    # Track per-file read offsets. Persist to disk to avoid resending old lines after agent restart.
    offsets: dict[str, dict] = {}
    state_path = os.getenv("AGENT_LOG_REPORT_STATE_PATH") or "/tmp/mindfabric_agent_log_reporter_state.json"
    recent_sigs_limit = 2000

    def _load_state() -> None:
        nonlocal offsets
        try:
            import json as _json
            import os as _os

            if _os.path.exists(state_path):
                raw = _os.path.getsize(state_path)
                if raw > 0:
                    with open(state_path, "r", errors="ignore") as f:
                        data = _json.load(f)
                    if isinstance(data, dict) and isinstance(data.get("offsets"), dict):
                        offsets = data.get("offsets")  # type: ignore
        except Exception:
            offsets = {}

    def _save_state() -> None:
        try:
            import json as _json

            payload = {"offsets": offsets, "saved_at": time.time()}
            with open(state_path, "w") as f:
                _json.dump(payload, f)
        except Exception:
            pass

    _load_state()

    def _get_recent_sigs(path: str) -> list[str]:
        """
        Keep a bounded list of recently-sent signatures per path.
        This prevents resending identical lines after agent restart / file rotation.
        """
        try:
            m = offsets.get(path)
            if not isinstance(m, dict):
                return []
            v = m.get("recent_sigs")
            if isinstance(v, list):
                # sanitize
                out = [str(x) for x in v if isinstance(x, str) and x]
                if len(out) > recent_sigs_limit:
                    out = out[:recent_sigs_limit]
                m["recent_sigs"] = out
                return out
            m["recent_sigs"] = []
            return []
        except Exception:
            return []

    def _remember_sig(path: str, sig: str) -> None:
        try:
            if not sig:
                return
            m = offsets.get(path)
            if not isinstance(m, dict):
                offsets[path] = {"recent_sigs": [sig]}
                return
            rs = _get_recent_sigs(path)
            if sig in rs:
                return
            rs.insert(0, sig)
            if len(rs) > recent_sigs_limit:
                del rs[recent_sigs_limit:]
            m["recent_sigs"] = rs
        except Exception:
            return

    def _read_new(path: str) -> list[str]:
        import os as _os

        try:
            st = _os.stat(path)
            key = (st.st_ino, st.st_dev)
            prev = offsets.get(path)
            # reset if rotated
            if prev and prev.get("key") != key:
                # Rotation: keep recent_sigs so we don't re-report historical lines after restart/rotation.
                keep = {}
                try:
                    if isinstance(prev, dict) and isinstance(prev.get("recent_sigs"), list):
                        keep["recent_sigs"] = prev.get("recent_sigs")
                except Exception:
                    keep = {}
                offsets[path] = {"key": key, "pos": 0, **keep}
            if not offsets.get(path):
                # Bootstrap: start at end and DO NOT emit historical lines on first scan.
                offsets[path] = {"key": key, "pos": int(st.st_size), "bootstrapped": True}
                _save_state()
                return []
            pos = int(offsets[path]["pos"])
            end = int(st.st_size)
            if end - pos > max_bytes:
                pos = max(0, end - max_bytes)
            with open(path, "r", errors="ignore") as f:
                f.seek(pos)
                # If we seek into the middle of the file (log truncation window),
                # we may land in the middle of a long log line. Drop the first partial line
                # to avoid reporting chopped payloads.
                if pos > 0:
                    try:
                        _ = f.readline()  # discard remainder of current (partial) line
                    except Exception:
                        pass
                data = f.read(max_bytes)
                offsets[path]["pos"] = f.tell()
            offsets[path].pop("bootstrapped", None)
            _save_state()
            return data.splitlines()
        except Exception:
            return []

    patterns = (
        " error ",
        "error:",
        "error=",  # e.g. error="TimeoutError: ..."
        "status=error",
        "exception",
        "traceback",
        "cannot write to closing transport",
        "out of memory: killed process",
        "oom-kill",
        " failed:",
    )

    try:
        ctx_before = int(os.getenv("AGENT_LOG_CONTEXT_BEFORE", "3"))
    except Exception:
        ctx_before = 3
    try:
        ctx_after = int(os.getenv("AGENT_LOG_CONTEXT_AFTER", "3"))
    except Exception:
        ctx_after = 3
    if ctx_before < 0:
        ctx_before = 0
    if ctx_before > 20:
        ctx_before = 20
    if ctx_after < 0:
        ctx_after = 0
    if ctx_after > 20:
        ctx_after = 20

    while not bool(getattr(ws_client, "_stop", False)):
        await asyncio.sleep(interval)
        if not getattr(ws_client, "session_token", None):
            continue
        try:
            # choose best command correlation snapshot
            corr = None
            corr_is_active = False
            try:
                metas = list(getattr(ws_client, "active_task_meta", {}).values())
                if metas:
                    corr = sorted(metas, key=lambda m: float(m.get("started_ts") or 0), reverse=True)[0]
                    corr_is_active = True
                elif getattr(ws_client, "recent_task_meta", None):
                    corr = ws_client.recent_task_meta[0] if len(ws_client.recent_task_meta) else None
                    corr_is_active = False
            except Exception:
                corr = None
                corr_is_active = False

            logs: list[dict] = []
            ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

            # per-file context buffers
            from collections import deque as _dq

            before_bufs = {p: _dq(maxlen=ctx_before) for p in paths}
            pending_after: list[dict] = []  # [{path, item, remaining, after_lines}]

            def _flush_pending_for_line(path: str, line: str) -> None:
                nonlocal pending_after
                if not pending_after:
                    return
                still = []
                for ev in pending_after:
                    if ev.get("path") != path:
                        still.append(ev)
                        continue
                    if ev.get("remaining", 0) > 0:
                        ev["after_lines"].append(line[:2000])
                        ev["remaining"] = int(ev["remaining"]) - 1
                    if ev.get("remaining", 0) > 0:
                        still.append(ev)
                    else:
                        # complete
                        # Best-effort enrich "Command <id> failed:" lines with structured reason found in after-context.
                        try:
                            item = ev.get("item") or {}
                            details = item.get("details") if isinstance(item, dict) else None
                            after_lines = ev.get("after_lines") if isinstance(ev.get("after_lines"), list) else []
                            if isinstance(details, dict) and after_lines:
                                import re as _re

                                full = str(details.get("full_message") or item.get("message") or "")
                                full_low = full.lower()
                                m = _re.search(r"\\bcommand\\s+([0-9a-f\\-]{36})\\b", full_low)
                                cid = m.group(1) if m else None
                                if cid:
                                    details["command_id"] = cid
                                    # Try find matching status summary line in after-context
                                    for al in after_lines:
                                        al_s = str(al or "")
                                        al_low = al_s.lower()
                                        if f"command_id={cid}" not in al_low:
                                            continue
                                        m_pl = _re.search(r"\\bplugin=([a-z0-9_\\-]+)", al_low)
                                        if m_pl:
                                            details["plugin"] = m_pl.group(1)
                                        m_dur = _re.search(r"\\bduration_ms=(\\d+)", al_low)
                                        if m_dur:
                                            try:
                                                details["duration_ms"] = int(m_dur.group(1))
                                            except Exception:
                                                pass
                                        m_rc = _re.search(r"\\breturn_code=([^\\s]+)", al_low)
                                        if m_rc:
                                            details["return_code"] = m_rc.group(1)
                                        m_err = _re.search(r'\\berror=\"([^\"]*)\"', al_s)
                                        if m_err and m_err.group(1).strip():
                                            err = m_err.group(1).strip()
                                            details["error"] = err
                                            if "timeout" in err.lower():
                                                details["log_type"] = "timeout"
                                            else:
                                                details.setdefault("log_type", "plugin")
                                            # Improve user-facing message if it's just "... failed:"
                                            try:
                                                msg0 = str(item.get("message") or "")
                                                if msg0.lower().endswith("failed:"):
                                                    item["message"] = f"Command failed: {err}"[:500]
                                            except Exception:
                                                pass
                                        break
                        except Exception:
                            pass
                        logs.append(ev["item"])
                pending_after = still

            def _finalize_pending() -> None:
                nonlocal pending_after
                for ev in pending_after:
                    logs.append(ev["item"])
                pending_after = []

            dedupe: set[str] = set()

            def _try_parse_event_at(line: str) -> Optional[str]:
                """
                Best-effort parse of timestamps in agent logs/syslog.
                Returns ISO8601 (UTC, Z) or None.
                """
                try:
                    import re as _re

                    s = (line or "").strip()
                    if not s:
                        return None
                    # Formats we see:
                    # - "2026-02-04 15:33:35.750 | ERROR | ..."
                    # - "2026-02-06T11:28:45.578760+00:00 host proc: ..."
                    m = _re.match(
                        r"^(?P<d>\\d{4}-\\d{2}-\\d{2})[ T](?P<t>\\d{2}:\\d{2}:\\d{2})(?:\\.(?P<u>\\d{1,6}))?(?P<tz>Z|[+-]\\d{2}:?\\d{2})?",
                        s,
                    )
                    if not m:
                        return None
                    date_part = m.group("d")
                    time_part = m.group("t")
                    micro = m.group("u") or "0"
                    micro = (micro + "000000")[:6]
                    tz = m.group("tz")
                    # If timezone is present, parse via fromisoformat.
                    if tz:
                        tz_norm = tz
                        if tz_norm == "Z":
                            tz_norm = "+00:00"
                        if len(tz_norm) == 5 and tz_norm[3] != ":":
                            tz_norm = tz_norm[:3] + ":" + tz_norm[3:]
                        dt = datetime.fromisoformat(f"{date_part}T{time_part}.{micro}{tz_norm}")
                        return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                    dt = datetime.strptime(f"{date_part} {time_part}.{micro}", "%Y-%m-%d %H:%M:%S.%f")
                    return dt.replace(tzinfo=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                except Exception:
                    return None

            def _is_too_old(event_at_iso: Optional[str]) -> bool:
                if not max_age_seconds:
                    return False
                if not event_at_iso:
                    return False
                try:
                    ev = datetime.strptime(event_at_iso, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    age = (datetime.now(timezone.utc) - ev).total_seconds()
                    return age > float(max_age_seconds)
                except Exception:
                    return False

            def _corr_is_plausible(event_at_iso: Optional[str], corr_meta: Optional[dict]) -> bool:
                try:
                    if not event_at_iso or not corr_meta:
                        return False
                    started_at = corr_meta.get("started_at")
                    finished_at = corr_meta.get("finished_at")
                    if not isinstance(started_at, str) or not started_at:
                        return False
                    ev = datetime.strptime(event_at_iso, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    st = datetime.strptime(started_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    ft = None
                    if isinstance(finished_at, str) and finished_at:
                        try:
                            ft = datetime.strptime(finished_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                        except Exception:
                            ft = None
                    if ft:
                        return (st - timedelta(seconds=10)) <= ev <= (ft + timedelta(seconds=10))
                    return abs((ev - st).total_seconds()) <= 5 * 60
                except Exception:
                    return False

            # Coalesce noisy backend availability pairs:
            last_backend_err_seen_ts: dict[str, float] = {}

            # Cross-file error enrichment:
            last_cmd_status_by_id: dict[str, dict] = {}

            def _maybe_capture_cmd_status(line_low: str, line_raw: str) -> None:
                try:
                    import re as _re

                    if "command_id=" not in line_low:
                        return
                    m = _re.search(r"command_id=([0-9a-f\\-]{36})", line_low)
                    if not m:
                        return
                    cid = m.group(1)
                    info: dict[str, Any] = {"command_id": cid}
                    m_pl = _re.search(r"\\bplugin=([a-z0-9_\\-]+)", line_low)
                    if m_pl:
                        info["plugin"] = m_pl.group(1)
                    m_status = _re.search(r"\\bstatus=([a-z_]+)", line_low)
                    if m_status:
                        info["status"] = m_status.group(1)
                    m_rc = _re.search(r"\\breturn_code=([^\\s]+)", line_low)
                    if m_rc:
                        info["return_code"] = m_rc.group(1)
                    m_dur = _re.search(r"\\bduration_ms=([0-9]+)", line_low)
                    if m_dur:
                        try:
                            info["duration_ms"] = int(m_dur.group(1))
                        except Exception:
                            pass
                    m_err = _re.search(r'\\berror=\"([^\"]*)\"', line_raw)
                    if m_err and m_err.group(1).strip():
                        info["error"] = m_err.group(1).strip()
                    info["line"] = line_raw[:2000]
                    last_cmd_status_by_id[cid] = info
                except Exception:
                    return

            def _parse_level_from_line(line_s: str) -> Optional[str]:
                """
                Best-effort parse of log level from common agent log formats.
                Supports loguru style: "ts | LEVEL | message".
                """
                try:
                    import re as _re

                    m = _re.search(r"\\|\\s*(DEBUG|INFO|WARNING|ERROR|SUCCESS)\\s*\\|", line_s)
                    if not m:
                        return None
                    v = m.group(1).strip().lower()
                    if v == "warning":
                        return "warning"
                    if v in {"debug", "info", "error", "success"}:
                        return v
                    return None
                except Exception:
                    return None

            def _extract_tail_msg(full: str) -> str:
                try:
                    t = (full or "").strip()
                    if not t:
                        return ""
                    if " | " in t:
                        tail = t.split(" | ")[-1].strip()
                        return tail or t.splitlines()[0].strip()
                    return t.splitlines()[0].strip()
                except Exception:
                    return (full or "").strip()

            def _derive_title_for_log(line_s: str, ctx_before_lines: list[str]) -> str:
                """
                Choose a better human title for noisy agent error blocks.
                Keep original line in details.full_message.
                """
                try:
                    tail = _extract_tail_msg(line_s)
                    tail_low = tail.lower()
                    if (
                        tail_low.startswith("error context")
                        or tail_low.startswith("traceback (most recent call last)")
                        or tail_low.endswith("cancellederror")
                    ):
                        for prev in reversed(ctx_before_lines or []):
                            pt = _extract_tail_msg(prev)
                            if pt.lower().startswith("error type:"):
                                return pt
                        for prev in reversed(ctx_before_lines or []):
                            pt = _extract_tail_msg(prev)
                            if pt.lower().startswith("queue command error"):
                                return pt
                        for prev in reversed(ctx_before_lines or []):
                            pt = _extract_tail_msg(prev)
                            if "timeouterror" in pt.lower():
                                return pt
                    return tail or "agent_log"
                except Exception:
                    return "agent_log"

            for p in paths:
                for raw in _read_new(p):
                    line = (raw or "").rstrip("\n")
                    if ctx_after:
                        _flush_pending_for_line(p, line)

                    s = line.strip()
                    if not s:
                        if ctx_before:
                            before_bufs[p].append(line[:2000])
                        continue
                    low = s.lower()

                    # Drop very old lines (prevents resurfacing historical errors due to log rotation/state issues).
                    ev_iso_for_ttl = _try_parse_event_at(s)
                    if _is_too_old(ev_iso_for_ttl):
                        if ctx_before:
                            before_bufs[p].append(line[:2000])
                        continue

                    _maybe_capture_cmd_status(low, s)

                    # Avoid forwarding unrelated OS syslog noise.
                    try:
                        p_low = str(p).lower()
                    except Exception:
                        p_low = ""
                    if p_low.endswith("/syslog") and ("mindfabric-agent" not in low):
                        if ctx_before:
                            before_bufs[p].append(line[:2000])
                        continue

                    # Coalesce backend availability errors.
                    if "backend server error (" in low:
                        last_backend_err_seen_ts[p] = time.time()
                    if "please check if the backend server is running and accessible" in low:
                        last_ts = last_backend_err_seen_ts.get(p)
                        if last_ts and (time.time() - float(last_ts)) < 5.0:
                            if ctx_before:
                                before_bufs[p].append(line[:2000])
                            continue

                    if any(tok in low for tok in patterns):
                        sig = hashlib.sha1(f"{p}|{s[:300]}".encode("utf-8", errors="ignore")).hexdigest()
                        if sig in dedupe:
                            if ctx_before:
                                before_bufs[p].append(line[:2000])
                            continue
                        # persisted dedupe across restarts/rotations
                        try:
                            if sig in _get_recent_sigs(p):
                                if ctx_before:
                                    before_bufs[p].append(line[:2000])
                                continue
                            _remember_sig(p, sig)
                        except Exception:
                            pass
                        dedupe.add(sig)
                        try:
                            _save_state()
                        except Exception:
                            pass

                        details: dict[str, Any] = {"path": p}
                        event_at = _try_parse_event_at(s)
                        if event_at:
                            details["event_at"] = event_at

                        # If the log line contains a command UUID, prefer it over correlation snapshot.
                        try:
                            import re

                            m = re.search(r"\\bcommand\\s+([0-9a-f\\-]{36})\\b", low)
                            if m:
                                details["command_id"] = m.group(1)
                        except Exception:
                            pass

                        if corr and isinstance(corr, dict) and _corr_is_plausible(event_at, corr):
                            if (not details.get("command_id")) or str(details.get("command_id")) == str(corr.get("command_id")):
                                details.update(
                                    {
                                        "command_id": corr.get("command_id"),
                                        "plugin": corr.get("plugin"),
                                        "hook": corr.get("hook"),
                                        "command_type": corr.get("command_type"),
                                        "started_at": corr.get("started_at"),
                                        "finished_at": corr.get("finished_at"),
                                    }
                                )

                        if ctx_before:
                            details["context_before"] = list(before_bufs[p])

                        ctx_before_lines = details.get("context_before") if isinstance(details.get("context_before"), list) else []
                        safe_ctx_before = [str(x) for x in ctx_before_lines] if isinstance(ctx_before_lines, list) else []
                        derived_title = _derive_title_for_log(s, safe_ctx_before)[:500]
                        details.setdefault("full_message", s[:20000])

                        # Provide a compact type for UI tables (backend can use it directly).
                        try:
                            p_low = str(p).lower()
                            msg_low = str(s).lower()
                            
                            # Check for 502/503/504 errors FIRST - these should always be backend_unavailable
                            # Even if log_type was already set, we override it for gateway/availability errors
                            if "backend server error (" in msg_low:
                                import re
                                m = re.search(r"backend server error \\((\\d{3})\\)", msg_low)
                                if m:
                                    code = m.group(1)
                                    # Always set backend_unavailable for gateway/availability codes OR if message indicates unavailability
                                    if code in ("502", "503", "504") or "not responding" in msg_low or "is down" in msg_low:
                                        details["log_type"] = "backend_unavailable"
                                        try:
                                            details["backend_status"] = int(code)
                                        except Exception:
                                            pass
                                    else:
                                        # Other error codes (500, 501, etc.) use backend_{code}
                                        details.setdefault("log_type", f"backend_{code}")
                                elif "not responding" in msg_low or "is down" in msg_low:
                                    # If regex didn't match but message indicates unavailability
                                    details["log_type"] = "backend_unavailable"
                                else:
                                    # Fallback for other backend errors
                                    details.setdefault("log_type", "backend_error")
                            elif (
                                "backend server is not responding" in msg_low
                                or "the backend server is not responding" in msg_low
                                or "please check if the backend server is running and accessible" in msg_low
                            ):
                                # Always set backend_unavailable for these messages
                                details["log_type"] = "backend_unavailable"
                            elif "websocket is not initialized" in msg_low:
                                details.setdefault("log_type", "ws_not_initialized")
                            elif "clientconnectorerror" in msg_low or ("websocket" in msg_low and "connect" in msg_low and "failed" in msg_low):
                                details.setdefault("log_type", "ws_connect")
                            elif "registration failed" in msg_low:
                                # Registration failures are connectivity/backend issues, not plugin errors
                                # Always override any previously set log_type (e.g., "system" from syslog source)
                                details["log_type"] = "ws_connect"
                            elif "ssl" in msg_low and ("certificate" in msg_low or "handshake" in msg_low or "tls" in msg_low):
                                details.setdefault("log_type", "tls")
                            elif (
                                "temporary failure in name resolution" in msg_low
                                or "name or service not known" in msg_low
                                or "getaddrinfo failed" in msg_low
                                or "nodename nor servname provided" in msg_low
                            ):
                                details.setdefault("log_type", "dns")
                            elif "timeouterror" in msg_low or "timeout" in msg_low or "readtimeout" in msg_low or "connecttimeout" in msg_low:
                                details.setdefault("log_type", "timeout")
                            elif "permission denied" in msg_low or "operation not permitted" in msg_low or "read-only file system" in msg_low:
                                details.setdefault("log_type", "permission")
                            elif "no space left on device" in msg_low:
                                details.setdefault("log_type", "disk_full")
                            elif "no such file or directory" in msg_low or "file not found" in msg_low:
                                details.setdefault("log_type", "file_not_found")
                            elif "connectionerror" in msg_low or ("connect" in msg_low and "refused" in msg_low) or "network is unreachable" in msg_low:
                                details.setdefault("log_type", "network")
                            elif "unknown plugin:" in msg_low:
                                details.setdefault("log_type", "plugin_missing")
                            elif "separator is found, but chunk is longer than limit" in msg_low:
                                details.setdefault("log_type", "payload_too_large")
                            elif "command " in msg_low and " failed" in msg_low:
                                import re

                                m = re.search(r"command\\s+([0-9a-f\\-]{36})\\s+failed", msg_low)
                                if m:
                                    cid = m.group(1)
                                    extra = last_cmd_status_by_id.get(cid) or {}
                                    if extra:
                                        if extra.get("plugin"):
                                            details["plugin"] = extra.get("plugin")
                                        if extra.get("duration_ms") is not None:
                                            details["duration_ms"] = extra.get("duration_ms")
                                        if extra.get("return_code") is not None:
                                            details["return_code"] = extra.get("return_code")
                                        if extra.get("error"):
                                            details["error"] = extra.get("error")
                                            if "timeout" in str(extra.get("error")).lower():
                                                details.setdefault("log_type", "timeout")
                                            else:
                                                details.setdefault("log_type", "plugin")
                                        if str(derived_title).lower().endswith("failed:") and extra.get("error"):
                                            derived_title = f"Command failed: {extra.get('error')}"[:500]
                                details.setdefault("log_type", "plugin")
                            elif isinstance(details.get("plugin"), str) and details.get("plugin"):
                                details.setdefault("log_type", "plugin")
                            elif "out of memory" in msg_low or "oom" in msg_low or ("killed" in msg_low and "signal" in msg_low):
                                details.setdefault("log_type", "oom")
                                try:
                                    if isinstance(corr, dict) and corr.get("command_id") and corr.get("plugin"):
                                        if not details.get("command_id"):
                                            details["suspected_command_id"] = corr.get("command_id")
                                        if not details.get("plugin"):
                                            details["suspected_plugin"] = corr.get("plugin")
                                        if corr.get("hook") and not details.get("hook"):
                                            details["suspected_hook"] = corr.get("hook")
                                        if corr.get("command_type") and not details.get("command_type"):
                                            details["suspected_command_type"] = corr.get("command_type")
                                        if corr.get("started_at"):
                                            details.setdefault("suspected_started_at", corr.get("started_at"))
                                        if corr_is_active:
                                            details.setdefault("suspected_is_active", True)
                                except Exception:
                                    pass
                            else:
                                details.setdefault("log_type", "unknown")
                        except Exception:
                            pass

                        # Determine log level. Do NOT mark everything as error.
                        try:
                            p_low = str(p).lower()
                        except Exception:
                            p_low = ""
                        parsed_level = _parse_level_from_line(s)
                        item_level = parsed_level
                        if not item_level:
                            item_level = "error" if (p_low.endswith("/error.log") or p_low.endswith("mindfabric-agent/error.log")) else "info"
                        if any(tok in low for tok in ("traceback", "exception", "status=error", "error:", " error ", " failed:", "cannot write to closing transport")):
                            item_level = "error"

                        # User requirement: do not ship INFO/DEBUG/SUCCESS to backend at all.
                        # System Logs should only contain actionable events.
                        if item_level not in ("error", "warning"):
                            if ctx_before:
                                before_bufs[p].append(line[:2000])
                            continue

                        item = {
                            "timestamp": ts,
                            "level": item_level,
                            "source": f"agent_log:{p}",
                            "message": derived_title,
                            "details": details,
                        }

                        if ctx_after:
                            pending_after.append({"path": p, "item": item, "remaining": ctx_after, "after_lines": []})
                            details["context_after"] = pending_after[-1]["after_lines"]
                        else:
                            logs.append(item)

                        if len(logs) + len(pending_after) >= max_entries:
                            break

                    if ctx_before:
                        before_bufs[p].append(line[:2000])
                if len(logs) + len(pending_after) >= max_entries:
                    break

            _finalize_pending()
            if logs:
                # Use the highest severity in this batch as envelope default (backend still trusts per-item levels).
                try:
                    lvls = [str(x.get("level") or "").strip().lower() for x in (logs or []) if isinstance(x, dict)]
                    if any(l == "error" for l in lvls):
                        batch_level = "error"
                    elif any(l == "warning" for l in lvls):
                        batch_level = "warning"
                    elif any(l == "success" for l in lvls):
                        batch_level = "success"
                    elif any(l == "debug" for l in lvls):
                        batch_level = "debug"
                    else:
                        batch_level = "info"
                except Exception:
                    batch_level = "info"
                await ws_client.send_agent_logs(batch_level, logs[:max_entries])
        except Exception as e:
            logger.debug(f"[AGENT_LOG_REPORTER] failed: {e}")

