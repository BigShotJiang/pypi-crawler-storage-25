import asyncio
import json
import aiohttp
import ipaddress
from typing import Optional, Any, Tuple
import platform
import socket
import urllib.request
import hashlib
import time
import psutil
from collections import defaultdict
import base64
import tempfile
import os
import inspect
import shlex
import subprocess
from pathlib import Path
from collections import deque
import random
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse

from core.capabilities.runtime_capabilities import collect_runtime_capabilities
from core.heartbeat import HeartbeatManager
#from core.proto.schema import Task, TaskResult
from core.queue.task_queue import TaskQueue
from plugins.base_plugin import BasePlugin
#from core.executor.registry import get_executor
from utils.logger import logger

HEARTBEAT_INTERVAL = 20  # seconds
RECONNECT_DELAY = 5      # seconds
# If no inbound TEXT frame for this long, treat connection as dead (half-open / stuck recv).
# Backend sends JSON ping every WS_HEARTBEAT_INTERVAL (typically 30s); default allows ~4 missed pings.
DEFAULT_RECV_IDLE_TIMEOUT_S = 120.0
DEFAULT_RECV_IDLE_CHECK_INTERVAL_S = 10.0


def _http_metadata_get(url: str, headers: Optional[dict] = None, timeout: float = 0.85) -> Optional[str]:
    try:
        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            raw = resp.read(256)
            return raw.decode("utf-8", errors="ignore").strip() or None
    except Exception:
        return None


def _is_public_ipv4(addr: str) -> bool:
    try:
        ip = ipaddress.ip_address((addr or "").strip())
        return ip.version == 4 and ip.is_global
    except Exception:
        return False


def _local_route_ipv4() -> Optional[str]:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def _registration_primary_ipv4() -> Tuple[Optional[str], Optional[str]]:
    """
    Returns (ip_for_asset, optional_private_ip).
    On cloud VMs with 1:1 NAT, the default UDP route source is often RFC1918; prefer metadata public IPv4 when available.
    """
    local = _local_route_ipv4()
    # GCP
    pub = _http_metadata_get(
        "http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip",
        headers={"Metadata-Flavor": "Google"},
    )
    if pub and _is_public_ipv4(pub):
        return pub, local if local and local != pub else None
    # AWS (classic IMDS path; no public IP => often 404)
    pub = _http_metadata_get("http://169.254.169.254/latest/meta-data/public-ipv4")
    if pub and _is_public_ipv4(pub):
        return pub, local if local and local != pub else None
    if local:
        return local, None
    return None, None


class WebSocketAgentClient:
    def __init__(self, ws_url, agent_id, access_key, registry, config=None, ws_proxy_url=None, ws_proxy_enabled=False, stealth_mode=False, debug_mode=False, allow_remote_shell=False):
        self.ws_url = ws_url
        self.agent_id = agent_id
        self.access_key = access_key
        self.registry = registry
        self.config = config or {}  # Сохраняем config для доступа к agent_name
        self.ws_proxy_url = ws_proxy_url
        self.ws_proxy_enabled = ws_proxy_enabled
        self._stop = False
        self._ws = None
        # Increments each time a new websocket connection is established.
        # Used to prevent mixing chunk sends across reconnects.
        self._ws_generation = 0
        # Serialize all writes to the websocket to avoid interleaving (heartbeat/progress/results).
        self._send_lock = asyncio.Lock()
        self.task_queue = None
        self.session_token = None
        self.current_task = None
        self.active_tasks = {}  # command_id: asyncio.Task
        # Structured metadata for correlation of logs -> currently running (or recently finished) commands.
        # Populated by TaskQueue.
        self.active_task_meta = {}  # command_id: {plugin, hook, command_type, started_at, ...}
        self.recent_task_meta = deque(maxlen=50)
        self.stealth_mode = stealth_mode
        self.debug_mode = debug_mode
        self.allow_remote_shell = allow_remote_shell
        self.pending_results = []  # Очередь для результатов, которые не удалось отправить
        self.pending_partial_results = {}  # batch_id -> partial_result awaiting backend ack
        self._pending_partial_ack_timeout_s = 30.0
        # IMPORTANT:
        # Some deployments (reverse proxies / ws middlewares) enforce much smaller frame/message limits
        # than 5MB. We therefore chunk aggressively by default and allow tuning via env.
        try:
            self.max_message_size = int(os.getenv("WS_MAX_MESSAGE_SIZE", str(200 * 1024)))  # 200KB
        except Exception:
            self.max_message_size = 200 * 1024
        try:
            self.chunk_size = int(os.getenv("WS_CHUNK_SIZE", str(180 * 1024)))  # 180KB
        except Exception:
            self.chunk_size = 180 * 1024
        # Some WebSocket stacks (proxies/gateways) effectively cap frame/message sizes around ~64KiB.
        # If we send larger payloads without chunking, the connection may get closed and the backend
        # will never persist the command result (leading to false "timeout" statuses).
        try:
            self.always_chunk_above = int(os.getenv("WS_ALWAYS_CHUNK_ABOVE", str(64 * 1024)))  # 64KB
        except Exception:
            self.always_chunk_above = 64 * 1024
        try:
            # Conservative default:
            # some WS gateways effectively cap frames around 16KiB-32KiB.
            # Use a smaller default to reduce disconnects during send ("Cannot write to closing transport").
            # 16KB даёт слишком много чанков у "толстых" payload (asset_discovery),
            # что повышает риск потери чанка и зависания сборки на backend.
            self.always_chunk_size = int(os.getenv("WS_ALWAYS_CHUNK_SIZE", str(64 * 1024)))  # 64KB
        except Exception:
            self.always_chunk_size = 64 * 1024
        # Backend can sometimes send duplicate execute_command messages for the same command_id.
        # To avoid inconsistent execution paths (plugin vs shell) and status flapping, dedupe by command_id.
        self._seen_command_ids = set()
        self._last_reconnect_request_ts = 0.0
        self._reconnect_request_min_interval = 2.0  # seconds
        # Heartbeat network rate calculation (bytes/sec)
        self._last_net_io = None  # psutil.net_io_counters() snapshot
        self._last_net_ts = None  # time.time() of last snapshot
        # Inbound activity tracking (detect zombie / one-way dead connections without HTTP).
        self._last_rx_ts: Optional[float] = None
        try:
            self._recv_idle_timeout_s = float(
                os.getenv("AGENT_WS_RECV_IDLE_TIMEOUT_S", str(DEFAULT_RECV_IDLE_TIMEOUT_S))
            )
        except Exception:
            self._recv_idle_timeout_s = DEFAULT_RECV_IDLE_TIMEOUT_S
        if self._recv_idle_timeout_s < 45.0:
            self._recv_idle_timeout_s = 45.0  # floor: must exceed typical server ping interval
        try:
            self._recv_idle_check_interval_s = float(
                os.getenv("AGENT_WS_RECV_IDLE_CHECK_INTERVAL_S", str(DEFAULT_RECV_IDLE_CHECK_INTERVAL_S))
            )
        except Exception:
            self._recv_idle_check_interval_s = DEFAULT_RECV_IDLE_CHECK_INTERVAL_S
        if self._recv_idle_check_interval_s < 2.0:
            self._recv_idle_check_interval_s = 2.0

        # Reconnect backoff + log throttling
        self._reconnect_backoff_s = float(RECONNECT_DELAY)
        self._reconnect_backoff_max_s = 60.0
        self._connect_error_last_log_ts = 0.0
        self._connect_error_suppressed = 0
        self._connect_error_log_interval_s = 30.0
        # Avoid log storms when callers try to send while WS isn't ready yet.
        self._ws_not_ready_last_log_ts = 0.0
        self._ws_not_ready_suppressed = 0
        self._ws_not_ready_log_interval_s = 30.0

        # WS diagnostics (never include secrets)
        self._ws_diag_last_success_ts: Optional[float] = None
        self._ws_diag_last_connect_error: Optional[dict] = None
        self._ws_diag_last_connect_error_ts: Optional[float] = None
        self._ws_diag_last_reconnect_reason: Optional[str] = None
        self._ws_diag_last_reconnect_request_ts: Optional[float] = None
        self._ws_diag_last_not_ready: Optional[dict] = None
        self._ws_diag_last_send: Optional[dict] = None
        self._ws_diag_last_send_ts: Optional[float] = None

        # Auto-update (optional; OFF by default)
        self._auto_update_task = None
        self._auto_update_lock = asyncio.Lock()
        self._auto_update_last_check_ts = 0.0
        self._auto_update_last_log_ts = 0.0
        self._auto_update_log_interval_s = 300.0  # 5 min
        self._last_successful_update_ts = 0.0  # Track last successful update timestamp
        self._previous_version_before_update: Optional[str] = None  # Store version before update for rollback
        self._rollback_enabled = True  # Enable rollback mechanism
        self._auto_update_was_blocked = False  # Track if update was blocked due to busy agent
        
        # Subprocess cleanup (periodic cleanup of hung plugin subprocesses)
        self._subprocess_cleanup_task = None
        self._subprocess_cleanup_interval_s = 60.0  # Check every 1 minute (reduced from 5 minutes)
        self._subprocess_cleanup_last_check_ts = 0.0
        self._subprocess_max_age_s = 30 * 60  # Kill subprocesses older than 30 minutes (more aggressive cleanup)
        
        # Database cleanup (periodic cleanup of old SQLite databases)
        self._db_cleanup_task = None
        self._db_cleanup_interval_s = 24 * 3600  # Run once per day
        self._db_cleanup_last_run_ts = 0.0
        self._auto_update_enabled = self._bool_from_env_or_config(
            "AGENT_AUTO_UPDATE_ENABLED",
            config_key="auto_update_enabled",
            default=False,
        )
        try:
            self._auto_update_interval_s = int(
                os.getenv(
                    "AGENT_AUTO_UPDATE_INTERVAL_S",
                    # Default: 10 minutes (was 6 hours; too slow for iterative rollouts).
                    str((self.config or {}).get("auto_update_interval_s", 10 * 60)),
                )
            )
        except Exception:
            self._auto_update_interval_s = 10 * 60
        # Defaults: production PyPI. Installers set AGENT_AUTO_UPDATE_* for TestPyPI when using --test-pypi.
        self._auto_update_pypi_json_url = os.getenv(
            "AGENT_AUTO_UPDATE_JSON_URL",
            "https://pypi.org/pypi/mindfabric-agent/json",
        )
        self._auto_update_index_url = os.getenv("AGENT_AUTO_UPDATE_INDEX_URL", "https://pypi.org/simple/")
        self._auto_update_extra_index_url = os.getenv("AGENT_AUTO_UPDATE_EXTRA_INDEX_URL", "https://pypi.org/simple")
        self._auto_update_package = os.getenv("AGENT_AUTO_UPDATE_PACKAGE", "mindfabric-agent")

    def _bool_from_env_or_config(self, env_key: str, *, config_key: str, default: bool) -> bool:
        try:
            raw = os.getenv(env_key)
            if raw is not None:
                return str(raw).strip().lower() in ("1", "true", "yes", "y", "on")
        except Exception:
            pass
        try:
            if isinstance(self.config, dict) and config_key in self.config:
                return bool(self.config.get(config_key))
        except Exception:
            pass
        return bool(default)

    def _auto_update_log(self, level: str, message: str, force: bool = False) -> None:
        """
        Log auto-update messages with throttling.
        
        Args:
            level: Log level (info, warning, error)
            message: Log message
            force: If True, bypass throttling for critical messages
        """
        now = time.time()
        if not force and (now - self._auto_update_last_log_ts) < self._auto_update_log_interval_s:
            return
        if not force:
            self._auto_update_last_log_ts = now
        if level == "warning":
            logger.warning(message)
        elif level == "error":
            logger.error(message)
        elif level == "debug":
            logger.debug(message)
        else:
            logger.info(message)

    def _parse_version_key(self, v: str):
        """
        Best-effort PEP440-ish version key. Prefers packaging if present, otherwise falls back to tuple parsing.
        """
        try:
            from packaging.version import Version  # type: ignore
            return Version(v)
        except Exception:
            # Fallback: split by non-digits, keep numeric parts.
            parts = []
            cur = ""
            for ch in str(v):
                if ch.isdigit():
                    cur += ch
                else:
                    if cur:
                        parts.append(int(cur))
                        cur = ""
            if cur:
                parts.append(int(cur))
            return tuple(parts)

    def _get_installed_version(self) -> str:
        v = "unknown"
        try:
            try:
                from importlib.metadata import version as dist_version  # py3.8+
            except Exception:
                from importlib_metadata import version as dist_version  # type: ignore
            for dist_name in ("mindfabric-agent", "mindfabric_agent"):
                try:
                    v = dist_version(dist_name)
                    break
                except Exception:
                    pass
        except Exception:
            pass
        return v

    async def _fetch_latest_version(self) -> Optional[str]:
        try:
            # Add cache-busting parameter to avoid stale version info
            import time
            cache_buster = int(time.time())
            url_with_cache_bust = f"{self._auto_update_pypi_json_url}?t={cache_buster}"
            async with aiohttp.ClientSession() as session:
                async with session.get(url_with_cache_bust, timeout=aiohttp.ClientTimeout(total=15), headers={"Cache-Control": "no-cache"}) as r:
                    if r.status != 200:
                        # Offline / registry hiccup — not actionable as a warning every interval
                        self._auto_update_log("info", f"[AUTO_UPDATE] version check skipped: HTTP {r.status}")
                        return None
                    data = await r.json()
        except Exception as e:
            detail = (str(e) or "").strip() or type(e).__name__
            benign = isinstance(e, (aiohttp.ClientError, asyncio.TimeoutError))
            lvl = "info" if benign else "warning"
            self._auto_update_log(lvl, f"[AUTO_UPDATE] version check failed: {detail}")
            return None

        try:
            # First try to get version from info.version (most reliable for Test PyPI)
            info = (data or {}).get("info", {}) or {}
            info_version = info.get("version")
            if info_version:
                self._auto_update_log("info", f"[AUTO_UPDATE] Got version from info.version: {info_version}", force=False)
                return info_version
            
            # Fallback to releases if info.version is not available
            releases = (data or {}).get("releases", {}) or {}
            versions = list(releases.keys())
            if not versions:
                return None
            versions.sort(key=self._parse_version_key)
            latest_from_releases = versions[-1]
            self._auto_update_log("info", f"[AUTO_UPDATE] Got version from releases: {latest_from_releases}", force=False)
            return latest_from_releases
        except Exception as e:
            self._auto_update_log("warning", f"[AUTO_UPDATE] failed to parse version list: {e}")
            return None

    def _is_idle_for_update(self) -> bool:
        try:
            # Avoid restarting mid-command execution.
            # But allow update if only fast tasks are running (e.g., infrastructure_intelligence context snapshots).
            # Updated logic:
            # - Block update if tasks running for < 5 minutes (increased from 2 minutes)
            # - Allow update if tasks running for > 30 minutes (force update for long-running tasks)
            # - Allow update for infrastructure_intelligence (fast tasks)
            import time
            now = time.time()
            
            # Check for forced update: if last update was more than 24 hours ago, force update
            last_update_ts = getattr(self, '_last_successful_update_ts', 0)
            if last_update_ts > 0 and (now - last_update_ts) > 24 * 3600:  # 24 hours
                self._auto_update_log("info", "[AUTO_UPDATE] Forcing update - no update in 24 hours")
                return True
            
            # Check active_tasks first (more reliable than current_task)
            if self.active_tasks:
                if hasattr(self, 'active_task_meta') and self.active_task_meta:
                    for task_id, meta in self.active_task_meta.items():
                        plugin = meta.get('plugin', '')
                        started_ts = meta.get('started_ts', 0)
                        if started_ts > 0:
                            task_duration = now - started_ts
                            # Allow update for infrastructure_intelligence (fast)
                            if plugin == 'infrastructure_intelligence':
                                continue
                            # Force update if task running for > 30 minutes
                            if task_duration > 30 * 60:  # 30 minutes
                                self._auto_update_log("info", f"[AUTO_UPDATE] Allowing update - task {plugin} running for {task_duration/60:.1f} minutes")
                                return True
                            # Block update if task running for < 5 minutes (increased from 2 minutes)
                            if task_duration < 5 * 60:  # 5 minutes
                                self._auto_update_log("info", f"[AUTO_UPDATE] Blocking update - task '{plugin}' running for {task_duration:.1f}s (< 5 minutes)")
                                return False
                else:
                    # If we can't check metadata but have active_tasks, be conservative only if tasks are recent
                    # If active_tasks exists but we can't check metadata, assume tasks might be old and allow update
                    # (This is safer than blocking updates forever)
                    pass
            
            # If there's a current_task, check if it's a fast one
            if self.current_task is not None:
                # Check if all active tasks are fast (infrastructure_intelligence)
                if hasattr(self, 'active_task_meta') and self.active_task_meta:
                    all_fast = True
                    for task_id, meta in self.active_task_meta.items():
                        plugin = meta.get('plugin', '')
                        started_ts = meta.get('started_ts', 0)
                        # Only infrastructure_intelligence is considered "fast" for auto-update
                        if plugin != 'infrastructure_intelligence':
                            all_fast = False
                            if started_ts > 0:
                                task_duration = now - started_ts
                                # Force update if task running for > 30 minutes
                                if task_duration > 30 * 60:  # 30 minutes
                                    self._auto_update_log("info", f"[AUTO_UPDATE] Allowing update - task {plugin} running for {task_duration/60:.1f} minutes")
                                    return True
                                # Block update if task running for < 5 minutes (increased from 2 minutes)
                                if task_duration < 5 * 60:  # 5 minutes
                                    self._auto_update_log("info", f"[AUTO_UPDATE] Blocking update - task '{plugin}' running for {task_duration:.1f}s (< 5 minutes)")
                                    return False
                    # If all tasks are fast, allow update
                    if all_fast:
                        return True
                # If we can't check metadata but current_task exists, check if active_tasks is empty
                # If active_tasks is empty, current_task might be stale, allow update
                if not self.active_tasks:
                    return True
                # If we can't check metadata and have active_tasks, be conservative
                return False
        except Exception as e:
            self._auto_update_log("warning", f"[AUTO_UPDATE] _is_idle_for_update error: {e}")
        return True

    async def _attempt_auto_update(self) -> None:
        async with self._auto_update_lock:
            installed = self._get_installed_version()
            latest = await self._fetch_latest_version()
            # Force log version check (bypass throttling for visibility)
            self._auto_update_log("info", f"[AUTO_UPDATE] check: installed={installed}, latest={latest}", force=True)
            if not latest or installed in ("unknown", "", None):
                if not latest:
                    self._auto_update_log("info", f"[AUTO_UPDATE] no latest version found", force=True)
                if installed in ("unknown", "", None):
                    self._auto_update_log("info", f"[AUTO_UPDATE] installed version is unknown: {installed}", force=True)
                return
            self._auto_update_log("info", f"[AUTO_UPDATE] Proceeding to version comparison...", force=True)
            try:
                latest_key = self._parse_version_key(latest)
                installed_key = self._parse_version_key(installed)
                self._auto_update_log("info", f"[AUTO_UPDATE] version comparison: latest_key={latest_key}, installed_key={installed_key}", force=True)
                if latest_key <= installed_key:
                    self._auto_update_log("info", f"[AUTO_UPDATE] already up to date: {installed} >= {latest}", force=True)
                    return
                self._auto_update_log("info", f"[AUTO_UPDATE] Update needed: {installed} < {latest}", force=True)
            except Exception as e:
                # If comparison fails, be conservative and skip.
                import traceback
                self._auto_update_log("warning", f"[AUTO_UPDATE] version comparison failed: {e}\n{traceback.format_exc()}", force=True)
                return
            is_idle = self._is_idle_for_update()
            # Force log critical update status messages (bypass throttling)
            self._auto_update_log("info", f"[AUTO_UPDATE] is_idle={is_idle}, current_task={self.current_task is not None}, active_tasks={len(self.active_tasks) if self.active_tasks else 0}", force=True)
            if not is_idle:
                self._auto_update_log("info", f"[AUTO_UPDATE] update available ({installed} -> {latest}) but agent is busy; will retry later", force=True)
                self._auto_update_was_blocked = True  # Mark that update was blocked
                return

            py = getattr(__import__("sys"), "executable")
            cmd = [
                py, "-m", "pip", "install",
                "--disable-pip-version-check",
                "--no-input",
                "--upgrade",
                "--index-url", self._auto_update_index_url,
                "--extra-index-url", self._auto_update_extra_index_url,
                self._auto_update_package,
            ]
            # Save previous version for potential rollback
            self._previous_version_before_update = installed
            
            self._auto_update_log("info", f"[AUTO_UPDATE] updating {self._auto_update_package} {installed} -> {latest}")
            try:
                p = subprocess.run(cmd, check=False, capture_output=True, text=True)
            except PermissionError:
                self._auto_update_log(
                    "warning",
                    "[AUTO_UPDATE] permission denied during pip install. If running as a system service, run install with sudo or ensure venv is writable.",
                )
                return
            except Exception as e:
                self._auto_update_log("warning", f"[AUTO_UPDATE] pip install failed to start: {e}")
                return

            if int(getattr(p, "returncode", 1)) != 0:
                self._auto_update_log("warning", f"[AUTO_UPDATE] pip install failed (exit={p.returncode}); will retry later")
                if p.stderr:
                    self._auto_update_log("warning", f"[AUTO_UPDATE] pip install stderr: {p.stderr[:500]}")
                return

            # Verify update was successful by checking installed version
            try:
                import subprocess as _subprocess
                check_cmd = [py, "-m", "pip", "show", self._auto_update_package]
                check_result = _subprocess.run(check_cmd, capture_output=True, text=True, timeout=10)
                if check_result.returncode == 0:
                    # Parse version from pip show output
                    for line in check_result.stdout.split('\n'):
                        if line.startswith('Version:'):
                            installed_after = line.split(':', 1)[1].strip()
                            if installed_after != latest:
                                self._auto_update_log("warning", f"[AUTO_UPDATE] Version mismatch after install: expected {latest}, got {installed_after}")
                                # Attempt rollback
                                if self._rollback_enabled and self._previous_version_before_update:
                                    await self._rollback_update(self._previous_version_before_update)
                                return
                            break
            except Exception as e:
                self._auto_update_log("warning", f"[AUTO_UPDATE] Failed to verify installed version: {e}")
                # If we can't verify, attempt rollback to be safe
                if self._rollback_enabled and self._previous_version_before_update:
                    self._auto_update_log("warning", f"[AUTO_UPDATE] Cannot verify update, rolling back to {self._previous_version_before_update}")
                    await self._rollback_update(self._previous_version_before_update)
                    return

            # Restart self to load the new code.
            try:
                import sys as _sys
                self._auto_update_log("info", "[AUTO_UPDATE] update installed; restarting agent process")
                # Use module execution to avoid relying on the console script path.
                os.execv(_sys.executable, [_sys.executable, "-m", "cli", *_sys.argv[1:]])
            except Exception as e:
                self._auto_update_log("warning", f"[AUTO_UPDATE] update installed but restart failed: {e}")
                # Attempt rollback if restart fails
                if self._rollback_enabled and self._previous_version_before_update:
                    self._auto_update_log("warning", f"[AUTO_UPDATE] Restart failed, rolling back to {self._previous_version_before_update}")
                    await self._rollback_update(self._previous_version_before_update)

    async def _rollback_update(self, previous_version: str) -> None:
        """
        Rollback to previous version if update fails or causes issues.
        
        Args:
            previous_version: Version to rollback to
        """
        if not previous_version or previous_version in ("unknown", "", None):
            self._auto_update_log("warning", "[AUTO_UPDATE] Cannot rollback: no previous version stored")
            return
        
        self._auto_update_log("warning", f"[AUTO_UPDATE] Attempting rollback to version {previous_version}")
        
        py = getattr(__import__("sys"), "executable")
        rollback_cmd = [
            py, "-m", "pip", "install",
            "--disable-pip-version-check",
            "--no-input",
            f"{self._auto_update_package}=={previous_version}",
            "--index-url", self._auto_update_index_url,
            "--extra-index-url", self._auto_update_extra_index_url,
        ]
        
        try:
            rollback_result = subprocess.run(rollback_cmd, check=False, capture_output=True, text=True, timeout=120)
            if rollback_result.returncode == 0:
                self._auto_update_log("info", f"[AUTO_UPDATE] Successfully rolled back to version {previous_version}")
                # Clear previous version after successful rollback
                self._previous_version_before_update = None
                # Restart to load rolled-back version
                import sys as _sys
                self._auto_update_log("info", "[AUTO_UPDATE] Restarting agent with rolled-back version")
                os.execv(_sys.executable, [_sys.executable, "-m", "cli", *_sys.argv[1:]])
            else:
                self._auto_update_log("error", f"[AUTO_UPDATE] Rollback failed (exit={rollback_result.returncode}): {rollback_result.stderr[:500] if rollback_result.stderr else 'unknown error'}")
        except Exception as e:
            self._auto_update_log("error", f"[AUTO_UPDATE] Rollback failed with exception: {e}")

    async def _auto_update_loop(self) -> None:
        # Small initial delay to avoid fighting with startup/registration.
        await asyncio.sleep(10)
        while not self._stop:
            try:
                if not self._auto_update_enabled:
                    await asyncio.sleep(5)
                    continue
                now = time.time()
                if (now - self._auto_update_last_check_ts) < float(self._auto_update_interval_s):
                    await asyncio.sleep(5)
                    continue
                self._auto_update_last_check_ts = now
                await self._attempt_auto_update()
                # Reset blocked flag after successful check (even if update was skipped)
                if self._auto_update_was_blocked:
                    self._auto_update_was_blocked = False
            except asyncio.CancelledError:
                return
            except Exception as e:
                self._auto_update_log("warning", f"[AUTO_UPDATE] loop error: {e}")
            # Sleep a bit so we can react to stop quickly even with long intervals.
            await asyncio.sleep(5)

    def _cleanup_hung_subprocesses(self) -> int:
        """
        Find and kill hung plugin subprocesses (plugin_subprocess_entrypoint).
        
        Returns:
            Number of processes killed
        """
        if not psutil:
            return 0
        
        killed_count = 0
        try:
            current_pid = os.getpid()
            current_process = psutil.Process(current_pid)
            
            # Find all processes matching plugin_subprocess_entrypoint
            # Check by both PPID (parent process) and cmdline for better detection
            for proc in psutil.process_iter(['pid', 'ppid', 'name', 'cmdline', 'create_time']):
                try:
                    if proc.info['pid'] == current_pid:
                        continue
                    
                    # Check 1: Is this a child process of our agent?
                    is_child = proc.info.get('ppid') == current_pid
                    
                    # Check 2: Does cmdline contain plugin_subprocess_entrypoint?
                    cmdline = proc.info.get('cmdline', [])
                    is_entrypoint = False
                    if cmdline:
                        for arg in cmdline:
                            if isinstance(arg, str) and 'plugin_subprocess_entrypoint' in arg:
                                is_entrypoint = True
                                break
                    
                    # Accept if either condition is true (child process OR entrypoint in cmdline)
                    if not (is_child or is_entrypoint):
                        continue
                    
                    # Check process age
                    create_time = proc.info.get('create_time', 0)
                    if create_time > 0:
                        age_seconds = time.time() - create_time
                        if age_seconds > self._subprocess_max_age_s:
                            try:
                                logger.warning(
                                    f"[SUBPROCESS_CLEANUP] Killing hung subprocess PID={proc.info['pid']} "
                                    f"(age={age_seconds/60:.1f} minutes, max={self._subprocess_max_age_s/60:.1f} minutes)"
                                )
                                proc.kill()
                                killed_count += 1
                            except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                                logger.debug(f"[SUBPROCESS_CLEANUP] Could not kill PID={proc.info['pid']}: {e}")
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    # Process already gone or we don't have permission
                    continue
                except Exception as e:
                    logger.debug(f"[SUBPROCESS_CLEANUP] Error checking process: {e}")
                    continue
        except Exception as e:
            logger.warning(f"[SUBPROCESS_CLEANUP] Error during cleanup: {e}")
        
        if killed_count > 0:
            logger.info(f"[SUBPROCESS_CLEANUP] Cleaned up {killed_count} hung subprocess(es)")
        
        return killed_count

    async def _subprocess_cleanup_loop(self) -> None:
        """
        Periodic cleanup loop for hung plugin subprocesses.
        Runs every _subprocess_cleanup_interval_s seconds.
        """
        # Small initial delay to avoid interfering with startup
        await asyncio.sleep(30)
        while not self._stop:
            try:
                now = time.time()
                if (now - self._subprocess_cleanup_last_check_ts) < self._subprocess_cleanup_interval_s:
                    await asyncio.sleep(10)
                    continue
                
                self._subprocess_cleanup_last_check_ts = now
                # Run cleanup in thread to avoid blocking event loop
                await asyncio.to_thread(self._cleanup_hung_subprocesses)
            except asyncio.CancelledError:
                return
            except Exception as e:
                logger.warning(f"[SUBPROCESS_CLEANUP] Loop error: {e}")
            # Sleep a bit so we can react to stop quickly
            await asyncio.sleep(10)

    async def _db_cleanup_loop(self) -> None:
        """
        Periodic cleanup loop for old SQLite databases (IOC Scanner, OSINT Finder).
        Runs once per day to avoid spam.
        """
        # Initial delay to avoid interfering with startup
        await asyncio.sleep(300)  # 5 minutes
        while not self._stop:
            try:
                now = time.time()
                if (now - self._db_cleanup_last_run_ts) < self._db_cleanup_interval_s:
                    await asyncio.sleep(3600)  # Check every hour
                    continue
                self._db_cleanup_last_run_ts = now
                # Run cleanup in thread to avoid blocking event loop
                from utils.cleanup_utils import run_periodic_cleanup
                await asyncio.to_thread(run_periodic_cleanup, ioc_max_age_days=3, osint_max_age_days=7, fim_max_age_days=30, quiet=True)
            except asyncio.CancelledError:
                return
            except Exception as e:
                logger.warning(f"[DB_CLEANUP] loop error: {e}")
            await asyncio.sleep(3600)  # Check every hour

    def _log_ws_not_ready(self, message: str, diag_extra: Optional[dict] = None) -> None:
        """
        Throttle repeated "WS not ready" messages to avoid filling /var/log/mindfabric-agent/error.log
        (and consequently backend System Logs) with duplicates.
        """
        try:
            self._ws_diag_last_not_ready = self._build_ws_diag_snapshot(
                event="ws_not_ready",
                extra=diag_extra if isinstance(diag_extra, dict) else None,
            )
        except Exception:
            # Never break caller paths for diagnostics.
            pass
        now = time.time()
        if (now - self._ws_not_ready_last_log_ts) >= self._ws_not_ready_log_interval_s:
            suppressed = self._ws_not_ready_suppressed
            self._ws_not_ready_last_log_ts = now
            self._ws_not_ready_suppressed = 0
            if suppressed:
                logger.warning(f"{message} (suppressed {suppressed} similar messages)")
            else:
                logger.warning(message)
        else:
            self._ws_not_ready_suppressed += 1

    async def _request_reconnect(self, reason: str) -> None:
        """
        Best-effort: force the current WS connection to close so the outer run() loop reconnects.
        This is critical for large chunked payloads: if the transport is half-closing, retries on the
        same socket frequently fail with 'Cannot write to closing transport'.
        """
        now = time.time()
        if (now - self._last_reconnect_request_ts) < self._reconnect_request_min_interval:
            return
        self._last_reconnect_request_ts = now
        try:
            self._ws_diag_last_reconnect_reason = str(reason)[:500] if reason is not None else None
            self._ws_diag_last_reconnect_request_ts = now
        except Exception:
            pass
        try:
            if self._ws and (not self._ws.closed):
                logger.warning(f"[WS] Requesting reconnect: {reason}")
                # Do not await close() here: when the transport is already half-closing,
                # awaiting the close handshake can stall the event loop and prevent reconnect.
                try:
                    asyncio.create_task(self._ws.close(code=1001, message=b"reconnect"))
                except Exception:
                    # Fallback to best-effort await with timeout
                    try:
                        await asyncio.wait_for(self._ws.close(code=1001, message=b"reconnect"), timeout=1.0)
                    except Exception:
                        pass
        except Exception as e:
            logger.debug(f"[WS] Failed to request reconnect ({reason}): {e}")

    async def run(self):
        # Start auto-update loop once (if enabled).
        if self._auto_update_enabled and self._auto_update_task is None:
            try:
                self._auto_update_task = asyncio.create_task(self._auto_update_loop())
            except Exception:
                self._auto_update_task = None
        
        # Start subprocess cleanup loop (always enabled to prevent hung processes)
                if self._subprocess_cleanup_task is None:
                    try:
                        self._subprocess_cleanup_task = asyncio.create_task(self._subprocess_cleanup_loop())
                    except Exception:
                        self._subprocess_cleanup_task = None
                
                # Start database cleanup loop
                if self._db_cleanup_task is None:
                    try:
                        self._db_cleanup_task = asyncio.create_task(self._db_cleanup_loop())
                    except Exception:
                        self._db_cleanup_task = None
        
        while not self._stop:
            try:
                headers = {
                    "access-key": self.access_key
                }
                # Добавляем agent-id только если он не None
                if self.agent_id:
                    headers["agent-id"] = self.agent_id
                proxy = self.ws_proxy_url if self.ws_proxy_enabled and self.ws_proxy_url else None
                if proxy:
                    logger.info(f"[PROXY MODE] Connecting to WS via proxy: {proxy}")
                else:
                    logger.info("Connecting to WS without proxy.")
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(
                        self.ws_url,
                        headers=headers,
                        proxy=proxy
                    ) as ws:
                        self._ws_generation += 1
                        self._ws = ws
                        try:
                            self._ws_diag_last_success_ts = time.time()
                        except Exception:
                            pass
                        # IMPORTANT:
                        # Keep TaskQueue running across WS reconnects so long-running plugins (e.g. asset_discovery)
                        # are not cancelled when the socket drops. Results will be queued and resent after reconnect.
                        if not self.task_queue:
                            self.task_queue = TaskQueue(
                                self.registry,
                                self,  # pass WebSocketAgentClient (not raw ws)
                                on_result=self.on_task_result,
                                active_tasks=self.active_tasks,
                                stealth_mode=self.stealth_mode,
                                allow_remote_shell=self.allow_remote_shell
                            )
                            await self.task_queue.start()
                        await self.register_agent()
                        # Ждём registration_ack и сохраняем session_token и agent_id
                        while True:
                            msg = await ws.receive()
                            if msg.type == aiohttp.WSMsgType.TEXT:
                                try:
                                    self._touch_rx_ts()
                                except Exception:
                                    pass
                                data = json.loads(msg.data)
                                if data.get("type") == "registration_ack" and data.get("status") == "ok":
                                    # Сохраняем agent_id, если он был прислан бэкендом
                                    if "agent_id" in data:
                                        agent_id = data["agent_id"]
                                        self.agent_id = agent_id
                                        # Сохраняем agent_id в локальный файл (в нескольких местах для надежности)
                                        agent_id_files = [
                                            Path("/app/.agent_id"),  # В рабочей директории
                                            Path("/usr/local/lib/python3.11/site-packages/.agent_id"),  # В site-packages
                                            Path(__file__).parent.parent.parent / ".agent_id"  # В корне пакета
                                        ]
                                        for agent_id_file in agent_id_files:
                                            try:
                                                agent_id_file.parent.mkdir(parents=True, exist_ok=True)
                                                agent_id_file.write_text(agent_id)
                                                logger.info(f"Saved agent_id {agent_id} to {agent_id_file}")
                                            except Exception as e:
                                                logger.warning(f"Failed to save agent_id to {agent_id_file}: {e}")
                                    self.session_token = data.get("session_token")
                                    # Never log token values (even prefixes).
                                    logger.info("[REGISTRATION] session_token received and set")
                                    # Reset reconnect backoff on successful registration.
                                    self._reconnect_backoff_s = float(RECONNECT_DELAY)
                                    if self.debug_mode:
                                        # Never log token values.
                                        logger.info(f"Registration OK. Agent ID: {self.agent_id}")
                                    else:
                                        print(f"✅ Agent '{self.agent_id}' successfully connected and ready to execute commands!")
                                    # Отправляем результаты из очереди после переподключения
                                    # Делаем небольшую задержку, чтобы убедиться, что соединение стабильно
                                    await asyncio.sleep(1)
                                    try:
                                        await self._resend_pending_results()
                                    except Exception as resend_error:
                                        logger.error(f"Error resending pending results after registration: {resend_error}")
                                    if self.pending_results:
                                        logger.info(f"Have {len(self.pending_results)} pending results, will resend after registration")
                                    await asyncio.sleep(2)
                                    await self._resend_pending_results()
                                    break
                                elif data.get("type") == "registration_ack" and data.get("status") == "error":
                                    # Ошибка аутентификации - показываем всегда, независимо от debug режима
                                    error_msg = data.get("msg", "Registration failed")
                                    hint = (data.get("hint") or "").strip()
                                    err_code = (data.get("error_code") or "").strip()
                                    print("❌ Authentication failed")
                                    print(f"   {error_msg}")
                                    if hint:
                                        print(f"   → {hint}")
                                    if err_code:
                                        print(f"   (code: {err_code})")
                                    if self.debug_mode:
                                        logger.error(f"Registration failed: {data}")
                                    # Не завершаем агент, а переподключаемся
                                    logger.warning(f"Will retry registration in {RECONNECT_DELAY}s...")
                                    await asyncio.sleep(RECONNECT_DELAY)
                                    break  # Выходим из внутреннего цикла, чтобы переподключиться
                                else:
                                    logger.error(f"Registration failed: {data}")
                                    # Не завершаем агент, а переподключаемся
                                    logger.warning(f"Will retry registration in {RECONNECT_DELAY}s...")
                                    await asyncio.sleep(RECONNECT_DELAY)
                                    break  # Выходим из внутреннего цикла, чтобы переподключиться
                            elif msg.type == aiohttp.WSMsgType.ERROR:
                                exc = None
                                try:
                                    exc = ws.exception()
                                except Exception:
                                    pass
                                logger.error(
                                    f"WebSocket error during registration: {repr(exc) if exc else None}"
                                )
                                # NEVER `return` here: that exits `run()` and terminates the process with
                                # no reconnect (asyncio.run completes). Raise so the outer `except` in
                                # `run()` applies backoff and reconnects — same as post-sleep / flaky proxy.
                                raise ConnectionError("WebSocket error during registration")
                            elif msg.type == aiohttp.WSMsgType.CLOSE:
                                logger.warning(
                                    "WebSocket closed during registration wait; will reconnect"
                                )
                                raise ConnectionError("WebSocket closed before registration_ack")
                        # После успешной регистрации запускаем heartbeat, listen и наблюдение за входом
                        recv_gen = self._ws_generation
                        tasks = [
                            asyncio.create_task(self.heartbeat()),
                            asyncio.create_task(self.listen()),
                            asyncio.create_task(self._recv_idle_watchdog(recv_gen)),
                        ]
                        # Agent logs -> backend System Logs
                        # Default ON (can be disabled via AGENT_LOG_REPORTER_ENABLED=0/false/no).
                        try:
                            raw = os.getenv("AGENT_LOG_REPORTER_ENABLED")
                            if raw is None:
                                enabled = True
                            else:
                                enabled = str(raw).strip().lower() in ("1", "true", "yes")
                        except Exception:
                            enabled = True
                        if enabled:
                            tasks.append(asyncio.create_task(self._agent_log_reporter_loop()))
                        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                        for t in tasks:
                            t.cancel()
                        # Do NOT shutdown TaskQueue here: a transient WS drop must not cancel in-flight plugin runs.
                        # IMPORTANT: Do not clear session_token here.
                        # In-flight chunked sends may still be running; clearing token mid-send causes
                        # commands_output chunks to fail with "requires session_token".
                        # Token will be refreshed/overwritten on the next successful registration_ack.
                        self._ws = None
            except Exception as e:
                error_msg = str(e)
                # Store structured connect error details for later correlation in System Logs.
                try:
                    now_ts = time.time()
                    err: dict[str, Any] = {
                        "class": type(e).__name__,
                        "message": str(e)[:2000],
                    }
                    st = getattr(e, "status", None)
                    if isinstance(st, int):
                        err["http_status"] = st
                    # aiohttp connector errors often wrap OSError with errno
                    eno = getattr(e, "errno", None)
                    if isinstance(eno, int):
                        err["errno"] = eno
                    self._ws_diag_last_connect_error = err
                    self._ws_diag_last_connect_error_ts = now_ts
                except Exception:
                    pass
                # Exponential backoff with jitter to avoid thundering herd and log spam
                delay = min(self._reconnect_backoff_s, self._reconnect_backoff_max_s)
                jitter = random.uniform(0.0, min(1.0, max(0.1, delay * 0.1)))
                sleep_s = delay + jitter

                now = time.time()
                should_log = (now - self._connect_error_last_log_ts) >= self._connect_error_log_interval_s
                if should_log:
                    if self._connect_error_suppressed:
                        logger.warning(f"[WS] Suppressed {self._connect_error_suppressed} repeated connection errors.")
                        self._connect_error_suppressed = 0
                    self._connect_error_last_log_ts = now

                    if "502" in error_msg:
                        # Single-line message (avoid duplicating follow-up "Please check..." line).
                        logger.error(f"Backend server error (502): The backend server is not responding or is down. URL: {self.ws_url}")
                    elif "404" in error_msg:
                        logger.error(f"Endpoint not found (404): The WebSocket endpoint does not exist. URL: {self.ws_url}")
                        logger.error("Please check if the backend URL is correct.")
                    elif "401" in error_msg or "403" in error_msg:
                        logger.error(f"Authentication failed ({error_msg}): Invalid access key or agent ID.")
                        logger.error(f"Agent ID: {self.agent_id}")
                        logger.error("Please check your access key and agent ID.")
                    elif "Connection refused" in error_msg or "Connection reset" in error_msg:
                        logger.error(f"Connection failed: Cannot connect to backend server at {self.ws_url}")
                        logger.error("Please check if the backend server is running and the URL is correct.")
                    else:
                        logger.error(f"WebSocket error: {error_msg}")

                    logger.warning(f"[WS] Reconnecting in ~{sleep_s:.1f}s... URL: {self.ws_url}")
                else:
                    self._connect_error_suppressed += 1

                # Increase backoff for next time (cap)
                self._reconnect_backoff_s = min(self._reconnect_backoff_s * 2.0, self._reconnect_backoff_max_s)
                await asyncio.sleep(sleep_s)

    def _sanitize_proxy(self, raw: Optional[str]) -> Optional[str]:
        try:
            if not raw:
                return None
            u = urlparse(str(raw))
            host = u.hostname or ""
            if not host:
                return "***"
            scheme = u.scheme or "http"
            port = f":{u.port}" if u.port else ""
            return f"{scheme}://{host}{port}"
        except Exception:
            return "***"

    def _approx_size(self, obj: Any, depth: int = 1) -> int:
        """
        Approximate size in bytes without serializing entire payloads.
        Used only for diagnostics (never exact).
        """
        try:
            if obj is None:
                return 0
            if isinstance(obj, (bytes, bytearray)):
                return len(obj)
            if isinstance(obj, str):
                return len(obj.encode("utf-8", errors="ignore"))
            if isinstance(obj, (int, float, bool)):
                return 8
            if isinstance(obj, dict):
                if depth <= 0:
                    return 64
                n = 0
                # cap to avoid O(n) for huge dicts
                for i, (k, v) in enumerate(obj.items()):
                    if i >= 50:
                        n += 128
                        break
                    n += self._approx_size(k, depth - 1)
                    n += self._approx_size(v, depth - 1)
                return n
            if isinstance(obj, (list, tuple)):
                if depth <= 0:
                    return 64
                n = 0
                for i, v in enumerate(obj):
                    if i >= 50:
                        n += 128
                        break
                    n += self._approx_size(v, depth - 1)
                return n
            # Fallback
            s = repr(obj)
            return len(s.encode("utf-8", errors="ignore"))
        except Exception:
            return 0

    def _pending_results_bytes_estimate(self) -> int:
        try:
            total = 0
            for r in (self.pending_results or [])[:200]:
                if isinstance(r, dict):
                    msg = r.get("msg")
                    total += self._approx_size(msg, depth=1)
            if isinstance(self.pending_results, list) and len(self.pending_results) > 200:
                total += 1024
            return total
        except Exception:
            return 0

    def _build_ws_diag_snapshot(self, event: str, extra: Optional[dict] = None) -> dict:
        """
        Minimal-but-useful snapshot attached to WS-related logs.
        Must be safe to persist in backend System Logs (no secrets).
        """
        ws = getattr(self, "_ws", None)
        proxy_cfg = self.ws_proxy_url if (self.ws_proxy_enabled and self.ws_proxy_url) else None
        snap: dict[str, Any] = {
            "event": str(event)[:100],
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "ws_url": str(self.ws_url),
            "ws_generation": int(getattr(self, "_ws_generation", 0) or 0),
            "ws_present": bool(ws is not None),
            "ws_closed": bool(getattr(ws, "closed", True)) if ws is not None else True,
            "ws_close_code": getattr(ws, "close_code", None) if ws is not None else None,
            "token_present": bool(self.session_token is not None),
            "proxy_enabled": bool(self.ws_proxy_enabled),
            "proxy_configured": self._sanitize_proxy(proxy_cfg),
            "env_proxy": {
                "http_proxy_set": bool(os.getenv("HTTP_PROXY") or os.getenv("http_proxy")),
                "https_proxy_set": bool(os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")),
                "no_proxy_set": bool(os.getenv("NO_PROXY") or os.getenv("no_proxy")),
            },
            "reconnect_backoff_s": float(getattr(self, "_reconnect_backoff_s", RECONNECT_DELAY) or RECONNECT_DELAY),
            "last_reconnect_reason": str(self._ws_diag_last_reconnect_reason)[:500] if self._ws_diag_last_reconnect_reason else None,
            "last_reconnect_request_at": (
                time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self._ws_diag_last_reconnect_request_ts))
                if self._ws_diag_last_reconnect_request_ts
                else None
            ),
            "last_success_at": (
                time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self._ws_diag_last_success_ts))
                if self._ws_diag_last_success_ts
                else None
            ),
            "last_connect_error": self._ws_diag_last_connect_error,
            "last_connect_error_at": (
                time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self._ws_diag_last_connect_error_ts))
                if self._ws_diag_last_connect_error_ts
                else None
            ),
            "pending_results": {
                "count": int(len(self.pending_results or [])),
                "bytes_est": int(self._pending_results_bytes_estimate()),
            },
            "ws_not_ready_suppressed": int(getattr(self, "_ws_not_ready_suppressed", 0) or 0),
            "connect_error_suppressed": int(getattr(self, "_connect_error_suppressed", 0) or 0),
            "last_send": self._ws_diag_last_send,
            "last_send_at": (
                time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(self._ws_diag_last_send_ts))
                if self._ws_diag_last_send_ts
                else None
            ),
            "recv_idle_timeout_s": float(getattr(self, "_recv_idle_timeout_s", DEFAULT_RECV_IDLE_TIMEOUT_S) or DEFAULT_RECV_IDLE_TIMEOUT_S),
            "last_rx_age_s": (
                round(time.time() - float(self._last_rx_ts), 1)
                if getattr(self, "_last_rx_ts", None) is not None
                else None
            ),
        }
        if isinstance(extra, dict) and extra:
            # Keep extra shallow + safe
            try:
                snap["extra"] = {k: v for k, v in list(extra.items())[:30]}
            except Exception:
                pass
        return snap

    def _ws_debug_state(self) -> str:
        """
        Best-effort snapshot of current aiohttp websocket state for debugging disconnects.
        Never includes secrets.
        """
        try:
            ws = getattr(self, "_ws", None)
            if not ws:
                return "ws=None"
            close_code = getattr(ws, "close_code", None)
            closed = getattr(ws, "closed", None)
            exc = None
            try:
                exc = ws.exception()
            except Exception:
                exc = None
            return f"ws.closed={closed} ws.close_code={close_code} ws.exc={repr(exc) if exc else None}"
        except Exception:
            return "ws_state_unavailable"

    async def register_agent(self):
        msg = self.build_registration_message()
        if self.debug_mode:
            logger.debug(f"Registration message: {json.dumps(msg, indent=2, default=str)}")
        await self._send(msg)
        logger.info("Registration message sent.")

    def build_registration_message(self):
        # Версия агента: берём из установленного пакета, чтобы UI показывал реальный version.
        # Fallback оставляем на случай запуска из исходников без установленного dist.
        version = "unknown"
        try:
            try:
                from importlib.metadata import version as dist_version  # py3.8+
            except Exception:
                from importlib_metadata import version as dist_version  # type: ignore

            for dist_name in ("mindfabric-agent", "mindfabric_agent"):
                try:
                    version = dist_version(dist_name)
                    break
                except Exception:
                    pass
        except Exception:
            pass
        os_name = platform.system().lower()
        hostname = socket.gethostname()
        plugins_with_versions = self.registry.get_plugins_with_versions()
        tags = ["default"]  # или из конфига
        
        # Получаем agent_name из конфига или используем hostname
        agent_name = None
        if isinstance(self.config, dict):
            agent_name = self.config.get("agent_name")
        else:
            agent_name = getattr(self.config, "agent_name", None)
        
        # Если agent_name не указан, используем hostname
        if not agent_name:
            agent_name = hostname
        
        # Собираем расширенную системную информацию
        system_info = {
            "os": os_name,
            "hostname": hostname
        }
        
        try:
            primary_ip, private_ip = _registration_primary_ipv4()
            if primary_ip:
                system_info["ip_address"] = primary_ip
            if private_ip:
                system_info.setdefault("extra_info", {})
                if isinstance(system_info["extra_info"], dict):
                    system_info["extra_info"]["private_ip_address"] = private_ip
        except Exception:
            system_info["ip_address"] = None
            
        try:
            # CPU информация
            # Agent should report CPU load (percent), not CPU model.
            # NOTE: psutil has no cpu_info() API; the old code always fell back to "Unknown CPU".
            # A short interval gives a more meaningful value than the first instantaneous sample.
            cpu_pct = psutil.cpu_percent(interval=0.2)
            # Keep backward compatibility with backend schema (cpu is a string field).
            system_info["cpu"] = f"{int(round(cpu_pct))}%"
        except:
            system_info["cpu"] = "Unknown CPU"
            
        try:
            # Memory информация
            memory = psutil.virtual_memory()
            total_bytes = int(getattr(memory, "total", 0) or 0)
            if total_bytes >= 1024**3:
                system_info["memory"] = f"{total_bytes // (1024**3)}GB"
            else:
                system_info["memory"] = f"{max(1, total_bytes // (1024**2))}MB"
        except:
            system_info["memory"] = None
            
        try:
            # Uptime
            uptime_seconds = time.time() - psutil.boot_time()
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            if days > 0:
                system_info["uptime"] = f"{days} days, {hours}:{minutes:02d}"
            else:
                system_info["uptime"] = f"{hours}:{minutes:02d}"
        except:
            system_info["uptime"] = None
            
        try:
            # User
            users = psutil.users()
            if users:
                system_info["user"] = users[0].name
            else:
                system_info["user"] = None
        except:
            system_info["user"] = None
            
        try:
            # Kernel и Architecture
            system_info["kernel"] = platform.release()
            system_info["architecture"] = platform.machine()
        except:
            system_info["kernel"] = None
            system_info["architecture"] = None
        
        # Удаляем все None значения из system_info для корректной сериализации JSON
        system_info_clean = {k: v for k, v in system_info.items() if v is not None}

        # Persist agent security-relevant runtime flags in extra_info so backend can store them in DB.
        # This makes it visible which agents allow ad-hoc remote shell commands.
        capability_summary = collect_runtime_capabilities()
        extra_info = system_info_clean.get("extra_info")
        if not isinstance(extra_info, dict):
            extra_info = {}
        extra_info["allow_remote_shell"] = bool(self.allow_remote_shell)
        extra_info["stealth_mode"] = bool(self.stealth_mode)
        extra_info["capability_summary"] = capability_summary
        system_info_clean["extra_info"] = extra_info
        
        # agent_id отправляется только если он уже был получен от бэкенда
        # При первой регистрации agent_id будет None, бэкенд сгенерирует UUID
        # Получаем agent_name из конфига или используем hostname
        agent_name = self.config.get("agent_name") if isinstance(self.config, dict) else getattr(self.config, "agent_name", None)
        if not agent_name:
            agent_name = hostname
        
        msg = {
            "type": "agent_registration",
            "version": version,
            "os": os_name,
            "hostname": hostname,
            "name": agent_name,  # Отправляем agent_name
            "tags": tags,
            "access_key": self.access_key,
            "heartbeat_interval": HEARTBEAT_INTERVAL,
            "plugins": plugins_with_versions,
            "system_info": system_info_clean,
            "stealth_mode": bool(self.stealth_mode),
        }
        
        # Добавляем agent_id только если он уже есть (после первой регистрации)
        if self.agent_id:
            msg["agent_id"] = self.agent_id
        
        return msg

    def _msg_with_token(self, msg: dict, token: Optional[str] = None) -> dict:
        """
        Добавляет session_token во все исходящие сообщения.

        Важно: при реконнекте `run()` может временно терять сокет/состояние, а in-flight chunked send
        всё ещё может продолжаться. Поэтому мы поддерживаем `token` override (snapshot) для стабильной
        отправки всех чанков одним и тем же токеном.
        """
        msg_type = msg.get("type", "unknown")
        effective = token or self.session_token
        if effective:
            msg["session_token"] = effective
            logger.debug(f"[_MSG_WITH_TOKEN] Added session_token to message type {msg_type}")
        else:
            logger.warning(f"[_MSG_WITH_TOKEN] No session_token available for message type {msg_type}")
        return msg

    async def heartbeat(self):
        while True:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            metrics = {}
            try:
                metrics["cpu"] = float(psutil.cpu_percent())
            except Exception:
                pass
            try:
                metrics["mem"] = float(psutil.virtual_memory().percent)
            except Exception:
                pass
            try:
                metrics["disk_free"] = int(psutil.disk_usage("/").free // (1024 * 1024))
            except Exception:
                pass
            # Network throughput (best-effort)
            try:
                now = time.time()
                cur = psutil.net_io_counters()
                prev = self._last_net_io
                prev_ts = self._last_net_ts
                if prev and prev_ts and now > prev_ts:
                    dt = now - prev_ts
                    rx_bps = (float(cur.bytes_recv) - float(prev.bytes_recv)) / dt
                    tx_bps = (float(cur.bytes_sent) - float(prev.bytes_sent)) / dt
                    # Backend expects net_rx_bps / net_tx_bps (also supports net_rx/net_tx)
                    metrics["net_rx_bps"] = max(0.0, rx_bps)
                    metrics["net_tx_bps"] = max(0.0, tx_bps)
                self._last_net_io = cur
                self._last_net_ts = now
            except Exception:
                # Never fail heartbeat if net counters are unavailable
                pass
            hb = {
                "type": "heartbeat",
                "timestamp": int(time.time()),
                "agent_id": self.agent_id,
                "session_token": self.session_token,
                "status": "online",
                "current_task": self.current_task,
                "metrics": metrics
            }
            # Keep runtime capability summary fresh even without full re-registration.
            try:
                hb["system_info"] = {
                    "extra_info": {
                        "allow_remote_shell": bool(self.allow_remote_shell),
                        "stealth_mode": bool(self.stealth_mode),
                        "capability_summary": collect_runtime_capabilities(),
                    }
                }
            except Exception:
                # Heartbeat must remain lightweight and resilient.
                pass
            try:
                await self._send(self._msg_with_token(hb))
                logger.debug("Heartbeat sent.")
            except Exception as e:
                # Heartbeat must never crash the whole WS session; treat send failure as a reconnect signal.
                logger.warning(f"[HEARTBEAT] Failed to send heartbeat: {e}. Will request reconnect.")
                await self._request_reconnect("heartbeat_send_failed")
                continue
            # После heartbeat проверяем, можно ли отправить результаты из очереди
            if self.pending_results and self.session_token:
                await asyncio.sleep(0.3)
                await self._resend_pending_results()
            if self.pending_partial_results and self.session_token:
                await asyncio.sleep(0.1)
                await self._resend_pending_partial_results()

    async def send_command_ack(self, command_id, status="accepted"):
        # command_id is required for backend to correlate the ack
        if not command_id:
            logger.warning(f"[ACK] Missing command_id for status={status}; skipping ack send")
            return

        msg = {
            "type": "command_ack",
            "command_id": command_id,
            "status": status,
            "received_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "agent_id": self.agent_id,
        }

        try:
            await self._send(self._msg_with_token(msg))
        except Exception as e:
            # Critical: never drop/abort command handling because the WS is half-closing.
            # Queue the ack for resend after reconnect/registration, same as command outputs.
            logger.warning(f"[ACK] Failed to send command_ack (status={status}) for command {command_id}: {e}. Queuing for retry.")
            try:
                # Deduplicate by (command_id, status, type)
                self.pending_results = [
                    r for r in self.pending_results
                    if not (
                        r.get("command_id") == command_id and
                        isinstance(r.get("msg"), dict) and
                        r["msg"].get("type") == "command_ack" and
                        r["msg"].get("status") == status
                    )
                ]
                self.pending_results.append({"command_id": command_id, "msg": msg, "timestamp": time.time()})
            except Exception:
                # If pending queue is corrupted/unavailable, at least request reconnect.
                pass
            try:
                await self._request_reconnect(f"command_ack_send_failed status={status} command={command_id}")
            except Exception:
                pass

    def _extract_partial_local_ack(self, metadata):
        if not isinstance(metadata, dict):
            return {}, None
        cleaned = dict(metadata)
        local_ack = cleaned.pop("_agent_ack", None)
        if not isinstance(local_ack, dict):
            local_ack = None
        return cleaned, local_ack

    def _queue_partial_result_for_ack(self, *, batch_id, command_id, msg, ack_timeout_s, local_ack, sent=False):
        if not batch_id:
            return
        try:
            existing = self.pending_partial_results.get(batch_id) or {}
            self.pending_partial_results[batch_id] = {
                "command_id": command_id,
                "msg": msg,
                "timestamp": float(existing.get("timestamp") or time.time()),
                "last_send_ts": time.time() if sent else 0.0,
                "ack_timeout_s": max(5.0, float(ack_timeout_s or self._pending_partial_ack_timeout_s)),
                "local_ack": local_ack if isinstance(local_ack, dict) else existing.get("local_ack"),
                "failures": int(existing.get("failures", 0) or 0),
            }
        except Exception as e:
            logger.debug(f"[PARTIAL_ACK] Failed to queue batch {batch_id}: {e}")

    def _mark_osint_sqlite_batch_reported(self, local_ack):
        if not isinstance(local_ack, dict):
            return
        if local_ack.get("kind") != "osint_sqlite_batch":
            return
        db_path = local_ack.get("db_path")
        finding_ids = local_ack.get("finding_ids")
        if not isinstance(db_path, str) or not db_path:
            return
        if not isinstance(finding_ids, list) or not finding_ids:
            return
        try:
            from plugins.osint_finder.modules.storage.osint_sqlite_store import OsintSqliteStore
            store = OsintSqliteStore(db_path=db_path)
            clean_ids = [str(fid) for fid in finding_ids if isinstance(fid, str) and fid]
            if clean_ids:
                store.mark_findings_reported(clean_ids)
                logger.info(f"[PARTIAL_ACK] Marked {len(clean_ids)} OSINT SQLite findings as reported after backend ack")
        except Exception as e:
            logger.warning(f"[PARTIAL_ACK] Failed to mark OSINT SQLite findings reported: {e}")

    async def _handle_osint_partial_ack(self, data):
        batch_id = data.get("batch_id")
        if not isinstance(batch_id, str) or not batch_id:
            return
        pending = self.pending_partial_results.pop(batch_id, None)
        if not pending:
            logger.debug(f"[PARTIAL_ACK] Received ack for unknown batch {batch_id}")
            return
        status = str(data.get("status") or "ok").lower()
        if status != "ok":
            logger.warning(f"[PARTIAL_ACK] Backend returned non-ok ack for batch {batch_id}: {status}")
            return
        self._mark_osint_sqlite_batch_reported(pending.get("local_ack"))

    async def _resend_pending_partial_results(self, *, force=False):
        if not self.pending_partial_results:
            return
        if not self.session_token or not self._ws or self._ws.closed:
            return
        now = time.time()
        for batch_id, pending in list(self.pending_partial_results.items()):
            try:
                ack_timeout_s = max(5.0, float(pending.get("ack_timeout_s") or self._pending_partial_ack_timeout_s))
                last_send_ts = float(pending.get("last_send_ts") or 0.0)
                if not force and last_send_ts and (now - last_send_ts) < ack_timeout_s:
                    continue
                msg = pending.get("msg")
                if not isinstance(msg, dict):
                    self.pending_partial_results.pop(batch_id, None)
                    continue
                await self.send_command_partial_result(
                    pending.get("command_id"),
                    output=msg.get("output") or {},
                    logs=msg.get("logs") or [],
                    alerts=msg.get("alerts") or [],
                    metadata=msg.get("metadata") or {},
                )
            except Exception as e:
                pending["failures"] = int(pending.get("failures", 0) or 0) + 1
                logger.warning(f"[PARTIAL_ACK] Failed to resend partial batch {batch_id}: {e}")
                if pending["failures"] >= 3:
                    logger.warning(f"[PARTIAL_ACK] Dropping partial batch {batch_id} after repeated resend failures")
                    self.pending_partial_results.pop(batch_id, None)

    def _split_output_into_chunks(self, output, chunk_size):
        """
        Split output into chunks for WebSocket transport.

        Backward compatible:
        - If output contains "stdout" (string), we split stdout into multiple output dicts (legacy behavior).
        - Otherwise we serialize the whole output to JSON and split the JSON string into chunks.
          Each chunk is sent as output={"__chunk": "<piece>", "__chunk_mode": "json"} and
          reassembled on backend.
        """
        # NOTE:
        # We intentionally chunk as *stdout* to maximize backend compatibility.
        # Backend can always reassemble stdout chunks reliably, and we can then JSON-parse stdout back into dicts.
        # This avoids issues where some deployments miss/don't handle "__chunk" json-mode chunks consistently.
        try:
            output_str = json.dumps(output, default=str)
        except Exception:
            output_str = json.dumps({"raw": str(output)}, default=str)
        output_bytes = output_str.encode("utf-8")
        total_size = len(output_bytes)
        if total_size <= chunk_size:
            return [{"chunk_index": 0, "chunk_data": output}]
        
        chunks = []
        chunk_index = 0
        offset = 0
        
        while offset < total_size:
            # Вычисляем размер текущей части
            chunk_end = min(offset + chunk_size, total_size)
            
            # Извлекаем часть строки, стараясь не разорвать UTF-8 символ
            chunk_bytes = output_bytes[offset:chunk_end]
            # Если не на границе, откатываемся назад до начала последнего полного символа
            while chunk_end < total_size and chunk_bytes and (chunk_bytes[-1] & 0xC0) == 0x80:
                chunk_end -= 1
                chunk_bytes = output_bytes[offset:chunk_end]
            
            chunk_str = chunk_bytes.decode('utf-8', errors='ignore')
            
            # Send as stdout chunk (backend will reassemble stdout, then parse JSON on its side)
            chunk_output = {"stdout": chunk_str, "__chunk_mode": "stdout_json"}
            
            chunks.append({
                "chunk_index": chunk_index,
                "chunk_data": chunk_output
            })
            
            offset = chunk_end
            chunk_index += 1
        
        return chunks
    
    async def send_command_output(self, command_id, output, status="finished", logs=None, alerts=None, metadata=None):
        # Детальное логирование состояния перед отправкой
        # Keep logs minimal: these were extremely noisy and could leak auth token prefixes.
        logger.debug(f"[SEND_OUTPUT] send_command_output enter command={command_id} ws_active={self._ws is not None} closed={(self._ws.closed if self._ws else 'N/A')} token_present={self.session_token is not None}")
        
        # Snapshot token + ws + generation for the whole send operation.
        # This prevents losing token mid-send if the WS drops and `run()` clears state concurrently.
        token_snapshot = self.session_token
        ws_snapshot = self._ws
        ws_gen_snapshot = self._ws_generation

        # If transport isn't ready, do NOT error-log repeatedly. Queue once and retry after reconnect.
        if (ws_snapshot is None) or (getattr(ws_snapshot, "closed", False) is True):
            try:
                diag = {
                    "path": "send_command_output",
                    "command_id": command_id,
                    "msg_type": "commands_output",
                    "status": status,
                    "stdout_bytes": self._approx_size((output or {}).get("stdout"), depth=0) if isinstance(output, dict) else 0,
                    "stderr_bytes": self._approx_size((output or {}).get("stderr"), depth=0) if isinstance(output, dict) else 0,
                    "data_bytes_est": self._approx_size((output or {}).get("data"), depth=1) if isinstance(output, dict) else 0,
                    "logs_count": len(logs or []),
                    "alerts_count": len(alerts or []),
                }
            except Exception:
                diag = {"path": "send_command_output", "command_id": command_id}
            self._log_ws_not_ready(
                f"[SEND_OUTPUT] WS not ready for command {command_id}; queuing result for resend",
                diag_extra=diag,
            )
            # Deduplicate by command_id
            self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
            self.pending_results.append({
                "command_id": command_id,
                "msg": {
                    "type": "commands_output",
                    "command_id": command_id,
                    "status": status,
                    "output": output,
                    "logs": logs or [],
                    "alerts": alerts or [],
                    "metadata": metadata or {}
                },
                "timestamp": time.time()
            })
            # Best-effort reconnect (no-op if already reconnecting)
            await self._request_reconnect(f"ws_not_ready command={command_id}")
            return

        # Проверяем, что у нас есть session_token перед отправкой
        if not token_snapshot:
            logger.warning(f"[SEND_OUTPUT] No session_token available for command {command_id}, queuing result (pending={len(self.pending_results)})")
            # Проверяем, нет ли уже этого результата в очереди
            existing = [r for r in self.pending_results if r.get("command_id") == command_id]
            if not existing:
                self.pending_results.append({
                    "command_id": command_id,
                    "msg": {
                        "type": "commands_output",
                        "command_id": command_id,
                        "status": status,
                        "output": output,
                        "logs": logs or [],
                        "alerts": alerts or [],
                        "metadata": metadata or {}
                    },
                    "timestamp": time.time()
                })
                logger.debug(f"[SEND_OUTPUT] Added command {command_id} result to pending queue (pending={len(self.pending_results)})")
            else:
                logger.debug(f"[SEND_OUTPUT] Command {command_id} result already in pending queue")
            # Пытаемся получить session_token из registration_ack, если он еще не получен
            # Это будет обработано в listen loop
            return
        
        # Проверяем размер полного сообщения
        base_msg = {
            "type": "commands_output",
            "command_id": command_id,
            "status": status,
            "output": output,
            "logs": logs or [],
            "alerts": alerts or [],
            "metadata": metadata or {}
        }
        
        try:
            # Добавляем session_token к сообщению
            msg_with_token = self._msg_with_token(base_msg, token=token_snapshot)
            # Token presence check only; never log token values.
            if 'session_token' not in msg_with_token:
                logger.error(f"[SEND_OUTPUT] CRITICAL: session_token missing from message after _msg_with_token (command={command_id})")
            
            msg_str = json.dumps(msg_with_token, default=str)
            msg_size = len(msg_str.encode('utf-8'))
            
            # Если сообщение слишком большое (или выше консервативного порога), разбиваем на части.
            should_chunk = (msg_size > self.max_message_size) or (msg_size > self.always_chunk_above)
            if should_chunk:
                effective_chunk_size = min(self.chunk_size, self.always_chunk_size) if msg_size > self.always_chunk_above else self.chunk_size
                logger.info(
                    f"Chunking message for command {command_id}: size={msg_size} bytes, "
                    f"max_message_size={self.max_message_size}, always_chunk_above={self.always_chunk_above}, "
                    f"chunk_size={effective_chunk_size}"
                )
                
                # Разбиваем output на части
                chunks = self._split_output_into_chunks(output, effective_chunk_size)
                total_chunks = len(chunks)
                
                if total_chunks == 1:
                    # Если после разбиения все еще одна часть, отправляем как есть
                    # (возможно, проблема в других полях, не в stdout)
                    # IMPORTANT: Mark as final to ensure backend knows this is the complete result
                    base_msg["is_final"] = True
                    await self._send_on(ws_snapshot, self._msg_with_token(base_msg, token=token_snapshot))
                else:
                    # Отправляем каждую часть отдельным сообщением
                    for chunk_info in chunks:
                        # If WS was replaced mid-send (reconnect), do NOT continue sending remaining chunks
                        # on a new socket. Queue the whole result and resend after reconnect.
                        if self._ws_generation != ws_gen_snapshot or self._ws is not ws_snapshot:
                            logger.warning(
                                f"[SEND_OUTPUT] WS changed mid-chunk-send for command {command_id} "
                                f"(gen {ws_gen_snapshot}->{self._ws_generation}); queuing full result for resend"
                            )
                            self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
                            self.pending_results.append({
                                "command_id": command_id,
                                "msg": base_msg,
                                "timestamp": time.time()
                            })
                            # Do NOT force-close here: a reconnect is already in progress (generation changed).
                            # Forcing another close can create a reconnect storm and stall the loop.
                            return

                        chunk_index = chunk_info["chunk_index"]
                        chunk_output = chunk_info["chunk_data"]
                        
                        chunk_msg = {
                            "type": "commands_output",
                            "command_id": command_id,
                            # Normalize statuses to backend vocabulary:
                            # - terminal: success/error/timeout
                            # - non-terminal: partial_result
                            "status": ("success" if status in ("succeeded", "success", "finished") else status) if chunk_index == total_chunks - 1 else "partial_result",
                            "output": chunk_output,
                            "logs": logs or [] if chunk_index == 0 else [],  # Логи только в первой части
                            "alerts": alerts or [] if chunk_index == 0 else [],  # Алерты только в первой части
                            "metadata": metadata or {} if chunk_index == 0 else {},  # Метаданные только в первой части
                            "chunk_index": chunk_index,
                            "total_chunks": total_chunks,
                            "is_final": (chunk_index == total_chunks - 1)
                        }
                        
                        try:
                            await self._send_on(ws_snapshot, self._msg_with_token(chunk_msg, token=token_snapshot))
                            logger.debug(f"Sent chunk {chunk_index + 1}/{total_chunks} for command {command_id}")
                            # Небольшая задержка между отправкой частей, чтобы не перегрузить соединение
                            if chunk_index < total_chunks - 1:
                                await asyncio.sleep(0.1)
                        except Exception as chunk_error:
                            # Treat send errors as transient transport issues: queue the whole result and return.
                            logger.error(f"Error sending chunk {chunk_index} for command {command_id}: {chunk_error}")
                            self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
                            self.pending_results.append({
                                "command_id": command_id,
                                "msg": base_msg,
                                "timestamp": time.time()
                            })
                            # Force reconnect so we can resend from scratch on a fresh socket.
                            await self._request_reconnect(f"chunk_send_failed command={command_id}")
                            return
                    
                    logger.info(f"Successfully sent {total_chunks} chunks for command {command_id}")
            else:
                # Сообщение нормального размера, отправляем как есть
                # IMPORTANT: Mark as final to ensure backend knows this is the complete result
                base_msg["is_final"] = True
                logger.debug(f"[SEND_OUTPUT] Sending message for command {command_id}, size={msg_size} bytes")
                await self._send_on(ws_snapshot, self._msg_with_token(base_msg, token=token_snapshot))
                logger.debug(f"[SEND_OUTPUT] ✓ Message sent successfully for command {command_id}")
            
            # Удаляем из очереди, если был там
            self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
        except Exception as e:
            error_str = str(e).lower()
            is_transport = (
                "closing transport" in error_str
                or "closed" in error_str
                or "connection" in error_str
                or "not initialized" in error_str
            )
            if is_transport:
                self._log_ws_not_ready(f"[SEND_OUTPUT] transport error for {command_id}: {e}; queuing for resend")
            else:
                logger.error(f"Error in send_command_output for {command_id}: {e}")
            # If WebSocket is closed/uninitialized, queue and retry after reconnect
            if is_transport:
                logger.warning(f"WebSocket appears unavailable, adding to pending queue for command {command_id}")
                # Добавляем в очередь для повторной отправки (dedupe by command_id)
                self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
                self.pending_results.append({
                    "command_id": command_id,
                    "msg": base_msg,
                    "timestamp": time.time()
                })
                # IMPORTANT: do NOT retry immediately here.
                # Immediate retries can create reconnect storms and keep the transport in a half-closing state.
                # We'll resend after reconnect/registration (or next heartbeat) via _resend_pending_results().
                await self._request_reconnect(f"send_failed command={command_id}")
                return
            else:
                raise

    async def send_file_upload(self, command_id, file_url=None, payload_b64=None, filename=None, size=None, metadata=None):
        msg = {
            "type": "file_upload",
            "command_id": command_id,
            "file_url": file_url,
            "payload_b64": payload_b64,
            "filename": filename,
            "size": size,
            "metadata": metadata or {}
        }
        await self._send(self._msg_with_token(msg))

    async def upload_artifact_file(
        self,
        command_id: str,
        file_path: str,
        *,
        filename: Optional[str] = None,
        content_type: str = "application/octet-stream",
        upload_id: Optional[str] = None,
        chunk_bytes: int = 48 * 1024,
    ) -> None:
        """
        Stream an artifact file to backend via WS type=file_upload without loading it all into RAM.
        Uses base64 chunks; backend appends chunks to disk.
        """
        import base64
        import os
        from pathlib import Path

        try:
            p = Path(file_path)
            if not p.exists() or not p.is_file():
                logger.warning(f"[ARTIFACT_UPLOAD] file does not exist: {file_path}")
                return
        except Exception:
            logger.warning(f"[ARTIFACT_UPLOAD] invalid file_path: {file_path}")
            return

        safe_name = filename or Path(file_path).name
        up_id = upload_id or safe_name

        # Safety: avoid destabilizing the main WS during scans by pushing very large artifacts.
        # Can be overridden per host.
        try:
            max_bytes = int(os.getenv("WS_FILE_UPLOAD_MAX_BYTES", str(2 * 1024 * 1024)))  # 2MB default
        except Exception:
            max_bytes = 2 * 1024 * 1024
        if max_bytes < 64 * 1024:
            max_bytes = 64 * 1024

        try:
            total_size = int(os.path.getsize(file_path))
        except Exception:
            total_size = None

        if total_size is not None and total_size > max_bytes:
            logger.warning(
                f"[ARTIFACT_UPLOAD] skip upload (too large): file={safe_name} size={total_size}B max={max_bytes}B"
            )
            return

        # optional total_chunks; backend doesn't require it
        total_chunks = None
        if total_size is not None and chunk_bytes and chunk_bytes > 0:
            try:
                total_chunks = (total_size + chunk_bytes - 1) // chunk_bytes
            except Exception:
                total_chunks = None

        # Throttle between chunks to keep heartbeat/pong responsive and reduce proxy/gateway resets.
        try:
            inter_chunk_sleep = float(os.getenv("WS_FILE_UPLOAD_INTER_CHUNK_SLEEP", "0.02"))
        except Exception:
            inter_chunk_sleep = 0.02
        if inter_chunk_sleep < 0:
            inter_chunk_sleep = 0.0

        ws_snapshot = self._ws
        ws_gen_snapshot = self._ws_generation

        try:
            with open(file_path, "rb") as f:
                idx = 0
                while True:
                    # Abort if WS changed/closed mid-upload; do not trigger reconnect storms.
                    if self._ws is None or self._ws_generation != ws_gen_snapshot or self._ws is not ws_snapshot:
                        logger.warning(f"[ARTIFACT_UPLOAD] abort (ws changed) upload_id={up_id} command_id={command_id}")
                        return
                    buf = f.read(chunk_bytes)
                    if not buf:
                        break
                    b64 = base64.b64encode(buf).decode("ascii")
                    msg = {
                        "type": "file_upload",
                        "command_id": command_id,
                        "upload_id": up_id,
                        "filename": safe_name,
                        "content_type": content_type,
                        "encoding": "base64",
                        "data": b64,
                        "chunk_index": idx,
                        "total_chunks": total_chunks,
                        "is_final": False,
                    }
                    await self._send(self._msg_with_token(msg))
                    idx += 1
                    if inter_chunk_sleep:
                        await asyncio.sleep(inter_chunk_sleep)

                # final marker (even for empty file)
                final_msg = {
                    "type": "file_upload",
                    "command_id": command_id,
                    "upload_id": up_id,
                    "filename": safe_name,
                    "content_type": content_type,
                    "encoding": "base64",
                    "data": "",
                    "chunk_index": idx,
                    "total_chunks": total_chunks,
                    "is_final": True,
                }
                await self._send(self._msg_with_token(final_msg))
                logger.info(f"[ARTIFACT_UPLOAD] uploaded {safe_name} chunks={idx} command_id={command_id}")
        except Exception as e:
            logger.warning(f"[ARTIFACT_UPLOAD] upload failed for {file_path}: {e}")

    async def send_reconnect(self, reason, details=None):
        msg = {
            "type": "reconnect",
            "agent_id": self.agent_id,
            "reason": reason,
            "details": details
        }
        await self._send(self._msg_with_token(msg))

    async def send_agent_logs(self, log_level, logs):
        msg = {
            "type": "agent_logs",
            "log_level": log_level,
            "logs": logs
        }
        await self._send(self._msg_with_token(msg))

    async def _agent_log_reporter_loop(self):
        """
        Periodically scan local log files for error signals and report them to backend as system logs.
        Enable with AGENT_LOG_REPORTER_ENABLED=1.
        """
        from core.ws.agent_log_reporter import agent_log_reporter_loop

        await agent_log_reporter_loop(self)

    async def listen(self):
        try:
            async for msg in self._ws:
                try:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        try:
                            self._touch_rx_ts()
                        except Exception:
                            pass
                        # WS payloads can be large; don't spam logs.
                        if self.debug_mode:
                            logger.debug(f"WS RECV: {msg.data[:500]}{'...' if len(msg.data) > 500 else ''}")
                        data = json.loads(msg.data)
                        logger.debug(f"WS RX: {data}")
                        msg_type = data.get("type")
                        if msg_type == "exec_command":
                            await self.handle_command(data.get("data", data))
                        elif msg_type == "execute_command":
                            await self.handle_command(data)
                        elif msg_type == "get_plugins":
                            await self.send_plugins()
                        elif msg_type == "commands":
                            await self.handle_commands(data)
                        elif msg_type == "cancel_task":
                            await self.handle_cancel_task(data)
                        elif msg_type == "sys_command":
                            await self.handle_sys_command(data)
                        elif msg_type == "request_agent_logs":
                            await self.handle_request_agent_logs(data)
                        elif msg_type == "user_custom":
                            await self.handle_user_custom(data)
                        elif msg_type and msg_type.startswith("hook_"):
                            await self.handle_hook(data)
                        elif msg_type == "file_upload":
                            await self.handle_file_upload(data)
                        elif msg_type == "reconnect":
                            await self.handle_reconnect(data)
                        elif msg_type == "registration_ack":
                            # Обрабатываем registration_ack и в listen тоже (на случай, если пришло после переподключения)
                            if data.get("status") == "ok":
                                if "agent_id" in data:
                                    self.agent_id = data["agent_id"]
                                    self.session_token = data.get("session_token")
                                    logger.info("[REGISTRATION] session_token received in listen loop")
                                    if self.debug_mode:
                                        logger.debug(f"Registration OK in listen. Agent ID: {self.agent_id}")
                                    # Отправляем результаты из очереди после получения нового session_token
                                    await asyncio.sleep(1)
                                    try:
                                        await self._resend_pending_results()
                                        await self._resend_pending_partial_results(force=True)
                                    except Exception as resend_error:
                                        logger.error(f"Error resending pending results after registration: {resend_error}")
                            pass
                        elif msg_type == "osint_partial_ack":
                            await self._handle_osint_partial_ack(data)
                        elif msg_type == "ping":
                            # Обработка ping сообщений для поддержания соединения
                            if self.debug_mode:
                                logger.debug("Received ping, sending pong")
                            try:
                                await self._send(self._msg_with_token({"type": "pong"}))
                            except ConnectionError:
                                logger.warning("WebSocket closed during pong send, will reconnect")
                                break
                            # После pong проверяем, можно ли отправить результаты из очереди
                            if self.pending_results and self.session_token:
                                await asyncio.sleep(0.5)
                                await self._resend_pending_results()
                            if self.pending_partial_results and self.session_token:
                                await asyncio.sleep(0.1)
                                await self._resend_pending_partial_results()
                        elif msg_type == "config_update":
                            await self.handle_config_update(data)
                        elif msg_type == "error":
                            # Обработка ошибок от бэкенда
                            error_msg = data.get("msg", "")
                            logger.error(f"[LISTEN] Received error from backend: {error_msg}")
                            if "Missing session_token" in error_msg or "Invalid session_token" in error_msg:
                                logger.error(f"[LISTEN] CRITICAL: session_token error! Current session_token: {self.session_token is not None}")
                                if self.session_token:
                                    logger.error("[LISTEN] session_token present but validation failed")
                                # Сбрасываем session_token и переподключаемся
                                self.session_token = None
                                logger.warning("[LISTEN] session_token cleared, will reconnect")
                                break
                        else:
                            if self.debug_mode:
                                logger.warning(f"Unknown WS message type: {msg_type}")
                    elif msg.type == aiohttp.WSMsgType.ERROR:
                        # ERROR is typically raised when the connection is already unhealthy.
                        # Log as much context as possible (code/exception) to diagnose proxy/network issues.
                        exc = None
                        try:
                            exc = self._ws.exception()
                        except Exception:
                            exc = None
                        logger.error(
                            f"WebSocket error event: {repr(exc) if exc else None}; {self._ws_debug_state()}"
                        )
                        break
                    elif msg.type == aiohttp.WSMsgType.CLOSE:
                        # CLOSE frame received from server. msg.data/msg.extra may contain close payload.
                        data = getattr(msg, "data", None)
                        extra = getattr(msg, "extra", None)
                        logger.warning(
                            f"WebSocket closed by server: msg.data={data} msg.extra={extra}; {self._ws_debug_state()}"
                        )
                        break
                except Exception as e:
                    logger.error(f"Failed to handle message: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"Error in listen loop: {e}", exc_info=True)
        finally:
            # При выходе из listen пытаемся отправить результаты из очереди
            if self.pending_results:
                logger.info(f"Listen loop ended, attempting to resend {len(self.pending_results)} pending results")
                try:
                    await self._resend_pending_results()
                except Exception as resend_error:
                    logger.error(f"Error resending pending results: {resend_error}")
            if self.pending_partial_results:
                try:
                    await self._resend_pending_partial_results(force=True)
                except Exception as resend_error:
                    logger.error(f"Error resending pending partial results: {resend_error}")

    def _touch_rx_ts(self) -> None:
        """Mark time of last inbound WS activity (TEXT frames)."""
        self._last_rx_ts = time.time()

    async def _recv_idle_watchdog(self, generation: int) -> None:
        """
        If inbound JSON/text stops (e.g. half-open socket), outgoing heartbeat may still succeed.
        Force reconnect when no TEXT received for recv_idle_timeout_s.
        """
        while True:
            try:
                await asyncio.sleep(self._recv_idle_check_interval_s)
            except asyncio.CancelledError:
                raise
            except Exception:
                await asyncio.sleep(self._recv_idle_check_interval_s)
            if self._stop:
                return
            if self._ws_generation != generation:
                return
            ts = self._last_rx_ts
            if ts is None:
                continue
            age = time.time() - float(ts)
            if age <= self._recv_idle_timeout_s:
                continue
            logger.warning(
                "[WS] Inbound idle %.0fs (limit %.0fs); requesting reconnect",
                age,
                self._recv_idle_timeout_s,
            )
            try:
                await self._request_reconnect("recv_idle_timeout")
            except Exception as e:
                logger.debug("[WS] recv_idle_watchdog reconnect request failed: %s", e)
            return

    async def handle_config_update(self, data: dict) -> None:
        """
        Apply runtime configuration updates pushed from backend.
        Expected shape:
          { "type": "config_update", "config": { "stealth_mode": true, ... } }
        """
        try:
            cfg = data.get("config") if isinstance(data, dict) else None
            if not isinstance(cfg, dict):
                return

            if "stealth_mode" in cfg:
                new_val = cfg.get("stealth_mode")
                if isinstance(new_val, bool):
                    self.stealth_mode = new_val
                    if self.task_queue:
                        self.task_queue.global_stealth_mode = new_val
                    logger.info(f"[CONFIG_UPDATE] stealth_mode set to {new_val}")
        except Exception as e:
            logger.error(f"Failed to apply config_update: {e}", exc_info=True)

    async def handle_commands(self, data):
        # batch: {"type": "commands", "commands": [...], ...}
        commands = data.get("commands", [])
        for cmd in commands:
            await self.handle_command(cmd)
        logger.debug(f"Batch commands queued: {len(commands)}")

    async def handle_cancel_task(self, data):
        command_id = data.get("command_id")
        logger.info(f"Cancel task received: {data}")
        task = self.active_tasks.get(command_id)
        if task and not task.done():
            task.cancel()
            await self.send_command_output(
                command_id,
                output={"stdout": "", "stderr": "Cancelled by backend", "return_code": 137, "files": []},
                status="cancelled",
                logs=[{"line": "Cancelled by backend", "level": "warning"}],
                alerts=["cancelled"],
                metadata={"cancelled_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            )
        else:
            if self.debug_mode:
                logger.warning(f"No active task to cancel for command_id={command_id}")

    async def handle_sys_command(self, data):
        action = data.get("action")
        logger.info(f"Sys command received: {data}")
        if action == "shutdown":
            logger.info("Shutting down agent by sys_command.")
            await self.send_agent_logs("info", [{"timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "msg": "Agent shutdown by backend", "trace": ""}])
            self._stop = True
            await asyncio.sleep(1)
            exit(0)
        elif action == "restart":
            logger.info("Restart requested (not implemented)")
            # TODO: реализовать рестарт агента
        elif action == "update_config":
            logger.info("Config reload requested (not implemented)")
            # TODO: реализовать reload config
        else:
            if self.debug_mode:
                logger.warning(f"Unknown sys_command action: {action}")

    async def handle_system_command(self, data):
        """Обрабатывает системные команды."""
        command = data.get("command", "").lower()
        command_id = data.get("command_id")
        
        await self.send_command_ack(command_id, status="accepted")
        
        if command in ["list_plugins", "plugins"]:
            await self.handle_list_plugins_command(command_id)
        elif command == "help":
            await self.handle_help_command(command_id)
        else:
            await self.send_command_output(
                command_id,
                output={"stdout": f"Unknown system command: {command}", "stderr": "", "return_code": 1, "files": []},
                status="error",
                logs=[{"line": f"Unknown system command: {command}", "level": "error"}],
                alerts=["command_failed"],
                metadata={"failed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            )
    
    async def handle_list_plugins_command(self, command_id):
        """Обрабатывает команду list_plugins."""
        try:
            plugins_info = []
            
            for plugin_name, PluginCls in self.registry.plugins.items():
                plugin_info = {
                    "name": plugin_name,
                    "version": getattr(PluginCls, 'VERSION', '1.0.0'),
                    "description": getattr(PluginCls, '__doc__', 'No description available'),
                    "commands": []
                }
                
                # Получаем список команд плагина
                plugin_commands = []
                
                # Проверяем все методы плагина
                for method_name in dir(PluginCls):
                    method = getattr(PluginCls, method_name)
                    if callable(method) and not method_name.startswith('_'):
                        # Пропускаем служебные методы базового класса
                        if method_name in ['register_hook', 'run_custom_hook', 'run_all_hooks', 'get_command_examples', '_extract_examples_from_docstring', '_auto_register_hooks', 'version']:
                            continue
                        
                        # Дополнительная проверка: пропускаем методы, которые есть в BasePlugin
                        if hasattr(BasePlugin, method_name) and method_name not in ['run']:
                            continue
                        
                        # Пропускаем property методы
                        if isinstance(method, property):
                            continue
                        
                        # Пропускаем статические и классовые методы, кроме основных команд
                        if (inspect.ismethod(method) or inspect.isfunction(method)) and not method_name.startswith('hook_') and method_name != 'run':
                            # Проверяем, что это не статический или классовый метод
                            if hasattr(method, '__self__') and method.__self__ is not None:
                                # Это instance method, оставляем
                                pass
                            else:
                                # Это статический или классовый метод, пропускаем
                                continue
                        
                        command_info = {
                            "name": method_name,
                            "type": "method",
                            "description": getattr(method, '__doc__', 'No description available'),
                            "args": []
                        }
                        
                        # Извлекаем параметры метода
                        try:
                            sig = inspect.signature(method)
                            for param_name, param in sig.parameters.items():
                                # Исключаем служебные параметры
                                if param_name not in ['self', 'cls', 'kwargs', 'args']:
                                    # Проверяем, что это не служебный параметр
                                    if not param_name.startswith('_'):
                                        # Улучшаем отображение типа
                                        param_type = param.annotation
                                        if param_type == inspect.Parameter.empty:
                                            type_str = "any"
                                        elif hasattr(param_type, '__name__'):
                                            type_str = param_type.__name__
                                        elif hasattr(param_type, '_name'):
                                            type_str = param_type._name
                                        else:
                                            type_str = str(param_type).replace('<class \'', '').replace('\'>', '')
                                        
                                        param_info = {
                                            "name": param_name,
                                            "type": type_str,
                                            "default": param.default if param.default != inspect.Parameter.empty else None,
                                            "required": param.default == inspect.Parameter.empty
                                        }
                                        command_info["args"].append(param_info)
                        except Exception as e:
                            logger.debug(f"Could not extract args for {method_name}: {e}")
                        
                        # Автоматически извлекаем примеры команд из плагина
                        try:
                            # Создаем временный экземпляр плагина для извлечения примеров
                            temp_plugin = PluginCls(None, None, {})
                            plugin_examples = temp_plugin.get_command_examples()
                            
                            # Ищем примеры для текущего метода
                            method_examples = []
                            if method_name.startswith('hook_'):
                                hook_command = method_name[5:]  # убираем 'hook_'
                                method_examples = plugin_examples.get(hook_command, [])
                            elif method_name == 'run':
                                method_examples = plugin_examples.get('run', [])
                            
                            # Убираем дубликаты из примеров
                            if method_examples:
                                # Используем set для дедупликации, затем обратно в list
                                unique_examples = list(dict.fromkeys(method_examples))  # сохраняет порядок
                                command_info["examples"] = unique_examples
                            else:
                                # Fallback для методов без примеров - создаем базовый пример
                                if method_name.startswith('hook_'):
                                    hook_command = method_name[5:]
                                    command_info["examples"] = [f"plugin:{plugin_name} {hook_command}"]
                                else:
                                    command_info["examples"] = [f"plugin:{plugin_name} {method_name}"]
                        except Exception as e:
                            logger.debug(f"Could not extract examples for {method_name}: {e}")
                            # Fallback пример
                            if method_name.startswith('hook_'):
                                hook_command = method_name[5:]
                                command_info["examples"] = [f"plugin:{plugin_name} {hook_command}"]
                            else:
                                command_info["examples"] = [f"plugin:{plugin_name} {method_name}"]
                        
                        # Специальная обработка для hook методов
                        if method_name.startswith('hook_'):
                            hook_command = method_name[5:]  # убираем 'hook_'
                            command_info.update({
                                "name": hook_command,
                                "type": "hook_command",
                                "description": getattr(method, '__doc__', f'Execute {hook_command} command')
                            })
                        
                        # Специальная обработка для основных методов
                        elif method_name == 'run':
                            command_info.update({
                                "type": "main_method",
                                "description": getattr(method, '__doc__', f'Main {method_name} method')
                            })
                        
                        plugin_commands.append(command_info)
                
                plugin_info["commands"] = plugin_commands
                plugins_info.append(plugin_info)
            
            # Формируем структурированный ответ для LLM
            result = {
                "agent_id": self.agent_id,
                "total_plugins": len(plugins_info),
                "plugins": plugins_info,
                "usage_instructions": {
                    "overview": "Security Agent provides shell command execution and plugin-based security analysis capabilities",
                    
                    "command_types": {
                        "system_commands": "Built-in agent commands (list_plugins, help)",
                        "shell_commands": "Direct shell command execution (ls, ps, netstat, etc.)",
                        "plugin_commands": "Security analysis commands from plugins (scan, map, escape)"
                    },
                    
                    "plugin_architecture": {
                        "hook_commands": "Main plugin commands that can be called directly (e.g., scan, map, escape)",
                        "main_method": "Internal plugin entry point (run method)",
                        "auto_detection": "Commands are automatically routed to appropriate plugins"
                    },
                    
                    "command_formats": {
                        "unified_string": "Single string with plugin, command and arguments: 'plugin:osint_finder scan root_dir=/etc max_files=1000'",
                        "structured": "JSON object with separate fields: {'command': 'scan', 'plugin': 'osint_finder', 'args': ['root_dir=/etc']}",
                        "implicit": "Command only, plugin auto-detected: 'scan' (routes to appropriate plugin)",
                        "explicit": "Plugin selection only: 'plugin:osint_finder' (selects plugin for next command)"
                    },
                    
                    "argument_formats": {
                        "command_line": "Space-separated key=value pairs: 'root_dir=/etc max_files=1000'",
                        "json_args": "Array of strings: ['root_dir=/etc', 'max_files=1000']",
                        "json_options": "Object with typed values: {'root_dir': '/etc', 'max_files': 1000}"
                    },
                    
                    "available_plugins": {
                        "osint_finder": "OSINT gathering, secret-style signals, and configuration analysis",
                        "network_mapper": "Network mapping and connection analysis",
                        "docker_escape": "Docker container security assessment"
                    },
                    
                    "examples": {
                        "system": [
                            "list_plugins - Show all available plugins and commands",
                            "help - Show usage instructions"
                        ],
                        "shell": [
                            "ls -la - List files in current directory",
                            "ps aux - Show running processes",
                            "netstat -tuln - Show network connections"
                        ],
                        "plugin_unified": [
                            "plugin:osint_finder scan root_dir=/etc max_files=1000",
                            "plugin:network_mapper map mode=live",
                            "plugin:docker_escape escape"
                        ],
                        "plugin_implicit": [
                            "scan root_dir=/etc - Auto-detects appropriate scanner plugin",
                            "map mode=all - Auto-detects network_mapper plugin",
                            "escape - Auto-detects docker_escape plugin"
                        ],
                        "plugin_structured": [
                            "{'command': 'scan', 'plugin': 'osint_finder', 'args': ['root_dir=/etc']}",
                            "{'command': 'map', 'args': ['mode=live']}",
                            "{'command': 'escape', 'options': {'mode': 'full'}}"
                        ]
                    },
                    
                    "best_practices": {
                        "use_unified_format": "Prefer unified string format for simple commands: 'plugin:name command args'",
                        "use_structured_for_complex": "Use structured JSON for complex arguments or multiple options",
                        "check_plugin_capabilities": "Use list_plugins to see available commands and their arguments",
                        "provide_examples": "Each plugin command includes usage examples in its documentation"
                    },
                    
                    "error_handling": {
                        "unknown_command": "Unknown commands are executed as shell commands",
                        "plugin_not_found": "If plugin not found, command is executed as shell command",
                        "argument_validation": "Invalid arguments may cause command failure - check plugin documentation"
                    }
                }
            }
            
            import json
            output = {
                "stdout": json.dumps(result, indent=2, ensure_ascii=False),
                "stderr": "",
                "return_code": 0,
                "files": []
            }
            
            await self.send_command_output(
                command_id,
                output=output,
                status="finished",
                logs=[{"line": f"Listed {len(plugins_info)} plugins with commands", "level": "info"}],
                alerts=[],
                metadata={"finished_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            )
            
        except Exception as e:
            logger.error(f"Error in handle_list_plugins_command: {e}")
            await self.send_command_output(
                command_id,
                output={"stdout": "", "stderr": str(e), "return_code": 1, "files": []},
                status="error",
                logs=[{"line": str(e), "level": "error"}],
                alerts=["command_failed"],
                metadata={"failed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            )
    
    async def handle_help_command(self, command_id):
        """Обрабатывает команду help."""
        help_text = """
Security Agent - Usage Guide

OVERVIEW:
Security Agent provides shell command execution and plugin-based security analysis capabilities.

COMMAND TYPES:

1. SYSTEM COMMANDS:
   - list_plugins, plugins: Show all available plugins with their methods and versions
   - help: Show this help message

2. SHELL COMMANDS:
   - Any shell command (ls, ps, netstat, etc.) will be executed directly
   - Examples: "ls -la", "ps aux", "netstat -tuln"

3. PLUGIN COMMANDS:
   Available plugins and their main commands:
   
   osint_finder:
     - scan: OSINT gathering, secret-style pattern signals, and configuration analysis
     - Examples: "plugin:osint_finder scan root_dir=/etc max_files=1000"
   
   network_mapper:
     - map: Network mapping and connection analysis
     - Examples: "plugin:network_mapper map mode=live"
   
   docker_escape:
     - escape: Docker container security assessment
     - Examples: "plugin:docker_escape escape"

COMMAND FORMATS:

1. UNIFIED STRING FORMAT (Recommended):
   "plugin:name command args"
   Examples:
   - "plugin:osint_finder scan root_dir=/etc max_files=1000"
   - "plugin:network_mapper map mode=all"

2. IMPLICIT PLUGIN SELECTION:
   "command args" (plugin auto-detected)
   Examples:
   - "scan root_dir=/etc" (auto-detects appropriate scanner)
   - "map mode=live" (auto-detects network_mapper)
   - "escape" (auto-detects docker_escape)

3. STRUCTURED JSON FORMAT:
   {
     "command": "scan",
     "plugin": "osint_finder",
     "args": ["root_dir=/etc", "max_files=1000"]
   }

ARGUMENT FORMATS:

1. COMMAND LINE: Space-separated key=value pairs
   "root_dir=/etc max_files=1000"

2. JSON ARGS: Array of strings
   ["root_dir=/etc", "max_files=1000"]

3. JSON OPTIONS: Object with typed values
   {"root_dir": "/etc", "max_files": 1000}

BEST PRACTICES:

- Use unified string format for simple commands
- Use structured JSON for complex arguments
- Check available commands with "list_plugins"
- Each plugin command includes usage examples
- Unknown commands are executed as shell commands

For detailed plugin information and available methods, use: list_plugins
"""
        
        output = {
            "stdout": help_text.strip(),
            "stderr": "",
            "return_code": 0,
            "files": []
        }
        
        await self.send_command_output(
            command_id,
            output=output,
            status="finished",
            logs=[{"line": "Help command executed", "level": "info"}],
            alerts=[],
            metadata={"finished_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        )

    async def handle_request_agent_logs(self, data):
        logger.info(f"Request agent logs: {data}")
        # Пример: возвращаем sample log, можно доработать для реальных логов
        logs = [{"timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "msg": "Sample log", "trace": ""}]
        await self.send_agent_logs("info", logs)

    async def handle_file_upload(self, data):
        logger.info(f"File upload received: {data}")
        filename = data.get("filename", f"upload_{int(time.time())}")
        payload_b64 = data.get("payload_b64")
        if payload_b64:
            try:
                file_bytes = base64.b64decode(payload_b64)
                temp_dir = tempfile.gettempdir()
                file_path = os.path.join(temp_dir, filename)
                with open(file_path, "wb") as f:
                    f.write(file_bytes)
                logger.info(f"File saved to {file_path} (size: {len(file_bytes)})")
            except Exception as e:
                logger.error(f"Failed to save uploaded file: {e}")
        else:
            if self.debug_mode:
                logger.warning("No payload_b64 in file_upload message.")

    async def handle_reconnect(self, data):
        logger.info(f"Reconnect requested: {data}")
        await self.send_reconnect(reason=data.get("reason", "manual"), details=data.get("details"))

    async def handle_user_custom(self, data):
        logger.info(f"User custom message: {data}")
        plugin_name = data.get("plugin")
        if plugin_name and plugin_name in self.registry.plugins:
            PluginCls = self.registry.plugins[plugin_name]
            plugin_inst = PluginCls(ws=self, command_id=data.get("command_id", "custom"), options=data)
            if hasattr(plugin_inst, "user_custom"):
                try:
                    result = await plugin_inst.user_custom()
                    try:
                        # Keep logs compact; full results are sent via commands_output when applicable.
                        s = repr(result)
                        if len(s) > 500:
                            s = s[:500] + "…"
                        logger.info(f"user_custom result: {s}")
                    except Exception:
                        logger.info("user_custom result: <unprintable>")
                except Exception as e:
                    logger.error(f"user_custom error: {e}")
            else:
                if self.debug_mode:
                    logger.warning(f"Plugin {plugin_name} has no user_custom method.")
        else:
            if self.debug_mode:
                logger.warning("No plugin specified or plugin not found for user_custom.")

    async def handle_hook(self, data):
        logger.info(f"Hook message: {data}")
        plugin_name = data.get("plugin")
        hook_name = data.get("hook")
        if plugin_name and plugin_name in self.registry.plugins and hook_name:
            PluginCls = self.registry.plugins[plugin_name]
            plugin_inst = PluginCls(ws=self, command_id=data.get("command_id", "hook"), options=data)
            hook_method = getattr(plugin_inst, f"hook_{hook_name}", None)
            if hook_method:
                try:
                    result = await hook_method()
                    try:
                        s = repr(result)
                        if len(s) > 500:
                            s = s[:500] + "…"
                        logger.info(f"hook_{hook_name} result: {s}")
                    except Exception:
                        logger.info(f"hook_{hook_name} result: <unprintable>")
                except Exception as e:
                    logger.error(f"hook_{hook_name} error: {e}")
            else:
                if self.debug_mode:
                    logger.warning(f"Plugin {plugin_name} has no hook_{hook_name} method.")
        else:
            if self.debug_mode:
                logger.warning("No plugin or hook specified for handle_hook.")

    async def handle_command(self, data):
        # data: {plugin: ..., command: ..., command_id: ...}
        if self.debug_mode:
            logger.debug(f"[handle_command] Received data keys: {list(data.keys()) if isinstance(data, dict) else type(data)}")
        command_id = data.get("command_id")
        if command_id:
            if command_id in self._seen_command_ids:
                logger.debug(f"[handle_command] Duplicate execute_command for command_id={command_id}, ignoring")
                return
            self._seen_command_ids.add(command_id)
        plugin_name = data.get("plugin")
        command = data.get("command", "")
        
        # Если команда передана как единая строка (например, "plugin:vault_security_auditor test_output=true"), парсим её
        # ВАЖНО: парсим ВСЕГДА, если команда содержит пробелы, даже если plugin уже указан
        if command and " " in command:
            # Это может быть единая строка команды с аргументами
            logger.debug("[handle_command] Command contains spaces, parsing")
            parsed_data = self.parse_unified_command(command)
            logger.debug("[handle_command] Parsed command")
            # Сохраняем исходные args из WebSocket сообщения
            original_args = data.get("args", [])
            # Обновляем data с результатами парсинга
            data.update(parsed_data)
            # Восстанавливаем исходные args, если они есть
            if original_args:
                data["args"] = original_args
            command = data.get("command", command)
            plugin_name = data.get("plugin")
            logger.debug(f"[handle_command] After parsing: plugin='{plugin_name}', command='{command}'")
        
        # Если плагин не указан, определяем его по команде
        if not plugin_name:
            plugin_name = self._determine_plugin_by_command(command)
            if plugin_name:
                data["plugin"] = plugin_name
                logger.info(f"Auto-detected plugin '{plugin_name}' for command '{command}'")
            else:
                if self.debug_mode:
                    logger.warning(f"No plugin found for command '{command}', using shell executor")
                # Используем shell executor для неизвестных команд
                data["command_type"] = "shell"
                data["command_payload"] = {
                    "command": command,
                    "args": data.get("args", []),
                    "timeout": data.get("timeout", 30000) / 1000  # конвертируем из миллисекунд в секунды
                }
        else:
            # Плагин указан явно, проверяем что он существует
            logger.debug(f"[handle_command] Plugin '{plugin_name}' explicitly provided, checking registry")
            if plugin_name not in self.registry.plugins:
                # If this is a mock run (test_output=true), still treat it as a plugin command.
                # Registry can serve mock outputs even if the real plugin isn't loadable in this agent runtime.
                opts = data.get("options") if isinstance(data.get("options"), dict) else {}
                is_test_output = opts.get("test_output") is True
                if not is_test_output:
                    # Fallback: detect test_output from args if options weren't provided
                    args = data.get("args") or []
                    if isinstance(args, (list, tuple)) and any(
                        str(a).strip().lower() in ("test_output=true", "test_output=1", "test_output=yes", "test_output=on")
                        for a in args
                    ):
                        is_test_output = True
                if is_test_output:
                    logger.info(f"Plugin '{plugin_name}' not found in registry, but test_output=true — will execute via plugin path using mock output")
                    data["command_type"] = "plugin"
                else:
                    # IMPORTANT: никогда не превращаем команды с явным `plugin` в shell-команду.
                    # `parse_unified_command()` нормализует команду до "run"/"hook_*" и удаляет префикс "plugin:",
                    # поэтому проверка `command.startswith("plugin:")` здесь ненадёжна.
                    # Если плагин не загружен/не зарегистрирован, пусть это будет явная ошибка "plugin not found"
                    # (или mock-output), а не политика allow_remote_shell.
                    logger.warning(
                        f"Plugin '{plugin_name}' not found in registry (available: {list(self.registry.plugins.keys())}). "
                        f"Keeping command_type='plugin' (will surface plugin-not-found error)."
                    )
                    data["command_type"] = "plugin"
            else:
                # Плагин найден, НЕ устанавливаем command_type, чтобы он выполнился как плагин
                logger.info(f"Plugin '{plugin_name}' found in registry, will execute as plugin (not shell)")
                # Явно устанавливаем command_type = "plugin" для ясности
                data["command_type"] = "plugin"
        
        # Обработка системных команд
        if plugin_name == "system":
            await self.handle_system_command(data)
            return
        
        # Отправляем статус "pending" когда команда только получена
        await self.send_command_ack(command_id, status="pending")
        
        await self.send_command_ack(command_id, status="accepted")
        await self.task_queue.add(plugin_name, data)
        await self.send_command_ack(command_id, status="started")
        logger.info(f"Command queued for plugin: {plugin_name}")
        # результат отправится через on_task_result

    async def send_command_progress(self, command_id, progress, output=None, logs=None, alerts=None, metadata=None):
        """Отправляет промежуточный статус выполнения команды."""
        msg = {
            "type": "commands_output",
            "command_id": command_id,
            "status": "in_progress",
            "progress": progress,
            "output": output or {},
            "alerts": alerts or [],
            "metadata": metadata or {}
        }
        await self._send(self._msg_with_token(msg))

    async def send_command_partial_result(self, command_id, output, logs=None, alerts=None, metadata=None):
        """Отправляет частичный результат выполнения команды с chunking/retry support."""
        metadata_clean, local_ack = self._extract_partial_local_ack(metadata or {})
        batch_id = metadata_clean.get("batch_id") if isinstance(metadata_clean.get("batch_id"), str) else None
        ack_required = bool(metadata_clean.get("ack_required")) and bool(batch_id)
        ack_timeout_s = metadata_clean.get("ack_timeout_s") or self._pending_partial_ack_timeout_s

        base_msg = {
            "type": "commands_output",
            "command_id": command_id,
            "status": "partial_result",
            "output": output,
            "logs": logs or [],
            "alerts": alerts or [],
            "metadata": metadata_clean,
        }

        def _queue_generic_partial() -> None:
            try:
                self.pending_results = [
                    r for r in self.pending_results
                    if not (
                        r.get("command_id") == command_id and
                        isinstance(r.get("msg"), dict) and
                        r["msg"].get("type") == "commands_output" and
                        r["msg"].get("status") == "partial_result" and
                        ((r["msg"].get("metadata") or {}).get("batch_id") == batch_id)
                    )
                ]
                self.pending_results.append({
                    "command_id": command_id,
                    "msg": base_msg,
                    "timestamp": time.time(),
                })
            except Exception:
                pass

        token_snapshot = self.session_token
        ws_snapshot = self._ws
        ws_gen_snapshot = self._ws_generation

        if (ws_snapshot is None) or (getattr(ws_snapshot, "closed", False) is True) or not token_snapshot:
            if ack_required:
                self._queue_partial_result_for_ack(
                    batch_id=batch_id,
                    command_id=command_id,
                    msg=base_msg,
                    ack_timeout_s=ack_timeout_s,
                    local_ack=local_ack,
                    sent=False,
                )
            else:
                _queue_generic_partial()
            await self._request_reconnect(f"partial_result_ws_not_ready command={command_id}")
            return

        try:
            msg_with_token = self._msg_with_token(dict(base_msg), token=token_snapshot)
            msg_size = len(json.dumps(msg_with_token, default=str).encode("utf-8"))
            should_chunk = (msg_size > self.max_message_size) or (msg_size > self.always_chunk_above)
            if should_chunk:
                effective_chunk_size = min(self.chunk_size, self.always_chunk_size) if msg_size > self.always_chunk_above else self.chunk_size
                chunks = self._split_output_into_chunks(output, effective_chunk_size)
                total_chunks = len(chunks)
                if total_chunks == 1:
                    single_msg = dict(base_msg)
                    # partial_result is never a final command result; this flag is only
                    # about command completion and must stay false for incremental batches.
                    single_msg["is_final"] = False
                    await self._send_on(ws_snapshot, self._msg_with_token(single_msg, token=token_snapshot))
                else:
                    for chunk_info in chunks:
                        if self._ws_generation != ws_gen_snapshot or self._ws is not ws_snapshot:
                            raise ConnectionError("WebSocket changed during partial_result chunk send")
                        chunk_index = chunk_info["chunk_index"]
                        chunk_output = chunk_info["chunk_data"]
                        chunk_msg = {
                            "type": "commands_output",
                            "command_id": command_id,
                            "status": "partial_result",
                            "output": chunk_output,
                            "logs": logs or [] if chunk_index == 0 else [],
                            "alerts": alerts or [] if chunk_index == 0 else [],
                            "metadata": metadata_clean if chunk_index == 0 else {},
                            "chunk_index": chunk_index,
                            "total_chunks": total_chunks,
                            # The last transport chunk completes payload assembly, not the
                            # underlying command. Backend must keep treating it as streaming.
                            "is_final": False,
                        }
                        await self._send_on(ws_snapshot, self._msg_with_token(chunk_msg, token=token_snapshot))
                        if chunk_index < total_chunks - 1:
                            await asyncio.sleep(0.1)
            else:
                await self._send_on(ws_snapshot, msg_with_token)

            if ack_required:
                self._queue_partial_result_for_ack(
                    batch_id=batch_id,
                    command_id=command_id,
                    msg=base_msg,
                    ack_timeout_s=ack_timeout_s,
                    local_ack=local_ack,
                    sent=True,
                )
        except Exception as e:
            error_str = str(e).lower()
            is_transport = (
                "closing transport" in error_str
                or "closed" in error_str
                or "connection" in error_str
                or "not initialized" in error_str
            )
            if ack_required:
                self._queue_partial_result_for_ack(
                    batch_id=batch_id,
                    command_id=command_id,
                    msg=base_msg,
                    ack_timeout_s=ack_timeout_s,
                    local_ack=local_ack,
                    sent=False,
                )
            elif is_transport:
                _queue_generic_partial()
            if is_transport:
                await self._request_reconnect(f"partial_result_send_failed command={command_id}")
                return
            raise

    def _determine_plugin_by_command(self, command):
        """Определяет плагин по команде."""
        command_lower = command.lower()
        
        # Специальные системные команды
        if command_lower in ["list_plugins", "plugins", "help"]:
            return "system"
        
        # Новый формат: plugin:name
        if command_lower.startswith("plugin:"):
            plugin_name = command_lower[7:]  # убираем 'plugin:'
            if plugin_name in self.registry.plugins:
                return plugin_name
            else:
                return None
        
        # Динамически определяем плагин по команде
        for plugin_name, PluginCls in self.registry.plugins.items():
            # Проверяем методы плагина
            for method_name in dir(PluginCls):
                if method_name.startswith('hook_'):
                    # Убираем префикс 'hook_' для сравнения
                    hook_command = method_name[5:]  # убираем 'hook_'
                    if command_lower == hook_command:
                        return plugin_name
        
        # Если команда не найдена в плагинах, возвращаем None (будет использован shell executor)
        return None

    async def send_plugins(self):
        reply = {
            "type": "plugins_list",
            "data": {
                "agent_id": self.agent_id,
                "plugins": self.registry.get_plugins_with_versions()
            }
        }
        await self._send(reply)

    async def on_task_result(self, plugin_name, data, result, error):
        command_id = data.get("command_id")
        logger.debug(f"on_task_result called for command {command_id}, plugin={plugin_name}, has_result={result is not None}, has_error={error is not None}")
        
        # If update was blocked and agent is now idle, trigger update check immediately
        if self._auto_update_was_blocked and self._is_idle_for_update():
            self._auto_update_log("info", f"[AUTO_UPDATE] Agent became idle after task completion, checking for updates immediately", force=True)
            self._auto_update_was_blocked = False
            # Reset last check timestamp to allow immediate update check
            self._auto_update_last_check_ts = 0.0
            # Trigger update check in background (don't await to avoid blocking)
            asyncio.create_task(self._attempt_auto_update())
        
        if error:
            # asyncio.TimeoutError often stringifies to "", which leads to blank stderr/UI.
            # Always include exception class.
            try:
                err_s = str(error).strip()
            except Exception:
                err_s = ""
            if not err_s:
                err_s = type(error).__name__
            elif not err_s.lower().startswith(type(error).__name__.lower()):
                err_s = f"{type(error).__name__}: {err_s}"

            is_timeout = False
            try:
                import asyncio as _asyncio
                is_timeout = isinstance(error, _asyncio.TimeoutError) or type(error).__name__ in {"TimeoutError"}
            except Exception:
                is_timeout = type(error).__name__ in {"TimeoutError"}

            status = "timeout" if is_timeout else "error"
            alerts = ["command_timeout"] if is_timeout else ["command_failed"]

            logger.error(f"Command {command_id} failed: {err_s}")
            output = {
                "stdout": "",
                "stderr": err_s,
                "return_code": 124 if is_timeout else 1,
                "files": []
            }
            err_meta = {"failed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
            pe = data.get("pentest") if isinstance(data.get("pentest"), dict) else None
            if pe:
                err_meta["pentest"] = {
                    k: pe[k] for k in ("campaign_id", "action_id", "assigned_role_key") if k in pe
                }
            await self.send_command_output(
                command_id,
                output=output,
                status=status,
                logs=[{"line": err_s, "level": "error"}],
                alerts=alerts,
                metadata=err_meta,
            )
        else:
            # result может быть tuple (stdout, stderr, return_code, execution_time) или dict
            if isinstance(result, tuple):
                if len(result) == 4:
                    # Новый формат с execution_time
                    stdout, stderr, return_code, execution_time = result
                else:
                    # Старый формат без execution_time
                    stdout, stderr, return_code = result
                    execution_time = None
                
                output = {
                    "stdout": stdout,
                    "stderr": stderr,
                    "return_code": return_code,
                    "files": []
                }
            elif isinstance(result, dict):
                # If plugin returns an explicit error envelope (status=error + return_code/stderr),
                # treat it as a command failure rather than stuffing it into stdout JSON.
                try:
                    if str(result.get("status") or "").lower() == "error" and ("return_code" in result or "stderr" in result):
                        rc = result.get("return_code")
                        try:
                            rc = int(rc) if rc is not None else 1
                        except Exception:
                            rc = 1
                        stderr_msg = ""
                        try:
                            stderr_msg = str(result.get("stderr") or "").strip()
                        except Exception:
                            stderr_msg = ""
                        if not stderr_msg:
                            # Common fallbacks used by plugins / wrappers
                            for k in ("error", "exception", "message", "reason"):
                                v = result.get(k)
                                if isinstance(v, str) and v.strip():
                                    stderr_msg = v.strip()
                                    break
                        if not stderr_msg:
                            stderr_msg = f"Command failed (return_code={rc})"

                        failed_at = None
                        try:
                            md = result.get("metadata") if isinstance(result.get("metadata"), dict) else {}
                            failed_at = md.get("failed_at") or md.get("event_at")
                        except Exception:
                            failed_at = None

                        await self.send_command_output(
                            command_id,
                            output={
                                "stdout": str(result.get("stdout") or ""),
                                "stderr": stderr_msg,
                                "return_code": rc,
                                "files": result.get("files") if isinstance(result.get("files"), list) else [],
                            },
                            status="error",
                            logs=[{"line": stderr_msg, "level": "error"}],
                            alerts=["command_failed"],
                            metadata={"failed_at": failed_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
                        )
                        return
                except Exception:
                    # If anything goes wrong here, fall back to the legacy plugin-result path below.
                    pass

                # Проверяем, является ли это результатом плагина (с полями found, scanned_at и т.д.)
                # Расширяем список признаков результата плагина
                plugin_result_indicators = [
                    "found", "scanned_at", "timestamp", "metadata", "findings", 
                    "check_results", "raw_output", "scan_id", "scan_type", 
                    "severity_summary", "category_summaries", "compliance_summaries",
                    "cis_summaries", "technique_summaries", "process_summaries",
                    "framework_assessments", "all_findings", "changes", "test_results",
                    "endpoints", "scan_start", "scan_end", "assessment_id", "assessment_start",
                    "assets", "services", "connections", "data", "status"  # Asset discovery and other plugins
                ]
                is_plugin_result = any(key in result for key in plugin_result_indicators)
                
                if is_plugin_result:
                    # Это результат плагина - преобразуем в stdout
                    # НЕ усекаем данные - они будут разбиты на части в send_command_output при необходимости
                    import json
                    result_to_serialize = result.copy()
                    
                    # Безопасная функция для сериализации enum и других объектов
                    def safe_serialize(obj):
                        """Safely serialize objects, handling enums and other special types."""
                        import enum
                        # Handle basic types first
                        if obj is None:
                            return None
                        if isinstance(obj, (str, bytes, int, float, bool)):
                            return obj
                        # Handle enum types
                        if isinstance(obj, enum.Enum):
                            try:
                                return obj.value
                            except Exception:
                                return str(obj)
                        # Check for value attribute only if it's not a basic type
                        # But first check if it's actually a string (strings can have attributes in some edge cases)
                        if isinstance(obj, str):
                            return obj
                        # Now check for value attribute safely
                        if hasattr(obj, 'value'):
                            try:
                                value = obj.value
                                # Recursively serialize the value
                                return safe_serialize(value)
                            except (AttributeError, TypeError):
                                # If accessing .value fails, continue to other methods
                                pass
                        # Handle dict-like objects
                        if isinstance(obj, dict):
                            return {k: safe_serialize(v) for k, v in obj.items()}
                        # Handle list-like objects
                        if isinstance(obj, (list, tuple)):
                            return [safe_serialize(item) for item in obj]
                        # Handle objects with __dict__
                        if hasattr(obj, '__dict__'):
                            try:
                                return {k: safe_serialize(v) for k, v in obj.__dict__.items()}
                            except Exception:
                                pass
                        # Final fallback: convert to string
                        return str(obj)
                    
                    # IMPORTANT: For infra plugins with large structured payloads, prefer sending structured
                    # data in `output.data` (so backend can persist it) instead of stuffing everything into stdout.
                    if plugin_name in ("asset_discovery", "infrastructure_intelligence") and isinstance(result.get("data"), dict):
                        output = {
                            "stdout": "",
                            "stderr": "",
                            "return_code": 0,
                            "files": [],
                            "data": safe_serialize(result.get("data")),
                        }
                        execution_time = result.get("execution_time")
                        stdout_str = ""  # for logging below
                    else:
                        # Default: send as JSON string in stdout
                        try:
                            stdout_str = json.dumps(result_to_serialize, indent=2, ensure_ascii=False, default=safe_serialize)
                        except Exception as json_error:
                            logger.error(f"Error serializing plugin result: {json_error}", exc_info=True)
                            # Fallback to simple str serialization
                            stdout_str = json.dumps(result_to_serialize, indent=2, ensure_ascii=False, default=str)
                    
                    # Never log full results; they can be huge and may contain secrets.
                    logger.debug(f"[on_task_result] Plugin result for {plugin_name}; keys={list(result.keys()) if isinstance(result, dict) else 'N/A'}")
                    if isinstance(result, dict) and "data" in result:
                        data = result["data"]
                        if isinstance(data, dict):
                            assets_count = len(data.get("assets", []))
                            services_count = len(data.get("services", []))
                            connections_count = len(data.get("connections", []))
                            logger.debug(f"[on_task_result] Data summary: assets={assets_count} services={services_count} connections={connections_count}")
                    # Check for findings and remediation
                    if isinstance(result, dict) and "findings" in result:
                        findings = result.get("findings", [])
                        logger.debug(f"[on_task_result] Findings count: {len(findings)}")
                        if findings:
                            first_finding = findings[0] if isinstance(findings, list) else None
                            if isinstance(first_finding, dict):
                                logger.debug(f"[on_task_result] First finding keys: {list(first_finding.keys())}")
                    logger.debug(f"[on_task_result] Serialized size: {len(stdout_str)} bytes")
                    
                    if "output" not in locals():
                        output = {
                            "stdout": stdout_str,
                            "stderr": "",
                            "return_code": 0,
                            "files": []
                        }
                        execution_time = result.get("execution_time")
                else:
                    # Это уже правильный формат output
                    output = result
                    execution_time = result.get("execution_time")
            else:
                # Результат может быть dataclass или другим объектом - преобразуем в dict
                import json
                try:
                    # СНАЧАЛА проверяем Pydantic модели (они имеют model_dump)
                    if hasattr(result, "model_dump"):
                        try:
                            result_dict = result.model_dump(mode="json")
                            # НЕ усекаем данные - они будут разбиты на части в send_command_output при необходимости
                            stdout_str = json.dumps(result_dict, indent=2, ensure_ascii=False, default=str)
                            
                            output = {
                                "stdout": stdout_str,
                                "stderr": "",
                                "return_code": 0,
                                "files": []
                            }
                            execution_time = result_dict.get("execution_time") if isinstance(result_dict, dict) else None
                        except Exception as dump_error:
                            logger.warning(f"Error calling model_dump: {dump_error}, trying asdict/dict()")
                            # Fall through to dataclass/dict handling
                            pass
                    
                    # Пробуем преобразовать в dict через asdict для dataclass
                    if "output" not in locals():
                        from dataclasses import asdict, is_dataclass
                        if is_dataclass(result):
                            result_dict = asdict(result)
                            output = {
                                "stdout": json.dumps(result_dict, indent=2, ensure_ascii=False, default=str),
                                "stderr": "",
                                "return_code": 0,
                                "files": []
                            }
                            execution_time = result_dict.get("execution_time") if isinstance(result_dict, dict) else None
                        elif hasattr(result, "model_dump"):
                            # Пробуем через model_dump для Pydantic моделей (если еще не пробовали)
                            try:
                                result_dict = result.model_dump(mode="json")
                                # НЕ усекаем данные - они будут разбиты на части в send_command_output при необходимости
                                stdout_str = json.dumps(result_dict, indent=2, ensure_ascii=False, default=str)
                                
                                output = {
                                    "stdout": stdout_str,
                                    "stderr": "",
                                    "return_code": 0,
                                    "files": []
                                }
                                execution_time = result_dict.get("execution_time") if isinstance(result_dict, dict) else None
                            except Exception as dump_error:
                                logger.warning(f"Error calling model_dump: {dump_error}, trying dict()")
                                try:
                                    result_dict = dict(result)
                                    output = {
                                        "stdout": json.dumps(result_dict, indent=2, ensure_ascii=False, default=str),
                                        "stderr": "",
                                        "return_code": 0,
                                        "files": []
                                    }
                                    execution_time = result_dict.get("execution_time") if isinstance(result_dict, dict) else None
                                except Exception as dict_error:
                                    logger.warning(f"Error converting to dict: {dict_error}, using str representation")
                                    output = {"stdout": str(result), "stderr": "", "return_code": 0, "files": []}
                                    execution_time = None
                        elif hasattr(result, "__dict__"):
                            # Пробуем через __dict__ для обычных объектов
                            try:
                                result_dict = result.__dict__
                                output = {
                                    "stdout": json.dumps(result_dict, indent=2, ensure_ascii=False, default=str),
                                    "stderr": "",
                                    "return_code": 0,
                                    "files": []
                                }
                                execution_time = result_dict.get("execution_time") if isinstance(result_dict, dict) else None
                            except Exception as dict_error:
                                logger.warning(f"Error accessing __dict__: {dict_error}, using str representation")
                                output = {"stdout": str(result), "stderr": "", "return_code": 0, "files": []}
                                execution_time = None
                        else:
                            # Последняя попытка - просто str
                            output = {"stdout": str(result), "stderr": "", "return_code": 0, "files": []}
                            execution_time = None
                except Exception as e:
                    logger.warning(f"Error converting result to dict: {e}, using str representation")
                    output = {"stdout": str(result), "stderr": "", "return_code": 0, "files": []}
                    execution_time = None
            
            # Get working directory from command data
            working_directory = None
            if data.get("command_type") == "shell":
                working_directory = data.get("command_payload", {}).get("working_directory")
            else:
                working_directory = data.get("working_directory")
            
            # If no working directory specified, use current directory
            if not working_directory:
                working_directory = os.getcwd()
            
            metadata = {
                "finished_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            }
            
            if working_directory:
                metadata["working_directory"] = working_directory
            
            if execution_time is not None:
                metadata["execution_time"] = execution_time

            pe = data.get("pentest") if isinstance(data.get("pentest"), dict) else None
            if pe:
                metadata["pentest"] = {
                    k: pe[k] for k in ("campaign_id", "action_id", "assigned_role_key") if k in pe
                }
            
            logger.debug(f"[on_task_result] Sending command output for {command_id} (token_present={self.session_token is not None})")
            if not self.session_token:
                logger.warning(f"[on_task_result] session_token missing before send_command_output; will queue result (command={command_id})")
            try:
                await self.send_command_output(
                    command_id,
                    output=output,
                    status="success",
                    #logs=[{"line": "run ok", "level": "info"}],
                    alerts=[],
                    metadata=metadata
                )
                logger.debug(f"[on_task_result] send_command_output completed for {command_id}")
            except Exception as e:
                error_str = str(e).lower()
                if "closing transport" in error_str or "closed" in error_str or "connection" in error_str or "not initialized" in error_str:
                    logger.warning(f"WebSocket not ready while sending result for {command_id}, result queued for retry")
                    # Result is queued inside send_command_output()
                else:
                    logger.error(f"Error sending command output for {command_id}: {e}")
                    # Добавляем в очередь для повторной отправки (best-effort)
                    self.pending_results.append({
                        "command_id": command_id,
                        "msg": {
                            "type": "commands_output",
                            "command_id": command_id,
                            "status": "success",
                            "output": output,
                            "logs": [],
                            "alerts": [],
                            "metadata": metadata or {}
                        },
                        "timestamp": time.time()
                    })
                    logger.info(f"Added command {command_id} result to pending queue for retry")

    async def send_json(self, msg: dict):
        """
        Отправляет JSON сообщение через WebSocket с автоматическим добавлением session_token.
        Этот метод используется плагинами для отправки сообщений.
        """
        msg_with_token = self._msg_with_token(msg)
        await self._send(msg_with_token)
    
    async def _send(self, msg):
        # Default send uses current websocket.
        return await self._send_on(self._ws, msg)

    async def _send_on(self, ws, msg):
        # Serialize sends so heartbeat/progress/results don't interleave and corrupt transport.
        async with self._send_lock:
            # Детальное логирование перед отправкой
            msg_type = msg.get("type", "unknown")
            logger.debug(f"[_SEND] Preparing to send message type: {msg_type}")
            # Never log token values (even prefixes).
            logger.debug(f"[_SEND] session_token in msg: {'session_token' in msg}")
            logger.debug(f"[_SEND] self.session_token present: {self.session_token is not None}")
            
            # Проверяем, что WebSocket соединение активно
            if not ws:
                try:
                    self._ws_diag_last_send = {
                        "path": "_send_on",
                        "msg_type": msg_type,
                        "bytes_est": int(self._approx_size(msg, depth=1)),
                    }
                    self._ws_diag_last_send_ts = time.time()
                except Exception:
                    pass
                self._log_ws_not_ready(
                    "[_SEND] WebSocket is not initialized",
                    diag_extra={
                        "path": "_send_on",
                        "msg_type": msg_type,
                        "bytes_est": int(self._approx_size(msg, depth=1)),
                    },
                )
                raise ConnectionError("WebSocket is not initialized")
            
            if ws.closed:
                try:
                    logger.error(f"[_SEND] WebSocket is closed ({self._ws_debug_state()})")
                except Exception:
                    logger.error("[_SEND] WebSocket is closed")
                raise ConnectionError("WebSocket is closed")
            
            # Удаляем все None значения из вложенных словарей для корректной сериализации JSON
            def clean_dict(d):
                if isinstance(d, dict):
                    cleaned = {}
                    for k, v in d.items():
                        if k is not None:
                            cleaned_value = clean_dict(v) if v is not None else None
                            if cleaned_value is not None:
                                cleaned[k] = cleaned_value
                    return cleaned
                elif isinstance(d, list):
                    return [clean_dict(item) for item in d if item is not None]
                else:
                    return d
            try:
                # IMPORTANT:
                # `send_msg` is what we actually send to the backend.
                # Never mutate it for logging/masking purposes.
                send_msg = clean_dict(msg)

                # Log a masked copy (do not leak session_token value).
                if self.debug_mode:
                    try:
                        log_msg = json.loads(json.dumps(send_msg, default=str))
                    except Exception:
                        log_msg = dict(send_msg) if isinstance(send_msg, dict) else send_msg
                    if isinstance(log_msg, dict) and "session_token" in log_msg:
                        log_msg["session_token"] = "***"
                    logger.debug(f"WS SEND (cleaned): {json.dumps(log_msg, indent=2, default=str)}")

                # Дополнительная проверка состояния перед отправкой
                # Размер сообщения проверяется в send_command_output, здесь просто отправляем
                msg_str = json.dumps(send_msg, default=str)
                
                # Финальная проверка перед отправкой
                if ws.closed:
                    try:
                        logger.error(f"[_SEND] WebSocket closed before send ({self._ws_debug_state()})")
                    except Exception:
                        logger.error("[_SEND] WebSocket closed before send")
                    raise ConnectionError("WebSocket closed before send")
                
                # Проверяем наличие session_token в сообщении для критичных типов
                if msg_type in ["commands_output", "command_ack", "heartbeat"] and "session_token" not in send_msg:
                    logger.error(f"[_SEND] CRITICAL: Message type {msg_type} missing session_token! self.session_token={self.session_token is not None}")
                    # Не отправляем сообщение без токена - это вызовет ошибку на бэкенде
                    raise ValueError(f"Message type {msg_type} requires session_token but it's missing")
                
                logger.debug(f"[_SEND] Sending message type {msg_type}, size: {len(msg_str)} bytes")
                await ws.send_str(msg_str)
                logger.debug(f"[_SEND] Successfully sent message type {msg_type}")
            except Exception as e:
                error_str = str(e).lower()
                if "closing transport" in error_str or "closed" in error_str or "connection" in error_str:
                    logger.error(f"WebSocket connection error during send: {e}; {self._ws_debug_state()}")
                    raise ConnectionError(f"WebSocket connection error: {e}")
                logger.error(f"Error serializing/sending message: {e}")
                try:
                    safe_preview = msg if not isinstance(msg, dict) else dict(msg)
                    if isinstance(safe_preview, dict) and "session_token" in safe_preview:
                        safe_preview["session_token"] = "***"
                    logger.error(f"Message content (first 500 chars): {str(safe_preview)[:500]}")
                except Exception:
                    logger.error("Message content preview unavailable")
                raise
    
    async def _resend_pending_results(self):
        """Отправляет результаты из очереди после переподключения или получения session_token."""
        if not self.pending_results:
            return
        
        if not self.session_token:
            logger.debug(f"Have {len(self.pending_results)} pending results but no session_token yet, will retry later")
            return
        
        logger.info(f"Resending {len(self.pending_results)} pending command results (session_token available)")
        # Сортируем по timestamp (старые первыми)
        self.pending_results.sort(key=lambda x: x.get("timestamp", 0))
        
        failed_results = []
        for pending in list(self.pending_results):  # Create a copy to iterate
            try:
                command_id = pending.get("command_id")
                msg = pending.get("msg")
                if not msg or not command_id:
                    continue
                
                # Проверяем, что соединение активно
                if not self._ws or self._ws.closed:
                    failed_results.append(pending)
                    continue

                # IMPORTANT:
                # Never resend large results by calling _send() directly, because that bypasses chunking
                # and can immediately drop the WS connection (especially for asset_discovery).
                # If this is a commands_output payload, route through send_command_output() which chunks.
                if isinstance(msg, dict) and msg.get("type") == "commands_output":
                    if msg.get("status") == "partial_result":
                        await self.send_command_partial_result(
                            command_id=command_id,
                            output=msg.get("output") or {},
                            logs=msg.get("logs") or [],
                            alerts=msg.get("alerts") or [],
                            metadata=msg.get("metadata") or {},
                        )
                    else:
                        await self.send_command_output(
                            command_id=command_id,
                            output=msg.get("output") or {},
                            status=msg.get("status") or "succeeded",
                            logs=msg.get("logs") or [],
                            alerts=msg.get("alerts") or [],
                            metadata=msg.get("metadata") or {},
                        )
                else:
                    # For small/non-output messages, _send is fine.
                    await self._send(self._msg_with_token(msg))

                logger.info(f"Successfully resent pending result for command {command_id}")
                # Удаляем из списка после успешной отправки
                self.pending_results = [r for r in self.pending_results if r.get("command_id") != command_id]
            except Exception as e:
                cid = pending.get("command_id")
                logger.warning(f"Failed to resend pending result for command {cid}: {e}")
                # Prevent reconnect storms:
                # If a pending payload repeatedly causes the connection to drop (e.g., backend rejects it),
                # stop retrying it automatically.
                try:
                    pending["failures"] = int(pending.get("failures", 0) or 0) + 1
                except Exception:
                    pending["failures"] = 1
                if pending.get("failures", 0) >= 3:
                    logger.warning(f"Dropping pending result for command {cid} after {pending.get('failures')} failed resend attempts")
                    continue
                # Если результат слишком старый (больше 1 часа), удаляем его
                if time.time() - pending.get("timestamp", 0) > 3600:
                    logger.info(f"Removing stale pending result for command {pending.get('command_id')} (older than 1 hour)")
                else:
                    failed_results.append(pending)
        
        self.pending_results = failed_results
        if self.pending_results:
            logger.warning(f"Still have {len(self.pending_results)} pending results that failed to send")

    def parse_unified_command(self, command_string):
        """
        Парсит единую строку команды в структурированный формат.
        
        Поддерживаемые форматы:
        - "list_plugins" -> системная команда
        - "ls -la" -> shell команда
        - "map" -> auto-detect plugin command
        - "map mode=live" -> plugin command with args
        - "plugin:network_mapper map mode=live" -> explicit plugin with command and args
        - "scan root_dir=/etc max_files=1000" -> plugin command with multiple args
        
        Returns:
            dict: Структурированная команда для обработки
        """
        command_string = command_string.strip()
        
        # Системные команды
        if command_string in ["list_plugins", "plugins", "help"]:
            return {
                "command": command_string,
                "plugin": "system"
            }
        
        def _split_tokens(s: str):
            """
            Split command string into tokens preserving quoted substrings.
            Falls back to simple whitespace split if shlex fails.
            """
            try:
                return shlex.split(s)
            except Exception:
                return s.split()

        # Формат plugin:name command args
        if command_string.startswith("plugin:"):
            tokens = _split_tokens(command_string)
            plugin_part = tokens[0]
            plugin_name = plugin_part[7:]  # убираем 'plugin:'
            
            if len(tokens) > 1:
                # Разбираем команду и аргументы (tokens already preserve quoted values)
                cmd_parts = tokens[1:]
                # Проверяем, является ли первый элемент командой или аргументом
                # Если первый элемент содержит "=", это аргумент, команда = "run"
                if "=" in cmd_parts[0]:
                    # Все части - это аргументы, команда = "run"
                    cmd_name = "run"
                    args = cmd_parts
                else:
                    # Первый элемент - это команда
                    cmd_name = cmd_parts[0]
                    args = cmd_parts[1:] if len(cmd_parts) > 1 else []
                
                # Преобразуем аргументы вида key=value в словарь options
                options = {}
                for arg in args:
                    if "=" in arg:
                        key, value = arg.split("=", 1)
                        # Преобразуем строковые значения в булевы/числа если нужно
                        if value.lower() in ("true", "1", "yes", "on"):
                            options[key] = True
                        elif value.lower() in ("false", "0", "no", "off"):
                            options[key] = False
                        else:
                            try:
                                # Пробуем преобразовать в число
                                if "." in value:
                                    options[key] = float(value)
                                else:
                                    options[key] = int(value)
                            except ValueError:
                                options[key] = value
                    else:
                        # Аргумент без = считается как флаг (True)
                        options[arg] = True
                
                result = {
                    "command": cmd_name,
                    "plugin": plugin_name,
                    "args": args
                }
                if options:
                    result["options"] = options
                
                return result
            else:
                # Только plugin:name без команды
                return {
                    "command": "run",
                    "plugin": plugin_name
                }
        
        # Обычные команды (auto-detect plugin или shell)
        parts = _split_tokens(command_string)
        command = parts[0] if parts else ""
        args = parts[1:] if len(parts) > 1 else []
        
        # Проверяем, является ли это командой плагина
        plugin_name = self._determine_plugin_by_command(command)
        
        if plugin_name:
            return {
                "command": command,
                "plugin": plugin_name,
                "args": args
            }
        else:
            # Shell команда
            return {
                "command": command_string,
                "command_type": "shell",
                "command_payload": {
                    "command": command_string
                }
            }
