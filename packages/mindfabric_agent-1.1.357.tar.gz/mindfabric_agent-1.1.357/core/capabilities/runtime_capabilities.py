from __future__ import annotations

import getpass
import os
import platform
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _status_entry(
    status: str,
    detail: str,
    *,
    path: Optional[str] = None,
) -> Dict[str, Any]:
    entry: Dict[str, Any] = {
        "status": status,
        "detail": detail,
    }
    if path:
        entry["path"] = path
    return entry


def _current_username() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return os.getenv("USER") or os.getenv("USERNAME") or "unknown"


def _safe_get_effective_uid() -> Optional[int]:
    try:
        geteuid = getattr(os, "geteuid", None)
        if callable(geteuid):
            return int(geteuid())
    except Exception:
        pass
    try:
        getuid = getattr(os, "getuid", None)
        if callable(getuid):
            return int(getuid())
    except Exception:
        pass
    return None


def _detect_elevated(platform_name: str) -> tuple[Optional[int], bool]:
    euid = _safe_get_effective_uid()
    if euid is not None:
        return euid, euid == 0

    if platform_name == "windows":
        try:
            import ctypes

            is_admin = bool(ctypes.windll.shell32.IsUserAnAdmin())
            return None, is_admin
        except Exception:
            return None, False

    return None, False


def _check_shadow_access(is_linux: bool) -> Dict[str, Any]:
    if not is_linux:
        return _status_entry("not_applicable", "The /etc/shadow check is only relevant on Linux hosts.")

    shadow_path = "/etc/shadow"
    if os.access(shadow_path, os.R_OK):
        return _status_entry("available", "The agent can read /etc/shadow.", path=shadow_path)

    return _status_entry(
        "unavailable",
        "No read access to /etc/shadow. Password hash and shadow-based account audits will be degraded.",
        path=shadow_path,
    )


def _check_cross_process_memory(is_linux: bool, is_elevated: bool) -> Dict[str, Any]:
    if not is_linux:
        return _status_entry(
            "not_applicable",
            "Cross-process memory inspection is only relevant on Linux hosts.",
        )

    if is_elevated:
        return _status_entry(
            "available",
            "The agent is running with elevated privileges, so privileged process memory inspection is available.",
        )

    return _status_entry(
        "unavailable",
        "Reading other processes' memory usually requires root or CAP_SYS_PTRACE.",
    )


def _check_socket_access(paths: List[str], label: str, *, applicable: bool) -> Dict[str, Any]:
    if not applicable:
        return _status_entry("not_applicable", f"{label} checks are only relevant on Linux hosts.")

    existing_without_access: List[str] = []

    for path in paths:
        if not os.path.exists(path):
            continue
        if os.access(path, os.R_OK | os.W_OK):
            return _status_entry("available", f"The agent can access {label}.", path=path)
        existing_without_access.append(path)

    if existing_without_access:
        return _status_entry(
            "unavailable",
            f"{label} exists, but the agent cannot access it.",
            path=existing_without_access[0],
        )

    # No socket file at known paths: treat as "not here", not a privilege limitation.
    # (When Docker/CRI is installed later, the next registration will re-evaluate.)
    return _status_entry(
        "not_applicable",
        f"{label} was not found at expected paths (runtime may not be installed, or uses a non-default socket).",
    )


def _build_limitations(checks: Dict[str, Dict[str, Any]], *, platform_name: str) -> List[Dict[str, Any]]:
    limitations: List[Dict[str, Any]] = []

    if checks["root_access"]["status"] == "unavailable" and platform_name != "linux":
        limitations.append(
            {
                "id": "elevated_access",
                "title": "Some system-wide inspection is limited",
                "detail": checks["root_access"]["detail"],
                "affected_plugins": ["user_audit", "privilege_escalation", "process_security_scanner"],
            }
        )

    if checks["shadow_access"]["status"] == "unavailable":
        limitations.append(
            {
                "id": "shadow_access",
                "title": "User audit will be degraded",
                "detail": checks["shadow_access"]["detail"],
                "affected_plugins": ["user_audit", "privilege_escalation"],
            }
        )

    if checks["cross_process_memory"]["status"] == "unavailable":
        limitations.append(
            {
                "id": "cross_process_memory",
                "title": "Deep process and memory inspection is limited",
                "detail": checks["cross_process_memory"]["detail"],
                "affected_plugins": ["osint_finder", "process_security_scanner"],
            }
        )

    # Only count container checks as a *limitation* when a socket exists but this process
    # cannot use it. Missing sockets (no Docker on host) are not_applicable and do not
    # downgrade full → standard.
    if (
        checks["docker_socket"]["status"] == "unavailable"
        or checks["container_runtime_socket"]["status"] == "unavailable"
    ):
        limitations.append(
            {
                "id": "container_runtime_access",
                "title": "Container escape checks may be unavailable",
                "detail": "A container runtime socket exists on this host but the agent cannot access it (permissions or ownership).",
                "affected_plugins": ["docker_escape", "kubernetes_escape"],
            }
        )

    return limitations


def _build_recommendations(is_elevated: bool, limitations: List[Dict[str, Any]]) -> List[str]:
    recommendations: List[str] = []

    if not is_elevated:
        recommendations.append("Run the agent with elevated privileges to unlock full host inspection.")

    limitation_ids = {item.get("id") for item in limitations}
    if "elevated_access" in limitation_ids:
        recommendations.append("Install the agent as a system-level service if you need broader host visibility.")
    if "shadow_access" in limitation_ids:
        recommendations.append("Grant read access to /etc/shadow only if shadow-based audits are required.")
    if "cross_process_memory" in limitation_ids:
        recommendations.append("Grant CAP_SYS_PTRACE or run as root if cross-process memory scanning is needed.")
    if "container_runtime_access" in limitation_ids:
        recommendations.append("Add access to Docker or CRI sockets if container escape checks are needed.")

    return recommendations


def collect_runtime_capabilities() -> Dict[str, Any]:
    platform_name = platform.system().lower()
    is_linux = platform_name == "linux"
    privilege_label = "administrator" if platform_name == "windows" else "root"
    euid, is_elevated = _detect_elevated(platform_name)

    checks: Dict[str, Dict[str, Any]] = {
        "root_access": _status_entry(
            "available" if is_elevated else "unavailable",
            (
                f"The agent is running with {privilege_label} privileges."
                if is_elevated
                else f"The agent is not running with {privilege_label} privileges."
            ),
        ),
        "shadow_access": _check_shadow_access(is_linux),
        "cross_process_memory": _check_cross_process_memory(is_linux, is_elevated),
        "docker_socket": _check_socket_access(
            ["/var/run/docker.sock", "/run/docker.sock"],
            "the Docker socket",
            applicable=is_linux,
        ),
        "container_runtime_socket": _check_socket_access(
            [
                "/run/containerd/containerd.sock",
                "/var/run/containerd/containerd.sock",
                "/run/crio/crio.sock",
                "/var/run/crio/crio.sock",
                "/run/k3s/containerd/containerd.sock",
            ],
            "a container runtime socket",
            applicable=is_linux,
        ),
    }

    limitations = _build_limitations(checks, platform_name=platform_name)
    limitation_count = len(limitations)

    if limitation_count == 0:
        mode = "full"
        summary = "Full runtime access is available."
    elif limitation_count == 1:
        mode = "standard"
        summary = "The agent can run normally, but some privileged checks are degraded."
    else:
        mode = "limited"
        summary = "The agent is running in a limited mode with multiple privileged checks unavailable."

    return {
        "schema_version": 1,
        "detected_at": datetime.now(timezone.utc).isoformat(),
        "platform": platform_name,
        "install_scope": os.getenv("MINDFABRIC_INSTALL_SCOPE") or ("system" if is_elevated else "user"),
        "username": _current_username(),
        "euid": euid,
        "is_root": is_elevated,
        "mode": mode,
        "summary": summary,
        "checks": checks,
        "limitations": limitations,
        "recommendations": _build_recommendations(is_elevated, limitations),
    }


def format_runtime_capability_log_lines(summary: Dict[str, Any]) -> List[str]:
    mode = summary.get("mode", "unknown")
    username = summary.get("username", "unknown")
    euid = summary.get("euid", "unknown")
    install_scope = summary.get("install_scope", "unknown")

    lines = [
        f"[capabilities] mode={mode} install_scope={install_scope} user={username} euid={euid}",
    ]

    for limitation in summary.get("limitations", []) or []:
        title = limitation.get("title") or "Limitation"
        detail = limitation.get("detail") or ""
        lines.append(f"[capabilities] {title}: {detail}")

    return lines
