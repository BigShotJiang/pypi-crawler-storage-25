"""
Core executor module for command execution.
"""

from .shell_executor import ShellExecutor
from .stealth_executor import StealthExecutor
from .registry import ExecutorRegistry
from .plugin_subprocess_executor import run_plugin_in_subprocess

__all__ = [
    "ShellExecutor",
    "StealthExecutor",
    "ExecutorRegistry",
    "run_plugin_in_subprocess",
]
