import importlib
import importlib.util
import pkgutil
import inspect
import asyncio
import os
import sys
from plugins.base_plugin import BasePlugin
from utils.logger import logger
from core.executor.plugin_subprocess_executor import run_plugin_in_subprocess

PLUGIN_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../plugins'))

class ExecutorRegistry:
    def __init__(self):
        self.plugins = {}  # name: class
        self.plugin_info = {}  # name: {class, version}

    def load_plugins(self, debug_mode=False):
        """ Автоматически импортировать и зарегистрировать все плагины """
        import time
        start_time = time.time()
        
        for finder, name, ispkg in pkgutil.iter_modules([PLUGIN_DIR]):
            if name == "base_plugin" or name.startswith("_"):
                continue
            try:
                # Оптимизация: сначала пробуем стандартный импорт (самый быстрый)
                module = None
                import_error = None
                
                # Вариант 1: Стандартный импорт через plugins.{name} (самый быстрый путь)
                try:
                    imported_module = importlib.import_module(f"plugins.{name}")
                    # ВАЖНО: для пакетов проверяем, что загрузился пакетный модуль (__init__.py), а не главный модуль
                    if ispkg:
                        # Проверяем по имени модуля И по файлу - для пакетов файл должен быть __init__.py
                        module_file = getattr(imported_module, '__file__', '')
                        module_name = imported_module.__name__
                        
                        # Проверяем, что это пакетный модуль (plugins.{name}), а не главный (plugins.{name}.{name})
                        is_package_module = (
                            module_name == f"plugins.{name}" and
                            module_file and 
                            module_file.endswith('__init__.py')
                        )
                        
                        if is_package_module:
                            module = imported_module
                        else:
                            # Загрузился главный модуль вместо пакетного - загружаем пакетный явно
                            if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                logger.warning(f"[REGISTRY] {name}: Module {module_name} (file: {module_file}) is not package module (expected plugins.{name} with __init__.py), loading __init__.py explicitly")
                            init_path = os.path.join(PLUGIN_DIR, name, "__init__.py")
                            if os.path.exists(init_path):
                                try:
                                    package_module_name = f"plugins.{name}"
                                    # Если пакетный модуль уже загружен, используем его
                                    if package_module_name in sys.modules:
                                        package_module = sys.modules[package_module_name]
                                        if package_module.__name__ == package_module_name:
                                            module = package_module
                                        else:
                                            # Перезагружаем пакетный модуль
                                            package_spec = importlib.util.spec_from_file_location(
                                                package_module_name, 
                                                init_path,
                                                submodule_search_locations=[os.path.dirname(init_path)]
                                            )
                                            package_module = importlib.util.module_from_spec(package_spec)
                                            sys.modules[package_module_name] = package_module
                                            package_module.__package__ = package_module_name
                                            package_module.__name__ = package_module_name
                                            package_spec.loader.exec_module(package_module)
                                            module = package_module
                                    else:
                                        # Загружаем пакетный модуль впервые
                                        package_spec = importlib.util.spec_from_file_location(
                                            package_module_name, 
                                            init_path,
                                            submodule_search_locations=[os.path.dirname(init_path)]
                                        )
                                        package_module = importlib.util.module_from_spec(package_spec)
                                        sys.modules[package_module_name] = package_module
                                        package_module.__package__ = package_module_name
                                        package_module.__name__ = package_module_name
                                        package_spec.loader.exec_module(package_module)
                                        module = package_module
                                except Exception as e_pkg:
                                    if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                        logger.error(f"[REGISTRY] {name}: Failed to load package module: {e_pkg}")
                                        import traceback
                                        logger.error(f"[REGISTRY] {name}: Traceback:\n{traceback.format_exc()}")
                                    # Fallback to imported module
                                    module = imported_module
                            else:
                                # No __init__.py, use imported module
                                module = imported_module
                    else:
                        module = imported_module
                except ImportError as e:
                    import_error = str(e)
                    # Вариант 2: Импорт через agent.plugins.{name} (только если первый не сработал)
                    try:
                        module = importlib.import_module(f"agent.plugins.{name}")
                    except ImportError as e2:
                        import_error = str(e2)
                        # Вариант 3: Загрузка через __init__.py если это пакет (только если первые два не сработали)
                        if ispkg:
                            try:
                                # Сначала попробуем загрузить через стандартный импорт
                                try:
                                    module = importlib.import_module(f"plugins.{name}")
                                except (ImportError, ModuleNotFoundError, AttributeError, SyntaxError) as e:
                                    import_error = str(e)
                                    # Если не получилось, загружаем через правильный путь
                                    init_path = os.path.join(PLUGIN_DIR, name, "__init__.py")
                                    if os.path.exists(init_path):
                                        try:
                                            # Устанавливаем правильный parent package
                                            parent_module_name = "plugins"
                                            if parent_module_name not in sys.modules:
                                                # Создаем родительский модуль если его нет
                                                parent_init = os.path.join(PLUGIN_DIR, "__init__.py")
                                                if os.path.exists(parent_init):
                                                    parent_spec = importlib.util.spec_from_file_location(
                                                        parent_module_name, parent_init
                                                    )
                                                    if parent_spec:
                                                        parent_module = importlib.util.module_from_spec(parent_spec)
                                                        sys.modules[parent_module_name] = parent_module
                                            
                                            # Загружаем главный модуль плагина ПЕРЕД загрузкой __init__.py
                                            # Это важно, чтобы класс был доступен при импорте в __init__.py
                                            main_file = os.path.join(PLUGIN_DIR, name, f"{name}.py")
                                            main_module = None
                                            if os.path.exists(main_file):
                                                try:
                                                    main_module_name = f"plugins.{name}.{name}"
                                                    main_spec = importlib.util.spec_from_file_location(main_module_name, main_file)
                                                    main_module = importlib.util.module_from_spec(main_spec)
                                                    sys.modules[main_module_name] = main_module
                                                    # Устанавливаем правильный parent
                                                    main_module.__package__ = f"plugins.{name}"
                                                    main_module.__name__ = main_module_name
                                                    # Загружаем модуль, но игнорируем ошибки в подмодулях
                                                    try:
                                                        main_spec.loader.exec_module(main_module)
                                                    except Exception as e_main:
                                                        if debug_mode:
                                                            logger.debug(f"Warning loading main module {name}.{name} (some submodules may have errors): {e_main}")
                                                        # Продолжаем даже если есть ошибки в подмодулях
                                                except Exception as e_main:
                                                    if debug_mode:
                                                        logger.debug(f"Error loading main module {name}.{name}: {e_main}")
                                                    pass  # Игнорируем ошибки загрузки подмодулей
                                            
                                            # Загружаем пакет плагина (__init__.py)
                                            package_module_name = f"plugins.{name}"
                                            package_spec = importlib.util.spec_from_file_location(
                                                package_module_name, 
                                                init_path,
                                                submodule_search_locations=[os.path.dirname(init_path)]
                                            )
                                            package_module = importlib.util.module_from_spec(package_spec)
                                            sys.modules[package_module_name] = package_module
                                            package_module.__package__ = package_module_name
                                            package_module.__name__ = package_module_name
                                            
                                            # Теперь выполняем __init__.py (он должен импортировать класс из главного модуля)
                                            try:
                                                package_spec.loader.exec_module(package_module)
                                                module = package_module
                                            except Exception as e_init:
                                                # Если __init__.py не может загрузиться (например, из-за отсутствия зависимостей),
                                                # но главный модуль загружен, используем его
                                                if main_module:
                                                    if debug_mode:
                                                        logger.debug(f"Warning: __init__.py for {name} failed to load ({e_init}), using main module directly")
                                                    module = main_module
                                                else:
                                                    # Если главный модуль тоже не загружен, пробуем загрузить его сейчас
                                                    if os.path.exists(main_file):
                                                        try:
                                                            main_module_name = f"plugins.{name}.{name}"
                                                            main_spec = importlib.util.spec_from_file_location(main_module_name, main_file)
                                                            main_module = importlib.util.module_from_spec(main_spec)
                                                            sys.modules[main_module_name] = main_module
                                                            if hasattr(main_module, '__package__'):
                                                                main_module.__package__ = f"plugins.{name}"
                                                            main_module.__name__ = main_module_name
                                                            main_spec.loader.exec_module(main_module)
                                                            module = main_module
                                                            if debug_mode:
                                                                logger.debug(f"Loaded main module {name}.{name} as fallback after __init__.py failed")
                                                        except Exception as e_main_fallback:
                                                            if debug_mode:
                                                                logger.debug(f"Could not load main module as fallback for {name}: {e_main_fallback}")
                                                            # Продолжаем с package_module даже если он не полностью загружен
                                                            module = package_module
                                                    else:
                                                        # Нет главного файла, используем package_module как есть
                                                        if debug_mode:
                                                            logger.debug(f"No main file for {name}, using package_module despite import error")
                                                        module = package_module
                                        except Exception as e3:
                                            import_error = str(e3)
                            except Exception as e3:
                                import_error = str(e3)
                        # Вариант 4: Загрузка напрямую из файла
                        if not module:
                            module_path = os.path.join(PLUGIN_DIR, f"{name}.py")
                            if os.path.exists(module_path):
                                try:
                                    spec = importlib.util.spec_from_file_location(name, module_path)
                                    module = importlib.util.module_from_spec(spec)
                                    spec.loader.exec_module(module)
                                except Exception as e4:
                                    import_error = str(e4)
                
                if module:
                    # Найдём класс-плагин
                    plugin_class = None
                    
                    # Собираем все классы плагинов из модуля
                    plugin_classes = []
                    package_module = module  # Сохраняем ссылку на пакетный модуль (__init__.py)
                    
                    # ПРИОРИТЕТ 1: Если это пакет с __all__, сначала проверяем __all__ (класс может быть импортирован в __init__.py)
                    if ispkg and hasattr(package_module, '__all__'):
                        # Сначала пробуем найти класс в package_module
                        found_in_package = False
                        __all__ = getattr(package_module, '__all__', [])
                        # Log for debugging problematic plugins
                        if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                            logger.info(f"[REGISTRY] {name}: Checking __all__ = {__all__}, hasattr checks: {[hasattr(package_module, item) for item in __all__]}")
                        for item_name in __all__:
                            try:
                                if hasattr(package_module, item_name):
                                    obj = getattr(package_module, item_name)
                                    if inspect.isclass(obj):
                                        try:
                                            if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                                plugin_classes.append((item_name, obj))
                                                module = package_module  # Используем пакетный модуль
                                                found_in_package = True
                                                if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                    logger.info(f"[REGISTRY] {name}: Found plugin class {item_name} in package_module")
                                                break  # Нашли класс, можно прекращать поиск
                                        except (TypeError, AttributeError) as e:
                                            if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                logger.warning(f"[REGISTRY] {name}: Class {item_name} is not a BasePlugin subclass: {e}")
                                            continue
                                    else:
                                        if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                            logger.warning(f"[REGISTRY] {name}: {item_name} is not a class, type: {type(obj)}")
                                else:
                                    if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                        logger.warning(f"[REGISTRY] {name}: {item_name} not found in package_module, dir: {[x for x in dir(package_module) if not x.startswith('_')][:10]}")
                            except Exception as e:
                                if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                    logger.error(f"[REGISTRY] {name}: Exception checking {item_name}: {e}")
                                continue
                        
                        # Если не нашли в package_module, пробуем загрузить главный модуль напрямую
                        if not found_in_package:
                            main_file = os.path.join(PLUGIN_DIR, name, f"{name}.py")
                            if os.path.exists(main_file):
                                try:
                                    main_module_name = f"plugins.{name}.{name}"
                                    main_module = None
                                    
                                    # Проверяем, не загружен ли уже модуль
                                    if main_module_name in sys.modules:
                                        main_module = sys.modules[main_module_name]
                                    else:
                                        # Загружаем главный модуль напрямую
                                        main_spec = importlib.util.spec_from_file_location(main_module_name, main_file)
                                        main_module = importlib.util.module_from_spec(main_spec)
                                        sys.modules[main_module_name] = main_module
                                        if hasattr(main_module, '__package__'):
                                            main_module.__package__ = f"plugins.{name}"
                                        main_module.__name__ = main_module_name
                                        try:
                                            main_spec.loader.exec_module(main_module)
                                        except Exception as e_main:
                                            # Log errors for problematic plugins even in production
                                            if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                logger.error(f"[REGISTRY] {name}: Error loading main module: {e_main}")
                                                import traceback
                                                logger.error(f"[REGISTRY] {name}: Traceback:\n{traceback.format_exc()}")
                                            elif debug_mode:
                                                logger.debug(f"Warning loading main module {name}.{name} (some submodules may have errors): {e_main}")
                                            # Продолжаем даже если есть ошибки в подмодулях
                                    
                                    # Ищем классы в главном модуле по именам из __all__
                                    if main_module:
                                        __all__ = getattr(package_module, '__all__', [])
                                        if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                            logger.info(f"[REGISTRY] {name}: Searching main_module for classes from __all__: {__all__}")
                                        for item_name in __all__:
                                            try:
                                                if hasattr(main_module, item_name):
                                                    obj = getattr(main_module, item_name)
                                                    if inspect.isclass(obj):
                                                        try:
                                                            if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                                                # Импортируем класс в package_module для доступа
                                                                setattr(package_module, item_name, obj)
                                                                plugin_classes.append((item_name, obj))
                                                                module = package_module
                                                                found_in_package = True
                                                                if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                                    logger.info(f"[REGISTRY] {name}: Found and imported {item_name} from main_module to package_module")
                                                                break
                                                        except (TypeError, AttributeError) as e:
                                                            if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                                logger.warning(f"[REGISTRY] {name}: {item_name} is not a BasePlugin subclass: {e}")
                                                            continue
                                                else:
                                                    if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                        logger.warning(f"[REGISTRY] {name}: {item_name} not found in main_module, available: {[x for x in dir(main_module) if not x.startswith('_') and inspect.isclass(getattr(main_module, x, None))][:10]}")
                                            except Exception as e:
                                                if name in ["osint_finder", "process_security_scanner", "kubernetes_escape"]:
                                                    logger.error(f"[REGISTRY] {name}: Exception checking {item_name} in main_module: {e}")
                                                continue
                                        
                                        # Если нашли класс в главном модуле, используем package_module
                                        if found_in_package:
                                            break
                                        
                                        # Если не нашли по именам из __all__, ищем все BasePlugin подклассы в главном модуле
                                        for member_name, obj in inspect.getmembers(main_module, inspect.isclass):
                                            try:
                                                if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                                    # Проверяем, есть ли это имя в __all__
                                                    if member_name in package_module.__all__:
                                                        setattr(package_module, member_name, obj)
                                                        plugin_classes.append((member_name, obj))
                                                        module = package_module
                                                        found_in_package = True
                                                        break
                                            except (TypeError, AttributeError):
                                                continue
                                except Exception as e:
                                    if debug_mode:
                                        logger.debug(f"Error loading main module for {name} from __all__ check: {e}")
                                    continue
                    
                    # ПРИОРИТЕТ 2: Если не нашли через __all__, проверяем все классы в модуле
                    if not plugin_classes:
                        for member_name, obj in inspect.getmembers(module, inspect.isclass):
                            try:
                                if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                    plugin_classes.append((member_name, obj))
                            except (TypeError, AttributeError):
                                continue
                    
                    # Если все еще не нашли, проверяем все атрибуты пакетного модуля напрямую
                    if not plugin_classes and ispkg:
                        for attr_name in dir(package_module):
                            if attr_name.startswith('_'):
                                continue
                            try:
                                obj = getattr(package_module, attr_name)
                                if inspect.isclass(obj):
                                    try:
                                        if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                            plugin_classes.append((attr_name, obj))
                                            module = package_module  # Используем пакетный модуль
                                    except (TypeError, AttributeError):
                                        continue
                            except Exception:
                                continue
                    
                    # Если все еще не нашли, но это пакет, попробуем загрузить главный файл
                    if not plugin_classes and ispkg:
                        main_file = os.path.join(PLUGIN_DIR, name, f"{name}.py")
                        if os.path.exists(main_file):
                            try:
                                main_module_name = f"plugins.{name}.{name}"
                                # Проверяем, не загружен ли уже модуль
                                if main_module_name in sys.modules:
                                    main_module = sys.modules[main_module_name]
                                else:
                                    main_spec = importlib.util.spec_from_file_location(main_module_name, main_file)
                                    main_module = importlib.util.module_from_spec(main_spec)
                                    sys.modules[main_module_name] = main_module
                                    # Устанавливаем правильный parent
                                    if hasattr(main_module, '__package__'):
                                        main_module.__package__ = f"plugins.{name}"
                                    main_module.__name__ = main_module_name
                                    try:
                                        main_spec.loader.exec_module(main_module)
                                    except Exception as e_main:
                                        if debug_mode:
                                            logger.debug(f"Warning loading main module {name}.{name} (some submodules may have errors): {e_main}")
                                        # Продолжаем даже если есть ошибки в подмодулях
                                
                                # Ищем классы в главном модуле
                                for member_name, obj in inspect.getmembers(main_module, inspect.isclass):
                                    try:
                                        if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                            plugin_classes.append((member_name, obj))
                                    except (TypeError, AttributeError):
                                        continue
                                
                                # Если нашли классы в главном модуле, используем его
                                if plugin_classes:
                                    module = main_module
                            except Exception as e:
                                if debug_mode:
                                    logger.debug(f"Error loading main module for {name}: {e}")
                                pass
                        
                        # Если все еще не нашли, пробуем найти класс напрямую в главном модуле по имени
                        if not plugin_classes:
                            main_file = os.path.join(PLUGIN_DIR, name, f"{name}.py")
                            if os.path.exists(main_file):
                                try:
                                    main_module_name = f"plugins.{name}.{name}"
                                    if main_module_name in sys.modules:
                                        main_module = sys.modules[main_module_name]
                                        # Ищем класс по ожидаемому имени
                                        expected_class_names = [
                                            f"{name.replace('_', ' ').title().replace(' ', '')}Plugin",
                                            f"{''.join(word.capitalize() for word in name.split('_'))}Plugin",
                                            name.replace('_', '').capitalize() + "Plugin",
                                            # Also try without "Plugin" suffix for some plugins
                                            f"{name.replace('_', ' ').title().replace(' ', '')}",
                                            f"{''.join(word.capitalize() for word in name.split('_'))}",
                                        ]
                                        for class_name in expected_class_names:
                                            if hasattr(main_module, class_name):
                                                obj = getattr(main_module, class_name)
                                                if inspect.isclass(obj):
                                                    try:
                                                        if (issubclass(obj, BasePlugin) and obj is not BasePlugin):
                                                            plugin_classes.append((class_name, obj))
                                                            module = main_module
                                                            break
                                                    except (TypeError, AttributeError):
                                                        continue
                                except Exception:
                                    pass
                    
                    if not plugin_classes:
                        if debug_mode:
                            logger.warning(f"Failed to load plugin {name}: No plugin class found in module")
                        # Log even in production for osint_finder to debug
                        if name == "osint_finder":
                            logger.warning(f"[REGISTRY] osint_finder: No plugin class found. Module: {module}, has __all__: {hasattr(module, '__all__')}, members: {[m for m in dir(module) if not m.startswith('_')][:10]}")
                    elif len(plugin_classes) == 1:
                        # Если только один класс - используем его
                        plugin_class = plugin_classes[0][1]
                    else:
                        # Если несколько классов, выбираем по имени
                        expected_class_names = [
                            f"{name.replace('_', ' ').title().replace(' ', '')}Plugin",
                            f"{''.join(word.capitalize() for word in name.split('_'))}Plugin",
                            name.replace('_', '').capitalize() + "Plugin",
                            # Also try without "Plugin" suffix for some plugins
                            f"{name.replace('_', ' ').title().replace(' ', '')}",
                            f"{''.join(word.capitalize() for word in name.split('_'))}",
                        ]
                        
                        # Сначала ищем по точному совпадению
                        for member_name, obj in plugin_classes:
                            if member_name in expected_class_names:
                                plugin_class = obj
                                break
                        
                        # Если не нашли, ищем по паттерну
                        if not plugin_class:
                            plugin_name_lower = name.lower().replace("_", "")
                            for member_name, obj in plugin_classes:
                                class_name_lower = member_name.lower()
                                if (plugin_name_lower in class_name_lower or 
                                    class_name_lower.endswith("plugin")):
                                    plugin_class = obj
                                    break
                        
                        # Если все еще не нашли, проверяем __all__
                        if not plugin_class and hasattr(module, '__all__'):
                            for member_name, obj in plugin_classes:
                                if member_name in module.__all__:
                                    plugin_class = obj
                                    break
                        
                        # Последняя попытка - берем первый
                        if not plugin_class:
                            plugin_class = plugin_classes[0][1]
                    
                    if plugin_class:
                        if debug_mode:
                            logger.info(f"Registering plugin: {name}")
                        # Пропускаем плагины с None именем
                        if name is not None:
                            self.plugins[name] = plugin_class
                            # Сохраняем информацию о плагине включая версию
                            self.plugin_info[name] = {
                                'class': plugin_class,
                                'version': getattr(plugin_class, 'VERSION', '1.0.0')
                            }
                            # Log osint_finder registration even in production
                            if name == "osint_finder":
                                logger.info(f"[REGISTRY] Successfully registered osint_finder plugin")
                            # Log c2_commander and network_protocol_attacker registration
                            if name in ["c2_commander", "network_protocol_attacker"]:
                                logger.info(f"[REGISTRY] Successfully registered {name} plugin")
                            # Log kubernetes_escape and process_security_scanner registration
                            if name in ["kubernetes_escape", "process_security_scanner"]:
                                logger.info(f"[REGISTRY] Successfully registered {name} plugin")
                    else:
                        if debug_mode:
                            logger.warning(f"Failed to load plugin {name}: No plugin class found in module")
                        # Log even in production for osint_finder to debug
                        if name == "osint_finder":
                            logger.warning(f"[REGISTRY] osint_finder: plugin_class is None. plugin_classes: {plugin_classes}")
                        # Log c2_commander and network_protocol_attacker errors
                        if name in ["c2_commander", "network_protocol_attacker"]:
                            logger.error(f"[REGISTRY] {name}: plugin_class is None. plugin_classes: {plugin_classes}, module: {module}, has __all__: {hasattr(module, '__all__') if module else 'N/A'}")
                        # Log kubernetes_escape and process_security_scanner errors
                        if name in ["kubernetes_escape", "process_security_scanner"]:
                            logger.error(f"[REGISTRY] {name}: plugin_class is None. plugin_classes: {plugin_classes}, module: {module}, has __all__: {hasattr(module, '__all__') if module else 'N/A'}, ispkg: {ispkg}")
                else:
                    if debug_mode:
                        logger.warning(f"Failed to load plugin {name}: Could not import module. Error: {import_error}")
                    # Log even in production for osint_finder to debug
                    if name == "osint_finder":
                        logger.error(f"[REGISTRY] osint_finder: Could not import module. Error: {import_error}")
                        # Try to provide more context
                        import traceback
                        logger.error(f"[REGISTRY] osint_finder: Full traceback:\n{traceback.format_exc()}")
                    # Log c2_commander and network_protocol_attacker errors
                    if name in ["c2_commander", "network_protocol_attacker"]:
                        logger.error(f"[REGISTRY] {name}: Could not import module. Error: {import_error}")
            except Exception as e:
                if debug_mode:
                    import traceback
                    logger.warning(f"Failed to load plugin {name}: {e}\n{traceback.format_exc()}")
                # Log even in production for osint_finder to debug
                if name == "osint_finder":
                    import traceback
                    logger.error(f"[REGISTRY] osint_finder: Exception during load: {e}\n{traceback.format_exc()}")
                # Log c2_commander and network_protocol_attacker errors
                if name in ["c2_commander", "network_protocol_attacker"]:
                    import traceback
                    logger.error(f"[REGISTRY] {name}: Exception during load: {e}\n{traceback.format_exc()}")
                # В production режиме просто пропускаем ошибки плагинов
        
        elapsed = time.time() - start_time
        if elapsed > 1.0:  # Log only if loading took more than 1 second
            logger.info(f"[REGISTRY] Plugin loading completed in {elapsed:.2f}s ({len(self.plugins)} plugins loaded)")

    def get_plugin_versions(self):
        """Возвращает словарь с версиями всех плагинов."""
        return {name: info['version'] for name, info in self.plugin_info.items()}

    def get_plugins_with_versions(self):
        """Возвращает список плагинов с их версиями (+ описание и функции, если доступны)."""
        result = []
        for name, info in self.plugin_info.items():
            if name is not None:  # Пропускаем плагины с None именем
                version = info.get('version') if isinstance(info, dict) else None
                if version is None:
                    version = '1.0.0'  # Дефолтная версия
                plugin_class = None
                try:
                    plugin_class = info.get("class") if isinstance(info, dict) else None
                except Exception:
                    plugin_class = None

                description = None
                functions = []
                try:
                    if plugin_class:
                        description = getattr(plugin_class, "DESCRIPTION", None) or (getattr(plugin_class, "__doc__", None) or "")
                        if isinstance(description, str):
                            description = description.strip().splitlines()[0].strip() if description.strip() else None
                        # Expose available entrypoints: run + hook_* methods.
                        functions = ["run"]
                        for attr in dir(plugin_class):
                            if attr.startswith("hook_"):
                                try:
                                    fn = getattr(plugin_class, attr)
                                    if callable(fn):
                                        functions.append(attr[5:])
                                except Exception:
                                    continue
                        # Deduplicate while preserving order
                        seen = set()
                        deduped = []
                        for f in functions:
                            if f in seen:
                                continue
                            seen.add(f)
                            deduped.append(f)
                        functions = deduped
                except Exception:
                    # Never fail registration payload generation due to metadata issues
                    description = None
                    functions = []
                result.append({
                    'name': name,
                    'version': version,
                    **({'description': description} if description else {}),
                    **({'functions': functions} if functions else {})
                })
        return result

    async def execute(self, plugin_name, data, ws):
        # Ensure data is a dict and options is properly set
        plugin_options = data if data and isinstance(data, dict) else {}
        # Merge options from data.get("options") into plugin_options
        if "options" in data and isinstance(data["options"], dict):
            plugin_options = {**plugin_options, **data["options"]}
        
        # ---------------------------------------------------------------------
        # TEST MODE: return mock output before instantiating plugin
        # Some plugins may raise during __init__ in constrained environments.
        # Enabled via: plugin:<name> test_output=true
        # ---------------------------------------------------------------------
        test_output_val = plugin_options.get("test_output")
        test_output_enabled = False
        if test_output_val is True:
            test_output_enabled = True
        elif isinstance(test_output_val, str):
            test_output_enabled = test_output_val.strip().lower() in ("true", "1", "yes", "on")
        elif isinstance(test_output_val, (int, float)):
            test_output_enabled = bool(test_output_val)

        if plugin_name != "database_connector" and test_output_enabled:
            try:
                from plugins.mock_outputs import get_mock_output  # type: ignore
                mock_output = get_mock_output(plugin_name, options=plugin_options)
            except Exception as e:
                logger.warning(f"[Registry] Failed to load mock output for {plugin_name}: {e}")
                mock_output = None

            if mock_output is None:
                return {"error": f"No mock output available for plugin {plugin_name}"}

            # Normalize all security plugin outputs (mock + real) to a single canonical contract
            try:
                from plugins.security_contract import normalize_security_output  # type: ignore

                return normalize_security_output(plugin_name, mock_output, plugin_options=plugin_options)
            except Exception as e:
                logger.warning(f"[Registry] Failed to normalize mock output for {plugin_name}: {e}")
                return mock_output

        if plugin_name not in self.plugins:
            raise RuntimeError(f"Unknown plugin: {plugin_name}")
        PluginCls = self.plugins[plugin_name]

        # ---------------------------------------------------------------------
        # Execution model: each plugin runs in a dedicated subprocess.
        # This provides memory isolation on small hosts and prevents plugin-level leaks from
        # destabilizing the main agent process.
        #
        # WS interactions from plugins are proxied via IPC and forwarded by the parent.
        # ---------------------------------------------------------------------
        try:
            plugin_module = getattr(PluginCls, "__module__", "") or ""
            plugin_class = getattr(PluginCls, "__name__", "") or ""
        except Exception:
            plugin_module = ""
            plugin_class = ""
        if not plugin_module or not plugin_class:
            raise RuntimeError(f"Plugin {plugin_name} has invalid class metadata for subprocess execution")

        timeout_ms = None
        try:
            timeout_ms = int(plugin_options.get("timeout") or data.get("timeout") or 0) or None
        except Exception:
            timeout_ms = None

        return await run_plugin_in_subprocess(
            plugin_name=plugin_name,
            plugin_module=plugin_module,
            plugin_class=plugin_class,
            data=data,
            ws=ws,
            timeout_ms=timeout_ms,
        )
