"""
Plugin subprocess executor (parent-side).

Runs plugin code in an isolated Python subprocess while forwarding WS calls
back to the real WebSocketAgentClient via an IPC stream (JSONL on stdout).
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

from utils.logger import logger

# Directory that contains `core/` and `utils/` (agent package root). Subprocess `-m core...`
# uses sys.path; without this, a non-agent cwd causes ModuleNotFoundError for core/utils.
_PLUGIN_SUBPROCESS_AGENT_ROOT = str(Path(__file__).resolve().parents[2])


async def _drain_stderr(
    stream: asyncio.StreamReader, *, prefix: str, ring: Optional[list[str]] = None
) -> None:
    try:
        while True:
            line = await stream.readline()
            if not line:
                return
            s = line.decode("utf-8", errors="replace").rstrip("\n")
            if s:
                logger.info(f"{prefix}{s}")
                if ring is not None:
                    ring.append(s)
                    # Keep only a short tail for error context.
                    if len(ring) > 80:
                        del ring[:-80]
    except Exception:
        return


async def run_plugin_in_subprocess(
    *,
    plugin_name: str,
    plugin_module: str,
    plugin_class: str,
    data: dict,
    ws: Any,
    timeout_ms: Optional[int] = None,
) -> Any:
    """
    Execute a plugin in a subprocess and return its final result (Python object).

    During execution, IPC "event" messages are forwarded to the real ws client.
    """
    payload = {
        "plugin_name": plugin_name,
        "plugin_module": plugin_module,
        "plugin_class": plugin_class,
        "data": data,
    }

    _env = os.environ.copy()
    _pp = _env.get("PYTHONPATH", "").strip()
    _env["PYTHONPATH"] = (
        _PLUGIN_SUBPROCESS_AGENT_ROOT + (os.pathsep + _pp if _pp else "")
    )

    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "core.executor.plugin_subprocess_entrypoint",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=_PLUGIN_SUBPROCESS_AGENT_ROOT,
        env=_env,
    )

    assert proc.stdin and proc.stdout and proc.stderr

    # Send payload
    proc.stdin.write(json.dumps(payload, default=str).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()

    stderr_tail: list[str] = []
    stderr_task = asyncio.create_task(
        _drain_stderr(
            proc.stderr, prefix=f"[plugin:{plugin_name}:stderr] ", ring=stderr_tail
        )
    )

    async def _forward_event(name: str, payload: dict) -> None:
        try:
            if name == "send_json":
                msg = payload.get("msg")
                if isinstance(msg, dict) and hasattr(ws, "send_json"):
                    await ws.send_json(msg)
                return
            if name == "send_command_progress" and hasattr(ws, "send_command_progress"):
                await ws.send_command_progress(
                    payload.get("command_id"),
                    payload.get("progress"),
                    output=payload.get("output"),
                    logs=payload.get("logs"),
                    alerts=payload.get("alerts"),
                    metadata=payload.get("metadata"),
                )
                return
            if name == "send_command_partial_result" and hasattr(ws, "send_command_partial_result"):
                await ws.send_command_partial_result(
                    payload.get("command_id"),
                    payload.get("output"),
                    logs=payload.get("logs"),
                    alerts=payload.get("alerts"),
                    metadata=payload.get("metadata"),
                )
                return
            if name == "send_command_output" and hasattr(ws, "send_command_output"):
                await ws.send_command_output(
                    payload.get("command_id"),
                    output=payload.get("output"),
                    status=payload.get("status"),
                    logs=payload.get("logs"),
                    alerts=payload.get("alerts"),
                    metadata=payload.get("metadata"),
                )
                return
            if name == "send_file_upload" and hasattr(ws, "send_file_upload"):
                await ws.send_file_upload(
                    payload.get("command_id"),
                    file_url=payload.get("file_url"),
                    payload_b64=payload.get("payload_b64"),
                    filename=payload.get("filename"),
                    size=payload.get("size"),
                    metadata=payload.get("metadata"),
                )
                return
            if name == "upload_artifact_file" and hasattr(ws, "upload_artifact_file"):
                await ws.upload_artifact_file(
                    command_id=payload.get("command_id"),
                    file_path=payload.get("file_path"),
                    filename=payload.get("filename"),
                    content_type=payload.get("content_type") or "application/octet-stream",
                    upload_id=payload.get("upload_id"),
                    chunk_bytes=int(payload.get("chunk_bytes") or (48 * 1024)),
                )
                return
        except Exception as e:
            logger.debug(f"[plugin_subprocess] forward_event failed name={name}: {e}")

    async def _read_result() -> Any:
        """
        Read JSONL messages from subprocess stdout.

        IMPORTANT:
        `StreamReader.readline()` can raise `LimitOverrunError: Separator is found, but chunk is longer than limit`
        when a single JSON line exceeds asyncio's internal limit (~64KiB). Some plugins produce large results,
        so we implement a chunked reader and split on newlines ourselves.
        """
        buf = b""
        max_line_bytes = 10 * 1024 * 1024  # 10MB safety cap for a single JSONL line
        while True:
            try:
                chunk = await proc.stdout.read(64 * 1024)
            except Exception as e:
                raise RuntimeError(f"Failed reading plugin subprocess stdout (plugin={plugin_name}): {e}")

            if not chunk:
                # Flush any remaining buffer as a last attempt
                if buf.strip():
                    s = buf.decode("utf-8", errors="replace").strip()
                    try:
                        msg = json.loads(s)
                        if msg.get("kind") == "result":
                            if msg.get("ok") is True:
                                return msg.get("result")
                            err = str(msg.get("error") or "plugin_error")
                            tb = str(msg.get("traceback") or "")
                            raise RuntimeError(f"{err}\n{tb}".strip())
                    except Exception:
                        pass
                rc = proc.returncode
                if rc is None:
                    try:
                        rc = await asyncio.wait_for(proc.wait(), timeout=0.2)
                    except Exception:
                        rc = None
                tail = "\n".join(stderr_tail[-20:]).strip()
                details = f" (return_code={rc})" if rc is not None else ""
                if tail:
                    raise RuntimeError(
                        f"Plugin subprocess exited without result (plugin={plugin_name}){details}.\n"
                        f"stderr_tail:\n{tail}"
                    )
                raise RuntimeError(
                    f"Plugin subprocess exited without result (plugin={plugin_name}){details}"
                )

            buf += chunk

            # Protect against runaway output with no newlines
            if b"\n" not in buf and len(buf) > max_line_bytes:
                raise RuntimeError(
                    f"Plugin subprocess stdout line exceeded {max_line_bytes} bytes without newline "
                    f"(plugin={plugin_name})."
                )

            while b"\n" in buf:
                raw_line, buf = buf.split(b"\n", 1)
                if not raw_line.strip():
                    continue
                if len(raw_line) > max_line_bytes:
                    raise RuntimeError(
                        f"Plugin subprocess JSONL line exceeded {max_line_bytes} bytes (plugin={plugin_name})."
                    )
                s = raw_line.decode("utf-8", errors="replace").strip()
                try:
                    msg = json.loads(s)
                except Exception:
                    logger.debug(f"[plugin_subprocess] non-json stdout for {plugin_name}: {s[:500]}")
                    continue
                kind = msg.get("kind")
                if kind == "event":
                    await _forward_event(
                        str(msg.get("name") or ""),
                        msg.get("payload") if isinstance(msg.get("payload"), dict) else {},
                    )
                    continue
                if kind == "result":
                    if msg.get("ok") is True:
                        return msg.get("result")
                    err = str(msg.get("error") or "plugin_error")
                    tb = str(msg.get("traceback") or "")
                    raise RuntimeError(f"{err}\n{tb}".strip())

    try:
        if timeout_ms and int(timeout_ms) > 0:
            res = await asyncio.wait_for(_read_result(), timeout=float(timeout_ms) / 1000.0)
        else:
            res = await _read_result()
        return res
    except asyncio.TimeoutError:
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=2.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        raise
    except asyncio.CancelledError:
        try:
            proc.terminate()
        except Exception:
            pass
        raise
    finally:
        try:
            await proc.wait()
        except Exception:
            pass
        try:
            stderr_task.cancel()
        except Exception:
            pass

