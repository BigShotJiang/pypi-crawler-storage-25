"""
Helpers to import plugin modules inside the plugin subprocess.

Some deployments ship a wheel where `import plugins.<name>` should work, but
namespace / layout edge cases can still fail. We fall back to loading
`plugins/<name>/__init__.py` from the same install tree that contains both
`core/` and `plugins/` (e.g. site-packages).
"""

from __future__ import annotations

import importlib
import importlib.util
import os
import sys
import types
from typing import Optional


def _find_install_root_with_plugins() -> Optional[str]:
    """Walk upward from this file until we find siblings `core/` and `plugins/`."""
    here = os.path.dirname(os.path.abspath(__file__))
    cur = here
    for _ in range(12):
        parent = os.path.dirname(cur)
        if os.path.isdir(os.path.join(parent, "plugins")) and os.path.isdir(
            os.path.join(parent, "core")
        ):
            return parent
        if parent == cur:
            break
        cur = parent
    return None


def _load_plugin_package_from_fs(plugin_name: str) -> Optional[types.ModuleType]:
    """
    Load `plugins.<plugin_name>` by executing its __init__.py from disk.
    Preloads `plugins.<plugin_name>.<plugin_name>` when present so __init__ can import it.
    """
    root = _find_install_root_with_plugins()
    if not root:
        return None
    pkg_dir = os.path.join(root, "plugins", plugin_name)
    init_py = os.path.join(pkg_dir, "__init__.py")
    if not os.path.isfile(init_py):
        return None

    pkg_name = f"plugins.{plugin_name}"
    main_py = os.path.join(pkg_dir, f"{plugin_name}.py")

    # Ensure parent namespace `plugins` exists (minimal stub if missing)
    if "plugins" not in sys.modules:
        plugins_init = os.path.join(root, "plugins", "__init__.py")
        if os.path.isfile(plugins_init):
            spec = importlib.util.spec_from_file_location(
                "plugins",
                plugins_init,
                submodule_search_locations=[os.path.dirname(plugins_init)],
            )
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                sys.modules["plugins"] = mod
                spec.loader.exec_module(mod)
        else:
            plugins_pkg = types.ModuleType("plugins")
            plugins_pkg.__path__ = [os.path.join(root, "plugins")]  # type: ignore[attr-defined]
            sys.modules["plugins"] = plugins_pkg

    # Preload main implementation module (registry does the same)
    if os.path.isfile(main_py):
        main_name = f"{pkg_name}.{plugin_name}"
        if main_name not in sys.modules:
            main_spec = importlib.util.spec_from_file_location(main_name, main_py)
            if main_spec and main_spec.loader:
                main_mod = importlib.util.module_from_spec(main_spec)
                sys.modules[main_name] = main_mod
                main_mod.__package__ = pkg_name
                main_mod.__name__ = main_name
                try:
                    main_spec.loader.exec_module(main_mod)
                except Exception:
                    pass

    if pkg_name in sys.modules:
        return sys.modules[pkg_name]

    spec = importlib.util.spec_from_file_location(
        pkg_name,
        init_py,
        submodule_search_locations=[pkg_dir],
    )
    if not spec or not spec.loader:
        return None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[pkg_name] = mod
    mod.__path__ = [pkg_dir]  # type: ignore[attr-defined]
    spec.loader.exec_module(mod)
    return mod


def _load_exact_plugin_submodule_from_fs(
    module_name: str, plugin_name: str
) -> Optional[types.ModuleType]:
    """
    Best-effort load for exact plugin module, e.g.
    `plugins.infrastructure_intelligence.infrastructure_intelligence`.
    """
    root = _find_install_root_with_plugins()
    if not root:
        return None
    main_py = os.path.join(root, "plugins", plugin_name, f"{plugin_name}.py")
    if not os.path.isfile(main_py):
        return None
    if module_name in sys.modules:
        return sys.modules[module_name]
    spec = importlib.util.spec_from_file_location(module_name, main_py)
    if not spec or not spec.loader:
        return None
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = f"plugins.{plugin_name}"
    mod.__name__ = module_name
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod


def import_plugin_module(module_name: str, plugin_name: str):
    """
    Import a plugin module by dotted name, with filesystem fallback for `plugins.<name>`.
    """
    first_error: Optional[ModuleNotFoundError] = None
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError as e:
        first_error = e
        if not plugin_name or not module_name.startswith("plugins."):
            raise

    _load_plugin_package_from_fs(plugin_name)
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError:
        pass

    # Direct fallback to exact module file when package import path is inconsistent.
    try:
        mod = _load_exact_plugin_submodule_from_fs(module_name, plugin_name)
        if mod is not None:
            return mod
    except ModuleNotFoundError:
        pass

    # Submodule-only case: e.g. plugins.foo.bar while package stub was missing from sys.path
    if module_name.count(".") >= 3 and module_name.startswith("plugins."):
        parent = module_name.rsplit(".", 1)[0]
        if parent.startswith("plugins.") and parent.count(".") >= 2:
            try:
                importlib.import_module(parent)
                return importlib.import_module(module_name)
            except ModuleNotFoundError:
                pass

    if first_error is not None:
        raise first_error
    raise ModuleNotFoundError(f"No module named {module_name!r}")
