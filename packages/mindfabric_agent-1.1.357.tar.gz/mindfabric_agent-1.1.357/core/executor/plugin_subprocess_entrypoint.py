"""
Subprocess entrypoint for running a single plugin execution.

This module is invoked by the parent agent process as:

  python -m core.executor.plugin_subprocess_entrypoint

It reads a single JSON payload from stdin, runs the requested plugin/hook,
emits JSONL "event" messages to stdout (IPC stream), and finally emits a
single JSONL "result" message.

IMPORTANT:
- We redirect regular stdout (prints) to stderr to keep the stdout stream clean for IPC.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import sys
import traceback
from typing import Any, Dict, Optional

from core.executor.plugin_import_utils import import_plugin_module

# Setup logger for subprocess (so plugin logs go to stderr and are captured by parent)
from utils.logger import setup_logger
setup_logger(log_level="INFO", log_dir=None)  # Use default log dir


class _IPC:
    def __init__(self, out):
        self._out = out

    def event(self, name: str, payload: Optional[dict] = None) -> None:
        try:
            msg = {"kind": "event", "name": str(name), "payload": payload or {}}
            self._out.write(json.dumps(msg, default=str) + "\n")
            self._out.flush()
        except Exception:
            # Never crash plugin execution due to IPC serialization.
            pass

    def result_ok(self, result: Any) -> None:
        msg = {"kind": "result", "ok": True, "result": result}
        self._out.write(json.dumps(msg, default=str) + "\n")
        self._out.flush()

    def result_err(self, err: str, tb: str) -> None:
        msg = {"kind": "result", "ok": False, "error": err, "traceback": tb}
        self._out.write(json.dumps(msg, default=str) + "\n")
        self._out.flush()


class SubprocessWSProxy:
    """
    Minimal WS proxy exposed to plugins when running in a subprocess.

    Methods emit IPC events; the parent agent forwards them to the real WS client.
    """

    def __init__(self, ipc: _IPC):
        self._ipc = ipc

    async def send_json(self, msg: dict):
        self._ipc.event("send_json", {"msg": msg})

    async def send_command_progress(self, command_id, progress, output=None, logs=None, alerts=None, metadata=None):
        self._ipc.event(
            "send_command_progress",
            {
                "command_id": command_id,
                "progress": progress,
                "output": output or {},
                "logs": logs or [],
                "alerts": alerts or [],
                "metadata": metadata or {},
            },
        )

    async def send_command_partial_result(self, command_id, output, logs=None, alerts=None, metadata=None):
        self._ipc.event(
            "send_command_partial_result",
            {
                "command_id": command_id,
                "output": output,
                "logs": logs or [],
                "alerts": alerts or [],
                "metadata": metadata or {},
            },
        )

    async def send_command_output(self, command_id, output, status="success", logs=None, alerts=None, metadata=None):
        self._ipc.event(
            "send_command_output",
            {
                "command_id": command_id,
                "output": output,
                "status": status,
                "logs": logs or [],
                "alerts": alerts or [],
                "metadata": metadata or {},
            },
        )

    async def send_file_upload(self, command_id, file_url=None, payload_b64=None, filename=None, size=None, metadata=None):
        self._ipc.event(
            "send_file_upload",
            {
                "command_id": command_id,
                "file_url": file_url,
                "payload_b64": payload_b64,
                "filename": filename,
                "size": size,
                "metadata": metadata or {},
            },
        )

    async def upload_artifact_file(
        self,
        command_id: str,
        file_path: str,
        *,
        filename: Optional[str] = None,
        content_type: str = "application/octet-stream",
        upload_id: Optional[str] = None,
        chunk_bytes: int = 48 * 1024,
    ) -> None:
        self._ipc.event(
            "upload_artifact_file",
            {
                "command_id": command_id,
                "file_path": file_path,
                "filename": filename,
                "content_type": content_type,
                "upload_id": upload_id,
                "chunk_bytes": chunk_bytes,
            },
        )


def _merge_plugin_options(data: dict) -> dict:
    plugin_options = dict(data) if isinstance(data, dict) else {}
    opts = data.get("options") if isinstance(data, dict) else None
    if isinstance(opts, dict):
        plugin_options = {**plugin_options, **opts}
    return plugin_options


def _compact_final_result_for_ipc(plugin_name: str, result: Any) -> Any:
    """
    Keep subprocess IPC results compact for plugins that already stream rich data.
    This prevents the final JSONL result from blocking on a full pipe.
    """
    if plugin_name != "osint_finder" or not isinstance(result, dict):
        return result

    findings = result.get("findings")
    if not isinstance(findings, list):
        findings = result.get("found")
    findings_count = len(findings) if isinstance(findings, list) else 0

    compact = {
        "status": result.get("status", "success"),
        "scanned_at": result.get("scanned_at"),
        "mode": result.get("mode"),
        "summary": result.get("summary") if isinstance(result.get("summary"), dict) else {},
    }
    compact["summary"] = {
        **compact["summary"],
        "findings_count": findings_count,
        "ipc_compacted": True,
    }
    if result.get("error"):
        compact["error"] = result.get("error")
    if result.get("note"):
        compact["note"] = result.get("note")
    return compact


async def _call_plugin(plugin_inst: Any, plugin_name: str, data: dict, plugin_options: dict) -> Any:
    try:
        # Check if a specific hook command is requested
        command = data.get("command", "run")
        sys.stderr.write(f"[_call_plugin] Plugin {plugin_name}, command: {command}\n")
        sys.stderr.flush()

        if isinstance(command, str) and command.startswith("hook_"):
            hook_name = command[5:]
            meth_name = f"hook_{hook_name}"
            sys.stderr.write(f"[_call_plugin] Looking for hook method: {meth_name}\n")
            sys.stderr.flush()
            if hasattr(plugin_inst, meth_name):
                hook_method = getattr(plugin_inst, meth_name)
                sys.stderr.write(f"[_call_plugin] Found hook method {meth_name}, calling it\n")
                sys.stderr.flush()
                if inspect.iscoroutinefunction(hook_method):
                    result = await hook_method()
                else:
                    result = await asyncio.to_thread(hook_method)
                sys.stderr.write(f"[_call_plugin] Hook method {meth_name} completed\n")
                sys.stderr.flush()
                return result

        if command != "run" and isinstance(command, str) and hasattr(plugin_inst, f"hook_{command}"):
            hook_method = getattr(plugin_inst, f"hook_{command}")
            sys.stderr.write(f"[_call_plugin] Found hook_{command}, calling it\n")
            sys.stderr.flush()
            if inspect.iscoroutinefunction(hook_method):
                result = await hook_method()
            else:
                result = await asyncio.to_thread(hook_method)
            sys.stderr.write(f"[_call_plugin] hook_{command} completed\n")
            sys.stderr.flush()
            return result

        if not hasattr(plugin_inst, "run"):
            raise RuntimeError(f"Plugin {plugin_name} missing run method")

        runner = plugin_inst.run
        sig = inspect.signature(runner)
        params = [p for p in sig.parameters.keys() if p != "self"]
        
        sys.stderr.write(f"[_call_plugin] Calling run() method, params: {params}\n")
        sys.stderr.flush()

        if params:
            call_kwargs = {k: plugin_options[k] for k in params if k in plugin_options}
            sys.stderr.write(f"[_call_plugin] Calling run() with kwargs: {list(call_kwargs.keys())}\n")
            sys.stderr.flush()
            if inspect.iscoroutinefunction(runner):
                result = await runner(**call_kwargs)
            else:
                result = await asyncio.to_thread(runner, **call_kwargs)
            sys.stderr.write(f"[_call_plugin] run() completed\n")
            sys.stderr.flush()
            return result

        sys.stderr.write(f"[_call_plugin] Calling run() without params\n")
        sys.stderr.flush()
        if inspect.iscoroutinefunction(runner):
            result = await runner()
        else:
            result = await asyncio.to_thread(runner)
        sys.stderr.write(f"[_call_plugin] run() completed\n")
        sys.stderr.flush()
        return result
    except Exception as e:
        error_msg = f"[_call_plugin] ERROR calling plugin {plugin_name}: {e}\n{traceback.format_exc()}"
        sys.stderr.write(error_msg + "\n")
        sys.stderr.flush()
        raise


async def main() -> int:
    ipc_out = sys.stdout
    # Redirect regular stdout to stderr to keep stdout clean for IPC JSONL.
    sys.stdout = sys.stderr
    ipc = _IPC(ipc_out)

    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw else {}
        plugin_name = str(payload.get("plugin_name") or "")
        module_name = str(payload.get("plugin_module") or "")
        class_name = str(payload.get("plugin_class") or "")
        data = payload.get("data") if isinstance(payload.get("data"), dict) else {}

        if not plugin_name or not module_name or not class_name:
            raise RuntimeError("Missing plugin_name/plugin_module/plugin_class")

        plugin_options = _merge_plugin_options(data)

        mod = import_plugin_module(module_name, plugin_name)
        PluginCls = getattr(mod, class_name)

        ws = SubprocessWSProxy(ipc)
        plugin_inst = PluginCls(ws=ws, command_id=plugin_options.get("command_id", "unknown"), options=plugin_options)

        # Log plugin execution start
        sys.stderr.write(f"[PLUGIN_SUBPROCESS] Calling plugin {plugin_name}.{class_name}.run()\n")
        sys.stderr.flush()
        
        result = await _call_plugin(plugin_inst, plugin_name, data, plugin_options)
        
        sys.stderr.write(f"[PLUGIN_SUBPROCESS] Plugin {plugin_name} returned result, type: {type(result)}\n")
        sys.stderr.flush()

        # Normalize security outputs (same behavior as parent registry)
        try:
            from plugins.security_contract import normalize_security_output  # type: ignore

            sys.stderr.write(f"[PLUGIN_SUBPROCESS] Normalizing security output for {plugin_name}\n")
            sys.stderr.flush()
            
            result = normalize_security_output(plugin_name, result, plugin_options=plugin_options)
            
            sys.stderr.write(f"[PLUGIN_SUBPROCESS] Normalization completed for {plugin_name}\n")
            sys.stderr.flush()
        except Exception as e:
            sys.stderr.write(f"[PLUGIN_SUBPROCESS] Normalization failed for {plugin_name}: {e}\n")
            sys.stderr.flush()
            pass

        sys.stderr.write(f"[PLUGIN_SUBPROCESS] Sending result_ok for {plugin_name}\n")
        sys.stderr.flush()
        
        ipc.result_ok(_compact_final_result_for_ipc(plugin_name, result))
        return 0
    except Exception as e:
        error_msg = f"[PLUGIN_SUBPROCESS] Exception in main() for {plugin_name}: {e}\n{traceback.format_exc()}"
        sys.stderr.write(error_msg + "\n")
        sys.stderr.flush()
        ipc.result_err(str(e), traceback.format_exc())
        return 1


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        raise SystemExit(130)

