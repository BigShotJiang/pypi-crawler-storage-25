"""
Installation integrity helpers for the agent runtime.

These helpers avoid mixed deployments where Python imports parts of the agent
from different install roots (for example, a stale checkout and a newer
site-packages install). They can also clear local __pycache__ trees during
install/update flows to reduce stale bytecode issues after upgrades.
"""

from __future__ import annotations

import importlib
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Optional


_AGENT_ROOT_MARKERS = ("core", "plugins", "utils")
_AGENT_MODULE_PREFIXES = ("core", "plugins", "utils", "config")


@dataclass
class InstallationIntegrityReport:
    current_root: Path
    discovered_roots: List[Path]
    foreign_roots: List[Path]
    cleared_pycache_dirs: List[Path] = field(default_factory=list)
    dropped_modules: List[str] = field(default_factory=list)


def _normalize_root(path: os.PathLike[str] | str) -> Optional[Path]:
    try:
        resolved = Path(path).resolve()
    except Exception:
        return None
    if not resolved.is_dir():
        return None
    if all((resolved / marker).is_dir() for marker in _AGENT_ROOT_MARKERS):
        return resolved
    return None


def _module_matches_agent_namespace(name: str) -> bool:
    return any(name == prefix or name.startswith(f"{prefix}.") for prefix in _AGENT_MODULE_PREFIXES)


def _is_path_under_root(module_path: Path, root: Path) -> bool:
    try:
        module_path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def discover_agent_roots(extra_paths: Optional[Iterable[os.PathLike[str] | str]] = None) -> List[Path]:
    roots: List[Path] = []
    seen = set()
    candidates = list(sys.path)
    if extra_paths:
        candidates.extend(str(path) for path in extra_paths)

    for candidate in candidates:
        if not candidate:
            continue
        root = _normalize_root(candidate)
        if root is None:
            continue
        key = str(root)
        if key in seen:
            continue
        seen.add(key)
        roots.append(root)

    return roots


def clear_local_pycache(root: os.PathLike[str] | str) -> List[Path]:
    root_path = Path(root).resolve()
    cleared: List[Path] = []
    for current_root, dirnames, _filenames in os.walk(root_path):
        if "__pycache__" not in dirnames:
            continue
        pycache_dir = Path(current_root) / "__pycache__"
        try:
            shutil.rmtree(pycache_dir)
            cleared.append(pycache_dir)
        except Exception:
            continue
    return cleared


def prepare_runtime_environment(
    *,
    current_root: Optional[os.PathLike[str] | str] = None,
    clean_pycache: bool = False,
) -> InstallationIntegrityReport:
    root = _normalize_root(current_root or Path(__file__).resolve().parents[1])
    if root is None:
        raise RuntimeError("Could not determine agent install root")

    sys.path[:] = [entry for entry in sys.path if entry]
    root_str = str(root)
    sys.path[:] = [entry for entry in sys.path if str(Path(entry).resolve()) != root_str] if sys.path else []
    sys.path.insert(0, root_str)

    discovered_roots = discover_agent_roots([root])
    foreign_roots = [candidate for candidate in discovered_roots if candidate != root]

    dropped_modules: List[str] = []
    if foreign_roots:
        for module_name, module in list(sys.modules.items()):
            if not _module_matches_agent_namespace(module_name):
                continue
            module_file = getattr(module, "__file__", None)
            if not module_file:
                continue
            module_path = Path(module_file)
            if any(_is_path_under_root(module_path, foreign_root) for foreign_root in foreign_roots):
                sys.modules.pop(module_name, None)
                dropped_modules.append(module_name)

    importlib.invalidate_caches()

    cleared_pycache_dirs: List[Path] = []
    if clean_pycache:
        cleared_pycache_dirs = clear_local_pycache(root)

    return InstallationIntegrityReport(
        current_root=root,
        discovered_roots=discovered_roots,
        foreign_roots=foreign_roots,
        cleared_pycache_dirs=cleared_pycache_dirs,
        dropped_modules=dropped_modules,
    )


def format_root_summary(roots: Iterable[Path]) -> str:
    return ", ".join(sorted(str(path) for path in roots))
