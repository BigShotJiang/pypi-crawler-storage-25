import os
import sys
import json
import random
import socket
from pathlib import Path


def _to_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")

# Словарь распространённых слов для генерации имён агентов
AGENT_NAME_WORDS = [
    "alpha", "beta", "gamma", "delta", "echo", "foxtrot", "golf", "hotel", "india", "juliet",
    "kilo", "lima", "mike", "november", "oscar", "papa", "quebec", "romeo", "sierra", "tango",
    "uniform", "victor", "whiskey", "xray", "yankee", "zulu",
    "phoenix", "thunder", "shadow", "storm", "blaze", "fury", "nova", "cosmic", "quantum",
    "cyber", "digital", "neon", "matrix", "pixel", "binary", "code", "data", "flux", "wave",
    "guardian", "sentinel", "watcher", "scout", "ranger", "hunter", "tracker", "seeker",
    "explorer", "discovery", "venture", "quest", "journey", "pathfinder", "navigator"
]

def generate_agent_name():
    """Генерирует случайное имя агента из словаря слов"""
    word1 = random.choice(AGENT_NAME_WORDS)
    word2 = random.choice(AGENT_NAME_WORDS)
    number = random.randint(1, 9999)
    return f"{word1}-{word2}-{number}"

def load_config():
    # Переменные окружения имеют приоритет над config.json
    base_dir = Path(__file__).parent
    config_path = os.getenv("AGENT_CONFIG") or str(base_dir / "config.json")
    config = {}
    if not os.path.exists(config_path):
        # `config.json` is intentionally not tracked (may contain secrets).
        # Ship a safe default config with the package and use it as fallback.
        fallback_path = str(base_dir / "config.example.json")
        if os.path.exists(fallback_path):
            config_path = fallback_path

    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)

    # Получаем hostname для использования по умолчанию
    hostname = socket.gethostname()
    
    # Получаем agent_name из ENV или config, если не указан или пустой - используем hostname
    agent_name = os.getenv("AGENT_NAME") or config.get("agent_name")
    if not agent_name or agent_name.strip() == "" or agent_name == "unknown":
        agent_name = hostname

    # Получаем access_key из ENV или config
    access_key = os.getenv("ACCESS_KEY") or config.get("access_key", "")
    
    # ENV переменные имеют приоритет над значениями из файла
    return {
        "agent_name": agent_name,  # Если не указан в config, будет hostname
        "access_key": access_key,
        "backend_url": os.getenv("BACKEND_URL") or config.get("backend_url", "agent.mindfabric.ai"),
        "backend_ws_url": os.getenv("BACKEND_WS_URL") or config.get("backend_ws_url", config.get("backend_url", "agent.mindfabric.ai")),
        "debug_mode": _to_bool(os.getenv("DEBUG_MODE"), config.get("debug_mode", False)),
        "stealth_mode": _to_bool(os.getenv("STEALTH_MODE"), config.get("stealth_mode", False)),
        "log_level": os.getenv("LOG_LEVEL") or config.get("log_level", "INFO"),
        # Политика безопасности: запрещать удалённые shell-команды из бэкенда (разрешены только команды плагинов)
        "allow_remote_shell": _to_bool(os.getenv("ALLOW_REMOTE_SHELL"), config.get("allow_remote_shell", False)),
        # For test environments where we only need mock outputs, skip heavy plugin imports.
        "skip_plugin_loading": _to_bool(os.getenv("SKIP_PLUGIN_LOADING"), config.get("skip_plugin_loading", False)),
    }
