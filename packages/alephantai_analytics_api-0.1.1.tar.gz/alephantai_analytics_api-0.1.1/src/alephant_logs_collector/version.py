from importlib import metadata

__version__ = metadata.version("alephantai-analytics-api")
