import torch
import torch.nn as nn
from .wrapper import UniversalDriftSDK
from .decision import DecisionMaker
from .adapter import LocalAdapter

class FDAVRS(nn.Module):
    """
    Federated Drift-Aware Vision Reliability System (FDAVRS).
    A wrapper that adds self-healing and federated learning capabilities.
    """
    def __init__(self, client_model, feature_layer='avgpool', threshold=0.3):
        super(FDAVRS, self).__init__() 
        self.model = client_model
        
        # Initialize Sub-Systems
        self.monitor = UniversalDriftSDK(client_model, feature_layer_name=feature_layer)
        self.brain = DecisionMaker(high_drift_threshold=0.8, low_drift_threshold=threshold)
        self.adapter = LocalAdapter(client_model)
        
        # Initialize Logs
        self.last_action = "IDLE"
        self.last_metrics = {'score': 0.0, 'entropy': 0.0, 'shift': 0.0, 'confidence': 1.0}

    def fit(self, dataloader):
        """Calibrates the SDK baseline using clean data."""
        self.monitor.fit_baseline(dataloader)

    def fit_baseline(self, dataloader):
        """Alias for backward compatibility."""
        self.fit(dataloader)

    def predict(self, x):
        """Inference with real-time drift monitoring and adaptation."""
        self.model.eval()
        
        # 1. Initial Inference
        with torch.no_grad():
            logits = self.model(x)
        
        # 2. Get Metrics & Decide
        metrics = self.monitor.predict_metrics(logits)
        self.last_metrics = metrics
        
        brain_action = self.brain.decide(metrics)
        self.last_action = brain_action 
        
        # # 3. Synchronize Knowledge & Adapt
        self.last_action = self.adapter.synchronize_knowledge(
            x, metrics, brain_action, self.monitor, self.brain.low_thresh
        )
        # pass
        # 4. Final Forward Pass (if adapted)
        if self.last_action in ["KNOWLEDGE_BRIDGE_CREATED", "PASSIVE_DISCOVERY"]:
            with torch.no_grad():
                logits = self.model(x)
        
        return logits

    def forward(self, x):
        """Allows the wrapper to be called directly like a PyTorch model."""
        return self.predict(x)

    def status(self):
        """Returns the current operational state and drift metrics."""
        return {
            "action": self.last_action,
            "metrics": self.last_metrics
        }