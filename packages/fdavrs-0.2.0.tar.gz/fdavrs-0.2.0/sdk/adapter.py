import torch
import torch.nn as nn
import os
import json
import datetime
import requests  # NEW: For talking to the server
import base64    # NEW: For decoding the server's weights
import io        # NEW: For loading the weights into PyTorch

# The URL where your Uvicorn server is running
SERVER_URL = "http://127.0.0.1:8000"

class LocalAdapter:
    def __init__(self, model):
        self.model = model
        self.vault_path = os.path.normpath(os.path.join(os.getcwd(), "server", "local_knowledge_vault"))
        os.makedirs(self.vault_path, exist_ok=True)
        is_yolo = hasattr(model, 'names') or (hasattr(model, 'model') and hasattr(model.model, 'names'))
        self.model_type = "yolo" if is_yolo else "resnet"
        self.has_discovered = False   # blocks re-deposit
        self.cure_applied = False     # blocks re-querying server after cure is applied

    def adapt(self, inputs):
        """Universal Test-Time Adaptation: Updates normalization layers locally."""
        self.model.train() 
        with torch.no_grad():
            for _ in range(5):
                _ = self.model(inputs)
        self.model.eval()

    def apply_global_update(self, b64_weights):
        """NEW: Decodes Base64 weights from the server and patches the local model."""
        weight_bytes = base64.b64decode(b64_weights)
        buffer = io.BytesIO(weight_bytes)
        
        # Load the PyTorch state dictionary from the buffer
        global_state_dict = torch.load(buffer, map_location=next(self.model.parameters()).device, weights_only=True)
        
        # Apply the weights to the model (strict=False ensures we only overwrite BN layers)
        self.model.load_state_dict(global_state_dict, strict=False)
        print(" ⚡ [SDK] SUCCESS! Global Cure Applied Instantly. Skipped Local TTA.")

    def deposit_to_server(self, initial_metrics, final_score, weight_file):
        """NEW: Sends the locally discovered cure to the global server."""
        print(" 📤 [SDK] Depositing new knowledge to Federated Server...")
        payload = {
            "drift_signature": {
                "entropy": float(initial_metrics.get('entropy', 0)),
                "shift": float(initial_metrics.get('shift', 0)),
                "sample_count": 32
            },
            "model_type": self.model_type,
            "final_reliability": float(1.0 - final_score), # Assuming reliability is 1 - score
            "weight_delta_ref": weight_file,
            "client_id": "client_node_live"
        }
        try:
            res = requests.post(f"{SERVER_URL}/deposit", json=payload, timeout=3)
            if res.status_code == 200:
                print(" ✅ [SDK] Deposit Successful! Network is now protected.")
        except Exception as e:
            print(f" ⚠️ [SDK] Server unreachable for deposit: {e}")

    def synchronize_knowledge(self, images, metrics, brain_action, monitor, low_thresh):
        """
        Policy Engine: Upgraded to 'Server-First Query Strategy'
        """
        if self.cure_applied:
            return brain_action 
            
        drift_score = metrics.get('score', 0)
        
        # 1. DRIFT DETECTED: First, try to ask the Server for a cure
        if brain_action in ["REQUEST_SERVER_CURE", "LOCAL_ADAPTATION"]:
            print(f" 🔍 [SDK] Drift Score {drift_score:.2f} > Threshold. Querying Server...")
            
            query_payload = {
                "drift_signature": {
                    "entropy": float(metrics.get('entropy', 0)),
                    "shift": float(metrics.get('shift', 0)),
                    "sample_count": 32
                },
                "model_type": self.model_type,
                "reliability": float(1.0 - drift_score),
                "client_id": "client_node_live"
            }
            
            try:
                res = requests.post(f"{SERVER_URL}/query", json=query_payload, timeout=3)
                if res.status_code == 200 and res.json().get("match_found"):
                    b64_weights = res.json().get("global_delta")
                    
                    # APPLY THE CURE!
                    self.apply_global_update(b64_weights)
                    self.cure_applied = True
                    return "GLOBAL_CURE_APPLIED"
                else:
                    print(" ❌ [SDK] Server reported NO MATCH found.")
            except Exception as e:
                print(f" ⚠️ [SDK] Server unreachable: {e}")

            # 2. NO MATCH FOUND: Fallback to Local Adaptation
            print(" 🔄 [SDK] Falling back to Local Test-Time Adaptation...")
            self.adapt(images)
            
            with torch.no_grad():
                logits = self.model(images)
            post_metrics = monitor.predict_metrics(logits)
            
            # 3. SUCCESSFUL RECOVERY: Save locally AND deposit to server
            if post_metrics['score'] <= low_thresh:
                weight_file = self.save_knowledge_package(post_metrics['score'], metrics)
                self.deposit_to_server(metrics, post_metrics['score'], weight_file)
                self.has_discovered = True
                return "KNOWLEDGE_BRIDGE_CREATED"
                
            return "LOCAL_ADAPTATION"
            
        elif (self.model_type == "yolo" and brain_action == "IDLE" and drift_score > 0.06): 
            self.adapt(images)
            self.save_knowledge_package(drift_score, metrics)
            self.has_discovered = True
            return "PASSIVE_DISCOVERY"
            
        return brain_action

    def save_knowledge_package(self, final_score, initial_metrics, n_samples=32):
        """Saves weights and JSON locally. Modified to return the filename."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        state = {k: v.cpu() for k, v in self.model.state_dict().items() 
                 if 'norm' in k.lower() or 'bn' in k.lower()}
        
        weight_file = f"weights_{timestamp}.pt"
        torch.save(state, os.path.join(self.vault_path, weight_file))

        package = {
            "signature": {
                "entropy": float(initial_metrics.get('entropy', 0)),
                "shift": float(initial_metrics.get('shift', 0)),
                "sample_count": n_samples 
            },
            "solution_ref": weight_file,
            "final_reliability": float(final_score),
            "model_type": self.model_type
        }
        
        json_path = os.path.join(self.vault_path, f"pack_{timestamp}.json")
        with open(json_path, "w") as f:
            json.dump(package, f, indent=4)
        
        print(f" 💾 [SDK] Local Package Saved: {weight_file}")
        
        # Return the file name so deposit_to_server knows what to tell the database
        return weight_file