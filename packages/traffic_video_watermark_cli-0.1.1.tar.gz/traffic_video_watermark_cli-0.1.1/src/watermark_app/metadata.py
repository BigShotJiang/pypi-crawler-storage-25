from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import imageio_ffmpeg


SHANGHAI = timezone(timedelta(hours=8))


@dataclass(frozen=True)
class VideoInfo:
    duration_seconds: float
    start_time: datetime
    width: int
    height: int


def ffmpeg_exe() -> str:
    return imageio_ffmpeg.get_ffmpeg_exe()


def ffmpeg_info(input_path: Path) -> str:
    exe = ffmpeg_exe()
    proc = subprocess.run(
        [
            exe,
            "-hide_banner",
            "-i",
            str(input_path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return proc.stdout


def read_video_info(input_path: Path) -> VideoInfo:
    info = ffmpeg_info(input_path)
    duration_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", info)
    if not duration_match:
        raise ValueError("无法读取视频时长")
    hours, minutes, seconds = duration_match.groups()
    duration = int(hours) * 3600 + int(minutes) * 60 + float(seconds)

    start_time = _parse_creation_time(info) or _parse_time_from_name(input_path)
    if start_time is None:
        start_time = datetime.now(SHANGHAI).replace(microsecond=0)

    size_match = re.search(r"Video:.*?,\s*(\d+)x(\d+)[,\s]", info)
    width = int(size_match.group(1)) if size_match else 1280
    height = int(size_match.group(2)) if size_match else 720

    return VideoInfo(
        duration_seconds=duration,
        start_time=start_time,
        width=width,
        height=height,
    )


def _parse_creation_time(info: str) -> datetime | None:
    for value in re.findall(r"creation_time\s*:\s*([^\r\n]+)", info):
        normalized = str(value).replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(SHANGHAI).replace(microsecond=0)
    return None


def _parse_time_from_name(input_path: Path) -> datetime | None:
    match = re.search(r"(\d{4}-\d{2}-\d{2})[_ -](\d{2})[-_:](\d{2})[-_:](\d{2})", input_path.stem)
    if not match:
        return None
    date, hour, minute, second = match.groups()
    return datetime.fromisoformat(f"{date}T{hour}:{minute}:{second}").replace(tzinfo=SHANGHAI)


def scan_gps_text(input_path: Path) -> tuple[float, float] | None:
    data = input_path.read_bytes()
    # Covers common QuickTime ISO6709 text like +22.1234+113.1234/.
    text = "".join(chr(b) if 32 <= b < 127 else " " for b in data)
    match = re.search(r"([+-]22\.\d{4,})([+-]11[34]\.\d{4,})", text)
    if not match:
        return None
    return float(match.group(1)), float(match.group(2))
