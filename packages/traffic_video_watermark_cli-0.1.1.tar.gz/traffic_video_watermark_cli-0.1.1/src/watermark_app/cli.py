from __future__ import annotations

import argparse
from pathlib import Path

from .metadata import read_video_info, scan_gps_text
from .settings import DEFAULT_LOCATION, default_output_for
from .watermark import render_watermark


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="traffic-watermark",
        description="给交通举报视频烧录时间和位置水印，并导出 MP4。",
    )
    parser.add_argument("-i", "--input", required=True, help="输入视频路径，例如行车记录仪导出的 mp4")
    parser.add_argument("-o", "--output", help="输出 MP4 路径，默认在输入文件名后追加 -watermarked")
    parser.add_argument(
        "-l",
        "--location",
        default=DEFAULT_LOCATION,
        help=f"位置水印文字，默认：{DEFAULT_LOCATION}",
    )
    parser.add_argument("--info", action="store_true", help="只读取视频信息，不导出")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    input_path = Path(args.input).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve() if args.output else default_output_for(input_path)

    info = read_video_info(input_path)
    gps = scan_gps_text(input_path)
    print(f"输入视频: {input_path}")
    print(f"视频尺寸: {info.width}x{info.height}")
    print(f"视频时长: {info.duration_seconds:.2f}s")
    print(f"起始时间: {info.start_time:%Y-%m-%d %H:%M:%S}")
    if gps:
        print(f"检测到GPS: {gps[0]:.6f}, {gps[1]:.6f}")

    if args.info:
        return 0

    print(f"位置水印: {args.location}")
    print(f"输出文件: {output_path}")
    render_watermark(input_path, output_path, args.location, progress_callback=_print_ffmpeg_progress)
    print(f"已生成: {output_path}")
    return 0


def _print_ffmpeg_progress(line: str) -> None:
    if line.startswith("frame=") or "Error" in line or "failed" in line.lower():
        print(line)


if __name__ == "__main__":
    raise SystemExit(main())
