from __future__ import annotations

import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .metadata import VideoInfo, ffmpeg_exe, read_video_info
from .settings import TIME_FORMAT, WATERMARK_PREFIX_LOCATION, WATERMARK_PREFIX_TIME


def render_watermark(
    input_path: Path,
    output_path: Path,
    location_text: str,
    start_time: datetime | None = None,
    progress_callback: callable | None = None,
) -> VideoInfo:
    info = read_video_info(input_path)
    effective_start = start_time or info.start_time
    ass_path = output_path.with_suffix(".watermark.ass")
    _write_ass(ass_path, info, effective_start, location_text)
    try:
        _run_ffmpeg(input_path, output_path, ass_path, effective_start, progress_callback)
    finally:
        ass_path.unlink(missing_ok=True)
    return info


def _write_ass(ass_path: Path, info: VideoInfo, start_time: datetime, location_text: str) -> None:
    font_size = max(24, int(info.height * 0.035))
    margin = max(18, int(info.width * 0.018))
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {info.width}
PlayResY: {info.height}
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Watermark,Microsoft YaHei,{font_size},&H00FFFFFF,&H000000FF,&H00000000,&H99000000,1,0,0,0,100,100,0,0,3,2,0,7,{margin},{margin},{margin},1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    lines = [header]
    for second in range(int(info.duration_seconds) + 1):
        ts = start_time + timedelta(seconds=second)
        text = (
            f"{WATERMARK_PREFIX_TIME}: {ts.strftime(TIME_FORMAT)}"
            r"\N"
            f"{WATERMARK_PREFIX_LOCATION}: {_escape_ass(location_text)}"
        )
        lines.append(
            "Dialogue: 0,"
            f"{_ass_time(second)},{_ass_time(min(second + 1, info.duration_seconds + 0.1))},"
            f"Watermark,,0,0,0,,{text}\n"
        )
    ass_path.write_text("".join(lines), encoding="utf-8")


def _run_ffmpeg(
    input_path: Path,
    output_path: Path,
    ass_path: Path,
    start_time: datetime,
    progress_callback: callable | None,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        ffmpeg_exe(),
        "-y",
        "-hide_banner",
        "-i",
        str(input_path),
        "-vf",
        f"ass={_ffmpeg_filter_path(ass_path)}",
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-c:v",
        "libx264",
        "-preset",
        "medium",
        "-crf",
        "18",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "copy",
        "-metadata",
        f"creation_time={start_time.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000000Z')}",
        "-movflags",
        "+faststart",
        str(output_path),
    ]
    proc = subprocess.Popen(
        cmd,
        cwd=str(output_path.parent),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        if progress_callback:
            progress_callback(line.rstrip())
    return_code = proc.wait()
    if return_code != 0:
        raise RuntimeError(f"ffmpeg 导出失败，退出码 {return_code}")


def _ass_time(seconds: float) -> str:
    centis = int(round(max(0, seconds) * 100))
    h, rem = divmod(centis, 360000)
    m, rem = divmod(rem, 6000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _escape_ass(text: str) -> str:
    return text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}").replace("\n", " ")


def _ffmpeg_filter_path(path: Path) -> str:
    return path.name.replace("\\", "/").replace(":", "\\:")
