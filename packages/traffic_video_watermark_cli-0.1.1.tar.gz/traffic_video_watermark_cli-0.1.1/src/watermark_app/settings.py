from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


DEFAULT_LOCATION = "某市某路段附近"
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
WATERMARK_PREFIX_TIME = "时间"
WATERMARK_PREFIX_LOCATION = "位置"


@dataclass(frozen=True)
class AppPaths:
    input_video: Path | None = None
    output_video: Path | None = None


def default_output_for(input_path: Path) -> Path:
    return input_path.with_name(f"{input_path.stem}-watermarked.mp4")
