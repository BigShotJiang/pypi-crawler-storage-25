# Traffic Video Watermark CLI

跨平台命令行工具，用于给交通举报视频烧录动态时间和位置水印，并导出可播放 MP4。

水印格式：

```text
时间: 2026-04-27 09:11:50
位置: 某市某路段附近
```

工具会优先读取视频容器里的 `creation_time`，按上海时区换算为画面时间；如果视频没有该元数据，会尝试从常见行车记录仪文件名里的时间读取。

## 安装

本地目录安装：

```bash
pip install .
```

从 wheel 安装：

```bash
pip install dist/traffic_video_watermark_cli-0.1.1-py3-none-any.whl
```

## 使用

只查看视频信息：

```bash
traffic-watermark --input 2026-04-27_09-11-50-front.mp4 --info
```

生成水印视频：

```bash
traffic-watermark \
  --input 2026-04-27_09-11-50-front.mp4 \
  --output report-watermarked.mp4 \
  --location "某市某路段附近"
```

如果不传 `--output`，默认输出到输入视频同目录，文件名后追加 `-watermarked.mp4`。

## 发布到 PyPI

构建发布包：

```bash
python -m pip install -e ".[build]"
python -m build
python -m twine check dist/*
```

上传到 PyPI 需要 PyPI API token：

```bash
python -m twine upload dist/*
```

也可以使用环境变量：

```bash
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-你的token
python -m twine upload dist/*
```
