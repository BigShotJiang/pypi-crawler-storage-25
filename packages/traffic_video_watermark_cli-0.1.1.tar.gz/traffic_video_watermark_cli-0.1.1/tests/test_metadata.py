from datetime import datetime, timezone

from watermark_app.metadata import SHANGHAI, _parse_creation_time, _parse_time_from_name


def test_parse_creation_time_to_shanghai() -> None:
    info = "creation_time   : 2026-04-27T01:11:50.000000Z"
    parsed = _parse_creation_time(info)
    assert parsed == datetime(2026, 4, 27, 9, 11, 50, tzinfo=SHANGHAI)


def test_parse_file_name_time() -> None:
    parsed = _parse_time_from_name(type("P", (), {"stem": "2026-04-27_09-11-50-front"})())
    assert parsed == datetime(2026, 4, 27, 9, 11, 50, tzinfo=SHANGHAI)
