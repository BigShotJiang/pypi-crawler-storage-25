# Changelog

All notable changes to KMF are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2025

First stable release.

### Added
- **Core format**: `KMFObject` with 10 types (fact, preference, decision, episode, entity, summary, conflict, rule, goal, task)
- **Storage**: SQLite-backed local repository, export/import as `.kmf` ZIP archive
- **Consolidation engine**: post-session pipeline with stability scoring and conflict detection
- **Recall pipeline**: 7-stage retrieval with token-budgeted TOON output
- **Semantic search**: optional `sentence-transformers` integration (`pip install "kmf[semantic]"`)
- **TOON renderer**: Token-Optimized Output Notation — 30–85% fewer tokens vs JSON
- **MCP server**: 6 tools for Claude Desktop / claude.ai (`kmf mcp personal.kmf`)
- **Ingest**: Claude conversation parser + Haiku-based auto-extraction (`kmf ingest`)
- **Schema migration**: automatic `0.1 → 0.2 → 1.0` migration on load
- **Merge protocol**: deterministic repository merge with conflict detection (`kmf merge`)
- **LangChain integration**: `KMFMemory` and `KMFRetriever` (`pip install "kmf[langchain]"`)
- **Security**: zip bomb protection, path traversal prevention, model allowlist, API key masking, TOON injection prevention
- **CLI**: `init`, `consolidate`, `recall`, `list`, `history`, `stats`, `ingest`, `merge`, `index`, `mcp`, `version`
- **Tests**: 80+ tests across security, core pipeline, MCP, embeddings, migration, merge

### Install

```bash
pip install kmf                    # core
pip install "kmf[semantic]"        # + semantic search
pip install "kmf[langchain]"       # + LangChain integration
pip install "kmf[all]"             # everything
```

---

## [0.2.0] — 2025

### Added
- Ingest module: Claude conversation parser (`kmf/ingest/`)
- Auto-extraction via Claude Haiku (`< $0.001` per conversation)
- MCP server with 6 tools
- Security module: zip bomb, path traversal, injection protection
- Semantic search with `sentence-transformers`

---

## [0.1.0] — 2025

### Added
- Initial release: core models, storage, consolidation, recall, TOON renderer, CLI
