"""
KMF Consolidation Engine
Post-session process: raw session → structured memory objects.
The chat writes nothing directly — this decides what persists.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from ..models.base import (
    Chunk, Commit, KMFObject, ObjectStatus, ObjectType,
    Provenance, ProvenanceMethod, ProvenanceWriter,
    Sensitivity, ValidTime, Permissions, PromptUse,
    new_id,
)
from ..storage.repository import Repository
from ..render.toon import estimate_tokens


# ──────────────────────────────────────────────
# Candidate: proposed object before commit
# ──────────────────────────────────────────────

@dataclass
class Candidate:
    obj: KMFObject
    stability_score: float = 0.0
    stability_notes: list[str] = field(default_factory=list)
    action: str = "add"  # add | update | skip | conflict


# ──────────────────────────────────────────────
# Stability checker
# ──────────────────────────────────────────────

def _stability_score(obj: KMFObject, existing: list[KMFObject]) -> tuple[float, list[str]]:
    """
    Assess how stable/trustworthy this candidate is.
    Returns (score 0-1, reasons list)
    """
    score = 0.0
    notes = []

    # Explicit user statements are most stable
    writer = obj.provenance.writer
    if isinstance(writer, str):
        writer_val = writer
    else:
        writer_val = writer.value

    if writer_val == "explicit_user_statement":
        score += 0.5
        notes.append("explicit user statement (+0.5)")
    elif writer_val == "cross_session_confirmation":
        score += 0.6
        notes.append("cross-session confirmed (+0.6)")
    elif writer_val == "document_extraction":
        score += 0.3
        notes.append("document extraction (+0.3)")
    elif writer_val == "tool_observation":
        score += 0.3
        notes.append("tool observation (+0.3)")
    else:  # assistant_inference
        score += 0.1
        notes.append("assistant inference (+0.1 — low trust)")

    # High confidence adds stability
    if obj.confidence >= 0.9:
        score += 0.2
        notes.append(f"high confidence {obj.confidence:.2f} (+0.2)")
    elif obj.confidence >= 0.7:
        score += 0.1
        notes.append(f"moderate confidence {obj.confidence:.2f} (+0.1)")

    # Confirmed in existing objects? Cross-session confirmation bonus
    for ex in existing:
        if ex.type == obj.type and ex.content.get("subject") == obj.content.get("subject"):
            if ex.content.get("predicate") == obj.content.get("predicate"):
                if ex.content.get("object") == obj.content.get("object"):
                    score += 0.3
                    notes.append("confirmed in existing memory (+0.3)")
                    break

    return min(1.0, score), notes


# ──────────────────────────────────────────────
# Conflict detection
# ──────────────────────────────────────────────

def _find_conflict(
    candidate: KMFObject,
    existing: list[KMFObject],
) -> Optional[KMFObject]:
    """
    Check if a candidate conflicts with an existing object.
    A conflict is: same subject+predicate but different object (for facts).
    """
    if candidate.type not in (ObjectType.FACT, "fact"):
        return None

    c_subj = candidate.content.get("subject", "")
    c_pred = candidate.content.get("predicate", "")
    c_obj  = candidate.content.get("object", "")

    for ex in existing:
        ex_type = ex.type if isinstance(ex.type, str) else ex.type.value
        if ex_type != "fact":
            continue
        if ex.status != ObjectStatus.ACTIVE:
            continue
        ex_subj = ex.content.get("subject", "")
        ex_pred = ex.content.get("predicate", "")
        ex_obj  = ex.content.get("object", "")

        if ex_subj == c_subj and ex_pred == c_pred and ex_obj != c_obj:
            return ex

    return None


# ──────────────────────────────────────────────
# Session input
# ──────────────────────────────────────────────

@dataclass
class SessionInput:
    """
    Raw input for consolidation.
    In production, this would come from a chat transcript parser.
    For v0.1, caller supplies structured data directly.
    """
    session_id: str = field(default_factory=lambda: new_id("ep"))
    title: str = ""
    summary_short: str = ""
    summary_long: str = ""
    topics: list[str] = field(default_factory=list)
    participants: list[str] = field(default_factory=list)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    # Proposed items — caller extracts these from the session
    proposed_facts: list[dict] = field(default_factory=list)
    proposed_preferences: list[dict] = field(default_factory=list)
    proposed_decisions: list[dict] = field(default_factory=list)
    proposed_entities: list[dict] = field(default_factory=list)

    # Raw transcript (optional, stored as SourceRecord)
    raw_transcript: str = ""


# ──────────────────────────────────────────────
# Consolidation result
# ──────────────────────────────────────────────

@dataclass
class ConsolidationResult:
    commit: Commit
    episode: KMFObject
    added: list[KMFObject] = field(default_factory=list)
    updated: list[KMFObject] = field(default_factory=list)
    conflicts_created: list[KMFObject] = field(default_factory=list)
    skipped: list[tuple[KMFObject, str]] = field(default_factory=list)  # (obj, reason)


# ──────────────────────────────────────────────
# Chunk generator
# ──────────────────────────────────────────────

def _object_to_text(obj: KMFObject) -> str:
    """Generate human-readable text representation of an object for chunking."""
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    c = obj.content

    if t == "fact":
        return c.get("natural_text") or f"{c.get('subject')} {c.get('predicate')} {c.get('object')}"
    elif t == "preference":
        return c.get("natural_text") or f"{c.get('domain')}: {c.get('key')} = {c.get('value')}"
    elif t == "decision":
        return c.get("natural_text") or f"{c.get('title')}: {c.get('decision')}"
    elif t == "entity":
        return c.get("natural_text") or f"{c.get('canonical_name')} ({c.get('entity_type')})"
    elif t == "episode":
        return c.get("summary_short") or c.get("title", "")
    elif t == "summary":
        return c.get("text", "")
    elif t == "conflict":
        return f"Conflict between {' and '.join(c.get('members', []))}: {c.get('reason', '')}"
    else:
        return str(c)

def _make_chunk(obj: KMFObject) -> Chunk:
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    type_to_chunk = {
        "preference": "profile",
        "fact":       "fact",
        "decision":   "decision",
        "entity":     "raw",
        "episode":    "summary",
        "summary":    "summary",
        "conflict":   "raw",
    }
    text = _object_to_text(obj)
    return Chunk(
        parent_object_id=obj.id,
        chunk_type=type_to_chunk.get(t, "raw"),
        token_count_est=estimate_tokens(text),
        topic_tags=obj.content.get("topics", []),
        importance=obj.importance,
        confidence=obj.confidence,
        freshness_score=1.0,
        prompt_priority=obj.importance * obj.confidence,
        text=text,
    )


# ──────────────────────────────────────────────
# Main consolidation engine
# ──────────────────────────────────────────────

STABILITY_THRESHOLD = 0.3  # Objects below this are skipped

class ConsolidationEngine:
    """
    Post-session consolidation: session input → persistent memory objects.

    The separation of chat from persistence is the core KMF principle.
    This is where quality control happens.
    """

    def __init__(self, repo: Repository):
        self.repo = repo

    def consolidate(
        self,
        session: SessionInput,
        auto_commit: bool = True,
        stability_threshold: float = STABILITY_THRESHOLD,
    ) -> ConsolidationResult:
        """
        Run the full consolidation pipeline.
        Returns all decisions made — caller can inspect before committing.
        """
        existing = self.repo.list_objects(status=ObjectStatus.ACTIVE)

        # Step 1: Create episode object
        episode = self._make_episode(session)

        # Step 2: Process candidates
        candidates = self._build_candidates(session, existing)

        # Step 3: Stability filter + conflict detection
        to_add: list[KMFObject] = [episode]
        to_update: list[KMFObject] = []
        conflicts: list[KMFObject] = []
        skipped: list[tuple[KMFObject, str]] = []

        for cand in candidates:
            stab, notes = _stability_score(cand.obj, existing)
            cand.stability_score = stab
            cand.stability_notes = notes

            if stab < stability_threshold:
                cand.action = "skip"
                skipped.append((cand.obj, f"stability {stab:.2f} < threshold {stability_threshold}"))
                continue

            # Conflict check
            conflicting = _find_conflict(cand.obj, existing)
            if conflicting:
                conflict_obj = self._make_conflict(cand.obj, conflicting)
                conflicts.append(conflict_obj)
                # Still add the new object but mark it
                cand.obj.source_refs.append(conflict_obj.id)

            # Check if updating existing
            dup = self._find_duplicate(cand.obj, existing)
            if dup:
                # Update existing rather than creating duplicate
                dup.confidence = max(dup.confidence, cand.obj.confidence)
                dup.source_refs = list(set(dup.source_refs + cand.obj.source_refs))
                dup.touch()
                to_update.append(dup)
                cand.action = "update"
            else:
                cand.action = "add"
                to_add.append(cand.obj)

        # Step 4: Persist
        if auto_commit:
            commit = self._commit(
                session=session,
                episode=episode,
                added=to_add,
                updated=to_update,
                conflicts=conflicts,
            )
        else:
            commit = Commit(
                session_ref=session.session_id,
                summary="(dry run — not committed)",
            )

        return ConsolidationResult(
            commit=commit,
            episode=episode,
            added=to_add,
            updated=to_update,
            conflicts_created=conflicts,
            skipped=skipped,
        )

    def _make_episode(self, session: SessionInput) -> KMFObject:
        return KMFObject(
            id=session.session_id,
            type=ObjectType.EPISODE,
            confidence=1.0,
            importance=0.7,
            sensitivity=Sensitivity.INTERNAL,
            provenance=Provenance(
                writer=ProvenanceWriter.EXPLICIT_USER,
                method=ProvenanceMethod.POST_CONSOLIDATION,
            ),
            permissions=Permissions(
                read=["owner"],
                export=True,
                prompt_use=PromptUse.CONDITIONAL,
            ),
            content={
                "title": session.title or session.session_id,
                "start_time": session.start_time.isoformat() if session.start_time else None,
                "end_time": session.end_time.isoformat() if session.end_time else None,
                "participants": session.participants,
                "topics": session.topics,
                "summary_short": session.summary_short,
                "summary_long": session.summary_long,
                "derived_refs": [],
                "source_refs": [],
            }
        )

    def _build_candidates(
        self,
        session: SessionInput,
        existing: list[KMFObject],
    ) -> list[Candidate]:
        candidates = []

        for item in session.proposed_facts:
            obj = KMFObject(
                type=ObjectType.FACT,
                confidence=item.get("confidence", 0.8),
                importance=item.get("importance", 0.7),
                sensitivity=Sensitivity(item.get("sensitivity", "internal")),
                scope=item.get("scope", ["personal"]),
                source_refs=[session.session_id],
                provenance=Provenance(
                    writer=ProvenanceWriter(item.get("writer", "assistant_inference")),
                    method=ProvenanceMethod.POST_CONSOLIDATION,
                ),
                permissions=Permissions(
                    prompt_use=PromptUse(item.get("prompt_use", "conditional")),
                ),
                content={
                    "subject":      item.get("subject", ""),
                    "predicate":    item.get("predicate", ""),
                    "object":       item.get("object", ""),
                    "qualifiers":   item.get("qualifiers", {}),
                    "natural_text": item.get("natural_text", ""),
                }
            )
            candidates.append(Candidate(obj=obj))

        for item in session.proposed_preferences:
            obj = KMFObject(
                type=ObjectType.PREFERENCE,
                confidence=item.get("confidence", 0.85),
                importance=item.get("importance", 0.8),
                sensitivity=Sensitivity.INTERNAL,
                scope=item.get("scope", ["personal"]),
                source_refs=[session.session_id],
                provenance=Provenance(
                    writer=ProvenanceWriter(item.get("writer", "explicit_user_statement")),
                    method=ProvenanceMethod.POST_CONSOLIDATION,
                ),
                permissions=Permissions(prompt_use=PromptUse.ALWAYS),
                content={
                    "domain":       item.get("domain", ""),
                    "key":          item.get("key", ""),
                    "value":        item.get("value", ""),
                    "strength":     item.get("strength", "moderate"),
                    "natural_text": item.get("natural_text", ""),
                }
            )
            candidates.append(Candidate(obj=obj))

        for item in session.proposed_decisions:
            obj = KMFObject(
                type=ObjectType.DECISION,
                confidence=item.get("confidence", 0.9),
                importance=item.get("importance", 0.85),
                sensitivity=Sensitivity.INTERNAL,
                scope=item.get("scope", ["personal"]),
                source_refs=[session.session_id],
                provenance=Provenance(
                    writer=ProvenanceWriter(item.get("writer", "explicit_user_statement")),
                    method=ProvenanceMethod.POST_CONSOLIDATION,
                ),
                permissions=Permissions(prompt_use=PromptUse.ALWAYS),
                content={
                    "title":                    item.get("title", ""),
                    "decision":                 item.get("decision", ""),
                    "alternatives_considered":  item.get("alternatives_considered", []),
                    "rationale":                item.get("rationale", []),
                    "tradeoffs":                item.get("tradeoffs", []),
                    "scope":                    item.get("scope", []),
                    "natural_text":             item.get("natural_text", ""),
                }
            )
            candidates.append(Candidate(obj=obj))

        for item in session.proposed_entities:
            obj = KMFObject(
                type=ObjectType.ENTITY,
                confidence=item.get("confidence", 0.9),
                importance=item.get("importance", 0.6),
                sensitivity=Sensitivity.INTERNAL,
                scope=item.get("scope", ["personal"]),
                source_refs=[session.session_id],
                provenance=Provenance(
                    writer=ProvenanceWriter.EXPLICIT_USER,
                    method=ProvenanceMethod.POST_CONSOLIDATION,
                ),
                permissions=Permissions(prompt_use=PromptUse.CONDITIONAL),
                content={
                    "entity_type":    item.get("entity_type", "concept"),
                    "canonical_name": item.get("canonical_name", ""),
                    "aliases":        item.get("aliases", []),
                    "attributes":     item.get("attributes", {}),
                    "natural_text":   item.get("natural_text", ""),
                }
            )
            candidates.append(Candidate(obj=obj))

        return candidates

    def _find_duplicate(
        self,
        candidate: KMFObject,
        existing: list[KMFObject],
    ) -> Optional[KMFObject]:
        """Find an existing object that is semantically equivalent."""
        c_type = candidate.type if isinstance(candidate.type, str) else candidate.type.value
        for ex in existing:
            ex_type = ex.type if isinstance(ex.type, str) else ex.type.value
            if ex_type != c_type:
                continue
            if c_type == "fact":
                if (ex.content.get("subject") == candidate.content.get("subject")
                        and ex.content.get("predicate") == candidate.content.get("predicate")
                        and ex.content.get("object") == candidate.content.get("object")):
                    return ex
            elif c_type == "preference":
                if (ex.content.get("domain") == candidate.content.get("domain")
                        and ex.content.get("key") == candidate.content.get("key")):
                    return ex
            elif c_type == "entity":
                if ex.content.get("canonical_name") == candidate.content.get("canonical_name"):
                    return ex
        return None

    def _make_conflict(
        self,
        new_obj: KMFObject,
        existing_obj: KMFObject,
    ) -> KMFObject:
        return KMFObject(
            type=ObjectType.CONFLICT,
            confidence=1.0,
            importance=0.9,
            sensitivity=Sensitivity.INTERNAL,
            scope=new_obj.scope,
            source_refs=[new_obj.id, existing_obj.id],
            provenance=Provenance(
                writer=ProvenanceWriter.ASSISTANT_INFERENCE,
                method=ProvenanceMethod.POST_CONSOLIDATION,
            ),
            permissions=Permissions(prompt_use=PromptUse.ALWAYS),
            content={
                "members": [existing_obj.id, new_obj.id],
                "reason": (
                    f"same subject-predicate "
                    f"({new_obj.content.get('subject')}/{new_obj.content.get('predicate')}), "
                    f"divergent object: "
                    f"'{existing_obj.content.get('object')}' vs '{new_obj.content.get('object')}'"
                ),
                "resolution_status": "unresolved",
                "preferred_ref": None,
                "resolution_note": None,
            }
        )

    def _commit(
        self,
        session: SessionInput,
        episode: KMFObject,
        added: list[KMFObject],
        updated: list[KMFObject],
        conflicts: list[KMFObject],
    ) -> Commit:
        # Write everything
        for obj in added:
            self.repo.put_object(obj)
            chunk = _make_chunk(obj)
            self.repo.put_chunk(chunk)

        for obj in updated:
            self.repo.put_object(obj)
            chunk = _make_chunk(obj)
            self.repo.put_chunk(chunk)

        for obj in conflicts:
            self.repo.put_object(obj)

        # Record commit
        commit = Commit(
            session_ref=session.session_id,
            added=[o.id for o in added],
            updated=[o.id for o in updated],
            conflicts_created=[o.id for o in conflicts],
            summary=(
                f"Consolidation of session '{session.title}': "
                f"{len(added)} added, {len(updated)} updated, "
                f"{len(conflicts)} conflicts."
            ),
        )
        self.repo.put_commit(commit)
        return commit
