"""
KMF Sync — Merge Protocol
Merges two KMF repositories into one.

This is the v1.0 "sync" story: instead of building a cloud sync daemon
(which is a distributed systems problem), KMF provides a deterministic
merge algorithm that lets you reconcile two diverged repos.

Typical use cases:
  - Merging work laptop + home laptop
  - Sharing a team .kmf file
  - Importing another person's memory into yours (with scope filtering)

Merge strategy:
  - Objects with same ID: newer updated_at wins (last-write-wins per object)
  - Objects only in A: kept
  - Objects only in B: added
  - Conflicting facts (same subj/pred, different obj): creates a Conflict object
  - Commits: union of both histories
  - Preferences: last-write-wins (same domain/key → newer wins)

Usage:
    from kmf.sync import merge
    from kmf.api import KMF

    base = KMF.load("work.kmf")
    incoming = KMF.load("home.kmf")
    result = merge(base, incoming)
    result.summary()           # show what changed
    base.save("merged.kmf")    # save merged result

    # Or via CLI:
    kmf merge work.kmf home.kmf --output merged.kmf
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from ..models.base import (
    KMFObject, ObjectStatus, ObjectType,
    Provenance, ProvenanceWriter, ProvenanceMethod,
    Permissions, PromptUse, Sensitivity,
)

logger = logging.getLogger("kmf.sync")


# ──────────────────────────────────────────────
# Merge result
# ──────────────────────────────────────────────

@dataclass
class MergeResult:
    added: list[KMFObject] = field(default_factory=list)
    updated: list[KMFObject] = field(default_factory=list)
    skipped: list[tuple[KMFObject, str]] = field(default_factory=list)
    conflicts_created: list[KMFObject] = field(default_factory=list)

    def summary(self) -> str:
        lines = ["── KMF Merge Summary ──────────────────"]
        lines.append(f"  Added:            {len(self.added)}")
        lines.append(f"  Updated:          {len(self.updated)}")
        lines.append(f"  Skipped (older):  {len(self.skipped)}")
        lines.append(f"  Conflicts:        {len(self.conflicts_created)}")
        if self.conflicts_created:
            lines.append("\n  ⚠ Conflicts (use kmf_conflicts to review):")
            for c in self.conflicts_created:
                lines.append(f"    {c.content.get('reason', c.id)[:80]}")
        return "\n".join(lines)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _parse_dt(val) -> datetime:
    if isinstance(val, datetime):
        return val.replace(tzinfo=timezone.utc) if val.tzinfo is None else val
    if isinstance(val, str):
        try:
            dt = datetime.fromisoformat(val.replace("Z", "+00:00"))
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        except ValueError:
            pass
    return datetime.min.replace(tzinfo=timezone.utc)


def _is_newer(a: KMFObject, b: KMFObject) -> bool:
    """Return True if a.updated_at > b.updated_at."""
    return _parse_dt(a.updated_at) > _parse_dt(b.updated_at)


def _fact_key(obj: KMFObject) -> Optional[tuple]:
    """Unique key for a fact: (subject, predicate). Used for conflict detection."""
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    if t != "fact":
        return None
    return (
        obj.content.get("subject", "").lower(),
        obj.content.get("predicate", "").lower(),
    )


def _pref_key(obj: KMFObject) -> Optional[tuple]:
    """Unique key for a preference: (domain, key)."""
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    if t != "preference":
        return None
    return (
        obj.content.get("domain", "").lower(),
        obj.content.get("key", "").lower(),
    )


def _make_conflict(obj_a: KMFObject, obj_b: KMFObject) -> KMFObject:
    from ..models.base import new_id
    return KMFObject(
        type=ObjectType.CONFLICT,
        confidence=1.0,
        importance=0.9,
        sensitivity=Sensitivity.INTERNAL,
        scope=obj_a.scope,
        source_refs=[obj_a.id, obj_b.id],
        provenance=Provenance(
            writer=ProvenanceWriter.ASSISTANT_INFERENCE,
            method=ProvenanceMethod.POST_CONSOLIDATION,
        ),
        permissions=Permissions(prompt_use=PromptUse.ALWAYS),
        content={
            "members": [obj_a.id, obj_b.id],
            "reason": (
                f"merge conflict: same subject-predicate "
                f"({obj_a.content.get('subject')}/{obj_a.content.get('predicate')}), "
                f"divergent values: "
                f"'{obj_a.content.get('object')}' vs '{obj_b.content.get('object')}'"
            ),
            "resolution_status": "unresolved",
            "preferred_ref": None,
            "resolution_note": f"Auto-created during merge",
        },
    )


# ──────────────────────────────────────────────
# Merge algorithm
# ──────────────────────────────────────────────

def merge(base_kmf, incoming_kmf, scopes: Optional[list[str]] = None) -> MergeResult:
    """
    Merge incoming_kmf into base_kmf (in-place on base_kmf).

    Strategy:
      - Same ID: newer updated_at wins
      - Only in incoming: added to base
      - Fact conflict (same subj+pred, different obj): Conflict object created
      - Preference conflict (same domain+key): newer wins, no conflict object

    Args:
        base_kmf:     KMF instance to merge into (modified in place)
        incoming_kmf: KMF instance to merge from (read-only)
        scopes:       If set, only merge objects matching these scopes

    Returns:
        MergeResult with details of what changed
    """
    result = MergeResult()

    # Get all active objects from both repos
    base_objects = {obj.id: obj for obj in base_kmf.list()}
    incoming_objects = incoming_kmf.list()

    # Build lookup tables for conflict detection in base
    base_fact_keys: dict[tuple, KMFObject] = {}
    base_pref_keys: dict[tuple, KMFObject] = {}
    for obj in base_objects.values():
        fk = _fact_key(obj)
        if fk:
            base_fact_keys[fk] = obj
        pk = _pref_key(obj)
        if pk:
            base_pref_keys[pk] = obj

    # Collect existing conflict IDs to avoid duplicates
    existing_conflicts = {
        frozenset(c.content.get("members", []))
        for c in base_kmf.list(type=ObjectType.CONFLICT)
    }

    for inc_obj in incoming_objects:
        # Scope filter
        if scopes:
            obj_scopes = inc_obj.scope if isinstance(inc_obj.scope, list) else [inc_obj.scope]
            if not any(s in obj_scopes for s in scopes):
                result.skipped.append((inc_obj, "scope mismatch"))
                continue

        t = inc_obj.type if isinstance(inc_obj.type, str) else inc_obj.type.value

        # ── Case 1: Same ID exists in base ───────
        if inc_obj.id in base_objects:
            base_obj = base_objects[inc_obj.id]
            if _is_newer(inc_obj, base_obj):
                base_kmf.put(inc_obj)
                result.updated.append(inc_obj)
            else:
                result.skipped.append((inc_obj, "base is newer"))
            continue

        # ── Case 2: New object — check for semantic conflicts ─
        if t == "fact":
            fk = _fact_key(inc_obj)
            if fk and fk in base_fact_keys:
                base_fact = base_fact_keys[fk]
                inc_val = inc_obj.content.get("object", "")
                base_val = base_fact.content.get("object", "")
                if inc_val.lower() != base_val.lower():
                    # Conflict — add both and create conflict object
                    member_set = frozenset([base_fact.id, inc_obj.id])
                    if member_set not in existing_conflicts:
                        conflict = _make_conflict(base_fact, inc_obj)
                        base_kmf.put(inc_obj)
                        base_kmf.put(conflict)
                        result.added.append(inc_obj)
                        result.conflicts_created.append(conflict)
                        existing_conflicts.add(member_set)
                        continue
                else:
                    # Same value — take newer
                    if _is_newer(inc_obj, base_fact):
                        base_kmf.put(inc_obj)
                        result.updated.append(inc_obj)
                    else:
                        result.skipped.append((inc_obj, "duplicate value, base is newer"))
                    continue

        elif t == "preference":
            pk = _pref_key(inc_obj)
            if pk and pk in base_pref_keys:
                base_pref = base_pref_keys[pk]
                if _is_newer(inc_obj, base_pref):
                    base_kmf.put(inc_obj)
                    result.updated.append(inc_obj)
                else:
                    result.skipped.append((inc_obj, "preference: base is newer"))
                continue

        # ── Case 3: Genuinely new object ─────────
        base_kmf.put(inc_obj)
        result.added.append(inc_obj)

    # Merge commit history (append incoming commits not in base)
    base_commit_ids = {c.commit_id for c in base_kmf.history()}
    for commit in incoming_kmf.history():
        if commit.commit_id not in base_commit_ids:
            base_kmf._repo.put_commit(commit)

    return result
