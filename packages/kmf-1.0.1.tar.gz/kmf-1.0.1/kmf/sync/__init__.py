"""
KMF Sync
Merge protocol for reconciling two KMF repositories.
"""
from .merge import merge, MergeResult

__all__ = ["merge", "MergeResult"]
