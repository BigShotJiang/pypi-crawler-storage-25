"""
KMF Ingest — Auto Extractor
Uses Claude Haiku to extract structured memory objects from a transcript.

Design goals:
  - Cheap: uses claude-haiku-4-5-20251001 (lowest cost model)
  - Single API call per transcript
  - Returns a ready-to-consolidate SessionInput
  - Graceful degradation: if extraction fails, returns minimal SessionInput
"""
from __future__ import annotations

import json
import os
from typing import Optional

from ..consolidation.engine import SessionInput
from .claude import Transcript


# ──────────────────────────────────────────────
# Extraction prompt
# ──────────────────────────────────────────────

EXTRACTION_SYSTEM = """\
You are a memory extraction engine. Your job is to analyze a conversation and extract structured knowledge.

Extract ONLY what is clearly stated or strongly implied. Do NOT invent or guess.

Return ONLY valid JSON — no markdown, no explanation, no backticks.

Output schema:
{
  "title": "short descriptive title of the conversation (max 10 words)",
  "summary_short": "one sentence summary",
  "summary_long": "2-3 sentence summary",
  "topics": ["topic1", "topic2"],
  "facts": [
    {
      "subject": "who/what this is about",
      "predicate": "relationship or attribute",
      "object": "the value or target",
      "confidence": 0.0-1.0,
      "writer": "explicit_user_statement | assistant_inference"
    }
  ],
  "preferences": [
    {
      "domain": "category (e.g. language, style, tools, workflow)",
      "key": "specific preference name",
      "value": "preference value",
      "strength": "strong | moderate | weak",
      "writer": "explicit_user_statement | assistant_inference"
    }
  ],
  "decisions": [
    {
      "title": "short decision title",
      "decision": "what was decided",
      "rationale": ["reason 1", "reason 2"],
      "tradeoffs": ["tradeoff 1"],
      "confidence": 0.0-1.0,
      "writer": "explicit_user_statement | assistant_inference"
    }
  ],
  "entities": [
    {
      "entity_type": "person | project | organization | tool | concept | file | location",
      "canonical_name": "canonical name",
      "aliases": ["alias1"],
      "confidence": 0.0-1.0
    }
  ]
}

Rules:
- facts.writer = "explicit_user_statement" only if the user stated it directly
- confidence < 0.7 means you're not sure — include it anyway but mark it low
- preferences: extract language, communication style, tool choices, workflow preferences
- decisions: only real choices made, not hypotheticals
- entities: only entities important enough to remember
- If nothing belongs in a category, return an empty list
- Keep values concise — this goes into a prompt context later
"""

EXTRACTION_USER_TMPL = """\
Conversation title: {title}

{transcript_text}

Extract structured memory from this conversation. Return only JSON."""


# ──────────────────────────────────────────────
# Token estimation
# ──────────────────────────────────────────────

def _truncate_transcript(text: str, max_tokens: int = 3000) -> str:
    """
    Truncate transcript to fit in context.
    Keeps start and end (most important parts), drops middle if needed.
    ~4 chars per token estimate.
    """
    max_chars = max_tokens * 4
    if len(text) <= max_chars:
        return text

    half = max_chars // 2
    start = text[:half]
    end = text[-half:]
    dropped = len(text) - max_chars
    return f"{start}\n\n[... {dropped} characters omitted for brevity ...]\n\n{end}"


# ──────────────────────────────────────────────
# Extraction
# ──────────────────────────────────────────────

def _parse_extraction_response(raw: str) -> dict:
    """
    Parse JSON from model response.
    Handles: plain JSON, ```json fences, JSON embedded in text.
    """
    text = raw.strip()

    # Try 1: direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try 2: strip any ``` fences (```json ... ``` or ``` ... ```)
    import re
    fence_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if fence_match:
        try:
            return json.loads(fence_match.group(1))
        except json.JSONDecodeError:
            pass

    # Try 3: find first { ... } block in the text
    brace_match = re.search(r'\{.*\}', text, re.DOTALL)
    if brace_match:
        try:
            return json.loads(brace_match.group(0))
        except json.JSONDecodeError:
            pass

    raise json.JSONDecodeError("No valid JSON found in response", text, 0)


def extract(
    transcript: Transcript,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    max_transcript_tokens: int = 6000,
) -> SessionInput:
    """
    Extract structured memory from a transcript using Claude Haiku.

    Args:
        transcript: Normalized conversation transcript
        api_key: Anthropic API key (defaults to ANTHROPIC_API_KEY env var)
        model: Model to use (default: Haiku — cheapest option)
        max_transcript_tokens: Max tokens of transcript to send (cost control)

    Returns:
        SessionInput ready for KMF consolidation

    Cost estimate:
        ~500-800 input tokens + ~300-500 output tokens per call
        At Haiku pricing: < $0.001 per conversation
    """
    import urllib.request
    from ..security import validate_model, validate_api_key, mask_api_key

    # Validate model before sending to API
    model = validate_model(model)

    raw_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not raw_key:
        raise ValueError(
            "No API key provided. Set ANTHROPIC_API_KEY environment variable "
            "or pass api_key= to extract()."
        )

    # Validate key format (catches obvious mistakes early, before network call)
    try:
        key = validate_api_key(raw_key)
    except ValueError as e:
        raise ValueError(str(e)) from e

    transcript_text = _truncate_transcript(transcript.text, max_transcript_tokens)

    payload = json.dumps({
        "model": model,
        "max_tokens": 4096,
        "system": EXTRACTION_SYSTEM,
        "messages": [
            {
                "role": "user",
                "content": EXTRACTION_USER_TMPL.format(
                    title=transcript.title,
                    transcript_text=transcript_text,
                )
            }
        ],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            response_data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        # Never include the API key in error messages
        raise RuntimeError(
            f"Anthropic API error {e.code} (key: {mask_api_key(key)}): {body}"
        ) from e

    # Extract text content from response
    content_blocks = response_data.get("content", [])
    raw_text = ""
    for block in content_blocks:
        if block.get("type") == "text":
            raw_text += block.get("text", "")

    if not raw_text.strip():
        # Graceful degradation — return minimal session
        return SessionInput(
            session_id=transcript.conversation_id or None,
            title=transcript.title,
            summary_short="(extraction failed — no response)",
        )

    try:
        extracted = _parse_extraction_response(raw_text)
    except json.JSONDecodeError:
        # Try to salvage truncated JSON (happens when response hits max_tokens)
        salvaged = None
        for closing in ['"]}}}', '"]}', ']}', '}']:
            try:
                salvaged = json.loads(raw_text + closing)
                break
            except Exception:
                pass
        if salvaged:
            extracted = salvaged
        else:
            return SessionInput(
                session_id=transcript.conversation_id or None,
                title=transcript.title,
                summary_short=raw_text[:200],
            )

    return SessionInput(
        session_id=transcript.conversation_id or None,
        title=extracted.get("title") or transcript.title,
        summary_short=extracted.get("summary_short", ""),
        summary_long=extracted.get("summary_long", ""),
        topics=extracted.get("topics", []),
        proposed_facts=extracted.get("facts", []),
        proposed_preferences=extracted.get("preferences", []),
        proposed_decisions=extracted.get("decisions", []),
        proposed_entities=extracted.get("entities", []),
    )


def extract_batch(
    transcripts: list[Transcript],
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    on_progress=None,
) -> list[SessionInput]:
    """
    Extract from multiple transcripts.

    Args:
        transcripts: List of transcripts to process
        api_key: Anthropic API key
        model: Model to use
        on_progress: Optional callback(current, total, transcript) for progress

    Returns:
        List of SessionInput objects (same order as input)
    """
    results = []
    for i, transcript in enumerate(transcripts):
        if on_progress:
            on_progress(i + 1, len(transcripts), transcript)
        try:
            session = extract(transcript, api_key=api_key, model=model)
        except Exception as e:
            # Graceful degradation — don't fail the whole batch
            session = SessionInput(
                title=transcript.title,
                summary_short=f"(extraction error: {e})",
            )
        results.append(session)
    return results
