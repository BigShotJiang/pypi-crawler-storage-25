"""
KMF Ingest — Claude Parser
Parses Claude conversation exports (JSON) into a normalized transcript
that the extractor can process.

Supports:
  - claude.ai conversation export (conversations.json)
  - Single conversation JSON
  - Raw list of messages [{"role": "user"|"assistant", "content": "..."}]
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


# ──────────────────────────────────────────────
# Normalized types
# ──────────────────────────────────────────────

@dataclass
class Message:
    role: str          # "user" | "assistant"
    content: str
    timestamp: Optional[datetime] = None


@dataclass
class Transcript:
    """
    A normalized conversation transcript ready for extraction.
    Provider-agnostic — Claude parser produces this, extractor consumes it.
    """
    title: str
    messages: list[Message] = field(default_factory=list)
    created_at: Optional[datetime] = None
    conversation_id: Optional[str] = None
    source: str = "claude"

    @property
    def text(self) -> str:
        """Full conversation as plain text block."""
        lines = []
        for m in self.messages:
            role = "User" if m.role == "user" else "Assistant"
            lines.append(f"{role}: {m.content}")
        return "\n\n".join(lines)

    @property
    def word_count(self) -> int:
        return len(self.text.split())

    @property
    def token_estimate(self) -> int:
        """Rough estimate: ~0.75 tokens per word."""
        return int(self.word_count * 0.75)


# ──────────────────────────────────────────────
# Parsing helpers
# ──────────────────────────────────────────────

def _extract_text_from_content(content) -> str:
    """
    Claude API content can be a string or a list of content blocks.
    Handles both.
    """
    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block.get("text", "").strip())
                # Skip tool_use, tool_result, image blocks
        return "\n".join(p for p in parts if p)

    return str(content).strip()


def _parse_timestamp(value) -> Optional[datetime]:
    if not value:
        return None
    if isinstance(value, (int, float)):
        try:
            return datetime.utcfromtimestamp(value)
        except Exception:
            return None
    if isinstance(value, str):
        for fmt in (
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
        ):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
    return None


# ──────────────────────────────────────────────
# Format detectors
# ──────────────────────────────────────────────

def _is_claude_export(data: dict | list) -> bool:
    """
    claude.ai exports conversations.json as a list of conversation objects,
    each with a 'chat_messages' key.
    """
    if isinstance(data, list) and len(data) > 0:
        first = data[0]
        if isinstance(first, dict) and "chat_messages" in first:
            return True
    return False


def _is_single_conversation(data: dict) -> bool:
    """Single conversation object with chat_messages."""
    return isinstance(data, dict) and "chat_messages" in data


def _is_messages_list(data: list) -> bool:
    """Simple list of {role, content} dicts."""
    if not isinstance(data, list) or len(data) == 0:
        return False
    first = data[0]
    return isinstance(first, dict) and "role" in first and "content" in first


# ──────────────────────────────────────────────
# Parsers for each format
# ──────────────────────────────────────────────

def _parse_chat_messages(raw_messages: list, title: str, conversation_id: str = None, created_at=None) -> Transcript:
    """Parse a list of claude.ai chat_messages into a Transcript."""
    messages = []
    for msg in raw_messages:
        role = msg.get("sender", msg.get("role", "")).lower()
        if role == "human":
            role = "user"

        content_raw = msg.get("content", msg.get("text", ""))
        content = _extract_text_from_content(content_raw)

        if not content:
            continue

        ts = _parse_timestamp(msg.get("created_at") or msg.get("timestamp"))
        messages.append(Message(role=role, content=content, timestamp=ts))

    return Transcript(
        title=title,
        messages=messages,
        created_at=_parse_timestamp(created_at),
        conversation_id=conversation_id,
        source="claude",
    )


def _parse_messages_list(data: list, title: str = "Conversation") -> Transcript:
    """Parse a simple [{role, content}] list."""
    messages = []
    for msg in data:
        role = msg.get("role", "").lower()
        if role == "human":
            role = "user"
        content = _extract_text_from_content(msg.get("content", ""))
        if content:
            ts = _parse_timestamp(msg.get("timestamp") or msg.get("created_at"))
            messages.append(Message(role=role, content=content, timestamp=ts))

    return Transcript(title=title, messages=messages, source="claude")


# ──────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────

def parse_file(path: str | Path) -> list[Transcript]:
    """
    Parse a Claude export file into a list of Transcripts.

    Accepts:
      - conversations.json (claude.ai full export) → multiple transcripts
      - single conversation JSON → one transcript
      - [{role, content}] list → one transcript

    Returns a list (always), even for single conversations.
    """
    from ..security import safe_read_json_file
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    raw_bytes = safe_read_json_file(path)
    raw = json.loads(raw_bytes.decode("utf-8"))
    return parse(raw, title=path.stem)


def parse(data: dict | list, title: str = "Conversation") -> list[Transcript]:
    """
    Parse Claude conversation data (already loaded from JSON).

    Accepts:
      - Full claude.ai export (list of conversations)
      - Single conversation dict
      - Simple messages list

    Returns a list of Transcript objects.
    """
    # Full claude.ai export: list of conversation objects
    if _is_claude_export(data):
        transcripts = []
        for conv in data:
            t = _parse_chat_messages(
                raw_messages=conv.get("chat_messages", []),
                title=conv.get("name") or conv.get("title") or "Untitled",
                conversation_id=conv.get("uuid") or conv.get("id"),
                created_at=conv.get("created_at"),
            )
            if t.messages:
                transcripts.append(t)
        return transcripts

    # Single conversation object
    if _is_single_conversation(data):
        t = _parse_chat_messages(
            raw_messages=data.get("chat_messages", []),
            title=data.get("name") or data.get("title") or title,
            conversation_id=data.get("uuid") or data.get("id"),
            created_at=data.get("created_at"),
        )
        return [t] if t.messages else []

    # Simple messages list
    if _is_messages_list(data):
        t = _parse_messages_list(data, title=title)
        return [t] if t.messages else []

    raise ValueError(
        "Unrecognized format. Expected: claude.ai conversations.json, "
        "single conversation dict, or [{role, content}] list."
    )


def parse_text(text: str, title: str = "Conversation") -> Transcript:
    """
    Parse a raw conversation text (e.g. copy-pasted from Claude).

    Expected format:
        User: ...
        Assistant: ...
        User: ...

    Returns a single Transcript.
    """
    messages = []
    current_role = None
    current_lines = []

    for line in text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith(("user:", "human:")):
            if current_role and current_lines:
                messages.append(Message(role=current_role, content="\n".join(current_lines).strip()))
            current_role = "user"
            current_lines = [stripped.split(":", 1)[1].strip()]
        elif stripped.lower().startswith(("assistant:", "claude:")):
            if current_role and current_lines:
                messages.append(Message(role=current_role, content="\n".join(current_lines).strip()))
            current_role = "assistant"
            current_lines = [stripped.split(":", 1)[1].strip()]
        else:
            if current_role is not None:
                current_lines.append(stripped)

    if current_role and current_lines:
        messages.append(Message(role=current_role, content="\n".join(current_lines).strip()))

    return Transcript(title=title, messages=messages, source="claude")
