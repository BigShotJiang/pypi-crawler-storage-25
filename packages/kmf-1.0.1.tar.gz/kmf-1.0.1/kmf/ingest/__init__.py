"""
KMF Ingest
Parsers and extractors for converting raw conversations into KMF memory.

Usage:
    from kmf.ingest import from_claude_file, from_claude_export, from_text

    # From claude.ai export file
    sessions = from_claude_file("conversations.json", api_key="...")

    # From already-loaded data
    sessions = from_claude_export(data, api_key="...")

    # From copy-pasted text
    session = from_text("User: ...\nAssistant: ...", api_key="...")

    # Then consolidate
    kmf = KMF.load("memory.kmf")
    for session in sessions:
        kmf.consolidate(session)
    kmf.save("memory.kmf")
"""
from __future__ import annotations

from typing import Optional

from .claude import parse_file, parse, parse_text, Transcript
from .extractor import extract, extract_batch
from ..consolidation.engine import SessionInput


def from_claude_file(
    path: str,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    on_progress=None,
) -> list[SessionInput]:
    """
    Parse a claude.ai export file and extract memory from all conversations.

    Args:
        path: Path to conversations.json or single conversation JSON
        api_key: Anthropic API key (or set ANTHROPIC_API_KEY env var)
        model: Extraction model (default: Haiku)
        on_progress: Optional callback(current, total, transcript)

    Returns:
        List of SessionInput objects ready for kmf.consolidate()
    """
    transcripts = parse_file(path)
    return extract_batch(transcripts, api_key=api_key, model=model, on_progress=on_progress)


def from_claude_export(
    data: dict | list,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    title: str = "Conversation",
) -> list[SessionInput]:
    """
    Extract memory from already-loaded Claude conversation data.

    Args:
        data: Parsed JSON from claude.ai export
        api_key: Anthropic API key
        model: Extraction model
        title: Default title if not in data

    Returns:
        List of SessionInput objects
    """
    transcripts = parse(data, title=title)
    return extract_batch(transcripts, api_key=api_key, model=model)


def from_text(
    text: str,
    title: str = "Conversation",
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
) -> SessionInput:
    """
    Extract memory from a copy-pasted conversation text.

    Expected format:
        User: ...
        Assistant: ...
        User: ...

    Args:
        text: Raw conversation text
        title: Conversation title
        api_key: Anthropic API key
        model: Extraction model

    Returns:
        A single SessionInput ready for kmf.consolidate()
    """
    transcript = parse_text(text, title=title)
    return extract(transcript, api_key=api_key, model=model)


def from_transcript(
    transcript: Transcript,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
) -> SessionInput:
    """
    Extract memory from a Transcript object directly.
    Useful for custom parsers or other providers.
    """
    return extract(transcript, api_key=api_key, model=model)


__all__ = [
    "from_claude_file",
    "from_claude_export",
    "from_text",
    "from_transcript",
    "Transcript",
    "SessionInput",
    "parse_file",
    "parse",
    "parse_text",
    "extract",
    "extract_batch",
]
