"""
KMF Security
Validators, sanitizers, and safe utilities used across the codebase.
"""
from __future__ import annotations

import os
import re
from pathlib import Path, PurePosixPath
from typing import Optional

# ──────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────

# Max uncompressed size for a .kmf ZIP (50 MB)
KMF_MAX_UNCOMPRESSED_BYTES = 50 * 1024 * 1024

# Max compressed size for a single entry (10 MB)
KMF_MAX_ENTRY_BYTES = 10 * 1024 * 1024

# Max JSON file size for conversation import (20 MB)
INGEST_MAX_FILE_BYTES = 20 * 1024 * 1024

# Allowed Anthropic model prefixes
ALLOWED_MODEL_PREFIXES = (
    "claude-haiku",
    "claude-sonnet",
    "claude-opus",
)

# Allowed ZIP entry path components
_ALLOWED_ZIP_DIRS = {"objects", "chunks", "history"}
_ALLOWED_ZIP_FILES = {"manifest.json"}


# ──────────────────────────────────────────────
# Model validation
# ──────────────────────────────────────────────

def validate_model(model: str) -> str:
    """
    Validate that a model string is an allowed Anthropic model.
    Prevents passing arbitrary strings to the API.

    Raises ValueError if not allowed.
    Returns the model string if valid.
    """
    if not isinstance(model, str) or not model.strip():
        raise ValueError("model must be a non-empty string")

    model = model.strip()

    if not any(model.startswith(prefix) for prefix in ALLOWED_MODEL_PREFIXES):
        raise ValueError(
            f"Model '{model}' is not allowed. "
            f"Must start with one of: {', '.join(ALLOWED_MODEL_PREFIXES)}"
        )

    # Only allow alphanumeric, hyphens, dots, underscores
    if not re.match(r'^[a-zA-Z0-9\-_.]+$', model):
        raise ValueError(f"Model string contains invalid characters: '{model}'")

    return model


# ──────────────────────────────────────────────
# API key handling
# ──────────────────────────────────────────────

def mask_api_key(key: str) -> str:
    """Return a masked version of an API key safe for logging."""
    if not key or len(key) < 8:
        return "***"
    return key[:7] + "..." + key[-3:]


def validate_api_key(key: str) -> str:
    """
    Basic validation that a string looks like an Anthropic API key.
    Does NOT make a network call — just format checking.
    """
    if not isinstance(key, str) or not key.strip():
        raise ValueError("API key must be a non-empty string")
    key = key.strip()
    if not key.startswith("sk-ant-"):
        raise ValueError(
            "API key does not look valid (expected 'sk-ant-...'). "
            "Check your ANTHROPIC_API_KEY."
        )
    return key


# ──────────────────────────────────────────────
# ZIP / file safety
# ──────────────────────────────────────────────

def safe_zip_namelist(zf) -> list[str]:
    """
    Validate all entries in a ZIP file.

    Checks:
    - No path traversal (../ or absolute paths)
    - No entries outside allowed directories
    - No suspiciously large entries (zip bomb protection)
    - No symlinks

    Returns the list of valid entry names.
    Raises ValueError if any entry is unsafe.
    """
    valid = []
    total_size = 0

    for info in zf.infolist():
        name = info.filename

        # No absolute paths
        if name.startswith("/") or name.startswith("\\"):
            raise ValueError(f"ZIP entry has absolute path: '{name}'")

        # No path traversal
        try:
            resolved = PurePosixPath(name)
            for part in resolved.parts:
                if part == "..":
                    raise ValueError(f"ZIP entry contains path traversal: '{name}'")
        except Exception as e:
            raise ValueError(f"Invalid ZIP entry name '{name}': {e}") from e

        # No null bytes
        if "\x00" in name:
            raise ValueError(f"ZIP entry contains null byte: '{name!r}'")

        # Check entry is in allowed location
        parts = name.split("/")
        if name not in _ALLOWED_ZIP_FILES:
            if not parts[0] in _ALLOWED_ZIP_DIRS:
                raise ValueError(
                    f"ZIP entry outside allowed directories: '{name}'. "
                    f"Allowed: {_ALLOWED_ZIP_FILES | _ALLOWED_ZIP_DIRS}"
                )

        # Zip bomb: check uncompressed size
        if info.file_size > KMF_MAX_ENTRY_BYTES:
            raise ValueError(
                f"ZIP entry '{name}' is too large: "
                f"{info.file_size:,} bytes (max {KMF_MAX_ENTRY_BYTES:,})"
            )

        total_size += info.file_size
        if total_size > KMF_MAX_UNCOMPRESSED_BYTES:
            raise ValueError(
                f"ZIP total uncompressed size exceeds limit: "
                f"{total_size:,} bytes (max {KMF_MAX_UNCOMPRESSED_BYTES:,})"
            )

        # Detect suspicious compression ratio (zip bomb indicator)
        if info.compress_size > 0:
            ratio = info.file_size / info.compress_size
            if ratio > 100:
                raise ValueError(
                    f"ZIP entry '{name}' has suspicious compression ratio: {ratio:.0f}x"
                )

        valid.append(name)

    return valid


def safe_read_json_file(path: str | Path, max_bytes: int = INGEST_MAX_FILE_BYTES) -> bytes:
    """
    Read a JSON file with size limit.

    Raises:
        FileNotFoundError: if file doesn't exist
        ValueError: if file exceeds size limit
    """
    path = Path(path)
    size = path.stat().st_size
    if size > max_bytes:
        raise ValueError(
            f"File '{path.name}' is too large: {size:,} bytes "
            f"(max {max_bytes:,} bytes = {max_bytes // 1024 // 1024} MB)"
        )
    return path.read_bytes()


# ──────────────────────────────────────────────
# TOON injection prevention
# ──────────────────────────────────────────────

# Characters that could break TOON structure
_TOON_STRUCTURAL_CHARS = re.compile(r'[\[\]\{\}]')

def toon_sanitize(value: str) -> str:
    """
    Sanitize a value for safe inclusion in TOON output.

    Removes/replaces characters that could be interpreted as TOON
    structural markers: [ ] { }
    Also handled by existing _toon_escape: , and newlines.
    """
    # Replace structural chars with look-alikes that won't be parsed
    value = _TOON_STRUCTURAL_CHARS.sub(lambda m: {
        '[': '❲', ']': '❳', '{': '❴', '}': '❵'
    }[m.group()], value)
    return value


# ──────────────────────────────────────────────
# Object ID validation
# ──────────────────────────────────────────────

_VALID_ID_RE = re.compile(r'^[a-zA-Z0-9_\-]{3,64}$')

def validate_object_id(obj_id: str) -> str:
    """Validate a KMF object ID to prevent SQL injection via ID fields."""
    if not isinstance(obj_id, str) or not _VALID_ID_RE.match(obj_id):
        raise ValueError(
            f"Invalid object ID: '{obj_id}'. "
            "Must be 3-64 alphanumeric/underscore/hyphen characters."
        )
    return obj_id
