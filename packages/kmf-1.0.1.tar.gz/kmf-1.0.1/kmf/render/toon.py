"""
KMF TOON Renderer
Tokenoptimized Output Notation — converts KMF objects to compact prompt format.
Savings: 30–85% vs raw JSON depending on data type.
"""
from __future__ import annotations

import math
from datetime import datetime
from typing import Any

from ..models.base import (
    KMFObject, ObjectType, ProvenanceWriter,
    ResolutionStatus, Sensitivity,
)


# ──────────────────────────────────────────────
# Token estimation (rough but consistent)
# ──────────────────────────────────────────────

def estimate_tokens(text: str) -> int:
    """Rough GPT-style token estimate: ~4 chars per token."""
    return max(1, math.ceil(len(text) / 4))


# ──────────────────────────────────────────────
# TOON escape: commas in values become ‚ (single low-9 quotation mark)
# This is the escaping scheme missing from the spec — fixed here.
# ──────────────────────────────────────────────

def _toon_escape(value: str) -> str:
    """Escape commas, newlines, and structural bracket chars in TOON values."""
    from ..security import toon_sanitize
    value = str(value).replace(",", "‚").replace("\n", " ").strip()
    return toon_sanitize(value)

def _toon_unescape(value: str) -> str:
    return value.replace("‚", ",")


# ──────────────────────────────────────────────
# Per-type renderers
# ──────────────────────────────────────────────

def _render_preference(obj: KMFObject) -> str:
    c = obj.content
    domain  = _toon_escape(c.get("domain", ""))
    key     = _toon_escape(c.get("key", ""))
    value   = _toon_escape(c.get("value", ""))
    strength = _toon_escape(c.get("strength", ""))
    return f"{domain},{key},{value},{strength}"

def _render_fact(obj: KMFObject) -> str:
    c = obj.content
    subject   = _toon_escape(c.get("subject", ""))
    predicate = _toon_escape(c.get("predicate", ""))
    obj_val   = _toon_escape(c.get("object", ""))
    conf      = f"{obj.confidence:.2f}"
    return f"{subject},{predicate},{obj_val},{conf}"

def _render_decision(obj: KMFObject) -> str:
    c = obj.content
    title    = _toon_escape(c.get("title", ""))
    decision = _toon_escape(c.get("decision", ""))
    conf     = f"{obj.confidence:.2f}"
    return f"{title},{decision},{conf}"

def _render_entity(obj: KMFObject) -> str:
    c = obj.content
    name      = _toon_escape(c.get("canonical_name", ""))
    ent_type  = _toon_escape(c.get("entity_type", ""))
    return f"{name},{ent_type}"

def _render_task(obj: KMFObject) -> str:
    c = obj.content
    title  = _toon_escape(c.get("title", ""))
    status = _toon_escape(c.get("status", ""))
    return f"{title},{status}"


# ──────────────────────────────────────────────
# Section builders
# ──────────────────────────────────────────────

def _build_section(
    name: str,
    header: str,
    objects: list[KMFObject],
    row_fn,
    fields: str,
) -> tuple[str, int]:
    """Build one TOON section. Returns (text, token_count)."""
    if not objects:
        return "", 0
    rows = [row_fn(o) for o in objects]
    lines = [
        f"[{header}]",
        f"{name.lower()}[{len(rows)}]{{{fields}}}:",
    ] + rows
    text = "\n".join(lines)
    return text, estimate_tokens(text)

def _build_summary_section(objects: list[KMFObject]) -> tuple[str, int]:
    if not objects:
        return "", 0
    parts = []
    for obj in objects:
        text = obj.content.get("text", obj.content.get("summary_long", ""))
        scope = ", ".join(obj.content.get("scope_focus", []))
        label = f"[SUMMARY — {scope}]" if scope else "[SUMMARY]"
        parts.append(f"{label}\n{text.strip()}")
    combined = "\n\n".join(parts)
    return combined, estimate_tokens(combined)

def _build_conflict_section(objects: list[KMFObject]) -> tuple[str, int]:
    if not objects:
        return "", 0
    lines = ["[CONFLICTS]"]
    for obj in objects:
        c = obj.content
        members = "|".join(c.get("members", []))
        reason  = c.get("reason", "")
        status  = c.get("resolution_status", "unresolved")
        note    = c.get("resolution_note", "")
        line = f"⚠ {obj.id} — {status}: {members} — {reason}"
        if note:
            line += f" | {note}"
        lines.append(line)
    text = "\n".join(lines)
    return text, estimate_tokens(text)

def _build_episode_section(objects: list[KMFObject]) -> tuple[str, int]:
    if not objects:
        return "", 0
    parts = ["[RECENT EPISODES]"]
    for obj in objects:
        c = obj.content
        title = c.get("title", obj.id)
        summary = c.get("summary_short", "")
        topics = ", ".join(c.get("topics", []))
        line = f"• {title}"
        if summary:
            line += f": {summary}"
        if topics:
            line += f" [{topics}]"
        parts.append(line)
    text = "\n".join(parts)
    return text, estimate_tokens(text)


# ──────────────────────────────────────────────
# Uncertainty flag
# ──────────────────────────────────────────────

def _uncertain_note(obj: KMFObject) -> str:
    if obj.provenance.writer == ProvenanceWriter.ASSISTANT_INFERENCE:
        return " ~"  # ~ = inferred, not confirmed
    return ""


# ──────────────────────────────────────────────
# Main: render a prompt bundle
# ──────────────────────────────────────────────

class PromptBundle:
    def __init__(
        self,
        bundle_id: str,
        query: str,
        scopes_used: list[str],
        budget_tokens: int,
        sections: dict[str, list[KMFObject]],
    ):
        self.bundle_id = bundle_id
        self.query = query
        self.scopes_used = scopes_used
        self.budget_tokens = budget_tokens
        self.sections = sections
        self._rendered: str = ""
        self._used_tokens: int = 0

    def render(self) -> str:
        parts: list[str] = []
        used = 0

        header = (
            f"[MEMORY CONTEXT — bundle:{self.bundle_id} — "
            f"scopes:{','.join(self.scopes_used)} — budget:{self.budget_tokens}tok]"
        )
        parts.append(header)
        used += estimate_tokens(header)

        # Profile: preferences
        prefs = self.sections.get("preferences", [])
        if prefs:
            text, tok = _build_section(
                "prefs", "PROFILE", prefs,
                _render_preference, "domain,key,value,strength"
            )
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Summary
        summaries = self.sections.get("summaries", [])
        if summaries:
            text, tok = _build_summary_section(summaries)
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Facts
        facts = self.sections.get("facts", [])
        if facts:
            text, tok = _build_section(
                "facts", "FACTS", facts,
                _render_fact, "subject,predicate,object,conf"
            )
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Decisions
        decisions = self.sections.get("decisions", [])
        if decisions:
            text, tok = _build_section(
                "decisions", "DECISIONS", decisions,
                _render_decision, "title,decision,conf"
            )
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Episodes
        episodes = self.sections.get("episodes", [])
        if episodes:
            text, tok = _build_episode_section(episodes)
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Entities
        entities = self.sections.get("entities", [])
        if entities:
            text, tok = _build_section(
                "entities", "ENTITIES", entities,
                _render_entity, "name,type"
            )
            if used + tok <= self.budget_tokens:
                parts.append(text)
                used += tok

        # Conflicts — always include if any, they're critical
        conflicts = self.sections.get("conflicts", [])
        if conflicts:
            text, tok = _build_conflict_section(conflicts)
            parts.append(text)
            used += tok

        parts.append("[/MEMORY CONTEXT]")

        self._rendered = "\n\n".join(p for p in parts if p)
        self._used_tokens = used
        return self._rendered

    @property
    def rendered(self) -> str:
        if not self._rendered:
            self.render()
        return self._rendered

    @property
    def used_tokens(self) -> int:
        if not self._used_tokens:
            self.render()
        return self._used_tokens

    def to_dict(self) -> dict:
        return {
            "bundle_id": self.bundle_id,
            "query": self.query,
            "scopes_used": self.scopes_used,
            "budget_tokens": self.budget_tokens,
            "used_tokens_est": self.used_tokens,
            "sections": {k: [o.id for o in v] for k, v in self.sections.items()},
            "rendered_context": self.rendered,
        }
