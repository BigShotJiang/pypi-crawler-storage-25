"""
KMF Recall Pipeline
7-stage recall with semantic search (or keyword fallback).

Scoring formula:
  score = sem*0.35 + imp*0.20 + conf*0.15 + rec*0.15 + scope*0.10 - sens*0.05

  sem: cosine similarity if embeddings available, keyword overlap otherwise
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from ..models.base import (
    KMFObject, ObjectStatus, ObjectType, Sensitivity,
)
from ..storage.repository import Repository
from ..render.toon import PromptBundle, estimate_tokens
from ..models.base import new_id


# ──────────────────────────────────────────────
# Scoring helpers
# ──────────────────────────────────────────────

SENSITIVITY_PENALTY = {
    Sensitivity.PUBLIC:       0.0,
    Sensitivity.INTERNAL:     0.0,
    Sensitivity.PRIVATE:      0.1,
    Sensitivity.RESTRICTED:   0.3,
    Sensitivity.SECRET_LOCAL: 1.0,
}


def _recency_score(obj: KMFObject) -> float:
    """Decay: objects older than 365 days score < 0.5."""
    try:
        if isinstance(obj.updated_at, str):
            updated = datetime.fromisoformat(obj.updated_at.replace("Z", "+00:00"))
        else:
            updated = obj.updated_at
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        age_days = (now - updated).days
        return max(0.0, 1.0 - age_days / 365.0)
    except Exception:
        return 0.5


def _scope_match(obj: KMFObject, query_scopes: list[str]) -> float:
    obj_scopes = obj.scope if isinstance(obj.scope, list) else [obj.scope]
    if not query_scopes:
        return 1.0
    matches = sum(1 for s in query_scopes if s in obj_scopes)
    return min(1.0, matches / max(1, len(query_scopes)))


def _keyword_relevance(obj: KMFObject, keywords: list[str]) -> float:
    """Keyword overlap fallback when embeddings not available."""
    if not keywords:
        return 0.5
    text_parts: list[str] = []
    for v in obj.content.values():
        if isinstance(v, str):
            text_parts.append(v.lower())
        elif isinstance(v, list):
            text_parts.extend(str(i).lower() for i in v)
    full_text = " ".join(text_parts)
    hits = sum(1 for kw in keywords if kw.lower() in full_text)
    return min(1.0, hits / len(keywords))


def score_object(
    obj: KMFObject,
    keywords: list[str],
    query_scopes: list[str],
    semantic_score: Optional[float] = None,
) -> float:
    """
    Score an object for a given query.
    If semantic_score is provided, uses it instead of keyword matching.
    """
    sem  = semantic_score if semantic_score is not None else _keyword_relevance(obj, keywords)
    imp  = obj.importance
    conf = obj.confidence
    rec  = _recency_score(obj)
    scope = _scope_match(obj, query_scopes)
    sens_v = obj.sensitivity if isinstance(obj.sensitivity, str) else obj.sensitivity.value
    sens_pen = SENSITIVITY_PENALTY.get(sens_v, 0.0)

    return (
        sem   * 0.35
        + imp * 0.20
        + conf * 0.15
        + rec  * 0.15
        + scope * 0.10
        - sens_pen * 0.05
    )


# ──────────────────────────────────────────────
# Policy checks
# ──────────────────────────────────────────────

def _passes_policy(
    obj: KMFObject,
    query_scopes: list[str],
    allow_restricted: bool = False,
) -> bool:
    sens_v = obj.sensitivity if isinstance(obj.sensitivity, str) else obj.sensitivity.value

    if sens_v == Sensitivity.SECRET_LOCAL or sens_v == "secret_local_only":
        return False
    if sens_v == Sensitivity.RESTRICTED or sens_v == "restricted":
        return allow_restricted
    if not obj.is_promptable():
        return False
    return True


# ──────────────────────────────────────────────
# Recall result
# ──────────────────────────────────────────────

@dataclass
class RecallResult:
    query: str
    scopes: list[str]
    budget_tokens: int
    used_semantic: bool = False
    candidates: list[tuple[float, KMFObject]] = field(default_factory=list)
    selected: dict[str, list[KMFObject]] = field(default_factory=dict)
    conflicts_flagged: list[KMFObject] = field(default_factory=list)
    bundle: Optional[PromptBundle] = None


# ──────────────────────────────────────────────
# Recall pipeline
# ──────────────────────────────────────────────

class RecallPipeline:

    def __init__(self, repo: Repository, embedding_engine=None):
        self.repo = repo
        self._engine = embedding_engine

    def _get_indexer(self):
        """Lazy-create the embedding indexer."""
        from .embeddings import EmbeddingIndexer, EmbeddingEngine, embeddings_available
        if not embeddings_available():
            return None
        engine = self._engine or EmbeddingEngine()
        return EmbeddingIndexer(self.repo, engine)

    def recall(
        self,
        query: str,
        scopes: Optional[list[str]] = None,
        budget_tokens: int = 2000,
        allow_restricted: bool = False,
        max_per_type: int = 5,
        use_semantic: bool = True,
    ) -> RecallResult:
        """
        Full 7-stage recall pipeline.
        Returns a RecallResult with a ready-to-use PromptBundle.
        """
        result = RecallResult(
            query=query,
            scopes=scopes or [],
            budget_tokens=budget_tokens,
        )

        # ── Stage 1: Query analysis ─────────────
        keywords = self._extract_keywords(query)
        effective_scopes = scopes or []

        # Try semantic scoring — silently fall back to keywords on any failure
        semantic_scores: dict[str, float] = {}
        if use_semantic:
            try:
                indexer = self._get_indexer()
                if indexer is not None:
                    indexer.index_all()
                    semantic_scores = indexer.semantic_scores(query)
                    result.used_semantic = bool(semantic_scores)
            except ImportError:
                pass
            except Exception as e:
                import logging
                logging.getLogger("kmf.recall").warning(
                    f"Semantic search failed, falling back to keyword: {e}"
                )

        # ── Stage 2+3: Scope filter + Candidates ─
        all_objects = self.repo.list_objects(status=ObjectStatus.ACTIVE)

        # ── Stage 4: Score and rank ──────────────
        scored: list[tuple[float, KMFObject]] = []
        for obj in all_objects:
            if not _passes_policy(obj, effective_scopes, allow_restricted):
                continue
            sem = semantic_scores.get(obj.id)
            s = score_object(obj, keywords, effective_scopes, semantic_score=sem)
            scored.append((s, obj))

        scored.sort(key=lambda x: x[0], reverse=True)
        result.candidates = scored

        # ── Stage 5: Conflict check ──────────────
        conflict_objs = self.repo.list_objects(
            type=ObjectType.CONFLICT,
            status=ObjectStatus.ACTIVE,
        )
        result.conflicts_flagged = [
            c for c in conflict_objs
            if c.content.get("resolution_status", "unresolved") == "unresolved"
        ]

        # ── Stage 6: Budget allocation ───────────
        selected: dict[str, list[KMFObject]] = {
            "preferences": [],
            "facts": [],
            "decisions": [],
            "summaries": [],
            "episodes": [],
            "entities": [],
            "conflicts": result.conflicts_flagged,
        }

        for _, obj in scored:
            t = obj.type if isinstance(obj.type, str) else obj.type.value
            if t == "conflict":
                continue
            key = t + "s"
            if key in selected and len(selected[key]) < max_per_type:
                selected[key].append(obj)

        result.selected = selected

        # ── Stage 7: Bundle composition ──────────
        bundle = PromptBundle(
            bundle_id=new_id("ctx"),
            query=query,
            scopes_used=effective_scopes,
            budget_tokens=budget_tokens,
            sections=selected,
        )
        bundle.render()
        result.bundle = bundle

        return result

    def _extract_keywords(self, query: str) -> list[str]:
        STOPWORDS = {
            "ich", "du", "er", "sie", "es", "wir", "ihr",
            "und", "oder", "aber", "ist", "sind", "war",
            "the", "a", "an", "is", "are", "was", "i",
            "we", "you", "it", "and", "or", "but", "in",
            "on", "at", "to", "for", "of", "with", "as",
            "were", "be", "been", "have", "has",
            "that", "this", "what", "how", "why", "when",
        }
        words = query.lower().split()
        return [w.strip(".,!?;:\"'") for w in words if w not in STOPWORDS and len(w) > 2]
