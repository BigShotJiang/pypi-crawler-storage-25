"""
KMF Embeddings
Local semantic embeddings for recall scoring.

Design:
  - Model-agnostic: sentence-transformers by default, pluggable
  - Lazy-loaded: model only downloads on first use
  - Local-first: runs entirely offline after first download
  - Graceful fallback: if embeddings unavailable, keyword scoring kicks in
  - Stored in SQLite alongside objects (no separate vector DB)

Default model: all-MiniLM-L6-v2
  - 80MB download
  - 384-dim vectors
  - Fast on CPU (~5ms/doc)
  - Good multilingual support (DE/EN both work)

Usage:
    from kmf.recall.embeddings import EmbeddingEngine
    eng = EmbeddingEngine()              # lazy — model not loaded yet
    vec = eng.embed("architecture decision")  # loads model on first call
    score = eng.similarity(vec_a, vec_b)
"""
from __future__ import annotations

import json
import logging
import math
from typing import Optional

logger = logging.getLogger("kmf.embeddings")

# Default model — small, fast, multilingual
DEFAULT_MODEL = "all-MiniLM-L6-v2"

# Dimension for the default model
DEFAULT_DIM = 384


# ──────────────────────────────────────────────
# Availability check
# ──────────────────────────────────────────────

def embeddings_available() -> bool:
    """Check if sentence-transformers is installed."""
    try:
        import sentence_transformers  # noqa: F401
        return True
    except ImportError:
        return False


# ──────────────────────────────────────────────
# Embedding engine
# ──────────────────────────────────────────────

class EmbeddingEngine:
    """
    Wraps a sentence-transformers model with lazy loading and caching.

    Thread-safe for read operations (encode is stateless after load).
    """

    def __init__(self, model_name: str = DEFAULT_MODEL):
        self.model_name = model_name
        self._model = None
        self._dim: Optional[int] = None

    def _load(self):
        """Load model on first use."""
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading embedding model: {self.model_name}")
            self._model = SentenceTransformer(self.model_name)
            # Determine dimension
            test = self._model.encode(["test"], convert_to_numpy=True)
            self._dim = test.shape[1]
            logger.info(f"Model loaded: {self.model_name} dim={self._dim}")
        except ImportError:
            raise ImportError(
                "sentence-transformers is required for semantic search.\n"
                "Install with: pip install sentence-transformers\n"
                "Or use keyword search (no install needed)."
            )

    @property
    def dim(self) -> int:
        self._load()
        return self._dim

    def embed(self, text: str) -> list[float]:
        """Embed a single text. Returns a list of floats."""
        self._load()
        import numpy as np
        vec = self._model.encode([text], convert_to_numpy=True, normalize_embeddings=True)
        return vec[0].tolist()

    def embed_batch(self, texts: list[str], batch_size: int = 64) -> list[list[float]]:
        """Embed multiple texts efficiently."""
        if not texts:
            return []
        self._load()
        vecs = self._model.encode(
            texts,
            batch_size=batch_size,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=len(texts) > 50,
        )
        return [v.tolist() for v in vecs]

    def similarity(self, vec_a: list[float], vec_b: list[float]) -> float:
        """
        Cosine similarity between two normalized vectors.
        Since we normalize on encode, this is just dot product.
        """
        if not vec_a or not vec_b or len(vec_a) != len(vec_b):
            return 0.0
        return sum(a * b for a, b in zip(vec_a, vec_b))


# ──────────────────────────────────────────────
# Object text extractor
# ──────────────────────────────────────────────

def object_to_embed_text(obj) -> str:
    """
    Convert a KMFObject to the text that should be embedded.
    Combines the most semantically relevant fields.
    """
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    c = obj.content
    parts = []

    if t == "fact":
        subj = c.get("subject", "")
        pred = c.get("predicate", "")
        obj_val = c.get("object", "")
        natural = c.get("natural_text", "")
        parts.append(natural or f"{subj} {pred} {obj_val}")

    elif t == "preference":
        domain = c.get("domain", "")
        key = c.get("key", "")
        value = c.get("value", "")
        natural = c.get("natural_text", "")
        parts.append(natural or f"{domain} {key} {value}")

    elif t == "decision":
        title = c.get("title", "")
        decision = c.get("decision", "")
        rationale = " ".join(c.get("rationale", []))
        natural = c.get("natural_text", "")
        parts.append(natural or f"{title} {decision} {rationale}")

    elif t == "entity":
        name = c.get("canonical_name", "")
        etype = c.get("entity_type", "")
        aliases = " ".join(c.get("aliases", []))
        parts.append(f"{name} {etype} {aliases}")

    elif t == "episode":
        title = c.get("title", "")
        short = c.get("summary_short", "")
        long_ = c.get("summary_long", "")
        topics = " ".join(c.get("topics", []))
        parts.append(f"{title} {short} {long_} {topics}")

    elif t == "summary":
        parts.append(c.get("text", ""))

    else:
        # Fallback: join all string values
        parts.extend(str(v) for v in c.values() if isinstance(v, str))

    return " ".join(p for p in parts if p).strip()


# ──────────────────────────────────────────────
# Vector storage in SQLite
# ──────────────────────────────────────────────

EMBEDDING_SCHEMA = """
CREATE TABLE IF NOT EXISTS embeddings (
    object_id   TEXT PRIMARY KEY,
    model_name  TEXT NOT NULL,
    vector      TEXT NOT NULL,   -- JSON array of floats
    text_hash   TEXT NOT NULL,   -- SHA256 of embedded text (for staleness check)
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_emb_model ON embeddings(model_name);
"""


class VectorStore:
    """
    Stores and retrieves embeddings from SQLite.
    Lives alongside the main KMF repository connection.
    """

    def __init__(self, conn, model_name: str = DEFAULT_MODEL):
        self._conn = conn
        self.model_name = model_name
        self._init_schema()

    def _init_schema(self):
        self._conn.executescript(EMBEDDING_SCHEMA)
        self._conn.commit()

    def put(self, object_id: str, vector: list[float], text_hash: str):
        from datetime import datetime
        self._conn.execute(
            """INSERT OR REPLACE INTO embeddings
               (object_id, model_name, vector, text_hash, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (
                object_id,
                self.model_name,
                json.dumps(vector),
                text_hash,
                datetime.utcnow().isoformat(),
            )
        )
        self._conn.commit()

    def get(self, object_id: str) -> Optional[list[float]]:
        row = self._conn.execute(
            "SELECT vector FROM embeddings WHERE object_id = ? AND model_name = ?",
            (object_id, self.model_name)
        ).fetchone()
        if row is None:
            return None
        return json.loads(row[0])

    def get_hash(self, object_id: str) -> Optional[str]:
        row = self._conn.execute(
            "SELECT text_hash FROM embeddings WHERE object_id = ? AND model_name = ?",
            (object_id, self.model_name)
        ).fetchone()
        return row[0] if row else None

    def get_all(self) -> dict[str, list[float]]:
        """Return all vectors as {object_id: vector}."""
        rows = self._conn.execute(
            "SELECT object_id, vector FROM embeddings WHERE model_name = ?",
            (self.model_name,)
        ).fetchall()
        return {r[0]: json.loads(r[1]) for r in rows}

    def delete(self, object_id: str):
        self._conn.execute(
            "DELETE FROM embeddings WHERE object_id = ?", (object_id,)
        )
        self._conn.commit()

    def count(self) -> int:
        return self._conn.execute(
            "SELECT COUNT(*) FROM embeddings WHERE model_name = ?",
            (self.model_name,)
        ).fetchone()[0]


# ──────────────────────────────────────────────
# Indexer — builds/updates embeddings for a repo
# ──────────────────────────────────────────────

def _text_hash(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class EmbeddingIndexer:
    """
    Builds and maintains the embedding index for a KMF repository.
    """

    def __init__(self, repo, engine: Optional[EmbeddingEngine] = None):
        self._repo = repo
        self._engine = engine or EmbeddingEngine()
        self._store = VectorStore(repo._conn, self._engine.model_name)

    def index_all(self, force: bool = False) -> dict:
        """
        Index all active objects. Skips already-indexed objects unless force=True.

        Returns: {"indexed": N, "skipped": N, "failed": N}
        """
        objects = self._repo.list_objects()
        texts = []
        to_index = []

        for obj in objects:
            text = object_to_embed_text(obj)
            if not text.strip():
                continue
            h = _text_hash(text)
            if not force and self._store.get_hash(obj.id) == h:
                continue
            texts.append(text)
            to_index.append((obj, text, h))

        if not to_index:
            return {"indexed": 0, "skipped": len(objects), "failed": 0}

        try:
            vectors = self._engine.embed_batch([t for _, t, _ in to_index])
        except ImportError as e:
            raise e
        except Exception as e:
            logger.error(f"Batch embedding failed: {e}")
            return {"indexed": 0, "skipped": len(objects), "failed": len(to_index)}

        indexed = 0
        failed = 0
        for (obj, text, h), vec in zip(to_index, vectors):
            try:
                self._store.put(obj.id, vec, h)
                indexed += 1
            except Exception as e:
                logger.warning(f"Failed to store embedding for {obj.id}: {e}")
                failed += 1

        return {
            "indexed": indexed,
            "skipped": len(objects) - len(to_index),
            "failed": failed,
        }

    def index_object(self, obj) -> bool:
        """Index a single object. Returns True if indexed."""
        text = object_to_embed_text(obj)
        if not text.strip():
            return False
        try:
            vec = self._engine.embed(text)
            self._store.put(obj.id, vec, _text_hash(text))
            return True
        except Exception as e:
            logger.warning(f"Failed to embed {obj.id}: {e}")
            return False

    def semantic_scores(self, query: str) -> dict[str, float]:
        """
        Compute semantic similarity scores for all indexed objects.
        Returns {object_id: score 0-1}.
        """
        try:
            query_vec = self._engine.embed(query)
        except Exception:
            return {}

        all_vecs = self._store.get_all()
        scores = {}
        for obj_id, vec in all_vecs.items():
            scores[obj_id] = self._engine.similarity(query_vec, vec)
        return scores

    @property
    def store(self) -> VectorStore:
        return self._store
