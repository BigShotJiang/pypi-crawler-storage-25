"""
KMF MCP — Model Context Protocol server.

Exposes KMF memory as MCP tools for Claude Desktop and claude.ai.

Usage:
    python -m kmf.mcp.server --repo personal.kmf
    kmf mcp personal.kmf
"""
from .server import MCPServer, run_server, TOOLS, HANDLERS

__all__ = ["MCPServer", "run_server", "TOOLS", "HANDLERS"]
