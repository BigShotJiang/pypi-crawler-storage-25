"""
KMF MCP Server entry point.

Usage:
    # With uvx (recommended — no install needed):
    uvx kmf mcp

    # After pip install:
    python -m kmf.mcp.server
    kmf mcp
"""
import argparse
import os
import sys
from pathlib import Path
from .server import run_server

DEFAULT_REPO = Path.home() / ".kmf" / "personal.kmf"


def main():
    parser = argparse.ArgumentParser(
        prog="kmf mcp",
        description=(
            "KMF MCP server — gives Claude persistent memory.\n\n"
            "Add to Claude Desktop config (~/.claude/claude_desktop_config.json):\n"
            '{\n'
            '  "mcpServers": {\n'
            '    "kmf": {\n'
            '      "command": "uvx",\n'
            '      "args": ["kmf", "mcp"]\n'
            '    }\n'
            '  }\n'
            '}'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "repo",
        nargs="?",
        default=str(DEFAULT_REPO),
        help=f"Path to .kmf file (default: {DEFAULT_REPO})",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level — goes to stderr, not stdout",
    )
    args = parser.parse_args()
    run_server(repo_path=args.repo, log_level=args.log_level)


if __name__ == "__main__":
    main()
