"""
KMF MCP Server
Exposes KMF memory operations as MCP tools for Claude Desktop and claude.ai.

Tools exposed:
  kmf_recall      — retrieve relevant memory context for a query
  kmf_ingest_text — extract and store memory from a conversation snippet
  kmf_remember    — directly store a fact, preference, or decision
  kmf_forget      — archive (soft-delete) a memory object
  kmf_stats       — repository statistics
  kmf_conflicts   — list unresolved conflicts

Usage:
  # Start the server (uses stdio transport — standard for MCP)
  python -m kmf.mcp.server --repo personal.kmf

  # Or via CLI
  kmf mcp personal.kmf

MCP config for Claude Desktop (claude_desktop_config.json):
  {
    "mcpServers": {
      "kmf": {
        "command": "python",
        "args": ["-m", "kmf.mcp.server", "--repo", "/path/to/personal.kmf"]
      }
    }
  }
"""
from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("kmf.mcp")


# ──────────────────────────────────────────────
# Tool definitions (MCP schema)
# ──────────────────────────────────────────────

TOOLS = [
    {
        "name": "kmf_recall",
        "description": (
            "Retrieve relevant memory context for a query. "
            "Returns a compact TOON-formatted bundle with facts, preferences, "
            "decisions, and recent episodes relevant to the query. "
            "Use this at the start of conversations to load user context. "
            "Automatically respects token budget."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What you want to recall (e.g. 'user preferences', 'project architecture', 'recent decisions')",
                },
                "budget_tokens": {
                    "type": "integer",
                    "description": "Max tokens for the context bundle (default: 1500)",
                    "default": 1500,
                },
                "scopes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional scope filter (e.g. ['personal', 'work'])",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "kmf_ingest_text",
        "description": (
            "Extract and store memory from a conversation snippet. "
            "Uses Claude Haiku to automatically extract facts, preferences, "
            "decisions, and entities — then consolidates them into memory. "
            "Use after significant conversations to persist what was learned."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Conversation text in 'User: ... / Assistant: ...' format",
                },
                "title": {
                    "type": "string",
                    "description": "Short title for this conversation (optional)",
                    "default": "Conversation",
                },
                "api_key": {
                    "type": "string",
                    "description": "Anthropic API key for extraction (uses ANTHROPIC_API_KEY env var if not provided)",
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "kmf_remember",
        "description": (
            "Directly store a specific piece of information as a memory object. "
            "Use when you want to explicitly remember something without full extraction. "
            "Supports: fact, preference, decision."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "type": {
                    "type": "string",
                    "enum": ["fact", "preference", "decision"],
                    "description": "Type of memory object to create",
                },
                "content": {
                    "type": "object",
                    "description": (
                        "Content depends on type:\n"
                        "fact: {subject, predicate, object, confidence?}\n"
                        "preference: {domain, key, value, strength?}\n"
                        "decision: {title, decision, rationale?, tradeoffs?, confidence?}"
                    ),
                },
                "confidence": {
                    "type": "number",
                    "description": "Confidence score 0.0-1.0 (default: 0.9)",
                    "default": 0.9,
                },
            },
            "required": ["type", "content"],
        },
    },
    {
        "name": "kmf_forget",
        "description": (
            "Archive (soft-delete) a memory object by ID. "
            "The object is marked as archived and excluded from recall, "
            "but kept in history. Use when information is outdated or incorrect."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "object_id": {
                    "type": "string",
                    "description": "ID of the object to archive (from kmf_recall results)",
                },
                "reason": {
                    "type": "string",
                    "description": "Why this is being forgotten (optional, stored as note)",
                },
            },
            "required": ["object_id"],
        },
    },
    {
        "name": "kmf_stats",
        "description": (
            "Get repository statistics: object counts by type, "
            "total objects, last commit, and repository name."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "kmf_conflicts",
        "description": (
            "List unresolved memory conflicts. "
            "A conflict occurs when two facts have the same subject+predicate "
            "but different values. Returns conflicts that need resolution."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "kmf_graph",
        "description": (
            "Show memory organized by topic and subtopic — a knowledge graph. "
            "Returns a tree: trading → polymarket_bot, coding → python, school → handouts. "
            "Use to explore what KMF knows about a specific domain, "
            "or query within a specific topic for more focused recall."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {
                    "type": "string",
                    "description": "Filter to specific topic (e.g. 'trading', 'coding', 'school'). Empty = full tree.",
                },
                "query": {
                    "type": "string",
                    "description": "Query within the topic (optional)",
                },
            },
            "required": [],
        },
    },
]


# ──────────────────────────────────────────────
# Tool handlers
# ──────────────────────────────────────────────

def handle_recall(kmf, params: dict) -> str:
    query = params.get("query", "")
    budget = int(params.get("budget_tokens", 1500))
    scopes = params.get("scopes") or None

    if not query.strip():
        return "Error: query cannot be empty"

    # Check if memory is empty — trigger onboarding
    stats = kmf.stats()
    if stats.get("total_active", 0) == 0:
        return (
            "KMF memory is empty. I don't know anything about you yet.\n\n"
            "To build your memory, tell me about yourself in this conversation "
            "and I'll save it using kmf_remember. Or import your Claude conversation "
            "history using kmf_ingest_text.\n\n"
            "Example: tell me your name, what you're working on, "
            "your preferred coding language, and communication style."
        )

    bundle = kmf.recall(query=query, budget_tokens=budget, scopes=scopes)
    return bundle.rendered


def handle_ingest_text(kmf, params: dict) -> str:
    text = params.get("text", "").strip()
    title = params.get("title", "Conversation")
    api_key = params.get("api_key") or os.environ.get("ANTHROPIC_API_KEY", "")

    if not text:
        return "Error: text cannot be empty"
    if not api_key:
        return "Error: no API key. Set ANTHROPIC_API_KEY or pass api_key in params."

    try:
        result = kmf.ingest_text(text=text, title=title, api_key=api_key)
        added = len(result.added)
        updated = len(result.updated)
        conflicts = len(result.conflicts_created)
        skipped = len(result.skipped)

        lines = [f"✓ Ingested '{title}'"]
        lines.append(f"  {added} objects added, {updated} updated, {skipped} skipped")
        if conflicts:
            lines.append(f"  ⚠ {conflicts} conflict(s) detected — use kmf_conflicts to review")

        # Show what was added
        for obj in result.added[:5]:
            t = obj.type if isinstance(obj.type, str) else obj.type.value
            if t == "fact":
                c = obj.content
                lines.append(f"  + fact: {c.get('subject')} {c.get('predicate')} {c.get('object')}")
            elif t == "preference":
                c = obj.content
                lines.append(f"  + pref: {c.get('domain')}/{c.get('key')} = {c.get('value')}")
            elif t == "decision":
                c = obj.content
                lines.append(f"  + decision: {c.get('title')}")
        if len(result.added) > 5:
            lines.append(f"  ... and {len(result.added) - 5} more")

        kmf.save(kmf._repo._db_path if kmf._repo._db_path != ":memory:" else None)
        return "\n".join(lines)

    except Exception as e:
        return f"Error during ingest: {e}"


def handle_remember(kmf, params: dict) -> str:
    from kmf.models.base import (
        KMFObject, ObjectType, Sensitivity, Provenance,
        ProvenanceWriter, ProvenanceMethod, Permissions, PromptUse,
    )
    from kmf.consolidation.engine import SessionInput

    obj_type = params.get("type", "").lower()
    content = params.get("content", {})
    confidence = float(params.get("confidence", 0.9))

    if obj_type not in ("fact", "preference", "decision"):
        return f"Error: type must be one of: fact, preference, decision. Got: '{obj_type}'"

    if not isinstance(content, dict):
        return "Error: content must be a JSON object"

    # Validate required fields per type
    required = {
        "fact": ["subject", "predicate", "object"],
        "preference": ["domain", "key", "value"],
        "decision": ["title", "decision"],
    }
    missing = [f for f in required[obj_type] if not content.get(f)]
    if missing:
        return f"Error: missing required fields for {obj_type}: {', '.join(missing)}"

    # Build a minimal session and consolidate
    session_kwargs = {
        "title": f"Direct: {obj_type}",
        "summary_short": f"Manually remembered {obj_type}",
    }
    item = {**content, "confidence": confidence, "writer": "explicit_user_statement"}

    if obj_type == "fact":
        session_kwargs["proposed_facts"] = [item]
    elif obj_type == "preference":
        session_kwargs["proposed_preferences"] = [item]
    elif obj_type == "decision":
        session_kwargs["proposed_decisions"] = [item]

    session = SessionInput(**session_kwargs)
    result = kmf.consolidate(session)

    type_map = {"fact": "facts", "preference": "preferences", "decision": "decisions"}
    added_of_type = [o for o in result.added if (o.type if isinstance(o.type, str) else o.type.value) == obj_type]

    if added_of_type:
        obj = added_of_type[0]
        return f"✓ Remembered {obj_type} (id: {obj.id})\n  Content: {json.dumps(content, ensure_ascii=False)}"
    elif result.updated:
        return f"✓ Updated existing {obj_type}\n  Content: {json.dumps(content, ensure_ascii=False)}"
    else:
        return f"Skipped (low stability or duplicate): {json.dumps(content, ensure_ascii=False)}"


def handle_forget(kmf, params: dict) -> str:
    from kmf.security import validate_object_id
    obj_id = params.get("object_id", "").strip()
    reason = params.get("reason", "")

    if not obj_id:
        return "Error: object_id cannot be empty"

    try:
        validate_object_id(obj_id)
    except ValueError as e:
        return f"Error: {e}"

    obj = kmf.get(obj_id)
    if obj is None:
        return f"Error: object '{obj_id}' not found"

    t = obj.type if isinstance(obj.type, str) else obj.type.value
    kmf.archive(obj_id)

    msg = f"✓ Archived {t} '{obj_id}'"
    if reason:
        msg += f"\n  Reason: {reason}"
    return msg


def handle_stats(kmf, params: dict) -> str:
    stats = kmf.stats()
    lines = [f"Repository: {stats['name']}"]
    lines.append(f"Total active objects: {stats['total_active']}")
    if stats.get("object_counts"):
        for t, n in sorted(stats["object_counts"].items()):
            lines.append(f"  {t}: {n}")
    lines.append(f"Commits: {stats['commits']}")
    if stats.get("last_commit"):
        lines.append(f"Last commit: {stats['last_commit'][:24]}")
    return "\n".join(lines)


def handle_conflicts(kmf, params: dict) -> str:
    from kmf.models.base import ObjectType, ObjectStatus
    conflicts = kmf.list(type=ObjectType.CONFLICT)
    unresolved = [
        c for c in conflicts
        if c.content.get("resolution_status", "unresolved") == "unresolved"
    ]
    if not unresolved:
        return "✓ No unresolved conflicts"

    lines = [f"⚠ {len(unresolved)} unresolved conflict(s):\n"]
    for c in unresolved:
        lines.append(f"ID: {c.id}")
        lines.append(f"  {c.content.get('reason', '')}")
        members = c.content.get("members", [])
        if members:
            lines.append(f"  Members: {', '.join(members)}")
        lines.append("")
    lines.append("Use kmf_forget(object_id) to archive the outdated version.")
    return "\n".join(lines)


def handle_graph(kmf, params: dict) -> str:
    topic = params.get("topic", "").strip() or None
    query = params.get("query", "").strip() or None

    try:
        kg = kmf.graph()

        if query and topic:
            results = kg.query(query, topic=topic)
            if not results:
                return f"No results for '{query}' in topic '{topic}'"
            lines = [f"Results for '{query}' in [{topic}]:\n"]
            for score, obj in results[:10]:
                t = obj.type if isinstance(obj.type, str) else obj.type.value
                from kmf.recall.embeddings import object_to_embed_text
                preview = object_to_embed_text(obj)[:80]
                lines.append(f"  [{score:.2f}] {t}: {preview}")
            return "\n".join(lines)

        elif topic:
            tree = kg.tree()
            if topic not in tree:
                available = ", ".join(sorted(tree.keys()))
                return f"Topic '{topic}' not found. Available: {available}"
            return tree[topic].display()

        else:
            # Full tree
            display = kg.display()
            topics = kg.topics()
            if not topics:
                return (
                    "Knowledge graph is empty.\n"
                    "Build it first: kmf graph --build personal.kmf\n"
                    "Or it builds automatically on next ingest."
                )
            return display

    except Exception as e:
        return f"Graph error: {e}"


HANDLERS = {
    "kmf_recall": handle_recall,
    "kmf_ingest_text": handle_ingest_text,
    "kmf_remember": handle_remember,
    "kmf_forget": handle_forget,
    "kmf_stats": handle_stats,
    "kmf_conflicts": handle_conflicts,
    "kmf_graph": handle_graph,
}


# ──────────────────────────────────────────────
# MCP stdio transport
# ──────────────────────────────────────────────

class MCPServer:
    """
    Minimal MCP server over stdio (JSON-RPC 2.0).
    No external dependencies — pure stdlib.

    Auto-creates repository if it doesn't exist.
    Detects first run and injects onboarding prompt.
    """

    def __init__(self, repo_path: str, default_budget: int = 1500):
        self.repo_path = repo_path
        self.default_budget = default_budget
        self._kmf = None
        self._repo_path_resolved = Path(repo_path).expanduser().resolve() if repo_path else None
        self._is_new_repo = False

    def _get_kmf(self):
        """Lazy-load or create KMF repository."""
        if self._kmf is None:
            from kmf.api import KMF
            p = self._repo_path_resolved
            if p and p.exists():
                logger.info(f"Loading KMF repo: {p}")
                self._kmf = KMF.load(p)
            else:
                # Auto-create — make parent dirs if needed
                if p:
                    p.parent.mkdir(parents=True, exist_ok=True)
                name = p.stem if p else "personal"
                logger.info(f"Creating new KMF repo: {name}")
                self._kmf = KMF.create(name)
                self._is_new_repo = True
                # Save immediately so it exists on disk
                if p:
                    self._kmf.save(p)
        return self._kmf

    def _save(self):
        """Save if we have a path."""
        if self._kmf and self._repo_path_resolved:
            self._kmf.save(self._repo_path_resolved)

    def _send(self, obj: dict):
        line = json.dumps(obj, ensure_ascii=False)
        sys.stdout.write(line + "\n")
        sys.stdout.flush()

    def _error(self, req_id, code: int, message: str) -> dict:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        }

    def _ok(self, req_id, result) -> dict:
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    def handle(self, request: dict) -> Optional[dict]:
        req_id = request.get("id")
        method = request.get("method", "")
        params = request.get("params", {})

        # Notifications (no id) — no response needed
        if req_id is None:
            return None

        try:
            if method == "initialize":
                # Trigger lazy load so we know if it's a new repo
                try:
                    self._get_kmf()
                except Exception:
                    pass
                return self._ok(req_id, {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "kmf",
                        "version": "2.0.0",
                        "new_repo": self._is_new_repo,
                    },
                })

            elif method == "tools/list":
                return self._ok(req_id, {"tools": TOOLS})

            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})

                if tool_name not in HANDLERS:
                    return self._error(req_id, -32601, f"Unknown tool: '{tool_name}'")

                kmf = self._get_kmf()
                try:
                    result_text = HANDLERS[tool_name](kmf, tool_args)
                    # Auto-save after mutations
                    if tool_name in ("kmf_ingest_text", "kmf_remember", "kmf_forget"):
                        self._save()
                    return self._ok(req_id, {
                        "content": [{"type": "text", "text": result_text}],
                        "isError": False,
                    })
                except Exception as e:
                    logger.exception(f"Tool '{tool_name}' error")
                    return self._ok(req_id, {
                        "content": [{"type": "text", "text": f"Error: {e}"}],
                        "isError": True,
                    })

            elif method == "ping":
                return self._ok(req_id, {})

            else:
                return self._error(req_id, -32601, f"Method not found: '{method}'")

        except Exception as e:
            logger.exception("Unhandled error in handle()")
            return self._error(req_id, -32603, f"Internal error: {e}")

    def run(self):
        """Main loop — read JSON-RPC from stdin, write responses to stdout."""
        logger.info(f"KMF MCP server starting (repo: {self.repo_path})")

        for raw_line in sys.stdin:
            raw_line = raw_line.strip()
            if not raw_line:
                continue

            try:
                request = json.loads(raw_line)
            except json.JSONDecodeError as e:
                self._send(self._error(None, -32700, f"Parse error: {e}"))
                continue

            response = self.handle(request)
            if response is not None:
                self._send(response)


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────

def run_server(repo_path: str, log_level: str = "WARNING"):
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.WARNING),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,  # logs to stderr, not stdout (stdout is MCP transport)
    )
    server = MCPServer(repo_path=repo_path)
    server.run()
