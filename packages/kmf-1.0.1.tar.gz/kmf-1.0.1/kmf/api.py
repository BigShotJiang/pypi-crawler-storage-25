"""
KMF Public API
One clean entry point for all KMF operations.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from .models.base import (
    KMFObject, ObjectType, ObjectStatus,
    Commit, Manifest, new_id,
)
from .storage.repository import Repository
from .recall.pipeline import RecallPipeline, RecallResult
from .consolidation.engine import ConsolidationEngine, SessionInput, ConsolidationResult
from .render.toon import PromptBundle


class KMF:
    """
    KMF — Knowledge Memory Format
    Main entry point for all repository operations.

    Usage:
        # Create new
        kmf = KMF.create("personal")

        # Load from file
        kmf = KMF.load("personal.kmf")

        # Save
        kmf.save("personal.kmf")

        # Consolidate a session
        result = kmf.consolidate(session)

        # Recall context for a query
        bundle = kmf.recall("what did we decide about the database?")
        print(bundle.rendered)
    """

    def __init__(self, repo: Repository):
        self._repo = repo
        self._recall = RecallPipeline(repo)
        self._consolidation = ConsolidationEngine(repo)

    # ── Factory methods ───────────────────────

    @classmethod
    def create(
        cls,
        name: str = "personal",
        owner: str = "user_local",
        scopes: Optional[list[str]] = None,
        description: str = "",
    ) -> "KMF":
        """Create a new in-memory repository."""
        repo = Repository.create(
            name=name,
            owner=owner,
            scopes=scopes or [name],
            description=description,
        )
        return cls(repo)

    @classmethod
    def load(cls, path: str | Path) -> "KMF":
        """Load repository from a .kmf file."""
        repo = Repository.from_kmf(path)
        return cls(repo)

    # ── Persistence ───────────────────────────

    def save(self, path: str | Path) -> Path:
        """Export repository to a .kmf file."""
        return self._repo.export_kmf(path)

    # ── Objects ───────────────────────────────

    def put(self, obj: KMFObject) -> KMFObject:
        """Store an object directly."""
        self._repo.put_object(obj)
        return obj

    def get(self, obj_id: str) -> Optional[KMFObject]:
        """Retrieve an object by ID."""
        return self._repo.get_object(obj_id)

    def list(
        self,
        type: Optional[ObjectType] = None,
        scopes: Optional[list[str]] = None,
        min_confidence: float = 0.0,
    ) -> list[KMFObject]:
        """List active objects with optional filters."""
        return self._repo.list_objects(
            type=type,
            scopes=scopes,
            min_confidence=min_confidence,
        )

    def archive(self, obj_id: str) -> bool:
        """Archive an object (soft delete)."""
        return self._repo.archive_object(obj_id)

    def delete(self, obj_id: str) -> bool:
        """Hard-delete an object."""
        return self._repo.delete_object(obj_id)

    def resolve_conflict(
        self,
        conflict_id: str,
        preferred_id: str,
        note: str = "",
        status: str = "resolved",
    ) -> bool:
        """Resolve a conflict object."""
        obj = self._repo.get_object(conflict_id)
        if obj is None:
            return False
        obj.content["resolution_status"] = status
        obj.content["preferred_ref"] = preferred_id
        if note:
            obj.content["resolution_note"] = note
        obj.touch()
        self._repo.put_object(obj)
        return True

    # ── Consolidation ─────────────────────────

    def consolidate(
        self,
        session: SessionInput,
        auto_commit: bool = True,
        stability_threshold: float = 0.3,
    ) -> ConsolidationResult:
        """
        Run post-session consolidation.
        This is the main write path — chat → structured memory.
        """
        return self._consolidation.consolidate(
            session=session,
            auto_commit=auto_commit,
            stability_threshold=stability_threshold,
        )

    # ── Recall ────────────────────────────────

    def recall(
        self,
        query: str,
        scopes: Optional[list[str]] = None,
        budget_tokens: int = 2000,
        allow_restricted: bool = False,
    ) -> PromptBundle:
        """
        Build a token-budgeted prompt bundle for a query.
        This is the main read path.
        """
        result = self._recall.recall(
            query=query,
            scopes=scopes,
            budget_tokens=budget_tokens,
            allow_restricted=allow_restricted,
        )
        return result.bundle

    def recall_full(
        self,
        query: str,
        scopes: Optional[list[str]] = None,
        budget_tokens: int = 2000,
    ) -> RecallResult:
        """Full recall result with scoring details."""
        return self._recall.recall(
            query=query,
            scopes=scopes,
            budget_tokens=budget_tokens,
        )

    # ── History ───────────────────────────────

    def history(self) -> list[Commit]:
        """List all commits in reverse chronological order."""
        return self._repo.list_commits()

    # ── Stats ─────────────────────────────────

    def stats(self) -> dict:
        """Repository statistics."""
        return self._repo.stats()

    # ── Import from existing KMF spec example ─

    @classmethod
    def from_example_repo(cls, repo_dir: str | Path) -> "KMF":
        """
        Load from an unzipped KMF example repository directory.
        Useful for testing with the bundled example-repo.
        """
        repo_dir = Path(repo_dir)
        manifest_path = repo_dir / "manifest.json"
        manifest = Manifest.model_validate(
            json.loads(manifest_path.read_text())
        )
        repo = Repository(manifest=manifest)
        inst = cls(repo)

        # Load all object JSON files
        objects_dir = repo_dir / "objects"
        if objects_dir.exists():
            for json_file in objects_dir.rglob("*.json"):
                data = json.loads(json_file.read_text())
                if isinstance(data, list):
                    for od in data:
                        repo.put_object(KMFObject.model_validate(od))
                elif isinstance(data, dict):
                    repo.put_object(KMFObject.model_validate(data))

        return inst

    # ── Sync / Merge ──────────────────────────

    def merge(self, other: "KMF", scopes: Optional[list[str]] = None):
        """
        Merge another KMF repository into this one.

        Strategy:
          - Same ID: newer updated_at wins
          - New objects: added
          - Fact conflicts (same subj+pred, different value): Conflict object created
          - Preferences: newer wins

        Args:
            other:  KMF instance to merge from (read-only)
            scopes: If set, only merge objects matching these scopes

        Returns:
            MergeResult with summary of changes

        Example:
            base = KMF.load("work.kmf")
            home = KMF.load("home.kmf")
            result = base.merge(home)
            print(result.summary())
            base.save("merged.kmf")
        """
        from .sync.merge import merge as _merge
        return _merge(self, other, scopes=scopes)

    # ── Version info ──────────────────────────

    @property
    def version(self) -> str:
        """Schema version of this repository."""
        return self._repo.manifest.kmf_version

    # ── Ingest ────────────────────────────────

    def ingest_file(
        self,
        path: str | Path,
        api_key: Optional[str] = None,
        model: str = "claude-haiku-4-5-20251001",
        auto_commit: bool = True,
        on_progress=None,
    ) -> list:
        """
        Parse a Claude export file and consolidate all conversations into memory.

        This is the main entry point for importing existing conversations.
        Uses Claude Haiku for extraction (cheapest model — < $0.001 per conversation).

        Args:
            path: Path to conversations.json or single conversation JSON
            api_key: Anthropic API key (or set ANTHROPIC_API_KEY env var)
            model: Extraction model (default: Haiku)
            auto_commit: Whether to commit to storage immediately
            on_progress: Optional callback(current, total, transcript)

        Returns:
            List of ConsolidationResult objects

        Example:
            kmf = KMF.create("personal")
            results = kmf.ingest_file("conversations.json", api_key="sk-...")
            kmf.save("personal.kmf")
        """
        from .ingest import from_claude_file
        sessions = from_claude_file(
            path=path,
            api_key=api_key,
            model=model,
            on_progress=on_progress,
        )
        results = []
        for session in sessions:
            result = self.consolidate(session, auto_commit=auto_commit)
            results.append(result)
        return results

    def ingest_text(
        self,
        text: str,
        title: str = "Conversation",
        api_key: Optional[str] = None,
        model: str = "claude-haiku-4-5-20251001",
        auto_commit: bool = True,
    ):
        """
        Extract memory from a copy-pasted conversation and consolidate.

        Args:
            text: Raw conversation text (User: ... / Assistant: ... format)
            title: Conversation title
            api_key: Anthropic API key
            model: Extraction model
            auto_commit: Whether to commit to storage

        Returns:
            ConsolidationResult

        Example:
            result = kmf.ingest_text(
                \"\"\"User: I prefer Python over JavaScript.
Assistant: Got it, I'll use Python.\"\"\",
                title="Language preference",
                api_key="sk-..."
            )
        """
        from .ingest import from_text
        session = from_text(text=text, title=title, api_key=api_key, model=model)
        return self.consolidate(session, auto_commit=auto_commit)

    def __repr__(self) -> str:
        s = self.stats()
        return (
            f"<KMF repo='{s['name']}' "
            f"objects={s['total_active']} "
            f"chunks={s['chunks']}>"
        )
