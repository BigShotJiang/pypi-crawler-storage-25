
from __future__ import annotations
import json, logging, os, re
from dataclasses import dataclass, field
from typing import Optional
from ..models.base import KMFObject, ObjectStatus

logger = logging.getLogger("kmf.graph")
BATCH_SIZE = 50

GRAPH_SCHEMA = """
CREATE TABLE IF NOT EXISTS object_topics (
    object_id TEXT PRIMARY KEY, topic TEXT NOT NULL,
    subtopic TEXT NOT NULL DEFAULT "general",
    tags TEXT NOT NULL DEFAULT "[]", assigned_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_topic ON object_topics(topic);
CREATE INDEX IF NOT EXISTS idx_subtopic ON object_topics(topic, subtopic);
CREATE TABLE IF NOT EXISTS entity_links (
    entity_id TEXT NOT NULL, object_id TEXT NOT NULL,
    link_type TEXT NOT NULL DEFAULT "mentions",
    PRIMARY KEY (entity_id, object_id)
);
"""

def _obj_to_cluster_text(obj) -> str:
    t = obj.type if isinstance(obj.type, str) else obj.type.value
    c = obj.content
    if t == "fact": return f"{c.get("subject")} {c.get("predicate")} {c.get("object")}"
    if t == "preference": return f"{c.get("domain")}/{c.get("key")}: {c.get("value")}"
    if t == "decision": return f"{c.get("title")}: {c.get("decision")}"
    if t == "entity": return f"{c.get("canonical_name")} ({c.get("entity_type")})"
    return " ".join(str(v) for v in c.values() if isinstance(v, str))[:200]

def _keyword_topic(obj) -> dict:
    text = _obj_to_cluster_text(obj).lower()
    KWS = {
        "trading": ["trade","bot","polymarket","btc","eth","stake","pnl","sharpe","backtest","rust"],
        "coding": ["python","code","api","server","deploy","azure","kmf","mcp","function"],
        "school": ["handout","school","homework","exam","deutsch","pdf layout"],
        "research": ["paper","analysis","coefficient","regression","statistical","tpu"],
        "personal": ["prefer","style","language","communicate","direct"],
    }
    best, score = "personal", 0
    for topic, kws in KWS.items():
        s = sum(1 for kw in kws if kw in text)
        if s > score: best, score = topic, s
    return {"topic": best, "subtopic": "general", "tags": []}

def assign_topics_batch(objects, api_key, model="claude-haiku-4-5-20251001") -> dict:
    import urllib.request
    results = {}
    batches = [objects[i:i+BATCH_SIZE] for i in range(0, len(objects), BATCH_SIZE)]
    system = "Classify memory objects. Return ONLY JSON array: [{id, topic, subtopic, tags}]. topic=one lowercase word: trading/coding/school/research/personal/work/finance. subtopic=specific project. tags=2-3 keywords. No markdown."
    for i, batch in enumerate(batches):
        items = [{"id": o.id, "type": o.type if isinstance(o.type,str) else o.type.value, "content": _obj_to_cluster_text(o)[:100]} for o in batch]
        payload = json.dumps({"model": model, "max_tokens": len(items)*80+300, "system": system,
            "messages": [{"role":"user","content":f"Classify:\n{json.dumps(items)}"}]}).encode()
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=payload,
            headers={"Content-Type":"application/json","x-api-key":api_key,"anthropic-version":"2023-06-01"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read())
            raw = data["content"][0]["text"].strip()
            m = re.search(r"\[.*\]", raw, re.DOTALL)
            if m:
                for e in json.loads(m.group(0)):
                    if e.get("id"): results[e["id"]] = e
            print(f"  Batch {i+1}/{len(batches)}: {len(results)} clustered")
        except Exception as ex:
            print(f"  Batch {i+1} failed: {ex}")
            for o in batch: results[o.id] = _keyword_topic(o)
    return results

@dataclass
class TopicNode:
    name: str
    subtopics: dict = field(default_factory=dict)

    @property
    def total_objects(self): return sum(len(v) for v in self.subtopics.values())

    def display(self, indent=0) -> str:
        pad = "  " * indent
        lines = [f"{pad}📁 {self.name} ({self.total_objects} objects)"]
        for sub, objs in sorted(self.subtopics.items()):
            lines.append(f"{pad}  ├─ {sub} ({len(objs)})")
            for o in objs[:3]:
                t = o.type if isinstance(o.type,str) else o.type.value
                lines.append(f"{pad}    · [{t}] {_obj_to_cluster_text(o)[:60]}")
            if len(objs) > 3: lines.append(f"{pad}    ... {len(objs)-3} more")
        return "\n".join(lines)

class KnowledgeGraph:
    def __init__(self, repo, api_key=None):
        self._repo = repo
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY","")
        self._repo._conn.executescript(GRAPH_SCHEMA)
        self._repo._conn.commit()

    def build(self, force=False, use_ai=True, on_progress=None) -> dict:
        objects = self._repo.list_objects(status=ObjectStatus.ACTIVE)
        if not force:
            already = self._get_assigned_ids()
            objects = [o for o in objects if o.id not in already]
        skipped = len(self._repo.list_objects()) - len(objects)
        if not objects:
            print(f"Nothing to cluster — {skipped} already assigned")
            return {"assigned":0,"skipped":skipped,"failed":0,"api_calls":0}
        assigned = failed = api_calls = 0
        if use_ai and self._api_key:
            topic_map = assign_topics_batch(objects, self._api_key)
            api_calls = len(objects)//BATCH_SIZE + 1
            for obj in objects:
                td = topic_map.get(obj.id) or _keyword_topic(obj)
                try:
                    self._store_topic(obj.id, td)
                    self._link_entities(obj)
                    assigned += 1
                except Exception as e:
                    logger.warning(f"{obj.id}: {e}"); failed += 1
        else:
            for obj in objects:
                try:
                    self._store_topic(obj.id, _keyword_topic(obj))
                    assigned += 1
                except: failed += 1
        return {"assigned":assigned,"skipped":skipped,"failed":failed,"api_calls":api_calls}

    def tree(self) -> dict:
        rows = self._repo._conn.execute("SELECT object_id,topic,subtopic FROM object_topics").fetchall()
        obj_cache = {o.id:o for o in self._repo.list_objects()}
        tree = {}
        for obj_id, topic, subtopic in rows:
            if topic not in tree: tree[topic] = TopicNode(name=topic)
            if subtopic not in tree[topic].subtopics: tree[topic].subtopics[subtopic] = []
            if obj_id in obj_cache: tree[topic].subtopics[subtopic].append(obj_cache[obj_id])
        return tree

    def query(self, query, topic=None, subtopic=None, limit=20) -> list:
        if topic and subtopic:
            rows = self._repo._conn.execute("SELECT object_id FROM object_topics WHERE topic=? AND subtopic=?",(topic,subtopic)).fetchall()
        elif topic:
            rows = self._repo._conn.execute("SELECT object_id FROM object_topics WHERE topic=?",(topic,)).fetchall()
        else:
            rows = self._repo._conn.execute("SELECT object_id FROM object_topics").fetchall()
        candidate_ids = {r[0] for r in rows}
        from ..recall.pipeline import score_object, _passes_policy
        keywords = query.lower().split()
        scored = []
        for obj in self._repo.list_objects(status=ObjectStatus.ACTIVE):
            if candidate_ids and obj.id not in candidate_ids: continue
            if not _passes_policy(obj,[]): continue
            scored.append((score_object(obj,keywords,[]),obj))
        scored.sort(key=lambda x:x[0],reverse=True)
        return scored[:limit]

    def topics(self) -> list:
        return [r[0] for r in self._repo._conn.execute("SELECT DISTINCT topic FROM object_topics ORDER BY topic").fetchall()]

    def display(self) -> str:
        tree = self.tree()
        if not tree: return "Empty — run kg.build() first"
        lines = ["📊 Knowledge Graph","="*40]
        for name, node in sorted(tree.items()): lines.append(node.display())
        return "\n".join(lines)

    def get_topic(self, object_id) -> Optional[dict]:
        row = self._repo._conn.execute("SELECT topic,subtopic,tags FROM object_topics WHERE object_id=?",(object_id,)).fetchone()
        return {"topic":row[0],"subtopic":row[1],"tags":json.loads(row[2])} if row else None

    def related(self, object_id, limit=5) -> list:
        eids = [r[0] for r in self._repo._conn.execute("SELECT entity_id FROM entity_links WHERE object_id=?",(object_id,)).fetchall()]
        related = set()
        for eid in eids:
            for (rid,) in self._repo._conn.execute("SELECT object_id FROM entity_links WHERE entity_id=? AND object_id!=?",(eid,object_id)).fetchall():
                related.add(rid)
        row = self._repo._conn.execute("SELECT topic,subtopic FROM object_topics WHERE object_id=?",(object_id,)).fetchone()
        if row:
            for (rid,) in self._repo._conn.execute("SELECT object_id FROM object_topics WHERE topic=? AND subtopic=? AND object_id!=?",(row[0],row[1],object_id)).fetchall():
                related.add(rid)
        return [o for rid in list(related)[:limit] if (o:=self._repo.get_object(rid))]

    def _store_topic(self, object_id, td):
        from datetime import datetime
        self._repo._conn.execute(
            "INSERT OR REPLACE INTO object_topics (object_id,topic,subtopic,tags,assigned_at) VALUES (?,?,?,?,?)",
            (object_id, td.get("topic","personal"), td.get("subtopic","general"), json.dumps(td.get("tags",[])), datetime.utcnow().isoformat())
        )
        self._repo._conn.commit()

    def _link_entities(self, obj):
        text = _obj_to_cluster_text(obj).lower()
        for entity in self._repo.list_objects():
            t = entity.type if isinstance(entity.type,str) else entity.type.value
            if t != "entity": continue
            name = entity.content.get("canonical_name","").lower()
            if name and name in text:
                try: self._repo._conn.execute("INSERT OR IGNORE INTO entity_links (entity_id,object_id,link_type) VALUES (?,?,?)",(entity.id,obj.id,"mentions"))
                except: pass
        self._repo._conn.commit()

    def _get_assigned_ids(self) -> set:
        return {r[0] for r in self._repo._conn.execute("SELECT object_id FROM object_topics").fetchall()}
