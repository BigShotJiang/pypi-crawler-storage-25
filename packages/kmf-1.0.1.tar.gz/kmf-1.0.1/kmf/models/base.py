"""
KMF — Knowledge Memory Format
Core object models (Spec v0.1)
"""
from __future__ import annotations
from datetime import datetime, date
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field
from ulid import ULID


# ──────────────────────────────────────────────
# Enumerations
# ──────────────────────────────────────────────

class ObjectType(str, Enum):
    EPISODE    = "episode"
    FACT       = "fact"
    PREFERENCE = "preference"
    DECISION   = "decision"
    ENTITY     = "entity"
    SUMMARY    = "summary"
    CONFLICT   = "conflict"
    RULE       = "rule"
    GOAL       = "goal"
    TASK       = "task"

class ObjectStatus(str, Enum):
    ACTIVE     = "active"
    ARCHIVED   = "archived"
    DELETED    = "deleted"
    SUPERSEDED = "superseded"

class Sensitivity(str, Enum):
    PUBLIC          = "public"
    INTERNAL        = "internal"
    PRIVATE         = "private"
    RESTRICTED      = "restricted"
    SECRET_LOCAL    = "secret_local_only"

class PromptUse(str, Enum):
    ALWAYS      = "always"
    CONDITIONAL = "conditional"
    NEVER       = "never"

class ProvenanceWriter(str, Enum):
    EXPLICIT_USER        = "explicit_user_statement"
    ASSISTANT_INFERENCE  = "assistant_inference"
    ASSISTANT_SESSION    = "assistant_session"       # alias used in spec examples
    DOCUMENT_EXTRACTION  = "document_extraction"
    TOOL_OBSERVATION     = "tool_observation"
    CROSS_SESSION        = "cross_session_confirmation"

class ProvenanceMethod(str, Enum):
    POST_CONSOLIDATION = "post_session_consolidation"
    DIRECT_ENTRY       = "direct_entry"
    INFERENCE          = "inference"

class ResolutionStatus(str, Enum):
    UNRESOLVED          = "unresolved"
    RESOLVED            = "resolved"
    ACCEPTED_AMBIGUITY  = "accepted_ambiguity"


# ──────────────────────────────────────────────
# Sub-models
# ──────────────────────────────────────────────

class Provenance(BaseModel):
    writer: ProvenanceWriter
    method: ProvenanceMethod

class ValidTime(BaseModel):
    from_date: Optional[date] = Field(None, alias="from")
    until: Optional[date] = None

    model_config = {"populate_by_name": True}

class Permissions(BaseModel):
    read: list[str] = Field(default_factory=lambda: ["owner"])
    export: bool = True
    prompt_use: PromptUse = PromptUse.CONDITIONAL


# ──────────────────────────────────────────────
# Base Object — every KMF object inherits this
# ──────────────────────────────────────────────

def new_id(prefix: str = "obj") -> str:
    return f"{prefix}_{ULID()}"

class KMFObject(BaseModel):
    id: str = Field(default_factory=lambda: new_id("obj"))
    type: ObjectType
    schema_version: str = "0.1"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    status: ObjectStatus = ObjectStatus.ACTIVE
    scope: list[str] = Field(default_factory=lambda: ["personal"])
    sensitivity: Sensitivity = Sensitivity.INTERNAL
    confidence: float = Field(0.8, ge=0.0, le=1.0)
    importance: float = Field(0.7, ge=0.0, le=1.0)
    source_refs: list[str] = Field(default_factory=list)
    provenance: Provenance = Field(
        default_factory=lambda: Provenance(
            writer=ProvenanceWriter.ASSISTANT_INFERENCE,
            method=ProvenanceMethod.POST_CONSOLIDATION
        )
    )
    valid_time: ValidTime = Field(default_factory=ValidTime)
    permissions: Permissions = Field(default_factory=Permissions)
    content: dict[str, Any] = Field(default_factory=dict)

    def touch(self) -> None:
        self.updated_at = datetime.utcnow()

    def archive(self) -> None:
        self.status = ObjectStatus.ARCHIVED
        self.touch()

    def is_promptable(self) -> bool:
        return (
            self.status == ObjectStatus.ACTIVE
            and self.permissions.prompt_use != PromptUse.NEVER
        )

    model_config = {"use_enum_values": True}


# ──────────────────────────────────────────────
# Typed content helpers
# ──────────────────────────────────────────────

class EpisodeContent(BaseModel):
    title: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    participants: list[str] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)
    summary_short: str = ""
    summary_long: str = ""
    derived_refs: list[str] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)

class FactContent(BaseModel):
    subject: str
    predicate: str
    object: str
    qualifiers: dict[str, Any] = Field(default_factory=dict)
    natural_text: str = ""

class PreferenceContent(BaseModel):
    domain: str
    key: str
    value: str
    strength: str = "moderate"  # strong | moderate | weak
    natural_text: str = ""

class DecisionContent(BaseModel):
    title: str
    decision: str
    alternatives_considered: list[str] = Field(default_factory=list)
    rationale: list[str] = Field(default_factory=list)
    tradeoffs: list[str] = Field(default_factory=list)
    scope: list[str] = Field(default_factory=list)
    natural_text: str = ""

class EntityContent(BaseModel):
    entity_type: str  # person | organization | project | file | location | product | concept
    canonical_name: str
    aliases: list[str] = Field(default_factory=list)
    attributes: dict[str, Any] = Field(default_factory=dict)
    natural_text: str = ""

class SummaryContent(BaseModel):
    covers: list[str] = Field(default_factory=list)
    time_range: dict[str, Any] = Field(default_factory=dict)
    scope_focus: list[str] = Field(default_factory=list)
    text: str = ""
    compression_ratio: float = 0.5

class ConflictContent(BaseModel):
    members: list[str]  # exactly 2 object IDs
    reason: str
    resolution_status: ResolutionStatus = ResolutionStatus.UNRESOLVED
    preferred_ref: Optional[str] = None
    resolution_note: Optional[str] = None

class RuleContent(BaseModel):
    rule_text: str
    applies_to: list[str] = Field(default_factory=list)
    enforcement: str = "soft"  # hard | soft
    natural_text: str = ""


# ──────────────────────────────────────────────
# Chunk model
# ──────────────────────────────────────────────

class Chunk(BaseModel):
    chunk_id: str = Field(default_factory=lambda: new_id("chunk"))
    parent_object_id: str
    chunk_type: str = "raw"  # raw | summary | fact | decision | profile | project_state | task | policy
    token_count_est: int = 0
    semantic_hash: str = ""
    topic_tags: list[str] = Field(default_factory=list)
    entity_refs: list[str] = Field(default_factory=list)
    time_refs: list[str] = Field(default_factory=list)
    importance: float = 0.5
    confidence: float = 0.8
    freshness_score: float = 1.0
    prompt_priority: float = 0.5
    compression_level: str = "none"  # none | light | heavy
    text: str = ""  # rendered text of this chunk


# ──────────────────────────────────────────────
# Commit model
# ──────────────────────────────────────────────

class Commit(BaseModel):
    commit_id: str = Field(default_factory=lambda: new_id("commit"))
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    session_ref: Optional[str] = None
    added: list[str] = Field(default_factory=list)
    updated: list[str] = Field(default_factory=list)
    archived: list[str] = Field(default_factory=list)
    deleted: list[str] = Field(default_factory=list)
    conflicts_created: list[str] = Field(default_factory=list)
    conflicts_resolved: list[str] = Field(default_factory=list)
    summary: str = ""


# ──────────────────────────────────────────────
# Manifest
# ──────────────────────────────────────────────

class Manifest(BaseModel):
    kmf_version: str = "0.1"
    repository_id: str = Field(default_factory=lambda: new_id("repo"))
    name: str = "personal"
    owner: str = "user_local"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    scopes: list[str] = Field(default_factory=lambda: ["personal"])
    object_count: int = 0
    last_commit: Optional[str] = None
    encryption: str = "none"
    description: str = ""
