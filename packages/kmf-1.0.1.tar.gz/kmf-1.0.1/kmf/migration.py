"""
KMF Schema Migration
Handles version upgrades when loading older .kmf files.

Version history:
  0.1 → baseline (no migration needed, is the starting point)
  0.2 → adds sensitivity default normalization + embeddings table
  1.0 → adds valid_time index, normalizes scope to always be a list

Design:
  - Each migration is a pure function: (manifest, objects, commits) → same types
  - Migrations are additive — never delete fields, only add/normalize
  - On load, KMF auto-detects version and runs all needed migrations
  - After migration, manifest.kmf_version is updated and file re-saved

Usage:
  # Automatic — happens inside Repository.from_kmf()
  repo = Repository.from_kmf("old.kmf")  # migrates silently if needed

  # Manual check
  from kmf.migration import needs_migration, get_version
  if needs_migration("old.kmf"):
      print("Will be migrated on next load")
"""
from __future__ import annotations

import json
import logging
from typing import Callable

logger = logging.getLogger("kmf.migration")

# Current schema version
CURRENT_VERSION = "1.0"

# All known versions in order
VERSION_ORDER = ["0.1", "0.2", "1.0"]


# ──────────────────────────────────────────────
# Version utilities
# ──────────────────────────────────────────────

def _version_index(v: str) -> int:
    """Return sort index of a version string. Unknown versions get index -1."""
    try:
        return VERSION_ORDER.index(v)
    except ValueError:
        return -1


def needs_migration(file_version: str) -> bool:
    return _version_index(file_version) < _version_index(CURRENT_VERSION)


def get_pending_migrations(file_version: str) -> list[str]:
    """Return list of versions that need to be applied, in order."""
    idx = _version_index(file_version)
    if idx < 0:
        logger.warning(f"Unknown version '{file_version}', applying all migrations")
        idx = 0
    return VERSION_ORDER[idx + 1:]


# ──────────────────────────────────────────────
# Migration functions
# ──────────────────────────────────────────────

def _migrate_0_1_to_0_2(manifest: dict, objects: list[dict]) -> tuple[dict, list[dict]]:
    """
    0.1 → 0.2
    - Normalize sensitivity: ensure all objects have a valid sensitivity value
    - Normalize scope: ensure scope is always a list, not a string
    - Add schema_version field to objects that lack it
    """
    VALID_SENSITIVITY = {"public", "internal", "private", "restricted", "secret_local_only"}
    DEFAULT_SENSITIVITY = "internal"

    migrated = []
    for obj in objects:
        # Normalize sensitivity
        sens = obj.get("sensitivity", DEFAULT_SENSITIVITY)
        if sens not in VALID_SENSITIVITY:
            logger.debug(f"Normalizing sensitivity '{sens}' → '{DEFAULT_SENSITIVITY}' on {obj.get('id')}")
            obj["sensitivity"] = DEFAULT_SENSITIVITY

        # Normalize scope to list
        scope = obj.get("scope", ["personal"])
        if isinstance(scope, str):
            obj["scope"] = [scope]

        # Add schema_version if missing
        if "schema_version" not in obj:
            obj["schema_version"] = "0.2"

        migrated.append(obj)

    manifest["kmf_version"] = "0.2"
    return manifest, migrated


def _migrate_0_2_to_1_0(manifest: dict, objects: list[dict]) -> tuple[dict, list[dict]]:
    """
    0.2 → 1.0
    - Add valid_time field to objects that lack it
    - Normalize provenance: ensure writer/method fields exist
    - Normalize permissions: ensure prompt_use field exists
    - Add importance/confidence floor (clamp to 0.0-1.0)
    """
    migrated = []
    for obj in objects:
        # Add valid_time if missing
        if "valid_time" not in obj:
            obj["valid_time"] = {}

        # Normalize provenance
        prov = obj.get("provenance", {})
        if not isinstance(prov, dict):
            obj["provenance"] = {
                "writer": "assistant_inference",
                "method": "post_session_consolidation",
            }
        else:
            if "writer" not in prov:
                prov["writer"] = "assistant_inference"
            if "method" not in prov:
                prov["method"] = "post_session_consolidation"
            obj["provenance"] = prov

        # Normalize permissions
        perms = obj.get("permissions", {})
        if not isinstance(perms, dict):
            obj["permissions"] = {"read": ["owner"], "export": True, "prompt_use": "conditional"}
        else:
            if "prompt_use" not in perms:
                perms["prompt_use"] = "conditional"
            obj["permissions"] = perms

        # Clamp confidence and importance
        obj["confidence"] = max(0.0, min(1.0, float(obj.get("confidence", 0.8))))
        obj["importance"] = max(0.0, min(1.0, float(obj.get("importance", 0.7))))

        # Update schema_version
        obj["schema_version"] = "1.0"

        migrated.append(obj)

    manifest["kmf_version"] = "1.0"
    return manifest, migrated


# Registry: (from_version, to_version) → migration function
MIGRATIONS: dict[tuple[str, str], Callable] = {
    ("0.1", "0.2"): _migrate_0_1_to_0_2,
    ("0.2", "1.0"): _migrate_0_2_to_1_0,
}


# ──────────────────────────────────────────────
# Main migration runner
# ──────────────────────────────────────────────

def migrate(manifest: dict, objects: list[dict]) -> tuple[dict, list[dict], list[str]]:
    """
    Run all pending migrations on manifest + objects.

    Args:
        manifest: Manifest dict loaded from file
        objects:  List of KMFObject dicts loaded from file

    Returns:
        (updated_manifest, updated_objects, applied_migrations)
        applied_migrations: list of version strings that were applied
    """
    file_version = manifest.get("kmf_version", "0.1")

    if not needs_migration(file_version):
        return manifest, objects, []

    pending = get_pending_migrations(file_version)
    applied = []
    current_version = file_version

    for target_version in pending:
        key = (current_version, target_version)
        fn = MIGRATIONS.get(key)
        if fn is None:
            logger.warning(f"No migration found for {current_version} → {target_version}, skipping")
            current_version = target_version
            continue

        logger.info(f"Migrating KMF schema: {current_version} → {target_version} ({len(objects)} objects)")
        try:
            manifest, objects = fn(manifest, objects)
            applied.append(target_version)
            current_version = target_version
            logger.info(f"Migration to {target_version} complete")
        except Exception as e:
            logger.error(f"Migration {current_version} → {target_version} failed: {e}")
            raise RuntimeError(
                f"KMF schema migration failed ({current_version} → {target_version}): {e}\n"
                "Your original file has NOT been modified."
            ) from e

    return manifest, objects, applied
