"""
KMF CLI
Command-line interface for managing KMF repositories.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint

from ..api import KMF
from ..consolidation.engine import SessionInput
from ..models.base import ObjectType

console = Console()


def _load_repo(path: str) -> KMF:
    p = Path(path)
    if not p.exists():
        console.print(f"[red]Error:[/red] File not found: {path}")
        sys.exit(1)
    return KMF.load(path)


@click.group()
@click.version_option("0.1.0", prog_name="kmf")
def cli():
    """KMF — Knowledge Memory Format\n\nPortable, local, versioned AI memory."""
    pass


# ── init ──────────────────────────────────────

@cli.command()
@click.argument("name", default="personal")
@click.option("--owner", default="user_local", help="Repository owner")
@click.option("--scope", multiple=True, help="Scope(s) for this repository")
@click.option("--description", default="", help="Description")
@click.option("--output", "-o", default=None, help="Output path (default: <name>.kmf)")
def init(name, owner, scope, description, output):
    """Initialize a new KMF repository."""
    scopes = list(scope) if scope else [name]
    kmf = KMF.create(name=name, owner=owner, scopes=scopes, description=description)
    out_path = output or f"{name}.kmf"
    saved = kmf.save(out_path)
    console.print(f"[green]✓[/green] Created repository [bold]{name}[/bold] → {saved}")


# ── stats ─────────────────────────────────────

@cli.command()
@click.argument("repo_path")
def stats(repo_path):
    """Show repository statistics."""
    kmf = _load_repo(repo_path)
    s = kmf.stats()

    table = Table(title=f"Repository: {s['name']}", show_header=True)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Repository ID", s["repository_id"])
    table.add_row("Total active objects", str(s["total_active"]))
    table.add_row("Chunks", str(s["chunks"]))
    table.add_row("Commits", str(s["commits"]))
    table.add_row("Last commit", str(s.get("last_commit", "—")))
    table.add_row("Updated", str(s.get("updated_at", "—")))

    if s["object_counts"]:
        table.add_section()
        for otype, count in s["object_counts"].items():
            table.add_row(f"  {otype}s", str(count))

    console.print(table)


# ── list ──────────────────────────────────────

@cli.command("list")
@click.argument("repo_path")
@click.option("--type", "-t", "obj_type", default=None,
              type=click.Choice([t.value for t in ObjectType]),
              help="Filter by object type")
@click.option("--min-confidence", default=0.0, help="Minimum confidence score")
@click.option("--limit", default=20, help="Maximum results")
def list_objects(repo_path, obj_type, min_confidence, limit):
    """List objects in a repository."""
    kmf = _load_repo(repo_path)
    type_filter = ObjectType(obj_type) if obj_type else None
    objects = kmf.list(type=type_filter, min_confidence=min_confidence)[:limit]

    if not objects:
        console.print("[yellow]No objects found.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("ID", style="dim", width=24)
    table.add_column("Type", width=12)
    table.add_column("Confidence", width=10)
    table.add_column("Importance", width=10)
    table.add_column("Summary", style="white")

    for obj in objects:
        c = obj.content
        t = obj.type if isinstance(obj.type, str) else obj.type.value
        summary = (
            c.get("natural_text")
            or c.get("title")
            or c.get("canonical_name")
            or c.get("text", "")[:80]
            or str(c)[:80]
        )
        table.add_row(
            obj.id[:22],
            t,
            f"{obj.confidence:.2f}",
            f"{obj.importance:.2f}",
            str(summary)[:70],
        )

    console.print(table)
    console.print(f"[dim]Showing {len(objects)} objects[/dim]")


# ── recall ────────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.argument("query")
@click.option("--budget", default=2000, help="Token budget")
@click.option("--scope", multiple=True, help="Scope filter(s)")
@click.option("--json-output", is_flag=True, help="Output as JSON")
def recall(repo_path, query, budget, scope, json_output):
    """Build a memory context bundle for a query."""
    kmf = _load_repo(repo_path)
    scopes = list(scope) if scope else None
    bundle = kmf.recall(query, scopes=scopes, budget_tokens=budget)
    bundle.render()

    if json_output:
        click.echo(json.dumps(bundle.to_dict(), ensure_ascii=False, indent=2))
        return

    console.print(Panel(
        Text(bundle.rendered, style="white"),
        title=f"[bold cyan]Memory Context[/bold cyan] — {bundle.used_tokens}/{budget} tokens",
        border_style="cyan",
    ))


# ── consolidate ───────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.argument("session_file")
@click.option("--dry-run", is_flag=True, help="Show what would be committed without committing")
@click.option("--threshold", default=0.3, help="Stability threshold (0-1)")
def consolidate(repo_path, session_file, dry_run, threshold):
    """Consolidate a session JSON file into the repository."""
    kmf = _load_repo(repo_path)

    sf = Path(session_file)
    if not sf.exists():
        console.print(f"[red]Error:[/red] Session file not found: {session_file}")
        sys.exit(1)

    data = json.loads(sf.read_text())
    session = SessionInput(**data)

    result = kmf.consolidate(
        session,
        auto_commit=not dry_run,
        stability_threshold=threshold,
    )

    prefix = "[yellow]DRY RUN —[/yellow] " if dry_run else ""

    console.print(f"\n{prefix}[bold]Consolidation result:[/bold]")
    console.print(f"  [green]Added:[/green]    {len(result.added)} objects")
    console.print(f"  [blue]Updated:[/blue]   {len(result.updated)} objects")
    console.print(f"  [red]Conflicts:[/red]  {len(result.conflicts_created)}")
    console.print(f"  [dim]Skipped:[/dim]   {len(result.skipped)}")

    if result.skipped:
        console.print("\n[dim]Skipped:[/dim]")
        for obj, reason in result.skipped:
            console.print(f"  [dim]• {obj.id[:20]} — {reason}[/dim]")

    if result.conflicts_created:
        console.print("\n[yellow]⚠ Conflicts created:[/yellow]")
        for c in result.conflicts_created:
            console.print(f"  • {c.content.get('reason', c.id)}")

    if not dry_run:
        saved = kmf.save(repo_path)
        console.print(f"\n[green]✓[/green] Saved → {saved}")


# ── history ───────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.option("--limit", default=10, help="Number of commits to show")
def history(repo_path, limit):
    """Show commit history."""
    kmf = _load_repo(repo_path)
    commits = kmf.history()[:limit]

    if not commits:
        console.print("[yellow]No commits yet.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Commit ID", style="dim", width=26)
    table.add_column("Timestamp", width=22)
    table.add_column("Added", width=6)
    table.add_column("Updated", width=8)
    table.add_column("Summary")

    for commit in commits:
        ts = commit.timestamp
        if hasattr(ts, "isoformat"):
            ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
        else:
            ts_str = str(ts)[:19]
        table.add_row(
            commit.commit_id[:24],
            ts_str,
            str(len(commit.added)),
            str(len(commit.updated)),
            commit.summary[:60],
        )

    console.print(table)


# ── export ────────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.argument("output_path")
def export(repo_path, output_path):
    """Export repository to a .kmf file."""
    kmf = _load_repo(repo_path)
    saved = kmf.save(output_path)
    s = kmf.stats()
    console.print(
        f"[green]✓[/green] Exported [bold]{s['name']}[/bold] "
        f"({s['total_active']} objects) → {saved}"
    )


# ── get ───────────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.argument("object_id")
def get(repo_path, object_id):
    """Get a specific object by ID."""
    kmf = _load_repo(repo_path)
    obj = kmf.get(object_id)
    if obj is None:
        console.print(f"[red]Not found:[/red] {object_id}")
        sys.exit(1)
    click.echo(json.dumps(obj.model_dump(mode="json"), ensure_ascii=False, indent=2))


# ── merge ─────────────────────────────────────

@cli.command()
@click.argument("base_repo")
@click.argument("incoming_repo")
@click.option("--output", default=None, help="Output path (default: overwrites base)")
@click.option("--scopes", default=None, help="Comma-separated scope filter (e.g. personal,work)")
@click.option("--dry-run", is_flag=True, help="Show what would change without saving")
def merge(base_repo, incoming_repo, output, scopes, dry_run):
    """
    Merge two KMF repositories.

    BASE_REPO:     Repository to merge into
    INCOMING_REPO: Repository to merge from

    Example:
        kmf merge work.kmf home.kmf --output merged.kmf
        kmf merge personal.kmf colleague.kmf --scopes work --dry-run
    """
    base = _load_repo(base_repo)
    try:
        incoming = _load_repo(incoming_repo)
    except Exception as e:
        console.print(f"[red]Error loading incoming repo:[/red] {e}")
        sys.exit(1)

    scope_list = [s.strip() for s in scopes.split(",")] if scopes else None

    console.print(f"\n[bold]Merging[/bold] {incoming_repo} → {base_repo}")
    if scope_list:
        console.print(f"Scopes: [cyan]{', '.join(scope_list)}[/cyan]")
    if dry_run:
        console.print("[dim]Dry run — no changes will be saved[/dim]")
    console.print()

    result = base.merge(incoming, scopes=scope_list)

    console.print(result.summary())

    if not dry_run:
        out = output or base_repo
        base.save(out)
        console.print(f"\n[green]✓[/green] Saved to {out}")
    else:
        console.print("\n[dim](dry run — not saved)[/dim]")


# ── version ───────────────────────────────────

@cli.command()
@click.argument("repo_path")
def version(repo_path):
    """Show schema version of a .kmf file."""
    kmf = _load_repo(repo_path)
    from ..migration import CURRENT_VERSION, needs_migration
    v = kmf.version
    status = ""
    if needs_migration(v):
        status = f" [yellow](outdated — current is {CURRENT_VERSION}, will auto-migrate on load)[/yellow]"
    else:
        status = " [green](up to date)[/green]"
    console.print(f"{repo_path}: [bold]{v}[/bold]{status}")


# ── index ─────────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.option("--force", is_flag=True, help="Re-index all objects, even if already indexed")
@click.option("--model", default="all-MiniLM-L6-v2", show_default=True,
              help="Embedding model to use")
def index(repo_path, force, model):
    """
    Build semantic search index for a repository.

    Downloads and runs the embedding model locally (~80MB first run).
    Required for semantic recall — without it, recall falls back to keywords.

    Install requirements first:
        pip install sentence-transformers

    Example:
        kmf index personal.kmf
    """
    try:
        from ..recall.embeddings import EmbeddingEngine, EmbeddingIndexer, embeddings_available
    except ImportError:
        console.print("[red]Error:[/red] sentence-transformers not installed.")
        console.print("Run: [bold]pip install sentence-transformers[/bold]")
        sys.exit(1)

    if not embeddings_available():
        console.print("[red]Error:[/red] sentence-transformers not installed.")
        console.print("Run: [bold]pip install sentence-transformers[/bold]")
        sys.exit(1)

    kmf = _load_repo(repo_path)

    console.print(f"\n[bold]Building semantic index[/bold] for {repo_path}")
    console.print(f"Model: [cyan]{model}[/cyan]  Force: {'yes' if force else 'no'}\n")

    try:
        engine = EmbeddingEngine(model_name=model)
        indexer = EmbeddingIndexer(kmf._repo, engine)

        with console.status("[bold green]Indexing objects...[/bold green]"):
            stats = indexer.index_all(force=force)

        total = stats["indexed"] + stats["skipped"] + stats["failed"]
        console.print(
            f"[green]✓[/green] Done — "
            f"{stats['indexed']} indexed, "
            f"{stats['skipped']} skipped (up to date), "
            f"{stats['failed']} failed"
        )
        if stats["failed"]:
            console.print("[yellow]Some objects failed to index — check logs.[/yellow]")

        kmf.save(repo_path)
        console.print(f"[dim]Saved to {repo_path}[/dim]")

    except Exception as e:
        console.print(f"[red]Indexing failed:[/red] {e}")
        sys.exit(1)


# ── mcp ──────────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.option("--log-level", default="WARNING", show_default=True,
              type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"]),
              help="Log level (to stderr)")
def mcp(repo_path, log_level):
    """
    Start the KMF MCP server for Claude Desktop / claude.ai.

    REPO_PATH: Path to .kmf file (created if not exists).

    Communicates over stdio (JSON-RPC 2.0).

    Add to claude_desktop_config.json:

    \b
    {
      "mcpServers": {
        "kmf": {
          "command": "kmf",
          "args": ["mcp", "/path/to/personal.kmf"]
        }
      }
    }
    """
    from ..mcp.server import run_server
    # Print config hint to stderr so it doesn't pollute the MCP transport
    sys.stderr.write(f"KMF MCP server starting — repo: {repo_path}\n")
    run_server(repo_path=repo_path, log_level=log_level)


# ── ingest ───────────────────────────────────

@cli.command()
@click.argument("repo_path")
@click.argument("conversations_file")
@click.option("--api-key", envvar="ANTHROPIC_API_KEY", help="Anthropic API key")
@click.option("--model", default="claude-haiku-4-5-20251001", show_default=True, help="Extraction model")
@click.option("--dry-run", is_flag=True, help="Parse and extract but don't commit")
def ingest(repo_path, conversations_file, api_key, model, dry_run):
    """
    Import conversations from a Claude export file into memory.

    CONVERSATIONS_FILE: Path to conversations.json or single conversation JSON.

    Uses Claude Haiku for extraction (< $0.001 per conversation).

    Example:
        kmf ingest personal.kmf ~/Downloads/conversations.json
    """
    from ..ingest import from_claude_file

    if not api_key:
        console.print("[red]Error:[/red] No API key. Set ANTHROPIC_API_KEY or use --api-key.")
        sys.exit(1)

    kmf = _load_repo(repo_path)

    total_processed = 0
    total_added = 0
    total_skipped = 0

    def progress(current, total, transcript):
        console.print(
            f"  [dim]{current}/{total}[/dim] Extracting: [bold]{transcript.title[:60]}[/bold] "
            f"[dim]({transcript.token_estimate} tokens)[/dim]"
        )

    console.print(f"\n[bold]Ingesting[/bold] {conversations_file} → {repo_path}")
    console.print(f"Model: [cyan]{model}[/cyan]  Dry run: {'yes' if dry_run else 'no'}\n")

    try:
        sessions = from_claude_file(
            path=conversations_file,
            api_key=api_key,
            model=model,
            on_progress=progress,
        )
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Extraction error:[/red] {e}")
        sys.exit(1)

    console.print(f"\n[green]✓[/green] Extracted {len(sessions)} sessions. Consolidating...\n")

    for session in sessions:
        result = kmf.consolidate(session, auto_commit=not dry_run)
        added = len(result.added)
        skipped = len(result.skipped)
        conflicts = len(result.conflicts_created)
        total_added += added
        total_skipped += skipped
        total_processed += 1

        status = "[green]✓[/green]" if added > 0 else "[dim]○[/dim]"
        conflict_str = f" [yellow]{conflicts} conflicts[/yellow]" if conflicts else ""
        console.print(
            f"  {status} [bold]{session.title[:55]}[/bold] "
            f"+{added} objects, {skipped} skipped{conflict_str}"
        )

    if not dry_run:
        kmf.save(repo_path)

    console.print(
        f"\n[bold green]Done.[/bold green] "
        f"{total_processed} sessions · "
        f"{total_added} objects added · "
        f"{total_skipped} skipped"
        + (" [dim](dry run — not saved)[/dim]" if dry_run else f" · saved to {repo_path}")
    )


def main():
    cli()


if __name__ == "__main__":
    main()
