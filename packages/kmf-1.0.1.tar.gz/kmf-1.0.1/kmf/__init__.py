"""
KMF — Knowledge Memory Format
Portable, local, versioned AI memory.

Quick start:
    from kmf import KMF, SessionInput

    kmf = KMF.create("personal")
    kmf.consolidate(SessionInput(
        title="My session",
        proposed_facts=[{"subject": "user", "predicate": "prefers", "object": "Python",
                         "confidence": 0.95, "writer": "explicit_user_statement"}],
    ))
    bundle = kmf.recall("Python")
    print(bundle.rendered)
    kmf.save("personal.kmf")
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("kmf")
except PackageNotFoundError:
    __version__ = "1.0.0"

from .api import KMF
from .consolidation.engine import SessionInput, ConsolidationResult
from .models.base import (
    KMFObject, ObjectType, ObjectStatus, Sensitivity,
    Provenance, ProvenanceWriter, ProvenanceMethod,
    Permissions, PromptUse, Commit, Manifest, Chunk, ValidTime, new_id,
)
from .recall.pipeline import RecallPipeline, RecallResult
from .render.toon import PromptBundle, estimate_tokens
from .storage.repository import Repository
from .migration import CURRENT_VERSION as SCHEMA_VERSION

__all__ = [
    "KMF", "SessionInput", "ConsolidationResult",
    "KMFObject", "ObjectType", "ObjectStatus", "Sensitivity",
    "Provenance", "ProvenanceWriter", "ProvenanceMethod",
    "Permissions", "PromptUse", "Commit", "Manifest", "Chunk", "ValidTime", "new_id",
    "RecallPipeline", "RecallResult", "PromptBundle", "estimate_tokens",
    "Repository", "__version__", "SCHEMA_VERSION",
]
