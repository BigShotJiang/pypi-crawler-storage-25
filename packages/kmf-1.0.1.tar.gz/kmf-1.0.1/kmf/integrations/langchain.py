"""
KMF LangChain Integration
Provides LangChain-compatible Memory and Retriever classes backed by KMF.

Requires: pip install langchain langchain-core

Classes:
  KMFMemory    — drop-in replacement for ConversationBufferMemory
  KMFRetriever — semantic retriever for use in RAG chains

Usage:
    from langchain.chains import ConversationChain
    from langchain_openai import ChatOpenAI
    from kmf.integrations.langchain import KMFMemory

    memory = KMFMemory.from_file("personal.kmf")
    chain = ConversationChain(llm=ChatOpenAI(), memory=memory)
    chain.predict(input="What did we decide about the database?")
    # → Claude recalls from KMF, answers, stores new memory

    # Or with a retriever in a RAG chain:
    from kmf.integrations.langchain import KMFRetriever
    retriever = KMFRetriever.from_file("personal.kmf")
    docs = retriever.get_relevant_documents("Python architecture")
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    pass


# ──────────────────────────────────────────────
# Availability check
# ──────────────────────────────────────────────

def _require_langchain():
    try:
        import langchain_core  # noqa: F401
    except ImportError:
        raise ImportError(
            "langchain-core is required for KMF LangChain integration.\n"
            "Install with: pip install langchain langchain-core"
        )


# ──────────────────────────────────────────────
# KMFMemory
# ──────────────────────────────────────────────

class KMFMemory:
    """
    LangChain-compatible Memory backed by KMF.

    Replaces ConversationBufferMemory / ConversationSummaryMemory.
    Instead of keeping raw chat history, stores structured memory objects
    and injects a compact TOON context bundle at each turn.

    Usage:
        memory = KMFMemory.from_file("personal.kmf", api_key="sk-ant-...")
        chain = ConversationChain(llm=llm, memory=memory)

    The memory_key controls what variable is injected into the prompt.
    Default is "history" to be compatible with ConversationChain.
    """

    def __init__(
        self,
        kmf,
        api_key: Optional[str] = None,
        memory_key: str = "history",
        budget_tokens: int = 1500,
        auto_ingest: bool = True,
        ingest_model: str = "claude-haiku-4-5-20251001",
    ):
        """
        Args:
            kmf:          KMF instance
            api_key:      Anthropic API key for auto-ingest (or ANTHROPIC_API_KEY env)
            memory_key:   Variable name injected into prompts (default: "history")
            budget_tokens: Token budget for context bundle
            auto_ingest:  If True, save memory after each conversation turn
            ingest_model: Model for auto-extraction (default: Haiku)
        """
        _require_langchain()
        self._kmf = kmf
        self._api_key = api_key
        self.memory_key = memory_key
        self.budget_tokens = budget_tokens
        self.auto_ingest = auto_ingest
        self.ingest_model = ingest_model
        self._pending_messages: list[dict] = []

    @classmethod
    def from_file(cls, path: str, **kwargs) -> "KMFMemory":
        """Load from a .kmf file."""
        from ..api import KMF
        from pathlib import Path
        p = Path(path)
        kmf = KMF.load(p) if p.exists() else KMF.create(p.stem)
        return cls(kmf=kmf, **kwargs)

    @classmethod
    def create(cls, name: str = "personal", **kwargs) -> "KMFMemory":
        """Create with a new in-memory repository."""
        from ..api import KMF
        return cls(kmf=KMF.create(name), **kwargs)

    # ── LangChain Memory interface ────────────

    @property
    def memory_variables(self) -> list[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, str]:
        """
        Called at the start of each chain run.
        Returns relevant memory context as a string.
        """
        # Use the user's input as the recall query
        query = ""
        for key in ("input", "question", "query", "human_input"):
            if key in inputs:
                query = str(inputs[key])
                break
        if not query:
            query = " ".join(str(v) for v in inputs.values())

        bundle = self._kmf.recall(query=query, budget_tokens=self.budget_tokens)
        return {self.memory_key: bundle.rendered}

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """
        Called after each chain run with the inputs and outputs.
        Optionally ingests the exchange into KMF.
        """
        if not self.auto_ingest or not self._api_key:
            return

        # Build conversation text from this turn
        human = inputs.get("input", inputs.get("question", ""))
        ai = outputs.get("response", outputs.get("output", outputs.get("text", "")))

        if human and ai:
            turn_text = f"User: {human}\nAssistant: {ai}"
            self._pending_messages.append({"human": human, "ai": ai})
            try:
                self._kmf.ingest_text(
                    text=turn_text,
                    title=f"Turn: {human[:40]}",
                    api_key=self._api_key,
                    model=self.ingest_model,
                )
            except Exception as e:
                import logging
                logging.getLogger("kmf.langchain").warning(f"Auto-ingest failed: {e}")

    def clear(self) -> None:
        """Clear pending messages (does not delete stored memory)."""
        self._pending_messages = []

    def save(self, path: str) -> None:
        """Persist repository to disk."""
        self._kmf.save(path)


# ──────────────────────────────────────────────
# KMFRetriever
# ──────────────────────────────────────────────

class KMFRetriever:
    """
    LangChain-compatible retriever backed by KMF semantic search.

    Returns KMF memory objects as LangChain Documents for use in RAG chains.

    Usage:
        retriever = KMFRetriever.from_file("personal.kmf")
        docs = retriever.get_relevant_documents("database architecture")
        # → [Document(page_content="...", metadata={type: "fact", ...}), ...]

        # Use in a RAG chain:
        chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
        )
    """

    def __init__(
        self,
        kmf,
        budget_tokens: int = 2000,
        k: int = 10,
    ):
        """
        Args:
            kmf:          KMF instance
            budget_tokens: Token budget for recall
            k:            Max documents to return
        """
        _require_langchain()
        self._kmf = kmf
        self.budget_tokens = budget_tokens
        self.k = k

    @classmethod
    def from_file(cls, path: str, **kwargs) -> "KMFRetriever":
        from ..api import KMF
        from pathlib import Path
        p = Path(path)
        kmf = KMF.load(p) if p.exists() else KMF.create(p.stem)
        return cls(kmf=kmf, **kwargs)

    def _obj_to_document(self, obj, score: float = 0.0):
        """Convert a KMFObject to a LangChain Document."""
        from langchain_core.documents import Document

        t = obj.type if isinstance(obj.type, str) else obj.type.value
        c = obj.content

        # Build page_content
        if t == "fact":
            text = c.get("natural_text") or f"{c.get('subject')} {c.get('predicate')} {c.get('object')}"
        elif t == "preference":
            text = c.get("natural_text") or f"{c.get('domain')}/{c.get('key')}: {c.get('value')}"
        elif t == "decision":
            rationale = "; ".join(c.get("rationale", []))
            text = c.get("natural_text") or f"{c.get('title')}: {c.get('decision')}. Rationale: {rationale}"
        elif t == "episode":
            text = c.get("summary_long") or c.get("summary_short") or c.get("title", "")
        else:
            text = " ".join(str(v) for v in c.values() if isinstance(v, str))

        return Document(
            page_content=text.strip(),
            metadata={
                "kmf_id": obj.id,
                "kmf_type": t,
                "confidence": obj.confidence,
                "importance": obj.importance,
                "score": round(score, 4),
                **{k: v for k, v in c.items() if isinstance(v, (str, int, float, bool))},
            },
        )

    # ── LangChain Retriever interface ─────────

    def get_relevant_documents(self, query: str) -> list:
        """Retrieve relevant KMF objects as LangChain Documents."""
        result = self._kmf.recall_full(
            query=query,
            budget_tokens=self.budget_tokens,
        )

        docs = []
        seen_ids = set()
        for score, obj in result.candidates[:self.k]:
            if obj.id not in seen_ids:
                docs.append(self._obj_to_document(obj, score))
                seen_ids.add(obj.id)

        return docs

    async def aget_relevant_documents(self, query: str) -> list:
        """Async version — runs sync version in executor."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_relevant_documents, query)

    # Support LangChain's BaseRetriever protocol
    def as_retriever(self, **kwargs):
        return self
