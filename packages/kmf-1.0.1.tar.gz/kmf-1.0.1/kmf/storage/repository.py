"""
KMF Storage Layer
SQLite-backed local repository with import/export as .kmf (ZIP)
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from ..models.base import (
    Chunk, Commit, KMFObject, Manifest,
    ObjectStatus, ObjectType,
)


# ──────────────────────────────────────────────
# JSON helpers
# ──────────────────────────────────────────────

def _to_json(obj) -> str:
    if hasattr(obj, "model_dump"):
        return json.dumps(obj.model_dump(mode="json"), ensure_ascii=False, indent=2)
    return json.dumps(obj, ensure_ascii=False, default=str)

def _from_json_obj(data: dict) -> KMFObject:
    return KMFObject.model_validate(data)

def _from_json_chunk(data: dict) -> Chunk:
    return Chunk.model_validate(data)

def _from_json_commit(data: dict) -> Commit:
    return Commit.model_validate(data)


# ──────────────────────────────────────────────
# Repository
# ──────────────────────────────────────────────

class Repository:
    """
    A KMF repository backed by SQLite.
    Can be serialized to/from a .kmf ZIP archive.
    """

    def __init__(self, manifest: Manifest, db_path: str = ":memory:"):
        self.manifest = manifest
        self._db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    # ── Schema ────────────────────────────────

    def _init_schema(self):
        c = self._conn
        c.executescript("""
            CREATE TABLE IF NOT EXISTS objects (
                id          TEXT PRIMARY KEY,
                type        TEXT NOT NULL,
                status      TEXT NOT NULL DEFAULT 'active',
                scope       TEXT NOT NULL,          -- JSON array
                sensitivity TEXT NOT NULL,
                confidence  REAL NOT NULL,
                importance  REAL NOT NULL,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL,
                data        TEXT NOT NULL           -- full JSON blob
            );

            CREATE TABLE IF NOT EXISTS chunks (
                chunk_id          TEXT PRIMARY KEY,
                parent_object_id  TEXT NOT NULL,
                chunk_type        TEXT NOT NULL,
                token_count_est   INTEGER,
                importance        REAL,
                confidence        REAL,
                freshness_score   REAL,
                prompt_priority   REAL,
                topic_tags        TEXT,              -- JSON array
                text              TEXT NOT NULL,
                data              TEXT NOT NULL      -- full JSON blob
            );

            CREATE TABLE IF NOT EXISTS commits (
                commit_id   TEXT PRIMARY KEY,
                timestamp   TEXT NOT NULL,
                data        TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_obj_type   ON objects(type);
            CREATE INDEX IF NOT EXISTS idx_obj_status ON objects(status);
            CREATE INDEX IF NOT EXISTS idx_obj_scope  ON objects(scope);
            CREATE INDEX IF NOT EXISTS idx_chunk_parent ON chunks(parent_object_id);
            CREATE INDEX IF NOT EXISTS idx_chunk_type   ON chunks(chunk_type);
        """)
        c.commit()

    # ── Objects ───────────────────────────────

    def put_object(self, obj: KMFObject) -> None:
        obj.touch()
        data = json.loads(_to_json(obj))
        self._conn.execute(
            """INSERT OR REPLACE INTO objects
               (id, type, status, scope, sensitivity, confidence, importance,
                created_at, updated_at, data)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                obj.id,
                obj.type if isinstance(obj.type, str) else obj.type.value,
                obj.status if isinstance(obj.status, str) else obj.status.value,
                json.dumps(obj.scope),
                obj.sensitivity if isinstance(obj.sensitivity, str) else obj.sensitivity.value,
                obj.confidence,
                obj.importance,
                obj.created_at.isoformat() if isinstance(obj.created_at, datetime) else obj.created_at,
                obj.updated_at.isoformat() if isinstance(obj.updated_at, datetime) else obj.updated_at,
                _to_json(obj),
            )
        )
        self._conn.commit()
        self._update_manifest_count()

    def get_object(self, obj_id: str) -> Optional[KMFObject]:
        row = self._conn.execute(
            "SELECT data FROM objects WHERE id = ?", (obj_id,)
        ).fetchone()
        if row is None:
            return None
        return _from_json_obj(json.loads(row["data"]))

    def list_objects(
        self,
        type: Optional[ObjectType] = None,
        status: ObjectStatus = ObjectStatus.ACTIVE,
        scopes: Optional[list[str]] = None,
        min_confidence: float = 0.0,
        min_importance: float = 0.0,
    ) -> list[KMFObject]:
        q = "SELECT data FROM objects WHERE status = ?"
        params: list = [status.value if hasattr(status, "value") else status]

        if type:
            q += " AND type = ?"
            params.append(type.value if hasattr(type, "value") else type)
        if min_confidence > 0:
            q += " AND confidence >= ?"
            params.append(min_confidence)
        if min_importance > 0:
            q += " AND importance >= ?"
            params.append(min_importance)

        rows = self._conn.execute(q, params).fetchall()
        objects = [_from_json_obj(json.loads(r["data"])) for r in rows]

        if scopes:
            filtered = []
            for o in objects:
                obj_scopes = o.scope if isinstance(o.scope, list) else [o.scope]
                if any(s in obj_scopes for s in scopes):
                    filtered.append(o)
            return filtered
        return objects

    def archive_object(self, obj_id: str) -> bool:
        obj = self.get_object(obj_id)
        if obj is None:
            return False
        obj.archive()
        self.put_object(obj)
        return True

    def delete_object(self, obj_id: str) -> bool:
        obj = self.get_object(obj_id)
        if obj is None:
            return False
        obj.status = ObjectStatus.DELETED
        obj.touch()
        self.put_object(obj)
        return True

    # ── Chunks ────────────────────────────────

    def put_chunk(self, chunk: Chunk) -> None:
        self._conn.execute(
            """INSERT OR REPLACE INTO chunks
               (chunk_id, parent_object_id, chunk_type, token_count_est,
                importance, confidence, freshness_score, prompt_priority,
                topic_tags, text, data)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                chunk.chunk_id,
                chunk.parent_object_id,
                chunk.chunk_type,
                chunk.token_count_est,
                chunk.importance,
                chunk.confidence,
                chunk.freshness_score,
                chunk.prompt_priority,
                json.dumps(chunk.topic_tags),
                chunk.text,
                _to_json(chunk),
            )
        )
        self._conn.commit()

    def get_chunks(
        self,
        chunk_type: Optional[str] = None,
        min_prompt_priority: float = 0.0,
        limit: int = 100,
    ) -> list[Chunk]:
        q = "SELECT data FROM chunks WHERE prompt_priority >= ?"
        params: list = [min_prompt_priority]
        if chunk_type:
            q += " AND chunk_type = ?"
            params.append(chunk_type)
        q += " ORDER BY prompt_priority DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(q, params).fetchall()
        return [_from_json_chunk(json.loads(r["data"])) for r in rows]

    def search_chunks_by_tags(self, tags: list[str], limit: int = 20) -> list[Chunk]:
        """Simple tag-based search (no embeddings needed for v0.1)."""
        rows = self._conn.execute(
            "SELECT data, topic_tags FROM chunks ORDER BY prompt_priority DESC"
        ).fetchall()
        results = []
        for row in rows:
            obj_tags = json.loads(row["topic_tags"] or "[]")
            if any(t.lower() in [ot.lower() for ot in obj_tags] for t in tags):
                results.append(_from_json_chunk(json.loads(row["data"])))
        return results[:limit]

    def search_chunks_text(self, query: str, limit: int = 20) -> list[Chunk]:
        """Simple keyword search across chunk text."""
        keywords = query.lower().split()
        rows = self._conn.execute(
            "SELECT data, text FROM chunks ORDER BY prompt_priority DESC"
        ).fetchall()
        scored = []
        for row in rows:
            text_lower = (row["text"] or "").lower()
            score = sum(1 for kw in keywords if kw in text_lower)
            if score > 0:
                chunk = _from_json_chunk(json.loads(row["data"]))
                scored.append((score, chunk))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [c for _, c in scored[:limit]]

    # ── Commits ───────────────────────────────

    def put_commit(self, commit: Commit) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO commits (commit_id, timestamp, data) VALUES (?,?,?)",
            (
                commit.commit_id,
                commit.timestamp.isoformat() if isinstance(commit.timestamp, datetime) else commit.timestamp,
                _to_json(commit),
            )
        )
        self._conn.commit()
        self.manifest.last_commit = commit.commit_id
        self.manifest.updated_at = datetime.utcnow()

    def list_commits(self) -> list[Commit]:
        rows = self._conn.execute(
            "SELECT data FROM commits ORDER BY timestamp DESC"
        ).fetchall()
        return [_from_json_commit(json.loads(r["data"])) for r in rows]

    # ── Manifest ──────────────────────────────

    def _update_manifest_count(self):
        count = self._conn.execute(
            "SELECT COUNT(*) FROM objects WHERE status = 'active'"
        ).fetchone()[0]
        self.manifest.object_count = count

    # ── Import / Export ───────────────────────

    def export_kmf(self, path: str | Path) -> Path:
        """Export repository to a .kmf file (ZIP archive)."""
        path = Path(path)
        if not path.suffix:
            path = path.with_suffix(".kmf")

        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            # Manifest
            zf.writestr("manifest.json", _to_json(self.manifest))

            # Objects by type
            for obj_type in ObjectType:
                objects = self.list_objects(
                    type=obj_type,
                    status=ObjectStatus.ACTIVE,
                )
                archived = self.list_objects(
                    type=obj_type,
                    status=ObjectStatus.ARCHIVED,
                )
                all_objs = objects + archived
                if all_objs:
                    folder = f"objects/{obj_type.value}s/"
                    zf.writestr(
                        folder + f"{obj_type.value}s.json",
                        json.dumps(
                            [json.loads(_to_json(o)) for o in all_objs],
                            ensure_ascii=False,
                            indent=2,
                        )
                    )

            # Chunks
            chunks = self.get_chunks(limit=10000)
            if chunks:
                chunk_index = "\n".join(
                    json.dumps(json.loads(_to_json(c)), ensure_ascii=False)
                    for c in chunks
                )
                zf.writestr("chunks/chunk_index.jsonl", chunk_index)

            # Commits
            commits = self.list_commits()
            if commits:
                commit_log = "\n".join(
                    json.dumps(json.loads(_to_json(c)), ensure_ascii=False)
                    for c in commits
                )
                zf.writestr("history/commits.jsonl", commit_log)

        return path

    @classmethod
    def from_kmf(cls, path: str | Path, db_path: str = ":memory:") -> "Repository":
        """
        Load a repository from a .kmf file.
        Automatically migrates older schema versions to current.
        """
        from ..security import safe_zip_namelist
        from ..migration import migrate, needs_migration, CURRENT_VERSION
        import logging
        _log = logging.getLogger("kmf.storage")

        path = Path(path)
        with zipfile.ZipFile(path, "r") as zf:
            valid_names = set(safe_zip_namelist(zf))

            if "manifest.json" not in valid_names:
                raise ValueError("Invalid .kmf file: missing manifest.json")

            manifest_data = json.loads(zf.read("manifest.json"))

            # Collect all objects for migration
            all_object_dicts: list[dict] = []
            for name in valid_names:
                if name.startswith("objects/") and name.endswith(".json"):
                    objects_data = json.loads(zf.read(name))
                    if isinstance(objects_data, list):
                        all_object_dicts.extend(
                            od for od in objects_data if isinstance(od, dict)
                        )

            # Run migrations if needed
            file_version = manifest_data.get("kmf_version", "0.1")
            if needs_migration(file_version):
                _log.info(f"Migrating .kmf file from {file_version} → {CURRENT_VERSION}")
                manifest_data, all_object_dicts, applied = migrate(manifest_data, all_object_dicts)
                if applied:
                    _log.info(f"Applied migrations: {' → '.join(applied)}")

            manifest = Manifest.model_validate(manifest_data)
            repo = cls(manifest=manifest, db_path=db_path)

            for od in all_object_dicts:
                repo.put_object(_from_json_obj(od))

            # Load chunks
            if "chunks/chunk_index.jsonl" in valid_names:
                for line in zf.read("chunks/chunk_index.jsonl").decode("utf-8", errors="replace").splitlines():
                    if line.strip():
                        repo.put_chunk(_from_json_chunk(json.loads(line)))

            # Load commits
            if "history/commits.jsonl" in valid_names:
                for line in zf.read("history/commits.jsonl").decode("utf-8", errors="replace").splitlines():
                    if line.strip():
                        repo.put_commit(_from_json_commit(json.loads(line)))

        return repo

    @classmethod
    def create(
        cls,
        name: str = "personal",
        owner: str = "user_local",
        scopes: Optional[list[str]] = None,
        description: str = "",
        db_path: str = ":memory:",
    ) -> "Repository":
        manifest = Manifest(
            name=name,
            owner=owner,
            scopes=scopes or ["personal"],
            description=description,
        )
        return cls(manifest=manifest, db_path=db_path)

    def stats(self) -> dict:
        counts = {}
        for obj_type in ObjectType:
            n = self._conn.execute(
                "SELECT COUNT(*) FROM objects WHERE type = ? AND status = 'active'",
                (obj_type.value,)
            ).fetchone()[0]
            if n > 0:
                counts[obj_type.value] = n
        n_chunks = self._conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        n_commits = self._conn.execute("SELECT COUNT(*) FROM commits").fetchone()[0]
        return {
            "name": self.manifest.name,
            "repository_id": self.manifest.repository_id,
            "object_counts": counts,
            "total_active": self.manifest.object_count,
            "chunks": n_chunks,
            "commits": n_commits,
            "last_commit": self.manifest.last_commit,
            "updated_at": self.manifest.updated_at.isoformat()
                if isinstance(self.manifest.updated_at, datetime)
                else str(self.manifest.updated_at),
        }
