"""
Tests for Schema Migration, Merge Protocol, and LangChain Integration.
Run with: pytest tests/test_v1.py -v
"""
import pytest
from kmf.api import KMF
from kmf.consolidation.engine import SessionInput
from kmf.migration import migrate, needs_migration, get_pending_migrations, CURRENT_VERSION
from kmf.sync.merge import merge, MergeResult


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

def _make_kmf_with_facts(facts: list[dict], name="test") -> KMF:
    k = KMF.create(name)
    k.consolidate(SessionInput(
        title="Test",
        proposed_facts=[{**f, "writer": "explicit_user_statement"} for f in facts],
    ))
    return k


# ──────────────────────────────────────────────
# Schema Migration
# ──────────────────────────────────────────────

class TestSchemaMigration:
    def test_current_version_needs_no_migration(self):
        assert not needs_migration(CURRENT_VERSION)

    def test_old_version_needs_migration(self):
        assert needs_migration("0.1")
        assert needs_migration("0.2")

    def test_unknown_version_needs_migration(self):
        assert needs_migration("0.0")

    def test_pending_migrations_from_01(self):
        pending = get_pending_migrations("0.1")
        assert "0.2" in pending
        assert "1.0" in pending
        assert pending.index("0.2") < pending.index("1.0")

    def test_pending_migrations_from_02(self):
        pending = get_pending_migrations("0.2")
        assert "0.2" not in pending
        assert "1.0" in pending

    def test_no_pending_from_current(self):
        pending = get_pending_migrations(CURRENT_VERSION)
        assert pending == []

    def test_migrate_01_normalizes_sensitivity(self):
        manifest = {"kmf_version": "0.1", "name": "test"}
        objects = [
            {"id": "obj_1", "type": "fact", "sensitivity": "INVALID",
             "scope": "personal", "confidence": 0.9, "importance": 0.8,
             "content": {}, "provenance": {"writer": "explicit_user_statement", "method": "post_session_consolidation"},
             "permissions": {"prompt_use": "always"}, "status": "active",
             "created_at": "2024-01-01T00:00:00", "updated_at": "2024-01-01T00:00:00"},
        ]
        manifest_out, objects_out, applied = migrate(manifest, objects)
        assert objects_out[0]["sensitivity"] == "internal"
        assert "0.2" in applied

    def test_migrate_01_normalizes_scope_string_to_list(self):
        manifest = {"kmf_version": "0.1", "name": "test"}
        objects = [
            {"id": "obj_2", "type": "fact", "sensitivity": "internal",
             "scope": "personal",  # string, should become list
             "confidence": 0.9, "importance": 0.8, "content": {},
             "provenance": {"writer": "explicit_user_statement", "method": "post_session_consolidation"},
             "permissions": {"prompt_use": "always"}, "status": "active",
             "created_at": "2024-01-01T00:00:00", "updated_at": "2024-01-01T00:00:00"},
        ]
        _, objects_out, _ = migrate(manifest, objects)
        assert isinstance(objects_out[0]["scope"], list)
        assert "personal" in objects_out[0]["scope"]

    def test_migrate_02_adds_valid_time(self):
        manifest = {"kmf_version": "0.2", "name": "test"}
        objects = [
            {"id": "obj_3", "type": "fact", "sensitivity": "internal",
             "scope": ["personal"], "confidence": 0.9, "importance": 0.8,
             "content": {}, "provenance": {"writer": "explicit_user_statement", "method": "post_session_consolidation"},
             "permissions": {"prompt_use": "always"}, "status": "active",
             "created_at": "2024-01-01T00:00:00", "updated_at": "2024-01-01T00:00:00"},
        ]
        _, objects_out, applied = migrate(manifest, objects)
        assert "valid_time" in objects_out[0]
        assert "1.0" in applied

    def test_migrate_clamps_confidence(self):
        manifest = {"kmf_version": "0.2", "name": "test"}
        objects = [
            {"id": "obj_4", "type": "fact", "sensitivity": "internal",
             "scope": ["personal"], "confidence": 1.5,  # over 1.0!
             "importance": -0.1,  # under 0.0!
             "content": {}, "valid_time": {},
             "provenance": {"writer": "explicit_user_statement", "method": "post_session_consolidation"},
             "permissions": {"prompt_use": "always"}, "status": "active",
             "created_at": "2024-01-01T00:00:00", "updated_at": "2024-01-01T00:00:00"},
        ]
        _, objects_out, _ = migrate(manifest, objects)
        assert objects_out[0]["confidence"] == 1.0
        assert objects_out[0]["importance"] == 0.0

    def test_full_migration_chain_01_to_10(self):
        manifest = {"kmf_version": "0.1", "name": "test"}
        objects = [
            {"id": "obj_5", "type": "fact", "sensitivity": "internal",
             "scope": "work",  # string scope
             "confidence": 0.9, "importance": 0.8, "content": {},
             "provenance": {"writer": "explicit_user_statement", "method": "post_session_consolidation"},
             "permissions": {"prompt_use": "always"}, "status": "active",
             "created_at": "2024-01-01T00:00:00", "updated_at": "2024-01-01T00:00:00"},
        ]
        manifest_out, objects_out, applied = migrate(manifest, objects)
        assert manifest_out["kmf_version"] == CURRENT_VERSION
        assert applied == ["0.2", "1.0"]
        assert isinstance(objects_out[0]["scope"], list)
        assert "valid_time" in objects_out[0]
        assert objects_out[0]["schema_version"] == "1.0"

    def test_save_and_load_preserves_version(self, tmp_path):
        k = KMF.create("versioned")
        k.consolidate(SessionInput(title="Test", proposed_facts=[{
            "subject": "x", "predicate": "y", "object": "z",
            "confidence": 0.9, "writer": "explicit_user_statement"
        }]))
        path = tmp_path / "versioned.kmf"
        k.save(path)
        loaded = KMF.load(path)
        assert loaded.version == CURRENT_VERSION


# ──────────────────────────────────────────────
# Merge Protocol
# ──────────────────────────────────────────────

class TestMerge:
    def test_merge_adds_new_objects(self):
        base = _make_kmf_with_facts([
            {"subject": "db", "predicate": "type", "object": "PostgreSQL", "confidence": 0.9}
        ], "base")
        incoming = _make_kmf_with_facts([
            {"subject": "api", "predicate": "framework", "object": "FastAPI", "confidence": 0.9}
        ], "incoming")
        result = base.merge(incoming)
        assert len(result.added) > 0
        all_subjects = [o.content.get("subject") for o in base.list()]
        assert "api" in all_subjects

    def test_merge_newer_wins(self):
        import time
        base = _make_kmf_with_facts([
            {"subject": "lang", "predicate": "primary", "object": "Python", "confidence": 0.9}
        ], "base-newer")
        time.sleep(0.01)  # ensure timestamp difference
        incoming = _make_kmf_with_facts([
            {"subject": "lang", "predicate": "primary", "object": "Python", "confidence": 0.95}
        ], "inc-newer")
        result = base.merge(incoming)
        # No conflict — same value, different confidence
        assert len(result.conflicts_created) == 0

    def test_merge_detects_fact_conflict(self):
        base = _make_kmf_with_facts([
            {"subject": "db", "predicate": "type", "object": "PostgreSQL", "confidence": 0.9}
        ], "base-conflict")
        incoming = _make_kmf_with_facts([
            {"subject": "db", "predicate": "type", "object": "MongoDB", "confidence": 0.9}
        ], "inc-conflict")
        result = base.merge(incoming)
        assert len(result.conflicts_created) == 1
        c = result.conflicts_created[0]
        assert "PostgreSQL" in c.content["reason"] or "MongoDB" in c.content["reason"]

    def test_merge_no_duplicate_conflicts(self):
        """Merging same repos twice should not create duplicate conflicts."""
        base = _make_kmf_with_facts([
            {"subject": "x", "predicate": "y", "object": "A", "confidence": 0.9}
        ], "base-dedup")
        incoming = _make_kmf_with_facts([
            {"subject": "x", "predicate": "y", "object": "B", "confidence": 0.9}
        ], "inc-dedup")
        base.merge(incoming)
        result2 = base.merge(incoming)
        # Second merge should not create another conflict for the same pair
        assert len(result2.conflicts_created) == 0

    def test_merge_scope_filter(self):
        base = KMF.create("base-scope")
        incoming = KMF.create("inc-scope")
        # Add personal object to incoming
        from kmf.models.base import KMFObject, ObjectType, Provenance, ProvenanceWriter, ProvenanceMethod
        personal_obj = KMFObject(
            type=ObjectType.FACT,
            scope=["personal"],
            confidence=0.9, importance=0.8,
            provenance=Provenance(writer=ProvenanceWriter.EXPLICIT_USER, method=ProvenanceMethod.POST_CONSOLIDATION),
            content={"subject": "user", "predicate": "name", "object": "Alice"},
        )
        work_obj = KMFObject(
            type=ObjectType.FACT,
            scope=["work"],
            confidence=0.9, importance=0.8,
            provenance=Provenance(writer=ProvenanceWriter.EXPLICIT_USER, method=ProvenanceMethod.POST_CONSOLIDATION),
            content={"subject": "company", "predicate": "name", "object": "Acme"},
        )
        incoming.put(personal_obj)
        incoming.put(work_obj)
        # Merge only work scope
        result = base.merge(incoming, scopes=["work"])
        subjects = [o.content.get("subject") for o in base.list()]
        assert "company" in subjects
        assert "user" not in subjects

    def test_merge_summary_output(self):
        base = _make_kmf_with_facts([], "base-summary")
        incoming = _make_kmf_with_facts([
            {"subject": "a", "predicate": "b", "object": "c", "confidence": 0.9}
        ], "inc-summary")
        result = base.merge(incoming)
        summary = result.summary()
        assert "Added" in summary
        assert "Merge Summary" in summary

    def test_merge_preserves_commit_history(self):
        base = _make_kmf_with_facts([
            {"subject": "x", "predicate": "y", "object": "1", "confidence": 0.9}
        ], "base-hist")
        incoming = _make_kmf_with_facts([
            {"subject": "a", "predicate": "b", "object": "2", "confidence": 0.9}
        ], "inc-hist")
        base_commits_before = len(base.history())
        base.merge(incoming)
        # Should have commits from both repos
        assert len(base.history()) >= base_commits_before

    def test_save_load_after_merge(self, tmp_path):
        base = _make_kmf_with_facts([
            {"subject": "db", "predicate": "type", "object": "SQLite", "confidence": 0.9}
        ], "base-sl")
        incoming = _make_kmf_with_facts([
            {"subject": "lang", "predicate": "primary", "object": "Python", "confidence": 0.9}
        ], "inc-sl")
        base.merge(incoming)
        path = tmp_path / "merged.kmf"
        base.save(path)
        loaded = KMF.load(path)
        subjects = [o.content.get("subject") for o in loaded.list()]
        assert "db" in subjects
        assert "lang" in subjects


# ──────────────────────────────────────────────
# LangChain Integration
# ──────────────────────────────────────────────

class TestLangChainIntegration:
    def test_import_without_langchain_raises(self):
        """If langchain-core not installed, should raise ImportError."""
        import unittest.mock as mock
        import sys
        # Temporarily remove langchain_core from sys.modules
        original = sys.modules.get("langchain_core")
        sys.modules["langchain_core"] = None  # type: ignore
        try:
            from kmf.integrations.langchain import KMFMemory, _require_langchain
            with pytest.raises((ImportError, TypeError)):
                _require_langchain()
        finally:
            if original is None:
                sys.modules.pop("langchain_core", None)
            else:
                sys.modules["langchain_core"] = original

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_memory_load_variables(self):
        from kmf.integrations.langchain import KMFMemory
        k = _make_kmf_with_facts([
            {"subject": "user", "predicate": "prefers", "object": "Python", "confidence": 0.9}
        ], "lc-mem")
        memory = KMFMemory(kmf=k)
        vars_ = memory.load_memory_variables({"input": "Python preference"})
        assert "history" in vars_
        assert "[MEMORY CONTEXT" in vars_["history"]

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_memory_variables_property(self):
        from kmf.integrations.langchain import KMFMemory
        k = KMF.create("lc-mv")
        memory = KMFMemory(kmf=k, memory_key="context")
        assert memory.memory_variables == ["context"]

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_retriever_get_documents(self):
        from kmf.integrations.langchain import KMFRetriever
        k = _make_kmf_with_facts([
            {"subject": "db", "predicate": "type", "object": "PostgreSQL", "confidence": 0.9},
            {"subject": "api", "predicate": "framework", "object": "FastAPI", "confidence": 0.9},
        ], "lc-ret")
        retriever = KMFRetriever(kmf=k)
        docs = retriever.get_relevant_documents("database")
        assert isinstance(docs, list)
        assert len(docs) > 0
        # Each doc should have page_content and metadata
        for doc in docs:
            assert hasattr(doc, "page_content")
            assert hasattr(doc, "metadata")
            assert "kmf_type" in doc.metadata

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_retriever_metadata(self):
        from kmf.integrations.langchain import KMFRetriever
        k = _make_kmf_with_facts([
            {"subject": "user", "predicate": "name", "object": "Alice", "confidence": 0.95}
        ], "lc-meta")
        retriever = KMFRetriever(kmf=k)
        docs = retriever.get_relevant_documents("user name")
        assert any(d.metadata.get("kmf_type") == "fact" for d in docs)

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_memory_save_context_no_api_key(self):
        """save_context should not raise even without api_key."""
        from kmf.integrations.langchain import KMFMemory
        k = KMF.create("lc-save")
        memory = KMFMemory(kmf=k, auto_ingest=True, api_key=None)
        # Should not raise — just skip ingest silently
        memory.save_context(
            {"input": "Hello"},
            {"response": "Hi there"},
        )

    @pytest.mark.skipif(
        not _langchain_available(),
        reason="langchain-core not installed"
    )
    def test_memory_clear(self):
        from kmf.integrations.langchain import KMFMemory
        k = KMF.create("lc-clear")
        memory = KMFMemory(kmf=k)
        memory._pending_messages = [{"human": "test", "ai": "test"}]
        memory.clear()
        assert memory._pending_messages == []


def _langchain_available() -> bool:
    try:
        import langchain_core  # noqa: F401
        return True
    except ImportError:
        return False
