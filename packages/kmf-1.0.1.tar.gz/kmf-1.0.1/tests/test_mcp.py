"""
Tests for KMF MCP server.
Run with: pytest tests/test_mcp.py -v
"""
import json
import pytest
from kmf.api import KMF
from kmf.mcp.server import MCPServer, TOOLS, HANDLERS
from kmf.consolidation.engine import SessionInput


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

@pytest.fixture
def kmf_with_data():
    k = KMF.create("test-mcp")
    k.consolidate(SessionInput(
        title="Architecture session",
        summary_short="Decided on local-first",
        proposed_facts=[{
            "subject": "project",
            "predicate": "architecture",
            "object": "local-first",
            "confidence": 0.95,
            "writer": "explicit_user_statement",
        }],
        proposed_preferences=[{
            "domain": "language",
            "key": "code_language",
            "value": "Python",
            "strength": "strong",
            "writer": "explicit_user_statement",
        }],
        proposed_decisions=[{
            "title": "Use SQLite",
            "decision": "SQLite for local storage",
            "rationale": ["Simple", "No server needed"],
            "confidence": 0.9,
            "writer": "explicit_user_statement",
        }],
    ))
    return k


@pytest.fixture
def server(tmp_path):
    s = MCPServer(repo_path=str(tmp_path / "test.kmf"))
    return s


# ──────────────────────────────────────────────
# Tool schema
# ──────────────────────────────────────────────

class TestToolSchema:
    def test_all_tools_have_required_fields(self):
        for tool in TOOLS:
            assert "name" in tool
            assert "description" in tool
            assert "inputSchema" in tool
            assert tool["inputSchema"]["type"] == "object"

    def test_all_handlers_exist(self):
        tool_names = {t["name"] for t in TOOLS}
        handler_names = set(HANDLERS.keys())
        assert tool_names == handler_names

    def test_tool_names_prefixed(self):
        for tool in TOOLS:
            assert tool["name"].startswith("kmf_"), \
                f"Tool '{tool['name']}' should be prefixed with 'kmf_'"

    def test_required_tools_present(self):
        names = {t["name"] for t in TOOLS}
        assert "kmf_recall" in names
        assert "kmf_remember" in names
        assert "kmf_forget" in names
        assert "kmf_stats" in names
        assert "kmf_ingest_text" in names
        assert "kmf_conflicts" in names


# ──────────────────────────────────────────────
# MCP protocol
# ──────────────────────────────────────────────

class TestMCPProtocol:
    def test_initialize(self, server):
        req = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        resp = server.handle(req)
        assert resp["id"] == 1
        assert "result" in resp
        assert resp["result"]["protocolVersion"] == "2024-11-05"
        assert "serverInfo" in resp["result"]

    def test_tools_list(self, server):
        req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        resp = server.handle(req)
        assert "result" in resp
        assert "tools" in resp["result"]
        assert len(resp["result"]["tools"]) == len(TOOLS)

    def test_unknown_method(self, server):
        req = {"jsonrpc": "2.0", "id": 3, "method": "unknown/method", "params": {}}
        resp = server.handle(req)
        assert "error" in resp
        assert resp["error"]["code"] == -32601

    def test_unknown_tool(self, server):
        req = {
            "jsonrpc": "2.0", "id": 4,
            "method": "tools/call",
            "params": {"name": "unknown_tool", "arguments": {}},
        }
        resp = server.handle(req)
        assert "error" in resp

    def test_notification_returns_none(self, server):
        # Notifications have no id — no response expected
        req = {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}
        resp = server.handle(req)
        assert resp is None

    def test_ping(self, server):
        req = {"jsonrpc": "2.0", "id": 5, "method": "ping", "params": {}}
        resp = server.handle(req)
        assert resp["result"] == {}


# ──────────────────────────────────────────────
# Tool: kmf_recall
# ──────────────────────────────────────────────

class TestRecallTool:
    def test_recall_returns_memory_context(self, kmf_with_data):
        result = HANDLERS["kmf_recall"](kmf_with_data, {"query": "architecture"})
        assert "[MEMORY CONTEXT" in result
        assert "[/MEMORY CONTEXT]" in result

    def test_recall_empty_query(self, kmf_with_data):
        result = HANDLERS["kmf_recall"](kmf_with_data, {"query": ""})
        assert "Error" in result

    def test_recall_budget_respected(self, kmf_with_data):
        result = HANDLERS["kmf_recall"](kmf_with_data, {
            "query": "anything",
            "budget_tokens": 100,
        })
        # Should still return something, just small
        assert "[MEMORY CONTEXT" in result

    def test_recall_default_budget(self, kmf_with_data):
        result = HANDLERS["kmf_recall"](kmf_with_data, {"query": "Python"})
        assert "Python" in result or "language" in result or "[MEMORY CONTEXT" in result


# ──────────────────────────────────────────────
# Tool: kmf_remember
# ──────────────────────────────────────────────

class TestRememberTool:
    def test_remember_fact(self, kmf_with_data):
        result = HANDLERS["kmf_remember"](kmf_with_data, {
            "type": "fact",
            "content": {
                "subject": "user",
                "predicate": "works_at",
                "object": "Acme Corp",
            },
            "confidence": 0.95,
        })
        assert "✓" in result
        assert "fact" in result

    def test_remember_preference(self, kmf_with_data):
        result = HANDLERS["kmf_remember"](kmf_with_data, {
            "type": "preference",
            "content": {
                "domain": "ui",
                "key": "theme",
                "value": "dark",
                "strength": "strong",
            },
        })
        assert "✓" in result

    def test_remember_decision(self, kmf_with_data):
        result = HANDLERS["kmf_remember"](kmf_with_data, {
            "type": "decision",
            "content": {
                "title": "Use pytest",
                "decision": "pytest for all tests",
                "rationale": ["Familiar", "Good fixtures"],
            },
        })
        assert "✓" in result

    def test_remember_invalid_type(self, kmf_with_data):
        result = HANDLERS["kmf_remember"](kmf_with_data, {
            "type": "invalid_type",
            "content": {},
        })
        assert "Error" in result

    def test_remember_missing_fields(self, kmf_with_data):
        result = HANDLERS["kmf_remember"](kmf_with_data, {
            "type": "fact",
            "content": {"subject": "only_subject"},  # missing predicate + object
        })
        assert "Error" in result
        assert "missing" in result.lower()


# ──────────────────────────────────────────────
# Tool: kmf_forget
# ──────────────────────────────────────────────

class TestForgetTool:
    def test_forget_existing_object(self, kmf_with_data):
        objects = kmf_with_data.list()
        assert len(objects) > 0
        obj = objects[0]
        result = HANDLERS["kmf_forget"](kmf_with_data, {
            "object_id": obj.id,
            "reason": "outdated",
        })
        assert "✓" in result
        assert "Archived" in result

    def test_forget_nonexistent(self, kmf_with_data):
        result = HANDLERS["kmf_forget"](kmf_with_data, {
            "object_id": "obj_NOTEXIST123456789",
        })
        assert "Error" in result

    def test_forget_invalid_id(self, kmf_with_data):
        result = HANDLERS["kmf_forget"](kmf_with_data, {
            "object_id": "'; DROP TABLE objects;--",
        })
        assert "Error" in result

    def test_forget_actually_archives(self, kmf_with_data):
        objects = kmf_with_data.list()
        obj_id = objects[0].id
        HANDLERS["kmf_forget"](kmf_with_data, {"object_id": obj_id})
        # Object should no longer appear in active list
        active = kmf_with_data.list()
        assert not any(o.id == obj_id for o in active)


# ──────────────────────────────────────────────
# Tool: kmf_stats
# ──────────────────────────────────────────────

class TestStatsTool:
    def test_stats_returns_info(self, kmf_with_data):
        result = HANDLERS["kmf_stats"](kmf_with_data, {})
        assert "Repository" in result
        assert "objects" in result.lower()

    def test_stats_empty_repo(self):
        k = KMF.create("empty")
        result = HANDLERS["kmf_stats"](k, {})
        assert "0" in result or "Repository" in result


# ──────────────────────────────────────────────
# Tool: kmf_conflicts
# ──────────────────────────────────────────────

class TestConflictsTool:
    def test_no_conflicts(self, kmf_with_data):
        result = HANDLERS["kmf_conflicts"](kmf_with_data, {})
        assert "No unresolved conflicts" in result

    def test_detects_conflict(self):
        k = KMF.create("conflict-test")
        k.consolidate(SessionInput(
            title="S1",
            proposed_facts=[{"subject": "db", "predicate": "type", "object": "PostgreSQL",
                             "confidence": 0.9, "writer": "explicit_user_statement"}]
        ))
        k.consolidate(SessionInput(
            title="S2",
            proposed_facts=[{"subject": "db", "predicate": "type", "object": "SQLite",
                             "confidence": 0.9, "writer": "explicit_user_statement"}]
        ))
        result = HANDLERS["kmf_conflicts"](k, {})
        assert "conflict" in result.lower()
        assert "unresolved" in result.lower()


# ──────────────────────────────────────────────
# Full MCP round-trip via server.handle()
# ──────────────────────────────────────────────

class TestMCPRoundTrip:
    def test_recall_via_mcp(self, server):
        # Pre-populate
        server._kmf = KMF.create("rt-test")
        server._kmf.consolidate(SessionInput(
            title="Test",
            proposed_facts=[{"subject": "user", "predicate": "likes", "object": "Python",
                             "confidence": 0.9, "writer": "explicit_user_statement"}]
        ))
        req = {
            "jsonrpc": "2.0", "id": 10,
            "method": "tools/call",
            "params": {"name": "kmf_recall", "arguments": {"query": "Python"}},
        }
        resp = server.handle(req)
        assert resp["id"] == 10
        assert "result" in resp
        content = resp["result"]["content"]
        assert len(content) > 0
        assert "[MEMORY CONTEXT" in content[0]["text"]

    def test_remember_then_recall(self, server):
        server._kmf = KMF.create("rt2-test")
        # Remember something
        server.handle({
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {
                "name": "kmf_remember",
                "arguments": {
                    "type": "fact",
                    "content": {"subject": "user", "predicate": "name", "object": "Alice"},
                },
            },
        })
        # Recall it
        resp = server.handle({
            "jsonrpc": "2.0", "id": 2,
            "method": "tools/call",
            "params": {"name": "kmf_recall", "arguments": {"query": "user name"}},
        })
        text = resp["result"]["content"][0]["text"]
        assert "Alice" in text

    def test_tool_error_returns_isError(self, server):
        server._kmf = KMF.create("err-test")
        resp = server.handle({
            "jsonrpc": "2.0", "id": 99,
            "method": "tools/call",
            "params": {"name": "kmf_forget", "arguments": {"object_id": "nonexistent_id_xyz"}},
        })
        assert resp["result"]["isError"] is True
