"""
Tests for KMF semantic search (embeddings + recall pipeline).
Run with: pytest tests/test_embeddings.py -v

Tests work in two modes:
  - WITH sentence-transformers installed: full semantic tests
  - WITHOUT: tests verify graceful fallback to keyword search
"""
import pytest
from kmf.api import KMF
from kmf.consolidation.engine import SessionInput
from kmf.recall.embeddings import (
    embeddings_available,
    object_to_embed_text,
    EmbeddingEngine,
    EmbeddingIndexer,
    VectorStore,
    _text_hash,
)
from kmf.recall.pipeline import RecallPipeline, score_object
from kmf.models.base import KMFObject, ObjectType, Provenance, ProvenanceWriter, ProvenanceMethod
from kmf.storage.repository import Repository


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

@pytest.fixture
def repo():
    return Repository.create("test-emb")

@pytest.fixture
def kmf_with_data():
    k = KMF.create("emb-test")
    k.consolidate(SessionInput(
        title="Python session",
        summary_short="User prefers Python",
        proposed_facts=[
            {"subject": "user", "predicate": "prefers", "object": "Python",
             "confidence": 0.95, "writer": "explicit_user_statement"},
            {"subject": "database", "predicate": "type", "object": "PostgreSQL",
             "confidence": 0.9, "writer": "explicit_user_statement"},
        ],
        proposed_preferences=[
            {"domain": "editor", "key": "ide", "value": "VS Code",
             "strength": "moderate", "writer": "explicit_user_statement"},
        ],
        proposed_decisions=[
            {"title": "Use FastAPI", "decision": "FastAPI for REST endpoints",
             "rationale": ["Fast", "Type hints"], "confidence": 0.9,
             "writer": "explicit_user_statement"},
        ],
    ))
    k.consolidate(SessionInput(
        title="Architecture session",
        summary_short="Local-first architecture decided",
        proposed_decisions=[
            {"title": "Local-first", "decision": "Data lives on user device",
             "rationale": ["Privacy", "Offline support"], "confidence": 0.95,
             "writer": "explicit_user_statement"},
        ],
    ))
    return k


# ──────────────────────────────────────────────
# object_to_embed_text
# ──────────────────────────────────────────────

class TestObjectToEmbedText:
    def _make_obj(self, obj_type, content):
        return KMFObject(
            type=obj_type,
            content=content,
            provenance=Provenance(
                writer=ProvenanceWriter.EXPLICIT_USER,
                method=ProvenanceMethod.POST_CONSOLIDATION,
            ),
        )

    def test_fact_text(self):
        obj = self._make_obj(ObjectType.FACT, {
            "subject": "user", "predicate": "prefers", "object": "Python"
        })
        text = object_to_embed_text(obj)
        assert "Python" in text
        assert "user" in text

    def test_fact_uses_natural_text_if_present(self):
        obj = self._make_obj(ObjectType.FACT, {
            "subject": "x", "predicate": "y", "object": "z",
            "natural_text": "The user loves Python programming",
        })
        text = object_to_embed_text(obj)
        assert "loves Python" in text

    def test_preference_text(self):
        obj = self._make_obj(ObjectType.PREFERENCE, {
            "domain": "editor", "key": "ide", "value": "VS Code"
        })
        text = object_to_embed_text(obj)
        assert "VS Code" in text
        assert "editor" in text

    def test_decision_text(self):
        obj = self._make_obj(ObjectType.DECISION, {
            "title": "Use FastAPI",
            "decision": "FastAPI for all endpoints",
            "rationale": ["Fast", "Type hints"],
        })
        text = object_to_embed_text(obj)
        assert "FastAPI" in text
        assert "Fast" in text

    def test_episode_text(self):
        obj = self._make_obj(ObjectType.EPISODE, {
            "title": "Architecture discussion",
            "summary_short": "Decided on microservices",
            "topics": ["architecture", "services"],
        })
        text = object_to_embed_text(obj)
        assert "microservices" in text
        assert "architecture" in text

    def test_empty_content_no_crash(self):
        obj = self._make_obj(ObjectType.FACT, {})
        text = object_to_embed_text(obj)
        assert isinstance(text, str)


# ──────────────────────────────────────────────
# VectorStore
# ──────────────────────────────────────────────

class TestVectorStore:
    def test_put_and_get(self, repo):
        store = VectorStore(repo._conn)
        vec = [0.1, 0.2, 0.3]
        store.put("obj_001", vec, "hash123")
        result = store.get("obj_001")
        assert result == pytest.approx(vec)

    def test_get_missing_returns_none(self, repo):
        store = VectorStore(repo._conn)
        result = store.get("does_not_exist")
        assert result is None

    def test_get_all(self, repo):
        store = VectorStore(repo._conn)
        store.put("a", [1.0, 0.0], "h1")
        store.put("b", [0.0, 1.0], "h2")
        all_vecs = store.get_all()
        assert "a" in all_vecs
        assert "b" in all_vecs
        assert len(all_vecs) == 2

    def test_overwrite(self, repo):
        store = VectorStore(repo._conn)
        store.put("obj_001", [1.0, 0.0], "old")
        store.put("obj_001", [0.0, 1.0], "new")
        result = store.get("obj_001")
        assert result == pytest.approx([0.0, 1.0])

    def test_count(self, repo):
        store = VectorStore(repo._conn)
        assert store.count() == 0
        store.put("a", [1.0], "h1")
        store.put("b", [2.0], "h2")
        assert store.count() == 2

    def test_delete(self, repo):
        store = VectorStore(repo._conn)
        store.put("obj_del", [1.0], "hx")
        store.delete("obj_del")
        assert store.get("obj_del") is None

    def test_staleness_check(self, repo):
        store = VectorStore(repo._conn)
        store.put("obj_s", [1.0], "hash_v1")
        h = store.get_hash("obj_s")
        assert h == "hash_v1"

    def test_model_isolation(self, repo):
        """Different models should not share embeddings."""
        store_a = VectorStore(repo._conn, model_name="model-a")
        store_b = VectorStore(repo._conn, model_name="model-b")
        store_a.put("obj_x", [1.0, 0.0], "h")
        assert store_b.get("obj_x") is None
        assert store_a.get("obj_x") is not None


# ──────────────────────────────────────────────
# EmbeddingEngine (mock-based — no model download needed)
# ──────────────────────────────────────────────

class MockEmbeddingEngine:
    """Deterministic fake embeddings for testing without model download."""
    model_name = "mock-model"

    def embed(self, text: str) -> list[float]:
        # Simple hash-based fake embedding (deterministic, 4-dim)
        h = hash(text) % 1000 / 1000.0
        import math
        return [math.cos(h), math.sin(h), math.cos(h * 2), math.sin(h * 2)]

    def embed_batch(self, texts: list[str], batch_size: int = 64) -> list[list[float]]:
        return [self.embed(t) for t in texts]

    def similarity(self, a: list[float], b: list[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = sum(x ** 2 for x in a) ** 0.5
        nb = sum(x ** 2 for x in b) ** 0.5
        if na == 0 or nb == 0:
            return 0.0
        return dot / (na * nb)


class TestEmbeddingIndexer:
    def test_index_all(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        stats = indexer.index_all()
        assert stats["indexed"] > 0
        assert stats["failed"] == 0

    def test_skip_already_indexed(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        stats1 = indexer.index_all()
        stats2 = indexer.index_all()  # second run — should skip all
        assert stats2["indexed"] == 0
        assert stats2["skipped"] == stats1["indexed"] + stats1["skipped"]

    def test_force_reindex(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        indexer.index_all()
        stats = indexer.index_all(force=True)
        assert stats["indexed"] > 0

    def test_semantic_scores_returns_dict(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        indexer.index_all()
        scores = indexer.semantic_scores("Python programming language")
        assert isinstance(scores, dict)
        assert len(scores) > 0
        for score in scores.values():
            assert 0.0 <= score <= 1.0 + 1e-6  # float tolerance

    def test_index_single_object(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        objects = kmf_with_data.list()
        result = indexer.index_object(objects[0])
        assert result is True


# ──────────────────────────────────────────────
# RecallPipeline with semantic scoring
# ──────────────────────────────────────────────

class TestSemanticRecall:
    def test_recall_with_mock_engine(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        pipeline = RecallPipeline(kmf_with_data._repo, embedding_engine=engine)
        result = pipeline.recall("Python programming preference")
        assert result.bundle is not None
        assert "[MEMORY CONTEXT" in result.bundle.rendered

    def test_used_semantic_flag(self, kmf_with_data):
        engine = MockEmbeddingEngine()
        # Pre-index so semantic_scores returns data
        from kmf.recall.embeddings import EmbeddingIndexer
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        indexer.index_all()

        pipeline = RecallPipeline(kmf_with_data._repo, embedding_engine=engine)
        # Patch _get_indexer to return our pre-built indexer
        pipeline._get_indexer = lambda: indexer
        result = pipeline.recall("Python")
        assert result.used_semantic is True

    def test_fallback_when_no_embeddings(self, kmf_with_data):
        """Pipeline should work fine with keyword fallback."""
        pipeline = RecallPipeline(kmf_with_data._repo, embedding_engine=None)
        # Force no semantic (simulate unavailable)
        result = pipeline.recall("Python", use_semantic=False)
        assert result.used_semantic is False
        assert result.bundle is not None
        assert "[MEMORY CONTEXT" in result.bundle.rendered

    def test_semantic_improves_relevance(self, kmf_with_data):
        """
        With semantic search, a conceptually related query should still
        surface relevant objects even without exact keyword overlap.
        """
        engine = MockEmbeddingEngine()
        indexer = EmbeddingIndexer(kmf_with_data._repo, engine)
        indexer.index_all()

        pipeline = RecallPipeline(kmf_with_data._repo, embedding_engine=engine)
        pipeline._get_indexer = lambda: indexer

        # "coding language choice" doesn't contain "Python" but is related
        result = pipeline.recall("coding language choice")
        rendered = result.bundle.rendered
        # Should find something meaningful (not empty)
        assert "[/MEMORY CONTEXT]" in rendered

    def test_score_object_with_semantic(self):
        obj = KMFObject(
            type=ObjectType.FACT,
            confidence=0.9,
            importance=0.8,
            content={"subject": "user", "predicate": "prefers", "object": "Python"},
            provenance=Provenance(
                writer=ProvenanceWriter.EXPLICIT_USER,
                method=ProvenanceMethod.POST_CONSOLIDATION,
            ),
        )
        # With high semantic score
        s_high = score_object(obj, [], [], semantic_score=0.95)
        # With low semantic score
        s_low = score_object(obj, [], [], semantic_score=0.1)
        assert s_high > s_low

    def test_score_object_keyword_fallback(self):
        obj = KMFObject(
            type=ObjectType.FACT,
            confidence=0.9,
            importance=0.8,
            content={"subject": "user", "predicate": "uses", "object": "Python"},
            provenance=Provenance(
                writer=ProvenanceWriter.EXPLICIT_USER,
                method=ProvenanceMethod.POST_CONSOLIDATION,
            ),
        )
        # No semantic score — uses keyword fallback
        s_match = score_object(obj, ["Python"], [], semantic_score=None)
        s_no_match = score_object(obj, ["Java"], [], semantic_score=None)
        assert s_match > s_no_match


# ──────────────────────────────────────────────
# Graceful degradation
# ──────────────────────────────────────────────

class TestGracefulDegradation:
    def test_recall_works_without_sentence_transformers(self, kmf_with_data):
        """Even without sentence-transformers, recall should work via keywords."""
        pipeline = RecallPipeline(kmf_with_data._repo)
        result = pipeline.recall("Python", use_semantic=False)
        assert result.bundle is not None
        assert not result.used_semantic

    def test_engine_import_error_caught(self, kmf_with_data):
        """If sentence-transformers raises ImportError, pipeline continues."""
        import unittest.mock as mock

        pipeline = RecallPipeline(kmf_with_data._repo)

        # Simulate ImportError from _get_indexer
        def raise_import_error():
            return None  # embeddings_available() returns False

        with mock.patch("kmf.recall.embeddings.embeddings_available", return_value=False):
            result = pipeline.recall("Python architecture decision")

        assert result.bundle is not None  # keyword fallback worked
