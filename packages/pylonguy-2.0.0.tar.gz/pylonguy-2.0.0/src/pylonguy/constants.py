"""Application-wide non-visual constants."""

# Camera sensor limits
MAX_OFFSET_X = 4096
MAX_OFFSET_Y = 3072
MIN_ROI_WIDTH = 16
MIN_ROI_HEIGHT = 16

# Timing intervals
CAMERA_APPLY_TIMEOUT = 0.05  # seconds
FPS_UPDATE_INTERVAL_MS = 200
FPS_RESET_INTERVAL = 5.0  # seconds
STATS_UPDATE_INTERVAL = 0.2  # seconds
SIGNAL_TIMER_INTERVAL_MS = 100

# Threading
WRITER_QUEUE_SIZE = 10000
WRITER_THREAD_TIMEOUT = 60  # seconds
QUEUE_GET_TIMEOUT = 0.1  # seconds
LIMIT_CHECK_INTERVAL = 100  # frames

# Slider configuration
OFFSET_SLIDER_STEP = 16
