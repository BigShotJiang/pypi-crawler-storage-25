"""Local HTTP server for CLI ← Browser communication.

Provides:
  - /callback  — OAuth-style login callback (browser redirects here with token)
  - /health    — Liveness check
  - /          — Future: local web UI entry point

Design: lightweight stdlib server, zero external dependencies.
The server runs in a background thread so the CLI main thread can
show progress / wait for the callback.
"""

import logging
import socket
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

logger = logging.getLogger(__name__)

# Default port range for the local server
DEFAULT_PORT_RANGE = (19280, 19290)

# Success page shown in browser after login callback
_SUCCESS_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>登录成功</title>
<style>
  body { font-family: system-ui, sans-serif; display: flex; justify-content: center;
         align-items: center; min-height: 100vh; margin: 0; background: #0a0a0a; color: #fafafa; }
  .card { text-align: center; padding: 48px; }
  .icon { font-size: 64px; margin-bottom: 16px; }
  h1 { font-size: 24px; font-weight: 600; margin: 0 0 8px; }
  p { color: #888; font-size: 14px; margin: 0; }
</style></head>
<body><div class="card">
  <div class="icon">✓</div>
  <h1>登录成功</h1>
  <p>已授权慧媒 CLI，可以关闭此页面</p>
</div></body></html>"""

_FAIL_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>登录失败</title>
<style>
  body { font-family: system-ui, sans-serif; display: flex; justify-content: center;
         align-items: center; min-height: 100vh; margin: 0; background: #0a0a0a; color: #fafafa; }
  .card { text-align: center; padding: 48px; }
  .icon { font-size: 64px; margin-bottom: 16px; }
  h1 { font-size: 24px; font-weight: 600; margin: 0 0 8px; }
  p { color: #888; font-size: 14px; margin: 0; }
</style></head>
<body><div class="card">
  <div class="icon">✗</div>
  <h1>登录失败</h1>
  <p>未收到有效凭证，请重试</p>
</div></body></html>"""


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the local CLI server."""

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/callback":
            self._handle_callback(parsed)
        elif parsed.path == "/health":
            self._respond(200, "ok")
        else:
            self._respond(404, "not found")

    def _handle_callback(self, parsed):
        params = parse_qs(parsed.query)
        token = params.get("token", [None])[0]

        if token:
            # Store token on the server instance for the caller to read
            self.server.received_token = token
            self._respond_html(200, _SUCCESS_HTML)
            logger.info("Login callback received token")
        else:
            self._respond_html(200, _FAIL_HTML)
            logger.warning("Login callback received no token")

    def _respond(self, code: int, body: str):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _respond_html(self, code: int, html: str):
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def log_message(self, format, *args):
        """Suppress default stderr logging."""
        logger.debug(format, *args)


def _find_free_port(start: int, end: int) -> int:
    """Find a free port in the given range."""
    for port in range(start, end + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return port
        except OSError:
            continue
    raise RuntimeError(f"No free port found in range {start}-{end}")


class CliLocalServer:
    """Manages the local HTTP server lifecycle.

    Usage:
        server = CliLocalServer()
        server.start()
        print(server.callback_url)  # http://127.0.0.1:19280/callback
        # ... open browser, wait for callback ...
        token = server.wait_for_token(timeout=300)
        server.stop()
    """

    def __init__(self, port_range: tuple[int, int] = DEFAULT_PORT_RANGE):
        self.port = _find_free_port(*port_range)
        self._httpd = HTTPServer(("127.0.0.1", self.port), _CallbackHandler)
        self._httpd.received_token = None
        self._thread = None

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def callback_url(self) -> str:
        return f"{self.base_url}/callback"

    def start(self):
        """Start the server in a background daemon thread."""
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            daemon=True,
        )
        self._thread.start()
        logger.info("CLI local server started on %s", self.base_url)

    def wait_for_token(self, timeout: float = 300) -> str | None:
        """Block until a token is received or timeout (seconds).

        Returns the token string, or None on timeout.
        """
        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._httpd.received_token:
                return self._httpd.received_token
            time.sleep(0.5)
        return None

    def stop(self):
        """Shutdown the server."""
        self._httpd.shutdown()
        if self._thread:
            self._thread.join(timeout=2)
        logger.info("CLI local server stopped")
