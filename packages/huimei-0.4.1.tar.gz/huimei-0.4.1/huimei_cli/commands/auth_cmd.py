"""Auth commands: login, logout, status."""

import typer
from rich.console import Console
from rich.table import Table

from huimei_cli.auth import (
    do_login, do_browser_login, is_logged_in,
    get_current_user, logout,
)
from huimei_cli.config import get_server_url, get_frontend_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
app = typer.Typer(help="认证相关命令")


@app.command()
def login(
    password_mode: bool = typer.Option(
        False, "--password", "-p", help="使用用户名密码登录（非浏览器）"
    ),
    server: str = typer.Option(None, help="服务器地址"),
):
    """登录慧媒引擎账号（默认打开浏览器）"""
    if password_mode:
        username = typer.prompt("用户名")
        password = typer.prompt("密码", hide_input=True)
        with console.status("正在登录..."):
            ok = do_login(username, password, server)
        if ok:
            user = get_current_user()
            name = user.get("username", username) if user else username
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败，请检查用户名和密码")
            raise typer.Exit(1)
    else:
        target = server or get_server_url()
        frontend_target = get_frontend_url() if not server else server
        console.print(f"[cyan]正在打开浏览器...[/cyan]")
        console.print(f"[dim]服务器: {target}[/dim]")
        console.print(f"[dim]前端: {frontend_target}[/dim]")
        console.print("[dim]如果已登录将自动完成，否则请在浏览器中登录[/dim]")
        ok = do_browser_login(server)
        if ok:
            user = get_current_user()
            name = user.get("username", "用户") if user else "用户"
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败或超时")
            raise typer.Exit(1)


@app.command()
def status():
    """查看当前登录状态和订阅信息"""
    if not is_logged_in():
        console.print("[yellow]未登录[/yellow]，请先运行 huimei login")
        raise typer.Exit(1)

    user = get_current_user()
    table = Table(title="账号状态")
    table.add_column("项目", style="cyan")
    table.add_column("值")
    table.add_row("用户名", user.get("username", "未知") if user else "未知")
    table.add_row("服务器", get_server_url())
    table.add_row("登录状态", "[green]已登录[/green]")

    # Try to get subscription info
    try:
        from huimei_cli.config import get_config
        cfg = get_config()
        client = ApiClient(get_server_url(), cfg.get("token"))
        sub = client.get_subscription_info()
        if sub:
            table.add_row("订阅类型", str(sub.get("plan", "免费版")))
            table.add_row("到期时间", str(sub.get("expire_time", "-")))
    except Exception:
        table.add_row("订阅信息", "[dim]获取失败[/dim]")

    console.print(table)


@app.command(name="logout")
def do_logout():
    """退出登录"""
    logout()
    console.print("[green]✓[/green] 已退出登录")
