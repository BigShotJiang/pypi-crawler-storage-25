"""Publish command — upload media and create publish tasks via backend."""

import asyncio
import json

import typer
from rich.console import Console
from rich.table import Table
from pathlib import Path
from typing import Optional

from huimei_cli.auth import is_logged_in
from huimei_cli.config import get_config, get_server_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
app = typer.Typer(
    help="内容发布",
    rich_markup_mode="rich",
    epilog="""[dim]示例:[/dim]
  [green]huimei publish -p douyin,xhs -v ~/Videos/demo.mp4 -t "AI教程" --tags AI,教程[/green]
  [green]huimei publish -p bilibili -i ./img1.jpg,./img2.png -t "图文" -c "正文"[/green]
  [green]huimei publish -p douyin -v C:\\Users\\me\\Videos\\demo.mp4 -t "标题"[/green]  [dim](Windows)[/dim]
  [green]huimei publish -p douyin -a "我的抖音号" -v ./demo.mp4 -t "标题"[/green]

[dim]运行 [green]huimei platforms[/green] 查看所有支持的平台[/dim]
[dim]注意: --video 和 --images 仅支持本地文件路径，暂不支持网络URL[/dim]""",
)


def _require_login():
    """Ensure user is logged in, exit if not."""
    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)


def _resolve_accounts(
    client: ApiClient,
    platforms: list[str],
    account_filter: Optional[str],
) -> list[dict]:
    """Resolve target accounts from --account filter or platform matching.

    Returns a list of account dicts (id, platform_id, account_name, ...).
    If multiple accounts exist for a platform and no filter narrows it to one,
    prompts the user to choose interactively.
    """
    try:
        all_accounts = client.get_accounts() or []
    except ApiError as e:
        console.print(f"[red]✗[/red] 获取账号列表失败: {e.message}")
        raise typer.Exit(1)

    if not all_accounts:
        console.print("[red]✗[/red] 当前没有绑定任何账号，请先在网页端绑定账号")
        raise typer.Exit(1)

    # If --account is given, filter by name or id
    if account_filter:
        tokens = [t.strip() for t in account_filter.split(",") if t.strip()]
        matched: list[dict] = []
        for tok in tokens:
            found = [
                a for a in all_accounts
                if str(a.get("id")) == tok or a.get("account_name", "") == tok
            ]
            if not found:
                console.print(f"[red]✗[/red] 未找到账号: {tok}")
                raise typer.Exit(1)
            matched.extend(found)
        return matched

    # No --account: filter by platform list
    selected: list[dict] = []
    for plat in platforms:
        candidates = [
            a for a in all_accounts
            if a.get("platform_id", "").lower() == plat.lower()
        ]
        if not candidates:
            console.print(f"[yellow]⚠[/yellow] 平台 [cyan]{plat}[/cyan] 没有绑定账号，跳过")
            continue

        if len(candidates) == 1:
            selected.append(candidates[0])
            continue

        # Multiple accounts for this platform — let user pick
        console.print(f"\n[cyan]平台 {plat} 有多个账号，请选择:[/cyan]")
        table = Table(show_header=True, header_style="bold")
        table.add_column("#", width=4)
        table.add_column("ID", width=10)
        table.add_column("账号名")
        table.add_column("状态")
        for idx, acc in enumerate(candidates, 1):
            ast = acc.get("account_status")
            if ast == 1:
                status_str = "在线"
            elif ast == 2:
                status_str = "失效"
            else:
                status_str = "离线"
            table.add_row(
                str(idx),
                str(acc.get("id", "")),
                acc.get("account_name", ""),
                status_str,
            )
        console.print(table)

        choices = typer.prompt(
            "输入序号 (多个用逗号分隔, 如 1,3; 输入 a 全选)",
            default="a",
        )
        if choices.strip().lower() == "a":
            selected.extend(candidates)
        else:
            for num in choices.split(","):
                num = num.strip()
                if not num.isdigit() or int(num) < 1 or int(num) > len(candidates):
                    console.print(f"[red]✗[/red] 无效序号: {num}")
                    raise typer.Exit(1)
                selected.append(candidates[int(num) - 1])

    if not selected:
        console.print("[red]✗[/red] 没有匹配的账号可发布")
        raise typer.Exit(1)

    return selected


def _upload_files(
    client: ApiClient,
    video: Optional[Path],
    image_paths: list[Path],
) -> list[str]:
    """Upload local files and return a list of media IDs."""
    media_ids: list[str] = []

    if video:
        console.print(f"[cyan]⬆ 上传视频:[/cyan] {video}")
        try:
            result = client.upload_media(str(video))
            mid = str(result.get("id", ""))
            media_ids.append(mid)
            console.print(f"  [green]✓[/green] mediaId={mid}")
        except ApiError as e:
            console.print(f"  [red]✗[/red] 上传失败: {e.message}")
            raise typer.Exit(1)

    for img in image_paths:
        console.print(f"[cyan]⬆ 上传图片:[/cyan] {img}")
        try:
            result = client.upload_media(str(img))
            mid = str(result.get("id", ""))
            media_ids.append(mid)
            console.print(f"  [green]✓[/green] mediaId={mid}")
        except ApiError as e:
            console.print(f"  [red]✗[/red] 上传失败: {e.message}")
            raise typer.Exit(1)

    return media_ids


@app.callback(invoke_without_command=True)
def publish(
    platform: str = typer.Option(
        ..., "--platform", "-p",
        help="目标平台，逗号分隔 (如: douyin,xhs,bilibili)",
    ),
    account: Optional[str] = typer.Option(
        None, "--account", "-a",
        help="指定账号名或ID，逗号分隔 (可选，不指定则按平台自动匹配)",
    ),
    video: Optional[Path] = typer.Option(
        None, "--video", "-v",
        help="视频文件本地路径 (如: ~/Videos/demo.mp4)",
    ),
    images: Optional[str] = typer.Option(
        None, "--images", "-i",
        help="图片文件本地路径，多张逗号分隔 (如: ./cover.jpg,./slide2.png)",
    ),
    title: str = typer.Option(
        "", "--title", "-t",
        help="作品标题",
    ),
    content: str = typer.Option(
        "", "--content", "-c",
        help="作品正文/描述",
    ),
    tags: str = typer.Option(
        "", "--tags",
        help="标签，逗号分隔 (如: AI,教程,科技)",
    ),
):
    """发布内容到指定平台

    \b
    示例:
      # 发布视频到抖音和小红书
      huimei publish -p douyin,xhs -v ~/Videos/demo.mp4 -t "AI教程" --tags AI,教程

      # 发布图文到B站
      huimei publish -p bilibili -i ./img1.jpg,./img2.png -t "图文分享" -c "正文内容"

      # 指定账号发布
      huimei publish -p douyin -a "我的抖音号" -v ./demo.mp4 -t "标题"

    \b
    支持的平台:
      douyin(抖音) xhs(小红书) bilibili(B站) kuaishou(快手)
      weibo(微博) toutiao(头条) zhihu(知乎) baijiahao(百家号)
      tencent(腾讯视频) weixingongzhonghao(公众号) ks(快手)

    \b
    注意:
      --video 和 --images 仅支持本地文件路径，暂不支持网络URL
      路径支持绝对路径和相对路径，支持 ~ 表示用户主目录
    """
    _require_login()

    # Check execution mode
    exec_config = get_config().get("execution", {})
    exec_mode = exec_config.get("mode", "cloud")

    if exec_mode == "local" or exec_mode == "auto":
        # Try local execution
        try:
            _local_publish(
                platform=platform, account=account, video=video,
                images=images, title=title, content=content, tags=tags
            )
            return
        except Exception as e:
            if exec_mode == "local":
                console.print(f"[red]✗ 客户端执行失败: {e}[/red]")
                raise typer.Exit(1)
            else:
                console.print(f"[yellow]⚠ 客户端执行失败，回退到云端: {e}[/yellow]")

    # Cloud execution (existing logic continues below)

    # ── Validate inputs ──────────────────────────────────────
    if not video and not images:
        console.print("[red]✗[/red] 请至少指定 --video 或 --images")
        raise typer.Exit(1)

    if video and images:
        console.print("[red]✗[/red] --video 和 --images 不能同时指定，请分开发布")
        raise typer.Exit(1)

    # Validate local files exist
    if video and not video.exists():
        console.print(f"[red]✗[/red] 视频文件不存在: {video}")
        raise typer.Exit(1)

    image_paths: list[Path] = []
    if images:
        for img_str in images.split(","):
            p = Path(img_str.strip())
            if not p.exists():
                console.print(f"[red]✗[/red] 图片文件不存在: {p}")
                raise typer.Exit(1)
            image_paths.append(p)

    # Determine content type
    content_type = "video" if video else "image"

    platforms = [p.strip() for p in platform.split(",") if p.strip()]
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    console.print(f"[cyan]准备发布到: {', '.join(platforms)}[/cyan]")
    console.print(f"[cyan]内容类型: {content_type}[/cyan]")

    # ── Init API client ──────────────────────────────────────
    cfg = get_config()
    client = ApiClient(get_server_url(), cfg.get("token"))

    # ── Resolve target accounts ──────────────────────────────
    target_accounts = _resolve_accounts(client, platforms, account)

    console.print(f"\n[cyan]目标账号 ({len(target_accounts)}):[/cyan]")
    for acc in target_accounts:
        console.print(
            f"  • [green]{acc.get('account_name', '?')}[/green]"
            f" ({acc.get('platform_id', '?')}, id={acc.get('id', '?')})"
        )

    # ── Upload media files ─────────────────────────────────────
    console.print()
    media_ids = _upload_files(client, video, image_paths)

    if not media_ids:
        console.print("[red]✗[/red] 没有成功上传任何素材")
        raise typer.Exit(1)

    # ── Create publish task for each account ─────────────────
    console.print()
    success_count = 0
    fail_count = 0

    for acc in target_accounts:
        acc_id = acc.get("id")
        acc_name = acc.get("account_name", "?")
        plat_id = acc.get("platform_id", "")

        task_data: dict = {
            "accountId": acc_id,
            "contentType": content_type,
            "title": title,
            "content": content,
            "tags": tag_list,
            "mediaIds": media_ids,
        }

        # Populate type-specific media lists
        if content_type == "video":
            task_data["fileList"] = media_ids
        else:
            task_data["imageList"] = media_ids

        console.print(
            f"[cyan]▶ 创建发布任务:[/cyan] {acc_name} ({plat_id})"
        )
        try:
            result = client.create_task(task_data)
            task_id = result.get("id") or result.get("task_id") if result else None
            console.print(f"  [green]✓[/green] 任务已创建: {task_id}")
            success_count += 1
        except ApiError as e:
            console.print(f"  [red]✗[/red] 创建任务失败: {e.message}")
            fail_count += 1

    # ── Summary ──────────────────────────────────────────────
    console.print()
    if fail_count == 0:
        console.print(f"[green]✓ 发布完成[/green] — 成功创建 {success_count} 个任务")
    else:
        console.print(
            f"[yellow]⚠ 发布完成[/yellow] — 成功 {success_count}, 失败 {fail_count}"
        )
        raise typer.Exit(1)


def _local_publish(platform, account, video, images, title, content, tags):
    """本地Playwright执行发布"""
    from huimei_cli.engine.script_loader import ScriptLoader
    from huimei_cli.engine.memory_executor import MemoryExecutor
    from huimei_cli.engine.session import CliSession, SessionType
    from huimei_cli.engine.browser import BrowserManager

    cfg = get_config()
    client = ApiClient(get_server_url(), cfg.get("token"))

    # Determine action type
    is_video = video is not None
    action = "publish_video" if is_video else "publish_image"

    # Parse platforms
    platforms = [p.strip().lower() for p in platform.split(",") if p.strip()]

    # Resolve accounts
    accounts = _resolve_accounts(client, platforms, account)
    if not accounts:
        console.print("[red]✗ 没有可用的账号[/red]")
        raise typer.Exit(1)

    # Filter accounts to only target platforms
    accounts = [a for a in accounts if a.get("platform_id", "").lower() in platforms]
    if not accounts:
        console.print("[red]✗ 指定平台没有匹配的账号[/red]")
        raise typer.Exit(1)

    # Get script
    console.print("[dim]正在获取平台脚本...[/dim]")
    loader = ScriptLoader()

    for acct in accounts:
        plat_id = acct.get("platform_id", "").lower()
        acct_name = acct.get("account_name", "未知")

        console.print(f"\n[bold]客户端发布[/bold] [{plat_id}] {acct_name}")

        # Get encrypted script
        try:
            script_data = loader.get_script(plat_id, action)
        except Exception as e:
            console.print(f"[red]✗ 获取脚本失败: {e}[/red]")
            continue

        # Load uploader in memory
        executor = MemoryExecutor()
        try:
            uploader = executor.load_uploader(
                script_data["script"], script_data["base_script"], action
            )
        except Exception as e:
            console.print(f"[red]✗ 加载脚本失败: {e}[/red]")
            continue

        # Parse cookie
        cookie_str = acct.get("cookie_data", "")
        try:
            cookie_data = json.loads(cookie_str) if isinstance(cookie_str, str) else cookie_str
        except json.JSONDecodeError:
            console.print(f"[red]✗ Cookie数据格式错误[/red]")
            continue

        # Prepare file paths
        if is_video:
            vp = Path(video).expanduser().resolve()
            file_list = [str(vp)]
            image_paths = []
        else:
            file_list = []
            image_paths = []
            if images:
                for img_str in images.split(","):
                    ip = Path(img_str.strip()).expanduser().resolve()
                    image_paths.append(str(ip))
                file_list = image_paths

        # Parse tags
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

        # Execute
        headless = cfg.get("execution", {}).get("headless", True)
        asyncio.run(_execute_local(
            uploader, plat_id, cookie_data, headless,
            title or "", content or "", tag_list,
            file_list, image_paths,
            str(video) if video else None
        ))


async def _execute_local(uploader, platform_id, cookie_data, headless,
                          title, content, tags, file_list, image_paths, video_path):
    """核心客户端执行逻辑"""
    from huimei_cli.engine.session import CliSession, SessionType

    session = CliSession(platform_id=platform_id, session_type=SessionType.PUBLISH)
    session.context['cookie_data'] = cookie_data
    session.context['headless'] = headless
    session.context['publish_data'] = {
        'title': title,
        'content': content,
        'tags': tags,
        'file_path': video_path,
        'file_list': file_list,
        'image_paths': image_paths,
    }

    try:
        console.print("[dim]启动本地浏览器...[/dim]")
        result = await uploader.execute_publish(session)

        if result.get('success'):
            console.print(f"[green]✓ 发布成功[/green]")
            post_id = result.get('data', {}).get('post_id')
            url = (result.get('data', {}).get('video_url') or
                   result.get('data', {}).get('article_url'))
            if post_id:
                console.print(f"  帖子ID: {post_id}")
            if url:
                console.print(f"  链接: {url}")
        else:
            msg = result.get('message', '发布失败')
            console.print(f"[red]✗ {msg}[/red]")
    except Exception as e:
        console.print(f"[red]✗ 客户端执行异常: {e}[/red]")
    finally:
        await session.cleanup()
