"""Account commands: add, list."""

import logging
import typer
from rich.console import Console
from rich.table import Table

from huimei_cli.auth import is_logged_in
from huimei_cli.config import get_config, get_server_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
logger = logging.getLogger(__name__)
app = typer.Typer(help="平台账号管理")


def _require_login():
    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)


def _get_client() -> ApiClient:
    cfg = get_config()
    return ApiClient(get_server_url(), cfg.get("token"))


@app.command(name="list")
def list_accounts():
    """列出已绑定的平台账号"""
    _require_login()
    try:
        client = _get_client()
        accounts = client.get_accounts()
        if not accounts:
            console.print("[dim]暂无绑定账号，使用 huimei account add <平台> 添加[/dim]")
            return
        table = Table(title="已绑定账号")
        table.add_column("平台ID", style="cyan")
        table.add_column("平台名称")
        table.add_column("账号ID", style="dim")
        table.add_column("账号名")
        table.add_column("状态")
        for acc in accounts:
            # account_status: 1=正常(在线), 0=离线, 2=失效
            ast = acc.get("account_status")
            if ast == 1:
                status_str = "[green]在线[/green]"
            elif ast == 2:
                status_str = "[red]失效[/red]"
            else:
                status_str = "[yellow]离线[/yellow]"
            table.add_row(
                acc.get("platform_id", "?"),
                acc.get("platform_name", acc.get("platform", "?")),
                str(acc.get("id", "?")),
                acc.get("account_name", acc.get("name", "未知")),
                status_str,
            )
        console.print(table)
    except ApiError as e:
        console.print(f"[red]✗[/red] 获取账号列表失败: {e.message}")


@app.command()
def add(platform: str = typer.Argument(..., help="平台ID，如 douyin, xhs")):
    """添加平台账号（打开本地浏览器登录）"""
    _require_login()
    console.print(f"[cyan]即将打开浏览器，请在浏览器中登录 {platform} 账号...[/cyan]")
    console.print("[dim]登录成功后将自动保存账号信息[/dim]")

    import asyncio
    try:
        asyncio.run(_do_add_account(platform))
    except KeyboardInterrupt:
        console.print("\n[yellow]已取消[/yellow]")
    except Exception as e:
        console.print(f"[red]✗[/red] 添加账号失败: {e}")


async def _do_add_account(platform: str):
    """Execute the account add flow: load encrypted script → login → upload cookie."""
    import json
    from huimei_cli.engine.script_loader import ScriptLoader
    from huimei_cli.engine.memory_executor import MemoryExecutor
    from huimei_cli.engine.session import CliSession, SessionType

    # 1. Load encrypted login script from backend
    console.print("[dim]正在准备...[/dim]")
    try:
        loader = ScriptLoader()
        script_data = loader.get_script(platform, "login")
    except Exception as e:
        console.print(f"[red]✗[/red] 准备失败，请稍后重试")
        logger.debug("Script load error: %s", e)
        return

    # 2. Decrypt and load orchestrator in memory
    try:
        executor = MemoryExecutor()
        orchestrator = executor.load_uploader(
            script_data["script"], script_data["base_script"], "login"
        )
    except Exception as e:
        console.print(f"[red]✗[/red] 初始化失败，请稍后重试")
        logger.debug("Script executor error: %s", e)
        return

    # 3. Create session and execute login
    session = CliSession(platform_id=platform, session_type=SessionType.LOGIN)
    session.context["headless"] = False  # Login needs visible browser
    session.context["cookie_data"] = {}

    try:
        result = await orchestrator.execute_login(session)

        if not result:
            console.print(f"[red]✗[/red] {platform} 登录失败或超时")
            return

        account_name = result.get("account_name") or result.get("nickname") or "未知"
        console.print(f"[green]✓[/green] 登录成功: {account_name}")

        # 4. Extract cookie (storage_state from browser context)
        cookie_data = result.get("cookie_data") or result.get("storage_state")
        if not cookie_data and session.playwright_context:
            # Fallback: grab storage_state from live browser context
            try:
                cookie_data = await session.playwright_context.storage_state()
            except Exception:
                pass

        if not cookie_data:
            console.print("[yellow]⚠[/yellow] 登录信息不完整，请重试")
            return

        # 5. Upload cookie to backend
        cookie_str = json.dumps(cookie_data) if isinstance(cookie_data, dict) else str(cookie_data)
        console.print("[dim]正在保存账号信息...[/dim]")

        client = _get_client()
        try:
            resp = client.create_account_with_cookie(
                platform_id=platform,
                account_name=account_name,
                cookie_data=cookie_str,
                account_id=result.get("user_id") or result.get("account_id"),
                account_avatar=result.get("account_avatar") or result.get("avatar"),
            )
            if resp and resp.get("created"):
                console.print(f"[green]✓[/green] 新账号已添加")
            else:
                console.print(f"[green]✓[/green] 账号信息已更新")
        except ApiError as e:
            console.print(f"[yellow]⚠[/yellow] 保存失败，请稍后重试")
            logger.debug("Cookie upload error: %s", e.message)
            console.print("[dim]登录信息已保留，下次可重试[/dim]")

    finally:
        await session.cleanup()



