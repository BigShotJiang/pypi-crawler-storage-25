"""Local configuration management for huimei-cli.

Config stored as JSON in ~/.huimei/config.json
"""

import json
import uuid
from pathlib import Path

CONFIG_DIR = Path.home() / ".huimei"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_SERVER_URL = "https://huimei.smaroot.tech"

# Pre-defined environment aliases for --server shorthand
SERVER_ALIASES = {
    "prod":  "https://huimei.smaroot.tech",
    "test":  "https://testhuimei.smaroot.tech",
    "local": "http://localhost:5002",
    "dev":   "http://localhost:5002",  # synonym for local
}

# Matching frontend URLs for browser login
FRONTEND_ALIASES = {
    "prod":  "https://huimei.smaroot.tech",
    "test":  "https://testhuimei.smaroot.tech",
    "local": "http://localhost:5173",
    "dev":   "http://localhost:5173",
}


def resolve_server_alias(server: str) -> str:
    """Resolve server alias to full URL.

    Examples:
        'test'  → 'https://testhuimei.smaroot.tech'
        'local' → 'http://localhost:5002'
        'https://my.server.com' → 'https://my.server.com' (unchanged)
    """
    if not server:
        return get_server_url()
    lower = server.lower().strip()
    if lower in SERVER_ALIASES:
        return SERVER_ALIASES[lower]
    # Already a URL
    return server


def resolve_frontend_alias(server: str) -> str:
    """Resolve frontend URL for a server alias.

    Falls back to server URL itself if not a known alias.
    """
    if not server:
        return get_frontend_url()
    lower = server.lower().strip()
    if lower in FRONTEND_ALIASES:
        return FRONTEND_ALIASES[lower]
    return server


_DEFAULTS = {
    "server_url": DEFAULT_SERVER_URL,
    "token": None,
    "device_id": None,
    "execution": {
        "mode": "auto",  # local | cloud | auto
        "auto_rules": {
            "fallback_on_unreachable": True,
            "fallback_on_offline": True,
            "fallback_on_failure": False,
        },
    },
}


def _ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_config() -> dict:
    """Load config from disk, returning defaults if file missing."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                stored = json.load(f)
            # Note: localhost migration removed - users may intentionally use localhost for dev
            # Merge with defaults so new keys are always present
            return {**_DEFAULTS, **stored}
        except (json.JSONDecodeError, OSError):
            pass
    return dict(_DEFAULTS)


def save_config(config: dict):
    """Write config dict to disk as JSON."""
    _ensure_config_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def get_server_url() -> str:
    """Return the configured server URL."""
    return get_config().get("server_url") or DEFAULT_SERVER_URL


def get_token() -> str | None:
    """Return the stored auth token, or None."""
    return get_config().get("token")


def save_token(token: str):
    """Persist an auth token to config."""
    config = get_config()
    config["token"] = token
    save_config(config)


def get_frontend_url() -> str:
    """Return the frontend URL for browser login.

    In production, frontend is served from the same domain as the API.
    In local dev, frontend runs on a different port (e.g. 5173).
    Falls back to server_url if frontend_url is not configured.
    """
    cfg = get_config()
    return cfg.get("frontend_url") or get_server_url()


def get_device_id() -> str:
    """Return a stable device ID, generating one on first call."""
    config = get_config()
    device_id = config.get("device_id")
    if not device_id:
        device_id = str(uuid.uuid4())
        config["device_id"] = device_id
        save_config(config)
    return device_id
