"""Script loader — fetch encrypted platform scripts from backend, cache locally."""

import json
import logging
import hashlib
from pathlib import Path
from typing import Optional

from huimei_cli.config import get_config, get_server_url, CONFIG_DIR
from huimei_cli.api_client import ApiClient, ApiError

logger = logging.getLogger(__name__)

SCRIPTS_DIR = CONFIG_DIR / "scripts"
VERSIONS_FILE = SCRIPTS_DIR / "versions.json"


class ScriptLoader:
    """Fetch encrypted scripts from backend with local .enc cache."""

    def __init__(self):
        SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
        cfg = get_config()
        self._client = ApiClient(get_server_url(), cfg.get("token"))
        self._versions = self._load_versions()

    def get_script(self, platform_id: str, action: str) -> dict:
        """Get encrypted script + base for a platform action.
        
        Returns dict with keys: script, base_script, version, platform_id, action
        All script values are base64-encoded AES ciphertext.
        Uses local cache if version matches.
        """
        cache_key = f"{platform_id}_{action}"
        cached_ver = self._versions.get(cache_key)
        
        # Try fetching from backend
        try:
            data = self._fetch_from_backend(platform_id, action, cached_ver)
            if data:
                # New version, save cache
                self._save_cache(cache_key, data)
                return data
        except Exception as e:
            logger.warning("Failed to fetch script from backend: %s", e)

        # Fallback to local cache
        cached = self._load_cache(cache_key)
        if cached:
            logger.info("Using cached script: %s v%s", cache_key, cached.get("version"))
            return cached

        raise RuntimeError(f"No script available for {platform_id}/{action}")

    def _fetch_from_backend(self, platform_id: str, action: str, 
                             current_version: Optional[str] = None) -> Optional[dict]:
        """Call backend API to get encrypted script."""
        params = {"action": action}
        if current_version:
            params["currentVersion"] = current_version
        
        try:
            resp = self._client._request("GET", 
                f"/api/v1/scripts/platform/{platform_id}", params=params)
            return resp  # {script, base_script, version, platform_id, action}
        except ApiError as e:
            if e.code == 304:  # Not modified
                return None
            raise

    def _save_cache(self, cache_key: str, data: dict):
        """Save encrypted script to local .enc file and update versions."""
        cache_file = SCRIPTS_DIR / f"{cache_key}.json"
        with open(cache_file, "w") as f:
            json.dump(data, f)
        
        self._versions[cache_key] = data.get("version", "unknown")
        self._save_versions()
        logger.info("Cached script: %s v%s", cache_key, data.get("version"))

    def _load_cache(self, cache_key: str) -> Optional[dict]:
        """Load cached encrypted script."""
        cache_file = SCRIPTS_DIR / f"{cache_key}.json"
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        return None

    def _load_versions(self) -> dict:
        if VERSIONS_FILE.exists():
            try:
                with open(VERSIONS_FILE) as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _save_versions(self):
        with open(VERSIONS_FILE, "w") as f:
            json.dump(self._versions, f, indent=2)
