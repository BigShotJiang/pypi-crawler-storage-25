"""Memory-only script executor — decrypt, compile, exec, wipe.

Platform scripts never touch disk as .py files.
Decrypted source lives in memory only during execution.
"""

import gc
import types
import logging
from typing import Optional, Any

from huimei_cli.engine.crypto import decrypt_script, secure_wipe
from huimei_cli.engine.browser import BrowserManager

logger = logging.getLogger(__name__)


class MemoryExecutor:
    """Load and execute encrypted platform scripts in memory."""

    def __init__(self, encryption_key: str = None):
        self._key = encryption_key  # None = use default from crypto.py

    def load_uploader(self, encrypted_script: str, encrypted_base: str,
                       action: str) -> Any:
        """Decrypt and load uploader class from encrypted scripts.
        
        Args:
            encrypted_script: Base64 AES encrypted uploader source
            encrypted_base: Base64 AES encrypted base.py source
            action: 'publish_video', 'publish_image', or 'login'
        
        Returns:
            Instantiated uploader/orchestrator object
        """
        base_source = None
        script_source = None
        
        try:
            # 1. Decrypt base.py
            kwargs = {"key": self._key} if self._key else {}
            base_source = decrypt_script(encrypted_base, **kwargs)
            logger.debug("Base script decrypted: %d bytes", len(base_source))

            # 2. Decrypt uploader script
            script_source = decrypt_script(encrypted_script, **kwargs)
            logger.debug("Uploader script decrypted: %d bytes", len(script_source))

            # 3. Build base module in memory
            base_module = self._exec_module("_cli_base", base_source)

            # 4. Register base module in sys.modules so 'from _cli_base import ...' works
            import sys
            sys.modules["_cli_base"] = base_module

            # 5. Build uploader module with base injected
            uploader_module = self._exec_module(
                "_cli_uploader", script_source,
                extra_globals={"_cli_base": base_module}
            )

            # 6. Find the uploader class
            class_name = self._find_class(uploader_module, action)
            if not class_name:
                raise RuntimeError(f"No uploader class found for action: {action}")

            cls = getattr(uploader_module, class_name)
            instance = cls()
            logger.info("Loaded uploader: %s", class_name)
            return instance

        finally:
            # 7. Secure wipe decrypted source
            if base_source:
                secure_wipe(base_source)
            if script_source:
                secure_wipe(script_source)
            # Clean up sys.modules
            import sys
            sys.modules.pop("_cli_base", None)
            gc.collect()

    def _exec_module(self, name: str, source: bytes, 
                      extra_globals: dict = None) -> types.ModuleType:
        """Compile and exec source into a new module object."""
        # Rewrite imports: the engine scripts use 'from platforms.base import ...'
        # We need to redirect to our in-memory base module
        source_str = source.decode("utf-8")
        source_str = source_str.replace(
            "from platforms.base import", "from _cli_base import"
        )
        source_str = source_str.replace(
            "from core.session_manager import", "# cli-stripped: "
        )
        source_str = source_str.replace(
            "from sls_integration.client import", "# cli-stripped: "
        )
        source_str = source_str.replace(
            "from core.browser_creator import BrowserCreator",
            "# cli-stripped: BrowserCreator"
        )
        
        code = compile(source_str, f"<memory:{name}>", "exec")
        
        module = types.ModuleType(name)
        module.__file__ = f"<memory:{name}>"
        
        # Inject dependencies
        exec_globals = module.__dict__
        if extra_globals:
            exec_globals.update(extra_globals)
        
        # Provide a no-op log_to_sls for scripts that import it
        exec_globals.setdefault('log_to_sls', lambda *a, **kw: None)
        
        # Inject CLI session types to replace engine's core.session_manager imports
        from huimei_cli.engine.session import CliSession, SessionType, SessionStatus, BrowserType
        exec_globals.setdefault('Session', CliSession)
        exec_globals.setdefault('SessionType', SessionType)
        exec_globals.setdefault('SessionStatus', SessionStatus)
        exec_globals.setdefault('BrowserType', BrowserType)
        
        # Inject BrowserCreator replacement that uses CLI's BrowserManager
        exec_globals.setdefault('BrowserCreator', _CliBrowserCreator)
        
        exec(code, exec_globals)
        return module

    def _find_class(self, module: types.ModuleType, action: str) -> Optional[str]:
        """Find the uploader/orchestrator class name based on action."""
        action_suffix_map = {
            "publish_video": "VideoUploader",
            "publish_image": "ImageUploader",
            "login": "LoginOrchestrator",
        }
        suffix = action_suffix_map.get(action)
        if not suffix:
            return None
        
        for name in dir(module):
            if name.endswith(suffix) and not name.startswith("Base"):
                return name
        return None

    def create_browser_and_session(self, platform_id, cookie_data, headless=True):
        """Helper: prepare browser+session for uploader execution.
        
        Returns (session, browser_manager) tuple.
        Caller must cleanup after use.
        """
        from huimei_cli.engine.session import CliSession, SessionType
        
        session = CliSession(platform_id=platform_id, session_type=SessionType.PUBLISH)
        session.context['cookie_data'] = cookie_data
        session.context['headless'] = headless
        return session


class _CliBrowserCreator:
    """Drop-in replacement for engine's BrowserCreator.
    
    The engine's base.py calls BrowserCreator.create_browser_session(session)
    inside BasePublishUploader/BaseLoginOrchestrator. This class provides 
    the same interface using CLI's BrowserManager.
    """

    @staticmethod
    async def create_browser_session(session):
        from huimei_cli.engine.browser import BrowserManager

        if session.page:
            return {'browser': session.playwright_browser, 'page': session.page}

        headless = session.context.get('headless', True)
        mgr = BrowserManager(headless=headless)
        await mgr.start()

        cookie_data = session.context.get('cookie_data')
        storage_state = None
        cookies = None
        if isinstance(cookie_data, dict):
            if 'cookies' in cookie_data and 'origins' in cookie_data:
                storage_state = cookie_data
            elif 'cookies' in cookie_data:
                cookies = cookie_data['cookies']
        elif isinstance(cookie_data, list):
            cookies = cookie_data

        ctx = await mgr.new_context(cookies=cookies, storage_state=storage_state)
        page = await ctx.new_page()

        session.playwright_browser = mgr._browser
        session.playwright_context = ctx
        session.playwright_page = page
        session.browser = mgr._browser
        session.page = page
        session.context_obj = ctx
        session._browser_manager = mgr

        session.send_message('info', {'message': '浏览器已就绪'})
        return {'browser': mgr._browser, 'page': page, 'context': ctx}
