"""Test for CLI entry point and command registration."""


def test_app_exists():
    """Main app can be imported."""
    from huimei_cli.main import app
    assert app is not None


def test_version_exists():
    """Version string is set."""
    from huimei_cli import __version__
    assert __version__ == "0.4.1"


def test_platform_registry_loads():
    """Platform registry files can be imported."""
    import importlib
    platforms = ["douyin", "xhs", "bilibili", "ks", "weibo"]
    for pid in platforms:
        mod = importlib.import_module(f"huimei_cli.platforms.registry.{pid}")
        config = getattr(mod, "PLATFORM_CONFIG")
        assert "name" in config
        assert "publish_params_config" in config
