"""
tapnop - Game Sound Effects Trading Platform Client Library

tapnop is a Python client library for interacting with the backend API of the
game sound effects trading platform. It provides a simple interface for uploading
audio files to the marketplace, supporting both single and batch uploads.

The library handles authentication via JWT tokens, file validation, multipart
form data encoding, and comprehensive error handling.

Version: 0.1.0

Main Functions:
    configure(api_base_url): Set the API base URL for requests.
    upload(file_path, name, category, jwt_token, **kwargs): Upload a single file.
    batch_upload(files_with_metadata, jwt_token, common_metadata): Upload multiple files.

Exception Classes:
    TapnopError: Base exception for all library errors.
    APIError: Raised when API requests fail, includes status code and response data.
    AuthenticationError: Raised when JWT token is invalid or expired.
    FileError: Raised when local file operations fail.

Basic Usage:
    >>> import tapnop
    >>>
    >>> # Configure API endpoint (optional, has a default)
    >>> tapnop.configure("https://api.example.com/api/market/sounds")
    >>>
    >>> # Upload a single file
    >>> result = tapnop.upload(
    ...     file_path="./sound.wav",
    ...     name="Explosion",
    ...     category="FX",
    ...     jwt_token="your_jwt_token_here",
    ...     price=100,
    ...     tags=["explosion", "battle"]
    ... )
    >>>
    >>> # Upload multiple files with common metadata
    >>> results = tapnop.batch_upload(
    ...     files_with_metadata=[
    ...         {"file_path": "a.wav", "name": "Sound A"},
    ...         {"file_path": "b.wav", "name": "Sound B"},
    ...     ],
    ...     jwt_token="your_jwt_token_here",
    ...     common_metadata={"category": "FX", "price": 50}
    ... )

Error Handling:
    >>> from tapnop import TapnopError, FileError, AuthenticationError, APIError
    >>>
    >>> try:
    ...     tapnop.upload(...)
    ... except FileError as e:
    ...     print(f"File error: {e}")
    ... except AuthenticationError as e:
    ...     print(f"Authentication failed: {e}")
    ... except APIError as e:
    ...     print(f"API error [{e.status_code}]: {e}")
    ... except TapnopError as e:
    ...     print(f"Library error: {e}")

Installation:
    pip install tapnop
"""

__version__ = "0.1.0"

# Import core functions
from .client import batch_upload, configure, upload

# Import exception classes
from .exceptions import APIError, AuthenticationError, FileError, TapnopError

__all__ = [
    "__version__",
    "configure",
    "upload",
    "batch_upload",
    "TapnopError",
    "APIError",
    "AuthenticationError",
    "FileError",
]
