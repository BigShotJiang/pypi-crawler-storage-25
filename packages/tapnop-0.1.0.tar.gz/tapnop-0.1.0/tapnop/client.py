"""
tapnop Client Module

This module provides the core functionality for interacting with the backend API
of the game sound effects trading platform. It includes functions for uploading
single or multiple audio files to the server.

Functions:
    configure: Set the API base URL for all requests.
    upload: Upload a single audio file with metadata to the server.
    batch_upload: Upload multiple audio files with optional common metadata.

Example:
    >>> import tapnop
    >>> tapnop.configure("https://api.example.com/api/market/sounds")
    >>> result = tapnop.upload(
    ...     file_path="sound.wav",
    ...     name="Explosion",
    ...     category="FX",
    ...     jwt_token="your_token_here",
    ...     price=100
    ... )
"""

import os
from typing import Dict, List

import requests

from .exceptions import APIError, AuthenticationError, FileError, TapnopError


# Private variable: API base URL
_api_base_url = "https://uu862979-8359-996463ae.westb.seetacloud.com:8443/api/market/sounds"


def configure(api_base_url: str) -> None:
    """
    Configure the base URL for the backend API.

    This function sets the global API base URL that will be used for all
    subsequent upload requests. The URL should point to the sounds endpoint
    of the market API (e.g., "https://api.example.com/api/market/sounds").

    Args:
        api_base_url: The base URL string for the API endpoint.

    Returns:
        None

    Side Effects:
        Updates the global `_api_base_url` variable and prints a confirmation message.

    Example:
        >>> import tapnop
        >>> tapnop.configure("https://api.example.com/api/market/sounds")
        tapnop configured successfully: API base URL set to https://api.example.com/api/market/sounds
    """
    global _api_base_url
    _api_base_url = api_base_url
    print(f"tapnop configured successfully: API base URL set to {_api_base_url}")


def upload(
    file_path: str,
    name: str,
    category: str,
    jwt_token: str,
    **kwargs
) -> Dict:
    """
    Upload a single audio file to the backend API with metadata.

    This function validates the file, prepares the multipart form data, and sends
    a POST request to the configured API endpoint. It handles various error
    scenarios and raises appropriate exceptions.

    Args:
        file_path: The local path to the audio file to upload.
            Must be a valid file path that exists on the local filesystem.
            Supported formats: WAV, OGG, MP3.
        name: The display name for the sound effect.
            This will be shown in the marketplace.
        category: The category classification for the sound effect.
            Examples: "FX", "Ambient", "Music", "Voice".
        jwt_token: The JWT (JSON Web Token) for authentication.
            Must be a valid token issued by the backend authentication system.
        **kwargs: Optional additional metadata fields.
            Supported keys include:
                - tags (list[str]): List of tags for searchability.
                  Will be converted to a comma-separated string.
                - description (str): Detailed description of the sound.
                - price (int): Price in credits (0-10000).

    Returns:
        dict: The JSON response from the API on successful upload.
            Typically contains the sound ID, name, category, and other metadata.

    Raises:
        FileError: If the file does not exist or is not a valid file.
        AuthenticationError: If the JWT token is invalid or expired.
        APIError: If the API returns an error response or connection fails.
        TapnopError: For other unexpected errors during the upload process.

    Example:
        >>> result = tapnop.upload(
        ...     file_path="./sounds/explosion.wav",
        ...     name="Big Explosion",
        ...     category="FX",
        ...     jwt_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        ...     price=100,
        ...     tags=["explosion", "battle", "action"]
        ... )
        Upload succeeded: explosion.wav
        >>> print(result["id"])
        "abc123-def456"
    """
    # 1. Validate file existence
    if not os.path.exists(file_path):
        raise FileError(f"File not found: {file_path}")
    if not os.path.isfile(file_path):
        raise FileError(f"Path is not a file: {file_path}")

    # 2. Prepare metadata, handling tags as comma-separated string
    data = {
        "name": name,
        "category": category,
    }

    # Merge additional metadata
    for key, value in kwargs.items():
        if key == "tags" and isinstance(value, list):
            data["tags"] = ",".join(str(tag) for tag in value)
        else:
            data[key] = value

    # 3. Prepare file upload
    filename = os.path.basename(file_path)
    files = {
        "file": (filename, open(file_path, "rb"))
    }

    # 4. Prepare headers with JWT token
    headers = {
        "Authorization": f"Bearer {jwt_token}"
    }

    # 5. Build API endpoint URL
    upload_url = _api_base_url

    try:
        # 6. Send POST request
        response = requests.post(upload_url, headers=headers, files=files, data=data)

        # 7. Process response
        if response.status_code == 401:
            raise AuthenticationError("JWT Token is invalid or expired")

        if not response.ok:
            try:
                error_data = response.json()
                error_message = error_data.get("detail", error_data.get("message", "Upload failed"))
            except Exception:
                error_message = response.text or "Upload failed"
                error_data = {}

            raise APIError(
                message=error_message,
                status_code=response.status_code,
                response_data=error_data
            )

        # 8. Parse successful response
        try:
            result = response.json()
            print(f"Upload succeeded: {filename}")
            return result
        except ValueError as exc:
            raise APIError("Failed to parse API response") from exc

    except requests.ConnectionError as exc:
        raise APIError(f"Cannot connect to server: {exc}") from exc
    except requests.Timeout as exc:
        raise APIError(f"Request timeout: {exc}") from exc
    except requests.RequestException as exc:
        raise APIError(f"Request failed: {exc}") from exc
    finally:
        # Ensure file is closed
        if "file" in files:
            files["file"][1].close()


def batch_upload(
    files_with_metadata: List[Dict],
    jwt_token: str,
    common_metadata: Dict = None
) -> List[Dict]:
    """
    Upload multiple audio files with optional common metadata.

    This function iterates through a list of file specifications, merging
    each with common metadata and uploading individually. It provides detailed
    progress output and returns a comprehensive results list.

    For each file:
    1. Merges common_metadata with file-specific metadata (file-specific takes precedence)
    2. Infers name from filename if not provided
    3. Uses "Default" category if not specified
    4. Attempts upload and captures result or error

    Args:
        files_with_metadata: A list of dictionaries, each containing file metadata.
            Each dictionary must include:
                - file_path (str, required): Path to the local audio file
            Each dictionary may include:
                - name (str, optional): Display name (defaults to filename without extension)
                - category (str, optional): Category (defaults to "Default")
                - Other metadata fields (e.g., price, tags, description)

            Example:
                [
                    {"file_path": "a.wav", "name": "A", "category": "FX"},
                    {"file_path": "b.wav", "name": "B"}
                ]
        jwt_token: The JWT (JSON Web Token) for authentication.
            Must be a valid token issued by the backend authentication system.
        common_metadata: Optional dictionary of metadata to apply to all files.
            If a file-specific value conflicts with a common value, the file-specific
            value takes precedence.

            Example:
                {
                    "price": 50,
                    "tags": ["game", "sfx"],
                    "category": "Ambient"
                }

    Returns:
        List[Dict]: A list of upload results, one per file.
            Each result dictionary contains:
                - file (str): The file path that was processed
                - status (str): Either "success" or "failed"
                - result (dict, optional): API response on success
                - error (str, optional): Error message on failure

            Example:
                [
                    {"file": "a.wav", "status": "success", "result": {"id": "123"}},
                    {"file": "b.wav", "status": "failed", "error": "File not found"}
                ]

    Raises:
        Does not raise exceptions; all errors are captured in the results list.
        Individual file upload errors are caught and recorded.

    Example:
        >>> results = tapnop.batch_upload(
        ...     files_with_metadata=[
        ...         {"file_path": "./sounds/explosion.wav", "name": "Explosion"},
        ...         {"file_path": "./sounds/footstep.wav", "name": "Footstep"},
        ...     ],
        ...     jwt_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        ...     common_metadata={"price": 50, "category": "FX"}
        ... )
        Batch upload started: 2 file(s)
        Upload succeeded: explosion.wav
        Upload succeeded: footstep.wav
        Batch upload completed: 2 succeeded, 0 failed
    """
    common_metadata = common_metadata or {}
    results = []
    total_files = len(files_with_metadata)
    print(f"\nBatch upload started: {total_files} file(s)")

    for file_meta in files_with_metadata:
        file_path = file_meta.get("file_path")

        if not file_path:
            results.append({
                "file": "<unknown>",
                "status": "failed",
                "error": "Missing file_path parameter"
            })
            continue

        # Merge metadata: common metadata + file-specific metadata
        # File-specific metadata takes precedence
        merged_metadata = {**common_metadata, **file_meta}

        # Infer name and category if not provided
        # Get from merged metadata, preferring file_meta values
        name = merged_metadata.get("name")
        if not name:
            # Use filename without extension as default
            name = os.path.splitext(os.path.basename(file_path))[0]

        category = merged_metadata.get("category")
        if not category:
            # Use default category
            category = "Default"

        # Remove fields that are passed as separate parameters
        merged_metadata.pop("file_path", None)
        merged_metadata.pop("name", None)
        merged_metadata.pop("category", None)

        try:
            result = upload(
                file_path=file_path,
                name=name,
                category=category,
                jwt_token=jwt_token,
                **merged_metadata
            )
            results.append({
                "file": file_path,
                "status": "success",
                "result": result
            })
        except TapnopError as exc:
            print(f"Upload failed: {file_path} - {str(exc)}")
            results.append({
                "file": file_path,
                "status": "failed",
                "error": str(exc)
            })
        except Exception as exc:
            print(f"Upload failed: {file_path} - Unknown error: {exc}")
            results.append({
                "file": file_path,
                "status": "failed",
                "error": f"Unknown error: {exc}"
            })

    # Summary output
    success_count = sum(1 for r in results if r["status"] == "success")
    failed_count = total_files - success_count
    print(f"Batch upload completed: {success_count} succeeded, {failed_count} failed")

    return results
