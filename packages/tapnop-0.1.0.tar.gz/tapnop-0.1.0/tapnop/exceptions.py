"""
tapnop Custom Exceptions Module

This module defines all custom exception classes used by the tapnop library.
All exceptions inherit from TapnopError, providing a common base for exception handling.

Classes:
    TapnopError: Base exception class for all tapnop library exceptions.
    APIError: Raised when the backend API returns an error status code or data.
    AuthenticationError: Raised when JWT token validation fails (subclass of APIError).
    FileError: Raised when local file operations fail (subclass of TapnopError).

Example:
    >>> from tapnop.exceptions import TapnopError, APIError, FileError
    >>> try:
    ...     tapnop.upload(...)
    ... except FileError as e:
    ...     print(f"File error: {e}")
    ... except APIError as e:
    ...     print(f"API error [{e.status_code}]: {e}")
    ... except TapnopError as e:
    ...     print(f"Tapnop error: {e}")
"""


class TapnopError(Exception):
    """
    Base exception class for the tapnop library.

    All custom exceptions in the tapnop library inherit from this class,
    allowing for broad exception catching when needed.

    Attributes:
        message (str): The error message describing the exception.

    Example:
        >>> raise TapnopError("Something went wrong")
    """

    pass


class APIError(TapnopError):
    """
    Raised when the backend API returns an error status code or invalid data.

    This exception is raised when the API request fails due to server-side errors,
    invalid responses, or other API-related issues. It includes additional
    context about the HTTP response.

    Attributes:
        message (str): The error message describing what went wrong.
        status_code (int, optional): The HTTP status code returned by the API.
            Common values include 400 (Bad Request), 404 (Not Found), 500 (Server Error).
        response_data (dict): The raw response data from the API, if available.
            May contain additional error details from the server.

    Args:
        message: A descriptive error message.
        status_code: The HTTP status code from the API response (optional).
        response_data: The response data dictionary from the API (optional).

    Example:
        >>> raise APIError("Resource not found", status_code=404)
        >>> str(exc)
        '[404] Resource not found'
    """

    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data or {}

    def __str__(self):
        """Return a string representation including status code if available."""
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(APIError):
    """
    Raised when JWT token authentication fails.

    This exception is raised when the JWT token provided to the API is invalid,
    expired, or otherwise fails authentication. It is a subclass of APIError
    and always has a default status code of 401.

    Attributes:
        message (str): The error message (default: "Authentication failed").
        status_code (int): Always 401 (Unauthorized).
        response_data (dict): The response data from the API (optional).

    Args:
        message: A descriptive error message (default: "Authentication failed").
        status_code: The HTTP status code (default: 401).
        response_data: The response data dictionary from the API (optional).

    Example:
        >>> raise AuthenticationError("Token expired")
        >>> exc.status_code
        401
    """

    def __init__(self, message: str = "Authentication failed", status_code: int = 401, response_data: dict = None):
        super().__init__(message, status_code, response_data)


class FileError(TapnopError):
    """
    Raised when local file operations fail.

    This exception is raised when a file cannot be accessed, does not exist,
    or is not a valid file. It is typically raised before attempting to
    upload a file to the API.

    Attributes:
        message (str): The error message describing the file-related issue.

    Args:
        message: A descriptive error message about the file issue.

    Example:
        >>> raise FileError("File not found: /path/to/file.wav")
        >>> str(exc)
        'File not found: /path/to/file.wav'
    """

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def __str__(self):
        """Return the error message."""
        return self.message
