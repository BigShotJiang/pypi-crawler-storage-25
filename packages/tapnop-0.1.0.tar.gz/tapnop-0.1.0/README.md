# tapnop

A Python client library for interacting with the backend API of the Game Sound Effects Trading Platform.

## Installation

```bash
pip install tapnop
```

## Configuration

Configure the API base URL before using the library (optional, has a default):

```python
import tapnop

# Configure the backend API address
# Default: https://uu862979-8359-996463ae.westb.seetacloud.com:8443/api/market/sounds
# tapnop.configure("https://api.example.com/api/market/sounds")
```

## Upload Sound Effects

### Single File Upload

```python
import tapnop

jwt_token = "your_jwt_token_here"

result = tapnop.upload(
    file_path="path/to/sound.wav",
    name="Explosion Sound",
    category="FX",
    jwt_token=jwt_token,
    price=100,
    tags=["explosion", "battle", "action"],
    description="A powerful explosion sound effect"
)

print("Upload succeeded:", result)
```

### Batch Upload

```python
import tapnop

jwt_token = "your_jwt_token_here"

# Define file list
files = [
    {"file_path": "sounds/explosion.wav", "name": "Explosion", "category": "FX"},
    {"file_path": "sounds/footstep.wav", "name": "Footstep", "category": "Ambient"},
]

# Batch upload with common metadata
results = tapnop.batch_upload(
    files_with_metadata=files,
    jwt_token=jwt_token,
    common_metadata={
        "price": 50,
        "tags": ["game", "sfx"],
        "description": "Game sound effect"
    }
)

for result in results:
    if result["status"] == "success":
        print(f"{result['file']}: Upload succeeded")
    else:
        print(f"{result['file']}: Upload failed - {result['error']}")
```

## Error Handling

```python
import tapnop
from tapnop import TapnopError, FileError, AuthenticationError, APIError

try:
    result = tapnop.upload(
        file_path="sound.wav",
        name="My Sound",
        category="FX",
        jwt_token="invalid_token"
    )
except FileError as e:
    print(f"File error: {e}")
except AuthenticationError as e:
    print(f"Authentication failed: {e}")
except APIError as e:
    print(f"API error [{e.status_code}]: {e}")
except TapnopError as e:
    print(f"tapnop error: {e}")
```

## Exception Types

| Exception | Description |
|-----------|-------------|
| `TapnopError` | Base exception class |
| `APIError` | API returns error status code or data |
| `AuthenticationError` | JWT Token is invalid or expired |
| `FileError` | Local file not found or inaccessible |

## License

MIT License
