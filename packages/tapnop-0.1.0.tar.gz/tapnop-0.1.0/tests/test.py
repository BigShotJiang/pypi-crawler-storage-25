import tapnop
# 单文件上传
result = tapnop.upload(
    file_path="./can_opening.wav",
    name="can_opening",
    category="Ambient",
    jwt_token="eyJzdWIiOiJ1c2VyXzNBZkxSRVF2TVNzQW5MeE8zbnIzQzlhSjUxcCIsImVtYWlsIjoiYW5kcmV3NjE3OTM4QDE2My5jb20iLCJpYXQiOjE3NzM5MDkxMTcsImV4cCI6MTc3NjUwMTExN30._5-ujrVVxSIS_EWhKxiGSMtANXsKN6_xtbwmJsG4424",
    price=0
)

# 批量上传
results = tapnop.batch_upload(
    files_with_metadata=[
        {"file_path": "./rainfall.wav", "price": 10, "category": "bala"},
        {"file_path": "./river.wav", "price": 15, "category": "Nature"},
    ],
    jwt_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyXzNBZkxSRVF2TVNzQW5MeE8zbnIzQzlhSjUxcCIsImVtYWlsIjoiYW5kcmV3NjE3OTM4QDE2My5jb20iLCJpYXQiOjE3NzM5MDkxMTcsImV4cCI6MTc3NjUwMTExN30._5-ujrVVxSIS_EWhKxiGSMtANXsKN6_xtbwmJsG4424",
    common_metadata={"name": "123"}
)