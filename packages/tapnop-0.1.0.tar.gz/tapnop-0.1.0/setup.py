"""
tapnop 包的 setup.py 配置
"""

import os

from setuptools import find_packages, setup

# 读取 README.md
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="tapnop",
    version="0.1.0",
    author="AmazingcatAndrew",
    author_email="andrew617938@gmail.com",
    description="A Python client library for TapNop market",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AmazingcatAndrew/tapnop",
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.20.0",
    ],
)
