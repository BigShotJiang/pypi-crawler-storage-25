from typing import Self

from mpt_api_client.http import AsyncHTTPClient, HTTPClient
from mpt_api_client.resources import (
    Accounts,
    AsyncAccounts,
    AsyncAudit,
    AsyncBilling,
    AsyncCatalog,
    AsyncCommerce,
    AsyncExchange,
    AsyncHelpdesk,
    AsyncIntegration,
    AsyncNotifications,
    AsyncProgram,
    AsyncSpotlight,
    Audit,
    Billing,
    Catalog,
    Commerce,
    Exchange,
    Helpdesk,
    Integration,
    Notifications,
    Program,
    Spotlight,
)


class AsyncMPTClient:
    """MPT API Client."""

    def __init__(
        self,
        http_client: AsyncHTTPClient | None = None,
    ):
        self.http_client = http_client or AsyncHTTPClient()

    @classmethod
    def from_config(
        cls,
        api_token: str,
        base_url: str,
        timeout: float = 60.0,
    ) -> Self:
        """Create MPT client from configuration.

        Args:
            api_token: MPT API Token
            base_url: MPT Base URL
            timeout: HTTP request timeout in seconds. Defaults to 60.0.

        Returns:
            MPT Client

        """
        return cls(AsyncHTTPClient(base_url=base_url, api_token=api_token, timeout=timeout))

    @property
    def catalog(self) -> AsyncCatalog:
        """Catalog MPT API Client."""
        return AsyncCatalog(http_client=self.http_client)

    @property
    def commerce(self) -> AsyncCommerce:
        """Commerce MPT API Client."""
        return AsyncCommerce(http_client=self.http_client)

    @property
    def audit(self) -> AsyncAudit:
        """Audit MPT API Client."""
        return AsyncAudit(http_client=self.http_client)

    @property
    def billing(self) -> AsyncBilling:
        """Billing MPT API Client."""
        return AsyncBilling(http_client=self.http_client)

    @property
    def accounts(self) -> AsyncAccounts:
        """Accounts MPT API Client."""
        return AsyncAccounts(http_client=self.http_client)

    @property
    def notifications(self) -> AsyncNotifications:
        """Notifications MPT API Client."""
        return AsyncNotifications(http_client=self.http_client)

    @property
    def helpdesk(self) -> AsyncHelpdesk:
        """Helpdesk MPT API Client."""
        return AsyncHelpdesk(http_client=self.http_client)

    @property
    def exchange(self) -> AsyncExchange:
        """Exchange MPT API Client."""
        return AsyncExchange(http_client=self.http_client)

    @property
    def integration(self) -> AsyncIntegration:
        """Integration MPT API Client."""
        return AsyncIntegration(http_client=self.http_client)

    @property
    def program(self) -> AsyncProgram:
        """Program MPT API Client."""
        return AsyncProgram(http_client=self.http_client)

    @property
    def spotlight(self) -> AsyncSpotlight:
        """Spotlight MPT API Client."""
        return AsyncSpotlight(http_client=self.http_client)


class MPTClient:
    """MPT API Client."""

    def __init__(
        self,
        http_client: HTTPClient | None = None,
    ):
        self.http_client = http_client or HTTPClient()

    @classmethod
    def from_config(
        cls,
        api_token: str,
        base_url: str,
        timeout: float = 60.0,
    ) -> Self:
        """Create MPT client from configuration.

        Args:
            api_token: MPT API Token
            base_url: MPT Base URL
            timeout: HTTP request timeout in seconds. Defaults to 60.0.

        Returns:
            MPT Client

        """
        return cls(HTTPClient(base_url=base_url, api_token=api_token, timeout=timeout))

    @property
    def commerce(self) -> Commerce:
        """Commerce MPT API Client.

        The Commerce API provides a comprehensive set of endpoints
        for managing agreements, requests, subscriptions, and orders
        within a vendor-client-ops ecosystem.
        """
        return Commerce(http_client=self.http_client)

    @property
    def catalog(self) -> Catalog:
        """Catalog MPT API Client."""
        return Catalog(http_client=self.http_client)

    @property
    def audit(self) -> Audit:
        """Audit MPT API Client."""
        return Audit(http_client=self.http_client)

    @property
    def billing(self) -> Billing:
        """Billing MPT API Client."""
        return Billing(http_client=self.http_client)

    @property
    def accounts(self) -> Accounts:
        """Accounts MPT API Client."""
        return Accounts(http_client=self.http_client)

    @property
    def notifications(self) -> Notifications:
        """Notifications MPT API Client."""
        return Notifications(http_client=self.http_client)

    @property
    def helpdesk(self) -> Helpdesk:
        """Helpdesk MPT API Client."""
        return Helpdesk(http_client=self.http_client)

    @property
    def exchange(self) -> Exchange:
        """Exchange MPT API Client."""
        return Exchange(http_client=self.http_client)

    @property
    def integration(self) -> Integration:
        """Integration MPT API Client."""
        return Integration(http_client=self.http_client)

    @property
    def program(self) -> Program:
        """Program MPT API Client."""
        return Program(http_client=self.http_client)

    @property
    def spotlight(self) -> Spotlight:
        """Spotlight MPT API Client."""
        return Spotlight(http_client=self.http_client)
