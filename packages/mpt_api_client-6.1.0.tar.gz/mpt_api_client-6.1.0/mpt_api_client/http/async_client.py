import os
from typing import Any

from httpx import AsyncClient, HTTPError, RequestError
from httpx_retries import Retry, RetryTransport

from mpt_api_client.constants import APPLICATION_JSON
from mpt_api_client.exceptions import MPTError, MPTMaxRetryError
from mpt_api_client.http.client import json_to_file_payload
from mpt_api_client.http.client_utils import get_query_params, validate_base_url
from mpt_api_client.http.query_options import QueryOptions
from mpt_api_client.http.request_response_utils import handle_response_http_error
from mpt_api_client.http.types import HeaderTypes, QueryParam, RequestFiles, Response


class AsyncHTTPClient:
    """Async HTTP client for interacting with SoftwareOne Marketplace Platform API."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_token: str | None = None,
        timeout: float = 20.0,
        retries: int = 5,
    ):
        self._retries = retries
        retry = Retry(
            total=retries,
            allowed_methods={"DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT", "PATCH"},
        )
        transport = RetryTransport(retry=retry)

        api_token = api_token or os.getenv("MPT_API_TOKEN")
        if not api_token:
            raise ValueError(
                "API token is required. "
                "Set it up as env variable MPT_API_TOKEN or pass it as `api_token` "
                "argument to MPTClient."
            )

        base_url = validate_base_url(base_url or os.getenv("MPT_API_BASE_URL"))
        base_headers = {
            "User-Agent": "swo-marketplace-client/1.0",
            "Authorization": f"Bearer {api_token}",
        }
        self.httpx_client = AsyncClient(
            base_url=base_url,
            headers=base_headers,
            timeout=timeout,
            transport=transport,
            follow_redirects=True,
        )

    async def request(  # noqa: WPS211
        self,
        method: str,
        url: str,
        *,
        files: RequestFiles | None = None,
        json: Any | None = None,
        query_params: QueryParam | None = None,
        headers: HeaderTypes | None = None,
        json_file_key: str = "_attachment_data",
        force_multipart: bool = False,
        options: QueryOptions | None = None,
    ) -> Response:
        """Perform an HTTP request.

        Args:
            method: HTTP method.
            url: URL to send the request to.
            files: Request files.
            json: Request JSON data.
            query_params: Query parameters.
            headers: Request headers.
            json_file_key: json file name for data when sending a multipart request.
            force_multipart: force multipart request even if file is not provided.
            options: Additional options for the request.

        Returns:
            Response object.

        Raises:
            MPTError: If the request fails.
            MPTApiError: If the response contains an error.
            MPTHttpError: If the response contains an HTTP error.
            MPTMaxRetryError: If the request fails after maximum retry attempts.
        """
        files = dict(files or {})
        if force_multipart or (files and json):
            files[json_file_key] = (None, json_to_file_payload(json), APPLICATION_JSON)
            json = None
        params_str = get_query_params(query_params, options)
        try:
            response = await self.httpx_client.request(
                method,
                url,
                files=files,
                json=json,
                params=params_str or None,
                headers=headers,
            )
        except RequestError as err:
            raise MPTMaxRetryError(str(err), self._retries + 1) from err
        except HTTPError as err:
            raise MPTError(f"HTTP Error: {err}") from err

        handle_response_http_error(response)

        return Response(
            headers=dict(response.headers),
            status_code=response.status_code,
            content=response.content,
        )
