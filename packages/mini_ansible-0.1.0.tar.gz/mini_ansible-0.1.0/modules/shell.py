def run(host, user, password, args, executor, become=False):
    """
    Execute a shell command on the remote host.

    Args:
        host: Host IP string or full host dict (with connection info)
        user: SSH username
        password: SSH password (may be None for MySSH connections)
        args: Module arguments:
            - cmd: Command to run (required)
            - chdir: Directory to change to before running command
        executor: Executor module for running commands
        become: Whether to run with sudo

    Returns:
        Dict with host, output, error, and optionally changed status
    """
    command = args.get("cmd")
    chdir = args.get("chdir")
    host_id = host if isinstance(host, str) else host.get("ip", "unknown")

    if not command:
        return {
            "host": host_id,
            "output": "",
            "error": "Missing 'cmd' argument for shell module"
        }

    if chdir:
        command = f"cd {chdir} && {command}"

    if become:
        command = f"sudo sh -c '{command}'"

    return executor.run_command(host, user, password, command)
