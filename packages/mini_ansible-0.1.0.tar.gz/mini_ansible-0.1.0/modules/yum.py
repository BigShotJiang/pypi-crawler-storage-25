from utils.sudo import sudo_wrap


def get_host_id(host):
    """Get host identifier for result dict."""
    return host if isinstance(host, str) else host.get("ip", "unknown")


def run(host, user, password, args, executor, become=False):
    """YUM module for RedHat/CentOS systems"""

    host_id = get_host_id(host)
    packages = args.get("name")

    if isinstance(packages, str):
        packages = [packages]
    elif isinstance(packages, list):
        pass
    else:
        return {"host": host_id, "output": "", "error": "Package name must be string or list"}

    state = args.get("state", "present")
    update_cache = args.get("update_cache", False)

    commands = []

    if update_cache:
        commands.append("yum makecache")

    if state == "present":
        pkg_list = " ".join(packages)
        commands.append(f"yum install -y {pkg_list}")
    elif state == "absent":
        pkg_list = " ".join(packages)
        commands.append(f"yum remove -y {pkg_list}")
    elif state == "latest":
        pkg_list = " ".join(packages)
        commands.append(f"yum update -y {pkg_list}")
    else:
        return {"host": host_id, "output": "", "error": f"Unknown state '{state}' for yum module"}

    if become:
        commands = [sudo_wrap(cmd) for cmd in commands]

    full_command = " && ".join(commands)

    return executor.run_command(host, user, password, full_command)
