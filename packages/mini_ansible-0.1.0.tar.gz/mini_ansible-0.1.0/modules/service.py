def get_host_id(host):
    """Get host identifier for result dict."""
    return host if isinstance(host, str) else host.get("ip", "unknown")


def run(host, user, password, args, executor, become=False):
    """Manage system services."""
    host_id = get_host_id(host)
    service = args.get("name")
    state = args.get("state")

    if not service:
        return {"host": host_id, "output": "", "error": "Service name is required"}

    if state not in ["start", "stop", "restart", "reload", "enable", "disable"]:
        return {"host": host_id, "output": "", "error": f"Invalid state '{state}' for service module"}

    command = f"systemctl {state} {service}"

    if become:
        command = f"sudo {command}"

    return executor.run_command(host, user, password, command)
