import os
import base64
import hashlib
import paramiko


def get_host_id(host):
    """Get host identifier for result dict."""
    return host if isinstance(host, str) else host.get("ip", "unknown")


def get_connection_type(host):
    """Get connection type from host config."""
    if isinstance(host, dict):
        return host.get("connection", "password")
    return "password"


def file_checksum(host, user, password, path, executor):
    """Calculate remote file checksum."""
    cmd = f"sha256sum {path} 2>/dev/null || echo 'FILE_NOT_FOUND'"
    result = executor.run_command(host, user, password, cmd)
    if "FILE_NOT_FOUND" in result.get("output", "") or result.get("error"):
        return None
    return result.get("output", "").split()[0]


def local_checksum(filepath):
    """Calculate local file checksum."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def copy_via_sftp(host_ip, user, password, src, dest):
    """Copy file using paramiko SFTP (for password auth)."""
    transport = paramiko.Transport((host_ip, 22))
    transport.connect(username=user, password=password)
    sftp = paramiko.SFTPClient.from_transport(transport)
    sftp.put(src, dest)
    sftp.close()
    transport.close()


def copy_via_base64(host, user, password, src, dest, executor):
    """Copy file using base64 encoding (works with any connection type)."""
    with open(src, "rb") as f:
        content = f.read()

    encoded = base64.b64encode(content).decode("ascii")

    # Split into chunks to avoid command line length limits
    chunk_size = 50000
    chunks = [encoded[i:i+chunk_size] for i in range(0, len(encoded), chunk_size)]

    # Write first chunk (create/overwrite file)
    cmd = f"echo '{chunks[0]}' | base64 -d > {dest}"
    result = executor.run_command(host, user, password, cmd)
    if result.get("error"):
        return result

    # Append remaining chunks
    for chunk in chunks[1:]:
        cmd = f"echo '{chunk}' | base64 -d >> {dest}"
        result = executor.run_command(host, user, password, cmd)
        if result.get("error"):
            return result

    return {"output": f"Copied via base64 encoding", "error": ""}


def run(host, user, password, args, executor, become=False):
    """
    Copy a file to the remote host.

    Supports both password and MySSH connections.
    For MySSH, uses base64 encoding since direct SFTP isn't available.
    """
    src = args.get("src")
    dest = args.get("dest")
    mode = args.get("mode")
    owner = args.get("owner")
    group = args.get("group")

    host_id = get_host_id(host)
    connection_type = get_connection_type(host)

    result = {
        "host": host_id,
        "output": "",
        "error": "",
        "changed": False
    }

    if not src or not dest:
        result["error"] = "Missing 'src' or 'dest' in copy module args"
        return result

    if not os.path.exists(src):
        result["error"] = f"Source file '{src}' does not exist"
        return result

    # Check if file already matches
    local_sum = local_checksum(src)
    remote_sum = file_checksum(host, user, password, dest, executor)

    if remote_sum == local_sum:
        result["output"] = "File already up-to-date, skipping copy"
        return result

    # Use temp location then move (for permission handling)
    temp_dest = f"/tmp/{os.path.basename(dest)}.{os.getpid()}"

    try:
        if connection_type == "myssh":
            # Use base64 encoding for MySSH connections
            copy_result = copy_via_base64(host, user, password, src, temp_dest, executor)
            if copy_result.get("error"):
                result["error"] = f"Copy failed: {copy_result['error']}"
                return result
        else:
            # Use SFTP for password connections
            host_ip = host if isinstance(host, str) else host.get("ip")
            copy_via_sftp(host_ip, user, password, src, temp_dest)

        result["output"] = f"Copied '{src}' to '{dest}'"
        result["changed"] = True

    except Exception as e:
        result["error"] = f"Copy failed: {e}"
        return result

    # Move file from temp to final destination
    mv_cmd = f"mv {temp_dest} {dest}"
    if become:
        mv_cmd = f"sudo {mv_cmd}"
    mv_result = executor.run_command(host, user, password, mv_cmd)
    if mv_result.get("error"):
        result["error"] = f"Move failed: {mv_result['error']}"
        return result

    # Set permissions if specified
    if mode:
        cmd = f"chmod {mode} {dest}"
        if become:
            cmd = f"sudo {cmd}"
        chmod_result = executor.run_command(host, user, password, cmd)
        if chmod_result.get("error"):
            result["error"] += f"\nchmod error: {chmod_result['error']}"

    # Set ownership if specified
    if owner or group:
        chown_str = f"{owner or ''}:{group or ''}"
        cmd = f"chown {chown_str} {dest}"
        if become:
            cmd = f"sudo {cmd}"
        chown_result = executor.run_command(host, user, password, cmd)
        if chown_result.get("error"):
            result["error"] += f"\nchown error: {chown_result['error']}"

    return result
