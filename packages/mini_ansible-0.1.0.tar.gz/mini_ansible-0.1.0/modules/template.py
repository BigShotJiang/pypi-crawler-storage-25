from utils.sudo import sudo_wrap


def get_host_id(host):
    """Get host identifier for result dict."""
    return host if isinstance(host, str) else host.get("ip", "unknown")


def run(host, user, password, args, executor, become=False):
    """Template module - simplified version"""

    host_id = get_host_id(host)
    src = args.get("src")
    dest = args.get("dest")

    if not src or not dest:
        return {"host": host_id, "output": "", "error": "Both src and dest are required for template module"}

    commands = [f"cp {src} {dest}"]

    mode = args.get("mode")
    owner = args.get("owner")
    group = args.get("group")

    if mode:
        commands.append(f"chmod {mode} {dest}")

    if owner:
        if group:
            commands.append(f"chown {owner}:{group} {dest}")
        else:
            commands.append(f"chown {owner} {dest}")
    elif group:
        commands.append(f"chgrp {group} {dest}")

    if become:
        commands = [sudo_wrap(cmd) for cmd in commands]

    full_command = " && ".join(commands)

    return executor.run_command(host, user, password, full_command)
