import argparse
import sys
from core.inventory import get_inventory
from core.task_runner import load_playbook, run_playbook


def main():
    parser = argparse.ArgumentParser(
        description="Mini Ansible - Lightweight automation tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with traditional inventory (password auth)
  mini-ansible run playbook.yaml --inventory inventory.ini

  # Run with MySSH connection
  mini-ansible run playbook.yaml --inventory myssh-inventory.ini --myssh-org my-org

  # MySSH inventory format:
  # [webservers:vars]
  # connection=myssh
  #
  # [webservers]
  # node-hostname-1
  # a3f8b2c1d4e5
"""
    )
    parser.add_argument("command", choices=["run"], help="Command to execute")
    parser.add_argument("playbook", help="Path to YAML playbook file")
    parser.add_argument(
        "--inventory", "-i",
        default="./examples/inventory.ini",
        help="Path to inventory file"
    )
    parser.add_argument(
        "--myssh-org",
        help="Default MySSH organization ID or slug (overrides inventory/playbook)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )

    args = parser.parse_args()

    if args.command == "run":
        try:
            hosts = get_inventory(args.inventory)
            playbook = load_playbook(args.playbook)
            run_playbook(hosts, playbook, myssh_org=args.myssh_org)
        except FileNotFoundError as e:
            print(f"Error: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"Error: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)


if __name__ == "__main__":
    main()
