"""
Inventory parser for Mini Ansible.

Supports two inventory formats:

1. Traditional password-based:
   [groupname]
   ip username password

2. MySSH Zero-Trust:
   [groupname:vars]
   connection=myssh
   myssh_org=my-org-slug

   [groupname]
   node-hostname
   a3f8b2c1d4e5  # Node ID

3. Mixed inventory:
   [servers]
   192.168.1.10 ubuntu password
   my-myssh-node connection=myssh myssh_org=prod
"""

from typing import Dict, List, Any, Optional


def parse_host_line(line: str, group_vars: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Parse a single host line from the inventory.

    Supports formats:
    - ip username password
    - ip username password key=value ...
    - hostname connection=myssh myssh_org=org
    - hostname (with group_vars providing connection settings)
    """
    parts = line.split()
    host: Dict[str, Any] = {}

    # Extract key=value pairs from the line
    inline_vars = {}
    remaining_parts = []
    for part in parts:
        if "=" in part:
            key, value = part.split("=", 1)
            inline_vars[key] = value
        else:
            remaining_parts.append(part)

    # Apply group vars first (lower priority)
    if group_vars:
        for key, value in group_vars.items():
            if key == "connection":
                host["connection"] = value
            elif key == "myssh_org":
                host["myssh_org"] = value
            else:
                host.setdefault("extra_vars", {})[key] = value

    # Apply inline vars (higher priority)
    for key, value in inline_vars.items():
        if key == "connection":
            host["connection"] = value
        elif key == "myssh_org":
            host["myssh_org"] = value
        elif key == "myssh_node_id":
            host["myssh_node_id"] = value
        else:
            host.setdefault("extra_vars", {})[key] = value

    # Parse remaining parts based on connection type
    connection = host.get("connection", "password")

    if connection == "myssh":
        # MySSH: just hostname or node ID
        if remaining_parts:
            host["ip"] = remaining_parts[0]  # hostname or node ID
            host["username"] = remaining_parts[1] if len(remaining_parts) > 1 else ""
        host["password"] = None
    else:
        # Traditional: ip username password
        if len(remaining_parts) >= 3:
            host["ip"] = remaining_parts[0]
            host["username"] = remaining_parts[1]
            host["password"] = remaining_parts[2]
        elif len(remaining_parts) == 2:
            host["ip"] = remaining_parts[0]
            host["username"] = remaining_parts[1]
            host["password"] = ""
        elif len(remaining_parts) == 1:
            host["ip"] = remaining_parts[0]
            host["username"] = ""
            host["password"] = ""

    return host


def get_inventory(path: str = "./examples/inventory.ini") -> Dict[str, List[Dict[str, Any]]]:
    """
    Parse an inventory file.

    Args:
        path: Path to the inventory file

    Returns:
        Dictionary mapping group names to lists of host dictionaries
    """
    inventory: Dict[str, List[Dict[str, Any]]] = {}
    current_group: Optional[str] = None
    group_vars: Dict[str, Dict[str, str]] = {}  # group -> {var: value}
    is_vars_section = False

    with open(path, "r") as inventory_file:
        for line in inventory_file:
            line = line.strip()

            # Skip empty lines and comments (# and ; are comment characters)
            if not line or line.startswith("#") or line.startswith(";"):
                continue

            # Check for group header
            if line.startswith("[") and line.endswith("]"):
                header = line[1:-1].strip()

                # Check for :vars suffix
                if ":vars" in header:
                    # This is a variables section
                    group_name = header.split(":vars")[0].strip()
                    is_vars_section = True
                    if group_name not in group_vars:
                        group_vars[group_name] = {}
                    current_group = group_name
                else:
                    # Regular group header
                    is_vars_section = False
                    current_group = header
                    if current_group not in inventory:
                        inventory[current_group] = []
                continue

            # Handle vars section
            if is_vars_section and current_group:
                if "=" in line:
                    key, value = line.split("=", 1)
                    group_vars[current_group][key.strip()] = value.strip()
                continue

            # Handle host line
            if current_group is None:
                current_group = "ungrouped"
                if current_group not in inventory:
                    inventory[current_group] = []

            # Get group-specific vars
            gvars = group_vars.get(current_group, {})

            # Parse the host line
            host = parse_host_line(line, gvars)
            if host.get("ip"):
                inventory[current_group].append(host)

    return inventory


def get_hosts_for_group(
    inventory: Dict[str, List[Dict[str, Any]]],
    group: str
) -> List[Dict[str, Any]]:
    """
    Get all hosts for a specific group.

    Args:
        inventory: Parsed inventory dictionary
        group: Group name, or "all" for all hosts

    Returns:
        List of host dictionaries with 'group' field added
    """
    if group == "all":
        hosts = []
        for group_name, group_hosts in inventory.items():
            for host in group_hosts:
                host_with_group = host.copy()
                host_with_group["group"] = group_name
                hosts.append(host_with_group)
        return hosts
    else:
        group_hosts = inventory.get(group, [])
        hosts = []
        for host in group_hosts:
            host_with_group = host.copy()
            host_with_group["group"] = group
            hosts.append(host_with_group)
        return hosts
