"""
MySSH Zero-Trust connection provider.

This provider connects to remote hosts through MySSH using the myssh CLI.
All authentication, certificate issuance, and tunneling is handled by the CLI.

Environment variables for CI/CD:
    MYSSH_SERVICE_TOKEN: SSH service token (created via `myssh ssh-token create`)
    MYSSH_ORG_ID: Organization ID (required when using service token)
    MYSSH_API_URL: Optional API URL override (default: production)

Usage in CI:
    export MYSSH_SERVICE_TOKEN=ssh_svc_...
    export MYSSH_ORG_ID=your-org-id
    mini-ansible run playbook.yml --inventory inventory.ini
"""

import json
import os
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict, Any

from ..connection import (
    ConnectionProvider,
    SSHConnection,
    HostConfig,
    CommandResult,
)


class MySSHProvider(ConnectionProvider):
    """
    Connection provider using MySSH CLI.

    Uses `myssh run` for command execution and `myssh cp` for file transfers.
    """

    CONFIG_PATH = Path.home() / ".myssh" / "config.json"

    def __init__(
        self,
        default_org: Optional[str] = None,
        session_ttl: int = 30,
        **kwargs
    ):
        self.default_org = default_org
        self.session_ttl = min(max(1, session_ttl), 60)
        self._active_org_id: Optional[str] = None

        # Verify myssh CLI is available
        if not shutil.which("myssh"):
            raise ConnectionError(
                "myssh CLI not found. Install it first."
            )

        # Load config to get active org
        self._load_config()

    def _load_config(self):
        """Load MySSH config for org resolution."""
        if not self.CONFIG_PATH.exists():
            raise ConnectionError(
                "Not authenticated with MySSH. Run: myssh login"
            )

        try:
            with open(self.CONFIG_PATH) as f:
                config = json.load(f)
                self._active_org_id = config.get("activeOrgId")
        except (json.JSONDecodeError, IOError) as e:
            raise ConnectionError(f"Failed to read MySSH config: {e}")

    def _get_org_id(self, host_config: HostConfig) -> str:
        """Resolve the organization ID to use."""
        if host_config.myssh_org:
            return host_config.myssh_org
        if self.default_org:
            return self.default_org
        if self._active_org_id:
            return self._active_org_id

        raise ConnectionError(
            "No MySSH organization specified. Set myssh_org in inventory "
            "or run: myssh org switch"
        )

    def connect(self, host_config: HostConfig) -> "MySSHConnection":
        """Create a connection wrapper for the host."""
        # The myssh CLI handles all the complexity
        # We just need to track the node identifier
        node_id = host_config.myssh_node_id or host_config.ip

        return MySSHConnection(
            host_config=host_config,
            node_id=node_id,
            session_ttl=self.session_ttl
        )

    def close(self, connection: SSHConnection):
        if hasattr(connection, "close"):
            connection.close()


class MySSHConnection(SSHConnection):
    """SSH connection through MySSH CLI."""

    def __init__(
        self,
        host_config: HostConfig,
        node_id: str,
        session_ttl: int
    ):
        self.host_config = host_config
        self.node_id = node_id
        self.session_ttl = session_ttl
        self.metadata = {"node_id": node_id}
        self._closed = False

    @property
    def host(self) -> str:
        return self.node_id

    @property
    def username(self) -> str:
        return self.host_config.username or "ubuntu"

    def exec_command(self, command: str, timeout: Optional[int] = None):
        """Execute command, return (stdin, stdout, stderr)."""
        if self._closed:
            raise RuntimeError("Connection is closed")

        result = self.run_command(command, timeout)

        class FakeStream:
            def __init__(self, data, exit_code=None):
                self._data = data.encode() if isinstance(data, str) else data
                if exit_code is not None:
                    self.channel = type("Ch", (), {"recv_exit_status": lambda: exit_code})()

            def read(self):
                return self._data

        return (
            FakeStream(b""),
            FakeStream(result.output or "", result.return_code),
            FakeStream(result.error or "")
        )

    def run_command(self, command: str, timeout: Optional[int] = None) -> CommandResult:
        """Execute command using myssh run CLI."""
        result = CommandResult(host=self.host)

        # Build myssh run command
        cli_args = [
            "myssh", "run",
            self.node_id,
            command,
            "--ttl", str(self.session_ttl),
            "--quiet"  # Only output command result
        ]

        try:
            proc = subprocess.run(
                cli_args,
                capture_output=True,
                timeout=timeout or 300
            )
            result.output = proc.stdout.decode().strip()
            result.error = proc.stderr.decode().strip()
            result.return_code = proc.returncode
            result.failed = proc.returncode != 0
        except subprocess.TimeoutExpired:
            result.error = f"Command timed out after {timeout}s"
            result.failed = True
            result.unreachable = True
        except FileNotFoundError:
            result.error = "myssh CLI not found"
            result.failed = True
            result.unreachable = True
        except Exception as e:
            result.error = str(e)
            result.failed = True

        return result

    def copy_file(self, local_path: str, remote_path: str, mode: Optional[int] = None) -> CommandResult:
        """Copy file using myssh cp CLI."""
        result = CommandResult(host=self.host)

        # Build myssh cp command: myssh cp <source> <node>:<dest>
        destination = f"{self.node_id}:{remote_path}"
        cli_args = [
            "myssh", "cp",
            local_path,
            destination,
            "--ttl", str(self.session_ttl),
            "--quiet"
        ]

        try:
            proc = subprocess.run(
                cli_args,
                capture_output=True,
                timeout=120
            )
            if proc.returncode == 0:
                result.changed = True
                # Set mode if specified
                if mode:
                    chmod_result = self.run_command(f"chmod {oct(mode)[2:]} {remote_path}")
                    if chmod_result.failed:
                        result.error = f"File copied but chmod failed: {chmod_result.error}"
            else:
                result.error = proc.stderr.decode().strip()
                result.failed = True
        except subprocess.TimeoutExpired:
            result.error = "File copy timed out"
            result.failed = True
        except FileNotFoundError:
            result.error = "myssh CLI not found"
            result.failed = True
        except Exception as e:
            result.error = str(e)
            result.failed = True

        return result

    def open_sftp(self):
        raise NotImplementedError("Use copy_file() instead")

    def close(self):
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False
