"""
Password-based SSH connection provider.

This is the default connection provider that uses traditional
username/password authentication via paramiko.
"""

import socket
import paramiko
from paramiko.ssh_exception import (
    SSHException,
    AuthenticationException,
    NoValidConnectionsError
)

from ..connection import (
    ConnectionProvider,
    SSHConnection,
    HostConfig,
    CommandResult,
)


class PasswordProvider(ConnectionProvider):
    """
    Connection provider using password authentication.

    This provider establishes SSH connections using username/password
    credentials stored in the inventory.
    """

    def __init__(self, timeout: int = 10):
        """
        Initialize the password provider.

        Args:
            timeout: Connection timeout in seconds (default: 10)
        """
        self.timeout = timeout

    def connect(self, host_config: HostConfig) -> SSHConnection:
        """
        Establish an SSH connection using password authentication.

        Args:
            host_config: Host configuration with IP, username, and password.

        Returns:
            SSHConnection wrapper around the paramiko client.

        Raises:
            ConnectionError: If the connection fails.
        """
        if not host_config.password:
            raise ConnectionError(
                f"Password required for host {host_config.ip} "
                "(password provider does not support key-based auth)"
            )

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            client.connect(
                hostname=host_config.ip,
                username=host_config.username,
                password=host_config.password,
                timeout=self.timeout,
                look_for_keys=False,
                allow_agent=False
            )
        except AuthenticationException:
            raise ConnectionError(
                f"Authentication failed for host {host_config.ip}"
            )
        except NoValidConnectionsError as e:
            raise ConnectionError(
                f"Connection failed for host {host_config.ip}: {e}"
            )
        except socket.timeout:
            raise ConnectionError(
                f"Connection to host {host_config.ip} timed out"
            )
        except SSHException as e:
            raise ConnectionError(
                f"SSH error on host {host_config.ip}: {e}"
            )
        except Exception as e:
            raise ConnectionError(
                f"Unexpected error connecting to {host_config.ip}: {e}"
            )

        return SSHConnection(client, host_config)


def run_command(host, user, password, command):
    """
    Legacy function for backward compatibility with existing modules.

    This function maintains the original executor.py interface while
    using the new provider system internally.

    Args:
        host: IP address or hostname
        user: SSH username
        password: SSH password
        command: Command to execute

    Returns:
        Dict with 'host', 'output', and 'error' keys.
    """
    result = {
        "host": host,
        "output": "",
        "error": ""
    }

    host_config = HostConfig(
        ip=host,
        username=user,
        password=password
    )

    provider = PasswordProvider()

    try:
        connection = provider.connect(host_config)
        try:
            cmd_result = provider.run_command(connection, command)
            result["output"] = cmd_result.output
            result["error"] = cmd_result.error
        finally:
            provider.close(connection)
    except ConnectionError as e:
        result["error"] = str(e)

    return result
