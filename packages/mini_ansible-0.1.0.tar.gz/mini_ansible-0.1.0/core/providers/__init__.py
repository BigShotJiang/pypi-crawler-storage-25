"""
Connection providers for Mini Ansible.

Available providers:
- password: Traditional SSH with username/password authentication
- myssh: MySSH Zero-Trust proxy with certificate authentication
"""

from typing import Optional
from ..connection import ConnectionProvider, ConnectionManager


def get_provider(name: str, **kwargs) -> ConnectionProvider:
    """
    Get a connection provider by name.

    Args:
        name: Provider name ("password" or "myssh")
        **kwargs: Provider-specific configuration

    Returns:
        ConnectionProvider instance

    Raises:
        ValueError: If the provider name is unknown
    """
    if name == "password":
        from .password import PasswordProvider
        return PasswordProvider(**kwargs)
    elif name == "myssh":
        from .myssh import MySSHProvider
        return MySSHProvider(**kwargs)
    else:
        raise ValueError(f"Unknown connection provider: {name}")


def create_connection_manager(
    myssh_org: Optional[str] = None,
    myssh_api_url: Optional[str] = None
) -> ConnectionManager:
    """
    Create a ConnectionManager with all available providers registered.

    Args:
        myssh_org: Default MySSH organization ID/slug
        myssh_api_url: MySSH API URL (defaults to env var or localhost)

    Returns:
        ConnectionManager with providers registered
    """
    manager = ConnectionManager()

    # Always register password provider
    manager.register_provider("password", get_provider("password"))

    # Register MySSH provider if possible
    try:
        myssh_kwargs = {}
        if myssh_org:
            myssh_kwargs["default_org"] = myssh_org
        if myssh_api_url:
            myssh_kwargs["api_url"] = myssh_api_url
        manager.register_provider("myssh", get_provider("myssh", **myssh_kwargs))
    except Exception:
        # MySSH provider may not be available (e.g., missing dependencies or config)
        pass

    return manager


__all__ = [
    "get_provider",
    "create_connection_manager",
    "ConnectionProvider",
    "ConnectionManager",
]
