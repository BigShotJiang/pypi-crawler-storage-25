"""
Connection provider abstraction for Mini Ansible.

Supports multiple connection backends:
- password: Traditional SSH with username/password (default)
- myssh: MySSH Zero-Trust proxy with certificate authentication
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import paramiko


@dataclass
class CommandResult:
    """Result of executing a remote command."""
    host: str
    output: str = ""
    error: str = ""
    changed: bool = False
    failed: bool = False
    unreachable: bool = False
    skipped: bool = False
    return_code: int = 0


@dataclass
class HostConfig:
    """Configuration for a single host."""
    ip: str
    username: str
    password: Optional[str] = None
    group: str = "ungrouped"
    connection: str = "password"  # "password" or "myssh"
    myssh_org: Optional[str] = None
    myssh_node_id: Optional[str] = None
    extra_vars: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "HostConfig":
        """Create HostConfig from a dictionary."""
        return cls(
            ip=data.get("ip", data.get("hostname", "")),
            username=data.get("username", ""),
            password=data.get("password"),
            group=data.get("group", "ungrouped"),
            connection=data.get("connection", "password"),
            myssh_org=data.get("myssh_org"),
            myssh_node_id=data.get("myssh_node_id"),
            extra_vars=data.get("extra_vars", {})
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for backward compatibility."""
        return {
            "ip": self.ip,
            "username": self.username,
            "password": self.password,
            "group": self.group,
            "connection": self.connection,
            "myssh_org": self.myssh_org,
            "myssh_node_id": self.myssh_node_id,
            **self.extra_vars
        }


class SSHConnection:
    """Wrapper around an SSH connection."""

    def __init__(
        self,
        client: paramiko.SSHClient,
        host_config: HostConfig,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.client = client
        self.host_config = host_config
        self.metadata = metadata or {}
        self._closed = False

    @property
    def host(self) -> str:
        return self.host_config.ip

    @property
    def username(self) -> str:
        return self.host_config.username

    def exec_command(self, command: str, timeout: Optional[int] = None) -> tuple:
        """Execute a command on the remote host."""
        if self._closed:
            raise RuntimeError("Connection is closed")
        return self.client.exec_command(command, timeout=timeout)

    def open_sftp(self) -> paramiko.SFTPClient:
        """Open an SFTP session."""
        if self._closed:
            raise RuntimeError("Connection is closed")
        return self.client.open_sftp()

    def close(self):
        """Close the connection."""
        if not self._closed:
            try:
                self.client.close()
            except Exception:
                pass
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


class ConnectionProvider(ABC):
    """Abstract base class for connection providers."""

    @abstractmethod
    def connect(self, host_config: HostConfig) -> SSHConnection:
        """
        Establish a connection to the host.

        Args:
            host_config: Configuration for the host to connect to.

        Returns:
            SSHConnection wrapper around the established connection.

        Raises:
            ConnectionError: If the connection cannot be established.
        """
        pass

    def run_command(
        self,
        connection: SSHConnection,
        command: str,
        timeout: Optional[int] = None
    ) -> CommandResult:
        """
        Execute a command on the remote host.

        Args:
            connection: Active SSH connection.
            command: Command to execute.
            timeout: Optional timeout in seconds.

        Returns:
            CommandResult with output and status.
        """
        result = CommandResult(host=connection.host)

        try:
            stdin, stdout, stderr = connection.exec_command(command, timeout=timeout)
            result.output = stdout.read().decode().strip()
            result.error = stderr.read().decode().strip()
            result.return_code = stdout.channel.recv_exit_status()
            result.failed = result.return_code != 0
        except Exception as e:
            result.error = str(e)
            result.failed = True
            if "timeout" in str(e).lower():
                result.unreachable = True

        return result

    def copy_file(
        self,
        connection: SSHConnection,
        local_path: str,
        remote_path: str,
        mode: Optional[int] = None
    ) -> CommandResult:
        """
        Copy a file to the remote host.

        Args:
            connection: Active SSH connection.
            local_path: Path to the local file.
            remote_path: Destination path on the remote host.
            mode: Optional file permissions (e.g., 0o644).

        Returns:
            CommandResult indicating success or failure.
        """
        result = CommandResult(host=connection.host)

        try:
            sftp = connection.open_sftp()
            sftp.put(local_path, remote_path)
            if mode is not None:
                sftp.chmod(remote_path, mode)
            sftp.close()
            result.changed = True
        except Exception as e:
            result.error = str(e)
            result.failed = True

        return result

    def close(self, connection: SSHConnection):
        """Close the connection."""
        connection.close()


class ConnectionManager:
    """Manages connections across multiple hosts with caching."""

    def __init__(self):
        self._providers: Dict[str, ConnectionProvider] = {}
        self._connections: Dict[str, SSHConnection] = {}

    def register_provider(self, name: str, provider: ConnectionProvider):
        """Register a connection provider."""
        self._providers[name] = provider

    def get_provider(self, name: str) -> ConnectionProvider:
        """Get a registered provider by name."""
        if name not in self._providers:
            raise ValueError(f"Unknown connection provider: {name}")
        return self._providers[name]

    def get_connection(self, host_config: HostConfig) -> SSHConnection:
        """
        Get or create a connection for a host.

        Connections are cached by host IP to allow reuse within a playbook run.
        """
        cache_key = f"{host_config.connection}:{host_config.ip}"

        if cache_key in self._connections:
            conn = self._connections[cache_key]
            if not conn._closed:
                return conn

        provider = self.get_provider(host_config.connection)
        connection = provider.connect(host_config)
        self._connections[cache_key] = connection
        return connection

    def close_all(self):
        """Close all cached connections."""
        for conn in self._connections.values():
            try:
                conn.close()
            except Exception:
                pass
        self._connections.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_all()
        return False
