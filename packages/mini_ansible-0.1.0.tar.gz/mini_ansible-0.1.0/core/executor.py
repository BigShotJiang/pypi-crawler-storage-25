"""
Command execution for Mini Ansible.

This module provides functions for executing commands on remote hosts.
It supports both the legacy function-based interface and the new
ConnectionProvider interface.
"""

import paramiko
from paramiko.ssh_exception import SSHException, AuthenticationException, NoValidConnectionsError
import socket
from typing import Optional, Dict, Any

from .connection import HostConfig, CommandResult, SSHConnection
from .providers import create_connection_manager, get_provider


# Global connection manager for reusing connections within a playbook run
_connection_manager = None


def get_connection_manager(myssh_org: Optional[str] = None):
    """Get or create the global connection manager."""
    global _connection_manager
    if _connection_manager is None:
        _connection_manager = create_connection_manager(myssh_org=myssh_org)
    return _connection_manager


def reset_connection_manager():
    """Reset the global connection manager (for testing or cleanup)."""
    global _connection_manager
    if _connection_manager is not None:
        _connection_manager.close_all()
        _connection_manager = None


def run_command(host, user, password, command):
    """
    Legacy function for backward compatibility with existing modules.

    This function maintains the original interface while supporting
    both password and MySSH connections through the host dictionary.

    Args:
        host: IP address, hostname, or host dictionary with connection info
        user: SSH username (ignored if host is a dict with username)
        password: SSH password (ignored for MySSH connections)
        command: Command to execute

    Returns:
        Dict with 'host', 'output', and 'error' keys.
    """
    result = {
        "host": host if isinstance(host, str) else host.get("ip", "unknown"),
        "output": "",
        "error": ""
    }

    # Handle both dict and positional args
    if isinstance(host, dict):
        host_config = HostConfig.from_dict(host)
    else:
        host_config = HostConfig(
            ip=host,
            username=user,
            password=password
        )

    connection_type = host_config.connection

    try:
        if connection_type == "myssh":
            # Use MySSH provider
            provider = get_provider("myssh")
            connection = provider.connect(host_config)
            try:
                cmd_result = connection.run_command(command)
                result["output"] = cmd_result.output
                result["error"] = cmd_result.error
                if cmd_result.failed:
                    result["failed"] = True
                if cmd_result.changed:
                    result["changed"] = True
            finally:
                provider.close(connection)
        else:
            # Use password provider (original behavior)
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            try:
                ssh.connect(
                    hostname=host_config.ip,
                    username=host_config.username,
                    password=host_config.password,
                    timeout=10
                )
                stdin, stdout, stderr = ssh.exec_command(command)
                result["output"] = stdout.read().decode().strip()
                result["error"] = stderr.read().decode().strip()

            except AuthenticationException:
                result["error"] = f"Authentication failed for host {host_config.ip}."
            except NoValidConnectionsError as e:
                result["error"] = f"Connection failed for host {host_config.ip}: {e}"
            except socket.timeout:
                result["error"] = f"Connection to host {host_config.ip} timed out."
            except SSHException as e:
                result["error"] = f"SSH error on host {host_config.ip}: {e}"
            except Exception as e:
                result["error"] = f"Unexpected error on host {host_config.ip}: {e}"
            finally:
                ssh.close()

    except ConnectionError as e:
        result["error"] = str(e)
    except Exception as e:
        result["error"] = f"Unexpected error: {e}"

    return result


def run_command_with_connection(
    connection: SSHConnection,
    command: str,
    timeout: Optional[int] = None
) -> CommandResult:
    """
    Execute a command using an existing connection.

    This is the preferred method for modules to use as it allows
    connection reuse and supports all connection types.

    Args:
        connection: Active SSH connection
        command: Command to execute
        timeout: Optional timeout in seconds

    Returns:
        CommandResult with output and status
    """
    if hasattr(connection, "run_command"):
        # MySSH connection with run_command method
        return connection.run_command(command, timeout)

    # Standard SSHConnection via paramiko
    result = CommandResult(host=connection.host)

    try:
        stdin, stdout, stderr = connection.exec_command(command, timeout=timeout)
        result.output = stdout.read().decode().strip()
        result.error = stderr.read().decode().strip()
        result.return_code = stdout.channel.recv_exit_status()
        result.failed = result.return_code != 0
    except Exception as e:
        result.error = str(e)
        result.failed = True
        if "timeout" in str(e).lower():
            result.unreachable = True

    return result


def copy_file_with_connection(
    connection: SSHConnection,
    local_path: str,
    remote_path: str,
    mode: Optional[int] = None
) -> CommandResult:
    """
    Copy a file to a remote host using an existing connection.

    Args:
        connection: Active SSH connection
        local_path: Path to local file
        remote_path: Destination path on remote host
        mode: Optional file permissions

    Returns:
        CommandResult indicating success or failure
    """
    if hasattr(connection, "copy_file"):
        # MySSH connection with copy_file method
        return connection.copy_file(local_path, remote_path, mode)

    # Standard SSHConnection via paramiko SFTP
    result = CommandResult(host=connection.host)

    try:
        sftp = connection.open_sftp()
        sftp.put(local_path, remote_path)
        if mode is not None:
            sftp.chmod(remote_path, mode)
        sftp.close()
        result.changed = True
    except Exception as e:
        result.error = str(e)
        result.failed = True

    return result
