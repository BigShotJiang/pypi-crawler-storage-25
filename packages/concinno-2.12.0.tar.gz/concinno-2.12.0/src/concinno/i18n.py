"""concinno.i18n — Internationalization for messages and detection patterns.

@module i18n
@responsibility Centralized locale management. Messages display in user's locale
    (fallback English). Detection patterns merge from ALL active locales.
    Translation glossary provides canonical term rendering per locale.
@dependencies (none — stdlib only)
@exports msg, patterns, get_locale, set_locale, get_active_locales,
         glossary_term, get_glossary

Architecture:
  - locale/*.json contains {"messages": {...}, "patterns": {...}, "glossary": {...}}
  - en.json + zh_TW.json ship as built-in (always loaded for patterns)
  - Users add locales via /locale Skill → new JSON file + CC_UX_LANG env var
  - Messages: display locale → English fallback
  - Patterns: merged from ALL loaded locales (inclusive detection)
  - Glossary: display locale → English → raw term (never raises KeyError)
  - Persistence: ~/.concinno/locale.json stores user's chosen locale so that
    pip install -U does NOT revert a user who switched away from "en".
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

# ── Constants ────────────────────────────────────────────────────

_LOCALE_DIR = Path(__file__).parent / "locale"
_DEFAULT_LOCALE = "en"

# User-level persistence file — never overwritten by pip install.
_LOCALE_FILE = Path.home() / ".concinno" / "locale.json"


def _locale_to_filename(locale: str) -> str:
    """Normalize a BCP-47 locale to the filename form used on disk.

    ``config._VALID_LOCALES`` stores BCP-47 hyphenated strings (``zh-TW``)
    because that is the standard users type into
    ``concinno config set locale``. On disk we ship ``zh_TW.json`` because
    underscores are friendlier across filesystems (e.g. some URL-escape
    setups choke on hyphen + capital combos). Everywhere else in i18n
    uses the filename form as the cache key.
    """
    return locale.replace("-", "_")


def _derive_builtin_locales() -> tuple[str, ...]:
    """Derive the set of builtin locales from :data:`config._VALID_LOCALES`.

    Single source of truth lives in ``concinno.config`` so adding a new
    locale only requires updating one frozenset. Filename-form locales
    (underscored) are returned here; callers load them from disk.

    Falls back to the historical built-in list if the config module is
    unavailable during very early import (should never happen, but keeps
    i18n usable when someone vendors just the i18n file).
    """
    try:
        from concinno.config import _VALID_LOCALES
    except Exception:
        return ("en", "zh_TW", "ja", "ko", "es")
    return tuple(sorted(_locale_to_filename(loc) for loc in _VALID_LOCALES))


# Always loaded for pattern detection. Derived from config._VALID_LOCALES
# so a new locale added there automatically participates here — no more
# drift between the two (fixed 2.6.1, was bug F4 in S5 redteam).
_BUILTIN_LOCALES = _derive_builtin_locales()

# ── Persistence helpers ──────────────────────────────────────────


def _read_persisted_locale() -> str | None:
    """Read the user's persisted locale from ~/.concinno/locale.json.

    Fail-open: corrupted JSON, missing file, or permission denied all
    return None and emit a one-shot stderr warning (never raises).

    Returns:
        Locale string (e.g. "zh_TW") or None if unavailable.
    """
    try:
        if not _LOCALE_FILE.is_file():
            return None
        with open(_LOCALE_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        locale_val = data.get("locale")
        if isinstance(locale_val, str) and locale_val.strip():
            return locale_val.strip()
        return None
    except json.JSONDecodeError:
        try:
            print(
                f"[concinno.i18n] {_LOCALE_FILE} is malformed JSON; "
                "ignoring persisted locale",
                file=sys.stderr,
            )
        except Exception:
            pass
        return None
    except OSError:
        return None


def _write_persisted_locale(code: str) -> None:
    """Atomically write the user's locale choice to ~/.concinno/locale.json.

    Uses a temp-file + os.replace to avoid half-written files on crash.
    Emits a stderr warning on any OS error but never raises.

    Note: This function is ONLY called by set_locale(persist=True).
    pip install / upgrade never calls this function, so the file is
    never overwritten on upgrade.

    Args:
        code: Normalised locale key (e.g. "zh_TW").
    """
    import datetime

    payload = {
        "locale": code,
        "set_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "source": "user",
    }
    try:
        _LOCALE_FILE.parent.mkdir(parents=True, exist_ok=True)
        # Write to a sibling temp file then atomically rename.
        fd, tmp_path = tempfile.mkstemp(
            dir=_LOCALE_FILE.parent, prefix=".locale_", suffix=".tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False)
            os.replace(tmp_path, _LOCALE_FILE)
        except Exception:
            # Clean up temp file if rename failed.
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except OSError as exc:
        try:
            print(
                f"[concinno.i18n] could not persist locale to {_LOCALE_FILE}: {exc}; "
                "locale stored in env only",
                file=sys.stderr,
            )
        except Exception:
            pass


# ── Module state ─────────────────────────────────────────────────

_display_locale: str = ""
_message_cache: dict[str, dict[str, str]] = {}
_pattern_cache: dict[str, dict[str, list[str]]] = {}
_glossary_cache: dict[str, dict[str, str]] = {}
_loaded: bool = False


# ── Loading ──────────────────────────────────────────────────────


def _load_locale_file(
    locale: str,
) -> tuple[dict[str, str], dict[str, list[str]], dict[str, str]]:
    """Load a single locale JSON. Returns (messages, patterns, glossary).

    Args:
        locale: Filename-form locale key (e.g. "zh_TW").

    Returns:
        Three-tuple of (messages dict, patterns dict, glossary dict).
        Any section missing or malformed returns an empty dict for that
        section; never raises.
    """
    path = _LOCALE_DIR / f"{locale}.json"
    if not path.is_file():
        return {}, {}, {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data: dict[str, Any] = json.load(f)
        msgs = data.get("messages", {})
        pats = data.get("patterns", {})
        gloss = data.get("glossary", {})
        if not isinstance(msgs, dict):
            msgs = {}
        if not isinstance(pats, dict):
            pats = {}
        if not isinstance(gloss, dict):
            gloss = {}
        return msgs, pats, gloss
    except (json.JSONDecodeError, OSError):
        return {}, {}, {}


def _resolve_display_locale() -> str:
    """Resolve display locale from layered config → normalize to locale key.

    Priority (first non-empty wins):
      1. ``CC_UX_LANG`` env var — current-session override, always wins.
      2. ``~/.concinno/locale.json`` — persistent user choice that survives
         ``pip install -U concinno`` and process restarts.
      3. :func:`concinno.config.get("locale")` — project/user config stack.
      4. ``_DEFAULT_LOCALE`` ("en") as a last-resort safety net.
    """
    raw: str = os.environ.get("CC_UX_LANG", "").strip()

    if not raw:
        raw = _read_persisted_locale() or ""

    if not raw:
        try:
            from concinno.config import get as _cfg_get

            raw = str(_cfg_get("locale")).strip()
        except Exception:
            raw = _DEFAULT_LOCALE

    if not raw:
        raw = _DEFAULT_LOCALE

    # Normalize: "zh-TW" → "zh_TW", "zh" → "zh_TW", "en" → "en"
    normalized = raw.replace("-", "_")
    if normalized in ("zh", "zh_TW", "zh_tw"):
        return "zh_TW"
    if normalized.startswith("zh"):
        return "zh_TW"
    return normalized


_missing_locale_warned: set[str] = set()


def _ensure_loaded() -> None:
    """Lazy-load all built-in locales + user's display locale.

    Populates _message_cache, _pattern_cache, and _glossary_cache.

    Missing translation files for a declared builtin locale (e.g. user
    added ``fr`` to config._VALID_LOCALES but didn't ship ``fr.json``)
    emit a one-shot stderr warning and fall back silently to English so
    callers still get a usable string — no raise, no chatty spam.
    """
    global _loaded, _display_locale
    if _loaded:
        return

    _display_locale = _resolve_display_locale()

    # Load all built-in locales (for pattern merging)
    for loc in _BUILTIN_LOCALES:
        if loc not in _message_cache:
            msgs, pats, gloss = _load_locale_file(loc)
            _message_cache[loc] = msgs
            _pattern_cache[loc] = pats
            _glossary_cache[loc] = gloss

    # Load user's display locale if not already loaded
    if _display_locale not in _message_cache:
        msgs, pats, gloss = _load_locale_file(_display_locale)
        if msgs or pats or gloss:
            _message_cache[_display_locale] = msgs
            _pattern_cache[_display_locale] = pats
            _glossary_cache[_display_locale] = gloss

    # Warn (once per process) if the user asked for a locale that has
    # no translation file on disk — prevents the silent-English-fallback
    # UX bug where `concinno config set locale fr` seemed to succeed but
    # the user never saw French messages.
    if (
        _display_locale != _DEFAULT_LOCALE
        and not _message_cache.get(_display_locale)
        and _display_locale not in _missing_locale_warned
    ):
        _missing_locale_warned.add(_display_locale)
        try:
            print(
                f"[concinno.i18n] locale {_display_locale!r} has no "
                f"translation file; falling back to {_DEFAULT_LOCALE!r}",
                file=sys.stderr,
            )
        except Exception:
            pass

    _loaded = True


# ── Public API ───────────────────────────────────────────────────


def msg(key: str, **kwargs: Any) -> str:
    """Get a localized message string.

    Lookup order: display locale → English → key itself.
    Supports {placeholder} formatting via kwargs.

    Args:
        key: Message key (e.g. "confidence_gate.deny").
        **kwargs: Format placeholders.

    Returns:
        Formatted message string.
    """
    _ensure_loaded()
    for loc in (_display_locale, _DEFAULT_LOCALE):
        msgs = _message_cache.get(loc, {})
        if key in msgs:
            template = msgs[key]
            return template.format(**kwargs) if kwargs else template
    return key  # Fallback: return key as-is


def patterns(key: str) -> list[str]:
    """Get detection patterns merged from ALL loaded locales.

    Each locale contributes its own patterns for the given key.
    Results are deduplicated while preserving order.

    Args:
        key: Pattern key (e.g. "correction_l1", "research_keywords").

    Returns:
        Merged list of pattern strings from all active locales.
    """
    _ensure_loaded()
    result: list[str] = []
    seen: set[str] = set()
    for pats in _pattern_cache.values():
        for p in pats.get(key, []):
            if p not in seen:
                result.append(p)
                seen.add(p)
    return result


def get_locale() -> str:
    """Return current display locale (e.g. 'en', 'zh_TW')."""
    _ensure_loaded()
    return _display_locale


def get_active_locales() -> list[str]:
    """Return all loaded locale keys (for debugging/status)."""
    _ensure_loaded()
    return list(_pattern_cache.keys())


def set_locale(locale: str, persist: bool = True) -> None:
    """Set display locale and optionally persist to ~/.concinno/locale.json.

    Always sets CC_UX_LANG env var so child processes inherit the choice.
    When persist=True (default), writes ~/.concinno/locale.json so the
    choice survives process restarts and ``pip install -U`` upgrades.
    When persist=False, only mutates the env var (backward-compat path).

    Args:
        locale: Locale key (e.g. "en", "zh_TW", "ja", "ko").
        persist: If True (default), write ~/.concinno/locale.json.
    """
    global _display_locale
    _ensure_loaded()
    normalized = locale.replace("-", "_")
    if normalized in ("zh", "zh_tw"):
        normalized = "zh_TW"
    _display_locale = normalized
    os.environ["CC_UX_LANG"] = normalized

    if normalized not in _message_cache:
        msgs, pats, gloss = _load_locale_file(normalized)
        if msgs:
            _message_cache[normalized] = msgs
        if pats:
            _pattern_cache[normalized] = pats
        if gloss:
            _glossary_cache[normalized] = gloss

    if persist:
        _write_persisted_locale(normalized)


def reload() -> None:
    """Force reload all locales from disk. Use after adding new locale files."""
    global _loaded
    _message_cache.clear()
    _pattern_cache.clear()
    _glossary_cache.clear()
    _loaded = False
    _ensure_loaded()


def locale_dir() -> Path:
    """Return path to locale directory (for Skill to add new locales)."""
    return _LOCALE_DIR


def glossary_term(term: str, locale: str | None = None) -> str:
    """Return the canonical rendering of a term in the given locale.

    Fallback chain: target_locale → "en" → raw term string.
    Never raises KeyError regardless of input.

    Args:
        term: The canonical English term key (e.g. "handoff", "CBUA").
        locale: Locale to use; defaults to current display locale.

    Returns:
        Translated term string, or the original *term* if not found.

    Examples:
        >>> glossary_term("handoff", "zh_TW")
        '交接'
        >>> glossary_term("handoff", "en")
        'handoff'
        >>> glossary_term("unknown_key")
        'unknown_key'
    """
    _ensure_loaded()
    target = locale if locale is not None else _display_locale
    # Normalize (accept "zh-TW" etc.)
    target = target.replace("-", "_")
    if target in ("zh", "zh_tw"):
        target = "zh_TW"

    # 1. Try target locale
    gloss = _glossary_cache.get(target, {})
    if term in gloss:
        return gloss[term]

    # 2. Fall back to English
    en_gloss = _glossary_cache.get(_DEFAULT_LOCALE, {})
    if term in en_gloss:
        return en_gloss[term]

    # 3. Return raw term — never KeyError
    return term


def get_glossary(locale: str | None = None) -> dict[str, str]:
    """Return the full glossary dict for the given locale.

    Merges target-locale entries on top of English entries so the
    returned dict always contains every key defined in "en".
    Missing keys in the target locale fall back to the English value.

    Args:
        locale: Locale to use; defaults to current display locale.

    Returns:
        Dict mapping term keys to their canonical renderings.
    """
    _ensure_loaded()
    target = locale if locale is not None else _display_locale
    target = target.replace("-", "_")
    if target in ("zh", "zh_tw"):
        target = "zh_TW"

    # Start with English as the authoritative key set.
    result = dict(_glossary_cache.get(_DEFAULT_LOCALE, {}))
    if target != _DEFAULT_LOCALE:
        # Overlay target-locale values where they exist.
        result.update(_glossary_cache.get(target, {}))
    return result
