from django.db.models import Count, Exists, OuterRef, Q
from django.db.models.expressions import RawSQL

from wbfdm.models import Instrument


def fix_duplicated_dl_parameters(metric_type: str = "statements", merge_leftovers: bool = False):
    """
    Finds instruments at level 0 sharing duplicate dl_parameters__{metric_type}__parameters,
    nullifies the field for invalid instruments (no active children), then merges duplicates
    into the latest instrument by ID.
    """

    def _process_duplicate_param(param_value):
        base_qs = Instrument.objects.filter(
            **{
                "level": 0,
                f"dl_parameters__{metric_type}__parameters": param_value,
            }
        ).annotate(
            is_valid=Exists(Instrument.objects.filter(parent=OuterRef("pk"), delisted_date__isnull=True)),
            is_family_investable_universe=Exists(
                Instrument.objects.filter(tree_id=OuterRef("tree_id"), is_investable_universe=True)
            ),
        )

        # Nullify parameter and set delisted_date for invalid instruments
        for instrument in base_qs.filter(is_valid=False, is_family_investable_universe=False):
            if instrument.delisted_date is None and instrument.children.exists():
                latest_child = instrument.children.latest("delisted_date")
                instrument.delisted_date = latest_child.delisted_date
                instrument.save()

            instrument.get_descendants(include_self=True).update(
                dl_parameters=RawSQL(
                    "jsonb_set(dl_parameters, ARRAY[%s, 'parameters']::text[], 'null'::jsonb)", [metric_type]
                )
            )
        # Merge all remaining duplicates into the latest instrument
        if merge_leftovers and base_qs.exists():
            ordered_qs = base_qs.order_by(
                "-is_family_investable_universe", "-id"
            )  # we want instrument in an investable universe family first, then order by latest
            latest_instrument = ordered_qs.first()

            for instrument in ordered_qs.exclude(pk=latest_instrument.pk):
                try:
                    latest_instrument.merge(instrument)
                except Exception as e:
                    print(f"Failed to merge instrument {instrument.pk} into {latest_instrument.pk}: {e}")  # noqa

    duplicate_param_values = (
        Instrument.objects.filter(level=0)
        .exclude(
            Q(**{f"dl_parameters__{metric_type}__parameters__isnull": True})
            | Q(**{f"dl_parameters__{metric_type}__parameters": None})
        )
        .values(f"dl_parameters__{metric_type}__parameters")
        .annotate(c=Count(f"dl_parameters__{metric_type}__parameters"))
        .filter(c__gt=1)
        .values_list(f"dl_parameters__{metric_type}__parameters", flat=True)
    )
    for value in duplicate_param_values:
        _process_duplicate_param(value)
