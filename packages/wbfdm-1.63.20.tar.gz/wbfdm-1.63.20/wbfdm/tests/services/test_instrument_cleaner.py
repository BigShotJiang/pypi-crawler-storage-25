from datetime import date
from unittest.mock import patch

import pytest
from django.utils import timezone

from wbfdm.factories import InstrumentFactory
from wbfdm.models import Instrument
from wbfdm.services.instrument_cleaner import fix_duplicated_dl_parameters


@pytest.mark.django_db
class TestFixDuplicatedDlParameters:
    def make_instrument(self, param_value, level=0, **kwargs):
        return InstrumentFactory.create(
            level=level,
            dl_parameters={"statements": {"parameters": param_value}},
            **kwargs,
        )

    # --- Detection ---

    def test_no_duplicates_does_nothing(self):
        self.make_instrument("param_A")
        self.make_instrument("param_B")
        fix_duplicated_dl_parameters()
        assert Instrument.objects.filter(dl_parameters__statements__parameters__isnull=False).count() == 2

    def test_preserves_other_dl_parameters_keys(self):
        """jsonb_set should not touch other keys in dl_parameters."""
        i1 = InstrumentFactory.create(
            level=0,
            delisted_date=date.today(),
            dl_parameters={"statements": {"parameters": "param_A"}, "other_key": "preserved"},
        )
        self.make_instrument("param_A")

        fix_duplicated_dl_parameters()

        i1.refresh_from_db()
        assert i1.dl_parameters["other_key"] == "preserved"

    def test_sets_delisted_date_from_latest_child(self):
        """If instrument has no delisted_date but has children, it should inherit the latest."""
        parent = self.make_instrument("param_A", delisted_date=None)
        InstrumentFactory.create(parent=parent, delisted_date=date.today() - timezone.timedelta(days=10))
        child_late = InstrumentFactory.create(parent=parent, delisted_date=date.today())
        self.make_instrument("param_A")  # second duplicate to trigger processing

        fix_duplicated_dl_parameters()

        parent.refresh_from_db()
        assert parent.delisted_date == child_late.delisted_date

    def test_does_not_override_existing_delisted_date(self):
        """Should not overwrite delisted_date if already set."""
        original_date = date.today() - timezone.timedelta(days=5)
        parent = self.make_instrument("param_A", delisted_date=original_date)
        InstrumentFactory.create(parent=parent, delisted_date=date.today())
        self.make_instrument("param_A")

        fix_duplicated_dl_parameters()

        parent.refresh_from_db()
        assert parent.delisted_date == original_date

    def test_valid_instrument_not_nullified(self):
        """Instrument with active children should not be nullified."""
        i1 = self.make_instrument("param_A")
        InstrumentFactory.create(parent=i1, delisted_date=None)  # active child
        self.make_instrument("param_A")

        fix_duplicated_dl_parameters()

        i1.refresh_from_db()
        assert i1.dl_parameters["statements"]["parameters"] == "param_A"

    # --- Merging ---

    def test_merge_leftovers_false_by_default(self):
        """merge_leftovers=False should skip merging."""
        i1 = self.make_instrument("param_A")
        i2 = self.make_instrument("param_A")

        fix_duplicated_dl_parameters(merge_leftovers=False)

        assert Instrument.objects.filter(pk__in=[i1.pk, i2.pk]).count() == 2

    def test_merge_exception_does_not_abort(self):
        """A merge failure on one instrument should not prevent others from being processed."""
        self.make_instrument("param_A")
        i2 = self.make_instrument("param_A")

        with patch.object(i2.__class__, "merge", side_effect=Exception("merge failed")):
            # Should not raise
            fix_duplicated_dl_parameters(merge_leftovers=True)

    # --- metric_type param ---

    def test_custom_metric_type(self):
        i1 = InstrumentFactory.create(
            level=0,
            delisted_date=date.today(),
            dl_parameters={"financials": {"parameters": "param_A"}},
        )
        InstrumentFactory.create(
            level=0,
            dl_parameters={"financials": {"parameters": "param_A"}},
        )

        fix_duplicated_dl_parameters(metric_type="financials")

        i1.refresh_from_db()
        assert i1.dl_parameters["financials"]["parameters"] is None
