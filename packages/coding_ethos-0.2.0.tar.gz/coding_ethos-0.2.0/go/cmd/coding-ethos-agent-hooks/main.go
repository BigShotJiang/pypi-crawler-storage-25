// SPDX-FileCopyrightText: 2026 Blackcat Informatics Inc. <paudley@blackcat.ca>
// SPDX-License-Identifier: MIT

package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"strings"

	"blackcat.ca/coding-ethos/go/internal/agenthooks"
)

const (
	commandArgIndex   = 1
	commandArgsOffset = 2
)

var errUnknownCommand = errors.New("unknown agent-hooks command")

func main() {
	if len(os.Args) < commandArgsOffset {
		usage()
		os.Exit(commandArgsOffset)
	}

	var err error

	switch os.Args[commandArgIndex] {
	case "print":
		err = printSettings(os.Args[commandArgsOffset:])
	case "sync":
		err = syncSettings(os.Args[commandArgsOffset:])
	case "doctor":
		err = doctorSettings(os.Args[commandArgsOffset:])
	case "verify":
		err = verifySettings(os.Args[commandArgsOffset:])
	default:
		usage()

		err = fmt.Errorf("%w: %s", errUnknownCommand, os.Args[commandArgIndex])
	}

	if err != nil {
		fmt.Fprintf(os.Stderr, "%s\n", err)
		os.Exit(1)
	}
}

func printSettings(args []string) error {
	flags := flag.NewFlagSet("print", flag.ExitOnError)
	hookCommand := flags.String("hook-command", "", "Agent hook command")

	err := flags.Parse(args)
	if err != nil {
		return fmt.Errorf("parse print flags: %w", err)
	}

	err = agenthooks.WriteSettings(os.Stdout, defaultHookCommand(*hookCommand))
	if err != nil {
		return fmt.Errorf("write agent hook settings: %w", err)
	}

	return nil
}

func syncSettings(args []string) error {
	flags := flag.NewFlagSet("sync", flag.ExitOnError)
	root := flags.String("root", ".", "Repository root for agent settings")
	hookCommand := flags.String("hook-command", "", "Agent hook command")

	err := flags.Parse(args)
	if err != nil {
		return fmt.Errorf("parse sync flags: %w", err)
	}

	err = agenthooks.SyncSettings(*root, defaultHookCommand(*hookCommand))
	if err != nil {
		return fmt.Errorf("sync agent hook settings: %w", err)
	}

	return nil
}

func doctorSettings(args []string) error {
	flags := flag.NewFlagSet("doctor", flag.ExitOnError)
	root := flags.String("root", ".", "Repository root for agent settings")
	hookCommand := flags.String("hook-command", "", "Agent hook command")

	err := flags.Parse(args)
	if err != nil {
		return fmt.Errorf("parse doctor flags: %w", err)
	}

	err = agenthooks.DoctorSettings(*root, defaultHookCommand(*hookCommand))
	if err != nil {
		return fmt.Errorf("doctor agent hook settings: %w", err)
	}

	err = writeDoctorReport(os.Stdout)
	if err != nil {
		return err
	}

	return nil
}

func verifySettings(args []string) error {
	flags := flag.NewFlagSet("verify", flag.ExitOnError)
	root := flags.String("root", ".", "Repository root for agent settings")
	hookCommand := flags.String("hook-command", "", "Agent hook command")

	err := flags.Parse(args)
	if err != nil {
		return fmt.Errorf("parse verify flags: %w", err)
	}

	report, err := agenthooks.VerifySettings(*root, defaultHookCommand(*hookCommand))
	if err != nil {
		if encodeErr := writeJSONReport(os.Stdout, report); encodeErr != nil {
			return encodeErr
		}

		return fmt.Errorf("verify agent hook settings: %w", err)
	}

	err = writeJSONReport(os.Stdout, report)
	if err != nil {
		return err
	}

	return nil
}

func defaultHookCommand(hookCommand string) string {
	if strings.TrimSpace(hookCommand) != "" {
		return hookCommand
	}
	runner := strings.TrimSpace(os.Getenv("CODING_ETHOS_RUN_GO_HOOK"))
	if runner == "" {
		return ""
	}

	return runner + " agent-hook"
}

func writeDoctorReport(file *os.File) error {
	payload := map[string]any{
		"status":       "valid",
		"capabilities": agenthooks.ProviderCapabilities(),
	}

	return writeJSONReport(file, payload)
}

func writeJSONReport(file *os.File, payload any) error {
	encoder := json.NewEncoder(file)
	encoder.SetEscapeHTML(false)
	encoder.SetIndent("", "  ")

	err := encoder.Encode(payload)
	if err != nil {
		return fmt.Errorf("encode doctor report: %w", err)
	}

	return nil
}

func usage() {
	fmt.Fprintln(
		os.Stderr,
		"Usage: coding-ethos-agent-hooks <print|sync|doctor|verify> [flags]",
	)
}
