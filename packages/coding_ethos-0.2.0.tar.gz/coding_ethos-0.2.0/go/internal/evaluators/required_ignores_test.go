// SPDX-FileCopyrightText: 2026 Blackcat Informatics Inc. <paudley@blackcat.ca>
// SPDX-License-Identifier: MIT

package evaluators_test

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"

	. "blackcat.ca/coding-ethos/go/internal/evaluators"
)

func TestEvaluateRequiredIgnoresCELAllowsIgnoredPaths(t *testing.T) {
	t.Parallel()

	repo := newRequiredIgnoreRepo(t)
	writeRequiredIgnoreFile(t, repo, ".code-ethos/cache/\n.coding-ethos/\n")
	policyDef := compiledRepoBundle(t).Policies["repo.required_ignores"]

	decisions, err := EvaluateCELExpression(policyDef, Context{
		Cwd:              repo,
		EvaluatorOptions: policyDef.Evaluators[0].Options,
	})
	if err != nil {
		t.Fatalf("evaluate required ignores: %v", err)
	}

	if len(decisions) != 0 {
		t.Fatalf("expected no decisions, got %#v", decisions)
	}
}

func TestEvaluateRequiredIgnoresCELBlocksMissingPaths(t *testing.T) {
	t.Parallel()

	repo := newRequiredIgnoreRepo(t)
	writeRequiredIgnoreFile(t, repo, "*.pyc\n")
	policyDef := compiledRepoBundle(t).Policies["repo.required_ignores"]

	decisions, err := EvaluateCELExpression(policyDef, Context{
		Cwd:              repo,
		EvaluatorOptions: policyDef.Evaluators[0].Options,
	})
	if err != nil {
		t.Fatalf("evaluate required ignores: %v", err)
	}

	if len(decisions) != 1 || decisions[0].Decision != blockDecision {
		t.Fatalf("expected block decision, got %#v", decisions)
	}
}

func TestEvaluateRequiredIgnoresCELUsesConfiguredPaths(t *testing.T) {
	t.Parallel()

	repo := newRequiredIgnoreRepo(t)
	writeRequiredIgnoreFile(t, repo, ".coding-ethos/\n")
	policyDef := compiledRepoBundle(t).Policies["repo.required_ignores"]
	options := map[string]any{}
	for key, value := range policyDef.Evaluators[0].Options {
		options[key] = value
	}
	options["required_ignore_paths"] = []string{"build-cache/"}

	decisions, err := EvaluateCELExpression(policyDef, Context{
		Cwd:              repo,
		EvaluatorOptions: options,
	})
	if err != nil {
		t.Fatalf("evaluate required ignores: %v", err)
	}

	if len(decisions) != 1 || decisions[0].Decision != blockDecision {
		t.Fatalf("expected block decision, got %#v", decisions)
	}
}

func newRequiredIgnoreRepo(t *testing.T) string {
	t.Helper()

	repo := t.TempDir()
	cmd := exec.Command("git", "init")
	cmd.Dir = repo
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("git init: %v\n%s", err, output)
	}

	return repo
}

func writeRequiredIgnoreFile(t *testing.T, repo string, content string) {
	t.Helper()

	path := filepath.Join(repo, ".gitignore")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatalf("write gitignore: %v", err)
	}
}
