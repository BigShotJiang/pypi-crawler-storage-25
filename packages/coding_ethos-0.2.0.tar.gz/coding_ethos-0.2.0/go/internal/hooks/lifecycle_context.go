// SPDX-FileCopyrightText: 2026 Blackcat Informatics Inc. <paudley@blackcat.ca>
// SPDX-License-Identifier: MIT

package hooks

import "strings"

func lifecycleOutput(event Event) *HookSpecificOutput {
	context := lifecycleContext(event)
	if context == "" {
		return nil
	}

	return &HookSpecificOutput{
		HookEventName:     event.HookEventName,
		AdditionalContext: hookOutputNormalizer(event.Cwd).preserveLines(context),
	}
}

func lifecycleContext(event Event) string {
	switch event.HookEventName {
	case "SessionStart":
		return buildGuidanceContext(
			[]string{
				"Load repository conventions, managed toolchain rules, and generated skills before editing.",
			},
			"",
		)
	case "UserPromptSubmit":
		return buildGuidanceContext(
			[]string{
				"Use and maintain a todo list for multi-step work.",
			},
			event.Content(),
		)
	case "PostToolBatch":
		return buildGuidanceContext(
			[]string{
				"Review tool results before continuing.",
				"Update the todo list to reflect completed and remaining work.",
				"Run focused verification after code edits and before broader gates.",
			},
			"",
		)
	case "Stop", "SessionEnd":
		return buildChecklistContext(
			"Before ending:",
			[]string{
				"Do not report completion while planned work remains.",
				"Summarize evidence: files changed, checks run, and unresolved risks.",
				"If hooks or lint failed, keep the failure visible and fix it structurally.",
			},
		)
	case "SubagentStart":
		return buildGuidanceContext(
			[]string{
				"Keep delegated work scoped and concrete.",
				"Do not overwrite edits made by other agents or the user.",
				"Return changed files, verification, and any unresolved risks.",
			},
			event.Content(),
		)
	case "SubagentStop":
		return buildChecklistContext(
			"Before accepting subagent work:",
			[]string{
				"Check the subagent result against the assigned scope.",
				"Integrate only verified changes and preserve unrelated user work.",
				"Record any remaining follow-up explicitly.",
			},
		)
	default:
		return ""
	}
}

func buildChecklistContext(heading string, guidance []string) string {
	lines := []string{heading}
	for _, item := range guidance {
		lines = append(lines, "- "+item)
	}

	return strings.Join(lines, "\n")
}

func buildGuidanceContext(guidance []string, prompt string) string {
	lines := []string{}
	if trimmed := strings.TrimSpace(prompt); trimmed != "" {
		lines = append(lines, "prompt:", trimmed, "")
	}

	lines = append(lines, "guidance:")
	for _, item := range guidance {
		lines = append(lines, "- "+item)
	}

	return strings.Join(lines, "\n")
}
