"""
cli/puvinoise_run.py
─────────────────────
Phase E — `puvinoise run <command>` implementation.

This is the primary developer entrypoint. It is imported lazily from
cli/puvinoise.py so the main CLI stays fast to start.

Design goals (see Phase E spec):
  1. No file-based injection — we do NOT modify the user's source tree.
  2. env_id is required — if PUVINOISE_ENV_ID is not set AND no sidecar
     state file exists, we refuse to run and tell the user what to do.
  3. SDK presence is injected process-wide via sitecustomize.py, so the SDK
     auto-registers before user code runs its first line.
  4. The wrapped process inherits a clean env; we only add what we need.
  5. Exit code + signals are proxied transparently.

Fix 2 — Sitecustomize chaining:
  The generated sitecustomize.py first scans sys.path for any existing
  sitecustomize (at child-process startup time) and exec()s it before
  doing the PUVINoise injection. This prevents collision with user/framework
  sitecustomize files (e.g. pytest, coverage.py, virtualenvs).

Fix 4 — CLI argument handling:
  cmd_run() merges args._unknown_args (set by main() via parse_known_args)
  into the command list so arbitrary user flags pass through transparently.

Fix 5 — env_id source logging:
  _resolve_env_id_with_source() returns (env_id, source_label) and
  run_command() prints the resolved source so developers know where it came from.

Usage:
    puvinoise run python app.py
    puvinoise run --env-id prod-123 --agent-name billing-agent python app.py
    puvinoise run --dry-run python app.py       # print what would run, don't exec
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from importlib import metadata as importlib_metadata
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


SSL_ERROR_PATTERNS = (
    "CERTIFICATE_VERIFY_FAILED",
    "SSL:",
    "unable to get local issuer certificate",
    "SSL_CERT_FILE",
    "certificate verify failed",
)
SDK_PYPI_URL = "https://pypi.org/pypi/puvinoise/json"
SDK_VERSION_CACHE_TTL_SECONDS = 6 * 60 * 60
SDK_VERSION_CACHE_PATH = Path.home() / ".cache" / "puvinoise" / "version_check.json"


def _is_ssl_certificate_issue(text: object) -> bool:
    haystack = str(text or "")
    haystack_lower = haystack.lower()
    return any(pattern.lower() in haystack_lower for pattern in SSL_ERROR_PATTERNS)


def _certifi_installed() -> bool:
    try:
        import certifi  # type: ignore  # noqa: F401
        return True
    except Exception:
        return False


def _print_ssl_certificate_guidance() -> None:
    print(
        "\n[PUVINoise] SSL certificate issue detected.\n\n"
        "This is a common macOS Python environment issue.\n\n"
        "Run the following command to fix it:\n\n"
        "export SSL_CERT_FILE=$(python3 -m certifi)\n\n"
        "Then re-run your agent.",
        file=sys.stderr,
    )
    if not _certifi_installed():
        print(
            "\nIf certifi is not installed, run:\n\n"
            "pip install certifi",
            file=sys.stderr,
        )


def _get_installed_sdk_version() -> Optional[str]:
    for package_name in ("puvinoise-sdk", "puvinoise"):
        try:
            version = str(importlib_metadata.version(package_name)).strip()
            if version:
                return version
        except Exception:
            continue
    return None


def _get_latest_version_cached_or_fetch() -> Optional[str]:
    now = int(time.time())
    try:
        if SDK_VERSION_CACHE_PATH.is_file():
            cached = json.loads(SDK_VERSION_CACHE_PATH.read_text(encoding="utf-8"))
            cached_version = str(cached.get("latest_version", "")).strip()
            checked_at = int(cached.get("checked_at", 0) or 0)
            if cached_version and checked_at > 0 and (now - checked_at) <= SDK_VERSION_CACHE_TTL_SECONDS:
                return cached_version
    except Exception:
        pass

    try:
        req = urllib.request.Request(SDK_PYPI_URL, headers={"User-Agent": "puvinoise-cli/1.0"})
        with urllib.request.urlopen(req, timeout=2.5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        latest = str(((payload or {}).get("info") or {}).get("version") or "").strip()
        if not latest:
            return None
        try:
            SDK_VERSION_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            SDK_VERSION_CACHE_PATH.write_text(
                json.dumps({"latest_version": latest, "checked_at": now}),
                encoding="utf-8",
            )
        except Exception:
            pass
        return latest
    except Exception:
        # Non-blocking behavior by design: version checks should never break runs.
        return None


def _is_update_available(installed: str, latest: str) -> bool:
    try:
        from packaging.version import Version

        return Version(latest) > Version(installed)
    except Exception:
        return False


def _check_sdk_update_notice() -> None:
    installed = _get_installed_sdk_version()
    if not installed:
        return
    latest = _get_latest_version_cached_or_fetch()
    if not latest:
        return
    if _is_update_available(installed, latest):
        print(
            f"[puvinoise] SDK (puvinoise-sdk) update available: {installed} \u2192 {latest}\n"
            "Run: puvinoise upgrade-sdk",
            file=sys.stderr,
        )


def _run_upgrade_sdk() -> int:
    try:
        return subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "puvinoise-sdk"],
            check=False,
        ).returncode
    except Exception as exc:  # noqa: BLE001
        print(f"[puvinoise] SDK upgrade failed (non-fatal): {exc}", file=sys.stderr)
        return 1


def _run_child_with_ssl_detection(command: List[str], child_env: Dict[str, str]) -> int:
    """Run child process, tee output, and print SSL guidance only when matching errors appear."""
    captured: List[str] = []
    captured_chars = 0
    max_capture_chars = 200_000

    def remember(chunk: str) -> None:
        nonlocal captured_chars
        if captured_chars >= max_capture_chars:
            return
        room = max_capture_chars - captured_chars
        piece = chunk[:room]
        captured.append(piece)
        captured_chars += len(piece)

    try:
        proc = subprocess.Popen(
            command,
            env=child_env,
            stdin=None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
    except Exception as exc:  # noqa: BLE001
        if _is_ssl_certificate_issue(exc):
            _print_ssl_certificate_guidance()
        raise

    def pump(stream, target) -> None:
        if stream is None:
            return
        try:
            for line in iter(stream.readline, ""):
                remember(line)
                target.write(line)
                target.flush()
        finally:
            try:
                stream.close()
            except Exception:
                pass

    threads = [
        threading.Thread(target=pump, args=(proc.stdout, sys.stdout), daemon=True),
        threading.Thread(target=pump, args=(proc.stderr, sys.stderr), daemon=True),
    ]
    for thread in threads:
        thread.start()
    returncode = proc.wait()
    for thread in threads:
        thread.join()
    if _is_ssl_certificate_issue("".join(captured)):
        _print_ssl_certificate_guidance()
    return returncode


# ─── Fix 2: sitecustomize chain header ────────────────────────────────────────
# Injected at the TOP of the generated sitecustomize.py.
# At child-process startup, this scans the *real* sys.path for an existing
# sitecustomize and exec()s it before PUVINoise init runs.  The scan is
# performed at runtime (inside the child), not here, so it sees the child's
# actual sys.path regardless of what the parent process had.
_SITECUSTOMIZE_CHAIN_HEADER = """\
# puvinoise run — sitecustomize chaining (Fix 2)
# Execute any existing sitecustomize.py from the *real* sys.path first,
# so we do not accidentally suppress user or framework sitecustomize hooks
# (e.g. pytest-cov, virtualenvs, editable installs).
import sys as _sc_sys
import os as _sc_os

_sc_this_dir = _sc_os.path.dirname(_sc_os.path.abspath(__file__))
for _sc_entry in list(_sc_sys.path):
    if _sc_entry == _sc_this_dir:
        continue
    _sc_candidate = _sc_os.path.join(_sc_entry, "sitecustomize.py")
    if _sc_os.path.isfile(_sc_candidate):
        try:
            with open(_sc_candidate, "r", encoding="utf-8") as _sc_fh:
                exec(compile(_sc_fh.read(), _sc_candidate, "exec"), {})  # noqa: S102
        except Exception as _sc_exc:
            _sc_sys.stderr.write(
                f"[puvinoise-run] warning: chained sitecustomize raised: {_sc_exc}\\n"
            )
        break
del _sc_sys, _sc_os, _sc_this_dir
# ── end chaining ──────────────────────────────────────────────────────────────

"""

PRELOAD_SNIPPET = """\
# puvinoise run — auto-generated preload (strict identity contract v1.0)
#
# REGISTRATION RULE (NON-NEGOTIABLE):
#   This snippet runs inside the child process (sitecustomize.py).
#   It MUST NOT attempt agent registration under any circumstances.
#   Registration is EXCLUSIVELY the responsibility of the parent process
#   via _maybe_auto_register(), which runs before this process is spawned.
#   If no agent_<id>.json exists here: warn and stop. Do NOT call any registration endpoint.
#
# Identity source: .puvinoise/agent_<id>.json ONLY (written by parent).
# No env-var fallback. No registration. No side effects.
import sys as _sys

try:
    import puvinoise as _puvi
    import os as _os
    from pathlib import Path as _Path

    _workdir = _Path(_os.getcwd())
    _state = {}

    try:
        from puvinoise.agent_state import load_agent_state as _load_agent_state
        _state, _state_path = _load_agent_state(_workdir)
    except Exception as _re:
        _sys.stderr.write(f"[puvinoise] state load failed: {_re}\\n")
        _state = {}

    if not _state:
        # No agent_<id>.json found — parent registration did not complete.
        # DO NOT attempt registration here. Log and skip SDK init.
        _sys.stderr.write(
            "[puvinoise] WARNING: no agent state found in .puvinoise/ — SDK init skipped.\\n"
            "  The parent process should have registered the agent before spawning.\\n"
            "  Fix: run 'puvinoise-bind --env-only' then 'puvinoise run <command>'.\\n"
        )
    else:
        _api_key = str(_state.get("api_key", "")).strip()
        _tenant_id = str(_state.get("tenant_id", "")).strip()
        _agent_id = str(_state.get("agent_id", "")).strip()
        _env_id = str(_state.get("env_id", "")).strip()
        _agent_name = str(
            _state.get("agent_name", "")
            or _os.environ.get("PUVINOISE_AGENT_NAME", "")
            or "puvinoise-agent"
        ).strip()

        if not _api_key:
            _sys.stderr.write(
                "[puvinoise] CRITICAL: agent state found but api_key is empty — SDK init skipped.\\n"
                "  Fix: rm -rf .puvinoise && puvinoise run (to re-register).\\n"
            )
        elif not _tenant_id:
            _sys.stderr.write(
                "[puvinoise] CRITICAL: agent state found but tenant_id is empty — "
                "behaviour pipeline DISABLED.\\n"
                "  Fix: rm -rf .puvinoise && puvinoise run (to re-register).\\n"
            )
        else:
            _puvi.init(
                api_key=_api_key,
                agent_name=_agent_name,
                tenant_id=_tenant_id,
            )
            _sys.stderr.write(
                f"[puvinoise] init() identity loaded — "
                f"agent_id={_agent_id} tenant_id={_tenant_id} env_id={_env_id}\\n"
            )
except Exception as _e:
    _sys.stderr.write(f"[puvinoise] SDK init failed (non-fatal): {_e}\\n")
"""

# ─────────────────────────────────────────────────────────────────────────────
# Fix 5: env_id resolution with source transparency
# ─────────────────────────────────────────────────────────────────────────────

_ENV_ID_KEYS = ("PUVINOISE_ENV_ID", "PUVINOISE_ENVIRONMENT_ID")


def _resolve_env_id_with_source(explicit: Optional[str]) -> Tuple[str, str]:
    """
    Resolve env_id from (in priority order):
      1. explicit CLI --env-id flag
      2. process environment (populated from ``.puvinoise/env.json`` / ``agent_*.json``
         by ``_load_json_binding_into_environ`` in ``run_command``)

    Use ``puvinoise bindcar`` to bind the folder, then ``puvinoise run``.
    """
    if explicit and explicit.strip():
        return explicit.strip(), "cli:--env-id"

    for k in _ENV_ID_KEYS:
        v = os.environ.get(k, "").strip()
        if v:
            return v, f"env_var:{k}"

    return "", "not_found"


def _active_env_file_cwd() -> Path:
    """Single active env file for this working directory (bindcar contract)."""
    return Path.cwd() / ".env.puvinoise"


# Canonical keys written by ``puvinoise bindcar`` / ``puvinoise switch`` (no token).
_ACTIVE_BINDING_KEYS = frozenset(
    {
        "PUVINOISE_BASE_URL",
        "PUVINOISE_ENV_ID",
        "PUVINOISE_ENV_NAME",
        "PUVINOISE_TENANT_ID",
    }
)

# Remove stale binding / token keys so a prior shell or old file cannot leak into the run.
_BINDING_KEYS_TO_CLEAR = _ACTIVE_BINDING_KEYS | frozenset(
    {
        "PUVINOISE_REGISTRATION_TOKEN",
        "PUVINOISE_ENVIRONMENT_NAME",
        "PUVINOISE_DEPLOY_ENV",
        "PUVINOISE_TENANTID",
    }
)


def _coerce_legacy_binding_map(m: Dict[str, str]) -> Dict[str, str]:
    """Map pre-bindcar-v2 keys into the strict 4-key contract for this process only."""
    out = dict(m)
    if not (out.get("PUVINOISE_ENV_NAME") or "").strip() and (
        out.get("PUVINOISE_ENVIRONMENT_NAME") or ""
    ).strip():
        out["PUVINOISE_ENV_NAME"] = str(out.get("PUVINOISE_ENVIRONMENT_NAME") or "").strip()
    if not (out.get("PUVINOISE_TENANT_ID") or "").strip() and (out.get("PUVINOISE_TENANTID") or "").strip():
        out["PUVINOISE_TENANT_ID"] = str(out.get("PUVINOISE_TENANTID") or "").strip()
    return out


def _load_active_dotenv_into_environ() -> Tuple[bool, str]:
    """
    Load ``./.env.puvinoise`` and **overwrite** canonical binding env vars in this process.

    Does not use ``setdefault`` — the active file is the single source of truth for the run.
    Stale tokens / legacy keys are removed from ``os.environ`` before applying the file.
    """
    from puvinoise.env_resolve import normalize_environment_aliases, reset_environment_normalization

    p = _active_env_file_cwd()
    if not p.is_file():
        return False, "missing_file"
    m = _coerce_legacy_binding_map(_parse_dotenv_file(p))
    if not (m.get("PUVINOISE_ENV_ID") or "").strip():
        return False, "missing_env_id"

    reset_environment_normalization()
    for k in _BINDING_KEYS_TO_CLEAR:
        os.environ.pop(k, None)

    for k in _ACTIVE_BINDING_KEYS:
        if k in m and str(m.get(k) or "").strip():
            os.environ[k] = str(m[k]).strip()

    normalize_environment_aliases()

    # Optional identity / credentials from the same file (append after bindcar).
    _optional_run_keys = ("PUVINOISE_AGENT_ID", "PUVINOISE_AGENT_NAME", "PUVINOISE_API_KEY")
    for _k in _optional_run_keys:
        if _k in m and str(m.get(_k) or "").strip():
            os.environ[_k] = str(m[_k]).strip()

    return True, ""


def _load_json_binding_into_environ() -> Tuple[bool, str]:
    """
    Load binding from ``.puvinoise/agent_*.json`` (priority) or ``.puvinoise/env.json``
    and apply canonical binding env vars to this process.

    This is the single source of truth for environment binding.
    ``.env.puvinoise`` is NOT consulted for binding — only for SSL keys (see
    ``_load_ssl_dotenv_into_environ``).

    Reads **only** ``./.puvinoise/`` under the current working directory (no parent walk).
    Returns ``(True, "")`` on success, ``(False, reason)`` on failure.
    """
    from puvinoise.env_resolve import normalize_environment_aliases, reset_environment_normalization
    from puvinoise.agent_state import load_agent_state, load_env_state

    cwd = Path.cwd()
    agent_data, _ = load_agent_state(cwd)
    env_data: Dict[str, Any] = {}
    if not agent_data:
        env_data, _ = load_env_state(cwd)

    if not agent_data and not env_data:
        return False, "missing_file"

    state = agent_data if agent_data else env_data
    env_id = str(state.get("env_id") or "").strip()
    if not env_id:
        return False, "missing_env_id"

    reset_environment_normalization()
    for k in _BINDING_KEYS_TO_CLEAR:
        os.environ.pop(k, None)

    base_url = str(state.get("base_url") or "").strip().rstrip("/")
    tenant_id = str(state.get("tenant_id") or "").strip()
    env_name = (
        str(state.get("env_name") or "").strip()
        or str(state.get("environment") or "").strip()
    )

    os.environ["PUVINOISE_ENV_ID"] = env_id
    if base_url:
        os.environ["PUVINOISE_BASE_URL"] = base_url
    if tenant_id:
        os.environ["PUVINOISE_TENANT_ID"] = tenant_id
        os.environ["PUVINOISE_TENANTID"] = tenant_id
    if env_name:
        os.environ["PUVINOISE_ENV_NAME"] = env_name
        os.environ["PUVINOISE_DEPLOY_ENV"] = env_name

    # Full identity from agent_*.json: apply credentials so the child process
    # does not need to re-read the JSON file independently.
    if agent_data:
        api_key = str(agent_data.get("api_key") or "").strip()
        agent_id = str(agent_data.get("agent_id") or "").strip()
        agent_name_val = str(agent_data.get("agent_name") or "").strip()
        if api_key:
            os.environ["PUVINOISE_API_KEY"] = api_key
        if agent_id:
            os.environ["PUVINOISE_AGENT_ID"] = agent_id
        if agent_name_val:
            os.environ["PUVINOISE_AGENT_NAME"] = agent_name_val

    # Load SSL cert keys from .env.puvinoise if present (that file's only purpose).
    _load_ssl_dotenv_into_environ()

    normalize_environment_aliases()
    return True, ""


def _load_ssl_dotenv_into_environ() -> None:
    """
    Read ONLY SSL certificate keys from ``.env.puvinoise`` into this process.

    ``.env.puvinoise`` is reserved exclusively for SSL configuration written by
    ``bind_sidecar._patch_env_file_ssl()``.  All binding identity comes from
    ``.puvinoise/env.json`` / ``agent_*.json`` via ``_load_json_binding_into_environ``.
    """
    _SSL_KEYS = ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE")
    p = _active_env_file_cwd()
    if not p.is_file():
        return
    try:
        m = _parse_dotenv_file(p)
    except Exception:  # noqa: BLE001
        return
    for k in _SSL_KEYS:
        v = (m.get(k) or "").strip()
        if v:
            os.environ[k] = v


# Keep the old name as an alias so existing callers inside this module compile.
def _resolve_env_id_from_cli_or_env(explicit: Optional[str]) -> str:
    env_id, _ = _resolve_env_id_with_source(explicit)
    return env_id


def _shell_nonempty(*keys: str) -> bool:
    return any(os.environ.get(k, "").strip() for k in keys)


def _parse_dotenv_file(path: Path) -> Dict[str, str]:
    """KEY=VAL lines; supports optional `export ` prefix and quoted values."""
    out: Dict[str, str] = {}
    if not path.is_file():
        return out
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        k, _, rest = line.partition("=")
        k = k.strip()
        if not k:
            continue
        val = rest.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ("\"", "'"):
            val = val[1:-1]
        out[k] = val
    return out


# Optional keys merged from ``./.env`` (standard project env file) via setdefault — never
# overrides JSON binding, ``.env.puvinoise``, or explicit shell exports.
_PROJECT_DOTENV_OPTIONAL_KEYS = frozenset(
    {
        "PUVINOISE_AGENT_NAME",
        "PUVINOISE_BEARER_TOKEN",
        "PUVINOISE_RUN_AGENT_ID",
        "PUVINOISE_REGISTRATION_TOKEN",
    }
)


def _load_optional_project_dotenv_into_environ(cwd: Optional[Path] = None) -> None:
    root = (cwd or Path.cwd()).resolve()
    p = root / ".env"
    if not p.is_file():
        return
    try:
        m = _parse_dotenv_file(p)
    except Exception:  # noqa: BLE001
        return
    merged_keys: List[str] = []
    for k in _PROJECT_DOTENV_OPTIONAL_KEYS:
        v = (m.get(k) or "").strip()
        if v and k not in os.environ:
            os.environ[k] = v
            merged_keys.append(k)
    if merged_keys:
        print(
            "[puvinoise-run] optional run keys from ./.env: "
            + ", ".join(sorted(merged_keys)),
            file=sys.stderr,
        )


def _load_first_sidecar_json_state() -> Tuple[Dict[str, object], Optional[Path]]:
    """
    Load JSON state from ``./.puvinoise/`` only (current working directory).

    Priority (two-layer identity model):
      1. ``.puvinoise/agent_*.json``  — per-agent scoped state (wins)
      2. ``.puvinoise/env.json``      — environment state (bootstrap-only fallback)

    Delegates to ``puvinoise_json_config`` (shared logging, multi-file warning).
    No legacy files (.puvinoise_bind_state.json, .puvinoise_env.json).
    """
    from puvinoise.puvinoise_json_config import load_agent_json_first, load_env_json_if_present

    cwd = Path.cwd()
    agent_data, agent_path = load_agent_json_first(cwd)
    if agent_data:
        return agent_data, agent_path
    env_data, env_path = load_env_json_if_present(cwd)
    if env_data:
        return env_data, env_path
    return {}, None


def _compose_bootstrap_extra_env() -> Tuple[Dict[str, str], str]:
    """
    Supplement child env from persisted agent state only.

    Active environment keys (``PUVINOISE_ENV_ID``, ``PUVINOISE_BASE_URL``, etc.) come
    exclusively from ``./.env.puvinoise`` merged into ``os.environ`` by ``run_command`` —
    this function does not walk the tree or read ``.puvinoise/env.json`` for environment.

    May still inject ``PUVINOISE_BASE_URL`` / ``PUVINOISE_AGENT_ID`` from
    ``.puvinoise/agent_*.json`` when not already set (agent registration handoff).
    """
    extra: Dict[str, str] = {}
    labels: List[str] = []

    active = _active_env_file_cwd()
    if active.is_file():
        labels.append(str(active))

    state, sidecar_path = _load_first_sidecar_json_state()
    if state:
        base = (state.get("base_url") or "").strip()
        if base and not _shell_nonempty("PUVINOISE_BASE_URL"):
            extra["PUVINOISE_BASE_URL"] = base.rstrip("/")
        aid = (state.get("agent_id") or "").strip()
        if aid and not _shell_nonempty("PUVINOISE_AGENT_ID"):
            extra["PUVINOISE_AGENT_ID"] = aid
        if sidecar_path:
            labels.append(str(sidecar_path))

    summary = " · ".join(labels) if labels else ""
    return extra, summary


def _build_sitecustomize(tmpdir: Path) -> Path:
    """
    Write a sitecustomize.py to a scratch dir, then prepend that dir to
    PYTHONPATH in the child process.  CPython auto-imports sitecustomize at
    interpreter startup, so the SDK initializes BEFORE user code runs.

    The generated file first chains any existing sitecustomize (Fix 2), then
    runs the PUVINoise init snippet.
    """
    site = tmpdir / "sitecustomize.py"
    site.write_text(_SITECUSTOMIZE_CHAIN_HEADER + PRELOAD_SNIPPET, encoding="utf-8")
    return site


def _build_child_env(
    *,
    env_id: str,
    agent_name: Optional[str],
    tmpdir: Path,
    extra_env: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    env = os.environ.copy()
    env["PUVINOISE_ENV_ID"] = env_id
    if agent_name:
        env["PUVINOISE_AGENT_NAME"] = agent_name
    # Mark this process as SDK-instrumented so the sidecar bootstrap path
    # downgrades gracefully if it ever runs alongside.
    env["PUVINOISE_RUNTIME_DRIVEN"] = "1"
    env["PUVINOISE_AUTOREGISTER"] = env.get("PUVINOISE_AUTOREGISTER", "1")

    # sitecustomize injection — prepend scratch dir to PYTHONPATH so the
    # interpreter loads our hook before user packages.
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        f"{tmpdir}{os.pathsep}{existing_pp}" if existing_pp else str(tmpdir)
    )
    if extra_env:
        for k, v in extra_env.items():
            env[k] = str(v)
    return env


def _resolve_initial_agent_name(
    *,
    workdir: Path,
    cli_agent_id: Optional[str],
    base_url: str,
    env_id: str,
) -> Tuple[Optional[str], Optional[str]]:
    """
    When there is no local agent state and no CLI/env agent name yet, resolve the
    tenant agent name used for POST /api/auto-register.

    * 0 agents → error (explicit onboarding / create required)
    * 1 agent → use its name (deterministic)
    * N agents → require --agent-id, or interactive pick if TTY
    """
    bearer = (os.environ.get("PUVINOISE_BEARER_TOKEN", "") or "").strip()
    if not bearer:
        return None, (
            "agent_name is required for first-time registration.\n"
            "  • puvinoise onboard [--name ...]\n"
            "  • puvinoise run --agent-name <name> ...\n"
            "  • export PUVINOISE_AGENT_NAME=...  or put it in ./.env\n"
            "  • or export PUVINOISE_BEARER_TOKEN=<jwt> to auto-pick when exactly one tenant agent exists"
        )

    try:
        from puvinoise.tenant_api import api_list_agents
    except Exception as exc:  # noqa: BLE001
        return None, f"Cannot load tenant API: {exc}"

    if not base_url:
        return None, "PUVINOISE_BASE_URL is missing — run bindcar first."

    try:
        agents = api_list_agents(base_url, bearer)
    except RuntimeError as e:
        return None, f"Could not list agents ({e}). Set --agent-name explicitly."

    if len(agents) == 0:
        return None, (
            "No agents in tenant — run `puvinoise onboard --name ...` or "
            "`puvinoise create --name ...` (JWT required) before `puvinoise run`."
        )

    if len(agents) == 1:
        n = str(agents[0].get("name") or "").strip()
        if not n:
            return None, "Tenant returned one agent without a name — use --agent-name."
        print(
            f"[puvinoise-run] Single tenant agent '{n}' — using it for registration.",
            file=sys.stderr,
        )
        return n, None

    want_id = (cli_agent_id or os.environ.get("PUVINOISE_RUN_AGENT_ID", "") or "").strip()
    if want_id:
        for a in agents:
            if str(a.get("agent_id") or "").strip() == want_id:
                n = str(a.get("name") or "").strip()
                if not n:
                    return None, f"Agent {want_id} has no name in registry."
                print(
                    f"[puvinoise-run] Using agent {want_id} ({n}) from --agent-id.",
                    file=sys.stderr,
                )
                return n, None
        return None, f"--agent-id {want_id!r} not found in tenant agent list."

    if not sys.stdin.isatty():
        return None, (
            "Multiple agents in tenant — choose explicitly:\n"
            "  puvinoise run --agent-name <name> ...\n"
            "  puvinoise run --agent-id <agt_...> ...\n"
            "  (CI/non-interactive must pass one of these.)"
        )

    print("Multiple agents in tenant — pick one for this folder:", file=sys.stderr)
    for i, a in enumerate(agents):
        print(
            f"  [{i + 1}] {a.get('name')!s}  ({a.get('agent_id')!s})",
            file=sys.stderr,
        )
    try:
        choice = input("Enter number: ").strip()
    except EOFError:
        return None, "EOF while choosing agent."
    try:
        idx = int(choice, 10) - 1
    except ValueError:
        return None, "Invalid selection."
    if idx < 0 or idx >= len(agents):
        return None, "Selection out of range."
    n = str(agents[idx].get("name") or "").strip()
    if not n:
        return None, "Selected agent has no name."
    return n, None


def _maybe_auto_register(
    *,
    workdir: Path,
    env_id: str,
    agent_name: Optional[str],
    extra_env: Dict[str, str],
    registration_token: Optional[str] = None,
) -> None:
    """
    Pre-spawn auto-registration (requirement: "zero-config" first run).

    Triggered when:
      • ``.puvinoise/env.json`` exists  — environment is bootstrapped
      • no ``.puvinoise/agent_*.json``  — agent not yet registered this dir

    When ``registration_token`` (prt_...) is provided, uses POST /api/register
    (token-based flow from the UI). Otherwise falls back to POST /api/auto-register
    (open endpoint, requires BOOTSTRAPPED environment).

    On success the registration writes ``.puvinoise/agent_<id>.json`` (including
    the api_key) so subsequent runs need neither ``.env.puvinoise`` nor any
    manually exported env vars.

    Always fails open (prints a warning, never raises).  The subprocess still
    runs — it will retry registration via the sitecustomize hook.
    """
    from puvinoise.agent_state import load_agent_state, load_env_state, save_agent_state

    # Only run if environment is known (env.json or bindcar `.env.puvinoise` already loaded into os.environ).
    env_state, _ = load_env_state(workdir)
    if not env_state:
        base_url = (os.environ.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")
        dotenv_eid = (os.environ.get("PUVINOISE_ENV_ID") or "").strip()
        if base_url and dotenv_eid:
            env_state = {"base_url": base_url, "env_id": dotenv_eid}
    if not env_state:
        return
    agent_state, _ = load_agent_state(workdir)
    if agent_state:
        # Already registered — nothing to do.
        return

    platform_url = str(env_state.get("base_url", "")).strip().rstrip("/")
    resolved_env_id = env_id or str(env_state.get("env_id", "")).strip()

    if not platform_url or not resolved_env_id:
        print(
            "[puvinoise-run] No agent state found — cannot register: "
            "base_url or env_id missing from env.json",
            file=sys.stderr,
        )
        return

    name = (
        agent_name
        or extra_env.get("PUVINOISE_AGENT_NAME")
        or os.environ.get("PUVINOISE_AGENT_NAME", "")
    ).strip()
    if not name:
        print(
            "[puvinoise-run] agent_name is required for first-time registration "
            "(no folder-based or default name).\n"
            "  Use: puvinoise onboard  |  --agent-name  |  PUVINOISE_AGENT_NAME in env or ./.env  |  "
            "PUVINOISE_BEARER_TOKEN with a single tenant agent or interactive pick.",
            file=sys.stderr,
        )
        return

    print(
        f"[puvinoise-run] No agent state found — invoking registration "
        f"(agent='{name}', env_id={resolved_env_id})",
        file=sys.stderr,
    )

    reg_env_slug = ""
    if env_state:
        reg_env_slug = str(
            env_state.get("env_name") or env_state.get("environment") or ""
        ).strip()

    try:
        import json as _json_ar
        import urllib.request as _ureq_ar

        token_clean = (
            (registration_token or "").strip()
            or (os.environ.get("PUVINOISE_REGISTRATION_TOKEN", "") or "").strip()
        )
        if token_clean:
            # Token-based registration via UI-issued prt_ token.
            payload = {"registration_token": token_clean, "agent_name": name}
            url = f"{platform_url}/api/register"
        else:
            # Fallback: open auto-register (requires BOOTSTRAPPED environment).
            payload = {"env_id": resolved_env_id, "agent_name": name}
            url = f"{platform_url}/api/auto-register"

        req_ar = _ureq_ar.Request(
            url,
            data=_json_ar.dumps(payload).encode("utf-8"),
            method="POST",
        )
        req_ar.add_header("Content-Type", "application/json")
        with _ureq_ar.urlopen(req_ar, timeout=20) as resp_ar:
            body_ar = _json_ar.loads(resp_ar.read().decode("utf-8"))
        got_api_key = str(body_ar.get("api_key", "")).strip()
        got_agent_id = str(body_ar.get("agent_id", "")).strip()
        got_tenant_id = str(body_ar.get("tenant_id", "")).strip()
        if not got_api_key or not got_agent_id:
            print(
                f"[puvinoise-run] ⚠ {url} returned incomplete response — "
                "registration failed.",
                file=sys.stderr,
            )
            return
        save_agent_state(
            agent_id=got_agent_id,
            env_id=resolved_env_id,
            base_url=platform_url,
            workdir=workdir,
            api_key=got_api_key,
            tenant_id=got_tenant_id,
            agent_name=name,
            env_name=reg_env_slug or None,
        )
        extra_env["PUVINOISE_API_KEY"] = got_api_key
        extra_env["PUVINOISE_AGENT_ID"] = got_agent_id
        print(
            f"[puvinoise-run] ✓ agent registered: {got_agent_id}",
            file=sys.stderr,
        )
    except Exception as exc:  # noqa: BLE001
        print(
            f"[puvinoise-run] ⚠ registration failed (non-fatal): {exc}\n"
            "  The subprocess will run without SDK init.\n"
            "  Check that `puvinoise bindcar` has been run and the server is reachable.",
            file=sys.stderr,
        )


def run_command(
    command: List[str],
    *,
    env_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    cli_agent_id: Optional[str] = None,
    dry_run: bool = False,
    strict: bool = True,
    registration_token: Optional[str] = None,
    auto_upgrade: bool = False,
) -> int:
    """
    Execute <command> as a PUVINoise-instrumented process.

    Returns the child process's exit code (or 1 on precondition failure).
    """
    if not command:
        print("puvinoise run: no command provided", file=sys.stderr)
        return 2
    installed_sdk_version = _get_installed_sdk_version()
    if installed_sdk_version:
        print(f"[puvinoise] SDK: {installed_sdk_version}", file=sys.stderr)
    _check_sdk_update_notice()
    if auto_upgrade:
        _run_upgrade_sdk()

    ok_bind, bind_reason = _load_json_binding_into_environ()
    if not ok_bind:
        print(
            "Environment not bound. Run: puvinoise bindcar --token <prt_...>",
            file=sys.stderr,
        )
        if bind_reason == "missing_file":
            print(
                "  No .puvinoise/env.json or agent_*.json in the current directory's .puvinoise/.",
                file=sys.stderr,
            )
        elif bind_reason == "missing_env_id":
            print(
                "  .puvinoise/env.json exists but env_id is missing or empty.",
                file=sys.stderr,
            )
        return 1 if strict else 0

    # Identity lock: if a persisted agent_<id>.json exists, it is the single source
    # of truth for env_id.  A --env-id CLI override that disagrees is a hard fail.
    # This prevents accidental cross-environment runs after the first registration.
    try:
        from puvinoise.agent_state import load_agent_state as _load_agent_state
        _as, _ap = _load_agent_state(Path.cwd())
        if _as and _as.get("env_id"):
            _persisted_env_id = str(_as["env_id"]).strip()
            _cli_env_id = (env_id or "").strip()
            if _cli_env_id and _cli_env_id != _persisted_env_id:
                print(
                    f"puvinoise run: Env mismatch — CLI --env-id='{_cli_env_id}' "
                    f"!= persisted env_id='{_persisted_env_id}'.\n"
                    f"  Source: {_ap}\n"
                    "  Remove the --env-id override, or reset the agent directory:\n"
                    "    rm -rf .puvinoise && puvinoise bindcar --token <prt_...>",
                    file=sys.stderr,
                )
                return 1
            if _cli_env_id and _cli_env_id == _persisted_env_id:
                pass  # matches — silently accepted
            elif _cli_env_id:
                print(
                    f"[puvinoise-run] --env-id override ignored; using persisted identity ({_ap.name})",
                    file=sys.stderr,
                )
            # Always prefer the persisted value.
            env_id = _persisted_env_id
    except Exception:  # noqa: BLE001
        pass  # identity lock is best-effort; proceed with normal resolution

    # Fix 5: resolve with source transparency
    resolved_env_id, env_id_source = _resolve_env_id_with_source(env_id)
    if not resolved_env_id:
        print(
            "puvinoise run: env_id is missing from ./.env.puvinoise after load.\n"
            "  Run `puvinoise bindcar --token <prt_...>` with PUVINOISE_BASE_URL set, or pass --env-id.",
            file=sys.stderr,
        )
        return 1 if strict else 0

    # Fix 5: print resolved source so the developer knows where it came from.
    print(
        f"[puvinoise-run] env_id resolved  (source={env_id_source})",
        file=sys.stderr,
    )

    _load_optional_project_dotenv_into_environ(Path.cwd())

    # First-time registration: require an explicit agent name or deterministic tenant selection.
    resolved_agent_name = (agent_name or "").strip() or (
        os.environ.get("PUVINOISE_AGENT_NAME", "") or ""
    ).strip()
    if not dry_run:
        from puvinoise.agent_state import load_agent_state as _load_as_pre

        _as_pre, _ = _load_as_pre(Path.cwd().resolve())
        if not _as_pre and not resolved_agent_name:
            base_u = (os.environ.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")
            pick, err = _resolve_initial_agent_name(
                workdir=Path.cwd().resolve(),
                cli_agent_id=cli_agent_id,
                base_url=base_u,
                env_id=resolved_env_id,
            )
            if err:
                print(f"puvinoise run: {err}", file=sys.stderr)
                return 1 if strict else 0
            resolved_agent_name = pick or ""
        agent_name = resolved_agent_name or agent_name

    handoff_env, bootstrap_sources = _compose_bootstrap_extra_env()
    if bootstrap_sources and any(
        k in handoff_env
        for k in (
            "PUVINOISE_BASE_URL",
            "PUVINOISE_AGENT_ID",
        )
    ):
        print(
            f"[puvinoise-run] bootstrap env (no export needed): {bootstrap_sources}",
            file=sys.stderr,
        )

    # Capture whether agent_id was already present from the state file BEFORE
    # _maybe_auto_register() runs, so we can accurately attribute the source in the log.
    _agent_id_from_state_file = handoff_env.get("PUVINOISE_AGENT_ID", "").strip()

    # Pre-spawn auto-registration: if .puvinoise/env.json exists but no agent file
    # has been written yet, register the agent NOW (before the subprocess starts).
    # This is the "zero-config first run" path — writes .puvinoise/agent_<id>.json
    # (including api_key) so all future runs need no .env.puvinoise.
    # Also injects PUVINOISE_API_KEY into handoff_env if obtained from state file.
    if not dry_run:
        _maybe_auto_register(
            workdir=Path.cwd().resolve(),
            env_id=resolved_env_id,
            agent_name=agent_name,
            extra_env=handoff_env,
            registration_token=registration_token,
        )
        # NOTE: No api_key re-injection needed here.
        # The PRELOAD_SNIPPET in the child process calls resolve_api_key() which reads
        # directly from .puvinoise/agent_<id>.json (just written by _maybe_auto_register).
        # Strict contract: api_key never travels through env vars.

    # ─── agent_id resolution (strict, single source of truth) ────────────────────
    # PUVINOISE_AGENT_ID flows through exactly one path:
    #   runtime → handoff_env → child process env → SDK reads os.environ["PUVINOISE_AGENT_ID"]
    # init() does NOT accept agent_id as a parameter. There is no fallback.
    # If not resolvable here: fail before spawning — don't let the child run silently dropping traces.
    resolved_agent_id = (
        handoff_env.get("PUVINOISE_AGENT_ID") or os.environ.get("PUVINOISE_AGENT_ID", "")
    ).strip()

    if not resolved_agent_id:
        if dry_run:
            # --dry-run skips _maybe_auto_register so first-time runs won't have an id yet.
            print(
                "[puvinoise-run] WARNING: agent_id not yet resolved "
                "(dry-run skips registration).\n"
                "  Run 'puvinoise run' (without --dry-run) to trigger first-time registration.",
                file=sys.stderr,
            )
        else:
            print(
                "puvinoise run: agent_id could not be resolved.\n"
                "  Agent not registered. Run `puvinoise bindcar` then `puvinoise run` again,\n"
                "  or complete first-time registration.",
                file=sys.stderr,
            )
            return 1

    if resolved_agent_id:
        # Determine the precise source: state_file (pre-existing .puvinoise/agent_*.json),
        # registration (written by _maybe_auto_register this run), or env_var (manual override).
        if _agent_id_from_state_file:
            _agent_id_source = "state_file"
        elif handoff_env.get("PUVINOISE_AGENT_ID"):
            _agent_id_source = "registration"
        elif os.environ.get("PUVINOISE_AGENT_ID"):
            _agent_id_source = "env_var"
        else:
            _agent_id_source = "unknown"
        print(
            f"[puvinoise-run] agent_id={resolved_agent_id} (source={_agent_id_source})",
            file=sys.stderr,
        )

    # Resolve the command's executable — respect PATH but give a clear error.
    exe = command[0]
    if not os.path.isabs(exe) and os.sep not in exe:
        found = shutil.which(exe)
        # macOS/Homebrew often expose `python3` but not `python` on PATH.
        if not found and exe == "python":
            found = shutil.which("python3")
            if found:
                print(
                    f"[puvinoise-run] `{exe}` not on PATH — using {found}",
                    file=sys.stderr,
                )
        if not found:
            hint = ""
            if exe in ("python", "python3"):
                hint = f"\n  Hint: install Python or use `puvinoise run python3 ...` / full path to the interpreter."
            print(
                f"puvinoise run: command not found on PATH: {exe}{hint}",
                file=sys.stderr,
            )
            return 127
        command = [found] + list(command[1:])

    # Create a short-lived scratch dir for the sitecustomize hook.
    tmpdir_obj = tempfile.TemporaryDirectory(prefix="puvinoise-run-")
    tmpdir = Path(tmpdir_obj.name)
    try:
        _build_sitecustomize(tmpdir)
        child_env = _build_child_env(
            env_id=resolved_env_id,
            agent_name=agent_name,
            tmpdir=tmpdir,
            extra_env=handoff_env or None,
        )

        if dry_run:
            print("puvinoise run — DRY RUN")
            print(f"  command       : {' '.join(shlex.quote(c) for c in command)}")
            print(f"  env_id        : {resolved_env_id}  [{env_id_source}]")
            print(f"  agent_name    : {agent_name or '(inherited)'}")
            print(f"  sitecustomize : {tmpdir / 'sitecustomize.py'}")
            print(f"  PYTHONPATH    : {child_env['PYTHONPATH']}")
            if handoff_env:
                print(f"  bootstrap keys: {', '.join(sorted(handoff_env.keys()))}")
            return 0

        # Tee child output while retaining enough text to detect common SSL failures.
        try:
            return _run_child_with_ssl_detection(command, child_env)
        except KeyboardInterrupt:
            return 130
    finally:
        try:
            tmpdir_obj.cleanup()
        except Exception:  # noqa: BLE001
            pass


def cmd_run(args) -> int:
    """argparse entry point for `puvinoise run`."""
    command = list(args.command or [])
    # Drop the leading '--' that argparse.REMAINDER may preserve.
    if command and command[0] == "--":
        command = command[1:]

    # Fix 4: merge unknown args captured by parse_known_args() in main()
    # so arbitrary user flags (e.g. `puvinoise run --foo python app.py`) are
    # passed through to the subprocess rather than raising an argparse error.
    unknown = getattr(args, "_unknown_args", None)
    if unknown:
        command = list(unknown) + command

    # Strip --token=<value> / --token <value> from the command list regardless
    # of position.  argparse.REMAINDER captures everything after the first
    # positional (the script name) so --token never reaches the flag parser
    # when written after the script.  We own it — never pass it to user code.
    registration_token = getattr(args, "registration_token", None)
    filtered: list = []
    i = 0
    while i < len(command):
        arg = command[i]
        if arg.startswith("--token="):
            if not registration_token:
                registration_token = arg[len("--token="):]
            i += 1
        elif arg == "--token" and i + 1 < len(command):
            if not registration_token:
                registration_token = command[i + 1]
            i += 2
        else:
            filtered.append(arg)
            i += 1
    command = filtered

    return run_command(
        command,
        env_id=getattr(args, "env_id", None),
        agent_name=getattr(args, "agent_name", None),
        cli_agent_id=getattr(args, "cli_agent_id", None),
        dry_run=getattr(args, "dry_run", False),
        strict=not getattr(args, "no_strict", False),
        registration_token=registration_token,
        auto_upgrade=bool(getattr(args, "auto_upgrade", False)),
    )


def register_subparser(sub) -> None:
    """Attach the `run` subcommand to the top-level CLI parser."""
    run_p = sub.add_parser(
        "run",
        help="Run a command inside the PUVINoise SDK runtime (auto-register + telemetry)",
        description=(
            "Run <command> as an instrumented agent. Requires ./.env.puvinoise from "
            "`puvinoise bindcar` (active environment for this folder)."
        ),
    )
    run_p.add_argument("--env-id", dest="env_id", default=None, help="Environment id (overrides PUVINOISE_ENV_ID)")
    run_p.add_argument("--agent-name", dest="agent_name", default=None, help="Agent name override")
    run_p.add_argument(
        "--agent-id",
        dest="cli_agent_id",
        default=None,
        help=(
            "When multiple tenant agents exist and there is no local .puvinoise agent state, "
            "select registry agent by agt_ id (requires PUVINOISE_BEARER_TOKEN). "
            "Or set PUVINOISE_RUN_AGENT_ID."
        ),
    )
    run_p.add_argument("--dry-run", dest="dry_run", action="store_true", help="Print what would run and exit 0")
    run_p.add_argument("--no-strict", dest="no_strict", action="store_true", help="Don't fail when env_id is missing")
    run_p.add_argument("--auto-upgrade", dest="auto_upgrade", action="store_true", help="Upgrade SDK before running command")
    run_p.add_argument("--token", dest="registration_token", default=None, help="One-time registration token (prt_...) issued by the PUVINoise UI")
    run_p.add_argument("command", nargs=subparser_remainder(), help="Command to run (prefix with -- for flag safety)")
    run_p.set_defaults(func=cmd_run)


def cmd_upgrade_sdk(_args) -> int:
    """argparse entry point for `puvinoise upgrade-sdk`."""
    return _run_upgrade_sdk()


def register_upgrade_subparser(sub) -> None:
    """Attach `upgrade-sdk` subcommand."""
    up_p = sub.add_parser(
        "upgrade-sdk",
        help="Upgrade puvinoise SDK via pip",
        description="Upgrade installed puvinoise SDK using pip.",
    )
    up_p.set_defaults(func=cmd_upgrade_sdk)


def subparser_remainder():
    """argparse.REMAINDER constant — isolated so the module imports cleanly."""
    import argparse
    return argparse.REMAINDER
