# -*- coding: utf-8 -*-
"""Agentic action execution for AI Chat plugin. (C) 2026 by Maciej Piecko

Handles file creation, console execution, package installation, and patch
application triggered by special code fences in LLM responses.
"""

import os
import re
import shutil
import subprocess


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def find_git():
    """Return the path to the git executable, or None if not found."""
    return shutil.which("git")


def run_git_command(args, cwd=None):
    """
    Run a git command.  args is a list of strings (without the leading 'git').
    Returns (stdout: str, stderr: str, returncode: int).
    Raises RuntimeError if git is not installed.
    """
    git = find_git()
    if not git:
        raise RuntimeError(
            "git is not installed or not on PATH.\n"
            "Please install Git and make sure it is available in your system PATH."
        )
    try:
        result = subprocess.run(
            [git] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", "git command timed out after 30 seconds.", 1
    except Exception as exc:
        return "", str(exc), 1


# ---------------------------------------------------------------------------
# Agentic system prompt injected when agentic mode is enabled
# ---------------------------------------------------------------------------


AGENTIC_SYSTEM_PROMPT = """\
You can take direct actions by using special code fences. The user will see a \
button and must click it to confirm and execute each action.

IMPORTANT RULE — file vs patch:
- Use a `patch:` fence to edit or modify an EXISTING file. Never rewrite an \
existing file in full with a `file:` fence.
- Use a `file:` fence ONLY when creating a brand new file that does not yet exist.
- When the user says "edit", "change", "update", "fix", "refactor", or \
"modify" a file — always produce a `patch:` fence, not a `file:` fence.

Create a brand-new file (path relative to project root, or absolute):
```file:path/to/new_file.py
# full file content here
```

Run Python code in the IPython console:
```run:python
print("hello world")
```

Install a Python package:
```install:pip
numpy pandas
```

Apply a unified diff patch to modify an EXISTING file:
```patch:path/to/file.py
--- a/path/to/file.py
+++ b/path/to/file.py
@@ -1,3 +1,3 @@
 context line
-old line
+new line
```

Run a git command in the project directory:
```run:git
log --oneline -10
```
The command output will appear inline. The user can attach it to the chat so \
you can read and reason about it, or dismiss it. Use read-only commands \
(log, diff, status, show, blame) to inspect the repository. Use write \
commands (commit, branch, checkout) to perform operations. Always show the \
user what command you are running and why.

Use these action fences only when the user explicitly asks you to create or \
modify files, run code, install packages, or interact with git. Always \
explain what you are doing before the action fence."""


# ---------------------------------------------------------------------------
# Execution helpers
# ---------------------------------------------------------------------------

def execute_create_file(path, content, base_dir=None):
    """Create or overwrite a file. Returns the absolute path written."""
    if base_dir and not os.path.isabs(path):
        path = os.path.join(base_dir, path)
    path = os.path.normpath(os.path.abspath(path))
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    return path


def execute_patch_file(path, diff_text, base_dir=None):
    """Apply a unified diff to a file. Returns the absolute path written."""
    if base_dir and not os.path.isabs(path):
        path = os.path.join(base_dir, path)
    path = os.path.normpath(os.path.abspath(path))
    try:
        with open(path, "r", encoding="utf-8") as f:
            original = f.read()
    except FileNotFoundError:
        original = ""
    result = _apply_unified_diff(original, diff_text)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(result)
    return path


def _find_hunk_position(lines, hunk_old):
    """Find where hunk_old appears in lines. Returns start index or None."""
    if not hunk_old:
        return 0
    # Exact match first
    for start in range(len(lines) - len(hunk_old) + 1):
        if lines[start:start + len(hunk_old)] == hunk_old:
            return start
    # Stripped match (ignore leading/trailing whitespace differences)
    hunk_stripped = [l.strip() for l in hunk_old]
    for start in range(len(lines) - len(hunk_old) + 1):
        if [l.strip() for l in lines[start:start + len(hunk_old)]] == hunk_stripped:
            return start
    return None


def _apply_unified_diff(original_text, diff_text):
    """Apply a unified diff string to original_text. Returns new text."""
    orig_lines = original_text.splitlines()
    result = list(orig_lines)
    offset = 0
    i = 0
    diff_lines = diff_text.splitlines()

    while i < len(diff_lines):
        line = diff_lines[i]
        if not line.startswith("@@"):
            i += 1
            continue

        m = re.match(r"@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@", line)
        old_start = max(0, int(m.group(1)) - 1) if m else None
        i += 1

        # Collect hunk lines, stop at next hunk or end
        hunk_old = []   # lines as they were (context + removed)
        hunk_new = []   # lines as they should be (context + added)
        while i < len(diff_lines):
            hl = diff_lines[i]
            if hl.startswith("@@"):
                break
            if hl.startswith("---") or hl.startswith("+++"):
                i += 1
                continue
            if hl.startswith("-"):
                hunk_old.append(hl[1:])
            elif hl.startswith("+"):
                hunk_new.append(hl[1:])
            elif hl.startswith(" "):
                hunk_old.append(hl[1:])
                hunk_new.append(hl[1:])
            elif hl == "":
                # Blank line within hunk counts as context
                hunk_old.append("")
                hunk_new.append("")
            i += 1

        if old_start is None:
            # LLM omitted line numbers — fuzzy search for the removed lines
            pos = _find_hunk_position(result, hunk_old)
            if pos is None:
                continue  # can't locate hunk, skip it
            # Don't update offset: fuzzy search always uses absolute positions
            end = min(pos + len(hunk_old), len(result))
            result[pos:end] = hunk_new
            offset += len(hunk_new) - len(hunk_old)
        else:
            pos = max(0, min(old_start + offset, len(result)))
            end = min(pos + len(hunk_old), len(result))
            result[pos:end] = hunk_new
            offset += len(hunk_new) - len(hunk_old)

    return "\n".join(result)


# ---------------------------------------------------------------------------
# Qt confirm dialog  (imported lazily to avoid Qt import at module load)
# ---------------------------------------------------------------------------

def show_confirm_dialog(parent, action_type, target, content, base_dir=None):
    """
    Show a modal confirmation dialog for one agentic action.

    Returns:
        (confirmed: bool, final_path: str)  — final_path may differ from
        target if the user edited it in the dialog (file/patch actions).
    """
    from qtpy.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel,
        QPlainTextEdit, QLineEdit, QDialogButtonBox, QPushButton,
        QFrame, QSizePolicy,
    )
    from qtpy.QtCore import Qt
    from qtpy.QtGui import QFont as _QFont

    dlg = QDialog(parent)
    dlg.setWindowTitle("Confirm Agentic Action")
    dlg.setMinimumWidth(480)

    lay = QVBoxLayout(dlg)
    lay.setSpacing(8)
    lay.setContentsMargins(14, 14, 14, 14)

    # ── Header ──────────────────────────────────────────────────────────
    _ICONS = {
        "file":    "📄",
        "patch":   "🩹",
        "run":     "▶",
        "install": "📦",
        "git":     "⎇",
    }
    _LABELS = {
        "file":    "Create / Overwrite File",
        "patch":   "Apply Patch",
        "run":     "Run in IPython Console",
        "install": "Install Package",
        "git":     "Run Git Command",
    }
    icon  = _ICONS.get(action_type, "?")
    label = _LABELS.get(action_type, action_type)

    _hdr_color = "#e8a050" if action_type == "git" else "#4ec9b0"
    hdr = QLabel(f"<b>{icon} {label}</b>")
    hdr.setStyleSheet(f"font-size: 11pt; color: {_hdr_color};")
    lay.addWidget(hdr)

    sep = QFrame()
    sep.setFrameShape(QFrame.HLine)
    sep.setStyleSheet("color: #444; margin: 2px 0;")
    lay.addWidget(sep)

    # ── Path / target field (editable for file/patch) ───────────────────
    _path_edit = None
    if action_type in ("file", "patch"):
        if base_dir:
            base_note = QLabel(f"📁 Base path: <code>{base_dir}</code>")
            base_note.setTextFormat(Qt.RichText)
            base_note.setStyleSheet(
                "color: #c8c8c8; font-size: 9pt; "
                "background: #2a2a2a; border: 1px solid #555; "
                "border-radius: 3px; padding: 3px 6px;")
            lay.addWidget(base_note)
        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("Path:"))
        _path_edit = QLineEdit(target)
        _path_edit.setPlaceholderText("Relative to base path above, or absolute")
        _path_edit.setStyleSheet("font-size: 9pt;")
        path_row.addWidget(_path_edit, 1)
        lay.addLayout(path_row)
    elif action_type == "install":
        pkg_lbl = QLabel(f"<b>Package(s):</b> <code>{target or content.strip()}</code>")
        pkg_lbl.setTextFormat(Qt.RichText)
        lay.addWidget(pkg_lbl)
    elif action_type == "run":
        run_lbl = QLabel(f"<b>Language:</b> {target}")
        lay.addWidget(run_lbl)
    elif action_type == "git":
        cmd_first_line = content.strip().split("\n")[0]
        cmd_lbl = QLabel(f"<b>Command:</b> <code>$ git {cmd_first_line}</code>")
        cmd_lbl.setTextFormat(Qt.RichText)
        cmd_lbl.setWordWrap(True)
        cmd_lbl.setStyleSheet(
            "color: #f0c080; font-size: 10pt; "
            "background: #2a1a00; border: 1px solid #e8a050; "
            "border-radius: 3px; padding: 4px 8px;")
        lay.addWidget(cmd_lbl)
        _cwd = base_dir or "~ (home directory)"
        dir_lbl = QLabel(f"📁 Working directory: <code>{_cwd}</code>")
        dir_lbl.setTextFormat(Qt.RichText)
        dir_lbl.setStyleSheet(
            "color: #c8c8c8; font-size: 9pt; "
            "background: #2a2a2a; border: 1px solid #555; "
            "border-radius: 3px; padding: 3px 6px;")
        lay.addWidget(dir_lbl)

    # ── Content preview (not shown for git — command already displayed above) ──
    if action_type != "git":
        if action_type == "patch":
            from qtpy.QtWidgets import QTextEdit as _QTE
            from qtpy.QtGui import QTextOption as _QTO
            from .markdown_renderer import _diff_to_html
            preview = _QTE()
            preview.setReadOnly(True)
            preview.setWordWrapMode(_QTO.NoWrap)
            preview.setMaximumHeight(240)
            preview.setStyleSheet(
                "QTextEdit { background: #1e1e1e; border: 1px solid #444; "
                "border-radius: 3px; padding: 4px; }")
            preview.setHtml(_diff_to_html(content, 9))
        else:
            preview = QPlainTextEdit()
            preview.setReadOnly(True)
            preview.setPlainText(content)
            preview.setMaximumHeight(240)
            preview.setFont(_QFont("Monospace", 9))
            preview.setStyleSheet(
                "QPlainTextEdit { background: #1e1e1e; color: #d4d4d4; "
                "border: 1px solid #444; border-radius: 3px; padding: 4px; }")
        preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        lay.addWidget(preview)


    # ── Buttons ─────────────────────────────────────────────────────────
    btns = QDialogButtonBox()
    ok_btn = QPushButton(f"{icon} Execute")
    ok_btn.setDefault(True)
    ok_btn.setStyleSheet(
        "QPushButton { background: #2a4a2a; color: #80c880; "
        "border: 1px solid #4a8a4a; border-radius: 3px; padding: 4px 16px; }"
        "QPushButton:hover { background: #3a5a3a; }")
    cancel_btn = QPushButton("Cancel")
    cancel_btn.setStyleSheet(
        "QPushButton { padding: 4px 16px; }")
    btns.addButton(ok_btn, QDialogButtonBox.AcceptRole)
    btns.addButton(cancel_btn, QDialogButtonBox.RejectRole)
    btns.accepted.connect(dlg.accept)
    btns.rejected.connect(dlg.reject)
    lay.addWidget(btns)

    result = dlg.exec_()
    confirmed = result == QDialog.Accepted
    final_path = _path_edit.text().strip() if _path_edit else target
    return confirmed, final_path
