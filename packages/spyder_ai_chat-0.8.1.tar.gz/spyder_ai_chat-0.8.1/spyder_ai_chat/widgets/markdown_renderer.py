# -*- coding: utf-8 -*-
"""
Markdown → Qt widgets renderer for AI Chat responses. (C) 2026 by Maciej Piecko

Supported elements:
  - Headings (#, ##, ###)
  - Bold (**text** or __text__)
  - Italic (*text* or _text_)
  - Bold+Italic (***text***)
  - Inline code (`code`)
  - Fenced code blocks (```lang ... ```)
  - Bullet lists (-, *, +)
  - Numbered lists (1. 2. etc.)
  - Blockquotes (> text)
  - Horizontal rules (--- or ***)
  - Tables (| col | col |)
  - Strikethrough (~~text~~)
  - Links ([text](url))
  - Plain paragraphs
"""

import re
from qtpy.QtCore import Qt, Signal, QPoint, QTimer, QThread
from qtpy.QtGui import QFont, QColor
from qtpy.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QSizePolicy, QGridLayout, QScrollArea, QTextBrowser,
)


# ---------------------------------------------------------------------------
# Inline markdown → HTML  (used inside QLabel with RichText)
# ---------------------------------------------------------------------------
def _inline_to_html(text):
    """Convert inline markdown to HTML for use in a QLabel."""
    # Preserve <br> tags before escaping, then restore them after
    text = re.sub(r'<br\s*/?>', '\x00BR\x00', text, flags=re.IGNORECASE)
    # Escape HTML special chars first (except we'll add our own tags)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = text.replace('\x00BR\x00', '<br>')

    # Bold + Italic: ***text*** or ___text___
    text = re.sub(r'\*{3}(.+?)\*{3}', r'<b><i>\1</i></b>', text)
    text = re.sub(r'_{3}(.+?)_{3}',   r'<b><i>\1</i></b>', text)

    # Bold: **text** or __text__
    text = re.sub(r'\*{2}(.+?)\*{2}', r'<b>\1</b>', text)
    text = re.sub(r'_{2}(.+?)_{2}',   r'<b>\1</b>', text)

    # Italic: *text* or _text_  (not inside words)
    text = re.sub(r'(?<!\w)\*(.+?)\*(?!\w)', r'<i>\1</i>', text)
    text = re.sub(r'(?<!\w)_(.+?)_(?!\w)',   r'<i>\1</i>', text)

    # Strikethrough: ~~text~~
    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    # Inline code: ``code`` (double backtick) — must come before single
    text = re.sub(r'``([^`]+?)``',
                  r'<code style="background:#1e1e1e;color:#d4d4d4;'
                  r'padding:1px 4px;border-radius:3px;">\1</code>', text)
    # Inline code: `code` (single backtick)
    text = re.sub(r'`([^`]+)`',
                  r'<code style="background:#1e1e1e;color:#d4d4d4;'
                  r'padding:1px 4px;border-radius:3px;">\1</code>', text)

    # Links: [text](url)
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)',
                  r'<a href="\2" style="color:#4ec9b0;">\1</a>', text)

    return text


# ---------------------------------------------------------------------------
# Block-level parser — splits raw markdown into block tokens
# ---------------------------------------------------------------------------
def parse_blocks(text):
    """
    Parse markdown text into a list of block tokens.
    Each token is a dict with a 'type' key and type-specific fields.
    Each block also carries '_char_end': the absolute character offset in
    *text* immediately after this block (used for incremental streaming render).
    """
    # ── pre-pass: extract <think>...</think> blocks ───────────────────
    # Split text into think/non-think segments before line parsing.
    # Track each segment's start offset in the original text so we can
    # convert relative _char_end values to absolute positions.
    raw_blocks = []   # (seg_type, seg_text, seg_offset_in_text)
    think_pattern = re.compile(r'<think>(.*?)</think>', re.DOTALL | re.IGNORECASE)
    last = 0
    for m in think_pattern.finditer(text):
        if m.start() > last:
            raw_blocks.append(("text", text[last:m.start()], last))
        # Think block ends at m.end() (right after </think>)
        raw_blocks.append(("think", m.group(1).strip(), m.end()))
        last = m.end()
    if last < len(text):
        raw_blocks.append(("text", text[last:], last))

    blocks = []
    for seg_type, seg_text, seg_offset in raw_blocks:
        if seg_type == "think":
            # seg_offset is the absolute position of the end of </think>
            blocks.append({"type": "think", "content": seg_text,
                           "_char_end": seg_offset})
        else:
            seg_blocks = _parse_text_blocks(seg_text)
            for b in seg_blocks:
                b["_char_end"] = seg_offset + b.get("_char_end", len(seg_text))
            blocks.extend(seg_blocks)
    return blocks


def _parse_list_items(lines, base_indent):
    """
    Recursively parse a list of raw lines into a tree of list items.

    Each item is a dict:
        {
            "ordered": bool,
            "num":     int | None,   # None for bullet items
            "content": str,
            "children": [ ... ]      # nested items at deeper indent
        }

    Items at exactly `base_indent` spaces are siblings.
    Lines with greater indent become children of the preceding item.
    """
    items  = []
    i      = 0

    while i < len(lines):
        l = lines[i]
        if not l.strip():          # skip blank lines inside list
            i += 1
            continue

        indent = len(l) - len(l.lstrip())
        if indent < base_indent:   # de-dented past our level — stop
            break

        if indent > base_indent:   # deeper than expected — attach to last item
            if items:
                items[-1]["children"] += _parse_list_items(lines[i:], indent)
            i += 1
            continue

        # Match bullet or numbered marker at this indent level
        bm = re.match(r'^(\s*)([-*+•·‣⁃])\s+(.*)', l)
        nm = re.match(r'^(\s*)(\d+)\.\s+(.*)', l)

        if bm:
            content = bm.group(3).rstrip()
            items.append({"ordered": False, "num": None,
                          "content": content, "children": []})
            i += 1
        elif nm:
            content = nm.group(3).rstrip()
            items.append({"ordered": True, "num": int(nm.group(2)),
                          "content": content, "children": []})
            i += 1
        else:
            i += 1   # unrecognised line — skip

        # Collect immediately following deeper-indented lines as children
        child_lines = []
        while i < len(lines):
            nl = lines[i]
            if not nl.strip():
                # Blank line: peek ahead — if next non-blank is deeper, include
                j = i + 1
                while j < len(lines) and not lines[j].strip():
                    j += 1
                if j < len(lines):
                    next_indent = len(lines[j]) - len(lines[j].lstrip())
                    if next_indent > base_indent:
                        i += 1
                        continue
                break
            next_indent = len(nl) - len(nl.lstrip())
            if next_indent > base_indent:
                child_lines.append(nl)
                i += 1
            else:
                break

        if child_lines and items:
            child_base = len(child_lines[0]) - len(child_lines[0].lstrip())
            items[-1]["children"] += _parse_list_items(child_lines, child_base)

    return items


def _parse_text_blocks(text):
    """Parse a plain text segment into markdown blocks (no think tags).
    Each block dict includes '_char_end': the character offset in *text*
    immediately after the block's last character (used for incremental rendering).
    """
    # Use keepends=True so we can compute exact character positions per line.
    lines_with_nl = text.splitlines(keepends=True)
    lines = [l.rstrip('\r\n') for l in lines_with_nl]

    # _line_starts[i] = char offset in text where line i begins.
    # _line_starts[len(lines)] = len(text).
    _line_starts = [0]
    for l in lines_with_nl:
        _line_starts.append(_line_starts[-1] + len(l))

    def _ce(line_idx):
        """Char offset right after line (line_idx-1), i.e. start of line_idx."""
        return _line_starts[min(line_idx, len(lines))]

    blocks = []
    i      = 0

    while i < len(lines):
        line = lines[i]

        # ── fenced code block (including action fences) ──────────────
        m = re.match(r'^\s*```(\S*)\s*$', line)
        if m:
            lang  = m.group(1)
            code_lines = []
            i += 1
            while i < len(lines) and not re.match(r'\s*```', lines[i]):
                code_lines.append(lines[i])
                i += 1
            fence_found = i < len(lines)  # True = closing ``` found; False = buffer exhausted
            i += 1  # skip closing ``` (or step past end)
            _ACTION_PREFIXES = ("file:", "run:", "install:", "patch:")
            block_type = "action" if any(lang.startswith(p) for p in _ACTION_PREFIXES) else "code"
            blocks.append({"type": block_type, "lang": lang,
                           "content": "\n".join(code_lines),
                           "_char_end": _ce(i),
                           "_closed": fence_found})
            continue

        # ── heading ──────────────────────────────────────────────────
        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            level = len(m.group(1))
            i += 1
            blocks.append({"type": "heading", "level": level,
                           "content": m.group(2).strip(),
                           "_char_end": _ce(i)})
            continue

        # ── horizontal rule ──────────────────────────────────────────
        if re.match(r'^(---+|\*\*\*+|___+)\s*$', line):
            i += 1
            blocks.append({"type": "hr", "_char_end": _ce(i)})
            continue

        # ── blockquote ───────────────────────────────────────────────
        if line.startswith("> ") or line == ">":
            quote_lines = []
            while i < len(lines) and (lines[i].startswith("> ") or
                                       lines[i] == ">"):
                quote_lines.append(lines[i][2:] if lines[i].startswith("> ")
                                   else lines[i][1:])
                i += 1
            blocks.append({"type": "blockquote",
                           "content": "\n".join(quote_lines),
                           "_char_end": _ce(i)})
            continue

        # ── table ────────────────────────────────────────────────────
        if "|" in line and i + 1 < len(lines) and re.match(
                r'^\s*\|?[\s\-:|]+\|', lines[i + 1]):
            rows = []
            while i < len(lines) and "|" in lines[i]:
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            ce = _ce(i)
            # rows[0] = header, rows[1] = separator, rows[2:] = data
            if len(rows) >= 2:
                header = rows[0]
                data   = rows[2:] if len(rows) > 2 else []
                blocks.append({"type": "table", "header": header,
                               "rows": data, "_char_end": ce})
                continue
            # Fallback: treat as paragraph
            for r in rows:
                blocks.append({"type": "paragraph",
                               "content": " | ".join(r),
                               "_char_end": ce})
            continue

        # ── list (bullet or numbered, arbitrary nesting) ─────────────
        if re.match(r'^(\s*)([-*+•·‣⁃]|\d+\.)\s+', line):
            # Collect all consecutive list lines (including blank lines
            # between items) into a raw block, then parse recursively.
            raw = []
            while i < len(lines):
                l = lines[i]
                if re.match(r'^\s*([-*+•·‣⁃]|\d+\.)\s+', l):
                    raw.append(l)
                    i += 1
                elif l.strip() == "":
                    # Keep blank only if next non-blank is still a list item
                    j = i + 1
                    while j < len(lines) and lines[j].strip() == "":
                        j += 1
                    if j < len(lines) and re.match(
                            r'^\s*([-*+•·‣⁃]|\d+\.)\s+', lines[j]):
                        i += 1   # skip blank, stay in list
                    else:
                        break    # end of list
                else:
                    break
            blocks.append({"type": "list",
                           "items": _parse_list_items(raw, 0),
                           "_char_end": _ce(i)})
            continue

        # ── blank line ───────────────────────────────────────────────
        if line.strip() == "":
            i += 1
            continue

        # ── paragraph (collect until blank line or block element) ────
        para_lines = []
        while i < len(lines):
            l = lines[i]
            if (l.strip() == "" or
                    re.match(r'^#{1,6}\s', l) or
                    re.match(r'^```', l) or
                    re.match(r'^(---+|\*\*\*+|___+)\s*$', l) or
                    re.match(r'^>\s?', l) or
                    re.match(r'^\s*[-*+•·‣⁃]\s+', l) or
                    re.match(r'^\d+\.\s+', l) or
                    ("|" in l and i + 1 < len(lines) and
                     re.match(r'^\s*\|?[\s\-:|]+\|', lines[i + 1]
                              if i + 1 < len(lines) else ""))):
                break
            para_lines.append(l)
            i += 1
        if para_lines:
            blocks.append({"type": "paragraph",
                           "content": " ".join(para_lines),
                           "_char_end": _ce(i)})

    return blocks


# ---------------------------------------------------------------------------
# Qt widget builders for each block type
# ---------------------------------------------------------------------------

def _make_label(html, selectable=True, word_wrap=True, text_color="#d4d4d4",
                font_size=10):
    lbl = QLabel()
    lbl.setTextFormat(Qt.RichText)
    lbl.setWordWrap(word_wrap)
    lbl.setText(html)
    lbl.setOpenExternalLinks(True)
    lbl.setStyleSheet(
        f"background: transparent; padding: 1px 8px; "
        f"color: {text_color}; font-size: {font_size}pt;")
    if selectable:
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard |
            Qt.LinksAccessibleByMouse)
    return lbl


def build_heading(block, base_size=14):
    level   = block["level"]
    content = _inline_to_html(block["content"])
    # Scale heading levels relative to base_size
    sizes   = {1: base_size, 2: base_size - 2, 3: base_size - 4,
               4: base_size - 5, 5: base_size - 6, 6: base_size - 7}
    size    = max(sizes.get(level, base_size - 4), 8)
    colors  = {1: "#4ec9b0", 2: "#4ec9b0", 3: "#9cdcfe"}
    color   = colors.get(level, "#d4d4d4")
    # Wrap in a block element so Qt rich-text gives the glyph room
    # Use emoji-capable font family so keycap sequences (1⃣ etc.) render cleanly
    emoji_fonts = "'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', 'Noto Emoji', 'Twemoji Mozilla', sans-serif"
    html    = (f'<p style="margin-top:4px; margin-bottom:0; padding-left:4px;">'
               f'<span style="font-size:{size}pt; font-weight:bold; color:{color};'
               f'font-family:{emoji_fonts};">{content}</span></p>')
    w = _make_label(html, text_color=color, font_size=size)
    w.setStyleSheet(
        f"background: transparent; padding: 6px 8px 4px 10px; "
        f"color: {color}; font-size: {size}pt;")
    return w


def build_paragraph(block, text_color="#d4d4d4", font_size=10):
    html = _inline_to_html(block["content"])
    return _make_label(
        f'<span style="color:{text_color};">{html}</span>',
        text_color=text_color, font_size=font_size)


def build_hr():
    line = QFrame()
    line.setFrameShape(QFrame.HLine)
    line.setFrameShadow(QFrame.Sunken)
    line.setStyleSheet("color: #555; margin: 4px 8px;")
    return line


def build_think(block, font_size=9):
    """Collapsible thinking block with distinct background."""
    outer = QFrame()
    # Expanding horizontally so the frame fills the scroll-area width.
    # Labels inside inherit this width, which makes setWordWrap(True) work correctly.
    outer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    outer.setStyleSheet(
        "QFrame { background: #1a2a1a; border: 1px solid #2a3d2a; "
        "border-radius: 4px; margin: 2px 8px; }")
    lay = QVBoxLayout(outer)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(0)

    # Header row with toggle button
    header = QWidget()
    header.setStyleSheet(
        "background: #243824; border-bottom: 1px solid #2a3d2a; "
        "border-radius: 4px 4px 0 0;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 3, 8, 3)
    icon_lbl = QLabel("🧠")
    icon_lbl.setStyleSheet("background: transparent; border: none; font-size: 11px;")
    hl.addWidget(icon_lbl)
    title_lbl = QLabel("Thinking…")
    title_lbl.setStyleSheet(
        f"color: #7ec87e; font-size: {font_size}pt; "
        "background: transparent; border: none;")
    hl.addWidget(title_lbl)
    hl.addStretch()
    toggle_btn = QPushButton("▾ hide")
    toggle_btn.setFlat(True)
    toggle_btn.setStyleSheet(
        f"QPushButton {{ color: #7ec87e; font-size: {font_size}pt; border: none; "
        "background: transparent; padding: 0 4px; }"
        "QPushButton:hover { color: #aeeaae; }")
    hl.addWidget(toggle_btn)
    lay.addWidget(header)

    # Content area — QPlainTextEdit with vertical scrollbar.
    # Fixed max-height avoids all the dynamic sizing complexity.
    from qtpy.QtWidgets import QPlainTextEdit

    content_w = QPlainTextEdit()
    content_w.setReadOnly(True)
    content_w.setFrameShape(QFrame.NoFrame)
    content_w.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    content_w.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    content_w.setLineWrapMode(QPlainTextEdit.WidgetWidth)
    content_w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    content_w.setStyleSheet(
        f"QPlainTextEdit {{ background: transparent; border: none; "
        f"color: #8abf8a; font-size: {font_size}pt; "
        f"padding: 6px 10px; }}")
    content_w.setPlainText(block["content"])
    content_w.setMaximumHeight(200)

    lay.addWidget(content_w)

    # Wire toggle — preserves the viewport position of the think block header
    def _toggle():
        # Walk up the widget tree to find the enclosing QScrollArea so we can
        # restore the on-screen position of this block after the layout reflows.
        scroll_area = None
        p = outer.parent()
        while p is not None:
            if isinstance(p, QScrollArea):
                scroll_area = p
                break
            p = p.parent()

        if scroll_area is not None:
            vsb      = scroll_area.verticalScrollBar()
            outer_y  = outer.mapTo(scroll_area.widget(), QPoint(0, 0)).y()
            screen_y = outer_y - vsb.value()   # current visual offset from viewport top

        visible = content_w.isVisible()
        content_w.setVisible(not visible)
        toggle_btn.setText("▸ show" if visible else "▾ hide")

        if scroll_area is not None:
            # Restore after Qt reflows the layout (rangeChanged fires synchronously
            # during setVisible and may have already moved the scrollbar).
            def _restore():
                new_outer_y = outer.mapTo(scroll_area.widget(), QPoint(0, 0)).y()
                vsb.setValue(max(0, new_outer_y - screen_y))
            QTimer.singleShot(0, _restore)

    toggle_btn.clicked.connect(_toggle)
    return outer


def build_blockquote(block, text_color="#d4d4d4", font_size=10):
    w   = QFrame()
    w.setStyleSheet(
        "QFrame { border-left: 3px solid #4a90d9; "
        "background: rgba(74,144,217,0.08); "
        "margin: 2px 8px; border-radius: 2px; }")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(10, 4, 8, 4)
    lay.setSpacing(2)
    for line in block["content"].splitlines():
        lbl = _make_label(
            f'<i style="color:#9cdcfe;">{_inline_to_html(line)}</i>',
            text_color="#9cdcfe", font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: #9cdcfe; font-size: {font_size}pt;")
        lay.addWidget(lbl)
    return w


def _build_list_widget(items, text_color, font_size, depth=0):
    """Recursively build a QWidget for a list tree at the given depth."""
    w   = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(depth * 16, 0, 0, 0)
    lay.setSpacing(1)

    for item in items:
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)

        # Marker: number or bullet symbol, cycling through styles by depth
        if item["ordered"]:
            marker_text = f"{item['num']}."
            marker_w    = 28
        else:
            symbols     = ["•", "◦", "▪", "▸"]
            marker_text = symbols[min(depth, len(symbols) - 1)]
            marker_w    = 14

        marker = QLabel(marker_text)
        marker.setStyleSheet(
            f"color: #4ec9b0; padding: 0 6px 0 0; background: transparent; "
            f"font-size: {font_size}pt;"
            + (" font-weight: bold;" if item["ordered"] and depth == 0 else ""))
        marker.setFixedWidth(marker_w)
        row.addWidget(marker, 0, Qt.AlignTop)

        # Item text
        lbl = _make_label(
            f'<span style="color:{text_color};">'
            f'{_inline_to_html(item["content"])}</span>',
            text_color=text_color, font_size=font_size)
        lbl.setStyleSheet(
            f"background: transparent; padding: 0; color: {text_color}; "
            f"font-size: {font_size}pt;")
        row.addWidget(lbl, 1)
        lay.addLayout(row)

        # Recurse into children
        if item.get("children"):
            lay.addWidget(
                _build_list_widget(item["children"], text_color,
                                   font_size, depth + 1))
    return w


def build_list(block, text_color="#d4d4d4", font_size=10):
    """Build a recursively nested list widget."""
    return _build_list_widget(block["items"], text_color, font_size, depth=0)


class _AutoHeightTextBrowser(QTextBrowser):
    """QTextBrowser that auto-adjusts its height to fit content on resize."""

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._adjust_height()

    def showEvent(self, event):
        super().showEvent(event)
        self._adjust_height()

    def wheelEvent(self, event):
        # Pass wheel events to the parent so the chat window scrolls instead
        event.ignore()

    def _adjust_height(self):
        doc = self.document()
        doc.setTextWidth(self.viewport().width())
        h = int(doc.size().height())
        self.setFixedHeight(max(h + 4, 20))


def build_table(block, font_size=10):
    header_cells = "".join(
        f'<th style="background-color:#2d2d2d; color:#4ec9b0; font-weight:bold;'
        f' padding:4px 8px; border:1px solid #444;">'
        f'{_inline_to_html(cell)}</th>'
        for cell in block["header"]
    )
    body_rows = ""
    for row_i, row in enumerate(block["rows"]):
        bg = "#1e1e1e" if row_i % 2 == 0 else "#252525"
        cells = "".join(
            f'<td style="background-color:{bg}; color:#d4d4d4;'
            f' padding:3px 8px; border:1px solid #444;">'
            f'{_inline_to_html(row[col] if col < len(row) else "")}</td>'
            for col in range(len(block["header"]))
        )
        body_rows += f"<tr>{cells}</tr>"

    html = (
        f'<table style="border-collapse:collapse; width:100%;'
        f' font-size:{font_size}pt;">'
        f'<thead><tr>{header_cells}</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        f'</table>'
    )

    browser = _AutoHeightTextBrowser()
    browser.setHtml(html)
    browser.setOpenExternalLinks(True)
    browser.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    browser.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    browser.setStyleSheet(
        "QTextBrowser { background-color: transparent; border: none;"
        " margin: 4px 8px; padding: 0; }"
    )
    return browser


def build_code_block(block, insert_signal=None, font_size=10):
    """Build a code block frame with header bar and copy button."""
    lang = block["lang"]
    code = block["content"]

    frame = QFrame()
    frame.setFrameShape(QFrame.StyledPanel)
    frame.setStyleSheet(
        "QFrame { background: #1e1e1e; border: 1px solid #444; "
        "border-radius: 4px; margin: 2px 8px; }")
    fl = QVBoxLayout(frame)
    fl.setContentsMargins(0, 0, 0, 0)
    fl.setSpacing(0)

    # Code text — created first so the header's copy button can capture it
    from qtpy.QtWidgets import QPlainTextEdit as _PTE
    code_lbl = _PTE()
    code_lbl.setReadOnly(True)
    code_lbl.setFrameShape(QFrame.NoFrame)
    code_lbl.setLineWrapMode(_PTE.NoWrap)
    code_lbl.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    code_lbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    code_lbl.setFont(QFont("Monospace", font_size))
    code_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    code_lbl.setStyleSheet(
        "QPlainTextEdit { color: #d4d4d4; background: transparent; "
        "padding: 8px 10px; border: none; }")
    code_lbl.setPlainText(code)
    # Height = text lines + vertical padding + horizontal scrollbar.
    # fontMetrics().lineSpacing() is the real per-line pixel height for this font/DPI.
    # 24 px = CSS padding (8 top + 8 bottom = 16 px) + QTextDocument document margin
    #         (4 px × 2 sides = 8 px).
    # horizontalScrollBar().sizeHint().height() reserves space for the scrollbar so
    # it never overlaps the last code line(s) when wide content triggers it.
    n_lines = code.count("\n") + 1
    sb_h = code_lbl.horizontalScrollBar().sizeHint().height()
    code_lbl.setFixedHeight(n_lines * code_lbl.fontMetrics().lineSpacing() + 24 + sb_h)

    # Header — built after code_lbl so the copy button lambda can capture it
    header = QWidget()
    header.setStyleSheet("background: #2d2d2d; border-bottom: 1px solid #444;")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 2, 4, 2)
    lang_lbl = QLabel(lang if lang else "code")
    lang_lbl.setStyleSheet(
        "color: #888; font-size: 10px; background: transparent; border: none;")
    hl.addWidget(lang_lbl)
    hl.addStretch()
    if insert_signal is not None:
        copy_btn = QPushButton("📋 Copy to editor")
        copy_btn.setFlat(True)
        copy_btn.setStyleSheet(
            "QPushButton { color: #4ec9b0; font-size: 10px; "
            "padding: 1px 6px; border: none; background: transparent; }"
            "QPushButton:hover { color: #fff; }")
        copy_btn.setToolTip("Insert this code at cursor in the current editor")
        copy_btn.clicked.connect(
            lambda checked=False, pte=code_lbl: insert_signal.emit(pte.toPlainText()))
        hl.addWidget(copy_btn)
    fl.addWidget(header)
    fl.addWidget(code_lbl)
    return frame


# ---------------------------------------------------------------------------
# Done-badge widget with hover ↺ Re-run transition
# ---------------------------------------------------------------------------

class _DoneBadge(QPushButton):
    """
    Green '✓ Done' badge that transitions to '↺ Re-run' (action colour) on hover.
    Clicking always triggers re-run (same as original action button).
    """

    def __init__(self, rerun_color="#5a9a4a", parent=None):
        super().__init__("✓ Done", parent)
        self._rerun_color = rerun_color
        self._done_style = (
            "QPushButton { color: #5a9a5a; font-size: 10px; "
            "border: 1px solid #5a9a5a; border-radius: 3px; padding: 2px 12px; "
            "background: transparent; }")
        self._rerun_style = (
            f"QPushButton {{ color: {rerun_color}; font-size: 10px; "
            f"border: 1px solid {rerun_color}; border-radius: 3px; padding: 2px 12px; "
            "background: transparent; }")
        self.setStyleSheet(self._done_style)

    def enterEvent(self, event):
        self.setText("↺ Re-run")
        self.setStyleSheet(self._rerun_style)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.setText("✓ Done")
        self.setStyleSheet(self._done_style)
        super().leaveEvent(event)


# ---------------------------------------------------------------------------
# Action block widget (file:, run:, install:, patch: fences)
# ---------------------------------------------------------------------------

def _diff_to_html(content, font_size):
    """Convert unified diff text to HTML with coloured lines."""
    import html as _html
    lines = content.split("\n")
    parts = [
        f'<body style="font-family:\'Courier New\',monospace;font-size:{font_size}pt;'
        f'white-space:pre;margin:0;padding:6px 10px;">'
    ]
    for line in lines:
        esc = _html.escape(line) or "&nbsp;"
        if line.startswith("---") or line.startswith("+++"):
            continue  # file header lines — filename already shown in block header
        if line.startswith("@@"):
            # Hunk separator — shown as a subtle divider, not raw metadata
            parts.append(
                '<div style="color:#555;background:#111;border-top:1px solid #333;'
                'border-bottom:1px solid #333;font-size:0.85em;">──────────────</div>'
            )
            continue
        elif line.startswith("-"):
            parts.append(
                f'<div style="color:#f97583;background:#2d0000;">{esc}</div>')
        elif line.startswith("+"):
            parts.append(
                f'<div style="color:#85e89d;background:#002d00;">{esc}</div>')
        else:
            parts.append(f'<div style="color:#d4d4d4;">{esc}</div>')
    parts.append("</body>")
    return "".join(parts)


class _GitWorker(QThread):
    """Runs a git command off the UI thread."""
    done = Signal(str, str, int)   # stdout, stderr, returncode

    def __init__(self, args, cwd):
        super().__init__()
        self._args = args
        self._cwd  = cwd

    def run(self):
        from .agentic_actions import run_git_command
        stdout, stderr, rc = run_git_command(self._args, cwd=self._cwd)
        self.done.emit(stdout or "", stderr or "", rc)


def build_action_block(block, action_env=None, font_size=10):
    """
    Build a widget for an agentic action fence.

    block:      dict with 'lang' (e.g. "file:path/foo.py") and 'content'
    action_env: dict with keys:
        create_file_fn(path, content, base_dir) -> str (written path) or raises
        patch_file_fn(path, diff, base_dir) -> str or raises
        run_console_fn(code) -> None
        install_fn(spec) -> None
        load_file_fn(path) -> None  (opens file in editor after creation)
        base_dir: str or None
        confirm_each: bool
        allow_create_file / allow_run_console / allow_install / allow_patch: bool
    If action_env is None (agentic mode off) the block renders as a plain code block.
    """
    import os as _os

    lang    = block.get("lang", "")
    content = block.get("content", "")

    # ── Allow-flag check — render as plain code if action type is disabled ──
    _ALLOW_KEYS = {
        "file":    "allow_create_file",
        "run":     "allow_run_console",
        "install": "allow_install",
        "patch":   "allow_patch",
        "git":     "allow_git",
    }

    # Determine action type and target
    if lang.startswith("file:"):
        action_type = "file"
        target = lang[5:]
    elif lang == "run:git" or lang.startswith("run:git "):
        action_type = "git"
        target = ""
    elif lang.startswith("run:"):
        action_type = "run"
        target = lang[4:]
    elif lang.startswith("install:"):
        action_type = "install"
        target = lang[8:]
    elif lang.startswith("patch:"):
        action_type = "patch"
        target = lang[6:]
    else:
        return build_code_block(block, font_size=font_size)

    env = action_env or {}
    block_idx = env.get("_block_idx", -1)

    # If agentic env not provided or action type disabled → plain code block
    allow_key = _ALLOW_KEYS.get(action_type)
    if not env or not env.get(allow_key, True):
        return build_code_block(block, font_size=font_size)

    # Pre-executed check (for blocks restored from chat history)
    already_executed = block_idx in env.get("_executed_blocks", set())

    # ── Resolve absolute path for file existence check ────────────────────
    base_dir = env.get("base_dir")
    abs_target = None
    if action_type in ("file", "patch") and target:
        if _os.path.isabs(target):
            abs_target = _os.path.normpath(target)
        elif base_dir:
            abs_target = _os.path.normpath(_os.path.join(base_dir, target))

    # ── Per-action-type styling ───────────────────────────────────────────
    if action_type == "file":
        file_exists = abs_target and _os.path.exists(abs_target)
        if file_exists:
            header_icon  = "📄"
            header_label = f"📄 Overwrite File  →  {target}"
            header_color = "#c8a000"   # amber
            bg_color     = "#1e1500"
            btn_text     = "⚠ Overwrite file"
        else:
            header_icon  = "📄"
            header_label = f"📄 Create File  →  {target}"
            header_color = "#3a80cc"   # blue
            bg_color     = "#09182a"
            btn_text     = "✓ Create file"
    elif action_type == "run":
        header_label = f"▶ Run in console  ({target})"
        header_color = "#3a9a5a"       # green
        bg_color     = "#091e10"
        btn_text     = "▶ Run in console"
    elif action_type == "install":
        header_label = f"⬇ Install package  ({target})"
        header_color = "#2a8a8a"       # teal
        bg_color     = "#001e1e"
        btn_text     = "⬇ Install"
    elif action_type == "git":
        cmd_preview = content.strip().split("\n")[0][:60]
        header_label = f"⎇  $ git {cmd_preview}"
        header_color = "#e8a050"       # orange
        bg_color     = "#1e1000"
        btn_text     = "⎇ Run git command"
    else:  # patch
        header_label = f"✎ Apply patch  →  {target}"
        header_color = "#80c040"       # lime green
        bg_color     = "#0c1a06"
        btn_text     = "✎ Apply patch"

    frame = QFrame()
    frame.setFrameShape(QFrame.StyledPanel)
    frame.setStyleSheet(
        f"QFrame {{ background: {bg_color}; border: 1px solid {header_color}; "
        "border-radius: 4px; margin: 2px 8px; }}")
    fl = QVBoxLayout(frame)
    fl.setContentsMargins(0, 0, 0, 0)
    fl.setSpacing(0)

    # ── Header ───────────────────────────────────────────────────────────
    header = QWidget()
    header.setStyleSheet(
        f"background: {header_color}22; border-bottom: 1px solid {header_color};")
    hl = QHBoxLayout(header)
    hl.setContentsMargins(8, 3, 8, 3)
    header_lbl = QLabel(header_label)
    header_lbl.setStyleSheet(
        f"color: {header_color}; font-size: 10px; font-weight: bold; "
        "background: transparent; border: none;")
    hl.addWidget(header_lbl, 1)
    fl.addWidget(header)

    # ── Code content (not shown for git — command already in header) ─────
    if action_type != "git":
        if action_type == "patch":
            from qtpy.QtWidgets import QTextEdit as _QTE
            from qtpy.QtGui import QTextOption as _QTO
            code_lbl = _QTE()
            code_lbl.setReadOnly(True)
            code_lbl.setFrameShape(QFrame.NoFrame)
            code_lbl.setWordWrapMode(_QTO.NoWrap)
            code_lbl.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            code_lbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            code_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            code_lbl.setStyleSheet(
                "QTextEdit { background: transparent; border: none; padding: 0; }")
            code_lbl.setHtml(_diff_to_html(content, font_size))
        else:
            from qtpy.QtWidgets import QPlainTextEdit as _PTE
            code_lbl = _PTE()
            code_lbl.setReadOnly(True)
            code_lbl.setFrameShape(QFrame.NoFrame)
            code_lbl.setLineWrapMode(_PTE.NoWrap)
            code_lbl.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            code_lbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            code_lbl.setFont(QFont("Monospace", font_size))
            code_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            code_lbl.setStyleSheet(
                "QPlainTextEdit { color: #d4d4d4; background: transparent; "
                "padding: 6px 10px; border: none; }")
            code_lbl.setPlainText(content)
        if action_type == "patch":
            visible_lines = [l for l in content.split("\n")
                             if not (l.startswith("---") or l.startswith("+++"))]
            n_lines = max(len(visible_lines), 1)
        else:
            n_lines = max(content.count("\n") + 1, 1)
        sb_h = code_lbl.horizontalScrollBar().sizeHint().height()
        code_lbl.setFixedHeight(n_lines * code_lbl.fontMetrics().lineSpacing() + 20 + sb_h)
        fl.addWidget(code_lbl)

    # ── Action button row ─────────────────────────────────────────────────
    btn_row = QWidget()
    btn_row.setStyleSheet("background: transparent;")
    brl = QHBoxLayout(btn_row)
    brl.setContentsMargins(8, 4, 8, 6)
    brl.setSpacing(6)
    brl.addStretch()

    exec_btn = QPushButton(btn_text)
    exec_btn.setStyleSheet(
        f"QPushButton {{ color: {header_color}; font-size: 10px; "
        f"border: 1px solid {header_color}; border-radius: 3px; padding: 2px 12px; "
        "background: transparent; }"
        f"QPushButton:hover {{ color: #fff; border-color: #fff; "
        f"background: {header_color}44; }}")
    brl.addWidget(exec_btn)
    exec_btn.setVisible(not already_executed)   # after addWidget — avoids parentless flash

    # Done badge with hover ↺ Re-run — shown immediately for pre-executed blocks
    done_badge = _DoneBadge(rerun_color=header_color)
    brl.addWidget(done_badge)
    done_badge.setVisible(already_executed)     # after addWidget — avoids parentless flash

    # ── Status label ─────────────────────────────────────────────────────
    status_lbl = QLabel("")
    status_lbl.setStyleSheet(
        "color: #888; font-size: 9px; background: transparent; border: none;")
    status_lbl.setWordWrap(True)
    brl.addWidget(status_lbl, 1)

    fl.addWidget(btn_row)

    # ── Git output panel (hidden until command runs) ──────────────────────
    git_output_panel = None
    if action_type == "git":
        git_output_panel = QWidget()
        git_output_panel.setStyleSheet("background: transparent;")
        git_output_panel.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        git_out_lay = QVBoxLayout(git_output_panel)
        git_out_lay.setContentsMargins(8, 0, 8, 6)
        git_out_lay.setSpacing(4)

        from qtpy.QtWidgets import QPlainTextEdit as _PTE2
        git_out_edit = _PTE2()
        git_out_edit.setReadOnly(True)
        git_out_edit.setFrameShape(QFrame.NoFrame)
        git_out_edit.setLineWrapMode(_PTE2.NoWrap)
        git_out_edit.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        git_out_edit.setFont(QFont("Monospace", font_size - 1))
        git_out_edit.setStyleSheet(
            "QPlainTextEdit { color: #d4d4d4; background: #111; "
            "border: 1px solid #333; border-radius: 3px; padding: 4px; }")
        git_out_edit.setMaximumHeight(180)
        git_out_lay.addWidget(git_out_edit)

        git_btn_row = QHBoxLayout()
        git_btn_row.setSpacing(6)
        git_btn_row.addStretch()

        git_attach_btn = QPushButton("📎 Add to chat")
        git_attach_btn.setStyleSheet(
            f"QPushButton {{ color: {header_color}; font-size: 10px; "
            f"border: 1px solid {header_color}; border-radius: 3px; padding: 2px 10px; "
            "background: transparent; }"
            f"QPushButton:hover {{ color: #fff; border-color: #fff; "
            f"background: {header_color}44; }}")

        git_dismiss_btn = QPushButton("✕ Dismiss")
        git_dismiss_btn.setStyleSheet(
            "QPushButton { color: #888; font-size: 10px; "
            "border: 1px solid #555; border-radius: 3px; padding: 2px 10px; "
            "background: transparent; }"
            "QPushButton:hover { color: #fff; border-color: #aaa; }")

        git_btn_row.addWidget(git_attach_btn)
        git_btn_row.addWidget(git_dismiss_btn)
        git_out_lay.addLayout(git_btn_row)

        git_output_panel.setVisible(False)
        fl.addWidget(git_output_panel)

        def _on_git_dismiss():
            git_output_panel.setVisible(False)
            exec_btn.setVisible(False)
            done_badge.setVisible(True)   # command ran — show done, re-run on click

        def _on_git_attach():
            out_text = git_out_edit.toPlainText()
            cmd_text = content.strip()
            inject_fn = env.get("inject_git_output_fn")
            if inject_fn:
                inject_fn(f"git {cmd_text}", out_text)
            git_output_panel.setVisible(False)
            exec_btn.setVisible(False)
            done_badge.setVisible(True)

        git_dismiss_btn.clicked.connect(_on_git_dismiss)
        git_attach_btn.clicked.connect(_on_git_attach)

    # ── Execute logic ─────────────────────────────────────────────────────
    def _run_action(final_target, live_base_dir=None):
        """Execute the action — called after confirmation."""
        bd = live_base_dir or base_dir
        try:
            if action_type == "file":
                fn = env.get("create_file_fn")
                written = fn(final_target, content, bd) if fn else None
                if written is None:
                    from .agentic_actions import execute_create_file
                    written = execute_create_file(final_target, content, bd)
                status_lbl.setText(f"✓ Written: {written}")
                # Switch block appearance to "Overwrite" state immediately
                _ow = "#c8a000"   # amber
                _ow_bg = "#1e1500"
                frame.setStyleSheet(
                    f"QFrame {{ background: {_ow_bg}; border: 1px solid {_ow}; "
                    "border-radius: 4px; margin: 2px 8px; }}")
                header.setStyleSheet(
                    f"background: {_ow}22; border-bottom: 1px solid {_ow};")
                header_lbl.setText(f"📄 Overwrite File  →  {target}")
                header_lbl.setStyleSheet(
                    f"color: {_ow}; font-size: 10px; font-weight: bold; "
                    "background: transparent; border: none;")
                exec_btn.setText("⚠ Overwrite file")
                exec_btn.setStyleSheet(
                    f"QPushButton {{ color: {_ow}; font-size: 10px; "
                    f"border: 1px solid {_ow}; border-radius: 3px; padding: 2px 12px; "
                    "background: transparent; }"
                    f"QPushButton:hover {{ color: #fff; border-color: #fff; "
                    f"background: {_ow}44; }}")
                done_badge._rerun_color = _ow
                done_badge._rerun_style = (
                    f"QPushButton {{ color: {_ow}; font-size: 10px; "
                    f"border: 1px solid {_ow}; border-radius: 3px; padding: 2px 12px; "
                    "background: transparent; }}")
                # Open in editor if available
                load_fn = env.get("load_file_fn")
                if load_fn:
                    try:
                        load_fn(written)
                    except Exception:
                        pass
            elif action_type == "run":
                fn = env.get("run_console_fn")
                if not fn:
                    status_lbl.setText("⚠ No console available")
                    return
                fn(content)
                status_lbl.setText("✓ Sent to console")
            elif action_type == "install":
                spec = content.strip() or final_target
                fn = env.get("install_fn")
                if not fn:
                    status_lbl.setText("⚠ No console available")
                    return
                fn(spec)
                status_lbl.setText(f"✓ Installing: {spec}")
            elif action_type == "patch":
                fn = env.get("patch_file_fn")
                written = fn(final_target, content, bd) if fn else None
                if written is None:
                    from .agentic_actions import execute_patch_file
                    written = execute_patch_file(final_target, content, bd)
                status_lbl.setText(f"✓ Patched: {written}")
                # Reload the file in the editor if it is already open
                reload_fn = env.get("reload_file_fn")
                if reload_fn and written:
                    try:
                        reload_fn(written)
                    except Exception:
                        pass
            elif action_type == "git":
                import shlex as _shlex
                args = _shlex.split(content.strip())
                exec_btn.setEnabled(False)
                exec_btn.setText("⏳ Running…")
                status_lbl.setText("")

                worker = _GitWorker(args, bd)

                def _on_git_done(stdout, stderr, rc, _w=worker):
                    output = (stdout + stderr).strip() or "(no output)"
                    git_out_edit.setPlainText(output)
                    n    = max(output.count("\n") + 1, 1)
                    lh   = git_out_edit.fontMetrics().lineSpacing()
                    edit_h = min(n * lh + 16, 180)
                    git_out_edit.setFixedHeight(edit_h)
                    git_output_panel.setFixedHeight(edit_h + 42)
                    git_output_panel.setVisible(True)
                    exec_btn.setVisible(False)
                    exec_btn.setEnabled(True)
                    exec_btn.setText(btn_text)
                    if rc != 0:
                        status_lbl.setText(f"⚠ git exited with code {rc}")
                    # Persist execution record so done badge survives history reload
                    on_exec = env.get("on_executed")
                    if on_exec:
                        try:
                            on_exec(block_idx, action_type, content.strip())
                        except Exception:
                            pass
                    _w.deleteLater()

                worker.done.connect(_on_git_done)
                worker.start()
                return   # buttons handled by git_attach/dismiss — skip done_badge here
        except Exception as exc:
            status_lbl.setText(f"⚠ {exc}")
            return
        exec_btn.setVisible(False)
        done_badge.setVisible(True)
        # Notify parent to persist this execution in message history
        on_exec = env.get("on_executed")
        if on_exec:
            try:
                on_exec(block_idx, action_type, target)
            except Exception:
                pass

    def _on_execute():
        final_target = target
        # Resolve base_dir lazily so it reflects the current project root
        # even when this block was rendered at startup before the project loaded.
        live_base_dir = env.get("base_dir_fn", lambda: base_dir)()
        confirm = env.get("confirm_each", True)

        if confirm:
            from .agentic_actions import show_confirm_dialog
            parent_widget = frame.window()
            confirmed, final_target = show_confirm_dialog(
                parent_widget, action_type, target, content,
                base_dir=live_base_dir)
            if not confirmed:
                return

        _run_action(final_target, live_base_dir)

    exec_btn.clicked.connect(_on_execute)
    done_badge.clicked.connect(_on_execute)   # re-run on Done badge click

    return frame


# ---------------------------------------------------------------------------
# Main entry point: render markdown text into a QWidget
# ---------------------------------------------------------------------------
def render_markdown(text, insert_signal=None, font_cfg=None, action_env=None):
    """
    Parse markdown text and return a QWidget containing all rendered blocks.
    insert_signal: optional Signal(str) emitted when user clicks "Copy to editor"
    font_cfg: optional dict with keys fs_base, fs_code, fs_heading, fs_list,
              fs_table, fs_think (all in pt). Falls back to defaults if absent.
    """
    from .settings_dialog import EDITOR_DEFAULTS
    cfg = {**EDITOR_DEFAULTS, **(font_cfg or {})}

    try:
        from spyder.config.gui import is_dark_interface
        text_color = "#d4d4d4" if is_dark_interface() else "#1a1a1a"
    except Exception:
        text_color = "#d4d4d4"

    container = QWidget()
    container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    lay = QVBoxLayout(container)
    lay.setContentsMargins(0, 2, 0, 2)
    lay.setSpacing(3)

    blocks = parse_blocks(text)
    has_code = any(b["type"] == "code" for b in blocks)

    for block in blocks:
        t = block["type"]
        if t == "think":
            lay.addWidget(build_think(block, cfg["fs_think"]))
        elif t == "heading":
            lay.addWidget(build_heading(block, cfg["fs_heading"]))
        elif t == "paragraph":
            lay.addWidget(build_paragraph(block, text_color, cfg["fs_base"]))
        elif t == "code":
            lay.addWidget(build_code_block(block, insert_signal, cfg["fs_code"]))
        elif t == "action":
            lay.addWidget(build_action_block(block, action_env, cfg["fs_code"]))
        elif t == "hr":
            lay.addWidget(build_hr())
        elif t == "blockquote":
            lay.addWidget(build_blockquote(block, text_color, cfg["fs_base"]))
        elif t == "list":
            lay.addWidget(build_list(block, text_color, cfg["fs_list"]))
        elif t == "table":
            lay.addWidget(build_table(block, cfg["fs_table"]))

    if not has_code and insert_signal is not None:
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        copy_all = QPushButton("📋 Copy to editor")
        copy_all.setFlat(True)
        copy_all.setStyleSheet(
            "QPushButton { color: #888; font-size: 10px; padding: 1px 4px; "
            "border: none; background: transparent; }"
            "QPushButton:hover { color: #ccc; }")
        copy_all.setToolTip("Insert full response at cursor in current editor")
        copy_all.clicked.connect(
            lambda checked=False, t=text: insert_signal.emit(t))
        btn_row.addWidget(copy_all)
        lay.addLayout(btn_row)

    return container
