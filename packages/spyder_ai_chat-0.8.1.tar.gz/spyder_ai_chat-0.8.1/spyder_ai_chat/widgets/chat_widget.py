# -*- coding: utf-8 -*-
"""AI Chat Panel — Spyder 6 plugin (C) 2026 by Maciej Piecko"""

import json
import threading

from qtpy.QtCore import Qt, Signal, Slot, QEvent, QObject, QThread, QTimer
from qtpy.QtGui import QFont, QTextCursor, QTextCharFormat, QColor
from qtpy.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QFrame, QPlainTextEdit, QPushButton, QTabWidget, QTextEdit,
    QVBoxLayout, QWidget, QSizePolicy, QToolButton, QStyle, QScrollArea,
    QSpinBox,
)
from qtpy.QtCore import QFileSystemWatcher

from .chat_history_manager import (
    save_chat, load_chat, delete_chat, list_chats, search_chats,
    list_collections, move_chat,
)
from .collection_manager import ChatCollectionManagerDialog
from .commands import load_commands, save_commands, get_command_prompt

DEFAULT_MODELS = [
    "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo",
    "llama3", "mistral", "codellama", "phi3",
]

# Styles for the inference params summary bar label
_PARAMS_BAR_IDLE_STYLE = (
    "QPushButton { color: #ccc; font-size: 9px; text-align: left; "
    "border: none; padding: 0 4px; }"
    "QPushButton:hover { color: #fff; }"
)
_PARAMS_BAR_ACTIVE_STYLE = (
    "QPushButton { color: #c8a000; font-size: 9px; text-align: left; "
    "border: none; padding: 0 4px; }"
    "QPushButton:hover { color: #ffe080; }"
)



# ---------------------------------------------------------------------------
# Command-input widget
# A QPlainTextEdit that:
#  - watches for "/" typed by the user and shows a command-picker dropdown
#  - tracks which text spans are "active commands" (typed via the picker)
#  - highlights active-command spans with a tinted background
#  - translates active-command spans to their prompt text at send-time
#
# KEY DESIGN: "active command" tracking
#   self._active_commands = list of dicts:
#       { "start": int, "length": int, "name": str }
#   start/length are character positions in the document.
#   A span is ONLY considered an active command if it was selected via the
#   dropdown — typing "/tests" manually (after dismissing the dropdown with
#   Escape) is never added to _active_commands and is sent verbatim.
# ---------------------------------------------------------------------------
class _CommandInput(QPlainTextEdit):
    """Input field with slash-command picker dropdown."""

    # Emitted when Ctrl+Enter is pressed (parent wires this to _send)
    send_requested = Signal()

    # Background colour for highlighted command tokens
    _CMD_BG   = QColor("#2a3a1a")   # dark green tint
    _CMD_FG   = QColor("#b8e090")   # light green text

    def __init__(self, parent=None):
        super().__init__(parent)
        self._commands = []          # list of {name, prompt} — loaded externally
        self._active_commands = []   # list of {start, length, name}
        self._dropdown = None        # _CommandDropdown instance (lazy)
        self._dropdown_slash_pos = -1  # doc position of the '/' that opened dropdown
        self._suppress_change = False

        self.document().contentsChange.connect(self._on_contents_change)

    # ── public ───────────────────────────────────────────────────────────

    def set_commands(self, commands):
        self._commands = commands

    def get_text_for_send(self):
        """Return the plain text with all active-command spans replaced by their prompts."""
        raw = self.toPlainText()
        if not self._active_commands:
            return raw
        # Sort by start position, process in reverse so replacements don't shift offsets
        cmds = sorted(self._active_commands, key=lambda c: c["start"], reverse=True)
        result = list(raw)
        for cmd in cmds:
            s, l = cmd["start"], cmd["length"]
            prompt = get_command_prompt(cmd["name"], self._commands)
            replacement = prompt if prompt else raw[s:s+l]
            result[s:s+l] = list(replacement)
        return "".join(result)

    def clear(self):
        self._active_commands.clear()
        self._dropdown_slash_pos = -1
        self._close_dropdown()
        super().clear()

    # ── dropdown interaction ─────────────────────────────────────────────

    def _open_dropdown(self, slash_pos):
        """Show the command picker anchored near the slash character."""
        if not self._commands:
            return
        self._dropdown_slash_pos = slash_pos
        if self._dropdown is None:
            self._dropdown = _CommandDropdown(self)
            self._dropdown.command_selected.connect(self._on_command_selected)
            self._dropdown.cancelled.connect(self._on_dropdown_cancelled)
        self._dropdown.populate(self._commands)
        self._reposition_dropdown()
        self._dropdown.show()
        self._dropdown.raise_()
        self.setFocus()

    def _close_dropdown(self):
        if self._dropdown and self._dropdown.isVisible():
            self._dropdown.hide()
        self._dropdown_slash_pos = -1

    def _reposition_dropdown(self):
        if self._dropdown is None:
            return
        # Position relative to the slash character, not current cursor
        cursor = self.textCursor()
        if self._dropdown_slash_pos >= 0:
            cursor.setPosition(self._dropdown_slash_pos)
        rect = self.cursorRect(cursor)
        # Global position of the bottom of the slash character
        global_pt = self.mapToGlobal(rect.bottomLeft())
        dd = self._dropdown
        dd.adjustSize()
        dh = dd.sizeHint().height()
        dw = dd.sizeHint().width()
        # Screen geometry to decide above/below
        from qtpy.QtWidgets import QApplication
        screen = QApplication.screenAt(global_pt)
        if screen is None:
            screen = QApplication.primaryScreen()
        sg = screen.availableGeometry()
        # Show above the slash if not enough space below
        if global_pt.y() + dh > sg.bottom():
            y = self.mapToGlobal(rect.topLeft()).y() - dh
        else:
            y = global_pt.y()
        # Clamp horizontally
        x = min(global_pt.x(), sg.right() - dw)
        x = max(x, sg.left())
        dd.move(x, y)

    def _on_command_selected(self, name):
        """User picked a command — replace the '/' + any partial text with '/name'."""
        slash_pos = self._dropdown_slash_pos
        self._close_dropdown()
        if slash_pos < 0:
            return

        cursor = self.textCursor()
        doc_len = len(self.toPlainText())
        current_pos = cursor.position()

        # Replace from slash_pos to current cursor position with '/name'
        cmd_text = "/" + name
        self._suppress_change = True
        cursor.setPosition(slash_pos)
        cursor.setPosition(current_pos, QTextCursor.KeepAnchor)
        cursor.removeSelectedText()
        cursor.insertText(cmd_text)
        self._suppress_change = False

        # Register this as an active command
        self._active_commands.append({
            "start":  slash_pos,
            "length": len(cmd_text),
            "name":   name,
        })
        self._apply_highlights()
        self.setFocus()

    def _on_dropdown_cancelled(self):
        """Escape pressed — close dropdown, leave '/' as plain text (not a command)."""
        self._close_dropdown()
        self.setFocus()

    # ── highlights ───────────────────────────────────────────────────────

    def _apply_highlights(self):
        """Re-apply background highlights for all active-command spans."""
        # Clear all existing extra selections
        self.setExtraSelections([])
        selections = []
        raw = self.toPlainText()
        for cmd in self._active_commands:
            s, l = cmd["start"], cmd["length"]
            if s + l > len(raw):
                continue
            # Verify text still matches (guard against out-of-sync after edit)
            if raw[s:s+l] != "/" + cmd["name"]:
                continue
            cursor = self.textCursor()
            cursor.setPosition(s)
            cursor.setPosition(s + l, QTextCursor.KeepAnchor)
            fmt = QTextCharFormat()
            fmt.setBackground(self._CMD_BG)
            fmt.setForeground(self._CMD_FG)
            sel = QTextEdit.ExtraSelection()
            sel.cursor = cursor
            sel.format = fmt
            selections.append(sel)
        self.setExtraSelections(selections)

    # ── content-change tracking ──────────────────────────────────────────

    def _on_contents_change(self, position, removed, added):
        """Keep _active_commands offsets in sync as text is edited."""
        if self._suppress_change:
            return

        raw = self.toPlainText()
        updated = []
        for cmd in self._active_commands:
            s, l = cmd["start"], cmd["length"]
            end = s + l

            if removed > 0 or added > 0:
                # If the edit touched inside the command span → invalidate it
                edit_end = position + max(removed, added)
                if position < end and edit_end > s:
                    # Edit overlaps span — drop this command
                    continue
                # Shift spans that come after the edit position
                if position <= s:
                    delta = added - removed
                    s += delta
                    cmd = {**cmd, "start": s}

            # Final guard: verify text still matches
            if s >= 0 and s + l <= len(raw) and raw[s:s+l] == "/" + cmd["name"]:
                updated.append(cmd)

        self._active_commands = updated
        self._apply_highlights()

        # Also filter dropdown results if it's open
        if self._dropdown and self._dropdown.isVisible():
            slash_pos = self._dropdown_slash_pos
            cur_pos = self.textCursor().position()
            if slash_pos >= 0 and cur_pos > slash_pos:
                partial = raw[slash_pos + 1 : cur_pos]
                self._dropdown.filter(partial)
            else:
                self._close_dropdown()

    # ── keyboard events ──────────────────────────────────────────────────

    def keyPressEvent(self, event):
        key = event.key()

        # Ctrl+Enter → send
        if key in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ControlModifier:
            self.send_requested.emit()
            return

        # Forward Up/Down/Enter/Escape to dropdown when visible
        if self._dropdown and self._dropdown.isVisible():
            if key == Qt.Key_Escape:
                self._on_dropdown_cancelled()
                return
            if key in (Qt.Key_Up, Qt.Key_Down):
                self._dropdown.move_selection(key == Qt.Key_Down)
                return
            if key in (Qt.Key_Return, Qt.Key_Enter):
                self._dropdown.confirm_selection()
                return

        super().keyPressEvent(event)

        # After typing, check if we just typed '/'
        if key == Qt.Key_Slash:
            pos = self.textCursor().position()
            self._open_dropdown(pos - 1)


# ---------------------------------------------------------------------------
# Command-picker dropdown  (frameless popup list)
# ---------------------------------------------------------------------------
class _CommandDropdown(QFrame):
    """Floating dropdown that lists available slash commands."""

    command_selected = Signal(str)   # emits command name (without '/')
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent, Qt.ToolTip | Qt.FramelessWindowHint)
        self.setStyleSheet(
            "QFrame { background: #1e2a1e; border: 1px solid #3a5a3a; "
            "border-radius: 4px; }"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(0)

        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; "
            "color: #d0d0d0; font-size: 9pt; }"
            "QListWidget::item { padding: 2px 6px; border-radius: 2px; }"
            "QListWidget::item:selected { background: #2a4a2a; color: #b8e090; }"
            "QListWidget::item:hover { background: #243424; }"
        )
        self._list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._list.setFixedWidth(280)
        self._list.itemClicked.connect(self._on_item_click)
        lay.addWidget(self._list)
        self._all_commands = []

    def populate(self, commands):
        self._all_commands = commands
        self._fill(commands)

    def filter(self, partial):
        """Show only commands whose name starts with `partial`."""
        filtered = [c for c in self._all_commands
                    if c["name"].startswith(partial.lower())]
        self._fill(filtered)
        if not filtered:
            self.hide()

    def _fill(self, commands):
        self._list.clear()
        for cmd in commands:
            item = QListWidgetItem(f"/{cmd['name']}")
            # Add short description in muted colour using HTML isn't possible in
            # QListWidget directly — use UserRole for description display via
            # a custom approach: append description with tab spacing
            desc = self._short_desc(cmd["prompt"])
            item.setText(f"/{cmd['name']}   —   {desc}")
            item.setData(Qt.UserRole, cmd["name"])
            self._list.addItem(item)
        if self._list.count():
            self._list.setCurrentRow(0)
        # Resize to content
        rows = min(self._list.count(), 8)
        item_h = self._list.sizeHintForRow(0) if self._list.count() else 28
        self._list.setFixedHeight(rows * item_h + 6)
        self.adjustSize()

    @staticmethod
    def _short_desc(prompt, max_chars=40):
        words = prompt.split()
        out = ""
        for w in words:
            if len(out) + len(w) + 1 > max_chars:
                return out.rstrip() + "…"
            out += w + " "
        return out.strip()

    def move_selection(self, down: bool):
        row = self._list.currentRow()
        n = self._list.count()
        if down:
            row = (row + 1) % n
        else:
            row = (row - 1) % n
        self._list.setCurrentRow(row)

    def confirm_selection(self):
        item = self._list.currentItem()
        if item:
            self.command_selected.emit(item.data(Qt.UserRole))

    def _on_item_click(self, item):
        self.command_selected.emit(item.data(Qt.UserRole))


# ---------------------------------------------------------------------------
# Flow layout — wraps child widgets onto multiple rows like CSS flex-wrap
# ---------------------------------------------------------------------------
from qtpy.QtWidgets import QLayout
from qtpy.QtCore import QRect, QPoint, QSize

class _FlowLayout(QLayout):
    """Simple flow layout that wraps widgets to the next row when the row is full."""

    def __init__(self, parent=None, h_spacing=4, v_spacing=4):
        super().__init__(parent)
        self._items = []
        self._h_spacing = h_spacing
        self._v_spacing = v_spacing

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self):
        return Qt.Orientations(Qt.Orientation(0))

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(),
                      margins.top() + margins.bottom())
        return size

    def _do_layout(self, rect, test_only):
        margins = self.contentsMargins()
        x = rect.x() + margins.left()
        y = rect.y() + margins.top()
        line_height = 0
        right_edge = rect.right() - margins.right()

        for item in self._items:
            w = item.widget()
            hint = item.sizeHint()
            next_x = x + hint.width()
            if next_x > right_edge and line_height > 0:
                x = rect.x() + margins.left()
                y += line_height + self._v_spacing
                next_x = x + hint.width()
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x + self._h_spacing
            line_height = max(line_height, hint.height())

        return y + line_height - rect.y() + margins.bottom()


# ---------------------------------------------------------------------------
# Hover-warmup button: stays disabled/gray until the pointer rests on it,
# then animates gray→red over `warmup_ms` ms and becomes clickable.
# Moving the pointer off while still warming up reverses back to gray/disabled.
# ---------------------------------------------------------------------------
class _WarmupButton(QPushButton):
    """QPushButton that activates only after the cursor hovers for `warmup_ms` ms."""

    STEPS = 20  # animation ticks

    def __init__(self, text, warmup_ms=2000, parent=None):
        super().__init__(text, parent)
        self._warmup_ms = warmup_ms
        self._warmup_step = 0
        self._warmup_timer = None
        self._apply_style(0)
        self.setEnabled(False)

    # ── hover enter: start / resume animation ────────────────────────
    def enterEvent(self, event):
        super().enterEvent(event)
        if self._warmup_timer is None:
            interval = self._warmup_ms // self.STEPS
            self._warmup_timer = QTimer(self)
            self._warmup_timer.setInterval(interval)
            self._warmup_timer.timeout.connect(self._tick)
        self._warmup_timer.start()

    # ── hover leave: stop and reverse ────────────────────────────────
    def leaveEvent(self, event):
        super().leaveEvent(event)
        # Always reset -- button is only clickable while cursor is hovering
        self.reset()

    def _tick(self):
        self._warmup_step += 1
        if self._warmup_step >= self.STEPS:
            self._warmup_timer.stop()
            self._warmup_step = self.STEPS
            self.setEnabled(True)   # clickable only while cursor is here
            self._apply_style(self.STEPS)
        else:
            self._apply_style(self._warmup_step)

    def _apply_style(self, step):
        t = step / self.STEPS
        # gray #888 → red #f44
        r = int(0x88 + (0xff - 0x88) * t)
        g = int(0x88 + (0x44 - 0x88) * t)
        b = int(0x88 + (0x44 - 0x88) * t)
        col = f"#{r:02x}{g:02x}{b:02x}"
        bg_r = max(0x28, int(0x28 + 0x18 * t))
        dim = f"#{bg_r:02x}2828"
        self.setStyleSheet(
            f"QPushButton {{ color: {col}; font-size: 9px; padding: 1px 8px; "
            f"border: 1px solid {col}; border-radius: 3px; background: {dim}; }}"
            f"QPushButton:hover {{ color: #fcc; border-color: #fcc; background: {dim}; }}"
            f"QPushButton:disabled {{ color: {col}; border-color: {col}; background: {dim}; }}")

    def reset(self):
        """Call when popup is shown to put button back to initial gray state."""
        if self._warmup_timer:
            self._warmup_timer.stop()
        self._warmup_step = 0
        self.setEnabled(False)
        self._apply_style(0)


# ---------------------------------------------------------------------------
# Project Context Dialog
# ---------------------------------------------------------------------------
class _ProjectContextDialog(QDialog):
    """
    Folder-selection dialog shown when enabling project context.
    Scans the project root, shows top-level folder checkboxes with file counts,
    and reports an estimated token count.
    """

    def __init__(self, root, max_file_kb=256, max_files=500,
                 extra_patterns=(), parent=None):
        super().__init__(parent)
        self.setWindowTitle("Enable Project Context")
        self.setMinimumWidth(420)

        from .project_context import (
            collect_project_files, collect_unsaved_files,
            get_top_level_folders, estimate_tokens,
        )

        self._root = root
        self._max_file_kb = max_file_kb
        self._max_files = max_files
        self._extra_patterns = extra_patterns

        lay = QVBoxLayout(self)
        lay.setSpacing(8)

        # Header
        proj_name = root.split("/")[-1].split("\\")[-1] if root else ""
        hdr = QLabel(f"<b>Project:</b> {proj_name}<br>"
                     f"<small style='color:gray'>{root}</small>")
        hdr.setTextFormat(Qt.RichText)
        hdr.setWordWrap(True)
        lay.addWidget(hdr)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #444;")
        lay.addWidget(sep)

        lay.addWidget(QLabel("Include top-level folders:"))

        # Collect all files once for counts
        self._all_files = collect_project_files(
            root, included_folders=None,
            extra_patterns=extra_patterns,
            max_file_kb=max_file_kb, max_files=max_files,
        )

        # Group by top-level folder
        self._folder_files = {}
        top_folders = get_top_level_folders(root)
        root_files_count = 0
        for f in self._all_files:
            parts = f["path"].split("/")
            folder = parts[0] if len(parts) > 1 else ""
            if folder in top_folders:
                self._folder_files.setdefault(folder, []).append(f)
            else:
                root_files_count += 1

        # Scroll area for checkboxes
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setMaximumHeight(200)
        inner = QWidget()
        cb_lay = QVBoxLayout(inner)
        cb_lay.setContentsMargins(0, 0, 0, 0)
        cb_lay.setSpacing(2)

        self._checkboxes = {}
        for folder in top_folders:
            count = len(self._folder_files.get(folder, []))
            cb = QCheckBox(f"{folder}/  ({count} files)")
            cb.setChecked(True)
            cb.toggled.connect(self._update_estimate)
            self._checkboxes[folder] = cb
            cb_lay.addWidget(cb)

        if root_files_count:
            cb = QCheckBox(f"[root files]  ({root_files_count} files)")
            cb.setChecked(True)
            cb.toggled.connect(self._update_estimate)
            self._checkboxes[""] = cb
            cb_lay.addWidget(cb)

        cb_lay.addStretch()
        scroll.setWidget(inner)
        lay.addWidget(scroll)

        # Estimate label
        self._est_lbl = QLabel()
        self._est_lbl.setStyleSheet("font-size: 9pt; color: gray;")
        lay.addWidget(self._est_lbl)

        self._warn_lbl = QLabel(
            "⚠ Large context — may exceed model token limit.")
        self._warn_lbl.setStyleSheet("color: #c8a000; font-size: 9pt;")
        self._warn_lbl.setVisible(False)
        lay.addWidget(self._warn_lbl)

        # Buttons
        btns = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("Enable project context")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

        self._update_estimate()

    def _update_estimate(self):
        from .project_context import estimate_tokens
        selected = self._selected_files()
        n = len(selected)
        tok = estimate_tokens(selected)
        self._est_lbl.setText(f"{n} files · ~{tok:,} estimated tokens")
        self._warn_lbl.setVisible(tok > 100_000)

    def _selected_files(self):
        selected_folders = {
            folder for folder, cb in self._checkboxes.items()
            if cb.isChecked()
        }
        return [
            f for f in self._all_files
            if (f["path"].split("/")[0]
                if "/" in f["path"] else "") in selected_folders
        ]

    def selected_folders(self):
        """Return list of checked top-level folder names (including '' for root)."""
        return [
            folder for folder, cb in self._checkboxes.items()
            if cb.isChecked()
        ]

    def selected_files(self):
        return self._selected_files()

    def estimate_tokens(self):
        from .project_context import estimate_tokens
        return estimate_tokens(self._selected_files())


# ---------------------------------------------------------------------------
# Chat reference encoding (collection + filename)
# ---------------------------------------------------------------------------

def _encode_chat_ref(collection, filename):
    """Encode collection + filename into a single string reference.
    Default collection ('' or None) → bare "filename.json" (backward compat).
    Named collection → "CollectionName/filename.json".
    """
    if collection and collection != "__all__":
        return f"{collection}/{filename}"
    return filename


def _decode_chat_ref(ref):
    """Decode a chat reference into (collection, filename).
    Bare "filename.json" → ('', 'filename.json')  — Default collection.
    "Collection/file.json" → ('Collection', 'file.json').
    """
    if ref and "/" in ref:
        collection, filename = ref.split("/", 1)
        return collection, filename
    return "", ref  # Default collection (backward compat with bare filenames)


# ---------------------------------------------------------------------------
# Chat History Popup
# ---------------------------------------------------------------------------
class _ChatHistoryPopup(QFrame):
    """Popup listing saved chats with collection selector.

    Signals:
      load_chat(ref)  — ref is encoded as "Collection/filename.json" or bare
                        "filename.json" for the Default collection.
      del_chat(ref)   — same encoding.
      del_all()       — all chats in the current (non-'__all__') collection deleted.
    """
    load_chat = Signal(str)
    del_chat  = Signal(str)
    del_all   = Signal()

    _ALL = "__all__"

    def __init__(self, save_state_fn, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setMinimumWidth(430)
        self.setMinimumHeight(440)
        self.setMaximumHeight(620)

        self._save_state_fn   = save_state_fn   # callable(current_collection=str)
        self._current_collection = ""           # '' = Default
        self._current_file    = None            # currently open chat filename
        self._current_file_collection = ""     # collection of the currently open chat

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)

        # ── row 1: title ──────────────────────────────────────────────
        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(0, 0, 0, 0)
        hdr_lbl = QLabel("Chat History")
        hdr_lbl.setStyleSheet("font-weight: bold; font-size: 11px; padding: 2px 4px;")
        hdr_row.addWidget(hdr_lbl, 1)
        lay.addLayout(hdr_row)

        sep_top = QFrame()
        sep_top.setFrameShape(QFrame.HLine)
        sep_top.setStyleSheet("color: #444;")
        lay.addWidget(sep_top)

        # ── row 2: collection selector + manage button ────────────────
        coll_row = QHBoxLayout()
        coll_row.setContentsMargins(0, 0, 0, 0)
        coll_row.setSpacing(4)

        coll_lbl = QLabel("Collection:")
        coll_lbl.setStyleSheet("font-size: 11px;")
        coll_row.addWidget(coll_lbl)

        self._coll_combo = QComboBox()
        self._coll_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._coll_combo.setToolTip("Select a collection to browse, or 'All' to search everywhere")
        coll_row.addWidget(self._coll_combo, 1)

        self._coll_mgr_btn = QPushButton("\u2699\uFE0E")
        self._coll_mgr_btn.setFixedSize(26, 26)
        self._coll_mgr_btn.setToolTip("Manage collections…")
        self._coll_mgr_btn.setStyleSheet(
            "QPushButton { font-size: 14px; color: #ccc; "
            "border: 1px solid #555; border-radius: 3px; padding: 0px; }"
            "QPushButton:hover { color: #fff; border-color: #aaa; }")
        self._coll_mgr_btn.clicked.connect(self._open_manager)
        coll_row.addWidget(self._coll_mgr_btn)
        lay.addLayout(coll_row)

        # ── search field ──────────────────────────────────────────────
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search chats…")
        self._search.setClearButtonEnabled(True)
        self._search.setStyleSheet(
            "QLineEdit { border: 1px solid #444; border-radius: 3px; "
            "padding: 3px 6px; font-size: 11px; }")
        self._search.textChanged.connect(self._on_search)
        lay.addWidget(self._search)

        # ── chat list ─────────────────────────────────────────────────
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._container = QWidget()
        self._list_lay = QVBoxLayout(self._container)
        self._list_lay.setContentsMargins(0, 4, 0, 4)
        self._list_lay.setSpacing(2)
        self._list_lay.setAlignment(Qt.AlignTop)

        self._empty_lbl = QLabel("No saved chats yet.")
        self._empty_lbl.setStyleSheet("color: gray; padding: 12px 8px;")
        self._empty_lbl.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        self._list_lay.addWidget(self._empty_lbl)

        self._scroll.setWidget(self._container)
        lay.addWidget(self._scroll, stretch=1)

        # ── bottom row: Delete All ────────────────────────────────────
        sep_bot = QFrame()
        sep_bot.setFrameShape(QFrame.HLine)
        sep_bot.setStyleSheet("color: #444;")
        lay.addWidget(sep_bot)

        bot_row = QHBoxLayout()
        bot_row.setContentsMargins(0, 0, 0, 0)
        bot_row.addStretch(1)

        self._del_all_btn = _WarmupButton("🗑 Delete all", warmup_ms=1000)
        self._del_all_btn.setFlat(True)
        self._del_all_btn.setToolTip(
            "Deletes all chats from the currently selected collection  (hold 1 s to unlock)")
        self._del_all_btn.setFixedHeight(24)

        self._del_all_cancel = QPushButton("↩ Cancel (3)")
        self._del_all_cancel.setFlat(True)
        self._del_all_cancel.setFixedHeight(24)
        self._del_all_cancel.setStyleSheet(
            "QPushButton { color: #f88; font-size: 9px; padding: 1px 8px; "
            "border: 1px solid #f88; border-radius: 3px; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        self._del_all_cancel.setVisible(False)
        self._del_all_timer = None
        self._del_all_remaining = [3]

        self._del_all_btn.clicked.connect(self._arm_delete_all)
        self._del_all_cancel.clicked.connect(self._cancel_delete_all)
        bot_row.addWidget(self._del_all_cancel)
        bot_row.addWidget(self._del_all_btn)
        lay.addLayout(bot_row)

        # Wire combo AFTER widgets are created
        self._coll_combo.currentIndexChanged.connect(self._on_collection_changed)

    # ── collection combo ──────────────────────────────────────────────
    def _populate_collection_combo(self):
        """Rebuild the collection dropdown preserving the current selection."""
        self._coll_combo.blockSignals(True)
        self._coll_combo.clear()
        self._coll_combo.addItem("⊕ All Collections", self._ALL)
        self._coll_combo.addItem("Default", "")
        for name in list_collections():
            self._coll_combo.addItem(name, name)
        # Restore selection
        idx = self._coll_combo.findData(self._current_collection)
        self._coll_combo.setCurrentIndex(max(idx, 0))
        self._coll_combo.blockSignals(False)

    def _on_collection_changed(self, _idx):
        self._current_collection = self._coll_combo.currentData() or ""
        # "Delete All" is hidden in All-Collections mode (too destructive)
        is_all = (self._current_collection == self._ALL)
        self._del_all_btn.setVisible(not is_all)
        self._del_all_cancel.setVisible(False)
        self._cancel_delete_all()
        self._save_state_fn(self._current_collection)
        self._refresh(self._search.text().strip())

    def set_collection(self, name):
        """Externally switch the active collection and refresh."""
        self._current_collection = name or ""
        idx = self._coll_combo.findData(self._current_collection)
        if idx >= 0:
            self._coll_combo.setCurrentIndex(idx)
        else:
            self._refresh()

    # ── manager ──────────────────────────────────────────────────────
    def _open_manager(self):
        try:
            wins = QApplication.topLevelWidgets()
            main_win = next(
                (w for w in wins if w.isVisible()
                 and 'MainWindow' in type(w).__name__), None)
        except Exception:
            main_win = None
        dlg = ChatCollectionManagerDialog(
            current_collection=self._current_collection, parent=main_win)
        dlg.collections_changed.connect(self._on_manager_changed)
        # Keep popup visible behind manager (it's a Popup window)
        self.hide()
        dlg.exec_()
        # Sync active collection in case a rename/delete changed it
        resulting = dlg.resulting_collection()
        self._current_collection = resulting
        self._save_state_fn(self._current_collection)
        self._populate_collection_combo()
        self._refresh()
        self.show()
        self.raise_()

    def _on_manager_changed(self):
        self._populate_collection_combo()
        self._refresh()

    # ── delete-all countdown ──────────────────────────────────────────
    def _arm_delete_all(self):
        if self._del_all_timer:
            self._del_all_timer.stop()
        self._del_all_remaining[0] = 3
        self._del_all_btn.setVisible(False)
        self._del_all_cancel.setText("\u21a9 Cancel (3)")
        self._del_all_cancel.setVisible(True)

        def _tick():
            self._del_all_remaining[0] -= 1
            if self._del_all_remaining[0] > 0:
                self._del_all_cancel.setText(
                    f"\u21a9 Cancel ({self._del_all_remaining[0]})")
            else:
                self._del_all_timer.stop()
                self._del_all_timer = None
                self._del_all_cancel.setVisible(False)
                self._del_all_btn.setVisible(True)
                self._execute_delete_all()

        self._del_all_timer = QTimer(self)
        self._del_all_timer.setInterval(1000)
        self._del_all_timer.timeout.connect(_tick)
        self._del_all_timer.start()

    def _cancel_delete_all(self):
        if self._del_all_timer:
            self._del_all_timer.stop()
            self._del_all_timer = None
        self._del_all_cancel.setVisible(False)
        if hasattr(self._del_all_btn, 'reset'):
            self._del_all_btn.reset()
        self._del_all_btn.setVisible(True)

    def _execute_delete_all(self):
        # Only delete within the currently visible collection
        coll = self._current_collection
        if coll == self._ALL:
            return
        for chat in list_chats(collection=coll):
            delete_chat(chat["filename"], collection=coll)
        self.del_all.emit()
        self._refresh()

    # ── search + refresh ──────────────────────────────────────────────
    def _on_search(self, text):
        self._refresh(text.strip())

    def show_below(self, btn, current_file=None, current_collection="",
                   current_file_collection=""):
        self._current_file            = current_file
        self._current_file_collection = current_file_collection or ""
        self._current_collection      = current_collection or ""
        self._cancel_delete_all()
        if hasattr(self._del_all_btn, 'reset'):
            self._del_all_btn.reset()
        self._search.blockSignals(True)
        self._search.clear()
        self._search.blockSignals(False)
        self._populate_collection_combo()
        self._refresh()
        self.adjustSize()

        try:
            btn_bottom_right = btn.mapToGlobal(btn.rect().bottomRight())
            popup_x = btn_bottom_right.x() - self.width()
            popup_y = btn_bottom_right.y()
            from qtpy.QtWidgets import QApplication
            screen = QApplication.primaryScreen().availableGeometry()
            popup_x = max(screen.left(), popup_x)
        except Exception:
            pos = btn.mapToGlobal(btn.rect().bottomLeft())
            popup_x, popup_y = pos.x(), pos.y()

        self.move(popup_x, popup_y)
        self.show()
        self.raise_()

    def _refresh(self, query=""):
        # Clear chat rows but keep empty_lbl (index 0)
        while self._list_lay.count() > 1:
            item = self._list_lay.takeAt(1)
            if item.widget():
                item.widget().deleteLater()

        is_all  = (self._current_collection == self._ALL)
        coll    = None if is_all else (self._current_collection or None)

        if query:
            chats = search_chats(query, collection=coll, all_collections=is_all)
        else:
            chats = list_chats(collection=coll, all_collections=is_all)

        no_results = len(chats) == 0
        self._empty_lbl.setText(
            "No matching chats." if (query and no_results) else "No saved chats yet.")
        self._empty_lbl.setVisible(no_results)
        self._del_all_btn.setVisible(not no_results and not is_all)

        for chat in chats:
            self._add_row(chat)

    def _add_row(self, chat):
        fname      = chat["filename"]
        chat_coll  = chat.get("collection", "")   # '' = Default
        preview    = chat["preview"] or "(empty)"
        label      = preview[:55] + ("…" if len(preview) > 55 else "")
        try:
            dt = chat["saved_at"][:16].replace("T", " ")
        except Exception:
            dt = ""

        # Show collection badge when browsing All Collections
        if self._current_collection == self._ALL and chat_coll:
            dt = f"[{chat_coll}]  {dt}"

        is_active = (fname == self._current_file and
                     chat_coll == self._current_file_collection)

        row = QFrame()
        row.setObjectName("chatrow")
        if is_active:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; background: #1a3a1a; "
                "border: 1px solid #3a7a3a; }"
                "QFrame#chatrow:hover { background: #244a24; }")
        else:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; }"
                "QFrame#chatrow:hover { background: palette(highlight); }")

        # Right-click context menu for "Move to"
        row.setContextMenuPolicy(Qt.CustomContextMenu)
        row.customContextMenuRequested.connect(
            lambda pos, f=fname, c=chat_coll: self._show_row_menu(f, c, pos))

        rl = QHBoxLayout(row)
        rl.setContentsMargins(7, 3, 4, 3)
        rl.setSpacing(6)

        txt_btn = QPushButton(f"{label}\n{dt}")
        txt_btn.setFlat(True)
        if is_active:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0 2px 6px; "
                "font-size: 11px; color: #7ec87e; }"
                "QPushButton:hover { color: #aeeaae; }")
        else:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0 2px 6px; "
                "font-size: 11px; }"
                "QPushButton:hover { color: palette(highlighted-text); }")
        ref = _encode_chat_ref(chat_coll, fname)
        txt_btn.clicked.connect(lambda checked=False, r=ref: self._on_load(r))
        rl.addWidget(txt_btn, stretch=1)

        # Per-row delete with countdown/cancel
        del_btn    = QPushButton("✕")
        del_btn.setFixedSize(28, 28)
        del_btn.setFlat(True)
        del_btn.setToolTip("Delete this chat")
        del_btn.setStyleSheet(
            "QPushButton { color: #888; border: none; font-size: 13px; font-weight: bold; }"
            "QPushButton:hover { color: #f88; }")

        cancel_btn = QPushButton("↩ 3")
        cancel_btn.setFixedSize(44, 28)
        cancel_btn.setFlat(True)
        cancel_btn.setToolTip("Cancel deletion")
        cancel_btn.setStyleSheet(
            "QPushButton { color: #f88; border: 1px solid #f88; "
            "border-radius: 3px; font-size: 10px; font-weight: bold; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        cancel_btn.setVisible(False)

        rl.addWidget(del_btn)
        rl.addWidget(cancel_btn)

        row_state = {"timer": None, "remaining": [3]}

        def _arm(fn=fname, fc=chat_coll):
            if row_state["timer"]:
                row_state["timer"].stop()
            row_state["remaining"][0] = 3
            del_btn.setVisible(False)
            cancel_btn.setText("↩ 3")
            cancel_btn.setVisible(True)

            def _tick():
                row_state["remaining"][0] -= 1
                r = row_state["remaining"][0]
                if r > 0:
                    cancel_btn.setText(f"↩ {r}")
                else:
                    row_state["timer"].stop()
                    row_state["timer"] = None
                    self._on_delete(fn, fc)

            t = QTimer(row)
            t.setInterval(1000)
            t.timeout.connect(_tick)
            t.start()
            row_state["timer"] = t

        def _cancel():
            if row_state["timer"]:
                row_state["timer"].stop()
                row_state["timer"] = None
            cancel_btn.setVisible(False)
            del_btn.setVisible(True)

        del_btn.clicked.connect(lambda checked=False: _arm())
        cancel_btn.clicked.connect(lambda checked=False: _cancel())

        self._list_lay.addWidget(row)

    # ── row context menu ──────────────────────────────────────────────
    def _show_row_menu(self, filename, chat_collection, pos):
        from qtpy.QtWidgets import QMenu
        menu = QMenu(self)
        move_menu = menu.addMenu("Move to \u2192")
        # Default
        if chat_collection != "":
            act = move_menu.addAction("Default")
            act.triggered.connect(
                lambda checked=False, f=filename, fc=chat_collection:
                    self._move_chat(f, fc, ""))
        for coll in list_collections():
            if coll == chat_collection:
                continue
            act = move_menu.addAction(coll)
            act.triggered.connect(
                lambda checked=False, f=filename, fc=chat_collection, tc=coll:
                    self._move_chat(f, fc, tc))
        if move_menu.isEmpty():
            move_menu.addAction("(no other collections)").setEnabled(False)
        # Map local pos to global using the widget that emitted the signal
        sender = self.sender()
        global_pos = sender.mapToGlobal(pos) if sender else pos
        menu.exec_(global_pos)

    def _move_chat(self, filename, from_collection, to_collection):
        ok = move_chat(filename, from_collection, to_collection)
        if ok:
            # If the moved chat is the currently open one, update tracking
            if (filename == self._current_file and
                    from_collection == self._current_file_collection):
                self._current_file_collection = to_collection
                ref = _encode_chat_ref(to_collection, filename)
                self.load_chat.emit(ref)   # re-emit so panel updates _current_collection
            self._refresh(self._search.text().strip())

    def _on_load(self, ref):
        self.hide()
        self.load_chat.emit(ref)

    def _on_delete(self, filename, collection):
        delete_chat(filename, collection=collection)
        ref = _encode_chat_ref(collection, filename)
        self.del_chat.emit(ref)
        self._refresh(self._search.text().strip())





# ---------------------------------------------------------------------------
# Chat API worker
# ---------------------------------------------------------------------------
class _ChatWorker(QObject):
    chunk_ready = Signal(str)
    finished    = Signal()
    error       = Signal(str)

    def __init__(self, api_url, api_key, model, messages, extra_params=None):
        super().__init__()
        self._url          = api_url.rstrip("/")
        self._key          = api_key
        self._model        = model
        self._messages     = messages
        self._extra_params = extra_params or {}
        self._stop         = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            import urllib.request
            import urllib.error
            body = {
                "model": self._model,
                "messages": self._messages,
                "stream": True,
            }
            body.update(self._extra_params)
            payload = json.dumps(body).encode()
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "spyder-ai-chat/0.1.2",
            }
            if self._key:
                headers["Authorization"] = f"Bearer {self._key}"
            req = urllib.request.Request(
                f"{self._url}/chat/completions",
                data=payload, headers=headers, method="POST")
            try:
                resp_cm = urllib.request.urlopen(req, timeout=120)
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:300]
                except Exception:
                    body = ""
                self.error.emit(f"HTTP {e.code} {e.reason}: {body}")
                return
            with resp_cm as resp:
                for raw in resp:
                    if self._stop:
                        break
                    line = raw.decode().strip()
                    if not line or line == "data: [DONE]":
                        continue
                    if line.startswith("data: "):
                        line = line[6:]
                    try:
                        d = json.loads(line)
                        t = d["choices"][0]["delta"].get("content", "")
                        if t:
                            self.chunk_ready.emit(t)
                    except Exception:
                        pass
        except Exception as exc:
            self.error.emit(str(exc))
        finally:
            self.finished.emit()


# ---------------------------------------------------------------------------
# Inference Parameters Popup
# ---------------------------------------------------------------------------
class _InferParamsPopup(QFrame):
    """
    Popup for configuring per-chat inference hyperparameters.
    Shows all params supported by the current provider as a flat form.
    No scroll bar — the popup expands to fit its content naturally.
    Anchors ABOVE the button that opens it.
    Changes apply immediately to the parent panel's _infer_params dict.
    """

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setMinimumWidth(320)
        self.setMaximumWidth(420)

        self._panel = None
        self._provider_id = "custom"

        # Outer layout — no scroll area; just a plain VBox that sizes to content
        self._outer = QVBoxLayout(self)
        self._outer.setContentsMargins(8, 8, 8, 8)
        self._outer.setSpacing(4)

        # Header row
        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 2)
        hdr_lbl = QLabel("Inference Parameters")
        hdr_lbl.setStyleSheet("font-weight: bold; font-size: 11px;")
        hdr.addWidget(hdr_lbl, 1)
        self._reset_btn = QPushButton("Reset to defaults")
        self._reset_btn.setFlat(True)
        self._reset_btn.setStyleSheet(
            "QPushButton { color: #888; font-size: 9px; padding: 1px 6px; "
            "border: 1px solid #555; border-radius: 3px; }"
            "QPushButton:hover { color: #f88; border-color: #f88; }")
        self._reset_btn.clicked.connect(self._on_reset)
        hdr.addWidget(self._reset_btn)
        self._outer.addLayout(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #444;")
        self._outer.addWidget(sep)

        # Placeholder — will be replaced by _rebuild_controls()
        self._form_widget = QWidget()
        self._outer.addWidget(self._form_widget)

        # Notes label (provider-specific warnings)
        self._notes_lbl = QLabel()
        self._notes_lbl.setWordWrap(True)
        self._notes_lbl.setStyleSheet(
            "color: #c8a000; font-size: 9pt; padding: 4px 2px 0 2px;")
        self._notes_lbl.setVisible(False)
        self._outer.addWidget(self._notes_lbl)

    # ── public API ────────────────────────────────────────────────────

    def show_above(self, btn, panel):
        """Build controls for panel's current provider and show above btn."""
        self._panel = panel
        state = panel._load_state()
        self._provider_id = state.get("provider_type", "custom")
        self._rebuild_controls()

        # Let Qt compute the natural size before positioning
        self.adjustSize()

        # Anchor: bottom-right of popup aligns to top-right of button
        btn_top_right = btn.mapToGlobal(btn.rect().topRight())
        popup_x = btn_top_right.x() - self.width()
        popup_y = btn_top_right.y() - self.height()

        # Clamp to screen
        try:
            screen = QApplication.primaryScreen().availableGeometry()
            popup_x = max(screen.left(), min(popup_x, screen.right() - self.width()))
            popup_y = max(screen.top(), popup_y)
        except Exception:
            pass

        self.move(popup_x, popup_y)
        self.show()
        self.raise_()

    # ── control building ──────────────────────────────────────────────

    def _rebuild_controls(self):
        """Replace form widget with fresh controls for the current provider."""
        # Detach old form widget and schedule deletion
        old = self._form_widget
        old.setParent(None)
        old.deleteLater()

        pdef      = PROVIDERS.get(self._provider_id, PROVIDERS["custom"])
        supported = pdef["supported_params"]
        temp_max  = pdef.get("temperature_max", 2.0)
        params    = self._panel._infer_params if self._panel else {}

        # All params in display order (basic first, then advanced — no toggle)
        all_params = [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "frequency_penalty",
            "top_k", "min_p", "repetition_penalty",
            "seed", "num_ctx",
        ]

        self._form_widget = QWidget()
        form_lay = QVBoxLayout(self._form_widget)
        form_lay.setContentsMargins(0, 4, 0, 0)
        form_lay.setSpacing(4)

        self._ctrl_widgets = {}

        for pid in all_params:
            if pid not in supported:
                continue
            pinfo = PARAM_DEFS[pid]
            t_max = temp_max if pid == "temperature" else None
            row   = self._make_param_row(pid, pinfo, params, t_max)
            form_lay.addWidget(row)

        # Insert before notes label (which is the last item in outer)
        # outer layout: hdr(0), sep(1), form(2-old→removed), notes(last)
        # After removing old form we insert at position 2
        self._outer.insertWidget(2, self._form_widget)

        # Notes
        notes = pdef.get("notes", "")
        self._notes_lbl.setText(notes)
        self._notes_lbl.setVisible(bool(notes))

    def _make_param_row(self, pid, pinfo, current_params, temp_max=None):
        """Create a single label + spinbox row."""
        label_text, ptype, prange, tooltip = pinfo

        row = QWidget()
        rl  = QHBoxLayout(row)
        rl.setContentsMargins(2, 1, 2, 1)
        rl.setSpacing(8)

        lbl = QLabel(label_text + ":")
        lbl.setFixedWidth(140)
        lbl.setStyleSheet("font-size: 9pt;")
        lbl.setToolTip(tooltip)
        rl.addWidget(lbl)

        current_val = current_params.get(pid)

        if ptype == "float":
            lo, hi = prange
            if temp_max is not None:
                hi = temp_max

            sp = QDoubleSpinBox()
            sp.setRange(lo, hi)
            sp.setSingleStep(0.05)
            sp.setDecimals(2)
            sp.setFixedWidth(90)
            # 0.0 as minimum → special "default" text
            sp.setSpecialValueText("default")
            sp.setValue(float(current_val) if current_val is not None else 0.0)

            def _on_float(val, p=pid, s=sp):
                if not self._panel:
                    return
                if val == s.minimum():
                    self._panel._infer_params.pop(p, None)
                else:
                    self._panel._infer_params[p] = val
                self._panel._update_summary_bar()

            sp.valueChanged.connect(_on_float)
            rl.addWidget(sp)
            self._ctrl_widgets[pid] = sp

        elif ptype == "int":
            _, hi = prange
            sp = QSpinBox()
            sp.setRange(0, hi)   # 0 = "default"
            sp.setFixedWidth(100)
            sp.setSpecialValueText("default")
            sp.setValue(int(current_val) if current_val is not None else 0)

            def _on_int(val, p=pid):
                if not self._panel:
                    return
                if val == 0:
                    self._panel._infer_params.pop(p, None)
                else:
                    self._panel._infer_params[p] = val
                self._panel._update_summary_bar()

            sp.valueChanged.connect(_on_int)
            rl.addWidget(sp)
            self._ctrl_widgets[pid] = sp

        rl.addStretch()
        return row

    def _on_reset(self):
        if self._panel:
            self._panel._infer_params.clear()
            self._panel._update_summary_bar()
        self._rebuild_controls()
        self.adjustSize()


# ---------------------------------------------------------------------------
# Model dropdown popup
# ---------------------------------------------------------------------------
class _ModelPopup(QFrame):
    selected = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        self._lw = QListWidget()
        self._lw.setFrameShape(QFrame.NoFrame)
        self._lw.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._lw.itemClicked.connect(
            lambda item: (self.selected.emit(item.text()), self.hide()))
        lay.addWidget(self._lw)

    def _apply_theme(self):
        """Inherit application theme — no custom stylesheet needed."""
        self.setStyleSheet("")
        self._lw.setStyleSheet("")

    def show_below(self, btn, models, current):
        self._apply_theme()
        self._lw.clear()
        for m in models:
            item = QListWidgetItem(m)
            if m == current:
                f = item.font(); f.setBold(True); item.setFont(f)
            self._lw.addItem(item)
        row_h = max(self._lw.sizeHintForRow(0), 24)
        self._lw.setFixedHeight(min(row_h * len(models) + 4, 350))
        self.setFixedWidth(max(btn.width(), 200))
        self.adjustSize()
        self.move(btn.mapToGlobal(btn.rect().bottomLeft()))
        self.show()
        self.raise_()


from .markdown_renderer import (
    render_markdown, parse_blocks,
    build_heading, build_paragraph, build_code_block, build_hr,
    build_blockquote, build_list, build_table, build_think,
    build_action_block,
)
from .settings_dialog import (
    SettingsDialog, EDITOR_DEFAULTS, HISTORY_DEFAULTS, AGENTIC_DEFAULTS,
    PROVIDERS, PROVIDER_ORDER, PARAM_DEFS,
)
from .system_prompts import load_prompts, get_prompt, CUSTOM_ID


# ---------------------------------------------------------------------------
# Helper: assemble LLM message content from structured storage
# ---------------------------------------------------------------------------
def _build_llm_content(msg):
    """
    Build the content string to send to the LLM from a stored message dict.
    New format: {"role": "user", "content": "user text",
                 "content_llm": "expanded command text (if commands were used)",
                 "command_spans": [[start, length], ...],
                 "attachments": [{"name": "file.py", "content": "..."}]}
    Old format: {"role": "user", "content": "File: ...\n```\n...\n```\n\ntext"}
                 — returned as-is for backwards compatibility.
    content_llm is used when present so the original expansion is preserved
    even if the command is later edited or deleted in Settings.
    """
    import os
    text        = msg.get("content_llm") or msg.get("content", "")
    attachments = msg.get("attachments", [])
    proj_block  = msg.get("project_context_block", "")

    parts = []
    if proj_block:
        parts.append(proj_block)

    if not attachments and not parts:
        return text  # no attachments, or legacy format

    for att in attachments:
        name    = att.get("name", "")
        content = att.get("content", "")
        ext  = os.path.splitext(name)[1].lower()
        lang = {".py": "python", ".js": "javascript", ".ts": "typescript",
                ".html": "html", ".css": "css", ".json": "json",
                ".md": "markdown", ".txt": ""}.get(ext, "")
        fence = f"```{lang}" if lang else "```"
        parts.append(f"File: {name}\n{fence}\n{content}\n```")
    all_blocks = "\n\n".join(parts)
    return f"{all_blocks}\n\n{text}" if text else all_blocks


# ---------------------------------------------------------------------------
# The chat history display
# ---------------------------------------------------------------------------
class _ChatHistory(QWidget):

    insert_to_editor = Signal(str)

    _SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(4, 4, 4, 4)
        self._lay.setSpacing(6)
        self._lay.setAlignment(Qt.AlignTop)
        # Expand horizontally to fill scroll area width (needed for word-wrap),
        # but only take as much vertical space as the content actually needs
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._blocks = []
        self._stream_container = None
        self._stream_lbl       = None
        self._spinner_lbl      = None
        self._spinner_timer    = None
        self._spinner_frame    = 0
        self._rendered_zone          = None  # QVBoxLayout for incrementally rendered blocks
        self._rendered_block_count   = 0     # blocks already pushed to _rendered_zone
        self._scroll_to_bottom_cb = None  # callable, fired once after next resize
        self._action_env             = None  # passed from AIChatPanel when agentic ON
        self._current_executed_blocks = set()  # block indices already executed (history)

    # Signal(block_index, delete_before_too, role)
    # Signal(block_index, delete_before_too)
    delete_exchange = Signal(int, bool)
    # Signal() — regenerate the last assistant response
    regenerate = Signal()

    def _make_delete_bar(self, block_idx_fn):
        """
        Return a QWidget containing the delete action buttons for one message.
        block_idx_fn: callable returning the current block index at click time.
        """
        bar = QWidget()
        bar.setStyleSheet("background: transparent;")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(4)
        bl.addStretch()

        btn_this   = QPushButton("🗑 This")
        btn_before = QPushButton("⏫ All before")
        btn_this.setToolTip(
            "Delete this exchange (your message + assistant reply) from the chat")
        btn_before.setToolTip(
            "Delete all exchanges before this one (keeps this exchange)")
        for btn in (btn_this, btn_before):
            btn.setFlat(True)
            btn.setStyleSheet(
                "QPushButton { color: #888; font-size: 9px; padding: 1px 5px; "
                "border: 1px solid #555; border-radius: 3px; background: transparent; }"
                "QPushButton:hover { color: #f88; border-color: #f88; }")
        bl.addWidget(btn_before)
        bl.addWidget(btn_this)

        _state = {"timer": None, "pending": None}

        def _arm(delete_before):
            if _state["timer"] is not None:
                _state["timer"].stop()
            _state["pending"] = delete_before
            btn_this.setVisible(False)
            btn_before.setVisible(False)
            cancel_btn.setText("↩ Cancel (3)")
            cancel_btn.setVisible(True)
            remaining = [3]

            def _tick():
                remaining[0] -= 1
                if remaining[0] > 0:
                    cancel_btn.setText(f"↩ Cancel ({remaining[0]})")
                else:
                    _state["timer"].stop()
                    cancel_btn.setVisible(False)
                    btn_this.setVisible(True)
                    btn_before.setVisible(True)
                    self.delete_exchange.emit(block_idx_fn(), _state["pending"])

            t = QTimer(bar)
            t.setInterval(1000)
            t.timeout.connect(_tick)
            t.start()
            _state["timer"] = t

        def _cancel():
            if _state["timer"]:
                _state["timer"].stop()
                _state["timer"] = None
            cancel_btn.setVisible(False)
            btn_this.setVisible(True)
            btn_before.setVisible(True)

        cancel_btn = QPushButton("↩ Cancel (3)")
        cancel_btn.setFlat(True)
        cancel_btn.setStyleSheet(
            "QPushButton { color: #f88; font-size: 9px; padding: 1px 5px; "
            "border: 1px solid #f88; border-radius: 3px; background: transparent; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        cancel_btn.setVisible(False)
        cancel_btn.clicked.connect(_cancel)
        bl.addWidget(cancel_btn)

        btn_this.clicked.connect(lambda: _arm(False))
        btn_before.clicked.connect(lambda: _arm(True))

        return bar

    def _make_regenerate_btn(self):
        """Return a small Regenerate button that emits self.regenerate."""
        btn = QPushButton("🔄 Regenerate")
        btn.setFlat(True)
        btn.setToolTip("Discard this response and ask the model to answer again")
        btn.setStyleSheet(
            "QPushButton { color: #888; font-size: 9px; padding: 1px 5px; "
            "border: 1px solid #555; border-radius: 3px; background: transparent; }"
            "QPushButton:hover { color: #4ec9b0; border-color: #4ec9b0; }")
        btn.clicked.connect(self.regenerate.emit)
        return btn

    def _update_regenerate_button(self):
        """
        Ensure only the last assistant block has a Regenerate button.
        Scans all blocks, removes any existing regenerate buttons,
        then injects one into the last assistant block's title row.
        """
        # Remove existing regenerate buttons from all title rows
        for role, container in self._blocks:
            lay = container.layout()
            if lay and lay.count() > 0:
                first_item = lay.itemAt(0)
                if first_item and first_item.layout():
                    title_row = first_item.layout()
                    for i in range(title_row.count() - 1, -1, -1):
                        item = title_row.itemAt(i)
                        if item and item.widget():
                            w = item.widget()
                            if (isinstance(w, QPushButton) and
                                    "Regenerate" in w.text()):
                                title_row.removeWidget(w)
                                w.deleteLater()

        # Find last assistant or error block and inject regenerate button
        last_asst = None
        for role, container in reversed(self._blocks):
            if role in ("assistant", "assistant_error"):
                last_asst = container
                break
        if last_asst is None:
            return
        lay = last_asst.layout()
        if lay and lay.count() > 0:
            first_item = lay.itemAt(0)
            if first_item and first_item.layout():
                title_row = first_item.layout()
                # Insert before the delete bar (last widget)
                regen_btn = self._make_regenerate_btn()
                title_row.insertWidget(title_row.count() - 1, regen_btn)

    def request_scroll_to_bottom(self, callback):
        """Ask to fire callback once after the next resize (layout settled)."""
        self._scroll_to_bottom_cb = callback

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._scroll_to_bottom_cb is not None:
            cb = self._scroll_to_bottom_cb
            self._scroll_to_bottom_cb = None
            cb()

    # ── user bubble ───────────────────────────────────────────────────
    def add_user(self, text, attachments=None, command_spans=None):
        """
        Add a user message bubble.
        attachments:    optional list of attachment name strings (locked badges).
        command_spans:  optional list of (start, length) tuples marking active
                        command tokens — rendered with a green highlight.
        """
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)

        # Title row: "You:" on left, delete buttons on right
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title = QLabel("<b>You:</b>")
        title.setStyleSheet("color: #569cd6;")
        title_row.addWidget(title)
        title_row.addStretch()
        block_idx_fn = lambda: next(
            (i for i, b in enumerate(self._blocks) if b[1] is container), -1)
        title_row.addWidget(self._make_delete_bar(block_idx_fn))
        cl.addLayout(title_row)

        # Build label content — highlight command spans if present
        if command_spans:
            # Build rich-text with highlighted command tokens
            import html as _html
            spans = sorted(command_spans, key=lambda s: s[0])
            result = ""
            prev = 0
            for (s, l) in spans:
                result += _html.escape(text[prev:s])
                result += (
                    f'<span style="background:#2a3a1a; color:#b8e090; '
                    f'border-radius:3px; padding:0 2px;">'
                    f'{_html.escape(text[s:s+l])}</span>'
                )
                prev = s + l
            result += _html.escape(text[prev:])
            # Preserve newlines
            result = result.replace("\n", "<br>")
            w = QLabel(result)
            w.setTextFormat(Qt.RichText)
        else:
            w = QLabel(text)
            w.setTextFormat(Qt.PlainText)

        w.setWordWrap(True)
        w.setFont(QFont("Monospace", 10))
        w.setStyleSheet(
            "background: transparent; border-left: 3px solid #569cd6; "
            "padding: 4px 8px;")
        w.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(w)

        # Locked attachment badges (no X button — already sent)
        if attachments:
            badge_row = QWidget()
            badge_row.setStyleSheet("background: transparent;")
            bl = QHBoxLayout(badge_row)
            bl.setContentsMargins(8, 2, 0, 0)
            bl.setSpacing(4)
            for name in attachments:
                icon = "✂" if " selection" in name else "📎"
                tag = QFrame()
                tag.setStyleSheet(
                    "QFrame { background: #1e3a1e; border: 1px solid #3a6a3a; "
                    "border-radius: 3px; }")
                tl = QHBoxLayout(tag)
                tl.setContentsMargins(5, 1, 5, 1)
                tl.setSpacing(3)
                lbl = QLabel(f"{icon} {name}")
                lbl.setStyleSheet(
                    "color: #7ec87e; font-size: 9px; border: none; "
                    "background: transparent;")
                tl.addWidget(lbl)
                bl.addWidget(tag)
            bl.addStretch()
            cl.addWidget(badge_row)

        self._lay.addWidget(container)
        self._blocks.append(("user", container))

    # ── assistant: streaming placeholder ─────────────────────────────
    def add_assistant_start(self):
        """Create a plain streaming label. Returns the QLabel to write into."""
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)

        # Title row: "Assistant:" on left, delete buttons on right
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title = QLabel("<b>Assistant:</b>")
        title.setStyleSheet("color: #4ec9b0;")
        title_row.addWidget(title)
        title_row.addStretch()
        block_idx_fn = lambda: next(
            (i for i, b in enumerate(self._blocks) if b[1] is container), -1)
        title_row.addWidget(self._make_delete_bar(block_idx_fn))
        cl.addLayout(title_row)
        # Spinner shown while waiting for the first response token
        spinner = QLabel(self._SPINNER_FRAMES[0])
        spinner.setStyleSheet(
            "color: #4ec9b0; font-size: 14px; padding: 4px 8px;")
        cl.addWidget(spinner)
        self._spinner_lbl   = spinner
        self._spinner_frame = 0
        timer = QTimer(self)
        timer.timeout.connect(self._spinner_tick)
        timer.start(80)
        self._spinner_timer = timer

        # Rendered zone: completed blocks are added here incrementally
        rz_widget = QWidget()
        rz_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._rendered_zone = QVBoxLayout(rz_widget)
        self._rendered_zone.setContentsMargins(0, 0, 0, 0)
        self._rendered_zone.setSpacing(3)
        self._rendered_block_count = 0
        cl.addWidget(rz_widget)

        # Tail label: shows the current (potentially incomplete) block as plain text
        lbl = QLabel()
        lbl.setWordWrap(True)
        lbl.setTextFormat(Qt.PlainText)
        lbl.setFont(QFont("Monospace", 10))
        lbl.setStyleSheet(
            "background: transparent; border-left: 3px solid #4ec9b0; "
            "padding: 4px 8px;")
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        lbl.hide()   # shown only after first response token arrives
        cl.addWidget(lbl)
        self._lay.addWidget(container)
        self._blocks.append(("assistant_streaming", container))
        self._stream_container = container
        self._stream_lbl       = lbl
        return lbl

    def _spinner_tick(self):
        if self._spinner_lbl is None:
            return
        self._spinner_frame = (self._spinner_frame + 1) % len(self._SPINNER_FRAMES)
        self._spinner_lbl.setText(self._SPINNER_FRAMES[self._spinner_frame])

    def hide_spinner(self):
        """Stop and remove the waiting spinner (called on first chunk or error)."""
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None
        if self._spinner_lbl is not None:
            self._spinner_lbl.setParent(None)
            self._spinner_lbl.deleteLater()
            self._spinner_lbl = None

    def push_rendered_widget(self, widget):
        """Append a pre-built widget to the rendered zone (no block parsing)."""
        if self._rendered_zone is None:
            return
        self._rendered_zone.addWidget(widget)
        self._rendered_block_count += 1

    def push_rendered_block(self, block):
        """Build one block widget and append it to the rendered zone."""
        if self._rendered_zone is None:
            return
        from .settings_dialog import EDITOR_DEFAULTS
        cfg = {**EDITOR_DEFAULTS, **(getattr(self, "_font_cfg", None) or {})}
        try:
            from spyder.config.gui import is_dark_interface
            text_color = "#d4d4d4" if is_dark_interface() else "#1a1a1a"
        except Exception:
            text_color = "#d4d4d4"
        t = block["type"]
        if   t == "heading":    w = build_heading(block, cfg["fs_heading"])
        elif t == "paragraph":  w = build_paragraph(block, text_color, cfg["fs_base"])
        elif t == "code":       w = build_code_block(block, self.insert_to_editor, cfg["fs_code"])
        elif t == "action":
            # Augment action_env with per-block index and executed set for persistence
            aenv = dict(self._action_env) if self._action_env else {}
            aenv["_block_idx"]      = self._rendered_block_count
            aenv["_executed_blocks"] = getattr(self, "_current_executed_blocks", set())
            w = build_action_block(block, aenv, cfg["fs_code"])
        elif t == "hr":         w = build_hr()
        elif t == "blockquote": w = build_blockquote(block, text_color, cfg["fs_base"])
        elif t == "list":       w = build_list(block, text_color, cfg["fs_list"])
        elif t == "table":      w = build_table(block, cfg["fs_table"])
        elif t == "think":      w = build_think(block, cfg["fs_think"])
        else:                   return
        self._rendered_zone.addWidget(w)
        self._rendered_block_count += 1

    def show_error(self, msg):
        """Display an error response in a dark-red styled box. No Regenerate button."""
        self.hide_spinner()
        if self._stream_container is None:
            container = QWidget()
            container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            cl = QVBoxLayout(container)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            title_row = QHBoxLayout()
            title_row.setContentsMargins(0, 0, 0, 0)
            title = QLabel("<b>Assistant:</b>")
            title.setStyleSheet("color: #4ec9b0;")
            title_row.addWidget(title)
            title_row.addStretch()
            block_idx_fn = lambda c=container: next(
                (i for i, b in enumerate(self._blocks) if b[1] is c), -1)
            title_row.addWidget(self._make_delete_bar(block_idx_fn))
            cl.addLayout(title_row)
            self._lay.addWidget(container)
            self._blocks.append(("assistant_streaming", container))
            self._stream_container = container
            self._stream_lbl = None

        container = self._stream_container
        cl = container.layout()

        if self._stream_lbl is not None:
            self._stream_lbl.setParent(None)
            self._stream_lbl.deleteLater()
            self._stream_lbl = None

        header = QLabel("⚠ Response error occurred")
        header.setStyleSheet(
            "color: #ff6b6b; font-weight: bold; background: #3d1515; "
            "border-radius: 3px; padding: 4px 8px;")
        cl.addWidget(header)

        err_lbl = QLabel(msg)
        err_lbl.setWordWrap(True)
        err_lbl.setTextFormat(Qt.PlainText)
        err_lbl.setStyleSheet(
            "color: #ffaaaa; background: #2a0d0d; "
            "border-left: 3px solid #8b2020; padding: 6px 10px;")
        err_lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(err_lbl)

        for i, b in enumerate(self._blocks):
            if b[0] == "assistant_streaming" and b[1] is container:
                self._blocks[i] = ("assistant_error", container)
                break

        self._stream_container = None
        self._update_regenerate_button()

    # ── assistant: finalize with parsed code blocks ───────────────────
    def finalize_assistant(self, full_text):
        """
        Finalize a streaming response: render any not-yet-rendered blocks,
        remove the tail label, and add the 'Copy to editor' button if needed.
        Works both after streaming (container exists) and when loading from file.
        """
        self.hide_spinner()
        # If no streaming container exists (e.g. loading from file), create one now
        if self._stream_container is None:
            container = QWidget()
            container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            cl = QVBoxLayout(container)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            title_row = QHBoxLayout()
            title_row.setContentsMargins(0, 0, 0, 0)
            title = QLabel("<b>Assistant:</b>")
            title.setStyleSheet("color: #4ec9b0;")
            title_row.addWidget(title)
            title_row.addStretch()
            block_idx_fn = lambda c=container: next(
                (i for i, b in enumerate(self._blocks) if b[1] is c), -1)
            title_row.addWidget(self._make_delete_bar(block_idx_fn))
            cl.addLayout(title_row)
            # Rendered zone for this (file-load) container
            rz_widget = QWidget()
            rz_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            self._rendered_zone = QVBoxLayout(rz_widget)
            self._rendered_zone.setContentsMargins(0, 0, 0, 0)
            self._rendered_zone.setSpacing(3)
            self._rendered_block_count = 0
            cl.addWidget(rz_widget)
            self._lay.addWidget(container)
            self._blocks.append(("assistant_streaming", container))
            self._stream_container = container
            self._stream_lbl = None

        container = self._stream_container

        # Remove the tail (plain-text streaming) label
        if self._stream_lbl is not None:
            self._stream_lbl.setParent(None)
            self._stream_lbl.deleteLater()
            self._stream_lbl = None

        # Render any blocks not yet pushed during streaming
        blocks = parse_blocks(full_text)
        has_code = any(b["type"] == "code" for b in blocks)
        for block in blocks[self._rendered_block_count:]:
            self.push_rendered_block(block)

        # 'Copy to editor' button (only when response has no code blocks)
        if not has_code and self._rendered_zone is not None:
            btn_row = QHBoxLayout()
            btn_row.addStretch()
            copy_all = QPushButton("📋 Copy to editor")
            copy_all.setFlat(True)
            copy_all.setStyleSheet(
                "QPushButton { color: #888; font-size: 10px; padding: 1px 4px; "
                "border: none; background: transparent; }"
                "QPushButton:hover { color: #ccc; }")
            copy_all.setToolTip("Insert full response at cursor in current editor")
            copy_all.clicked.connect(
                lambda checked=False, t=full_text: self.insert_to_editor.emit(t))
            btn_row.addWidget(copy_all)
            self._rendered_zone.addLayout(btn_row)

        # Update block record
        for i, b in enumerate(self._blocks):
            if b[0] == "assistant_streaming" and b[1] is container:
                self._blocks[i] = ("assistant", container)
                break

        self._stream_container     = None
        self._rendered_zone        = None
        self._rendered_block_count = 0
        # Force the container to recalculate its height now that the streaming
        # label (which may have been much taller than the rendered widgets) is gone.
        container.layout().activate()
        self._update_regenerate_button()

    def clear_all(self):
        for _, container in self._blocks:
            container.deleteLater()
        self._blocks.clear()
        self._stream_container     = None
        self._stream_lbl           = None
        self._rendered_zone        = None
        self._rendered_block_count = 0
        self.hide_spinner()


# ---------------------------------------------------------------------------
# Main chat panel — pure QWidget, no PluginMainWidget inheritance
# ---------------------------------------------------------------------------
class AIChatPanel(QWidget):

    _sig_models_ok  = Signal(list)
    _sig_models_err = Signal(str)

    def __init__(self, get_conf, set_conf, get_editor_cursor, parent=None):
        super().__init__(parent)
        self._get_editor_cursor = get_editor_cursor
        self._messages         = []
        self._assistant_buf    = ""
        self._model_list       = list(DEFAULT_MODELS)
        self._current_model    = DEFAULT_MODELS[0]
        self._fetching         = False
        self._chat_thread      = None
        self._chat_worker      = None
        self._current_lbl      = None
        self._context_files    = []   # list of (name, content, source) added as context
        self._selection_counters = {}  # filename -> selection count
        self._current_chat_file = None        # filename of currently saved chat
        self._current_collection = ""         # active collection ('' = Default)
        self._auto_scroll = True
        self._sp_selected_id = CUSTOM_ID  # currently selected system prompt id
        self._hist_popup = None           # created lazily
        self._params_popup = None         # created lazily
        # Per-chat inference params: only explicitly-set values (empty = use defaults)
        self._infer_params: dict = {}
        # Provider type active when this chat was opened (used to detect provider change)
        self._chat_provider: str = ""
        self._worker_had_error  = False
        self._rendered_char_end = 0   # chars of _assistant_buf already in rendered zone
        # Live streaming code/think block: QPlainTextEdit inside the in-progress widget
        self._streaming_code_edit  = None
        self._streaming_think_edit = None

        # ── Agentic actions state ─────────────────────────────────────
        self._console_execute_fn    = None    # callable(code:str) → None
        self._load_file_fn          = None    # callable(path:str) → None
        self._reload_file_fn        = None    # callable(path:str) → None  (patch reload)

        # ── Project context state ─────────────────────────────────────
        self._proj_enabled          = False   # toggle on/off
        self._proj_root             = None    # project root path
        self._proj_included_folders = []      # top-level folders selected in dialog
        self._proj_hashes           = {}      # {path: hash} at time of last send
        self._proj_all_sent         = False   # True once full context sent in this chat
        self._proj_changed_count    = 0       # stale files detected by watcher
        # Plugin-provided callables (set via set_project_fns)
        self._get_project_root_fn   = None
        self._get_editor_widget_fn  = None

        self._sig_models_ok.connect(self._on_models_ok)
        self._sig_models_err.connect(self._on_models_err)

        # Load persisted state from local JSON file (reliable across restarts)
        self._state = self._load_state()
        self._current_collection = self._state.get("current_collection", "")
        saved_models = self._state.get("model_list", [])
        if saved_models:
            self._model_list = saved_models
        saved_sel = self._state.get("selected_model", "")
        if saved_sel and saved_sel in self._model_list:
            self._current_model = saved_sel
        elif self._model_list:
            self._current_model = self._model_list[0]

        self._popup = None  # created lazily on first use

        self._build_ui()

        # Initialise chat_provider from global state (before any chat is loaded)
        self._chat_provider = self._load_state().get("provider_type", "openai")

        # Restore last open chat after the widget is first shown
        self._last_chat_restored = False

    def showEvent(self, event):
        super().showEvent(event)
        if not self._last_chat_restored:
            self._last_chat_restored = True
            last = self._load_state().get("last_chat_file")
            if last:
                from .chat_history_manager import load_chat as _lc
                _coll, _fname = _decode_chat_ref(last)
                if _lc(_fname, collection=_coll) is not None:  # file still exists
                    QTimer.singleShot(100, lambda: self._load_chat_from_file(last))

    # ── persistent state helpers ──────────────────────────────────────
    @staticmethod
    def _state_path():
        import os
        home = os.path.expanduser("~")
        d = os.path.join(home, ".spyder_ai_chat")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "state.json")

    def _load_state(self):
        try:
            with open(self._state_path(), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_state(self, **kwargs):
        state = self._load_state()
        state.update(kwargs)
        try:
            with open(self._state_path(), "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def _build_ui(self):
        # ── top bar ───────────────────────────────────────────────────
        top = QHBoxLayout()
        top.setContentsMargins(4, 4, 4, 2)
        top.setSpacing(4)

        self._model_btn = QPushButton(self._current_model + " ▾")
        self._model_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._model_btn.setToolTip("Select model")
        self._model_btn.clicked.connect(self._toggle_popup)
        top.addWidget(self._model_btn)

        self._reload_btn = QPushButton("⟳")
        self._reload_btn.setToolTip("Reload model list from API")
        self._reload_btn.setFixedWidth(36)
        self._reload_btn.setStyleSheet(
            "QPushButton { font-size: 16px; font-weight: bold; padding: 0px; }")
        self._reload_btn.clicked.connect(self._reload_models)
        top.addWidget(self._reload_btn)

        self._new_btn = QPushButton("+ New Chat")
        self._new_btn.setToolTip("Clear conversation and start fresh")
        self._new_btn.clicked.connect(self._new_chat)
        top.addWidget(self._new_btn)

        self._cfg_btn = QPushButton("\u2699\uFE0E Settings")
        self._cfg_btn.clicked.connect(self._open_settings)
        top.addWidget(self._cfg_btn)

        self._hist_btn = QPushButton()
        self._hist_btn.setToolTip("Chat history")
        self._hist_btn.setFixedSize(28, 24)
        self._hist_btn.setStyleSheet("QPushButton { padding: 1px; border: none; }")
        # Inline SVG: document with checkmark lines
        _svg = b"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path d="M6 2h9l4 4v16H5V2z" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M14 2v5h5" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M7 10l1.5 1.5L11 9" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="10" x2="17" y2="10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 14l1.5 1.5L11 13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="14" x2="17" y2="14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 18l1.5 1.5L11 17" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="18" x2="17" y2="18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>"""
        from qtpy.QtSvg import QSvgRenderer
        from qtpy.QtGui import QPixmap, QPainter, QColor
        from qtpy.QtCore import QByteArray
        try:
            # Try to get foreground color from theme
            from spyder.config.gui import is_dark_interface
            icon_color = "#d4d4d4" if is_dark_interface() else "#333333"
        except Exception:
            icon_color = "#d4d4d4"
        svg_colored = _svg.replace(b"currentColor", icon_color.encode())
        renderer = QSvgRenderer(QByteArray(svg_colored))
        pixmap = QPixmap(16, 16)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        renderer.render(painter)
        painter.end()
        from qtpy.QtGui import QIcon
        self._hist_btn.setIcon(QIcon(pixmap))
        self._hist_btn.setIconSize(pixmap.size())
        self._hist_btn.clicked.connect(self._toggle_history_popup)
        top.addWidget(self._hist_btn)

        # ── scrollable chat history ───────────────────────────────────
        from qtpy.QtWidgets import QScrollArea
        self._history = _ChatHistory()
        self._history._font_cfg = self._editor_cfg()
        self._history.setMinimumWidth(400)
        self._history.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        scroll = QScrollArea()
        scroll.setWidget(self._history)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)
        self._scroll = scroll
        self._auto_scroll = True
        scroll.verticalScrollBar().rangeChanged.connect(self._on_scroll_range_changed)

        # ── file context bar ──────────────────────────────────────────
        # Left column: wrapping flow of attachment tags (expands).
        # Right column: project toggle button (fixed, always visible).
        self._ctx_bar = QWidget()
        self._ctx_bar.setVisible(True)
        ctx_bar_outer = QHBoxLayout(self._ctx_bar)
        ctx_bar_outer.setContentsMargins(4, 2, 4, 2)
        ctx_bar_outer.setSpacing(6)

        # Left: flow layout for tags
        self._ctx_tags_widget = QWidget()
        self._ctx_tags_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._ctx_bar_layout = _FlowLayout(self._ctx_tags_widget, h_spacing=4, v_spacing=3)
        self._ctx_bar_layout.setContentsMargins(0, 0, 0, 0)
        ctx_bar_outer.addWidget(self._ctx_tags_widget, 1)

        # Right: project context toggle (fixed width, always visible)
        self._proj_toggle_btn = QPushButton("📁 Proj. Context  ○")
        self._proj_toggle_btn.setCheckable(True)
        self._proj_toggle_btn.setFixedHeight(22)
        self._proj_toggle_btn.setToolTip(
            "Enable project-wide context — attach all project files to the chat")
        self._proj_toggle_btn.setStyleSheet(
            "QPushButton { font-size: 9px; padding: 1px 8px; border: 1px solid #555; "
            "border-radius: 3px; color: #aaa; background: transparent; }"
            "QPushButton:hover { color: #fff; border-color: #888; }"
            "QPushButton:checked { color: #c8a000; border-color: #c8a000; "
            "background: #3a2a00; }"
            "QPushButton:checked:hover { color: #ffe080; }")
        self._proj_toggle_btn.clicked.connect(self._on_proj_toggle)
        ctx_bar_outer.addWidget(self._proj_toggle_btn, 0)

        # File watcher for project directory changes
        self._proj_watcher = QFileSystemWatcher(self)
        self._proj_watcher.directoryChanged.connect(self._on_proj_dir_changed)

        # ══════════════════════════════════════════════════════════════
        # ROW 1: Inference params summary (always visible) + config btn
        # ══════════════════════════════════════════════════════════════
        params_row = QHBoxLayout()
        params_row.setContentsMargins(2, 1, 2, 1)
        params_row.setSpacing(4)

        # Summary label — always shown, clickable, opens params popup
        self._params_bar_lbl = QPushButton("Click to set inference params")
        self._params_bar_lbl.setFlat(True)
        self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_IDLE_STYLE)
        self._params_bar_lbl.setToolTip("Click to configure inference parameters (temperature, max tokens…)")
        self._params_bar_lbl.clicked.connect(self._toggle_params_popup)
        self._params_bar_lbl.setFixedHeight(24)
        params_row.addWidget(self._params_bar_lbl, 1)

        # Wrap in a widget
        params_bar_w = QWidget()
        params_bar_w.setLayout(params_row)
        self._params_bar = params_bar_w

        # ══════════════════════════════════════════════════════════════
        # ROW 2: System prompts selector + ↓ Copy to field button
        # ══════════════════════════════════════════════════════════════
        sp_bar = QWidget()
        sp_bar_lay = QHBoxLayout(sp_bar)
        sp_bar_lay.setContentsMargins(0, 0, 0, 0)
        sp_bar_lay.setSpacing(4)

        sp_lbl = QLabel("System prompts:")
        sp_lbl.setStyleSheet("font-size: 9pt; color: gray;")
        sp_lbl.setFixedWidth(100)
        sp_bar_lay.addWidget(sp_lbl)

        self._sp_combo = QComboBox()
        self._sp_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._sp_combo.setStyleSheet("font-size: 9pt;")
        sp_bar_lay.addWidget(self._sp_combo, 1)

        # ⚙ Settings button → opens Settings on the System Prompts tab
        self._sp_settings_btn = QPushButton("⚙")
        self._sp_settings_btn.setFixedSize(24, 24)
        self._sp_settings_btn.setToolTip("Manage system prompts in Settings")
        self._sp_settings_btn.setStyleSheet(
            "QPushButton { font-size: 12px; padding: 0; border: 1px solid #555; "
            "border-radius: 3px; color: #aaa; }"
            "QPushButton:hover { color: #fff; border-color: #aaa; }"
            "QPushButton:pressed { color: #c8a000; border-color: #c8a000; }")
        self._sp_settings_btn.clicked.connect(self._open_settings_sp_tab)
        sp_bar_lay.addWidget(self._sp_settings_btn)

        self._sp_copy_btn = QPushButton("↓📋 Copy and edit")
        self._sp_copy_btn.setFixedHeight(24)
        self._sp_copy_btn.setFixedWidth(125)
        self._sp_copy_btn.setStyleSheet("font-size: 9pt;")
        self._sp_copy_btn.setToolTip("Copy selected prompt text into the field below for editing")
        self._sp_copy_btn.setVisible(False)
        sp_bar_lay.addWidget(self._sp_copy_btn)

        # ══════════════════════════════════════════════════════════════
        # ROW 3: System prompt field (full width)
        # ══════════════════════════════════════════════════════════════
        self._sys_prompt = QPlainTextEdit()
        self._sys_prompt.setPlaceholderText("System prompt (optional)")
        self._sys_prompt.setMaximumHeight(48)
        self._sys_prompt.setFont(QFont("Monospace", 9))

        # ══════════════════════════════════════════════════════════════
        # ROW 4: User input + Send (tall) / Stop (short) stacked right
        # ══════════════════════════════════════════════════════════════
        self._input = _CommandInput()
        self._input.set_commands(load_commands())
        self._input.send_requested.connect(self._send)
        self._input.setPlaceholderText("Type message… (Ctrl+Enter to send, / for commands)")
        self._input.setMaximumHeight(72)
        self._input.setFont(QFont("Monospace", 10))
        self._input.installEventFilter(self)

        self._send_btn = QPushButton("Send")
        self._send_btn.setMinimumWidth(64)
        # Send gets ~66% of the input height
        self._send_btn.setFixedHeight(48)
        self._send_btn.clicked.connect(self._send)

        self._stop_btn = QPushButton("Stop")
        self._stop_btn.setMinimumWidth(64)
        # Stop gets the remaining ~34%
        self._stop_btn.setFixedHeight(24)
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop)

        btn_col = QVBoxLayout()
        btn_col.setContentsMargins(0, 0, 0, 0)
        btn_col.setSpacing(4)
        btn_col.addWidget(self._send_btn)
        btn_col.addWidget(self._stop_btn)

        input_row = QHBoxLayout()
        input_row.setContentsMargins(0, 0, 0, 0)
        input_row.setSpacing(2)
        input_row.addWidget(self._input, 1)
        input_row.addLayout(btn_col)

        # ── status ────────────────────────────────────────────────────
        n = len(self._model_list)
        src = "saved" if self._state.get("model_list") else "defaults"
        self._status = QLabel(f"Ready. {n} model(s) from {src}. Click ⟳ to refresh.")
        self._status.setWordWrap(True)
        self._status.setStyleSheet("font-size:10px; padding:2px 4px;")

        # ── assemble ──────────────────────────────────────────────────
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        lay.addLayout(top)
        lay.addWidget(scroll, stretch=1)
        lay.addWidget(self._ctx_bar)
        lay.addWidget(params_bar_w)
        lay.addWidget(sp_bar)
        lay.addWidget(self._sys_prompt)
        lay.addLayout(input_row)
        lay.addWidget(self._status)

        # Wire up copy-to-editor from history
        self._history.insert_to_editor.connect(self._insert_to_editor)
        # Wire up delete exchange
        self._history.delete_exchange.connect(self._on_delete_exchange)
        # Wire up regenerate
        self._history.regenerate.connect(self._on_regenerate)

        # Wire up system prompt selector
        self._sp_populate_combo()
        self._sp_combo.currentIndexChanged.connect(self._sp_on_select)
        self._sp_copy_btn.clicked.connect(self._sp_on_copy)

    # ── file context ─────────────────────────────────────────────────
    # ── project context ───────────────────────────────────────────────

    def set_project_fns(self, get_project_root_fn, get_editor_widget_fn):
        """Called by plugin.py to wire up project/editor access."""
        self._get_project_root_fn  = get_project_root_fn
        self._get_editor_widget_fn = get_editor_widget_fn

    def on_project_loaded(self, path):
        """Called by plugin.py when Spyder loads a project."""
        if self._proj_enabled and self._proj_root != path:
            # Different project loaded — reset state
            self._proj_root = path
            self._proj_hashes = {}
            self._proj_all_sent = False
            self._proj_changed_count = 0
            self._update_proj_watcher()
        self._proj_toggle_btn.setEnabled(True)
        self._rebuild_ctx_bar()

    def on_project_closed(self):
        """Called by plugin.py when Spyder closes the active project."""
        self._proj_toggle_btn.setEnabled(False)
        if self._proj_enabled:
            self._proj_changed_count = 0
            self._rebuild_ctx_bar()

    def _on_proj_toggle(self, checked):
        if checked:
            self._try_enable_project_context()
        else:
            self._disable_project_context()

    def _try_enable_project_context(self):
        root = (self._get_project_root_fn()
                if self._get_project_root_fn else None)
        if not root:
            self._proj_toggle_btn.setChecked(False)
            self._status.setText("⚠ No Spyder project is currently open.")
            return

        cfg = self._history_cfg()
        dlg = _ProjectContextDialog(
            root,
            max_file_kb=cfg.get("proj_max_file_kb", 256),
            max_files=cfg.get("proj_max_files", 500),
            extra_patterns=cfg.get("proj_extra_exclusions", "").splitlines(),
            parent=self,
        )
        if dlg.exec_() != QDialog.Accepted:
            self._proj_toggle_btn.setChecked(False)
            return

        self._proj_enabled          = True
        self._proj_root             = root
        self._proj_included_folders = dlg.selected_folders()
        self._proj_hashes           = {}
        self._proj_all_sent         = False
        self._proj_changed_count    = 0
        # Remove any manually attached files — project context replaces them
        self._context_files.clear()
        self._selection_counters.clear()
        self._update_proj_watcher()
        self._rebuild_ctx_bar()
        self._status.setText(
            f"Project context enabled: {len(dlg.selected_files())} files queued.")

    def _disable_project_context(self):
        from qtpy.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self,
            "Disable project context",
            "Project context will be detached from this chat.\n"
            "Future messages will not include project files.\nContinue?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            self._proj_toggle_btn.setChecked(True)
            return
        self._proj_enabled       = False
        self._proj_hashes        = {}
        self._proj_all_sent      = False
        self._proj_changed_count = 0
        self._update_proj_watcher()
        self._rebuild_ctx_bar()
        self._status.setText("Project context disabled.")

    def _update_proj_watcher(self):
        # Remove old watched paths
        old = self._proj_watcher.directories()
        if old:
            self._proj_watcher.removePaths(old)
        if self._proj_enabled and self._proj_root:
            self._proj_watcher.addPath(self._proj_root)

    def _on_proj_dir_changed(self, _path):
        if not self._proj_enabled:
            return
        self._proj_changed_count = self._count_proj_changes()
        self._rebuild_ctx_bar()

    def _count_proj_changes(self):
        """Quick count of files whose disk hash differs from stored hash."""
        if not self._proj_root or not self._proj_hashes:
            return 0
        from .project_context import collect_project_files, diff_files
        try:
            cfg = self._history_cfg()
            current = collect_project_files(
                self._proj_root,
                included_folders=self._proj_included_folders or None,
                extra_patterns=cfg.get("proj_extra_exclusions", "").splitlines(),
                max_file_kb=cfg.get("proj_max_file_kb", 256),
                max_files=cfg.get("proj_max_files", 500),
            )
            changed, added, removed = diff_files(self._proj_hashes, current)
            return len(changed) + len(added) + len(removed)
        except Exception:
            return 0

    def _proj_ctx_for_save(self):
        """Build project_context dict for saving to chat JSON."""
        if not self._proj_enabled or not self._proj_root:
            return None
        return {
            "enabled":          True,
            "root":             self._proj_root,
            "included_folders": self._proj_included_folders,
            "files": [
                {"path": p, "hash": h}
                for p, h in self._proj_hashes.items()
            ],
        }

    def _collect_project_context(self):
        """
        Collect all current project files and compute full/delta context text.
        Returns context text string (empty string if nothing to send).
        Updates self._proj_hashes and self._proj_all_sent.
        """
        from .project_context import (
            collect_project_files, collect_unsaved_files, get_effective_files,
            build_full_context_text, build_delta_text, diff_files,
        )
        cfg = self._history_cfg()
        editor_widget = (self._get_editor_widget_fn()
                         if self._get_editor_widget_fn else None)

        disk_files = collect_project_files(
            self._proj_root,
            included_folders=self._proj_included_folders or None,
            extra_patterns=cfg.get("proj_extra_exclusions", "").splitlines(),
            max_file_kb=cfg.get("proj_max_file_kb", 256),
            max_files=cfg.get("proj_max_files", 500),
        )
        disk_files = get_effective_files(disk_files, editor_widget)
        unsaved    = collect_unsaved_files(editor_widget)
        all_files  = disk_files + unsaved

        if not self._proj_all_sent:
            text = build_full_context_text(self._proj_root, all_files)
            self._proj_hashes   = {f["path"]: f["hash"] for f in all_files}
            self._proj_all_sent = True
        else:
            changed, added, removed = diff_files(self._proj_hashes, all_files)
            if not changed and not added and not removed:
                return ""
            text = build_delta_text(changed, added, removed, root=self._proj_root)
            for f in changed + added:
                self._proj_hashes[f["path"]] = f["hash"]
            for p in removed:
                self._proj_hashes.pop(p, None)

        self._proj_changed_count = 0
        self._rebuild_ctx_bar()
        return text

    # ── file context ──────────────────────────────────────────────────

    def add_file_context(self, path):
        """Add a saved file by path — reads content from disk."""
        import os
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as e:
            self._status.setText(f"⚠ Could not read file: {e}")
            return
        # Use full absolute path as the name so the LLM knows the exact location
        self.add_file_context_content(os.path.normpath(os.path.abspath(path)), content)

    def add_file_context_content(self, name, content, source="file"):
        """Add file context by name + content directly (works for unsaved files).
        source: "file" for whole-file editor attachments (blocked when project ON),
                "selection" for editor selections (always allowed),
                "console" for IPython console (always allowed)."""
        if self._proj_enabled and source == "file":
            self._status.setText(
                "⚠ Disable project context to attach individual files.")
            return
        # Don't add duplicates by name
        if any(n == name for n, *_ in self._context_files):
            self._status.setText(f"Already in context: {name}")
            return
        self._context_files.append((name, content, source))
        self._rebuild_ctx_bar()
        self._status.setText(
            f"Added to context: {name} ({len(content)} chars)")

    def next_selection_id(self, filename):
        """Return and increment the selection counter for this filename."""
        key = filename
        count = self._selection_counters.get(key, 0) + 1
        self._selection_counters[key] = count
        return count

    def _remove_file_context(self, name):
        self._context_files = [(n, c, s) for n, c, s in self._context_files if n != name]
        self._rebuild_ctx_bar()

    def _rebuild_ctx_bar(self):
        import os as _os
        # Clear all items from the flow layout
        while self._ctx_bar_layout.count() > 0:
            item = self._ctx_bar_layout.takeAt(0)
            if item and item.widget():
                item.widget().deleteLater()

        # Project badge (no ✕ button, amber/gold)
        if self._proj_enabled:
            badge_text = f"📁 {self._proj_badge_text()}"
            badge = QFrame()
            badge.setStyleSheet(
                "QFrame { background: #3a2a00; border: 1px solid #c8a000; "
                "border-radius: 3px; padding: 1px; }")
            bl = QHBoxLayout(badge)
            bl.setContentsMargins(5, 1, 5, 1)
            bl.setSpacing(0)
            lbl = QLabel(badge_text)
            lbl.setStyleSheet(
                "color: #c8a000; font-size: 10px; border: none; "
                "background: transparent;")
            bl.addWidget(lbl)
            self._ctx_bar_layout.addWidget(badge)

        # Regular attachment tags (editor/console/git)
        for name, _, source in self._context_files:
            if source == "console":
                bg, border_col, text_col = "#1e3a2a", "#3a7a5a", "#80c8a0"
            elif source == "git":
                bg, border_col, text_col = "#2a1a00", "#e8a050", "#f0c080"
            else:
                bg, border_col, text_col = "#2d4a6e", "#4a7ab5", "#9ec8f0"
            tag = QFrame()
            tag.setStyleSheet(
                f"QFrame {{ background: {bg}; border: 1px solid {border_col}; "
                "border-radius: 3px; padding: 1px; }")
            tl = QHBoxLayout(tag)
            tl.setContentsMargins(5, 1, 3, 1)
            tl.setSpacing(3)
            display_name = _os.path.basename(name) if (_os.path.sep in name or "/" in name) else name
            lbl = QLabel(display_name)
            lbl.setToolTip(name)
            lbl.setStyleSheet(
                f"color: {text_col}; font-size: 10px; border: none; "
                "background: transparent;")
            tl.addWidget(lbl)
            x_btn = QPushButton("×")
            x_btn.setFixedSize(14, 14)
            x_btn.setFlat(True)
            x_btn.setStyleSheet(
                "QPushButton { color: #888; font-size: 11px; border: none; "
                "background: transparent; padding: 0; }"
                "QPushButton:hover { color: #fff; }")
            x_btn.clicked.connect(
                lambda checked=False, n=name: self._remove_file_context(n))
            tl.addWidget(x_btn)
            self._ctx_bar_layout.addWidget(tag)

        self._ctx_tags_widget.setVisible(True)

        # ctx_bar is always visible (toggle button always shown)
        self._ctx_bar.setVisible(True)

        # Update toggle button label and tooltip to reflect current state
        if self._proj_enabled:
            self._proj_toggle_btn.setText("📁 Proj. Context  ●")
            self._proj_toggle_btn.setToolTip(
                "Project context is ON — click to disable")
        else:
            self._proj_toggle_btn.setText("📁 Proj. Context  ○")
            self._proj_toggle_btn.setToolTip(
                "Enable project-wide context — attach all project files to the chat")

    def _proj_badge_text(self):
        root = self._proj_root or ""
        name = root.split("/")[-1].split("\\")[-1] if root else "Project"
        n_files = len(self._proj_hashes)
        if not self._proj_all_sent:
            return f"{name} (pending first send)"
        if self._proj_changed_count:
            return f"{name} · {self._proj_changed_count} changed ⚠"
        return f"{name} · {n_files} files"

    # ── event filter ─────────────────────────────────────────────────
    def eventFilter(self, obj, event):
        # _CommandInput handles Ctrl+Enter and slash-dropdown natively;
        # keep this filter for any future obj-level overrides.
        return super().eventFilter(obj, event)

    # ── model popup ───────────────────────────────────────────────────
    def _toggle_popup(self):
        if self._popup is None:
            # Create lazily so main window is visible and stylesheet is applied
            try:
                from qtpy.QtWidgets import QApplication
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._popup = _ModelPopup(main_win)
            self._popup.selected.connect(self._select_model)

        if self._popup.isVisible():
            self._popup.hide()
        else:
            self._popup.show_below(
                self._model_btn, self._model_list, self._current_model)

    def _select_model(self, name):
        self._current_model = name
        self._model_btn.setText(name + " ▾")
        self._status.setText(f"Model: {name}")
        self._save_state(selected_model=name)

    def _reload_models(self):
        """Manually triggered model list refresh from API."""
        self._fetching = False   # force re-fetch even if previous attempt failed
        self._reload_btn.setEnabled(False)
        self._reload_btn.setText("…")
        self._fetch_models()

    # ── model fetching ────────────────────────────────────────────────
    def _fetch_models(self):
        if self._fetching:
            return
        self._fetching = True
        url = self._api_url()
        key = self._api_key()
        sig_ok  = self._sig_models_ok
        sig_err = self._sig_models_err

        def _work():
            try:
                import urllib.request
                import urllib.error
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": "spyder-ai-chat/0.1.2",
                }
                if key:
                    headers["Authorization"] = f"Bearer {key}"
                req = urllib.request.Request(
                    url.rstrip("/") + "/models", headers=headers)
                with urllib.request.urlopen(req, timeout=8) as r:
                    data  = json.loads(r.read().decode())
                    items = data.get("data", data.get("models", []))
                    models = sorted(
                        m["id"] for m in items
                        if isinstance(m, dict) and "id" in m)
                    sig_ok.emit(models if models else [])
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:200]
                except Exception:
                    body = ""
                sig_err.emit(f"HTTP {e.code} {e.reason}: {body}")
            except Exception as e:
                sig_err.emit(f"{type(e).__name__}: {e}")

        threading.Thread(target=_work, daemon=True).start()

    @Slot(list)
    def _on_models_ok(self, models):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        if models:
            self._model_list = models
            if self._current_model not in models:
                self._current_model = models[0]
                self._model_btn.setText(self._current_model + " ▾")
            self._save_state(model_list=models, selected_model=self._current_model)
            preview = ", ".join(models[:3]) + (" …" if len(models) > 3 else "")
            self._status.setText(f"✓ {len(models)} model(s): {preview}")
        else:
            self._status.setText("⚠ No models returned.")

    @Slot(str)
    def _on_models_err(self, err):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        self._status.setText(f"⚠ Model fetch failed: {err}")

    # ── config ────────────────────────────────────────────────────────
    def _api_url(self):
        return self._load_state().get("api_url", "https://api.openai.com/v1")

    def _api_key(self):
        return self._load_state().get("api_key", "")

    def _history_cfg(self):
        return {**HISTORY_DEFAULTS, **self._load_state().get("history", {})}

    def _editor_cfg(self):
        return {**EDITOR_DEFAULTS, **self._load_state().get("editor", {})}

    def _agentic_cfg(self):
        return {**AGENTIC_DEFAULTS, **self._load_state().get("agentic", {})}

    def set_console_execute_fn(self, fn):
        """Called by plugin to provide IPython console execute function."""
        self._console_execute_fn = fn

    def set_load_file_fn(self, fn):
        """Called by plugin to provide editor load-file function."""
        self._load_file_fn = fn

    def set_reload_file_fn(self, fn):
        """Called by plugin to provide editor reload-file function (for patch actions)."""
        self._reload_file_fn = fn

    def _build_action_env(self):
        """Build the action_env dict passed to build_action_block."""
        import os as _os
        from .agentic_actions import execute_create_file, execute_patch_file
        cfg = self._agentic_cfg()

        # Lazy base-dir resolver — called at execution time, not at build time,
        # so it always reflects the current Spyder project even when the action
        # env was built during startup before the project finished loading.
        cfg_base = cfg.get("base_path", "").strip()

        def _get_base_dir():
            if cfg_base and _os.path.isdir(cfg_base):
                return cfg_base
            live = (self._get_project_root_fn()
                    if self._get_project_root_fn else None)
            if live and _os.path.isdir(live):
                return live
            if self._proj_root and _os.path.isdir(self._proj_root):
                return self._proj_root
            return _os.path.expanduser("~")

        # Static snapshot used for display labels at render time (best-effort).
        base_dir = _get_base_dir()

        load_fn   = getattr(self, "_load_file_fn", None)
        reload_fn = getattr(self, "_reload_file_fn", None)

        def _create_file(path, content, bd=None):
            return execute_create_file(path, content, bd or _get_base_dir())

        def _patch_file(path, diff, bd=None):
            return execute_patch_file(path, diff, bd or _get_base_dir())

        def _run_console(code):
            if self._console_execute_fn:
                self._console_execute_fn(code)

        def _install(spec):
            if self._console_execute_fn:
                self._console_execute_fn(f"%pip install {spec.strip()}")

        def _inject_git_output(cmd, output):
            """Add git command output as an orange attachment tag."""
            name = f"⎇ {cmd}"
            body = f"[Git command: {cmd}]\n{output}"
            self.add_file_context_content(name, body, source="git")

        def _on_executed(block_idx, action_type, target):
            """Store execution record in the last assistant message and autosave."""
            for msg in reversed(self._messages):
                if msg.get("role") == "assistant":
                    executed = msg.setdefault("agentic_executed", [])
                    if not any(e.get("block_idx") == block_idx for e in executed):
                        executed.append({
                            "type":      action_type,
                            "target":    target,
                            "block_idx": block_idx,
                        })
                    break
            self._autosave()

        return {
            "create_file_fn":    _create_file,
            "patch_file_fn":     _patch_file,
            "run_console_fn":    _run_console,
            "install_fn":        _install,
            "inject_git_output_fn": _inject_git_output,
            "load_file_fn":      load_fn,
            "reload_file_fn":    reload_fn,
            "on_executed":       _on_executed,
            "base_dir":          base_dir,
            "base_dir_fn":       _get_base_dir,
            "confirm_each":      True,
            "allow_create_file": cfg.get("allow_create_file", True),
            "allow_run_console": cfg.get("allow_run_console", True),
            "allow_install":     cfg.get("allow_install", False),
            "allow_patch":       cfg.get("allow_patch", True),
            "allow_git":         cfg.get("allow_git", True),
        }

    # ── copy to editor ────────────────────────────────────────────────
    def _insert_to_editor(self, text):
        result = self._get_editor_cursor()
        cursor, editor_or_diag = result

        if cursor is not None:
            try:
                cursor.insertText(text)
                editor_or_diag.setTextCursor(cursor)
                self._status.setText("✓ Inserted into editor at cursor position.")
                return
            except Exception as e:
                editor_or_diag = str(e)

        # Fallback: clipboard
        QApplication.clipboard().setText(text)
        # Show diagnostic info so we can debug
        self._status.setText(f"Clipboard copy. Diag: {editor_or_diag}")

    # ── new chat ──────────────────────────────────────────────────────
    def _on_history_deleted(self, ref):
        """Called when a chat is deleted from the history popup."""
        collection, filename = _decode_chat_ref(ref)
        if filename == self._current_chat_file and collection == self._current_collection:
            # The currently displayed chat was deleted — clear the window
            self._current_chat_file = None
            self._messages.clear()
            self._history.clear_all()
            self._context_files.clear()
            self._selection_counters.clear()
            self._rebuild_ctx_bar()
            self._sys_prompt.clear()
            self._sp_selected_id = CUSTOM_ID
            self._sp_populate_combo(select_id=CUSTOM_ID)
            self._status.setText("Current chat deleted.")

    def _on_history_deleted_all(self):
        """Called when all chats are deleted via the Delete All button."""
        self._current_chat_file = None
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()
        self._sys_prompt.clear()
        self._sp_selected_id = CUSTOM_ID
        self._sp_populate_combo(select_id=CUSTOM_ID)
        self._save_state(last_chat_file=None)
        self._status.setText("All chats deleted.")

    def _new_chat(self):
        # Save current chat to history before clearing (if enabled)
        if self._messages and self._history_cfg().get("save_on_new", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                collection=self._current_collection,
                provider=self._chat_provider,
                infer_params=self._infer_params,
                project_context=self._proj_ctx_for_save(),
            )
        self._current_chat_file = None
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        # Optionally disable project context for new chats (configurable in settings)
        if self._history_cfg().get("proj_reset_on_new_chat", True):
            self._proj_enabled       = False
            self._proj_included_folders = []
            self._proj_hashes        = {}
            self._proj_all_sent      = False
            self._proj_changed_count = 0
            self._proj_toggle_btn.setChecked(False)
            self._update_proj_watcher()
        self._rebuild_ctx_bar()
        default_id = self._load_state().get("default_system_prompt_id")
        if default_id:
            p = get_prompt(default_id)
            if p:
                self._sp_selected_id = default_id
                self._sp_populate_combo(select_id=default_id)
                self._sys_prompt.setPlainText(p["content"])
            else:
                self._sp_selected_id = CUSTOM_ID
                self._sp_populate_combo(select_id=CUSTOM_ID)
                self._sys_prompt.clear()
        else:
            self._sp_selected_id = CUSTOM_ID
            self._sp_populate_combo(select_id=CUSTOM_ID)
            self._sys_prompt.clear()
        self._infer_params = {}
        self._update_summary_bar()
        self._save_state(last_chat_file=None)
        self._status.setText("New conversation started.")

    def _toggle_history_popup(self):
        if self._hist_popup is None:
            try:
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._hist_popup = _ChatHistoryPopup(
                save_state_fn=lambda coll: self._save_state(current_collection=coll),
                parent=main_win,
            )
            self._hist_popup.load_chat.connect(self._load_chat_from_file)
            self._hist_popup.del_chat.connect(self._on_history_deleted)
            self._hist_popup.del_all.connect(self._on_history_deleted_all)

        if self._hist_popup.isVisible():
            self._hist_popup.hide()
        else:
            self._hist_popup.show_below(
                self._hist_btn,
                current_file=self._current_chat_file,
                current_collection=self._current_collection,
                current_file_collection=self._current_collection,
            )

    def _load_chat_from_file(self, ref):
        """Load a saved chat into the current view.
        ref: encoded chat reference ("Collection/filename.json" or bare "filename.json").
        """
        collection, filename = _decode_chat_ref(ref)
        data = load_chat(filename, collection=collection)
        if data is None:
            self._status.setText("⚠ Could not load chat.")
            return
        # Save current chat first if it has content and saving is enabled
        if self._messages and self._history_cfg().get("autosave", True):
            save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                collection=self._current_collection,
                provider=self._chat_provider,
                infer_params=self._infer_params,
                project_context=self._proj_ctx_for_save(),
            )
        # Restore state
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()

        sys_p     = data.get("system_prompt", "")
        prompt_id = data.get("prompt_id", CUSTOM_ID) or CUSTOM_ID

        # If saved prompt no longer exists, fall back to custom
        if prompt_id != CUSTOM_ID and get_prompt(prompt_id) is None:
            prompt_id = CUSTOM_ID

        # Restore prompt selector first (it may overwrite sys_p via _sp_on_select)
        self._sp_selected_id = prompt_id
        self._sp_populate_combo(select_id=prompt_id)

        # For custom prompts, restore the text; saved prompts are set by combo
        if prompt_id == CUSTOM_ID:
            self._sys_prompt.setPlainText(sys_p)

        model = data.get("model", "")
        if model and model in self._model_list:
            self._current_model = model
            self._model_btn.setText(model + " ▾")

        # Restore project context first so _proj_root is set before
        # _build_action_env() runs — needed for base_dir and overwrite detection.
        import os as _os
        saved_proj = data.get("project_context")
        self._proj_enabled          = False
        self._proj_root             = None
        self._proj_included_folders = []
        self._proj_hashes           = {}
        self._proj_all_sent         = False
        self._proj_changed_count    = 0
        if saved_proj and saved_proj.get("enabled"):
            root = saved_proj.get("root", "")
            if root and _os.path.isdir(root):
                self._proj_enabled          = True
                self._proj_root             = root
                self._proj_included_folders = saved_proj.get("included_folders", [])
                self._proj_hashes           = {
                    f["path"]: f["hash"]
                    for f in saved_proj.get("files", [])
                }
                self._proj_all_sent = True
                self._proj_changed_count = self._count_proj_changes()
            else:
                self._status.setText("⚠ Project context: root folder not found.")
        self._proj_toggle_btn.setChecked(self._proj_enabled)
        self._update_proj_watcher()
        self._rebuild_ctx_bar()

        # Build action_env now that _proj_root is available, so action blocks
        # rendered during finalize_assistant() get correct base_dir,
        # run_console_fn, and overwrite detection from the first render.
        if self._agentic_cfg().get("enabled"):
            self._history._action_env = self._build_action_env()
        else:
            self._history._action_env = None

        for msg in data.get("messages", []):
            role    = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user":
                attachments = msg.get("attachments", [])
                # New format: content is plain user text, attachments are separate
                # Legacy format: file blocks embedded in content — strip them
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
                self._messages.append(msg)
            elif role == "assistant":
                # Restore which action blocks were already executed in this response
                executed_list = msg.get("agentic_executed", [])
                self._history._current_executed_blocks = {
                    e["block_idx"] for e in executed_list
                    if isinstance(e.get("block_idx"), int)
                }
                self._history.finalize_assistant(content)
                self._history._current_executed_blocks = set()
                self._messages.append(msg)
            elif role == "assistant_error":
                self._history.show_error(content)
                self._messages.append(msg)

        self._current_chat_file  = filename
        self._current_collection = collection
        self._save_state(
            last_chat_file=_encode_chat_ref(collection, filename),
            current_collection=collection,
        )

        # Restore per-chat provider and inference params
        current_provider = self._load_state().get("provider_type", "custom")
        saved_provider   = data.get("provider") or ""
        if saved_provider and saved_provider != current_provider:
            # Chat was saved under a different provider — reset params
            self._infer_params    = {}
            self._chat_provider   = current_provider
        else:
            self._infer_params  = dict(data.get("infer_params") or {})
            self._chat_provider = current_provider
        self._update_summary_bar()

        self._status.setText(f"Loaded: {data.get('preview', filename)[:40]}")
        self._deferred_scroll_to_bottom()

    # ── settings ──────────────────────────────────────────────────────
    def _open_settings_sp_tab(self):
        """Open Settings dialog with the System Prompts tab pre-selected."""
        self._open_settings(initial_tab=4)

    def _open_settings(self, initial_tab=0):
        state = self._load_state()
        old_provider = state.get("provider_type", "custom")
        dlg = SettingsDialog(
            self,
            provider_type    = state.get("provider_type", "openai"),
            api_url          = state.get("api_url", "https://api.openai.com/v1"),
            api_key          = state.get("api_key", ""),
            default_system_prompt_id = state.get("default_system_prompt_id"),
            editor_cfg       = state.get("editor", {}),
            history_cfg      = state.get("history", {}),
            azure_deployment = state.get("azure_deployment", ""),
            azure_api_version= state.get("azure_api_version", "2024-02-01"),
            commands         = load_commands(),
            fim_cfg          = state.get("fim", {}),
            agentic_cfg      = state.get("agentic", {}),
            initial_tab      = initial_tab,
        )
        if dlg.exec_() == QDialog.Accepted:
            v = dlg.values()
            self._save_state(
                provider_type            = v["provider_type"],
                agentic                  = v.get("agentic", {}),
                api_url                  = v["api_url"],
                api_key                  = v["api_key"],
                azure_deployment         = v["azure_deployment"],
                azure_api_version        = v["azure_api_version"],
                editor                   = v["editor"],
                history                  = v["history"],
                fim                      = v["fim"],
                default_system_prompt_id = v["default_system_prompt_id"],
            )
            self._history._font_cfg = self._editor_cfg()
            self._fetching = False
            self._status.setText("Settings saved.")
            self._fetch_models()
            # Refresh prompt combo in case prompts were added/deleted
            self._sp_populate_combo()
            # Reload commands into the input widget
            self._input.set_commands(load_commands())
            # If provider changed, reset per-chat inference params
            if v["provider_type"] != old_provider:
                self._on_provider_changed(v["provider_type"])

    # ── send / stop ───────────────────────────────────────────────────
    def _send(self):
        # Snapshot active commands BEFORE clearing the input (clear() resets them)
        active_commands_snapshot = list(self._input._active_commands)
        display_text = self._input.toPlainText().strip()
        if not display_text:
            return
        if self._chat_thread is not None and self._chat_thread.isRunning():
            return
        self._input.clear()

        # Snapshot and clear pending context files
        pending_attachments = list(self._context_files)
        if pending_attachments:
            self._context_files.clear()
            self._rebuild_ctx_bar()

        # Build structured message — content = display text for UI / history.
        # content_llm = expanded text frozen at send time so history replay is
        # correct even if the command is later edited or deleted in Settings.
        user_msg = {
            "role": "user",
            "content": display_text,
        }
        if active_commands_snapshot:
            # Expand spans against the display_text to produce the full LLM prompt
            chars = list(display_text)
            for c in sorted(active_commands_snapshot,
                            key=lambda x: x["start"], reverse=True):
                s, l = c["start"], c["length"]
                prompt = get_command_prompt(c["name"], self._input._commands)
                if prompt:
                    chars[s:s+l] = list(prompt)
            user_msg["content_llm"] = "".join(chars)
            user_msg["command_spans"] = [
                [c["start"], c["length"]] for c in active_commands_snapshot
            ]
        if pending_attachments:
            user_msg["attachments"] = [
                {"name": name, "content": content}
                for name, content, *_ in pending_attachments
            ]

        # Inject project context (full on first send, delta on subsequent)
        if self._proj_enabled and self._proj_root:
            try:
                proj_block = self._collect_project_context()
                if proj_block:
                    user_msg["project_context_block"] = proj_block
            except Exception as e:
                import logging
                logging.getLogger(__name__).debug(
                    "Project context collection failed: %s", e)

        llm_content = _build_llm_content(user_msg)

        # Update action_env so streaming blocks get correct callbacks/config
        agentic_cfg = self._agentic_cfg()
        if agentic_cfg.get("enabled"):
            self._history._action_env = self._build_action_env()
        else:
            self._history._action_env = None

        # Build full message list for LLM (system prompt + history + new)
        messages = []
        sys_p = self._sp_get_active_prompt()
        if sys_p:
            messages.append({"role": "system", "content": sys_p})

        # Inject agentic system prompt when enabled
        if agentic_cfg.get("enabled"):
            from .agentic_actions import AGENTIC_SYSTEM_PROMPT
            tpl = agentic_cfg.get("prompt_template", "").strip()
            # Fallback to built-in default if template was never saved (old config)
            agentic_sys = tpl if tpl else AGENTIC_SYSTEM_PROMPT
            if messages and messages[0]["role"] == "system":
                messages[0]["content"] += "\n\n" + agentic_sys
            else:
                messages.insert(0, {"role": "system", "content": agentic_sys})
        for m in self._messages:
            if m.get("role") not in ("user", "assistant"):
                continue
            messages.append({"role": m["role"],
                             "content": _build_llm_content(m)})
        messages.append({"role": "user", "content": llm_content})

        attachment_names = [a["name"] for a in user_msg.get("attachments", [])]

        # Update UI — show display_text with command highlights in chat bubble
        self._history.add_user(
            display_text,
            attachments=attachment_names or None,
            command_spans=[
                (c["start"], c["length"])
                for c in active_commands_snapshot
            ] or None,
        )
        self._messages.append(user_msg)
        self._current_lbl = self._history.add_assistant_start()
        self._assistant_buf    = ""
        self._rendered_char_end = 0
        self._streaming_code_edit  = None
        self._streaming_think_edit = None
        self._auto_scroll = True   # re-enable auto-scroll for this new exchange

        worker = _ChatWorker(
            self._api_url(), self._api_key(),
            self._current_model, messages,
            extra_params=self._build_extra_params())
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk_ready.connect(self._on_chunk)
        worker.finished.connect(self._on_done)
        worker.error.connect(self._on_err)
        worker.finished.connect(thread.quit)

        self._chat_worker = worker
        self._chat_thread = thread

        self._send_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._status.setText(f"Generating with {self._current_model}…")
        thread.start()

    def _stop(self):
        if self._chat_worker:
            self._chat_worker.stop()
        self._status.setText("Stopped.")

    @Slot(str)
    def _on_chunk(self, text):
        if not self._assistant_buf:          # first token — hide spinner, show tail bar
            self._history.hide_spinner()
            if self._current_lbl:
                self._current_lbl.show()
        self._assistant_buf += text
        # Skip raw tail-label update when a live code widget is active — the
        # widget owns the display; writing raw code into the label and then
        # immediately clearing it in _try_render_complete_blocks causes flicker.
        if (self._current_lbl
                and self._streaming_code_edit  is None
                and self._streaming_think_edit is None):
            self._current_lbl.setText(
                self._current_lbl.text() + text)
        # On every newline, promote any newly completed blocks to rendered widgets
        if '\n' in text:
            self._try_render_complete_blocks()
        # Scrolling is handled automatically by rangeChanged signal

    def _try_render_complete_blocks(self):
        """Parse _assistant_buf, render complete blocks into the rendered zone,
        and update the tail label with only the current incomplete block text."""
        import re as _re
        from qtpy.QtWidgets import QPlainTextEdit as _PTE
        from qtpy.QtGui import QFont as _QFont

        buf = self._assistant_buf
        buf_lower = buf.lower()

        # ── Finalize live think widget when </think> just arrived ─────────
        # The chunk that delivered </think> is now in buf but the live-think
        # branch below won't run (its guard requires </think> to be absent).
        # Update the widget content to the final stripped value, then fall
        # through to standard promotion so post-think text is handled.
        if self._streaming_think_edit is not None and '</think>' in buf_lower:
            think_start = buf_lower.index('<think>') + len('<think>')
            think_end   = buf_lower.index('</think>')
            self._streaming_think_edit.setPlainText(
                buf[think_start:think_end].strip())
            self._streaming_think_edit = None
            # _rendered_char_end will be corrected by standard promotion below

        # ── Live-update streaming think block ────────────────────────────
        # While <think> is open (no </think> yet), build/update the widget
        # in place on every newline instead of suppressing all rendering.
        elif '<think>' in buf_lower and '</think>' not in buf_lower:
            think_tag_start = buf_lower.index('<think>')
            think_content   = buf[think_tag_start + len('<think>'):]

            # Promote any blocks that appear before <think> (uncommon but
            # possible if the model emits a preamble before its think tag).
            pre_buf = buf[:think_tag_start]
            if pre_buf.strip():
                pre_blocks = parse_blocks(pre_buf)
                new_pre = pre_blocks[self._history._rendered_block_count:]
                for blk in new_pre:
                    self._history.push_rendered_block(blk)

            # Create the widget on the first newline inside <think>
            if self._streaming_think_edit is None:
                cfg = {**EDITOR_DEFAULTS,
                       **(getattr(self._history, "_font_cfg", None) or {})}
                dummy = {"type": "think", "content": think_content}
                w = build_think(dummy, cfg.get("fs_think", 9))
                self._streaming_think_edit = w.findChild(_PTE)
                self._history.push_rendered_widget(w)
            else:
                self._streaming_think_edit.setPlainText(think_content)

            # Auto-scroll to bottom so the latest thinking is always visible
            vsb = self._streaming_think_edit.verticalScrollBar()
            vsb.setValue(vsb.maximum())

            # Whole buffer is accounted for by the widget — blank the tail label
            self._rendered_char_end = len(buf)
            if self._current_lbl is not None:
                self._current_lbl.setText("")
                self._current_lbl.updateGeometry()
            return

        blocks = parse_blocks(buf)
        if not blocks:
            return

        # ── Live-update streaming code block ─────────────────────────────
        # The parser always emits a code block from an opening ``` even without
        # a closing ```, so we can't tell if it's complete from its mere presence.
        # When the LAST parsed block is a code block (regardless of how many
        # preceding blocks there are), we promote all preceding blocks first,
        # then live-update a QPlainTextEdit widget in place on every newline.
        # This works for both code-only messages and text-then-code messages.
        if blocks[-1]["type"] == "code":
            code_block = blocks[-1]

            # Promote any preceding blocks not yet rendered
            preceding = blocks[:-1]
            new_preceding = preceding[self._history._rendered_block_count:]
            if new_preceding:
                for blk in new_preceding:
                    self._history.push_rendered_block(blk)
                self._rendered_char_end = preceding[-1]["_char_end"]
                if self._current_lbl is not None:
                    self._current_lbl.setText(buf[self._rendered_char_end:])
                    self._current_lbl.updateGeometry()

            # Detect closing fence via parser flag (avoids false positives from
            # prior completed code blocks already in the buffer)
            fence_closed = code_block.get("_closed", False)

            cfg = {**EDITOR_DEFAULTS,
                   **(getattr(self._history, "_font_cfg", None) or {})}
            fs_code = cfg.get("fs_code", 10)

            if self._streaming_code_edit is None:
                # Opening ``` seen — create the widget
                w = build_code_block(code_block, self._history.insert_to_editor,
                                     fs_code)
                self._streaming_code_edit = w.findChild(_PTE)
                self._history.push_rendered_widget(w)

            # Update content and height in-place
            code = code_block["content"]
            self._streaming_code_edit.setPlainText(code)
            fm   = self._streaming_code_edit.fontMetrics()
            sb_h = self._streaming_code_edit.horizontalScrollBar().sizeHint().height()
            n_lines = max(code.count("\n") + 1, 1)
            self._streaming_code_edit.setFixedHeight(
                n_lines * fm.lineSpacing() + 24 + sb_h)
            self._streaming_code_edit.updateGeometry()

            # All buffer content is now in the widget — hide the tail label
            self._rendered_char_end = len(buf)
            if self._current_lbl is not None:
                self._current_lbl.setText("")
                self._current_lbl.updateGeometry()

            if fence_closed:
                # Closing ``` received — stop live-updating
                self._streaming_code_edit = None
            return

        # If we were live-updating a code block but now there are more blocks
        # (content appeared after the closing ```), stop tracking the live edit.
        if self._streaming_code_edit is not None:
            self._streaming_code_edit = None

        # ── Standard block promotion ──────────────────────────────────────
        # Think blocks are self-contained: parse_blocks only creates them when
        # </think> has been matched, so a lone think block is definitively complete.
        # All other single-block responses stay in the tail until a second block
        # confirms they are complete.
        if len(blocks) == 1 and blocks[0]["type"] != "think":
            return   # single non-self-closing block — tail may still be incomplete
        # All blocks except the last are complete (something follows them).
        # For a lone think block, treat the whole list as complete.
        complete = blocks[:-1] if len(blocks) >= 2 else blocks
        new_blocks = complete[self._history._rendered_block_count:]
        if not new_blocks:
            return
        for block in new_blocks:
            self._history.push_rendered_block(block)
        # Update char position of rendered content
        self._rendered_char_end = complete[-1]["_char_end"]
        # Trim the tail label to show only the unrendered suffix.
        # updateGeometry() tells the parent layout that the preferred size changed
        # so the label shrinks immediately when a large block (e.g. code) is promoted.
        tail = self._assistant_buf[self._rendered_char_end:]
        if self._current_lbl is not None:
            self._current_lbl.setText(tail)
            self._current_lbl.updateGeometry()

    @Slot()
    def _on_done(self):
        if self._worker_had_error:
            # _on_err already finalized — skip to avoid creating a second empty block
            self._worker_had_error = False
            return
        if self._assistant_buf:
            self._messages.append(
                {"role": "assistant", "content": self._assistant_buf})
        # Replace streaming label with parsed markdown view
        self._history.finalize_assistant(self._assistant_buf)
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._status.setText("Done.")
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl          = None
        self._streaming_code_edit  = None
        self._streaming_think_edit = None
        # Fire multiple deferred scrolls to catch all layout passes.
        # Rendered markdown is often shorter than raw streamed text, so the
        # scroll range shrinks and we must re-anchor to the new bottom.
        self._deferred_scroll_to_bottom()
        self._autosave()

    @Slot(str)
    def _on_err(self, msg):
        self._worker_had_error = True
        if self._assistant_buf:
            # Partial response received before error — finalize what we have
            self._messages.append({"role": "assistant", "content": self._assistant_buf})
            self._history.finalize_assistant(self._assistant_buf)
        else:
            # No content received — show styled error block
            self._messages.append({"role": "assistant_error", "content": msg})
            self._history.show_error(msg)
        self._status.setText(f"⚠ {msg}")
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl = None
        self._deferred_scroll_to_bottom()
        self._autosave()

    def _deferred_scroll_to_bottom(self):
        """Schedule scroll-to-bottom at 0 ms, 100 ms and 300 ms.
        Multiple passes are needed because Qt may take several layout
        rounds to settle after replacing the streaming label with
        rendered markdown (especially when content shrinks in height)."""
        for delay in (0, 100, 300):
            QTimer.singleShot(delay, self._scroll_to_bottom)

    def _on_scroll_range_changed(self, min_, max_):
        """Called whenever the vertical scroll range changes.
        Only auto-scrolls during active streaming; post-stream UI interactions
        (think block show/hide, window resize) must not cause jumps."""
        if self._auto_scroll and max_ > 0 and self._chat_worker is not None:
            self._scroll.verticalScrollBar().setValue(max_)

    def _scroll_to_bottom(self):
        """Scroll to the true bottom of content, even after re-render shrinks height."""
        self._auto_scroll = True
        sb = self._scroll.verticalScrollBar()
        # With setWidgetResizable(True), the widget is stretched to viewport
        # height, so sb.maximum() can be 0 even when content overflows.
        # Use the layout's sizeHint to find the real content height.
        content_h = self._history.layout().sizeHint().height()
        viewport_h = self._scroll.viewport().height()
        true_max = max(0, content_h - viewport_h)
        if true_max > 0:
            sb.setValue(true_max)
        else:
            sb.setValue(sb.maximum())

    # ── system prompt selector ────────────────────────────────────────

    def _sp_populate_combo(self, select_id=None):
        """Reload combo from saved prompts. Preserves current selection."""
        if select_id is None:
            select_id = self._sp_selected_id
        self._sp_combo.blockSignals(True)
        self._sp_combo.clear()
        self._sp_combo.addItem("Use custom", userData=CUSTOM_ID)
        prompts = load_prompts()
        target_idx = 0
        for i, p in enumerate(prompts):
            self._sp_combo.addItem(p["title"], userData=p["id"])
            if p["id"] == select_id:
                target_idx = i + 1
        self._sp_combo.blockSignals(False)
        self._sp_combo.setCurrentIndex(target_idx)
        self._sp_on_select(target_idx)

    def _sp_on_select(self, idx):
        prompt_id = self._sp_combo.currentData()
        self._sp_selected_id = prompt_id
        if prompt_id == CUSTOM_ID:
            # Custom: enable the text field, hide copy button
            self._sys_prompt.setEnabled(True)
            self._sys_prompt.setPlaceholderText("System prompt (optional)")
            self._sp_copy_btn.setVisible(False)
        else:
            # Saved prompt selected: show content read-only, show copy button
            p = get_prompt(prompt_id)
            if p:
                self._sys_prompt.setPlainText(p["content"])
            self._sys_prompt.setEnabled(False)
            self._sp_copy_btn.setVisible(True)

    def _sp_on_copy(self):
        """Copy selected saved prompt into the field for editing, switch to custom."""
        p = get_prompt(self._sp_selected_id)
        if p:
            self._sys_prompt.setPlainText(p["content"])
        # Switch combo to "Use custom" without triggering _sp_on_select clear
        self._sp_combo.blockSignals(True)
        self._sp_combo.setCurrentIndex(0)
        self._sp_combo.blockSignals(False)
        self._sp_selected_id = CUSTOM_ID
        self._sys_prompt.setEnabled(True)
        self._sp_copy_btn.setVisible(False)
        self._sys_prompt.setFocus()

    def _sp_get_active_prompt(self):
        """Return the effective system prompt text for sending."""
        if self._sp_selected_id != CUSTOM_ID:
            p = get_prompt(self._sp_selected_id)
            if p:
                return p["content"]
        return self._sys_prompt.toPlainText().strip()

    def _on_delete_exchange(self, block_idx, delete_before):
        """
        Delete one exchange (user+assistant pair) or all exchanges before it.
        '🗑 This'      → delete this user+assistant pair.
        '⏫ All before' → delete all exchanges before (and including) this one.
        """
        if block_idx < 0 or block_idx >= len(self._messages):
            return

        # Step back to paired user if an assistant block was clicked
        idx = block_idx
        if idx % 2 == 1:
            idx -= 1

        if delete_before:
            del self._messages[: idx + 2]
        else:
            del self._messages[idx: idx + 2]

        # Rebuild UI
        self._history.clear_all()
        for msg in self._messages:
            role_   = msg.get("role", "")
            content = msg.get("content", "")
            if role_ == "user":
                attachments = msg.get("attachments", [])
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
            elif role_ == "assistant":
                self._history.finalize_assistant(content)
            elif role_ == "assistant_error":
                self._history.show_error(content)

        self._autosave()
        self._deferred_scroll_to_bottom()
        self._status.setText("Exchange deleted.")

    def _on_regenerate(self):
        """Remove the last assistant reply and re-send the last user message."""
        if self._chat_thread is not None and self._chat_thread.isRunning():
            return
        # Need at least one user + one assistant message
        if len(self._messages) < 2:
            return
        if self._messages[-1].get("role") not in ("assistant", "assistant_error"):
            return

        # Drop the last assistant reply (or error) from the stored messages
        self._messages.pop()

        # Rebuild UI without the last assistant block
        self._history.clear_all()
        for msg in self._messages:
            role_   = msg.get("role", "")
            content = msg.get("content", "")
            if role_ == "user":
                attachments = msg.get("attachments", [])
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
            elif role_ == "assistant":
                self._history.finalize_assistant(content)
            elif role_ == "assistant_error":
                self._history.show_error(content)

        # Build LLM messages from current history (last entry is the user message)
        messages = []
        sys_p = self._sp_get_active_prompt()
        if sys_p:
            messages.append({"role": "system", "content": sys_p})

        # Inject agentic system prompt and set action_env — same as _send()
        agentic_cfg = self._agentic_cfg()
        if agentic_cfg.get("enabled"):
            self._history._action_env = self._build_action_env()
            from .agentic_actions import AGENTIC_SYSTEM_PROMPT
            tpl = agentic_cfg.get("prompt_template", "").strip()
            agentic_sys = tpl if tpl else AGENTIC_SYSTEM_PROMPT
            if messages and messages[0]["role"] == "system":
                messages[0]["content"] += "\n\n" + agentic_sys
            else:
                messages.insert(0, {"role": "system", "content": agentic_sys})
        else:
            self._history._action_env = None

        for m in self._messages:
            if m.get("role") not in ("user", "assistant"):
                continue
            messages.append({"role": m["role"],
                             "content": _build_llm_content(m)})

        # Add streaming placeholder for the new response
        self._current_lbl = self._history.add_assistant_start()
        self._assistant_buf    = ""
        self._rendered_char_end = 0
        self._streaming_code_edit  = None
        self._streaming_think_edit = None
        self._auto_scroll = True

        worker = _ChatWorker(
            self._api_url(), self._api_key(),
            self._current_model, messages,
            extra_params=self._build_extra_params())
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk_ready.connect(self._on_chunk)
        worker.finished.connect(self._on_done)
        worker.error.connect(self._on_err)
        worker.finished.connect(thread.quit)

        self._chat_worker = worker
        self._chat_thread = thread
        self._send_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._status.setText(f"Regenerating with {self._current_model}…")
        thread.start()

    # ── inference parameters ──────────────────────────────────────────

    def _build_extra_params(self) -> dict:
        """
        Build the dict of inference params to send to the API.
        Filters to only params supported by the current provider,
        and renames max_tokens → max_completion_tokens for Groq.
        Returns empty dict if no params are set.
        """
        if not self._infer_params:
            return {}
        state = self._load_state()
        pid   = state.get("provider_type", "custom")
        pdef  = PROVIDERS.get(pid, PROVIDERS["custom"])
        supported = set(pdef["supported_params"])
        result = {k: v for k, v in self._infer_params.items() if k in supported}
        # Groq uses max_completion_tokens, not max_tokens
        if pid == "groq" and "max_tokens" in result:
            result["max_completion_tokens"] = result.pop("max_tokens")
        return result

    def _update_summary_bar(self):
        """Update the params summary label. Bar is always visible."""
        if not self._infer_params:
            self._params_bar_lbl.setText("Click to set inference params")
            self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_IDLE_STYLE)
            return
        # Build compact summary text
        parts = []
        label_map = {
            "temperature": "temp", "max_tokens": "max", "top_p": "top_p",
            "top_k": "top_k", "min_p": "min_p",
            "presence_penalty": "pres", "frequency_penalty": "freq",
            "repetition_penalty": "rep", "seed": "seed", "num_ctx": "ctx",
        }
        for k, v in self._infer_params.items():
            short = label_map.get(k, k)
            if isinstance(v, float):
                parts.append(f"{short}: {v:.2f}")
            else:
                parts.append(f"{short}: {v}")
        self._params_bar_lbl.setText("⚙ " + " · ".join(parts))
        self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_ACTIVE_STYLE)

    def _toggle_params_popup(self):
        """Open or close the inference params popup anchored above the ⚙ button."""
        if self._params_popup is None:
            try:
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._params_popup = _InferParamsPopup(main_win)

        if self._params_popup.isVisible():
            self._params_popup.hide()
        else:
            self._params_popup.show_above(self._params_bar_lbl, self)

    def _on_provider_changed(self, new_provider_id: str):
        """
        Called when the user switches provider in Settings.
        Resets per-chat inference params and updates chat_provider.
        """
        self._infer_params  = {}
        self._chat_provider = new_provider_id
        self._update_summary_bar()
        # Close popup if open so it rebuilds with new provider next time
        if self._params_popup and self._params_popup.isVisible():
            self._params_popup.hide()
        self._status.setText(
            f"Provider changed to {PROVIDERS.get(new_provider_id, {}).get('label', new_provider_id)}"
            f" — inference parameters reset.")

    def _autosave(self):
        """Save current chat to disk after each exchange (if enabled)."""
        if self._messages and self._history_cfg().get("autosave", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                collection=self._current_collection,
                provider=self._chat_provider,
                infer_params=self._infer_params,
                project_context=self._proj_ctx_for_save(),
            )
            if self._current_chat_file:
                self._save_state(
                    last_chat_file=_encode_chat_ref(
                        self._current_collection, self._current_chat_file)
                )


# ---------------------------------------------------------------------------
# PluginMainWidget — proper Spyder 6 integration
# Spyder calls setup() to build content inside its managed central area.
# get_main_layout() returns the QVBoxLayout of the central content widget,
# which sits BELOW the toolbars and title bar — so toolbars stay intact.
# ---------------------------------------------------------------------------
from spyder.api.widgets.main_widget import PluginMainWidget

class AIChatWidget(PluginMainWidget):

    DEFAULT_OPTIONS = {}

    def get_title(self):
        return "AI Chat"

    def setup(self, options=None):
        self._panel = AIChatPanel(
            get_conf=lambda k, d="": d,
            set_conf=lambda k, v: None,
            get_editor_cursor=lambda: (None, "not set yet"),
            parent=self,
        )
        # set_content_widget() is the correct Spyder 6 API —
        # places our panel in the central area below the toolbars
        self.set_content_widget(self._panel)

    def set_editor_cursor_fn(self, fn):
        """Called by plugin.py after Spyder wires up the editor plugin."""
        if hasattr(self, '_panel'):
            self._panel._get_editor_cursor = fn

    def set_project_fns(self, get_project_root_fn, get_editor_widget_fn):
        """Called by plugin.py to wire up project/editor widget access."""
        if hasattr(self, '_panel'):
            self._panel.set_project_fns(get_project_root_fn, get_editor_widget_fn)

    def is_project_context_enabled(self):
        """Return True when the current chat has project context active."""
        return bool(getattr(getattr(self, '_panel', None), '_proj_enabled', False))

    def set_console_execute_fn(self, fn):
        """Called by plugin.py to provide IPython console execute function."""
        if hasattr(self, '_panel'):
            self._panel.set_console_execute_fn(fn)

    def set_load_file_fn(self, fn):
        """Called by plugin.py to provide editor load-file function."""
        if hasattr(self, '_panel'):
            self._panel.set_load_file_fn(fn)

    def set_reload_file_fn(self, fn):
        """Called by plugin.py to provide editor reload-file function (patch)."""
        if hasattr(self, '_panel'):
            self._panel.set_reload_file_fn(fn)

    def on_project_loaded(self, path):
        if hasattr(self, '_panel'):
            self._panel.on_project_loaded(path)

    def on_project_closed(self):
        if hasattr(self, '_panel'):
            self._panel.on_project_closed()

    def add_file_context(self, path):
        """Called by plugin.py when user picks 'Add to AI Chat context'."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context(path)

    def add_file_context_content(self, name, content, source="file"):
        """Called by plugin.py with already-read content (supports unsaved files)."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context_content(name, content, source)

    def next_selection_id(self, filename):
        """Return next selection counter for this filename."""
        if hasattr(self, '_panel'):
            return self._panel.next_selection_id(filename)
        return 1

    def update_actions(self):
        pass
