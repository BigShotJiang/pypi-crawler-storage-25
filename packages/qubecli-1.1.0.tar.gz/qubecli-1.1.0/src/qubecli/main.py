import json
from contextlib import contextmanager
from importlib.metadata import version
from pathlib import Path
from typing import Annotated, Generator

import grpc
import typer
from qubecore_client import (
    AmpRabiParams,
    BlobReadoutFreqParams,
    ChevronParams,
    DragAlphaParams,
    GateFidelityParams,
    QubeClient,
    RamseyParams,
    ReadoutFidelityParams,
    StackX90Params,
    T1Params,
    TimeRabiParams,
    is_token_expired,
    login,
    logout,
    refresh_token,
)

_CONFIG_PATH = Path.home() / ".qubecli" / "config.json"

app = typer.Typer(help="QubeCore CLI — Quantum Computing Operating System", invoke_without_command=True)
calibration_app = typer.Typer(help="Calibration commands")
app.add_typer(calibration_app, name="calibration")


def _load_config() -> dict:
    try:
        return json.loads(_CONFIG_PATH.read_text())
    except FileNotFoundError:
        return {}
    except (json.JSONDecodeError, OSError) as e:
        typer.echo(f"Warning: failed to read config ({e}), using defaults.", err=True)
        return {}


def _save_config(data: dict) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(data, indent=2))
    _CONFIG_PATH.chmod(0o600)


def _get_address() -> str:
    address = _load_config().get("host")
    if not address:
        typer.echo("No server connected. Run 'qubecli connect <host[:port]>' first.", err=True)
        raise typer.Exit(1)
    return address


def _load_token() -> str:
    cfg = _load_config()
    access_token: str = cfg.get("access_token", "")
    stored_refresh: str = cfg.get("refresh_token", "")

    if not access_token and not stored_refresh:
        typer.echo("Not logged in. Run 'qubecli login' first.", err=True)
        raise typer.Exit(1)

    if is_token_expired(access_token):
        if not stored_refresh:
            typer.echo("Session expired. Run 'qubecli login' again.", err=True)
            raise typer.Exit(1)
        try:
            address = _get_address()
            access_token, stored_refresh = refresh_token(address, stored_refresh)
            cfg["access_token"] = access_token
            cfg["refresh_token"] = stored_refresh
            _save_config(cfg)
        except RuntimeError:
            typer.echo("Session expired. Run 'qubecli login' again.", err=True)
            raise typer.Exit(1)

    return access_token


def _report_grpc_error(e: grpc.RpcError, address: str) -> None:
    """Print a user-friendly message for an RPC failure, then signal exit-after-return."""
    code = e.code()
    if code == grpc.StatusCode.UNAVAILABLE:
        typer.echo(f"Cannot connect to server: {address}", err=True)
        typer.echo("  Check that the server is running.", err=True)
    elif code == grpc.StatusCode.UNAUTHENTICATED:
        typer.echo("Authentication failed. Run 'qubecli login' again.", err=True)
    elif code == grpc.StatusCode.PERMISSION_DENIED:
        typer.echo(f"Permission denied: {e.details()}", err=True)
    else:
        typer.echo(f"gRPC error: {e.details()}", err=True)


@contextmanager
def _get_client(address: str, require_auth: bool = True) -> Generator[QubeClient, None, None]:
    token = _load_token() if require_auth else None
    client = QubeClient(address=address, token=token)
    try:
        yield client
    except grpc.RpcError as e:
        _report_grpc_error(e, address)
        raise typer.Exit(1)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    finally:
        client.close()


def _priority_label(priority: int) -> str:
    return {1: "CRITICAL", 2: "HIGH", 3: "NORMAL", 4: "LOW"}.get(priority, str(priority))


def _validate_priority(priority: int | None) -> None:
    if priority is not None and priority not in (1, 2, 3, 4):
        typer.echo("priority must be between 1 and 4.", err=True)
        raise typer.Exit(1)


def _validate_optimization_level(optimization_level: int | None) -> None:
    if optimization_level is not None and optimization_level not in (0, 1, 2, 3):
        typer.echo("optimization-level must be between 0 and 3.", err=True)
        raise typer.Exit(1)


def _is_qir(circuit: str) -> bool:
    return "; ModuleID" in circuit or "__quantum__" in circuit


def _warn_if_optimization_level_ignored(circuit: str, optimization_level: int | None) -> None:
    if optimization_level is not None and _is_qir(circuit):
        typer.echo("Warning: --optimization-level is ignored for QIR input.", err=True)


def _print_calibration_submitted(job_id: str, calibration_type: str, priority: int | None) -> None:
    typer.echo("✓ Job submitted")
    typer.echo(f"  job_id           : {job_id}")
    typer.echo(f"  calibration_type : {calibration_type}")
    typer.echo(f"  priority         : {_priority_label(priority if priority is not None else 3)}")


def _parse_json_list(value: str, field_name: str) -> list:
    """Parse a JSON-encoded list from a CLI string option, exiting with a friendly error on failure."""
    try:
        result = json.loads(value)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse {field_name}: {e}", err=True)
        raise typer.Exit(1)
    if not isinstance(result, list):
        typer.echo(f"{field_name} must be a JSON array.", err=True)
        raise typer.Exit(1)
    return result


def _submit_calibration(client_method_name: str, calibration_type: str, params: dict, priority: int | None) -> None:
    """Shared submit flow for all calibration commands."""
    _validate_priority(priority)
    address = _get_address()
    with _get_client(address) as client:
        method = getattr(client, client_method_name)
        job_id = method(params=params, priority=priority)
    _print_calibration_submitted(job_id, calibration_type, priority)


def _normalize_stream_params(params_list: list[dict]) -> list[dict[str, float]]:
    """StreamGateJobRequest.params is map<string,double> — coerce numbers, reject invalid types."""
    out: list[dict[str, float]] = []
    for i, p in enumerate(params_list):
        norm: dict[str, float] = {}
        for k, v in p.items():
            if not isinstance(k, str):
                typer.echo(f"params[{i}] keys must be strings (got {type(k).__name__}).", err=True)
                raise typer.Exit(1)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                typer.echo(
                    f"params[{i}][{k!r}] must be a JSON number "
                    "(StreamGateJob uses map<string,double>; bool/string/object/array are not allowed).",
                    err=True,
                )
                raise typer.Exit(1)
            norm[k] = float(v)
        out.append(norm)
    return out


_ASCII = r"""
   ___  _   _ ____  _____ ____ ___  ____  _____
  / _ \| | | | __ )| ____/ ___/ _ \|  _ \| ____|
 | | | | | | |  _ \|  _|| |  | | | | |_) |  _|
 | |_| | |_| | |_) | |__| |__| |_| |  _ <| |___
  \__\_\\___/|____/|_____\____\___/|_| \_\_____|
"""

_W = 59


def _c(s: str, fg: str, bold: bool = False) -> str:
    return typer.style(s, fg=fg, bold=bold)


def _print_banner() -> None:
    ver = version("qubecli")

    border_top    = _c("┌" + "─" * (_W - 2) + "┐", typer.colors.BRIGHT_BLACK)
    border_bottom = _c("└" + "─" * (_W - 2) + "┘", typer.colors.BRIGHT_BLACK)
    border_sep    = _c("├" + "─" * (_W - 2) + "┤", typer.colors.BRIGHT_BLACK)
    empty         = _c("│" + " " * (_W - 2) + "│", typer.colors.BRIGHT_BLACK)
    pipe          = _c("│", typer.colors.BRIGHT_BLACK)

    typer.echo(border_top)
    typer.echo(empty)
    for art_line in _ASCII.strip("\n").splitlines():
        padding = (_W - 2 - len(art_line)) // 2
        right   = _W - 2 - padding - len(art_line)
        typer.echo(pipe + " " * padding + _c(art_line, typer.colors.CYAN, bold=True) + " " * right + pipe)
    typer.echo(empty)
    tagline = "Quantum Computing Operating System"
    tpad    = (_W - 2 - len(tagline)) // 2
    typer.echo(pipe + " " * tpad + _c(tagline, typer.colors.WHITE, bold=True) + " " * (_W - 2 - tpad - len(tagline)) + pipe)
    company = "by SDT"
    cpad    = (_W - 2 - len(company)) // 2
    typer.echo(pipe + " " * cpad + _c(company, typer.colors.BRIGHT_BLACK) + " " * (_W - 2 - cpad - len(company)) + pipe)
    typer.echo(empty)
    typer.echo(border_sep)
    info = "  " + _c("version", typer.colors.GREEN) + f"  {ver}"
    info_len = 2 + 7 + 2 + len(ver)
    typer.echo(pipe + info + " " * (_W - 2 - info_len) + pipe)
    hint = "  Run 'qubecli help' to see all available commands"
    typer.echo(pipe + _c(hint + " " * (_W - 2 - len(hint)), typer.colors.BRIGHT_BLACK) + pipe)
    typer.echo(border_bottom)
    typer.echo("")


@app.callback()
def _callback(
    ctx: typer.Context,
    ver: Annotated[bool, typer.Option("-v", "--version", help="Print version", is_eager=True)] = False,
) -> None:
    if ver:
        typer.echo(f"v{version('qubecli')}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        _print_banner()


@app.command("connect")
def connect_cmd(
    host: Annotated[str, typer.Argument(help="Server address (host or host:port)")],
) -> None:
    """Connect to a QubeCore server and save the address"""
    if ":" in host:
        parts = host.split(":", 1)
        if not parts[1].isdigit():
            typer.echo("Invalid format. Use host or host:port (e.g. localhost:50051)", err=True)
            raise typer.Exit(1)

    channel = grpc.insecure_channel(host)
    try:
        grpc.channel_ready_future(channel).result(timeout=5)
    except grpc.FutureTimeoutError:
        typer.echo(f"✗ Cannot connect to {host}", err=True)
        raise typer.Exit(1)
    finally:
        channel.close()

    cfg = _load_config()
    cfg["host"] = host
    _save_config(cfg)
    typer.echo(f"✓ Connected to {host}")


@app.command("login")
def login_cmd(
    username: Annotated[str | None, typer.Option(help="Username")] = None,
    password: Annotated[str | None, typer.Option(help="Password")] = None,
) -> None:
    """Log in to QubeCore and save credentials"""
    address = _get_address()

    cfg = _load_config()
    access_token = cfg.get("access_token", "")
    refresh_tok = cfg.get("refresh_token", "")
    if (access_token or refresh_tok) and not is_token_expired(access_token):
        typer.echo("Already logged in. Run 'qubecli logout' first.", err=True)
        raise typer.Exit(1)

    if username is None:
        username = typer.prompt("Username")
    if password is None:
        password = typer.prompt("Password", hide_input=True)

    try:
        access_token, refresh_tok = login(address, username, password)
    except RuntimeError as e:
        typer.echo(f"Login failed: {e}", err=True)
        raise typer.Exit(1)
    except grpc.RpcError as e:
        _report_grpc_error(e, address)
        raise typer.Exit(1)

    cfg["access_token"] = access_token
    cfg["refresh_token"] = refresh_tok
    _save_config(cfg)
    typer.echo(f"✓ Logged in as {username}")


@app.command("logout")
def logout_cmd() -> None:
    """Log out and remove saved credentials"""
    address = _get_address()

    cfg = _load_config()
    if not cfg.get("access_token") and not cfg.get("refresh_token"):
        typer.echo("Not logged in.", err=True)
        raise typer.Exit(1)
    access_token = cfg.get("access_token", "")
    if access_token:
        try:
            logout(address, access_token)
        except grpc.RpcError:
            typer.echo("Warning: server logout failed (credentials cleared locally).", err=True)
    cfg.pop("access_token", None)
    cfg.pop("refresh_token", None)
    _save_config(cfg)
    typer.echo("✓ Logged out")


@app.command()
def me() -> None:
    """Show current user info"""
    address = _get_address()
    with _get_client(address) as client:
        info = client.get_me()

    typer.echo(f"  user_id    : {info['user_id']}")
    typer.echo(f"  username   : {info['username']}")
    typer.echo(f"  role       : {info['role']}")
    typer.echo(f"  created_at : {info['created_at']}")


@app.command()
def jobs(
    page: Annotated[int, typer.Option(help="Page number (1-based)")] = 1,
    size: Annotated[int, typer.Option(help="Results per page")] = 20,
) -> None:
    """List my jobs"""
    if page < 1:
        typer.echo("Error: page must be >= 1", err=True)
        raise typer.Exit(1)
    if size < 1 or size > 200:
        typer.echo("Error: size must be between 1 and 200", err=True)
        raise typer.Exit(1)
    address = _get_address()
    with _get_client(address) as client:
        result = client.get_my_jobs(page=page, page_size=size)

    total = result["total"]
    job_list = result["jobs"]
    typer.echo(f"  total : {total}  (page {page}, size {size})")
    if not job_list:
        typer.echo("  (no jobs)")
        return
    for j in job_list:
        finished = j["finished_at"] or "(running)"
        typer.echo(
            f"  {j['job_id']}  {j['type']:<22}  {j['status']:<10}"
            f"  {_priority_label(j['priority']):<8}  {j['submitted_at']}  {finished}"
        )


@app.command("submit-gate")
def submit(
    circuit: Annotated[str | None, typer.Option(help="Circuit string — OpenQASM 2.0 / 3.0 / QIR / JSON (server auto-detects format from prefix)")] = None,
    circuit_file: Annotated[str | None, typer.Option(help="Path to circuit file (alternative to --circuit; useful for multi-line QIR)")] = None,
    shots: Annotated[int, typer.Option(help="Number of shots")] = ...,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
    optimization_level: Annotated[int | None, typer.Option(help="Transpile optimization level 0–3 (ignored for QIR input)")] = None,
) -> None:
    """Submit a gate-circuit execution job"""
    if circuit is None and circuit_file is None:
        typer.echo("Error: provide --circuit or --circuit-file.", err=True)
        raise typer.Exit(1)
    if circuit is not None and circuit_file is not None:
        typer.echo("Error: --circuit and --circuit-file are mutually exclusive.", err=True)
        raise typer.Exit(1)
    if circuit_file is not None:
        try:
            circuit = Path(circuit_file).read_text()
        except OSError as e:
            typer.echo(f"Error reading circuit file: {e}", err=True)
            raise typer.Exit(1)
    circuit = circuit.replace("\\n", "\n").replace("\\t", "\t")  # type: ignore[union-attr]
    if not circuit.strip():
        typer.echo("Error: circuit must not be empty.", err=True)
        raise typer.Exit(1)
    _validate_priority(priority)
    _validate_optimization_level(optimization_level)
    _warn_if_optimization_level_ignored(circuit, optimization_level)
    address = _get_address()
    with _get_client(address) as client:
        job_id = client.submit_gate_job(
            gate_circuits=[circuit],
            shots=shots,
            priority=priority,
            optimization_level=optimization_level,
        )

    typer.echo("✓ Job submitted")
    typer.echo(f"  job_id   : {job_id}")
    typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@app.command("submit-pulse")
def submit_pulse(
    pulse: Annotated[str, typer.Option(help="Pulse program string (backend-specific JSON)")],
    shots: Annotated[int, typer.Option(help="Number of shots")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a pulse-program execution job"""
    _validate_priority(priority)
    address = _get_address()
    with _get_client(address) as client:
        job_id = client.submit_pulse_job(
            pulse_circuits=[pulse],
            shots=shots,
            priority=priority,
        )

    typer.echo("✓ Job submitted")
    typer.echo(f"  job_id   : {job_id}")
    typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@app.command("reset")
def submit_reset(
    qubits: Annotated[str, typer.Option(help="Comma-separated qubit names (e.g. qubit_0,qubit_1)")],
    shots: Annotated[int, typer.Option(help="Number of verification shots after reset")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a qubit active-reset job"""
    _validate_priority(priority)
    qubit_list = [q.strip() for q in qubits.split(",") if q.strip()]
    if not qubit_list:
        typer.echo("qubits must include at least one non-empty qubit name.", err=True)
        raise typer.Exit(1)
    address = _get_address()
    with _get_client(address) as client:
        job_id = client.submit_reset_job(
            qubits=qubit_list,
            shots=shots,
            priority=priority,
        )

    typer.echo("✓ Job submitted")
    typer.echo(f"  job_id   : {job_id}")
    typer.echo(f"  qubits   : {qubit_list}")
    typer.echo(f"  priority : {_priority_label(priority if priority is not None else 3)}")


@calibration_app.command("widescan")
def submit_widescan(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    freq_span: Annotated[float, typer.Option(help="Frequency scan range in Hz")],
    n_freqs: Annotated[int, typer.Option(help="Number of scan points")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a widescan calibration job"""
    _submit_calibration(
        "submit_widescan_job", "widescan",
        {"qubit": qubit, "freq_span": freq_span, "n_freqs": n_freqs, "shots": shots},
        priority,
    )


@calibration_app.command("chevron")
def submit_chevron(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    freq_span: Annotated[float, typer.Option(help="Frequency span in Hz")],
    n_freqs: Annotated[int, typer.Option(help="Number of frequency points")],
    x_twidth: Annotated[str, typer.Option(help="X pulse twidths as JSON array (e.g. [1e-8,2e-8,3e-8])")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    center_freq: Annotated[float | None, typer.Option(help="Center frequency in Hz")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a chevron calibration job"""
    params: ChevronParams = {
        "qubit": qubit, "freq_span": freq_span, "n_freqs": n_freqs,
        "x_twidth": _parse_json_list(x_twidth, "x-twidth"), "shots": shots,
    }
    if center_freq is not None:
        params["center_freq"] = center_freq
    _submit_calibration("submit_chevron_job", "chevron", params, priority)


@calibration_app.command("amp-rabi")
def submit_amp_rabi(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    n_amps: Annotated[int, typer.Option(help="Number of amplitude partitions")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    target_twidth: Annotated[float | None, typer.Option(help="Target pulse width in seconds (default: current X90 twidth from qchip)")] = None,
    amp_range_min: Annotated[float, typer.Option(help="Amplitude range min")] = 0.0,
    amp_range_max: Annotated[float, typer.Option(help="Amplitude range max")] = 1.0,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit an amplitude Rabi calibration job"""
    params: AmpRabiParams = {
        "qubit": qubit, "n_amps": n_amps, "shots": shots,
        "amp_range_min": amp_range_min, "amp_range_max": amp_range_max,
    }
    if target_twidth is not None:
        params["target_twidth"] = target_twidth
    _submit_calibration("submit_amp_rabi_job", "amp_rabi", params, priority)


@calibration_app.command("time-rabi")
def submit_time_rabi(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    x_twidth: Annotated[str | None, typer.Option(help="X pulse twidths as JSON array (e.g. [1e-8,2e-8,3e-8]); default: auto from qchip")] = None,
    target_amplitude: Annotated[float | None, typer.Option(help="Target amplitude (default: current X90 amp from qchip)")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a time Rabi calibration job"""
    params: TimeRabiParams = {"qubit": qubit, "shots": shots}
    if x_twidth is not None:
        params["x_twidth"] = _parse_json_list(x_twidth, "x-twidth")
    if target_amplitude is not None:
        params["target_amplitude"] = target_amplitude
    _submit_calibration("submit_time_rabi_job", "time_rabi", params, priority)


@calibration_app.command("ramsey")
def submit_ramsey(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    delay_interval: Annotated[str, typer.Option(help="Delay intervals as JSON array (e.g. [1e-6,2e-6,3e-6])")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    framsey_offsets: Annotated[str | None, typer.Option(help="Framsey offsets as JSON array")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a Ramsey calibration job"""
    params: RamseyParams = {
        "qubit": qubit,
        "delay_interval": _parse_json_list(delay_interval, "delay-interval"),
        "shots": shots,
    }
    if framsey_offsets is not None:
        params["framsey_offsets"] = _parse_json_list(framsey_offsets, "framsey-offsets")
    _submit_calibration("submit_ramsey_job", "ramsey", params, priority)


@calibration_app.command("t1")
def submit_t1(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    delay_interval: Annotated[str, typer.Option(help="Delay intervals as JSON array (e.g. [1e-6,2e-6,3e-6])")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a T1 calibration job"""
    params: T1Params = {
        "qubit": qubit,
        "delay_interval": _parse_json_list(delay_interval, "delay-interval"),
        "shots": shots,
    }
    _submit_calibration("submit_t1_job", "t1", params, priority)


@calibration_app.command("stack-x90")
def submit_stack_x90(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a stack X90 calibration job"""
    params: StackX90Params = {"qubit": qubit, "shots": shots}
    _submit_calibration("submit_stack_x90_job", "stack_x90", params, priority)


@calibration_app.command("drag-alpha")
def submit_drag_alpha(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    alphas: Annotated[str | None, typer.Option(help="Alpha values as JSON array (e.g. [-0.5,-0.3,0.0,0.3,0.5])")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a DRAG alpha calibration job"""
    params: DragAlphaParams = {"qubit": qubit, "shots": shots}
    if alphas is not None:
        params["alphas"] = _parse_json_list(alphas, "alphas")
    _submit_calibration("submit_drag_alpha_job", "drag_alpha", params, priority)


@calibration_app.command("blob-readout-freq")
def submit_blob_readout_freq(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    dfreads: Annotated[str | None, typer.Option(help="Readout frequency offsets as JSON array (e.g. [-1e6,0,1e6])")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a blob readout frequency calibration job"""
    params: BlobReadoutFreqParams = {"qubit": qubit, "shots": shots}
    if dfreads is not None:
        params["dfreads"] = _parse_json_list(dfreads, "dfreads")
    _submit_calibration("submit_blob_readout_freq_job", "blob_readout_freq", params, priority)


@calibration_app.command("readout-fidelity")
def submit_readout_fidelity(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per circuit")] = 1000,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a readout fidelity calibration job (|0⟩/|1⟩ assignment fidelity)"""
    _submit_calibration("submit_readout_fidelity_job", "readout_fidelity", {"qubit": qubit, "shots": shots}, priority)


@calibration_app.command("gate-fidelity")
def submit_gate_fidelity(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    shots: Annotated[int, typer.Option(help="Shots per circuit")] = 100,
    lengths: Annotated[str | None, typer.Option(help="RB sequence lengths as JSON array (e.g. [1,2,4,8,16,32])")] = None,
    n_seeds: Annotated[int | None, typer.Option(help="Number of random seeds per length")] = None,
    seed_base: Annotated[int | None, typer.Option(help="Base seed for reproducibility")] = None,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a gate fidelity calibration job (1Q Clifford Randomized Benchmarking)"""
    params: dict = {"qubit": qubit, "shots": shots}
    if lengths is not None:
        params["lengths"] = _parse_json_list(lengths, "lengths")
    if n_seeds is not None:
        params["n_seeds"] = n_seeds
    if seed_base is not None:
        params["seed_base"] = seed_base
    _submit_calibration("submit_gate_fidelity_job", "gate_fidelity", params, priority)


@calibration_app.command("punchout")
def submit_punchout(
    qubit: Annotated[str, typer.Option(help="Qubit name (e.g. qubit_0)")],
    amps: Annotated[str, typer.Option(help="Amplitudes as JSON array (e.g. [0.01,0.05,0.1])")],
    freq_span: Annotated[float, typer.Option(help="Frequency scan range in Hz")],
    n_freqs: Annotated[int, typer.Option(help="Number of frequency points")],
    shots: Annotated[int, typer.Option(help="Shots per point")],
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
) -> None:
    """Submit a punchout calibration job"""
    _submit_calibration(
        "submit_punchout_job", "punchout",
        {
            "qubit": qubit, "freq_span": freq_span, "n_freqs": n_freqs,
            "amps": _parse_json_list(amps, "amps"), "shots": shots,
        },
        priority,
    )


@app.command()
def status(
    job_id: Annotated[str, typer.Option(help="Job ID")],
) -> None:
    """Show job status"""
    address = _get_address()
    with _get_client(address) as client:
        try:
            job = client.get_job_status(job_id)
        except ValueError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1)

    typer.echo(f"  job_id    : {job['job_id']}")
    typer.echo(f"  status    : {job['status']}")
    typer.echo(f"  priority  : {_priority_label(job['priority'])}")
    typer.echo(f"  submitted : {job['submitted_at']}")
    typer.echo(f"  started   : {job['started_at'] or '(not started)'}")
    typer.echo(f"  finished  : {job['finished_at'] or '(not finished)'}")
    if job["error"]:
        typer.echo(f"  error     : {job['error']}")


@app.command()
def result(
    job_id: Annotated[str, typer.Option(help="Job ID")],
) -> None:
    """Show job result"""
    address = _get_address()
    try:
        with _get_client(address) as client:
            job = client.get_job_result(job_id)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    typer.echo(f"  job_id : {job['job_id']}")
    typer.echo(f"  status : {job['status']}")
    if "calibration_result" in job:
        typer.echo(f"  calibration_result : {json.dumps(job['calibration_result'], indent=2)}")
    else:
        for i, r in enumerate(job.get("results", [])):
            typer.echo(f"  [circuit {i}] counts        : {r['counts']}")
            if r.get("s11"):
                typer.echo(f"  [circuit {i}] s11           : {r['s11']}")
            if r.get("qubit_mapping"):
                typer.echo(f"  [circuit {i}] qubit_mapping : {r['qubit_mapping']}")


@app.command()
def cancel(
    job_id: Annotated[str, typer.Option(help="Job ID")],
) -> None:
    """Cancel a job (only possible while status is PENDING)"""
    address = _get_address()
    with _get_client(address) as client:
        message = client.cancel_job(job_id)

    typer.echo(f"✓ {message}")


@app.command("qpu-info")
def backend_info() -> None:
    """Show QPU info (name, qubits, coupling map, gates)"""
    address = _get_address()
    with _get_client(address) as client:
        info = client.get_backend_info()

    typer.echo(f"  name                 : {info['name']}")
    typer.echo(f"  num_qubits           : {info['num_qubits']}")
    typer.echo(f"  native_gates         : {info['native_gates']}")
    typer.echo(f"  qasm_supported_gates : {info['qasm_supported_gates']}")
    typer.echo(f"  coupling_map         : {[[p['qubit_a'], p['qubit_b']] for p in info['coupling_map']]}")


@app.command("characterization")
def characterization() -> None:
    """Show qubit characterization (T1, T2, frequency)"""
    address = _get_address()
    with _get_client(address) as client:
        data = client.get_characterization()

    typer.echo(f"  last_calibrated : {data['last_calibrated']}")
    typer.echo(f"  {'index':<6} {'t1':<12} {'t2':<12} {'frequency'}")
    typer.echo(f"  {'─'*6} {'─'*12} {'─'*12} {'─'*12}")
    for q in data["qubits"]:
        typer.echo(f"  {q['index']:<6} {q['t1']:<12.2e} {q['t2']:<12.2e} {q['frequency']:.4e}")


@app.command("update-characterization")
def update_characterization(
    qubits: Annotated[str | None, typer.Option(help="Comma-separated qubit names to measure (e.g. qubit_0,qubit_1). Omit for all qubits.")] = None,
) -> None:
    """Measure and update qubit characterization (T1, T2, readout/gate fidelity). Admin only."""
    qubit_list: list[str] | None = None
    if qubits:
        qubit_list = [q.strip() for q in qubits.split(",") if q.strip()]
    address = _get_address()
    with _get_client(address) as client:
        message = client.update_characterization(qubits=qubit_list)

    typer.echo(f"✓ {message}")



@app.command()
def stream(
    template: Annotated[str | None, typer.Option(help="Gate-circuit template with {param} placeholders — OpenQASM 2.0 / 3.0 / QIR / JSON (server auto-detects format)")] = None,
    template_file: Annotated[str | None, typer.Option(help="Path to circuit template file (alternative to --template; useful for multi-line QIR)")] = None,
    params: Annotated[str, typer.Option(help='JSON array of parameter dicts, e.g. \'[{"theta": 0.0}, {"theta": 1.57}]\'')] = ...,
    shots: Annotated[int, typer.Option(help="Number of shots per iteration")] = ...,
    priority: Annotated[int | None, typer.Option(help="Priority 1–4 (default: 3=NORMAL)")] = None,
    optimization_level: Annotated[int | None, typer.Option(help="Transpile optimization level 0–3 (ignored for QIR input)")] = None,
) -> None:
    """Stream gate-circuit jobs with a parameter sweep (bidirectional streaming)"""
    if template is None and template_file is None:
        typer.echo("Error: provide --template or --template-file.", err=True)
        raise typer.Exit(1)
    if template is not None and template_file is not None:
        typer.echo("Error: --template and --template-file are mutually exclusive.", err=True)
        raise typer.Exit(1)
    if template_file is not None:
        try:
            template = Path(template_file).read_text()
        except OSError as e:
            typer.echo(f"Error reading template file: {e}", err=True)
            raise typer.Exit(1)
    _validate_priority(priority)
    _validate_optimization_level(optimization_level)
    try:
        params_list = json.loads(params)
    except json.JSONDecodeError as e:
        typer.echo(f"Failed to parse params JSON: {e}", err=True)
        raise typer.Exit(1)
    if not isinstance(params_list, list):
        typer.echo("params must be a JSON array.", err=True)
        raise typer.Exit(1)
    if not all(isinstance(p, dict) for p in params_list):
        typer.echo("Each element of params must be a JSON object.", err=True)
        raise typer.Exit(1)

    params_list = _normalize_stream_params(params_list)
    circuit_template = template.replace("\\n", "\n").replace("\\t", "\t")  # type: ignore[union-attr]
    if not circuit_template.strip():
        typer.echo("Error: circuit must not be empty.", err=True)
        raise typer.Exit(1)
    _warn_if_optimization_level_ignored(circuit_template, optimization_level)

    address = _get_address()
    with _get_client(address) as client:
        typer.echo(f"Streaming {len(params_list)} iteration(s) → shots={shots}")
        try:
            for i, res in enumerate(client.stream_gate_job(
                circuit_template=circuit_template,
                params_list=params_list,
                shots=shots,
                priority=priority,
                optimization_level=optimization_level,
            )):
                typer.echo(f"  [{i + 1}/{len(params_list)}] counts={res['counts']}")
        except (RuntimeError, ValueError) as e:
            typer.echo(f"Stream error: {e}", err=True)
            raise typer.Exit(1)


@app.command("help")
def help_cmd() -> None:
    """Show all commands with usage examples"""
    typer.echo("""
Commands
────────────────────────────────────────────────────────────

  Server
    qubecli connect <host[:port]>

  Auth
    qubecli login [--username TEXT] [--password TEXT]
    qubecli logout
    qubecli me

  Submit
    qubecli submit-gate --circuit <QASM> --shots <N>
                        [--priority 1-4] [--optimization-level 0-3]

    qubecli submit-pulse --pulse <JSON> --shots <N>
                         [--priority 1-4]

    qubecli reset --qubits <qubit_0,qubit_1,...> --shots <N>
                  [--priority 1-4]

    qubecli calibration widescan --qubit <Q> --freq-span <Hz> --n-freqs <N> --shots <N>
    qubecli calibration punchout --qubit <Q> --amps <JSON> --freq-span <Hz> --n-freqs <N> --shots <N>
    qubecli calibration chevron  --qubit <Q> --freq-span <Hz> --n-freqs <N> --x-twidth <JSON> --shots <N>
    qubecli calibration amp-rabi --qubit <Q> --n-amps <N> --shots <N> [--target-twidth <s>]
    qubecli calibration time-rabi --qubit <Q> --shots <N> [--x-twidth <JSON>]
    qubecli calibration ramsey   --qubit <Q> --delay-interval <JSON> --shots <N>
    qubecli calibration t1       --qubit <Q> --delay-interval <JSON> --shots <N>
    qubecli calibration stack-x90 --qubit <Q> --shots <N>
    qubecli calibration drag-alpha --qubit <Q> --shots <N>
    qubecli calibration blob-readout-freq --qubit <Q> --shots <N>
                                 [--priority 1-4 for all above]

  Backend
    qubecli qpu-info
    qubecli characterization
    qubecli update-characterization --data <JSON>

  Job
    qubecli status --job-id <ID>
    qubecli result --job-id <ID>
    qubecli cancel --job-id <ID>
    qubecli jobs [--page N] [--size N]

  Stream
    qubecli stream --template <QASM_WITH_{PARAM}> --params <JSON_ARRAY>
                   --shots <N> [--priority 1-4] [--optimization-level 0-3]

  Other
    qubecli -v

────────────────────────────────────────────────────────────
  Priority  1=CRITICAL  2=HIGH  3=NORMAL(default)  4=LOW
────────────────────────────────────────────────────────────

Examples
    qubecli connect localhost:50051
    qubecli login --username admin --password Admin1234!
    qubecli submit-gate --circuit 'OPENQASM 2.0; include "qelib1.inc"; qreg q[2]; creg c[2]; h q[0]; cx q[0],q[1]; measure q->c;' --shots 1000
    qubecli status --job-id <ID>
    qubecli result --job-id <ID>
    qubecli stream --template 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; rx({theta}) q[0]; measure q[0]->c[0];' --params '[{"theta": 0.0}, {"theta": 1.5707}, {"theta": 3.1415}]' --shots 200
""")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
