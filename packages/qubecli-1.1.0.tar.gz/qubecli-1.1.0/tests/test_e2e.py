"""End-to-end tests for qubecli — real gRPC server, no mocks.

Requirements:
  - QubeCore gRPC server running at localhost:50051
  - Admin credentials: admin / admin
  - Backend: kreo.sc-20 (20-qubit QPU)

Run (skip hardware tests):
    uv run pytest tests/test_e2e.py -v --tb=short -m "not hardware"

Run all including hardware:
    uv run pytest tests/test_e2e.py -v --tb=short
"""
import json
import time
from pathlib import Path
from typing import Generator
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from qubecli.main import app

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOST = "localhost:50051"
ADMIN_USER = "admin"
ADMIN_PASS = "admin"

BELL_CIRCUIT = (
    'OPENQASM 2.0; include "qelib1.inc"; '
    "qreg q[2]; creg c[2]; "
    "h q[0]; cx q[0],q[1]; "
    "measure q->c;"
)

SINGLE_QUBIT_CIRCUIT = (
    'OPENQASM 2.0; include "qelib1.inc"; '
    "qreg q[1]; creg c[1]; "
    "h q[0]; "
    "measure q[0]->c[0];"
)

BELL_QASM3 = (
    'OPENQASM 3; include "stdgates.inc"; '
    "qubit[2] q; bit[2] c; "
    "h q[0]; cx q[0], q[1]; "
    "c[0] = measure q[0]; c[1] = measure q[1];"
)

# Canonical 2-qubit Bell-state QIR (generated with pyqir's BasicQisBuilder).
BELL_QIR = """\
; ModuleID = 'bell'
source_filename = "bell"

%Qubit = type opaque
%Result = type opaque

define void @main() #0 {
entry:
  call void @__quantum__qis__h__body(%Qubit* null)
  call void @__quantum__qis__cnot__body(%Qubit* null, %Qubit* inttoptr (i64 1 to %Qubit*))
  call void @__quantum__qis__mz__body(%Qubit* null, %Result* null)
  call void @__quantum__qis__mz__body(%Qubit* inttoptr (i64 1 to %Qubit*), %Result* inttoptr (i64 1 to %Result*))
  ret void
}

declare void @__quantum__qis__h__body(%Qubit*)

declare void @__quantum__qis__cnot__body(%Qubit*, %Qubit*)

declare void @__quantum__qis__mz__body(%Qubit*, %Result* writeonly) #1

attributes #0 = { "entry_point" "output_labeling_schema" "qir_profiles"="custom" "required_num_qubits"="2" "required_num_results"="2" }
attributes #1 = { "irreversible" }

!llvm.module.flags = !{!0, !1, !2, !3}

!0 = !{i32 1, !"qir_major_version", i32 1}
!1 = !{i32 7, !"qir_minor_version", i32 0}
!2 = !{i32 1, !"dynamic_qubit_management", i1 false}
!3 = !{i32 1, !"dynamic_result_management", i1 false}
"""

VALID_JOB_STATUSES = {"PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED"}
TERMINAL_STATUSES = {"COMPLETED", "FAILED", "CANCELLED"}

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def e2e_config(tmp_path: Path) -> Generator[Path, None, None]:
    """Isolated config file for each E2E test, with host pre-configured."""
    config_file = tmp_path / "e2e_config.json"
    config_file.write_text(json.dumps({"host": HOST}))
    with patch("qubecli.main._CONFIG_PATH", config_file):
        yield config_file


@pytest.fixture()
def logged_in_config(tmp_path: Path) -> Generator[Path, None, None]:
    """Config file that already has a valid admin session (real login performed once)."""
    config_file = tmp_path / "e2e_config.json"
    config_file.write_text(json.dumps({"host": HOST}))
    with patch("qubecli.main._CONFIG_PATH", config_file):
        result = runner.invoke(
            app,
            ["login", "--username", ADMIN_USER, "--password", ADMIN_PASS],
        )
        if result.exit_code != 0:
            pytest.skip(f"Server unavailable or login failed: {result.output}")
        yield config_file


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _invoke(config_file: Path, args: list[str]):
    with patch("qubecli.main._CONFIG_PATH", config_file):
        return runner.invoke(app, args)


def _submit_gate(config_file: Path, circuit: str = BELL_CIRCUIT, shots: int = 10) -> str:
    """Submit a gate job and return the job_id."""
    result = _invoke(config_file, ["submit-gate", "--circuit", circuit, "--shots", str(shots)])
    assert result.exit_code == 0, result.output
    for line in result.output.splitlines():
        if "job_id" in line:
            return line.split(":", 1)[1].strip()
    raise AssertionError(f"job_id not found in output:\n{result.output}")


# ---------------------------------------------------------------------------
# 1. Auth E2E
# ---------------------------------------------------------------------------


class TestAuthE2E:
    """Full auth flow: connect → login → me → logout."""

    def test_login_exit_code_zero(self, e2e_config: Path) -> None:
        result = _invoke(e2e_config, ["login", "--username", ADMIN_USER, "--password", ADMIN_PASS])
        assert result.exit_code == 0, f"Login failed: {result.output}"

    def test_login_saves_tokens_to_config(self, e2e_config: Path) -> None:
        _invoke(e2e_config, ["login", "--username", ADMIN_USER, "--password", ADMIN_PASS])
        assert e2e_config.exists(), "Config file was not created"
        cfg = json.loads(e2e_config.read_text())
        assert "access_token" in cfg
        assert "refresh_token" in cfg
        assert cfg["access_token"]
        assert cfg["refresh_token"]

    def test_me_shows_admin_info(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["me"])
        assert result.exit_code == 0, result.output
        assert ADMIN_USER in result.output
        assert "admin" in result.output

    def test_login_bad_password_fails(self, e2e_config: Path) -> None:
        result = _invoke(e2e_config, ["login", "--username", ADMIN_USER, "--password", "WRONG_PASSWORD"])
        assert result.exit_code != 0

    def test_login_wrong_host_fails(self, e2e_config: Path) -> None:
        bad_config = e2e_config.parent / "bad_config.json"
        bad_config.write_text(json.dumps({"host": "localhost:19999"}))
        result = _invoke(bad_config, ["login", "--username", ADMIN_USER, "--password", ADMIN_PASS])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 2. Job submit E2E
# ---------------------------------------------------------------------------


class TestJobSubmitE2E:
    """Submit → status flow."""

    def test_submit_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", BELL_CIRCUIT, "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_submit_job_id_appears_in_status(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, SINGLE_QUBIT_CIRCUIT, shots=50)
        status_result = _invoke(logged_in_config, ["status", "--job-id", job_id])
        assert status_result.exit_code == 0, status_result.output
        assert job_id in status_result.output
        assert any(s in status_result.output for s in VALID_JOB_STATUSES)

    def test_submit_default_priority_is_normal(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", SINGLE_QUBIT_CIRCUIT, "--shots", "10"],
        )
        assert result.exit_code == 0, result.output
        assert "NORMAL" in result.output

    def test_submit_with_explicit_priority(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", SINGLE_QUBIT_CIRCUIT, "--shots", "10", "--priority", "2"],
        )
        assert result.exit_code == 0, result.output
        assert "HIGH" in result.output

    def test_submit_with_optimization_level(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", BELL_CIRCUIT, "--shots", "10", "--optimization-level", "1"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_status_has_required_fields(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config)
        result = _invoke(logged_in_config, ["status", "--job-id", job_id])
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output
        assert "status" in result.output
        assert "priority" in result.output


# ---------------------------------------------------------------------------
# 3. Cancel E2E
# ---------------------------------------------------------------------------


class TestJobCancelE2E:
    """Cancel pending jobs."""

    def test_cancel_pending_job(self, logged_in_config: Path) -> None:
        job_ids = [_submit_gate(logged_in_config) for _ in range(5)]
        cancelled = False
        for job_id in job_ids:
            result = _invoke(logged_in_config, ["cancel", "--job-id", job_id])
            if result.exit_code == 0:
                cancelled = True
                break
        if not cancelled:
            pytest.skip("No jobs remained PENDING long enough to cancel")

    def test_cancel_nonexistent_job_fails(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["cancel", "--job-id", "00000000-0000-0000-0000-000000000000"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 4. Backend info E2E
# ---------------------------------------------------------------------------


class TestBackendInfoE2E:
    """QPU info and characterization."""

    def test_qpu_info_shows_name(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["qpu-info"])
        assert result.exit_code == 0, result.output
        assert "name" in result.output

    def test_qpu_info_has_expected_fields(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["qpu-info"])
        assert result.exit_code == 0, result.output
        assert "num_qubits" in result.output
        assert "native_gates" in result.output
        assert "coupling_map" in result.output

    def test_qpu_info_kreo_sc20(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["qpu-info"])
        assert result.exit_code == 0, result.output
        assert "kreo.sc-20" in result.output

    def test_characterization_returns_data(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["characterization"])
        assert result.exit_code == 0, result.output

    def test_characterization_has_qubit_data(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["characterization"])
        assert result.exit_code == 0, result.output
        assert "t1" in result.output or "frequency" in result.output

    def test_characterization_qubit_count_matches_backend(self, logged_in_config: Path) -> None:
        info_result = _invoke(logged_in_config, ["qpu-info"])
        assert info_result.exit_code == 0
        char_result = _invoke(logged_in_config, ["characterization"])
        assert char_result.exit_code == 0


# ---------------------------------------------------------------------------
# 5. Jobs list E2E
# ---------------------------------------------------------------------------


class TestJobsListE2E:
    """jobs list command."""

    def test_jobs_returns_output(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["jobs"])
        assert result.exit_code == 0, result.output

    def test_submitted_job_appears_in_list(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config)
        result = _invoke(logged_in_config, ["jobs"])
        assert result.exit_code == 0, result.output
        assert job_id in result.output

    def test_jobs_pagination(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["jobs", "--page", "1", "--size", "5"])
        assert result.exit_code == 0, result.output

    def test_jobs_status_values_are_valid(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["jobs"])
        assert result.exit_code == 0, result.output
        for line in result.output.splitlines():
            for status in VALID_JOB_STATUSES:
                if status in line:
                    break


# ---------------------------------------------------------------------------
# 6. Hardware E2E
# ---------------------------------------------------------------------------


class TestHardwareE2E:
    """Tests that require actual QPU execution."""

    @pytest.mark.hardware
    def test_bell_state_job_completes(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, BELL_CIRCUIT, shots=100)
        for _ in range(30):
            time.sleep(2)
            result = _invoke(logged_in_config, ["status", "--job-id", job_id])
            if any(s in result.output for s in TERMINAL_STATUSES):
                break
        result = _invoke(logged_in_config, ["result", "--job-id", job_id])
        assert result.exit_code == 0, result.output
        assert "counts" in result.output

    @pytest.mark.hardware
    def test_single_qubit_job_result_has_shots(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, SINGLE_QUBIT_CIRCUIT, shots=200)
        for _ in range(30):
            time.sleep(2)
            result = _invoke(logged_in_config, ["status", "--job-id", job_id])
            if any(s in result.output for s in TERMINAL_STATUSES):
                break
        result = _invoke(logged_in_config, ["result", "--job-id", job_id])
        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# 6b. Circuit format support E2E (QASM 2.0 / QASM 3.0 / QIR via CLI)
# ---------------------------------------------------------------------------


class TestCircuitFormatsE2E:
    """Submit gate circuits in each supported format via the CLI.

    Submit-only tests (no @pytest.mark.hardware) only verify that the CLI
    forwards the circuit string to the server and gets back a ``job_id`` —
    they pass on any backend because format parsing runs in the worker.
    Hardware-marked tests additionally verify end-to-end execution on QubiC.
    """

    def test_submit_qasm3_via_cli(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", BELL_QASM3, "--shots", "10"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_submit_qir_via_cli(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", BELL_QIR, "--shots", "10"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    @pytest.mark.hardware
    def test_qasm3_completes_via_cli(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, BELL_QASM3, shots=100)
        for _ in range(30):
            time.sleep(2)
            result = _invoke(logged_in_config, ["status", "--job-id", job_id])
            if any(s in result.output for s in TERMINAL_STATUSES):
                break
        result = _invoke(logged_in_config, ["result", "--job-id", job_id])
        assert result.exit_code == 0, result.output
        assert "counts" in result.output

    @pytest.mark.hardware
    def test_qir_completes_via_cli(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, BELL_QIR, shots=100)
        for _ in range(30):
            time.sleep(2)
            result = _invoke(logged_in_config, ["status", "--job-id", job_id])
            if any(s in result.output for s in TERMINAL_STATUSES):
                break
        result = _invoke(logged_in_config, ["result", "--job-id", job_id])
        assert result.exit_code == 0, result.output
        assert "counts" in result.output


# ---------------------------------------------------------------------------
# 7. Edge cases E2E
# ---------------------------------------------------------------------------


class TestEdgeCaseE2E:
    def test_status_unknown_job_id_fails(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["status", "--job-id", "00000000-0000-0000-0000-000000000000"])
        assert result.exit_code != 0

    def test_multiple_jobs_submitted_sequentially(self, logged_in_config: Path) -> None:
        job_ids = [_submit_gate(logged_in_config) for _ in range(3)]
        assert len(set(job_ids)) == 3

    def test_submit_text_output_contains_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-gate", "--circuit", BELL_CIRCUIT, "--shots", "10"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_jobs_total_increases_after_submit(self, logged_in_config: Path) -> None:
        _submit_gate(logged_in_config)
        result = _invoke(logged_in_config, ["jobs"])
        assert result.exit_code == 0, result.output

    def test_full_stack_flow(self, logged_in_config: Path) -> None:
        job_id = _submit_gate(logged_in_config, BELL_CIRCUIT, shots=10)
        status_result = _invoke(logged_in_config, ["status", "--job-id", job_id])
        assert status_result.exit_code == 0
        assert job_id in status_result.output


# ---------------------------------------------------------------------------
# 8. Logout E2E
# ---------------------------------------------------------------------------


class TestLogoutE2E:
    def test_logout_clears_tokens(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["logout"])
        assert result.exit_code == 0, result.output
        cfg = json.loads(logged_in_config.read_text())
        assert "access_token" not in cfg
        assert "refresh_token" not in cfg


# ---------------------------------------------------------------------------
# 9. Submit Pulse E2E
# ---------------------------------------------------------------------------


class TestSubmitPulseE2E:
    PULSE = '[{"name":"X90","qubit":"qubit_0"},{"name":"read","qubit":"qubit_0"}]'

    def test_submit_pulse_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-pulse", "--pulse", self.PULSE, "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_submit_pulse_default_priority_is_normal(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["submit-pulse", "--pulse", self.PULSE, "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "NORMAL" in result.output


# ---------------------------------------------------------------------------
# 10. Calibration E2E
# ---------------------------------------------------------------------------


class TestSubmitCalibrationE2E:
    def test_submit_widescan_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["calibration", "widescan", "--qubit", "qubit_0", "--freq-span", "100000000", "--n-freqs", "200", "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output
        assert "widescan" in result.output

    def test_submit_punchout_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            [
                "calibration", "punchout",
                "--qubit", "qubit_0",
                "--amps", "[0.01,0.05,0.1,0.2,0.3,0.5]",
                "--freq-span", "20000000",
                "--n-freqs", "20",
                "--shots", "100",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output
        assert "punchout" in result.output


# ---------------------------------------------------------------------------
# 11. Result E2E
# ---------------------------------------------------------------------------


class TestResultE2E:
    def test_result_pending_job(self, logged_in_config: Path) -> None:
        # 시뮬레이터에서는 즉시 완료(exit_code=0)될 수 있고,
        # QPU 환경에서는 미완료(exit_code=1)를 반환한다 — 양쪽 모두 정상
        job_id = _submit_gate(logged_in_config)
        result = _invoke(logged_in_config, ["result", "--job-id", job_id])
        assert result.exit_code in (0, 1)

    def test_result_unknown_job_fails(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["result", "--job-id", "00000000-0000-0000-0000-000000000000"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 12. UpdateCharacterization E2E
# ---------------------------------------------------------------------------


class TestUpdateCharacterizationE2E:
    def test_update_characterization_all_qubits(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["update-characterization"])
        assert result.exit_code == 0, result.output

    def test_update_characterization_specific_qubits(self, logged_in_config: Path) -> None:
        result = _invoke(logged_in_config, ["update-characterization", "--qubits", "qubit_0"])
        assert result.exit_code == 0, result.output
        assert "qubit_0" in result.output


# ---------------------------------------------------------------------------
# 12b. Calibration (ReadoutFidelity / GateFidelity) E2E
# ---------------------------------------------------------------------------


class TestCalibrationReadoutFidelityE2E:
    def test_readout_fidelity_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["calibration", "readout-fidelity", "--qubit", "qubit_0", "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output


class TestCalibrationGateFidelityE2E:
    def test_gate_fidelity_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["calibration", "gate-fidelity", "--qubit", "qubit_0", "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output

    def test_gate_fidelity_with_lengths_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            [
                "calibration", "gate-fidelity",
                "--qubit", "qubit_0",
                "--shots", "100",
                "--lengths", "1,2,4,8",
                "--n-seeds", "5",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output


# ---------------------------------------------------------------------------
# 13. Submit Reset E2E
# ---------------------------------------------------------------------------


class TestSubmitResetE2E:
    def test_submit_reset_returns_job_id(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["reset", "--qubits", "qubit_0", "--shots", "10"],
        )
        assert result.exit_code == 0, result.output
        assert "job_id" in result.output


# ---------------------------------------------------------------------------
# 14. Stream E2E
# ---------------------------------------------------------------------------


class TestStreamE2E:
    """stream command — bidirectional streaming gate job."""

    TEMPLATE = (
        'OPENQASM 2.0; include "qelib1.inc"; '
        'qreg q[1]; creg c[1]; '
        'rx({theta}) q[0]; '
        'measure q[0]->c[0];'
    )
    PARAMS = '[{"theta": 0.0}, {"theta": 1.5707963}]'

    def test_stream_invalid_params_json_fails(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["stream", "--template", self.TEMPLATE, "--params", "not-valid-json", "--shots", "10"],
        )
        assert result.exit_code != 0

    def test_stream_params_not_array_fails(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["stream", "--template", self.TEMPLATE, "--params", '{"theta": 0.0}', "--shots", "10"],
        )
        assert result.exit_code != 0

    @pytest.mark.hardware
    def test_stream_two_params_yields_two_results(self, logged_in_config: Path) -> None:
        result = _invoke(
            logged_in_config,
            ["stream", "--template", self.TEMPLATE, "--params", self.PARAMS, "--shots", "100"],
        )
        assert result.exit_code == 0, result.output
        lines = [l for l in result.output.splitlines() if "counts" in l]
        assert len(lines) == 2
