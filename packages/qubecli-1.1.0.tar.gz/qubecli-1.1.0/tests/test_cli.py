"""Unit tests for qubecli CLI using typer.testing.CliRunner."""
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import grpc
import pytest
from typer.testing import CliRunner

from qubecli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_client_mock(
    *,
    job_status: dict | None = None,
    jobs_result: dict | None = None,
    cancel_message: str = "Job cancelled",
    job_id: str = "job-abc-123",
) -> MagicMock:
    """Return a fully-configured mock QubeClient instance."""
    mock_client = MagicMock()
    mock_client.close = MagicMock()

    if job_status is None:
        job_status = {
            "job_id": job_id,
            "status": "COMPLETED",
            "priority": 3,
            "submitted_at": "2024-01-01T00:00:00Z",
            "started_at": "2024-01-01T00:00:01Z",
            "finished_at": "2024-01-01T00:00:02Z",
            "error": None,
        }
    mock_client.get_job_status.return_value = job_status

    if jobs_result is None:
        jobs_result = {
            "total": 1,
            "jobs": [
                {
                    "job_id": job_id,
                    "type": "GATE",
                    "status": "COMPLETED",
                    "priority": 3,
                    "submitted_at": "2024-01-01T00:00:00Z",
                    "finished_at": "2024-01-01T00:00:02Z",
                }
            ],
        }
    mock_client.get_my_jobs.return_value = jobs_result

    mock_client.submit_gate_job.return_value = job_id
    mock_client.submit_reset_job.return_value = job_id
    mock_client.cancel_job.return_value = cancel_message

    return mock_client


def _patch_client(mock_client: MagicMock):
    return patch("qubecli.main.QubeClient", return_value=mock_client)


class _FakeRpcError(grpc.RpcError):
    def __init__(self, status_code: grpc.StatusCode, detail: str = "error") -> None:
        super().__init__(detail)
        self._status_code = status_code
        self._detail = detail

    def code(self) -> grpc.StatusCode:
        return self._status_code

    def details(self) -> str:
        return self._detail


def _make_grpc_error(status_code: grpc.StatusCode, detail: str = "error") -> _FakeRpcError:
    return _FakeRpcError(status_code, detail)


# ---------------------------------------------------------------------------
# 1. connect command
# ---------------------------------------------------------------------------

class TestConnectCommand:
    def _mock_channel_ready(self):
        mock_future = MagicMock()
        mock_future.result.return_value = None
        return mock_future

    def test_connect_host_port_success(self, tmp_config: Path):
        with (
            patch("qubecli.main.grpc.insecure_channel") as mock_channel,
            patch("qubecli.main.grpc.channel_ready_future", return_value=self._mock_channel_ready()),
        ):
            mock_channel.return_value = MagicMock()
            result = runner.invoke(app, ["connect", "localhost:50051"])
        assert result.exit_code == 0, result.output
        assert "Connected" in result.output
        saved = json.loads(tmp_config.read_text())
        assert saved["host"] == "localhost:50051"

    def test_connect_host_only_success(self, tmp_config: Path):
        with (
            patch("qubecli.main.grpc.insecure_channel") as mock_channel,
            patch("qubecli.main.grpc.channel_ready_future", return_value=self._mock_channel_ready()),
        ):
            mock_channel.return_value = MagicMock()
            result = runner.invoke(app, ["connect", "myserver.com"])
        assert result.exit_code == 0, result.output
        assert "Connected" in result.output
        saved = json.loads(tmp_config.read_text())
        assert saved["host"] == "myserver.com"

    def test_connect_invalid_port_exits(self, tmp_config: Path):
        result = runner.invoke(app, ["connect", "localhost:notaport"])
        assert result.exit_code != 0
        assert "Invalid format" in result.output

    def test_connect_timeout_exits(self, tmp_config: Path):
        mock_future = MagicMock()
        mock_future.result.side_effect = grpc.FutureTimeoutError()
        with (
            patch("qubecli.main.grpc.insecure_channel") as mock_channel,
            patch("qubecli.main.grpc.channel_ready_future", return_value=mock_future),
        ):
            mock_channel.return_value = MagicMock()
            result = runner.invoke(app, ["connect", "localhost:50051"])
        assert result.exit_code != 0
        assert "Cannot connect" in result.output

    def test_no_host_in_config_blocks_command(self, tmp_path: Path):
        """Without connect, commands should fail with a helpful message."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({}))
        with patch("qubecli.main._CONFIG_PATH", config_file):
            result = runner.invoke(app, ["qpu-info"])
        assert result.exit_code != 0
        assert "connect" in result.output.lower()


# ---------------------------------------------------------------------------
# 2. submit-gate command
# ---------------------------------------------------------------------------

class TestSubmitGateCommand:
    def test_missing_shots_returns_error(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--circuit", "OPENQASM 2.0;"])
        assert result.exit_code != 0

    def test_valid_submit_shows_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="job-new-999")
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", "OPENQASM 2.0;", "--shots", "1000"],
            )
        assert result.exit_code == 0, result.output
        assert "job-new-999" in result.output

    def test_invalid_priority_validation(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", "OPENQASM 2.0;", "--shots", "100", "--priority", "9"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_invalid_optimization_level_validation(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", "OPENQASM 2.0;", "--shots", "100", "--optimization-level", "5"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_submit_calls_client_correctly(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="job-check")
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", "OPENQASM 2.0;", "--shots", "200", "--priority", "2"],
            )
        assert result.exit_code == 0, result.output
        mock_client.submit_gate_job.assert_called_once()
        call_kwargs = mock_client.submit_gate_job.call_args
        assert call_kwargs.kwargs.get("shots") == 200 or call_kwargs.args[1] == 200

    @pytest.mark.parametrize(
        "fmt,circuit",
        [
            ("qasm2", 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; h q[0]; measure q[0]->c[0];'),
            ("qasm3", 'OPENQASM 3; include "stdgates.inc"; qubit[1] q; bit[1] c; h q[0]; c[0] = measure q[0];'),
            ("qir",   "; ModuleID = 'bell'\ntarget triple = \"x86_64-unknown-linux-gnu\"\ndefine void @main() { call void @__quantum__qis__h__body(); ret void }"),
            ("json",  '[{"name":"X90","qubit":"qubit_0"},{"name":"read","qubit":"qubit_0"}]'),
        ],
    )
    def test_circuit_string_forwarded_unchanged(self, authed_config: tuple, fmt: str, circuit: str):
        """--circuit string is forwarded verbatim to client.submit_gate_job regardless of format."""
        mock_client = _make_client_mock(job_id=f"job-{fmt}")
        mock_client.submit_gate_job.return_value = f"job-{fmt}"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--circuit", circuit, "--shots", "10"])
        assert result.exit_code == 0, result.output
        assert f"job-{fmt}" in result.output
        mock_client.submit_gate_job.assert_called_once()
        call = mock_client.submit_gate_job.call_args
        forwarded = call.kwargs.get("gate_circuits", call.args[0] if call.args else None)
        assert forwarded == [circuit]

    def test_circuit_file_option(self, authed_config: tuple, tmp_path: Path):
        """--circuit-file reads file content and forwards it to submit_gate_job."""
        circuit = 'OPENQASM 2.0; qreg q[1]; creg c[1]; h q[0]; measure q[0]->c[0];'
        circuit_file = tmp_path / "bell.qasm"
        circuit_file.write_text(circuit)
        mock_client = _make_client_mock(job_id="job-file")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--circuit-file", str(circuit_file), "--shots", "10"])
        assert result.exit_code == 0, result.output
        call = mock_client.submit_gate_job.call_args
        forwarded = call.kwargs.get("gate_circuits", call.args[0] if call.args else None)
        assert forwarded == [circuit]

    def test_circuit_and_circuit_file_mutually_exclusive(self, authed_config: tuple, tmp_path: Path):
        circuit_file = tmp_path / "bell.qasm"
        circuit_file.write_text("OPENQASM 2.0;")
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["submit-gate", "--circuit", "OPENQASM 2.0;", "--circuit-file", str(circuit_file), "--shots", "10"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_missing_circuit_and_circuit_file_returns_error(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--shots", "10"])
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_circuit_file_not_found_returns_error(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--circuit-file", "/nonexistent/path.qir", "--shots", "10"])
        assert result.exit_code != 0
        assert mock_client.submit_gate_job.call_count == 0

    def test_qir_optimization_level_warning(self, authed_config: tuple):
        qir = "; ModuleID = 'bell'\ndefine void @main() { ret void }"
        mock_client = _make_client_mock(job_id="job-qir")
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", qir, "--shots", "10", "--optimization-level", "2"]
            )
        assert result.exit_code == 0, result.output
        assert "Warning" in result.output or "ignored" in result.output

    def test_qasm_no_optimization_level_warning(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="job-qasm")
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-gate", "--circuit", "OPENQASM 2.0;", "--shots", "10", "--optimization-level", "1"]
            )
        assert result.exit_code == 0, result.output
        assert "Warning" not in result.output

    @pytest.mark.parametrize("circuit", ["", "   ", "\n\t\n"])
    def test_empty_circuit_returns_error(self, authed_config: tuple, circuit: str):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-gate", "--circuit", circuit, "--shots", "10"])
        assert result.exit_code != 0
        assert "empty" in result.output or "empty" in (result.stderr or "")
        assert mock_client.submit_gate_job.call_count == 0


# ---------------------------------------------------------------------------
# 4. login command
# ---------------------------------------------------------------------------

class TestLoginCommand:
    def test_successful_login_saves_tokens(self, tmp_config: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["login"].return_value = ("access_tok", "refresh_tok")
        result = runner.invoke(app, ["login", "--username", "alice", "--password", "secret"])
        assert result.exit_code == 0, result.output
        assert "alice" in result.output or "Logged in" in result.output
        saved = json.loads(tmp_config.read_text())
        assert saved["access_token"] == "access_tok"
        assert saved["refresh_token"] == "refresh_tok"

    def test_login_already_logged_in(self, config_with_tokens: Path, mock_qubecore_auth: dict):
        result = runner.invoke(app, ["login", "--username", "alice", "--password", "secret"])
        assert result.exit_code != 0
        assert "Already logged in" in result.output

    def test_failed_login_shows_error(self, tmp_config: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["login"].side_effect = RuntimeError("bad credentials")
        result = runner.invoke(app, ["login", "--username", "alice", "--password", "wrong"])
        assert result.exit_code != 0
        assert "Login failed" in result.output

    def test_login_grpc_unavailable(self, tmp_config: Path, mock_qubecore_auth: dict):
        err = _make_grpc_error(grpc.StatusCode.UNAVAILABLE, "connection refused")
        mock_qubecore_auth["login"].side_effect = err
        result = runner.invoke(app, ["login", "--username", "alice", "--password", "secret"])
        assert result.exit_code != 0
        assert "Cannot connect" in result.output or "connect" in result.output.lower()


# ---------------------------------------------------------------------------
# 5. jobs command
# ---------------------------------------------------------------------------

class TestJobsCommand:
    def test_jobs_text_output_formatted(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs"])
        assert result.exit_code == 0, result.output
        assert "total" in result.output
        assert "job-abc-123" in result.output

    def test_jobs_empty_list(self, authed_config: tuple):
        mock_client = _make_client_mock(jobs_result={"total": 0, "jobs": []})
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs"])
        assert result.exit_code == 0, result.output
        assert "no jobs" in result.output.lower() or "total" in result.output

    def test_jobs_pagination_params(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["jobs", "--page", "2", "--size", "5"])
        assert result.exit_code == 0, result.output
        mock_client.get_my_jobs.assert_called_once_with(page=2, page_size=5)


# ---------------------------------------------------------------------------
# 6. cancel command
# ---------------------------------------------------------------------------

class TestCancelCommand:
    def test_cancel_success_shows_message(self, authed_config: tuple):
        mock_client = _make_client_mock(cancel_message="Job cancelled successfully")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        assert "cancelled" in result.output.lower() or "Job cancelled" in result.output

    def test_cancel_grpc_failure(self, authed_config: tuple):
        mock_client = _make_client_mock()
        rpc_error = _make_grpc_error(grpc.StatusCode.NOT_FOUND, "job not found")
        mock_client.cancel_job.side_effect = rpc_error
        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "no-such-job"])
        assert result.exit_code != 0

    def test_cancel_unauthenticated(self, authed_config: tuple):
        mock_client = _make_client_mock()
        rpc_error = _make_grpc_error(grpc.StatusCode.UNAUTHENTICATED, "unauthenticated")
        mock_client.cancel_job.side_effect = rpc_error
        with _patch_client(mock_client):
            result = runner.invoke(app, ["cancel", "--job-id", "job-abc-123"])
        assert result.exit_code != 0
        assert "login" in result.output.lower() or "Authentication" in result.output


# ---------------------------------------------------------------------------
# 7. Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_version_flag(self):
        result = runner.invoke(app, ["-v"])
        assert result.exit_code == 0
        assert result.output.startswith("v")

    def test_logout_not_logged_in(self, tmp_config: Path, mock_qubecore_auth: dict):
        result = runner.invoke(app, ["logout"])
        assert result.exit_code != 0
        assert "Not logged in" in result.output

    def test_logout_clears_tokens(self, config_with_tokens: Path, mock_qubecore_auth: dict):
        mock_qubecore_auth["logout"].return_value = None
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0, result.output
        saved = json.loads(config_with_tokens.read_text())
        assert "access_token" not in saved
        assert "refresh_token" not in saved

    def test_status_missing_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["status"])
        assert result.exit_code != 0

    def test_reset_valid(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="reset-001")
        mock_client.submit_reset_job.return_value = "reset-001"
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["reset", "--qubits", "qubit_0,qubit_1", "--shots", "100"],
            )
        assert result.exit_code == 0, result.output
        assert "reset-001" in result.output

    def test_reset_empty_qubits(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["reset", "--qubits", "  ", "--shots", "100"],
            )
        assert result.exit_code != 0
        assert mock_client.submit_reset_job.call_count == 0

    def test_status_no_watch_calls_once(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        assert mock_client.get_job_status.call_count == 1

    def test_token_expired_refresh(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "host": "localhost:50051",
            "access_token": "expired_tok",
            "refresh_token": "valid_refresh",
        }))
        mock_client = _make_client_mock()
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
            patch(
                "qubecli.main.refresh_token",
                return_value=("new_access_tok", "new_refresh_tok"),
            ) as mock_refresh,
            _patch_client(mock_client),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code == 0, result.output
        mock_refresh.assert_called_once()
        saved = json.loads(config_file.read_text())
        assert saved["access_token"] == "new_access_tok"

    def test_token_expired_no_refresh_token_exits(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"host": "localhost:50051", "access_token": "expired_tok"}))
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code != 0

    def test_token_expired_refresh_fails_exits(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "host": "localhost:50051",
            "access_token": "expired_tok",
            "refresh_token": "bad_refresh",
        }))
        with (
            patch("qubecli.main._CONFIG_PATH", config_file),
            patch("qubecli.main.is_token_expired", return_value=True),
            patch("qubecli.main.refresh_token", side_effect=RuntimeError("expired")),
        ):
            result = runner.invoke(app, ["status", "--job-id", "job-abc-123"])
        assert result.exit_code != 0

    def test_help_command(self):
        result = runner.invoke(app, ["help"])
        assert result.exit_code == 0
        assert "Commands" in result.output
        assert "submit" in result.output.lower()

    def test_no_subcommand_prints_banner(self, tmp_config: Path):
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        assert "QUBECORE" in result.output or "QubeCore" in result.output or "SDT" in result.output


# ---------------------------------------------------------------------------
# 8. me command
# ---------------------------------------------------------------------------

class TestMeCommand:
    def _make_me_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_me.return_value = {
            "user_id": "uid-001",
            "username": "alice",
            "role": "user",
            "created_at": "2024-01-01T00:00:00Z",
        }
        return client

    def test_me_text_output(self, authed_config: tuple):
        mock_client = self._make_me_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["me"])
        assert result.exit_code == 0, result.output
        assert "alice" in result.output
        assert "uid-001" in result.output


# ---------------------------------------------------------------------------
# 9. submit-pulse command
# ---------------------------------------------------------------------------

class TestSubmitPulseCommand:
    def test_submit_pulse_shows_job_id(self, authed_config: tuple):
        mock_client = _make_client_mock(job_id="pulse-job-001")
        mock_client.submit_pulse_job.return_value = "pulse-job-001"
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["submit-pulse", "--pulse", '{"channel":"ch0"}', "--shots", "512"],
            )
        assert result.exit_code == 0, result.output
        assert "pulse-job-001" in result.output

    def test_submit_pulse_missing_shots_returns_error(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["submit-pulse", "--pulse", '{"channel":"ch0"}'])
        assert result.exit_code != 0
        assert mock_client.submit_pulse_job.call_count == 0


# ---------------------------------------------------------------------------
# 10. calibration commands
# ---------------------------------------------------------------------------

_CAL_HAPPY = [
    ("widescan",         "submit_widescan_job",         "cal-job-001",
     ["--qubit", "qubit_0", "--freq-span", "100000000", "--n-freqs", "200", "--shots", "100"]),
    ("punchout",         "submit_punchout_job",         "cal-job-002",
     ["--qubit", "qubit_0", "--amps", "[0.01,0.05,0.1]", "--freq-span", "20000000",
      "--n-freqs", "20", "--shots", "100"]),
    ("chevron",          "submit_chevron_job",          "cal-job-003",
     ["--qubit", "qubit_0", "--freq-span", "1000000", "--n-freqs", "20",
      "--x-twidth", "[1e-8,2e-8]", "--shots", "100"]),
    ("amp-rabi",         "submit_amp_rabi_job",         "cal-job-004",
     ["--qubit", "qubit_0", "--n-amps", "20", "--shots", "100"]),
    ("time-rabi",        "submit_time_rabi_job",        "cal-job-005",
     ["--qubit", "qubit_0", "--shots", "100"]),
    ("ramsey",           "submit_ramsey_job",           "cal-job-006",
     ["--qubit", "qubit_0", "--delay-interval", "[1e-7,2e-7,3e-7]", "--shots", "100"]),
    ("t1",               "submit_t1_job",               "cal-job-007",
     ["--qubit", "qubit_0", "--delay-interval", "[1e-6,5e-6,1e-5]", "--shots", "100"]),
    ("stack-x90",        "submit_stack_x90_job",        "cal-job-008",
     ["--qubit", "qubit_0", "--shots", "100"]),
    ("drag-alpha",       "submit_drag_alpha_job",       "cal-job-009",
     ["--qubit", "qubit_0", "--shots", "100"]),
    ("blob-readout-freq","submit_blob_readout_freq_job","cal-job-010",
     ["--qubit", "qubit_0", "--shots", "100"]),
    ("readout-fidelity", "submit_readout_fidelity_job", "cal-job-011",
     ["--qubit", "qubit_0", "--shots", "1000"]),
    ("gate-fidelity",    "submit_gate_fidelity_job",    "cal-job-012",
     ["--qubit", "qubit_0", "--shots", "100"]),
]


_CAL_BAD_JSON = [
    # subcommand, client method, args containing a malformed JSON value
    ("punchout",          "submit_punchout_job",
     ["--qubit", "qubit_0", "--amps", "not-json", "--freq-span", "20000000",
      "--n-freqs", "20", "--shots", "100"]),
    ("punchout",          "submit_punchout_job",
     ["--qubit", "qubit_0", "--amps", '{"a": 1}', "--freq-span", "20000000",
      "--n-freqs", "20", "--shots", "100"]),
    ("chevron",           "submit_chevron_job",
     ["--qubit", "qubit_0", "--freq-span", "1000000", "--n-freqs", "20",
      "--x-twidth", "not-json", "--shots", "100"]),
    ("ramsey",            "submit_ramsey_job",
     ["--qubit", "qubit_0", "--delay-interval", "not-json", "--shots", "100"]),
    ("t1",                "submit_t1_job",
     ["--qubit", "qubit_0", "--delay-interval", "not-json", "--shots", "100"]),
    ("drag-alpha",        "submit_drag_alpha_job",
     ["--qubit", "qubit_0", "--shots", "100", "--alphas", "not-json"]),
    ("blob-readout-freq", "submit_blob_readout_freq_job",
     ["--qubit", "qubit_0", "--shots", "100", "--dfreads", "not-json"]),
]


class TestCalibrationCommand:
    @pytest.mark.parametrize("subcmd,client_method,job_id,extra_args", _CAL_HAPPY)
    def test_shows_job_id(
        self,
        authed_config: tuple,
        subcmd: str,
        client_method: str,
        job_id: str,
        extra_args: list[str],
    ):
        mock_client = _make_client_mock(job_id=job_id)
        getattr(mock_client, client_method).return_value = job_id
        with _patch_client(mock_client):
            result = runner.invoke(app, ["calibration", subcmd, *extra_args])
        assert result.exit_code == 0, result.output
        assert job_id in result.output

    def test_widescan_missing_qubit_exits(self, authed_config: tuple):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["calibration", "widescan"])
        assert result.exit_code != 0

    @pytest.mark.parametrize("subcmd,client_method,extra_args", _CAL_BAD_JSON)
    def test_invalid_json_exits(
        self,
        authed_config: tuple,
        subcmd: str,
        client_method: str,
        extra_args: list[str],
    ):
        mock_client = _make_client_mock()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["calibration", subcmd, *extra_args])
        assert result.exit_code != 0
        assert getattr(mock_client, client_method).call_count == 0


# ---------------------------------------------------------------------------
# 11. result command
# ---------------------------------------------------------------------------

class TestResultCommand:
    def _make_result_client(self, status: str = "COMPLETED") -> MagicMock:
        client = _make_client_mock()
        client.get_job_result.return_value = {
            "job_id": "job-res-001",
            "status": status,
            "results": [{"counts": {"00": 512, "11": 488}, "s11": None, "qubit_mapping": {"q0": "qubit_0"}}],
        }
        return client

    def test_result_completed_text_output(self, authed_config: tuple):
        mock_client = self._make_result_client("COMPLETED")
        with _patch_client(mock_client):
            result = runner.invoke(app, ["result", "--job-id", "job-res-001"])
        assert result.exit_code == 0, result.output
        assert "job-res-001" in result.output
        assert "COMPLETED" in result.output
        assert "counts" in result.output


# ---------------------------------------------------------------------------
# 12. qpu-info command
# ---------------------------------------------------------------------------

class TestBackendInfoCommand:
    def _make_backend_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_backend_info.return_value = {
            "name": "sdt-q5",
            "num_qubits": 5,
            "native_gates": ["X90", "ZX90"],
            "qasm_supported_gates": ["h", "cx", "rz"],
            "coupling_map": [
                {"qubit_a": 0, "qubit_b": 1},
                {"qubit_a": 1, "qubit_b": 2},
            ],
        }
        return client

    def test_backend_info_text_output(self, authed_config: tuple):
        mock_client = self._make_backend_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["qpu-info"])
        assert result.exit_code == 0, result.output
        assert "sdt-q5" in result.output


# ---------------------------------------------------------------------------
# 13. characterization command
# ---------------------------------------------------------------------------

class TestCharacterizationCommand:
    def _make_char_client(self) -> MagicMock:
        client = _make_client_mock()
        client.get_characterization.return_value = {
            "last_calibrated": "2024-06-01T12:00:00Z",
            "qubits": [
                {"index": 0, "t1": 1e-4, "t2": 9e-5, "frequency": 4.85e9},
                {"index": 1, "t1": 1.1e-4, "t2": 8.5e-5, "frequency": 4.92e9},
            ],
        }
        return client

    def test_characterization_text_output(self, authed_config: tuple):
        mock_client = self._make_char_client()
        with _patch_client(mock_client):
            result = runner.invoke(app, ["characterization"])
        assert result.exit_code == 0, result.output
        assert "2024-06-01T12:00:00Z" in result.output


# ---------------------------------------------------------------------------
# 14. update-characterization command
# ---------------------------------------------------------------------------

class TestUpdateCharacterizationCommand:
    def test_all_qubits_success(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_characterization.return_value = "Characterization updated: all qubits"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-characterization"])
        assert result.exit_code == 0, result.output
        assert "Characterization updated" in result.output
        mock_client.update_characterization.assert_called_once_with(qubits=None)

    def test_specific_qubits_passed(self, authed_config: tuple):
        mock_client = _make_client_mock()
        mock_client.update_characterization.return_value = "Characterization updated: qubit_0, qubit_1"
        with _patch_client(mock_client):
            result = runner.invoke(app, ["update-characterization", "--qubits", "qubit_0,qubit_1"])
        assert result.exit_code == 0, result.output
        mock_client.update_characterization.assert_called_once_with(qubits=["qubit_0", "qubit_1"])


# ---------------------------------------------------------------------------
# 15. stream command
# ---------------------------------------------------------------------------

class TestStreamCommand:
    _TEMPLATE = 'OPENQASM 2.0; include "qelib1.inc"; qreg q[1]; creg c[1]; rx({theta}) q[0]; measure q[0]->c[0];'
    _PARAMS = '[{"theta": 0.0}, {"theta": 1.5707}]'

    def _make_stream_client(self) -> MagicMock:
        client = _make_client_mock()
        client.stream_gate_job.return_value = iter([
            {"counts": {"0": 480, "1": 544}},
            {"counts": {"0": 100, "1": 924}},
        ])
        return client

    def test_stream_text_output(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["stream", "--template", self._TEMPLATE, "--params", self._PARAMS, "--shots", "1024"],
            )
        assert result.exit_code == 0, result.output
        assert "counts" in result.output

    def test_stream_invalid_params_json_exits(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["stream", "--template", self._TEMPLATE, "--params", "not-valid-json", "--shots", "1024"],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_not_list_exits(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["stream", "--template", self._TEMPLATE, "--params", '{"theta": 0.0}', "--shots", "1024"],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_boolean_value_exits(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app, ["stream", "--template", self._TEMPLATE, "--params", '[{"theta": true}]', "--shots", "1024"],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0

    def test_stream_params_string_value_exits(self, authed_config: tuple):
        mock_client = self._make_stream_client()
        with _patch_client(mock_client):
            result = runner.invoke(
                app,
                ["stream", "--template", self._TEMPLATE, "--params", '[{"theta": "not-a-number"}]', "--shots", "1024"],
            )
        assert result.exit_code != 0
        assert mock_client.stream_gate_job.call_count == 0
