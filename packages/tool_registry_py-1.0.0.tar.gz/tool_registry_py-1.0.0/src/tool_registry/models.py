"""Data models for tool-registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ParamType(str, Enum):
    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"


@dataclass
class ToolParam:
    name: str
    type: ParamType
    description: str = ""
    required: bool = True
    default: Any = None
    enum: list[Any] | None = None

    def to_json_schema(self) -> dict[str, Any]:
        schema: dict[str, Any] = {"type": self.type.value}
        if self.description:
            schema["description"] = self.description
        if self.enum:
            schema["enum"] = self.enum
        return schema

    def __repr__(self) -> str:
        req = "required" if self.required else f"optional={self.default!r}"
        return f"ToolParam({self.name!r}: {self.type.value}, {req})"


@dataclass
class ToolSpec:
    """A typed specification for an LLM-callable tool."""

    name: str
    description: str
    params: list[ToolParam] = field(default_factory=list)
    fn: Any = None
    tags: list[str] = field(default_factory=list)
    category: str = "general"
    version: str = "1.0.0"

    @property
    def required_params(self) -> list[ToolParam]:
        return [p for p in self.params if p.required]

    @property
    def optional_params(self) -> list[ToolParam]:
        return [p for p in self.params if not p.required]

    def to_anthropic(self) -> dict[str, Any]:
        properties = {p.name: p.to_json_schema() for p in self.params}
        required = [p.name for p in self.required_params]
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": properties,
                **({"required": required} if required else {}),
            },
        }

    def to_openai(self) -> dict[str, Any]:
        properties = {p.name: p.to_json_schema() for p in self.params}
        required = [p.name for p in self.required_params]
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    **({"required": required} if required else {}),
                },
            },
        }

    def call(self, **kwargs: Any) -> Any:
        if self.fn is None:
            raise RuntimeError(f"Tool {self.name!r} has no callable attached.")
        missing = [p.name for p in self.required_params if p.name not in kwargs]
        if missing:
            raise ValueError(f"Tool {self.name!r} missing required params: {missing}")
        return self.fn(**kwargs)

    def __repr__(self) -> str:
        return f"ToolSpec({self.name!r}, params={[p.name for p in self.params]})"
