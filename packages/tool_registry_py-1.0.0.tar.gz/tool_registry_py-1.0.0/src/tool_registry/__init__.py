"""
tool_registry — typed tool catalogue for LLM agents.

Quick start:
    from tool_registry import ToolRegistry

    registry = ToolRegistry()

    @registry.register(tags=["search", "web"])
    def web_search(query: str, max_results: int = 5) -> str:
        '''Search the web for information.
        Args:
            query: The search query to execute.
            max_results: Maximum number of results.
        '''
        ...

    tools = registry.to_anthropic()   # Anthropic format
    tools = registry.to_openai()      # OpenAI format
    results = registry.find("search") # discover by keyword
"""

from tool_registry.models import ParamType, ToolParam, ToolSpec
from tool_registry.registry import ToolRegistry, tool

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = ["ToolRegistry", "tool", "ToolSpec", "ToolParam", "ParamType"]
