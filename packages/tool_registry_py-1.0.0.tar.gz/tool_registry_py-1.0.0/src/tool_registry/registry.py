"""ToolRegistry — register, discover, and export tools."""

from __future__ import annotations

import inspect
import re
from typing import Any, Callable

from tool_registry.models import ParamType, ToolParam, ToolSpec

_TYPE_MAP: dict[str, ParamType] = {
    "str": ParamType.STRING,
    "int": ParamType.INTEGER,
    "float": ParamType.NUMBER,
    "bool": ParamType.BOOLEAN,
    "list": ParamType.ARRAY,
    "dict": ParamType.OBJECT,
}


def _infer_type(annotation: Any) -> ParamType:
    if annotation is inspect.Parameter.empty:
        return ParamType.STRING
    name = getattr(annotation, "__name__", str(annotation))
    if hasattr(annotation, "__origin__"):
        args = getattr(annotation, "__args__", [])
        if args:
            name = getattr(args[0], "__name__", str(args[0]))
    return _TYPE_MAP.get(name, ParamType.STRING)


def _parse_docstring(fn: Callable) -> tuple[str, dict[str, str]]:
    doc = inspect.getdoc(fn) or ""
    lines = doc.split("\n")
    desc_lines: list[str] = []
    param_docs: dict[str, str] = {}
    in_params = False
    for line in lines:
        stripped = line.strip()
        if stripped.lower().startswith(("args:", "params:", "parameters:")):
            in_params = True
            continue
        if in_params:
            m = re.match(r"(\w+)(?:\s*\([^)]+\))?\s*:\s*(.+)", stripped)
            if m:
                param_docs[m.group(1)] = m.group(2)
            elif stripped and not re.match(r"\w+\s*:", stripped):
                in_params = False
        else:
            desc_lines.append(line)
    description = " ".join(ln.strip() for ln in desc_lines if ln.strip())
    return description, param_docs


def _spec_from_function(
    fn: Callable,
    name: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
    category: str = "general",
) -> ToolSpec:
    tool_name = name or fn.__name__
    doc_desc, param_docs = _parse_docstring(fn)
    tool_desc = description or doc_desc or f"Call {tool_name}"
    sig = inspect.signature(fn)
    params: list[ToolParam] = []
    for pname, param in sig.parameters.items():
        if pname in ("self", "cls"):
            continue
        ptype = _infer_type(param.annotation)
        pdesc = param_docs.get(pname, "")
        required = param.default is inspect.Parameter.empty
        default = None if required else param.default
        params.append(
            ToolParam(name=pname, type=ptype, description=pdesc, required=required, default=default)
        )
    return ToolSpec(
        name=tool_name,
        description=tool_desc,
        params=params,
        fn=fn,
        tags=tags or [],
        category=category,
    )


class ToolRegistry:
    """
    Registry for LLM agent tools.

    Example:
        registry = ToolRegistry()

        @registry.register(tags=["search"])
        def web_search(query: str, max_results: int = 5) -> str:
            '''Search the web. Args: query: Search query. max_results: Max results.'''
            ...

        tools = registry.to_anthropic()
        registry.call("web_search", query="RAG systems")
    """

    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(
        self,
        fn: Callable | None = None,
        *,
        name: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
        category: str = "general",
    ) -> Any:
        def _do_register(func: Callable) -> Callable:
            spec = _spec_from_function(
                func, name=name, description=description, tags=tags, category=category
            )
            self._tools[spec.name] = spec
            return func

        if fn is not None:
            return _do_register(fn)
        return _do_register

    def add(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def get(self, name: str) -> ToolSpec:
        if name not in self._tools:
            raise KeyError(f"Tool {name!r} not found. Available: {sorted(self._tools)}")
        return self._tools[name]

    def find(self, query: str) -> list[ToolSpec]:
        q = query.lower()
        return [
            t
            for t in self._tools.values()
            if q in t.name.lower()
            or q in t.description.lower()
            or q in t.category.lower()
            or any(q in tag.lower() for tag in t.tags)
        ]

    def by_tag(self, tag: str) -> list[ToolSpec]:
        return [t for t in self._tools.values() if tag.lower() in [tg.lower() for tg in t.tags]]

    def by_category(self, category: str) -> list[ToolSpec]:
        return [t for t in self._tools.values() if t.category.lower() == category.lower()]

    def all(self) -> list[ToolSpec]:
        return list(self._tools.values())

    def names(self) -> list[str]:
        return sorted(self._tools.keys())

    def to_anthropic(self, names: list[str] | None = None) -> list[dict[str, Any]]:
        tools = [self._tools[n] for n in names] if names else self.all()
        return [t.to_anthropic() for t in tools]

    def to_openai(self, names: list[str] | None = None) -> list[dict[str, Any]]:
        tools = [self._tools[n] for n in names] if names else self.all()
        return [t.to_openai() for t in tools]

    def call(self, name: str, **kwargs: Any) -> Any:
        return self.get(name).call(**kwargs)

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        return f"ToolRegistry({len(self)} tools: {self.names()[:5]})"


_default_registry = ToolRegistry()


def tool(
    fn: Callable | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
    category: str = "general",
) -> Any:
    """Register a tool in the default module-level registry."""
    return _default_registry.register(
        fn, name=name, description=description, tags=tags, category=category
    )
