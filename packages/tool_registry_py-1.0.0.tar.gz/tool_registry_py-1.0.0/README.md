# tool-registry

**Typed tool catalogue for LLM agents. Register, discover, validate, and export tools to Anthropic/OpenAI format. Zero dependencies.**

[![Tests](https://img.shields.io/badge/Tests-36%20passing-brightgreen?style=flat-square)](tests/)
[![Dependencies](https://img.shields.io/badge/Dependencies-zero-brightgreen?style=flat-square)](pyproject.toml)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?style=flat-square)](pyproject.toml)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![LinkedIn](https://img.shields.io/badge/-Linda_Oraegbunam-blue?logo=linkedin&style=flat-square)](https://www.linkedin.com/in/linda-oraegbunam/)

## Install

```bash
pip install tool-registry
```

## Quick start

```python
from tool_registry import ToolRegistry

registry = ToolRegistry()

@registry.register(tags=["search", "web"])
def web_search(query: str, max_results: int = 5) -> str:
    """Search the web for information.
    Args:
        query: The search query to execute.
        max_results: Maximum number of results to return.
    """
    ...

# Export to Anthropic format — ready for client.messages.create()
tools = registry.to_anthropic()

# Export to OpenAI format
tools = registry.to_openai()

# Discover by capability
search_tools = registry.find("search")
web_tools = registry.by_tag("web")

# Call a tool
result = registry.call("web_search", query="UK AI regulation 2026")
```

Auto-inferred from your function signature:
- Parameter types (`str`, `int`, `float`, `bool`, `list`, `dict`)
- Required vs optional (based on defaults)
- Descriptions (from docstring Args section)

---

**Linda Oraegbunam** | [LinkedIn](https://www.linkedin.com/in/linda-oraegbunam/) | [GitHub](https://github.com/obielin)
