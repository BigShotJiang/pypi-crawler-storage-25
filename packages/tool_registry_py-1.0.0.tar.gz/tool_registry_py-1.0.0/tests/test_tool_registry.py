"""Tests for tool-registry. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from tool_registry import ParamType, ToolParam, ToolRegistry, ToolSpec


@pytest.fixture
def registry():
    return ToolRegistry()


def search_fn(query: str, max_results: int = 5) -> str:
    """Search the web for information.

    Args:
        query: The search query to execute.
        max_results: Maximum number of results to return.
    """
    return f"results for {query}"


def calculator_fn(expression: str) -> float:
    """Evaluate a mathematical expression.

    Args:
        expression: The expression to evaluate.
    """
    return float(eval(expression))  # noqa: S307


class TestToolParam:
    def test_to_json_schema_type(self):
        p = ToolParam(name="q", type=ParamType.STRING, description="A query")
        assert p.to_json_schema()["type"] == "string"

    def test_to_json_schema_description(self):
        p = ToolParam(name="q", type=ParamType.STRING, description="A query")
        assert "description" in p.to_json_schema()

    def test_to_json_schema_enum(self):
        p = ToolParam(name="fmt", type=ParamType.STRING, enum=["json", "text"])
        assert p.to_json_schema()["enum"] == ["json", "text"]

    def test_repr(self):
        p = ToolParam(name="q", type=ParamType.STRING, required=True)
        assert "required" in repr(p)


class TestToolSpec:
    def test_to_anthropic_format(self):
        spec = ToolSpec(
            name="search",
            description="Search the web",
            params=[ToolParam("query", ParamType.STRING, "The query", required=True)],
        )
        fmt = spec.to_anthropic()
        assert fmt["name"] == "search"
        assert "input_schema" in fmt
        assert "query" in fmt["input_schema"]["properties"]
        assert "query" in fmt["input_schema"]["required"]

    def test_to_openai_format(self):
        spec = ToolSpec(
            name="search", description="Search", params=[ToolParam("query", ParamType.STRING)]
        )
        fmt = spec.to_openai()
        assert fmt["type"] == "function"
        assert fmt["function"]["name"] == "search"

    def test_required_params_filter(self):
        spec = ToolSpec(
            name="t",
            description="test",
            params=[
                ToolParam("a", ParamType.STRING, required=True),
                ToolParam("b", ParamType.INTEGER, required=False, default=5),
            ],
        )
        assert len(spec.required_params) == 1
        assert spec.required_params[0].name == "a"

    def test_optional_params_filter(self):
        spec = ToolSpec(
            name="t",
            description="test",
            params=[
                ToolParam("a", ParamType.STRING, required=True),
                ToolParam("b", ParamType.INTEGER, required=False),
            ],
        )
        assert len(spec.optional_params) == 1

    def test_call_executes_fn(self):
        spec = ToolSpec(
            name="add",
            description="Add",
            params=[ToolParam("x", ParamType.INTEGER), ToolParam("y", ParamType.INTEGER)],
            fn=lambda x, y: x + y,
        )
        assert spec.call(x=2, y=3) == 5

    def test_call_no_fn_raises(self):
        spec = ToolSpec(name="t", description="test")
        with pytest.raises(RuntimeError):
            spec.call()

    def test_call_missing_required_raises(self):
        spec = ToolSpec(
            name="t",
            description="test",
            params=[ToolParam("required_arg", ParamType.STRING, required=True)],
            fn=lambda required_arg: required_arg,
        )
        with pytest.raises(ValueError, match="missing required"):
            spec.call()

    def test_repr(self):
        spec = ToolSpec(name="search", description="test")
        assert "search" in repr(spec)


class TestToolRegistry:
    def test_register_decorator(self, registry):
        @registry.register(tags=["search"])
        def my_search(query: str) -> str:
            """Search for things."""
            return query

        assert "my_search" in registry

    def test_register_with_name(self, registry):
        @registry.register(name="web_search")
        def search(q: str) -> str:
            """Do a search."""
            return q

        assert "web_search" in registry

    def test_register_direct(self, registry):
        registry.register(search_fn, tags=["search", "web"])
        assert "search_fn" in registry

    def test_add_spec(self, registry):
        spec = ToolSpec(name="my_tool", description="A tool")
        registry.add(spec)
        assert "my_tool" in registry

    def test_get_existing(self, registry):
        registry.register(search_fn)
        assert registry.get("search_fn").name == "search_fn"

    def test_get_missing_raises(self, registry):
        with pytest.raises(KeyError):
            registry.get("nonexistent")

    def test_find_by_name(self, registry):
        registry.register(search_fn, tags=["search"])
        assert any(t.name == "search_fn" for t in registry.find("search"))

    def test_find_by_tag(self, registry):
        registry.register(search_fn, tags=["web", "search"])
        assert len(registry.find("web")) >= 1

    def test_find_no_match(self, registry):
        registry.register(search_fn)
        assert registry.find("xyz_nonexistent_zzz") == []

    def test_by_tag(self, registry):
        registry.register(search_fn, tags=["web"])
        registry.register(calculator_fn, tags=["math"])
        assert len(registry.by_tag("web")) == 1

    def test_by_category(self, registry):
        registry.register(search_fn, category="research")
        assert len(registry.by_category("research")) == 1

    def test_all_returns_all(self, registry):
        registry.register(search_fn)
        registry.register(calculator_fn)
        assert len(registry.all()) == 2

    def test_names_sorted(self, registry):
        registry.register(search_fn)
        registry.register(calculator_fn)
        names = registry.names()
        assert names == sorted(names)

    def test_to_anthropic_list(self, registry):
        registry.register(search_fn)
        tools = registry.to_anthropic()
        assert len(tools) == 1
        assert tools[0]["name"] == "search_fn"
        assert "input_schema" in tools[0]

    def test_to_openai_list(self, registry):
        registry.register(search_fn)
        tools = registry.to_openai()
        assert tools[0]["type"] == "function"

    def test_to_anthropic_filter(self, registry):
        registry.register(search_fn)
        registry.register(calculator_fn)
        assert len(registry.to_anthropic(names=["search_fn"])) == 1

    def test_call_tool(self, registry):
        @registry.register()
        def add(x: int, y: int) -> int:
            """Add two numbers."""
            return x + y

        assert registry.call("add", x=3, y=4) == 7

    def test_len(self, registry):
        registry.register(search_fn)
        assert len(registry) == 1

    def test_contains(self, registry):
        registry.register(search_fn)
        assert "search_fn" in registry
        assert "missing" not in registry

    def test_repr(self, registry):
        assert "ToolRegistry" in repr(registry)

    def test_auto_infers_param_types(self, registry):
        registry.register(search_fn)
        spec = registry.get("search_fn")
        param_types = {p.name: p.type for p in spec.params}
        assert param_types["query"] == ParamType.STRING
        assert param_types["max_results"] == ParamType.INTEGER

    def test_auto_infers_required(self, registry):
        registry.register(search_fn)
        spec = registry.get("search_fn")
        required = {p.name: p.required for p in spec.params}
        assert required["query"] is True
        assert required["max_results"] is False

    def test_auto_infers_description_from_docstring(self, registry):
        registry.register(search_fn)
        spec = registry.get("search_fn")
        assert "search" in spec.description.lower() or "information" in spec.description.lower()

    def test_anthropic_required_params_in_schema(self, registry):
        registry.register(search_fn)
        fmt = registry.to_anthropic()[0]
        assert "query" in fmt["input_schema"]["required"]
        assert "max_results" not in fmt["input_schema"].get("required", [])
