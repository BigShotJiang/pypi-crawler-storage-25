"""
Notionブロックモデル

ブロックタイプごとにファイルを分割して実装
"""

from typing import Annotated

from pydantic import Field

from .base import ApiColor, BlockType, BaseBlockObject, PartialBlock
from .text_blocks import (
    ParagraphBlock,
    Heading1Block,
    Heading2Block,
    Heading3Block,
    Heading4Block,
    BulletedListItemBlock,
    NumberedListItemBlock,
    QuoteBlock,
    ToDoBlock,
    ToggleBlock,
    TemplateBlock,
)
from .special_blocks import (
    SyncedBlockBlock,
    ChildPageBlock,
    ChildDatabaseBlock,
    EquationBlock,
    CodeBlock,
    CalloutBlock,
    MeetingNotesBlock,
)
from .layout_blocks import (
    DividerBlock,
    BreadcrumbBlock,
    TableOfContentsBlock,
    ColumnListBlock,
    ColumnBlock,
    TabBlock,
    LinkToPageBlock,
    TableBlock,
    TableRowBlock,
)
from .media_blocks import (
    EmbedBlock,
    BookmarkBlock,
    ImageBlock,
    VideoBlock,
    PdfBlock,
    FileBlock,
    AudioBlock,
    LinkPreviewBlock,
)
from .unsupported import UnsupportedBlock

# Union type for all block types with discriminator
BlockObject = Annotated[
    ParagraphBlock
    | Heading1Block
    | Heading2Block
    | Heading3Block
    | Heading4Block
    | BulletedListItemBlock
    | NumberedListItemBlock
    | QuoteBlock
    | ToDoBlock
    | ToggleBlock
    | TemplateBlock
    | SyncedBlockBlock
    | ChildPageBlock
    | ChildDatabaseBlock
    | EquationBlock
    | CodeBlock
    | CalloutBlock
    | MeetingNotesBlock
    | DividerBlock
    | BreadcrumbBlock
    | TableOfContentsBlock
    | ColumnListBlock
    | ColumnBlock
    | TabBlock
    | LinkToPageBlock
    | TableBlock
    | TableRowBlock
    | EmbedBlock
    | BookmarkBlock
    | ImageBlock
    | VideoBlock
    | PdfBlock
    | FileBlock
    | AudioBlock
    | LinkPreviewBlock
    | UnsupportedBlock,
    Field(discriminator="type"),
]

__all__ = [
    # Base
    "ApiColor",
    "BlockType",
    "BaseBlockObject",
    "PartialBlock",
    "BlockObject",
    # Text blocks
    "ParagraphBlock",
    "Heading1Block",
    "Heading2Block",
    "Heading3Block",
    "Heading4Block",
    "BulletedListItemBlock",
    "NumberedListItemBlock",
    "QuoteBlock",
    "ToDoBlock",
    "ToggleBlock",
    "TemplateBlock",
    # Special blocks
    "SyncedBlockBlock",
    "ChildPageBlock",
    "ChildDatabaseBlock",
    "EquationBlock",
    "CodeBlock",
    "CalloutBlock",
    "MeetingNotesBlock",
    # Layout blocks
    "DividerBlock",
    "BreadcrumbBlock",
    "TableOfContentsBlock",
    "ColumnListBlock",
    "ColumnBlock",
    "TabBlock",
    "LinkToPageBlock",
    "TableBlock",
    "TableRowBlock",
    # Media blocks
    "EmbedBlock",
    "BookmarkBlock",
    "ImageBlock",
    "VideoBlock",
    "PdfBlock",
    "FileBlock",
    "AudioBlock",
    "LinkPreviewBlock",
    # Unsupported
    "UnsupportedBlock",
]
