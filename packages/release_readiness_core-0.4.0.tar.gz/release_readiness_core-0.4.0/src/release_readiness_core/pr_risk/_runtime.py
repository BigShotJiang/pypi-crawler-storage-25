"""PR Risk runtime skeleton.

A ``PRRiskRuntime`` carries the loaded ``PRRiskConfig`` plus lazily-compiled
artifacts that Phases 2-4 will use:

- Phase 2: a compiled ``Classifier`` that turns the config's ``domains`` list
  into ``classify_domain(path)`` / ``classify_area(path)`` lookups.
- Phase 3: a gate registry that loops over ``runtime.gates`` evaluating each
  gate's ``applies_when`` predicates.
- Phase 4: an evidence-detector resolver that compiles each gate's
  ``evidence: { template, args }`` block into a callable.

This module ships only the skeleton: ``from_default()`` returns a runtime
whose config mirrors today's hardcoded behavior; ``from_config(path)`` loads
from a YAML file. The classify / gates / detector accessors are stubs that
Phases 2-4 fill in.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from release_readiness_core.pr_risk._classifier import Classifier
from release_readiness_core.pr_risk._config import (
    Gate,
    PRRiskConfig,
    load_pr_risk_config,
)
from release_readiness_core.pr_risk._default_config import default_pr_risk_config


@dataclass
class PRRiskRuntime:
    """Loaded config + lazily-compiled per-runtime artifacts.

    Phase 1 only exposes ``config`` and ``register_detector``. The remaining
    accessors are stubs that raise ``NotImplementedError`` so that any caller
    threading a runtime through before its phase is wired in fails loudly
    rather than silently using stale defaults.
    """

    config: PRRiskConfig
    _classifier: Optional[Classifier] = None
    _custom_detectors: Dict[str, Callable[..., Any]] = field(default_factory=dict)

    @classmethod
    def from_default(cls) -> "PRRiskRuntime":
        """Construct a runtime whose config mirrors today's hardcoded values."""
        return cls(config=default_pr_risk_config())

    @classmethod
    def from_config(cls, path: str | Path) -> "PRRiskRuntime":
        """Construct a runtime from a YAML config file."""
        return cls(config=load_pr_risk_config(path))

    # ------------------------------------------------------------------
    # Phase 2 (classifier).

    @property
    def domains(self) -> List[Any]:
        """Convenience accessor for ``config.domains``."""
        return list(self.config.domains)

    @property
    def sensitive_domains(self) -> List[str]:
        """Convenience accessor for ``config.sensitive_domains``."""
        return list(self.config.sensitive_domains)

    @property
    def classifier(self) -> Classifier:
        """Lazily-compiled config-driven classifier (Phase 2)."""
        if self._classifier is None:
            self._classifier = Classifier(self.config)
        return self._classifier

    def classify_area(self, path: str) -> str:
        """Return the product-area domain id for ``path``. Mirrors the previous
        hardcoded ``classify.classify_area`` semantics — first matching domain
        in declared order wins; ``"other"`` when no domain matches."""
        return self.classifier.classify_area(path)

    def classify(self, path: str) -> str:
        """Return the domain id for ``path`` (with test detection).

        ``is_test_path`` lives in ``classify.py`` because it's a language /
        framework heuristic, not project policy. We import lazily to avoid a
        circular import (``classify.py`` imports this module).
        """
        from release_readiness_core.pr_risk.classify import is_test_path

        if is_test_path(path):
            return "tests"
        return self.classify_area(path)

    # ------------------------------------------------------------------
    # Phase 3 (gate registry).

    @property
    def gates(self) -> List[Gate]:
        """Convenience accessor for ``config.gates``."""
        return list(self.config.gates)

    def priority_for(self, action_id: str) -> str:
        """Return the priority string for a gate id from the loaded config.
        Falls back to ``'medium'`` for unknown ids (matches today's behavior
        in ``actions_priority.priority_for_action_id``)."""
        for g in self.config.gates:
            if g.id == action_id:
                return g.priority
        return "medium"

    # ------------------------------------------------------------------
    # Phase 4 (evidence detectors).

    def detector_for(self, action_id: str) -> Callable[..., Any]:
        """Return the compiled evidence detector callable for a gate id.

        Resolves ``gate.evidence.template`` against the closed-set built-in
        templates first, then the runtime's user-registered overrides
        (``register_detector``). Returns a callable of shape
        ``(label: str, r: Result) -> ValidationEvidence``.
        Raises ``KeyError`` for unknown gate ids and ``ValueError`` for
        gate evidence templates that aren't registered.
        """
        from release_readiness_core.pr_risk._evidence_templates import BUILTIN_TEMPLATES

        for gate in self.config.gates:
            if gate.id != action_id:
                continue
            if gate.evidence is None:
                raise ValueError(
                    f"Gate {action_id!r} has no evidence block; cannot resolve detector"
                )
            template_name = gate.evidence.template
            args = dict(gate.evidence.args or {})
            fn = self._custom_detectors.get(template_name) or BUILTIN_TEMPLATES.get(template_name)
            if fn is None:
                raise ValueError(
                    f"Unknown evidence template {template_name!r} for gate {action_id!r}"
                )
            # Bind action_id and args; the returned callable matches the
            # legacy detector signature (label, r).
            def _bound(label, r, _fn=fn, _id=action_id, _args=args):
                return _fn(_id, label, _args, r)

            return _bound
        raise KeyError(f"No gate with id {action_id!r}")

    def register_detector(self, template_name: str, fn: Callable[..., Any]) -> None:
        """Programmatic escape hatch for adopters who need a custom detector
        template that isn't in the closed set. Phase 4 consumes
        the registered callable. Stored on the runtime instance only."""
        if not isinstance(template_name, str) or not template_name:
            raise ValueError("template_name must be a non-empty string")
        if not callable(fn):
            raise TypeError("fn must be callable")
        self._custom_detectors[template_name] = fn
