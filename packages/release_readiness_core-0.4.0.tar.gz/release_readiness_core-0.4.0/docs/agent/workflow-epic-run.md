# Epic Run Workflow

Source of truth: This file owns epic automation contract, strict gate rules, and halt/resume behavior.

## Commands

Use `epic-run` skill (`.claude/skills/epic-run/SKILL.md`):

- `run epic <EPIC-KEY>`
- `continue epic <EPIC-KEY>`
- `continue epic run for <EPIC-KEY>`

## Contract

- Goal: every child issue is fully implemented, PR-gated, squash-merged to `main`, and transitioned to Done in order.
- In this repo, deployed means code merged to `main` with gate expectations met for that PR.
- A single `continue epic` should drain all remaining work unless halted by policy.

## Epic-vs-Standalone FULL_AUTO

- Standalone FULL_AUTO may merge on `mergeable_state: clean` + PR Gate success.
- Epic mode uses the same merge criteria as standalone FULL_AUTO: merge only when `mergeable_state: clean` and PR Gate check is `success`.

## Parallel Marker Convention

Default execution is sequential. A ticket may run in parallel batch only when:

- Jira label `parallel-ok`, or
- Jira description contains `Parallel: yes`

Consecutive parallel-eligible tickets run as a batch and must resolve before moving on.

## Halt and Resume

Automation HALTs when:

- mergeability/gate polling does not resolve to required pass state in budget, or
- PR Gate completes non-success, mergeability becomes terminally ineligible, or polling budget expires.

Active polling continuity rule (mandatory):

- While a ticket PR is in active gate polling (checks queued/in-progress or mergeable not yet terminal), continue polling; do not stop for checkpoint/progress convenience updates.
- Do not require a user "continue epic" message to resume an in-flight poll loop.
- Only stop polling on terminal outcomes: PASS and merged path, explicit HALT condition, or user interruption.

On resume (`continue epic ...`), agent must re-read Jira children (`statusCategory != Done`) as source of truth and reconcile:

- already Done: skip
- merged but Jira not Done: transition Jira + cleanup
- open PR still non-PASS/non-mergeable: halt again
- open PR now PR-Gate-PASS and mergeable: resume polling and merge
- not started: run `implement <KEY> FULL_AUTO` under epic rules

Git hygiene before next ticket: fetch/checkout/pull `main` so branch starts from current main.

Stale state file rule: if `.epic-run/<EPIC-KEY>.json` exists and not complete, use `continue epic` instead of `run epic`.

