"""End-to-end tests for parts2jitx.

Split into local tests (no network) and network tests (hit LCSC/EasyEDA).
Run with: python tests/test_end_to_end.py [--local-only]
"""

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd: list[str], **kwargs) -> subprocess.CompletedProcess:
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    return result


# ---------------------------------------------------------------------------
# Local tests (no network required)
# ---------------------------------------------------------------------------

def test_kicad_stdin():
    """Convert a minimal KiCad footprint from stdin."""
    print("--- Test: KiCad conversion from stdin ---")
    minimal_fp = '(footprint "TestPart" (pad "1" smd rect (at -1.0 0.0) (size 0.6 1.0) (layers "F.Cu" "F.Paste" "F.Mask")) (pad "2" smd rect (at 1.0 0.0) (size 0.6 1.0) (layers "F.Cu" "F.Paste" "F.Mask")))'

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "TestPart"],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    assert "class TestPart" in result.stdout, "Class not in output"
    assert "Port()" in result.stdout, "No ports"
    assert "jitx.Component" in result.stdout, "Missing jitx.Component"
    assert "BoxSymbol" in result.stdout, "Missing BoxSymbol"

    print(f"  Generated {len(result.stdout)} bytes")
    print("  PASS\n")


def test_kicad_dump_pads():
    """Parse pads from a minimal footprint via --dump-pads."""
    print("--- Test: KiCad --dump-pads ---")
    minimal_fp = '(footprint "TestPart" (pad "1" smd rect (at -1.0 0.0) (size 0.6 1.0) (layers "F.Cu")) (pad "2" smd rect (at 1.0 0.0) (size 0.6 1.0) (layers "F.Cu")))'

    result = run(
        ["parts2jitx-kicad", "--stdin", "--dump-pads"],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"

    data = json.loads(result.stdout)
    pads = data["pads"]
    assert len(pads) == 2, f"Expected 2 pads, got {len(pads)}"
    assert pads[0]["name"] == "1"
    assert pads[1]["name"] == "2"
    assert pads[0]["shape"] == "rect"
    assert pads[0]["x"] == -1.0
    assert pads[1]["x"] == 1.0

    print(f"  Parsed {len(pads)} pads correctly")
    print("  PASS\n")


def test_kicad_file_roundtrip():
    """Write a .kicad_mod to disk, convert to .py, verify output."""
    print("--- Test: KiCad file → JITX file ---")
    fp_content = """(footprint "SOT23_3"
        (pad "1" smd rect (at -0.95 -1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "2" smd rect (at 0.95 -1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "3" smd rect (at 0.0 1.0) (size 0.6 0.7) (layers "F.Cu" "F.Paste" "F.Mask"))
    )"""

    with tempfile.TemporaryDirectory() as tmpdir:
        fp_path = Path(tmpdir) / "sot23.kicad_mod"
        out_path = Path(tmpdir) / "sot23.py"
        fp_path.write_text(fp_content)

        result = run([
            "parts2jitx-kicad", str(fp_path),
            "--class-name", "MyTransistor",
            "--manufacturer", "Nexperia",
            "--mpn", "BC847B",
            "--ref-prefix", "Q",
            "-o", str(out_path),
        ])
        assert result.returncode == 0, f"Failed: {result.stderr}"
        assert out_path.exists(), "Output file not created"

        code = out_path.read_text()
        assert "class MyTransistor(jitx.Component)" in code
        assert 'manufacturer = "Nexperia"' in code
        assert 'mpn = "BC847B"' in code
        assert 'reference_designator_prefix = "Q"' in code
        assert code.count("Port()") == 3, f"Expected 3 ports, got {code.count('Port()')}"

        print(f"  Output: {len(code)} bytes, 3 ports, class MyTransistor")
        print("  PASS\n")


def test_kicad_complex_footprint():
    """Convert a more complex footprint with thermal pad and through-hole."""
    print("--- Test: Complex footprint (thermal pad + thru-hole) ---")
    fp_content = """(footprint "QFN_Example"
        (pad "1" smd rect (at -1.5 -0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "2" smd rect (at -1.5 -0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "3" smd rect (at -1.5 0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "4" smd rect (at -1.5 0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "5" smd rect (at -0.75 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "6" smd rect (at -0.25 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "7" smd rect (at 0.25 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "8" smd rect (at 0.75 1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "9" smd rect (at 1.5 0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "10" smd rect (at 1.5 0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "11" smd rect (at 1.5 -0.25) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "12" smd rect (at 1.5 -0.75) (size 0.25 0.5) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "13" smd rect (at 0.75 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "14" smd rect (at 0.25 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "15" smd rect (at -0.25 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "16" smd rect (at -0.75 -1.5) (size 0.5 0.25) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "17" smd rect (at 0.0 0.0) (size 1.7 1.7) (layers "F.Cu" "F.Paste" "F.Mask"))
    )"""

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "QFN16_EP"],
        input=fp_content,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    code = result.stdout
    assert "class QFN16_EP" in code
    assert code.count("Port()") == 17, f"Expected 17 ports, got {code.count('Port()')}"

    print(f"  Generated {len(code)} bytes, 17 ports (16 signal + 1 thermal)")
    print("  PASS\n")


def test_circular_pad_emits_Circle_class():
    """Regression: circular pads must emit `Circle(radius=R)` and import `Circle`,
    not the non-existent lowercase helper `circle(R)`. Footprints with mounting
    holes or through-hole pin headers were producing uncompilable code.
    """
    print("--- Test: circular pads emit jitx.shapes.primitive.Circle ---")
    fp_content = """(footprint "ConnectorWithMountingHole"
        (pad "1" smd circle (at -1.0 0.0) (size 0.6 0.6) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "2" smd circle (at 1.0 0.0) (size 0.6 0.6) (layers "F.Cu" "F.Paste" "F.Mask"))
        (pad "" np_thru_hole circle (at 0.0 2.0) (size 1.0 1.0) (drill 1.0) (layers "*.Cu"))
    )"""

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "TestConn"],
        input=fp_content,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    code = result.stdout

    # Emitted shape calls must use the Class form Circle(radius=...)
    assert "Circle(radius=" in code, "Generated code must call Circle(radius=...)"
    # The lowercase `circle(` helper does not exist in jitx.shapes — must not appear
    # in generated code (KiCad parser internals are fine; this checks the output).
    for line in code.splitlines():
        # Strip imports and comments to avoid false positives on docstrings.
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith('"""') or "import" in stripped:
            continue
        assert "circle(" not in stripped, (
            f"Generated code must not call lowercase `circle(...)` "
            f"(this helper does not exist in jitx.shapes). Found: {stripped!r}"
        )

    # Import line must reference `Circle` (class), not `circle` (helper).
    assert "from jitx.shapes.primitive import" in code
    import_lines = [l for l in code.splitlines() if "from jitx.shapes.primitive import" in l]
    assert any("Circle" in l for l in import_lines), (
        f"Expected `Circle` in jitx.shapes.primitive import, got: {import_lines}"
    )
    for l in import_lines:
        # Match a bare `circle` token (not Circle, not CircleSomething). Require a word boundary.
        import re
        bad = re.search(r"\bcircle\b", l)
        assert not bad, f"Generated import imports lowercase `circle` (does not exist): {l}"

    # The generated file should be syntactically valid Python.
    import ast
    ast.parse(code)

    print("  PASS\n")


def test_generated_python_escapes_metadata():
    """Code-review HIGH: metadata fields with quotes/backslashes/newlines must
    not break generated Python. Previously `mpn = "foo"bar"` would compile to
    invalid source. Verify the generated file is syntactically valid Python
    after a hostile MPN/manufacturer/description.
    """
    print("--- Test: generated Python escapes string metadata ---")
    import ast
    minimal_fp = '(footprint "T" (pad "1" smd rect (at 0 0) (size 0.6 1.0) (layers "F.Cu" "F.Paste" "F.Mask")))'

    nasty_mpn = 'X"Y\\Z'
    nasty_mfr = "Foo's \"Co.\""
    nasty_desc = 'Line1\nLine2 with "quotes" and \\backslash'

    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "Hostile",
         "--mpn", nasty_mpn, "--manufacturer", nasty_mfr, "--description", nasty_desc],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Failed: {result.stderr}"
    # Must parse as Python
    ast.parse(result.stdout)

    # And the values must round-trip through exec
    ns: dict = {}
    sandbox_src = [
        l for l in result.stdout.splitlines()
        if l.lstrip().startswith(("mpn", "manufacturer"))
    ]
    for line in sandbox_src:
        exec(line.strip(), ns)
    assert ns["mpn"] == nasty_mpn, f"MPN round-trip failed: {ns['mpn']!r}"
    assert ns["manufacturer"] == nasty_mfr, f"Manufacturer round-trip failed: {ns['manufacturer']!r}"

    print("  PASS\n")


def test_lcsc_flag_fatal_without_pinout():
    """Code-review HIGH: --lcsc on a bogus C-ID must exit non-zero by default,
    not silently emit unrenamed pads. Pass --allow-missing-pinout to opt back
    into the soft fallback.
    """
    print("--- Test: --lcsc bogus ID is fatal by default ---")
    minimal_fp = '(footprint "T" (pad "1" smd rect (at 0 0) (size 0.6 1.0) (layers "F.Cu")))'

    # Default: fatal exit.
    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "T", "--lcsc", "C0"],
        input=minimal_fp,
    )
    assert result.returncode != 0, "Expected non-zero exit for missing pinout"
    assert "No pinout from LCSC" in result.stderr, f"stderr: {result.stderr!r}"

    # With --allow-missing-pinout: warning + success + unchanged pads.
    result = run(
        ["parts2jitx-kicad", "--stdin", "--class-name", "T",
         "--lcsc", "C0", "--allow-missing-pinout"],
        input=minimal_fp,
    )
    assert result.returncode == 0, f"Expected success with --allow-missing-pinout: {result.stderr}"
    assert "p1 = Port()" in result.stdout

    print("  PASS\n")


def test_search_empty_keyword_rejected():
    """Code-review MEDIUM: --search with an empty/whitespace keyword should
    error out instead of silently turning search mode off."""
    print("--- Test: --search empty keyword rejected ---")
    result = run(["parts2jitx-lcsc", "--search", ""])
    assert result.returncode != 0
    assert "empty" in result.stderr.lower(), f"stderr: {result.stderr!r}"
    print("  PASS\n")


def test_custom_pad_bbox_per_axis_max():
    """Code-review MEDIUM: custom pads whose primitive bbox is larger in only
    *one* axis must still be emitted at the larger size in that axis (was
    silently downsized to the nominal anchor pad).
    """
    print("--- Test: custom-pad bbox uses per-axis max ---")
    from parts2jitx.kicad_to_jitx import PadInfo, effective_pad_size

    # Nominal anchor pad is 0.6 x 0.6, but the custom primitive is a long
    # rectangle 0.6 x 2.0 — only Y expands.
    pad = PadInfo(
        name="1", pad_type="smd", shape="custom",
        width=0.6, height=0.6,
        custom_bbox=(0.6, 2.0),
    )
    w, h = effective_pad_size(pad)
    assert (w, h) == (0.6, 2.0), f"Expected (0.6, 2.0), got ({w}, {h})"

    # Pad with single-axis X expansion.
    pad_x = PadInfo(
        name="1", pad_type="smd", shape="custom",
        width=0.6, height=0.6,
        custom_bbox=(2.0, 0.6),
    )
    w, h = effective_pad_size(pad_x)
    assert (w, h) == (2.0, 0.6), f"Expected (2.0, 0.6), got ({w}, {h})"

    print("  PASS\n")


def test_drill_offset_emitted():
    """Code-review MEDIUM: KiCad drill offsets must be applied to the emitted
    cutout shape. Previously parsed but silently dropped, producing
    through-hole pads with the drill in the wrong place.
    """
    print("--- Test: drill offsets reach the generated cutout ---")
    fp = (
        '(footprint "OffsetDrill"\n'
        '  (pad "1" thru_hole circle (at 0 0) (size 1.5 1.5)\n'
        '       (drill 0.8 (offset 0.3 -0.2)) (layers "*.Cu" "*.Mask")))'
    )
    result = run(["parts2jitx-kicad", "--stdin", "--class-name", "T"], input=fp)
    assert result.returncode == 0, result.stderr

    # KiCad Y+ down, JITX Y+ up → -(-0.2) = 0.2
    assert ".at(0.3, 0.2)" in result.stdout, (
        f"Expected drill offset .at(0.3, 0.2) in generated cutout; got:\n{result.stdout}"
    )

    import ast
    ast.parse(result.stdout)
    print("  PASS\n")


def test_parser_decodes_escapes():
    """Code-review MEDIUM: tokenizer must decode `\\\"` → `\"` and `\\\\` → `\\`
    inside quoted strings, not preserve the raw backslash escape.
    """
    print("--- Test: S-expression parser decodes escapes ---")
    from parts2jitx.kicad_to_jitx import parse_kicad_mod

    src = r'(footprint "name with \"quotes\" and \\backslash" (pad "1" smd rect (at 0 0) (size 1 1) (layers "F.Cu")))'
    parsed = parse_kicad_mod(src)
    assert parsed[1] == 'name with "quotes" and \\backslash', f"Got: {parsed[1]!r}"
    print("  PASS\n")


def test_parser_rejects_malformed():
    """Code-review MEDIUM: parser must raise on unclosed lists, unterminated
    quotes, and trailing tokens — silently returning partial output produced
    incorrect codegen for malformed footprints.
    """
    print("--- Test: S-expression parser rejects malformed input ---")
    from parts2jitx.kicad_to_jitx import parse_kicad_mod

    cases = [
        ("(footprint", "unclosed list"),
        ('(footprint "unterminated', "unterminated quote"),
        ("(footprint) (extra)", "trailing tokens"),
        ("", "empty input"),
    ]
    for src, label in cases:
        try:
            parse_kicad_mod(src)
            raise AssertionError(f"Expected ValueError for {label}: {src!r}")
        except ValueError:
            pass
    print("  PASS\n")


def test_rename_pads_normalization():
    """Code-review MEDIUM: rename_pads_from_pinout should be tolerant of case
    and whitespace mismatches and absorb leading zeros for numeric keys.
    """
    print("--- Test: rename_pads_from_pinout normalization ---")
    from parts2jitx.kicad_to_jitx import PadInfo, rename_pads_from_pinout

    pads = [
        PadInfo(name="01", pad_type="smd", shape="rect"),   # leading zero
        PadInfo(name=" 2 ", pad_type="smd", shape="rect"),  # whitespace
        PadInfo(name="a1", pad_type="smd", shape="rect"),   # case
    ]
    pinout = [
        {"number": "1", "name": "VDD"},
        {"number": "2", "name": "GND"},
        {"number": "A1", "name": "BALL_A1"},
    ]
    renamed = rename_pads_from_pinout(pads, pinout)
    assert renamed == 3, f"Expected 3, got {renamed}"
    assert pads[0].name == "VDD"
    assert pads[1].name == "GND"
    assert pads[2].name == "BALL_A1"

    print("  PASS\n")


def test_python_import():
    """Verify the package imports correctly."""
    print("--- Test: Python import ---")
    from parts2jitx import __version__
    from parts2jitx.lcsc_lookup import lcsc_stock, get_footprint, get_pinout, lcsc_search
    from parts2jitx.kicad_to_jitx import parse_kicad_mod, extract_pads, rename_pads_from_pinout

    assert __version__ == "0.2.0"
    assert callable(lcsc_stock)
    assert callable(get_footprint)
    assert callable(get_pinout)
    assert callable(lcsc_search)
    assert callable(parse_kicad_mod)
    assert callable(extract_pads)
    assert callable(rename_pads_from_pinout)

    print(f"  Version: {__version__}")
    print("  All public functions importable")
    print("  PASS\n")


def test_rename_pads_from_pinout():
    """Bug #3: --lcsc rewrites KiCad pad numbers to functional pin names.

    rename_pads_from_pinout() is the unit underlying the --lcsc flag.
    Pads whose KiCad name matches a pinout 'number' get renamed; pads
    without a match keep their original name (e.g. unnamed NPTH holes).
    """
    print("--- Test: rename_pads_from_pinout ---")
    from parts2jitx.kicad_to_jitx import PadInfo, rename_pads_from_pinout

    pads = [
        PadInfo(name="1", pad_type="smd", shape="rect"),
        PadInfo(name="2", pad_type="smd", shape="rect"),
        PadInfo(name="3", pad_type="smd", shape="rect"),
        PadInfo(name="", pad_type="np_thru_hole", shape="circle"),
    ]
    pinout = [
        {"number": "1", "name": "VBUS", "type": "power"},
        {"number": "2", "name": "GND", "type": "power"},
        {"number": "3", "name": "GND", "type": "power"},
    ]
    renamed = rename_pads_from_pinout(pads, pinout)
    assert renamed == 3, f"Expected 3 renames, got {renamed}"
    assert pads[0].name == "VBUS"
    assert pads[1].name == "GND"
    assert pads[2].name == "GND"  # duplicate name → will become array port at group stage
    assert pads[3].name == ""  # NPTH stays unnamed

    print("  PASS\n")


def test_pinout_json_serializable():
    """Bug #2: get_pinout() result must be JSON-serializable.

    Real pin types come from `EasyedaPinType`, a Python enum. The function
    must coerce these to a string so `json.dump` works (the user-facing
    crash was `TypeError: Object of type EasyedaPinType is not JSON serializable`).
    We test the contract without a network call by constructing a minimal
    object graph that matches what easyeda2kicad produces.
    """
    print("--- Test: get_pinout JSON serializable ---")
    import enum
    from unittest.mock import patch, MagicMock

    class FakePinType(enum.Enum):
        _input = 1
        power = 4

    pin = MagicMock()
    pin.name.text = "VDD"
    pin.settings.spice_pin_number = "1"
    pin.settings.type = FakePinType.power

    symbol = MagicMock()
    symbol.pins = [pin]

    fake_importer = MagicMock()
    fake_importer.get_symbol.return_value = symbol

    fake_api = MagicMock()
    fake_api.get_cad_data_of_component.return_value = {"some": "data"}

    with patch("easyeda2kicad.easyeda.easyeda_api.EasyedaApi", return_value=fake_api), \
         patch("easyeda2kicad.easyeda.easyeda_importer.EasyedaSymbolImporter",
               return_value=fake_importer):
        from parts2jitx.lcsc_lookup import get_pinout
        pins = get_pinout("C123")

    assert pins is not None and len(pins) == 1
    # Critical: this is what the bug was — must serialize without error.
    json.dumps(pins)
    assert pins[0]["type"] == "power", f"Expected 'power', got {pins[0]['type']!r}"

    print("  PASS\n")


# ---------------------------------------------------------------------------
# Network tests (require LCSC API access)
# ---------------------------------------------------------------------------

def test_lcsc_stock_lookup():
    """LCSC stock/pricing lookup."""
    print("--- Test: LCSC stock lookup (C165948) ---")
    result = run(["parts2jitx-lcsc", "C165948", "--json"])
    assert result.returncode == 0, f"Failed: {result.stderr}"

    data = json.loads(result.stdout)
    stock = data["stock"]

    assert stock["lcsc"] == "C165948"
    assert stock["mpn"], "Missing MPN"
    assert stock["manufacturer"], "Missing manufacturer"
    assert isinstance(stock["stock"], (int, float))
    assert len(stock["prices"]) > 0, "No pricing data"

    print(f"  Part: {stock['mpn']} ({stock['manufacturer']})")
    print(f"  Stock: {stock['stock']:,}")
    print(f"  Price: ${stock['prices'][0]['price_usd']:.4f}")
    print("  PASS\n")


def test_lcsc_footprint_download():
    """KiCad footprint download from LCSC/EasyEDA."""
    print("--- Test: LCSC footprint download (C165948) ---")
    with tempfile.TemporaryDirectory() as tmpdir:
        outpath = Path(tmpdir) / "test.kicad_mod"
        result = run(["parts2jitx-lcsc", "C165948", "--footprint", "-o", str(outpath)])
        assert result.returncode == 0, f"Failed: {result.stderr}"
        assert outpath.exists(), "Footprint file not created"

        content = outpath.read_text()
        assert "(pad " in content, "No pads found in footprint"

        print(f"  File: {len(content)} bytes, {content.count('(pad ')} pads")
        print("  PASS\n")


def test_full_pipeline():
    """Full pipeline: LCSC download → KiCad → JITX conversion."""
    print("--- Test: Full pipeline (C165948) ---")
    with tempfile.TemporaryDirectory() as tmpdir:
        fp_path = Path(tmpdir) / "usb_c.kicad_mod"
        result = run(["parts2jitx-lcsc", "C165948", "--footprint", "-o", str(fp_path)])
        assert result.returncode == 0, f"Download failed: {result.stderr}"
        assert fp_path.exists(), "Footprint not created"

        out_path = Path(tmpdir) / "usb_c.py"
        result = run([
            "parts2jitx-kicad", str(fp_path),
            "--class-name", "USB_C_16P",
            "--manufacturer", "Korean Hroparts Elec",
            "--mpn", "TYPE-C-31-M-12",
            "-o", str(out_path),
        ])
        assert result.returncode == 0, f"Conversion failed: {result.stderr}"

        code = out_path.read_text()
        assert "class USB_C_16P" in code
        assert "jitx.Component" in code
        assert "Port()" in code
        assert 'mpn = "TYPE-C-31-M-12"' in code

        print(f"  Output: {len(code)} bytes, {code.count('Port()')} ports")
        print("  PASS\n")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    local_only = "--local-only" in sys.argv

    local_tests = [
        test_python_import,
        test_kicad_stdin,
        test_kicad_dump_pads,
        test_kicad_file_roundtrip,
        test_kicad_complex_footprint,
        test_circular_pad_emits_Circle_class,
        test_rename_pads_from_pinout,
        test_rename_pads_normalization,
        test_pinout_json_serializable,
        test_generated_python_escapes_metadata,
        test_lcsc_flag_fatal_without_pinout,
        test_search_empty_keyword_rejected,
        test_parser_decodes_escapes,
        test_parser_rejects_malformed,
        test_custom_pad_bbox_per_axis_max,
        test_drill_offset_emitted,
    ]

    network_tests = [
        test_lcsc_stock_lookup,
        test_lcsc_footprint_download,
        test_full_pipeline,
    ]

    tests = local_tests if local_only else local_tests + network_tests

    if local_only:
        print("Running local tests only (no network)\n")
    else:
        print("Running all tests (local + network)\n")

    passed = 0
    failed = 0
    skipped_network = 0

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            err = str(e)
            # If a network test fails due to connectivity, mark as skip not fail
            if test in network_tests and ("403" in err or "timeout" in err.lower()
                    or "connection" in err.lower() or "not created" in err.lower()
                    or "No pins" in err):
                print(f"  SKIP (network unavailable): {e}\n")
                skipped_network += 1
            else:
                print(f"  FAIL: {e}\n")
                failed += 1

    print(f"{'='*40}")
    parts = [f"{passed} passed"]
    if failed:
        parts.append(f"{failed} failed")
    if skipped_network:
        parts.append(f"{skipped_network} skipped (network)")
    print(f"Results: {', '.join(parts)}")

    if failed:
        sys.exit(1)
    print("All tests passed!" if not skipped_network else "All reachable tests passed!")
