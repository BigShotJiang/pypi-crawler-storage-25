#!/usr/bin/env python3
"""Look up LCSC/JLCPCB parts: stock, pricing, datasheet, and KiCad footprint.

Uses easyeda2kicad (pip install easyeda2kicad) for footprint/symbol data
and the LCSC public API for real-time stock and pricing.

Usage:
    # Check stock and pricing
    python lcsc_lookup.py C165948

    # Download KiCad footprint
    python lcsc_lookup.py C165948 --footprint -o usb_c.kicad_mod

    # Get pinout data
    python lcsc_lookup.py C165948 --pinout

    # Full pipeline: lookup + footprint + convert to JITX
    python lcsc_lookup.py C165948 --footprint -o usb_c.kicad_mod && \\
        python kicad_to_jitx.py usb_c.kicad_mod --class-name USB_C_16P

    # All info at once
    python lcsc_lookup.py C165948 --all -o usb_c.kicad_mod

Setup:
    pip install easyeda2kicad requests
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

try:
    import requests
except ImportError:
    print("Error: 'requests' package required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# LCSC Stock/Price API (real-time, no auth)
# ---------------------------------------------------------------------------

LCSC_DETAIL_URL = "https://wmsc.lcsc.com/ftps/wm/product/detail"


def lcsc_stock(lcsc_id: str) -> dict | None:
    """Fetch real-time stock and pricing from LCSC.

    Returns dict with: mpn, manufacturer, description, stock, prices,
    datasheet_url, package, category. Returns None on failure.
    """
    try:
        resp = requests.get(
            LCSC_DETAIL_URL,
            params={"productCode": lcsc_id},
            headers={"User-Agent": "jitx-skill/1.0"},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, ValueError) as e:
        # Narrow: connection/timeout/HTTP-status (RequestException) or malformed
        # JSON (ValueError covers requests.exceptions.JSONDecodeError on
        # older/newer requests versions). Anything else surfaces as a bug.
        print(f"LCSC API error ({type(e).__name__}): {e}", file=sys.stderr)
        return None

    result = data.get("result")
    if not result:
        return None

    # Extract pricing tiers
    prices = []
    for tier in result.get("productPriceList", []):
        try:
            price = float(tier.get("productPrice", 0))
        except (ValueError, TypeError):
            price = 0.0
        prices.append({
            "qty": tier.get("startPurchasedNumber", 0),
            "price_usd": price,
        })

    return {
        "lcsc": lcsc_id,
        "mpn": result.get("productModel", ""),
        "manufacturer": result.get("brandNameEn", ""),
        "description": result.get("productIntroEn", ""),
        "stock": result.get("stockNumber", 0),
        "stock_domestic": result.get("stockSz", 0),
        "stock_overseas": result.get("stockJs", 0),
        "prices": prices,
        "datasheet_url": result.get("pdfUrl", ""),
        "package": result.get("encapStandard", ""),
        "category": result.get("parentCatalogName", ""),
        "min_qty": result.get("minBuyNumber", 1),
        "product_url": f"https://www.lcsc.com/product-detail/{lcsc_id}.html",
    }


# ---------------------------------------------------------------------------
# EasyEDA footprint/symbol via easyeda2kicad
# ---------------------------------------------------------------------------

def get_footprint(lcsc_id: str, output_path: str | None = None) -> str | None:
    """Download KiCad footprint for an LCSC part.

    Returns the .kicad_mod content as a string, or None on failure.
    Optionally writes to output_path.
    """
    try:
        from easyeda2kicad.easyeda.easyeda_api import EasyedaApi
        from easyeda2kicad.easyeda.easyeda_importer import EasyedaFootprintImporter
        from easyeda2kicad.kicad.export_kicad_footprint import ExporterFootprintKicad
    except ImportError:
        print("Error: 'easyeda2kicad' package required. Run: pip install easyeda2kicad", file=sys.stderr)
        return None

    try:
        api = EasyedaApi()
        cad_data = api.get_cad_data_of_component(lcsc_id=lcsc_id)
        if not cad_data:
            print(f"No CAD data found for {lcsc_id}", file=sys.stderr)
            return None

        fp_importer = EasyedaFootprintImporter(easyeda_cp_cad_data=cad_data)
        fp = fp_importer.get_footprint()
        exporter = ExporterFootprintKicad(footprint=fp)

        if output_path:
            outpath = Path(output_path)
            outpath.parent.mkdir(parents=True, exist_ok=True)
            exporter.export(
                footprint_full_path=str(outpath),
                model_3d_path=str(outpath.parent / "3d"),
            )
            return outpath.read_text()
        else:
            import tempfile
            with tempfile.TemporaryDirectory(prefix="parts2jitx-fp-") as tmpdir:
                tmp_path = str(Path(tmpdir) / "footprint.kicad_mod")
                exporter.export(
                    footprint_full_path=tmp_path,
                    model_3d_path=str(Path(tmpdir) / "3d"),
                )
                return Path(tmp_path).read_text()

    except (OSError, ValueError, KeyError, AttributeError, TypeError) as e:
        # easyeda2kicad already handles URLError/JSONDecodeError internally and
        # returns falsy cad_data; what reaches us is file IO failures (OSError),
        # parsing failures (ValueError), or schema drift in the EasyEDA payload
        # (Key/Attribute/TypeError). Unknown exception classes propagate so
        # bugs aren't silently swallowed.
        print(f"Footprint error ({type(e).__name__}): {e}", file=sys.stderr)
        return None


def get_pinout(lcsc_id: str) -> list[dict] | None:
    """Get pin names and numbers from EasyEDA symbol data.

    Returns list of {name, number, type} dicts, or None on failure.
    """
    try:
        from easyeda2kicad.easyeda.easyeda_api import EasyedaApi
        from easyeda2kicad.easyeda.easyeda_importer import EasyedaSymbolImporter
    except ImportError:
        print("Error: 'easyeda2kicad' package required. Run: pip install easyeda2kicad", file=sys.stderr)
        return None

    try:
        api = EasyedaApi()
        cad_data = api.get_cad_data_of_component(lcsc_id=lcsc_id)
        if not cad_data:
            return None

        sym_importer = EasyedaSymbolImporter(easyeda_cp_cad_data=cad_data)
        symbol = sym_importer.get_symbol()

        pins = []
        for pin in symbol.pins:
            raw_type = getattr(pin.settings, "type", "unspecified")
            # EasyedaPinType is an enum; .name keeps the field name (e.g. "_input")
            # which json.dump can serialize. Fall back to str() for plain strings.
            type_name = getattr(raw_type, "name", None) or str(raw_type)
            # Coerce everything to plain str — downstream code (CLI format spec
            # `:>6s`, JSON dump, rename matching) all assume strings.
            pins.append({
                "name": str(pin.name.text),
                "number": str(pin.settings.spice_pin_number),
                "type": str(type_name),
            })
        return pins

    except (OSError, ValueError, KeyError, AttributeError, TypeError) as e:
        # See get_footprint() for rationale on the narrowed exception set.
        print(f"Pinout error ({type(e).__name__}): {e}", file=sys.stderr)
        return None


def lcsc_search(
    keyword: str,
    page: int = 1,
    page_size: int = 10,
    part_type: str | None = None,
) -> dict | None:
    """Search the JLCPCB parts library by keyword / MPN.

    Wraps `easyeda2kicad.easyeda_api.EasyedaApi.search_jlcpcb_components`.

    Args:
        keyword: MPN, manufacturer, or other text to search for.
        page: 1-based page index.
        page_size: results per page (JLCPCB caps the effective max).
        part_type: "base" for Basic parts, "expand" for Extended, None for all.

    Returns:
        Dict with keys `total` (int) and `results` (list of part dicts), or None
        if the dependency is missing.
    """
    try:
        from easyeda2kicad.easyeda.easyeda_api import EasyedaApi
    except ImportError:
        print("Error: 'easyeda2kicad' package required. Run: pip install easyeda2kicad", file=sys.stderr)
        return None

    try:
        api = EasyedaApi()
        return api.search_jlcpcb_components(
            keyword=keyword,
            page=page,
            page_size=page_size,
            part_type=part_type,
        )
    except (OSError, ValueError, KeyError, AttributeError, TypeError) as e:
        # easyeda2kicad's search_jlcpcb_components already normalizes URL/JSON
        # failures to an empty result set; what can still escape is dependency
        # API drift (Key/Attribute/TypeError) or local IO.
        print(f"Search error ({type(e).__name__}): {e}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Look up LCSC/JLCPCB parts: stock, pricing, and KiCad footprint.",
    )
    parser.add_argument(
        "lcsc_id",
        nargs="?",
        help="LCSC part code (e.g., C165948, C8734). Omit when using --search.",
    )
    parser.add_argument("--footprint", action="store_true", help="Download KiCad footprint")
    parser.add_argument("--pinout", action="store_true", help="Get pin names and numbers")
    parser.add_argument("--all", action="store_true", help="Stock + footprint + pinout")
    parser.add_argument("-o", "--output", help="Output path for .kicad_mod file")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument(
        "--search",
        metavar="KEYWORD",
        help="Search JLCPCB by keyword / MPN. Returns LCSC IDs, stock, type.",
    )
    parser.add_argument("--page", type=int, default=1, help="Search page (default: 1)")
    parser.add_argument(
        "--page-size",
        type=int,
        default=10,
        help="Search results per page (default: 10)",
    )
    parser.add_argument(
        "--basic-only",
        action="store_true",
        help="Restrict --search to JLCPCB Basic parts.",
    )
    args = parser.parse_args()

    # Search mode: no LCSC ID required.
    if args.search is not None:
        keyword = args.search.strip()
        if not keyword:
            parser.error("--search keyword cannot be empty.")
        if args.lcsc_id:
            parser.error("--search is mutually exclusive with a positional LCSC ID.")
        if args.page < 1:
            parser.error("--page must be >= 1.")
        if args.page_size < 1:
            parser.error("--page-size must be >= 1.")
        part_type = "base" if args.basic_only else None
        data = lcsc_search(
            keyword=keyword,
            page=args.page,
            page_size=args.page_size,
            part_type=part_type,
        )
        if data is None:
            sys.exit(1)
        results = data.get("results", [])
        total = data.get("total", 0)
        # Empty results are a failure in either output mode — easyeda2kicad
        # normalizes API/network errors to an empty list, so silent exit-0 here
        # masks transport failures.
        empty = not results
        if args.json:
            json.dump(data, sys.stdout, indent=2)
            print()
        else:
            if empty:
                print(f"No results for {keyword!r}.", file=sys.stderr)
            else:
                print(f"{total} total matches; showing page {args.page} ({len(results)}):\n")
                for r in results:
                    price = r.get("price")
                    price_str = f"${price:.4f}" if isinstance(price, (int, float)) else "—"
                    print(
                        f"  {r.get('lcsc', ''):<10} {r.get('model', ''):<24} "
                        f"{r.get('brand', ''):<20} stock={r.get('stock', 0):<8} "
                        f"{r.get('type', '')} {price_str}"
                    )
        if empty:
            sys.exit(1)
        return

    if not args.lcsc_id:
        parser.error("LCSC ID is required unless --search is used.")

    lcsc_id = args.lcsc_id.upper()
    if not lcsc_id.startswith("C"):
        lcsc_id = "C" + lcsc_id

    do_footprint = args.footprint or args.all
    do_pinout = args.pinout or args.all

    result = {}
    had_failure = False

    # Stock/pricing (always)
    t0 = time.time()
    stock_data = lcsc_stock(lcsc_id)
    stock_time = time.time() - t0

    if stock_data:
        result["stock"] = stock_data
        if not args.json:
            s = stock_data
            print(f"{'Part:':<14} {s['mpn']} ({s['manufacturer']})")
            print(f"{'LCSC:':<14} {s['lcsc']}")
            print(f"{'Package:':<14} {s['package']}")
            print(f"{'Stock:':<14} {s['stock']:,}")
            print(f"{'Description:':<14} {s['description'][:80]}")
            if s["prices"]:
                p1 = s["prices"][0]
                print(f"{'Price:':<14} ${p1['price_usd']:.4f} (qty {p1['qty']}+)")
            if s["datasheet_url"]:
                print(f"{'Datasheet:':<14} {s['datasheet_url']}")
            print(f"{'Lookup:':<14} {stock_time:.2f}s")
    else:
        print(f"Part {lcsc_id} not found on LCSC", file=sys.stderr)
        had_failure = True
        if not do_footprint and not do_pinout:
            sys.exit(1)

    # Footprint
    if do_footprint:
        print(f"\nDownloading footprint...", file=sys.stderr)
        t0 = time.time()
        fp_content = get_footprint(lcsc_id, args.output)
        fp_time = time.time() - t0

        if fp_content:
            result["footprint_path"] = args.output or "(stdout)"
            result["footprint_size"] = len(fp_content)
            if not args.json:
                if args.output:
                    print(f"{'Footprint:':<14} {args.output} ({len(fp_content)} bytes, {fp_time:.2f}s)")
                else:
                    print(f"\n--- KiCad Footprint ({fp_time:.2f}s) ---")
                    print(fp_content)
        else:
            print(f"Failed to download footprint for {lcsc_id}", file=sys.stderr)
            had_failure = True

    # Pinout
    if do_pinout:
        t0 = time.time()
        pins = get_pinout(lcsc_id)
        pin_time = time.time() - t0

        if pins:
            result["pins"] = pins
            if not args.json:
                print(f"\n{'Pinout:':<14} {len(pins)} pins ({pin_time:.2f}s)")
                for pin in pins:
                    print(f"  {pin['number']:>6s}  {pin['name']}")
        else:
            print(f"Failed to get pinout for {lcsc_id}", file=sys.stderr)
            had_failure = True

    if args.json:
        json.dump(result, sys.stdout, indent=2)
        print()

    if had_failure:
        sys.exit(1)


if __name__ == "__main__":
    main()
