"""Kitty Bridge — launch coding agents through a local API bridge."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "1.0.2"
__all__ = ["__version__"]
