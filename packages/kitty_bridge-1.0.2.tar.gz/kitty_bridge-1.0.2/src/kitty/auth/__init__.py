"""OpenAI subscription OAuth authentication."""
