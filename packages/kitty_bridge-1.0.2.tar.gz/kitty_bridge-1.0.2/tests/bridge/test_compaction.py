"""Tests for context compaction in BridgeServer.

Tests verify that _compact_messages correctly prunes large conversation
histories to prevent 400 "context too large" errors from upstream providers.
"""

import json

from kitty.bridge.server import (
    _COMPACTION_GUARANTEED_MESSAGES_MAX,
    _MAX_REQUEST_CHARS,
    BridgeServer,
)
from kitty.launchers.base import LauncherAdapter, SpawnConfig
from kitty.profiles.schema import Profile
from kitty.providers.base import ProviderAdapter
from kitty.providers.model_context import DEFAULT_CONTEXT_TOKENS, tokens_to_chars
from kitty.types import BridgeProtocol

# ── Stub adapters for testing ───────────────────────────────────────────────


class StubLauncher(LauncherAdapter):
    def __init__(self, protocol: BridgeProtocol = BridgeProtocol.MESSAGES_API):
        self._protocol = protocol

    @property
    def name(self) -> str:
        return "stub"

    @property
    def binary_name(self) -> str:
        return "stub"

    @property
    def bridge_protocol(self) -> BridgeProtocol:
        return self._protocol

    def build_spawn_config(self, profile: Profile, bridge_port: int, resolved_key: str) -> SpawnConfig:
        return SpawnConfig(env_overrides={}, env_clear=[], cli_args=[])


class StubProvider(ProviderAdapter):
    @property
    def provider_type(self) -> str:
        return "stub"

    @property
    def default_base_url(self) -> str:
        return "https://api.example.com/v1"

    def build_request(self, model: str, messages: list[dict], **kwargs) -> dict:
        return {"model": model, "messages": messages, "stream": kwargs.get("stream", False)}

    def parse_response(self, response_data: dict) -> dict:
        return response_data

    def map_error(self, status_code: int, body: dict) -> Exception:
        return Exception(f"Upstream error {status_code}: {body}")


def _make_server() -> BridgeServer:
    adapter = StubLauncher()
    provider = StubProvider()
    return BridgeServer(adapter, provider, "test-key")


# ── Helpers ─────────────────────────────────────────────────────────────────


def _make_messages(n: int, start_idx: int = 0) -> list[dict]:
    """Create n alternating user/assistant messages."""
    msgs = []
    for i in range(start_idx, start_idx + n):
        role = "user" if i % 2 == 0 else "assistant"
        msgs.append({"role": role, "content": f"Message {i}"})
    return msgs


def _make_tool_call_block(call_id: str, tool_name: str, result_content: str) -> list[dict]:
    """Create an atomic tool_call + tool_result block."""
    return [
        {
            "role": "assistant",
            "content": None,
            "tool_calls": [{"id": call_id, "type": "function", "function": {"name": tool_name, "arguments": "{}"}}],
        },
        {
            "role": "tool",
            "content": result_content,
            "tool_call_id": call_id,
        },
    ]


def _char_size(messages: list[dict]) -> int:
    """Estimate serialized character size of messages list."""
    return len(json.dumps(messages, ensure_ascii=False))


def _make_large_messages(count: int, content_multiplier: int = 2000) -> list[dict]:
    """Create messages large enough to exceed the 2.8M char compaction threshold."""
    messages = [{"role": "system", "content": "System"}]
    for i in range(count):
        role = "user" if i % 2 == 0 else "assistant"
        messages.append({"role": role, "content": f"Message {i} " * content_multiplier})
    return messages


# ── Tests ───────────────────────────────────────────────────────────────────


class TestCompactMessagesBelowThreshold:
    """When messages are below the compaction threshold, nothing should change."""

    def test_short_history_unchanged(self):
        server = _make_server()
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        original = json.dumps(messages, ensure_ascii=False)

        result = server._compact_messages(messages.copy())

        assert json.dumps(result, ensure_ascii=False) == original

    def test_empty_messages_unchanged(self):
        server = _make_server()
        result = server._compact_messages([])
        assert result == []


class TestCompactMessagesPreservesCriticalMessages:
    """System message and last user message must always be preserved."""

    def test_system_message_always_preserved(self):
        server = _make_server()
        system_msg = {"role": "system", "content": "Critical system prompt " * 1000}
        # Build a large message list that exceeds threshold
        messages = [system_msg] + _make_messages(100)

        result = server._compact_messages(messages.copy())

        # System message must be first
        assert result[0]["role"] == "system"
        assert result[0]["content"] == system_msg["content"]

    def test_oversized_system_message_still_preserved(self):
        """System message must be preserved even if it exceeds head_budget alone."""
        server = _make_server()
        # System prompt > 560K chars (20% of 2.8M threshold)
        huge_system = {"role": "system", "content": "S" * 600_000}
        messages = [huge_system]
        for i in range(120):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Message {i} " * 2000})

        assert _char_size(messages) > 2_800_000

        result = server._compact_messages(messages.copy())

        # System message must survive even though it's larger than head_budget
        assert result[0]["role"] == "system"
        assert len(result[0]["content"]) == 600_000

    def test_last_user_message_preserved(self):
        server = _make_server()
        last_user = {"role": "user", "content": "This is the critical last question"}
        messages = _make_messages(100) + [last_user]

        result = server._compact_messages(messages.copy())

        # Find the last user message in result
        user_msgs = [m for m in result if m["role"] == "user"]
        assert any(m["content"] == "This is the critical last question" for m in user_msgs)

    def test_system_and_last_user_both_preserved(self):
        server = _make_server()
        system_msg = {"role": "system", "content": "System prompt"}
        last_user = {"role": "user", "content": "Final question"}
        messages = [system_msg] + _make_messages(100) + [last_user]

        result = server._compact_messages(messages.copy())

        assert result[0]["role"] == "system"
        assert result[0]["content"] == "System prompt"
        user_msgs = [m for m in result if m["role"] == "user"]
        assert any(m["content"] == "Final question" for m in user_msgs)


class TestCompactMessagesHeadTail:
    """Head+Tail compaction: keep head (system+initial) and tail (recent)."""

    def test_reduces_message_count(self):
        server = _make_server()
        messages = _make_large_messages(200)

        original_size = _char_size(messages)
        assert original_size > 2_800_000, f"Test data too small: {original_size}"

        result = server._compact_messages(messages.copy())
        result_size = _char_size(result)

        assert result_size < original_size
        assert len(result) < len(messages)

    def test_head_preserves_initial_context(self):
        server = _make_server()
        system_msg = {"role": "system", "content": "System"}
        first_user = {"role": "user", "content": "This is my initial task description " * 100}

        messages = [system_msg, first_user] + _make_messages(200, start_idx=2)
        # Make messages large enough to trigger compaction
        for m in messages[2:]:
            m["content"] = m["content"] + " " * 2000

        result = server._compact_messages(messages.copy())

        # First two messages (system + first user) should be preserved
        assert result[0]["role"] == "system"
        assert result[1]["content"].startswith("This is my initial task description")

    def test_tail_preserves_recent_messages(self):
        server = _make_server()
        recent_messages = [
            {"role": "user", "content": "Recent question 1"},
            {"role": "assistant", "content": "Recent answer 1"},
            {"role": "user", "content": "Recent question 2"},
            {"role": "assistant", "content": "Recent answer 2"},
        ]
        messages = [{"role": "system", "content": "System"}]
        for i in range(150):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Old message {i} " * 300})
        messages.extend(recent_messages)

        result = server._compact_messages(messages.copy())

        # Last 4 messages should match the recent_messages
        for rm, actual in zip(recent_messages, result[-4:], strict=True):
            assert actual["content"] == rm["content"]


class TestCompactMessagesToolResultTruncation:
    """Large tool results should be truncated to save space."""

    def test_large_tool_result_truncated(self):
        server = _make_server()
        large_content = "X" * 100_000

        # Build messages large enough to exceed compaction threshold
        messages = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "Do something"},
            {
                "role": "assistant",
                "content": "Let me check",
                "tool_calls": [
                    {"id": "call_123", "type": "function", "function": {"name": "read_file", "arguments": "{}"}}
                ],
            },
            {
                "role": "tool",
                "content": large_content,
                "tool_call_id": "call_123",
            },
        ]
        # Add filler to push total over the 2.8M threshold
        for i in range(50):
            messages.append({"role": "user" if i % 2 == 0 else "assistant", "content": "Filler " * 10000})

        assert _char_size(messages) > 2_800_000

        result = server._compact_messages(messages.copy())

        # The tool result should be truncated
        tool_results = [m for m in result if m["role"] == "tool"]
        assert len(tool_results) == 1
        assert len(tool_results[0]["content"]) < 100_000
        assert "truncated" in tool_results[0]["content"].lower()
        assert "original size" in tool_results[0]["content"].lower()

    def test_truncation_preserves_tool_call_id(self):
        server = _make_server()
        large_content = "Y" * 100_000
        tool_msg = {
            "role": "tool",
            "content": large_content,
            "tool_call_id": "call_abc_456",
        }

        messages = [{"role": "system", "content": "System"}, tool_msg]
        for i in range(50):
            messages.append({"role": "user" if i % 2 == 0 else "assistant", "content": "Filler " * 10000})

        result = server._compact_messages(messages.copy())

        tool_results = [m for m in result if m["role"] == "tool"]
        assert len(tool_results) == 1
        assert tool_results[0]["tool_call_id"] == "call_abc_456"

    def test_small_tool_result_unchanged(self):
        server = _make_server()
        small_content = "File contents here"
        tool_msg = {
            "role": "tool",
            "content": small_content,
            "tool_call_id": "call_123",
        }

        messages = [
            {"role": "system", "content": "System"},
            tool_msg,
        ]

        result = server._compact_messages(messages.copy())

        tool_results = [m for m in result if m["role"] == "tool"]
        assert tool_results[0]["content"] == small_content


class TestCompactMessagesToolCallAtomicity:
    """Tool-call + tool-result pairs must never be split by pruning."""

    def test_tool_call_result_pair_kept_together_in_tail(self):
        """If a tool result is in the tail, its assistant tool_call must also be there."""
        server = _make_server()
        block = _make_tool_call_block("call_tail", "read_file", "File content here")

        messages = [{"role": "system", "content": "System"}]
        for i in range(200):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Filler {i} " * 2000})
        messages.extend(block)

        assert _char_size(messages) > 2_800_000

        result = server._compact_messages(messages.copy())

        # Find the tool result in the output
        tool_result_idx = None
        for i, m in enumerate(result):
            if m.get("role") == "tool" and m.get("tool_call_id") == "call_tail":
                tool_result_idx = i
                break

        assert tool_result_idx is not None, "Tool result should be present in compacted output"
        # The immediately preceding message must be the assistant tool_call
        assert tool_result_idx > 0
        assert result[tool_result_idx - 1]["role"] == "assistant"
        assert result[tool_result_idx - 1].get("tool_calls") is not None

    def test_tool_call_result_pair_kept_together_in_head(self):
        """If an assistant tool_call is in the head, its tool result must also be there."""
        server = _make_server()
        block = _make_tool_call_block("call_head", "list_files", "file1.py\nfile2.py")

        messages = [
            {"role": "system", "content": "System"},
        ]
        messages.extend(block)
        # Add enough filler after to force compaction
        for i in range(200):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Filler {i} " * 2000})

        assert _char_size(messages) > 2_800_000

        result = server._compact_messages(messages.copy())

        # Find the assistant tool_call in the output
        tool_call_idx = None
        for i, m in enumerate(result):
            if m.get("role") == "assistant" and m.get("tool_calls"):
                for tc in m["tool_calls"]:
                    if tc["id"] == "call_head":
                        tool_call_idx = i
                        break

        assert tool_call_idx is not None, "Tool call should be preserved in compacted output"
        # The immediately next message must be the tool result
        assert tool_call_idx + 1 < len(result)
        assert result[tool_call_idx + 1]["role"] == "tool"
        assert result[tool_call_idx + 1]["tool_call_id"] == "call_head"


class TestCompactMessagesLogging:
    """Compaction should log when triggered."""

    def test_logs_compaction_summary(self, caplog):
        import logging

        server = _make_server()
        messages = _make_large_messages(200)

        assert _char_size(messages) > 2_800_000

        with caplog.at_level(logging.INFO, logger="kitty.bridge.server"):
            server._compact_messages(messages.copy())

        assert any("compaction" in r.message.lower() for r in caplog.records)


class TestCompactMessagesEdgeCases:
    """Edge cases for the compaction logic."""

    def test_single_message_unchanged(self):
        server = _make_server()
        messages = [{"role": "user", "content": "Hello"}]
        result = server._compact_messages(messages.copy())
        assert len(result) == 1
        assert result[0]["content"] == "Hello"

    def test_all_messages_fit_unchanged(self):
        """If all messages fit under threshold, return as-is."""
        server = _make_server()
        messages = [
            {"role": "system", "content": "Short system"},
            {"role": "user", "content": "Short user"},
            {"role": "assistant", "content": "Short response"},
        ]
        original = json.dumps(messages, ensure_ascii=False)

        result = server._compact_messages(messages.copy())

        assert json.dumps(result, ensure_ascii=False) == original

    def test_messages_with_only_system_and_user(self):
        """Minimal conversation should pass through unchanged."""
        server = _make_server()
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "What is 2+2?"},
        ]
        result = server._compact_messages(messages.copy())
        assert len(result) == 2

    def test_no_overlap_between_head_and_tail(self):
        """Head and tail must not contain duplicate messages."""
        server = _make_server()
        messages = _make_large_messages(200)

        result = server._compact_messages(messages.copy())

        # Check no message appears twice (by identity)
        assert len(result) == len({id(m) for m in result})


class TestCompactMessagesGuaranteedFit:
    """Compaction must guarantee the serialized messages fit under _COMPACTION_GUARANTEED_MESSAGES_MAX.

    After head+tail pruning, if the result is still too large, the method must
    iteratively drop oldest blocks (head first, then tail front) until it fits.
    System messages and at least one tail block must always be preserved.
    """

    def test_guaranteed_fit_reduces_oversized_result(self):
        """Even enormous messages must be reduced below the guaranteed max."""
        server = _make_server()
        # Build messages where each block is huge, so head+tail pruning still
        # leaves a result above the guaranteed budget.
        messages = [{"role": "system", "content": "System prompt"}]
        for i in range(30):
            role = "user" if i % 2 == 0 else "assistant"
            # Each message ~200K chars; 30 of them = ~6M total
            messages.append({"role": role, "content": f"Message {i} " * 50_000})

        original_size = _char_size(messages)
        assert original_size > _COMPACTION_GUARANTEED_MESSAGES_MAX

        result = server._compact_messages(messages.copy())
        result_size = _char_size(result)

        assert result_size <= _COMPACTION_GUARANTEED_MESSAGES_MAX, (
            f"Compacted size {result_size} exceeds guaranteed max {_COMPACTION_GUARANTEED_MESSAGES_MAX}"
        )

    def test_guaranteed_fit_drops_head_before_tail(self):
        """When shrinking, oldest head blocks are dropped before any tail blocks."""
        server = _make_server()
        # Small system, distinct head messages, distinct tail messages
        messages = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "HEAD_FIRST " * 100_000},  # ~1.2M
            {"role": "assistant", "content": "HEAD_SECOND " * 100_000},  # ~1.3M
            {"role": "user", "content": "MIDDLE " * 100_000},  # ~0.7M
            {"role": "assistant", "content": "TAIL_SECOND " * 100_000},  # ~1.3M
            {"role": "user", "content": "TAIL_FIRST " * 100_000},  # ~1.2M
        ]

        result = server._compact_messages(messages.copy())
        result_text = json.dumps(result, ensure_ascii=False)

        # System must survive
        assert result[0]["role"] == "system"

        # Most recent tail content must survive (it's most valuable)
        assert "TAIL_FIRST" in result_text

        # Head content should be dropped to make room
        assert "HEAD_FIRST" not in result_text

    def test_guaranteed_fit_trims_tail_keeping_latest(self):
        """When head is fully dropped, tail is trimmed from oldest but latest block survives."""
        server = _make_server()
        # No head — only system + many huge tail blocks
        messages = [{"role": "system", "content": "S" * 100_000}]  # ~100K system
        for i in range(25):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Block_{i:02d}_" * 50_000})  # ~350K each

        result = server._compact_messages(messages.copy())
        result_text = json.dumps(result, ensure_ascii=False)

        # System survives
        assert result[0]["role"] == "system"
        assert len(result[0]["content"]) == 100_000

        # Latest block (Block_24) must survive
        assert "Block_24" in result_text

        # Result must be under guaranteed max
        assert _char_size(result) <= _COMPACTION_GUARANTEED_MESSAGES_MAX

    def test_guaranteed_fit_preserves_system_message(self):
        """System message must survive aggressive shrinking even when very large."""
        server = _make_server()
        huge_system = "SYS" * 500_000  # ~1.5M chars
        messages = [{"role": "system", "content": huge_system}]
        for i in range(15):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Msg{i} " * 50_000})

        result = server._compact_messages(messages.copy())

        # System message must be first and unchanged
        assert result[0]["role"] == "system"
        assert result[0]["content"] == huge_system

    def test_guaranteed_fit_preserves_atomic_blocks(self):
        """Tool-call/result pairs must not be split during fallback shrinking."""
        server = _make_server()
        messages = [
            {"role": "system", "content": "System"},
            {"role": "user", "content": "Do task"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [{"id": "call_1", "type": "function", "function": {"name": "read", "arguments": "{}"}}],
            },
            {"role": "tool", "content": "T" * 200_000, "tool_call_id": "call_1"},
            {"role": "assistant", "content": "A" * 200_000},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [{"id": "call_2", "type": "function", "function": {"name": "write", "arguments": "{}"}}],
            },
            {"role": "tool", "content": "R" * 200_000, "tool_call_id": "call_2"},
            {"role": "assistant", "content": "Final answer"},
        ]

        result = server._compact_messages(messages.copy())

        # If a tool_call_id appears, its assistant tool_call must be adjacent
        tool_results = [(i, m) for i, m in enumerate(result) if m.get("role") == "tool"]
        for idx, tr in tool_results:
            assert idx > 0, f"Tool result at index {idx} has no preceding assistant"
            prev = result[idx - 1]
            assert prev["role"] == "assistant"
            assert prev.get("tool_calls") is not None
            call_ids = {tc["id"] for tc in prev["tool_calls"]}
            assert tr["tool_call_id"] in call_ids


class TestRequestSizeAccountingForTools:
    """Regression tests for the full-request size check including tools.

    The bridge's compaction only shrinks messages, but _check_request_size
    checks the ENTIRE request (tools + system + model + metadata + messages).
    If the tools array is large, the request can exceed _MAX_REQUEST_CHARS
    even after messages are compacted.  This test class validates the fix.
    """

    def test_check_request_size_rejects_when_tools_push_over_limit(self):
        """A request with compacted messages but large tools must still be rejected."""
        server = _make_server()
        # Messages are small (well under threshold)
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
        ]
        # But tools are enormous — push the whole request over _MAX_REQUEST_CHARS
        large_tools = [
            {
                "type": "function",
                "function": {
                    "name": f"tool_{i}",
                    "description": f"Tool {i}: " + "x" * 100_000,
                    "parameters": {"type": "object", "properties": {}},
                },
            }
            for i in range(50)
        ]
        cc_request = {
            "model": "test-model",
            "messages": messages,
            "tools": large_tools,
            "stream": True,
        }
        # Sanity: the full request should exceed the limit
        full_size = len(json.dumps(cc_request, ensure_ascii=False))
        assert full_size > _MAX_REQUEST_CHARS

        result = server._check_request_size(cc_request)
        assert result is not None, "Expected _check_request_size to reject the oversized request"
        assert result.status == 400

    def test_compaction_does_not_shrink_tools(self):
        """_apply_compaction only touches messages — tools are never trimmed."""
        server = _make_server()
        # Build a request where messages are small but tools are huge
        original_tools = [
            {
                "type": "function",
                "function": {
                    "name": f"tool_{i}",
                    "description": "x" * 50_000,
                    "parameters": {"type": "object", "properties": {}},
                },
            }
            for i in range(20)
        ]
        tools_size_before = len(json.dumps(original_tools, ensure_ascii=False))
        cc_request = {
            "model": "test-model",
            "messages": [
                {"role": "system", "content": "System"},
                {"role": "user", "content": "A" * 3_000_000},
                {"role": "assistant", "content": "B" * 3_000_000},
            ],
            "tools": original_tools,
        }
        server._apply_compaction(cc_request)

        # Tools should be unchanged
        assert cc_request["tools"] == original_tools
        tools_size_after = len(json.dumps(cc_request["tools"], ensure_ascii=False))
        assert tools_size_before == tools_size_after

    def test_full_request_fits_after_compaction_with_tools(self):
        """The happy path: messages are compacted, tools are preserved, whole request fits."""
        server = _make_server()
        # Large messages that trigger compaction
        messages = [{"role": "system", "content": "System"}]
        for i in range(20):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Msg{i} " * 50_000})

        # Moderate tools — together with compacted messages should fit
        tools = [
            {
                "type": "function",
                "function": {
                    "name": f"tool_{i}",
                    "description": f"Tool {i} description",
                    "parameters": {"type": "object", "properties": {}},
                },
            }
            for i in range(10)
        ]
        cc_request = {
            "model": "test-model",
            "messages": messages,
            "tools": tools,
            "stream": True,
        }

        server._apply_compaction(cc_request)
        result = server._check_request_size(cc_request)
        assert result is None, (
            f"Expected request to fit after compaction. "
            f"Full size: {len(json.dumps(cc_request, ensure_ascii=False))} chars, "
            f"limit: {_MAX_REQUEST_CHARS}"
        )

    def test_request_rejected_when_tools_plus_compacted_messages_exceed_limit(self):
        """BUG: compacted messages fit, but tools push the full request over the limit.

        This reproduces the /compact failure scenario: Claude Code's compaction
        produces a request where messages are small enough, but the tools array
        (which is never compacted) causes the full request to exceed the limit.
        The bridge must handle this gracefully instead of hard-rejecting.
        """
        server = _make_server()
        # Build messages that are just barely under the compaction threshold
        # so compaction still kicks in but doesn't shrink much
        messages = [{"role": "system", "content": "System prompt"}]
        for i in range(15):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Msg{i} " * 100_000})

        # Tools that are large but not enormous — together with compacted
        # messages they push the full request over _MAX_REQUEST_CHARS
        tools = [
            {
                "type": "function",
                "function": {
                    "name": f"tool_{i}",
                    "description": "A tool that does something useful. " + "x" * 20_000,
                    "parameters": {"type": "object", "properties": {}},
                },
            }
            for i in range(40)  # 40 tools × ~20K each ≈ 800K total
        ]

        cc_request = {
            "model": "test-model",
            "messages": messages,
            "tools": tools,
            "stream": True,
        }

        # Before compaction: the full request would exceed the limit.
        # Verify this by checking the raw messages size.
        raw_msg_size = len(json.dumps(cc_request["messages"], ensure_ascii=False))
        assert raw_msg_size > _COMPACTION_GUARANTEED_MESSAGES_MAX, (
            f"Raw messages should exceed guaranteed max: got {raw_msg_size:,}"
        )

        # Apply compaction — now accounts for the non-message payload (tools, model)
        server._apply_compaction(cc_request)

        full_size = len(json.dumps(cc_request, ensure_ascii=False))
        # After tools-aware compaction, the full request should fit.
        result = server._check_request_size(cc_request)
        assert result is None, (
            f"Full request should fit after tools-aware compaction. "
            f"Full size: {full_size:,}, limit: {_MAX_REQUEST_CHARS:,}"
        )


# ---------------------------------------------------------------------------
# _get_max_context_chars — context-aware char budget
# ---------------------------------------------------------------------------


class TestGetMaxContextChars:
    """_get_max_context_chars derives the char budget from model metadata."""

    def test_no_model_returns_absolute_cap(self):
        """When no model is configured, fall back to _MAX_REQUEST_CHARS."""
        server = _make_server()
        assert server._get_max_context_chars() == _MAX_REQUEST_CHARS

    def test_known_model_returns_context_derived_chars(self):
        """When a model with known context is set, return tokens_to_chars(context)."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "openai/gpt-4o"
        server._active_provider_config = {}
        server._backends = None
        # gpt-4o has 128k context in metadata → 128000 * 4 = 512000
        assert server._get_max_context_chars() == 512_000

    def test_unknown_model_returns_default_chars(self):
        """When the model is set but metadata is missing, use DEFAULT_CONTEXT_TOKENS."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "nonexistent-model-xyz"
        server._active_provider_config = {}
        server._backends = None
        expected = tokens_to_chars(DEFAULT_CONTEXT_TOKENS)  # 800k
        assert server._get_max_context_chars() == expected

    def test_balancing_uses_min_context(self):
        """For balancing profiles, use the smallest context across all backends."""
        server = _make_server()
        # Simulate balancing with 2 backends: gpt-4o (128k) and deepseek-chat (163_840)
        p1 = StubProvider()
        profile1 = Profile(
            name="p1",
            provider="openrouter",
            model="openai/gpt-4o",
            auth_ref="dd7f361b-3794-4343-a917-906760d3cde4",
        )
        p2 = StubProvider()
        profile2 = Profile(
            name="p2",
            provider="openrouter",
            model="deepseek/deepseek-chat",
            auth_ref="76df9193-5b84-4824-8c35-a1dce9c01d64",
        )
        server._backends = [
            (p1, "key1", profile1),
            (p2, "key2", profile2),
        ]
        # Min: gpt-4o 128000 → 128000 * 4 = 512000
        assert server._get_max_context_chars() == 512_000

    def test_provider_config_override(self):
        """Manual context_window in provider_config overrides metadata."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "openai/gpt-4o"
        server._active_provider_config = {"context_window": 50_000}
        server._backends = None
        # Override: 50000 * 4 = 200000
        assert server._get_max_context_chars() == 200_000

    def test_huge_context_capped_at_max_request_chars(self):
        """Models with very large context are capped at _MAX_REQUEST_CHARS."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "google/gemini-2.0-flash-001"
        server._active_provider_config = {}
        server._backends = None
        # gemini has 1M context → 4M chars, capped at _MAX_REQUEST_CHARS (4M)
        assert server._get_max_context_chars() == _MAX_REQUEST_CHARS


# ---------------------------------------------------------------------------
# Context-aware compaction and size checking
# ---------------------------------------------------------------------------


class TestContextAwareCompaction:
    """Compaction and request-size checks use model-derived char limits."""

    def test_compaction_uses_model_context(self):
        """Compaction threshold is derived from model context, not hardcoded."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "openai/gpt-4o"  # 128k → 512k chars
        server._active_provider_config = {}
        server._backends = None

        # Create messages that exceed 70% of 512k (~358k) but are under 70% of 4M (~2.8M)
        messages = [{"role": "system", "content": "System"}]
        for i in range(30):
            role = "user" if i % 2 == 0 else "assistant"
            messages.append({"role": role, "content": f"Message {i} " * 3000})
        raw_size = len(json.dumps(messages, ensure_ascii=False))
        assert raw_size > 358_000, f"Need >358k chars, got {raw_size:,}"

        cc_request = {"model": "gpt-4o", "messages": messages}
        server._apply_compaction(cc_request)
        result_size = len(json.dumps(cc_request["messages"], ensure_ascii=False))
        # After compaction, messages should be smaller
        assert result_size < raw_size, "Compaction should have reduced messages"

    def test_size_check_uses_model_context(self):
        """_check_request_size rejects based on model-derived limit, not hardcoded."""
        server = _make_server()
        server._active_provider = StubProvider()
        server._active_model = "openai/gpt-4o"  # 128k → 512k chars
        server._active_provider_config = {}
        server._backends = None

        # Create a request that exceeds 512k but is under 4M
        large_content = "A" * 600_000
        cc_request = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": large_content}],
        }
        full_size = len(json.dumps(cc_request, ensure_ascii=False))
        assert full_size > 512_000, f"Need >512k chars, got {full_size:,}"
        assert full_size < _MAX_REQUEST_CHARS, f"Should be under 4M, got {full_size:,}"

        result = server._check_request_size(cc_request)
        assert result is not None, "Should reject request exceeding model context"
        assert result.status == 400
