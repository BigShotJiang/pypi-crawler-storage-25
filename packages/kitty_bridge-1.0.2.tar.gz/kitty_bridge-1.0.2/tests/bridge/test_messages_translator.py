"""Tests for bridge/messages/translator.py — Anthropic Messages API <-> Chat Completions translation."""

import json
import uuid

from kitty.bridge.messages.translator import MessagesTranslator


def _v4() -> str:
    return str(uuid.uuid4())


# ── translate_request ───────────────────────────────────────────────────────


class TestTranslateRequest:
    def setup_method(self):
        self.t = MessagesTranslator()

    def test_extracts_model(self):
        req = {"model": "claude-3-opus", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 1024}
        result = self.t.translate_request(req)
        assert result["model"] == "claude-3-opus"

    def test_system_prompt_mapped(self):
        req = {
            "model": "claude-3-opus",
            "system": "You are helpful.",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        assert result["messages"][0] == {"role": "system", "content": "You are helpful."}

    def test_system_prompt_as_content_blocks_flattened_to_string(self):
        """Anthropic allows system as array of content blocks — must flatten to string."""
        req = {
            "model": "claude-3-opus",
            "system": [
                {"type": "text", "text": "Part one."},
                {"type": "text", "text": "Part two.", "cache_control": {"type": "ephemeral"}},
            ],
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        assert result["messages"][0] == {"role": "system", "content": "Part one.\nPart two."}

    def test_text_content_blocks_mapped_to_string(self):
        req = {
            "model": "claude-3-opus",
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": "hello"}]},
            ],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        assert result["messages"][-1]["content"] == "hello"

    def test_tool_use_blocks_mapped_to_tool_calls(self):
        req = {
            "model": "claude-3-opus",
            "messages": [
                {"role": "user", "content": "weather?"},
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "Let me check."},
                        {"type": "tool_use", "id": "toolu_001", "name": "get_weather", "input": {"city": "London"}},
                    ],
                },
            ],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        assistant_msg = result["messages"][-1]
        assert assistant_msg["role"] == "assistant"
        assert assistant_msg["content"] == "Let me check."
        assert len(assistant_msg["tool_calls"]) == 1
        tc = assistant_msg["tool_calls"][0]
        assert tc["id"] == "toolu_001"
        assert tc["function"]["name"] == "get_weather"
        assert json.loads(tc["function"]["arguments"]) == {"city": "London"}

    def test_tool_result_blocks_mapped_to_tool_messages(self):
        req = {
            "model": "claude-3-opus",
            "messages": [
                {"role": "user", "content": "weather?"},
                {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "toolu_001", "name": "get_weather", "input": {"city": "London"}},
                    ],
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "tool_result", "tool_use_id": "toolu_001", "content": "72F sunny"},
                    ],
                },
            ],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        tool_msg = result["messages"][-1]
        assert tool_msg["role"] == "tool"
        assert tool_msg["tool_call_id"] == "toolu_001"
        assert tool_msg["content"] == "72F sunny"

    def test_multiple_tool_results_produce_multiple_tool_messages(self):
        req = {
            "model": "claude-3-opus",
            "messages": [
                {"role": "user", "content": "weather?"},
                {
                    "role": "assistant",
                    "content": [
                        {"type": "tool_use", "id": "toolu_001", "name": "get_weather", "input": {"city": "London"}},
                        {"type": "tool_use", "id": "toolu_002", "name": "get_weather", "input": {"city": "Paris"}},
                    ],
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "tool_result", "tool_use_id": "toolu_001", "content": "72F sunny"},
                        {"type": "tool_result", "tool_use_id": "toolu_002", "content": "65F cloudy"},
                    ],
                },
            ],
            "max_tokens": 1024,
        }
        result = self.t.translate_request(req)
        # Should produce two tool role messages
        tool_msgs = [m for m in result["messages"] if m["role"] == "tool"]
        assert len(tool_msgs) == 2
        assert tool_msgs[0]["tool_call_id"] == "toolu_001"
        assert tool_msgs[1]["tool_call_id"] == "toolu_002"

    def test_tools_mapped_from_anthropic_to_cc_format(self):
        req = {
            "model": "claude-3-opus",
            "messages": [{"role": "user", "content": "weather?"}],
            "max_tokens": 1024,
            "tools": [
                {
                    "name": "get_weather",
                    "description": "Get weather",
                    "input_schema": {
                        "type": "object",
                        "properties": {"city": {"type": "string"}},
                        "required": ["city"],
                    },
                }
            ],
        }
        result = self.t.translate_request(req)
        assert len(result["tools"]) == 1
        tool = result["tools"][0]
        assert tool["type"] == "function"
        assert tool["function"]["name"] == "get_weather"
        assert tool["function"]["parameters"]["required"] == ["city"]

    def test_max_tokens_passthrough(self):
        req = {"model": "m", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 512}
        result = self.t.translate_request(req)
        assert result["max_tokens"] == 512

    def test_stream_flag_passthrough(self):
        req = {"model": "m", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 10, "stream": True}
        result = self.t.translate_request(req)
        assert result["stream"] is True

    def test_temperature_top_p_passthrough(self):
        req = {
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 10,
            "temperature": 0.7,
            "top_p": 0.9,
        }
        result = self.t.translate_request(req)
        assert result["temperature"] == 0.7
        assert result["top_p"] == 0.9

    def test_thinking_stripped_and_flag_set(self):
        req = {
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 10,
            "thinking": {"type": "enabled", "budget_tokens": 4000},
        }
        assert not self.t.thinking_warned
        result = self.t.translate_request(req)
        assert "thinking" not in result
        assert self.t.thinking_warned

    def test_thinking_warning_only_once(self):
        req = {
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 10,
            "thinking": {"type": "enabled", "budget_tokens": 4000},
        }
        self.t.translate_request(req)
        assert self.t.thinking_warned
        # Second call should not reset or re-warn
        self.t.translate_request(req)
        assert self.t.thinking_warned

    def test_unsupported_fields_stripped(self):
        req = {
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 10,
            "metadata": {"user_id": "123"},
            "stop_sequences": ["\n"],
            "top_k": 50,
            "tool_choice": "auto",
        }
        result = self.t.translate_request(req)
        assert "metadata" not in result
        assert "stop_sequences" not in result
        assert "top_k" not in result
        assert "tool_choice" not in result

    def test_thinking_block_mapped_to_reasoning_content(self):
        """Thinking blocks in assistant messages must be mapped to reasoning_content
        for Chat Completions, not stripped. Required by Kimi Code and other
        providers with thinking mode."""
        req = {
            "model": "m",
            "messages": [
                {
                    "role": "assistant",
                    "content": [
                        {"type": "thinking", "thinking": "Let me analyze this..."},
                        {"type": "text", "text": "The answer is 42."},
                    ],
                },
            ],
            "max_tokens": 10,
        }
        result = self.t.translate_request(req)
        assistant_msg = result["messages"][-1]
        assert assistant_msg["reasoning_content"] == "Let me analyze this..."
        assert assistant_msg["content"] == "The answer is 42."

    def test_thinking_block_with_tool_use_maps_to_reasoning_content(self):
        """Thinking blocks with tool_use must include reasoning_content.
        Kimi Code errors with 400 if reasoning_content is missing from
        assistant tool call messages when thinking mode is enabled."""
        req = {
            "model": "m",
            "messages": [
                {
                    "role": "assistant",
                    "content": [
                        {"type": "thinking", "thinking": "I need to check the weather..."},
                        {"type": "tool_use", "id": "toolu_001", "name": "get_weather", "input": {"city": "London"}},
                    ],
                },
            ],
            "max_tokens": 10,
        }
        result = self.t.translate_request(req)
        assistant_msg = result["messages"][-1]
        assert assistant_msg["reasoning_content"] == "I need to check the weather..."
        assert assistant_msg["content"] is None
        assert len(assistant_msg["tool_calls"]) == 1

    def test_multiple_thinking_blocks_concatenated(self):
        """Multiple thinking blocks should be concatenated into a single reasoning_content."""
        req = {
            "model": "m",
            "messages": [
                {
                    "role": "assistant",
                    "content": [
                        {"type": "thinking", "thinking": "Part one."},
                        {"type": "thinking", "thinking": "Part two."},
                        {"type": "text", "text": "Result."},
                    ],
                },
            ],
            "max_tokens": 10,
        }
        result = self.t.translate_request(req)
        assistant_msg = result["messages"][-1]
        assert assistant_msg["reasoning_content"] == "Part one.\nPart two."

    def test_no_thinking_block_no_reasoning_content(self):
        """Assistant messages without thinking blocks should not have reasoning_content."""
        req = {
            "model": "m",
            "messages": [
                {
                    "role": "assistant",
                    "content": "Just a plain response.",
                },
            ],
            "max_tokens": 10,
        }
        result = self.t.translate_request(req)
        assistant_msg = result["messages"][-1]
        assert "reasoning_content" not in assistant_msg


# ── translate_response ──────────────────────────────────────────────────────


class TestTranslateResponse:
    def setup_method(self):
        self.t = MessagesTranslator()

    def test_text_response(self):
        cc_response = {
            "id": "chatcmpl-123",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "Hello!"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }
        result = self.t.translate_response(cc_response)
        assert result["type"] == "message"
        assert result["role"] == "assistant"
        assert result["id"].startswith("msg_")
        assert result["model"] == "gpt-4o"
        assert result["stop_reason"] == "end_turn"
        assert result["stop_sequence"] is None
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"
        assert result["content"][0]["text"] == "Hello!"
        assert result["usage"]["input_tokens"] == 10
        assert result["usage"]["output_tokens"] == 5

    def test_tool_call_response(self):
        cc_response = {
            "id": "chatcmpl-456",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [
                            {
                                "id": "call_abc",
                                "type": "function",
                                "function": {
                                    "name": "get_weather",
                                    "arguments": '{"city": "London"}',
                                },
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30},
        }
        result = self.t.translate_response(cc_response)
        assert result["stop_reason"] == "tool_use"
        tool_blocks = [b for b in result["content"] if b["type"] == "tool_use"]
        assert len(tool_blocks) == 1
        tb = tool_blocks[0]
        assert tb["name"] == "get_weather"
        assert tb["input"] == {"city": "London"}

    def test_stop_reason_mapping(self):
        for finish_reason, expected in [("stop", "end_turn"), ("tool_calls", "tool_use"), ("length", "max_tokens")]:
            cc_response = {
                "id": "chatcmpl-1",
                "model": "m",
                "choices": [
                    {"index": 0, "message": {"role": "assistant", "content": "x"}, "finish_reason": finish_reason}
                ],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            }
            result = self.t.translate_response(cc_response)
            assert result["stop_reason"] == expected, f"{finish_reason} -> {result['stop_reason']}, expected {expected}"

    def test_mixed_text_and_tool_call(self):
        cc_response = {
            "id": "chatcmpl-789",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "Let me check.",
                        "tool_calls": [
                            {
                                "id": "call_abc",
                                "type": "function",
                                "function": {"name": "get_weather", "arguments": '{"city": "London"}'},
                            }
                        ],
                    },
                    "finish_reason": "tool_calls",
                }
            ],
            "usage": {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30},
        }
        result = self.t.translate_response(cc_response)
        assert result["type"] == "message"
        assert len(result["content"]) == 2
        assert result["content"][0]["type"] == "text"
        assert result["content"][1]["type"] == "tool_use"

    def test_empty_assistant_output_emits_fallback_text_block(self):
        cc_response = {
            "id": "chatcmpl-empty",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": None},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 42, "completion_tokens": 0, "total_tokens": 42},
        }

        result = self.t.translate_response(cc_response)
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"
        assert result["content"][0]["text"].strip() != ""
        assert "retry" in result["content"][0]["text"].lower()
        assert "/clear" in result["content"][0]["text"]

    def test_empty_assistant_output_prefers_refusal_text(self):
        cc_response = {
            "id": "chatcmpl-empty-refusal",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": None, "refusal": "Policy refusal from upstream"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 42, "completion_tokens": 0, "total_tokens": 42},
        }

        result = self.t.translate_response(cc_response)
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"
        assert result["content"][0]["text"] == "Policy refusal from upstream"

    def test_empty_assistant_output_with_context_includes_provider_model(self):
        cc_response = {
            "id": "chatcmpl-empty",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": None},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 42, "completion_tokens": 0, "total_tokens": 42},
        }

        result = self.t.translate_response(
            cc_response,
            context={"provider": "openai", "model": "gpt-4o", "attempts": 3},
        )
        text = result["content"][0]["text"]
        assert "retry" in text.lower()
        assert "/clear" in text
        assert "openai" in text.lower()
        assert "gpt-4o" in text

    def test_empty_assistant_output_without_context_keeps_default(self):
        cc_response = {
            "id": "chatcmpl-empty",
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": None},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 42, "completion_tokens": 0, "total_tokens": 42},
        }

        result = self.t.translate_response(cc_response)
        text = result["content"][0]["text"]
        assert text == (
            "Upstream model returned an empty response. Please retry. "
            "If the context is full, use /clear to reset the conversation."
        )

    def test_response_with_reasoning_content_mapped_to_thinking_block(self):
        """Chat Completions responses with reasoning_content must be mapped
        to thinking blocks in Messages API."""
        cc_response = {
            "id": "chatcmpl-reason",
            "model": "kimi-k2",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "The answer is 42.",
                        "reasoning_content": "Step 1: Analyze. Step 2: Compute.",
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 50, "total_tokens": 60},
        }
        result = self.t.translate_response(cc_response)
        # content should be [thinking block, text block]
        assert len(result["content"]) == 2
        assert result["content"][0]["type"] == "thinking"
        assert result["content"][0]["thinking"] == "Step 1: Analyze. Step 2: Compute."
        assert result["content"][1]["type"] == "text"
        assert result["content"][1]["text"] == "The answer is 42."

    def test_response_with_only_reasoning_content_mapped_to_thinking_block(self):
        cc_response = {
            "id": "chatcmpl-reason-only",
            "model": "kimi-k2",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "reasoning_content": "Deep thinking...",
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 50, "total_tokens": 60},
        }
        result = self.t.translate_response(cc_response)
        # thinking-only response must include fallback text block
        assert len(result["content"]) == 2
        assert result["content"][0]["type"] == "thinking"
        assert result["content"][0]["thinking"] == "Deep thinking..."
        assert result["content"][1]["type"] == "text"
        assert "retry" in result["content"][1]["text"].lower()


# ── translate_stream_chunk ─────────────────────────────────────────────────


class TestTranslateStreamChunk:
    def setup_method(self):
        self.t = MessagesTranslator()

    def _make_message_id(self) -> str:
        return f"msg_{uuid.uuid4().hex[:24]}"

    def test_text_delta_produces_content_block_events(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        chunk = {
            "choices": [{"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}],
        }
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        # Should produce content_block_start + content_block_delta for text
        assert any("content_block_start" in e for e in events)
        assert any("content_block_delta" in e for e in events)
        # Check text_delta
        delta_events = [e for e in events if "content_block_delta" in e]
        assert '"text_delta"' in delta_events[0]
        assert '"Hello"' in delta_events[0]

    def test_finish_produces_message_delta_and_stop(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        chunk = {
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        assert any("message_delta" in e for e in events)
        assert any("message_stop" in e for e in events)
        # Check stop_reason
        delta_event = [e for e in events if "message_delta" in e][0]
        assert "end_turn" in delta_event

    def test_finish_without_content_emits_fallback_text_events(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        chunk = {
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 0, "total_tokens": 10},
        }

        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        event_blob = "\n".join(events)
        assert "message_start" in event_blob
        assert "content_block_start" in event_blob
        assert "content_block_delta" in event_blob
        assert "/clear" in event_blob
        assert "retry" in event_blob.lower()
        assert "message_stop" in event_blob

    def test_finalize_interrupted_stream_closes_open_text_block(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        chunk = {
            "choices": [{"index": 0, "delta": {"content": "Hello"}, "finish_reason": None}],
        }

        initial_events = self.t.translate_stream_chunk(msg_id, model, chunk)
        final_events = self.t.finalize_interrupted_stream()
        final_blob = "\n".join(final_events)

        assert any("content_block_delta" in event for event in initial_events)
        assert "content_block_stop" in final_blob
        assert "message_delta" in final_blob
        assert '"stop_reason": "end_turn"' in final_blob
        assert "message_stop" in final_blob
        assert "error" not in final_blob
        assert self.t._text_block_opened is False
        assert self.t._message_started is False

    def test_finalize_interrupted_stream_with_message_start_only_emits_fallback_block(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        events: list[str] = []
        self.t._emit_message_start_if_needed(events, msg_id, model)

        final_events = self.t.finalize_interrupted_stream()
        final_blob = "\n".join(final_events)

        assert "message_start" not in final_blob
        assert "content_block_start" in final_blob
        assert "content_block_delta" in final_blob
        assert "/clear" in final_blob
        assert "content_block_stop" in final_blob
        assert "message_delta" in final_blob
        assert "message_stop" in final_blob

    def test_finalize_interrupted_stream_closes_open_tool_block(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_1",
                                "type": "function",
                                "function": {"name": "lookup", "arguments": '{"query":'},
                            },
                        ],
                    },
                    "finish_reason": None,
                },
            ],
        }

        initial_events = self.t.translate_stream_chunk(msg_id, model, chunk)
        final_events = self.t.finalize_interrupted_stream()
        final_blob = "\n".join(final_events)

        assert any("tool_use" in event for event in initial_events)
        assert "content_block_stop" in final_blob
        assert "message_delta" in final_blob
        assert "message_stop" in final_blob
        assert self.t._tool_call_buffers == {}

    def test_finalize_interrupted_stream_without_started_message_is_noop(self):
        assert self.t.finalize_interrupted_stream() == []

    def test_tool_call_delta_produces_input_json_delta(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        # First chunk: tool call name
        chunk1 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_001",
                                "type": "function",
                                "function": {"name": "get_weather", "arguments": ""},
                            }
                        ]
                    },
                    "finish_reason": None,
                }
            ],
        }
        events1 = self.t.translate_stream_chunk(msg_id, model, chunk1)
        assert any("content_block_start" in e for e in events1)
        assert any("tool_use" in e for e in events1)

        # Second chunk: argument delta
        chunk2 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"tool_calls": [{"index": 0, "function": {"arguments": '{"city":'}}]},
                    "finish_reason": None,
                }
            ],
        }
        events2 = self.t.translate_stream_chunk(msg_id, model, chunk2)
        assert any("input_json_delta" in e for e in events2)

    def test_content_block_index_increments(self):
        msg_id = self._make_message_id()
        model = "claude-3-opus"
        # Text delta (index 0)
        chunk1 = {
            "choices": [{"index": 0, "delta": {"content": "hi"}, "finish_reason": None}],
        }
        events1 = self.t.translate_stream_chunk(msg_id, model, chunk1)
        # Verify text block at index 0
        start_events = [e for e in events1 if "content_block_start" in e]
        assert '"index": 0' in start_events[0]

        # Tool call (should be index 1)
        chunk2 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_001",
                                "type": "function",
                                "function": {"name": "fn", "arguments": ""},
                            }
                        ]
                    },
                    "finish_reason": None,
                }
            ],
        }
        events2 = self.t.translate_stream_chunk(msg_id, model, chunk2)
        start_events2 = [e for e in events2 if "content_block_start" in e]
        assert '"index": 1' in start_events2[0]

    def test_auto_reset_after_finish(self):
        msg_id = self._make_message_id()
        model = "m"
        chunk = {
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        self.t.translate_stream_chunk(msg_id, model, chunk)
        assert self.t._tool_call_buffers == {}
        assert self.t._content_block_index == 0
        assert self.t._text_block_opened is False

    def test_reset_clears_internal_state(self):
        chunk = {
            "choices": [{"index": 0, "delta": {"content": "hi"}, "finish_reason": None}],
        }
        self.t.translate_stream_chunk("msg_1", "m", chunk)
        self.t.reset()
        assert self.t._tool_call_buffers == {}
        assert self.t._content_block_index == 0
        assert self.t._text_block_opened is False

    def test_finish_reason_length_maps_to_max_tokens(self):
        msg_id = self._make_message_id()
        model = "m"
        chunk = {
            "choices": [{"index": 0, "delta": {}, "finish_reason": "length"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        delta_event = [e for e in events if "message_delta" in e][0]
        assert "max_tokens" in delta_event

    def test_empty_choices_returns_empty_events(self):
        """SSE chunks with empty choices list (e.g. Fireworks usage chunks) must not crash."""
        msg_id = self._make_message_id()
        model = "m"
        chunk = {"choices": [], "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        assert events == []

    def test_missing_choices_returns_empty_events(self):
        """SSE chunks with no choices key must not crash."""
        msg_id = self._make_message_id()
        model = "m"
        chunk = {"id": "chatcmpl-1", "usage": {"prompt_tokens": 10, "completion_tokens": 5}}
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        assert events == []

    def test_duplicate_finish_chunk_does_not_emit_extra_message(self):
        """Duplicate finish_reason chunks (emitted by some models/providers like Gemma/OpenRouter)
        must not produce a second message lifecycle with fallback text.

        Reproduces: https://github.com/QwenLM/qwen-code/issues/2402
        Some models emit two consecutive finish_reason chunks. After the first finishes
        and self.reset() is called, the second (empty) finish chunk must be silently ignored
        rather than triggering the fallback-text path.
        """
        msg_id = self._make_message_id()
        model = "m"

        # First chunk: content delta with finish
        chunk1 = {
            "choices": [{"index": 0, "delta": {"content": "hello"}, "finish_reason": "stop"}],
        }
        events1 = self.t.translate_stream_chunk(msg_id, model, chunk1)

        # Should produce: message_start, content_block_start(text), content_block_delta("hello"),
        # content_block_stop, message_delta, message_stop
        content_block_deltas = [e for e in events1 if "content_block_delta" in e]
        assert len(content_block_deltas) == 1
        assert '"text": "hello"' in content_block_deltas[0]

        message_stops = [e for e in events1 if "message_stop" in e]
        assert len(message_stops) == 1

        # Second chunk: duplicate finish (empty delta) — must be ignored
        chunk2 = {
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        }
        events2 = self.t.translate_stream_chunk(msg_id, model, chunk2)

        # Must produce ZERO events — no second message lifecycle, no fallback text
        assert events2 == [], f"Duplicate finish chunk should produce no events, got: {events2}"

    def test_translator_reuse_across_requests(self):
        """A new message_id must reset _finished so the translator can handle multiple requests."""
        msg_id1 = self._make_message_id()
        msg_id2 = self._make_message_id()
        model = "m"

        # First request finishes normally
        chunk1 = {
            "choices": [{"index": 0, "delta": {"content": "hi"}, "finish_reason": "stop"}],
        }
        events1 = self.t.translate_stream_chunk(msg_id1, model, chunk1)
        assert any("message_stop" in e for e in events1)

        # Second request (different message_id) must also finish properly
        chunk2 = {
            "choices": [{"index": 0, "delta": {"content": "bye"}, "finish_reason": "stop"}],
        }
        events2 = self.t.translate_stream_chunk(msg_id2, model, chunk2)
        assert any("message_stop" in e for e in events2), "Second request should emit message_stop"
        content_deltas = [e for e in events2 if "content_block_delta" in e]
        assert any('"bye"' in e for e in content_deltas), "Second request should emit its content"

    def test_reasoning_delta_produces_thinking_block(self):
        """Streaming reasoning_content deltas must map to thinking blocks in Messages API."""
        msg_id = self._make_message_id()
        model = "kimi-k2"

        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"reasoning_content": "Let me think..."},
                    "finish_reason": None,
                }
            ],
        }
        events = self.t.translate_stream_chunk(msg_id, model, chunk)
        # Should produce content_block_start for thinking + content_block_delta
        start_events = [e for e in events if "content_block_start" in e]
        assert len(start_events) == 1
        assert '"thinking"' in start_events[0]

        delta_events = [e for e in events if "content_block_delta" in e]
        assert len(delta_events) == 1
        assert '"thinking_delta"' in delta_events[0]
        assert "Let me think..." in delta_events[0]

    def test_reasoning_then_text_content_block_increments(self):
        """Thinking block at index 0, then text block at index 1."""
        msg_id = self._make_message_id()
        model = "kimi-k2"

        # Reasoning chunk
        chunk1 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"reasoning_content": "Analyzing..."},
                    "finish_reason": None,
                }
            ],
        }
        events1 = self.t.translate_stream_chunk(msg_id, model, chunk1)
        thinking_starts = [e for e in events1 if "content_block_start" in e]
        assert '"index": 0' in thinking_starts[0]

        # Text chunk
        chunk2 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"content": "The answer."},
                    "finish_reason": None,
                }
            ],
        }
        events2 = self.t.translate_stream_chunk(msg_id, model, chunk2)
        text_starts = [e for e in events2 if "content_block_start" in e]
        assert len(text_starts) == 1
        assert '"index": 1' in text_starts[0]

    def test_thinking_only_finish_emits_fallback_text(self):
        """When the stream produces only thinking and no text, fallback text must be added."""
        msg_id = self._make_message_id()
        model = "kimi-k2"

        # Reasoning chunk
        chunk1 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"reasoning_content": "Deep thinking..."},
                    "finish_reason": None,
                }
            ],
        }
        self.t.translate_stream_chunk(msg_id, model, chunk1)

        # Finish chunk with no text
        chunk2 = {
            "choices": [
                {
                    "index": 0,
                    "delta": {},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 50, "total_tokens": 60},
        }
        events = self.t.translate_stream_chunk(msg_id, model, chunk2)
        event_blob = "\n".join(events)

        # Must contain a fallback text block after thinking
        assert "retry" in event_blob.lower() or "/clear" in event_blob

    def test_thinking_only_finalized_interrupted_stream_emits_fallback_text(self):
        """When an interrupted stream has only a thinking block open, fallback text must be added."""
        msg_id = self._make_message_id()
        model = "kimi-k2"

        # Reasoning chunk to open a thinking block
        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"reasoning_content": "Thinking..."},
                    "finish_reason": None,
                }
            ],
        }
        self.t.translate_stream_chunk(msg_id, model, chunk)

        # Finalize the interrupted stream
        events = self.t.finalize_interrupted_stream()
        event_blob = "\n".join(events)

        # Must contain fallback text
        assert "retry" in event_blob.lower() or "/clear" in event_blob
