from __future__ import annotations

import shutil
from pathlib import Path
from typing import List, Union


__all__ = ["create_project"]
__version__ = "5.1.23"


TEMPLATE_DIR = Path(__file__).resolve().parent / "template"


def create_project(target_dir: Union[str, Path] = ".", overwrite: bool = False) -> List[Path]:
    """Create the shoe shop PyQt/SQLite project in target_dir.

    Args:
        target_dir: Folder where project files should be created.
        overwrite: Replace existing files when True.

    Returns:
        Paths that were created or replaced.
    """
    target = Path(target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)

    created: List[Path] = []
    for source in TEMPLATE_DIR.rglob("*"):
        if "__pycache__" in source.parts or source.suffix == ".pyc":
            continue

        relative = source.relative_to(TEMPLATE_DIR)
        destination = target / relative

        if source.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            continue

        if destination.exists() and not overwrite:
            raise FileExistsError(
                f"File already exists: {destination}. "
                "Pass overwrite=True to replace existing files."
            )

        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        created.append(destination)

    return created
