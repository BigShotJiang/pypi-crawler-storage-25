from __future__ import annotations

import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
import random
from typing import List, Optional, Tuple

from PyQt5 import QtCore, QtGui, QtWidgets, uic

from app.database import ROOT, connect, initialize_database


UI_DIR = ROOT / "ui"
IMPORT_DIR = ROOT / "import"

ROLE_ADMIN = "Администратор"
ROLE_MANAGER = "Менеджер"
ROLE_CLIENT = "Авторизированный клиент"
ROLE_GUEST = "Гость"


def parse_order_items(articles_text: str) -> List[Tuple[str, int]]:
    parts = [part.strip() for part in str(articles_text).split(",") if part.strip()]
    items = []
    for index in range(0, len(parts), 2):
        article = parts[index]
        try:
            quantity = int(float(parts[index + 1]))
        except (IndexError, ValueError):
            quantity = 1
        items.append((article, quantity))
    return items


def replace_order_items(conn: sqlite3.Connection, order_id: int, articles_text: str) -> None:
    conn.execute("DELETE FROM products_in_orders WHERE order_id = ?", (order_id,))
    conn.executemany(
        """
        INSERT INTO products_in_orders(order_id, product_article, quantity)
        VALUES (?, ?, ?)
        """,
        [(order_id, article, quantity) for article, quantity in parse_order_items(articles_text)],
    )


def orders_has_articles_column(conn: sqlite3.Connection) -> bool:
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(orders)")}
    return "articles" in columns


def user_id_by_name(conn: sqlite3.Connection, full_name: str) -> Optional[int]:
    row = conn.execute("SELECT id FROM users WHERE full_name = ?", (full_name,)).fetchone()
    return row["id"] if row else None


APP_STYLE = """
* {
    font-family: "Times New Roman";
    font-size: 14px;
}
QMainWindow, QDialog, QWidget {
    /* Основной фон */
    background: #FFFFFF;
}
QFrame#headerFrame, QFrame#productToolsFrame {
    /* Дополнительный фон */
    background: #7FFF00;
}
QPushButton {
    /* Акцентирование внимания */
    background: #00FA9A;
    border: 1px solid #20B2AA;
    border-radius: 4px;
    padding: 7px 12px;
}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {
    border: 1px solid #A0A0A0;
    border-radius: 3px;
    padding: 5px;
    /* Основной фон */
    background: #FFFFFF;
}
QTableWidget {
    gridline-color: #D0D0D0;
    /* Акцентирование внимания */
    selection-background-color: #00FA9A;
}
QLabel#titleLabel {
    font-size: 22px;
    font-weight: bold;
}
QLabel#messageLabel {
    color: #B00020;
}
"""


class LoginWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        uic.loadUi(UI_DIR / "login.ui", self)
        self.main_window: Optional["MainWindow"] = None
        self._apply_branding()
        self.loginButton.clicked.connect(self.login)
        self.guestButton.clicked.connect(self.enter_as_guest)
        self.passwordEdit.returnPressed.connect(self.login)

    def _apply_branding(self) -> None:
        logo = QtGui.QPixmap(str(IMPORT_DIR / "picture.png"))
        if not logo.isNull():
            self.logoLabel.setPixmap(
                logo.scaled(
                    self.logoLabel.size(),
                    QtCore.Qt.KeepAspectRatio,
                    QtCore.Qt.SmoothTransformation,
                )
            )

    def login(self) -> None:
        login = self.loginEdit.text().strip()
        password = self.passwordEdit.text()
        with connect() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE login = ? AND password = ?",
                (login, password),
            ).fetchone()
        if user is None:
            self.messageLabel.setText("Неверный логин или пароль")
            return
        self.open_main(dict(user))

    def enter_as_guest(self) -> None:
        self.open_main({"role": ROLE_GUEST, "full_name": "Гость"})

    def open_main(self, user: dict) -> None:
        self.main_window = MainWindow(user)
        self.main_window.show()
        self.close()


class MainWindow(QtWidgets.QMainWindow):
    product_headers = [
        "Артикул",
        "Наименование",
        "Ед.",
        "Цена",
        "Поставщик",
        "Производитель",
        "Категория",
        "Скидка",
        "Остаток",
        "Описание",
        "Фото",
    ]
    order_headers = [
        "Номер",
        "Артикулы",
        "Дата заказа",
        "Дата доставки",
        "Пункт выдачи",
        "Клиент",
        "Код",
        "Статус",
    ]

    def __init__(self, user: dict) -> None:
        super().__init__()
        uic.loadUi(UI_DIR / "main_window.ui", self)
        self.user = user
        self.role = user["role"]
        self._setup_ui()
        self._bind_actions()
        self.load_products()
        self.load_orders()

    def _setup_ui(self) -> None:
        icon_path = IMPORT_DIR / "Icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QtGui.QIcon(str(icon_path)))
        logo = QtGui.QPixmap(str(IMPORT_DIR / "picture.png"))
        if not logo.isNull():
            self.logoLabel.setPixmap(
                logo.scaled(90, 54, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            )
        self.userLabel.setText(f"{self.user['full_name']} - {self.role}")

        self.productsList.setSpacing(8)
        self.ordersList.setSpacing(8)

        self.categoryCombo.clear()
        self.categoryCombo.addItem("Все категории")
        with connect() as conn:
            categories = conn.execute(
                "SELECT DISTINCT category FROM products ORDER BY category"
            ).fetchall()
        for row in categories:
            self.categoryCombo.addItem(row["category"])

        self.sortCombo.clear()
        self.sortCombo.addItems(
            [
                "По наименованию",
                "Цена по возрастанию",
                "Цена по убыванию",
                "Остаток по возрастанию",
                "Остаток по убыванию",
                "По артикулу",
            ]
        )

        can_filter = True
        can_admin = self.role == ROLE_ADMIN
        can_buy = self.role == ROLE_CLIENT
        self.productToolsFrame.setVisible(can_filter or can_admin or can_buy)
        self.searchEdit.setVisible(can_filter)
        self.categoryCombo.setVisible(can_filter)
        self.sortCombo.setVisible(can_filter)
        self.buyProductButton.setVisible(can_buy)
        self.addProductButton.setVisible(can_admin)
        self.editProductButton.setVisible(can_admin)
        self.deleteProductButton.setVisible(can_admin)

        orders_allowed = self.role in (ROLE_MANAGER, ROLE_ADMIN)
        self.tabs.setTabVisible(1, orders_allowed)
        self.addOrderButton.setVisible(can_admin)
        self.editOrderButton.setVisible(can_admin)
        self.deleteOrderButton.setVisible(can_admin)

    def _bind_actions(self) -> None:
        self.logoutButton.clicked.connect(self.logout)
        self.searchEdit.textChanged.connect(self.load_products)
        self.categoryCombo.currentTextChanged.connect(self.load_products)
        self.sortCombo.currentTextChanged.connect(self.load_products)
        self.addProductButton.clicked.connect(self.add_product)
        self.editProductButton.clicked.connect(self.edit_product)
        self.deleteProductButton.clicked.connect(self.delete_product)
        self.buyProductButton.clicked.connect(self.buy_selected_product)
        self.productsList.currentItemChanged.connect(self.update_product_selection)
        self.ordersList.currentItemChanged.connect(self.update_order_selection)
        self.addOrderButton.clicked.connect(self.add_order)
        self.editOrderButton.clicked.connect(self.edit_order)
        self.deleteOrderButton.clicked.connect(self.delete_order)

    def logout(self) -> None:
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

    def load_products(self) -> None:
        params: List[str] = []
        query = "SELECT * FROM products"
        clauses = []
        text = self.searchEdit.text().strip()
        if text:
            clauses.append(
                "(article LIKE ? OR name LIKE ? OR category LIKE ? OR description LIKE ?)"
            )
            like = f"%{text}%"
            params.extend([like, like, like, like])
        category = self.categoryCombo.currentText()
        if category and category != "Все категории":
            clauses.append("category = ?")
            params.append(category)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        sort = self.sortCombo.currentText()
        order_by = {
            "Цена по возрастанию": "price ASC, name ASC",
            "Цена по убыванию": "price DESC, name ASC",
            "Остаток по возрастанию": "stock ASC, name ASC",
            "Остаток по убыванию": "stock DESC, name ASC",
            "По артикулу": "article ASC",
        }.get(sort, "name ASC")
        query += f" ORDER BY {order_by}"
        with connect() as conn:
            products = conn.execute(query, params).fetchall()

        self.productsList.clear()
        for product in products:
            item = QtWidgets.QListWidgetItem()
            item.setData(QtCore.Qt.UserRole, product["article"])
            card = ProductCard(product)
            item.setSizeHint(card.sizeHint())
            self.productsList.addItem(item)
            self.productsList.setItemWidget(item, card)
        self.update_product_selection()

    def load_orders(self) -> None:
        with connect() as conn:
            orders = conn.execute(
                """
                SELECT
                    orders.*,
                    pickup_points.address,
                    COALESCE(
                        GROUP_CONCAT(products_in_orders.product_article || ', ' || products_in_orders.quantity, ', '),
                        ''
                    ) AS articles
                FROM orders
                LEFT JOIN pickup_points ON pickup_points.id = orders.pickup_point_id
                LEFT JOIN products_in_orders ON products_in_orders.order_id = orders.id
                GROUP BY orders.id
                ORDER BY orders.id
                """
            ).fetchall()
        self.ordersList.clear()
        for order in orders:
            item = QtWidgets.QListWidgetItem()
            item.setData(QtCore.Qt.UserRole, order["id"])
            card = OrderCard(order)
            item.setSizeHint(card.sizeHint())
            self.ordersList.addItem(item)
            self.ordersList.setItemWidget(item, card)
        self.update_order_selection()

    def selected_product_article(self) -> Optional[str]:
        item = self.productsList.currentItem()
        if item is None:
            return None
        return item.data(QtCore.Qt.UserRole)

    def selected_order_id(self) -> Optional[int]:
        item = self.ordersList.currentItem()
        if item is None:
            return None
        return int(item.data(QtCore.Qt.UserRole))

    def update_product_selection(self) -> None:
        current = self.productsList.currentItem()
        for index in range(self.productsList.count()):
            item = self.productsList.item(index)
            card = self.productsList.itemWidget(item)
            if isinstance(card, ProductCard):
                card.set_selected(item is current)

    def update_order_selection(self) -> None:
        current = self.ordersList.currentItem()
        for index in range(self.ordersList.count()):
            item = self.ordersList.item(index)
            card = self.ordersList.itemWidget(item)
            if isinstance(card, OrderCard):
                card.set_selected(item is current)

    def add_product(self) -> None:
        dialog = ProductDialog(self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            data = dialog.data()
            try:
                with connect() as conn:
                    conn.execute(
                        """
                        INSERT INTO products(article, name, unit, price, supplier,
                                             manufacturer, category, discount, stock,
                                             description, photo)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        data,
                    )
                self.load_products()
            except sqlite3.IntegrityError:
                QtWidgets.QMessageBox.warning(self, "Ошибка", "Товар с таким артикулом уже есть")

    def buy_selected_product(self) -> None:
        article = self.selected_product_article()
        if article is None:
            QtWidgets.QMessageBox.information(self, "Покупка", "Выберите товар")
            return

        with connect() as conn:
            product = conn.execute(
                "SELECT article, name, stock FROM products WHERE article = ?",
                (article,),
            ).fetchone()

        if product is None:
            QtWidgets.QMessageBox.warning(self, "Покупка", "Товар не найден")
            return
        if product["stock"] <= 0:
            QtWidgets.QMessageBox.warning(self, "Покупка", "Товара нет на складе")
            return

        dialog = PurchaseDialog(self, product)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        quantity, pickup_point_id = dialog.data()

        today = datetime.now()
        delivery = today + timedelta(days=3)
        receive_code = str(random.randint(100, 999))
        with connect() as conn:
            next_id = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM orders").fetchone()[0]
            articles_text = f"{article}, {quantity}"
            if orders_has_articles_column(conn):
                conn.execute(
                    """
                    INSERT INTO orders(id, articles, order_date, delivery_date,
                                       pickup_point_id, client_user_id, client_name,
                                       receive_code, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        next_id,
                        articles_text,
                        today.strftime("%d.%m.%Y"),
                        delivery.strftime("%d.%m.%Y"),
                        pickup_point_id,
                        user_id_by_name(conn, self.user["full_name"]),
                        self.user["full_name"],
                        receive_code,
                        "Новый",
                    ),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO orders(id, order_date, delivery_date, pickup_point_id,
                                       client_user_id, client_name, receive_code, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        next_id,
                        today.strftime("%d.%m.%Y"),
                        delivery.strftime("%d.%m.%Y"),
                        pickup_point_id,
                        user_id_by_name(conn, self.user["full_name"]),
                        self.user["full_name"],
                        receive_code,
                        "Новый",
                    ),
                )
            replace_order_items(conn, next_id, articles_text)
            conn.execute(
                "UPDATE products SET stock = stock - ? WHERE article = ? AND stock >= ?",
                (quantity, article, quantity),
            )

        self.load_products()
        QtWidgets.QMessageBox.information(
            self,
            "Покупка",
            f"Заказ оформлен. Код получения: {receive_code}",
        )

    def edit_product(self) -> None:
        article = self.selected_product_article()
        if article is None:
            QtWidgets.QMessageBox.information(self, "Товар", "Выберите товар")
            return
        with connect() as conn:
            product = conn.execute("SELECT * FROM products WHERE article = ?", (article,)).fetchone()
        dialog = ProductDialog(self, product)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            data = dialog.data()
            try:
                with connect() as conn:
                    conn.execute(
                        """
                        UPDATE products
                        SET article = ?, name = ?, unit = ?, price = ?, supplier = ?,
                            manufacturer = ?, category = ?, discount = ?, stock = ?,
                            description = ?, photo = ?
                        WHERE article = ?
                        """,
                        (*data, article),
                    )
                self.load_products()
            except sqlite3.IntegrityError:
                QtWidgets.QMessageBox.warning(self, "Ошибка", "Товар с таким артикулом уже есть")

    def delete_product(self) -> None:
        article = self.selected_product_article()
        if article is None:
            QtWidgets.QMessageBox.information(self, "Товар", "Выберите товар")
            return
        answer = QtWidgets.QMessageBox.question(self, "Удаление", "Удалить выбранный товар?")
        if answer == QtWidgets.QMessageBox.Yes:
            try:
                with connect() as conn:
                    conn.execute("DELETE FROM products WHERE article = ?", (article,))
                self.load_products()
            except sqlite3.IntegrityError:
                QtWidgets.QMessageBox.warning(
                    self,
                    "Ошибка",
                    "Нельзя удалить товар, который уже используется в заказах",
                )

    def add_order(self) -> None:
        dialog = OrderDialog(self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            try:
                (
                    order_id,
                    articles_text,
                    order_date,
                    delivery_date,
                    pickup_point_id,
                    client_name,
                    receive_code,
                    status,
                ) = dialog.data()
                with connect() as conn:
                    conn.execute("DELETE FROM products_in_orders WHERE order_id = ?", (order_id,))
                    if orders_has_articles_column(conn):
                        conn.execute(
                            """
                            INSERT INTO orders(id, articles, order_date, delivery_date,
                                               pickup_point_id, client_user_id, client_name,
                                               receive_code, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                order_id,
                                articles_text,
                                order_date,
                                delivery_date,
                                pickup_point_id,
                                user_id_by_name(conn, client_name),
                                client_name,
                                receive_code,
                                status,
                            ),
                        )
                    else:
                        conn.execute(
                            """
                            INSERT INTO orders(id, order_date, delivery_date, pickup_point_id,
                                               client_user_id, client_name, receive_code, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                order_id,
                                order_date,
                                delivery_date,
                                pickup_point_id,
                                user_id_by_name(conn, client_name),
                                client_name,
                                receive_code,
                                status,
                            ),
                        )
                    replace_order_items(conn, order_id, articles_text)
                self.load_orders()
            except sqlite3.IntegrityError:
                QtWidgets.QMessageBox.warning(self, "Ошибка", "Заказ с таким номером уже есть")

    def edit_order(self) -> None:
        order_id = self.selected_order_id()
        if order_id is None:
            QtWidgets.QMessageBox.information(self, "Заказ", "Выберите заказ")
            return
        with connect() as conn:
            order = conn.execute(
                """
                SELECT
                    orders.*,
                    COALESCE(
                        GROUP_CONCAT(products_in_orders.product_article || ', ' || products_in_orders.quantity, ', '),
                        ''
                    ) AS articles
                FROM orders
                LEFT JOIN products_in_orders ON products_in_orders.order_id = orders.id
                WHERE orders.id = ?
                GROUP BY orders.id
                """,
                (order_id,),
            ).fetchone()
        dialog = OrderDialog(self, order)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            try:
                (
                    new_order_id,
                    articles_text,
                    order_date,
                    delivery_date,
                    pickup_point_id,
                    client_name,
                    receive_code,
                    status,
                ) = dialog.data()
                with connect() as conn:
                    if orders_has_articles_column(conn):
                        conn.execute(
                            """
                            UPDATE orders
                            SET id = ?, articles = ?, order_date = ?, delivery_date = ?,
                                pickup_point_id = ?, client_user_id = ?, client_name = ?,
                                receive_code = ?, status = ?
                            WHERE id = ?
                            """,
                            (
                                new_order_id,
                                articles_text,
                                order_date,
                                delivery_date,
                                pickup_point_id,
                                user_id_by_name(conn, client_name),
                                client_name,
                                receive_code,
                                status,
                                order_id,
                            ),
                        )
                    else:
                        conn.execute(
                            """
                            UPDATE orders
                            SET id = ?, order_date = ?, delivery_date = ?,
                                pickup_point_id = ?, client_user_id = ?, client_name = ?,
                                receive_code = ?, status = ?
                            WHERE id = ?
                            """,
                            (
                                new_order_id,
                                order_date,
                                delivery_date,
                                pickup_point_id,
                                user_id_by_name(conn, client_name),
                                client_name,
                                receive_code,
                                status,
                                order_id,
                            ),
                        )
                    replace_order_items(conn, new_order_id, articles_text)
                self.load_orders()
            except sqlite3.IntegrityError:
                QtWidgets.QMessageBox.warning(self, "Ошибка", "Заказ с таким номером уже есть")

    def delete_order(self) -> None:
        order_id = self.selected_order_id()
        if order_id is None:
            QtWidgets.QMessageBox.information(self, "Заказ", "Выберите заказ")
            return
        answer = QtWidgets.QMessageBox.question(self, "Удаление", "Удалить выбранный заказ?")
        if answer == QtWidgets.QMessageBox.Yes:
            with connect() as conn:
                conn.execute("DELETE FROM orders WHERE id = ?", (order_id,))
            self.load_orders()


class ProductCard(QtWidgets.QFrame):
    def __init__(self, product: sqlite3.Row) -> None:
        super().__init__()
        self.product = product
        self.setObjectName("productCard")
        self.setFrameShape(QtWidgets.QFrame.Box)
        self.setLineWidth(2)
        self.setMinimumHeight(150)
        self.set_selected(False)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        photo = QtWidgets.QLabel()
        photo.setObjectName("photoBox")
        photo.setFixedSize(155, 120)
        photo.setAlignment(QtCore.Qt.AlignCenter)
        self._set_photo(photo, product["photo"] or "")
        layout.addWidget(photo)

        info = QtWidgets.QLabel(self._info_text(product))
        info.setObjectName("productTitle")
        info.setTextFormat(QtCore.Qt.RichText)
        info.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        info.setWordWrap(True)
        layout.addWidget(info, 1)

        discount = QtWidgets.QLabel(f"Действующая\nскидка\n{product['discount']}%")
        discount.setObjectName("discountBox")
        discount.setProperty("largeDiscount", product["discount"] > 15)
        discount.setFixedSize(95, 120)
        discount.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(discount)

    def sizeHint(self) -> QtCore.QSize:
        return QtCore.QSize(900, 154)

    def set_selected(self, selected: bool) -> None:
        if selected:
            self.setStyleSheet(
                """
                QFrame#productCard {
                    /* Акцентирование внимания */
                    background: #00FA9A;
                    border: 3px solid #006B4F;
                }
                QLabel#photoBox, QLabel#discountBox {
                    border: 2px solid #000000;
                    /* Основной фон */
                    background: #FFFFFF;
                }
                QLabel#discountBox[largeDiscount="true"] {
                    /* Размер скидки превышает 15% */
                    background: #2E8B57;
                    color: #FFFFFF;
                }
                QLabel#productTitle {
                    font-weight: bold;
                }
                """
            )
            return

        self.setStyleSheet(
            """
            QFrame#productCard {
                /* Основной фон */
                background: #FFFFFF;
                border: 2px solid #000000;
            }
            QLabel#photoBox, QLabel#discountBox {
                border: 2px solid #000000;
                /* Основной фон */
                background: #FFFFFF;
            }
            QLabel#discountBox[largeDiscount="true"] {
                /* Размер скидки превышает 15% */
                background: #2E8B57;
                color: #FFFFFF;
            }
            QLabel#productTitle {
                font-weight: bold;
            }
            """
        )

    def _set_photo(self, label: QtWidgets.QLabel, photo_name: str) -> None:
        path = IMPORT_DIR / photo_name
        pixmap = QtGui.QPixmap(str(path))
        if pixmap.isNull():
            label.setText("Фото")
            return
        label.setPixmap(
            pixmap.scaled(
                145,
                110,
                QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation,
            )
        )

    def _info_text(self, product: sqlite3.Row) -> str:
        return (
            f"{product['category']} | {product['name']}<br>"
            f"Описание товара: {product['description'] or ''}<br>"
            f"Производитель: {product['manufacturer']}<br>"
            f"Поставщик: {product['supplier']}<br>"
            f"Цена: {product['price']:.2f}<br>"
            f"Единица измерения: {product['unit']}<br>"
            f"Количество на складе: {product['stock']}"
        )


class OrderCard(QtWidgets.QFrame):
    def __init__(self, order: sqlite3.Row) -> None:
        super().__init__()
        self.order = order
        self.setObjectName("orderCard")
        self.setFrameShape(QtWidgets.QFrame.Box)
        self.setLineWidth(2)
        self.setMinimumHeight(120)
        self.set_selected(False)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(12)

        info = QtWidgets.QLabel(self._info_text(order))
        info.setObjectName("orderInfo")
        info.setTextFormat(QtCore.Qt.RichText)
        info.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        info.setWordWrap(True)
        layout.addWidget(info, 1)

        delivery = QtWidgets.QLabel(f"Дата доставки<br><b>{order['delivery_date']}</b>")
        delivery.setObjectName("deliveryBox")
        delivery.setTextFormat(QtCore.Qt.RichText)
        delivery.setFixedSize(140, 88)
        delivery.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(delivery)

    def sizeHint(self) -> QtCore.QSize:
        return QtCore.QSize(900, 124)

    def set_selected(self, selected: bool) -> None:
        if selected:
            self.setStyleSheet(
                """
                QFrame#orderCard {
                    /* Акцентирование внимания */
                    background: #00FA9A;
                    border: 3px solid #006B4F;
                }
                QLabel#orderInfo, QLabel#deliveryBox {
                    border: 2px solid #000000;
                    /* Основной фон */
                    background: #FFFFFF;
                    padding: 4px;
                }
                QLabel#orderInfo {
                    font-weight: normal;
                }
                """
            )
            return

        self.setStyleSheet(
            """
            QFrame#orderCard {
                /* Основной фон */
                background: #FFFFFF;
                border: 2px solid #000000;
            }
            QLabel#orderInfo, QLabel#deliveryBox {
                border: 2px solid #000000;
                /* Основной фон */
                background: #FFFFFF;
                padding: 4px;
            }
            QLabel#orderInfo {
                font-weight: normal;
            }
            """
        )

    def _info_text(self, order: sqlite3.Row) -> str:
        return (
            f"<b>{order['articles']}</b><br>"
            f"Статус заказа: {order['status']}<br>"
            f"Адрес пункта выдачи: {order['address'] or ''}<br>"
            f"Дата заказа: {order['order_date']}"
        )


class PurchaseDialog(QtWidgets.QDialog):
    def __init__(self, parent: QtWidgets.QWidget, product: sqlite3.Row) -> None:
        super().__init__(parent)
        uic.loadUi(UI_DIR / "purchase_dialog.ui", self)
        self.productLabel.setText(
            f"Товар: {product['name']} ({product['article']}). "
            f"Доступно на складе: {product['stock']}"
        )
        self.quantitySpin.setMaximum(int(product["stock"]))
        self._load_pickup_points()
        self.buttonBox.accepted.connect(self._validate_and_accept)
        self.buttonBox.rejected.connect(self.reject)

    def _load_pickup_points(self) -> None:
        with connect() as conn:
            points = conn.execute("SELECT id, address FROM pickup_points ORDER BY id").fetchall()
        for point in points:
            self.pickupCombo.addItem(f"{point['id']}. {point['address']}", point["id"])

    def data(self) -> Tuple[int, int]:
        return self.quantitySpin.value(), int(self.pickupCombo.currentData())

    def _validate_and_accept(self) -> None:
        if self.pickupCombo.currentData() is None:
            QtWidgets.QMessageBox.warning(self, "Покупка", "Выберите пункт выдачи")
            return
        self.accept()


class ProductDialog(QtWidgets.QDialog):
    def __init__(self, parent: QtWidgets.QWidget, product: Optional[sqlite3.Row] = None) -> None:
        super().__init__(parent)
        uic.loadUi(UI_DIR / "product_dialog.ui", self)
        self.buttonBox.accepted.connect(self._validate_and_accept)
        self.buttonBox.rejected.connect(self.reject)
        if product is not None:
            self.articleEdit.setText(product["article"])
            self.nameEdit.setText(product["name"])
            self.unitEdit.setText(product["unit"])
            self.priceSpin.setValue(float(product["price"]))
            self.supplierEdit.setText(product["supplier"])
            self.manufacturerEdit.setText(product["manufacturer"])
            self.categoryEdit.setText(product["category"])
            self.discountSpin.setValue(int(product["discount"]))
            self.stockSpin.setValue(int(product["stock"]))
            self.descriptionEdit.setPlainText(product["description"] or "")
            self.photoEdit.setText(product["photo"] or "")

    def data(self) -> tuple:
        return (
            self.articleEdit.text().strip(),
            self.nameEdit.text().strip(),
            self.unitEdit.text().strip() or "шт.",
            self.priceSpin.value(),
            self.supplierEdit.text().strip(),
            self.manufacturerEdit.text().strip(),
            self.categoryEdit.text().strip(),
            self.discountSpin.value(),
            self.stockSpin.value(),
            self.descriptionEdit.toPlainText().strip(),
            self.photoEdit.text().strip(),
        )

    def _validate_and_accept(self) -> None:
        article, name, *_ = self.data()
        if not article or not name:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Заполните артикул и наименование")
            return
        self.accept()


class OrderDialog(QtWidgets.QDialog):
    def __init__(self, parent: QtWidgets.QWidget, order: Optional[sqlite3.Row] = None) -> None:
        super().__init__(parent)
        uic.loadUi(UI_DIR / "order_dialog.ui", self)
        self.buttonBox.accepted.connect(self._validate_and_accept)
        self.buttonBox.rejected.connect(self.reject)
        self._load_pickup_points()
        self._set_next_id()
        if order is not None:
            self.idSpin.setValue(int(order["id"]))
            self.articlesEdit.setText(order["articles"])
            self.orderDateEdit.setText(order["order_date"])
            self.deliveryDateEdit.setText(order["delivery_date"])
            index = self.pickupCombo.findData(order["pickup_point_id"])
            if index >= 0:
                self.pickupCombo.setCurrentIndex(index)
            self.clientEdit.setText(order["client_name"])
            self.codeEdit.setText(order["receive_code"])
            status_index = self.statusCombo.findText(order["status"])
            if status_index >= 0:
                self.statusCombo.setCurrentIndex(status_index)

    def _load_pickup_points(self) -> None:
        with connect() as conn:
            points = conn.execute("SELECT id, address FROM pickup_points ORDER BY id").fetchall()
        for point in points:
            self.pickupCombo.addItem(f"{point['id']}. {point['address']}", point["id"])

    def _set_next_id(self) -> None:
        with connect() as conn:
            next_id = conn.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM orders").fetchone()[0]
        self.idSpin.setValue(int(next_id))

    def data(self) -> tuple:
        return (
            self.idSpin.value(),
            self.articlesEdit.text().strip(),
            self.orderDateEdit.text().strip(),
            self.deliveryDateEdit.text().strip(),
            self.pickupCombo.currentData(),
            self.clientEdit.text().strip(),
            self.codeEdit.text().strip(),
            self.statusCombo.currentText(),
        )

    def _validate_and_accept(self) -> None:
        _, articles, order_date, delivery_date, _, client, code, _ = self.data()
        if not all([articles, order_date, delivery_date, client, code]):
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return
        self.accept()


def main() -> int:
    initialize_database()
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(APP_STYLE)
    icon_path = IMPORT_DIR / "Icon.ico"
    if icon_path.exists():
        app.setWindowIcon(QtGui.QIcon(str(icon_path)))
    window = LoginWindow()
    window.show()
    return app.exec_()


if __name__ == "__main__":
    raise SystemExit(main())
