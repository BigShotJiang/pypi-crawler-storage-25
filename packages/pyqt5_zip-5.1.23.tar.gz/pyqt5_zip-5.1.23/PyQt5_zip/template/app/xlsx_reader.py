from __future__ import annotations

import zipfile
from pathlib import Path
from typing import List, Union
from xml.etree import ElementTree as ET


NS = {
    "a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def read_first_sheet(path: Union[str, Path]) -> List[List[str]]:
    """Read simple xlsx files without an external dependency."""
    with zipfile.ZipFile(path) as archive:
        shared_strings = _read_shared_strings(archive)
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        relmap = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
        sheet = workbook.find(".//a:sheet", NS)
        if sheet is None:
            return []
        rel_id = sheet.attrib[f"{{{NS['r']}}}id"]
        target = "xl/" + relmap[rel_id]
        root = ET.fromstring(archive.read(target))

    rows: List[List[str]] = []
    for row in root.findall(".//a:sheetData/a:row", NS):
        cells = []
        last_col = 0
        for cell in row.findall("a:c", NS):
            col = _column_index(cell.attrib.get("r", "A1"))
            while last_col < col - 1:
                cells.append("")
                last_col += 1
            value = _cell_value(cell, shared_strings)
            cells.append(value)
            last_col = col
        rows.append(cells)
    return rows


def _read_shared_strings(archive: zipfile.ZipFile) -> List[str]:
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    values = []
    for item in root.findall("a:si", NS):
        values.append("".join(text.text or "" for text in item.findall(".//a:t", NS)))
    return values


def _cell_value(cell: ET.Element, shared_strings: List[str]) -> str:
    value_node = cell.find("a:v", NS)
    value = "" if value_node is None else value_node.text or ""
    if cell.attrib.get("t") == "s" and value:
        return shared_strings[int(value)]
    return value


def _column_index(ref: str) -> int:
    letters = "".join(ch for ch in ref if ch.isalpha()).upper()
    result = 0
    for ch in letters:
        result = result * 26 + ord(ch) - ord("A") + 1
    return result or 1
