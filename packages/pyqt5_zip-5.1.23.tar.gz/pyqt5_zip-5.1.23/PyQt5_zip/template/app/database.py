from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from .xlsx_reader import read_first_sheet


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "shoe_shop.sqlite"
IMPORT_DIR = ROOT / "import"


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_database() -> None:
    with connect() as conn:
        _ensure_schema(conn)
        if not _has_data(conn, "users"):
            _seed_users(conn)
        if not _has_data(conn, "products"):
            _seed_products(conn)
        if not _has_data(conn, "pickup_points"):
            _seed_pickup_points(conn)
        if not _has_data(conn, "orders"):
            _seed_orders(conn)


def _ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            full_name TEXT NOT NULL,
            login TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS products (
            article TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            unit TEXT NOT NULL,
            price REAL NOT NULL,
            supplier TEXT NOT NULL,
            manufacturer TEXT NOT NULL,
            category TEXT NOT NULL,
            discount INTEGER NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0,
            description TEXT,
            photo TEXT
        );

        CREATE TABLE IF NOT EXISTS pickup_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            address TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY,
            order_date TEXT NOT NULL,
            delivery_date TEXT NOT NULL,
            pickup_point_id INTEGER,
            client_user_id INTEGER,
            client_name TEXT NOT NULL,
            receive_code TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(id),
            FOREIGN KEY (client_user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS products_in_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_article TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_article) REFERENCES products(article)
        );
        """
    )
    _ensure_column(conn, "orders", "client_user_id", "INTEGER")
    _backfill_order_clients(conn)
    _backfill_products_in_orders(conn)


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def _backfill_products_in_orders(conn: sqlite3.Connection) -> None:
    if _has_data(conn, "products_in_orders"):
        return
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(orders)")}
    if "articles" not in columns:
        return
    rows = conn.execute("SELECT id, articles FROM orders").fetchall()
    for row in rows:
        _replace_order_items(conn, row["id"], row["articles"])


def _backfill_order_clients(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        UPDATE orders
        SET client_user_id = (
            SELECT users.id
            FROM users
            WHERE users.full_name = orders.client_name
        )
        WHERE client_user_id IS NULL
        """
    )


def _has_data(conn: sqlite3.Connection, table: str) -> bool:
    return conn.execute(f"SELECT EXISTS(SELECT 1 FROM {table})").fetchone()[0] == 1


def _seed_users(conn: sqlite3.Connection) -> None:
    rows = read_first_sheet(IMPORT_DIR / "user_import.xlsx")[1:]
    conn.executemany(
        "INSERT INTO users(role, full_name, login, password) VALUES (?, ?, ?, ?)",
        [tuple(row[:4]) for row in rows if len(row) >= 4],
    )


def _seed_products(conn: sqlite3.Connection) -> None:
    rows = read_first_sheet(IMPORT_DIR / "Tovar.xlsx")[1:]
    conn.executemany(
        """
        INSERT INTO products(article, name, unit, price, supplier, manufacturer,
                             category, discount, stock, description, photo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                row[0],
                row[1],
                row[2],
                float(row[3] or 0),
                row[4],
                row[5],
                row[6],
                int(float(row[7] or 0)),
                int(float(row[8] or 0)),
                row[9],
                row[10] if len(row) > 10 else "",
            )
            for row in rows
            if len(row) >= 10 and row[0]
        ],
    )


def _seed_pickup_points(conn: sqlite3.Connection) -> None:
    rows = read_first_sheet(IMPORT_DIR / "Пункты выдачи_import.xlsx")
    conn.executemany(
        "INSERT INTO pickup_points(address) VALUES (?)",
        [(row[0],) for row in rows if row and row[0]],
    )


def _seed_orders(conn: sqlite3.Connection) -> None:
    rows = read_first_sheet(IMPORT_DIR / "Заказ_import.xlsx")[1:]
    for row in rows:
        if len(row) < 8 or not row[0]:
            continue
        order_id = int(float(row[0]))
        client_name = row[5]
        conn.execute(
            """
            INSERT INTO orders(id, order_date, delivery_date, pickup_point_id,
                               client_user_id, client_name, receive_code, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                order_id,
                _normalize_date(row[2]),
                _normalize_date(row[3]),
                int(float(row[4])) if row[4] else None,
                _user_id_by_name(conn, client_name),
                client_name,
                row[6],
                row[7],
            ),
        )
        _replace_order_items(conn, order_id, row[1])


def _user_id_by_name(conn: sqlite3.Connection, full_name: str) -> Optional[int]:
    row = conn.execute("SELECT id FROM users WHERE full_name = ?", (full_name,)).fetchone()
    return row["id"] if row else None


def _replace_order_items(conn: sqlite3.Connection, order_id: int, articles_text: str) -> None:
    conn.execute("DELETE FROM products_in_orders WHERE order_id = ?", (order_id,))
    conn.executemany(
        """
        INSERT INTO products_in_orders(order_id, product_article, quantity)
        VALUES (?, ?, ?)
        """,
        [
            (order_id, article, quantity)
            for article, quantity in _parse_order_items(articles_text)
        ],
    )


def _parse_order_items(articles_text: str) -> list:
    parts = [part.strip() for part in str(articles_text).split(",") if part.strip()]
    items = []
    for index in range(0, len(parts), 2):
        article = parts[index]
        try:
            quantity = int(float(parts[index + 1]))
        except (IndexError, ValueError):
            quantity = 1
        items.append((article, quantity))
    return items


def _normalize_date(value: str) -> str:
    value = str(value).strip()
    if not value:
        return ""
    try:
        serial = float(value)
    except ValueError:
        return value
    date = datetime(1899, 12, 30) + timedelta(days=serial)
    return date.strftime("%d.%m.%Y")
