from __future__ import annotations

import argparse
from pathlib import Path
from typing import Union

from app.database import DB_PATH, initialize_database
import sqlite3


DEFAULT_OUTPUT = Path("database_full_dump.sql")


def dump_database(output_path: Union[str, Path] = DEFAULT_OUTPUT) -> Path:
    """Export the current SQLite database schema and data to an SQL file."""
    initialize_database()

    output = Path(output_path).resolve()
    with sqlite3.connect(DB_PATH) as conn:
        sql_lines = list(conn.iterdump())

    output.write_text("\n".join(sql_lines) + "\n", encoding="utf-8")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Export SQLite schema and INSERT data statements to an SQL file."
    )
    parser.add_argument(
        "output",
        nargs="?",
        default=str(DEFAULT_OUTPUT),
        help="Output SQL file. Defaults to database_full_dump.sql.",
    )
    args = parser.parse_args()

    output = dump_database(args.output)
    print(f"Database SQL dump created: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
