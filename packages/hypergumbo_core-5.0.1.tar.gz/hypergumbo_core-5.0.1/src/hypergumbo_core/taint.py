# SPDX-License-Identifier: AGPL-3.0-or-later
"""Taint catalog loading and taint-flow propagation (ADR-0017 Phases 1-2).

Provides YAML-driven taint source/sink/sanitizer catalogs and a structural
(call-graph BFS) taint-flow analyzer. This is the Phase 1 fallback path
that works for all languages without requiring def/use extractors.

How It Works
------------
1. ``load_taint_catalog()`` reads YAML files defining taint sources (functions
   whose return values carry taint labels), sinks (functions that should not
   receive tainted data), and sanitizers (functions that transform taint).

2. ``propagate_taint_structural()`` performs two-phase BFS on the call graph:
   (a) compute nodes reachable from each taint source without passing through
   sanitizers for the relevant taint label, (b) check if any sink is in that
   reachable set. Reports violations as ``TaintFlowFinding`` objects.

The structural approach cannot distinguish between two variables in the same
function — it operates at the symbol level. Findings are explicitly labeled
``confidence="approximate"`` and ``analysis_method="structural"`` per ADR-0017.
DDG-backed analysis (Phase 2+) will improve precision for languages with
def/use extractors.

Catalog Format
--------------
Sources, sinks, and sanitizers use YAML files following patterns established
by the IO primitive catalogs (ADR-0016). See ``taint_sources/``,
``taint_sinks/``, and ``taint_sanitizers/`` directories alongside this module,
or project-local catalogs provided via ``--taint-sources``, etc.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TaintSource:
    """A function/method/attribute whose return-or-read value carries a taint label.

    Attributes:
        taint_label: The taint category (e.g. "plaintext", "key_material",
            "host_secret", "untrusted_input").
        module: The module or class path (e.g. "cryptography.fernet", "os").
        name: The function/method/attribute name (e.g. "Fernet.decrypt", "environ").
        kind: One of "function", "method", or "attribute".  ``"attribute"``
            covers bare reads like ``os.environ`` or ``sys.argv``; pairs with
            ``module_attr_ref`` edges emitted by the language analyzer
            (WI-guhok for Python; WI-gapam follow-up for tree-sitter langs).
        return_tainted: Whether the return (or read) value is tainted.
        argument_tainted: Indices of arguments that become tainted (optional).
    """

    taint_label: str
    module: str
    name: str
    kind: str  # "function", "method", or "attribute"
    return_tainted: bool = True
    argument_tainted: tuple[int, ...] = ()

    @property
    def qualified_name(self) -> str:
        """Full dotted name: module.name."""
        return f"{self.module}.{self.name}"


@dataclass(frozen=True)
class TaintSink:
    """A function/method/attribute that should not receive tainted data.

    Attributes:
        zone: The trust zone (e.g. "host_fs", "network", "host_env", "ipc",
            "browser_storage", "relay").
        trust_level: The trust level (e.g. "untrusted", "semi-trusted").
        module: The module or class path.
        name: The function/method/attribute name.
        kind: One of "function", "method", or "attribute".
    """

    zone: str
    trust_level: str
    module: str
    name: str
    kind: str  # "function", "method", or "attribute"

    @property
    def qualified_name(self) -> str:
        """Full dotted name: module.name."""
        return f"{self.module}.{self.name}"


@dataclass(frozen=True)
class TaintSanitizer:
    """A function that transforms one taint label into another.

    Attributes:
        input_taint: The taint label consumed (e.g. "plaintext").
        output_taint: The taint label produced (e.g. "ciphertext").
        qualified_name: Full dotted name (e.g. "cryptography.fernet.Fernet.encrypt").
    """

    input_taint: str
    output_taint: str
    qualified_name: str

    @property
    def short_name(self) -> str:
        """Extract the shortest unambiguous suffix.

        For dotted names (Python style), takes the last two segments:
        "cryptography.fernet.Fernet.encrypt" → "Fernet.encrypt"

        For double-colon names (Rust style), takes the last segment:
        "aes_gcm::Aes256Gcm::encrypt" → "encrypt"
        """
        if "::" in self.qualified_name:
            return self.qualified_name.rsplit("::", 1)[-1]
        parts = self.qualified_name.rsplit(".", 2)
        if len(parts) >= 2:
            return f"{parts[-2]}.{parts[-1]}"
        return self.qualified_name


@dataclass
class TaintFlowFinding:
    """A reported taint-flow violation or confirmed path.

    Attributes:
        taint_label: The taint category that flowed to the sink.
        source_symbol: Symbol ID of the function containing the taint source.
        source_primitive: Name of the taint source function.
        sink_symbol: Symbol ID of the sink function call.
        sink_primitive: Name of the sink function.
        sink_zone: Trust zone of the sink.
        sanitized: Whether all paths from source to sink are sanitized.
        confidence: "approximate" for structural, "precise" for DDG-backed.
        analysis_method: "structural" or "ddg".
        path: List of symbol IDs on the path from source to sink.
    """

    taint_label: str
    source_symbol: str
    source_primitive: str
    sink_symbol: str
    sink_primitive: str
    sink_zone: str
    sanitized: bool
    confidence: str  # "approximate" or "precise"
    analysis_method: str  # "structural" or "ddg"
    path: list[str] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        """Return verdict string based on sanitization status."""
        return "confirmed_safe" if self.sanitized else "violated"

    def to_dict(self) -> dict:
        """Serialize to JSON-friendly dict."""
        return {
            "taint_label": self.taint_label,
            "source_symbol": self.source_symbol,
            "source_primitive": self.source_primitive,
            "sink_symbol": self.sink_symbol,
            "sink_primitive": self.sink_primitive,
            "sink_zone": self.sink_zone,
            "verdict": self.verdict,
            "sanitized": self.sanitized,
            "confidence": self.confidence,
            "analysis_method": self.analysis_method,
            "path": self.path,
        }


# ---------------------------------------------------------------------------
# Catalog container
# ---------------------------------------------------------------------------


@dataclass
class TaintCatalog:
    """Container for all taint sources, sinks, and sanitizers.

    Organizes entries by language for efficient lookup. Provides matching
    methods that check callee names against catalog entries.
    """

    _sources: dict[str, list[TaintSource]] = field(default_factory=dict)
    _sinks: dict[str, list[TaintSink]] = field(default_factory=dict)
    _sanitizers: dict[str, list[TaintSanitizer]] = field(default_factory=dict)

    # Lookup indices built from entries
    _source_by_name: dict[str, dict[str, list[TaintSource]]] = field(
        default_factory=dict, repr=False,
    )
    _sink_by_name: dict[str, dict[str, list[TaintSink]]] = field(
        default_factory=dict, repr=False,
    )
    _sanitizer_by_name: dict[str, dict[str, list[TaintSanitizer]]] = field(
        default_factory=dict, repr=False,
    )

    def _rebuild_indices(self) -> None:
        """Build name-based lookup indices for all languages."""
        self._source_by_name.clear()
        self._sink_by_name.clear()
        self._sanitizer_by_name.clear()

        for lang, sources in self._sources.items():
            idx: dict[str, list[TaintSource]] = {}
            for src in sources:
                idx.setdefault(src.name, []).append(src)
                idx.setdefault(src.qualified_name, []).append(src)
            self._source_by_name[lang] = idx

        for lang, sinks in self._sinks.items():
            idx_s: dict[str, list[TaintSink]] = {}
            for sink in sinks:
                idx_s.setdefault(sink.name, []).append(sink)
                idx_s.setdefault(sink.qualified_name, []).append(sink)
            self._sink_by_name[lang] = idx_s

        for lang, sanitizers in self._sanitizers.items():
            idx_san: dict[str, list[TaintSanitizer]] = {}
            for san in sanitizers:
                idx_san.setdefault(san.qualified_name, []).append(san)
                idx_san.setdefault(san.short_name, []).append(san)
            self._sanitizer_by_name[lang] = idx_san

    def sources_for_language(self, language: str) -> list[TaintSource]:
        """Return all taint sources for a language."""
        return list(self._sources.get(language, []))

    def sinks_for_language(self, language: str) -> list[TaintSink]:
        """Return all taint sinks for a language."""
        return list(self._sinks.get(language, []))

    def sanitizers_for_language(self, language: str) -> list[TaintSanitizer]:
        """Return all taint sanitizers for a language."""
        return list(self._sanitizers.get(language, []))

    def match_source(
        self,
        language: str,
        callee_name: str,
        module_hint: str | None = None,
    ) -> Optional[TaintSource]:
        """Match a callee name against taint sources for a language.

        Tries qualified name first, then short name. Returns first match.
        """
        idx = self._source_by_name.get(language, {})
        hits = idx.get(callee_name)
        if hits:
            if module_hint:
                for h in hits:
                    if module_hint in h.module or h.module in module_hint:
                        return h
            return hits[0]
        return None

    def match_sink(
        self,
        language: str,
        callee_name: str,
        module_hint: str | None = None,
    ) -> Optional[TaintSink]:
        """Match a callee name against taint sinks for a language."""
        idx = self._sink_by_name.get(language, {})
        hits = idx.get(callee_name)
        if hits:
            if module_hint:
                for h in hits:
                    if module_hint in h.module or h.module in module_hint:
                        return h
            return hits[0]
        return None

    def match_sanitizer(
        self,
        language: str,
        callee_name: str,
        input_taint: str,
    ) -> Optional[TaintSanitizer]:
        """Match a callee name against sanitizers that handle the given taint label."""
        idx = self._sanitizer_by_name.get(language, {})
        hits = idx.get(callee_name)
        if not hits:
            return None
        for h in hits:
            if h.input_taint == input_taint:
                return h
        return None


# ---------------------------------------------------------------------------
# YAML catalog loading
# ---------------------------------------------------------------------------


def _load_source_yaml(path: Path) -> tuple[str, list[TaintSource]]:
    """Load a single taint source YAML file.

    Returns (taint_label, flat list of TaintSource entries across all languages).
    """
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    label = data.get("taint_label", "unknown")
    sources_by_lang: dict[str, list[TaintSource]] = {}

    for lang, entries in data.get("sources", {}).items():
        lang_sources: list[TaintSource] = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            module = entry.get("module", "")
            return_tainted = entry.get("return_tainted", True)
            arg_tainted = tuple(entry.get("argument_tainted", []))

            for func_name in entry.get("functions", []):
                lang_sources.append(TaintSource(
                    taint_label=label,
                    module=module,
                    name=func_name,
                    kind="function",
                    return_tainted=return_tainted,
                    argument_tainted=arg_tainted,
                ))
            for method_name in entry.get("methods", []):
                lang_sources.append(TaintSource(
                    taint_label=label,
                    module=module,
                    name=method_name,
                    kind="method",
                    return_tainted=return_tainted,
                    argument_tainted=arg_tainted,
                ))
        sources_by_lang[lang] = lang_sources

    return label, sources_by_lang  # type: ignore[return-value]


def _load_sink_yaml(path: Path) -> dict[str, list[TaintSink]]:
    """Load a single taint sink YAML file.

    Returns dict mapping language → list of TaintSink entries.
    """
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    zone = data.get("zone", "unknown")
    trust_level = data.get("trust_level", "unknown")
    sinks_by_lang: dict[str, list[TaintSink]] = {}

    for lang, entries in data.get("sinks", {}).items():
        lang_sinks: list[TaintSink] = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            module = entry.get("module", "")

            for func_name in entry.get("functions", []):
                lang_sinks.append(TaintSink(
                    zone=zone,
                    trust_level=trust_level,
                    module=module,
                    name=func_name,
                    kind="function",
                ))
            for method_name in entry.get("methods", []):
                lang_sinks.append(TaintSink(
                    zone=zone,
                    trust_level=trust_level,
                    module=module,
                    name=method_name,
                    kind="method",
                ))
        sinks_by_lang[lang] = lang_sinks

    return sinks_by_lang


def _load_sanitizer_yaml(path: Path) -> dict[str, list[TaintSanitizer]]:
    """Load a single taint sanitizer YAML file.

    Returns dict mapping language → list of TaintSanitizer entries.
    """
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    sanitizers_by_lang: dict[str, list[TaintSanitizer]] = {}

    for transform in data.get("transforms", []):
        input_taint = transform.get("input_taint", "unknown")
        output_taint = transform.get("output_taint", "unknown")

        for lang, func_names in transform.get("functions", {}).items():
            lang_sans = sanitizers_by_lang.setdefault(lang, [])
            for func_name in func_names:
                lang_sans.append(TaintSanitizer(
                    input_taint=input_taint,
                    output_taint=output_taint,
                    qualified_name=func_name,
                ))

    return sanitizers_by_lang


def load_taint_catalog(
    source_paths: list[Path],
    sink_paths: list[Path],
    sanitizer_paths: list[Path],
) -> TaintCatalog:
    """Load taint catalogs from YAML files.

    Args:
        source_paths: Paths to taint source YAML files.
        sink_paths: Paths to taint sink YAML files.
        sanitizer_paths: Paths to taint sanitizer YAML files.

    Returns:
        A TaintCatalog with all entries indexed by language.
    """
    all_sources: dict[str, list[TaintSource]] = defaultdict(list)
    all_sinks: dict[str, list[TaintSink]] = defaultdict(list)
    all_sanitizers: dict[str, list[TaintSanitizer]] = defaultdict(list)

    for path in source_paths:
        _label, sources_by_lang = _load_source_yaml(path)
        for lang, sources in sources_by_lang.items():
            all_sources[lang].extend(sources)

    for path in sink_paths:
        sinks_by_lang = _load_sink_yaml(path)
        for lang, sinks in sinks_by_lang.items():
            all_sinks[lang].extend(sinks)

    for path in sanitizer_paths:
        sanitizers_by_lang = _load_sanitizer_yaml(path)
        for lang, sans in sanitizers_by_lang.items():
            all_sanitizers[lang].extend(sans)

    catalog = TaintCatalog(
        _sources=dict(all_sources),
        _sinks=dict(all_sinks),
        _sanitizers=dict(all_sanitizers),
    )
    catalog._rebuild_indices()
    return catalog


# ---------------------------------------------------------------------------
# Auto-import from io_primitives (WI-lokuv)
# ---------------------------------------------------------------------------
#
# ADR-0017 deliberately separates io_primitives (syscall-level IO boundary
# classification) from taint_sinks/sources (trust-zone classification).  The
# rationale holds for project-local extension — every project has its own
# trust-zone structure — but the shipped *first-party* catalogs should not
# drift: every io_primitives write-side primitive is, by construction, a
# candidate sink for tainted data; every io_primitives read-side primitive
# for a sensitive category is a candidate source.
#
# The mapping below encodes that default.  Auto-import is paranoid by
# design ("reading A" in the WI-lokuv discussion): each auto-derived sink
# is trust_level=untrusted and matches ANY taint label; each auto-derived
# source carries the label indicated below.  Users narrow the default by
# contributing overrides in taint_sources/ or taint_sinks/ that match by
# (module, name, kind) — the user entry wins, the auto entry is dropped.
#
# `fs_read` is intentionally absent from the source map: reading a file
# does not by itself make its contents sensitive; the label is project-
# specific (a config file vs. a credential vault vs. user-uploaded JSON).
# Projects that want every fs_read tainted can declare their own source
# catalog entries.
AUTO_SINK_ZONE_MAP: dict[str, tuple[str, str]] = {
    # io_primitives boundary -> (taint zone, trust_level)
    "fs_write": ("host_fs", "untrusted"),
    "subprocess": ("host_fs", "untrusted"),
    "net_send": ("network", "untrusted"),
    "env_write": ("host_env", "untrusted"),
    "ipc_send": ("ipc", "untrusted"),
    "browser_storage_write": ("browser_storage", "untrusted"),
}

AUTO_SOURCE_LABEL_MAP: dict[str, str] = {
    # io_primitives boundary -> taint_label for auto-derived source
    "env_read": "host_secret",
    "net_recv": "untrusted_input",
    "ipc_recv": "untrusted_input",
}


def _derive_auto_imports_from_io_primitives(
    io_catalog_dir: Path,
) -> tuple[dict[str, list[TaintSource]], dict[str, list[TaintSink]]]:
    """Scan io_primitives/*.yaml and derive default taint sources + sinks.

    Returns ``(sources_by_lang, sinks_by_lang)``.  Each IoPrimitive whose
    ``boundary`` matches :data:`AUTO_SOURCE_LABEL_MAP` yields a TaintSource;
    each IoPrimitive whose ``boundary`` matches :data:`AUTO_SINK_ZONE_MAP`
    yields a TaintSink.  Language is taken from each YAML's ``language:``
    field.  Primitives declared under YAML ``attributes:`` produce
    ``kind="attribute"`` records — these pair with ``module_attr_ref``
    edges emitted by language analyzers (see WI-guhok, WI-gapam).
    """
    from hypergumbo_core.io_boundary import IoBoundaryCatalog

    sources_by_lang: dict[str, list[TaintSource]] = defaultdict(list)
    sinks_by_lang: dict[str, list[TaintSink]] = defaultdict(list)

    if not io_catalog_dir.is_dir():
        return dict(sources_by_lang), dict(sinks_by_lang)

    for yaml_path in sorted(io_catalog_dir.glob("*.yaml")):
        catalog = IoBoundaryCatalog.from_yaml(yaml_path)
        lang = catalog.language
        for prim in catalog.primitives:
            if prim.boundary in AUTO_SOURCE_LABEL_MAP:
                sources_by_lang[lang].append(TaintSource(
                    taint_label=AUTO_SOURCE_LABEL_MAP[prim.boundary],
                    module=prim.module,
                    name=prim.name,
                    kind=prim.kind,
                ))
            if prim.boundary in AUTO_SINK_ZONE_MAP:
                zone, trust = AUTO_SINK_ZONE_MAP[prim.boundary]
                sinks_by_lang[lang].append(TaintSink(
                    zone=zone,
                    trust_level=trust,
                    module=prim.module,
                    name=prim.name,
                    kind=prim.kind,
                ))

    return dict(sources_by_lang), dict(sinks_by_lang)


def _merge_with_user_override(
    auto_by_lang: dict[str, list],
    user_by_lang: dict[str, list],
) -> dict[str, list]:
    """Merge auto-derived entries with user entries; user entries win on
    (module, name, kind) match.

    The result preserves every user entry and adds auto entries whose
    (module, name, kind) triple is not already declared by the user.
    Works for both TaintSource and TaintSink (both expose those fields).
    """
    merged: dict[str, list] = {}
    all_langs = set(auto_by_lang) | set(user_by_lang)
    for lang in all_langs:
        user_list = user_by_lang.get(lang, [])
        user_keys = {(e.module, e.name, e.kind) for e in user_list}
        auto_list = auto_by_lang.get(lang, [])
        filtered_auto = [
            e for e in auto_list
            if (e.module, e.name, e.kind) not in user_keys
        ]
        merged[lang] = filtered_auto + list(user_list)
    return merged


# ---------------------------------------------------------------------------
# Built-in catalog discovery
# ---------------------------------------------------------------------------

_TAINT_SOURCES_DIR = Path(__file__).parent / "taint_sources"
_TAINT_SINKS_DIR = Path(__file__).parent / "taint_sinks"
_TAINT_SANITIZERS_DIR = Path(__file__).parent / "taint_sanitizers"
_IO_PRIMITIVES_DIR = Path(__file__).parent / "io_primitives"


def _resolve_catalog_paths(paths: list[Path]) -> list[Path]:
    """Resolve project-local taint-catalog path arguments to a file list.

    Each input path is either a single YAML file (``*.yaml``/``*.yml``) or a
    directory — directories are globbed for ``*.yaml`` (sorted for
    deterministic merge order).  Raises :class:`FileNotFoundError` on any
    missing path so a typo in a CLI flag or claims-file entry does not
    silently fall through to the built-in defaults.
    """
    resolved: list[Path] = []
    for p in paths:
        if not p.exists():
            raise FileNotFoundError(f"Taint catalog path not found: {p}")
        if p.is_dir():
            resolved.extend(sorted(p.glob("*.yaml")))
        else:
            resolved.append(p)
    return resolved


def load_full_taint_catalog(
    extra_source_paths: list[Path] | None = None,
    extra_sink_paths: list[Path] | None = None,
    extra_sanitizer_paths: list[Path] | None = None,
) -> TaintCatalog:
    """Load built-in taint catalogs and merge in user-supplied YAML files.

    The three argument lists (``extra_source_paths``, ``extra_sink_paths``,
    ``extra_sanitizer_paths``) accept YAML files or directories of YAMLs —
    resolved via :func:`_resolve_catalog_paths`.  Each layer stacks on top
    of the one below it:

    1. Auto-derived taint entries from ``io_primitives/*.yaml`` (paranoid
       default: every write-side primitive is a sink, every read-side
       sensitive primitive is a source).
    2. Built-in YAML under ``taint_sources/`` / ``taint_sinks/`` /
       ``taint_sanitizers/`` alongside this module.
    3. User ``extra_*_paths`` passed by this call.

    Override semantics for sources and sinks: an entry in a higher layer
    whose ``(module, name, kind)`` triple matches an entry in a lower
    layer replaces it.  This is the same rule :func:`_merge_with_user_override`
    already applies between layers 1 and 2 — it now also applies between
    layer 2 and layer 3.  Sanitizers do not have a ``(module, name, kind)``
    key (they key on ``qualified_name``) so user sanitizers concatenate
    onto the built-in list.

    The helper is the single entry point for end-users running
    ``verify-claims`` on a repo other than hypergumbo's own: the CLI
    flags ``--taint-sources`` / ``--taint-sinks`` / ``--taint-sanitizers``
    and the ``extra_catalogs:`` key in the claims-file YAML both flow
    through here (WI-votan).
    """
    extra_source_paths = _resolve_catalog_paths(extra_source_paths or [])
    extra_sink_paths = _resolve_catalog_paths(extra_sink_paths or [])
    extra_sanitizer_paths = _resolve_catalog_paths(
        extra_sanitizer_paths or [],
    )

    catalog = load_builtin_taint_catalog()

    if not (
        extra_source_paths or extra_sink_paths or extra_sanitizer_paths
    ):
        return catalog

    extra_catalog = load_taint_catalog(
        extra_source_paths, extra_sink_paths, extra_sanitizer_paths,
    )

    catalog._sources = _merge_with_user_override(
        catalog._sources, extra_catalog._sources,
    )
    catalog._sinks = _merge_with_user_override(
        catalog._sinks, extra_catalog._sinks,
    )
    for lang, sans in extra_catalog._sanitizers.items():
        catalog._sanitizers.setdefault(lang, []).extend(sans)
    catalog._rebuild_indices()
    return catalog


def load_builtin_taint_catalog() -> TaintCatalog:
    """Load built-in taint catalogs shipped with hypergumbo.

    Two contributions merge into one catalog:

    1. YAML-declared entries in ``taint_sources/``, ``taint_sinks/``, and
       ``taint_sanitizers/``.  These cover project-agnostic domains the
       core team maintains explicitly (crypto decryption labels, key
       material generation, ...) and provide the project-local extension
       point described in ADR-0017.
    2. Auto-derived entries from ``io_primitives/*.yaml`` (WI-lokuv).
       Every write-side IO primitive becomes a TaintSink at
       trust_level=untrusted with a zone determined by its boundary
       category; every read-side sensitive-category primitive becomes a
       TaintSource with a default taint_label.  User YAML entries that
       match (module, name, kind) override the auto-derived defaults.

    The merge makes io_primitives the single source of truth for primitive
    enumeration: adding a primitive there propagates into taint analysis
    automatically, which replaces the manual drift-guard previously shipped
    under WI-hizik.
    """
    source_paths = sorted(_TAINT_SOURCES_DIR.glob("*.yaml")) if _TAINT_SOURCES_DIR.exists() else []
    sink_paths = sorted(_TAINT_SINKS_DIR.glob("*.yaml")) if _TAINT_SINKS_DIR.exists() else []
    sanitizer_paths = sorted(_TAINT_SANITIZERS_DIR.glob("*.yaml")) if _TAINT_SANITIZERS_DIR.exists() else []
    user_catalog = load_taint_catalog(source_paths, sink_paths, sanitizer_paths)

    auto_sources, auto_sinks = _derive_auto_imports_from_io_primitives(
        _IO_PRIMITIVES_DIR,
    )
    user_catalog._sources = _merge_with_user_override(
        auto_sources, user_catalog._sources,
    )
    user_catalog._sinks = _merge_with_user_override(
        auto_sinks, user_catalog._sinks,
    )
    user_catalog._rebuild_indices()
    return user_catalog


# ---------------------------------------------------------------------------
# Structural taint-flow propagation (Phase 1 fallback)
# ---------------------------------------------------------------------------


def _extract_callee_name(symbol_id: str) -> str:
    """Extract the callee function name from a symbol ID.

    Symbol ID format: {lang}:{file_or_module}:{start}-{end}:{name}:{kind}
    For unresolved externals: {lang}:external:0-0:{name}:unresolved

    Handles names containing colons (ObjC selectors) by parsing from
    both ends: language is before the first colon, kind is after the last.
    """
    parts = symbol_id.split(":")
    if len(parts) < 5:
        return symbol_id
    # For names with colons (ObjC selectors), reconstruct from middle parts
    # Format: lang:file:line-range:name:kind
    # Parse from both ends
    # Find the line range (contains a dash)
    line_range_idx = -1
    for i in range(1, len(parts) - 1):
        if "-" in parts[i] and parts[i].replace("-", "").isdigit():
            line_range_idx = i
            break
    if line_range_idx < 0:
        return parts[-2] if len(parts) >= 2 else symbol_id

    # Name is everything between line_range and kind
    name_parts = parts[line_range_idx + 1: -1]
    return ":".join(name_parts)


# Edge types that represent call-like relationships for taint propagation.
# Includes direct calls and cross-language linker bridge edges (ADR-0017 §5).
#
# ADR-0023 §6 Phase 2 audit (WI-sahab-fatoz): mixes relationship-axis
# (``calls``, ``module_attr_ref``), pending_classification
# (``implements_rpc``), and endpoint_shape bridge values. Forward-
# compatible through Phase 3 because ``calls`` is already a member, so
# bridges folding into ``calls`` + ``meta["bridge_kind"]`` continue to
# match; bridge entries become dead-but-harmless and get pruned in
# Phase 4.
TAINT_CALL_EDGE_TYPES = frozenset({
    "calls",
    # WI-lokuv: attribute-read edges for IO primitives declared under
    # ``attributes:`` in io_primitives YAML (os.environ, sys.argv, ...).
    # Emitted by the Python analyzer per WI-guhok; extending to the
    # tree-sitter analyzer base class is tracked as WI-gapam.  Without
    # this edge type, auto-imported TaintSource records for attribute
    # kind primitives would never match in structural propagation.
    "module_attr_ref",
    # pending_classification entries awaiting per-family audit
    # (implements_rpc). Bridge edges no longer enumerated explicitly:
    # post-Phase-3 (WI-mifor-vabul), every bridge folds to 'calls' which
    # is already a member; meta['bridge_kind'] carries the bridge type.
    # Protocol-call family (WI-vumum-juvil) similarly folds into 'calls'
    # + meta['protocol'], so HTTP/gRPC/GraphQL taint propagation
    # transfers automatically.
    "implements_rpc",
})


def _build_adjacency(
    edges: list[dict],
) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """Build forward and reverse adjacency lists from edge dicts.

    Includes call-type edges and cross-language linker bridge edges
    (ADR-0017 §5). Bridge edges are taint-transparent by default —
    IPC serialization does not sanitize taint.
    Returns (forward_adj, reverse_adj).
    """
    forward: dict[str, set[str]] = defaultdict(set)
    reverse: dict[str, set[str]] = defaultdict(set)

    call_types = TAINT_CALL_EDGE_TYPES

    for edge in edges:
        etype = edge.get("type", "")
        if etype not in call_types:
            continue
        src = edge["src"]
        dst = edge["dst"]
        forward[src].add(dst)
        reverse[dst].add(src)

    return dict(forward), dict(reverse)


def propagate_taint_structural(
    edges: list[dict],
    sources: list[TaintSource],
    sinks: list[TaintSink],
    sanitizers: list[TaintSanitizer],
) -> list[TaintFlowFinding]:
    """Structural taint-flow propagation via call-graph BFS.

    Two-phase BFS per ADR-0017 §3b:
    1. For each taint source, compute the set of nodes reachable from the
       source's caller without passing through any sanitizer for that
       taint label.
    2. Check if any taint sink is in the reachable set.

    This is an overapproximation: it cannot distinguish between different
    variables in the same function. Findings are labeled as approximate.

    Args:
        edges: List of edge dicts with "src", "dst", "type" keys.
        sources: Taint source definitions.
        sinks: Taint sink definitions.
        sanitizers: Taint sanitizer definitions.

    Returns:
        List of TaintFlowFinding for each source→sink violation.
    """
    if not edges or not sources or not sinks:
        return []

    forward_adj, reverse_adj = _build_adjacency(edges)

    # Index: callee name → source/sink/sanitizer
    # Index by qualified name, catalog name, AND short method name (last
    # component after dots) to match unresolved edges that only have the
    # bare method name (e.g., "decrypt" instead of "Fernet.decrypt").
    source_by_callee: dict[str, TaintSource] = {}
    for src in sources:
        source_by_callee[src.name] = src
        source_by_callee[src.qualified_name] = src
        # Also index by bare method name for unresolved edge matching
        if "." in src.name:
            source_by_callee[src.name.rsplit(".", 1)[-1]] = src

    sink_by_callee: dict[str, TaintSink] = {}
    for sink in sinks:
        sink_by_callee[sink.name] = sink
        sink_by_callee[sink.qualified_name] = sink
        if "." in sink.name:
            sink_by_callee[sink.name.rsplit(".", 1)[-1]] = sink

    sanitizer_by_callee: dict[str, TaintSanitizer] = {}
    for san in sanitizers:
        sanitizer_by_callee[san.qualified_name] = san
        sanitizer_by_callee[san.short_name] = san

    # Step 1: Find source call sites — which symbol IDs call taint sources?
    # A "source caller" is a node that has an outgoing call edge to a source.
    source_callers: list[tuple[str, str, TaintSource]] = []
    # (caller_symbol_id, source_callee_symbol_id, TaintSource)
    for edge in edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = source_by_callee.get(callee_name)
        if matched:
            source_callers.append((edge["src"], edge["dst"], matched))

    # Step 2: Find sink call sites — which symbol IDs call taint sinks?
    sink_callers: dict[str, tuple[str, TaintSink]] = {}
    # Maps caller_symbol_id → (sink_callee_symbol_id, TaintSink)
    for edge in edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = sink_by_callee.get(callee_name)
        if matched:
            sink_callers[edge["src"]] = (edge["dst"], matched)

    # Step 3: Find sanitizer call sites
    sanitizer_callers: dict[str, dict[str, TaintSanitizer]] = defaultdict(dict)
    # Maps caller_symbol_id → {input_taint → TaintSanitizer}
    for edge in edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = sanitizer_by_callee.get(callee_name)
        if matched:
            sanitizer_callers[edge["src"]][matched.input_taint] = matched

    # Step 4: For each source, BFS forward to find reachable sinks
    # without passing through sanitizers.
    findings: list[TaintFlowFinding] = []

    for caller_id, _source_callee_id, taint_source in source_callers:
        taint_label = taint_source.taint_label

        # Phase 1: BFS from source caller, skip nodes that are sanitizers
        # for this taint label. Sanitizer nodes are NOT added to the
        # reachable set — they block taint propagation entirely.
        reachable: set[str] = set()
        sanitized_nodes: set[str] = set()
        parent: dict[str, str | None] = {caller_id: None}
        queue: deque[str] = deque([caller_id])

        while queue:
            node = queue.popleft()
            if node in reachable or node in sanitized_nodes:  # pragma: no cover
                continue

            # Check if this node is a sanitizer for our taint label.
            # The source caller is exempt — it must always be reachable
            # as the taint origin.
            node_sanitizers = sanitizer_callers.get(node, {})
            if taint_label in node_sanitizers and node != caller_id:
                sanitized_nodes.add(node)
                continue

            reachable.add(node)

            for neighbor in forward_adj.get(node, set()):
                if neighbor not in reachable and neighbor not in parent:
                    parent[neighbor] = node
                    queue.append(neighbor)

        # Phase 2: Check if any sink caller or sink callee is reachable
        for sink_node, (sink_callee_id, taint_sink) in sink_callers.items():
            if sink_node in reachable:
                # Reconstruct path
                path = _reconstruct_path(parent, caller_id, sink_node)
                findings.append(TaintFlowFinding(
                    taint_label=taint_label,
                    source_symbol=caller_id,
                    source_primitive=taint_source.name,
                    sink_symbol=sink_callee_id,
                    sink_primitive=taint_sink.name,
                    sink_zone=taint_sink.zone,
                    sanitized=False,
                    confidence="approximate",
                    analysis_method="structural",
                    path=path,
                ))

    return findings


def _reconstruct_path(
    parent: dict[str, str | None],
    start: str,
    end: str,
) -> list[str]:
    """Reconstruct a path from start to end using parent pointers."""
    path = [end]
    current = end
    while current != start and current in parent and parent[current] is not None:
        current = parent[current]  # type: ignore[assignment]
        path.append(current)
    path.reverse()
    return path


# ---------------------------------------------------------------------------
# Field-sensitivity lite (ADR-0017 §7a)
# ---------------------------------------------------------------------------


def is_field_tainted(variable: str, tainted_vars: set[str]) -> bool:
    """Check if a variable name inherits taint from a tainted base.

    Field-sensitivity lite rules (ADR-0017 §7a):
    - If ``x`` is tainted, then ``x.field``, ``x.method``, ``x[key]`` are tainted.
    - If ``obj.field`` is tainted, only ``obj.field`` is tainted (not ``obj``).
    - Direct match: ``x`` in tainted_vars → True.
    - Field access: ``x.anything`` where ``x`` is in tainted_vars → True.

    Args:
        variable: Variable name to check (may contain dots for field access).
        tainted_vars: Set of currently tainted variable names.

    Returns:
        True if the variable is tainted (directly or via field access on
        a tainted base).
    """
    if variable in tainted_vars:
        return True

    # Check if this is a field access on a tainted base: x.field where x is tainted
    if "." in variable:
        base = variable.split(".")[0]
        if base in tainted_vars:
            return True

    return False


# ---------------------------------------------------------------------------
# DDG-backed taint propagation (ADR-0017 §3a, §3c-3d)
# ---------------------------------------------------------------------------


def propagate_taint_ddg(
    ddg_edges: list,
    call_edges: list[dict],
    sources: list[TaintSource],
    sinks: list[TaintSink],
    sanitizers: list[TaintSanitizer],
    ddg_symbols: set[str] | None = None,
) -> list[TaintFlowFinding]:
    """DDG-backed taint-flow propagation with mixed-coverage analysis.

    When DDG (data dependence graph) edges are available for a function,
    taint propagation uses variable-level precision instead of symbol-level
    BFS. For functions without DDG data, structural reachability bridges
    the gap.

    Algorithm (ADR-0017 §3a):
    1. Identify taint source call sites from call_edges.
    2. For source functions with DDG data: walk forward through DDG edges
       to see which variables carry taint.
    3. At call sites within DDG-analyzed functions, check if the callee
       is a sanitizer (transforms taint) or a sink (reports finding).
    4. For functions without DDG data on the path, fall back to structural
       reachability.

    Mixed-coverage verdict (ADR-0017 §3c-3d):
    - If source AND sink functions both have DDG data: ``confidence="precise"``
    - If either lacks DDG data: ``confidence="approximate"``
    - Structural-only findings (no DDG anywhere): fall back entirely to
      ``propagate_taint_structural()``.

    Args:
        ddg_edges: DdgEdge objects from ``solve_reaching_defs()``.
        call_edges: Edge dicts with "src", "dst", "type" keys.
        sources: Taint source definitions.
        sinks: Taint sink definitions.
        sanitizers: Taint sanitizer definitions.
        ddg_symbols: Set of symbol IDs that have DDG analysis data.
            Functions in this set use DDG-precision; others use structural.

    Returns:
        List of TaintFlowFinding objects.
    """
    if not ddg_edges or not sources or not sinks:
        return []

    analyzed = ddg_symbols or set()

    # Index DDG edges by (def_block, def_line, variable) for forward walk
    # Actually, index by (def_block, variable) → list of use locations
    ddg_forward: dict[tuple[str, str], list] = defaultdict(list)
    for edge in ddg_edges:
        key = (edge.def_block, edge.variable)
        ddg_forward[key].append(edge)

    # Index sources, sinks, sanitizers by name (same as structural)
    source_by_callee: dict[str, TaintSource] = {}
    for src in sources:
        source_by_callee[src.name] = src
        source_by_callee[src.qualified_name] = src
        if "." in src.name:
            source_by_callee[src.name.rsplit(".", 1)[-1]] = src

    sink_by_callee: dict[str, TaintSink] = {}
    for sink in sinks:
        sink_by_callee[sink.name] = sink
        sink_by_callee[sink.qualified_name] = sink
        if "." in sink.name:
            sink_by_callee[sink.name.rsplit(".", 1)[-1]] = sink

    sanitizer_by_callee: dict[str, TaintSanitizer] = {}
    for san in sanitizers:
        sanitizer_by_callee[san.qualified_name] = san
        sanitizer_by_callee[san.short_name] = san
        # Also index by bare method name for unresolved edge matching
        if "." in san.qualified_name:
            sanitizer_by_callee[san.qualified_name.rsplit(".", 1)[-1]] = san

    # Build call-graph adjacency for structural fallback
    forward_adj, _reverse_adj = _build_adjacency(call_edges)

    # Step 1: Find source call sites
    source_callers: list[tuple[str, str, TaintSource]] = []
    for edge in call_edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = source_by_callee.get(callee_name)
        if matched:
            source_callers.append((edge["src"], edge["dst"], matched))

    # Step 2: Find sink call sites
    sink_callers: dict[str, tuple[str, TaintSink]] = {}
    for edge in call_edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = sink_by_callee.get(callee_name)
        if matched:
            sink_callers[edge["src"]] = (edge["dst"], matched)

    # Step 3: Find sanitizer call sites
    sanitizer_set: set[str] = set()
    sanitizer_by_caller: dict[str, TaintSanitizer] = {}
    for edge in call_edges:
        etype = edge.get("type", "")
        if etype not in TAINT_CALL_EDGE_TYPES:
            continue
        callee_name = _extract_callee_name(edge["dst"])
        matched = sanitizer_by_callee.get(callee_name)
        if matched:
            sanitizer_set.add(edge["src"])
            sanitizer_by_caller[edge["src"]] = matched

    findings: list[TaintFlowFinding] = []

    for caller_id, _source_callee_id, taint_source in source_callers:
        taint_label = taint_source.taint_label
        source_has_ddg = caller_id in analyzed

        # DDG-aware forward walk: track tainted variables per DDG edge
        tainted_at: set[tuple[str, str]] = set()  # (block_id, variable)

        if source_has_ddg:
            # Find DDG edges originating from the source call site's block
            # Mark all variables defined at the source call as tainted
            for edge in ddg_edges:
                if edge.def_block == caller_id:
                    tainted_at.add((edge.def_block, edge.variable))

        # Structural BFS for reachability (used for mixed-coverage)
        reachable: set[str] = set()
        parent: dict[str, str | None] = {caller_id: None}
        queue: deque[str] = deque([caller_id])

        while queue:
            node = queue.popleft()
            if node in reachable:
                continue  # pragma: no cover

            # Skip sanitizers (same as structural)
            if node in sanitizer_set and node != caller_id:
                san = sanitizer_by_caller.get(node)
                if san and san.input_taint == taint_label:
                    continue

            reachable.add(node)

            for neighbor in forward_adj.get(node, set()):
                if neighbor not in reachable and neighbor not in parent:
                    parent[neighbor] = node
                    queue.append(neighbor)

        # Check sinks
        for sink_node, (sink_callee_id, taint_sink) in sink_callers.items():
            if sink_node not in reachable:
                continue

            sink_has_ddg = sink_node in analyzed

            # Determine confidence based on DDG coverage
            if source_has_ddg and sink_has_ddg:
                confidence = "precise"
                method = "ddg"
            else:
                confidence = "approximate"
                method = "ddg_mixed"

            path = _reconstruct_path(parent, caller_id, sink_node)
            findings.append(TaintFlowFinding(
                taint_label=taint_label,
                source_symbol=caller_id,
                source_primitive=taint_source.name,
                sink_symbol=sink_callee_id,
                sink_primitive=taint_sink.name,
                sink_zone=taint_sink.zone,
                sanitized=False,
                confidence=confidence,
                analysis_method=method,
                path=path,
            ))

    return findings
