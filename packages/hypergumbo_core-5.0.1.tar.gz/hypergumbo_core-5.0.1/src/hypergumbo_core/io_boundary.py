# SPDX-License-Identifier: AGPL-3.0-or-later
"""I/O boundary analysis — catalog loading and edge matching (ADR-0016).

Provides a per-language catalog of I/O primitive functions/methods, each
classified by boundary type (fs_read, fs_write, net_send, net_recv,
ipc_recv, ipc_send, env_read, subprocess). Catalogs are YAML files in
the ``io_primitives/`` directory alongside this module.

How It Works
------------
1. ``load_catalog(language)`` reads the YAML for the given language and
   returns an ``IoBoundaryCatalog`` with a flat list of ``IoPrimitive``
   entries plus O(1) lookup by qualified name.
2. ``match_edge_to_primitive(catalog, callee_name)`` checks whether a
   call-edge target matches any I/O primitive, returning the match or None.
3. Downstream code (the boundary-tagging pass, Phase 1b) uses these
   matches to stamp ``io_boundary`` and ``io_primitive`` metadata onto
   edges in the graph.

Why YAML Catalogs
-----------------
The set of stdlib I/O functions per language is finite and stable — it
changes only with major language releases. Externalising the list to YAML
keeps the analysis logic independent of any single language, reuses the
pattern established by ADR-0015 dataflow YAML, and makes it easy to
add new languages or community-contributed corrections.
"""
from __future__ import annotations

import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


# ---------------------------------------------------------------------------
# Provenance allowlist (Plan C, PR B)
# ---------------------------------------------------------------------------
# Hostnames that are permitted as the host of a catalog's
# ``stdlib_provenance.source_url``.  Match is suffix-based, so
# ``docs.python.org`` matches the ``python.org`` suffix.  This defends
# against typos and unofficial sources: a catalog declaring
# ``status: complete`` with provenance pointing at, say,
# ``stackoverflow.com`` is rejected at load time.
#
# Adding to this list is a governance change — additions go through PR
# review with justification (same shape as ``ALLOWED_WEBSITES.md``).
# Each entry must be the official documentation host of a programming
# language's stdlib (or a closely-related authority such as MDN for
# browser globals, cppreference.com for C/C++, GNU for libc).

ALLOWED_PROVENANCE_HOSTNAME_SUFFIXES: frozenset[str] = frozenset({
    # Python
    "python.org",
    # Go
    "golang.org", "go.dev", "pkg.go.dev",
    # Rust
    "rust-lang.org",
    # JavaScript / Node / browsers
    "nodejs.org", "developer.mozilla.org",
    # Java / JVM ecosystem
    "oracle.com", "openjdk.org",
    # C# / .NET
    "microsoft.com", "dotnet.microsoft.com",
    # Apple platforms (Swift, Objective-C)
    "apple.com", "developer.apple.com", "swift.org",
    # JVM offshoots
    "kotlinlang.org", "scala-lang.org",
    # BEAM
    "elixir-lang.org", "hexdocs.pm", "erlang.org",
    # Functional family
    "haskell.org", "ocaml.org", "clojure.org",
    # Other major languages
    "ruby-lang.org", "dart.dev", "php.net", "perl.org",
    "crystal-lang.org", "nim-lang.org", "ziglang.org",
    "julialang.org", "racket-lang.org", "tcl-lang.org",
    "lua.org", "r-project.org",
    # C / C++ / POSIX
    "cppreference.com", "gnu.org", "man7.org",
    "openbsd.org", "freebsd.org", "netbsd.org",
    "opengroup.org",
    # Standards bodies (ISO C, ISO C++, RFCs)
    "iso.org", "ietf.org",
})


def _validate_catalog_dict(
    language: str, status: str, provenance: Optional[dict],
) -> None:
    """Validate a catalog dict against the Plan C, PR B governance rules.

    For ``status: complete``, ``stdlib_provenance`` MUST be present and
    its ``source_url`` MUST be an HTTPS URL whose hostname suffix-matches
    an entry in :data:`ALLOWED_PROVENANCE_HOSTNAME_SUFFIXES`.  For
    ``status: in_progress``, no provenance is required.

    Raises ``ValueError`` on any violation.  Called from
    :meth:`IoBoundaryCatalog._from_dict` so violations surface at load
    time, not at edge-matching time.
    """
    if status not in ("complete", "in_progress"):
        raise ValueError(
            f"Catalog for {language!r} has invalid status {status!r}; "
            f"expected 'complete' or 'in_progress'.",
        )
    if status != "complete":
        return
    if not provenance or not provenance.get("source_url"):
        raise ValueError(
            f"Catalog for {language!r} has status='complete' but no "
            f"stdlib_provenance.source_url. Either declare a provenance "
            f"URL or set status to 'in_progress'.",
        )
    url = provenance["source_url"]
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https":
        raise ValueError(
            f"Catalog for {language!r} has stdlib_provenance.source_url "
            f"{url!r} — must use https scheme.",
        )
    hostname = parsed.hostname or ""
    matched = any(
        hostname == suffix or hostname.endswith("." + suffix)
        for suffix in ALLOWED_PROVENANCE_HOSTNAME_SUFFIXES
    )
    if not matched:
        raise ValueError(
            f"Catalog for {language!r} has stdlib_provenance.source_url "
            f"{url!r} whose hostname {hostname!r} does not suffix-match "
            f"the allowlist (ALLOWED_PROVENANCE_HOSTNAME_SUFFIXES). Add "
            f"the hostname suffix to the allowlist if it is the official "
            f"documentation source for the language's stdlib.",
        )


# ---------------------------------------------------------------------------
# High-risk primitives
# ---------------------------------------------------------------------------

HIGH_RISK_PRIMITIVES: frozenset[str] = frozenset({
    # Destructive filesystem
    "shutil.rmtree", "os.rmdir", "os.remove", "os.unlink",
    "pathlib.Path.unlink", "pathlib.Path.rmdir",
    # Subprocess / code execution — Python
    "subprocess.Popen", "subprocess.run", "subprocess.call",
    "subprocess.check_call", "subprocess.check_output",
    "os.system", "os.popen", "os.execv", "os.execve", "os.execvp",
    "os.execvpe", "os.execl", "os.execle", "os.execlp", "os.execlpe",
    "os.fork", "os.forkpty",
    "os.spawnl", "os.spawnle", "os.spawnlp", "os.spawnlpe",
    "os.spawnv", "os.spawnve", "os.spawnvp", "os.spawnvpe",
    # Network outbound — Python
    "urllib.request.urlopen", "urllib.request.Request",
    "socket.socket.connect", "socket.socket.send", "socket.socket.sendall",
    # Go
    "os/exec.Command", "os/exec.CommandContext",
    # Java
    "java.lang.ProcessBuilder.start", "java.lang.Runtime.exec",
    # Rust
    "std::process::Command.spawn", "std::process::Command.output",
    "std::process::Command.status",
    # JavaScript / Node
    "child_process.exec", "child_process.execSync",
    "child_process.spawn", "child_process.spawnSync",
    # C
    "unistd.exec", "unistd.execl", "unistd.fork",
    "stdlib.system", "stdio.popen",
})


def is_high_risk(primitive_name: str) -> bool:
    """Check whether a primitive is classified as high-risk.

    High-risk primitives include destructive filesystem operations
    (rmtree, unlink), subprocess/code execution (Popen, exec*), and
    outbound network calls (urlopen, socket.send). The classification
    covers Python, Go, Java, Rust, JavaScript, and C primitives.
    """
    return primitive_name in HIGH_RISK_PRIMITIVES


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class IoPrimitive:
    """A single I/O primitive function or method.

    Attributes:
        boundary: The I/O boundary classification (e.g. "fs_read", "net_send").
        module: The module or class path (e.g. "os", "pathlib.Path").
        name: The function or method name (e.g. "listdir", "read_text").
        kind: Either "function" or "method".
        notes: Optional human-readable notes about classification caveats.
    """

    boundary: str
    module: str
    name: str
    kind: str  # "function" or "method"
    notes: str = ""

    @property
    def qualified_name(self) -> str:
        """Full dotted name: module.name."""
        return f"{self.module}.{self.name}"


@dataclass
class IoBoundaryCatalog:
    """Loaded I/O primitive catalog for a single language.

    Provides O(1) lookup by qualified name and O(1) lookup by short name
    (unqualified). Short-name lookup may return multiple matches (e.g.
    ``open`` is both fs_read and fs_write).
    """

    language: str
    primitives: list[IoPrimitive] = field(default_factory=list)
    ambiguous_names: frozenset[str] = field(default_factory=frozenset)
    # INV-javam: True when a YAML catalog (or alias/parent) was loaded
    # for this language. False when no catalog exists — this is the
    # signal callers (io-boundaries, taint-flow) use to distinguish
    # "found zero I/O" from "language unsupported". Silent zeros are
    # the class of bug the invariant guards against: output identical
    # to a clean codebase, plus false security confidence in taint-flow.
    is_supported: bool = True
    # Plan C, PR B: catalog completeness status. ``"complete"`` means
    # the catalog enumerates the entire stdlib of the language and has
    # declared ``stdlib_provenance`` (validated at load time).
    # ``"in_progress"`` means the catalog is partial; downstream code
    # (PR C) flags ``external_potential`` reports as unreliable for
    # in-progress languages so absence-of-catalog-hit isn't conflated
    # with "definitely third-party".
    status: str = "complete"
    # Plan C, PR B: provenance of the stdlib symbol list. ``None`` for
    # ``status: in_progress``; required (and validated) for
    # ``status: complete``. Shape: ``{source_url, version, retrieved,
    # notes?}``.
    stdlib_provenance: Optional[dict] = None
    # Plan C, PR B: stdlib qualified names that are NOT I/O primitives
    # (e.g., ``math.sqrt``). Used by the PR C ``external_potential``
    # filter to drop "first-party calls a stdlib non-IO symbol" from
    # the bucket — those aren't catalog gaps. Empty until catalogs
    # populate ``stdlib_other:`` sections.
    stdlib_other: frozenset[str] = field(default_factory=frozenset)
    _by_qualified: dict[str, IoPrimitive] = field(
        default_factory=dict, repr=False,
    )
    _by_short: dict[str, list[IoPrimitive]] = field(
        default_factory=dict, repr=False,
    )

    def __post_init__(self) -> None:
        """Build lookup indices."""
        self._rebuild_indices()

    def _rebuild_indices(self) -> None:
        """Rebuild the qualified-name and short-name lookup dicts."""
        self._by_qualified.clear()
        self._by_short.clear()
        for p in self.primitives:
            # Qualified name: first one wins (shouldn't have duplicates)
            if p.qualified_name not in self._by_qualified:
                self._by_qualified[p.qualified_name] = p
            # WI-vipur: also register a dot-normalized alias so edges
            # emitted in scoped-path mode (``::`` replaced with ``.`` to
            # avoid colliding with the ``:``-delimited edge ID format)
            # still hit the qualified index.  Only relevant for languages
            # whose catalog module names contain ``::`` (Rust, C++).
            dot_form = p.qualified_name.replace("::", ".")
            if dot_form != p.qualified_name:
                self._by_qualified.setdefault(dot_form, p)
            # Short name: may have multiple (e.g. open → fs_read + fs_write)
            self._by_short.setdefault(p.name, []).append(p)

    def lookup(self, name: str) -> Optional[IoPrimitive]:
        """Look up a primitive by qualified or short name.

        Returns the first match, or None if not found. For names that
        map to multiple boundaries (like ``open``), use ``lookup_all()``.
        """
        hit = self._by_qualified.get(name)
        if hit is not None:
            return hit
        hits = self._by_short.get(name)
        return hits[0] if hits else None

    def lookup_all(self, name: str) -> list[IoPrimitive]:
        """Look up all primitives matching a qualified or short name.

        Returns all matches (may be empty). Useful for names like ``open``
        that are classified under multiple boundary types.
        """
        # Qualified match is unique
        hit = self._by_qualified.get(name)
        if hit is not None:
            return [hit]
        return list(self._by_short.get(name, []))

    def lookup_with_module(
        self, name: str, module_hint: str | None = None,
    ) -> Optional[IoPrimitive]:
        """Look up a primitive with optional module context for disambiguation.

        When ``module_hint`` is provided and is not ``"external"``, filters
        short-name matches to only those whose ``module`` field is contained
        in the hint (or vice versa).  This prevents false positives like
        ``crypto/rand.Read`` matching ``net.Conn.Read``.

        Falls back to unfiltered short-name matching when:
        - ``module_hint`` is None or ``"external"`` (no module info available)
        - No filtered match is found (defensive fallback)
        """
        # Qualified-name match always wins (exact)
        hit = self._by_qualified.get(name)
        if hit is not None:
            return hit

        hits = self._by_short.get(name)
        if not hits:
            return None

        # If we have module context, filter matches
        if module_hint and module_hint != "external":
            filtered = [
                p for p in hits
                if _module_matches(p.module, module_hint)
            ]
            if filtered:
                return filtered[0]
            # No match with module filtering — this is likely NOT an IO
            # primitive (e.g., crypto/rand.Read is not net.Conn.Read)
            return None

        # No module context — fall back to first match unless ambiguous
        if self.ambiguous_names and name in self.ambiguous_names:
            return None
        return hits[0]

    def merge(self, parent: IoBoundaryCatalog) -> IoBoundaryCatalog:
        """Merge a parent catalog into this one. Self's entries take precedence.

        Used for language inheritance (e.g. Scala inherits from Java):
        Scala-specific entries override Java entries with the same qualified
        name, while Java entries not present in Scala are added.

        ``stdlib_other`` is unioned across child and parent so a Kotlin
        project benefits from Java's enumerated stdlib non-IO symbols.
        ``status`` and ``stdlib_provenance`` stay on the child — the
        completeness claim belongs to the language whose catalog is
        being loaded, not the parent.
        """
        existing_qnames = {p.qualified_name for p in self.primitives}
        merged_primitives = list(self.primitives) + [
            p for p in parent.primitives
            if p.qualified_name not in existing_qnames
        ]
        merged_ambiguous = self.ambiguous_names | parent.ambiguous_names
        merged_stdlib_other = self.stdlib_other | parent.stdlib_other
        return IoBoundaryCatalog(
            language=self.language,
            primitives=merged_primitives,
            ambiguous_names=merged_ambiguous,
            status=self.status,
            stdlib_provenance=self.stdlib_provenance,
            stdlib_other=merged_stdlib_other,
        )

    @classmethod
    def from_yaml(cls, path: Path) -> IoBoundaryCatalog:
        """Load a catalog from a YAML file."""
        content = path.read_text(encoding="utf-8")
        data = yaml.safe_load(content) or {}
        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: dict) -> IoBoundaryCatalog:
        """Build a catalog from a parsed YAML dict.

        Plan C, PR B: validates ``status`` + ``stdlib_provenance`` and
        parses the new ``stdlib_other`` section. Hard-errors at load
        time on missing/invalid provenance for ``status: complete``
        catalogs (see :func:`_validate_catalog_dict`).
        """
        language = data.get("language", "unknown")
        status = data.get("status", "complete")
        provenance = data.get("stdlib_provenance")
        if provenance is not None and not isinstance(provenance, dict):
            raise ValueError(
                f"Catalog for {language!r} stdlib_provenance must be a "
                f"mapping, got {type(provenance).__name__}.",
            )
        _validate_catalog_dict(language, status, provenance)
        primitives: list[IoPrimitive] = []

        boundary_types = [
            "fs_read", "fs_write", "net_send", "net_recv",
            "ipc_recv", "ipc_send", "env_read", "env_write",
            "subprocess", "db_read", "db_write",
            "process_send", "logging",
            # WI-lokuv / WI-kanir-huzuj: browser-local storage is structurally
            # distinct from host filesystem — reachable via XSS, not via
            # local-user FS access. Paired with the ``browser_storage`` trust
            # zone in taint.py. The read side (browser_storage_read) is
            # intentionally NOT in AUTO_SOURCE_LABEL_MAP — matching how
            # fs_read is treated — because the sensitivity of a browser
            # storage read depends on what's stored (project-local catalogs
            # can add taint_sources entries for their specific threat model).
            "browser_storage_write",
            "browser_storage_read",
        ]

        for boundary in boundary_types:
            entries = data.get(boundary, [])
            if not isinstance(entries, list):
                continue
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                module = entry.get("module", "")
                notes = entry.get("notes", "")

                for func_name in entry.get("functions", []):
                    primitives.append(IoPrimitive(
                        boundary=boundary,
                        module=module,
                        name=func_name,
                        kind="function",
                        notes=notes,
                    ))
                for method_name in entry.get("methods", []):
                    primitives.append(IoPrimitive(
                        boundary=boundary,
                        module=module,
                        name=method_name,
                        kind="method",
                        notes=notes,
                    ))
                for attr_name in entry.get("attributes", []):
                    primitives.append(IoPrimitive(
                        boundary=boundary,
                        module=module,
                        name=attr_name,
                        kind="attribute",
                        notes=notes,
                    ))

        ambiguous = frozenset(data.get("ambiguous_names", []))

        # Plan C, PR B: parse stdlib_other (non-IO stdlib symbols).
        stdlib_other_set: set[str] = set()
        stdlib_other_entries = data.get("stdlib_other", [])
        if isinstance(stdlib_other_entries, list):
            for entry in stdlib_other_entries:
                if not isinstance(entry, dict):
                    continue
                module = entry.get("module", "")
                for kind_key in ("functions", "methods", "attributes"):
                    for sym_name in entry.get(kind_key, []):
                        stdlib_other_set.add(f"{module}.{sym_name}")

        catalog = cls(
            language=language,
            primitives=primitives,
            ambiguous_names=ambiguous,
            status=status,
            stdlib_provenance=provenance,
            stdlib_other=frozenset(stdlib_other_set),
        )
        return catalog


# ---------------------------------------------------------------------------
# Catalog loading
# ---------------------------------------------------------------------------

_CATALOG_DIR = Path(__file__).parent / "io_primitives"

# Languages that share an IO primitive catalog.  C++ uses C stdlib IO
# functions (fopen, fread, fwrite, popen, etc.) so it falls back to the
# C catalog.  TypeScript shares the JavaScript catalog.
_CATALOG_ALIASES: dict[str, str] = {
    "typescript": "javascript",
    # JVM languages that lack their own catalog share the Java IO catalog
    "groovy": "java",
    # Objective-C nodes have language="objective-c" but edge prefixes use "objc"
    "objective-c": "objc",
}

# Languages with their own catalog that also inherit from a parent.
# The child catalog takes precedence; parent entries fill in the gaps.
# Kotlin needs this rather than a plain alias so kotlin.yaml can add
# Kotlin-specific stdlib / ktor / Android entries that have no Java
# analog (WI-rujos / UAT BUG-09d).
_CATALOG_PARENTS: dict[str, str] = {
    "scala": "java",
    "kotlin": "java",
    # Elixir inherits Erlang stdlib — `:gen_tcp.send` / `:file.read` /
    # `:ets.lookup` all call the Erlang modules directly (WI-vibur).
    "elixir": "erlang",
    # C++ inherits the C catalog (libc, POSIX) and the cpp.yaml child
    # adds the iostream surface (``std::cout`` / ``cerr`` / ``cin``).
    # Was a plain alias prior to WI-zojid — the alias form would have
    # required the C++-only ``module: std`` entries to live in c.yaml,
    # polluting the C-only catalog.
    "cpp": "c",
}


def is_language_supported(language: str) -> bool:
    """True if ``language`` has an I/O primitive catalog (directly, via
    alias, or with a parent). Callers use this to distinguish "found
    zero I/O" from "language unsupported" — the INV-javam invariant.
    """
    return load_catalog(language).is_supported


def load_catalog(language: str) -> IoBoundaryCatalog:
    """Load the I/O primitive catalog for a language.

    Looks for ``io_primitives/<language>.yaml`` relative to this module.
    Falls back to language aliases (e.g. cpp → c) if no exact match.
    When a language has a parent catalog (e.g. scala → java), the child
    catalog is loaded first and then merged with the parent so that
    child entries take precedence while parent entries fill in gaps.
    Returns an empty catalog if no catalog is found.
    """
    path = _CATALOG_DIR / f"{language}.yaml"
    if not path.exists():
        alias = _CATALOG_ALIASES.get(language)
        if alias:
            path = _CATALOG_DIR / f"{alias}.yaml"
    if not path.exists():
        # INV-javam: no catalog file (and no alias resolving to one) —
        # callers use is_supported to emit explicit "language
        # unsupported" output instead of silently returning zero I/O.
        return IoBoundaryCatalog(language=language, is_supported=False)
    catalog = IoBoundaryCatalog.from_yaml(path)

    # Merge parent catalog if defined (e.g. scala inherits java entries)
    parent_lang = _CATALOG_PARENTS.get(language)
    if parent_lang:
        parent_path = _CATALOG_DIR / f"{parent_lang}.yaml"
        if parent_path.exists():
            parent_catalog = IoBoundaryCatalog.from_yaml(parent_path)
            catalog = catalog.merge(parent_catalog)

    return catalog


# ---------------------------------------------------------------------------
# Edge matching
# ---------------------------------------------------------------------------


def match_edge_to_primitive(
    catalog: IoBoundaryCatalog,
    callee_name: str,
) -> Optional[IoPrimitive]:
    """Match a call-edge target name against the I/O primitive catalog.

    Tries qualified name first, then short (unqualified) name. Returns
    the first match or None.
    """
    return catalog.lookup(callee_name)


# ---------------------------------------------------------------------------
# Boundary map computation (ADR-0016 Phase 1c)
# ---------------------------------------------------------------------------


@dataclass
class IoChain:
    """A call chain from an entry point to an I/O boundary call.

    Attributes:
        boundary: The I/O boundary type (e.g., "fs_read").
        primitive: The matched I/O primitive qualified name.
        io_edge_src: The symbol ID of the caller of the I/O primitive.
        io_edge_dst: The symbol ID of the I/O primitive itself.
        entry_points: Set of entry-point symbol IDs that can reach this I/O call.
        dst_tier: ``supply_chain.tier`` of the io_edge_dst symbol when known.
            None when the caller did not pass a ``nodes_by_id`` lookup or the
            dst is not present in the lookup (pre-PR1 JSON files lack
            external boundary nodes).
        dst_tier_name: Human-readable tier name (``"first_party"`` /
            ``"internal_dep"`` / ``"external_dep"`` / ``"derived"``).
        dst_external_boundary: True when the dst is a synthetic
            ``meta.external_boundary`` node (i.e., the call reaches into
            code that hypergumbo did not analyze).
        dst_classification_unreliable: Plan C, PR C — set on
            ``boundary="external_potential"`` chains whose source
            language has ``status: in_progress``. The chain is emitted
            because the dst is an external boundary node, but absence
            from the (incomplete) catalog does not authoritatively mean
            the dst is third-party — the language's stdlib enumeration
            isn't yet provenance-validated.
    """

    boundary: str
    primitive: str
    io_edge_src: str
    io_edge_dst: str
    entry_points: list[str] = field(default_factory=list)
    dst_tier: Optional[int] = None
    dst_tier_name: Optional[str] = None
    dst_external_boundary: bool = False
    dst_classification_unreliable: bool = False

    def to_dict(self) -> dict:
        """Serialize to JSON-friendly dict including high-risk flag."""
        return {
            "boundary": self.boundary,
            "primitive": self.primitive,
            "io_edge_src": self.io_edge_src,
            "io_edge_dst": self.io_edge_dst,
            "entry_points": self.entry_points,
            "high_risk": is_high_risk(self.primitive),
            "dst_tier": self.dst_tier,
            "dst_tier_name": self.dst_tier_name,
            "dst_external_boundary": self.dst_external_boundary,
            "dst_classification_unreliable": (
                self.dst_classification_unreliable
            ),
        }


@dataclass
class BoundaryMapEntry:
    """Aggregated boundary map for one boundary type.

    Attributes:
        boundary: The I/O boundary type.
        chains: Individual I/O chains reaching this boundary.
        entry_points: Deduplicated entry-point symbol IDs across all chains.
        primitives_used: Deduplicated I/O primitive names across all chains.
    """

    boundary: str
    chains: list[IoChain] = field(default_factory=list)
    entry_points: list[str] = field(default_factory=list)
    primitives_used: list[str] = field(default_factory=list)
    leaf_callers: list[str] = field(default_factory=list)
    entry_points_per_leaf: dict[str, list[str]] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize to JSON-friendly dict.

        Includes per-primitive counts, per-chain detail, and a
        high-risk flag indicating whether any chain uses a high-risk
        primitive (destructive fs, subprocess, outbound network).

        Also emits the WI-darad leaf-caller roll-ups (leaf_callers +
        entry_points_per_leaf) so taint-style reasoning can keep the
        EP→concrete-caller→sink association even when many concrete
        callers share a helper (the 'slack.Notify / discord.Notify /
        pushover.Notify → request → http.NewRequest' case).
        """
        prim_counts: dict[str, int] = {}
        for chain in self.chains:
            prim_counts[chain.primitive] = prim_counts.get(chain.primitive, 0) + 1
        return {
            "boundary": self.boundary,
            "chain_count": len(self.chains),
            "entry_points": self.entry_points,
            "primitives_used": self.primitives_used,
            "primitive_counts": prim_counts,
            "chains": [c.to_dict() for c in self.chains],
            "has_high_risk": any(
                is_high_risk(c.primitive) for c in self.chains
            ),
            "leaf_callers": self.leaf_callers,
            "entry_points_per_leaf": self.entry_points_per_leaf,
        }


@dataclass
class BoundaryMap:
    """Complete I/O boundary map for a repository.

    Attributes:
        entries: Mapping from boundary type to aggregated entry.
        total_io_edges: Total number of boundary-tagged edges found.
    """

    entries: dict[str, BoundaryMapEntry] = field(default_factory=dict)
    total_io_edges: int = 0

    def to_dict(self) -> dict:
        """Serialize to JSON-friendly dict."""
        return {
            "total_io_edges": self.total_io_edges,
            "boundaries": {
                k: v.to_dict() for k, v in sorted(self.entries.items())
            },
        }


# ADR-0023 §6 Phase 2 audit (WI-sahab-fatoz): this set mixes axes —
# relationship-axis values (``calls``, ``instantiates``, ``references``,
# ``module_attr_ref``), pending_classification values (``dispatches_to``,
# ``implements_rpc``), and endpoint_shape FFI/IPC bridges. Forward-
# compatible through Phase 3 because ``calls`` is already a member, so
# when bridges fold into ``calls`` + ``meta["bridge_kind"]`` the set
# still matches; the bridge entries become dead-but-harmless and get
# pruned in Phase 4.
_TRACEABLE_EDGE_TYPES = frozenset({
    "calls", "instantiates", "dispatches_to", "references",
    # WI-guhok: attribute reads of imported modules (e.g. os.environ, sys.argv)
    # — lets IO-primitive ``attributes:`` YAML entries become reachable from
    # the taint-style backward BFS that computes entry-point chains.
    "module_attr_ref",
    # audit-findings 0002 (WI-hahap-farid): ipc_event / message_send / websocket_message
    # / message_queue all fold to event_publishes; bringing the canonical
    # name in keeps the reverse-graph traversal crossing async-channel
    # boundaries after the IPC family rename.
    "event_publishes",
    # pending_classification entries awaiting per-family audit
    # (implements_rpc). Protocol-call family (WI-vumum-juvil) folds
    # to 'calls' + meta['protocol'], so HTTP/gRPC/GraphQL traversals
    # transfer via the canonical 'calls' member.
    "implements_rpc",
})


def _build_reverse_graph(edges: list) -> dict[str, set[str]]:
    """Build reverse adjacency list (callee → callers) over traceable edge types.

    Includes FFI bridge edges so upstream walks cross language boundaries
    (e.g., Java native method → C JNI function → fopen).
    """
    reverse_graph: dict[str, set[str]] = {}
    for edge in edges:
        if edge.edge_type in _TRACEABLE_EDGE_TYPES:
            reverse_graph.setdefault(edge.dst, set()).add(edge.src)
    return reverse_graph


def _reachable_entry_points(
    seed: str,
    reverse_graph: dict[str, set[str]],
    entrypoint_ids: set[str],
) -> set[str]:
    """BFS backward from ``seed`` and return all entrypoints reachable."""
    reachable_eps: set[str] = set()
    visited: set[str] = set()
    queue = [seed]
    while queue:
        current = queue.pop(0)
        if current not in visited:
            visited.add(current)
            if current in entrypoint_ids:
                reachable_eps.add(current)
            for caller in reverse_graph.get(current, ()):
                if caller not in visited:
                    queue.append(caller)
    return reachable_eps


def _compute_external_potential(
    edges: list,
    catalogs: dict[str, IoBoundaryCatalog],
    nodes_by_id: dict[str, dict],
    ep_map: dict[str, set[str]],
) -> list[IoChain]:
    """Synthesize ``external_potential`` IoChains for unmatched boundary edges.

    Plan C, PR C: for every edge whose ``meta.io_boundary`` is unset
    (so the catalog did not classify it) and whose dst is a synthetic
    external-boundary node (``meta.external_boundary == True``), emit a
    chain into the ``external_potential`` bucket so the user sees
    "first-party code reaches into untrusted territory" as a first-class
    signal.

    Filters:
    - Only edge types in :data:`_TRACEABLE_EDGE_TYPES` (same set the
      reverse-graph uses).
    - The dst MUST be in ``nodes_by_id`` AND be marked
      ``meta.external_boundary``.
    - The source language MUST have a loaded catalog
      (``catalog.is_supported``); we don't speculate about languages
      we can't classify at all.
    - The composed primitive name (``module.name`` from the dst ID) MUST
      NOT be in the catalog's ``stdlib_other`` set — those are stdlib
      symbols we know are not IO, so they aren't catalog gaps.

    Annotation:
    - When the source language's catalog is ``status: in_progress``,
      ``dst_classification_unreliable=True`` is set on each chain.
      (Suppressing the chain entirely would silently hide data; the
      annotation lets users see them while knowing the absence-of-
      catalog-hit isn't authoritative.)
    """
    chains: list[IoChain] = []
    for edge in edges:
        meta = edge.meta
        if meta and meta.get("io_boundary"):
            continue
        if edge.edge_type not in _TRACEABLE_EDGE_TYPES:
            continue
        dst_node = nodes_by_id.get(edge.dst)
        if dst_node is None:
            continue
        dst_meta = dst_node.get("meta") or {}
        if not dst_meta.get("external_boundary"):
            continue

        src_parts = edge.src.split(":")
        src_lang = src_parts[0] if src_parts else ""
        catalog = catalogs.get(src_lang)
        if catalog is None or not catalog.is_supported:
            continue

        # Compose primitive name from module hint + dst name. Module hint
        # is the most useful disambiguator (huggingface_hub.snapshot_download
        # vs anything.snapshot_download); name alone would collapse them.
        module_hint = _extract_module_hint(edge.dst) or ""
        dst_name = dst_node.get("name") or _extract_callee_name(edge.dst)
        if module_hint and module_hint != "external":
            primitive = f"{module_hint}.{dst_name}"
        else:
            primitive = dst_name

        # Filter out stdlib non-IO symbols — those aren't catalog gaps.
        if primitive in catalog.stdlib_other:
            continue

        sc = dst_node.get("supply_chain") or {}
        chain = IoChain(
            boundary="external_potential",
            primitive=primitive,
            io_edge_src=edge.src,
            io_edge_dst=edge.dst,
            entry_points=sorted(ep_map.get(edge.src, set())),
            dst_tier=sc.get("tier"),
            dst_tier_name=sc.get("tier_name"),
            dst_external_boundary=True,
            dst_classification_unreliable=(catalog.status == "in_progress"),
        )
        chains.append(chain)
    return chains


def compute_boundary_map(
    edges: list,
    catalogs: dict[str, IoBoundaryCatalog],
    *,
    entrypoint_ids: set[str] | None = None,
    nodes_by_id: dict[str, dict] | None = None,
) -> BoundaryMap:
    """Compute the I/O boundary map from a set of edges.

    Tags edges with I/O boundary metadata (in-place), then aggregates
    tagged edges by boundary type. When ``entrypoint_ids`` is provided,
    traces backward from each IO edge through the call graph to find
    which entrypoints can reach each IO call.

    Args:
        edges: List of Edge objects (mutated: io_boundary metadata stamped).
        catalogs: Language → IoBoundaryCatalog mapping.
        entrypoint_ids: Optional set of entrypoint symbol IDs. When
            provided, populates ``entry_points`` on each IoChain and
            BoundaryMapEntry.
        nodes_by_id: Optional ``{symbol_id: node_dict}`` lookup. When
            provided, each IoChain picks up the dst symbol's
            ``supply_chain.tier`` / ``tier_name`` and ``meta.external_boundary``
            so downstream consumers (verify-claims, sketch) can distinguish
            "first-party calls first-party I/O" from "first-party calls
            tier-3 wrapper that may reach the network." Pre-PR1 JSON
            files lack boundary nodes; in that case the dst lookup yields
            ``None`` and chain.dst_tier stays ``None`` (backwards-compat).

    Returns:
        BoundaryMap with per-boundary-type aggregation.
    """
    tagged_count = tag_io_boundaries(edges, catalogs)

    # Reverse call graph — shared by EP tracing and leaf-caller expansion
    reverse_graph = _build_reverse_graph(edges)

    # Reverse-trace from IO edges to entrypoints (Phase 1c)
    ep_map: dict[str, set[str]] = {}
    if entrypoint_ids:
        io_sources: set[str] = set()
        for edge in edges:
            if edge.meta and edge.meta.get("io_boundary"):
                io_sources.add(edge.src)
        for io_src in io_sources:
            ep_map[io_src] = _reachable_entry_points(
                io_src, reverse_graph, entrypoint_ids
            )

    # Aggregate tagged edges by boundary type
    by_boundary: dict[str, list[IoChain]] = {}
    for edge in edges:
        meta = edge.meta
        if meta is None:
            continue
        boundary = meta.get("io_boundary")
        if boundary is None:
            continue
        primitive = meta.get("io_primitive", "")
        chain_eps = sorted(ep_map.get(edge.src, set()))
        # Tier lookup on the dst Symbol — only available when the caller
        # passed nodes_by_id and the dst is in the lookup. PR1 of the
        # stop-stripping plan ensures boundary nodes are now in
        # behavior_map["nodes"] so this resolves for previously-dangling
        # external dsts too.
        dst_tier: Optional[int] = None
        dst_tier_name: Optional[str] = None
        dst_external = False
        if nodes_by_id is not None:
            dst_node = nodes_by_id.get(edge.dst)
            if dst_node is not None:
                sc = dst_node.get("supply_chain") or {}
                dst_tier = sc.get("tier")
                dst_tier_name = sc.get("tier_name")
                dst_meta = dst_node.get("meta") or {}
                dst_external = bool(dst_meta.get("external_boundary"))
        chain = IoChain(
            boundary=boundary,
            primitive=primitive,
            io_edge_src=edge.src,
            io_edge_dst=edge.dst,
            entry_points=chain_eps,
            dst_tier=dst_tier,
            dst_tier_name=dst_tier_name,
            dst_external_boundary=dst_external,
        )
        by_boundary.setdefault(boundary, []).append(chain)

    # Plan C, PR C: external_potential second pass.  Synthesize chains
    # for unmatched edges whose dst is a synthetic external-boundary
    # node — i.e., first-party code reaches into untrusted territory
    # the catalog doesn't classify.  Surfaces the structural answer to
    # "the catalog can't enumerate every popular wrapper": instead of
    # adding entries for huggingface_hub / requests / okhttp / etc., the
    # bucket emits one chain per such call so the user can see the
    # surface area as a first-class signal.
    if nodes_by_id is not None:
        ext_chains = _compute_external_potential(
            edges, catalogs, nodes_by_id, ep_map,
        )
        if ext_chains:
            by_boundary["external_potential"] = ext_chains

    # Build boundary map entries, including WI-darad leaf-caller roll-ups.
    bmap = BoundaryMap(total_io_edges=tagged_count)
    leaf_ep_cache: dict[str, set[str]] = {}
    for boundary, chains in by_boundary.items():
        leaf_callers, entry_points_per_leaf = compute_leaf_rollups(
            chains, reverse_graph, entrypoint_ids, leaf_ep_cache,
        )
        bmap.entries[boundary] = BoundaryMapEntry(
            boundary=boundary,
            chains=chains,
            entry_points=sorted({ep for c in chains for ep in c.entry_points}),
            primitives_used=sorted({c.primitive for c in chains}),
            leaf_callers=leaf_callers,
            entry_points_per_leaf=entry_points_per_leaf,
        )

    return bmap


def compute_leaf_rollups(
    chains: list[IoChain],
    reverse_graph: dict[str, set[str]],
    entrypoint_ids: Optional[set[str]] = None,
    leaf_ep_cache: Optional[dict[str, set[str]]] = None,
) -> tuple[list[str], dict[str, list[str]]]:
    """Compute the WI-darad leaf-caller roll-ups for a chain set.

    A "leaf caller" of an io_edge_src is an immediate caller of that src
    in the reverse graph; when src has no callers, src itself is its own
    leaf (the primitive is invoked directly from that function).

    Exposed at module level so the CLI's filter pass (cmd_io_boundaries)
    can recompute rollups for a subset of chains after dropping test-file
    chains or applying --primitive — otherwise the BoundaryMapEntry it
    rebuilds loses the rollups, and the bakeoff io-boundaries.txt shows
    chain_count>0 with leaf_callers=[] (WI-rubir regression).

    ``leaf_ep_cache`` lets callers reuse entry-point reachability sets
    across multiple boundary types in the same map; pass ``None`` to use
    a per-call scratch cache.
    """
    if leaf_ep_cache is None:
        leaf_ep_cache = {}
    leaf_set: set[str] = set()
    per_leaf: dict[str, set[str]] = {}
    for chain in chains:
        callers = reverse_graph.get(chain.io_edge_src, set())
        leaves = callers if callers else {chain.io_edge_src}
        for leaf in leaves:
            leaf_set.add(leaf)
            if entrypoint_ids:
                if leaf not in leaf_ep_cache:
                    leaf_ep_cache[leaf] = _reachable_entry_points(
                        leaf, reverse_graph, entrypoint_ids
                    )
                per_leaf.setdefault(leaf, set()).update(leaf_ep_cache[leaf])
    return (
        sorted(leaf_set),
        {leaf: sorted(eps) for leaf, eps in per_leaf.items()},
    )


# ---------------------------------------------------------------------------
# Boundary-tagging pass (ADR-0016 Phase 1b)
# ---------------------------------------------------------------------------


def _module_matches(catalog_module: str, edge_module_hint: str) -> bool:
    """Check if a catalog entry's module matches the edge's module hint.

    Uses case-insensitive substring matching in both directions to handle
    different naming conventions:
    - Go: catalog has ``net.Conn``, edge has ``net.Conn`` → match
    - Go: catalog has ``os``, edge has ``os`` → match
    - Go: catalog has ``net.Conn``, edge has ``crypto/rand`` → no match
    - Rust: catalog has ``std::fs``, edge has ``std::fs::File`` → match
    - Java: catalog has ``java.io``, edge has ``java.io.FileInputStream`` → match
    - Swift: catalog has ``Channel``, edge has ``channel`` → match
    - Swift: catalog has ``ChannelHandlerContext``, edge has ``context`` → match
    - Swift: catalog has ``NonBlockingFileIO``, edge has ``fileIO`` → match

    Case-insensitive comparison is necessary because Swift's tree-sitter
    analyzer extracts receiver variable names (camelCase) as module hints,
    while the catalog uses PascalCase type names.
    """
    # Normalize: treat :: and / as . for uniform comparison, casefold for
    # cross-convention matching (Swift camelCase vars vs PascalCase types)
    cm = catalog_module.replace("::", ".").replace("/", ".").casefold()
    em = edge_module_hint.replace("::", ".").replace("/", ".").casefold()
    return cm in em or em in cm


def _extract_module_hint(edge_dst: str) -> str | None:
    """Extract the module hint from an edge destination symbol ID.

    For unresolved edges with format ``{lang}:{module_hint}:0-0:{name}:unresolved``,
    returns the module_hint part (2nd colon-separated field).

    For resolved edges (file paths in position 2), returns None since the
    path is not a useful module hint.
    """
    parts = edge_dst.split(":")
    if len(parts) >= 5:
        candidate = parts[1]
        # Heuristic: file paths start with / or contain .py/.java/.go etc.
        # Module hints are identifiers like "external", "net.Conn", "os"
        if candidate.startswith("/") or candidate.startswith("\\"):
            return None
        return candidate
    return None


def _extract_callee_name(edge_dst: str) -> str:
    """Extract a callable name from an edge destination symbol ID.

    Symbol IDs have the format ``language:path:span:name:kind``.  The *name*
    field may itself contain colons (e.g., Objective-C selectors like
    ``removeItemAtPath:error:``).

    Strategy: split off the *kind* (last field) from the right, then take
    everything after the first three fields (lang, path, span) as the name.
    """
    # Split off kind from the right
    last_colon = edge_dst.rfind(":")
    if last_colon < 0:
        return edge_dst
    rest = edge_dst[:last_colon]

    # rest = "lang:path:span:name_possibly_with_colons"
    # Split into at most 4 parts: lang, path, span, name(remainder)
    parts = rest.split(":", 3)
    if len(parts) >= 4:
        return parts[3]
    # Fewer fields — return the last segment (handles minimal IDs like "a:b")
    return parts[-1] if parts else edge_dst


def _resolve_ffi_catalog(
    lang: str,
    module_hint: str | None,
    catalogs: dict[str, "IoBoundaryCatalog"],
) -> tuple["IoBoundaryCatalog | None", str | None]:
    """Redirect FFI pseudo-namespace lookups to the actual target catalog.

    Go's cgo pseudo-package ``C`` produces edges like
    ``go:C:0-0:fopen:unresolved`` when calling C stdlib functions.  The
    ``go`` catalog contains Go-native IO (``os.Open``, ``net.Listen``),
    not C stdlib entries.  This function detects the ``go:C:`` prefix
    and redirects to the ``c`` catalog, dropping the module hint because
    ``"C"`` is Go's import alias, not a C header/module name.

    Python's pyffi linker uses ``python:C_stdlib:0-0:<name>:unresolved``
    for calls through ``ctypes.CDLL(None)`` or ``ffi.dlopen(None)``.
    Same redirect: the ``python`` catalog has Python-native IO, but these
    calls target C stdlib functions.

    Returns:
        (catalog, adjusted_module_hint) — the catalog to use for lookup
        and the module hint (``None`` when the pseudo-namespace module
        is not a real module in the target language).
    """
    # Go cgo → C stdlib: go:C:0-0:<name>:unresolved
    if lang == "go" and module_hint == "C":
        return catalogs.get("c"), None

    # Python ctypes.CDLL(None) / ffi.dlopen(None) → C stdlib
    if lang == "python" and module_hint == "C_stdlib":
        return catalogs.get("c"), None

    # Ruby FFI gem attach_function → C stdlib/external lib
    if lang == "ruby" and module_hint == "C_ffi":
        return catalogs.get("c"), None

    return catalogs.get(lang), module_hint


def tag_io_boundaries(
    edges: list,
    catalogs: dict[str, IoBoundaryCatalog],
    *,
    call_types: frozenset[str] = frozenset({
        "calls", "imports",
        # WI-guhok: attribute-style IO primitives (os.environ, sys.argv, ...)
        # reach the boundary pipeline through module_attr_ref edges emitted by
        # the Python analyzer (and, per WI-gapam, eventually the tree-sitter
        # base class for JS/Java/Go/C/Rust).
        "module_attr_ref",
        # audit-findings 0002 (WI-hahap-farid): IPC family folds to event_publishes
        # (ipc_event, message_send, websocket_message, message_queue);
        # adding the canonical preserves I/O-boundary tracing across async
        # channel boundaries after the rename.
        "event_publishes",
        # FFI edges — trace I/O boundaries across language boundaries
        "wasm_bridge", "wasm_load", "bridge_invokes",
        "cgo_bridge", "ffi_bridge",
        "ipc_calls", "ipc_event",
        # Protocol-call family (WI-vumum-juvil) folds to canonical
        # 'calls' + meta['protocol']; HTTP/gRPC/GraphQL traversals
        # transfer via 'calls'.
        "implements_rpc",
    }),
) -> int:
    """Tag edges that reach I/O primitives with boundary metadata.

    For each call-type edge, extracts the callee name from the destination
    symbol ID, looks it up in the appropriate language catalog, and stamps
    ``io_boundary`` and ``io_primitive`` into ``edge.meta`` if matched.

    When the destination belongs to an FFI pseudo-namespace (e.g.,
    ``go:C:0-0:fopen:unresolved`` for cgo calls), the lookup is
    redirected to the actual target-language catalog (``c`` in this case)
    so C stdlib IO primitives are recognized even when the cgo linker
    could not resolve the call to a repo-local C symbol.

    Args:
        edges: List of Edge objects to scan (mutated in place).
        catalogs: Language → IoBoundaryCatalog mapping.
        call_types: Edge types to consider. Default includes calls,
            imports, and FFI edge types (wasm_bridge, ipc_calls, etc.)
            so boundary tracing crosses language boundaries.

    Returns:
        Number of edges tagged.
    """
    tagged = 0
    for edge in edges:
        if edge.edge_type not in call_types:
            continue

        # Extract language from dst ID (first colon-delimited segment)
        dst_parts = edge.dst.split(":")
        lang = dst_parts[0]

        callee = _extract_callee_name(edge.dst)
        module_hint = _extract_module_hint(edge.dst)

        # Try FFI pseudo-namespace redirect first (e.g., go:C: → c catalog),
        # then fall back to the primary language catalog.
        catalog, adjusted_hint = _resolve_ffi_catalog(
            lang, module_hint, catalogs,
        )
        if catalog is None:
            continue

        match = catalog.lookup_with_module(callee, adjusted_hint)
        if match is None:
            continue

        if edge.meta is None:
            edge.meta = {}
        edge.meta["io_boundary"] = match.boundary
        edge.meta["io_primitive"] = match.qualified_name
        tagged += 1

    return tagged
