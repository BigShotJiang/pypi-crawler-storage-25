# SPDX-License-Identifier: AGPL-3.0-or-later
"""Protocol linker: HTTP client-server for detecting cross-language API calls.

This linker detects HTTP client calls (fetch, axios, AngularJS $http, jQuery $.ajax,
requests, OpenAPI clients, RestClient, HTTParty, Faraday, Net::HTTP, RestTemplate,
Retrofit) and links them to server route handlers detected by language analyzers.

Detected Client Patterns
------------------------
JavaScript/TypeScript:
- fetch("/api/users") - Fetch API with literal URL
- fetch(API_URL) - Fetch API with variable URL
- fetch("/api/users", { method: "POST" }) - with options
- axios.get("/api/users") - Axios library with literal URL
- axios.get(config.apiUrl) - Axios with variable URL
- __request(OpenAPI, { method: 'GET', url: '/api/users' }) - OpenAPI generated clients
- $http.get("/api/users") - AngularJS $http service
- $http({method: 'GET', url: '/api/users'}) - AngularJS config object
- $.get("/api/users") - jQuery shorthand
- $.post("/api/users", data) - jQuery shorthand
- $.ajax({url: '/api/users', type: 'GET'}) - jQuery $.ajax

Python:
- requests.get("/api/users") - requests library with literal URL
- requests.get(API_URL) - requests library with variable URL
- httpx.get("/api/users") - httpx library

Go:
- http.Get("/api/users") - net/http standard library
- http.Post("/api/users", contentType, body) - net/http POST
- http.Head("/api/users") - net/http HEAD
- http.NewRequest("DELETE", "/api/users/1", nil) - explicit method
- http.NewRequestWithContext(ctx, "PATCH", "/api/users/1", body) - with context

Ruby:
- RestClient.get("/api/users") - rest-client gem
- HTTParty.get("/api/users") - httparty gem
- Faraday.get("/api/users") - faraday gem
- Net::HTTP.get(URI("/api/users")) - stdlib net/http
- Net::HTTP.post_form(URI("/api/users"), data) - stdlib net/http POST
- Net::HTTP.get_response(URI("/api/users")) - stdlib net/http

Java:
- restTemplate.getForObject("/api/users", ...) - Spring RestTemplate
- restTemplate.postForEntity("/api/users", ...) - Spring RestTemplate
- restTemplate.exchange("/api/users", HttpMethod.GET, ...) - Spring RestTemplate
- restTemplate.delete("/api/users/1") - Spring RestTemplate
- @GET("/api/users") - Retrofit annotation
- @POST("/api/items") - Retrofit annotation

Variable URL Detection
----------------------
URLs stored in variables are detected with lower confidence (0.65 vs 0.9):
- const API_URL = '/api/users'; fetch(API_URL) -> detected with url_type="variable"
- Direct literal URLs have url_type="literal" and higher confidence

Server Route Matching
---------------------
Routes are matched by:
1. HTTP method (GET, POST, PUT, DELETE, etc.)
2. URL path pattern (exact match or parameterized)

Parameterized routes are supported:
- /users/:id (Express/Flask style)
- /users/{id} (FastAPI/Retrofit style)
- /users/<id> (Flask style)

How It Works
------------
1. Collect route symbols from language analyzers (kind="route")
2. Scan source files for HTTP client calls
3. Extract URL and method from each call (literal or variable)
4. Match to route symbols by method + path pattern
5. Create canonical 'calls' edges with meta['protocol']='http' linking
   client to server (post WI-vumum-juvil; pre-fold name was http_calls)

Why This Design
---------------
- Cross-language linking enables full-stack code understanding
- Regex-based client detection is fast and portable
- Route matching handles common parameterization patterns
- Symbols for client calls enable slice traversal from either end
- Variable URL detection catches patterns where URLs are stored in constants
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator
from urllib.parse import urlparse

from ..analyze.base import make_route_stable_id
from ..discovery import find_files
from ..ir import AnalysisRun, Edge, PASS_VERSION, Span, Symbol, make_pass_id
from ._concept_utils import get_concept, has_concept
from .registry import LinkerContext, LinkerResult, LinkerRequirement, register_linker
from ._text_filters import read_masked_source

PASS_ID = make_pass_id("http-linker")


@dataclass
class HttpClientCall:
    """Represents a detected HTTP client call."""

    method: str  # GET, POST, PUT, DELETE, etc.
    url: str  # The URL string from the call
    line: int  # Line number in source
    file_path: str  # Source file path
    language: str  # Source language
    url_type: str = "literal"  # "literal" or "variable"


@dataclass
class HttpLinkResult:
    """Result of HTTP client-server linking."""

    edges: list[Edge] = field(default_factory=list)
    symbols: list[Symbol] = field(default_factory=list)
    run: AnalysisRun | None = None


# Pattern for matching variable identifiers (e.g., API_URL, config.apiUrl)
_IDENTIFIER = r"[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*"

# Combined pattern: matches either quoted string literal or variable identifier
# Group 1: literal URL, Group 2: variable identifier
_URL_ARG = rf"(?:['\"]([^'\"]+)['\"]|({_IDENTIFIER}))"

# Python HTTP client patterns - supports both literal URLs and variables
PYTHON_REQUESTS_PATTERN = re.compile(
    rf"""(?:requests|httpx)\.
        (get|post|put|patch|delete|head|options)
        \s*\(\s*
        {_URL_ARG}""",
    re.VERBOSE | re.IGNORECASE,
)

# JavaScript fetch pattern - supports both literal URLs and variables
JS_FETCH_PATTERN = re.compile(
    rf"""fetch\s*\(\s*{_URL_ARG}""",
    re.VERBOSE,
)

# JavaScript fetch with method option - literal URL only (complex pattern)
JS_FETCH_METHOD_PATTERN = re.compile(
    r"""fetch\s*\(\s*["']([^"']+)["']\s*,\s*\{[^}]*method\s*:\s*["'](\w+)["']""",
    re.VERBOSE | re.IGNORECASE,
)

# JavaScript axios pattern - supports both literal URLs and variables
JS_AXIOS_PATTERN = re.compile(
    rf"""axios\.(get|post|put|patch|delete|head|options)
        \s*\(\s*{_URL_ARG}""",
    re.VERBOSE | re.IGNORECASE,
)

# OpenAPI-generated client pattern (__request from @hey-api/openapi-ts, etc.)
# Matches: __request(OpenAPI, { method: 'GET', url: '/api/v1/items/' })
JS_OPENAPI_REQUEST_PATTERN = re.compile(
    r"""__request\s*\(\s*\w+\s*,\s*\{[^}]*
        method\s*:\s*["'](\w+)["'][^}]*
        url\s*:\s*["']([^"']+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# Alternative OpenAPI pattern where url comes before method
JS_OPENAPI_REQUEST_ALT_PATTERN = re.compile(
    r"""__request\s*\(\s*\w+\s*,\s*\{[^}]*
        url\s*:\s*["']([^"']+)["'][^}]*
        method\s*:\s*["'](\w+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# AngularJS $http service patterns
# $http.get/post/put/patch/delete("url") - method shorthand
JS_ANGULARJS_HTTP_PATTERN = re.compile(
    rf"""\$http\.(get|post|put|patch|delete|head|options)
        \s*\(\s*{_URL_ARG}""",
    re.VERBOSE | re.IGNORECASE,
)

# $http({method: 'GET', url: '/api/users'}) - config object (method before url)
JS_ANGULARJS_HTTP_CONFIG_PATTERN = re.compile(
    r"""\$http\s*\(\s*\{[^}]*
        method\s*:\s*["'](\w+)["'][^}]*
        url\s*:\s*["']([^"']+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# $http({url: '/api/users', method: 'POST'}) - config object (url before method)
JS_ANGULARJS_HTTP_CONFIG_ALT_PATTERN = re.compile(
    r"""\$http\s*\(\s*\{[^}]*
        url\s*:\s*["']([^"']+)["'][^}]*
        method\s*:\s*["'](\w+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# jQuery $.ajax({url: '/api/users', type: 'GET'}) or method: 'GET'
JS_JQUERY_AJAX_PATTERN = re.compile(
    r"""\$\.ajax\s*\(\s*\{[^}]*
        url\s*:\s*["']([^"']+)["'][^}]*
        (?:type|method)\s*:\s*["'](\w+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# jQuery $.ajax with type/method before url
JS_JQUERY_AJAX_ALT_PATTERN = re.compile(
    r"""\$\.ajax\s*\(\s*\{[^}]*
        (?:type|method)\s*:\s*["'](\w+)["'][^}]*
        url\s*:\s*["']([^"']+)["']""",
    re.VERBOSE | re.IGNORECASE | re.DOTALL,
)

# jQuery $.get/$.post shorthand - $.get("url", ...) or $.post("url", ...)
JS_JQUERY_SHORTHAND_PATTERN = re.compile(
    rf"""\$\.(get|post)\s*\(\s*{_URL_ARG}""",
    re.VERBOSE | re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# JS/TS template-literal fetch/axios (WI-sijoh)
# ---------------------------------------------------------------------------
#
# TypeScript / modern JavaScript widely uses backtick template literals with
# ${...} interpolation to build request URLs:
#
#     const API_PATH = "api/v1";
#     fetch(`${pathPrefix}/${API_PATH}${path}${queryString}`);
#
# The regex below matches `fetch(`...`)` and `axios.METHOD(`...`)` where
# the single backtick-delimited string contains the whole URL template.
# Nested template literals (backticks inside `${...}`) are rare in real
# client code — we intentionally do NOT recurse, and a file containing
# one will either miss the outer template or capture a truncated URL;
# either outcome is safe (no false-positive routes).
#
# The captured template is folded by _fold_template_literal() against
# module-scope const assignments extracted by _extract_module_constants().

# fetch(`TEMPLATE`) with default GET method.
JS_FETCH_TEMPLATE_PATTERN = re.compile(
    r"""fetch\s*\(\s*`([^`]*)`""",
    re.VERBOSE,
)

# axios.METHOD(`TEMPLATE`, ...)
JS_AXIOS_TEMPLATE_PATTERN = re.compile(
    r"""axios\.(get|post|put|patch|delete|head|options)
        \s*\(\s*`([^`]*)`""",
    re.VERBOSE | re.IGNORECASE,
)

# Module-scope const/let/var assigned to a plain string literal.
# Anchored at line start (MULTILINE) with no leading indentation, so
# function-scope bindings are excluded — only top-level module bindings
# are safe to substitute without tracking scope.
JS_MODULE_CONST_PATTERN = re.compile(
    r"""^(?:export\s+)?(?:const|let|var)\s+
        ([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*
        ["']([^"']+)["']\s*;?\s*$""",
    re.VERBOSE | re.MULTILINE,
)

# Any ${...} interpolation slot inside a template literal.
_TEMPLATE_SLOT = re.compile(r"\$\{([^}]+)\}")


# ---------------------------------------------------------------------------
# Elm HTTP client patterns (WI-tinip)
# ---------------------------------------------------------------------------
#
# Elm's HTTP idioms vary by library, but the dominant pattern in the
# Alertmanager UI (and most Elm 0.19+ apps) is to thread an `apiUrl`
# parameter through a wrapper module (`Utils.Api`) that exposes
# `get`/`post`/`put`/`delete` functions. The URL is built with `++`
# string concatenation:
#
#     Utils.Api.get (apiUrl ++ "/receivers") decoder
#     Utils.Api.post (apiUrl ++ "/silences") body decoder
#
# We also catch the stdlib `Http.get { url = "...", ... }` form and
# its `Http.request { method = "POST", url = "...", ... }` cousin.
#
# Captured in group 1 is the literal path portion (including the
# leading slash). The concatenated `apiUrl` prefix is treated as a
# host/base, so the path that remains is what we match against the Go
# route table (e.g. `/api/v2/alerts`). url_type is always "literal"
# because the string after `++` is a literal.
#
# Note: the function-definition forms with `let`-bound URLs (e.g.
# `fetchAlerts` in Alerts/Api.elm uses `String.join "/"` over a list)
# are harder to resolve without a proper Elm analyzer and are deferred
# to a follow-up. The majority of routes (`fetchReceivers`,
# `fetchSilences`, `fetchStatus`, etc. in the Alertmanager corpus) use
# the direct `apiUrl ++ "/path"` form and are captured here.
ELM_UTILS_API_PATTERN = re.compile(
    r"""Utils\.Api\.(get|post|put|patch|delete|head|options)
        \s*\(\s*
        [a-zA-Z_][a-zA-Z0-9_]*     # base-url variable (apiUrl, baseUrl, etc.)
        \s*\+\+\s*
        "([^"]+)"                   # literal path segment
    """,
    re.VERBOSE,
)

# Http.get { url = "..." } / Http.post { url = "..." } — core-library form
# Captures method from the call name, URL from the record field.
ELM_HTTP_RECORD_PATTERN = re.compile(
    r"""Http\.(get|post|put|patch|delete|head|options)
        \s*\{\s*[^}]*?
        url\s*=\s*"([^"]+)"
    """,
    re.VERBOSE | re.DOTALL,
)

# Http.request { method = "GET", url = "...", ... } — explicit-method form
ELM_HTTP_REQUEST_METHOD_PATTERN = re.compile(
    r"""Http\.request
        \s*\{\s*[^}]*?
        method\s*=\s*"(\w+)"[^}]*?
        url\s*=\s*"([^"]+)"
    """,
    re.VERBOSE | re.DOTALL,
)

# Http.request { url = "...", method = "GET", ... } — url before method
ELM_HTTP_REQUEST_URL_FIRST_PATTERN = re.compile(
    r"""Http\.request
        \s*\{\s*[^}]*?
        url\s*=\s*"([^"]+)"[^}]*?
        method\s*=\s*"(\w+)"
    """,
    re.VERBOSE | re.DOTALL,
)


# ---------------------------------------------------------------------------
# Elm let-bound ``String.join`` URL idiom (WI-rosan)
# ---------------------------------------------------------------------------
#
# Alertmanager's ``Silences/Api.elm`` and ``Alerts/Api.elm`` construct URLs
# via a ``let`` binding over ``String.join "/" [ apiUrl, ... ]`` and then
# pass the bound identifier to ``Utils.Api.<method>``. Example::
#
#     getSilence apiUrl uuid =
#         let
#             url =
#                 String.join "/" [ apiUrl, "silence", uuid ]
#         in
#         Utils.Api.send (Utils.Api.get url decoder)
#
# These calls are invisible to the Phase-1 regex scanner because the URL is
# indirected through a variable. This two-pass fold captures them:
#
#   1. Match every ``let <name> = String.join "/" [ <parts> ]`` binding.
#   2. Scan forward (bounded window) for a ``Utils.Api.<method> <name>``
#      call that consumes the bound identifier. If found, fold the list
#      items into a URL path.
#
# Parts are classified as literal string fragments (``"silence"`` or
# ``"silence" ++ <expr>`` — literal portion wins, ``++`` tail is dropped as
# a query/suffix continuation) or identifier references (``uuid``,
# ``silence.id`` — rewritten to ``{name}`` placeholders so
# ``_match_route_pattern`` can match them against Go route parameters).
# The first list item is assumed to be the base-URL variable (``apiUrl``,
# ``baseUrl``) and is dropped as the host prefix.

ELM_LET_STRING_JOIN_PATTERN = re.compile(
    r"""let\s+
        (?P<name>[a-zA-Z_]\w*)
        \s*=\s*
        String\.join\s+"/"\s+
        \[\s*(?P<parts>[^\[\]]*?)\s*\]
    """,
    re.VERBOSE | re.DOTALL,
)

# Elm ``Utils.Api.<method> <name>`` or ``Utils.Api.<method> (<name> ...)``
# call consuming a let-bound identifier. The ``<name>`` is interpolated via
# ``re.escape`` at match time since it varies per binding.
_ELM_URL_CALL_TEMPLATE = (
    r"""Utils\.Api\.
        (?P<method>get|post|put|patch|delete|head|options)
        \s+\(?\s*
        {name}\b
    """
)

# Scan window (chars) for finding the consuming call after a let-binding.
# Elm functions are typically short; 800 chars covers the largest realistic
# ``let ... in <body>`` block in the Alertmanager UI corpus.
_ELM_LET_CALL_WINDOW = 800


def _extract_url_from_match(match: re.Match, literal_group: int = 1, var_group: int = 2) -> tuple[str, str]:
    """Extract URL and url_type from a regex match.

    The _URL_ARG pattern captures:
    - Group literal_group: string literal (e.g., '/api/users')
    - Group var_group: variable identifier (e.g., API_URL, config.apiUrl)

    Returns:
        Tuple of (url, url_type) where url_type is "literal" or "variable".
    """
    literal = match.group(literal_group)
    if literal:
        return literal, "literal"
    variable = match.group(var_group)
    return variable, "variable"


def _extract_module_constants(content: str) -> dict[str, str]:
    """Extract module-scope string consts from a JS/TS source file (WI-sijoh).

    Scans for top-level ``const NAME = "value"`` (and ``let``/``var``/``export``
    variants) where the RHS is a single-line string literal. Function-scope
    bindings are excluded by the MULTILINE + line-start anchor in
    ``JS_MODULE_CONST_PATTERN``: any indentation means the binding lives
    inside a block, and folding it at call sites would be unsound.

    Numeric, object, array, and function-call RHS values are ignored — only
    plain string literals can be safely folded into URL templates.
    """
    return {
        m.group(1): m.group(2)
        for m in JS_MODULE_CONST_PATTERN.finditer(content)
    }


def _fold_template_literal(
    template: str, consts: dict[str, str]
) -> tuple[str, str]:
    """Fold ``${NAME}`` slots in a JS/TS template literal (WI-sijoh).

    Strategy (mirrors Elm wrapper-module semantics for host-prefix idioms
    and preserves path-parameter placeholders for ``_match_route_pattern``):

    * ``${NAME}`` slots resolved via ``consts`` → literal substitution.
    * Unresolved ``${NAME}`` slots → rewritten as ``{NAME}``.
    * Leading ``{VAR}/`` is stripped as a host/base URL prefix (the TS
      analogue of Elm's ``apiUrl ++ "/path"`` idiom).
    * An unresolved ``{VAR}`` preceded by ``/`` is a path segment parameter
      and is kept — ``_match_route_pattern`` converts ``:id``/``{id}``/``<id>``
      style placeholders to ``[^/]+`` on the route side, which matches our
      ``{VAR}`` on the client side.
    * An unresolved ``{VAR}`` NOT preceded by ``/`` is arbitrary template
      continuation (may span segments, may be a query-string tail). The
      URL is truncated at that point and the remaining literal prefix is
      used for route matching. Result is marked ``url_type="variable"``
      so callers can opt into prefix-matching semantics.

    Returns ``(folded_url, url_type)`` where ``url_type`` is ``"literal"``
    when every slot resolved cleanly (no truncation) AND the URL has a
    leading ``/`` anchor, else ``"variable"``.
    """
    def _sub(match: re.Match) -> str:
        name = match.group(1).strip()
        if name in consts:
            return consts[name]
        return "{" + name + "}"

    folded = _TEMPLATE_SLOT.sub(_sub, template)

    # Host-prefix strip: `{pathPrefix}/rest...` → `/rest...`.
    host_prefix = re.match(r"^\{[^}]+\}(/.*)$", folded)
    if host_prefix is not None:
        folded = host_prefix.group(1)

    # Find the first ``{VAR}`` that is NOT preceded by ``/``. Placeholders
    # preceded by ``/`` (or at string start after host-prefix strip, which
    # always leaves a leading ``/``) are treated as path-segment params and
    # retained. Non-``/``-preceded placeholders indicate template
    # continuation and truncate the URL there.
    truncated = False
    trunc_match = re.search(r"(?<!/)\{[^}]+\}", folded)
    if trunc_match is not None:
        folded = folded[: trunc_match.start()]
        truncated = True

    if truncated or not folded.startswith("/"):
        url_type = "variable"
    else:
        url_type = "literal"
    return folded, url_type


def _is_prefix_candidate(call_path: str) -> bool:
    """Return True when ``call_path`` is deep enough for prefix route matching.

    Used by the variable-URL fallback in ``link_http`` (WI-sijoh). A prefix
    of ``/`` or ``/api`` could match nearly every route in a medium-sized
    API and would drown real signal in noise — require at least two non-
    empty path segments (e.g. ``/api/v1``) before allowing prefix fallback.
    """
    segments = [seg for seg in call_path.split("/") if seg]
    return len(segments) >= 2


def _extract_path_from_url(url: str) -> str | None:
    """Extract the path component from a URL.

    Args:
        url: A URL string, either full (http://...) or path-only (/api/...)

    Returns:
        The path component, or None if invalid.
    """
    if not url:
        return None

    # Strip query parameters
    url = url.split("?")[0]

    # If it's a full URL, parse it
    if url.startswith(("http://", "https://")):
        parsed = urlparse(url)
        return parsed.path or "/"

    # Otherwise it's already a path
    return url


def _match_route_pattern(request_path: str, route_pattern: str) -> bool:
    """Check if a request path matches a route pattern.

    Handles parameterized routes:
    - :param (Express/Flask)
    - {param} (FastAPI)
    - <param> (Flask)

    Args:
        request_path: The actual path from the HTTP call (e.g., /users/123)
        route_pattern: The route pattern (e.g., /users/:id)

    Returns:
        True if the path matches the pattern.
    """
    # Normalize trailing slashes
    request_path = request_path.rstrip("/") or "/"
    route_pattern = route_pattern.rstrip("/") or "/"

    # Exact match
    if request_path == route_pattern:
        return True

    # Convert route pattern to regex
    # Escape special regex chars except our param patterns
    pattern = route_pattern

    # Replace :param with regex group
    pattern = re.sub(r":(\w+)", r"[^/]+", pattern)

    # Replace {param} with regex group
    pattern = re.sub(r"\{(\w+)\}", r"[^/]+", pattern)

    # Replace <param> with regex group
    pattern = re.sub(r"<(\w+)>", r"[^/]+", pattern)

    # Escape remaining special chars
    pattern = pattern.replace(".", r"\.")

    # Match full path
    pattern = f"^{pattern}$"

    try:
        return bool(re.match(pattern, request_path))
    except re.error:  # pragma: no cover
        return False


# Go HTTP client patterns
# http.Get/Post/Head("url") - supports both literal URLs and variables
GO_HTTP_SIMPLE_PATTERN = re.compile(
    rf"""http\.(Get|Post|Head)\s*\(\s*{_URL_ARG}""",
    re.VERBOSE,
)

# http.NewRequest("METHOD", "url", body) - explicit method
GO_HTTP_NEW_REQUEST_PATTERN = re.compile(
    rf"""http\.NewRequest\s*\(\s*["'](\w+)["']\s*,\s*{_URL_ARG}""",
    re.VERBOSE,
)

# http.NewRequestWithContext(ctx, "METHOD", "url", body) - with context
GO_HTTP_NEW_REQUEST_CTX_PATTERN = re.compile(
    rf"""http\.NewRequestWithContext\s*\(\s*\w+\s*,\s*["'](\w+)["']\s*,\s*{_URL_ARG}""",
    re.VERBOSE,
)


# Ruby HTTP client patterns
# RestClient.get/post/put/patch/delete("url") - rest-client gem
# HTTParty.get/post/put/patch/delete("url") - httparty gem
# Faraday.get/post/put/patch/delete("url") - faraday gem
RUBY_HTTP_LIB_PATTERN = re.compile(
    rf"""(?:RestClient|HTTParty|Faraday)\.
        (get|post|put|patch|delete|head|options)
        \s*\(\s*
        {_URL_ARG}""",
    re.VERBOSE | re.IGNORECASE,
)

# Net::HTTP.get/get_response(URI("url")) or Net::HTTP.get(URI.parse("url"))
# Net::HTTP.post_form(URI("url"), data)
RUBY_NET_HTTP_PATTERN = re.compile(
    r"""Net::HTTP\.(get|post_form|get_response)
        \s*\(\s*
        URI(?:\.parse)?\s*\(\s*
        ["']([^"']+)["']""",
    re.VERBOSE,
)

# Java RestTemplate patterns
# restTemplate.getForObject/getForEntity/postForObject/postForEntity/patchForObject("url", ...)
# Note: `put` and `delete` are excluded because they're too common as generic
# method names (HashMap.put, List.delete, etc.), causing false positives.
# Use the exchange() pattern (below) for RestTemplate PUT/DELETE detection.
JAVA_REST_TEMPLATE_PATTERN = re.compile(
    rf"""\w+\.(getForObject|getForEntity|postForObject|postForEntity|
        patchForObject)
        \s*\(\s*
        {_URL_ARG}""",
    re.VERBOSE,
)

# restTemplate.exchange("url", HttpMethod.METHOD, ...)
JAVA_REST_TEMPLATE_EXCHANGE_PATTERN = re.compile(
    rf"""\w+\.exchange\s*\(\s*
        {_URL_ARG}\s*,\s*
        HttpMethod\.(\w+)""",
    re.VERBOSE,
)

# Retrofit annotations: @GET("/api/users"), @POST("/api/users"), etc.
JAVA_RETROFIT_ANNOTATION_PATTERN = re.compile(
    r"""@(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)
        \s*\(\s*
        ["']([^"']+)["']""",
    re.VERBOSE,
)


def _find_source_files(root: Path) -> Iterator[Path]:
    """Find files that might contain HTTP client calls.

    Skips minified files (``*.min.js``, ``*.min.ts``) which can produce
    false-positive HTTP call detections from compressed library code.
    """
    patterns = [
        "**/*.py", "**/*.js", "**/*.ts", "**/*.jsx", "**/*.tsx",
        "**/*.go", "**/*.rb", "**/*.java", "**/*.elm",
    ]
    for path in find_files(root, patterns):
        if path.stem.endswith(".min"):
            continue
        yield path


def _scan_python_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan a Python file for HTTP client calls."""
    calls: list[HttpClientCall] = []

    for match in PYTHON_REQUESTS_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="python",
                url_type=url_type,
            )
        )

    return calls


def _scan_javascript_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan a JavaScript/TypeScript file for HTTP client calls."""
    calls: list[HttpClientCall] = []

    # Module-scope string consts used for template-literal folding (WI-sijoh).
    # Extracted once per file; reused for every fetch/axios template below.
    module_consts = _extract_module_constants(content)

    # Template-literal fetch/axios calls (WI-sijoh). Processed alongside
    # the quoted-URL patterns below; no de-dup is needed because the
    # JS_FETCH_PATTERN / JS_AXIOS_PATTERN _URL_ARG alternation only
    # matches ['"]...['"] or a bare identifier — never a backtick
    # template, so the two scan passes are disjoint.
    for match in JS_FETCH_TEMPLATE_PATTERN.finditer(content):
        template = match.group(1)
        url, url_type = _fold_template_literal(template, module_consts)
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method="GET",
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    for match in JS_AXIOS_TEMPLATE_PATTERN.finditer(content):
        method = match.group(1).upper()
        template = match.group(2)
        url, url_type = _fold_template_literal(template, module_consts)
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    # Check for fetch with method option first (more specific, literal URLs only)
    fetch_method_matches = set()
    for match in JS_FETCH_METHOD_PATTERN.finditer(content):
        url = match.group(1)
        method = match.group(2).upper()
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )
        fetch_method_matches.add(match.start())

    # Check for simple fetch calls (default to GET) - supports variables
    for match in JS_FETCH_PATTERN.finditer(content):
        # Skip if we already captured this with method option
        if match.start() in fetch_method_matches:
            continue

        # Groups: 1=literal URL, 2=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=1, var_group=2)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method="GET",
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    # Check for axios calls - supports variables
    for match in JS_AXIOS_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    # Check for OpenAPI-generated __request() calls (literal URLs only)
    openapi_matches = set()
    for match in JS_OPENAPI_REQUEST_PATTERN.finditer(content):
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )
        openapi_matches.add(match.start())

    # Check alternative pattern (url before method)
    for match in JS_OPENAPI_REQUEST_ALT_PATTERN.finditer(content):
        if match.start() in openapi_matches:  # pragma: no cover
            continue  # Already captured
        url = match.group(1)
        method = match.group(2).upper()
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )

    # Check for AngularJS $http.method() calls - supports variables
    for match in JS_ANGULARJS_HTTP_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    # Check for AngularJS $http({method: ..., url: ...}) config object
    angularjs_config_matches = set()
    for match in JS_ANGULARJS_HTTP_CONFIG_PATTERN.finditer(content):
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )
        angularjs_config_matches.add(match.start())

    # Check alternative pattern (url before method)
    for match in JS_ANGULARJS_HTTP_CONFIG_ALT_PATTERN.finditer(content):
        if match.start() in angularjs_config_matches:  # pragma: no cover
            continue
        url = match.group(1)
        method = match.group(2).upper()
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )

    # Check for jQuery $.get/$.post shorthand
    for match in JS_JQUERY_SHORTHAND_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type=url_type,
            )
        )

    # Check for jQuery $.ajax({url: ..., type/method: ...})
    jquery_ajax_matches = set()
    for match in JS_JQUERY_AJAX_PATTERN.finditer(content):
        url = match.group(1)
        method = match.group(2).upper()
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )
        jquery_ajax_matches.add(match.start())

    # Check alternative pattern (type/method before url)
    for match in JS_JQUERY_AJAX_ALT_PATTERN.finditer(content):
        if match.start() in jquery_ajax_matches:  # pragma: no cover
            continue
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="javascript",
                url_type="literal",
            )
        )

    return calls


def _scan_go_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan a Go file for HTTP client calls.

    Detects standard library net/http patterns:
    - http.Get/Post/Head("url") — simple shorthand calls
    - http.NewRequest("METHOD", "url", body) — explicit method
    - http.NewRequestWithContext(ctx, "METHOD", "url", body) — with context
    """
    calls: list[HttpClientCall] = []

    # http.Get/Post/Head("url")
    for match in GO_HTTP_SIMPLE_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method name, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="go",
                url_type=url_type,
            )
        )

    # http.NewRequest("METHOD", "url", body)
    for match in GO_HTTP_NEW_REQUEST_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="go",
                url_type=url_type,
            )
        )

    # http.NewRequestWithContext(ctx, "METHOD", "url", body)
    for match in GO_HTTP_NEW_REQUEST_CTX_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="go",
                url_type=url_type,
            )
        )

    return calls


def _scan_ruby_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan a Ruby file for HTTP client calls.

    Detects three families of Ruby HTTP clients:
    - RestClient, HTTParty, Faraday: LIB.method("url") pattern
    - Net::HTTP: Net::HTTP.get/post_form/get_response(URI("url")) pattern
    """
    calls: list[HttpClientCall] = []

    # RestClient/HTTParty/Faraday.method("url")
    for match in RUBY_HTTP_LIB_PATTERN.finditer(content):
        method = match.group(1).upper()
        # Groups: 1=method, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="ruby",
                url_type=url_type,
            )
        )

    # Net::HTTP.get/post_form/get_response(URI("url"))
    for match in RUBY_NET_HTTP_PATTERN.finditer(content):
        method_name = match.group(1).lower()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1

        # Map method names to HTTP methods
        if method_name == "post_form":
            http_method = "POST"
        else:
            # get and get_response both map to GET
            http_method = "GET"

        calls.append(
            HttpClientCall(
                method=http_method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="ruby",
                url_type="literal",
            )
        )

    return calls


# Map RestTemplate method names to HTTP methods
_REST_TEMPLATE_METHOD_MAP = {
    "getforobject": "GET",
    "getforentity": "GET",
    "postforobject": "POST",
    "postforentity": "POST",
    "patchforobject": "PATCH",
}


def _scan_java_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan a Java file for HTTP client calls.

    Detects two families of Java HTTP clients:
    - Spring RestTemplate: restTemplate.getForObject/postForEntity/exchange/delete/put
    - Retrofit: @GET/@POST/@PUT/@DELETE/@PATCH annotations
    """
    calls: list[HttpClientCall] = []

    # RestTemplate method calls (getForObject, postForEntity, delete, put, etc.)
    for match in JAVA_REST_TEMPLATE_PATTERN.finditer(content):
        method_name = match.group(1).lower()
        # Groups: 1=method name, 2=literal URL, 3=variable URL
        url, url_type = _extract_url_from_match(match, literal_group=2, var_group=3)
        line_num = content[: match.start()].count("\n") + 1

        http_method = _REST_TEMPLATE_METHOD_MAP.get(method_name, "GET")

        calls.append(
            HttpClientCall(
                method=http_method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="java",
                url_type=url_type,
            )
        )

    # RestTemplate.exchange("url", HttpMethod.METHOD, ...)
    for match in JAVA_REST_TEMPLATE_EXCHANGE_PATTERN.finditer(content):
        # Groups: 1=literal URL, 2=variable URL, 3=HTTP method
        url, url_type = _extract_url_from_match(match, literal_group=1, var_group=2)
        http_method = match.group(3).upper()
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=http_method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="java",
                url_type=url_type,
            )
        )

    # Retrofit annotations: @GET("/api/users"), @POST("/api/items")
    for match in JAVA_RETROFIT_ANNOTATION_PATTERN.finditer(content):
        http_method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1

        calls.append(
            HttpClientCall(
                method=http_method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="java",
                url_type="literal",
            )
        )

    return calls


def _parse_string_join_parts(parts: str) -> list[tuple[str, bool]]:
    """Parse the top-level comma-separated items inside ``String.join "/" [...]``.

    Returns a list of ``(value, is_literal)`` tuples. Items beginning with a
    ``"..."`` string literal are classified as literal (literal text is the
    value; any trailing ``++ <expr>`` is dropped). Anything else is classified
    as an identifier reference — the value is the last dotted component of
    the identifier (``silence.id`` → ``id``), which becomes a ``{name}``
    placeholder downstream. Unparseable items (empty or exotic) are skipped.
    """
    items: list[tuple[str, bool]] = []
    for raw in parts.split(","):
        segment = raw.strip()
        if not segment:
            continue
        literal_match = re.match(r'^"([^"]*)"', segment)
        if literal_match is not None:
            items.append((literal_match.group(1), True))
            continue
        ident_match = re.match(r"^[a-zA-Z_]\w*(?:\.\w+)*", segment)
        if ident_match is not None:
            last_component = ident_match.group(0).rsplit(".", 1)[-1]
            items.append((last_component, False))
            continue
    return items


def _fold_elm_string_join(parts: str) -> str | None:
    """Fold a ``String.join "/" [...]`` parts list into a URL path.

    Strategy: drop the first list item (assumed base URL variable, e.g.
    ``apiUrl``) as the host prefix. Join the remaining items with ``/``.
    Literal items contribute their text; identifier references become
    ``{name}`` placeholders so ``_match_route_pattern`` can match them
    against Go route parameters.

    Returns the URL (``"/silence/{uuid}"``, ``"/alerts"``) or ``None`` if
    the list is empty or has no path segments after the base URL.
    """
    items = _parse_string_join_parts(parts)
    if len(items) < 2:
        return None
    segments: list[str] = []
    for value, is_literal in items[1:]:
        segments.append(value if is_literal else "{" + value + "}")
    return "/" + "/".join(segments)


def _find_elm_let_bound_url_calls(
    content: str,
) -> list[tuple[str, str, int]]:
    """Find Elm ``Utils.Api.<method>`` calls whose URL comes from a
    ``let ... = String.join "/" [...]`` binding (WI-rosan).

    Returns a list of ``(method, url, line)`` tuples for each consumed
    let-binding. A let-binding whose identifier is never referenced by a
    subsequent ``Utils.Api.<method>`` call within the scan window is
    ignored — we don't invent calls that aren't in the source.
    """
    results: list[tuple[str, str, int]] = []
    for let_match in ELM_LET_STRING_JOIN_PATTERN.finditer(content):
        name = let_match.group("name")
        parts = let_match.group("parts")
        url = _fold_elm_string_join(parts)
        if url is None:
            continue
        window_end = let_match.end() + _ELM_LET_CALL_WINDOW
        tail = content[let_match.end():window_end]
        call_pattern = re.compile(
            _ELM_URL_CALL_TEMPLATE.format(name=re.escape(name)),
            re.VERBOSE,
        )
        call_match = call_pattern.search(tail)
        if call_match is None:
            continue
        method = call_match.group("method").upper()
        abs_pos = let_match.end() + call_match.start()
        line = content[:abs_pos].count("\n") + 1
        results.append((method, url, line))
    return results


def _scan_elm_file(file_path: Path, content: str) -> list[HttpClientCall]:
    """Scan an Elm file for HTTP client calls.

    Detects three idioms (WI-tinip):

    1. ``Utils.Api.get (apiUrl ++ "/path") ...`` — the Alertmanager-style
       wrapper-module pattern where a base-URL parameter is concatenated
       with a literal path.
    2. ``Http.get { url = "...", expect = ... }`` and the other
       method-named record forms from the ``elm/http`` core library.
    3. ``Http.request { method = "POST", url = "...", ... }`` and its
       reverse-order variant, for cases where the HTTP method is
       spelled out as a string field.
    4. ``let <name> = String.join "/" [ apiUrl, "path", ... ] in
       Utils.Api.<method> <name>`` — the indirect let-bound form used
       throughout Alertmanager's ``Silences/Api.elm`` and
       ``Alerts/Api.elm`` (WI-rosan). Identifier references in the
       list become ``{name}`` placeholders so the cross-language
       route matcher can bind them to Go route parameters.
    """
    calls: list[HttpClientCall] = []

    for match in ELM_UTILS_API_PATTERN.finditer(content):
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="elm",
                url_type="literal",
            )
        )

    for match in ELM_HTTP_RECORD_PATTERN.finditer(content):
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="elm",
                url_type="literal",
            )
        )

    for match in ELM_HTTP_REQUEST_METHOD_PATTERN.finditer(content):
        method = match.group(1).upper()
        url = match.group(2)
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="elm",
                url_type="literal",
            )
        )

    for match in ELM_HTTP_REQUEST_URL_FIRST_PATTERN.finditer(content):
        url = match.group(1)
        method = match.group(2).upper()
        line_num = content[: match.start()].count("\n") + 1
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="elm",
                url_type="literal",
            )
        )

    for method, url, line_num in _find_elm_let_bound_url_calls(content):
        calls.append(
            HttpClientCall(
                method=method,
                url=url,
                line=line_num,
                file_path=str(file_path),
                language="elm",
                url_type="literal",
            )
        )

    return calls


def _create_client_symbol(call: HttpClientCall, root: Path) -> Symbol:
    """Create a symbol for an HTTP client call."""
    rel_path = Path(call.file_path).relative_to(root) if root else Path(call.file_path)

    # ADR-0027 Phase 3 / audit-findings 0013: framework-role leak.
    # Fold to canonical kind="function" + meta["framework_role"].
    return Symbol(
        id=f"{rel_path}::http_client::{call.line}",
        name=f"{call.method} {call.url}",
        kind="function",
        path=call.file_path,
        span=Span(
            start_line=call.line,
            start_col=0,
            end_line=call.line,
            end_col=0,
        ),
        language=call.language,
        stable_id=make_route_stable_id(
            call.method, _extract_path_from_url(call.url) or call.url
        ),
        meta={
            "http_method": call.method,
            "url_path": _extract_path_from_url(call.url) or call.url,
            "raw_url": call.url,
            "url_type": call.url_type,
            "framework_role": "http_client",
        },
    )


def link_http(root: Path, route_symbols: list[Symbol]) -> HttpLinkResult:
    """Link HTTP client calls to server route handlers.

    Args:
        root: Repository root path.
        route_symbols: Route symbols from language analyzers (kind="route").

    Returns:
        HttpLinkResult with edges linking clients to servers.
    """
    start_time = time.time()
    run = AnalysisRun.create(pass_id=PASS_ID, version=PASS_VERSION)

    edges: list[Edge] = []
    symbols: list[Symbol] = []
    files_scanned = 0

    # Collect all HTTP client calls
    all_calls: list[HttpClientCall] = []

    for file_path in _find_source_files(root):
        try:
            content = read_masked_source(file_path, encoding="utf-8", errors="ignore")
            files_scanned += 1

            if file_path.suffix == ".py":
                calls = _scan_python_file(file_path, content)
            elif file_path.suffix == ".go":
                calls = _scan_go_file(file_path, content)
            elif file_path.suffix == ".rb":
                calls = _scan_ruby_file(file_path, content)
            elif file_path.suffix == ".java":
                calls = _scan_java_file(file_path, content)
            elif file_path.suffix == ".elm":
                calls = _scan_elm_file(file_path, content)
            else:
                calls = _scan_javascript_file(file_path, content)

            all_calls.extend(calls)
        except (OSError, IOError):  # pragma: no cover
            pass

    # Pre-extract route metadata once to avoid per-call re-extraction.
    # Each entry is (route_path, route_method, route_symbol).
    route_info: list[tuple[str, str, Symbol]] = []
    for route in route_symbols:
        concept_path, concept_method = _get_route_info_from_concept(route)
        route_path = concept_path or ""
        route_method = concept_method or ""
        if route_path:
            route_info.append((route_path, route_method, route))

    # Group routes by HTTP method for faster filtering.
    # "ANY" or empty-method routes go into every method bucket.
    routes_by_method: dict[str, list[tuple[str, Symbol]]] = {}
    for route_path, route_method, route in route_info:
        method_key = route_method.upper() if route_method else ""
        if method_key and method_key != "ANY":
            routes_by_method.setdefault(method_key, []).append((route_path, route))
        else:
            # Wildcard route: add to a special "" bucket
            routes_by_method.setdefault("", []).append((route_path, route))

    # Create symbols for each client call
    for call in all_calls:
        client_symbol = _create_client_symbol(call, root)
        symbols.append(client_symbol)

        # Try to match to a route symbol
        call_path = _extract_path_from_url(call.url)
        if not call_path:  # pragma: no cover
            continue

        # Check method-specific routes first, then wildcard routes
        call_method_upper = call.method.upper()
        candidates = routes_by_method.get(call_method_upper, [])
        wildcard_candidates = routes_by_method.get("", [])

        matched_route: Symbol | None = None
        for route_path, route in candidates:
            if _match_route_pattern(call_path, route_path):
                matched_route = route
                break

        if matched_route is None:
            for route_path, route in wildcard_candidates:
                if _match_route_pattern(call_path, route_path):
                    matched_route = route
                    break

        # Prefix-match fallback for variable URLs (WI-sijoh). When a
        # template-literal fetch/axios call truncated at an unresolved
        # placeholder, the remaining literal prefix can still identify a
        # route family: any route whose path STARTS WITH the prefix is a
        # plausible target. First match wins — confidence is already
        # reduced to 0.65 for url_type='variable' below.
        #
        # Requires the prefix to contain at least one non-root `/` segment
        # (e.g., '/api/v1' qualifies; '/' or '/api' does not) so the
        # matching stays meaningful.
        if (
            matched_route is None
            and call.url_type == "variable"
            and _is_prefix_candidate(call_path)
        ):
            for route_path, route in candidates:
                if route_path.startswith(call_path):
                    matched_route = route
                    break
            if matched_route is None:
                for route_path, route in wildcard_candidates:
                    if route_path.startswith(call_path):
                        matched_route = route
                        break

        if matched_route is not None:
            is_cross_language = client_symbol.language != matched_route.language
            is_variable_url = call.url_type == "variable"

            # Lower confidence for variable URLs (can't verify at static analysis)
            if is_variable_url:
                base_confidence = 0.65
            elif is_cross_language:
                base_confidence = 0.8
            else:
                base_confidence = 0.9

            # ADR-0023 §6 Phase 3 (WI-vumum-juvil): HTTP is a wire
            # protocol, not a relationship. The fold target is
            # canonical 'calls' + meta['protocol']='http'.
            # ADR-0028 Phase 3 / audit-findings 0014: pattern-detection leak.
            # http_url_match is a pattern shape (URL string match), not a
            # framework — fold uses meta["detection_pattern"] not
            # meta["framework_dispatch"].
            edge = Edge.create(
                src=client_symbol.id,
                dst=matched_route.id,
                edge_type="calls",
                line=call.line,
                confidence=base_confidence,
                origin=PASS_ID,
                origin_run_id=run.execution_id,
                evidence_type="ast_call_direct",
            )
            edge.meta = {
                "protocol": "http",
                "http_method": call.method,
                "url_path": call_path,
                "cross_language": is_cross_language,
                "url_type": call.url_type,
                "detection_pattern": "http_url",
            }
            edges.append(edge)

    run.duration_ms = int((time.time() - start_time) * 1000)
    run.files_analyzed = files_scanned

    return HttpLinkResult(edges=edges, symbols=symbols, run=run)


# =============================================================================
# Linker Registry Integration
# =============================================================================


def _has_route_concept(symbol: Symbol) -> bool:
    """Check if symbol has a route concept in meta.concepts."""
    return has_concept(symbol, "route")


def _get_route_info_from_concept(symbol: Symbol) -> tuple[str | None, str | None]:
    """Extract route path and method from symbol metadata.

    Checks in order:
    1. Concept metadata (meta.concepts[].path/method) - from FRAMEWORK_PATTERNS enrichment
    2. Direct metadata (meta.route_path/http_method) - from analyzer-created route symbols

    Returns:
        Tuple of (route_path, http_method), or (None, None) if not found.
    """
    # First, try concept metadata (from FRAMEWORK_PATTERNS enrichment)
    route = get_concept(symbol, "route")
    if route is not None:
        return route.get("path"), route.get("method")

    if not symbol.meta:
        return None, None

    # Fallback: check direct metadata (from analyzer-created route symbols)
    # Route symbols from Ruby, PHP, Elixir, JS analyzers store info here
    route_path = symbol.meta.get("route_path")
    http_method = symbol.meta.get("http_method")
    if route_path or http_method:
        return route_path, http_method

    return None, None


def _get_route_symbols(ctx: LinkerContext) -> list[Symbol]:
    """Extract route symbols from context.

    Route symbols are either:
    - kind="route" (Ruby, Go, Rust, Express analyzers)
    - have route concept in meta.concepts (FRAMEWORK_PATTERNS enrichment)

    Note: We no longer check legacy meta.route_path field - route detection
    should come from concepts (single source of truth).
    """
    return [
        s for s in ctx.symbols
        if (s.meta or {}).get("framework_role") == "route"
        or _has_route_concept(s)
    ]


def _count_route_symbols(ctx: LinkerContext) -> int:
    """Count available route symbols for requirement check."""
    return len(_get_route_symbols(ctx))


HTTP_REQUIREMENTS = [
    LinkerRequirement(
        name="route_symbols",
        description="Route handler symbols (kind=route or route concept)",
        check=_count_route_symbols,
    ),
]


@register_linker(
    "http",
    priority=60,  # Run after analyzers have produced route symbols
    description="HTTP client-server linking (fetch, axios, requests to routes)",
    requirements=HTTP_REQUIREMENTS,
)
def http_linker(ctx: LinkerContext) -> LinkerResult:
    """HTTP linker for registry-based dispatch.

    This wraps link_http() to use the LinkerContext/LinkerResult interface.
    Extracts route symbols from ctx and delegates to the core linking logic.
    """
    route_symbols = _get_route_symbols(ctx)
    result = link_http(ctx.repo_root, route_symbols)

    return LinkerResult(
        symbols=result.symbols,
        edges=result.edges,
        run=result.run,
    )
