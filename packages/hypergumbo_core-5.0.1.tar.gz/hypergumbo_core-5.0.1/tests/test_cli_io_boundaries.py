# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tests for the hypergumbo io-boundaries command (ADR-0016).

Covers cmd_io_boundaries CLI command: detecting I/O boundary calls from
a behavior map and displaying the boundary map.  Includes tests for
enriched text output (call sites, entry points, high-risk markers,
per-primitive counts), --by-file grouping, and --boundary/--primitive
filtering.
"""
import json
from pathlib import Path

from hypergumbo_core.cli import cmd_io_boundaries
from hypergumbo_core.schema import SCHEMA_VERSION


class FakeArgs:
    """Minimal namespace for testing command functions."""

    pass


def _make_behavior_map(nodes, edges, entrypoints=None):
    """Create a minimal behavior map dict."""
    bmap = {
        "schema_version": SCHEMA_VERSION,
        "nodes": nodes,
        "edges": edges,
    }
    if entrypoints is not None:
        bmap["entrypoints"] = entrypoints
    return bmap


def _make_args(tmp_path, bmap, **overrides):
    """Write behavior map to file and return FakeArgs with defaults."""
    input_file = tmp_path / "hg.json"
    input_file.write_text(json.dumps(bmap))
    args = FakeArgs()
    args.path = str(tmp_path)
    args.input = str(input_file)
    args.json_output = False
    args.by_file = False
    args.boundary = None
    args.primitive = None
    for k, v in overrides.items():
        setattr(args, k, v)
    return args


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

_SINGLE_FS_READ = {
    "nodes": [
        {
            "id": "python:src/main.py:1-5:main:function",
            "name": "main",
            "kind": "function",
            "language": "python",
            "path": "src/main.py",
            "span": {"start_line": 1, "end_line": 5},
        },
    ],
    "edges": [
        {
            "src": "python:src/main.py:1-5:main:function",
            "dst": "python:stdlib/os.py:100-102:os.listdir:function",
            "type": "calls",
            "confidence": 0.9,
        },
    ],
}

_MULTI_BOUNDARY = {
    "nodes": [
        {
            "id": "python:src/app.py:1-20:app:function",
            "name": "app",
            "kind": "function",
            "language": "python",
            "path": "src/app.py",
            "span": {"start_line": 1, "end_line": 20},
        },
        {
            "id": "python:src/deploy.py:1-10:deploy:function",
            "name": "deploy",
            "kind": "function",
            "language": "python",
            "path": "src/deploy.py",
            "span": {"start_line": 1, "end_line": 10},
        },
    ],
    "edges": [
        {
            "src": "python:src/app.py:1-20:app:function",
            "dst": "python:stdlib/os.py:1:os.listdir:function",
            "type": "calls",
        },
        {
            "src": "python:src/app.py:5-20:app:function",
            "dst": "python:stdlib/sub.py:1:subprocess.run:function",
            "type": "calls",
        },
        {
            "src": "python:src/deploy.py:1-10:deploy:function",
            "dst": "python:stdlib/sub.py:1:subprocess.Popen:function",
            "type": "calls",
        },
        {
            "src": "python:src/deploy.py:8-10:deploy:function",
            "dst": "python:stdlib/shutil.py:1:shutil.rmtree:function",
            "type": "calls",
        },
        {
            "src": "python:src/app.py:10-20:app:function",
            "dst": "python:stdlib/socket.py:1:socket.socket.send:method",
            "type": "calls",
        },
    ],
}


# ---------------------------------------------------------------------------
# Original tests (updated with explicit args attributes)
# ---------------------------------------------------------------------------


def test_cmd_io_boundaries_detects_fs_read(tmp_path: Path, capsys) -> None:
    """Detects fs_read boundary calls in a behavior map."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap)

    rc = cmd_io_boundaries(args)
    assert rc == 0
    out = capsys.readouterr().out
    assert "fs_read" in out
    assert "os.listdir" in out


def test_cmd_io_boundaries_json_output(tmp_path: Path, capsys) -> None:
    """JSON output mode produces valid JSON with boundary data."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/app.py:1-5:app:function",
                "name": "app",
                "kind": "function",
                "language": "python",
                "path": "src/app.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "python:src/app.py:1-5:app:function",
                "dst": "python:stdlib/sub.py:1-2:subprocess.run:function",
                "type": "calls",
                "confidence": 0.9,
            },
        ],
    )
    args = _make_args(tmp_path, bmap, json_output=True)

    rc = cmd_io_boundaries(args)
    assert rc == 0
    out = capsys.readouterr().out
    data = json.loads(out)
    assert data["total_io_edges"] == 1
    assert "subprocess" in data["boundaries"]


def test_cmd_io_boundaries_chain_shows_dst_tier_for_external_boundary(
    tmp_path: Path, capsys,
) -> None:
    """PR2 of stop-stripping plan: each chain's JSON output carries
    dst_tier / dst_tier_name / dst_external_boundary, and the human
    text output annotates external-boundary destinations with
    [tier-N tier_name] so users can see at a glance whether a chain
    reaches into first-party I/O or a third-party wrapper.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/fetch.py:1-5:fetch:function",
                "name": "fetch", "kind": "function", "language": "python",
                "path": "src/fetch.py",
                "span": {"start_line": 1, "end_line": 5},
                "supply_chain": {"tier": 1, "tier_name": "first_party"},
            },
            # The boundary node serialized after PR1.
            {
                "id": "python:urllib.request:0-0:urlopen:unresolved",
                "name": "urlopen", "kind": "external_symbol",
                "language": "python", "path": "<external>",
                "span": {"start_line": 0, "end_line": 0,
                         "start_col": 0, "end_col": 0},
                "meta": {"external_boundary": True},
                "supply_chain": {"tier": 3, "tier_name": "external_dep",
                                 "reason": "unresolved external reference"},
            },
        ],
        edges=[
            {
                "src": "python:src/fetch.py:1-5:fetch:function",
                "dst": "python:urllib.request:0-0:urlopen:unresolved",
                "type": "calls", "confidence": 0.9,
            },
        ],
    )
    # JSON mode: assert structured tier fields.
    args = _make_args(tmp_path, bmap, json_output=True)
    rc = cmd_io_boundaries(args)
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    chains = data["boundaries"]["net_send"]["chains"]
    assert len(chains) == 1
    chain = chains[0]
    assert chain["dst_tier"] == 3
    assert chain["dst_tier_name"] == "external_dep"
    assert chain["dst_external_boundary"] is True

    # Text mode: assert the [tier-3 external_dep] annotation appears.
    args2 = _make_args(tmp_path, bmap)
    rc = cmd_io_boundaries(args2)
    assert rc == 0
    text = capsys.readouterr().out
    assert "[tier-3 external_dep]" in text


def test_cmd_io_boundaries_renders_external_potential_section(
    tmp_path: Path, capsys,
) -> None:
    """Plan C, PR C: edges into a tier-3 boundary node not in the catalog
    surface as ``external_potential`` chains, both in JSON output and in
    the text-mode boundary section.  The Python catalog (status=complete)
    means the annotation is the standard ``[tier-3 external_dep]``;
    chains for in_progress catalogs additionally render the
    ``[unreliable]`` marker so the user sees that absence-of-catalog-hit
    isn't authoritative for that language.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/load.py:1-5:load:function",
                "name": "load", "kind": "function", "language": "python",
                "path": "src/load.py",
                "span": {"start_line": 1, "end_line": 5},
                "supply_chain": {"tier": 1, "tier_name": "first_party"},
            },
            # Tier-3 boundary node for a wrapper not in the catalog
            # (huggingface_hub.snapshot_download was reverted in the
            # WI-jihuj revert; PR A enforces strict-stdlib).
            {
                "id": "python:huggingface_hub:0-0:snapshot_download:unresolved",
                "name": "snapshot_download", "kind": "external_symbol",
                "language": "python", "path": "<external>",
                "span": {"start_line": 0, "end_line": 0,
                         "start_col": 0, "end_col": 0},
                "meta": {"external_boundary": True},
                "supply_chain": {"tier": 3, "tier_name": "external_dep",
                                 "reason": "unresolved external reference"},
            },
        ],
        edges=[
            {
                "src": "python:src/load.py:1-5:load:function",
                "dst": "python:huggingface_hub:0-0:snapshot_download:unresolved",
                "type": "calls", "confidence": 0.9,
            },
        ],
    )
    # JSON mode: external_potential bucket present, chain carries the
    # tier fields and dst_classification_unreliable=False (Python is
    # status=complete).
    args = _make_args(tmp_path, bmap, json_output=True)
    rc = cmd_io_boundaries(args)
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert "external_potential" in data["boundaries"], (
        "external_potential bucket missing from JSON output"
    )
    chains = data["boundaries"]["external_potential"]["chains"]
    assert len(chains) == 1
    chain = chains[0]
    assert "snapshot_download" in chain["primitive"]
    assert chain["dst_tier"] == 3
    assert chain["dst_external_boundary"] is True
    assert chain["dst_classification_unreliable"] is False

    # Text mode: external_potential boundary type appears in the
    # by-type rendering, with the standard tier annotation.
    args2 = _make_args(tmp_path, bmap)
    rc = cmd_io_boundaries(args2)
    assert rc == 0
    text = capsys.readouterr().out
    assert "external_potential" in text
    assert "[tier-3 external_dep]" in text
    assert "huggingface_hub.snapshot_download" in text


def test_cmd_io_boundaries_external_potential_unreliable_annotation(
    tmp_path: Path, capsys,
) -> None:
    """Chains in external_potential whose source language has
    ``status: in_progress`` carry ``dst_classification_unreliable=True``
    in JSON and an ``[unreliable]`` marker in text output, signaling
    that absence-of-catalog-hit is not authoritative for that language.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "go:src/main.go:1-5:run:function",
                "name": "run", "kind": "function", "language": "go",
                "path": "src/main.go",
                "span": {"start_line": 1, "end_line": 5},
                "supply_chain": {"tier": 1, "tier_name": "first_party"},
            },
            {
                "id": "go:github.com/some/wrapper:0-0:Fetch:unresolved",
                "name": "Fetch", "kind": "external_symbol",
                "language": "go", "path": "<external>",
                "span": {"start_line": 0, "end_line": 0,
                         "start_col": 0, "end_col": 0},
                "meta": {"external_boundary": True},
                "supply_chain": {"tier": 3, "tier_name": "external_dep"},
            },
        ],
        edges=[
            {
                "src": "go:src/main.go:1-5:run:function",
                "dst": "go:github.com/some/wrapper:0-0:Fetch:unresolved",
                "type": "calls", "confidence": 0.9,
            },
        ],
    )
    # JSON: dst_classification_unreliable=True for in_progress lang.
    args = _make_args(tmp_path, bmap, json_output=True)
    rc = cmd_io_boundaries(args)
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    chain = data["boundaries"]["external_potential"]["chains"][0]
    assert chain["dst_classification_unreliable"] is True

    # Text: the [unreliable] marker is present.
    args2 = _make_args(tmp_path, bmap)
    rc = cmd_io_boundaries(args2)
    assert rc == 0
    text = capsys.readouterr().out
    assert "[unreliable]" in text


def test_cmd_io_boundaries_no_io_calls(tmp_path: Path, capsys) -> None:
    """When no I/O calls found, reports accordingly."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/math.py:1-5:calc:function",
                "name": "calc",
                "kind": "function",
                "language": "python",
                "path": "src/math.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "python:src/math.py:1-5:calc:function",
                "dst": "python:stdlib/math.py:1-2:math.sqrt:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)

    rc = cmd_io_boundaries(args)
    assert rc == 0
    out = capsys.readouterr().out
    assert "No I/O boundary calls detected" in out


def test_cmd_io_boundaries_missing_input(tmp_path: Path) -> None:
    """Returns error when input file doesn't exist."""
    args = FakeArgs()
    args.path = str(tmp_path)
    args.input = str(tmp_path / "nonexistent.json")
    args.json_output = False
    args.by_file = False
    args.boundary = None
    args.primitive = None

    rc = cmd_io_boundaries(args)
    assert rc == 1


def test_cmd_io_boundaries_multiple_boundaries(tmp_path: Path, capsys) -> None:
    """Detects multiple boundary types in one behavior map."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, json_output=True)

    rc = cmd_io_boundaries(args)
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["total_io_edges"] == 5
    assert "fs_read" in data["boundaries"]
    assert "subprocess" in data["boundaries"]
    assert "net_send" in data["boundaries"]


# ---------------------------------------------------------------------------
# New tests: caller info / call sites
# ---------------------------------------------------------------------------


def test_shows_caller_info(tmp_path: Path, capsys) -> None:
    """Text output includes the caller function name and file path."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    # Should show caller name + location
    assert "main" in out
    assert "<-" in out  # call-site indicator


def test_shows_caller_info_fallback(tmp_path: Path, capsys) -> None:
    """When node not in index, falls back to parsing symbol ID."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/mystery.py:1-5:mystery:function",
                "name": "mystery",
                "kind": "function",
                "language": "python",
                "path": "src/mystery.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                # src does NOT match any node id
                "src": "python:src/unknown.py:10-12:helper:function",
                "dst": "python:stdlib/os.py:100-102:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "helper" in out
    assert "<-" in out


# ---------------------------------------------------------------------------
# New tests: entry points displayed
# ---------------------------------------------------------------------------


def test_shows_entry_points(tmp_path: Path, capsys) -> None:
    """Text output includes entry point info when entrypoints are present."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/main.py:1-5:main:function",
                "name": "main",
                "kind": "function",
                "language": "python",
                "path": "src/main.py",
                "span": {"start_line": 1, "end_line": 5},
            },
            {
                "id": "python:src/helper.py:1-5:helper:function",
                "name": "helper",
                "kind": "function",
                "language": "python",
                "path": "src/helper.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "python:src/main.py:1-5:main:function",
                "dst": "python:src/helper.py:1-5:helper:function",
                "type": "calls",
            },
            {
                "src": "python:src/helper.py:1-5:helper:function",
                "dst": "python:stdlib/os.py:100-102:os.listdir:function",
                "type": "calls",
            },
        ],
        entrypoints=[
            {"symbol_id": "python:src/main.py:1-5:main:function"},
        ],
    )
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "reachable from" in out
    assert "main" in out
    assert "entry point" in out


# ---------------------------------------------------------------------------
# New tests: per-primitive counts
# ---------------------------------------------------------------------------


def test_primitive_counts(tmp_path: Path, capsys) -> None:
    """Text output shows per-primitive call counts."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/a.py:1-5:read_dir:function",
                "name": "read_dir",
                "kind": "function",
                "language": "python",
                "path": "src/a.py",
                "span": {"start_line": 1, "end_line": 5},
            },
            {
                "id": "python:src/b.py:1-5:scan:function",
                "name": "scan",
                "kind": "function",
                "language": "python",
                "path": "src/b.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "python:src/a.py:1-5:read_dir:function",
                "dst": "python:stdlib/os.py:1:os.listdir:function",
                "type": "calls",
            },
            {
                "src": "python:src/b.py:1-5:scan:function",
                "dst": "python:stdlib/os.py:1:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "os.listdir (2)" in out


# ---------------------------------------------------------------------------
# New tests: high-risk highlighting
# ---------------------------------------------------------------------------


def test_high_risk_marker_in_text(tmp_path: Path, capsys) -> None:
    """High-risk primitives are highlighted in text output."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "HIGH RISK" in out
    assert "subprocess.Popen" in out
    assert "shutil.rmtree" in out


def test_no_high_risk_marker_for_safe_primitives(tmp_path: Path, capsys) -> None:
    """Safe primitives do not get HIGH RISK markers."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "HIGH RISK" not in out


# ---------------------------------------------------------------------------
# New tests: --boundary filter
# ---------------------------------------------------------------------------


def test_filter_boundary(tmp_path: Path, capsys) -> None:
    """--boundary filters to a specific boundary type."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, boundary="fs_read")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "fs_read" in out
    assert "subprocess" not in out
    assert "net_send" not in out


def test_filter_boundary_no_match(tmp_path: Path, capsys) -> None:
    """--boundary with non-matching type shows no results."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap, boundary="net_recv")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "No I/O boundary calls detected" in out


def test_filter_boundary_json(tmp_path: Path, capsys) -> None:
    """--boundary filter works with --json output."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, json_output=True, boundary="subprocess")

    cmd_io_boundaries(args)
    data = json.loads(capsys.readouterr().out)
    assert set(data["boundaries"].keys()) == {"subprocess"}
    # Filtered total reflects only subprocess chains
    assert data["total_io_edges"] == 2


# ---------------------------------------------------------------------------
# New tests: --primitive filter
# ---------------------------------------------------------------------------


def test_filter_primitive(tmp_path: Path, capsys) -> None:
    """--primitive filters to a specific primitive."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, primitive="subprocess.run")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "subprocess.run" in out
    assert "subprocess.Popen" not in out
    assert "os.listdir" not in out


def test_filter_primitive_no_match(tmp_path: Path, capsys) -> None:
    """--primitive with non-matching name shows no results."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap, primitive="nonexistent.func")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "No I/O boundary calls detected" in out


def test_filter_primitive_json(tmp_path: Path, capsys) -> None:
    """--primitive filter works with --json output."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, json_output=True, primitive="shutil.rmtree")

    cmd_io_boundaries(args)
    data = json.loads(capsys.readouterr().out)
    assert data["total_io_edges"] == 1
    # shutil.rmtree is fs_write
    assert "fs_write" in data["boundaries"]
    assert data["boundaries"]["fs_write"]["primitive_counts"] == {"shutil.rmtree": 1}


# ---------------------------------------------------------------------------
# New tests: --by-file view
# ---------------------------------------------------------------------------


def test_by_file_view(tmp_path: Path, capsys) -> None:
    """--by-file groups output by source file."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, by_file=True)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "by File" in out
    assert "src/app.py" in out
    assert "src/deploy.py" in out
    # Should show boundary type labels in brackets
    assert "[fs_read]" in out or "[subprocess]" in out


def test_by_file_with_filter(tmp_path: Path, capsys) -> None:
    """--by-file and --boundary work together."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, by_file=True, boundary="subprocess")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "by File" in out
    assert "[subprocess]" in out
    assert "[fs_read]" not in out


def test_by_file_no_results(tmp_path: Path, capsys) -> None:
    """--by-file with filter yielding no results shows empty message."""
    bmap = _make_behavior_map(**_SINGLE_FS_READ)
    args = _make_args(tmp_path, bmap, by_file=True, boundary="net_recv")

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "No I/O boundary calls detected" in out


def test_by_file_high_risk(tmp_path: Path, capsys) -> None:
    """--by-file view shows HIGH RISK markers per file."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, by_file=True)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "HIGH RISK" in out


# ---------------------------------------------------------------------------
# New tests: enriched JSON output
# ---------------------------------------------------------------------------


def test_json_output_enriched(tmp_path: Path, capsys) -> None:
    """JSON output includes chains, primitive_counts, and has_high_risk."""
    bmap = _make_behavior_map(**_MULTI_BOUNDARY)
    args = _make_args(tmp_path, bmap, json_output=True)

    cmd_io_boundaries(args)
    data = json.loads(capsys.readouterr().out)

    sub_boundary = data["boundaries"]["subprocess"]
    assert "primitive_counts" in sub_boundary
    assert "chains" in sub_boundary
    assert "has_high_risk" in sub_boundary
    assert sub_boundary["has_high_risk"] is True
    assert sub_boundary["primitive_counts"]["subprocess.run"] == 1
    assert sub_boundary["primitive_counts"]["subprocess.Popen"] == 1

    fs_boundary = data["boundaries"]["fs_read"]
    assert fs_boundary["has_high_risk"] is False


def test_caller_format_node_no_line(tmp_path: Path, capsys) -> None:
    """Caller display works when node span has no start_line."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/mod.py:1-5:mod:module",
                "name": "mod",
                "kind": "module",
                "language": "python",
                "path": "src/mod.py",
                "span": {},  # no start_line
            },
        ],
        edges=[
            {
                "src": "python:src/mod.py:1-5:mod:module",
                "dst": "python:stdlib/os.py:1-2:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)
    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "mod" in out
    assert "src/mod.py" in out


def test_caller_format_node_no_path(tmp_path: Path, capsys) -> None:
    """Caller display works when node has no path."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:virtual:1-5:ghost:function",
                "name": "ghost",
                "kind": "function",
                "language": "python",
                "path": "",
                "span": {"start_line": 1},
            },
        ],
        edges=[
            {
                "src": "python:virtual:1-5:ghost:function",
                "dst": "python:stdlib/os.py:1-2:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)
    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "ghost" in out


def test_caller_fallback_no_path(tmp_path: Path, capsys) -> None:
    """Fallback caller format works when symbol ID has no file path."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/x.py:1-5:x:function",
                "name": "x",
                "kind": "function",
                "language": "python",
                "path": "src/x.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                # src is a short symbol ID (no file path) not matching any node
                "src": "py:short",
                "dst": "python:stdlib/os.py:1-2:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)
    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    # Should fall through to returning the raw symbol_id
    assert "py:short" in out


def test_caller_fallback_no_file_path(tmp_path: Path, capsys) -> None:
    """Fallback: 5-part symbol ID where path extraction returns empty."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/x.py:1-5:x:function",
                "name": "x",
                "kind": "function",
                "language": "python",
                "path": "src/x.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                # 5 colon-separated parts, but no :\d+-\d+: pattern so path
                # extraction returns "" — exercises the `return name` fallback
                "src": "python:modname:nospan:helper:function",
                "dst": "python:stdlib/os.py:1-2:os.listdir:function",
                "type": "calls",
            },
        ],
    )
    args = _make_args(tmp_path, bmap)
    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "helper" in out


def test_relativize_no_repo_root(tmp_path: Path, capsys) -> None:
    """_relativize returns path unchanged when repo_root is None."""
    from hypergumbo_core.cli import _relativize
    assert _relativize("/some/path", None) == "/some/path"
    assert _relativize("", None) == ""


def test_by_file_entry_points(tmp_path: Path, capsys) -> None:
    """--by-file view shows entry point traces."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/main.py:1-5:main:function",
                "name": "main",
                "kind": "function",
                "language": "python",
                "path": "src/main.py",
                "span": {"start_line": 1, "end_line": 5},
            },
            {
                "id": "python:src/helper.py:1-5:helper:function",
                "name": "helper",
                "kind": "function",
                "language": "python",
                "path": "src/helper.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "python:src/main.py:1-5:main:function",
                "dst": "python:src/helper.py:1-5:helper:function",
                "type": "calls",
            },
            {
                "src": "python:src/helper.py:1-5:helper:function",
                "dst": "python:stdlib/os.py:100-102:os.listdir:function",
                "type": "calls",
            },
        ],
        entrypoints=[
            {"symbol_id": "python:src/main.py:1-5:main:function"},
        ],
    )
    args = _make_args(tmp_path, bmap, by_file=True)

    cmd_io_boundaries(args)
    out = capsys.readouterr().out
    assert "reachable from" in out
    assert "main" in out


def test_objc_io_boundaries_detected(tmp_path: Path, capsys) -> None:
    """ObjC I/O boundaries are detected despite 'objective-c' vs 'objc' mismatch.

    Nodes report language='objective-c' but symbol IDs use 'objc:' prefix.
    The catalog loading must bridge this mismatch so tag_io_boundaries can
    match ObjC I/O primitives.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "objc:src/Manager.m:1-5:Manager.cleanup:method",
                "name": "Manager.cleanup",
                "kind": "method",
                "language": "objective-c",
                "path": "src/Manager.m",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[
            {
                "src": "objc:src/Manager.m:1-5:Manager.cleanup:method",
                "dst": "objc:external:0-0:removeItemAtPath:error::unresolved",
                "type": "calls",
                "confidence": 0.5,
            },
        ],
    )
    args = _make_args(tmp_path, bmap, json_output=True)

    rc = cmd_io_boundaries(args)
    assert rc == 0
    data = json.loads(capsys.readouterr().out)
    assert data["total_io_edges"] >= 1, (
        f"Expected >=1 ObjC IO edges, got {data['total_io_edges']}. "
        f"Boundaries: {list(data.get('boundaries', {}).keys())}"
    )
    assert "fs_write" in data["boundaries"]


class TestIoBoundariesExcludeTests:
    """Tests for --exclude-tests flag on io-boundaries command."""

    def test_exclude_tests_filters_test_chains(self, tmp_path, capsys):
        """Chains from test files are excluded when --exclude-tests is set."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:src/main.py:1-5:main:function",
                    "name": "main",
                    "kind": "function",
                    "language": "python",
                    "path": "src/main.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
                {
                    "id": "python:tests/test_main.py:1-5:test_func:function",
                    "name": "test_func",
                    "kind": "function",
                    "language": "python",
                    "path": "tests/test_main.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
                {
                    "id": "python:os:0-0:remove:unresolved",
                    "name": "remove",
                    "kind": "unresolved",
                    "language": "python",
                    "path": "",
                    "span": {"start_line": 0, "end_line": 0},
                },
            ],
            edges=[
                {
                    "src": "python:src/main.py:1-5:main:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
                {
                    "src": "python:tests/test_main.py:1-5:test_func:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
            ],
        )

        # Without --exclude-tests: both chains present
        args = _make_args(tmp_path, bmap, json_output=True, exclude_tests=False)
        rc = cmd_io_boundaries(args)
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["total_io_edges"] == 2

        # With --exclude-tests: only prod chain
        args = _make_args(tmp_path, bmap, json_output=True, exclude_tests=True)
        rc = cmd_io_boundaries(args)
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["total_io_edges"] == 1
        chains = data["boundaries"]["fs_write"]["chains"]
        assert len(chains) == 1
        assert "test" not in chains[0]["io_edge_src"]

    def test_exclude_tests_removes_empty_boundary_types(self, tmp_path, capsys):
        """Boundary types with only test chains are removed entirely."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:tests/test_io.py:1-5:test_write:function",
                    "name": "test_write",
                    "kind": "function",
                    "language": "python",
                    "path": "tests/test_io.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
                {
                    "id": "python:os:0-0:remove:unresolved",
                    "name": "remove",
                    "kind": "unresolved",
                    "language": "python",
                    "path": "",
                    "span": {"start_line": 0, "end_line": 0},
                },
            ],
            edges=[
                {
                    "src": "python:tests/test_io.py:1-5:test_write:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
            ],
        )

        args = _make_args(tmp_path, bmap, json_output=True, exclude_tests=True)
        rc = cmd_io_boundaries(args)
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["total_io_edges"] == 0
        assert len(data["boundaries"]) == 0

    def test_exclude_tests_keeps_unknown_source_chains(self, tmp_path, capsys):
        """Chains with source nodes not in the behavior map are kept (not test)."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:os:0-0:remove:unresolved",
                    "name": "remove",
                    "kind": "unresolved",
                    "language": "python",
                    "path": "",
                    "span": {"start_line": 0, "end_line": 0},
                },
            ],
            edges=[
                {
                    "src": "python:unknown/caller.py:1-5:mystery:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
            ],
        )

        args = _make_args(tmp_path, bmap, json_output=True, exclude_tests=True)
        rc = cmd_io_boundaries(args)
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        # Chain kept because source node unknown (can't determine if test)
        assert data["total_io_edges"] == 1

    def test_test_chains_excluded_by_default(self, tmp_path, capsys):
        """WI-sifif: production-only is the default for io-boundaries.

        When ``args.exclude_tests`` is not set at all (i.e., the user did
        not pass ``--exclude-tests`` or ``--include-tests``), the command
        must default to excluding test-file chains. Without this fix, the
        bakeoff's ``io-boundaries.txt`` was 78% noise on alertmanager
        (env_read: 9 chains, 7 in test files).
        """
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:src/main.py:1-5:main:function",
                    "name": "main",
                    "kind": "function",
                    "language": "python",
                    "path": "src/main.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
                {
                    "id": "python:tests/test_main.py:1-5:test_func:function",
                    "name": "test_func",
                    "kind": "function",
                    "language": "python",
                    "path": "tests/test_main.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
                {
                    "id": "python:os:0-0:remove:unresolved",
                    "name": "remove",
                    "kind": "unresolved",
                    "language": "python",
                    "path": "",
                    "span": {"start_line": 0, "end_line": 0},
                },
            ],
            edges=[
                {
                    "src": "python:src/main.py:1-5:main:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
                {
                    "src": "python:tests/test_main.py:1-5:test_func:function",
                    "dst": "python:os:0-0:remove:unresolved",
                    "type": "calls",
                    "meta": {"callee": "os.remove"},
                },
            ],
        )

        # No exclude_tests override at all — the command must default to
        # production-only. Note _make_args does not set this attribute, so
        # cmd_io_boundaries must use a True fallback.
        args = _make_args(tmp_path, bmap, json_output=True)
        assert not hasattr(args, "exclude_tests"), (
            "Test fixture invariant: exclude_tests must be unset so the "
            "default fallback in cmd_io_boundaries is exercised."
        )
        rc = cmd_io_boundaries(args)
        assert rc == 0
        data = json.loads(capsys.readouterr().out)
        assert data["total_io_edges"] == 1, (
            f"Default behavior must be production-only — got "
            f"{data['total_io_edges']} chains, expected 1 (the test_func "
            f"chain should be filtered out)."
        )
        chains = data["boundaries"]["fs_write"]["chains"]
        assert "test" not in chains[0]["io_edge_src"]


# ============================================================================
# INV-javam: distinguish "no I/O detected" from "language unsupported"
# ============================================================================


def test_cmd_io_boundaries_emits_notice_for_unsupported_language(
    tmp_path: Path, capsys,
) -> None:
    """INV-javam: when the behavior map contains nodes in a language with
    no IO primitive catalog, io-boundaries prints an explicit unsupported-
    language notice to stderr. Without this, zero boundaries is
    indistinguishable from a truly I/O-free codebase.
    """
    # A node in a language ("brainfuck") hypergumbo has no catalog for.
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "brainfuck:main.bf:1-3:main:function",
                "name": "main",
                "kind": "function",
                "language": "brainfuck",
                "path": "main.bf",
                "span": {"start_line": 1, "end_line": 3},
            },
        ],
        edges=[],
    )
    args = _make_args(tmp_path, bmap)
    rc = cmd_io_boundaries(args)
    assert rc == 0

    _, err = capsys.readouterr()
    assert "brainfuck" in err
    assert "no I/O primitive catalog" in err
    assert "does NOT mean" in err  # the key "don't misread zero" framing
    assert "INV-javam" in err


def test_cmd_io_boundaries_json_output_exposes_unsupported_languages(
    tmp_path: Path, capsys,
) -> None:
    """INV-javam: JSON consumers get an `unsupported_languages` field so
    programmatic pipelines (e.g., taint-flow) can refuse to assert
    success when the language isn't actually supported.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "brainfuck:main.bf:1-3:main:function",
                "name": "main",
                "kind": "function",
                "language": "brainfuck",
                "path": "main.bf",
                "span": {"start_line": 1, "end_line": 3},
            },
            {
                "id": "nim:src/thing.nim:1-5:main:function",
                "name": "main",
                "kind": "function",
                "language": "nim",
                "path": "src/thing.nim",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[],
    )
    args = _make_args(tmp_path, bmap, json_output=True)
    rc = cmd_io_boundaries(args)
    assert rc == 0

    data = json.loads(capsys.readouterr().out)
    assert "unsupported_languages" in data
    # Both languages have no catalog; list is sorted alphabetically
    assert data["unsupported_languages"] == ["brainfuck", "nim"]


def test_cmd_io_boundaries_no_notice_when_all_languages_supported(
    tmp_path: Path, capsys,
) -> None:
    """INV-javam: the notice must NOT fire when every detected language
    has a catalog. Anti-regression — we don't want to spam users on
    fully-supported codebases.
    """
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/api.py:1-5:main:function",
                "name": "main",
                "kind": "function",
                "language": "python",
                "path": "src/api.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[],
    )
    args = _make_args(tmp_path, bmap)
    rc = cmd_io_boundaries(args)
    assert rc == 0

    _, err = capsys.readouterr()
    assert "no I/O primitive catalog" not in err
    assert "INV-javam" not in err


def test_cmd_io_boundaries_json_output_empty_unsupported_when_all_supported(
    tmp_path: Path, capsys,
) -> None:
    """INV-javam: programmatic consumers always get the field, even when
    empty — keeps the JSON schema stable."""
    bmap = _make_behavior_map(
        nodes=[
            {
                "id": "python:src/api.py:1-5:main:function",
                "name": "main",
                "kind": "function",
                "language": "python",
                "path": "src/api.py",
                "span": {"start_line": 1, "end_line": 5},
            },
        ],
        edges=[],
    )
    args = _make_args(tmp_path, bmap, json_output=True)
    rc = cmd_io_boundaries(args)
    assert rc == 0

    data = json.loads(capsys.readouterr().out)
    assert data["unsupported_languages"] == []


# ---------------------------------------------------------------------------
# WI-rubir: leaf-caller rollups must survive the CLI filter pass
# ---------------------------------------------------------------------------


class TestLeafCallersSurviveFilterPass:
    """The WI-darad rollups (leaf_callers, entry_points_per_leaf) are
    computed inside compute_boundary_map but cmd_io_boundaries runs a
    filter pass (default exclude_tests=True) that previously dropped
    them by reconstructing BoundaryMapEntry without those fields.
    Bakeoff cohort-001/iter-010 caught this as a regression: every
    boundary had chain_count>0 but leaf_callers=[].
    """

    def test_leaf_callers_present_with_default_exclude_tests(
        self, tmp_path: Path, capsys,
    ) -> None:
        """Default args (exclude_tests=True) must preserve leaf_callers."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:src/app.py:1-5:app:function",
                    "name": "app",
                    "kind": "function",
                    "language": "python",
                    "path": "src/app.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
            ],
            edges=[
                {
                    "src": "python:src/app.py:1-5:app:function",
                    "dst": "python:stdlib/os.py:1:os.listdir:function",
                    "type": "calls",
                },
            ],
        )
        args = _make_args(tmp_path, bmap, json_output=True)
        rc = cmd_io_boundaries(args)
        assert rc == 0

        data = json.loads(capsys.readouterr().out)
        fs_read = data["boundaries"]["fs_read"]
        assert fs_read["chain_count"] == 1
        assert fs_read["leaf_callers"] == [
            "python:src/app.py:1-5:app:function"
        ], (
            "leaf_callers must include the io_edge_src when the src has no "
            "callers (leaf is the src itself per WI-darad)"
        )

    def test_entry_points_per_leaf_present_with_default_exclude_tests(
        self, tmp_path: Path, capsys,
    ) -> None:
        """Default args must also preserve entry_points_per_leaf."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:src/app.py:1-5:main:function",
                    "name": "main",
                    "kind": "function",
                    "language": "python",
                    "path": "src/app.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
            ],
            edges=[
                {
                    "src": "python:src/app.py:1-5:main:function",
                    "dst": "python:stdlib/os.py:1:os.listdir:function",
                    "type": "calls",
                },
            ],
            entrypoints=[
                {"symbol_id": "python:src/app.py:1-5:main:function"},
            ],
        )
        args = _make_args(tmp_path, bmap, json_output=True)
        rc = cmd_io_boundaries(args)
        assert rc == 0

        data = json.loads(capsys.readouterr().out)
        fs_read = data["boundaries"]["fs_read"]
        leaf = "python:src/app.py:1-5:main:function"
        assert fs_read["entry_points_per_leaf"] == {leaf: [leaf]}

    def test_leaf_callers_present_with_primitive_filter(
        self, tmp_path: Path, capsys,
    ) -> None:
        """The other filter trigger (primitive_filter) must also keep
        leaf_callers."""
        bmap = _make_behavior_map(
            nodes=[
                {
                    "id": "python:src/app.py:1-5:app:function",
                    "name": "app",
                    "kind": "function",
                    "language": "python",
                    "path": "src/app.py",
                    "span": {"start_line": 1, "end_line": 5},
                },
            ],
            edges=[
                {
                    "src": "python:src/app.py:1-5:app:function",
                    "dst": "python:stdlib/os.py:1:os.listdir:function",
                    "type": "calls",
                },
            ],
        )
        args = _make_args(
            tmp_path, bmap, json_output=True, primitive="os.listdir",
        )
        rc = cmd_io_boundaries(args)
        assert rc == 0

        data = json.loads(capsys.readouterr().out)
        fs_read = data["boundaries"]["fs_read"]
        assert fs_read["leaf_callers"] == [
            "python:src/app.py:1-5:app:function"
        ]
