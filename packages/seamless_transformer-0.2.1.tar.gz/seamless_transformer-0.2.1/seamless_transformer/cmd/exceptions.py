class SeamlessSystemExit(Exception):
    pass