"""Main command-line seamless-run executable script"""

__version__ = "1.00"

import argparse
from copy import copy
import sys
import os
import json
import re
import traceback
import threading
import logging
import functools
import time
import pathlib
import warnings

import seamless
import seamless.config

from seamless import Checksum, Buffer
from seamless.caching.buffer_cache import get_buffer_cache
from seamless.util import unchecksum
from seamless_transformer.cmd.message import (
    set_verbosity,
    message as msg,
    message_and_exit as err,
)
from seamless_transformer.cmd import parsing
from seamless_transformer.cmd.parsing import get_commands, guess_arguments
from seamless_transformer.cmd.file_mapping import get_file_mapping
from seamless_transformer.cmd.file_load import files_to_checksums
from seamless_transformer.cmd.bash_transformation import (
    prepare_bash_transformation,
    run_transformation,
)
from seamless_transformer.cmd import interface
from seamless_transformer.cmd.exceptions import SeamlessSystemExit
from seamless_transformer.cmd.bytes2human import human2bytes
from seamless_transformer.cmd.get_results import (
    get_results,
    get_result_buffer,
    maintain_futures,
)
from seamless_transformer.remote_job import REMOTE_JOB_META_KEY, RemoteJobWritten

### from seamless.Environment import Environment
from seamless.checksum.json_ import json_dumps_bytes
from seamless_transformer.transformation_cache import run_sync
from seamless_transformer.transformation_utils import (
    extract_job_dunder,
    extract_tf_dunder,
    tf_get_buffer,
)

try:
    from seamless_config import get_seamless_cache
except Exception:  # pragma: no cover - optional dependency
    get_seamless_cache = lambda: None

try:
    from seamless_config.select import select_project, select_subproject
except Exception:  # pragma: no cover - optional dependency
    select_project = None
    select_subproject = None


CONFIG_FILENAMES = ("seamless.yaml", "seamless.profile.yaml")


def _parse_scoped_value(value: str, label: str) -> tuple[str, str | None]:
    if not value:
        err(f"--{label} requires a value")
    if ":" in value:
        head, tail = value.split(":", 1)
        if not head:
            err(f"Invalid --{label} value '{value}'")
        if tail == "":
            tail = None
        return head, tail
    return value, None


def _load_input_file(path: str) -> list[str]:
    if not os.path.isfile(path):
        err(f"--input-file '{path}' is not a file")

    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except OSError as exc:
        err(f"--input-file '{path}' could not be read: {exc}")

    result = []
    pathdir = os.path.dirname(path)
    for line in lines:
        line = line.strip()
        if line.startswith("/"):
            result.append(line)
        else:
            result.append(os.path.normpath(os.path.join(pathdir, line)))
    return result


def _parse_var_spec(spec: str) -> tuple[str, str]:
    if "=" not in spec:
        err(f"Invalid --var '{spec}': expected NAME=VALUE")
    name, value = spec.split("=", 1)
    if not name:
        err(f"Invalid --var '{spec}': variable name is empty")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        err(
            f"Invalid --var '{spec}': variable name '{name}' "
            "must match [A-Za-z_][A-Za-z0-9_]*"
        )
    return name, value


def _parse_metavar_spec(spec: str) -> tuple[str, str]:
    name, value = _parse_var_spec(spec)
    if name.upper().startswith("META__"):
        err(f"Invalid --metavar '{spec}': name must not start with META__")
    return name, value


def _require_config_file(workdir: str) -> None:
    config_dir = pathlib.Path(workdir).resolve()
    for filename in CONFIG_FILENAMES:
        if (config_dir / filename).is_file():
            return
    filenames = " or ".join(CONFIG_FILENAMES)
    raise ValueError(
        f"No {filenames} found in '{config_dir}' "
        "(set SEAMLESS_CACHE=/path/to/cache for quick-and-dirty persistent caching)"
    )


def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-v",
        dest="verbosity",
        help="""Verbose mode.
    Multiple -v options increase the verbosity. The maximum is 3""",
        action="count",
        default=0,
    )
    parser.add_argument(
        "-q", dest="verbosity", help="Quiet mode", action="store_const", const=-1
    )

    parser.add_argument(
        "--project",
        metavar="PROJECT[:SUBPROJECT]",
        help="set Seamless project (and subproject). Each project has independent storage",
    )

    parser.add_argument(
        "--stage",
        metavar="STAGE[:SUBSTAGE]",
        help="set Seamless project stage (and substage). Each project stage has independent storage",
    )

    parser.add_argument(
        "-g1",
        help="""Disable argtyping guess rule 1.
    This rule states that any argument with a file extension must exist as a file.""",
        action="store_true",
    )

    parser.add_argument(
        "-g2",
        help="""Disable argtyping guess rule 2.
    This rule states that any argument without file extension must not exist as a file.""",
        action="store_true",
    )

    parser.add_argument(
        "-w",
        help="""Set the argtyping working directory to DIR.
    This allows any file in DIR to be specified as argument.""",
        dest="workdir",
    )

    parser.add_argument(
        "-W",
        help="""Set the argtyping working directory to /.
    This allows any file to be specified as argument.""",
        dest="workdir",
        action="store_const",
        const="/",
    )

    parser.add_argument(
        "-ms",
        help="""Set the argtyping file mapping mode to 'strip'.
    Strip directory names. After stripping, all files must be unique.""",
        dest="file_mapping_mode",
        action="store_const",
        const="strip",
    )

    parser.add_argument(
        "-mx",
        help="""Set the argtyping file mapping mode to 'extension'.
    Keep only file extensions. Rename the file name body to file1, file2, ...
    Example: 
    python script.py data.txt 
    => 
    python file1.py file2.txt

    Directories remain unchanged.""",
        dest="file_mapping_mode",
        action="store_const",
        const="extension",
    )

    parser.add_argument(
        "-c", help="Unquote the command line", dest="unquote", action="store_true"
    )

    parser.add_argument(
        "-cp",
        "--capture",
        help="""Add a file or directory to the result capture.

    After the command line has completed, this file (or directory) will checksummed,
    added to the result, and (potentially) downloaded.
    You can use ":" if the file is named differently on the server 
    than the download target file. For example, "-cp foo:bar" will download
    the result file "foo" on the server to the local file "bar".
    An empty server file name captures stdout, e.g. "-cp :bar"
    """,
        action="append",
        dest="extra_results",
    )

    parser.add_argument(
        "-i",
        "--input",
        help="""Add a file or directory as an input.

    Normally, only the first command gets analyzed for input files and directories.
    With this option, you can add an input manually.
    """,
        action="append",
        dest="extra_inputs",
    )
    parser.add_argument(
        "-I",
        "--input-file",
        help="""Add file paths listed one per line from FILE as inputs.

    Lines may be empty; empty lines are ignored.
    """,
        dest="input_files",
    )
    parser.add_argument(
        "--var",
        action="append",
        dest="explicit_vars",
        help="""Inject a variable input NAME=VALUE (repeatable).

    The injected variable is part of the transformation identity and is
    available to the bash command environment.
    """,
    )
    parser.add_argument(
        "--metavar",
        action="append",
        dest="explicit_metavars",
        help=(
            "Inject a meta variable NAME=VALUE (repeatable). "
            "The variable is available to the bash command as $NAME but does NOT "
            "contribute to the transformation identity. Two invocations that differ "
            "only in --metavar values share the same cache entry. "
            "Use for execution hints (thread counts, verbosity, debug flags) that "
            "should not invalidate the cache. Use --var for values that are part of "
            "the computation and should invalidate the cache when changed."
        ),
    )

    parser.add_argument(
        "--prologue",
        action="append",
        dest="prologues",
        help="Prepend CMD literally to the bash command (repeatable).",
    )

    parser.add_argument(
        "--primary",
        type=int,
        default=1,
        help="Treat the N-th command (1-indexed) as the primary command for argtype analysis.",
    )

    parser.add_argument(
        "-y",
        "--yes",
        dest="auto_confirm",
        help="""Sets any confirmation values to 'yes' automatically. Users will not be asked to confirm any file upload or download.
    Uploads will happen without confirmation for up to 400 files and up to 100 MB in total.
    Downloads will happen without confirmation for up to 2000 files and up to 500 MB in total.
    These thresholds can be controlled by the environment variables:
    SEAMLESS_MAX_UPLOAD_FILES, SEAMLESS_MAX_UPLOAD_SIZE, SEAMLESS_MAX_DOWNLOAD_FILES, SEAMLESS_MAX_DOWNLOAD_SIZE.""",
        action="store_const",
        const="yes",
    )

    parser.add_argument(
        "-n",
        "--no",
        dest="auto_confirm",
        help="""Sets any confirmation values to 'no' automatically. Users will not be asked to confirm any file upload or download.
    Uploads will happen without confirmation for up to 400 files and up to 100 MB in total.
    Downloads will happen without confirmation for up to 2000 files and up to 500 MB in total.
    These thresholds can be controlled by the environment variables:
    SEAMLESS_MAX_UPLOAD_FILES, SEAMLESS_MAX_UPLOAD_SIZE, SEAMLESS_MAX_DOWNLOAD_FILES, SEAMLESS_MAX_DOWNLOAD_SIZE.""",
        action="store_const",
        const="no",
    )

    parser.add_argument(
        "-nd",
        "--no-download",
        dest="no_download",
        help="Do not download any result files or directories, only their checksums",
        action="store_true",
    )

    parser.add_argument(
        "--scratch",
        help="Don't store any result values, only store the overall result checksum",
        default=False,
        action="store_true",
    )

    parser.add_argument(
        "--docker",
        "--docker-image",
        dest="docker_image",
        help="Specify Docker image where transformation is to run in",
    )

    parser.add_argument(
        "--conda",
        "--conda-env",
        "--conda-environment",
        dest="conda_environment",
        help="Specify an existing conda environment where the transformation could run in.",
    )

    """
    ### TODO
    parser.add_argument(
        "--ncores", help="Number of cores required. -1 means all available cores", type=int
    )
    """

    parser.add_argument(
        "--fingertip",
        help="If the result checksum is known but the result unavailable: force evaluation",
        default=False,
        action="store_true",
    )

    parser.add_argument(
        "--undo", help="Undo this seamless-run command", action="store_true"
    )

    parser.add_argument(
        "--direct-print",
        dest="direct_print",
        help="Attempt to print out stderr messages directly in the executor log",
        action="store_true",
    )

    parser.add_argument(
        "--local",
        help="""Don't delegate the transformation to a remote server, but execute in-process.
    This is most useful for driver scripts that contain themselves seamless-run commands""",
        action="store_true",
    )

    parser.add_argument(
        "--dry",
        "--dry-run",
        dest="dry_run",
        help="Only parse the arguments and prepare a transformation job, do not execute it",
        action="store_true",
        default=False,
    )

    parser.add_argument(
        "-j",
        "--write-job",
        dest="write_job",
        help="Requires --dry. Write out the (small) transformation job buffers into a job directory for seamless-run-transformation",
    )
    parser.add_argument(
        "--write-remote-job",
        dest="write_remote_job",
        help="Requires --dry. Store the remote job directory in transformation metadata and stop remote execution after materializing that directory",
    )

    parser.add_argument(
        "--upload",
        help="Requires --dry. Upload input files and the (small) transformation job buffers",
        action="store_true",
    )

    parser.add_argument(
        "--qsubmit",
        "--qsub",
        help="Parse the arguments and write the job to a queue file",
        action="store_true",
        default=False,
    )

    parser.add_argument("command", nargs=argparse.REMAINDER)

    args = parser.parse_args()

    primary_index = args.primary - 1  # convert to 0-indexed

    if args.dry_run:
        if args.qsubmit:
            err("--qsubmit and --dry cannot be used together")
    else:
        if args.write_job:
            err("-j/--write-job requires --dry")
        if args.write_remote_job:
            err("--write-remote-job requires --dry")
        if args.upload:
            err("--upload requires --dry")
    if args.write_job:
        if os.path.exists(args.write_job):
            err(f"Output job directory '{args.write_job}' already exists")
    command = args.command

    verbosity = min(args.verbosity, 3)
    set_verbosity(verbosity)
    msg(1, "Verbosity set to {}".format(verbosity))
    msg(1, "seamless-run {}".format(__version__))
    msg(3, "Command:", json.dumps(command, indent=4))

    local_mode = args.local
    cache_mode = get_seamless_cache() is not None

    if not cache_mode:
        try:
            _require_config_file(os.getcwd())
        except ValueError as exc:
            err(str(exc))

    if args.project:
        if select_project is None:
            err("seamless_config is unavailable; cannot set --project")
        project, subproject = _parse_scoped_value(args.project, "project")
        select_project(project)
        if subproject:
            select_subproject(subproject)

    if args.stage:
        stage, substage = _parse_scoped_value(args.stage, "stage")
        if substage:
            seamless.config.set_stage(stage, substage, workdir=os.getcwd())
        else:
            seamless.config.set_stage(stage, workdir=os.getcwd())

    if len(command) == 0:
        parser.print_usage()  # TODO: add to usage message
        return 1

    cli_variables = {}
    if args.explicit_vars:
        for varspec in args.explicit_vars:
            varname, varvalue = _parse_var_spec(varspec)
            if varname in cli_variables and cli_variables[varname][0] != varvalue:
                err(
                    f"Variable '{varname}' specified multiple times with different values"
                )
            cli_variables[varname] = (varvalue, "str")

    cli_meta_variables = {}
    if args.explicit_metavars:
        for varspec in args.explicit_metavars:
            varname, varvalue = _parse_metavar_spec(varspec)
            if (
                varname in cli_meta_variables
                and cli_meta_variables[varname][0] != varvalue
            ):
                err(
                    f"Meta variable '{varname}' specified multiple times with different values"
                )
            cli_meta_variables[varname] = (varvalue, "str")

    ################################################################

    workdir = os.getcwd()
    if args.workdir is not None:
        workdir = os.path.expanduser(args.workdir)
        msg(1, "set argtyping working directory to: {}".format(workdir))

    if args.qsubmit:
        queue_file = os.environ.get("SEAMLESS_QUEUE_FILE")
        if queue_file is None:
            queue_file = ".seamless-queue"
            msg(
                1,
                f"SEAMLESS_QUEUE_FILE not defined. Set queue file to '{queue_file}'",
            )
        else:
            msg(1, f"Read queue file from SEAMLESS_QUEUE_FILE: '{queue_file}'")

    ################################################################

    meta = None
    if args.direct_print:
        if meta is None:
            meta = {}
        meta["__direct_print__"] = True
    if args.write_remote_job:
        if meta is None:
            meta = {}
        meta[REMOTE_JOB_META_KEY] = args.write_remote_job

    if getattr(args, "ncores", None):
        if meta is None:
            meta = {}
        meta["ncores"] = args.ncores

    ################################################################

    if args.unquote:
        if len(command) != 1:
            err(-1, "Unquote requires a single argument")
        commandstring = command[0]
    else:
        commandstring = " ".join(command)

    commands, primary_pipeline, pipeline_redirect = get_commands(
        commandstring, primary=primary_index
    )

    if primary_index >= len(commands):
        err(f"--primary {args.primary} but only {len(commands)} command(s) found")

    first_command = commands[primary_index]

    (
        interface_argindex,
        interface_file,
        interface_py_file,
        mapped_execarg,
    ) = interface.locate_files(first_command.words)

    msg(1, f"First command: {first_command.commandstring}")

    first_command_words = copy(first_command.words)
    if mapped_execarg:
        first_command_words[0] = mapped_execarg
    first_pipeline_words = copy(first_command_words)

    argtypes_initial, results_initial = interface.get_argtypes_and_results(
        interface_file,
        interface_py_file,
        interface_argindex,
        first_command_words,
        first_command.words[0],
    )

    if interface_py_file is None:
        msg(2, "Try to obtain argtypes from rules")

        overrule_ext, overrule_no_ext = False, False
        if args.g1:
            msg(1, "disable argtyping guess rule 1")
            overrule_ext = True
        if args.g2:
            msg(1, "disable argtyping guess rule 2")
            overrule_no_ext = True

        try:
            if primary_pipeline:
                pp_start, pp_end = primary_pipeline
                for com in commands[pp_start:pp_end]:
                    if com is not first_command:
                        first_pipeline_words += com.words
            argtypes_guess = guess_arguments(
                first_pipeline_words,
                overrule_ext=overrule_ext,
                overrule_no_ext=overrule_no_ext,
            )
        except ValueError as exc:
            err(*exc.args)
        if argtypes_initial is None:
            argtypes_initial = argtypes_guess
        else:
            argtypes_temp = argtypes_initial
            argtypes_initial = {}
            argtypes_initial.update(argtypes_guess)
            argtypes_initial.update(argtypes_temp)

    extra_inputs: list[str] = []
    if args.extra_inputs:
        extra_inputs.extend(args.extra_inputs)
    if args.input_files:
        extra_inputs.extend(_load_input_file(args.input_files))

    argtypes_extra_inputs = {}
    if extra_inputs:
        argtypes_extra_inputs = guess_arguments(
            extra_inputs,
            overrule_ext=True,
            overrule_no_ext=True,
        )
        for inp in extra_inputs:
            assert inp in argtypes_extra_inputs
            if (
                argtypes_extra_inputs[inp] == "value"
                or argtypes_extra_inputs[inp]["type"] == "value"
            ):
                err(f"input argument '{inp}': file/directory does not exist")

    argtypesstr = json.dumps(unchecksum(argtypes_initial), sort_keys=False, indent=2)
    msg(1, "initial argtypes dict:\n" + argtypesstr)

    file_mapping_mode = args.file_mapping_mode
    if file_mapping_mode is None:
        file_mapping_mode = "literal"

    try:
        argtypes = get_file_mapping(
            argtypes_initial,
            mapping_mode=file_mapping_mode,
            working_directory=workdir,
        )
        argtypes_extra_inputs2 = get_file_mapping(
            argtypes_extra_inputs,
            mapping_mode=file_mapping_mode,
            working_directory=workdir,
        )
        argtypes_extra_inputs2.pop("@order")
        argtypes.update(argtypes_extra_inputs2)
    except ValueError as exc:
        err(*exc.args)

    argtypes = unchecksum(argtypes)
    argtypesstr = json.dumps(argtypes, sort_keys=False, indent=2)
    msg(1, "argtypes dict:\n" + argtypesstr)

    mapped_first_pipeline = argtypes["@order"]

    ################################################################
    assert len(mapped_first_pipeline) == len(first_pipeline_words)
    word_substitutions = {}
    for wordnr, word in enumerate(mapped_first_pipeline):
        offset = 0
        for com in commands:
            if wordnr >= len(com.words) + offset:
                offset += len(com.words)
                continue
            else:
                break
        old_word = com.words[wordnr - offset]
        if word != old_word:
            node = com.wordnodes[wordnr - offset]
            word_substitutions[node] = word

    ################################################################
    interface_data = {}
    make_executables = []

    def update_interface_data(new_interface_data, first):
        changed = False
        for k, v in new_interface_data.items():
            if k in ("argtypes", "files", "directories", "shim"):
                continue
            curr = interface_data.get(k)
            if k == "results":
                if first:
                    continue
                if isinstance(v, list):
                    v = {kk: None for kk in v}
                if k not in interface_data:
                    interface_data[k] = {}
                if v:
                    interface_data[k].update(v)
                    changed = True
                continue
            if k == "environment":
                if curr is None:
                    interface_data[k] = v
                    continue
                if curr == v:
                    continue
                raise NotImplementedError("Multiple environments")

            changed = True
            if curr is None:
                interface_data[k] = v
            else:
                if isinstance(v, list) != isinstance(curr, list):
                    interface_data[k] = v
                elif isinstance(curr, list):
                    interface_data[k] += v
                else:
                    interface_data[k] = v
        if changed:
            msg(3, f"Updated interface data: {json.dumps(interface_data, indent=2)}")

    for commandnr, command in enumerate(commands):
        if commandnr != primary_index:
            msg(1, f"Command #{commandnr+1}: {command.commandstring}")
            (
                interface_argindex,
                interface_file,
                interface_py_file,
                mapped_execarg,
            ) = interface.locate_files(command.words)
        if interface_file is not None or interface_py_file is not None:
            if commandnr > 0:
                msg(
                    1,
                    f"Interface files found for command #{commandnr+1}: {command.commandstring}",
                )

        shim = None
        if interface_file is not None:
            msg(2, f"loading {interface_file}")
            _new_interface_data = interface.load(interface_file.as_posix())
            msg(
                3,
                f"{interface_file} content: {json.dumps(_new_interface_data, indent=2)}",
            )
            new_shim = _new_interface_data.get("shim")
            if new_shim is not None:
                shim = new_shim
            update_interface_data(
                _new_interface_data, first=(commandnr == primary_index)
            )

        if commandnr == primary_index:
            interface_py_file = None
        if interface_py_file is not None:
            if commandnr == primary_index:
                command_words = mapped_first_pipeline
            else:
                command_words = copy(command.words)
                if mapped_execarg:
                    command_words[0] = mapped_execarg

            arguments = command_words[interface_argindex + 1 :]
            _new_interface_data = interface.interface_from_py_file(
                interface_py_file, arguments
            )
            msg(
                3,
                f"{interface_py_file} result: {json.dumps(_new_interface_data, indent=2)}",
            )
            new_shim = _new_interface_data.get("shim")
            if new_shim is not None:
                shim = new_shim
            update_interface_data(
                _new_interface_data, first=(commandnr == primary_index)
            )

            if shim:
                wordnode = command.wordnodes[interface_argindex]
                word_substitutions[wordnode] = shim

        if mapped_execarg and not shim:
            wordnode = command.wordnodes[0]
            word = command.words[0]
            word = word_substitutions.get(wordnode, word)
            if word not in (
                "cd",
                "echo",
                "eval",
                "exec",
                "export",
                "set",
                "source",
            ):
                make_executables.append(word)

    ################################################################

    redirection = None
    if pipeline_redirect:
        redirection_node = pipeline_redirect
    else:
        redirection_node = parsing.get_redirection(commands[-1])
    if redirection_node is not None:
        redirection = redirection_node.word
        redirection = os.path.expanduser(redirection)
        if workdir is not None and redirection.startswith(workdir):
            redirection = redirection[len(workdir) :]
        if redirection != redirection_node.word:
            word_substitutions[redirection_node] = redirection

    if results_initial is None:
        results_initial = {}
    else:
        msg(2, f"Initial result targets from first command: {results_initial}")
        decal = os.path.relpath(os.getcwd(), workdir)
        if decal != ".":
            results_initial2 = results_initial.copy()
            for _k, _v in results_initial.items():
                if _v is None:
                    _kk = os.path.join(decal, _k)
                    results_initial2.pop(_k)
                    results_initial2[_kk] = _v
            results_initial = results_initial2

    results = results_initial.copy()
    results.update(interface_data.get("results", {}))

    if args.extra_results:
        for extra_result in args.extra_results:
            pos = extra_result.find(":")
            if pos == -1:
                results[extra_result] = None
            elif pos == 0:
                results["STDOUT"] = extra_result[1:]
            else:
                results[extra_result[:pos]] = extra_result[pos + 1 :]

    if not results and not redirection:
        if args.no_download or args.scratch:
            err("Download disabled. Refuse to print output to screen.")
        elif args.qsubmit:
            err(
                "Submit to a queue, but no capture/download targets. Refuse to print output to screen."
            )
        capture_stdout = True
        result_targets = None
    else:
        if "STDOUT" in results:
            capture_stdout = True
        else:
            capture_stdout = False
        result_targets = results.copy()
        if redirection:
            result_targets[redirection] = None
        msg(1, f"Identify result targets: {result_targets}")

    ################################################################
    """
    ### TODO
    env = Environment()

    docker_image = args.docker_image
    if docker_image is None:
        docker_image = interface_data.get("environment", {}).get("docker_image")

    if docker_image is not None:
        msg(1, f'Set Docker image to "{docker_image}"')
        env.set_docker({"name": docker_image})

    conda_environment = args.conda_environment
    if conda_environment is None:
        conda_environment = interface_data.get("environment", {}).get("conda_environment")

    if conda_environment is not None:
        msg(1, f'Set conda environment to "{conda_environment}"')
        env.set_conda_env(conda_environment)
    ### /TODO
    """

    # CONFIG
    """    
    Now we will do something like:
        seamless.config.init(workdir=os.getcwd())
    
    However, we must interject overrulings of the execution command,
    based on the args
    """
    from seamless_config.extern_clients import set_remote_clients_from_env
    from seamless_config import change_stage, set_workdir
    from seamless_config.config_files import load_config_files
    from seamless_config.select import (
        select_execution,
        get_selected_cluster,
        get_execution,
    )

    include_dask = True
    if args.dry_run or args.qsubmit or local_mode:
        include_dask = False
    try:
        set_workdir(os.getcwd())
        if not set_remote_clients_from_env(include_dask=include_dask):
            load_config_files()
            if args.dry_run or args.qsubmit:
                import seamless_remote.database_remote

                seamless_remote.database_remote.DISABLED = True
                select_execution("process")
                if args.upload or args.qsubmit:
                    if get_selected_cluster() is None:
                        err(f"--upload or --qsubmit require a cluster")
            else:
                if local_mode:
                    if get_execution() == "remote":
                        select_execution("process")

            change_stage()
        # /CONFIG
    except ValueError as exc:
        err(str(exc))

    max_upload_files = os.environ.get("SEAMLESS_MAX_UPLOAD_FILES", "400")
    max_upload_files = int(max_upload_files)
    max_upload_size = os.environ.get("SEAMLESS_MAX_UPLOAD_SIZE", "100 MB")
    max_upload_size = human2bytes(max_upload_size)

    max_download_files = os.environ.get("SEAMLESS_MAX_DOWNLOAD_FILES", "2000")
    max_download_files = int(max_download_files)
    max_download_size = os.environ.get("SEAMLESS_MAX_DOWNLOAD_SIZE", "500 MB")
    max_download_size = human2bytes(max_download_size)

    paths = set()
    directories = {}
    mapping = {}
    direct_checksums = {}
    direct_checksum_directories = {}
    for argname, arg in argtypes.items():
        direct_checksum = None
        if isinstance(arg, dict):
            argtype = arg.get("type")
            path = arg.get("mapping", argname)
            direct_checksum = arg.get("checksum")
        else:
            argtype = arg
            path = argname
        if argtype in ("file", "directory"):
            if direct_checksum:
                if argtype == "directory":
                    direct_checksum_directories[argname] = argname
                direct_checksums[argname] = direct_checksum
            else:
                paths.add(path)
                if argtype == "directory":
                    directories[path] = argname
                mapping[argname] = path

    try:
        file_checksum_dict, _ = files_to_checksums(
            paths,
            max_upload_size=max_upload_size,
            max_upload_files=max_upload_files,
            directories=directories,
            auto_confirm=args.auto_confirm,
            dry_run=(args.dry_run and not args.upload),
        )
    except SeamlessSystemExit as exc:
        err(*exc.args)

    checksum_dict = {k: file_checksum_dict[v] for k, v in mapping.items()}
    checksum_dict.update(direct_checksums)
    checksum_dictstr = json.dumps(checksum_dict, sort_keys=True, indent=2)
    msg(2, "file/directory checksum dict:\n" + checksum_dictstr)
    directories.update(direct_checksum_directories)
    if len(directories):
        msg(2, "directories:", directories)

    ################################################################

    for node in sorted(word_substitutions.keys(), key=lambda node: -node.pos[0]):
        word = word_substitutions[node]
        commandstring = (
            commandstring[: node.pos[0]] + word + commandstring[node.pos[1] :]
        )

    if args.prologues:
        commandstring = "; ".join(args.prologues) + "; " + commandstring

    msg(1, "bash command:\n", commandstring, "\n")

    ################################################################

    command = commandstring.split()
    variables = cli_variables.copy() if cli_variables else None
    if len(commands) == 1:
        found_canonical = False
        canonical = interface_data.get("canonical", [])
        for canon in canonical:
            vars = canon.get("variables", [])
            varnames = [var["name"] for var in vars]
            vartypes = {var["name"]: var["celltype"] for var in vars}
            canon_cmd = canon["command"].split()
            if len(canon_cmd) != len(command):
                continue
            for w1, w2 in zip(canon_cmd, command):
                if w1 == w2:
                    continue
                if w1[0] == "$" and w1[1:] in varnames:
                    continue
                break
            else:
                msg(1, f"Found canonical command match:\n  {canon['command']}")
                variables_from_canonical = {}
                for w1, w2 in zip(canon_cmd, command):
                    if w1[0] == "$" and w1[1:] in varnames:
                        varname = w1[1:]
                        variables_from_canonical[varname] = (w2, vartypes[varname])
                if cli_variables:
                    for varname in cli_variables:
                        if varname in variables_from_canonical:
                            err(
                                f"Variable '{varname}' is already defined by canonical command matching"
                            )
                    variables_from_canonical.update(cli_variables)
                variables = variables_from_canonical
                msg(2, f"Variables:\n  {variables}")
                commandstring = canon["command"]
                found_canonical = True
        if len(canonical) and not found_canonical:
            msg(1, "No canonical command match found")

    ################################################################

    conda_environment = args.conda_environment
    if conda_environment is None:
        conda_environment = interface_data.get("environment", {}).get(
            "conda_environment"
        )

    environment = {}
    if conda_environment is not None:
        msg(1, f'Set conda environment to "{conda_environment}"')
        environment["conda_environment"] = conda_environment

    transformation_checksum, transformation_dict = prepare_bash_transformation(
        commandstring,
        checksum_dict,
        directories=list(directories.values()),
        make_executables=make_executables,
        capture_stdout=capture_stdout,
        result_targets=result_targets,
        environment=environment,
        variables=variables,
        meta_variables=cli_meta_variables,
        meta=meta,
        dry_run=(args.dry_run and not args.upload),
    )

    if make_executables:
        msg(
            2,
            "The following files will be made executable inside the transformer\n:\n  {}".format(
                "\n  ".join(make_executables)
            ),
        )
    else:
        msg(3, "No files will be made executable inside the transformer")

    ################################################################

    transformation_checksum = Checksum(transformation_checksum).hex()
    msg(3, f"Transformation checksum: {transformation_checksum}")

    def file_write(handle, buf):
        if isinstance(buf, Buffer):
            buf = buf.content
        handle.write(buf)

    if args.dry_run:
        if args.write_job is not None:
            os.mkdir(args.write_job)
            transformation_buffer = tf_get_buffer(transformation_dict)
            dunder = extract_job_dunder(transformation_dict)
            if dunder:
                with open(os.path.join(args.write_job, "dunder.json"), "wb") as _f:
                    _f.write(json_dumps_bytes(dunder) + b"\n")
            code_checksum = transformation_dict["code"][2]
            env_checksum = transformation_dict.get("__env__")
            if args.upload:
                with open(
                    os.path.join(args.write_job, "transformation.json.CHECKSUM"),
                    "w",
                ) as _f:
                    _f.write(transformation_checksum)
            else:
                with open(
                    os.path.join(args.write_job, "transformation.json"), "wb"
                ) as _f:
                    file_write(_f, transformation_buffer)
                cache = get_buffer_cache()
                command = cache.get(Checksum(code_checksum))
                if command is None:
                    command = Checksum(code_checksum).resolve()
                with open(os.path.join(args.write_job, "command.txt"), "wb") as _f:
                    file_write(_f, command)
                if env_checksum is not None:
                    env_buffer = cache.get(Checksum(env_checksum))
                    if env_buffer is None:
                        env_buffer = Checksum(env_checksum).resolve()
                    with open(os.path.join(args.write_job, "env.json"), "wb") as _f:
                        file_write(_f, env_buffer)

        if args.write_remote_job:
            print("Transformation submitted to remote server")
            if args.upload:
                transformation_buffer = Checksum(transformation_checksum).resolve()
                assert isinstance(transformation_buffer, Buffer)
                transformation_buffer.incref()
            tf_dunder = extract_tf_dunder(transformation_dict)
            try:
                run_sync(
                    transformation_dict,
                    tf_checksum=transformation_checksum,
                    tf_dunder=tf_dunder,
                    scratch=False,
                    require_value=False,
                )
            except RemoteJobWritten:
                return 0
            except Exception:
                traceback.print_exc(limit=0)
                return 1
            err(
                "Remote job write requested but the transformation returned a result checksum"
            )

        if args.upload or args.write_job:
            print(transformation_checksum)
            if args.upload:
                transformation_buffer = Checksum(transformation_checksum).resolve()
                assert isinstance(transformation_buffer, Buffer)
                transformation_buffer.incref()

        return 0

    elif args.qsubmit:
        if args.auto_confirm not in ("yes", "no"):
            msg(
                1,
                "qsubmit: download confirmation cannot be interactive. --yes not present => default to --no.",
            )
            auto_confirm = "no"
        else:
            auto_confirm = args.auto_confirm

        assert result_targets

        original_command = "seamless-run " + " ".join(sys.argv[1:])
        params = {
            "undo": args.undo,
            "scratch": args.scratch,
            "workdir": workdir,
            "download": not args.no_download,
            "auto_confirm": auto_confirm,
            "capture_stdout": capture_stdout,
            "max_download_size": max_download_size,
            "max_download_files": max_download_files,
        }
        queue_command = {
            "queue_command": "SUBMIT",
            "original_command": original_command,
            "transformation_checksum": str(transformation_checksum),
            "transformation_dict": transformation_dict,
            "result_targets": result_targets,
            "params": params,
        }
        qcj = json.dumps(queue_command, indent=2)

        lockpath = queue_file + ".LOCK"

        while 1:
            try:
                lock_stat_result = os.stat(lockpath)
            except FileNotFoundError:
                break
            lock_mtime = lock_stat_result.st_mtime
            if time.time() - lock_mtime > 30:
                msg(1, f"Stale lock on {queue_file}, breaking it...")
                break
            time.sleep(1)

        try:
            pathlib.Path(lockpath).touch()
            with open(queue_file, "ab") as fp:
                fp.write(qcj.encode() + b"\x00")

        finally:
            try:
                pathlib.Path(lockpath).unlink()
            except FileNotFoundError:
                pass

        msg(1, "Command submitted to queue file")

        return 0

    delete_futures_event = threading.Event()

    maintain_fut = functools.partial(
        maintain_futures,
        workdir,
        transformation_checksum,
        result_targets,
        delete_futures_event=delete_futures_event,
        msg_func=msg,
    )

    if result_targets:
        maintain_futures_thread = threading.Thread(
            target=maintain_fut, name=maintain_futures
        )
        maintain_futures_thread.start()

    try:
        result_fingertip = True
        if args.no_download:
            result_fingertip = False
        if result_targets:
            result_fingertip = True
        result_checksum = run_transformation(
            transformation_dict,
            undo=args.undo,
            fingertip=result_fingertip,
            scratch=args.scratch,
        )
    except Exception:
        traceback.print_exc(limit=0)
        return 1
    finally:
        delete_futures_event.set()
    ################################################################

    if not args.undo:
        msg(1, "Transformation finished")
        msg(2, "Result checksum: {}".format(result_checksum))

    if args.undo:
        if result_checksum is None:
            return 1
        else:
            msg(1, "Transformation undone")
            return 0

    else:
        result_buffer = get_result_buffer(
            result_checksum,
            do_fingertip=args.fingertip,
            do_scratch=args.scratch,
            has_result_targets=(True if result_targets else False),
            err_func=err,
        )
        result = get_results(
            result_targets,
            result_checksum,
            result_buffer,
            workdir=workdir,
            do_scratch=args.scratch,
            do_download=not args.no_download,
            do_capture_stdout=capture_stdout,
            max_download_size=max_download_size,
            max_download_files=max_download_files,
            do_auto_confirm=args.auto_confirm,
            msg_func=msg,
        )
        if result is not None:
            if isinstance(result, bytes):
                result = result.lstrip(b"\n")
                if result.endswith(b"\n"):
                    result = result.rstrip(b"\n") + b"\n"
                sys.stderr.buffer.write(result)
            else:
                result = result.lstrip("\n")
                if result.endswith("\n"):
                    result = result.rstrip("\n") + "\n"
                sys.stdout.write(result)


def main(argv: list[str] | None = None) -> int:
    try:
        return _main(argv)
    finally:
        seamless.close()


if __name__ == "__main__":
    sys.exit(main())
