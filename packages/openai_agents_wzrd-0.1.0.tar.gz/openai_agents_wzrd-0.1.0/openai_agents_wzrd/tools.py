"""WZRD velocity tools for OpenAI Agents SDK."""
from __future__ import annotations
import json, time, threading
from typing import Optional
import httpx
from agents import function_tool

_MOMENTUM_URL = "https://api.twzrd.xyz/v1/signals/momentum"
_CACHE_TTL = 60
_TREND_BOOST = {
    "surging": 3.0, "accelerating": 2.0, "stable": 0.0,
    "insufficient_history": 0.0, "decelerating": -1.0, "cooling": -2.0,
}
_CONFIDENCE_WEIGHT = {"normal": 1.0, "low": 0.5, "insufficient": 0.0}

_lock = threading.Lock()
_cache: dict[str, tuple[float, dict]] = {}


def _fetch(capability: Optional[str] = None) -> dict:
    url = f"{_MOMENTUM_URL}?capability={capability}" if capability else _MOMENTUM_URL
    now = time.monotonic()
    cached = _cache.get(url)
    if cached and (now - cached[0]) < _CACHE_TTL:
        return cached[1]
    try:
        r = httpx.get(url, timeout=5.0)
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if not isinstance(data, dict) or not isinstance(data.get("models"), list):
        return {}
    with _lock:
        _cache[url] = (now, data)
    return data


def _rank(signal: dict) -> list[dict]:
    scored: list[tuple[float, int, dict]] = []
    for i, m in enumerate(signal.get("models", [])):
        cw = _CONFIDENCE_WEIGHT.get(m.get("confidence", "insufficient"), 0.0)
        s = _TREND_BOOST.get(m.get("trend", "stable"), 0.0) * cw
        s += min(max(m.get("score", 0.0), 0.0), 1.0) * 0.3 * cw
        scored.append((s, i, m))
    scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)
    return [x[2] for x in scored]


@function_tool
def pick_model(task: str = "auto") -> str:
    """Pick the best AI model for a task using real-time velocity signals.

    Args:
        task: What you need the model for. Options: "code", "chat", "reasoning", "auto"

    Returns:
        JSON with model name, velocity score, trend, and platform.
    """
    capability = task if task in ("code", "chat", "reasoning") else None
    signal = _fetch(capability)
    ranked = _rank(signal)
    if not ranked:
        return json.dumps({"error": "no signal data available"})
    top = ranked[0]
    return json.dumps({
        "model": top.get("model"),
        "score": top.get("score"),
        "trend": top.get("trend"),
        "platform": top.get("platform"),
        "confidence": top.get("confidence"),
        "alternatives": [m.get("model") for m in ranked[1:4]],
    })


@function_tool
def get_velocity_signals() -> str:
    """Get full velocity data for all tracked AI models.

    Returns:
        JSON array of models sorted by composite velocity score, each with
        model name, score, trend, platform, and confidence.
    """
    signal = _fetch()
    ranked = _rank(signal)
    if not ranked:
        return json.dumps({"error": "no signal data available"})
    keys = ("model", "score", "trend", "platform", "confidence")
    return json.dumps([{k: m.get(k) for k in keys} for m in ranked])
