"""Tests for openai-agents-wzrd tools — mocked, no network or agents dep."""

from __future__ import annotations

import json
import sys
import types
from unittest.mock import MagicMock, patch

import pytest

# Stub openai-agents so import works without the dep
_agents = types.ModuleType("agents")
_agents.function_tool = lambda f: f  # type: ignore[attr-defined]
sys.modules.setdefault("agents", _agents)

from openai_agents_wzrd.tools import pick_model, get_velocity_signals, _fetch, _rank, _cache  # noqa: E402

MOCK_SIGNAL = {
    "models": [
        {"model": "qwen/qwen3-32b", "score": 0.92, "trend": "surging", "confidence": "normal", "platform": "openrouter"},
        {"model": "meta-llama/llama-4-scout", "score": 0.78, "trend": "accelerating", "confidence": "normal", "platform": "openrouter"},
        {"model": "google/gemini-2.5-pro", "score": 0.55, "trend": "stable", "confidence": "normal", "platform": "openrouter"},
        {"model": "old/stale", "score": 0.20, "trend": "cooling", "confidence": "low", "platform": "openrouter"},
    ],
    "generated_at": "2026-04-03T00:00:00Z",
}


@pytest.fixture(autouse=True)
def _clear_cache():
    _cache.clear()
    yield
    _cache.clear()


class TestRanking:
    def test_surging_first(self):
        ranked = _rank(MOCK_SIGNAL)
        assert ranked[0]["model"] == "qwen/qwen3-32b"

    def test_cooling_last(self):
        ranked = _rank(MOCK_SIGNAL)
        assert ranked[-1]["model"] == "old/stale"

    def test_empty(self):
        assert _rank({}) == []


class TestFetch:
    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_success(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        result = _fetch()
        assert len(result["models"]) == 4

    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_failure(self, mock_get):
        mock_get.side_effect = Exception("timeout")
        assert _fetch() == {}

    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_cache(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        _fetch()
        _fetch()
        assert mock_get.call_count == 1


class TestPickModel:
    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_returns_json_with_top_model(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        result = json.loads(pick_model("auto"))
        assert result["model"] == "qwen/qwen3-32b"
        assert result["trend"] == "surging"
        assert len(result["alternatives"]) == 3

    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_code_capability(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        pick_model("code")
        url = mock_get.call_args[0][0]
        assert "capability=code" in url

    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_no_signal_returns_error(self, mock_get):
        mock_get.side_effect = Exception("down")
        result = json.loads(pick_model("auto"))
        assert "error" in result


class TestGetVelocitySignals:
    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_returns_sorted_list(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        result = json.loads(get_velocity_signals())
        assert isinstance(result, list)
        assert result[0]["model"] == "qwen/qwen3-32b"
        assert all(k in result[0] for k in ("model", "score", "trend", "platform", "confidence"))

    @patch("openai_agents_wzrd.tools.httpx.get")
    def test_no_signal(self, mock_get):
        mock_get.side_effect = Exception("down")
        result = json.loads(get_velocity_signals())
        assert "error" in result
