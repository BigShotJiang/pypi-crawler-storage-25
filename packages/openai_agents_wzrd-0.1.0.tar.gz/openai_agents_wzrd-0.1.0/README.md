# openai-agents-wzrd

WZRD velocity tools for [OpenAI Agents SDK](https://github.com/openai/openai-agents-python). Gives any agent real-time AI model velocity signals from 100+ models across 4 platforms.

Free tier. No API key required. 60s cache.

## Install

```bash
pip install openai-agents-wzrd
```

## Usage

```python
from agents import Agent, Runner
from openai_agents_wzrd import pick_model, get_velocity_signals

agent = Agent(
    name="Model Router",
    tools=[pick_model, get_velocity_signals],
    instructions="Use WZRD velocity signals to pick the best model for each task.",
)

result = Runner.run_sync(agent, "Which model is best for code generation right now?")
print(result.final_output)
```

## Tools

- **`pick_model(task)`** - Top-ranked model for a task keyword (`"code"`, `"chat"`, `"reasoning"`, `"auto"`), plus score, trend, platform, and 3 alternatives.
- **`get_velocity_signals()`** - Full velocity data for all tracked models sorted by composite score.

Both tools hit the public WZRD momentum API (`api.twzrd.xyz/v1/signals/momentum`), rank by composite trend boost + velocity score weighted by confidence, and return JSON.
