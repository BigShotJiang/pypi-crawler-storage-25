# -*- coding: utf-8 -*-

"""
This module provides a group of CLI commands that abstract linter, type
checker, and security tool execution. Consuming projects import ``cli_dev``
and wire it into their own ``CommandCollection`` to expose ``run-linters`` and
``run-security`` without duplicating this logic.

**Available Commands:**

  * ``python manager.py run-linters <package>``
  * ``python manager.py run-linters core_dev_tools --tool ruff``
  * ``python manager.py run-linters core_dev_tools --tool mypy --tool pyright``
  * ``python manager.py run-security <package>``
"""

from __future__ import annotations

import subprocess  # nosec B404
import sys
from typing import List, Tuple

from click import argument, echo, option
from click.decorators import group

LINTERS: List[Tuple[str, List[str]]] = [
    ("ty", ["ty", "check"]),
    ("ruff", ["ruff", "check"]),
    ("mypy", ["mypy", "--explicit-package-bases"]),
    ("pyright", ["pyright"]),
    ("pylint", ["pylint"]),
]

_LINTER_NAMES = [name for name, _ in LINTERS]

# Third element indicates whether the tool accepts a package path argument.
SECURITY_TOOLS: List[Tuple[str, List[str], bool]] = [
    ("bandit", ["bandit", "-r"], True),
    ("pip-audit", ["pip-audit"], False),
]


@group()
def cli_dev():
    """
    Group of commands related to linters and type checkers.
    """


@cli_dev.command("run-linters")
@argument("package")
@option(
    "-t",
    "--tool",
    "tools",
    multiple=True,
    type=str,
    help="Run only the specified linter(s). Can be repeated. "
    f"Available: {', '.join(_LINTER_NAMES)}. Defaults to all.",
)
def run_linters(package: str, tools: Tuple[str, ...]) -> None:
    """
    Runs linters and type checkers against PACKAGE.

    :param package: Root package directory to check (e.g. ``core_dev_tools``).
    :param tools: Subset of linters to run. When omitted, all linters run.

    By default, runs all five tools in order:
      - ty check
      - ruff check
      - mypy
      - pyright
      - pylint

    All linters always run; a non-zero exit from any tool is collected and
    reported at the end, then the command exits with code 1.
    """

    invalid = set(tools) - set(_LINTER_NAMES)
    if invalid:
        echo(
            f"Unknown linter(s): {', '.join(sorted(invalid))}. "
            f"Available: {', '.join(_LINTER_NAMES)}",
            err=True,
        )
        sys.exit(1)

    selected = [(name, cmd) for name, cmd in LINTERS if not tools or name in tools]

    failed: List[str] = []

    for name, base_cmd in selected:
        echo(f"\n--- {name} ---")
        result = subprocess.run(base_cmd + [package], check=False)  # nosec B603
        if result.returncode != 0:
            failed.append(name)

    echo("")
    if failed:
        echo(f"Linters failed: {', '.join(failed)}", err=True)
        sys.exit(1)

    echo("All linters passed.")


@cli_dev.command("run-security")
@argument("package")
def run_security(package: str) -> None:
    """
    Runs security scanners against PACKAGE.

    :param package: Root package directory to scan (e.g. ``core_dev_tools``).

    Runs in order:
      - bandit -r <package>
      - pip-audit

    All tools always run; a non-zero exit from any tool is collected and
    reported at the end, then the command exits with code 1.
    """

    failed: List[str] = []

    for name, base_cmd, takes_path in SECURITY_TOOLS:
        echo(f"\n--- {name} ---")
        cmd = base_cmd + ([package] if takes_path else [])
        result = subprocess.run(cmd, check=False)  # nosec B603
        if result.returncode != 0:
            failed.append(name)

    echo("")
    if failed:
        echo(f"Security tools failed: {', '.join(failed)}", err=True)
        sys.exit(1)

    echo("All security checks passed.")
