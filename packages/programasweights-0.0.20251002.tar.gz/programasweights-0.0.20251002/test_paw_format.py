#!/usr/bin/env python3
"""
Simple test script for .paw format compilation and interpretation.
"""

import os
import sys
import traceback

def test_compile_and_interpret():
    """Test the full compile → load → interpret pipeline."""
    
    print("🧪 Testing .paw format compilation and interpretation...")
    
    # Test spec
    spec = 'Parse a string like "(A) ... (B) ... (C) ..." into a JSON list of options.'
    paw_file = "test_program.paw"
    test_input = "(A) cat (B) dog (C) both (A) and (B)"
    
    try:
        print(f"\n1. 🔨 Compiling spec to {paw_file}...")
        print(f"   Spec: {spec}")
        
        import programasweights as paw
        
        # Compile
        result_path = paw.compile(
            out_path=paw_file,
            spec=spec,
            checkpoint_dir="outputs/prefix_kv/checkpoint"
        )
        print(f"   ✅ Compiled to: {result_path}")
        
        # Check file exists
        if not os.path.exists(paw_file):
            print(f"   ❌ ERROR: {paw_file} was not created!")
            return False
            
        file_size = os.path.getsize(paw_file)
        print(f"   📁 File size: {file_size} bytes")
        
        print(f"\n2. 📂 Loading {paw_file}...")
        
        # Load and test
        fn = paw.function(
            path=paw_file,
            interpreter_name="outputs/prefix_kv/checkpoint/interpreter",
            max_new_tokens=64
        )
        print(f"   ✅ Loaded function successfully")
        
        print(f"\n3. 🚀 Testing with input...")
        print(f"   Input: {test_input}")
        
        output = fn(test_input)
        print(f"   Output: {output}")
        print(f"   ✅ Test completed successfully!")
        
        return True
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print(f"📋 Full traceback:")
        traceback.print_exc()
        return False
    
    finally:
        # Cleanup
        if os.path.exists(paw_file):
            os.remove(paw_file)
            print(f"\n🧹 Cleaned up {paw_file}")


def test_paw_format_directly():
    """Test the .paw format loading/saving directly."""
    
    print("\n🔬 Testing .paw format directly...")
    
    try:
        from programasweights.paw_format import save_paw_program, load_paw_program
        import torch
        
        # Create dummy KV layers
        dummy_kv = [
            (torch.randn(1, 4, 5, 64), torch.randn(1, 4, 5, 64)),  # Layer 0
            (torch.randn(1, 4, 5, 64), torch.randn(1, 4, 5, 64)),  # Layer 1
        ]
        
        test_file = "test_format.paw"
        
        print("   💾 Saving dummy .paw file...")
        save_paw_program(
            filepath=test_file,
            kv_layers=dummy_kv,
            spec="Test spec",
            base_model="test-model",
            prefix_steps=5
        )
        
        print("   📂 Loading .paw file...")
        loaded_kv, loaded_metadata = load_paw_program(test_file)
        
        print(f"   ✅ Loaded {len(loaded_kv)} layers")
        print(f"   📋 Metadata: {loaded_metadata}")
        
        # Verify shapes match
        for i, ((orig_k, orig_v), (load_k, load_v)) in enumerate(zip(dummy_kv, loaded_kv)):
            if orig_k.shape != load_k.shape or orig_v.shape != load_v.shape:
                print(f"   ❌ Shape mismatch in layer {i}")
                return False
        
        print("   ✅ All shapes match!")
        
        # Cleanup
        os.remove(test_file)
        return True
        
    except Exception as e:
        print(f"   ❌ ERROR: {e}")
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("🧪 ProgramAsWeights .paw Format Test Suite")
    print("=" * 50)
    
    # Test 1: .paw format directly
    format_ok = test_paw_format_directly()
    
    # Test 2: Full pipeline
    if format_ok:
        pipeline_ok = test_compile_and_interpret()
    else:
        print("\n⏭️  Skipping pipeline test due to format test failure")
        pipeline_ok = False
    
    print("\n" + "=" * 50)
    if format_ok and pipeline_ok:
        print("🎉 All tests passed!")
        sys.exit(0)
    else:
        print("❌ Some tests failed!")
        sys.exit(1) 