#!/usr/bin/env python3
"""
Extract compiler and interpreter models from joint training checkpoint.
Saves them as separate HuggingFace model directories.
"""

import argparse
import os
import torch
from pathlib import Path

from training.loops.prefix_tuning_sft import JointCompilerInterpreter


def extract_models(checkpoint_dir: str, output_dir: str) -> None:
    """
    Extract compiler and interpreter from joint checkpoint.
    
    Args:
        checkpoint_dir: Directory containing pytorch_model.bin
        output_dir: Directory to save extracted compiler/ and interpreter/ folders
    """
    print(f"Loading joint checkpoint from: {checkpoint_dir}")
    
    # Try to load mapper metadata (might not exist if saved as part of joint model)
    mapper_path = os.path.join(checkpoint_dir, "mapper.pt")
    mapper_pkg = None
    print("No separate mapper.pt found, will extract from joint model")
    # Use defaults - these should match your training config
    compiler_model_name = "Qwen/Qwen3-0.6B"
    interpreter_model_name = "Qwen/Qwen2.5-Coder-0.5B-Instruct"
    prefix_steps = 5
    
    print(f"Compiler base: {compiler_model_name}")
    print(f"Interpreter base: {interpreter_model_name}")
    print(f"Prefix steps: {prefix_steps}")
    
    # Load joint model
    model = JointCompilerInterpreter(
        compiler_model_name=compiler_model_name,
        interpreter_model_name=interpreter_model_name,
        prefix_steps=prefix_steps,
        max_spec_length=256,
        max_input_length=256,
        max_output_length=256,
    )
    
    # Load the trained weights
    checkpoint_path = os.path.join(checkpoint_dir, "pytorch_model.bin")
    if os.path.exists(checkpoint_path):
        print(f"Loading trained weights from: {checkpoint_path}")
        state_dict = torch.load(checkpoint_path, map_location="cpu")
        model.load_state_dict(state_dict)
    else:
        raise FileNotFoundError(f"pytorch_model.bin not found in {checkpoint_dir}")
    
    # Create output directories
    os.makedirs(output_dir, exist_ok=True)
    compiler_dir = os.path.join(output_dir, "compiler")
    interpreter_dir = os.path.join(output_dir, "interpreter")
    
    print(f"Saving compiler to: {compiler_dir}")
    model.compiler.save_pretrained(compiler_dir, safe_serialization=False)
    model.compiler_tokenizer.save_pretrained(compiler_dir)
    
    print(f"Saving interpreter to: {interpreter_dir}")
    model.interpreter.save_pretrained(interpreter_dir, safe_serialization=False)
    model.interpreter_tokenizer.save_pretrained(interpreter_dir)
    
    # Fix generation config for deterministic behavior
    gen_config_path = os.path.join(interpreter_dir, "generation_config.json")
    if os.path.exists(gen_config_path):
        import json
        with open(gen_config_path, "r", encoding="utf-8") as f:
            gen_config = json.load(f)
        gen_config["do_sample"] = False
        gen_config.pop("temperature", None)
        gen_config.pop("top_k", None)
        gen_config.pop("top_p", None)
        gen_config.pop("repetition_penalty", None)
        with open(gen_config_path, "w", encoding="utf-8") as f:
            json.dump(gen_config, f, indent=2)
        print("Updated generation_config.json for deterministic behavior")
    
    # Extract and save mapper state dict
    mapper_state_dict = {}
    for key, value in state_dict.items():
        if key.startswith("mapper."):
            mapper_state_dict[key[7:]] = value  # Remove "mapper." prefix
    
    if mapper_state_dict:
        mapper_save_pkg = {
            "state_dict": mapper_state_dict,
            "prefix_steps": prefix_steps,
            "compiler_model_name": compiler_model_name,
            "interpreter_model_name": interpreter_model_name,
        }
        mapper_dest = os.path.join(compiler_dir, "mapper.pt")
        torch.save(mapper_save_pkg, mapper_dest)
        print(f"Extracted and saved mapper to: {mapper_dest}")
    elif mapper_pkg:
        # Use the separate mapper.pt if it existed
        mapper_dest = os.path.join(compiler_dir, "mapper.pt")
        torch.save(mapper_pkg, mapper_dest)
        print(f"Copied mapper to: {mapper_dest}")
    else:
        print("⚠️  No mapper weights found")
    
    print("\n✅ Model extraction complete!")
    print(f"Compiler: {compiler_dir}")
    print(f"Interpreter: {interpreter_dir}")
    print(f"Mapper: {mapper_dest if 'mapper_dest' in locals() else 'N/A'}")


def main():
    parser = argparse.ArgumentParser(description="Extract compiler and interpreter from joint checkpoint")
    parser.add_argument("--checkpoint-dir", default="outputs/prefix_kv/checkpoint",
                       help="Directory containing pytorch_model.bin and possibly mapper.pt")
    parser.add_argument("--output-dir", default="outputs/prefix_kv/extracted",
                       help="Directory to save extracted compiler/ and interpreter/ folders")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.checkpoint_dir):
        print(f"❌ Checkpoint directory not found: {args.checkpoint_dir}")
        return 1
    
    try:
        extract_models(args.checkpoint_dir, args.output_dir)
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main()) 