from typing import List, Tuple, Optional
from app.config import settings
from .simple_sql_manager import simple_sql_manager

from openai import AsyncOpenAI
OPENAI_AVAILABLE = True

class GPTService:
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    async def generate_test_examples(
        self,
        spec: str,
        num_examples: int = 5
    ) -> Tuple[bool, List[Tuple[str, str]], Optional[str]]:
        """
        Generate test input/output examples using GPT based on the specification.
        
        Returns:
            Tuple of (success, [(input, output)...], error_message)
        """
        if not self.client:
            return False, [], "OpenAI API key not configured"

        try:
            prompt = f"""Given this program specification:
"{spec}"

Generate {num_examples} diverse test examples that demonstrate the program's functionality.
Each example should have an input and the expected output as a STRING.

IMPORTANT: 
- If the output should be JSON, provide it as a JSON string (e.g., "{{\\"A\\": \\"cat\\", \\"B\\": \\"dog\\"}}")
- If the output should be a list, provide it as a JSON string (e.g., "[\\"cat\\", \\"dog\\", \\"bird\\"]")
- Always return output as a string, not as an actual JSON object or array

Format your response as JSON with this structure:
{{
  "examples": [
    {{"input": "example input 1", "output": "expected output as string"}},
    {{"input": "example input 2", "output": "expected output as string"}},
    ...
  ]
}}

Make the examples realistic and cover different edge cases or variations of the expected input format."""

            response = await self.client.chat.completions.create(
                model="gpt-5-mini",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that generates test examples for programs. Always respond with valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                max_completion_tokens=4000,
                temperature=1.0,
                response_format={"type": "json_object"},
                reasoning_effort="low",
            )

            content = response.choices[0].message.content
            print(f"GPT response: {response}")
            # Parse JSON response
            import json
            data = json.loads(content)
            examples = []
            for ex in data.get("examples", []):
                input_text = ex["input"]
                output_value = ex["output"]
                
                # Convert output to string if it's not already
                if isinstance(output_value, list):
                    output_text = json.dumps(output_value)
                elif isinstance(output_value, dict):
                    output_text = json.dumps(output_value)
                else:
                    output_text = str(output_value)
                
                examples.append((input_text, output_text))
            
            return True, examples, None

        except Exception as e:
            return False, [], f"GPT service error: {str(e)}"

    def _parse_examples_from_text(self, text: str) -> List[Tuple[str, str]]:
        """
        Fallback method to parse examples from text if JSON parsing fails.
        """
        examples = []
        lines = text.split('\n')
        
        current_input = None
        for line in lines:
            line = line.strip()
            if line.startswith('"input":') or line.startswith('input:'):
                # Extract input
                start = line.find('"') + 1 if '"' in line else line.find(':') + 1
                end = line.rfind('"') if line.count('"') >= 2 else len(line)
                current_input = line[start:end].strip()
            elif line.startswith('"output":') or line.startswith('output:'):
                # Extract output
                start = line.find('"') + 1 if '"' in line else line.find(':') + 1
                end = line.rfind('"') if line.count('"') >= 2 else len(line)
                output = line[start:end].strip()
                if current_input:
                    examples.append((current_input, output))
                    current_input = None
        
        return examples

    async def generate_and_save_examples(
        self,
        spec: str,
        user_id: str,
        num_examples: int = 5,
        save_to_db: bool = True
    ) -> Tuple[bool, List[Tuple[str, str]], Optional[str], Optional[str]]:
        """
        Generate test examples and optionally save them to the database.
        
        Returns:
            Tuple of (success, [(input, output)...], error_message, spec_id)
        """
        # Generate examples using existing method
        success, examples, error = await self.generate_test_examples(spec, num_examples)
        
        if not success or not examples:
            return success, examples, error, None
        
        spec_id = None
        if save_to_db:
            # Prepare examples for database (add source info)
            examples_with_source = [
                (input_text, output_text, 'gpt') 
                for input_text, output_text in examples
            ]
            
            # Save to simplified database
            try:
                # Save specification first
                spec_id = simple_sql_manager.save_specification(spec)
                
                # Save examples
                for input_text, output_text, source in examples_with_source:
                    simple_sql_manager.save_example(spec_id, input_text, output_text, source)
                
                db_success = True
                db_error = None
            except Exception as e:
                # Still return the examples even if DB save failed
                return True, examples, f"Examples generated but DB save failed: {str(e)}", None
        
        return True, examples, None, spec_id

# Global service instance
gpt_service = GPTService()
