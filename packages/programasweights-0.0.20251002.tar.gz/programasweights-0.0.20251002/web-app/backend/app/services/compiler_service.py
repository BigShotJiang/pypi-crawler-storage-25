import os
import sys
import uuid
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Optional, Tuple

# Add the project root to Python path to import programasweights
project_root = Path(__file__).parent.parent.parent.parent.parent
sys.path.insert(0, str(project_root))

try:
    import programasweights as paw
except ImportError:
    print(f"Warning: Could not import programasweights. Make sure it's installed or project root is correct: {project_root}")
    paw = None

from app.config import settings

class CompilerService:
    def __init__(self):
        self.compiled_models_dir = Path(settings.COMPILED_MODELS_DIR)
        self.temp_dir = Path(settings.TEMP_DIR)
        self.checkpoint_dir = Path(settings.CHECKPOINT_DIR)
        
        # Create directories if they don't exist
        self.compiled_models_dir.mkdir(exist_ok=True)
        self.temp_dir.mkdir(exist_ok=True)

    async def compile_model(
        self,
        spec: str,
        compiler_model: str,
        interpreter_model: str,
        input_examples: str = "",
        output_examples: str = ""
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Compile a specification into a neural program.
        
        Returns:
            Tuple of (success, model_id_or_error, error_message)
        """
        if not paw:
            return False, "ProgramAsWeights library not available", "Import error"
        
        try:
            # Generate unique model ID
            model_id = str(uuid.uuid4())
            paw_file = self.compiled_models_dir / f"{model_id}.paw"
            
            # Use the actual paw.compile() function with trained checkpoint
            print(f"Compiling spec with trained models from: {self.checkpoint_dir}")
            
            try:
                paw.compile(
                    out_path=str(paw_file),
                    spec=spec,
                    checkpoint_dir=str(self.checkpoint_dir)
                )
                print(f"Successfully compiled program to: {paw_file}")
            except Exception as e:
                return False, f"Compilation failed: {str(e)}", str(e)
            
            # Save additional metadata for the web interface
            metadata = {
                "spec": spec,
                "compiler_model": compiler_model,
                "interpreter_model": interpreter_model,
                "input_examples": input_examples,
                "output_examples": output_examples,
                "model_id": model_id,
                "paw_file": str(paw_file)
            }
            
            metadata_file = self.compiled_models_dir / f"{model_id}.json"
            import json
            with open(metadata_file, "w") as f:
                json.dump(metadata, f, indent=2)
            
            return True, model_id, None
            
        except Exception as e:
            return False, str(e), f"Compilation failed: {str(e)}"

    async def create_download_archive(self, model_id: str) -> Optional[Path]:
        """
        Return the .paw file directly for download.
        
        Returns:
            Path to the .paw file or None if not found
        """
        try:
            paw_file = self.compiled_models_dir / f"{model_id}.paw"
            if paw_file.exists():
                return paw_file
            return None
            
        except Exception as e:
            print(f"Error getting download file: {e}")
            return None

    def model_exists(self, model_id: str) -> bool:
        """Check if a compiled model exists."""
        paw_file = self.compiled_models_dir / f"{model_id}.paw"
        return paw_file.exists()

    def get_model_path(self, model_id: str) -> Optional[Path]:
        """Get the path to a compiled .paw file."""
        paw_file = self.compiled_models_dir / f"{model_id}.paw"
        if paw_file.exists():
            return paw_file
        return None

# Global service instance
compiler_service = CompilerService()
