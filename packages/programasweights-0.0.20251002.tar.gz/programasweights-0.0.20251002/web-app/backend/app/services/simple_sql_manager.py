"""
Simplified SQL Manager for ProgramAsWeights
Only handles specifications and input/output examples
"""

import mysql.connector
from mysql.connector import Error
import uuid
from datetime import datetime
from contextlib import contextmanager
from typing import List, Tuple, Optional, Dict, Any
import logging
from app.config import settings

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SimpleSQLManager:
    """Simplified database manager for specifications and examples only."""
    
    def __init__(self):
        """Initialize the database connection and tables."""
        self.db_config = {
            'host': settings.MYSQL_HOST,
            'port': settings.MYSQL_PORT,
            'database': settings.MYSQL_DATABASE,
            'user': settings.MYSQL_USER,
            'password': settings.MYSQL_PASSWORD,
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci',
            'autocommit': True
        }
        
        # Test connection and create tables
        self.init_database()
    
    @contextmanager
    def get_cursor(self):
        """Context manager for database operations."""
        connection = None
        cursor = None
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            yield connection, cursor
        except Error as e:
            logger.error(f"Database error: {e}")
            if connection:
                connection.rollback()
            raise
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()
    
    def init_database(self):
        """Initialize the database with simplified tables."""
        try:
            with self.get_cursor() as (conn, cursor):
                # Create specifications table (simplified)
                try:
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS specifications (
                            id VARCHAR(36) PRIMARY KEY,
                            specification TEXT NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                            
                            INDEX idx_created_at (created_at)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """)
                    logger.info("✅ Specifications table ready")
                except mysql.connector.Error as e:
                    if e.errno == 1050:  # Table already exists
                        logger.info("✅ Specifications table already exists")
                    else:
                        logger.error(f"❌ Error creating specifications table: {e}")
                        raise
                
                # Create input_output_examples table (simplified)
                try:
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS input_output_examples (
                            id BIGINT AUTO_INCREMENT PRIMARY KEY,
                            specification_id VARCHAR(36) NOT NULL,
                            input_text TEXT NOT NULL,
                            output_text TEXT NOT NULL,
                            source ENUM('user', 'gpt') DEFAULT 'user' NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
                            
                            FOREIGN KEY (specification_id) REFERENCES specifications(id) ON DELETE CASCADE,
                            INDEX idx_specification_id (specification_id),
                            INDEX idx_created_at (created_at),
                            INDEX idx_source (source)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """)
                    logger.info("✅ Input_output_examples table ready")
                except mysql.connector.Error as e:
                    if e.errno == 1050:  # Table already exists
                        logger.info("✅ Input_output_examples table already exists")
                    else:
                        logger.error(f"❌ Error creating input_output_examples table: {e}")
                        raise
                
                logger.info("🎉 Database initialization completed successfully")
                
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {e}")
            raise
    
    def save_specification(self, specification: str) -> str:
        """
        Save a specification to the database.
        
        Args:
            specification: The program specification text
            
        Returns:
            str: The ID of the saved specification
        """
        spec_id = str(uuid.uuid4())
        
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    INSERT INTO specifications (id, specification, created_at)
                    VALUES (%s, %s, %s)
                """, (spec_id, specification, datetime.now()))
                
                logger.info(f"✅ Saved specification: {spec_id}")
                return spec_id
                
        except Error as e:
            logger.error(f"❌ Error saving specification: {e}")
            raise
    
    def save_example(self, specification_id: str, input_text: str, output_text: str, source: str = 'user') -> int:
        """
        Save an input/output example to the database.
        
        Args:
            specification_id: ID of the specification this example belongs to
            input_text: The input example
            output_text: The expected output
            source: Source of the example ('user' or 'gpt')
            
        Returns:
            int: The ID of the saved example
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    INSERT INTO input_output_examples (specification_id, input_text, output_text, source, created_at)
                    VALUES (%s, %s, %s, %s, %s)
                """, (specification_id, input_text, output_text, source, datetime.now()))
                
                # Get the ID of the inserted example
                example_id = cursor.lastrowid
                
                logger.info(f"✅ Saved {source} example {example_id} for spec {specification_id}")
                return example_id
                
        except Error as e:
            logger.error(f"❌ Error saving example: {e}")
            raise
    
    def get_specification(self, spec_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specification by ID.
        
        Args:
            spec_id: The specification ID
            
        Returns:
            Dict with specification data or None if not found
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    SELECT id, specification, created_at
                    FROM specifications
                    WHERE id = %s
                """, (spec_id,))
                
                result = cursor.fetchone()
                if result:
                    return {
                        'id': result[0],
                        'specification': result[1],
                        'created_at': result[2]
                    }
                return None
                
        except Error as e:
            logger.error(f"❌ Error getting specification: {e}")
            raise
    
    def get_examples_for_specification(self, spec_id: str) -> List[Dict[str, Any]]:
        """
        Get all examples for a specification.
        
        Args:
            spec_id: The specification ID
            
        Returns:
            List of example dictionaries
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    SELECT id, input_text, output_text, source, created_at
                    FROM input_output_examples
                    WHERE specification_id = %s
                    ORDER BY created_at ASC
                """, (spec_id,))
                
                results = cursor.fetchall()
                examples = []
                for result in results:
                    examples.append({
                        'id': result[0],
                        'input_text': result[1],
                        'output_text': result[2],
                        'source': result[3],
                        'created_at': result[4]
                    })
                
                return examples
                
        except Error as e:
            logger.error(f"❌ Error getting examples: {e}")
            raise
    
    def get_recent_specifications(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent specifications.
        
        Args:
            limit: Maximum number of specifications to return
            
        Returns:
            List of specification dictionaries
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    SELECT s.id, s.specification, s.created_at,
                           COUNT(e.id) as example_count
                    FROM specifications s
                    LEFT JOIN input_output_examples e ON s.id = e.specification_id
                    GROUP BY s.id, s.specification, s.created_at
                    ORDER BY s.created_at DESC
                    LIMIT %s
                """, (limit,))
                
                results = cursor.fetchall()
                specs = []
                for result in results:
                    specs.append({
                        'id': result[0],
                        'specification': result[1],
                        'created_at': result[2],
                        'example_count': result[3]
                    })
                
                return specs
                
        except Error as e:
            logger.error(f"❌ Error getting recent specifications: {e}")
            raise
    
    def get_stats(self) -> Dict[str, int]:
        """
        Get database statistics.
        
        Returns:
            Dictionary with count statistics
        """
        try:
            with self.get_cursor() as (conn, cursor):
                # Count specifications
                cursor.execute("SELECT COUNT(*) FROM specifications")
                spec_count = cursor.fetchone()[0]
                
                # Count examples
                cursor.execute("SELECT COUNT(*) FROM input_output_examples")
                example_count = cursor.fetchone()[0]
                
                return {
                    'total_specifications': spec_count,
                    'total_examples': example_count
                }
                
        except Error as e:
            logger.error(f"❌ Error getting stats: {e}")
            raise
    
    def get_latest_specification(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent specification.
        
        Returns:
            Dictionary with specification data or None if no specs exist
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    SELECT id, specification, created_at
                    FROM specifications
                    ORDER BY created_at DESC
                    LIMIT 1
                """)
                
                result = cursor.fetchone()
                if result:
                    return {
                        'id': result[0],
                        'specification': result[1],
                        'created_at': result[2]
                    }
                return None
                
        except Error as e:
            logger.error(f"❌ Error getting latest specification: {e}")
            raise
    
    def get_latest_examples(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get the most recent input-output examples across all specifications.
        
        Args:
            limit: Maximum number of examples to return
            
        Returns:
            List of example dictionaries with specification info
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("""
                    SELECT 
                        e.id, 
                        e.specification_id, 
                        e.input_text, 
                        e.output_text, 
                        e.source, 
                        e.created_at,
                        s.specification
                    FROM input_output_examples e
                    JOIN specifications s ON e.specification_id = s.id
                    ORDER BY e.created_at DESC
                    LIMIT %s
                """, (limit,))
                
                results = cursor.fetchall()
                examples = []
                for result in results:
                    examples.append({
                        'id': result[0],
                        'specification_id': result[1],
                        'input_text': result[2],
                        'output_text': result[3],
                        'source': result[4],
                        'created_at': result[5],
                        'specification': result[6]
                    })
                
                return examples
                
        except Error as e:
            logger.error(f"❌ Error getting latest examples: {e}")
            raise
    
    def get_latest_spec_with_examples(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent specification with all its examples.
        
        Returns:
            Dictionary with specification and its examples, or None if no specs exist
        """
        try:
            latest_spec = self.get_latest_specification()
            if not latest_spec:
                return None
            
            examples = self.get_examples_for_specification(latest_spec['id'])
            latest_spec['examples'] = examples
            latest_spec['example_count'] = len(examples)
            
            return latest_spec
            
        except Error as e:
            logger.error(f"❌ Error getting latest spec with examples: {e}")
            raise
    
    def health_check(self) -> bool:
        """
        Check if database connection is healthy.
        
        Returns:
            True if healthy, False otherwise
        """
        try:
            with self.get_cursor() as (conn, cursor):
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                return result is not None
        except Exception as e:
            logger.error(f"❌ Database health check failed: {e}")
            return False

# Create a global instance
simple_sql_manager = SimpleSQLManager()
