import os
import sys
from pathlib import Path
from typing import Optional, Tuple

# Add the project root to Python path to import programasweights
project_root = Path(__file__).parent.parent.parent.parent.parent
sys.path.insert(0, str(project_root))

try:
    import programasweights as paw
except ImportError:
    print(f"Warning: Could not import programasweights. Make sure it's installed or project root is correct: {project_root}")
    paw = None

from app.config import settings

class InterpreterService:
    def __init__(self):
        self.checkpoint_dir = Path(settings.CHECKPOINT_DIR)
        self.compiled_models_dir = Path(settings.COMPILED_MODELS_DIR)
        self._interpreters = {}  # Cache for loaded interpreters

    async def test_model(
        self,
        model_id: str,
        input_text: str,
        model_path: Path
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Test a compiled .paw model with the given input.
        
        Returns:
            Tuple of (success, output_or_error, error_message)
        """
        if not paw:
            return False, "ProgramAsWeights library not available", "Import error"
        
        try:
            # Get the interpreter model name from metadata
            interpreter_name = self._get_interpreter_model_name(model_id)
            
            # Load the function from the .paw file
            fn = paw.function(
                path=str(model_path),
                interpreter_name=interpreter_name,
                max_new_tokens=128
            )
            
            # Run the function
            output = fn(input_text)
            
            return True, output, None
            
        except Exception as e:
            return False, str(e), f"Test failed: {str(e)}"

    def _get_interpreter_model_name(self, model_id: str) -> str:
        """
        Get the interpreter model name from the compiled model metadata.
        Falls back to default if not found.
        """
        try:
            # Try to read from metadata.json (web interface metadata)
            import json
            metadata_file = self.compiled_models_dir / f"{model_id}.json"
            if metadata_file.exists():
                with open(metadata_file, "r") as f:
                    data = json.load(f)
                    if "interpreter_model" in data:
                        return data["interpreter_model"]
            
            # Try to read from .paw file metadata
            paw_file = self.compiled_models_dir / f"{model_id}.paw"
            if paw_file.exists():
                from programasweights.paw_format import load_paw_program
                _, metadata = load_paw_program(str(paw_file))
                if "base_model" in metadata:
                    return metadata["base_model"]
            
            # Check if fine-tuned interpreter exists
            finetuned_interpreter = self.checkpoint_dir / "interpreter"
            if finetuned_interpreter.exists():
                return str(finetuned_interpreter)
            
            # Fall back to PAW interpreter
            return "yuntian-deng/paw-interpreter"
            
        except Exception as e:
            print(f"Error getting interpreter model name: {e}")
            return "yuntian-deng/paw-interpreter"

# Global service instance
interpreter_service = InterpreterService()
