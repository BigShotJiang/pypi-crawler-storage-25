"""
Simplified FastAPI application for ProgramAsWeights
Only handles specifications and input/output examples
"""

from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from datetime import datetime
from app.config import settings
from app.models import (
    CompileRequest, CompileResponse,
    TestRequest, TestResponse,
    GenerateTestDataRequest, GenerateTestDataResponse,
    ModelOption, TestExample
)
from app.services.compiler_service import compiler_service
from app.services.interpreter_service import interpreter_service
from app.services.gpt_service import gpt_service
from app.services.simple_sql_manager import simple_sql_manager

app = FastAPI(
    title="ProgramAsWeights API (Simplified)",
    description="Simplified API for compiling and testing neural programs",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_user_id(request: Request) -> str:
    """Simple user identification based on IP and port."""
    client_host = request.client.host if request.client else "unknown"
    client_port = request.client.port if request.client else "unknown"
    return f"{client_host}_{client_port}"

@app.get("/")
async def root():
    return {"message": "ProgramAsWeights Simplified API is running"}

@app.get("/api/models/compiler", response_model=list[ModelOption])
async def get_compiler_models():
    """Get available compiler models."""
    return [ModelOption(**model) for model in settings.COMPILER_MODELS]

@app.get("/api/models/interpreter", response_model=list[ModelOption])
async def get_interpreter_models():
    """Get available interpreter models."""
    return [ModelOption(**model) for model in settings.INTERPRETER_MODELS]

@app.post("/api/compile", response_model=CompileResponse)
async def compile_model(request: CompileRequest, http_request: Request):
    """Compile a specification into a neural program."""
    try:
        user_id = get_user_id(http_request)
        
        # Parse user examples from the request
        user_examples = []
        
        # Parse input examples (assuming they're newline-separated)
        if request.inputExamples.strip():
            input_lines = [line.strip() for line in request.inputExamples.strip().split('\n') if line.strip()]
            output_lines = []
            
            # Parse output examples if provided
            if request.outputExamples.strip():
                output_lines = [line.strip() for line in request.outputExamples.strip().split('\n') if line.strip()]
            
            # Pair inputs with outputs (or empty string if no output)
            for i, input_text in enumerate(input_lines):
                output_text = output_lines[i] if i < len(output_lines) else ""
                user_examples.append((input_text, output_text, "user"))
        
        # Save specification and examples to simplified database
        spec_id = None
        try:
            # Save specification
            spec_id = simple_sql_manager.save_specification(request.spec)
            print(f"✅ Saved specification to database with ID: {spec_id}")
            
            # Save examples if provided
            for input_text, output_text, source in user_examples:
                if input_text.strip() and output_text.strip():
                    example_id = simple_sql_manager.save_example(spec_id, input_text, output_text, source)
                    print(f"✅ Saved {source} example {example_id}")
                
        except Exception as db_e:
            print(f"⚠️ Database save error: {db_e}")
            # Continue with compilation even if DB save fails
        
        # Proceed with compilation
        success, result, error = await compiler_service.compile_model(
            spec=request.spec,
            compiler_model=request.compilerModel,
            interpreter_model=request.interpreterModel,
            input_examples=request.inputExamples,
            output_examples=request.outputExamples
        )
        
        if success:
            model_id = result
            
            download_url = f"/api/download/{model_id}"
            return CompileResponse(
                success=True,
                compiledModelId=model_id,
                downloadUrl=download_url
            )
        else:
            return CompileResponse(
                success=False,
                error=error
            )
            
    except Exception as e:
        return CompileResponse(
            success=False,
            error=f"Unexpected error: {str(e)}"
        )

@app.post("/api/test", response_model=TestResponse)
async def test_model(request: TestRequest):
    """Test a compiled model with inputs."""
    try:
        model_path = compiler_service.get_model_path(request.compiledModelId)
        outputs = []
        for input_text in request.inputs:
            success, output, error = await interpreter_service.test_model(
                model_id=request.compiledModelId,
                input_text=input_text,
                model_path=model_path,
            )
        
        if success:
            outputs.append(output)
        else:
            return TestResponse(
                success=False,
                error=error
            )

        return TestResponse(
                success=True,
                outputs=outputs
        )
            
    except Exception as e:
        print (e)
        return TestResponse(
            success=False,
            error=f"Unexpected error: {str(e)}"
        )

@app.post("/api/generate-test-data", response_model=GenerateTestDataResponse)
async def generate_test_data(request: GenerateTestDataRequest, http_request: Request):
    """Generate test data using GPT."""
    try:
        user_id = get_user_id(http_request)
        success, examples, error, spec_id = await gpt_service.generate_and_save_examples(
            spec=request.spec,
            num_examples=request.numExamples,
            user_id=user_id
        )
        
        if success:
            test_examples = [TestExample(input=inp, output=out) for inp, out in examples]
            return GenerateTestDataResponse(
                success=True,
                examples=test_examples
            )
        else:
            return GenerateTestDataResponse(
                success=False,
                error=error
            )
            
    except Exception as e:
        print (e)
        return GenerateTestDataResponse(
            success=False,
            error=f"Unexpected error: {str(e)}"
        )

@app.get("/api/download/{model_id}")
async def download_model(model_id: str, background_tasks: BackgroundTasks):
    """Download a compiled model as a .paw file."""
    try:
        if not compiler_service.model_exists(model_id):
            raise HTTPException(status_code=404, detail="Model not found")
        
        paw_file_path = compiler_service.get_model_path(model_id)
        if not paw_file_path or not paw_file_path.exists():
            raise HTTPException(status_code=500, detail="Model file not found")
        
        return FileResponse(
            path=str(paw_file_path),
            filename=f"{model_id}.paw",
            media_type="application/octet-stream"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download error: {str(e)}")

# Simplified API endpoints for specifications and examples
@app.get("/api/specifications/stats")
async def get_specifications_stats():
    """Get statistics about specifications and examples."""
    try:
        stats = simple_sql_manager.get_stats()
        return {
            "success": True,
            "data": stats
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/specifications/recent")
async def get_recent_specifications():
    """Get recent specifications with their examples."""
    try:
        specs = simple_sql_manager.get_recent_specifications(limit=10)
        
        # Add example count and preview for each spec
        for spec in specs:
            examples = simple_sql_manager.get_examples_for_specification(spec['id'])
            spec['examples'] = examples[:3]  # First 3 examples as preview
            spec['total_examples'] = len(examples)
        
        return {
            "success": True,
            "data": specs
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/specifications/{spec_id}")
async def get_specification_detail(spec_id: str):
    """Get detailed information about a specific specification."""
    try:
        spec = simple_sql_manager.get_specification(spec_id)
        if not spec:
            return {
                "success": False,
                "error": "Specification not found"
            }
        
        examples = simple_sql_manager.get_examples_for_specification(spec_id)
        spec['examples'] = examples
        
        return {
            "success": True,
            "data": spec
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/latest/specification")
async def get_latest_specification():
    """Get the most recent specification."""
    try:
        spec = simple_sql_manager.get_latest_specification()
        return {
            "success": True,
            "data": spec
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/latest/examples")
async def get_latest_examples(limit: int = 10):
    """Get the most recent input-output examples across all specifications."""
    try:
        examples = simple_sql_manager.get_latest_examples(limit)
        return {
            "success": True,
            "data": examples
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/latest/spec-with-examples")
async def get_latest_spec_with_examples():
    """Get the most recent specification with all its examples."""
    try:
        spec_with_examples = simple_sql_manager.get_latest_spec_with_examples()
        return {
            "success": True,
            "data": spec_with_examples
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    db_healthy = simple_sql_manager.health_check()
    return {
        "status": "healthy" if db_healthy else "unhealthy",
        "database": "connected" if db_healthy else "disconnected",
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
