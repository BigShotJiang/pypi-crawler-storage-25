import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # OpenAI API key for test data generation
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    
    # Path to your trained models checkpoint directory
    CHECKPOINT_DIR: str = os.getenv("CHECKPOINT_DIR", "../../outputs/prefix_kv/checkpoint")
    
    # Directory to store compiled models
    COMPILED_MODELS_DIR: str = os.getenv("COMPILED_MODELS_DIR", "./compiled_models")
    
    # Temporary directory for file operations
    TEMP_DIR: str = os.getenv("TEMP_DIR", "./temp")
    
    # MySQL Database Configuration
    MYSQL_HOST: str = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_PORT: int = int(os.getenv("MYSQL_PORT", "3306"))
    MYSQL_DATABASE: str = os.getenv("MYSQL_DATABASE", "programasweights")
    MYSQL_USER: str = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD: str = os.getenv("MYSQL_PASSWORD", "password")
    
    # CORS settings
    ALLOWED_ORIGINS: list = [
        "http://localhost:5173",  # Vite dev server
        "http://localhost:3000",  # Alternative React dev server
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ]
    
    # Available models configuration - use trained checkpoint models
    COMPILER_MODELS = [
        {
            "id": "../../outputs/prefix_kv/checkpoint/compiler",
            "name": "Trained Compiler (Recommended)",
            "description": "Your trained compiler model optimized for neural programs"
        },
        {
            "id": "Qwen/Qwen3-0.6B",
            "name": "Qwen 3 0.6B (Base)",
            "description": "Base compiler model (not trained)"
        }
    ]
    
    INTERPRETER_MODELS = [
        {
            "id": "../../outputs/prefix_kv/checkpoint/interpreter",
            "name": "Trained Interpreter (Recommended)",
            "description": "Your trained interpreter model optimized for neural programs"
        },
        {
            "id": "yuntian-deng/paw-interpreter",
            "name": "PAW Interpreter",
            "description": "PAW Interpreter model"
        },
    ]

settings = Settings()
