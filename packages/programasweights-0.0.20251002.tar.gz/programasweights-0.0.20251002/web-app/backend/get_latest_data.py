#!/usr/bin/env python3
"""
Script to get the latest input-output examples and specifications
from the ProgramAsWeights database
"""

import requests
import json
from datetime import datetime
import mysql.connector
from mysql.connector import Error
import os

API_BASE = "http://localhost:8000/api"

def get_latest_specification():
    """Get the most recent specification."""
    try:
        response = requests.get(f"{API_BASE}/latest/specification")
        data = response.json()
        
        if data['success'] and data['data']:
            spec = data['data']
            print("📄 LATEST SPECIFICATION:")
            print(f"   ID: {spec['id']}")
            print(f"   Created: {spec['created_at']}")
            print(f"   Text: {spec['specification'][:100]}...")
            return spec
        else:
            print("❌ No specifications found")
            return None
    except Exception as e:
        print(f"❌ Error getting latest specification: {e}")
        return None

def get_latest_examples(limit=5):
    """Get the most recent input-output examples."""
    try:
        response = requests.get(f"{API_BASE}/latest/examples?limit={limit}")
        data = response.json()
        
        if data['success']:
            examples = data['data']
            print(f"\n💡 LATEST {len(examples)} EXAMPLES:")
            for i, ex in enumerate(examples, 1):
                source_icon = "👤" if ex['source'] == 'user' else "🤖"
                print(f"   {i}. {source_icon} Example {ex['id']} ({ex['source']}) - {ex['created_at']}")
                print(f"      Spec: {ex['specification'][:60]}...")
                print(f"      Input: {ex['input_text'][:80]}...")
                print(f"      Output: {ex['output_text'][:80]}...")
                print()
            return examples
        else:
            print("❌ No examples found")
            return []
    except Exception as e:
        print(f"❌ Error getting latest examples: {e}")
        return []

def get_latest_spec_with_examples():
    """Get the most recent specification with all its examples."""
    try:
        response = requests.get(f"{API_BASE}/latest/spec-with-examples")
        data = response.json()
        
        if data['success'] and data['data']:
            spec = data['data']
            print(f"\n🎯 LATEST SPEC WITH ALL EXAMPLES:")
            print(f"   Spec ID: {spec['id']}")
            print(f"   Created: {spec['created_at']}")
            print(f"   Text: {spec['specification']}")
            print(f"   Example Count: {spec['example_count']}")
            
            if spec['examples']:
                print("   Examples:")
                for ex in spec['examples']:
                    source_icon = "👤" if ex['source'] == 'user' else "🤖"
                    print(f"     • {source_icon} {ex['input_text'][:50]}... → {ex['output_text'][:50]}...")
            
            return spec
        else:
            print("❌ No specifications with examples found")
            return None
    except Exception as e:
        print(f"❌ Error getting latest spec with examples: {e}")
        return None

def get_database_stats():
    """Get database statistics."""
    try:
        response = requests.get(f"{API_BASE}/specifications/stats")
        data = response.json()
        
        if data['success']:
            stats = data['data']
            print(f"📊 DATABASE STATS:")
            print(f"   Total Specifications: {stats['total_specifications']}")
            print(f"   Total Examples: {stats['total_examples']}")
            return stats
        else:
            print("❌ Could not get database stats")
            return None
    except Exception as e:
        print(f"❌ Error getting database stats: {e}")
        return None

def export_training_data_to_jsonl(start_timestamp: str, end_timestamp: str, output_file: str):
    """
    Export training data between two timestamps to JSONL format.
    
    Args:
        start_timestamp: Start timestamp in format 'YYYY-MM-DD HH:MM:SS'
        end_timestamp: End timestamp in format 'YYYY-MM-DD HH:MM:SS'
        output_file: Path to output JSONL file
    """
    # Database configuration (should match your app settings)
    db_config = {
        'host': '127.0.0.1',
        'user': 'paw',
        'password': 'k4pe110s!',
        'database': 'programasweights',
        'charset': 'utf8mb4',
        'collation': 'utf8mb4_unicode_ci'
    }
    
    try:
        # Connect to database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        print(f"Exporting training data from {start_timestamp} to {end_timestamp}")
        print(f"Output file: {output_file}")
        
        # Query to get specifications with their examples in the time range
        query = """
        SELECT 
            s.id as spec_id,
            s.specification,
            s.created_at as spec_created_at,
            GROUP_CONCAT(
                CONCAT(
                    '{"input":"', REPLACE(REPLACE(e.input_text, '"', '\\"'), '\n', '\\n'), '",',
                    '"output":"', REPLACE(REPLACE(e.output_text, '"', '\\"'), '\n', '\\n'), '",',
                    '"source":"', e.source, '",',
                    '"created_at":"', e.created_at, '"}'
                )
                SEPARATOR '|||'
            ) as examples_json
        FROM specifications s
        LEFT JOIN input_output_examples e ON s.id = e.specification_id
        WHERE (s.created_at BETWEEN %s AND %s) 
           OR (e.created_at BETWEEN %s AND %s)
        GROUP BY s.id, s.specification, s.created_at
        HAVING examples_json IS NOT NULL
        ORDER BY s.created_at
        """
        
        cursor.execute(query, (start_timestamp, end_timestamp, start_timestamp, end_timestamp))
        results = cursor.fetchall()
        
        print(f"Found {len(results)} specifications with examples in the time range")
        
        # Process results and group by specification, deduplicating pairs
        spec_groups = {}  # spec_text -> set of (input, output) tuples
        
        for row in results:
            # Normalize specification text more thoroughly
            spec_text = row['specification'].strip().rstrip('.')  # Remove trailing periods and whitespace
            examples_str = row['examples_json']
            
            if not examples_str:
                continue
                
            # Initialize spec group if not exists
            if spec_text not in spec_groups:
                spec_groups[spec_text] = set()
                
            # Parse the concatenated examples
            example_parts = examples_str.split('|||')
            
            for example_str in example_parts:
                try:
                    example_data = json.loads(example_str)
                    input_text = example_data['input'].strip()
                    output_text = example_data['output'].strip()
                    
                    # Add to set (automatically deduplicates)
                    spec_groups[spec_text].add((input_text, output_text))
                except json.JSONDecodeError:
                    continue
        
        # Convert grouped data to training entries
        training_entries = []
        for spec_text, pairs_set in spec_groups.items():
            if pairs_set:  # Only if we have pairs
                # Convert set back to separate lists
                inputs = []
                outputs = []
                for input_text, output_text in sorted(pairs_set):  # Sort for consistent ordering
                    inputs.append(input_text)
                    outputs.append(output_text)
                
                training_entry = {
                    "spec": spec_text,
                    "inputs": inputs,
                    "outputs": outputs
                }
                training_entries.append(training_entry)
        
        # Write to JSONL file
        os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else '.', exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for entry in training_entries:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        
        print(f"Successfully exported {len(training_entries)} training entries to {output_file}")
        
        # Print detailed statistics
        total_pairs = sum(len(entry['inputs']) for entry in training_entries)
        total_unique_specs = len(spec_groups)
        print(f"Unique specifications: {total_unique_specs}")
        print(f"Total unique input-output pairs: {total_pairs}")
        
        # Show pairs per specification
        for i, entry in enumerate(training_entries, 1):
            pairs_count = len(entry['inputs'])
            spec_preview = entry['spec'][:60] + "..." if len(entry['spec']) > 60 else entry['spec']
            print(f"  {i}. {pairs_count} pairs - {spec_preview}")
        
        return training_entries
        
    except Error as e:
        print(f"Database error: {e}")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()
            print("🔒 Database connection closed")

def main():
    """Main function to demonstrate all endpoints."""
    print("Getting Latest Data from ProgramAsWeights Database")
    print("=" * 70)
    
    # Get database stats
    # get_database_stats()
    # print()
    
    # # Get latest specification
    # get_latest_specification()
    
    # # Get latest examples
    # get_latest_examples(limit=3)
    
    # # Get latest spec with examples
    # get_latest_spec_with_examples()
    
    # print("\n" + "=" * 70)
    # print("✅ Data retrieval complete!")
    
    export_training_data_to_jsonl(
        start_timestamp='2024-01-01 00:00:00',
        end_timestamp='2025-12-31 23:59:59',
        output_file='training_db_data.jsonl'
    )

if __name__ == "__main__":
    main()
