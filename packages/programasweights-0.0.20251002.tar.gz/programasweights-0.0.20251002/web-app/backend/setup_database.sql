-- MySQL setup script for ProgramAsWeights (Simplified Schema)
-- Run this script to create the database and tables

-- Create database
CREATE DATABASE IF NOT EXISTS programasweights 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- Create a dedicated user (optional but recommended)
CREATE USER IF NOT EXISTS 'paw_user'@'localhost' IDENTIFIED BY 'paw_password_123';

-- Grant privileges
GRANT ALL PRIVILEGES ON programasweights.* TO 'paw_user'@'localhost';

-- Refresh privileges
FLUSH PRIVILEGES;

-- Use the database
USE programasweights;

-- Drop old complex tables if they exist
DROP TABLE IF EXISTS votes;
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS programs;
DROP TABLE IF EXISTS example_feedback;
DROP TABLE IF EXISTS compilation_sessions;

-- Create simplified schema
-- Only two tables: specifications and input_output_examples

-- Create specifications table (simplified)
CREATE TABLE IF NOT EXISTS specifications (
    id VARCHAR(36) PRIMARY KEY,
    specification TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create input_output_examples table (simplified)
CREATE TABLE IF NOT EXISTS input_output_examples (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    specification_id VARCHAR(36) NOT NULL,
    input_text TEXT NOT NULL,
    output_text TEXT NOT NULL,
    source ENUM('user', 'gpt') DEFAULT 'user' NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    FOREIGN KEY (specification_id) REFERENCES specifications(id) ON DELETE CASCADE,
    INDEX idx_specification_id (specification_id),
    INDEX idx_created_at (created_at),
    INDEX idx_source (source)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Show final schema
SHOW TABLES;
DESCRIBE specifications;
DESCRIBE input_output_examples;
