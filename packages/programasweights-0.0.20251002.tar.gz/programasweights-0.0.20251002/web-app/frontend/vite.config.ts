import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    extensions: ['.js', '.ts', '.jsx', '.tsx', '.json']
  },
  esbuild: {
    target: 'esnext',
    format: 'esm'
  },
  server: {
    allowedHosts: ['programasweights.com', 'www.programasweights.com'],
  }
})
