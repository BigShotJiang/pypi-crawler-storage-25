import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import SpecInput from './SpecInput';
import AutoTestSection from './AutoTestSection';
import CopyCodeSection from './CopyCodeSection';
import { apiClient } from '../utils/api';

interface ModelOption {
  id: string;
  name: string;
  description: string;
}

interface TestCase {
  id: string;
  input: string;
  output: string;
  editable: boolean;
}

interface ExampleRow {
  id: string;
  input: string;
  output: string;
}

const MainInterface: React.FC = () => {
  // Model options
  const [compilerModels, setCompilerModels] = useState<ModelOption[]>([]);
  const [interpreterModels, setInterpreterModels] = useState<ModelOption[]>([]);
  const [loadingModels, setLoadingModels] = useState(true);

  // Form state
  const [compilerModel, setCompilerModel] = useState('');
  const [interpreterModel, setInterpreterModel] = useState('');
  const [spec, setSpec] = useState('Parse a string like "(A) ... (B) ... (C) ..." into a JSON list of options. Be robust to noise: extra spaces, bullets, and phrases like "both (A) and (B)".');
  const [examples, setExamples] = useState<ExampleRow[]>([
    { id: '1', input: '', output: '' }
  ]);

  // Compilation state
  const [compiling, setCompiling] = useState(false);
  const [compiled, setCompiled] = useState(false);
  const [compiledModelId, setCompiledModelId] = useState('');

  // Testing state
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [generatingTests, setGeneratingTests] = useState(false);
  const [runningTests, setRunningTests] = useState(false);

  // Load available models on component mount
  useEffect(() => {
    const loadModels = async () => {
      try {
        const [compilerOpts, interpreterOpts] = await Promise.all([
          apiClient.getCompilerModels(),
          apiClient.getInterpreterModels()
        ]);
        
        setCompilerModels(compilerOpts);
        setInterpreterModels(interpreterOpts);
        
        // Set default selections
        if (compilerOpts.length > 0) {
          setCompilerModel(compilerOpts[0].id);
        }
        if (interpreterOpts.length > 0) {
          setInterpreterModel(interpreterOpts[0].id);
        }
      } catch (error) {
        toast.error('Failed to load available models');
        console.error('Error loading models:', error);
      } finally {
        setLoadingModels(false);
      }
    };

    loadModels();
  }, []);

  // Auto-generate and run test cases after successful compilation
  useEffect(() => {
    if (compiled && compiledModelId && spec.trim()) {
      generateAndRunTestCases();
    }
  }, [compiled, compiledModelId]);

  const generateAndRunTestCases = async () => {
    setGeneratingTests(true);
    try {
      // 1. Generate test inputs with GPT-5-mini
      const response = await apiClient.generateTestData({
        spec,
        numExamples: 1  // Only generate 1 test case for simplicity
      });

      if (response.success) {
        const testInputs = response.examples.map(ex => ex.input);
        
        // 2. Run through compiled program
        setRunningTests(true);
        const testResponse = await apiClient.testModel({
          compiledModelId,
          inputs: testInputs
        });

        if (testResponse.success) {
          const cases: TestCase[] = testInputs.map((input, i) => ({
            id: `test_${i}`,
            input,
            output: testResponse.outputs?.[i] || '',
            editable: true
          }));
          setTestCases(cases);
          toast.success('Generated and ran test case!');
        } else {
          toast.error('Failed to run test case');
        }
      } else {
        toast.error('Failed to generate test case');
      }
    } catch (error) {
      toast.error('Error generating test case');
      console.error('Error:', error);
    } finally {
      setGeneratingTests(false);
      setRunningTests(false);
    }
  };

  const handleCompile = async () => {
    if (!spec.trim()) {
      toast.error('Please enter a program specification');
      return;
    }
    if (!compilerModel || !interpreterModel) {
      toast.error('Please select both compiler and interpreter models');
      return;
    }

    setCompiling(true);
    setCompiled(false);
    setTestCases([]);
    
    try {
      // Convert examples to the expected format
      const validExamples = examples.filter(ex => ex.input.trim() && ex.output.trim());
      const inputExamples = validExamples.map(ex => ex.input).join('\n');
      const outputExamples = validExamples.map(ex => ex.output).join('\n');

      const response = await apiClient.compileModel({
        spec,
        compilerModel,
        interpreterModel,
        inputExamples,
        outputExamples
      });

      if (response.success) {
        setCompiled(true);
        setCompiledModelId(response.compiledModelId);
        toast.success('Program compiled successfully!');
      } else {
        toast.error(response.error || 'Compilation failed');
      }
    } catch (error) {
      toast.error('Error during compilation');
      console.error('Compilation error:', error);
    } finally {
      setCompiling(false);
    }
  };

  const handleTestEdit = async (testId: string, newInput: string) => {
    if (!compiledModelId) return;

    // Update the test case input
    setTestCases(prev => prev.map(tc => 
      tc.id === testId ? { ...tc, input: newInput } : tc
    ));

    // Re-run this specific test
    try {
      const response = await apiClient.testModel({
        compiledModelId,
        inputs: [newInput]
      });

      if (response.success) {
        setTestCases(prev => prev.map(tc => 
          tc.id === testId ? { ...tc, output: response.outputs?.[0] || '' } : tc
        ));
      }
    } catch (error) {
      console.error('Error re-running test:', error);
    }
  };

  const canCompile = spec.trim() && compilerModel && interpreterModel && !loadingModels;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* 1. UNIFIED SPECIFICATION AND COMPILE SECTION */}
      <SpecInput
        value={spec}
        onChange={setSpec}
        examples={examples}
        onExamplesChange={setExamples}
        placeholder="Describe what you want your program to do. For example: 'Parse a string like (A) ... (B) ... (C) into a JSON list of options. Be robust to noise and variations.'"
        prominent={true}
        onCompile={handleCompile}
        compiling={compiling}
        canCompile={canCompile}
        compilerModels={compilerModels}
        interpreterModels={interpreterModels}
        compilerModel={compilerModel}
        interpreterModel={interpreterModel}
        onCompilerModelChange={setCompilerModel}
        onInterpreterModelChange={setInterpreterModel}
        loadingModels={loadingModels}
      />

      {/* 2. AUTO-TEST - Only after compile */}
      {compiled && (
        <AutoTestSection
          testCases={testCases}
          onTestEdit={handleTestEdit}
          generatingTests={generatingTests}
          runningTests={runningTests}
          onRegenerateTests={generateAndRunTestCases}
        />
      )}

      {/* 3. COPY CODE - Final CTA */}
      {compiled && testCases.length > 0 && (
        <CopyCodeSection
          programId={compiledModelId}
          exampleInput={testCases[0]?.input}
          expectedOutput={testCases[0]?.output}
        />
      )}
    </div>
  );
};

export default MainInterface;
