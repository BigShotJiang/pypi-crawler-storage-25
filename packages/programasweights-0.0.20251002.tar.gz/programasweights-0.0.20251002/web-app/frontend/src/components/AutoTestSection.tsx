import React from 'react';
import { Play, RefreshCw, Edit3, Loader2 } from 'lucide-react';

interface TestCase {
  id: string;
  input: string;
  output: string;
  editable: boolean;
}

interface AutoTestSectionProps {
  testCases: TestCase[];
  onTestEdit: (testId: string, newInput: string) => void;
  generatingTests: boolean;
  runningTests: boolean;
  onRegenerateTests: () => void;
}

const AutoTestSection: React.FC<AutoTestSectionProps> = ({
  testCases,
  onTestEdit,
  generatingTests,
  runningTests,
  onRegenerateTests
}) => {
  const handleInputChange = (testId: string, newInput: string) => {
    onTestEdit(testId, newInput);
  };

  if (generatingTests) {
    return (
      <div className="card p-6">
        <div className="flex items-center justify-center space-x-3 py-8">
          <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
          <span className="text-lg text-gray-700">Generating test cases...</span>
        </div>
      </div>
    );
  }

  // Show only the first test case to keep it compact
  const firstTestCase = testCases[0];

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-900">Test Your Program</h3>
        <button
          onClick={onRegenerateTests}
          disabled={generatingTests || runningTests}
          className="flex items-center space-x-2 px-3 py-2 text-sm bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${runningTests ? 'animate-spin' : ''}`} />
          <span>New Test</span>
        </button>
      </div>

      <p className="text-gray-600 mb-4">
        We generated a test case and ran it through your program. Edit the input to see how it responds.
      </p>

      {firstTestCase ? (
        <div className="border border-gray-200 rounded-lg p-4 bg-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input - Editable */}
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <label className="text-sm font-medium text-gray-700">Input</label>
                <Edit3 className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-400">editable</span>
              </div>
              <textarea
                value={firstTestCase.input}
                onChange={(e) => handleInputChange(firstTestCase.id, e.target.value)}
                className="w-full border border-gray-300 rounded p-3 text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent overflow-hidden"
                placeholder="Enter test input..."
                style={{
                  minHeight: '60px',
                  maxHeight: '120px',
                  height: Math.max(60, Math.min(120, (firstTestCase.input.split('\n').length * 20) + 24))
                }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = Math.min(120, Math.max(60, target.scrollHeight)) + 'px';
                }}
              />
            </div>
            
            {/* Output - Read-only, updates automatically */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Neural Program Output
              </label>
              <div className="relative">
                <textarea
                  value={firstTestCase.output}
                  readOnly
                  className="w-full border border-gray-200 rounded p-3 text-sm bg-gray-50 resize-none overflow-hidden"
                  placeholder="Output will appear here..."
                  style={{
                    minHeight: '60px',
                    maxHeight: '120px',
                    height: Math.max(60, Math.min(120, (firstTestCase.output.split('\n').length * 20) + 24))
                  }}
                />
                {runningTests && (
                  <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center rounded">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-6 text-gray-500">
          <Play className="w-8 h-8 mx-auto mb-2 text-gray-300" />
          <p>Test case will appear here after compilation</p>
        </div>
      )}
    </div>
  );
};

export default AutoTestSection; 