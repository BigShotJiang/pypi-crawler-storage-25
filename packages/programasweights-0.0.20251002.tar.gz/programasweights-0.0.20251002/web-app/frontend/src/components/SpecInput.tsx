import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Plus, Trash2, Settings, Zap } from 'lucide-react';
import ModelSelector from './ModelSelector';

interface ExampleRow {
  id: string;
  input: string;
  output: string;
}

interface ModelOption {
  id: string;
  name: string;
  description: string;
}

interface SpecInputProps {
  value: string;
  onChange: (value: string) => void;
  examples: ExampleRow[];
  onExamplesChange: (examples: ExampleRow[]) => void;
  placeholder?: string;
  prominent?: boolean;
  // Compile functionality
  onCompile: () => void;
  compiling: boolean;
  canCompile: boolean;
  compilerModels: ModelOption[];
  interpreterModels: ModelOption[];
  compilerModel: string;
  interpreterModel: string;
  onCompilerModelChange: (value: string) => void;
  onInterpreterModelChange: (value: string) => void;
  loadingModels: boolean;
}

const SpecInput: React.FC<SpecInputProps> = ({ 
  value, 
  onChange, 
  examples,
  onExamplesChange,
  placeholder = "Describe what you want your program to do...",
  prominent = false,
  onCompile,
  compiling,
  canCompile,
  compilerModels,
  interpreterModels,
  compilerModel,
  interpreterModel,
  onCompilerModelChange,
  onInterpreterModelChange,
  loadingModels
}) => {
  const [showExamples, setShowExamples] = useState(false);
  const [showModels, setShowModels] = useState(false);

  const addExample = () => {
    const newExample: ExampleRow = {
      id: Date.now().toString(),
      input: '',
      output: ''
    };
    onExamplesChange([...examples, newExample]);
  };

  const removeExample = (id: string) => {
    if (examples.length > 1) {
      onExamplesChange(examples.filter(ex => ex.id !== id));
    }
  };

  const updateExample = (id: string, field: 'input' | 'output', value: string) => {
    onExamplesChange(
      examples.map(ex => 
        ex.id === id ? { ...ex, [field]: value } : ex
      )
    );
  };

  const validExamples = examples.filter(ex => ex.input.trim() && ex.output.trim());

  return (
    <div className="card p-6">
      <h2 className={`font-bold text-gray-900 mb-4 ${prominent ? 'text-2xl' : 'text-xl'}`}>
        Program Specification
      </h2>
      <p className="text-gray-600 mb-4">
        Describe your program. It will take a string input and return a string output.
      </p>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full border border-gray-300 rounded-lg p-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none overflow-hidden ${
          prominent ? 'text-lg' : ''
        }`}
        style={{
          minHeight: prominent ? '80px' : '60px',
          maxHeight: '120px',
          height: Math.max(
            prominent ? 80 : 60,
            Math.min(120, (value.split('\n').length * 24) + 32)
          )
        }}
        onInput={(e) => {
          const target = e.target as HTMLTextAreaElement;
          target.style.height = 'auto';
          target.style.height = Math.min(120, Math.max(prominent ? 80 : 60, target.scrollHeight)) + 'px';
        }}
      />

      {/* Examples Section - Integrated (closer to specification) */}
      <div className="mt-4 pt-3">
        <button
          onClick={() => setShowExamples(!showExamples)}
          className="flex items-center justify-between w-full text-left"
        >
          <div className="flex items-center space-x-2">
            {showExamples ? (
              <ChevronDown className="w-4 h-4 text-gray-500" />
            ) : (
              <ChevronRight className="w-4 h-4 text-gray-500" />
            )}
            <span className="text-sm font-medium text-gray-700">
              Add Examples
            </span>
            {validExamples.length > 0 && (
              <span className="text-xs text-gray-500">
                ({validExamples.length} examples)
              </span>
            )}
          </div>
          <span className="text-xs text-gray-400">Optional</span>
        </button>

        {showExamples && (
          <div className="mt-3 space-y-3">
            <p className="text-xs text-gray-600">
              Provide examples to help clarify your program's expected behavior.
            </p>
            
            {examples.map((example, index) => (
              <div key={example.id} className="border border-gray-200 rounded p-3 bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-gray-700">
                    Example {index + 1}
                  </span>
                  {examples.length > 1 && (
                    <button
                      onClick={() => removeExample(example.id)}
                      className="text-red-500 hover:text-red-700 p-1"
                      title="Remove example"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Input
                    </label>
                    <textarea
                      value={example.input}
                      onChange={(e) => updateExample(example.id, 'input', e.target.value)}
                      placeholder="Example input..."
                      className="w-full border border-gray-300 rounded p-2 text-xs resize-none overflow-hidden"
                      style={{
                        minHeight: '40px',
                        maxHeight: '80px',
                        height: Math.max(40, Math.min(80, (example.input.split('\n').length * 16) + 16))
                      }}
                      onInput={(e) => {
                        const target = e.target as HTMLTextAreaElement;
                        target.style.height = 'auto';
                        target.style.height = Math.min(80, Math.max(40, target.scrollHeight)) + 'px';
                      }}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">
                      Expected Output
                    </label>
                    <textarea
                      value={example.output}
                      onChange={(e) => updateExample(example.id, 'output', e.target.value)}
                      placeholder="Expected output..."
                      className="w-full border border-gray-300 rounded p-2 text-xs resize-none overflow-hidden"
                      style={{
                        minHeight: '40px',
                        maxHeight: '80px',
                        height: Math.max(40, Math.min(80, (example.output.split('\n').length * 16) + 16))
                      }}
                      onInput={(e) => {
                        const target = e.target as HTMLTextAreaElement;
                        target.style.height = 'auto';
                        target.style.height = Math.min(80, Math.max(40, target.scrollHeight)) + 'px';
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
            
            <button
              onClick={addExample}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-xs font-medium"
            >
              <Plus className="w-3 h-3" />
              <span>Add Example</span>
            </button>
          </div>
        )}
      </div>

      {/* Compile Section - Integrated */}
      <div className="mt-6 border-t border-gray-200 pt-6">
        <div className="flex items-center justify-center space-x-4">
          <button
            onClick={onCompile}
            disabled={!canCompile || compiling}
            className={`
              inline-flex items-center space-x-3 px-8 py-4 text-lg font-semibold rounded-lg
              transition-all duration-200 transform hover:scale-105
              ${canCompile && !compiling
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }
            `}
          >
            <Zap className={`w-6 h-6 ${compiling ? 'animate-spin' : ''}`} />
            <span>
              {compiling ? 'Compiling Neural Program...' : 'Compile Neural Program'}
            </span>
          </button>

          <button
            onClick={() => setShowModels(!showModels)}
            className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Models</span>
            {showModels ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </button>
        </div>

        {!canCompile && !loadingModels && (
          <p className="text-sm text-gray-500 text-center mt-2">
            Enter a program specification to compile
          </p>
        )}

        {/* Model Configuration */}
        {showModels && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg">
            <ModelSelector
              label="Compiler Model"
              options={compilerModels}
              value={compilerModel}
              onChange={onCompilerModelChange}
              loading={loadingModels}
              placeholder="Select compiler model..."
            />
            <ModelSelector
              label="Interpreter Model"
              options={interpreterModels}
              value={interpreterModel}
              onChange={onInterpreterModelChange}
              loading={loadingModels}
              placeholder="Select interpreter model..."
            />
            <div className="md:col-span-2">
              <p className="text-xs text-gray-500">
                The compiler translates your specification into neural weights. 
                The interpreter executes those weights.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SpecInput;
