import React, { useState } from 'react';
import { Copy, Check, Download } from 'lucide-react';
import toast from 'react-hot-toast';

interface CopyCodeSectionProps {
  programId: string;
  exampleInput: string;
  expectedOutput: string;
}

const CopyCodeSection: React.FC<CopyCodeSectionProps> = ({
  programId,
  exampleInput,
  expectedOutput
}) => {
  const [copied, setCopied] = useState(false);
  const [programIdCopied, setProgramIdCopied] = useState(false);
  const [localCodeCopied, setLocalCodeCopied] = useState(false);

  const escapeForPython = (str: string): string => {
    return JSON.stringify(str);  // This handles all escaping including newlines, quotes, etc.
  };

  const codeSnippet = `import programasweights as paw

# Load your compiled neural program
fn = paw.function("${programId}")

# Use it like any Python function
output = fn(${escapeForPython(exampleInput)})
print(output)

# Expected output:
# ${escapeForPython(expectedOutput)}`;

  const localCodeSnippet = `import programasweights as paw

# Load from downloaded file
fn = paw.function("./${programId}.paw")

# Use it like any Python function
output = fn(${escapeForPython(exampleInput)})
print(output)`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(codeSnippet);
      setCopied(true);
      toast.success('Code copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy code');
    }
  };

  const handleLocalCodeCopy = async () => {
    try {
      await navigator.clipboard.writeText(localCodeSnippet);
      setLocalCodeCopied(true);
      toast.success('Local code copied!');
      setTimeout(() => setLocalCodeCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy code');
    }
  };

  const handleInstallCopy = async () => {
    const installCommand = 'pip install programasweights';
    try {
      await navigator.clipboard.writeText(installCommand);
      toast.success('Install command copied!');
    } catch (error) {
      toast.error('Failed to copy install command');
    }
  };

  const handleProgramIdCopy = async () => {
    try {
      await navigator.clipboard.writeText(programId);
      setProgramIdCopied(true);
      toast.success('Program ID copied!');
      setTimeout(() => setProgramIdCopied(false), 2000);
    } catch (error) {
      toast.error('Failed to copy program ID');
    }
  };

  const handleDownload = async () => {
    try {
      // Use the API download endpoint
      const downloadUrl = `/api/download/${programId}`;
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `${programId}.paw`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast.success('Download started!');
    } catch (error) {
      toast.error('Failed to download program');
    }
  };

  return (
    <div className="card p-6 bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
      <div className="flex items-center space-x-3 mb-4">
        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
          <Check className="w-5 h-5 text-white" />
        </div>
        <h3 className="text-xl font-bold text-gray-900">Your Program is Ready!</h3>
      </div>

      <p className="text-gray-700 mb-6">
        Your program has been compiled and tested. Use it in your Python code:
      </p>

      {/* Installation Step */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-800 mb-2">1. Install ProgramAsWeights</h4>
        <div className="flex items-center space-x-2">
          <code className="flex-1 bg-gray-100 px-3 py-2 rounded text-sm font-mono">
            pip install programasweights
          </code>
          <button
            onClick={handleInstallCopy}
            className="flex items-center space-x-1 px-3 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded transition-colors"
          >
            <Copy className="w-4 h-4" />
            <span>Copy</span>
          </button>
        </div>
      </div>

      {/* Usage Code */}
      <div className="mb-4">
        <h4 className="text-sm font-semibold text-gray-800 mb-1">2. Use Your Program</h4>
        <p className="text-xs text-gray-600 mb-2">Runs locally - no API calls or internet required (after initial download)</p>
        <div className="relative">
          <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
            <code>{codeSnippet}</code>
          </pre>
          <button
            onClick={handleCopy}
            className={`absolute top-3 right-3 flex items-center space-x-2 px-3 py-1.5 rounded text-sm transition-all ${
              copied 
                ? 'bg-green-600 text-white' 
                : 'bg-gray-700 hover:bg-gray-600 text-gray-200'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Code</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Program ID - Copyable */}
      <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-blue-800">
              <strong>Program ID:</strong> <code className="bg-blue-100 px-1 rounded">{programId}</code>
            </p>
            <p className="text-xs text-blue-600 mt-1">
              This program is hosted and will be downloaded automatically when first used.
            </p>
          </div>
          <button
            onClick={handleProgramIdCopy}
            className={`flex items-center space-x-1 px-2 py-1 text-xs rounded transition-all ${
              programIdCopied
                ? 'bg-green-600 text-white'
                : 'bg-blue-200 hover:bg-blue-300 text-blue-800'
            }`}
          >
            {programIdCopied ? (
              <>
                <Check className="w-3 h-3" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>Copy ID</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Direct Download Option */}
      <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-purple-800">
              <strong>Alternative:</strong> Download program file directly
            </p>
            <p className="text-xs text-purple-600 mt-1">
              Use local files if you prefer not to rely on our hosting
            </p>
          </div>
          <button
            onClick={handleDownload}
            className="flex items-center space-x-1 px-3 py-2 text-sm bg-purple-200 hover:bg-purple-300 text-purple-800 rounded transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download</span>
          </button>
        </div>
        
        {/* Local usage code */}
        <div className="mt-3">
          <div className="relative">
            <pre className="bg-gray-800 text-gray-100 p-3 rounded text-xs overflow-x-auto">
              <code>{localCodeSnippet}</code>
            </pre>
            <button
              onClick={handleLocalCodeCopy}
              className={`absolute top-2 right-2 flex items-center space-x-1 px-2 py-1 rounded text-xs transition-all ${
                localCodeCopied
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-600 hover:bg-gray-500 text-gray-200'
              }`}
            >
              {localCodeCopied ? (
                <>
                  <Check className="w-3 h-3" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CopyCodeSection; 
