import React, { useState } from 'react';
import { Settings, ChevronDown, ChevronRight, Zap } from 'lucide-react';
import ModelSelector from './ModelSelector';

interface ModelOption {
  id: string;
  name: string;
  description: string;
}

interface CompileButtonWithConfigProps {
  onCompile: () => void;
  compiling: boolean;
  canCompile: boolean;
  compilerModels: ModelOption[];
  interpreterModels: ModelOption[];
  compilerModel: string;
  interpreterModel: string;
  onCompilerModelChange: (value: string) => void;
  onInterpreterModelChange: (value: string) => void;
  loadingModels: boolean;
}

const CompileButtonWithConfig: React.FC<CompileButtonWithConfigProps> = ({
  onCompile,
  compiling,
  canCompile,
  compilerModels,
  interpreterModels,
  compilerModel,
  interpreterModel,
  onCompilerModelChange,
  onInterpreterModelChange,
  loadingModels
}) => {
  const [showConfig, setShowConfig] = useState(false);

  return (
    <div className="card p-6">
      <div className="space-y-4">
        {/* Main Compile Button with Config Toggle */}
        <div className="flex items-center justify-center space-x-4">
          <button
            onClick={onCompile}
            disabled={!canCompile || compiling}
            className={`
              inline-flex items-center space-x-3 px-8 py-4 text-lg font-semibold rounded-lg
              transition-all duration-200 transform hover:scale-105
              ${canCompile && !compiling
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }
            `}
          >
            <Zap className={`w-6 h-6 ${compiling ? 'animate-spin' : ''}`} />
            <span>
              {compiling ? 'Compiling Neural Program...' : 'Compile Neural Program'}
            </span>
          </button>

          <button
            onClick={() => setShowConfig(!showConfig)}
            className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Models</span>
            {showConfig ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </button>
        </div>

        {!canCompile && !loadingModels && (
          <p className="text-sm text-gray-500 text-center">
            Enter a program specification to compile
          </p>
        )}

        {/* Expandable Model Configuration */}
        {showConfig && (
          <div className="border-t border-gray-200 pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg">
              <ModelSelector
                label="Compiler Model"
                options={compilerModels}
                value={compilerModel}
                onChange={onCompilerModelChange}
                loading={loadingModels}
                placeholder="Select compiler model..."
              />
              <ModelSelector
                label="Interpreter Model"
                options={interpreterModels}
                value={interpreterModel}
                onChange={onInterpreterModelChange}
                loading={loadingModels}
                placeholder="Select interpreter model..."
              />
              <div className="md:col-span-2">
                <p className="text-xs text-gray-500">
                  The compiler translates your specification into neural weights. 
                  The interpreter executes those weights.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompileButtonWithConfig; 