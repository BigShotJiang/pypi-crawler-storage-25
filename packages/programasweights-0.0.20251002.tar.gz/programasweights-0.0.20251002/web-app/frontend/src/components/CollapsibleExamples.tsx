import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Plus, Trash2 } from 'lucide-react';

interface ExampleRow {
  id: string;
  input: string;
  output: string;
}

interface CollapsibleExamplesProps {
  examples: ExampleRow[];
  onExamplesChange: (examples: ExampleRow[]) => void;
}

const CollapsibleExamples: React.FC<CollapsibleExamplesProps> = ({
  examples,
  onExamplesChange
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const addExample = () => {
    const newExample: ExampleRow = {
      id: Date.now().toString(),
      input: '',
      output: ''
    };
    onExamplesChange([...examples, newExample]);
  };

  const removeExample = (id: string) => {
    if (examples.length > 1) {
      onExamplesChange(examples.filter(ex => ex.id !== id));
    }
  };

  const updateExample = (id: string, field: 'input' | 'output', value: string) => {
    onExamplesChange(
      examples.map(ex => 
        ex.id === id ? { ...ex, [field]: value } : ex
      )
    );
  };

  const validExamples = examples.filter(ex => ex.input.trim() && ex.output.trim());

  return (
    <div className="card p-6">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between w-full text-left"
      >
        <div className="flex items-center space-x-2">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-gray-500" />
          ) : (
            <ChevronRight className="w-5 h-5 text-gray-500" />
          )}
          <h3 className="text-lg font-semibold text-gray-900">
            Input/Output Examples
          </h3>
          <span className="text-sm text-gray-500">
            ({validExamples.length} examples)
          </span>
        </div>
        <span className="text-sm text-gray-400">Optional</span>
      </button>

      {isExpanded && (
        <div className="mt-4 space-y-4">
          <p className="text-sm text-gray-600">
            Provide examples to help clarify your program's expected behavior.
          </p>
          
          {examples.map((example, index) => (
            <div key={example.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-700">
                  Example {index + 1}
                </span>
                {examples.length > 1 && (
                  <button
                    onClick={() => removeExample(example.id)}
                    className="text-red-500 hover:text-red-700 p-1"
                    title="Remove example"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Input
                  </label>
                  <textarea
                    value={example.input}
                    onChange={(e) => updateExample(example.id, 'input', e.target.value)}
                    placeholder="Enter example input..."
                    className="w-full border border-gray-300 rounded p-2 text-sm resize-none overflow-hidden"
                    style={{
                      minHeight: '60px',
                      maxHeight: '100px',
                      height: Math.max(60, Math.min(100, (example.input.split('\n').length * 20) + 20))
                    }}
                    onInput={(e) => {
                      const target = e.target as HTMLTextAreaElement;
                      target.style.height = 'auto';
                      target.style.height = Math.min(100, Math.max(60, target.scrollHeight)) + 'px';
                    }}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expected Output
                  </label>
                  <textarea
                    value={example.output}
                    onChange={(e) => updateExample(example.id, 'output', e.target.value)}
                    placeholder="Enter expected output..."
                    className="w-full border border-gray-300 rounded p-2 text-sm resize-none overflow-hidden"
                    style={{
                      minHeight: '60px',
                      maxHeight: '100px',
                      height: Math.max(60, Math.min(100, (example.output.split('\n').length * 20) + 20))
                    }}
                    onInput={(e) => {
                      const target = e.target as HTMLTextAreaElement;
                      target.style.height = 'auto';
                      target.style.height = Math.min(100, Math.max(60, target.scrollHeight)) + 'px';
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
          
          <button
            onClick={addExample}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            <span>Add Example</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default CollapsibleExamples; 