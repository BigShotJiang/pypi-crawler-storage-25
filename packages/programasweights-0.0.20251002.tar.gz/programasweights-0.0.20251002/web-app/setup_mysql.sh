#!/bin/bash

# ProgramAsWeights MySQL Database Setup Script for Ubuntu
# Run this script on your Ubuntu server to set up the database

set -e  # Exit on any error

echo "🗄️  Setting up MySQL for ProgramAsWeights..."

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then
    echo "❌ This script needs to be run with sudo privileges"
    echo "Usage: sudo ./setup_mysql.sh"
    exit 1
fi

# Update package list
echo "📦 Updating package list..."
apt update

# Install MySQL server
echo "🗄️  Installing MySQL server..."
apt install -y mysql-server

# Start and enable MySQL service
echo "🚀 Starting MySQL service..."
systemctl start mysql
systemctl enable mysql

# Check if MySQL is running
if systemctl is-active --quiet mysql; then
    echo "✅ MySQL service is running"
else
    echo "❌ Failed to start MySQL service"
    exit 1
fi

# Secure MySQL installation (automated)
echo "🔒 Securing MySQL installation..."
mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password123';"
mysql -e "DELETE FROM mysql.user WHERE User='';"
mysql -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"
mysql -e "DROP DATABASE IF EXISTS test;"
mysql -e "DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';"
mysql -e "FLUSH PRIVILEGES;"

echo "✅ MySQL secured with root password: password123"

# Create the ProgramAsWeights database and user
echo "🏗️  Creating ProgramAsWeights database..."
mysql -u root -ppassword123 << EOF
-- Create database
CREATE DATABASE IF NOT EXISTS programasweights 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- Create a dedicated user
CREATE USER IF NOT EXISTS 'paw_user'@'localhost' IDENTIFIED BY 'paw_password_123';

-- Grant privileges
GRANT ALL PRIVILEGES ON programasweights.* TO 'paw_user'@'localhost';

-- Refresh privileges
FLUSH PRIVILEGES;

-- Use the database
USE programasweights;

-- Create specifications table (simplified)
CREATE TABLE IF NOT EXISTS specifications (
    id VARCHAR(36) PRIMARY KEY,
    specification TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create input_output_examples table (simplified)
CREATE TABLE IF NOT EXISTS input_output_examples (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    specification_id VARCHAR(36) NOT NULL,
    input_text TEXT NOT NULL,
    output_text TEXT NOT NULL,
    source ENUM('user', 'gpt') DEFAULT 'user' NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    FOREIGN KEY (specification_id) REFERENCES specifications(id) ON DELETE CASCADE,
    INDEX idx_specification_id (specification_id),
    INDEX idx_created_at (created_at),
    INDEX idx_source (source)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Show final schema
SHOW TABLES;
EOF

echo "✅ Database and tables created successfully"

# Create the .env file with correct database credentials
echo "📝 Creating .env file..."
cd backend
cat > .env << EOF
# OpenAI API Configuration
OPENAI_API_KEY=your_openai_api_key_here

# MySQL Database Configuration
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_DATABASE=programasweights
MYSQL_USER=paw_user
MYSQL_PASSWORD=paw_password_123

# Model Paths
CHECKPOINT_DIR=../../outputs/prefix_kv/checkpoint
COMPILED_MODELS_DIR=./compiled_models
TEMP_DIR=./temp

# Development Settings
DEBUG=true
EOF

echo "✅ .env file created with database credentials"

# Test the database connection
echo "🧪 Testing database connection..."
mysql -u paw_user -ppaw_password_123 -e "USE programasweights; SHOW TABLES;"

if [ $? -eq 0 ]; then
    echo "✅ Database connection test successful!"
    echo ""
    echo "🎉 MySQL setup complete!"
    echo ""
    echo "Database Details:"
    echo "  - Database: programasweights"
    echo "  - User: paw_user"
    echo "  - Password: paw_password_123"
    echo "  - Root Password: password123"
    echo ""
    echo "🚀 You can now start the web application:"
    echo "  cd /path/to/programasweights/web-app"
    echo "  ./start.sh"
else
    echo "❌ Database connection test failed"
    exit 1
fi
