from __future__ import annotations

import json
import os
from typing import Optional

import torch

from .dummy import compile_dummy  # noqa: F401
from ..paw_format import save_paw_program


def compile(
    out_path: str,
    *,
    spec: str,
    checkpoint_dir: str = "outputs/prefix_kv/checkpoint",
    prefix_steps: Optional[int] = None,
) -> str:
    """
    Compile a spec into a .paw neural program file.

    - Loads mapper and models from `checkpoint_dir`
    - Saves a single .paw file at `out_path`
    - Returns `out_path`
    """
    from training.loops.prefix_tuning_sft import JointCompilerInterpreter

    # Ensure .paw extension
    if not out_path.endswith('.paw'):
        out_path = out_path + '.paw'

    # Load metadata
    compiler_dir = os.path.join(checkpoint_dir, "compiler")
    interpreter_dir = os.path.join(checkpoint_dir, "interpreter")
    mapper_path = os.path.join(compiler_dir, "mapper.pt")
    
    if not os.path.exists(mapper_path):
        raise FileNotFoundError(f"mapper.pt not found at {mapper_path}")
    
    mapper_pkg = torch.load(mapper_path, map_location="cpu")
    compiler_model_name = mapper_pkg["compiler_model_name"]
    interpreter_model_name = mapper_pkg["interpreter_model_name"]
    steps = prefix_steps or mapper_pkg.get("prefix_steps", 5)

    model = JointCompilerInterpreter(
        compiler_model_name=compiler_dir if os.path.isdir(compiler_dir) else compiler_model_name,
        interpreter_model_name=interpreter_dir if os.path.isdir(interpreter_dir) else interpreter_model_name,
        prefix_steps=steps,
        max_spec_length=256,
        max_input_length=256,
        max_output_length=256,
    )
    # Load trained mapper weights for correct KV projection
    if "state_dict" in mapper_pkg:
        model.mapper.load_state_dict(mapper_pkg["state_dict"]) 
    model.eval()

    kv_per_item = model.compile_prefix([spec])  # one item
    kv_layers = [(k.cpu(), v.cpu()) for k, v in kv_per_item[0]]

    # Save as .paw file
    save_paw_program(
        filepath=out_path,
        kv_layers=kv_layers,
        spec=spec,
        base_model=interpreter_model_name,
        prefix_steps=steps
    )

    return out_path 