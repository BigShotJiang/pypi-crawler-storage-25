from __future__ import annotations

import os
import threading
import hashlib
import urllib.request
import urllib.parse
from pathlib import Path
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple, Union

import torch
import transformers as _tf

from programasweights.paw_format import load_paw_program, PAWFormat


# Global lock to guard generate() calls for simple thread-safety
_GLOBAL_GENERATE_LOCK = threading.RLock()


def get_cache_dir() -> Path:
    """Get the global cache directory for .paw files."""
    cache_dir = Path.home() / ".cache" / "programasweights"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def resolve_program_path(path: str) -> str:
    """
    Resolve a program path to a local .paw file, downloading if necessary.
    
    Handles:
    - Local files: "./program.paw" -> "./program.paw"
    - Program IDs: "abc123" -> downloads to ~/.cache/programasweights/abc123.paw
    - URLs: "https://..." -> downloads to cache with URL hash
    """
    # If it's already a local file that exists, use it
    if os.path.exists(path):
        if path.endswith('.paw') or PAWFormat.is_paw_file(path):
            return path
        else:
            raise ValueError(f"File {path} is not a valid .paw file")
    
    # If it looks like a URL, download it
    if path.startswith(('http://', 'https://')):
        return download_from_url(path)
    
    # Otherwise treat as program ID and download from programasweights.com
    return download_program_id(path)


def download_program_id(program_id: str) -> str:
    """Download a program by ID from programasweights.com."""
    # Remove .paw suffix if present
    clean_id = program_id.replace('.paw', '')
    
    cache_dir = get_cache_dir()
    cached_file = cache_dir / f"{clean_id}.paw"
    
    # Return cached file if it exists
    if cached_file.exists():
        print(f"Using cached program: {cached_file}")
        return str(cached_file)
    
    # Download from programasweights.com
    url = f"https://programasweights.com/programs/{clean_id}.paw"
    print(f"Downloading program {clean_id} from {url}...")
    
    try:
        urllib.request.urlretrieve(url, cached_file)
        print(f"Downloaded and cached: {cached_file}")
        return str(cached_file)
    except Exception as e:
        raise RuntimeError(f"Failed to download program {clean_id}: {e}")


def download_from_url(url: str) -> str:
    """Download a program from a URL and cache it."""
    # Create cache filename from URL hash
    url_hash = hashlib.sha256(url.encode()).hexdigest()[:16]
    cache_dir = get_cache_dir()
    cached_file = cache_dir / f"url_{url_hash}.paw"
    
    # Return cached file if it exists
    if cached_file.exists():
        print(f"Using cached program from URL: {cached_file}")
        return str(cached_file)
    
    # Download and cache
    print(f"Downloading program from {url}...")
    try:
        urllib.request.urlretrieve(url, cached_file)
        print(f"Downloaded and cached: {cached_file}")
        return str(cached_file)
    except Exception as e:
        raise RuntimeError(f"Failed to download program from {url}: {e}")


@dataclass
class RegisteredProgram:
    name: str
    path: str
    kv_layers: List[Tuple[torch.Tensor, torch.Tensor]]
    metadata: Dict[str, str]


def _ensure_list(x: Union[str, List[str]]) -> Tuple[bool, List[str]]:
    if isinstance(x, list):
        return True, x
    if isinstance(x, str):
        return False, [x]
    raise TypeError("Input must be str or List[str]")


class _Interpreter:
    def __init__(self, model_name: str, device: torch.device) -> None:
        self.model_name = model_name
        self.device = device
        self.tokenizer = _tf.AutoTokenizer.from_pretrained(model_name)
        self.model = _tf.AutoModelForCausalLM.from_pretrained(model_name)
        self.model.to(self.device)
        self._programs: Dict[str, RegisteredProgram] = {}

    def register_program(self, path: str, name: Optional[str]) -> RegisteredProgram:
        program_name = name if name is not None else os.path.basename(path)
        
        # Resolve path (download if necessary)
        resolved_path = resolve_program_path(path)
        
        # Load .paw file
        kv_layers, metadata = load_paw_program(resolved_path)
        # Move tensors to device
        kv_layers = [(k.to(self.device), v.to(self.device)) for k, v in kv_layers]

        program = RegisteredProgram(
            name=program_name, 
            path=resolved_path, 
            kv_layers=kv_layers,
            metadata=metadata
        )
        self._programs[program_name] = program
        return program

    def get_callable(self, program_name: str, max_new_tokens: int) -> Callable[[Union[str, List[str]]], Union[str, List[str]]]:
        if program_name not in self._programs:
            raise ValueError(f"Program '{program_name}' is not registered")

        def _call(x: Union[str, List[str]]) -> Union[str, List[str]]:
            was_list, inputs = _ensure_list(x)
            outputs = self._generate(program_name, inputs, max_new_tokens=max_new_tokens)
            return outputs if was_list else outputs[0]

        return _call

    def _generate(self, program_name: str, texts: List[str], *, max_new_tokens: int) -> List[str]:
        program = self._programs[program_name]
        kv_prefix = program.kv_layers

        tokenized = self.tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=False,
        )
        tokenized = {k: v.to(self.device) if hasattr(v, "to") else v for k, v in tokenized.items()}

        attention_mask = tokenized.get("attention_mask")
        if attention_mask is not None:
            bsz = attention_mask.size(0)
            expanded_kv: List[Tuple[torch.Tensor, torch.Tensor]] = []
            for (k, v) in kv_prefix:
                if k.dim() == 3:
                    k = k.unsqueeze(0).expand(bsz, -1, -1, -1).contiguous()
                    v = v.unsqueeze(0).expand(bsz, -1, -1, -1).contiguous()
                expanded_kv.append((k, v))
            kv_prefix = expanded_kv
            steps = kv_prefix[0][0].size(2)
            prefix_mask = torch.ones((bsz, steps), dtype=attention_mask.dtype, device=attention_mask.device)
            attention_mask = torch.cat([prefix_mask, attention_mask], dim=1)
            tokenized["attention_mask"] = attention_mask

        from transformers.cache_utils import DynamicCache
        cache_obj = DynamicCache.from_legacy_cache(tuple(kv_prefix))
        past_len = cache_obj.get_seq_length()

        bsz = tokenized["input_ids"].size(0)
        seq_len = tokenized["input_ids"].size(1)
        padding = tokenized['input_ids'].new_zeros(bsz, past_len).long()
        tokenized['input_ids'] = torch.cat((padding, tokenized['input_ids']), dim=-1)

        with _GLOBAL_GENERATE_LOCK:
            generated = self.model.generate(
                input_ids=tokenized["input_ids"],
                max_new_tokens=max_new_tokens,
                attention_mask=tokenized["attention_mask"],
                num_beams=1,
                past_key_values=cache_obj,
                use_cache=True,
            )

        input_len = tokenized["input_ids"].shape[1]
        outs = generated[:, input_len:]
        decoded: List[str] = [
            self.tokenizer.decode(seq, skip_special_tokens=True) for seq in outs
        ]
        return decoded


_INTERPRETER_SINGLETON: Optional[_Interpreter] = None


def _select_device() -> torch.device:
    override = os.environ.get("PROGRAMASWEIGHTS_DEVICE", "").strip().lower()
    if override == "cpu":
        return torch.device("cpu")
    if override == "cuda":
        if torch.cuda.is_available():
            return torch.device("cuda")
        return torch.device("cpu")
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def _get_interpreter(model_name: str) -> _Interpreter:
    global _INTERPRETER_SINGLETON
    if _INTERPRETER_SINGLETON is None:
        device = _select_device()
        _INTERPRETER_SINGLETON = _Interpreter(model_name=model_name, device=device)
    return _INTERPRETER_SINGLETON


def function(
    path: str,
    *,
    name: Optional[str] = None,
    interpreter_name: str = "yuntian-deng/paw-interpreter",
    max_new_tokens: int = 128,
) -> Callable[[Union[str, List[str]]], Union[str, List[str]]]:
    """
    Register a .paw program file and return a callable that runs it.
    """
    interp = _get_interpreter(model_name=interpreter_name)
    program = interp.register_program(path=path, name=name)
    return interp.get_callable(program_name=program.name, max_new_tokens=max_new_tokens) 
