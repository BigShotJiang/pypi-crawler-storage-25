"""
Custom .paw binary format for neural programs.
Combines KV tensors and metadata into a single file.
"""

from __future__ import annotations

import json
import struct
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Any

import torch
from safetensors.torch import save_file, load_file


class PAWFormat:
    """Handler for .paw binary format files."""
    
    MAGIC = b"PAW\x01"  # File format magic number
    VERSION = 1
    
    @staticmethod
    def save(
        filepath: str,
        kv_layers: List[Tuple[torch.Tensor, torch.Tensor]], 
        metadata: Dict[str, Any]
    ) -> None:
        """
        Save KV layers and metadata to a .paw file.
        
        Format:
        - Magic bytes (4 bytes): b"PAW\x01"
        - Version (4 bytes): uint32
        - Metadata length (4 bytes): uint32
        - Metadata (JSON bytes)
        - Tensors (safetensors format)
        """
        # Prepare tensors dict for safetensors
        tensors_dict = {}
        for i, (k, v) in enumerate(kv_layers):
            tensors_dict[f"layer_{i}_key"] = k
            tensors_dict[f"layer_{i}_value"] = v
        
        # Serialize metadata as JSON
        metadata_bytes = json.dumps(metadata, ensure_ascii=False).encode('utf-8')
        
        # Create tensors data in a temporary file first
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_path = temp_file.name
        
        save_file(tensors_dict, temp_path)
        
        # Read the safetensors data
        with open(temp_path, 'rb') as f:
            tensors_data = f.read()
        
        # Write the complete .paw file
        with open(filepath, 'wb') as f:
            # Write header
            f.write(PAWFormat.MAGIC)
            f.write(struct.pack('<I', PAWFormat.VERSION))
            f.write(struct.pack('<I', len(metadata_bytes)))
            
            # Write metadata
            f.write(metadata_bytes)
            
            # Write tensors data
            f.write(tensors_data)
        
        # Cleanup temp file
        Path(temp_path).unlink()
        
        total_size = Path(filepath).stat().st_size
        print(f"Saved .paw file: {filepath} ({total_size} bytes)")
    
    @staticmethod
    def load(filepath: str) -> Tuple[List[Tuple[torch.Tensor, torch.Tensor]], Dict[str, Any]]:
        """
        Load KV layers and metadata from a .paw file.
        
        Returns:
            Tuple of (kv_layers, metadata)
        """
        with open(filepath, 'rb') as f:
            # Read and verify magic
            magic = f.read(4)
            if magic != PAWFormat.MAGIC:
                raise ValueError(f"Invalid .paw file: wrong magic bytes")
            
            # Read version
            version = struct.unpack('<I', f.read(4))[0]
            if version != PAWFormat.VERSION:
                raise ValueError(f"Unsupported .paw version: {version}")
            
            # Read metadata length and metadata
            metadata_len = struct.unpack('<I', f.read(4))[0]
            metadata_bytes = f.read(metadata_len)
            metadata = json.loads(metadata_bytes.decode('utf-8'))
            
            # Read remaining data as tensors
            tensors_data = f.read()
        
        # Write tensors data to temp file for safetensors loading
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_file.write(tensors_data)
            temp_path = temp_file.name
        
        # Load tensors from temp file
        tensors_dict = load_file(temp_path)
        
        # Cleanup temp file
        Path(temp_path).unlink()
        
        # Reconstruct KV layers
        kv_layers = []
        layer_count = len([k for k in tensors_dict.keys() if k.endswith('_key')])
        
        for i in range(layer_count):
            key_tensor = tensors_dict[f"layer_{i}_key"]
            value_tensor = tensors_dict[f"layer_{i}_value"]
            kv_layers.append((key_tensor, value_tensor))
        
        print(f"Loaded .paw file: {filepath} ({layer_count} layers)")
        return kv_layers, metadata
    
    @staticmethod
    def is_paw_file(filepath: str) -> bool:
        """Check if a file is a valid .paw file."""
        try:
            with open(filepath, 'rb') as f:
                magic = f.read(4)
                return magic == PAWFormat.MAGIC
        except Exception:
            return False


def save_paw_program(
    filepath: str,
    kv_layers: List[Tuple[torch.Tensor, torch.Tensor]],
    spec: str,
    base_model: str,
    prefix_steps: int = 5
) -> None:
    """Convenience function to save a neural program as .paw file."""
    metadata = {
        "kind": "neural_program",
        "spec": spec,
        "base_model": base_model,
        "prefix_steps": prefix_steps,
        "num_layers": len(kv_layers),
        "format_version": PAWFormat.VERSION
    }
    PAWFormat.save(filepath, kv_layers, metadata)


def load_paw_program(filepath: str) -> Tuple[List[Tuple[torch.Tensor, torch.Tensor]], Dict[str, Any]]:
    """Convenience function to load a neural program from .paw file."""
    return PAWFormat.load(filepath) 