from __future__ import annotations

import logging
import os
import warnings
from typing import Any

logger = logging.getLogger(__name__)

REGENT_PROXY_BASE = "https://proxy.regent.dev"

_regent_api_key: str = ""
_proxy_url: str = REGENT_PROXY_BASE
_is_initialized: bool = False


def init(api_key: str, proxy_url: str = REGENT_PROXY_BASE) -> None:
    """
    Patch OpenAI and Anthropic client constructors so any client instantiated
    after this call routes through the Regent proxy.

    Only activates when the REGENT_ENABLED environment variable is set to "true".
    In production, leave REGENT_ENABLED unset — this becomes a no-op.

    Must be called before importing or instantiating any OpenAI/Anthropic clients.

    Args:
        api_key:   Your Regent API key (starts with ``rgt_``).
        proxy_url: Override the proxy base URL, e.g. ``http://localhost:8001``
                   for local development. Defaults to ``https://proxy.regent.dev``.
    """
    global _regent_api_key, _proxy_url, _is_initialized

    if os.environ.get("REGENT_ENABLED", "").lower() != "true":
        logger.debug("Regent: REGENT_ENABLED is not set — proxy patching skipped.")
        return

    if _is_initialized:
        warnings.warn(
            "regent.init() called more than once — ignoring subsequent call.",
            UserWarning,
            stacklevel=2,
        )
        return

    _regent_api_key = api_key
    _proxy_url = proxy_url.rstrip("/")
    _is_initialized = True

    _patch_openai()
    _patch_anthropic()


# ---------------------------------------------------------------------------
# OpenAI patching
# ---------------------------------------------------------------------------

def _patch_openai() -> None:
    try:
        import openai
    except ImportError:
        return

    openai_base = f"{_proxy_url}/proxy/openai"

    _wrap_init(
        openai,
        "OpenAI",
        base_url=openai_base,
        api_key=_regent_api_key,
    )
    _wrap_init(
        openai,
        "AsyncOpenAI",
        base_url=openai_base,
        api_key=_regent_api_key,
    )
    logger.debug("Regent: patched openai.OpenAI and openai.AsyncOpenAI → %s", openai_base)


# ---------------------------------------------------------------------------
# Anthropic patching
# ---------------------------------------------------------------------------

def _patch_anthropic() -> None:
    try:
        import anthropic
    except ImportError:
        return

    anthropic_base = f"{_proxy_url}/proxy/anthropic"

    _wrap_init(
        anthropic,
        "Anthropic",
        base_url=anthropic_base,
        api_key=_regent_api_key,
    )
    _wrap_init(
        anthropic,
        "AsyncAnthropic",
        base_url=anthropic_base,
        api_key=_regent_api_key,
    )
    logger.debug(
        "Regent: patched anthropic.Anthropic and anthropic.AsyncAnthropic → %s",
        anthropic_base,
    )


# ---------------------------------------------------------------------------
# Generic wrapper
# ---------------------------------------------------------------------------

def _wrap_init(module: Any, class_name: str, **injected_kwargs: Any) -> None:
    """
    Replace ``module.ClassName.__init__`` with a wrapper that injects
    ``injected_kwargs`` unless the caller already supplied them explicitly.
    """
    cls = getattr(module, class_name, None)
    if cls is None:
        return

    original_init = cls.__init__

    def patched_init(self: Any, *args: Any, **kwargs: Any) -> None:
        # If caller explicitly provided their own api_key, don't proxy —
        # they're intentionally using a different key (e.g. embeddings client).
        if "api_key" in kwargs:
            original_init(self, *args, **kwargs)
            return
        for key, value in injected_kwargs.items():
            if key not in kwargs:
                kwargs[key] = value
        try:
            original_init(self, *args, **kwargs)
        except TypeError as exc:
            warnings.warn(
                f"Regent: failed to patch {module.__name__}.{class_name}.__init__: {exc}. "
                "The client was not routed through the Regent proxy.",
                UserWarning,
                stacklevel=2,
            )
            # Fall back to the original call without our injected kwargs
            original_init(self, *args, **{k: v for k, v in kwargs.items() if k not in injected_kwargs})

    patched_init.__wrapped__ = original_init  # type: ignore[attr-defined]
    cls.__init__ = patched_init
