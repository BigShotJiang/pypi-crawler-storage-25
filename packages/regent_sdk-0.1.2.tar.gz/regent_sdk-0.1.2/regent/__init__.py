from regent._patch import init

__all__ = ["init"]
