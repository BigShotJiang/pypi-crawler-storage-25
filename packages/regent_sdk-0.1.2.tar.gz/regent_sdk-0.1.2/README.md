# Regent SDK

```
pip install regent-sdk
```

## Usage

```python
import regent
regent.init(api_key="your-regent-api-key")

# All OpenAI/Anthropic clients instantiated after this call
# will automatically route through Regent's proxy.

# Must be called before importing or instantiating OpenAI/Anthropic clients.
from openai import OpenAI
client = OpenAI()  # automatically proxied
```

## Local development

```python
regent.init(api_key="your-regent-api-key", proxy_url="http://localhost:8000")
```

## What gets proxied

Only LLM calls made without an explicit `api_key` argument are routed through Regent. If you pass your own `api_key` when constructing a client, the SDK leaves that client untouched — this is intentional so auxiliary clients (e.g. embeddings, sidecar services) are never accidentally rerouted.

```python
OpenAI()                        # proxied — Regent injects base_url + api_key
OpenAI(api_key="sk-...")        # not proxied — your key, your endpoint
```

## Privacy

Regent only proxies traffic from your test runs (GitHub Actions / CI). We do not intercept or touch your production traffic. If `REGENT_ENABLED` is not set to `"true"`, `regent.init()` is a no-op and nothing is patched.
