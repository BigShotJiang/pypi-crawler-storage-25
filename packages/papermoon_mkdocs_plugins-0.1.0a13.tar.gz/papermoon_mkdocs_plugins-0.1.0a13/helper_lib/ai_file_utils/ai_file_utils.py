import base64
import copy
import html
import json
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List

from mkdocs.utils import log


class AIFileUtils:
    """
    A utility class for resolving AI file actions and generating
    the HTML UI components (split-button dropdown) for those actions.
    This acts as a shared library for plugins to resolve links,
    clipboard content, LLM prompts, and render action HTML based
    on a defined schema.
    """

    def __init__(self):
        self._actions_schema = None
        self._actions_config_path = Path(__file__).parent / "ai_file_actions.json"

    def _load_actions_schema(self):
        """
        Loads the actions definition from the JSON file.
        """
        try:
            if self._actions_config_path.exists():
                text = self._actions_config_path.read_text(encoding="utf-8")
                self._actions_schema = json.loads(text)
                log.info(
                    f"[ai_file_utils] Loaded actions schema from {self._actions_config_path}"
                )
            else:
                log.warning(
                    f"[ai_file_utils] Actions schema file not found at {self._actions_config_path}"
                )
                self._actions_schema = {"actions": []}
        except json.JSONDecodeError as e:
            log.error(f"[ai_file_utils] Failed to parse actions schema JSON: {e}")
            self._actions_schema = {"actions": []}
        except Exception as e:
            log.error(
                f"[ai_file_utils] Unexpected error loading actions schema: {e}",
                exc_info=True,
            )
            self._actions_schema = {"actions": []}

    def get_page_widget_config(self) -> Dict[str, Any]:
        """Return the ``pageWidget`` configuration from the JSON schema."""
        if not self._actions_schema:
            self._load_actions_schema()
        return self._actions_schema.get("pageWidget", {})

    def is_page_excluded(
        self,
        src_path: str,
        page_meta: Dict[str, Any],
        skip_basenames: List[str] = None,
        skip_paths: List[str] = None,
    ) -> bool:
        """Check whether a page should be excluded from widget injection.

        Exclusion sources (checked in order):
        1. Dot-directories — any path component starting with ``.``
        2. ``skip_basenames`` — exact filename match
        3. ``skip_paths`` — substring match against the source path
        4. Front-matter key ``hide_ai_actions`` (configurable via JSON schema)
        """
        if skip_basenames is None:
            skip_basenames = []
        if skip_paths is None:
            skip_paths = []

        parts = Path(src_path).parts
        # Skip pages inside dot-directories
        if any(part.startswith(".") for part in parts):
            return True

        # Skip pages whose filename matches a skip_basenames entry
        filename = parts[-1] if parts else ""
        if filename in skip_basenames:
            return True

        # Skip pages whose path contains a skip_paths substring
        if any(x in src_path for x in skip_paths):
            return True

        # Skip pages that opt out via front-matter
        config = self.get_page_widget_config()
        fm_key = config.get("frontMatterKey", "hide_ai_actions")
        if page_meta.get(fm_key):
            return True

        return False

    def resolve_actions(
        self,
        page_url: str,
        filename: str,
        content: str,
        prompt_page_url: str = "",
    ) -> List[Dict[str, Any]]:
        """
        Resolves the list of actions for a given page context.

        Args:
            page_url: The relative URL to the markdown file (ai artifact).
            filename: The name of the file (e.g., 'page.md').
            content: The actual text content of the markdown file.
            prompt_page_url: The fully-qualified URL for use in prompt
                templates. Falls back to ``page_url`` if not provided.

        Returns:
            A list of action dictionaries with all placeholders resolved.
        """
        if not self._actions_schema:
            self._load_actions_schema()

        resolved_actions = []
        raw_actions = self._actions_schema.get("actions", [])

        for action_def in raw_actions:
            try:
                resolved_action = self._resolve_single_action(
                    action_def, page_url, filename, content,
                    prompt_page_url=prompt_page_url or page_url,
                )
                resolved_actions.append(resolved_action)
            except Exception as e:
                log.warning(
                    f"[ai_file_utils] Failed to resolve action {action_def.get('id')}: {e}",
                    exc_info=True,
                )

        return resolved_actions

    def _resolve_single_action(
        self,
        action_def: Dict[str, Any],
        page_url: str,
        filename: str,
        content: str,
        prompt_page_url: str = "",
    ) -> Dict[str, Any]:
        """
        Resolves a single action definition by replacing placeholders.
        """
        # Create a deep copy to avoid modifying the schema if it has nested structures
        action = copy.deepcopy(action_def)

        # 1. Resolve Prompt if a template exists
        prompt_text = ""
        if "promptTemplate" in action:
            tpl = action["promptTemplate"]
            # Prompt templates use the full URL so external services
            # (ChatGPT, Claude) receive a complete address.
            prompt_replacements = {
                "{{ content }}": content,
                "{{ page_url }}": prompt_page_url or page_url,
                "{{ filename }}": filename,
            }
            for placeholder, replacement in prompt_replacements.items():
                if placeholder in tpl:
                    tpl = tpl.replace(placeholder, replacement)
            prompt_text = tpl

            # Remove the template from the output as it's processed
            action.pop("promptTemplate")

        # 2. Prepare Context Variables
        # URL encode the prompt for use in query parameters
        encoded_prompt = urllib.parse.quote(prompt_text, safe="")

        replacements = {
            "{{ page_url }}": page_url,
            "{{ filename }}": filename,
            "{{ content }}": content,  # Be careful with large content in attributes, but for clipboard it's needed
            "{{ prompt }}": encoded_prompt,
        }

        # 3. Interpolate values into specific fields
        # Fields that support interpolation
        target_fields = ["href", "download", "clipboardContent"]

        for field in target_fields:
            if field in action and isinstance(action[field], str):
                val = action[field]
                for placeholder, replacement in replacements.items():
                    if placeholder in val:
                        val = val.replace(placeholder, replacement)
                action[field] = val

        return action
    
    # ------------------------------------------------------------------
    # MCP deeplinks & helpers
    # ------------------------------------------------------------------

    @staticmethod
    def build_cursor_deeplink(server_name: str, mcp_url: str) -> str:
        """Build a ``cursor://`` one-click install deeplink."""
        config_json = json.dumps({"url": mcp_url}, separators=(",", ":"))
        b64_config = base64.urlsafe_b64encode(config_json.encode()).decode()
        return (
            "cursor://anysphere.cursor-deeplink/mcp/install"
            f"?name={urllib.parse.quote(server_name, safe='')}&config={b64_config}"
        )

    @staticmethod
    def build_vscode_deeplink(server_name: str, mcp_url: str) -> str:
        """Build a ``vscode:`` one-click install deeplink."""
        config_json = json.dumps(
            {"name": server_name, "url": mcp_url}, separators=(",", ":")
        )
        return f"vscode:mcp/install?{urllib.parse.quote(config_json, safe='')}"

    @staticmethod
    def twemoji_icon(svg: str) -> str:
        """Wrap an SVG string in a twemoji span."""
        return f'<span class="twemoji">{svg}</span>'

    @staticmethod
    def mcp_install_button(href: str, label: str = "Install", html_icon: str = "") -> str:
        """Return an inline HTML button for a deeplink install action."""
        safe_href = html.escape(href, quote=True)
        safe_label = html.escape(label)
        return (
            f'<a href="{safe_href}" class="ai-file-actions-btn single-action-btn">{html_icon}{safe_label}</a>'
        )

    @staticmethod
    def mcp_copy_code(command: str) -> str:
        """Return an inline ``<code>`` element."""
        return f'<pre><code style="white-space: pre-wrap; word-break: break-all;">{html.escape(command)}</code></pre>'

    # ------------------------------------------------------------------
    # HTML generation
    # ------------------------------------------------------------------

    def _render_primary_button(
        self, action: dict, url: str, primary_label: str | None = None
    ) -> str:
        """Render the primary (left-side) button from a JSON action.

        Note: ``icon`` SVG markup from ``ai_file_actions.json`` is inserted
        into the HTML without escaping.  This is intentional — the JSON file
        is part of the codebase and should be treated as trusted code,
        subject to the same review process as any other source file.
        """
        safe_url = html.escape(url, quote=True)
        raw_label = primary_label if primary_label else action.get("label", "Copy file")
        label = html.escape(raw_label, quote=True)
        icon_svg = action.get("icon", "")
        action_id = html.escape(action.get("id", ""), quote=True)

        spinner_svg = (
            '<svg class="ai-file-actions-icon'
            ' loading-spinner"'
            ' xmlns="http://www.w3.org/2000/svg"'
            ' viewBox="0 0 24 24"'
            ' width="24" height="24">'
            '<circle cx="12" cy="12" r="10"'
            ' stroke="currentColor"'
            ' stroke-width="2" fill="none"'
            ' stroke-dasharray="31.4"'
            ' stroke-dashoffset="0">'
            '<animate attributeName="stroke-dashoffset"'
            ' dur="1s" repeatCount="indefinite"'
            ' from="0" to="62.8"/>'
            "</circle></svg>"
        )
        success_svg = (
            '<svg class="ai-file-actions-icon'
            ' copy-success-icon"'
            ' xmlns="http://www.w3.org/2000/svg"'
            ' viewBox="0 0 24 24">'
            '<path fill="currentColor"'
            ' d="M9 16.17L4.83 12l-1.42 1.41L9'
            ' 19 21 7l-1.41-1.41z"/>'
            "</svg>"
        )

        loading_attr = html.escape(spinner_svg, quote=True)
        success_attr = html.escape(success_svg, quote=True)

        return (
            '<button class="ai-file-actions-btn'
            ' ai-file-actions-copy"'
            f' title="{label}"'
            f' aria-label="{label}"'
            ' role="button"'
            f' data-action="{action_id}"'
            f' data-url="{safe_url}"'
            f' data-loading-html="{loading_attr}"'
            f' data-success-html="{success_attr}">'
            f"{icon_svg}"
            f'<span class="button-text">{label}</span>'
            "</button>"
        )

    def _render_action_item(self, action: dict, url: str) -> str:
        """Render a single dropdown item from a resolved action.

        Link-type actions render as ``<a>`` so the browser handles
        navigation natively.  Clipboard actions render as ``<button>``
        since copying requires JavaScript.

        See ``_render_primary_button`` for the SVG trust-boundary note.
        """
        action_type = action.get("type", "link")
        action_id = action.get("id", "")
        label = html.escape(action.get("label", ""), quote=True)
        icon_svg = action.get("icon", "")
        trailing_svg = action.get("trailingIcon", "")

        safe_id = html.escape(action_id, quote=True)
        inner = f"{icon_svg}" f"<span>{label}</span>" f"{trailing_svg}"

        if action_type == "link":
            href = action.get("href", "")
            safe_href = html.escape(href, quote=True)
            dl_attr = ""
            if "download" in action:
                safe_dl = html.escape(action["download"], quote=True)
                dl_attr = f' download="{safe_dl}"'
            else:
                dl_attr = ' target="_blank" rel="noopener noreferrer"'
            return (
                f'<a class="ai-file-actions-item"'
                f' href="{safe_href}"'
                f"{dl_attr}"
                f' data-action-id="{safe_id}"'
                f' role="menuitem" tabindex="-1">'
                f"{inner}"
                f"</a>"
            )

        # clipboard (or any non-link type)
        safe_url = html.escape(url, quote=True)
        return (
            f'<button class="ai-file-actions-item"'
            f' data-action-type="clipboard"'
            f' data-action-id="{safe_id}"'
            f' data-url="{safe_url}"'
            f' role="menuitem" tabindex="-1">'
            f"{inner}"
            f"</button>"
        )

    def generate_dropdown_html(
        self,
        url: str,
        filename: str,
        exclude: list | None = None,
        primary_label: str | None = None,
        site_url: str = "",
        label_replace: dict[str, str] | None = None,
        content: str = "",
        style: str = "split",
        dropdown_label: str = "Markdown for LLMs",
        extra_classes: str = "",
    ) -> str:
        """
        Generate the HTML for the AI file actions widget.

        Two styles are supported:

        ``"split"`` (default)
            The action marked ``primary: true`` in the JSON renders as a
            left-side button; all other actions render as dropdown items.
            The primary action is automatically excluded from the dropdown.

        ``"dropdown"``
            A single trigger button labelled ``dropdown_label`` (default
            ``"Markdown for LLMs"``) opens a menu that contains *all*
            actions, including the primary one.  No separate copy button
            is rendered.

        Args:
            url: The relative URL of the file to act upon.
            filename: The filename for the download action.
            exclude: Optional list of action IDs to exclude
                     from the dropdown.
            primary_label: Optional label override for the primary
                     button (e.g., "Copy page" vs default "Copy file").
                     Only used in ``"split"`` style.
            site_url: The base site URL (e.g., "https://docs.polkadot.com/").
                     When provided, ``page_url`` passed to prompt templates
                     will be the fully-qualified URL.
            label_replace: Optional dict of string replacements to apply
                     to dropdown item labels (e.g., ``{"file": "page"}``).
            content: Optional page content for prompt template interpolation.
            style: Widget style — ``"split"`` or ``"dropdown"``.
            dropdown_label: Trigger button label used in ``"dropdown"`` style.
            extra_classes: Additional CSS class(es) to append to the container
                     div (e.g., ``"ai-file-actions-container--table"``).
                     Multiple classes can be space-separated.

        Returns:
            The HTML string for the component.
        """
        # Build the full page URL for use in prompt templates.
        # Use urljoin so that absolute paths (starting with /) correctly
        # replace the base path instead of duplicating it.
        if site_url:
            full_url = urllib.parse.urljoin(site_url, url)
        else:
            full_url = url
        actions = self.resolve_actions(
            page_url=url, filename=filename, content=content, prompt_page_url=full_url
        )

        exclude_set = set(exclude) if exclude else set()

        # Build container class string — style modifier is auto-added, then
        # any caller-supplied extra_classes are appended on top.
        container_classes = "ai-file-actions-container"
        if style == "dropdown":
            container_classes += " ai-file-actions-container--dropdown"
        if extra_classes:
            container_classes += f" {extra_classes}"

        chevron = (
            '<svg xmlns="http://www.w3.org/2000/svg"'
            ' width="24px" height="24px"'
            ' viewBox="0 0 24 24"'
            ' class="ai-file-actions-icon'
            ' ai-file-actions-chevron"'
            ' aria-hidden="true">'
            '<path d="M7 10l5 5 5-5z"/></svg>'
        )

        # ------------------------------------------------------------------ #
        # "dropdown" style — single trigger button, all actions in the menu   #
        # ------------------------------------------------------------------ #
        if style == "dropdown":
            menu_items = ""
            for action in actions:
                if action.get("id") in exclude_set:
                    continue
                if label_replace and "label" in action:
                    for old, new in label_replace.items():
                        action["label"] = action["label"].replace(old, new)
                menu_items += self._render_action_item(action, url)

            safe_url = html.escape(url, quote=True)
            escaped_label = html.escape(dropdown_label, quote=True)
            markdown_icon = (
                '<svg xmlns="http://www.w3.org/2000/svg"'
                ' width="24px" height="24px"'
                ' viewBox="0 0 24 24"'
                ' class="ai-file-actions-icon"'
                ' aria-hidden="true">'
                '<path d="M20.56 18H3.44C2.65 18 2 17.37 2 16.59V7.41C2 6.63 2.65 6'
                ' 3.44 6h17.12C21.35 6 22 6.63 22 7.41v9.18c0 .78-.65 1.41-1.44'
                ' 1.41zM6 15v-4.5l2.5 2.5 2.5-2.5V15h2V9h-2l-2.5 2.5L6 9H4v6h2z'
                'm11.5 0L20 12h-2V9h-2v3h-2l3.5 4z"/>'
                '</svg>'
            )
            trigger_btn = (
                '<button class="ai-file-actions-btn ai-file-actions-trigger"'
                ' type="button"'
                f' aria-label="{escaped_label}"'
                ' aria-haspopup="true"'
                ' aria-expanded="false"'
                ' role="button"'
                f' data-url="{safe_url}">'
                f'{markdown_icon}'
                f'<span class="button-text">{escaped_label}</span>'
                f"{chevron}"
                "</button>"
            )
            dropdown_menu = (
                '<div class="ai-file-actions-menu" role="menu">'
                f"{menu_items}"
                "</div>"
            )
            return (
                f'<div class="{container_classes}">'
                f"{trigger_btn}"
                f"{dropdown_menu}"
                "</div>"
            )

        # ------------------------------------------------------------------ #
        # "split" style (default) — primary copy button + chevron trigger     #
        # ------------------------------------------------------------------ #
        primary_action = None
        dropdown_actions = []

        for action in actions:
            if action.get("primary"):
                primary_action = action
            elif action.get("id") not in exclude_set:
                if label_replace and "label" in action:
                    for old, new in label_replace.items():
                        action["label"] = action["label"].replace(old, new)
                dropdown_actions.append(action)

        # Primary copy button (left side of split button)
        copy_btn = self._render_primary_button(
            primary_action or {}, url, primary_label=primary_label
        )

        # Dropdown trigger (right side of split button)
        dropdown_btn = (
            '<button class="ai-file-actions-btn'
            ' ai-file-actions-trigger"'
            ' title="More options"'
            ' type="button"'
            ' aria-label="More options"'
            ' aria-haspopup="true"'
            ' aria-expanded="false"'
            ' role="button">'
            f"{chevron}"
            "</button>"
        )

        # Dropdown menu items
        menu_items = ""
        for action in dropdown_actions:
            menu_items += self._render_action_item(action, url)

        dropdown_menu = (
            '<div class="ai-file-actions-menu"' ' role="menu">' f"{menu_items}" "</div>"
        )

        return (
            f'<div class="{container_classes}">'
            f"{copy_btn}"
            f"{dropdown_btn}"
            f"{dropdown_menu}"
            "</div>"
        )
