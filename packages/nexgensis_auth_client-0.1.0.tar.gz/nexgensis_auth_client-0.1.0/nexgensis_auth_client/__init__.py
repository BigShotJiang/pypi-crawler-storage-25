"""``nexgensis_auth_client`` — official Python SDK for CentralAuth.

Public surface (stable across 0.x → 1.0):

    from nexgensis_auth_client import (
        AuthClient, AdminClient, M2MClient,
        AuthContext, JWTValidator, JWKSCache, DiscoveryClient,
        WebhookVerifier,
    )

Django integration imports live under ``nexgensis_auth_client.django``
so non-Django consumers don't pay the import cost.
"""
from ._version import __version__
from .admin_client import AdminClient
from .auth_client import AuthClient, TokenPair
from .auth_context import AuthContext
from .discovery import AuthConfig, DiscoveryClient
from .exceptions import (
    AuthenticationFailed,
    CentralAuthAPIError,
    CentralAuthError,
    ExpiredToken,
    InsufficientGroup,
    InsufficientScope,
    InvalidSignature,
    InvalidToken,
    JWKSUnavailable,
    MFARequired,
    ProductNotEntitled,
    StaleTimestamp,
)
from .jwks_cache import JWKSCache
from .jwt_validator import JWTValidator
from .m2m_client import M2MClient
from .webhook import VerifiedEvent, WebhookVerifier

__all__ = [
    "AdminClient",
    "AuthClient",
    "AuthConfig",
    "AuthContext",
    "AuthenticationFailed",
    "CentralAuthAPIError",
    "CentralAuthError",
    "DiscoveryClient",
    "ExpiredToken",
    "InsufficientGroup",
    "InsufficientScope",
    "InvalidSignature",
    "InvalidToken",
    "JWKSCache",
    "JWKSUnavailable",
    "JWTValidator",
    "M2MClient",
    "MFARequired",
    "ProductNotEntitled",
    "StaleTimestamp",
    "TokenPair",
    "VerifiedEvent",
    "WebhookVerifier",
    "__version__",
]
