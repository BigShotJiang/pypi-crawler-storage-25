"""Bootstrap discovery via ``GET /.well-known/auth-config.json``.

Products give the SDK only ``BASE_URL``; everything else (issuer URI,
JWKS URL, endpoint paths, token lifetimes) is fetched from CentralAuth.
The result is cached in-process for a short TTL.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class AuthConfig:
    """Snapshot of the discovery doc."""

    issuer: str
    jwks_uri: str
    namespace: str
    auth_endpoints: dict[str, str]
    token_lifetimes: dict[str, int]
    supported_grant_types: tuple[str, ...]


class DiscoveryClient:
    """Fetches + caches ``/.well-known/auth-config.json``.

    The cache TTL is short (5 min default) — this URL describes
    *config*, not *secrets*, so re-fetching is cheap and handles
    deploy-time issuer rename / endpoint addition transparently.
    """

    def __init__(
        self,
        base_url: str,
        *,
        ttl_seconds: int = 300,
        timeout_seconds: float = 5.0,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._ttl = ttl_seconds
        self._timeout = timeout_seconds
        self._client = client
        self._cached: AuthConfig | None = None
        self._fetched_at: float = 0.0

    @property
    def base_url(self) -> str:
        return self._base_url

    def get(self) -> AuthConfig:
        if self._cached is None or (time.time() - self._fetched_at) > self._ttl:
            self._cached = self._fetch()
            self._fetched_at = time.time()
        return self._cached

    def invalidate(self) -> None:
        self._cached = None
        self._fetched_at = 0.0

    def _fetch(self) -> AuthConfig:
        url = f"{self._base_url}/.well-known/auth-config.json"
        client = self._client or httpx.Client(timeout=self._timeout)
        try:
            response = client.get(url)
        finally:
            if self._client is None:
                client.close()
        response.raise_for_status()
        payload: dict[str, Any] = response.json()
        return AuthConfig(
            issuer=payload["issuer"],
            jwks_uri=payload["jwks_uri"],
            namespace=payload["namespace"],
            auth_endpoints=dict(payload.get("auth_endpoints", {})),
            token_lifetimes=dict(payload.get("token_lifetimes", {})),
            supported_grant_types=tuple(payload.get("supported_grant_types", ())),
        )
