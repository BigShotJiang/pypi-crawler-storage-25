"""``AdminClient`` — server-side wrapper for ``/api/v1/*`` admin REST.

Authenticates with an M2M token (typically with ``admin_api:write`` /
``admin_api:read`` scope) so Phase 9 (QMS migration) and other backend
sync jobs can manage users, groups, products, and entitlements
programmatically.
"""
from __future__ import annotations

from typing import Any, Iterator

import httpx

from .auth_client import _safe_json
from .exceptions import AuthenticationFailed, CentralAuthAPIError


class AdminClient:
    """Thin REST wrapper over ``/api/v1/*``.

    The ``token_provider`` is a callable returning a fresh access token
    on demand — typically ``M2MClient.token_for("centralauth")`` or
    similar. The client doesn't cache the token itself; it asks each
    call so token-rotation is transparent.
    """

    def __init__(
        self,
        base_url: str,
        *,
        token_provider,           # type: ignore[no-untyped-def]
        timeout_seconds: float = 10.0,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token_provider = token_provider
        self._timeout = timeout_seconds
        self._client = client

    @classmethod
    def from_settings(
        cls,
        *,
        m2m: "M2MClient | None" = None,
        scopes: list[str] | None = None,
        client: httpx.Client | None = None,
    ) -> "AdminClient":
        """Build an AdminClient from Django ``settings.CENTRALAUTH``.

        Wires the token_provider to ``m2m.token_for("centralauth", scopes=...)``.
        Pass ``m2m=...`` to share an existing M2M client (recommended in
        long-running processes), or omit it to mint a fresh one from
        the same settings.
        """
        from .m2m_client import M2MClient
        from .django.conf import raw_settings  # local import: Django optional

        raw = raw_settings()
        if m2m is None:
            m2m = M2MClient.from_settings(client=client)
        scope_list = list(scopes or ["admin_api:read", "admin_api:write"])
        return cls(
            raw["BASE_URL"],
            token_provider=lambda: m2m.token_for("centralauth", scopes=scope_list),
            client=client,
        )

    # ─────────────────────────────────────────────────────────────────
    # Users
    # ─────────────────────────────────────────────────────────────────

    def list_users(
        self, *, search: str | None = None, is_active: bool | None = None,
    ) -> Iterator[dict[str, Any]]:
        params: dict[str, str] = {}
        if search:
            params["search"] = search
        if is_active is not None:
            params["is_active"] = str(is_active).lower()
        yield from self._iter_paginated("/api/v1/users/", params=params)

    def get_user(self, user_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/users/{user_id}/")

    def find_user_by_email(self, email: str) -> dict[str, Any] | None:
        """Return the user whose email matches exactly, or None.

        Email is globally unique in CentralAuth (locked Phase 0
        decision), so at most one user is returned. Implemented over
        the search filter — server-side ``__icontains`` — and verified
        client-side against the lower-cased email for an exact match.
        """
        target = email.strip().lower()
        if not target:
            return None
        for row in self.list_users(search=target):
            if str(row.get("email", "")).strip().lower() == target:
                return row
        return None

    def create_user(
        self, *, email: str, name: str,
        password: str | None = None, groups: list[str] | None = None,
    ) -> dict[str, Any]:
        return self._post("/api/v1/users/", {
            "email": email,
            "name": name,
            "password": password or "",
            "groups": groups or [],
        })

    def disable_user(self, user_id: str) -> dict[str, Any]:
        return self._post(f"/api/v1/users/{user_id}/disable/", {})

    def enable_user(self, user_id: str) -> dict[str, Any]:
        return self._post(f"/api/v1/users/{user_id}/enable/", {})

    def grant_group(self, user_id: str, group_id: str) -> dict[str, Any]:
        return self._post(f"/api/v1/users/{user_id}/groups/", {"group": group_id})

    def revoke_group(self, user_id: str, group_id: str) -> None:
        self._post(f"/api/v1/users/{user_id}/groups/{group_id}/revoke/", {})

    # ─────────────────────────────────────────────────────────────────
    # Groups
    # ─────────────────────────────────────────────────────────────────

    def list_groups(self) -> list[dict[str, Any]]:
        return self._get_list("/api/v1/groups/")

    def create_group(self, *, code: str, name: str, description: str = "") -> dict[str, Any]:
        return self._post("/api/v1/groups/", {
            "code": code, "name": name, "description": description,
        })

    # ─────────────────────────────────────────────────────────────────
    # Products + entitlements
    # ─────────────────────────────────────────────────────────────────

    def list_products(self) -> list[dict[str, Any]]:
        return self._get_list("/api/v1/products/")

    def grant_entitlement(self, *, user: str, product: str) -> dict[str, Any]:
        return self._post("/api/v1/entitlements/", {"user": user, "product": product})

    def revoke_entitlement(self, entitlement_id: str) -> None:
        self._post(f"/api/v1/entitlements/{entitlement_id}/revoke/", {})

    # ─────────────────────────────────────────────────────────────────
    # Employee profile + org catalogs (Phase 9 prep)
    # ─────────────────────────────────────────────────────────────────

    def get_user_profile(self, user_id: str) -> dict[str, Any] | None:
        """Return the employee profile (department, designation, location,
        phone, employee_type, extras) for ``user_id``, or ``None`` if not
        set yet.

        Profile data is *not* embedded in the JWT — products fetch it
        on demand and cache locally, invalidating on the
        ``user.profile_changed`` webhook.
        """
        try:
            return self._get(f"/api/v1/users/{user_id}/profile/")
        except CentralAuthAPIError as exc:
            if exc.status_code == 404:
                return None
            raise

    def set_user_profile(
        self, user_id: str,
        *,
        phone: str | None = None,
        employee_type: str | None = None,
        department: str | None = None,
        designation: str | None = None,
        location: str | None = None,
        extras: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Upsert the profile for ``user_id``. Only fields you pass are
        modified; ``None`` is treated as 'leave alone'."""
        body: dict[str, Any] = {}
        if phone is not None:
            body["phone"] = phone
        if employee_type is not None:
            body["employee_type"] = employee_type
        if department is not None:
            body["department"] = department
        if designation is not None:
            body["designation"] = designation
        if location is not None:
            body["location"] = location
        if extras is not None:
            body["extras"] = extras
        return self._patch(f"/api/v1/users/{user_id}/profile/", body)

    def list_departments(self) -> Iterator[dict[str, Any]]:
        yield from self._iter_paginated("/api/v1/departments/", params={})

    def list_designations(self) -> Iterator[dict[str, Any]]:
        yield from self._iter_paginated("/api/v1/designations/", params={})

    def list_locations(self) -> Iterator[dict[str, Any]]:
        yield from self._iter_paginated("/api/v1/locations/", params={})

    # ─────────────────────────────────────────────────────────────────
    # E-sign certificates (metadata only — no key material)
    # ─────────────────────────────────────────────────────────────────

    def list_esign_certificates(
        self, *, user: str | None = None, is_active: bool | None = None,
    ) -> Iterator[dict[str, Any]]:
        params: dict[str, str] = {}
        if user:
            params["user"] = user
        if is_active is not None:
            params["is_active"] = str(is_active).lower()
        yield from self._iter_paginated("/api/v1/esign-certificates/", params=params)

    def get_esign_certificate(self, cert_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/esign-certificates/{cert_id}/")

    def register_esign_certificate(
        self, *,
        user: str,
        serial_number: str,
        issuer: str,
        subject: str,
        valid_from: str,        # ISO-8601 string
        valid_to: str,
        thumbprint: str,
    ) -> dict[str, Any]:
        return self._post("/api/v1/esign-certificates/", {
            "user": user,
            "serial_number": serial_number,
            "issuer": issuer,
            "subject": subject,
            "valid_from": valid_from,
            "valid_to": valid_to,
            "thumbprint": thumbprint,
        })

    def revoke_esign_certificate(
        self, cert_id: str, *, reason: str = "",
    ) -> dict[str, Any]:
        return self._post(
            f"/api/v1/esign-certificates/{cert_id}/revoke/",
            {"revocation_reason": reason},
        )

    def list_user_esign_certificates(self, user_id: str) -> list[dict[str, Any]]:
        result = self._get(f"/api/v1/users/{user_id}/esign-certificates/")
        # The user-scoped endpoint returns a bare list, not a paginated dict.
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "data" in result:
            return list(result["data"])
        raise CentralAuthAPIError(
            f"Unexpected user-esign list shape: {type(result).__name__}",
        )

    # ─────────────────────────────────────────────────────────────────
    # Audit
    # ─────────────────────────────────────────────────────────────────

    def query_audit(
        self, *,
        event_type: str | None = None,
        user: str | None = None,
        product: str | None = None,
    ) -> Iterator[dict[str, Any]]:
        params: dict[str, str] = {}
        if event_type:
            params["event_type"] = event_type
        if user:
            params["user"] = user
        if product:
            params["product"] = product
        yield from self._iter_paginated("/api/v1/audit/", params=params)

    # ─────────────────────────────────────────────────────────────────
    # HTTP helpers
    # ─────────────────────────────────────────────────────────────────

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token_provider()}"}

    def _http(self) -> httpx.Client:
        return self._client or httpx.Client()

    def _get(self, path: str, *, params: dict[str, str] | None = None) -> dict[str, Any]:
        response = self._http().get(
            f"{self._base_url}{path}",
            params=params or {},
            headers=self._headers(),
            timeout=self._timeout,
        )
        return _check_response(response)

    def _get_list(self, path: str) -> list[dict[str, Any]]:
        result = self._get(path)
        # Some admin endpoints return a bare list; others wrap in {data, ...}
        if isinstance(result, list):
            return result
        if isinstance(result, dict) and "data" in result:
            return list(result["data"])
        raise CentralAuthAPIError(
            f"Unexpected response shape from {path}: {type(result).__name__}",
        )

    def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        response = self._http().post(
            f"{self._base_url}{path}",
            json=body,
            headers=self._headers(),
            timeout=self._timeout,
        )
        return _check_response(response)

    def _patch(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        response = self._http().patch(
            f"{self._base_url}{path}",
            json=body,
            headers=self._headers(),
            timeout=self._timeout,
        )
        return _check_response(response)

    def _iter_paginated(
        self, path: str, *, params: dict[str, str],
    ) -> Iterator[dict[str, Any]]:
        cursor: str | None = None
        while True:
            page_params = dict(params)
            if cursor:
                page_params["cursor"] = cursor
            page = self._get(path, params=page_params)
            if not isinstance(page, dict) or "data" not in page:
                # Paginated endpoint wasn't paginated — yield once and stop.
                if isinstance(page, list):
                    yield from page
                return
            for row in page["data"]:
                yield row
            cursor = page.get("next_cursor")
            if not cursor:
                return


def _check_response(response: httpx.Response) -> dict[str, Any]:
    if response.status_code == 204:
        return {}
    body = _safe_json(response)
    if response.status_code == 401:
        raise AuthenticationFailed(
            "Admin API rejected the M2M token",
            status_code=response.status_code, body=body,
        )
    if response.status_code >= 400:
        raise CentralAuthAPIError(
            str(body.get("title") or body.get("detail") or body.get("error") or f"HTTP {response.status_code}"),
            status_code=response.status_code, body=body,
        )
    return body
