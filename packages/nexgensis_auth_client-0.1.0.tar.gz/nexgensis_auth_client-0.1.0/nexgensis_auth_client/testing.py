"""Test helpers for products that consume the SDK.

Lets a product write tests like::

    from nexgensis_auth_client.testing import build_auth_context, override_auth

    def test_qa_lead_can_close(client):
        ctx = build_auth_context(
            user_id="u-123",
            email="qa@example.com",
            groups=["QA_LEAD"],
        )
        with override_auth(client, ctx):
            response = client.post("/issues/I-1/close/")
        assert response.status_code == 200

without standing up a real CentralAuth + JWKS round-trip.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator

from .auth_context import AuthContext

DEFAULT_NAMESPACE = "https://centralauth.local"


def build_auth_context(
    *,
    user_id: str = "test-user",
    email: str = "test@example.com",
    name: str = "Test User",
    is_superuser: bool = False,
    is_service: bool = False,
    groups: list[str] | None = None,
    entitlements: list[str] | None = None,
    scopes: list[str] | None = None,
    audience: str = "test-product",
    issuer: str = "https://centralauth.local",
    namespace: str = DEFAULT_NAMESPACE,
    extra_claims: dict[str, Any] | None = None,
) -> AuthContext:
    """Build a fully-populated :class:`AuthContext` for tests."""
    ns = namespace.rstrip("/")
    claims: dict[str, Any] = {
        "sub": user_id,
        "iss": issuer,
        "aud": audience,
        "email": email,
        "name": name,
        "preferred_username": email,
        "exp": 9999999999,
        f"{ns}/groups": groups or [],
        f"{ns}/entitlements": entitlements or [],
        f"{ns}/scopes": scopes or [],
        f"{ns}/is_superuser": is_superuser,
    }
    if is_service:
        claims[f"{ns}/client_type"] = "service"
    if extra_claims:
        claims.update(extra_claims)
    return AuthContext(claims, namespace=ns)


class MockAuthContext(AuthContext):
    """Backwards-compat alias — :func:`build_auth_context` returns a
    real :class:`AuthContext`, which is all most tests need. Subclass
    if a test fixture must override behaviour."""


# ── Pytest / Django override helpers ────────────────────────────────


@contextmanager
def override_auth(client: Any, ctx: AuthContext) -> Iterator[None]:
    """Temporarily make a Django/DRF test client authenticate as ``ctx``.

    Implementation: monkeypatches the SDK's JWTAuthentication to return
    ``ctx`` on every call, regardless of headers. Restores the original
    behaviour on exit.

    The DRF test client honours the substitution because the
    authentication class is what produces ``request.auth`` and
    ``request.user`` — and the substitute sees no headers and just
    forces the ctx in.
    """
    try:
        from .django.authentication import JWTAuthentication, SDKUser  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "override_auth requires Django + djangorestframework installed.",
        ) from exc

    original = JWTAuthentication.authenticate

    def _patched(self: JWTAuthentication, request: Any) -> tuple[SDKUser, AuthContext]:
        return SDKUser(ctx), ctx

    JWTAuthentication.authenticate = _patched  # type: ignore[assignment,method-assign]
    try:
        yield
    finally:
        JWTAuthentication.authenticate = original  # type: ignore[assignment,method-assign]


def make_authorization_header(_ctx: AuthContext) -> str:
    """Cosmetic helper for tests that want a "Bearer ..." header.

    The token isn't a real JWT — :func:`override_auth` skips validation
    entirely. This just gives integration tests a believable-looking
    header to send.
    """
    return "Bearer test.fake.jwt"


__all__ = [
    "DEFAULT_NAMESPACE",
    "MockAuthContext",
    "build_auth_context",
    "make_authorization_header",
    "override_auth",
]
