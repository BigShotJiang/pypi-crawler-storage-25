"""``AuthClient`` — wraps ``/oauth/*`` and ``/api/auth/*``.

Used by products that do server-side auth (ROPC) and need to call
CentralAuth on behalf of the human user. Browser-redirect (Authorization
Code) flow is also supported for products that bounce the user
through CentralAuth.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from .exceptions import AuthenticationFailed, CentralAuthAPIError, MFARequired


@dataclass(frozen=True, slots=True)
class TokenPair:
    access_token: str
    refresh_token: str | None
    expires_in: int
    token_type: str = "Bearer"


class AuthClient:
    """Calls user-facing auth endpoints on CentralAuth.

    Requires the consuming product's ``client_id`` + ``client_secret``
    (registered via the admin UI). Some flows authenticate the call with
    HTTP Basic; others rely on an existing access token from the user.
    """

    def __init__(
        self,
        base_url: str,
        *,
        client_id: str,
        client_secret: str,
        timeout_seconds: float = 10.0,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self._timeout = timeout_seconds
        self._client = client

    @classmethod
    def from_settings(cls, *, client: httpx.Client | None = None) -> "AuthClient":
        """Build an AuthClient from Django ``settings.CENTRALAUTH``.

        Requires ``BASE_URL``, ``CLIENT_ID``, ``CLIENT_SECRET``. Convenience
        for products that don't want to pass them around manually.
        """
        from .django.conf import raw_settings  # local import: Django optional
        from django.core.exceptions import ImproperlyConfigured

        raw = raw_settings()
        cid = raw.get("CLIENT_ID") or raw.get("AUDIENCE")
        secret = raw.get("CLIENT_SECRET")
        if not cid or not secret:
            raise ImproperlyConfigured(
                "AuthClient.from_settings requires CENTRALAUTH['CLIENT_ID'] and ['CLIENT_SECRET'].",
            )
        return cls(
            raw["BASE_URL"],
            client_id=cid,
            client_secret=secret,
            client=client,
        )

    # ─────────────────────────────────────────────────────────────────
    # Token endpoint
    # ─────────────────────────────────────────────────────────────────

    def login(
        self,
        email: str,
        password: str,
        *,
        audience: str | None = None,
        remember_me: bool = False,
    ) -> TokenPair:
        """ROPC login.

        ``audience`` defaults to this client's own ``client_id`` (the
        most common case — a product authenticating its own users).
        """
        body = {
            "grant_type": "password",
            "username": email,
            "password": password,
            "audience": audience or self._client_id,
            "remember_me": remember_me,
        }
        return self._token_call(body)

    def refresh(self, refresh_token: str) -> TokenPair:
        return self._token_call({
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        })

    def exchange_code(self, *, code: str, redirect_uri: str) -> TokenPair:
        """Authorization Code grant — exchange an auth code for tokens.

        Phase 5 stubs the auth-code flow at the CentralAuth side; this
        method returns when Phase 5b ships. For now it surfaces the
        ``unsupported_grant_type`` error from the server.
        """
        return self._token_call({
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": self._client_id,
        })

    def revoke(self, refresh_token: str) -> None:
        """RFC 7009-style revoke — fire and forget; always succeeds at
        the protocol layer."""
        self._post_form("/oauth/revoke", {"refresh_token": refresh_token})

    # ─────────────────────────────────────────────────────────────────
    # User-facing endpoints
    # ─────────────────────────────────────────────────────────────────

    def userinfo(self, access_token: str) -> dict[str, Any]:
        """Fetch ``GET /api/auth/userinfo`` for the bearer."""
        return self._get_json("/api/auth/userinfo", access_token=access_token)

    def logout(self, refresh_token: str) -> None:
        """Best-effort server-side revoke. Errors swallowed (the caller
        will clear tokens locally regardless)."""
        try:
            self._post_json("/api/auth/logout", {"refresh_token": refresh_token})
        except CentralAuthAPIError:
            pass

    def change_password(
        self, *, access_token: str, current_password: str, new_password: str,
    ) -> None:
        self._post_json(
            "/api/auth/change-password",
            {"current_password": current_password, "new_password": new_password},
            access_token=access_token,
        )

    def forgot_password(self, email: str) -> None:
        """Anti-enumeration: always succeeds at the API level."""
        self._post_json("/api/auth/forgot-password", {"email": email})

    # ─────────────────────────────────────────────────────────────────
    # Internals
    # ─────────────────────────────────────────────────────────────────

    def _token_call(self, body: dict[str, Any]) -> TokenPair:
        response = self._http().post(
            f"{self._base_url}/oauth/token",
            json=body,
            auth=(self._client_id, self._client_secret),
            timeout=self._timeout,
        )
        data: dict[str, Any] = _safe_json(response)

        if response.status_code == 200 and data.get("error") == "mfa_required":
            raise MFARequired(mfa_token=str(data.get("mfa_token", "")), body=data)

        if response.status_code == 401:
            raise AuthenticationFailed(
                str(data.get("message") or data.get("error") or "Authentication failed"),
                status_code=response.status_code, body=data,
            )
        if response.status_code >= 400:
            raise CentralAuthAPIError(
                str(data.get("message") or data.get("error") or f"HTTP {response.status_code}"),
                status_code=response.status_code, body=data,
            )

        return TokenPair(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            expires_in=int(data.get("expires_in", 0)),
            token_type=str(data.get("token_type", "Bearer")),
        )

    def _post_form(self, path: str, data: dict[str, Any]) -> dict[str, Any]:
        response = self._http().post(
            f"{self._base_url}{path}", data=data, timeout=self._timeout,
        )
        return _raise_for_status(response)

    def _post_json(
        self, path: str, body: dict[str, Any], *, access_token: str | None = None,
    ) -> dict[str, Any]:
        headers = _bearer_headers(access_token)
        response = self._http().post(
            f"{self._base_url}{path}", json=body, headers=headers, timeout=self._timeout,
        )
        return _raise_for_status(response)

    def _get_json(self, path: str, *, access_token: str) -> dict[str, Any]:
        headers = _bearer_headers(access_token)
        response = self._http().get(
            f"{self._base_url}{path}", headers=headers, timeout=self._timeout,
        )
        return _raise_for_status(response)

    def _http(self) -> httpx.Client:
        return self._client or httpx.Client()


def _bearer_headers(access_token: str | None) -> dict[str, str]:
    if not access_token:
        return {}
    return {"Authorization": f"Bearer {access_token}"}


def _safe_json(response: httpx.Response) -> dict[str, Any]:
    try:
        return response.json()
    except Exception:  # noqa: BLE001
        return {}


def _raise_for_status(response: httpx.Response) -> dict[str, Any]:
    if response.status_code >= 400:
        body = _safe_json(response)
        if response.status_code == 401:
            raise AuthenticationFailed(
                str(body.get("message") or body.get("error") or "Unauthorized"),
                status_code=response.status_code, body=body,
            )
        raise CentralAuthAPIError(
            str(body.get("message") or body.get("error") or body.get("title") or f"HTTP {response.status_code}"),
            status_code=response.status_code, body=body,
        )
    return _safe_json(response)
