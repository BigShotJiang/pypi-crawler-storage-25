"""AuthContext — a friendly wrapper around the JWT claims dict.

Products read fields off this object instead of digging through the
namespaced custom claims directly. Stable surface across SDK versions.
"""
from __future__ import annotations

from typing import Any


class AuthContext:
    """Wraps a validated claims dict.

    Usage::

        ctx = AuthContext(claims, namespace="https://auth.example.com")
        if ctx.is_superuser:
            ...
        if ctx.has_group("QA_LEAD"):
            ...
    """

    def __init__(self, claims: dict[str, Any], *, namespace: str) -> None:
        self._claims = claims
        self._ns = namespace.rstrip("/")

    # ── Identity ─────────────────────────────────────────────────────

    @property
    def claims(self) -> dict[str, Any]:
        """Underlying claim dict (read-only)."""
        return dict(self._claims)

    @property
    def is_authenticated(self) -> bool:
        return "sub" in self._claims

    @property
    def user_id(self) -> str:
        return str(self._claims.get("sub", ""))

    @property
    def email(self) -> str:
        return str(self._claims.get("email", ""))

    @property
    def email_verified(self) -> bool:
        return bool(self._claims.get("email_verified", False))

    @property
    def name(self) -> str:
        return str(self._claims.get("name", ""))

    @property
    def preferred_username(self) -> str:
        return str(self._claims.get("preferred_username", ""))

    @property
    def picture(self) -> str | None:
        return self._claims.get("picture") or None

    # ── Token type ──────────────────────────────────────────────────

    @property
    def is_service(self) -> bool:
        return self._claims.get(f"{self._ns}/client_type") == "service"

    @property
    def is_superuser(self) -> bool:
        return bool(self._claims.get(f"{self._ns}/is_superuser", False))

    @property
    def has_set_password(self) -> bool:
        return bool(self._claims.get(f"{self._ns}/has_set_password", False))

    # ── Authorization (user) ────────────────────────────────────────

    @property
    def groups(self) -> list[str]:
        return list(self._claims.get(f"{self._ns}/groups", []) or [])

    @property
    def entitlements(self) -> list[str]:
        return list(self._claims.get(f"{self._ns}/entitlements", []) or [])

    def has_group(self, code: str) -> bool:
        return code in self.groups

    def has_any_group(self, codes: list[str]) -> bool:
        return bool(set(codes) & set(self.groups))

    def has_all_groups(self, codes: list[str]) -> bool:
        return set(codes).issubset(set(self.groups))

    def has_entitlement(self, client_id: str) -> bool:
        return client_id in self.entitlements

    # ── Authorization (M2M) ─────────────────────────────────────────

    @property
    def scopes(self) -> list[str]:
        return list(self._claims.get(f"{self._ns}/scopes", []) or [])

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes

    # ── Token metadata ──────────────────────────────────────────────

    @property
    def jti(self) -> str:
        return str(self._claims.get("jti", ""))

    @property
    def audience(self) -> str:
        aud = self._claims.get("aud")
        if isinstance(aud, list):
            return aud[0] if aud else ""
        return str(aud or "")

    @property
    def issuer(self) -> str:
        return str(self._claims.get("iss", ""))

    @property
    def expires_at(self) -> int:
        return int(self._claims.get("exp", 0))

    def __repr__(self) -> str:
        if self.is_service:
            return f"<AuthContext service={self.user_id!r} aud={self.audience!r}>"
        return f"<AuthContext user={self.email!r} groups={self.groups}>"
