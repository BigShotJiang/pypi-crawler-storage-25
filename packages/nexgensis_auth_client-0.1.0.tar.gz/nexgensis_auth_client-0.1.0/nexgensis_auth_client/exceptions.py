"""Public exception hierarchy for the SDK.

Stable error types so consuming products can `except` precisely
(InvalidToken, ExpiredToken, InsufficientGroup, etc.) without parsing
HTTP body strings.
"""
from __future__ import annotations


class CentralAuthError(Exception):
    """Root of all SDK errors."""


# ── Token validation ────────────────────────────────────────────────────────


class InvalidToken(CentralAuthError):
    """Token failed validation (signature, audience, format, etc.)."""


class ExpiredToken(InvalidToken):
    """Token signature is valid but the `exp` claim has passed."""


class JWKSUnavailable(CentralAuthError):
    """Could not fetch JWKS and have no cached key — token rejected."""


# ── HTTP / API ─────────────────────────────────────────────────────────────


class CentralAuthAPIError(CentralAuthError):
    """A non-2xx response from CentralAuth.

    The .response attribute (when present) carries the raw httpx.Response
    so callers can read .status_code / .json() if they need the
    machine-readable problem-details body.
    """

    def __init__(self, message: str, *, status_code: int | None = None, body: object = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthenticationFailed(CentralAuthAPIError):
    """Login or token refresh rejected (401-equivalent)."""


class MFARequired(CentralAuthAPIError):
    """Login succeeded credentials-wise; MFA challenge needed.

    The `mfa_token` attribute is the opaque token to present alongside
    the user's MFA code in the follow-up call.
    """

    def __init__(self, mfa_token: str, *, body: object = None) -> None:
        super().__init__("MFA challenge required", status_code=200, body=body)
        self.mfa_token = mfa_token


# ── Authorization (DRF integration) ─────────────────────────────────────────


class InsufficientGroup(CentralAuthError):
    """User's groups don't include the one(s) required for this endpoint."""


class InsufficientScope(CentralAuthError):
    """M2M token doesn't include a required scope."""


class ProductNotEntitled(CentralAuthError):
    """Authenticated user has no entitlement for this product."""


# ── Webhooks ────────────────────────────────────────────────────────────────


class InvalidSignature(CentralAuthError):
    """Webhook delivery's HMAC signature doesn't match the expected value."""


class StaleTimestamp(CentralAuthError):
    """Webhook X-Auth-Timestamp is outside the replay window."""
