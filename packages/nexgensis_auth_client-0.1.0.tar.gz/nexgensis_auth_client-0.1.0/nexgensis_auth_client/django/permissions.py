"""DRF permission classes that pivot on the JWT's claim set.

Pattern::

    @api_view(["GET"])
    @permission_classes([IsAuthenticated, HasGroup("QA_LEAD")])
    def my_view(request): ...

Each class is a *factory* that returns a permission class so usage is
declarative. ``HasAnyGroup`` accepts a list and short-circuits on first
match.
"""
from __future__ import annotations

from typing import Any

try:
    from rest_framework.permissions import BasePermission  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "nexgensis_auth_client.django.permissions requires djangorestframework.",
    ) from exc

from ..auth_context import AuthContext


def _ctx(request: Any) -> AuthContext | None:
    auth = getattr(request, "auth", None)
    if isinstance(auth, AuthContext):
        return auth
    return None


# ─────────────────────────────────────────────────────────────────────
# Identity-flavoured gates
# ─────────────────────────────────────────────────────────────────────


class IsCentralAuthAuthenticated(BasePermission):
    """Replacement for DRF's IsAuthenticated when our SDK provides auth.

    Works without Django's auth backends — only checks the JWT claims.
    """

    message = "Authentication required."

    def has_permission(self, request: Any, view: Any) -> bool:
        ctx = _ctx(request)
        return bool(ctx and ctx.is_authenticated)


class IsSuperuser(BasePermission):
    message = "Super-admin access required."

    def has_permission(self, request: Any, view: Any) -> bool:
        ctx = _ctx(request)
        return bool(ctx and ctx.is_superuser)


class IsService(BasePermission):
    """The token was minted via client_credentials (M2M)."""

    message = "Service-only endpoint."

    def has_permission(self, request: Any, view: Any) -> bool:
        ctx = _ctx(request)
        return bool(ctx and ctx.is_service)


# ─────────────────────────────────────────────────────────────────────
# Group / entitlement / scope factories
# ─────────────────────────────────────────────────────────────────────


def HasGroup(code: str) -> type[BasePermission]:  # noqa: N802 (DRF naming convention)
    """Require the user have membership in ``code``."""

    class _HasGroup(BasePermission):
        message = f"Requires group membership: {code}"

        def has_permission(self, request: Any, view: Any) -> bool:
            ctx = _ctx(request)
            return bool(ctx and ctx.has_group(code))

    _HasGroup.__name__ = f"HasGroup[{code}]"
    return _HasGroup


def HasAnyGroup(*codes: str) -> type[BasePermission]:  # noqa: N802
    """Require membership in at least one of ``codes``."""
    code_list = list(codes)

    class _HasAnyGroup(BasePermission):
        message = f"Requires one of groups: {code_list}"

        def has_permission(self, request: Any, view: Any) -> bool:
            ctx = _ctx(request)
            return bool(ctx and ctx.has_any_group(code_list))

    _HasAnyGroup.__name__ = f"HasAnyGroup[{','.join(code_list)}]"
    return _HasAnyGroup


def HasAllGroups(*codes: str) -> type[BasePermission]:  # noqa: N802
    """Require membership in *every* code listed."""
    code_list = list(codes)

    class _HasAllGroups(BasePermission):
        message = f"Requires all of groups: {code_list}"

        def has_permission(self, request: Any, view: Any) -> bool:
            ctx = _ctx(request)
            return bool(ctx and ctx.has_all_groups(code_list))

    _HasAllGroups.__name__ = f"HasAllGroups[{','.join(code_list)}]"
    return _HasAllGroups


def HasEntitlement(client_id: str) -> type[BasePermission]:  # noqa: N802
    """Require the user have an active entitlement for ``client_id``.

    Use this on endpoints in product A that should only respond if the
    user is also entitled to product B.
    """

    class _HasEntitlement(BasePermission):
        message = f"Missing entitlement for product: {client_id}"

        def has_permission(self, request: Any, view: Any) -> bool:
            ctx = _ctx(request)
            return bool(ctx and ctx.has_entitlement(client_id))

    _HasEntitlement.__name__ = f"HasEntitlement[{client_id}]"
    return _HasEntitlement


def HasScope(scope: str) -> type[BasePermission]:  # noqa: N802
    """For M2M endpoints — require the service token carry ``scope``."""

    class _HasScope(BasePermission):
        message = f"Missing required scope: {scope}"

        def has_permission(self, request: Any, view: Any) -> bool:
            ctx = _ctx(request)
            return bool(ctx and ctx.has_scope(scope))

    _HasScope.__name__ = f"HasScope[{scope}]"
    return _HasScope
