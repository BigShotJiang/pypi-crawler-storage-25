"""``AuthMiddleware`` — populates ``request.auth_context`` for Django views.

This is the non-DRF entry point. Plain Django views can read
``request.auth_context.has_group(...)`` without a DRF dependency. The
middleware never *rejects* a request — it only attaches context when a
valid token is present. Authorization (allow/deny) is the view's job.

Wire-up::

    MIDDLEWARE = [
        # ...
        "nexgensis_auth_client.django.middleware.AuthMiddleware",
    ]

For DRF views, use the ``JWTAuthentication`` class instead — it raises
401 on bad tokens, which is the expected DRF semantics.
"""
from __future__ import annotations

import logging
from typing import Any, Callable

from ..auth_context import AuthContext
from ..exceptions import ExpiredToken, InvalidToken, JWKSUnavailable
from .conf import get_config

logger = logging.getLogger(__name__)


class AuthMiddleware:
    """Attaches an :class:`AuthContext` to the request when a valid
    Bearer token is present. Silent on bad tokens — view-level
    permission checks decide what to do."""

    def __init__(self, get_response: Callable[[Any], Any]) -> None:
        self._get_response = get_response

    def __call__(self, request: Any) -> Any:
        auth_header = request.META.get("HTTP_AUTHORIZATION", "")
        token = _extract_bearer(auth_header)
        request.auth_context = None
        if token:
            try:
                config = get_config()
                claims = config.validator.validate(token)
                request.auth_context = AuthContext(claims, namespace=config.namespace)
            except (ExpiredToken, InvalidToken):
                # Silent: the view's permission check returns 401/403.
                pass
            except JWKSUnavailable:
                logger.warning("centralauth.jwks_unavailable")
        return self._get_response(request)


def _extract_bearer(header: str) -> str | None:
    if not header:
        return None
    parts = header.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1].strip() or None
