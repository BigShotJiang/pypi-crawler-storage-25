"""Process-global SDK configuration for Django apps.

Products configure the SDK once via Django settings::

    CENTRALAUTH = {
        "BASE_URL": "https://auth.example.com",
        "AUDIENCE": "qms",                      # this product's client_id
        "CLIENT_ID":     "qms",                 # OAuth client_id (often same as AUDIENCE)
        "CLIENT_SECRET": "<env var>",           # required for AuthClient/M2MClient.from_settings
        "JWKS_TTL_SECONDS": 300,                # optional
        "DISCOVERY_TTL_SECONDS": 300,           # optional
        "LEEWAY_SECONDS": 60,                   # optional clock skew
    }

The middleware / DRF auth class read :func:`get_config`. AuthClient,
AdminClient, and M2MClient each expose a ``from_settings()`` classmethod
that pulls the same dict via :func:`raw_settings`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from threading import Lock
from typing import Any

try:
    from django.conf import settings as django_settings  # type: ignore
    from django.core.exceptions import ImproperlyConfigured  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "nexgensis_auth_client.django requires Django to be installed.",
    ) from exc

from ..discovery import DiscoveryClient
from ..jwks_cache import JWKSCache
from ..jwt_validator import JWTValidator


@dataclass
class _SDKConfig:
    base_url: str
    audience: str
    discovery: DiscoveryClient
    jwks: JWKSCache
    validator: JWTValidator
    namespace: str
    extras: dict[str, Any] = field(default_factory=dict)


_CONFIG: _SDKConfig | None = None
_LOCK = Lock()


def get_config() -> _SDKConfig:
    """Build (and cache) the singleton SDK config from Django settings."""
    global _CONFIG
    if _CONFIG is not None:
        return _CONFIG
    with _LOCK:
        if _CONFIG is not None:
            return _CONFIG
        _CONFIG = _build_from_settings()
        return _CONFIG


def reset_config() -> None:
    """Test-only: clear the cached config so the next call rebuilds it."""
    global _CONFIG
    with _LOCK:
        _CONFIG = None


def raw_settings() -> dict[str, Any]:
    """Return the ``CENTRALAUTH`` settings dict, validated for presence.

    Used by ``AuthClient.from_settings()``, ``AdminClient.from_settings()``,
    and ``M2MClient.from_settings()`` so callers don't repeat the
    boilerplate. Raises :class:`ImproperlyConfigured` if the dict is
    missing or empty.
    """
    raw = getattr(django_settings, "CENTRALAUTH", None)
    if not raw or not isinstance(raw, dict):
        raise ImproperlyConfigured(
            "Add CENTRALAUTH = {...} to Django settings before using the SDK.",
        )
    if not raw.get("BASE_URL"):
        raise ImproperlyConfigured("CENTRALAUTH['BASE_URL'] is required.")
    return dict(raw)


def _build_from_settings() -> _SDKConfig:
    raw = getattr(django_settings, "CENTRALAUTH", None)
    if not raw or not isinstance(raw, dict):
        raise ImproperlyConfigured(
            "Add CENTRALAUTH = {...} to Django settings before using the SDK.",
        )
    base_url = raw.get("BASE_URL")
    audience = raw.get("AUDIENCE")
    if not base_url or not audience:
        raise ImproperlyConfigured(
            "CENTRALAUTH['BASE_URL'] and CENTRALAUTH['AUDIENCE'] are required.",
        )

    discovery_ttl = int(raw.get("DISCOVERY_TTL_SECONDS", 300))
    jwks_ttl = int(raw.get("JWKS_TTL_SECONDS", 300))
    leeway = int(raw.get("LEEWAY_SECONDS", 60))

    discovery = DiscoveryClient(base_url, ttl_seconds=discovery_ttl)
    config = discovery.get()

    jwks = JWKSCache(config.jwks_uri, ttl_seconds=jwks_ttl)
    validator = JWTValidator(
        jwks,
        issuer=config.issuer,
        audience=audience,
        leeway_seconds=leeway,
    )
    return _SDKConfig(
        base_url=base_url.rstrip("/"),
        audience=audience,
        discovery=discovery,
        jwks=jwks,
        validator=validator,
        namespace=config.namespace,
        extras=dict(raw),
    )
