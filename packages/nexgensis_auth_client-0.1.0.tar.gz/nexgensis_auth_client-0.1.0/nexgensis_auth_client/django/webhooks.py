"""Django decorator for webhook receivers.

Usage::

    from nexgensis_auth_client.django.webhooks import webhook_view

    @webhook_view(secret_setting="QMS_USER_SYNC_SECRET")
    def on_user_event(request, event):
        if event.event_type == "user.disabled":
            ...
        return HttpResponse(status=200)

The decorator handles HMAC verification, timestamp skew, and idempotent
dedupe in-process; the wrapped view is only called for valid, novel
events. Duplicates return ``200 OK`` (so CentralAuth marks them
delivered) without re-running side effects.

By design the secret comes from a Django setting name (so it can be
read once and rotated by env-var change without a redeploy). Callers
that already have a verifier built can pass ``verifier=`` instead.
"""
from __future__ import annotations

import logging
from functools import wraps
from typing import Any, Callable

try:
    from django.conf import settings as django_settings  # type: ignore
    from django.core.exceptions import ImproperlyConfigured  # type: ignore
    from django.http import HttpRequest, HttpResponse, JsonResponse  # type: ignore
    from django.views.decorators.csrf import csrf_exempt  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "nexgensis_auth_client.django.webhooks requires Django.",
    ) from exc

from ..exceptions import InvalidSignature, StaleTimestamp
from ..webhook import VerifiedEvent, WebhookVerifier

logger = logging.getLogger(__name__)


_VERIFIER_CACHE: dict[str, WebhookVerifier] = {}


def webhook_view(
    *,
    secret_setting: str | None = None,
    secret: str | None = None,
    verifier: WebhookVerifier | None = None,
    max_skew_seconds: int = 300,
    dedupe_size: int = 10_000,
) -> Callable[[Callable[..., HttpResponse]], Callable[..., HttpResponse]]:
    """Decorate a Django view so it only runs on validated webhook payloads.

    Provide exactly one of:
      - ``secret_setting``: name of the Django setting holding the raw secret
      - ``secret``: the raw secret directly (for tests)
      - ``verifier``: a pre-built :class:`WebhookVerifier`

    The wrapped view is called as ``view(request, event, **kwargs)`` —
    ``event`` is a :class:`VerifiedEvent` carrying ``event_id``,
    ``event_type``, ``timestamp``, and ``duplicate``.
    """
    if sum(x is not None for x in (secret_setting, secret, verifier)) != 1:
        raise ImproperlyConfigured(
            "webhook_view: pass exactly one of secret_setting, secret, or verifier.",
        )

    def decorator(view: Callable[..., HttpResponse]) -> Callable[..., HttpResponse]:
        @csrf_exempt
        @wraps(view)
        def _wrapped(request: HttpRequest, *args: Any, **kwargs: Any) -> HttpResponse:
            if request.method != "POST":
                return HttpResponse(status=405, headers={"Allow": "POST"})

            v = _resolve_verifier(
                verifier, secret, secret_setting, max_skew_seconds, dedupe_size,
            )

            try:
                event = v.verify(headers=_headers_for(request), body=request.body)
            except StaleTimestamp as exc:
                logger.warning("webhook.stale_timestamp", extra={"reason": str(exc)})
                return _problem(400, "stale_timestamp", str(exc))
            except InvalidSignature as exc:
                logger.warning("webhook.invalid_signature", extra={"reason": str(exc)})
                return _problem(401, "invalid_signature", str(exc))

            if event.duplicate:
                logger.info(
                    "webhook.duplicate_skipped",
                    extra={"event_id": event.event_id, "event_type": event.event_type},
                )
                return HttpResponse(status=200)

            return view(request, event, *args, **kwargs)

        return _wrapped

    return decorator


# ── Internals ───────────────────────────────────────────────────────


def _resolve_verifier(
    verifier: WebhookVerifier | None,
    secret: str | None,
    secret_setting: str | None,
    max_skew: int,
    dedupe_size: int,
) -> WebhookVerifier:
    if verifier is not None:
        return verifier
    if secret is not None:
        cache_key = f"__inline__:{id(secret)}"
        cached = _VERIFIER_CACHE.get(cache_key)
        if cached is None:
            cached = WebhookVerifier(secret, max_skew_seconds=max_skew, dedupe_size=dedupe_size)
            _VERIFIER_CACHE[cache_key] = cached
        return cached

    assert secret_setting is not None
    raw = getattr(django_settings, secret_setting, None)
    if not raw:
        raise ImproperlyConfigured(
            f"Setting {secret_setting!r} is empty — cannot verify webhooks.",
        )
    cached = _VERIFIER_CACHE.get(secret_setting)
    if cached is None:
        cached = WebhookVerifier(raw, max_skew_seconds=max_skew, dedupe_size=dedupe_size)
        _VERIFIER_CACHE[secret_setting] = cached
    return cached


def _headers_for(request: HttpRequest) -> dict[str, str]:
    out: dict[str, str] = {}
    for key, value in request.META.items():
        if key.startswith("HTTP_"):
            normalized = "-".join(part.capitalize() for part in key[len("HTTP_"):].split("_"))
            out[normalized] = value
    return out


def _problem(status: int, slug: str, detail: str) -> JsonResponse:
    return JsonResponse(
        {"type": f"about:blank#{slug}", "title": slug, "status": status, "detail": detail},
        status=status,
        content_type="application/problem+json",
    )


__all__ = ["webhook_view", "VerifiedEvent"]
