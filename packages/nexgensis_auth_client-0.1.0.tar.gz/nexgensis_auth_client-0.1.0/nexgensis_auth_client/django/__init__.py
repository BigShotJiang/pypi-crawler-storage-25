"""Django integration for the CentralAuth SDK.

Submodules:
    conf            — process-global config from Django settings
    authentication  — DRF JWTAuthentication class (request.user, request.auth)
    permissions     — HasGroup / HasEntitlement / HasScope DRF permissions
    middleware      — AuthMiddleware for plain Django views
    webhooks        — @webhook_view decorator (HMAC + timestamp + dedupe)
"""
from .authentication import JWTAuthentication, SDKUser
from .conf import get_config, reset_config
from .middleware import AuthMiddleware
from .permissions import (
    HasAllGroups,
    HasAnyGroup,
    HasEntitlement,
    HasGroup,
    HasScope,
    IsCentralAuthAuthenticated,
    IsService,
    IsSuperuser,
)
from .webhooks import webhook_view

__all__ = [
    "AuthMiddleware",
    "HasAllGroups",
    "HasAnyGroup",
    "HasEntitlement",
    "HasGroup",
    "HasScope",
    "IsCentralAuthAuthenticated",
    "IsService",
    "IsSuperuser",
    "JWTAuthentication",
    "SDKUser",
    "get_config",
    "reset_config",
    "webhook_view",
]
