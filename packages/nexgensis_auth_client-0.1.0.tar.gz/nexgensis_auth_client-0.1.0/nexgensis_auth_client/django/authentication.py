"""DRF authentication that validates Django-issued JWTs from CentralAuth.

Wire it up in DRF's settings::

    REST_FRAMEWORK = {
        "DEFAULT_AUTHENTICATION_CLASSES": [
            "nexgensis_auth_client.django.authentication.JWTAuthentication",
        ],
    }

After auth, ``request.user`` is a lightweight stand-in (``SDKUser``) and
``request.auth`` is the :class:`AuthContext`. Products do not have to
mirror CentralAuth's User table — the SDK delivers everything they need
on the request.
"""
from __future__ import annotations

from typing import Any

try:
    from rest_framework import authentication, exceptions  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "nexgensis_auth_client.django.authentication requires djangorestframework.",
    ) from exc

from ..auth_context import AuthContext
from ..exceptions import ExpiredToken, InvalidToken, JWKSUnavailable
from .conf import get_config


class SDKUser:
    """A request.user that's a thin wrapper over the JWT claims.

    Behaves enough like an authenticated user for DRF/Django code that
    checks ``request.user.is_authenticated`` and ``request.user.id``.
    Products that need richer user objects can read ``request.auth``.
    """

    is_anonymous = False

    def __init__(self, ctx: AuthContext) -> None:
        self._ctx = ctx

    @property
    def is_authenticated(self) -> bool:
        return self._ctx.is_authenticated

    @property
    def is_active(self) -> bool:
        return True

    @property
    def is_staff(self) -> bool:
        return self._ctx.is_superuser

    @property
    def is_superuser(self) -> bool:
        return self._ctx.is_superuser

    @property
    def id(self) -> str:
        return self._ctx.user_id

    @property
    def pk(self) -> str:
        return self._ctx.user_id

    @property
    def email(self) -> str:
        return self._ctx.email

    @property
    def username(self) -> str:
        return self._ctx.preferred_username or self._ctx.email

    @property
    def context(self) -> AuthContext:
        return self._ctx

    def __str__(self) -> str:
        return self._ctx.email or self._ctx.user_id or "(service)"

    def __getattr__(self, item: str) -> Any:
        # Pass-through for AuthContext properties so legacy code that
        # walks request.user.{groups,entitlements,...} keeps working.
        return getattr(self._ctx, item)


class JWTAuthentication(authentication.BaseAuthentication):
    """Validate ``Authorization: Bearer <token>`` against CentralAuth's JWKS."""

    keyword = "Bearer"
    www_authenticate_realm = "centralauth"

    def authenticate(self, request: Any) -> tuple[SDKUser, AuthContext] | None:
        header = authentication.get_authorization_header(request).decode("latin-1")
        if not header:
            return None
        parts = header.split()
        if len(parts) != 2 or parts[0] != self.keyword:
            return None
        token = parts[1]

        config = get_config()
        try:
            claims = config.validator.validate(token)
        except ExpiredToken as exc:
            raise exceptions.AuthenticationFailed("Token expired") from exc
        except InvalidToken as exc:
            raise exceptions.AuthenticationFailed(f"Invalid token: {exc}") from exc
        except JWKSUnavailable as exc:
            raise exceptions.AuthenticationFailed(
                "JWKS unavailable — cannot verify token",
            ) from exc

        ctx = AuthContext(claims, namespace=config.namespace)
        return SDKUser(ctx), ctx

    def authenticate_header(self, request: Any) -> str:
        return f'{self.keyword} realm="{self.www_authenticate_realm}"'
