"""``M2MClient`` — service-to-service token helper.

Service A wants to call Service B. A's product registration grants
``allowed_audiences=["service-b"]``. ``M2MClient.token_for("service-b")``
mints (or returns a cached) Bearer token signed for that audience.

Tokens are cached in-process per (audience, scopes) tuple and refreshed
80% through their TTL to avoid per-call round-trips.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass

import httpx

from .auth_client import _safe_json
from .exceptions import CentralAuthAPIError


@dataclass(frozen=True, slots=True)
class _CachedToken:
    token: str
    expires_at: float


class M2MClient:
    """Mints + caches access tokens for service-to-service calls.

    Construct once at process startup, share across requests. Thread-safe.
    """

    REFRESH_FRACTION = 0.8     # refresh after 80% of expires_in elapsed.

    def __init__(
        self,
        base_url: str,
        *,
        client_id: str,
        client_secret: str,
        timeout_seconds: float = 10.0,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self._timeout = timeout_seconds
        self._client = client
        self._lock = threading.Lock()
        self._cache: dict[tuple[str, tuple[str, ...]], _CachedToken] = {}

    @classmethod
    def from_settings(cls, *, client: httpx.Client | None = None) -> "M2MClient":
        """Build an M2MClient from Django ``settings.CENTRALAUTH``."""
        from .django.conf import raw_settings  # local import: Django optional
        from django.core.exceptions import ImproperlyConfigured

        raw = raw_settings()
        cid = raw.get("CLIENT_ID") or raw.get("AUDIENCE")
        secret = raw.get("CLIENT_SECRET")
        if not cid or not secret:
            raise ImproperlyConfigured(
                "M2MClient.from_settings requires CENTRALAUTH['CLIENT_ID'] and ['CLIENT_SECRET'].",
            )
        return cls(
            raw["BASE_URL"],
            client_id=cid,
            client_secret=secret,
            client=client,
        )

    def token_for(self, audience: str, scopes: list[str] | None = None) -> str:
        """Return a Bearer access token for calling ``audience``."""
        scope_key = tuple(sorted(scopes or []))
        cache_key = (audience, scope_key)

        with self._lock:
            cached = self._cache.get(cache_key)
            now = time.time()
            if cached is not None and now < cached.expires_at:
                return cached.token

            token, expires_at = self._mint(audience, scope_key)
            self._cache[cache_key] = _CachedToken(token=token, expires_at=expires_at)
            return token

    def invalidate(self, audience: str | None = None) -> None:
        """Drop cached tokens. Useful in tests."""
        with self._lock:
            if audience is None:
                self._cache = {}
            else:
                self._cache = {
                    k: v for k, v in self._cache.items() if k[0] != audience
                }

    def _mint(
        self, audience: str, scopes: tuple[str, ...],
    ) -> tuple[str, float]:
        body = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "audience": audience,
            "scope": " ".join(scopes),
        }
        client = self._client or httpx.Client(timeout=self._timeout)
        try:
            response = client.post(f"{self._base_url}/oauth/token", json=body)
        finally:
            if self._client is None:
                client.close()

        data = _safe_json(response)
        if response.status_code >= 400:
            raise CentralAuthAPIError(
                str(data.get("message") or data.get("error") or f"HTTP {response.status_code}"),
                status_code=response.status_code, body=data,
            )
        token = data["access_token"]
        expires_in = int(data.get("expires_in", 0))
        # Refresh slightly early to avoid serving an about-to-expire token.
        expires_at = time.time() + max(1, int(expires_in * self.REFRESH_FRACTION))
        return token, expires_at
