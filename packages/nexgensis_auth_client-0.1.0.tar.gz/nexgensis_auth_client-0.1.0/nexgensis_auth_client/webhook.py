"""``WebhookVerifier`` — receiver-side HMAC verification for CentralAuth webhooks.

CentralAuth signs every webhook delivery with::

    signature_input  = f"{timestamp}.{raw_body}"
    X-Auth-Signature = "sha256=" + hex(HMAC-SHA256(secret, signature_input))

Receivers MUST:
  1. Compare the constant-time HMAC.
  2. Reject deliveries whose ``X-Auth-Timestamp`` is outside a small skew
     window (default 5 min) — otherwise a captured request can be
     replayed forever.
  3. Track recent ``X-Auth-Event-Id`` values and skip duplicates —
     CentralAuth retries on transient failures, so receivers can see the
     same event twice.

This module gives you all three. It's framework-agnostic — call
:meth:`WebhookVerifier.verify` from any HTTP handler. A Django decorator
shipping in ``nexgensis_auth_client.django.webhooks`` builds on top of
this.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from collections import OrderedDict
from threading import Lock
from typing import Mapping

from .exceptions import InvalidSignature, StaleTimestamp


class WebhookVerifier:
    """Verify HMAC signatures + replay-guard + dedupe webhook deliveries.

    Construct one per webhook secret and reuse it — the dedupe cache is
    instance-local so each verifier remembers the last N event-ids it
    saw.

    Parameters
    ----------
    secret:
        The raw secret CentralAuth showed once at registration time.
        Store it like a password (env var, secrets manager).
    max_skew_seconds:
        Reject deliveries older/newer than this. Defaults to 300s
        (matches the server's signing window).
    dedupe_size:
        How many recent event-ids to remember for idempotency. The
        cache is a bounded LRU — older entries are evicted.
    """

    _HEADER_SIGNATURE = "X-Auth-Signature"
    _HEADER_TIMESTAMP = "X-Auth-Timestamp"
    _HEADER_EVENT_ID = "X-Auth-Event-Id"
    _HEADER_EVENT_TYPE = "X-Auth-Event-Type"

    def __init__(
        self,
        secret: str,
        *,
        max_skew_seconds: int = 300,
        dedupe_size: int = 10_000,
    ) -> None:
        if not secret:
            raise ValueError("WebhookVerifier requires a non-empty secret")
        self._secret = secret.encode("utf-8")
        self._max_skew = max_skew_seconds
        self._seen: OrderedDict[str, None] = OrderedDict()
        self._dedupe_size = dedupe_size
        self._lock = Lock()

    # ── Public API ──────────────────────────────────────────────────

    def verify(self, *, headers: Mapping[str, str], body: bytes) -> "VerifiedEvent":
        """Validate signature + timestamp and return event metadata.

        Raises:
            StaleTimestamp:    timestamp missing/malformed/outside window
            InvalidSignature:  signature missing/wrong format/mismatch

        Returns:
            VerifiedEvent with ``event_id``, ``event_type``, and a
            ``duplicate`` flag (True if we've already seen this event_id).
        """
        timestamp = _header(headers, self._HEADER_TIMESTAMP)
        signature = _header(headers, self._HEADER_SIGNATURE)
        event_id = _header(headers, self._HEADER_EVENT_ID) or ""
        event_type = _header(headers, self._HEADER_EVENT_TYPE) or ""

        self._check_timestamp(timestamp)
        self._check_signature(timestamp=timestamp, body=body, received=signature)

        duplicate = self._mark_seen(event_id) if event_id else False
        return VerifiedEvent(
            event_id=event_id,
            event_type=event_type,
            timestamp=int(timestamp),
            duplicate=duplicate,
        )

    # ── Internals ───────────────────────────────────────────────────

    def _check_timestamp(self, timestamp: str | None) -> None:
        if not timestamp:
            raise StaleTimestamp("Missing X-Auth-Timestamp header")
        try:
            ts = int(timestamp)
        except ValueError as exc:
            raise StaleTimestamp(f"Malformed X-Auth-Timestamp: {timestamp!r}") from exc
        if abs(int(time.time()) - ts) > self._max_skew:
            raise StaleTimestamp(
                f"X-Auth-Timestamp {ts} outside ±{self._max_skew}s skew window",
            )

    def _check_signature(self, *, timestamp: str | None, body: bytes, received: str | None) -> None:
        if not received:
            raise InvalidSignature("Missing X-Auth-Signature header")
        if not received.startswith("sha256="):
            raise InvalidSignature(f"Unsupported signature scheme: {received[:16]}...")
        expected = self._compute(timestamp or "", body)
        candidate = received[len("sha256="):]
        if not hmac.compare_digest(candidate, expected):
            raise InvalidSignature("Signature mismatch — body tampered or wrong secret")

    def _compute(self, timestamp: str, body: bytes) -> str:
        # Match the server's f"{timestamp}.{body}" framing.
        msg = timestamp.encode("utf-8") + b"." + body
        return hmac.new(self._secret, msg, hashlib.sha256).hexdigest()

    def _mark_seen(self, event_id: str) -> bool:
        with self._lock:
            if event_id in self._seen:
                # Touch as MRU.
                self._seen.move_to_end(event_id)
                return True
            self._seen[event_id] = None
            while len(self._seen) > self._dedupe_size:
                self._seen.popitem(last=False)
            return False


class VerifiedEvent:
    """Result of a successful :meth:`WebhookVerifier.verify` call."""

    __slots__ = ("event_id", "event_type", "timestamp", "duplicate")

    def __init__(
        self,
        *,
        event_id: str,
        event_type: str,
        timestamp: int,
        duplicate: bool,
    ) -> None:
        self.event_id = event_id
        self.event_type = event_type
        self.timestamp = timestamp
        self.duplicate = duplicate

    def __repr__(self) -> str:
        return (
            f"<VerifiedEvent type={self.event_type!r} id={self.event_id!r} "
            f"duplicate={self.duplicate}>"
        )


def _header(headers: Mapping[str, str], name: str) -> str | None:
    """Case-insensitive header lookup that tolerates Django's
    ``HTTP_X_AUTH_*`` and httpx's lowercase keys."""
    if name in headers:
        return headers[name]
    lowered = name.lower()
    if lowered in headers:
        return headers[lowered]
    django_key = "HTTP_" + name.upper().replace("-", "_")
    if django_key in headers:
        return headers[django_key]
    for key, value in headers.items():
        if key.lower() == lowered:
            return value
    return None
