"""JWT validation against the JWKS cache.

Algorithm whitelist: RS256 only (per locked decision in
``docs/JWT_CLAIM_CONTRACT.md``). Audience is mandatory — products
always know their own ``client_id`` (the audience they expect).
"""
from __future__ import annotations

import base64
from typing import Any

import jwt as pyjwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers

from .exceptions import ExpiredToken, InvalidToken, JWKSUnavailable
from .jwks_cache import JWKSCache


_ALLOWED_ALGORITHMS = ("RS256",)
_DEFAULT_LEEWAY_SECONDS = 60


class JWTValidator:
    """Verify Django-issued JWTs against ``CentralAuth``'s JWKS.

    Construct once, validate many. Stateless apart from the JWKS cache.
    """

    def __init__(
        self,
        jwks_cache: JWKSCache,
        *,
        issuer: str,
        audience: str,
        leeway_seconds: int = _DEFAULT_LEEWAY_SECONDS,
    ) -> None:
        self._jwks = jwks_cache
        self._issuer = issuer
        self._audience = audience
        self._leeway = leeway_seconds

    @property
    def audience(self) -> str:
        return self._audience

    def validate(self, token: str) -> dict[str, Any]:
        """Decode + verify ``token``. Returns the claims dict on success.

        Raises :class:`InvalidToken`, :class:`ExpiredToken`, or
        :class:`JWKSUnavailable`.
        """
        try:
            unverified = pyjwt.get_unverified_header(token)
        except pyjwt.PyJWTError as exc:
            raise InvalidToken(f"Malformed token header: {exc}") from exc

        alg = unverified.get("alg")
        if alg not in _ALLOWED_ALGORITHMS:
            raise InvalidToken(
                f"Algorithm {alg!r} not allowed (expected one of {_ALLOWED_ALGORITHMS}).",
            )

        kid = unverified.get("kid")
        if not kid:
            raise InvalidToken("Token header missing 'kid'.")

        try:
            jwk = self._jwks.get_key(kid)
        except JWKSUnavailable:
            # Fail-closed.
            raise

        public_pem = _jwk_to_public_pem(jwk)

        try:
            return pyjwt.decode(
                token,
                public_pem,
                algorithms=list(_ALLOWED_ALGORITHMS),
                audience=self._audience,
                issuer=self._issuer,
                leeway=self._leeway,
            )
        except pyjwt.ExpiredSignatureError as exc:
            raise ExpiredToken(str(exc)) from exc
        except pyjwt.PyJWTError as exc:
            raise InvalidToken(str(exc)) from exc


def _jwk_to_public_pem(jwk: dict[str, Any]) -> bytes:
    if jwk.get("kty") != "RSA":
        raise InvalidToken(f"Unsupported JWK kty: {jwk.get('kty')!r} (only RSA is allowed).")
    n = _b64url_int(jwk["n"])
    e = _b64url_int(jwk["e"])
    public_key = RSAPublicNumbers(e, n).public_key()
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def _b64url_int(value: str) -> int:
    pad = (-len(value)) % 4
    raw = base64.urlsafe_b64decode(value + "=" * pad)
    return int.from_bytes(raw, "big")
