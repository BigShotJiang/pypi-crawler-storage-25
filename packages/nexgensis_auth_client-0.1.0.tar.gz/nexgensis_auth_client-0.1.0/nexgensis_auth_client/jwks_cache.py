"""JWKS fetch + cache.

Phase 0 / locked decisions:
  - 24h cache TTL.
  - Refresh on `kid` miss.
  - Background refresh after 1h (proactive refresh below TTL).
  - Fail-closed on missing JWKS — never accept a token whose signing
    key we can't verify against.
"""
from __future__ import annotations

import threading
import time
from typing import Any

import httpx

from .exceptions import JWKSUnavailable


_DEFAULT_TTL_SECONDS = 86_400          # 24h
_DEFAULT_PROACTIVE_REFRESH_SECONDS = 3_600  # 1h
_DEFAULT_TIMEOUT_SECONDS = 5.0


class JWKSCache:
    """Thread-safe JWKS cache with single-flight refresh."""

    def __init__(
        self,
        jwks_url: str,
        *,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        proactive_refresh_seconds: int = _DEFAULT_PROACTIVE_REFRESH_SECONDS,
        timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS,
        client: httpx.Client | None = None,
    ) -> None:
        self._jwks_url = jwks_url
        self._ttl = ttl_seconds
        self._proactive_refresh = proactive_refresh_seconds
        self._timeout = timeout_seconds
        self._client = client
        self._lock = threading.Lock()
        self._keys: dict[str, dict[str, Any]] = {}
        self._fetched_at: float = 0.0

    @property
    def jwks_url(self) -> str:
        return self._jwks_url

    def get_key(self, kid: str) -> dict[str, Any]:
        """Return the JWK matching ``kid``.

        - Refresh on hard miss.
        - Refresh proactively if cache is older than the threshold.
        - Raise :class:`JWKSUnavailable` if neither cache nor live fetch
          can satisfy the lookup.
        """
        with self._lock:
            now = time.time()
            cached = self._keys.get(kid)
            stale = (now - self._fetched_at) > self._proactive_refresh

            if cached is not None and not stale:
                return cached

            # Cache miss or stale: try to refresh once.
            try:
                self._refresh_locked()
            except Exception:
                if cached is not None:
                    # Stale-but-have-it: serve the cached key.
                    return cached
                raise JWKSUnavailable(
                    f"Unable to fetch JWKS at {self._jwks_url} and no cached keys.",
                )

            if kid in self._keys:
                return self._keys[kid]
            if cached is not None:
                # Refresh succeeded but this kid disappeared — likely a key
                # we no longer want anyway. Fall back to the stale entry.
                return cached
            raise JWKSUnavailable(
                f"Signing key {kid!r} not present in JWKS at {self._jwks_url}.",
            )

    def invalidate(self) -> None:
        with self._lock:
            self._keys = {}
            self._fetched_at = 0.0

    def _refresh_locked(self) -> None:
        client = self._client or httpx.Client(timeout=self._timeout)
        try:
            response = client.get(self._jwks_url)
        finally:
            if self._client is None:
                client.close()
        response.raise_for_status()
        payload: dict[str, Any] = response.json()
        new_keys = {k["kid"]: k for k in payload.get("keys", []) if "kid" in k}
        if not new_keys:
            raise JWKSUnavailable(f"JWKS at {self._jwks_url} is empty.")
        self._keys = new_keys
        self._fetched_at = time.time()
