"""JWTValidator: signature, audience, issuer, expiry, alg whitelist."""
from __future__ import annotations

import time

import httpx
import pytest

from nexgensis_auth_client import (
    AuthContext,
    ExpiredToken,
    InvalidToken,
    JWKSCache,
    JWKSUnavailable,
    JWTValidator,
)

_AUDIENCE = "test-product"
_ISSUER = "https://centralauth.test"
_NS = "https://centralauth.test"


def _make_validator(jwks_payload: dict) -> JWTValidator:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=jwks_payload)

    cache = JWKSCache(
        "https://auth.test/.well-known/jwks.json",
        client=httpx.Client(transport=httpx.MockTransport(handler)),
    )
    return JWTValidator(cache, issuer=_ISSUER, audience=_AUDIENCE)


def test_validate_happy_path(issue_token, jwks_payload) -> None:
    validator = _make_validator(jwks_payload)
    token = issue_token(
        aud=_AUDIENCE, iss=_ISSUER,
        extra={f"{_NS}/groups": ["QA_LEAD"], "email": "a@b.com"},
    )
    claims = validator.validate(token)
    assert claims["sub"] == "u-1"
    ctx = AuthContext(claims, namespace=_NS)
    assert ctx.has_group("QA_LEAD")
    assert ctx.email == "a@b.com"


def test_rejects_wrong_audience(issue_token, jwks_payload) -> None:
    validator = _make_validator(jwks_payload)
    token = issue_token(aud="other-product", iss=_ISSUER)
    with pytest.raises(InvalidToken):
        validator.validate(token)


def test_rejects_wrong_issuer(issue_token, jwks_payload) -> None:
    validator = _make_validator(jwks_payload)
    token = issue_token(aud=_AUDIENCE, iss="https://attacker.test")
    with pytest.raises(InvalidToken):
        validator.validate(token)


def test_rejects_expired_token(issue_token, jwks_payload) -> None:
    validator = _make_validator(jwks_payload)
    token = issue_token(aud=_AUDIENCE, iss=_ISSUER, ttl_seconds=-3600)
    with pytest.raises(ExpiredToken):
        validator.validate(token)


def test_rejects_alg_none_attack(issue_token, jwks_payload) -> None:
    """RS256-only whitelist must refuse any other 'alg' header value,
    including the classic alg=none attack."""
    validator = _make_validator(jwks_payload)
    # Forge a JWT with alg=none manually since PyJWT won't sign with none easily.
    import base64
    import json

    header = base64.urlsafe_b64encode(json.dumps({"alg": "none", "kid": "test-1"}).encode()).rstrip(b"=").decode()
    payload = base64.urlsafe_b64encode(json.dumps({
        "iss": _ISSUER, "aud": _AUDIENCE, "sub": "x", "exp": int(time.time()) + 600,
    }).encode()).rstrip(b"=").decode()
    forged = f"{header}.{payload}."
    with pytest.raises(InvalidToken):
        validator.validate(forged)


def test_rejects_unknown_kid(issue_token, jwks_payload) -> None:
    """Unknown kid → JWKSUnavailable (fail-closed). The validator
    refuses to verify against any key it doesn't recognise."""
    validator = _make_validator(jwks_payload)
    token = issue_token(aud=_AUDIENCE, iss=_ISSUER, kid="does-not-exist")
    with pytest.raises(JWKSUnavailable):
        validator.validate(token)
