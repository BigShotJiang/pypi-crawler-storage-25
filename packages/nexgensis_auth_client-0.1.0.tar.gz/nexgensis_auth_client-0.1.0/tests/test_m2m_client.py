"""M2MClient: token caching with refresh fraction, audience+scope keying."""
from __future__ import annotations

import time
from collections.abc import Iterable

import httpx
import pytest

from nexgensis_auth_client import M2MClient


def _make_handler(responses: Iterable[dict]) -> httpx.MockTransport:
    iterator = iter(responses)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=next(iterator))

    return httpx.MockTransport(handler)


def test_token_is_cached_per_audience_scope_combo() -> None:
    transport = _make_handler([
        {"access_token": "tok-A1", "expires_in": 3600, "token_type": "Bearer"},
        {"access_token": "tok-B1", "expires_in": 3600, "token_type": "Bearer"},
    ])
    client = M2MClient(
        "https://auth.test",
        client_id="svc",
        client_secret="x",
        client=httpx.Client(transport=transport),
    )

    # First call to A: hits the network.
    a1 = client.token_for("product-a")
    # Second call to A: served from cache, no new network call.
    a2 = client.token_for("product-a")
    # Different audience: separate cache entry, new network call.
    b1 = client.token_for("product-b")

    assert a1 == "tok-A1"
    assert a2 == "tok-A1"
    assert b1 == "tok-B1"


def test_cache_expires_when_token_close_to_lifetime_end() -> None:
    transport = _make_handler([
        {"access_token": "tok-1", "expires_in": 10, "token_type": "Bearer"},
        {"access_token": "tok-2", "expires_in": 10, "token_type": "Bearer"},
    ])
    client = M2MClient(
        "https://auth.test",
        client_id="svc",
        client_secret="x",
        client=httpx.Client(transport=transport),
    )

    first = client.token_for("product-a")
    # Force the cached entry past its expiry to trigger a re-mint.
    from dataclasses import replace
    cached = client._cache[("product-a", ())]  # noqa: SLF001 — internal probe is fine in tests
    client._cache[("product-a", ())] = replace(cached, expires_at=time.time() - 1)  # noqa: SLF001
    second = client.token_for("product-a")

    assert first == "tok-1"
    assert second == "tok-2"


def test_scopes_are_part_of_the_cache_key() -> None:
    transport = _make_handler([
        {"access_token": "tok-read", "expires_in": 3600, "token_type": "Bearer"},
        {"access_token": "tok-write", "expires_in": 3600, "token_type": "Bearer"},
    ])
    client = M2MClient(
        "https://auth.test",
        client_id="svc",
        client_secret="x",
        client=httpx.Client(transport=transport),
    )
    t_read = client.token_for("product-a", scopes=["admin_api:read"])
    t_write = client.token_for("product-a", scopes=["admin_api:write"])
    assert t_read == "tok-read"
    assert t_write == "tok-write"
