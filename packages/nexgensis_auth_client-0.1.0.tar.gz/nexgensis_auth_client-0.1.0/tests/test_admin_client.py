"""AdminClient: pagination + find_user_by_email."""
from __future__ import annotations

import httpx

from nexgensis_auth_client import AdminClient


def _make_client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


def test_find_user_by_email_returns_exact_match() -> None:
    """Server-side search is __icontains; client-side filter must
    enforce an exact lower-cased match."""
    page = {
        "data": [
            {"id": "u-1", "email": "alice@example.com"},
            {"id": "u-2", "email": "alice@example.org"},  # superset match
        ],
        "next_cursor": None,
    }

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=page)

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )

    found = admin.find_user_by_email("alice@example.com")
    assert found is not None
    assert found["id"] == "u-1"


def test_find_user_by_email_returns_none_when_no_match() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"data": [], "next_cursor": None})

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )
    assert admin.find_user_by_email("ghost@example.com") is None


def test_find_user_by_email_is_case_insensitive() -> None:
    page = {"data": [{"id": "u-1", "email": "Alice@Example.com"}], "next_cursor": None}

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=page)

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )

    found = admin.find_user_by_email("ALICE@EXAMPLE.COM")
    assert found is not None
    assert found["id"] == "u-1"


# ── Profile + catalogs (Phase 9 prep) ────────────────────────────────


def test_get_user_profile_returns_payload() -> None:
    profile = {
        "user_id": "u-1", "phone": "+91 98765",
        "department": "d-1", "department_name": "QA",
    }

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/users/u-1/profile/"
        return httpx.Response(200, json=profile)

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )
    result = admin.get_user_profile("u-1")
    assert result is not None
    assert result["department_name"] == "QA"


def test_get_user_profile_returns_none_on_404() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"title": "No profile"})

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )
    assert admin.get_user_profile("u-ghost") is None


def test_set_user_profile_sends_only_provided_fields() -> None:
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        import json as _json
        captured["method"] = request.method
        captured["body"] = _json.loads(request.content.decode())
        return httpx.Response(200, json={"user_id": "u-1", "phone": "+91 98765"})

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )
    admin.set_user_profile("u-1", phone="+91 98765", employee_type="in_house")

    assert captured["method"] == "PATCH"
    assert captured["body"] == {"phone": "+91 98765", "employee_type": "in_house"}
    # None-valued kwargs must NOT be sent — keeps PATCH partial.
    assert "department" not in captured["body"]


def test_list_departments_uses_pagination() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/departments/"
        return httpx.Response(200, json={
            "data": [{"id": "d-1", "code": "QA"}, {"id": "d-2", "code": "OPS"}],
            "next_cursor": None,
        })

    admin = AdminClient(
        "https://auth.test",
        token_provider=lambda: "tok",
        client=_make_client(handler),
    )
    rows = list(admin.list_departments())
    assert [r["code"] for r in rows] == ["QA", "OPS"]
