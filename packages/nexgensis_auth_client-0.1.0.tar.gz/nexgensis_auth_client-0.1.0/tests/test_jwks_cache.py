"""JWKSCache: refresh, cache-miss, fail-closed."""
from __future__ import annotations

import json

import httpx
import pytest

from nexgensis_auth_client import JWKSCache, JWKSUnavailable


def _client_returning(payload: dict, *, status: int = 200) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status, json=payload) if status == 200 else httpx.Response(status, text="boom")

    return httpx.Client(transport=httpx.MockTransport(handler))


def test_get_key_returns_cached_match(jwks_payload: dict) -> None:
    cache = JWKSCache(
        "https://auth.test/.well-known/jwks.json",
        client=_client_returning(jwks_payload),
    )
    key = cache.get_key("test-1")
    assert key["kid"] == "test-1"
    assert key["alg"] == "RS256"


def test_get_key_raises_when_kid_missing(jwks_payload: dict) -> None:
    cache = JWKSCache(
        "https://auth.test/.well-known/jwks.json",
        client=_client_returning(jwks_payload),
    )
    with pytest.raises(JWKSUnavailable):
        cache.get_key("does-not-exist")


def test_fail_closed_when_jwks_endpoint_down() -> None:
    cache = JWKSCache(
        "https://auth.test/.well-known/jwks.json",
        client=_client_returning({}, status=503),
    )
    with pytest.raises(JWKSUnavailable):
        cache.get_key("test-1")


def test_invalidate_forces_next_call_to_refresh(jwks_payload: dict) -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(200, json=jwks_payload)

    cache = JWKSCache(
        "https://auth.test/.well-known/jwks.json",
        client=httpx.Client(transport=httpx.MockTransport(handler)),
    )
    cache.get_key("test-1")
    cache.invalidate()
    cache.get_key("test-1")
    assert calls["n"] == 2
