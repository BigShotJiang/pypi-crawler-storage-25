"""WebhookVerifier: HMAC, timestamp window, dedupe."""
from __future__ import annotations

import hashlib
import hmac
import json
import time

import pytest

from nexgensis_auth_client import InvalidSignature, StaleTimestamp, WebhookVerifier


SECRET = "super-secret-12345678901234567890"


def _sign(secret: str, timestamp: str, body: bytes) -> str:
    msg = timestamp.encode() + b"." + body
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def _headers(secret: str, body: bytes, *, ts_offset: int = 0, event_id: str = "evt-1") -> dict[str, str]:
    ts = str(int(time.time()) + ts_offset)
    sig = _sign(secret, ts, body)
    return {
        "X-Auth-Timestamp": ts,
        "X-Auth-Signature": f"sha256={sig}",
        "X-Auth-Event-Id": event_id,
        "X-Auth-Event-Type": "user.disabled",
    }


def test_verify_happy_path() -> None:
    v = WebhookVerifier(SECRET)
    body = json.dumps({"user_id": "u-1"}).encode()
    event = v.verify(headers=_headers(SECRET, body), body=body)
    assert event.event_type == "user.disabled"
    assert event.event_id == "evt-1"
    assert not event.duplicate


def test_dedupe_returns_duplicate_on_second_call() -> None:
    v = WebhookVerifier(SECRET)
    body = b'{"x":1}'
    headers = _headers(SECRET, body, event_id="evt-7")
    first = v.verify(headers=headers, body=body)
    # Re-build headers (timestamp would otherwise be a fresh second).
    headers2 = _headers(SECRET, body, event_id="evt-7")
    second = v.verify(headers=headers2, body=body)
    assert not first.duplicate
    assert second.duplicate


def test_rejects_stale_timestamp() -> None:
    v = WebhookVerifier(SECRET, max_skew_seconds=60)
    body = b"{}"
    with pytest.raises(StaleTimestamp):
        v.verify(headers=_headers(SECRET, body, ts_offset=-3600), body=body)


def test_rejects_signature_with_wrong_secret() -> None:
    v = WebhookVerifier(SECRET)
    body = b"{}"
    headers = _headers("WRONG-SECRET-XXXXXXXXXXXXXXXXXXXXX", body)
    with pytest.raises(InvalidSignature):
        v.verify(headers=headers, body=body)


def test_rejects_tampered_body() -> None:
    v = WebhookVerifier(SECRET)
    headers = _headers(SECRET, b'{"a":1}')
    with pytest.raises(InvalidSignature):
        v.verify(headers=headers, body=b'{"a":2}')


def test_rejects_missing_signature_header() -> None:
    v = WebhookVerifier(SECRET)
    body = b"{}"
    headers = _headers(SECRET, body)
    headers.pop("X-Auth-Signature")
    with pytest.raises(InvalidSignature):
        v.verify(headers=headers, body=body)


def test_rejects_unsupported_signature_scheme() -> None:
    v = WebhookVerifier(SECRET)
    body = b"{}"
    headers = _headers(SECRET, body)
    headers["X-Auth-Signature"] = "md5=deadbeef"
    with pytest.raises(InvalidSignature):
        v.verify(headers=headers, body=body)


def test_django_style_meta_keys_are_understood() -> None:
    v = WebhookVerifier(SECRET)
    body = b"{}"
    canonical = _headers(SECRET, body)
    django_meta = {
        "HTTP_" + k.upper().replace("-", "_"): val for k, val in canonical.items()
    }
    event = v.verify(headers=django_meta, body=body)
    assert event.event_type == "user.disabled"
