from __future__ import annotations

from nexgensis_auth_client import AuthContext

NS = "https://centralauth.test"


def _claims(**extra) -> dict:
    base = {
        "sub": "u-1",
        "email": "a@b.com",
        "name": "Alice",
        "exp": 9999999999,
        f"{NS}/groups": ["QA_LEAD", "VIEWER"],
        f"{NS}/entitlements": ["qms"],
        f"{NS}/scopes": [],
        f"{NS}/is_superuser": False,
    }
    base.update(extra)
    return base


def test_user_context_basic() -> None:
    ctx = AuthContext(_claims(), namespace=NS)
    assert ctx.is_authenticated
    assert ctx.user_id == "u-1"
    assert ctx.email == "a@b.com"
    assert not ctx.is_superuser
    assert ctx.has_group("QA_LEAD")
    assert ctx.has_any_group(["QA_LEAD", "X"])
    assert not ctx.has_all_groups(["QA_LEAD", "X"])
    assert ctx.has_entitlement("qms")
    assert not ctx.has_entitlement("crm")


def test_service_context() -> None:
    ctx = AuthContext(
        _claims(**{
            f"{NS}/client_type": "service",
            f"{NS}/scopes": ["admin_api:read"],
        }),
        namespace=NS,
    )
    assert ctx.is_service
    assert ctx.has_scope("admin_api:read")
    assert not ctx.has_scope("admin_api:write")


def test_namespace_with_trailing_slash_is_normalized() -> None:
    ctx = AuthContext(_claims(), namespace=NS + "/")
    assert ctx.has_group("QA_LEAD")
