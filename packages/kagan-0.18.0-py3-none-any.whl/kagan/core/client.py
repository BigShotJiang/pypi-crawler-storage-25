"""KaganCore — thin engine factory and convenience namespace.

Usage::

    async with KaganCore() as client:
        project = await client.projects.create("My Project")
        task = await client.tasks.create("Fix the bug")
"""

import asyncio
import contextlib
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from sqlalchemy import Engine
from sqlalchemy.exc import SQLAlchemyError
from sqlmodel import SQLModel

from kagan.core._agent import cleanup_all_spawned_processes
from kagan.core._analytics import Analytics
from kagan.core._audit import AuditLog
from kagan.core._db import create_db_engine, default_db_path, get_db_version
from kagan.core._events import Events
from kagan.core._persona import PersonaPresetOps
from kagan.core._preflight import PreflightCheckResult, run_all_checks
from kagan.core._projects import Projects
from kagan.core._reviews import Reviews
from kagan.core._sessions import Sessions
from kagan.core._settings import Settings
from kagan.core._tasks import Tasks
from kagan.core._watcher import DBWatcher
from kagan.core._worktrees import Worktrees


class KaganCore:
    def __init__(self, db_path: str | Path | None = None) -> None:
        resolved = Path(db_path) if db_path is not None else default_db_path()
        self._db_path: Path = resolved
        self._engine = create_db_engine(resolved)
        self._signals: dict[str, asyncio.Event] = {}
        self.tasks = Tasks(self._engine, self._signals, client=self, db_path=resolved)
        self.projects = Projects(self._engine, self)
        self.worktrees = Worktrees(self._engine, self)
        self.reviews = Reviews(self._engine, self)
        self.settings = Settings(self._engine)
        self.audit_log = AuditLog(self._engine)
        self.analytics = Analytics(self._engine)
        self.persona_presets = PersonaPresetOps(self.settings, self.audit_log)

        self.active_project_id: str | None = None
        logger.info("KaganCore initialized")

    @property
    def engine(self) -> "Engine":
        """Public access to the SQLAlchemy engine for module-function callers."""
        return self._engine

    def close(self) -> None:
        with contextlib.suppress(OSError, RuntimeError, SQLAlchemyError):
            self._engine.dispose()
        try:
            loop = asyncio.get_running_loop()
            task = loop.create_task(cleanup_all_spawned_processes())
            logger.debug("Cleanup task scheduled (fire-and-forget): {}", task)
        except RuntimeError:
            asyncio.run(cleanup_all_spawned_processes())
        logger.debug("Client closed")

    async def __aenter__(self) -> "KaganCore":
        return self

    async def __aexit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: Any,
    ) -> None:
        with contextlib.suppress(OSError, RuntimeError, SQLAlchemyError):
            self._engine.dispose()
        await cleanup_all_spawned_processes()
        logger.debug("Client closed")

    async def preflight(self, *, agent_backend: str | None = None) -> list[PreflightCheckResult]:
        return await asyncio.to_thread(run_all_checks, self._db_path, agent_backend)

    async def db_version(self) -> int:
        return await asyncio.to_thread(get_db_version, self._engine)

    async def reset(self) -> None:
        await asyncio.to_thread(self._wipe_all)
        logger.info("Database reset complete")

    def _wipe_all(self) -> None:
        with self._engine.begin() as conn:
            conn.exec_driver_sql("PRAGMA foreign_keys=OFF")
            try:
                SQLModel.metadata.drop_all(conn)
            finally:
                conn.exec_driver_sql("PRAGMA foreign_keys=ON")

        with self._engine.begin() as conn:
            SQLModel.metadata.create_all(conn)
        self.active_project_id = None
        self.tasks._active_project_id = None


__all__ = [
    "AuditLog",
    "DBWatcher",
    "Events",
    "KaganCore",
    "Projects",
    "Reviews",
    "Sessions",
    "Settings",
    "Tasks",
    "Worktrees",
]
