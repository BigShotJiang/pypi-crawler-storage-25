"""kagan.core.plugins._github — GitHub Issues import plugin.

Imports open issues from a GitHub repository into a kagan project as tasks.
Uses the ``gh`` CLI for authentication and API access — no token management
needed. Label conventions on the GitHub side auto-map to kagan task properties:

    priority:critical  →  Priority.CRITICAL
    priority:high      →  Priority.HIGH
    priority:medium    →  Priority.MEDIUM
    priority:low       →  Priority.LOW

Sync is idempotent: a mapping of issue numbers → task IDs is persisted in
the kagan settings table. Re-running sync skips already-imported issues.
"""

import asyncio
import json
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any, Final, TypedDict

from loguru import logger

from kagan.core import CheckStatus, KaganCore, PreflightCheckResult
from kagan.core.enums import Priority
from kagan.core.errors import KaganError, NotFoundError
from kagan.core.plugins import ImporterPlugin, ImportResult, PluginError, PluginSyncError
from kagan.runtime_env import build_sanitized_subprocess_environment


class GitHubIssue(TypedDict, total=False):
    number: int
    title: str
    body: str | None
    labels: list[dict[str, Any]]
    state: str
    url: str


class GitHubIssuePreview(TypedDict):
    number: int
    title: str
    state: str
    labels: list[str]
    url: str
    already_synced: bool


# Label prefix → (task field, mapping)
_PRIORITY_LABELS: Final[dict[str, Priority]] = {
    "priority:critical": Priority.CRITICAL,
    "priority:high": Priority.HIGH,
    "priority:medium": Priority.MEDIUM,
    "priority:low": Priority.LOW,
}

_GH_JSON_FIELDS = "number,title,body,labels,state,url"


@dataclass(frozen=True)
class GitHubImportConfig:
    """Configuration for a single GitHub import sync."""

    owner: str
    repo: str
    state: str = "open"
    labels: tuple[str, ...] = ()
    limit: int = 100
    issue_numbers: tuple[int, ...] = ()

    @property
    def repo_slug(self) -> str:
        return f"{self.owner}/{self.repo}"

    def settings_key(self) -> str:
        return f"plugin.github.{self.repo_slug}.sync_map"


def _gh_path() -> str | None:
    return shutil.which("gh")


async def _gh_is_authenticated() -> bool:
    try:
        proc = await asyncio.create_subprocess_exec(
            "gh",
            "auth",
            "token",
            env=build_sanitized_subprocess_environment(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return proc.returncode == 0 and bool(stdout.strip())
    except (OSError, FileNotFoundError):
        return False


async def _gh_fetch_issues(config: GitHubImportConfig) -> list[GitHubIssue]:
    cmd: list[str] = [
        "gh",
        "issue",
        "list",
        "--repo",
        config.repo_slug,
        "--state",
        config.state,
        "--json",
        _GH_JSON_FIELDS,
        "--limit",
        str(config.limit),
    ]
    for lbl in config.labels:
        cmd.extend(["--label", lbl])

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        env=build_sanitized_subprocess_environment(),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()

    if proc.returncode != 0:
        err = stderr.decode(errors="replace").strip()
        raise PluginSyncError(f"gh issue list failed: {err}")

    try:
        data = json.loads(stdout.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise PluginSyncError(f"Failed to parse gh output: {exc}") from exc

    if not isinstance(data, list):
        raise PluginSyncError(f"Expected JSON array from gh, got {type(data).__name__}")

    return data


def _extract_label_names(issue: GitHubIssue) -> list[str]:
    raw = issue.get("labels") or []
    return [lbl["name"] for lbl in raw if isinstance(lbl, dict) and "name" in lbl]


def _map_labels(label_names: list[str]) -> tuple[Priority, list[str]]:
    priority = Priority.MEDIUM
    remaining: list[str] = []
    for name in label_names:
        lower = name.lower()
        if lower in _PRIORITY_LABELS:
            priority = _PRIORITY_LABELS[lower]
        else:
            remaining.append(name)
    return priority, remaining


def _build_description(issue: GitHubIssue, extra_labels: list[str]) -> str:
    parts: list[str] = []

    if url := issue.get("url"):
        parts.append(url)

    if extra_labels:
        tags = " ".join(f"[{lbl}]" for lbl in extra_labels)
        parts.append(tags)

    body = (issue.get("body") or "").strip()
    if body:
        parts.append(body)

    return "\n\n".join(parts)


async def _load_sync_map(client: KaganCore, key: str) -> dict[str, str]:
    settings = await client.settings.get()
    raw = settings.get(key, "{}")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


async def _save_sync_map(client: KaganCore, key: str, sync_map: dict[str, str]) -> None:
    await client.settings.set({key: json.dumps(sync_map, separators=(",", ":"))})


class GitHubImporter(ImporterPlugin):
    """Import GitHub issues into kagan as tasks."""

    def __init__(self, config: GitHubImportConfig | None = None) -> None:
        self._config: GitHubImportConfig | None = config
        self._client: KaganCore | None = None

    @property
    def name(self) -> str:
        return "github"

    async def setup(self, client: KaganCore) -> None:
        self._client = client

    async def teardown(self) -> None:
        self._client = None

    def configure(self, config: object) -> None:
        if not isinstance(config, GitHubImportConfig):
            msg = f"Expected GitHubImportConfig, got {type(config).__name__}"
            raise TypeError(msg)
        if not config.owner or not config.repo:
            raise PluginError("configure() requires owner and repo")
        self._config = config

    def preflight(self) -> list[PreflightCheckResult]:
        checks: list[PreflightCheckResult] = []
        gh = _gh_path()
        if gh is None:
            checks.append(
                PreflightCheckResult(
                    name="gh_cli",
                    status=CheckStatus.WARN,
                    message="GitHub CLI (gh) not found on PATH",
                    fix_hint="Install → https://cli.github.com",
                )
            )
            return checks

        checks.append(
            PreflightCheckResult(
                name="gh_cli",
                status=CheckStatus.PASS,
                message=f"gh found at {gh}",
                fix_hint="",
            )
        )

        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                timeout=5,
                env=build_sanitized_subprocess_environment(),
            )
            if result.returncode == 0 and result.stdout.strip():
                checks.append(
                    PreflightCheckResult(
                        name="gh_auth",
                        status=CheckStatus.PASS,
                        message="gh authenticated",
                        fix_hint="",
                    )
                )
            else:
                checks.append(
                    PreflightCheckResult(
                        name="gh_auth",
                        status=CheckStatus.WARN,
                        message="GitHub CLI not authenticated",
                        fix_hint="Run → gh auth login",
                    )
                )
        except (OSError, subprocess.TimeoutExpired):
            checks.append(
                PreflightCheckResult(
                    name="gh_auth",
                    status=CheckStatus.WARN,
                    message="Could not verify gh authentication",
                    fix_hint="Run → gh auth login",
                )
            )

        return checks

    async def _fetch_issues(self) -> list[GitHubIssue]:
        """Validate prerequisites, fetch issues, apply issue_numbers filter."""
        if self._client is None:
            raise PluginError("Plugin not set up — call setup() first")
        if self._config is None:
            raise PluginError("Plugin not configured — call configure() first")

        if _gh_path() is None:
            raise PluginError("GitHub CLI (gh) not found. Install → https://cli.github.com")
        if not await _gh_is_authenticated():
            raise PluginError("GitHub CLI not authenticated. Run → gh auth login")

        issues = await _gh_fetch_issues(self._config)
        logger.info(
            "GitHub fetch: {} issues from {}",
            len(issues),
            self._config.repo_slug,
        )

        if self._config.issue_numbers:
            allowed = set(self._config.issue_numbers)
            issues = [i for i in issues if i.get("number") in allowed]

        return issues

    async def sync(self, project_id: str) -> ImportResult:
        issues = await self._fetch_issues()
        client = self._client
        config = self._config
        assert client is not None and config is not None  # guaranteed by _fetch_issues

        settings_key = config.settings_key()
        sync_map = await _load_sync_map(client, settings_key)
        result = ImportResult()

        for issue in issues:
            number = str(issue.get("number", ""))
            title = (issue.get("title") or "").strip()
            if not number or not title:
                result = result.with_error(f"Issue missing number or title: {issue}")
                continue

            try:
                result = await self._sync_single_issue(
                    client,
                    project_id,
                    number,
                    issue,
                    sync_map,
                    result,
                )
            except (PluginError, KaganError) as exc:
                result = result.with_error(f"Issue #{number}: {exc}")
                logger.opt(exception=True).warning("Failed to sync issue #{}", number)

        await _save_sync_map(client, settings_key, sync_map)
        logger.info(
            "GitHub sync complete: created={} skipped={} errors={}",
            result.created,
            result.skipped,
            len(result.errors),
        )
        return result

    async def preview(self, project_id: str) -> list[GitHubIssuePreview]:
        """Fetch issues matching config and return preview without importing."""
        issues = await self._fetch_issues()
        assert self._client is not None and self._config is not None

        sync_map = await _load_sync_map(self._client, self._config.settings_key())

        previews: list[GitHubIssuePreview] = []
        for issue in issues:
            number = issue.get("number")
            title = (issue.get("title") or "").strip()
            if not number or not title:
                continue
            previews.append(
                GitHubIssuePreview(
                    number=number,
                    title=title,
                    state=issue.get("state", "open"),
                    labels=_extract_label_names(issue),
                    url=issue.get("url", ""),
                    already_synced=str(number) in sync_map,
                )
            )
        return previews

    async def _sync_single_issue(
        self,
        client: KaganCore,
        project_id: str,
        number: str,
        issue: GitHubIssue,
        sync_map: dict[str, str],
        result: ImportResult,
    ) -> ImportResult:
        title = (issue.get("title") or "").strip()

        if number in sync_map:
            task_id = sync_map[number]
            try:
                await client.tasks.get(task_id)
                return ImportResult(
                    created=result.created,
                    updated=result.updated,
                    skipped=result.skipped + 1,
                    errors=result.errors,
                )
            except NotFoundError:
                logger.debug("Task {} for issue #{} was deleted, re-importing", task_id, number)

        label_names = _extract_label_names(issue)
        priority, extra_labels = _map_labels(label_names)
        description = _build_description(issue, extra_labels)

        task = await client.tasks.create(
            title,
            description=description,
            priority=priority,
        )
        sync_map[number] = task.id
        return ImportResult(
            created=result.created + 1,
            updated=result.updated,
            skipped=result.skipped,
            errors=result.errors,
        )


__all__ = [
    "GitHubImportConfig",
    "GitHubImporter",
    "GitHubIssuePreview",
]
