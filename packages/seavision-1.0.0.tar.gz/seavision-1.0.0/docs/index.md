# Home

SeaVision is a Python 🐍 library that removes the boilerplate from your computer vision workflow. Tired of repeating the same code for reading images/videos, running inference, uploading to fiftyone or fusing detections across cameras? So are we.

This project was born to help you experiment faster, prototype smarter, and build cleaner CV pipelines with minimal effort. Made by CV folks, for CV folks 🫶.

```python
import seavision as sv
```

## Still Cooking... 🍳

SeaVision is a work in progress. Please be patient while we sprinkle in more features and fix what we inevitably break 😬.

??? question "Wonder how this documentation is generated?"

    The following can help you get started:

    - [mkdocs-material](https://squidfunk.github.io/mkdocs-material/) --> the looks! :camera_with_flash:
    - [mkdocs.org](https://www.mkdocs.org) --> markdown based static site generator
    - [mkdocstrings](https://mkdocstrings.github.io/recipes/#automatic-code-reference-pages) --> Auto-document your code... if it has docstrings :wink:
    - Visit this repo's `mkdocs.yaml`


## Support

Buy me a :beer: or :coffee:
