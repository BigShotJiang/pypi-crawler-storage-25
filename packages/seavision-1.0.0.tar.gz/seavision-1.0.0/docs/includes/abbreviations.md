*[CV]: Computer Vision
*[AHOY]: A Horizon and Object detection Yolo network
*[DAN]: Dan And Night network (two AHOY models)
*[DALN]: Dan And Louis Network (AHOY for RGB images and LouisNet for gray16 images)
*[ONNX]: Open Neural Network Exchange
*[SAHI]: Sliced-Aided Hyper Inference
*[RAHI]: ROI-Aided Hyper Inference
*[ROI]: Region Of Interest
