<iframe
	src="https://sea-ai-detection-demo.hf.space"
	frameborder="0"
	width="100%"
	height="650px"
></iframe>
