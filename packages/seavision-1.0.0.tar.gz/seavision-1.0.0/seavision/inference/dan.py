"""DAN = **D**ay **A**nd **N**ight model for day and night detection."""

import logging
from typing import Any, Callable, Dict, List, Sequence, Tuple, Union

import numpy as np

from .mimo import MIMO
from .postprocessing import postprocess_ahoy, postprocess_ahoyv2, postprocess_yolo
from .preprocessing import preprocess_yolo, resize_and_center_images_in_batch
from .results import Results

logger = logging.getLogger(__name__)


class DAN(MIMO):
    """**D**ay **A**nd **N**ight CNN.

    Based on two models (AHOY or YOLO).
    """

    _registry: List[Tuple[Tuple[str, ...], type]] = []

    @classmethod
    def register(cls, *markers: str) -> Callable[[type], type]:
        """Decorator to register a DAN variant with path markers."""

        def decorator(variant_cls: type) -> type:
            cls._registry.append((markers, variant_cls))
            return variant_cls

        return decorator

    @classmethod
    def _resolve_base(cls, model_path: str) -> type:
        path_lower = model_path.lower()
        for markers, variant_cls in cls._registry:
            if any(m in path_lower for m in markers):
                return variant_cls
        return DANv1

    def __new__(cls, *args: Tuple[Any], **kwargs: Dict[str, Any]) -> "DAN":
        """Create the appropriate DAN variant instance based on the model path.

        Args:
            *args: Positional arguments passed to the constructor.
            **kwargs: Keyword arguments passed to the constructor.

        Returns:
            An instance of a registered DAN variant based on the model path.
        """
        model_path = kwargs.get("model_path") or (args[0] if args else None)
        if model_path is None:
            raise ValueError("model_path must be provided")

        base = cls._resolve_base(str(model_path))

        if cls is DAN:
            return super().__new__(base)

        # Build subclass with new base
        subclass = type(cls.__name__, (cls, base), {})
        instance = super().__new__(subclass)
        return instance

    def __init__(self, model_path: str, device: Union[int, str, None] = None) -> None:
        """Initialize the DAN model.

        Args:
            model_path: Path to the model file containing the weights and architecture.
            device: CUDA device to use.
        """
        super().__init__(model_path, device)
        self.validate_and_rename_outputs(self.expected_output_names)

        self.det_conf_thresh = 0.147
        self.det_iou_thresh = 0.1
        self.do_upscale = False

    @property
    def expected_output_names(self) -> List[str]:
        """Expected output names for the DAN model."""
        raise NotImplementedError("Subclass must implement this method")

    @property
    def do_upscale(self) -> bool:
        """Whether to upscale the input for inference."""
        return getattr(self, "_do_upscale", False)

    @do_upscale.setter
    def do_upscale(self, value: bool) -> None:
        """Set whether to upscale the input for inference."""
        self._set_attr("_do_upscale", value)

    def _preprocess(self, ims: Sequence[np.ndarray]) -> List[np.ndarray]:
        """Transform the input image so that the model can infer from it.

        Args:
            ims: The input image(s).

        Returns:
            Preprocessed images (one per model stream).
        """
        if self.model.alloc_arrays is not None:
            return [
                resize_and_center_images_in_batch(im, alloc_array, upscale=upscale)
                for im, alloc_array, upscale in zip(
                    ims, self.model.alloc_arrays, self.do_upscale
                )
            ]
        return [
            preprocess_yolo(im, input_hw, dtype, upscale)
            for im, input_hw, dtype, upscale in zip(
                ims, self.model.input_hw, self.model.dtype, self.do_upscale
            )
        ]

    def _postprocess(
        self,
        output: Dict[str, np.ndarray],  # pylint:disable=unused-argument
    ) -> Sequence[Sequence[np.ndarray]]:
        """Transform raw model output to application output.

        Args:
            output: Raw model output.

        Returns:
            Outer sequence corresponds to each model's batch input.
                Inner sequence corresponds to each sample in the batch.
                Arrays are of size (N, 6), where N is the number of detected
                bounding boxes, and 6 are the [x1,y1,x2,y2,score,class] per detection.
        """
        raise NotImplementedError("Subclass must implement this method")

    def _to_results(self, output: Sequence[np.ndarray]) -> List[Results]:
        """Convert the model output to a Results object."""
        return [
            Results.from_ahoy_output(
                out, image_hw=hw, cls_map=cls_map, label_encoder=self.label_encoder
            ).apply_confidence_map(conf_map, cls_map)
            for batch, orig_hw, cls_map, conf_map in zip(
                output, self.orig_hw, self.cls_map, self.conf_map
            )
            for out, hw in zip(batch, orig_hw)
        ]


@DAN.register("danv1")
class DANv1(DAN):
    """**D**ay **A**nd **N**ight CNN.

    Based on two AHOY models.
    """

    def __init__(self, model_path: str, device: Union[int, str, None] = None) -> None:
        """Initialize the DANv1 model."""
        super().__init__(model_path, device)
        self.hor_conf_thresh = 0.05

    @property
    def expected_output_names(self) -> List[str]:
        """Expected output names for the DAN model."""
        return [
            "ir_output0",
            "ir_output1",
            "ir_output2",
            "rgb_output0",
            "rgb_output1",
            "rgb_output2",
        ]

    def _postprocess(
        self,
        output: Dict[str, np.ndarray],
    ) -> Sequence[Sequence[np.ndarray]]:
        """Transform raw model output to application output.

        Args:
            output: Raw model output.

        Returns:
            Outer sequence corresponds to each model's batch input.
                Inner sequence corresponds to each sample in the batch.
                Arrays are of size (N, 6), where N is the number of detected
                bounding boxes, and 6 are the [x1,y1,x2,y2,score,class] per detection.
        """
        prefixes = ["ir_", "rgb_"]
        return [
            postprocess_ahoy(
                output_yolo=output[f"{prefix}output0"],
                output_offset=output[f"{prefix}output1"],
                output_theta=output[f"{prefix}output2"],
                input_hw=self.model.input_hw[i],
                orig_hw=self.orig_hw[i],
                det_conf_thresh=self.det_conf_thresh[i],
                det_iou_thresh=self.det_iou_thresh[i],
                hor_conf_thresh=self.hor_conf_thresh[i],
                was_upscaled=self.do_upscale[i],
            )
            for i, prefix in enumerate(prefixes)
        ]


@DAN.register("danv2", "obb")
class DANv2(DAN):
    """**D**ay **A**nd **N**ight CNN.

    Based on two AHOY models.
    """

    def __init__(self, model_path: str, device: Union[int, str, None] = None) -> None:
        """Initialize the DANv2 model."""
        super().__init__(model_path, device)
        self.hor_conf_thresh = 0.05

    @property
    def expected_output_names(self) -> List[str]:
        """Expected output names for the DAN model."""
        return ["ir_output0", "ir_output1", "rgb_output0", "rgb_output1"]

    def _postprocess(
        self,
        output: Dict[str, np.ndarray],
    ) -> Sequence[Sequence[np.ndarray]]:
        """Transform raw model output to application output.

        Args:
            output: Raw model output.

        Returns:
            Outer sequence corresponds to each model's batch input.
                Inner sequence corresponds to each sample in the batch.
                Arrays are of size (N, 6), where N is the number of detected
                bounding boxes, and 6 are the [x1,y1,x2,y2,score,class] per detection.
        """
        prefixes = ["ir_", "rgb_"]
        return [
            postprocess_ahoyv2(
                output_yolo=output[f"{prefix}output0"],
                output_yolo_obb=output[f"{prefix}output1"],
                input_hw=self.model.input_hw[i],
                orig_hw=self.orig_hw[i],
                det_conf_thresh=self.det_conf_thresh[i],
                det_iou_thresh=self.det_iou_thresh[i],
                hor_conf_thresh=self.hor_conf_thresh[i],
                was_upscaled=self.do_upscale[i],
            )
            for i, prefix in enumerate(prefixes)
        ]


@DAN.register("dany")
class DANY(DAN):
    """**D**ay **A**nd **N**ight **Y**olo CNN.

    Based on two YOLO models.
    """

    @property
    def expected_output_names(self) -> List[str]:
        """Expected output names for the DANY model."""
        return ["ir_output0", "rgb_output0"]

    def _postprocess(
        self,
        output: Dict[str, np.ndarray],
    ) -> Sequence[Sequence[np.ndarray]]:
        """Transform raw model output to application output.

        Args:
            output: Raw model output.

        Returns:
            Outer sequence corresponds to each model (IR, RGB).
            Inner sequence corresponds to each sample in the batch.
            Arrays are of size (N, 6), where N is the number of detected
            bounding boxes, and 6 are the [x1,y1,x2,y2,score,class] per detection.
        """
        prefixes = ["ir_", "rgb_"]
        results = []

        for i, prefix in enumerate(prefixes):
            model_preds = []
            det_logits_batch = output[f"{prefix}output0"]  # Shape: (batch_size, ...)

            # Process each image in the batch
            for det_logits, im0_hw in zip(det_logits_batch, self.orig_hw[i]):
                bboxes, p_bbox, classes, p_class_given_bbox = postprocess_yolo(
                    det_logits,
                    self.model.input_hw[i],
                    im0_hw,
                    conf_thresh=self.det_conf_thresh[i],
                    iou_thresh=self.det_iou_thresh[i],
                    was_upscaled=self.do_upscale[i],
                )
                model_preds.append(np.c_[bboxes, p_bbox, classes, p_class_given_bbox])

            results.append(model_preds)

        return results
