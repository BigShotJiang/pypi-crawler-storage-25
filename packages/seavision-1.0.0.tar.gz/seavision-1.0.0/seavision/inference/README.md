# Object and Horizon Detection with SEA.AI's Deep Learning Models

This project provides a comprehensive suite for processing, inference, and post-processing for object and horizon detection using SEA.AI's deep learning models. Below you will find a brief overview of the available models and usage examples.

## LouisNet

Custom U-Net based CNN developed in-house for object and horizon detection.

### Example usage

```python
from LouisNet import LouisNet
from utils import draw_preds, pil_side_by_side

with LouisNet(model_path=weights_path + "cerulean-level-b2-portrait.onnx") as cnn:
    ims = np.stack([img_sailing_irl_640, img_sailing_irr_640])
    preds = cnn.detect(ims)

pil_side_by_side(
    draw_preds(ims[0], preds[0], rect_color=(0,0,255), line_color=(255,0,0)),
    draw_preds(ims[1], preds[1], rect_color=(0,0,255), line_color=(255,0,0))
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/d1db55ca-a4cc-4ec1-bca4-553c8720c512)

```python
from LouisNet import LouisNet
from utils import draw_preds, pil_side_by_side

with LouisNet(model_path=weights_path + "cerulean-level-17_11_2023_RL_SPLIT_LN1_ep147.pb") as cnn:
    ims = np.stack([img_sentry_twfov, img_sentry_tnfov])
    preds = cnn.detect(ims)

pil_side_by_side(
    draw_preds(ims[0], preds[0], rect_color=(0,0,255), line_color=(255,0,0)),
    draw_preds(ims[1], preds[1], rect_color=(0,0,255), line_color=(255,0,0))
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/7dd4daa4-c20f-4e21-9b77-8d24edd848da)

## AHOY (IR)

**A** **H**orizon **O**bject detection based on **Y**OLOv5 (AHOY) is a combination of two models packed into a single computational graph. The model is capable of detecting objects and estimating the horizon line in a single forward pass. The object detection model is based on YOLOv5, while the horizon detection model is a custom model consisting of the YOLOv5 backbone and a custom head consisting of two classification outputs.

### Example usage

```python
from ahoy import AHOY
from utils import draw_preds, pil_side_by_side

with AHOY(model_path=weights_path + "ahoy-IR-b2.onnx") as cnn:
    ims = np.stack(
        [convert_to_8bit(im) for im in [img_sailing_irl_320, img_sailing_irr_320]]
    )
    preds = cnn.detect(ims)

pil_side_by_side(
    draw_preds(ims[0], preds[0], rect_color=(0,0,255), line_color=(255,0,0)),
    draw_preds(ims[1], preds[1], rect_color=(0,0,255), line_color=(255,0,0))
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/5c92afc8-f87e-4ca8-a7c5-d300eed50418)

```python
from ahoy import AHOY
from utils import draw_preds, pil_side_by_side

with AHOY(model_path=weights_path + "ahoy-IR-b2.onnx") as cnn:
    ims = np.stack(
        [convert_to_8bit(im) for im in [img_sailing_irl_640, img_sailing_irr_640]]
    )
    preds = cnn.detect(ims)

pil_side_by_side(
    draw_preds(ims[0], preds[0], rect_color=(0,0,255), line_color=(255,0,0)),
    draw_preds(ims[1], preds[1], rect_color=(0,0,255), line_color=(255,0,0))
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/057cdbe2-c539-47e5-a363-76bc053557b8)

## AHOY (RGB)

Similar to the IR version, but this model takes as input RGB images.

### Example usage

```python
with AHOY(model_path=weights_path + "ahoy-RGB-b2.onnx") as cnn:
    ims = np.stack(
        [im for im in [img_sailing_rgb_320, img_sailing_rgb_640]]
    )
    preds = cnn.detect(ims)

pil_up_down(
    Image.fromarray(draw_preds(ims[0], preds[0])),
    Image.fromarray(draw_preds(ims[1], preds[1]))
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/af0425e5-71b2-4675-a5c7-ce33ab59752e)


## DAN

**D**ay **A**nd **N**ight (DAN) vision model. This is basically two AHOY models combined into one, one will take as input RGB images and the other will take as input IR images.

### Example usage

```python
from dan import DAN
from utils import draw_preds, pil_side_by_side, pil_up_down

with DAN(model_path=weights_path + "dan-b2.onnx") as cnn:
    ims = [
        np.stack([convert_to_8bit(im) for im in [img_sailing_irl_640, img_sailing_irr_640]]),
        np.stack([img_sailing_rgb_640])
    ]
    preds = cnn.detect(ims)

pil_up_down(
    pil_side_by_side(
        draw_preds(ims[0][0], preds[0]),
        draw_preds(ims[0][1], preds[1])
    ),
    draw_preds(cv2.resize(ims[1][0], None, fx=0.8, fy=0.8), preds[2])
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/df002924-2fef-4c83-97cc-e6f0b79e0a75)

```python
from dan import DAN
from utils import draw_preds, pil_side_by_side, pil_up_down

with DAN(model_path=weights_path + "dan-b2.onnx") as cnn:
    ims = [
        np.stack([convert_to_8bit(im) for im in [img_sailing_irl_640, img_sailing_irr_640]]),
        np.stack([img_sailing_rgb_640])
    ]
    preds = cnn.detect(ims)

pil_up_down(
    pil_side_by_side(*[draw_preds(im, pred) for im, pred in zip(ims[0], preds[:2])]),
    pil_side_by_side(
        *[
            draw_preds(cv2.resize(im, None, fx=8 / 15, fy=8 / 15), pred)
            for im, pred in zip(ims[1], preds[2:])
        ]
    ),
)
```

![image](https://github.com/SEA-AI/Core-Backend/assets/35779409/ab096932-af80-4081-b357-23a0620673db)
