"""SAHI Inference Module.

Sliced Aided Hyper Inference. Mainly a wrapper around [SAHI](https://github.com/obss/sahi)
library.
"""

import logging
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

import numpy as np

from seavision.geometry.utils import create_affine_matrix
from seavision.sensorfusion import SensorFusionMethod

from .models import AHOY
from .preprocessing import resize_image_keeping_aspect_ratio
from .results import Results
from .slicing import AutoSlicer, ModelValidationMixin

if TYPE_CHECKING:
    from sahi.slicing import SliceImageResult

logger = logging.getLogger(__name__)


class SAHI(AHOY, ModelValidationMixin):
    """SAHI model for 4k object detection using image slicing."""

    BATCH_TO_RESOLUTION_CONFIG = {  # (height, width)
        3: (1080, 1920),
        7: (1620, 2880),
        9: (2160, 3840),
    }

    def __init__(
        self,
        model: str,
        device: str = None,
        sf_method: SensorFusionMethod = SensorFusionMethod.WBF,
        resolution_config: Optional[Dict[int, Tuple[int, int]]] = None,
    ):
        """Initialize the SAHI model.

        Args:
            model: The model to use.
            device: The device to use.
            sf_method: The sensor fusion method to use.
            resolution_config: The resolution configuration to use.
        """
        super().__init__(model, device)

        self.validate_model(model, supported_batch_sizes=[3, 7, 9])
        self.sf_method = sf_method
        self.slice_image_result: Optional[SliceImageResult] = None
        self.auto_slicer: AutoSlicer
        self.resolution_config = resolution_config or self.BATCH_TO_RESOLUTION_CONFIG
        self.resolution: Optional[Tuple[int, int]] = None

    def __call__(self, ims: np.ndarray, verbose: bool = False) -> List[Results]:
        """Process input images using SAHI approach.

        Args:
            ims: Input image array
            verbose: Whether to print processing information

        Returns:
            List of Results objects
        """
        self.auto_slicer = AutoSlicer.from_model(self.model)
        self.resolution = self.resolution_config[self.model.input_bs]

        # If resizing is necessary, resize input image according to the batch size
        if self.resolution != ims.shape[:2]:
            ims = resize_image_keeping_aspect_ratio(ims, self.resolution)

        return super().__call__(ims, verbose)

    def preprocess_hook(self, ims: np.ndarray) -> List[np.ndarray]:
        """Preprocess input image by slicing into smaller segments.

        Args:
            ims: Input image array

        Returns:
            List of preprocessed image arrays
        """
        self.slice_image_result = self.auto_slicer.slice(
            ims, self.resolution, self.model.input_bs - 1
        )
        return self.slice_image_result.images + [ims]

    def to_results_hook(self, output: List[Results]) -> Results:
        """Convert model output to results tuple.

        Returns:
            Results object with fused results.
        """
        projected_results = []

        # Project sliced results back match the original image
        for results, starting_pixel in zip(
            output[:-1], self.slice_image_result.starting_pixels
        ):
            homography_matrix = create_affine_matrix(
                starting_pixel[0], starting_pixel[1]
            )
            projected_result = results.apply_homography(
                homography_matrix,
                new_width=self.resolution[1],
                new_height=self.resolution[0],
            )
            projected_results.append(projected_result)

        # Add original image results
        projected_results.append(output[-1])

        # Fuse results
        method = self.sf_method(weights=[1] * len(projected_results))
        fused_results = method.fuse(projected_results)

        return fused_results


def main():
    """Run the SAHI baseline approach benchmark."""
    print("\nStarting benchmark for SAHI approach")
    from seavision.io import load_images_from_folder

    images = load_images_from_folder("data_path")

    sahi = SAHI(
        "model_file",
        sf_method=SensorFusionMethod.WBF,
    )

    for name, im in images.items():
        name = name.removesuffix(".jpg")
        _ = sahi(im, verbose=True)


if __name__ == "__main__":
    main()
