"""Inference using TensorRT engine.

Taken mostly from this repo
https://github.com/NVIDIA/object-detection-tensorrt-example/blob/master/SSD_Model/utils/common.py
"""

import atexit
import json
import logging
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Tuple, Union

import numpy as np
import pycuda.driver as cuda  # pylint: disable=import-error
import tensorrt as trt  # pylint: disable=import-error

from .infer_abc import IO, Infer

# loggers
TRT_LOGGER = trt.Logger(trt.Logger.ERROR)
logger = logging.getLogger(__name__)


def clean_cuda_context() -> None:
    """Pop the current CUDA context."""
    logger.info("Exiting, cleaning up CUDA context.")
    with suppress(cuda.LogicError):
        cuda.Context.pop()


atexit.register(clean_cuda_context)


@dataclass
class HostDeviceMem(IO):
    """Simple helper data class that's a little nicer to use than a tuple."""

    host: np.ndarray
    device: cuda.DeviceAllocation
    dtype: np.dtype = field(init=False)  # dtype is auto-initialized in __post_init__

    def __post_init__(self) -> None:
        # Use the dtype from host to set the dtype attribute
        self.dtype = self.host.dtype


class InferTRT(Infer):
    """Inference using TensorRT engine."""

    def __init__(self, trt_engine_path: str, device: int = 0) -> None:
        """Load TensorRT engine and allocate memory for inference.

        Args:
            trt_engine_path: Path to the TensorRT engine file.
            device: CUDA device to use.
        """
        try:
            trt.init_libnvinfer_plugins(TRT_LOGGER, "")
            logger.info("✓ TensorRT plugins initialized")
        except Exception as e:
            logger.warning(f"⚠️ Could not initialize plugins: {e}")

        cuda.init()
        device = 0 if device is None else device
        self.ctx = cuda.Device(device).make_context()

        # Display requested engine settings to stdout
        logger.info(f"⚙️ Loading TensorRT inference engine {trt_engine_path}")
        self.trt_engine = self.load_model(trt_engine_path)
        self.is_trt10 = not hasattr(self.trt_engine, "num_bindings")

        # Execution context is needed for inference
        self.context = self.trt_engine.create_execution_context()

        # This allocates memory for network inputs/outputs on both CPU and GPU
        self.inputs, self.outputs, self.bindings, self.stream = self.allocate_buffers(
            self.trt_engine, self.is_trt10
        )

        # Allocate memory for batch processing
        self.alloc_arrays = self.get_alloc_arrays()

        self.ctx.pop()  # pop the context to avoid CUDA error

        logger.info("⚙️ TensorRT engine loaded successfully.")
        for i in self.inputs:
            logger.info(f" - 📥 Input {i.name}: shape {i.shape}, dtype {i.dtype}")
        for o in self.outputs:
            logger.info(f" - 📤 Output {o.name}: shape {o.shape}, dtype {o.dtype}")

        logger.info("⏳ Warming up...")
        self.warmup()

    def load_model(self, model_path: str) -> trt.ICudaEngine:
        """Load model from file.

        Args:
            model_path: Path to the model file.
        """
        return self.load_engine(model_path, TRT_LOGGER)

    def warmup(self, n: int = 10) -> None:
        """Warmup the model by running inference on a batch of images.

        Args:
            n: Number of warmup iterations.
        """
        ims = [np.zeros(inp.shape, dtype=inp.dtype) for inp in self.inputs]
        ims = ims[0] if len(ims) == 1 else ims
        for _ in range(n):
            self.forward(ims)

    def check_input_shape(self, ims: Union[np.ndarray, List[np.ndarray]]) -> None:
        """Check if input shape matches image shape.

        Args:
            ims: Image to process.
        """
        # Check if input shape matches image shape
        if len(self.inputs) == 1:
            ims = [ims]

        for inp, im in zip(self.inputs, ims):
            msg = f"input shape {inp.shape} not equal to image shape {im.shape}"
            assert inp.shape == im.shape, msg

    @property
    def input_shape(
        self,
    ) -> Union[Tuple[int, int, int, int], List[Tuple[int, int, int, int]]]:
        """Return input(s) shape of the model."""
        shapes = [inp.shape for inp in self.inputs]
        if len(shapes) == 1:
            return shapes[0]
        return shapes

    @property
    def dtype(self) -> Union[np.dtype, List[np.dtype]]:
        """Return data type of the model."""
        dtypes = [inp.dtype for inp in self.inputs]
        if len(dtypes) == 1:
            return dtypes[0]
        return dtypes

    @staticmethod
    def allocate_buffers(
        engine: trt.ICudaEngine,
        is_trt10: bool = False,
    ) -> Tuple[List[HostDeviceMem], List[HostDeviceMem], List[int], cuda.Stream]:
        """Allocates host and device buffer for TRT engine inference.

        Args:
            engine (trt.ICudaEngine): TensorRT engine
            is_trt10 (bool): Whether the engine is TRT 1.0

        Returns:
            inputs [HostDeviceMem]: engine input memory
            outputs [HostDeviceMem]: engine output memory
            bindings [int]: buffer to device bindings
            stream (cuda.Stream): cuda stream for engine inference synchronization
        """
        inputs = []
        outputs = []
        bindings = []
        stream = cuda.Stream()

        def _get_binding_shape(
            engine: trt.ICudaEngine, binding: str
        ) -> Tuple[int, ...]:
            return (
                engine.get_tensor_shape(binding)
                if is_trt10
                else engine.get_binding_shape(binding)
            )

        def _get_binding_dtype(engine: trt.ICudaEngine, binding: str) -> np.dtype:
            return (
                engine.get_tensor_dtype(binding)
                if is_trt10
                else engine.get_binding_dtype(binding)
            )

        def _binding_is_input(engine: trt.ICudaEngine, binding: str) -> bool:
            return (
                engine.get_tensor_mode(binding) == trt.TensorIOMode.INPUT
                if is_trt10
                else engine.binding_is_input(binding)
            )

        for binding in engine:
            shape = _get_binding_shape(engine, binding)
            size = trt.volume(shape)
            dtype = trt.nptype(_get_binding_dtype(engine, binding))
            # Allocate host and device buffers
            host_mem = cuda.pagelocked_empty(size, dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)
            # Append the device buffer to device bindings.
            bindings.append(int(device_mem))
            # Append to the appropriate list.
            if _binding_is_input(engine, binding):
                inputs.append(HostDeviceMem(binding, shape, host_mem, device_mem))
            else:
                outputs.append(HostDeviceMem(binding, shape, host_mem, device_mem))

        return inputs, outputs, bindings, stream

    def forward(
        self, ims: Union[np.ndarray, List[np.ndarray]]
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Run inference on batch of images.

        Args:
            ims: Batch of images to process.

        Returns:
            Model outputs.
        """
        # Check if input shape matches image shape
        self.check_input_shape(ims)

        # NOTE: when using multiple threads, make sure to handle CUDA context
        # https://forums.developer.nvidia.com/t/how-to-use-tensorrt-by-the-multi-threading-package-of-python/123085/8
        self.ctx.push()

        # Copy it into appropriate place into memory
        # (self.inputs was returned earlier by allocate_buffers())
        for inp, im in zip(self.inputs, [ims] if len(self.inputs) == 1 else ims):
            np.copyto(inp.host, np.ascontiguousarray(im.ravel()))

        # Fetch output from the model
        infer_output = self.do_inference(
            self.context,
            bindings=self.bindings,
            inputs=self.inputs,
            outputs=self.outputs,
            stream=self.stream,
            is_trt10=self.is_trt10,
        )

        # Reshape outputs
        infer_output = {
            out.name: np.reshape(infer_out, out.shape)
            for infer_out, out in zip(infer_output, self.outputs)
        }

        self.ctx.pop()

        # And return results
        return infer_output

    @staticmethod
    def do_inference(
        context: trt.IExecutionContext,
        bindings: List[int],
        inputs: List[HostDeviceMem],
        outputs: List[HostDeviceMem],
        stream: cuda.Stream,
        is_trt10: bool = False,
    ) -> List[np.ndarray]:
        """Host-device memory transfer and inference execution."""
        # https://github.com/NVIDIA/TensorRT/blob/release/10.8/samples/python/common_runtime.py
        if is_trt10:
            for io in inputs + outputs:
                context.set_tensor_address(io.name, int(io.device))

        # Transfer input data to the GPU.
        _ = [cuda.memcpy_htod_async(inp.device, inp.host, stream) for inp in inputs]
        # Run inference.
        if is_trt10:
            context.execute_async_v3(stream_handle=stream.handle)
        else:
            context.execute_async_v2(bindings=bindings, stream_handle=stream.handle)
        # Transfer predictions back from the GPU.
        _ = [cuda.memcpy_dtoh_async(out.host, out.device, stream) for out in outputs]
        # Synchronize the stream
        stream.synchronize()
        # Return only the host outputs.
        return [out.host for out in outputs]

    @staticmethod
    def save_engine(engine: trt.ICudaEngine, engine_dest_path: str) -> None:
        """Save a serialized engine to a file."""
        print("Engine:", engine)
        buf = engine.serialize()
        with Path(engine_dest_path).open("wb") as f:
            f.write(buf)

    @staticmethod
    def load_engine(
        engine_path: str, trt_logger: trt.Logger = TRT_LOGGER
    ) -> trt.ICudaEngine:
        """Load a serialized engine from a file."""
        with Path(engine_path).open("rb") as f, trt.Runtime(trt_logger) as runtime:
            if "yolov8" in engine_path:
                meta_len = int.from_bytes(
                    f.read(4), byteorder="little"
                )  # read metadata length
                metadata = json.loads(f.read(meta_len).decode("utf-8"))
                print("metadata:", metadata)
            engine = runtime.deserialize_cuda_engine(f.read())
        return engine

    def close(self) -> None:
        """Free CUDA memory and detach context."""
        for inp in self.inputs:
            inp.device.free()
        for out in self.outputs:
            out.device.free()

        try:
            self.ctx.pop()
        except cuda.LogicError:
            logger.warning("CUDA context already popped.")
