"""Abstract class for inference aimed to be framework-agnostic."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Tuple, Union

import numpy as np


@dataclass
class DimsOrder:
    """Dataclass for input dimensions order."""

    B: int
    C: int
    H: int
    W: int

    @classmethod
    def from_dict(cls, d: Dict[str, int]) -> "DimsOrder":
        """Create a DimsOrder object from a dictionary."""
        return cls(**d)


@dataclass
class IO:
    """Dataclass for input and output information."""

    name: str
    shape: Tuple[int, ...]
    dtype: str


class Infer(ABC):
    """Abstract class for inference."""

    dims_order = DimsOrder(B=0, C=1, H=2, W=3)
    inputs: List[IO] = []
    outputs: List[IO] = []

    def set_input_dims_order(self, B: int, C: int, H: int, W: int) -> None:
        """Set input dimensions order."""
        self.dims_order = DimsOrder(B, C, H, W)

    @abstractmethod
    def load_model(self, model_path: str) -> None:
        """Load a model from file."""

    @abstractmethod
    def warmup(self, n: int = 10) -> None:
        """Warmup the model with a batch of images."""

    @property
    @abstractmethod
    def input_shape(
        self,
    ) -> Union[Tuple[int, int, int, int], List[Tuple[int, int, int, int]]]:
        """Return input(s) shape of the model."""

    @property
    @abstractmethod
    def dtype(self) -> Union[np.dtype, List[np.dtype]]:
        """Return data type of the model."""

    @property
    def input_hw(self) -> Union[Tuple[int, int], List[Tuple[int, int]]]:
        """Return input(s) height and width of the model."""
        shapes = self.input_shape
        if isinstance(shapes, list):
            return [(s[self.dims_order.H], s[self.dims_order.W]) for s in shapes]
        return (shapes[self.dims_order.H], shapes[self.dims_order.W])

    @property
    def input_ch(self) -> Union[int, List[int]]:
        """Return input(s) number of channels of the model."""
        shapes = self.input_shape
        if isinstance(shapes, list):
            return [shape[self.dims_order.C] for shape in shapes]
        return shapes[self.dims_order.C]

    @property
    def input_bs(self) -> Union[int, List[int]]:
        """Return input(s) batch size of the model."""
        shapes = self.input_shape
        if isinstance(shapes, list):
            return [shape[self.dims_order.B] for shape in shapes]
        return shapes[self.dims_order.B]

    @property
    def alloc_arrays(self) -> Union[np.ndarray, List[np.ndarray]]:
        """Return arrays to be used for allocation of model inputs."""
        return getattr(self, "_alloc_arrays", None)

    @alloc_arrays.setter
    def alloc_arrays(self, value: Union[np.ndarray, List[np.ndarray]]) -> None:
        """Set arrays to be used for allocation of model inputs."""
        self._alloc_arrays = value

    @abstractmethod
    def forward(
        self, ims: Union[np.ndarray, List[np.ndarray]]
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Run inference on batch of images.

        Args:
            ims: Batch of images to process.
        """

    @abstractmethod
    def close(self) -> None:
        """Close the model. Free up resources."""

    def get_alloc_arrays(self) -> Union[np.ndarray, List[np.ndarray]]:
        """Allocate memory for batch processing."""
        if isinstance(self.input_shape, list):
            return [
                np.zeros(shape, dtype=dtype)
                for dtype, shape in zip(self.dtype, self.input_shape)
            ]
        return np.zeros(self.input_shape, dtype=self.dtype)
