"""Inference using TensorFlow."""

import logging
from typing import List, Tuple, Union

import numpy as np

from .infer_abc import IO, Infer

logger = logging.getLogger(__name__)


def import_tensorflow_globally():
    """Import TensorFlow globally."""
    global tf
    logging.info("Importing Tensorflow")
    try:
        import tensorflow.compat.v1 as tf

        tf.disable_v2_behavior()
    except Exception as e:
        logging.info(
            f"tensorflow.compat.v1 failed, trying to import tensorflow directly: {e}"
        )
        import tensorflow as tf


class InferTF(Infer):
    """Inference using TensorFlow."""

    def __init__(self, tf_model_path: str, memory_fraction: float = 0.5) -> None:
        """Load TensorFlow and allocate memory for inference.

        Args:
            tf_model_path: Path to the TensorRT file.
            memory_fraction: Memory fraction to use.
        """
        import_tensorflow_globally()
        self.model_path = tf_model_path
        self.memory_fraction = memory_fraction

        # Display requested engine settings to stdout
        logger.info(f"⚙️ Loading TensorFlow inference model {tf_model_path}")
        self.input_img, self.output_cm, self.output_hm = self.load_model(
            self.model_path
        )

        self.inputs: List[IO] = []
        self.inputs.append(IO("input", (2, 256, 320, 1), np.dtype(np.float32)))

        self.outputs: List[IO] = []
        self.outputs.append(
            IO("hor_activation", (2, 128, 160, 1), np.dtype(np.float32))
        )
        self.outputs.append(
            IO("cl_activation", (2, 128, 160, 12), np.dtype(np.float32))
        )

        logger.info("⚙️ TensorFlow model loaded successfully.")

        for i in self.inputs:
            logger.info(f" - 📥 Input {i.name}: shape {i.shape}, dtype {i.dtype}")
        for o in self.outputs:
            logger.info(f" - 📤 Output {o.name}: shape {o.shape}, dtype {o.dtype}")

        logger.info("⏳ Warming up...")
        self.warmup()

    def load_model(
        self, model_path: str
    ) -> Tuple["tf.Tensor", "tf.Tensor", "tf.Tensor"]:
        """Load model from file.

        Args:
            model_path: Path to the model file.

        Returns:
            Input image, output horizon map, output class map.
        """
        try:
            self.sess.close()
        except Exception as e:  # noqa
            logger.exception(e)
        config = tf.ConfigProto()
        config.gpu_options.per_process_gpu_memory_fraction = self.memory_fraction
        self.tf_config = config
        self.sess = tf.Session(config=config, graph=tf.Graph())

        with tf.gfile.GFile(model_path, "rb") as f:
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(f.read())

            with self.sess.graph.as_default() as graph:
                print("LOADING LN_SEG_WHS")

                tf.import_graph_def(graph_def, name="NN")

                input_img = graph.get_tensor_by_name("NN/input_img:0")
                output_hm = graph.get_tensor_by_name("NN/output_hm:0")
                output_cm = graph.get_tensor_by_name("NN/output_cm:0")

        return input_img, output_cm, output_hm

    def warmup(self, n: int = 100):
        """Warmup the model by running inference on a batch of images.

        Args:
            n: Number of warmup iterations.
        """
        ims = [np.zeros(inp.shape, dtype=inp.dtype) for inp in self.inputs]
        ims = ims[0] if len(ims) == 1 else ims
        for _ in range(n):
            self.forward(ims)

    @property
    def input_shape(self) -> tuple:
        """Return input(s) shape of the model."""
        shapes = [inp.shape for inp in self.inputs]
        if len(shapes) == 1:
            return shapes[0]
        return tuple(shapes)

    @property
    def dtype(self) -> Union[np.dtype, List[np.dtype]]:
        """Return data type of the model."""

    def check_input_shape(self, ims: Union[np.ndarray, List[np.ndarray]]) -> None:
        """Check if input shape matches image shape.

        Args:
            ims: Image to process.
        """
        # Check if input shape matches image shape
        if len(self.inputs) == 1:
            ims = [ims]

        for inp, im in zip(self.inputs, ims):
            msg = f"input shape {inp.shape} not equal to image shape {im.shape}"
            assert inp.shape == im.shape, msg

    def forward(
        self, ims: Union[np.ndarray, List[np.ndarray]]
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """Run inference on batch of images."""
        self.check_input_shape(ims)
        out = self.sess.run(
            {"cl_activation": self.output_cm, "hor_activation": self.output_hm},
            feed_dict={self.input_img: ims},
        )
        return out

    def close(self):
        """Close TensorFlow session."""
        self.sess.close()
