"""Extracts the horizon line and confidence from a batch of masks output of YOLO-LN."""

from typing import Literal

import numpy as np

from .fit import (
    get_mean_residuals_and_inliers_linear_model,
    ransac_line_fitting_vectorized,
    robust_linear_regressor,
)
from .ops import (
    HAS_CUPY,
    get_horizon_points_fast_batched,
    ncp,  # numpy or cupy if installed
    remove_water_in_sky_batched,
)


# MAIN FUNCTION ########
def get_horizon_from_masks(  # noqa: PLR0914, pylint: disable=too-many-locals
    masks: np.ndarray,
    method: Literal["ransac", "linear_regression"] = "ransac",
    subsample: int = 60,
    inlier_threshold: float = 3,  # 3px
    recompute: bool = False,
    min_pts: int = 20,
) -> dict:
    """Extracts the horizon line and confidence from a batch of masks output of LN_YOLO.

    Args:
        masks: The masks output from LN_YOLO with shape
            [batch_size, num_classes, height, width]
        method: Method to use for horizon extraction ('ransac', 'linear_regression')
        subsample: Whether to subsample the points for line fitting
        inlier_threshold: Threshold for inliers in the RANSAC algorithm
        recompute: Whether to recompute inliers and mean residuals. More expensive but
            can improve confidence and line accuracy
        min_pts: Minimum number of points required to fit a horizon line

    Returns:
        List of dicts containing the horizon line and confidence for each mask
    """
    if HAS_CUPY:
        masks = ncp.asarray(masks)
    full_mask = remove_water_in_sky_batched(masks)
    xs_full, ys_full = get_horizon_points_fast_batched(full_mask)

    horizons = []
    inlier_threshold /= full_mask.shape[
        -1
    ]  # Normalize inlier threshold to pixel coordinates

    for batch_idx in range(masks.shape[0]):
        xs_b = xs_full[batch_idx]
        ys_b = ys_full[batch_idx]

        valid_mask = (xs_b >= 0) & (ys_b >= 0)
        xs_b = xs_b[valid_mask]
        ys_b = ys_b[valid_mask]

        if len(xs_b) < min_pts:
            horizons.append({"horizon": None, "confidence": 0})
            continue

        xs, ys = xs_b, ys_b
        if subsample:
            xs_idx = ncp.random.choice(  # noqa
                a=len(xs_b), size=min(subsample, len(xs_b)), replace=False
            )
            xs = xs_b[xs_idx]
            ys = ys_b[xs_idx]
            if HAS_CUPY:
                xs = ncp.asnumpy(xs)
                ys = ncp.asnumpy(ys)

        if method == "linear_regression":
            model, inliers = robust_linear_regressor(xs, ys)
        elif method == "ransac":
            model, inliers = ransac_line_fitting_vectorized(
                np.stack([xs, ys], axis=1), 25, inlier_threshold, refit=recompute
            )
        else:
            raise ValueError(f"Invalid method: {method}")

        if model is None:
            horizons.append({"horizon": None, "confidence": 0})
            continue

        m, b = model
        horizon = [(0, b), (1, m + b)]

        inlier_ratio = len(inliers) / len(xs)
        if recompute:
            _, inlier_ids = get_mean_residuals_and_inliers_linear_model(
                model=model, xy=(xs_b, ys_b), threshold=inlier_threshold
            )
            inlier_ratio = len(inlier_ids) / len(xs_b)

        horizons.append({"horizon": horizon, "confidence": inlier_ratio})

    return horizons
