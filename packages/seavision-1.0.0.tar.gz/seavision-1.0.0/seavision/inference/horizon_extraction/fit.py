"""Robust line fitting using RANSAC and least squares methods.

This module provides functions to fit a line to a set of points using RANSAC,
remove water pixels above dense sky regions, and extract horizon points.
"""

from typing import Tuple, Union

import numpy as np

MIN_PTS_PER_LINE = 2

rng = np.random.default_rng(0x533D)  # Create a random number generator instance


def robust_linear_regressor(  # noqa: PLR0914, pylint: disable=too-many-locals
    x: np.ndarray, y: np.ndarray, keep_fraction: float = 0.9, iterations: int = 5
) -> Tuple[Union[Tuple[float, float], None], np.ndarray]:
    """Robust linear regression for feature_dim=1.

    Iteratively, fits a regression and removed top (1-keep_fraction) worst points.

    Args:
        x ( np.ndarray): x-values / features
        y ( np.ndarray): y-values / targets
        keep_fraction (float, optional): Fraction of points to keep in each iteration.
            Defaults to 0.9.
        iterations (int, optional): Number of iterations. Defaults to 5.

    Returns:
        List[Tuple[float, float]]: horizon defined by [[0, y_1], [1, y_2]],
            where y_1, y_2 € [0,1].
    """
    keep_index = slice(None)
    for _ in range(iterations):
        x = x[keep_index]
        y = y[keep_index]

        sum_x = np.sum(x)
        sum_y = np.sum(y)
        sum_xy = np.sum(x * y)
        sum_x2 = np.sum(x * x)

        len_x = len(x)

        slope = (sum_xy - sum_x * sum_y / len_x) / (sum_x2 - sum_x * sum_x / len_x)
        intersect = (sum_y - slope * sum_x) / len_x

        residuals = y - slope * x - intersect
        residuals *= residuals

        cut_point = int(len(x) * keep_fraction)
        partion_index = np.argpartition(residuals, cut_point)

        keep_index = partion_index[:cut_point]

    model = None if np.isnan(slope) else (slope, intersect)  # check for nan
    return model, np.vstack((x, y))


def fit_line_lstq(best_inliers: np.ndarray) -> Tuple[float, float]:
    """Fit a line using least squares method.

    Args:
        best_inliers: inliers of the best model (shape: [N, 2])

    Returns:
        Tuple[float, float]: slope and intercept of the fitted line
    """
    x_coords = best_inliers[:, 0]
    y_coords = best_inliers[:, 1]
    # Stack x coordinates and ones to form equation system Ax = b
    # where A is [[x1, 1], [x2, 1], ...] and b is [y1, y2, ...]
    equation_system = np.vstack([x_coords, np.ones_like(x_coords)]).T
    result = np.linalg.lstsq(equation_system, y_coords, rcond=None)[0]
    return (result[0].item(), result[1].item())


def ransac_line_fitting(  # noqa: PLR0914, pylint: disable=too-many-locals
    points: np.ndarray,
    max_iterations: int,
    threshold: float,
    min_inliers: Union[int, None] = None,
    refit: bool = False,
) -> Tuple[Union[Tuple[float, float], None], np.ndarray]:
    """RANSAC line fitting.

    Note:
        it is hard to set min_inliers fixed, as the horizon can be tilted and sometimes
        contain only little part of the width, therefore, it is better to control the
        convergence through the threshold and max_iterations for horizon fitting.

    Args:
        points: 2D points (shape: [N, 2])
        max_iterations: maximum number of RANSAC iterations before returning the best
            solution
        threshold: threshold for inliers (distance from the line)
        min_inliers: minimum number of inliers to stop the algorithm early
        refit: whether to refit the line using least squares

    Returns:
        best_model: best line model (slope, intercept)
        best_inliers: inliers of the best
    """
    best_model = None
    best_inliers = np.empty((0, 2))

    if len(points) > 1:
        for _ in range(max_iterations):
            sample_indices = rng.choice(points.shape[0], 2, replace=False)
            p1, p2 = points[sample_indices]
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]

            if dx == 0:  # vertical, divison by zero
                continue

            # line parameters (slope and intercept)
            slope = dy / dx
            intercept = p1[1] - slope * p1[0]

            # vertical distance from all points to the line
            line_y = slope * points[:, 0] + intercept
            distances = np.abs(points[:, 1] - line_y)

            # check if the number of inliers is the best so far
            inliers = points[distances < threshold]  # Determine inliers
            if len(inliers) > len(best_inliers):
                best_model = (slope.item(), intercept.item())
                best_inliers = inliers

            # are enough inliers found
            if min_inliers is not None and len(best_inliers) >= min_inliers:
                break

        if refit:
            best_model = fit_line_lstq(best_inliers)

    return best_model, best_inliers


def ransac_line_fitting_vectorized(  # noqa: PLR0914, pylint: disable=too-many-locals
    points: np.ndarray,
    max_iterations: int,
    threshold: float,
    refit: bool = False,
) -> Tuple[Union[Tuple[float, float], None], np.ndarray]:
    """RANSAC line fitting using vectorized operations.

    Args:
        points: 2D points (shape: [N, 2])
        max_iterations: maximum number of RANSAC iterations before returning the best
        threshold: threshold for inliers (distance from the line)
        refit: whether to refit the line using least squares

    Returns:
        best_model: best line model (slope, intercept)
        best_inliers: inliers of the best
    """
    n_points = points.shape[0]
    if n_points < MIN_PTS_PER_LINE:
        return None, np.empty((0, 2))

    # Step 1: Generate all random line pairs (N_iters, 2 points)
    idx = rng.integers(
        0, n_points, size=(max_iterations, 2)
    )  # Use the generator's integers method
    # Make sure we don’t pick the same point twice for a line
    valid = idx[:, 0] != idx[:, 1]
    idx = idx[valid]

    p1 = points[idx[:, 0]]  # Shape: (N_iters, 2)
    p2 = points[idx[:, 1]]  # Shape: (N_iters, 2)

    dx = p2[:, 0] - p1[:, 0]
    dy = p2[:, 1] - p1[:, 1]
    non_vertical = dx != 0
    dx = dx[non_vertical]
    dy = dy[non_vertical]
    p1 = p1[non_vertical]
    p2 = p2[non_vertical]

    slope = dy / dx
    intercept = p1[:, 1] - slope * p1[:, 0]

    # distance from all points to the line
    line_y = slope[:, None] * points[:, 0] + intercept[:, None]
    distances = np.abs(points[:, 1] - line_y)

    # Step 4: Count inliers and find best model
    inlier_mask = distances < threshold
    inlier_counts = np.sum(inlier_mask, axis=1)
    best_idx = np.argmax(inlier_counts)

    # Step 5: Least-squares refinement on inliers
    best_inliers = points[inlier_mask[best_idx]]

    if best_inliers.shape[0] < MIN_PTS_PER_LINE:
        return None, np.empty((0, 2))

    best_model = (
        (slope[best_idx], intercept[best_idx])
        if not refit
        else fit_line_lstq(best_inliers)
    )

    return best_model, best_inliers


def get_mean_residuals_and_inliers_linear_model(
    model: Tuple[float, float], xy: Tuple[np.ndarray, np.ndarray], threshold: float = -1
) -> Tuple[float, Union[np.ndarray, None]]:
    """Compute mean residual error and return ids of inliers with error below threshold.

    Args:
        model (Tuple[float, float]): linear model in form (slope, intercept)
        xy (Tuple[np.ndarray, np.ndarray]): (features, targets)
        threshold (float): threshold for inliers

    Returns:
        float: mean resisdual value in iterval [0, 1]
        list: inlier ids
    """
    m, b = model
    residual_errors = np.abs(m * xy[0] + b - xy[1])
    inlier_ids = None
    if threshold > -1:
        inlier_ids = np.argwhere(residual_errors < threshold).flatten()
        residual_errors = residual_errors[inlier_ids]
    return np.mean(residual_errors).item(), inlier_ids
