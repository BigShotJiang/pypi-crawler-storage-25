"""Fast horizon extraction and water removal using CuPy.

This module provides functions to efficiently process segmentation masks
on GPU, removing water pixels above dense sky regions and extracting horizon points.
"""

from typing import Tuple

try:
    import cupy as ncp  # pylint: disable=import-error
    from cupyx.scipy.signal import convolve2d  # pylint: disable=import-error

    HAS_CUPY = True
except ImportError:
    import numpy as ncp

    HAS_CUPY = False


def remove_water_in_sky_batched(  # noqa: PLR0914, pylint: disable=too-many-locals
    masks: ncp.ndarray,
    k: int = 10,
    water_id: int = 0,
    sky_id: int = 1,
    tricks: bool = False,
) -> ncp.ndarray:
    """Remove WATER pixels that are above regions densely covered with SKY pixels.

    Args:
        masks: Segmentation masks with shape [B, C, H, W]
        k: Number of consecutive SKY pixels to consider dense
        water_id: Index of the WATER class in masks
        sky_id: Index of the SKY class in masks
        tricks: Whether to use tricks to speed up the computation

    Returns:
        Modified masks with water pixels removed above dense sky
    """
    B, _, H, W = masks.shape
    sky = masks[:, sky_id].astype(ncp.uint8)  # [B, H, W]
    water = masks[:, water_id]  # [B, H, W]

    kernel = ncp.ones(k, dtype=ncp.uint8)
    sky_sums = ncp.empty((B, H - k + 1, W), dtype=ncp.uint8)  # [B, H-k+1, W]

    if HAS_CUPY:
        if tricks:
            new_shape = (B, H - k + 1, k, W)
            new_strides = (
                sky.strides[0],
                sky.strides[1],
                sky.strides[1],
                sky.strides[2],
            )

            strided = ncp.lib.stride_tricks.as_strided(
                sky, shape=new_shape, strides=new_strides
            )
            sky_sums = ncp.sum(strided, axis=2)
        else:
            for b in range(B):
                sky_sums[b] = convolve2d(
                    sky[b], kernel[:, None], mode="valid", boundary="fill", fillvalue=0
                )
    else:
        for b in range(B):
            sky_sums[b] = ncp.apply_along_axis(
                lambda m: ncp.convolve(m, kernel, mode="valid"), axis=0, arr=sky[b]
            )

    sky_mask_threshold = sky_sums == k  # [B, H-k+1, W]
    has_sky = sky_mask_threshold.any(axis=1)  # [B, W]

    if not ncp.any(sky_mask_threshold):
        return masks

    reversed_sky = sky_mask_threshold[:, ::-1, :]  # [B, H-k+1, W]
    max_y_indices = ncp.argmax(reversed_sky, axis=1)  # [B, W]
    horizon_y = H - k - max_y_indices  # [B, W]

    yy = ncp.arange(H, dtype=ncp.int16).reshape(1, H, 1)  # [1, H, 1]
    horizon_y_exp = horizon_y[:, None, :]  # [B, 1, W]
    valid_cols_exp = has_sky[:, None, :]  # [B, 1, W]

    horizon_mask = (yy < horizon_y_exp) & valid_cols_exp  # [B, H, W]
    remove_mask = water & horizon_mask  # [B, H, W]
    masks[:, water_id][remove_mask] = 0
    return masks


def get_horizon_points_fast_batched(  # noqa: PLR0914, pylint: disable=too-many-locals
    masks: ncp.ndarray,
    top_thresh: int = 5,
    normalize: bool = True,
    water_id: int = 0,
    land_id: int = 2,
) -> Tuple[ncp.ndarray, ncp.ndarray]:
    """Extract horizon points from a batch of segmentation masks.

    Finds the top-most water pixels in each column of the masks that are not near land
    pixels. Points near land are filtered out to avoid noise from waves and shoreline.

    Args:
        masks: Segmentation masks with shape [B, C, H, W]
        top_thresh: Minimum y-coordinate threshold to consider valid water pixels
        normalize: Whether to normalize output coordinates to [0, 1] range
        water_id: Channel index for water mask
        land_id: Channel index for land mask

    Returns:
        Tuple of (xs, ys) coordinates of horizon points.
        Invalid points are marked with -1.
    """
    B, _, H, W = masks.shape
    water = masks[:, water_id]  # [B, H, W]
    land = masks[:, land_id]  # [B, H, W]

    top_water_y = ncp.argmax(water, axis=1)  # [B, W]
    is_valid = top_water_y >= top_thresh  # [B, W]
    neighbor_offsets = ncp.array([-2, -1, 1, 2], dtype=ncp.int16).reshape((1, 4, 1))
    neighbor_y = top_water_y[:, None, :] + neighbor_offsets  # [B, 4, W]

    in_bounds = (neighbor_y >= 0) & (neighbor_y < H)  # [B, 4, W]
    clipped_y = ncp.clip(neighbor_y, 0, H - 1)  # [B, 4, W]

    b_idx = ncp.arange(B).reshape(B, 1, 1)  # [B, 1, 1]
    x_idx = ncp.arange(W).reshape(1, 1, W)  # [1, 1, W]

    land_neighbors = land[b_idx, clipped_y, x_idx] & in_bounds  # [B, 4, W]
    near_land = ncp.any(land_neighbors, axis=1)  # [B, W]

    final_valid = is_valid & (~near_land)  # [B, W]

    xs = ncp.broadcast_to(
        ncp.arange(W, dtype=ncp.int16).reshape(1, W), (B, W)
    )  # [B, W]
    ys = top_water_y  # [B, W]

    xs = ncp.where(final_valid, xs, -1)
    ys = ncp.where(final_valid, ys, -1)

    if normalize:
        xs = xs.astype(ncp.float32) / W
        ys = ys.astype(ncp.float32) / H

    return xs, ys
