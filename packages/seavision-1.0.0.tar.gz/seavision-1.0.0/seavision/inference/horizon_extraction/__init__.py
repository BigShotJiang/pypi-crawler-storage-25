"""Horizon postprocessing module.

This module contains functions for extracting the horizon line and confidence
from a batch of masks output of YOLO-LN.

If cupy is available, it will use cupy for GPU acceleration.
"""

from .extract import get_horizon_from_masks

__all__ = ["get_horizon_from_masks"]
