"""Collection of image preprocessing functions for inference.

Most functions are designed to work with NumPy arrays.
"""

import math
from typing import Optional, Sequence, Tuple, Union

import cv2
import numpy as np

GRAYSCALE_CHANNELS = 1
RGB_CHANNELS = 3
RGBA_CHANNELS = 4

GRAYSCALE_DIMS = 2
RGB_DIMS = RGBA_DIMS = 3


def resize(im: np.ndarray, max_side: int, fast: bool = True) -> tuple:
    """Resize an image to a maximum side length while maintaining its aspect ratio.

    Args:
        im: The input image as a NumPy array.
        max_side: The maximum side length of the output image.
        fast: If True, use linear interpolation. Otherwise, use area interpolation.

    Returns:
        A tuple containing the resized image, the original shape, and the resized shape.
    """
    h0, w0 = im.shape[:2]  # orig hw
    r = max_side / max(h0, w0)  # ratio
    if r != 1:  # if sizes are not equal
        interp = cv2.INTER_LINEAR if (fast or r > 1) else cv2.INTER_AREA
        im = cv2.resize(
            im, (math.ceil(w0 * r), math.ceil(h0 * r)), interpolation=interp
        )
    return im, (h0, w0), im.shape[:2]  # im, hw_original, hw_resized


def letterbox_image(
    image: np.ndarray,
    box_size: Tuple[int, int],
    upscale: bool = False,
    color: Tuple[int, int, int] = (0, 0, 0),
    ensure_3ch: bool = True,
) -> np.ndarray:
    """Resize and pad image to fit the desired size, preserving its aspect ratio.

    Args:
        image: numpy array representing the image.
        box_size: tuple (height, width) representing the target dimensions.
        upscale: Whether to upscale the input for inference.
        color: tuple (B, G, R) representing the color to pad with.
        ensure_3ch: Whether to ensure the image has 3 channels.

    Returns:
        The letterboxed image.
    """
    if ensure_3ch:
        image = ensure_three_channels(image)
    resized_img = resize_image_keeping_aspect_ratio(
        image=image,
        box_size=box_size,
        upscale=upscale,
    )
    new_height, new_width = resized_img.shape[:2]
    top_padding = (box_size[0] - new_height) // 2
    bottom_padding = box_size[0] - new_height - top_padding
    left_padding = (box_size[1] - new_width) // 2
    right_padding = box_size[1] - new_width - left_padding

    padded_img = (
        cv2.copyMakeBorder(
            resized_img,
            top_padding,
            bottom_padding,
            left_padding,
            right_padding,
            cv2.BORDER_CONSTANT,
            value=color,
        )
        if any([top_padding, bottom_padding, left_padding, right_padding])
        else resized_img
    )

    # Add channel dimension if image is grayscale
    return (
        padded_img[..., np.newaxis] if padded_img.ndim == GRAYSCALE_DIMS else padded_img
    )


def resize_image_keeping_aspect_ratio(
    image: np.ndarray,
    box_size: Tuple[int, int],
    interpolation: int = cv2.INTER_LINEAR,
    upscale: bool = True,
) -> np.ndarray:
    """Resize the image while preserving its aspect ratio.

    Args:
        image: numpy array representing the image.
        box_size: tuple (height, width) representing the target dimensions.
        interpolation: interpolation method to use.
        upscale: whether to upscale the image.
    """
    img_h, img_w = image.shape[:2]
    box_h, box_w = box_size

    img_ratio = img_w / img_h
    box_ratio = box_w / box_h

    # Determine the new dimensions
    if img_ratio >= box_ratio:
        # Resize by width
        new_w = box_w
        new_h = int(box_w / img_ratio)
    else:
        # Resize by height
        new_h = box_h
        new_w = int(box_h * img_ratio)

    if not upscale and (new_w >= img_w and new_h >= img_h):
        return image  # don't upscale and image is already within the box size

    if new_w == img_w and new_h == img_h:
        return image  # avoid unnecessary resize

    return cv2.resize(
        image,
        (new_w, new_h),
        interpolation=interpolation,
    )


def center_crop(image: np.ndarray, crop_hw: Tuple[int, int]) -> np.ndarray:
    """Center crop the image.

    Args:
        image: The input image.
        crop_hw: The height and width of the crop.

    Returns:
        The center cropped image.
    """
    height, width = image.shape[:2]
    crop_h, crop_w = crop_hw

    if crop_h == height and crop_w == width:
        return image

    # Calculate the starting points for cropping
    start_x = (width - crop_w) // 2
    start_y = (height - crop_h) // 2

    return image[start_y : start_y + crop_h, start_x : start_x + crop_w]


def pad_batch_dim(batch: np.ndarray, target_batch_size: int) -> np.ndarray:
    """Pad the batch dimension of an array to a target batch size with zeros.

    Args:
        batch: Input batch of shape (N, H, W, C).
        target_batch_size: Target batch size to pad to.

    Returns:
        Padded batch of shape (target_batch_size, H, W, C).

    Raises:
        ValueError: If target_batch_size < current batch size.

    Example:
        ```python
        batch = np.random.rand(3, 64, 64, 3)  # Simulate a batch of 3 images
        target_batch_size = 5
        padded_batch = pad_batch_dimension(batch, target_batch_size)
        print("Original batch shape:", batch.shape)
        print("Padded batch shape:  ", padded_batch.shape)
        ```
    """
    current_batch_size = batch.shape[0]
    if target_batch_size < current_batch_size:
        raise ValueError(
            "target_batch_size must be greater than or equal to the current batch size."
            f" batch.shape: {batch.shape}, target_batch_size: {target_batch_size}"
        )

    # Calculate the number of images to pad
    num_images_to_pad = target_batch_size - current_batch_size

    # If padding needed, create an array of zeros and stack it with the original batch
    if num_images_to_pad > 0:
        padding = np.zeros((num_images_to_pad,) + batch.shape[1:], dtype=batch.dtype)
        padded_batch = np.vstack((batch, padding))
    else:
        padded_batch = batch

    return padded_batch


def ensure_three_channels(im: np.ndarray) -> np.ndarray:
    """Ensure the input image has 3 channels by repeating the image if necessary.

    Args:
        im: The input image.

    Returns:
        The input image as a 3 channel image.
    """

    def handle_3d_input(im: np.ndarray) -> np.ndarray:
        channels = im.shape[-1]
        if channels == RGB_CHANNELS:
            return im  # Already 3 channel image
        if channels == GRAYSCALE_CHANNELS:
            return np.repeat(im, 3, axis=-1)  # Grayscale to 3 channel image
        if channels == RGBA_CHANNELS:
            return im[..., :3]  # Discard alpha channel
        raise ValueError(f"Invalid channel size {channels} for 3D input.")

    if im.ndim == GRAYSCALE_DIMS:
        return np.repeat(im[..., np.newaxis], 3, axis=-1)  # to 3 channel image
    if im.ndim == RGB_DIMS:
        return handle_3d_input(im)
    raise ValueError(f"Invalid number of dimensions: {im.ndim}. Expected 2 or 3.")


def preprocess_yolo(
    ims: np.ndarray, input_hw: Tuple[int, int], dtype: np.dtype, upscale: bool
) -> np.ndarray:
    """Transform the input image so that the engine can infer from it.

    Args:
        ims: The input image(s).
        input_hw: The input height and width.
        dtype: The data type to cast the image to.
        upscale: Whether to upscale the input for inference.

    Returns:
        The preprocessed image.
    """
    x = np.stack([letterbox_image(im, input_hw, upscale) for im in ims], axis=0)
    x = x.transpose(0, 3, 1, 2)  # NHWC -> NCHW
    return x.astype(dtype)


def resize_and_center_images_in_batch(
    input_batch: np.ndarray, output_batch: np.ndarray, upscale: bool = False
) -> np.ndarray:
    """Resize and center images from an input batch into a preallocated array.

    Args:
        input_batch: The input batch of images with shape (N, H_in, W_in, C), where N is
            the batch size, H_in and W_in are the height and width of the images, and C
            is the number of channels.
        output_batch: The preallocated array with shape (N, C, H_out, W_out), where
            H_out and W_out are the target height and width. The array's contents will
            be overwritten with the resized and centered images.
        upscale: Whether to upscale the input for inference.

    Notes:
        - The function modifies the output_batch in place and does not return a value.
        - Ensure that the output_batch is preallocated with the desired data type and
        dimensions to avoid unintended behavior.
        - Significant variation in input image dimensions may lead to visual artifacts
        in the output_batch due to overlapping or incomplete coverage when pasting
        resized images.
    """

    def add_ch_dim_if_necessary(image: np.ndarray) -> np.ndarray:
        return image[..., np.newaxis] if image.ndim == GRAYSCALE_DIMS else image

    h_o, w_o = output_batch.shape[-2:]  # NCHW

    for i, im in enumerate(input_batch):
        if im.ndim > GRAYSCALE_DIMS and im.shape[0] <= min(im.shape[1], im.shape[2]):
            processed_im = im.transpose(1, 2, 0)  # CHW -> HWC

        processed_im = resize_image_keeping_aspect_ratio(
            im, (h_o, w_o), upscale=upscale
        )
        processed_im = add_ch_dim_if_necessary(processed_im)
        processed_im = processed_im.transpose(2, 0, 1)  # HWC -> CHW

        # Calculate padding offsets for centering
        h, w = processed_im.shape[-2:]  # CHW
        pad_height = (h_o - h) // 2
        pad_width = (w_o - w) // 2

        output_batch[i, :, pad_height : pad_height + h, pad_width : pad_width + w] = (
            processed_im
        )

    return output_batch


def check_orientation(ims: np.ndarray, input_hw: Tuple[int, int]) -> None:
    """Check if the images are in the correct orientation."""
    landscape_model = input_hw[0] < input_hw[1]
    if landscape_model and ims.shape[0] > ims.shape[1]:
        raise ValueError(f"Expected landscape images, but got {ims.shape}.")
    if not landscape_model and ims.shape[0] < ims.shape[1]:
        raise ValueError(f"Expected portrait images, but got {ims.shape}.")


def preprocess_louisnet(
    images: Union[np.ndarray, Sequence[np.ndarray]],
    input_hw: Tuple[int, int],
    mean_top_pad: int = 1,
    max_temperature_span: int = 8000,
    mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Preprocess input data for a LouisNet model.

    Args:
        images: The input images.
        input_hw: The input height and width.
        mean_top_pad: The number of top rows to use for calculating the mean image.
        max_temperature_span: The maximum temperature span.
        mask: The mask to apply to the images.

    Returns:
        The preprocessed images.
    """
    mean_images = []
    for im in images:
        check_orientation(im, input_hw)  # sanity check

        image = im.astype(np.float32)
        resize_shape = (256, 320) if image.shape[0] > image.shape[1] else (320, 256)
        image = cv2.resize(image, resize_shape)

        # map hot pixel to max temperature span based on closed value
        allow_max = np.amin(image) + max_temperature_span
        image[image > allow_max] = allow_max
        # calculate the mean image

        # Cut Out masked areas and set them to mean value
        if isinstance(mask, np.ndarray):
            mask_i = cv2.resize(
                mask.astype(np.uint8), resize_shape, interpolation=cv2.INTER_NEAREST
            )
            mask = 1 - mask_i
            N = max(int(np.sum(mask_i)), 1)  # pylint: disable=invalid-name
            m = np.sum(image * mask_i) / N
            image[mask == 1] = m
            mean_image = image - m
        else:
            mean_image = image - image[mean_top_pad:, :].mean()
        mean_images.append(mean_image)
    return np.concatenate([mean_images], axis=0)[..., None]
