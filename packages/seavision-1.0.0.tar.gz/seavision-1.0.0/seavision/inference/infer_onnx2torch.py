"""Inference using a PyTorch model converted from ONNX using onnx2torch."""

import logging
from pathlib import Path
from typing import Dict, List, Tuple, Union

import numpy as np
import onnx
import torch
from onnx2torch import convert

from seavision.utils.onnx_utils import convert_fp16_model_to_fp32

from .infer_abc import IO, Infer
from .preprocessing import pad_batch_dim

logger = logging.getLogger(__name__)


class InferONNX2Torch(Infer):
    """Inference using a PyTorch model converted from ONNX using onnx2torch."""

    def __init__(self, onnx_model_path: str, device: str = None) -> None:
        """Convert the ONNX model to PyTorch and prepare for inference.

        Args:
            onnx_model_path: Path to the ONNX model file.
            device: Device to run the model on.
        """
        # load model
        onnx_model, self.inputs, self.outputs = self.load_model(onnx_model_path)

        logger.info(f"⚙️ {Path(onnx_model_path).stem} loaded successfully.")
        for i in self.inputs:
            logger.info(f" - 📥 Input {i.name}: shape {i.shape}, dtype {i.dtype}")
        for o in self.outputs:
            logger.info(f" - 📤 Output {o.name}: shape {o.shape}, dtype {o.dtype}")

        self.print_metadata(onnx_model)
        self.cls_map = self.get_cls_map(onnx_model)

        self.device = self.infer_device() if device is None else torch.device(device)
        if self.device == torch.device("cpu"):
            onnx_model = convert_fp16_model_to_fp32(onnx_model)

        # convert model to PyTorch
        self.model = convert(onnx_model, save_input_names=True)
        self.model.to(self.device)
        self.model.eval()

        logger.info("⚙️ ONNX converted to PyTorch.")

        # Allocate memory for batch processing
        # DANGER ZONE: only uncomment if images will all have same size during inference
        # self.alloc_arrays = self.get_alloc_arrays()  # noqa: ERA001

        logger.info(f"🔥 Warming up model on {self.device}.")
        self.warmup()

    def load_model(self, model_path: str) -> Tuple[onnx.ModelProto, List[IO], List[IO]]:  # noqa: PLR6301
        """Load an ONNX model and convert it to PyTorch using onnx2torch.

        Args:
            model_path: Path to the ONNX model file.

        Returns:
            ONNX model, input and output information.
        """
        onnx_model = onnx.load(model_path)

        def get_dims(tensor: onnx.TensorProto) -> Tuple[int, ...]:
            return tuple(dim.dim_value for dim in tensor.type.tensor_type.shape.dim)

        def get_dtype(tensor: onnx.TensorProto) -> np.dtype:
            return onnx.helper.tensor_dtype_to_np_dtype(
                tensor.type.tensor_type.elem_type
            )

        # Get input and output names and shapes
        inputs = [
            IO(tensor.name, get_dims(tensor), get_dtype(tensor))
            for tensor in onnx_model.graph.input
        ]
        outputs = [
            IO(tensor.name, get_dims(tensor), get_dtype(tensor))
            for tensor in onnx_model.graph.output
        ]

        return onnx_model, inputs, outputs

    @staticmethod
    def print_metadata(onnx_model: onnx.ModelProto) -> None:
        """Print the metadata properties of the ONNX model.

        Args:
            onnx_model: ONNX model.
        """
        if onnx_model.metadata_props:
            logger.info("🏷️ Metadata properties:")
            for prop in onnx_model.metadata_props:
                logger.info(f" - {prop.key}: {prop.value}")

    @staticmethod
    def get_cls_map(
        onnx_model: onnx.ModelProto, key: str = "names"
    ) -> Union[Dict[int, str], List[Dict[int, str]]]:
        """Get the class map from the ONNX model's metadata properties.

        Args:
            onnx_model: ONNX model.
            key: Key to get the class map from.

        Returns:
            Class map.
        """
        cls_map = None
        if onnx_model.metadata_props:
            for prop in onnx_model.metadata_props:
                if key in prop.key:
                    cls_map: dict = eval(prop.value)  # pylint: disable=eval-used
        if isinstance(cls_map, dict) and "HORIZON" not in cls_map.values():
            cls_map[-1] = "HORIZON"
        if isinstance(cls_map, (list, tuple)):
            for _map in cls_map:
                if "HORIZON" not in _map.values():
                    _map[-1] = "HORIZON"
        return cls_map

    def warmup(self, n: int = 10) -> None:
        """Warmup the model by running inference on a batch of images.

        Args:
            n: Number of warmup iterations.
        """
        ims = [np.zeros(inp.shape, dtype=inp.dtype) for inp in self.inputs]
        ims = ims[0] if len(ims) == 1 else ims
        for _ in range(n):
            self.forward(ims)

    @property
    def input_shape(
        self,
    ) -> Union[Tuple[int, int, int, int], List[Tuple[int, int, int, int]]]:
        """Return the input(s) shape(s) of the model.

        Returns:
            Input shape of the model.
        """
        shapes = [inp.shape for inp in self.inputs]
        if len(shapes) == 1:
            return shapes[0]
        return shapes

    @property
    def dtype(self) -> Union[np.dtype, List[np.dtype]]:
        """Return the data type of the model's input(s).

        Returns:
            Data type of the model.
        """
        dtypes = [inp.dtype for inp in self.inputs]
        if len(dtypes) == 1:
            return dtypes[0]
        return dtypes

    def forward(
        self, ims: Union[np.ndarray, List[np.ndarray]]
    ) -> Union[torch.Tensor, List[torch.Tensor]]:
        """Run inference on a batch of images.

        Args:
            ims: Batch of images to process.

        Returns:
            Model outputs.
        """
        ims = [ims] if isinstance(ims, np.ndarray) else ims
        ims = [pad_batch_dim(im, inp.shape[0]) for im, inp in zip(ims, self.inputs)]

        for im, inp in zip(ims, self.inputs):
            assert im.shape == inp.shape, f"shape mismatch: {im.shape} != {inp.shape}"
            assert im.dtype == inp.dtype, f"dtype mismatch: {im.dtype} != {inp.dtype}"

        # Convert inputs to PyTorch tensors and move them to the selected device
        ims = [self.np_to_torch(im) for im, inp in zip(ims, self.inputs)]

        # Ensure model is in evaluation mode
        self.model.eval()

        # No need to track gradients for inference
        with torch.inference_mode():
            infer_output = self.model(*ims)

        infer_output = self.torch_to_np(infer_output)

        return {
            out.name: infer_out for infer_out, out in zip(infer_output, self.outputs)
        }

    def close(self) -> None:  # no need to close for pytorch (?) # noqa: PLR6301
        """Close the model."""
        return None

    @staticmethod
    def infer_device() -> torch.device:
        """Get the device on which the model will run.

        Returns:
            Device on which the model is running.
        """
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def np_to_torch(self, x: np.ndarray) -> torch.Tensor:
        """Convert a NumPy array to a PyTorch tensor.

        Args:
            x: Input array.

        Returns:
            Output tensor.
        """
        return torch.from_numpy(x).to(self.device).contiguous()

    @staticmethod
    def torch_to_np(x: Union[torch.Tensor, List[torch.Tensor]]) -> List[np.ndarray]:
        """Convert a PyTorch tensor to a NumPy array.

        Args:
            x: Input tensor.

        Returns:
            Output array.
        """
        tensors = x if isinstance(x, (list, tuple)) else [x]
        return [t.cpu().detach().numpy() for t in tensors]
