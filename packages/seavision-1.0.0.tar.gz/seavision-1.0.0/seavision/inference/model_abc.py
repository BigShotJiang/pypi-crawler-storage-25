"""Inference wrapper for a model.

Defines the pipeline for running a model on input images.
>>> y = self(ims)  # shorthand
>>> y = self.postprocess(self.model.forward(self.preprocess(ims)))
"""

import json
import logging
from abc import ABC, abstractmethod
from itertools import chain
from pathlib import Path
from types import TracebackType
from typing import Any, Dict, List, Optional, Sequence, Tuple, Type, Union

import numpy as np
import yaml

from .infer_abc import IO, Infer
from .results import Results
from .utils import LabelEncoder, Profile

logger = logging.getLogger(__name__)

GRAYSCALE_CHANNELS = 1
RGB_CHANNELS = 3
RGBA_CHANNELS = 4
COMPATIBLE_CHANNELS = {GRAYSCALE_CHANNELS, RGB_CHANNELS, RGBA_CHANNELS}

GRAYSCALE_DIMS = 2
RGB_DIMS = RGBA_DIMS = 3
BATCH_DIMS = 4


def load_engine(model_path: str, device: Optional[Union[int, str]] = None) -> Infer:
    """Load the engine and initialize the class mapping."""
    if Path(model_path).suffix == ".engine":
        from .infer_trt import InferTRT

        return InferTRT(model_path, device)
    if Path(model_path).suffix == ".onnx":
        from .infer_onnx2torch import InferONNX2Torch

        return InferONNX2Torch(model_path, device)

    raise ValueError(f"{Path(model_path).suffix} is not supported.")


def load_mappings(
    fpath: str, reverse: bool = False
) -> Tuple[List[Dict[int, str]], List[Dict[int, float]]]:
    """Load class mapping and confidence threshold mapping from YAML or JSON file.

    Returns:
        Tuple of (class_mappings, conf_mappings) - always as lists
    """
    path = Path(fpath)

    with path.open("r", encoding="utf-8") as f:
        if path.suffix.lower() in {".yaml", ".yml"}:
            data = yaml.safe_load(f)
        elif path.suffix.lower() == ".json":
            data = json.load(f)
        else:
            raise ValueError(f"Unsupported file format: {path.suffix}")

    # Normalize to list
    items = data if isinstance(data, list) else [data]

    class_maps, conf_maps = [], []
    for item in items:
        item.pop("version", None)
        cls_map, conf_map = _parse_mapping(item, reverse)
        class_maps.append(cls_map)
        # Return empty dict if no thresholds defined
        conf_maps.append(conf_map if any(conf_map.values()) else {})

    if not any(conf_maps):
        logger.warning("⚠️ No class thresholds defined in the config")

    # Unpack if single element
    unpack = lambda x: x[0] if len(x) == 1 else x  # noqa: E731  # pylint: disable=C3001

    return unpack(class_maps), unpack(conf_maps)


def _parse_mapping(
    data: Dict, reverse: bool
) -> Tuple[Dict[int, str], Dict[int, float]]:
    """Parse a single mapping dict."""
    class_map, conf_map = {}, {}

    for k, v in data.items():
        key = int(v if reverse else k)
        val = k if reverse else v

        if isinstance(val, dict):
            class_map[key] = val.get("name", val)
            conf_map[key] = val.get("threshold", 0.0)
        else:
            class_map[key] = val
            conf_map[key] = 0.0

    return class_map, conf_map


class Model(ABC):
    """Abstract wrapper class for a model's inference pipeline."""

    def __init__(self) -> None:
        """Initialize the model."""
        self.orig_hw: Optional[List[Union[Tuple[int, int], List[Tuple[int, int]]]]] = (
            None
        )
        self.ims_count: Optional[List[int]] = None

        # Mappings
        self.cls_map: Optional[
            Union[Dict[int, str], List[Optional[Dict[int, str]]]]
        ] = None
        self.conf_map: Optional[
            Union[Dict[int, float], List[Optional[Dict[int, float]]]]
        ] = None
        self.label_encoder: Optional[LabelEncoder] = None

        self.profiles = {
            "preprocess": Profile(),
            "inference": Profile(),
            "stain_removal": Profile(),
            "postprocess": Profile(),
        }

    def __enter__(self) -> "Model":
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> bool:
        self.close()
        return False  # propagate exceptions

    def __call__(
        self, ims: np.ndarray, verbose: bool = False
    ) -> Union[Results, List[Results]]:
        """Run the model pipeline on the given input image(s).

        Args:
            ims: The input image(s).
            verbose: Whether to print the time spent in each step of the pipeline.
                If True, prints the time spent in each step of the pipeline.

        Returns:
            The model output.
        """
        with self.profiles["preprocess"]:
            ims = self.preprocess(self.preprocess_hook(ims))

        with self.profiles["inference"]:
            output = self.forward(ims)

        with self.profiles["postprocess"]:
            output = self.postprocess_hook(self.postprocess(output))
            results = self.to_results_hook(self.to_results(output))

        if verbose:
            for name, profile in self.profiles.items():
                print(f"{profile.dt * 1e3:>5.1f} ms - {name}")

        if sum(self.ims_count) == 1:
            return results[0]
        return results

    def preprocess_hook(self, ims: np.ndarray) -> np.ndarray:  # noqa: PLR6301
        """Implement custom preprocessing steps in the subclass."""
        return ims

    @abstractmethod
    def _preprocess(self, ims: Union[np.ndarray, Sequence[np.ndarray]]) -> Sequence:
        """Transform the input image(s) into the format expected by the model."""

    def preprocess(self, ims: np.ndarray) -> Sequence:
        """Transform the input image(s) into the format expected by the model."""
        ims = convert_to_nested_list(len(self.model.inputs), ims)
        self.ims_count = self.get_ims_count(ims)
        assert all(n <= i.shape[0] for n, i in zip(self.ims_count, self.model.inputs))
        self.orig_hw = self.get_orig_hw(ims, self.model.inputs)

        return self._preprocess(ims)

    def forward(self, ims: Union[np.ndarray, Sequence[np.ndarray]]) -> Sequence:
        """Shortcut to run model.forward on the given input image(s)."""
        return self.model.forward(ims)

    @abstractmethod
    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence:
        """Transform the model output into the desired format."""

    def postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[Any]:
        """Transform the model output into the desired format."""
        return self._postprocess(output)

    def postprocess_hook(self, output: Sequence[Any]) -> Sequence[Any]:  # noqa: PLR6301
        """Implement custom postprocessing steps in the subclass."""
        return output

    @abstractmethod
    def _to_results(self, output: Sequence) -> Union[Results, List[Results]]:
        """Transform the model output into the desired format."""

    def to_results(self, output: Sequence) -> Union[Results, List[Results]]:
        """Transform the model output into the desired format."""
        return self._to_results(output)

    def to_results_hook(  # noqa: PLR6301
        self, output: Union[Results, List[Results]]
    ) -> Union[Results, List[Results]]:
        """Implement custom to results steps in the subclass."""
        return output

    @staticmethod
    def get_ims_count(ims: List[Union[np.ndarray, List[np.ndarray]]]) -> List[int]:
        """Count the number of images in each input."""
        return [len(im) if isinstance(im, list) else 1 for im in ims]

    @staticmethod
    def get_orig_hw(
        ims: List[Union[np.ndarray, List[np.ndarray]]],
        inputs: List[IO],
    ) -> List[Union[Tuple[int, int], List[Tuple[int, int]]]]:
        """Get (H, W) for each input image or batch of images."""
        ims = [ims] if len(inputs) == 1 and isinstance(ims[0], np.ndarray) else ims

        def pad(shapes: List[Tuple[int, int]], n: int) -> List[Tuple[int, int]]:
            """Pad with (1, 1) to match expected input count."""
            return shapes + [(1, 1)] * max(0, n - len(shapes))

        orig_hw = []
        for inp, im in zip(inputs, ims):
            if isinstance(im, list):
                shapes = pad([get_image_hw(x) for x in im], inp.shape[0])
            else:
                shapes = pad([get_image_hw(im)], inp.shape[0])
            orig_hw.append(shapes)

        return orig_hw[0] if len(orig_hw) == 1 else orig_hw

    def close(self) -> None:
        """Close the model. Free up resources."""
        self.model.close()

    @property
    def model(self) -> Infer:
        """The model used for inference."""
        return self._model

    @model.setter
    def model(self, model: Infer) -> None:
        if (
            not isinstance(model, (Infer))
            and getattr(model, "__class__", None).__name__ != "AutoShape"
        ):
            raise ValueError("model must inherit from `Infer` or `AutoShape`")
        self._model = model

    @property
    def input_shape(self) -> Union[Tuple[int, ...], List[Tuple[int, ...]]]:
        """Shortcut to model input shape."""
        return self.model.input_shape

    @property
    def det_conf_thresh(self) -> float:
        """Confidence threshold for p(class).

        Predictions with score<conf are ignored.
        """
        return getattr(self, "_det_conf_thresh", 0.1)

    @det_conf_thresh.setter
    def det_conf_thresh(self, value: float) -> None:
        if not 0 <= value <= 1:
            raise ValueError("det_conf_thresh must be in [0, 1]")
        self._det_conf_thresh = value

    @property
    def det_iou_thresh(self) -> float:
        """Minimum IOU to be counted as a duplicate detection."""
        return getattr(self, "_det_iou_thresh", 0.1)

    @det_iou_thresh.setter
    def det_iou_thresh(self, value: float) -> None:
        if not 0 <= value <= 1:
            raise ValueError("det_iou_thresh must be in [0, 1]")
        self._det_iou_thresh = value

    @property
    def hor_conf_thresh(self) -> float:
        """Confidence threshold for p(horizon).

        Ignore predictions with score<conf.
        """
        return getattr(self, "_hor_conf_thresh", 0.1)

    @hor_conf_thresh.setter
    def hor_conf_thresh(self, value: float) -> None:
        if not 0 <= value <= 1:
            raise ValueError("hor_conf_thresh must be in [0, 1]")
        self._hor_conf_thresh = value

    def init_cls_map(
        self, cls_map_fpath: str, reverse: bool = False, multi_input: bool = False
    ) -> None:
        """Initialize class and confidence mappings.

        Args:
            cls_map_fpath (str): Path to the class mapping file (YAML or JSON).
            reverse (bool): Reverse the key-value pairs in the mapping.
            multi_input (bool): Whether to replicate the maps for multi-input models.
        """
        self.label_encoder = None
        path = Path(cls_map_fpath)

        # 👇 Inner helper to set dummy class and confidence maps
        def set_dummy_mappings() -> None:
            dummy_cls_map = {i: str(i) for i in range(20)}
            dummy_cls_map[-1] = "HORIZON"
            self.cls_map = dummy_cls_map
            self.conf_map = dict.fromkeys(range(20), 0.0)

        # 👇 Inner helper to handle multi-input models
        def handle_multi_input() -> None:
            # Ensure cls_map is a list
            if not isinstance(self.cls_map, list):
                self.cls_map = [self.cls_map] * len(self.model.inputs)

            # Build label encoder from all class maps
            all_labels = set(
                chain.from_iterable(
                    cls_map.values() for cls_map in self.cls_map if cls_map is not None
                )
            )
            self.label_encoder = LabelEncoder()
            self.label_encoder.fit(list(all_labels))

            # Ensure conf_map is a list
            if not isinstance(self.conf_map, list):
                self.conf_map = [self.conf_map] * len(self.model.inputs)

        # ✅ Case 1: Mapping file exists — try to load it
        if path.exists():
            try:
                self.cls_map, self.conf_map = load_mappings(cls_map_fpath, reverse)
            except Exception as e:
                raise ValueError(
                    f"Error loading class mapping from {cls_map_fpath}"
                ) from e

        # ✅ Case 2: Mapping not found, but model has one attached
        elif hasattr(self.model, "cls_map"):
            self.cls_map = self.model.cls_map
            self.conf_map = None

        # ❌ Case 3: No file and no model mapping — fallback to dummy
        else:
            logger.warning("Class mapping not found — using dummy fallback mapping.")
            set_dummy_mappings()

        # 🧠 Adjust mappings for multi-input models if needed
        if multi_input:
            handle_multi_input()

        # 🖨️ Log final results
        logger.info(f"Class Mapping: {self.cls_map}")
        logger.info(f"Confidence Mapping: {self.conf_map}")


def is_single_image(x: np.ndarray) -> bool:
    """Check if the input is a single image.

    Handles both HWC and CHW formats:
    - HWC: (H,W) or (H,W,C) where C in {1,3,4}
    - CHW: (C,H,W) where C in {1,3,4}
    """
    if x.ndim == GRAYSCALE_DIMS:
        return True
    if x.ndim == RGB_DIMS:
        # Check for both HWC and CHW formats
        channels = min(x.shape)  # Smallest dimension is likely channels
        return channels in COMPATIBLE_CHANNELS
    return False


def is_batch_image(x: np.ndarray) -> bool:
    """Check if the input is a batch of images.

    Handles both NHWC and NCHW formats:
    - NHWC: (N,H,W,C) where C in {1,3,4}
    - NCHW: (N,C,H,W) where C in {1,3,4}
    """
    if x.ndim == RGB_DIMS:
        # Could be (N,H,W) or (H,W,C) - check if last dim is channels
        return x.shape[-1] not in COMPATIBLE_CHANNELS
    if x.ndim == BATCH_DIMS:
        # Check for both NHWC and NCHW formats
        channels = min(x.shape[1:])  # Smallest non-batch dim is likely channels
        return channels in COMPATIBLE_CHANNELS
    return False


def convert_to_list(image_data: np.ndarray) -> List[np.ndarray]:
    """Convert the input data into a list of image arrays.

    Args:
        image_data: The image data to be converted into a list of images.

    Returns:
        A list of numpy arrays, each representing a single image.
        This can be a single image array or a list of images.

    Raises:
        ValueError: If the input format is not supported or does not fit expected
            single or batch image configurations.
    """
    if isinstance(image_data, (list, tuple)):
        if all(is_single_image(item) for item in image_data):
            return image_data  # already in the correct format
        if len(image_data) == 1 and is_batch_image(image_data[0]):
            return list(image_data[0])

    if isinstance(image_data, np.ndarray):
        if is_single_image(image_data):
            return [image_data]
        if is_batch_image(image_data):
            return list(image_data)

    raise ValueError("Invalid input format.")


def get_image_hw(im: np.ndarray) -> Tuple[int, int]:
    """Return (H, W) from an image in HW, HWC, CHW, NHWC, or NCHW format."""
    ndim = im.ndim
    shape = im.shape

    if ndim == GRAYSCALE_DIMS:
        return shape  # HW
    if ndim == RGB_DIMS:
        return shape[1:3] if shape[0] in COMPATIBLE_CHANNELS else shape[:2]
    if ndim == BATCH_DIMS:
        return shape[2:4] if shape[1] in COMPATIBLE_CHANNELS else shape[1:3]

    raise ValueError(f"Unsupported image shape: {shape}")


def convert_to_nested_list(
    group_count: int,
    image_data: Union[np.ndarray, List[np.ndarray], List[List[np.ndarray]]],
) -> Union[List[np.ndarray], List[List[np.ndarray]]]:
    """Convert into a nested list of images based on the specified group count.

    Args:
        group_count: The number of top-level groups in the nested list.
        image_data: The image data to be organized into nested lists.
            This can be a single image, a batch of images, or a pre-formatted list
            of image arrays.

    Returns:
        A nested list of images organized according to the specified `group_count`.

    Raises:
        ValueError: If the input data cannot be formatted into the required nested
            list structure according to the `group_count` or based on the nature
            of the images provided.
    """
    if group_count == 1:
        return convert_to_list(image_data)

    if (
        len(image_data) == group_count
        and all(isinstance(item, (list, tuple)) for item in image_data)
        and all(is_single_image(im) for item in image_data for im in item)
    ):
        return image_data  # already in the correct format

    if len(image_data) != group_count:
        raise ValueError("Mismatch between group count and input data.")

    if isinstance(image_data, (list, tuple)):
        return [convert_to_list(item) for item in image_data]

    raise ValueError("Invalid input format.")
